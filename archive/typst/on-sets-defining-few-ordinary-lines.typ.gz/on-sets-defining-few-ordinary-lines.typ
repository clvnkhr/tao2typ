// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/
// Converted to Typst by tao2typ: "2026-10-14T16:36:53.020182+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On sets defining few ordinary lines", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On sets defining few ordinary lines")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 August 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/")[#text("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and I have just uploaded to the arXiv our new paper “")#link("http://arxiv.org/abs/1208.4714")[#text("On sets defining few ordinary lines")]#text("“, submitted to ")#link("http://www.springer.com/new+%26+forthcoming+titles+(default)/journal/454")[#text("Discrete and Computational Geometry")]#text(". This paper asymptotically solves two old questions concerning finite configurations of points ")#mi("{P}")#text(" in the plane ")#mi("{{\\mathbb R}^2}")#text(". Given a set ")#mi("{P}")#text(" of ")#mi("{n}")#text(" points in the plane, define an ")#emph[#text("ordinary line")]#text(" to be a line containing exactly two points of ")#mi("{P}")#text(". The classical ")#link("http://en.wikipedia.org/wiki/Sylvester-Gallai_theorem")[#text("Sylvester-Gallai theorem")]#text(", first posed as a problem by Sylvester in 1893, asserts that as long as the points of ")#mi("{P}")#text(" are not all collinear, ")#mi("{P}")#text(" defines at least one ordinary line:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/08/sylvester-question.jpg")[#image("../assets/279839a4c2cc5dfdb551d79fdeaa880e82bcfce339a0a74a290eb13532fe6c87-b266f904b8bb67f278159a5162a42d700582bbcc5c94406aac34c7204aa35a94.jpg", width: 90%)]

#text("It is then natural to pose the question of what is the minimal number of ordinary lines that a set of ")#mi("{n}")#text(" non-collinear points can generate. In 1940, ")#link("http://www.ams.org/mathscinet-getitem?mr=4476")[#text("Melchior gave")]#text(" an elegant proof of the Sylvester-Gallai theorem based on projective duality and Euler’s formula ")#mi("{V-E+F=2}")#text(", showing that at least three ordinary lines must be created; in 1951, ")#link("http://www.ams.org/mathscinet-getitem?mr=41447")[#text("Motzkin showed")]#text(" that there must be ")#mi("{\\gg n^{1/2}}")#text(" ordinary lines. Previously to this paper, the best lower bound was ")#link("http://www.ams.org/mathscinet-getitem?mr=1194036")[#text("by Csima and Sawyer")]#text(", who in 1993 showed that there are at least ")#mi("{6n/13}")#text(" ordinary lines. In the converse direction, if ")#mi("{n}")#text(" is even, then by considering ")#mi("{n/2}")#text(" equally spaced points on a circle, and ")#mi("{n/2}")#text(" points on the line at infinity in equally spaced directions, one can find a configuration of ")#mi("{n}")#text(" points that define just ")#mi("{n/2}")#text(" ordinary lines.")

#text("As first observed by Böröczky, variants of this example also give few ordinary lines for odd ")#mi("{n}")#text(", though not quite as few as ")#mi("{n/2}")#text("; more precisely, when ")#mi("{n=1 \\text{ mod } 4}")#text(" one can find a configuration with ")#mi("{3(n-1)/4}")#text(" ordinary lines, and when ")#mi("{n = 3 \\text{ mod } 4}")#text(" one can find a configuration with ")#mi("{3(n-3)/4}")#text(" ordinary lines. Our first main result is that these configurations are best possible for sufficiently large ")#mi("{n}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Dirac-Motzkin conjecture)")]#text(" ")#emph[#metadata(none) <tao-6a95eb4f0762bfe01733>#text(" If ")#mi("{n}")#text(" is sufficiently large, then any set of ")#mi("{n}")#text(" non-collinear points in the plane will define at least ")#mi("{\\lfloor n/2\\rfloor}")#text(" ordinary lines. Furthermore, if ")#mi("{n}")#text(" is odd, at least ")#mi("{3\\lfloor n/4\\rfloor}")#text(" ordinary lines must be created. ")]
]

#text("The ")#emph[#text("Dirac-Motzkin conjecture")]#text(" asserts that the first part of this theorem in fact holds for all ")#mi("{n}")#text(", not just for sufficiently large ")#mi("{n}")#text("; in principle, our theorem reduces that conjecture to a finite verification, although our bound for “sufficiently large” is far too poor to actually make this feasible (it is of double exponential type). (There are two known configurations for which one has ")#mi("{(n-1)/2}")#text(" ordinary lines, one with ")#mi("{n=7}")#text(" (discovered ")#link("http://www.ams.org/mathscinet-getitem?mr=97014")[#text("by Kelly and Moser")]#text("), and one with ")#mi("{n=13}")#text(" (discovered ")#link("http://www.ams.org/mathscinet-getitem?mr=235452")[#text("by Crowe and McKee")]#text(").)")

#text("Our second main result concerns not the ordinary lines, but rather the ")#emph[#mi("{3}")#text("-rich lines")]#text(" of an ")#mi("{n}")#text("-point set – a line that meets exactly three points of that set. A simple double counting argument (counting pairs of distinct points in the set in two different ways) shows that there are at most")

#align(center)[#tao-fit-display[#mitex("\\binom{n}{2} / \\binom{3}{2} = \\frac{1}{6} n^2 - \\frac{1}{6} n")]]

#mi("{3}")#text("-rich lines. On the other hand, on an ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]#text(", three distinct points P,Q,R on that curve are collinear precisely when they sum to zero with respect to the group law on that curve. Thus (as observed first by Sylvester in 1868), any finite subgroup of an elliptic curve (of which one can produce numerous examples, as elliptic curves in ")#mi("{{\\mathbb R}^2}")#text(" have the group structure of either ")#mi("{{\\mathbb R}/{\\mathbb Z}}")#text(" or ")#mi("{{\\mathbb R}/{\\mathbb Z} \\times ({\\mathbb Z}/2{\\mathbb Z})}")#text(") can provide examples of ")#mi("{n}")#text("-point sets with a large number of ")#mi("{3}")#text("-rich lines (")#mi("{\\lfloor \\frac{1}{6} n^2 - \\frac{1}{2} n + 1\\rfloor}")#text(", to be precise). One can also shift such a finite subgroup by a third root of unity and obtain a similar example with only one fewer ")#mi("{3}")#text("-rich line. ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/08/sylvester.pdf")[#text("Sylvester then formally posed")]#text(" the question of determining whether this was best possible.")

#text("This problem was known as the ")#link("http://en.wikipedia.org/wiki/Orchard-planting_problem")[#text("Orchard planting problem")]#text(", and was given a more poetic formulation as such by Jackson in 1821 (nearly fifty years prior to Sylvester!):")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/08/jackson-question.jpg")[#image("../assets/ba6413dfbb75ab3788c17dc97382e550642278a8f34e0ae848193260c7ecb6e8-3653e5023375b2b7caa1d720ad2063bbeacbfd7357e591b13a97d0729734fc18.jpg", width: 90%)]

#text("Our second main result answers this problem affirmatively in the large ")#mi("{n}")#text(" case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Orchard planting problem)")]#text(" ")#emph[#metadata(none) <tao-68566dc699f6bb9ea633>#text(" If ")#mi("{n}")#text(" is sufficiently large, then any set of ")#mi("{n}")#text(" points in the plane will determine at most ")#mi("{\\lfloor \\frac{1}{6} n^2 - \\frac{1}{2} n + 1\\rfloor}")#text(" ")#mi("{3}")#text("-rich lines. ")]
]

#text("Again, our threshold for “sufficiently large” for this ")#mi("{n}")#text(" is extremely large (though slightly less large than in the previous theorem), and so a full solution of the problem, while in principle reduced to a finitary computation, remains infeasible at present.")

#text("Our results also classify the extremisers (and near extremisers) for both of these problems; basically, the known examples mentioned previously are (up to projective transformation) the only extremisers when ")#mi("{n}")#text(" is sufficiently large.")

#text("Our proof strategy follows the “inverse theorem method” from additive combinatorics. Namely, rather than try to prove ")#emph[#text("direct")]#text(" theorems such as lower bounds on the number of ordinary lines, or upper bounds on the number of ")#mi("{3}")#text("-rich lines, we instead try to prove ")#emph[#text("inverse")]#text(" theorems (also known as ")#emph[#text("structure theorems")]#text("), in which one attempts a structural classification of all configurations with very few ordinary lines (or very many ")#mi("{3}")#text("-rich lines). In principle, once one has a sufficiently explicit structural description of these sets, one simply has to compute the precise number of ordinary lines or ")#mi("{3}")#text("-rich lines in each configuration in the list provided by that structural description in order to obtain results such as the two theorems above.")

#text("Note from double counting that sets with many ")#mi("{3}")#text("-rich lines will necessarily have few ordinary lines. Indeed, if we let ")#mi("{N_k}")#text(" denote the set of lines that meet exactly ")#mi("{k}")#text(" points of an ")#mi("{n}")#text("-point configuration, so that ")#mi("{N_3}")#text(" is the number of ")#mi("{3}")#text("-rich lines and ")#mi("{N_2}")#text(" is the number of ordinary lines, then we have the double counting identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=2}^n \\binom{k}{2} N_k = \\binom{n}{2}")]]

#text("which among other things implies that any counterexample to the orchard problem can have at most ")#mi("{n+O(1)}")#text(" ordinary lines. In particular, any structural theorem that lets us understand configurations with ")#mi("{O(n)}")#text(" ordinary lines will, in principle, allow us to obtain results such as the above two theorems.")

#text("As it turns out, we do eventually obtain a structure theorem that is strong enough to achieve these aims, but it is difficult to prove this theorem directly. Instead we proceed more iteratively, beginning with a “cheap” structure theorem that is relatively easy to prove but provides only a partial amount of control on the configurations with ")#mi("{O(n)}")#text(" ordinary lines. One then builds upon that theorem with additional arguments to obtain an “intermediate” structure theorem that gives better control, then a “weak” structure theorem that gives even more control, a “strong” structure theorem that gives yet more control, and then finally a “very strong” structure theorem that gives an almost complete description of the configurations (but only in the asymptotic regime when ")#mi("{n}")#text(" is very large). It turns out that the “weak” theorem is enough for the orchard planting problem, and the “strong” version is enough for the Dirac-Motzkin conjecture. (So the “very strong” structure theorem ends up being unnecessary for the two applications given, but may be of interest for other applications.) Note that the stronger theorems do not completely supercede the weaker ones, because the quantitative bounds in the theorems get progressively worse as the control gets stronger.")

#text("Before we state these structure theorems, note that all the examples mentioned previously of sets with few ordinary lines involved ")#link("http://en.wikipedia.org/wiki/Cubic_plane_curve")[#text("cubic curves")]#text(": either irreducible examples such as elliptic curves, or reducible examples such as the union of a circle (or more generally, a conic section) and a line. (We also allow singular cubic curves, such as the union of a conic section and a tangent line, or a singular irreducible curve such as ")#mi("{\\{ (x,y): y^2 = x^3 \\}}")#text(".) This turns out to be no coincidence; cubic curves happen to be very good at providing many ")#mi("{3}")#text("-rich lines (and thus, few ordinary lines), and conversely it turns out that they are essentially the only way to produce such lines. This can already be evidenced by our cheap structure theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Cheap structure theorem)")]#text(" ")#emph[#text(" Let ")#mi("{P}")#text(" be a configuration of ")#mi("{n}")#text(" points with at most ")#mi("{{}Kn}")#text(" ordinary lines for some ")#mi("{K \\geq 1}")#text(". Then ")#mi("{P}")#text(" can be covered by at most ")#mi("{500K}")#text(" cubic curves. ")]
]

#text("This theorem is already a non-trivial amount of control on sets with few ordinary lines, but because the result does not specify the nature of these curves, and how they interact with each other, it does not seem to be directly useful for applications. The intermediate structure theorem given below gives a more precise amount of control on these curves (essentially guaranteeing that all but at most one of the curve components are lines):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Intermediate structure theorem)")]#text(" ")#emph[#text(" Let ")#mi("{P}")#text(" be a configuration of ")#mi("{n}")#text(" points with at most ")#mi("{{}Kn}")#text(" ordinary lines for some ")#mi("{K \\geq 1}")#text(". Then one of the following is true: ")]

#enum(start: 1, 
[#mi("{P}")#text(" lies on the union of an irreducible cubic curve and an additional ")#mi("{O(K^{O(1)})}")#text(" points.")],
[#mi("{P}")#text(" lies on the union of an irreducible conic section and an additional ")#mi("{O(K^{O(1)})}")#text(" lines, with ")#mi("{n/2 + O(K^{O(1)})}")#text(" of the points on ")#mi("{P}")#text(" in either of the two components.")],
[#mi("{P}")#text(" lies on the union of ")#mi("{O(K)}")#text(" lines and an additional ")#mi("{O(K^{O(1)})}")#text(" points.")]
)
]

#text("By some additional arguments (including a very nice argument supplied to us by Luke Alexander Betts, an undergraduate at Cambridge, which replaces a much more complicated (and weaker) argument we originally had for this paper), one can cut down the number of lines in the above theorem to just one, giving a more useful structure theorem, at least when ")#mi("{n}")#text(" is large:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Weak structure theorem)")]#text(" ")#emph[#text(" Let ")#mi("{P}")#text(" be a configuration of ")#mi("{n}")#text(" points with at most ")#mi("{{}Kn}")#text(" ordinary lines for some ")#mi("{K \\geq 1}")#text(". Assume that ")#mi("{n \\geq \\exp(\\exp(CK^C))}")#text(" for some sufficiently large absolute constant ")#mi("{C}")#text(". Then one of the following is true: ")]

#enum(start: 1, 
[#mi("{P}")#text(" lies on the union of an irreducible cubic curve and an additional ")#mi("{O(K^{O(1)})}")#text(" points.")],
[#mi("{P}")#text(" lies on the union of an irreducible conic section, a line, and an additional ")#mi("{O(K^{O(1)})}")#text(" points, with ")#mi("{n/2 + O(K^{O(1)})}")#text(" of the points on ")#mi("{P}")#text(" in either of the first two components.")],
[#mi("{P}")#text(" lies on the union of a single line and an additional ")#mi("{O(K^{O(1)})}")#text(" points.")]
)
]

#text("As mentioned earlier, this theorem is already strong enough to resolve the orchard planting problem for large ")#mi("{n}")#text(". The presence of the double exponential here is extremely annoying, and is the main reason why the final thresholds for “sufficiently large” in our results are excessively large, but our methods seem to be unable to eliminate these exponentials from our bounds (though they can fortunately be confined to a lower bound for ")#mi("{n}")#text(", keeping the other bounds in the theorem polynomial in ")#mi("{K}")#text(").")

#text("For the Dirac-Motzkin conjecture one needs more precise control on the portion of ")#mi("{P}")#text(" on the various low-degree curves indicated. This is given by the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Strong structure theorem)")]#text(" ")#emph[#text(" Let ")#mi("{P}")#text(" be a configuration of ")#mi("{n}")#text(" points with at most ")#mi("{{}Kn}")#text(" ordinary lines for some ")#mi("{K \\geq 1}")#text(". Assume that ")#mi("{n \\geq \\exp(\\exp(CK^C))}")#text(" for some sufficiently large absolute constant ")#mi("{C}")#text(". Then, after adding or deleting ")#mi("{O(K^{O(1)})}")#text(" points from ")#mi("{P}")#text(" if necessary (modifying ")#mi("{n}")#text(" appropriately), and then applying a projective transformation, one of the following is true: ")]

#enum(start: 1, 
[#mi("{P}")#text(" is a finite subgroup of an elliptic curve (EDIT: as pointed out in comments, one also needs to allow for finite subgroups of acnodal singular cubic curves), possibly shifted by a third root of unity.")],
[#mi("{P}")#text(" is the Borozcky example mentioned previously (the union of ")#mi("{n/2}")#text(" equally spaced points on the circle, and ")#mi("{n/2}")#text(" points on the line at infinity).")],
[#mi("{P}")#text(" lies on a single line.")]
)
]

#text("By applying a final “cleanup” we can replace the ")#mi("{O(K^{O(1)})}")#text(" in the above theorem with the optimal ")#mi("{O(K)}")#text(", which is our “very strong” structure theorem. But the strong structure theorem is already sufficient to establish the Dirac-Motzkin conjecture for large ")#mi("{n}")#text(".")

#text("There are many tools that go into proving these theorems, some of which are extremely classical (with at least one going back to the ancient Greeks), and others being more recent. I will discuss some (not all) of these tools below the fold, and more specifically:")

#enum(start: 1, 
[#text("Melchior’s argument, based on projective duality and Euler’s formula, initially used to prove the Sylvester-Gallai theorem;")],
[#text("Chasles’ version of the ")#link("http://en.wikipedia.org/wiki/Cayley%E2%80%93Bacharach_theorem")[#text("Cayley-Bacharach theorem")]#text(", which can convert dual triangular grids (produced by Melchior’s argument) into cubic curves that meet many points of the original configuration ")#mi("{P}")#text(");")],
[#link("http://en.wikipedia.org/wiki/Menelaus%27_theorem")[#text("Menelaus’s theorem")]#text(", which is useful for producing ordinary lines when the point configuration lies on a few ")#emph[#text("non-concurrent")]#text(" lines, particularly when combined with a sum-product estimate of ")#link("http://www.ams.org/mathscinet-getitem?mr=1772612")[#text("Elekes, Nathanson, and Ruzsa")]#text(";")],
[#text("Betts’ argument, that produces ordinary lines when the point configuration lies on a few ")#emph[#text("concurrent")]#text(" lines;")],
[#text("A ")#link("http://www.ams.org/mathscinet-getitem?mr=1612877")[#text("result of Poonen and Rubinstein")]#text(" that any point not on the origin or unit circle can lie on at most seven chords connecting roots of unity; this, together with a variant for elliptic curves, gives the very strong structure theorem, and is also (a strong version of) what is needed to finish off the Dirac-Motzkin and orchard planting problems from the structure theorems given above.")]
)

#text("There are also a number of more standard tools from arithmetic combinatorics (e.g. a version of the Balog-Szemeredi-Gowers lemma) which are needed to tie things together at various junctures, but I won’t say more about these methods here as they are (by now) relatively routine.")

#metadata(none) <tao-15357dce4754ae864e27>

#strong[#text("1. Melchior’s argument ")]

#text("Our starting point was a closer look at Melchior’s proof of the Sylvester-Gallai theorem establishing a non-trivial bound on the number ")#mi("{N_2}")#text(" of ordinary lines. The first step was to look at the ")#link("http://en.wikipedia.org/wiki/Duality_(projective_geometry)")[#text("projective dual")]#text(" ")#mi("{P^*}")#text(" of the point set ")#mi("{P}")#text(", in which each point ")#mi("{p}")#text(" is replaced by its dual line ")#mi("{p^*}")#text(". (For this, one should really work in the projective plane ")#mi("{{\\bf RP}^2}")#text(" rather than the affine plane ")#mi("{{\\mathbb R}^2}")#text(", but let us ignore this technical detail for this post.) One now has a collection ")#mi("{P^*}")#text(" of ")#mi("{n}")#text(" lines that intersect each other in a number of points; each ordinary line now dualises to a point incident to exactly two of the lines in ")#mi("{P^*}")#text(", a ")#mi("{3}")#text("-rich line dualises to a point incident to exactly three lines, and so forth.")

#text("Now look at the graph (or more precisely, the drawing) determined by these points of intersection, and the line segments of lines in ")#mi("{P^*}")#text(" cut out by these points. This partitions the (projective) plane into a number of vertices, edges, and polygonal faces, which by Euler’s formula obey the relationship ")#mi("{V-E+F=1}")#text(". (Because we are working on the projective plane rather than the affine plane or sphere, the relevant Euler characteristic here is ")#mi("{1}")#text(", rather than ")#mi("{2}")#text(".) If one counts the number of vertices, edges, and faces in this configuration, one quickly arrives at the identities")

#tao-aligned(keep: true)[


#tao-math("V  & = \\sum_{k=2}^n N_k", block: true)



#tao-math("E  & = \\sum_{k=2}^n k N_k = \\frac{1}{2} \\sum_{s=3}^n s M_s", block: true)



#tao-math("F  & = \\sum_{s=3}^n M_s", block: true)
]

#text("where ")#mi("{N_k}")#text(" is the number of ")#mi("{k}")#text("-rich lines, and ")#mi("{M_s}")#text(" is the number of faces with ")#mi("{s}")#text(" sides. Euler’s formula ")#mi("{V-E+F=1}")#text(" then can be rearranged, after some elementary algebra, as ")#emph[#text("Melchior’s identity")]

#align(center)[#tao-fit-display[#mitex("N_2 = 3 + \\sum_{k=4}^n (k-3) N_k + \\sum_{s=4}^n (s-3) M_s,")]]

#text("which among other things gives Melchior’s bound ")#mi("{N_2 \\geq 3}")#text(", which implies the Sylvester-Gallai theorem. But it also shows that when the number ")#mi("{N_2}")#text(" of ordinary lines is small, the number of faces with more than ")#mi("{3}")#text(" sides is also small; in particular, when there are ")#mi("{O(n)}")#text(" ordinary lines, all but ")#mi("{O(n)}")#text(" the faces are triangles. Thus, in such cases the ")#mi("{n}")#text(" lines of ")#mi("{P^*}")#text(" must form configurations which locally resemble a triangular grid most of the time. The following configuration (of ")#mi("{P^*}")#text(", not of ")#mi("{P}")#text(") is typical:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/08/hexagon1.jpg")[#image("../assets/29d874261a8d0b1c8f92f96553777a1da653feb59421b5c97185d28ea65ac24e-989d5e4f6398d173d46ff8522ab00c9baf457568fc9e28775851a75e78a1bad0.jpg", width: 90%)]

#strong[#text("2. Chasles’ Cayley-Bacharach theorem ")]

#text("Once one sees the above consequence of Melchior’s argument, it becomes natural to ask what configurations of points have the property that their dual lines meet each other in local triangular grids. The three triplets of coloured lines in the above local triangular grid, when one removes the dualisation, become three triples of points which arrange in two different ways as collinear triples of points. This is precisely the type of configuration governed by the ")#link("http://en.wikipedia.org/wiki/Cayley%E2%80%93Bacharach_theorem")[#text("Cayley-Bacharach theorem")]#text(" (or more precisely, a version of this theorem first stated by Chasles):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Chasles)")]#text(" ")#emph[#text(" Suppose that two triples of lines meet each other transversely in nine distinct points. Then any cubic curve that passes through eight of these points, also passes through the ninth. ")]
]

#text("I blogged about this theorem in ")#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")[#text("this previous post")]#text("; the result is intimately connected to other classical facts in plane geometry such as ")#link("http://en.wikipedia.org/wiki/Pappus%27s_hexagon_theorem")[#text("Pappus’s theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Pascal%27s_theorem")[#text("Pascal’s theorem")]#text(", and the associativity of the elliptic curve group law. This theorem also clearly shows how cubic curves will arise in any analysis of sets with few ordinary lines; using this theorem, one can show that whenever three triplets of points in ")#mi("{P}")#text(" have their dual lines arranged in the hexagonal formation above, then any cubic curve that passes through eight of these points, also passes through the ninth. By iterating this observation (together with the conclusion from Melchior’s argument that there are large portions of the dual configuration that look like triangular grids), one can obtain the cheap structure theorem from routine combinatorial arguments (omitted here). Actually, these arguments provide not just one way to cover the set ")#mi("{P}")#text(" by a small number of cubic curves, but a large family of such ways; by comparing these coverings to each other (and making heavy use of ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(") one can eliminate a large number of possibilities for the cubic curves, eventually leading to the intermediate structure theorem.")

#strong[#text("3. Menelaus theorem ")]

#text("A good model case to consider when trying to understand ordinary lines is the case when the point set ")#mi("{P}")#text(" can be covered by a bounded number of lines, with a fair number of points (")#mi("{\\gg n}")#text(") on each line. This is a key case to understand when one wants to improve the intermediate structure theorem; in fact, by some fairly routine (but quantitatively expensive) reductions, one can basically reduce to this case when trying to reduce the number of lines in the intermediate structure theorem and replace it with the weak structure theorem.")

#text("One key subcase of this model case occurs when ")#mi("{P}")#text(" lies on three ")#emph[#text("non-concurrent")]#text(" lines. In this case, ")#link("http://en.wikipedia.org/wiki/Menelaus%27_theorem")[#text("Menelaus’s theorem")]#text(" from classical Greek geometry shows that any collinearity on ")#mi("{P}")#text(" (i.e. lack of ordinary lines) is connected to multiplicative structure on the coordinates of ")#mi("{P}")#text(". For instance, if the lines in question are the ")#mi("{x}")#text("-axis ")#mi("{\\{y=0\\}}")#text(", the ")#mi("{y}")#text("-axis ")#mi("{\\{x=0\\}}")#text(", and the shifted ")#mi("{x}")#text("-axis ")#mi("{\\{y=1\\}}")#text(", then observe that any three points ")#mi("{(r,0)}")#text(", ")#mi("{(0,s)}")#text(", ")#mi("{(t,1)}")#text(" (not on the intersections between these three lines) are collinear precisely when")

#align(center)[#tao-fit-display[#mitex("t = r \\cdot \\frac{s}{s-1}")]]

#text("thus providing a multiplicative relationship between the coordinates ")#mi("{r,s,t}")#text(" of the three points in question. The multiplicative relations given by Menelaus’s theorem already show that one cannot have too many collinear triples among any finite set of points in a triple of non-concurrent lines, basically because the multiplicative real line ")#mi("{{\\mathbb R}^\\times}")#text(" do not contain large finite subgroups. (To make this intuition precise requires some basic tools from arithmetic combinatorics, which we omit here.)")

#text("A more complicated version of these arguments also allows one to handle larger collections of mostly non-concurrent lines. Each triple of non-concurrent lines gives rise to a slightly different multiplicative relationship between the concurrent points on these triples. It turns out that there is a ")#emph[#text("sum-product phenomenon")]#text(" that ensures that these multiplicative relationships are “incompatible” with each other; any configuration of points which has a lot of collinear triples with respect to one of these relationships, necessarily has few collinear triples with respect to other relationships. This can be formalised by arithmetic combinatorics tools, and more precisely a result of ")#link("http://www.ams.org/mathscinet-getitem?mr=1772612")[#text("Elekes, Nathanson, and Ruzsa")]#text(", which (by using the Szemeredi-Trotter theorem) established results to the effect that if ")#mi("{A}")#text(" was a set of reals for which ")#mi("{A-A}")#text(" is small, then ")#mi("{f(A)-f(A)}")#text(" was necessarily large for suitably nonlinear choices of ")#mi("{f}")#text(" (e.g. strictly convex). One can reduce the study of collinearity on bounded collections of mostly non-concurrent lines to the Elekes-Nathanson-Ruzsa result by some routine arithmetic combinatorics arguments which we omit here.")

#strong[#text("4. Betts’ argument ")]

#text("The arguments based on Menelaus’s theorem allow one to produce many ordinary lines when a large fraction of the points ")#mi("{P}")#text(" lie on mostly non-collinear lines. But there is a key case not covered by the Menelaus argument, which is when the points ")#mi("{P}")#text(" lie on a set of collinear lines, which (after projective transformation) we can take to be parallel. To eliminate this case (and some related cases) from consideration, we use an argument of Luke Betts (superceding a much more complicated use of additive combinatorics tools, which no longer appears in the paper). Betts establishes a quantitative version of the following fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8")]#text(" ")#emph[#text(" Suppose that a set ")#mi("{P}")#text(" of ")#mi("{n}")#text(" points lie on ")#mi("{O(1)}")#text(" parallel lines, with the number of lines being at least two, and with each line containing ")#mi("{\\gg n}")#text(" points of ")#mi("{P}")#text(". Then ")#mi("{P}")#text(" determines ")#mi("{\\gg n^2}")#text(" ordinary lines. ")]
]

#text("Betts’s argument proceeds by first dualising the theorem to the following equivalent form;")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9")]#text(" ")#emph[#text(" Suppose that a set ")#mi("{L}")#text(" of ")#mi("{n}")#text(" lines lie in ")#mi("{O(1)}")#text(" families of parallel lines, with the number of directions being at least two, and with each direction having ")#mi("{\\gg n}")#text(" lines. Then there are ")#mi("{\\gg n^2}")#text(" points that are ordinary (i.e. are incident to exactly two lines in ")#mi("{L}")#text("). ")]
]

#text("The proof of this theorem, exploiting convexity, is elementary enough that we can describe the proof here. Let ")#mi("{Q}")#text(" be the set of all non-ordinary intersection points of lines in ")#mi("{L}")#text(", i.e. points incident to at least three lines of ")#mi("{L}")#text(". The claim is easy if all the points in ")#mi("{Q}")#text(" are collinear, so suppose this is not the case. Then we may find a vertex ")#mi("{p}")#text(" in ")#mi("{Q}")#text(" that is a vertex of the convex hull of ")#mi("{Q}")#text(". This point ")#mi("{q}")#text(" is incident to at least three lines of ")#mi("{L}")#text(", and is thus the endpoint of at least three rays in lines in ")#mi("{L}")#text(" that lie completely outside of the convex hull of ")#mi("{Q}")#text(", so that any intersection point on these lines is necessarily ordinary. Of these three rays, one lies between the other two (in the complement of ")#mi("{Q}")#text("). Every line in ")#mi("{L}")#text(" parallel to this middle ray, will meet one of the other two rays, and by the previous discussion, every one of these intersection points is ordinary. Thus we have found two lines in ")#mi("{L}")#text(" (the lines containing the two exterior rays) which between them capture ")#mi("{\\gg n}")#text(" ordinary points. Removing these lines and iterating, we obtain the theorem.")

#text("By combining the Menelaus theorem-based argument with Betts’ theorem and some additional combinatorial arguments, we were able to upgrade the intermediate structure theorem to the weak structure theorem. Using additional additive combinatorics tools (exploiting the group (or pseudo-group) structure on cubic curves, which is most well known in the case of elliptic curves, but also survives (in a somewhat degenerate form) for other cubic curves, such as singular cubic curves, unions of three lines, or the union of a conic and a line) we can then get the strong structure theorem.")

#strong[#text("5. Poonen-Rubinstein theorems ")]

#text("The strong structure theorem shows that sets with ")#mi("{O(n)}")#text(" ordinary lines are a perturbation (by adding or deleting ")#mi("{O(1)}")#text(" points, and by applying a projective transformation) from a very explicit example, either arising from a finite subgroup of an elliptic curve, equally spaced points on a circle and line, or points on a line. The projective transform is a symmetry of the problem and is harmless; the only remaining issue is to understand the effect of the ")#mi("{O(1)}")#text(" points added or deleted on the number of ordinary lines. Due to the very explicit nature of these examples, deleting a point is easy to understand; the main remaining difficulty is to understand the effect that the addition of a single point to one of these explicit configurations has on the number of ordinary lines. In particular, one wishes to prevent the scenario that the addition of such a point removes more ordinary lines than it creates, by being collinear with many pairs of points in the original configuration that were previously defining an ordinary line.")

#text("The following ")#link("http://www.ams.org/mathscinet-getitem?mr=1612877")[#text("result of Poonen and Rubinstein")]#text(" (a corollary of their more detailed results) is relevant for excluding this scenario:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Poonen-Rubinstein)")]#text(" ")#emph[#text(" Let ")#mi("{p}")#text(" be a point not on the unit circle or at the origin. Then ")#mi("{p}")#text(" lies on at most seven chords connecting two roots of unity. ")]
]

#text("It turns out (basically by an application of Menelaus’s theorem) that if three chords connecting roots of unity are concurrent, then there is a linear relationship between twelve other roots of unity closely related to the original six roots of unity, namely that these roots of unity sum to zero. The Poonen-Rubinstein paper uses some Galois theory and numerical computation to completely classify all the ways in which twelve or fewer roots of unity can sum to zero, which then leads to the above theorem. It turns out that a variant of the argument also works for secants, showing that a point outside the unit circle can lie on at most ")#mi("{O(1)}")#text(" secants passing through two roots of unity.")

#text("One would also like to have a similar result in which “roots of unity” are replaced by “elements of a finite subgroup of an elliptic curve”. Unfortunately, the Galois-theoretic techniques seem to become unavailable, and we were unable to establish the full analogue of the Poonen-Rubinstein theorem for these finite subgroups. We could however show that given a finite subgroup of order ")#mi("{n}")#text(", any point ")#mi("{p}")#text(" not on the curve formed at least ")#mi("{\\gg n}")#text(" ordinary lines with that subgroup, which was good enough for our applications; this came from an order-theoretic argument investigating how triples of adjacent points on the finite subgroup could form collinear triples with ")#mi("{p}")#text(".")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-163238")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("I can’t find anywhere definitions of L or M, or their relation to K in")#linebreak()#text(" theorems 3 — 6; presumably the set L in theorem 9 is unrelated?")

#text("Fred Lunnon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-163241")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("This is a strange WordPress LaTeX rendering bug which I have encountered before; there seems to be some collisions between LaTeX images (so, currently, ")#mi("Kn")#text(" is being rendered as ")#mi("LM")#text(" for some reason). Mousing over the image should reveal the LaTeX source. I’ll try to fix it, but usually the problem goes away by itself (somewhat mysteriously).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddf678caa9092510aeba5fe27e4bcfedd89ee6b2c7daf4410903126d15074d4a-9a35afe28f614ee781084e091371cf37bacae9085913cb812f15e8d6ae498954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emanuele Natale")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-163252")[#strong[#text("Emanuele Natale")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("@Lunnon in the paper LM is Kn, and looking those letters on the keyboard I guess it was a misprint that was then copied&pasted in what followed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddf678caa9092510aeba5fe27e4bcfedd89ee6b2c7daf4410903126d15074d4a-9a35afe28f614ee781084e091371cf37bacae9085913cb812f15e8d6ae498954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emanuele Natale")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-163254")[#strong[#text("Emanuele Natale")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("Sorry I didn’t reloaded the page before submitting to see the reply.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/815387abb27267e38e0a2f5283f676e11bbc6a335bc3cb3b21f217ced2c2319b-7a270c155a389afd795b534ca64eec559bec2a09b840c4cc7cb2b56940ad16d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duvall")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-163370")[#strong[#text("Duvall")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2012")])]

#text("Dear Terry,")

#text("I am sorry that this comment is a little bit off-topic, but I believe your blog is the right place to ask this question. Do you know any source where one can get an old paper of Vinogradov on the so-called equidistribution theorem, which says that irrational circle rotations at prime times are equally distributed. Somehow I was not able to find it. Any newer proofs would also work fine. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-165498")[#strong[#text("A Geometric Iteration with a Sylvester-Gallai Guarantee | Girls' Angle")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")]

#text("[…] of Sylvester-Gallai, Prof. Terrence Tao recently blogged about new results he obtained with Ben Green related to the theo…. They obtained far out results concerning the structure of finite sets of points that have very few […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4922346d8b56e6f2489d95005a871e26167c3da78efdf96fc1f707b59a6bfb3-d84c20e4c559abd8ee1d4230bf25902abd803f587777f5cecd8bfe9e301dd282.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frando")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-168456")[#strong[#text("Frando")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2012")])]

#text("Dear Terry, just one trivial remark about Luke Alexander Betts’ part in your paper. In the proof after the lemma 6.5, one should actually apply it ")#mi("\\lceil n/5\\rceil")#text(" times, instead of ")#mi("\\lfloor n/5\\rfloor")#text(" times. In the current state one actually obtains ")#mi("n^2/50-O(1)")#text(" ordinary points.")

#emph[#text("[This will be corrected in the next revision of the ms, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37fec22fb931350168f07d5610a4a1df0dc4f7050c935e193218adff47559d71-36e7178f9c5ee4db9101381e530332dac34f76d88319fb10f4f52b9ed3720369.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank de Zeeuw")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-176720")[#strong[#text("Frank de Zeeuw")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2012")])]

#text("This is a great result. I noticed one possible issue in the proof.")#linebreak()#text(" It uses the claim (on page 15 and 48 of the preprint) that for singular cubics, the group structure in ")#mi("\\mathbb{R}^2")#text(" can only be ")#mi("\\mathbb{R}")#text(" (cuspidal curve) or ")#mi("\\mathbb{R}\\times (\\mathbb{Z}/2\\mathbb{Z})")#text(" (nodal curve). I think this misses one case: for an “acnodal” curve the group structure is different.")#linebreak()#text(" I mean a cubic with an isolated point, for instance ")#mi("y^2 = x^3-x^2")#text(". It is nodal over ")#mi("\\mathbb{C}")#text(" in the sense that the tangent lines at the singularity have distinct slopes, but the slopes are complex. That the group structure is different can most easily be seen from the fact that these curves have 3 real inflection points (unlike the other singular cubics), one of which will be the identity at infinity, while the other two (")#mi("(4/3,\\pm 4/(3\\sqrt{3}))")#text(" for the example above) will be points of order 3 in the group.")#linebreak()#text(" I think the group in these cases is ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(", which would mean that there is another type of set with few ordinary lines, similar to the ones from nonsingular elliptic curves (it would happen in Lemma 7.2). I couldn’t find an explicit reference, but for instance using Silverman’s Arithmetic of Elliptic Curves, Ex.3.5, the group structure is that of the unit circle in ")#mi("\\mathbb{C}^*")#text(", which is indeed ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(". An online reference is ")#link("http://www.math.leidenuniv.nl/~edix/teaching/2010-2011/tag/davide2.pdf")[#text("http://www.math.leidenuniv.nl/~edix/teaching/2010-2011/tag/davide2.pdf")]#text(", Theorem 1, the twisted nodal case.")#linebreak()#text(" I hope this is helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-176873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2012")])]

#text("Hmm, you’re right, this is a case we overlooked. It appears that one can rectify the issue, basically by replacing “elliptic curve” by “elliptic curve or the smooth points of an acnodal cubic curve” throughout the paper, which makes some things (including the statements of some of the main theorems) a bit uglier, but otherwise the arguments seem to go through. Ben and I will try to amend the preprint accordingly over the next few days; thanks for pointing it out!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-188541")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2012")])]

#text("Does Proposition 8.2 contain a typo? It seems that adding a single point to ")#mi("X_{2m}")#text(" gives an example with at most ")#mi("3m")#text(" ordinary lines but which is not (in general) a Böröczky or near-Böröczky example – contradicting 8.2 for large enough ")#mi("m")#text(". Similarly in the proof I think ")#mi("X_{2m}")#text(" only determines $m$ tangent lines at the unit circle, rather than ")#mi("2m")#text(". If this is not a typo and I am misunderstanding the situation any clarification would be appreciated!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-188694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2012")])]

#text("Yes, this is a typo, sorry: 4m should be 3m (and 2m tangent lines should be m tangent lines). (For the purposes of proving Theorem 2.4, the change doesn’t end up mattering, indeed we could even go down to 2m and have the same result.) We’ll incorporate this correction in the next version of the ms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86ff5e51edbfa4c0436cc52d2368f2cde956c60d9e60784d067038f9f8d94c3f-fcd0b2de433bd43893eba9c0960d932ba92cbfd5ea1a5139d085ec4dc703342c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-189012")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2012")])]

#text("Thanks for the help. Thinking about this more, it seems that ")#mi("2m")#text(" is the correct statement here since adding a single point to ")#mi("X_{2m}")#text(" can result in non-Böröczky examples with at most ")#mi("2m")#text(" ordinary lines, e.g. adding a general point on the line at infinity, or adding the origin ")#mi("[0,0,1]")#text(" if ")#mi("m")#text(" is odd. The proof then doesn’t need the full power of 7.6, since in the first case just the ordinary lines to points at infinity are sufficient. In fact, just replacing ")#mi("m")#text(" by ")#mi("\\frac{m}{2}")#text(" in a handful of places clears up all the confusion I initially had.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-189020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2012")])]

#text("Ah, yes, you’re right. I see now how the problem arose in the first place; half the argument is written for X_2m (being adapted to part (i) of Proposition 2.1) and the other half for X_4m (being adapted to the other parts of Proposition 2.1). As you say, replacing m by m/2 in a number of places fixes everything.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On sets defining few ordinary lines « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-192706")[#strong[#text("On sets defining few ordinary lines « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] On sets defining few ordinary lines. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c3c025cc6031f3e0316bd99f66a4eb3a87043bd76001b8eb7f7de0c9489f57-9ce10ad1cbeb96317fc1680d74ac69b92ef8bcbe19d996bf36300388b23b4b30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minh Ngo")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-465289")[#strong[#text("Minh Ngo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2016")])]

#text("Reblogged this on ")#link("https://quangminhdtd.wordpress.com/2016/01/16/on-sets-defining-few-ordinary-lines/")[#text("Minh Ngo's blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-545559")[#strong[#text("To cheer you up in complicated times – A book proof by Rom Pinchasi and Alexandr Polyanskii for a 1978 Conjecture by Erdős and Purdy! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")]

#text("[…] me mention the 2012 solution by Ben Green and Terry Tao of the ordinary line conjecture and the Orchard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stronger")]], [#link("https://terrytao.wordpress.com/2012/08/24/on-sets-defining-few-ordinary-lines/#comment-545621")[#strong[#text("Stronger")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("I think saying you solved these two problems asymptotically is a bit misleadingly weak. Solving asymptotically would mean, for example, that any n non-collinear points in the plane determine at least (1/2+o(1))n ordinary lines. Regardless, very interesting blog post and paper. Thank you.")
]
