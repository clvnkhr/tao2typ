// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/
// Converted to Typst by tao2typ: "2026-10-14T08:50:44.378718+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The double Duhamel trick and the in/out decomposition", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The double Duhamel trick and the in/out decomposition")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/")[#text("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a technical post inspired by separate conversations with Jim Colliander and with Soonsik Kwon on the relationship between two techniques used to control non-radiating solutions to dispersive nonlinear equations, namely the “double Duhamel trick” and the “in/out decomposition”. See for instance ")#link("http://www.math.ucla.edu/~visan/ClayLectureNotes.pdf")[#text("these lecture notes of Killip and Visan")]#text(" for a survey of these two techniques and other related methods in the subject. (I should caution that this post is likely to be unintelligible to anyone not already working in this area.)")

#text("For sake of discussion we shall focus on solutions to a nonlinear Schrödinger equation")

#align(center)[#tao-fit-display[#mitex("iu_t + \\Delta u = F(u)")]]

#text("and we will not concern ourselves with the specific regularity of the solution ")#mi("{u}")#text(", or the specific properties of the nonlinearity ")#mi("{F}")#text(" here. We will also not address the issue of how to justify the formal computations being performed here.")

#text("Solutions to this equation enjoy the ")#emph[#text("forward Duhamel formula")]

#align(center)[#tao-fit-display[#mitex("u(t) = e^{i(t-t_0)\\Delta} u(t_0) - i \\int_{t_0}^t e^{i(t-t^{\\prime})\\Delta} F(u(t^{\\prime}))\\ dt^{\\prime}")]]

#text("for times ")#mi("{t}")#text(" to the future of ")#mi("{t_0}")#text(" in the lifespan of the solution, as well as the ")#emph[#text("backward Duhamel formula")]

#align(center)[#tao-fit-display[#mitex("u(t) = e^{i(t-t_1)\\Delta} u(t_1) + i \\int_t^{t_1} e^{i(t-t^{\\prime})\\Delta} F(u(t^{\\prime}))\\ dt^{\\prime}")]]

#text("for all times ")#mi("{t}")#text(" to the past of ")#mi("{t_1}")#text(" in the lifespan of the solution. The first formula asserts that the solution at a given time is determined by the initial state and by the immediate past, while the second formula is the time reversal of the first, asserting that the solution at a given time is determined by the final state and the immediate future. These basic causal formulae are the foundation of the local theory of these equations, and in particular play an instrumental role in establishing local well-posedness for these equations. In this local theory, the main philosophy is to treat the homogeneous (or ")#emph[#text("linear")]#text(") term ")#mi("{e^{i(t-t_0)\\Delta} u(t_0)}")#text(" or ")#mi("{e^{i(t-t_1)\\Delta} u(t_1)}")#text(" as the main term, and the inhomogeneous (or ")#emph[#text("nonlinear")]#text(", or ")#emph[#text("forcing")]#text(") integral term as an error term.")

#text("The situation is reversed when one turns to the global theory, and looks at the asymptotic behaviour of a solution as one approaches a limiting time ")#mi("{T}")#text(" (which can be infinite if one has global existence, or finite if one has finite time blowup). After a suitable rescaling, the linear portion of the solution often disappears from view, leaving one with an ")#emph[#text("asymptotic blowup profile")]#text(" solution which is ")#emph[#text("non-radiating")]#text(" in the sense that the linear components of the Duhamel formulae vanish, thus ")#metadata(none) <tao-469cc643a19fb75901e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u(t) = - i \\int_{t_0}^t e^{i(t-t^{\\prime})\\Delta} F(u(t^{\\prime}))\\ dt^{\\prime}")]]

#text("and ")#metadata(none) <tao-3a4212c9845a0804adcc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u(t) = i \\int_t^{t_1} e^{i(t-t^{\\prime})\\Delta} F(u(t^{\\prime}))\\ dt^{\\prime}")]]

#text("where ")#mi("{t_0, t_1}")#text(" are the endpoint times of existence. (This type of situation comes up for instance in the Kenig-Merle approach to critical regularity problems, by reducing to a minimal blowup solution which is almost periodic modulo symmetries, and hence non-radiating.) These types of non-radiating solutions are propelled solely by their own nonlinear self-interactions from the immediate past or immediate future; they are generalisations of “nonlinear bound states” such as solitons.")

#text("A key task is then to somehow combine the forward representation ")#link(<tao-469cc643a19fb75901e5>)[#text("(1)")]#text(" and the backward representation ")#link(<tao-3a4212c9845a0804adcc>)[#text("(2)")]#text(" to obtain new information on ")#mi("{u(t)}")#text(" itself, that cannot be obtained from either representation alone; it seems that the immediate past and immediate future can collectively exert more control on the present than they each do separately. This type of problem can be abstracted as follows. Let ")#tao-math("{\\left\\|u(t)\\right\\|_{Y_+}}", block: false)#text(" be the infimal value of ")#tao-math("{\\left\\|F_+\\right\\|_N}", block: false)#text(" over all forward representations of ")#mi("{u(t)}")#text(" of the form ")#metadata(none) <tao-589e06e042ab7b04ede3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(t) = \\int_{t_0}^t e^{i(t-t^{\\prime})\\Delta} F_+(t^{\\prime}) \\ dt^{\\prime}")]]

#text("where ")#mi("{N}")#text(" is some suitable spacetime norm (e.g. a Strichartz-type norm), and similarly let ")#tao-math("{\\left\\|u(t)\\right\\|_{Y_-}}", block: false)#text(" be the infimal value of ")#tao-math("{\\left\\|F_-\\right\\|_N}", block: false)#text(" over all backward representations of ")#mi("{u(t)}")#text(" of the form ")#metadata(none) <tao-cdad01052b9e93b3c31f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("u(t) = \\int_{t}^{t_1} e^{i(t-t^{\\prime})\\Delta} F_-(t^{\\prime}) \\ dt^{\\prime}.")]]

#text("Typically, one already has (or is willing to assume as a bootstrap hypothesis) control on ")#mi("{F(u)}")#text(" in the norm ")#mi("{N}")#text(", which gives control of ")#mi("{u(t)}")#text(" in the norms ")#mi("{Y_+, Y_-}")#text(". The task is then to use the control of both the ")#mi("{Y_+}")#text(" and ")#mi("{Y_-}")#text(" norm of ")#mi("{u(t)}")#text(" to gain control of ")#mi("{u(t)}")#text(" in a more conventional Hilbert space norm ")#mi("{X}")#text(", which is typically a Sobolev space such as ")#mi("{H^s}")#text(" or ")#mi("{L^2}")#text(".")

#text("One can use some classical functional analysis to clarify this situation. By the closed graph theorem, the above task is (morally, at least) equivalent to establishing an ")#emph[#text("a priori")]#text(" bound of the form ")#metadata(none) <tao-0f76cdd5fed837950ac8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| u \\right\\|_X \\lesssim \\left\\|u\\right\\|_{Y_+} + \\left\\|u\\right\\|_{Y_-}", block: true)]]

#text("for all reasonable ")#mi("{u}")#text(" (e.g. test functions). The ")#emph[#text("double Duhamel trick")]#text(" accomplishes this by establishing the stronger estimate ")#metadata(none) <tao-664ebfd043b0ab5ff83e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\langle u, v \\rangle_X\\right| \\lesssim \\left\\|u\\right\\|_{Y_+} \\left\\|v\\right\\|_{Y_-}", block: true)]]

#text("for all reasonable ")#mi("{u, v}")#text("; note that setting ")#mi("{u=v}")#text(" and applying the arithmetic-geometric inequality then gives ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(". The point is that if ")#mi("{u}")#text(" has a forward representation ")#link(<tao-589e06e042ab7b04ede3>)[#text("(3)")]#text(" and ")#mi("{v}")#text(" has a backward representation ")#link(<tao-cdad01052b9e93b3c31f>)[#text("(4)")]#text(", then the inner product ")#mi("{\\langle u, v \\rangle_X}")#text(" can (formally, at least) be expanded as a double integral")

#align(center)[#tao-fit-display[#mitex("\\int_{t_0}^t \\int_{t}^{t_1} \\langle e^{i(t^{\\prime\\prime}-t^{\\prime})\\Delta} F_+(t^{\\prime}), e^{i(t^{\\prime\\prime}-t^{\\prime})\\Delta} F_-(t^{\\prime}) \\rangle_X\\ dt^{\\prime\\prime} dt^{\\prime}.")]]

#text("The dispersive nature of the linear Schrödinger equation often causes ")#mi("{\\langle e^{i(t^{\\prime\\prime}-t^{\\prime})\\Delta} F_+(t^{\\prime}), e^{i(t^{\\prime\\prime}-t^{\\prime})\\Delta} F_-(t^{\\prime}) \\rangle_X}")#text(" to decay, especially in high dimensions. In high enough dimension (typically one needs five or higher dimensions, unless one already has some spacetime control on the solution), the decay is stronger than ")#tao-math("{1/\\left|t^{\\prime}-t^{\\prime\\prime}\\right|^2}", block: false)#text(", so that the integrand becomes absolutely integrable and one recovers ")#link(<tao-664ebfd043b0ab5ff83e>)[#text("(6)")]#text(".")

#text("Unfortunately it appears that estimates of the form ")#link(<tao-664ebfd043b0ab5ff83e>)[#text("(6)")]#text(" fail in low dimensions (for the type of norms ")#mi("{N}")#text(" that actually show up in applications); there is just too much interaction between past and future to hope for any reasonable control of this inner product. But one can try to obtain ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(" by other means. By the Hahn-Banach theorem (and ignoring various issues related to reflexivity), ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(" is equivalent to the assertion that every ")#mi("{u \\in X}")#text(" can be decomposed as ")#mi("{u = u_+ + u_-}")#text(", where ")#tao-math("{\\left\\|u_+\\right\\|_{Y_+^*} \\lesssim \\left\\|u\\right\\|_X}", block: false)#text(" and ")#tao-math("{\\left\\|u_-\\right\\|_{Y_-^*} \\lesssim \\left\\|v\\right\\|_X}", block: false)#text(". Indeed once one has such a decomposition, one obtains ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(" by computing the inner product of ")#mi("{u}")#text(" with ")#mi("{u=u_++u_-}")#text(" in ")#mi("{X}")#text(" in two different ways. One can also (morally at least) write ")#tao-math("{\\left\\|u_+\\right\\|_{Y_+^*}}", block: false)#text(" as ")#tao-math("{\\left\\| e^{i(\\cdot-t)\\Delta} u_+\\right\\|_{N^*([t_0,t])}}", block: false)#text(" and similarly write ")#tao-math("{\\left\\|u_-\\right\\|_{Y_-^*}}", block: false)#text(" as ")#tao-math("{\\left\\| e^{i(\\cdot-t)\\Delta} u_-\\right\\|_{N^*([t,t_1])}}", block: false)

#text("So one can dualise the task of proving ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(" as that of obtaining a decomposition of an arbitrary initial state ")#mi("{u}")#text(" into two components ")#mi("{u_+}")#text(" and ")#mi("{u_-}")#text(", where the former disperses into the past and the latter disperses into the future under the linear evolution. We do not know how to achieve this type of task efficiently in general – and doing so would likely lead to a significant advance in the subject (perhaps one of the main areas in this topic where serious harmonic analysis is likely to play a major role). But in the model case of spherically symmetric data ")#mi("{u}")#text(", one can perform such a decomposition quite easily: one uses microlocal projections to set ")#mi("{u_+}")#text(" to be the “inward” pointing component of ")#mi("{u}")#text(", which propagates towards the origin in the future and away from the origin in the past, and ")#mi("{u_-}")#text(" to simimlarly be the “outward” component of ")#mi("{u}")#text(". As spherical symmetry significantly dilutes the amplitude of the solution (and hence the strength of the nonlinearity) away from the origin, this decomposition tends to work quite well for applications, and is one of the main reasons (though not the only one) why we have a global theory for low-dimensional nonlinear Schrödinger equations in the radial case, but not in general.")

#text("The in/out decomposition is a linear one, but the Hahn-Banach argument gives no reason why the decomposition needs to be linear. (Note that other well-known decompositions in analysis, such as the Fefferman-Stein decomposition of BMO, are necessarily nonlinear, a fact which is ultimately equivalent to the non-complemented nature of a certain subspace of a Banach space; see these ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("lecture notes of mine")]#text(" and ")#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")[#text("this old blog post")]#text(" for some discussion.) So one could imagine a sophisticated nonlinear decomposition as a general substitute for the in/out decomposition. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1949165")[#text("this paper of Bourgain and Brezis")]#text(" for some of the subtleties of decomposition even in very classical function spaces such as ")#mi("{H^{1/2}(R)}")#text(". Alternatively, there may well be a third way to obtain estimates of the form ")#link(<tao-0f76cdd5fed837950ac8>)[#text("(5)")]#text(" that do not require either decomposition or the double Duhamel trick; such a method may well clarify the relative relationship between past, present, and future for critical nonlinear dispersive equations, which seems to be a key aspect of the theory that is still only partially understood. (In particular, it seems that one needs a fairly strong decoupling of the present from both the past and the future to get the sort of elliptic-like regularity results that allow us to make further progress with such equations.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/#comment-42847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2009")])]

#text("t’ should be t”")

#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/#comment-42848")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2009")])]

#text("In my browser, I see a formula that does not parse in the sentence that starts “The task is then to use the control of both the …”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37dbcb28a2f03fcbbb69bd038769e6ad5e07bc1b65dd3a7f1adfbfda60c051be-e178ab608699f48f3face211a8c4bfbcb6ab8749f0e7dde5760d38f66c319beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/#comment-42852")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2009")])]

#text("On Google Chrome there exists the problem “Formula does not parse” at place down 3 line from formula(4), but on Safari and Firefox, IE it’s ok.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/#comment-42865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2009")])]

#text("typo: that the integrand becoems ")#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e85a3703b23e73c06ecdfb00f4212b2bb924da0c8d77288bd949c9fe02262546-862abf0fa730b3bf8faf06916df7035f01b33cefee489f6c2a129e721cc2abe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gtm73")]], [#link("https://terrytao.wordpress.com/2009/12/17/the-double-duhamel-trick-and-the-inout-decomposition/#comment-42868")[#strong[#text("gtm73")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("Mathematics is as beautiful as Plato’s dialogues.")
]
