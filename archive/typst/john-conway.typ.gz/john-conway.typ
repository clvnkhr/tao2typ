// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/04/12/john-conway/
// Converted to Typst by tao2typ: "2026-10-14T16:38:45.924505+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "John Conway", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("John Conway")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 April 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/")[#text("https://terrytao.wordpress.com/2020/04/12/john-conway/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I was greatly saddened to learn that ")#link("https://en.wikipedia.org/wiki/John_Horton_Conway")[#text("John Conway")]#text(" ")#link("https://dailyvoice.com/new-jersey/mercer/obituaries/covid-19-kills-renowned-princeton-mathematician-game-of-life-inventor-john-conway-in-3-days/786461/")[#text("died yesterday from COVID-19")]#text(", aged 82.")

#text("My own mathematical areas of expertise are somewhat far from Conway’s; I have played for instance with finite simple groups on occasion, but have not studied his work on ")#link("https://en.wikipedia.org/wiki/Monstrous_moonshine")[#text("moonshine")]#text(" and the monster group. But I have certainly encountered his results every so often in surprising contexts; most recently, when ")#link("https://terrytao.wordpress.com/tag/collatz-conjecture/")[#text("working on the Collatz conjecture")]#text(", I looked into Conway’s wonderfully preposterous ")#link("https://en.wikipedia.org/wiki/FRACTRAN")[#text("FRACTRAN language")]#text(", which can encode any Turing machine as an iteration of a Collatz-type map, showing in particular that there are generalisations of the Collatz conjecture that are undecidable in axiomatic frameworks such as ZFC. [EDIT: also, my belief that the Navier-Stokes equations admit solutions that blow up in finite time is also highly influenced by the ability of ")#link("https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life")[#text("Conway’s game of life")]#text(" ")#link("https://en.wikipedia.org/wiki/Von_Neumann_cellular_automaton")[#text("to generate")]#text(" self-replicating “")#link("https://en.wikipedia.org/wiki/Self-replicating_machine")[#text("von Neumann machines")]#text("“.]")

#text("I first met John as an incoming graduate student in Princeton in 1992; indeed, a talk he gave, on “Extreme proofs” (proofs that are in some sense “extreme points” in the “convex hull” of all proofs of a given result), may well have been the first research-level talk I ever attended, and one that set a high standard for all the subsequent talks I went to, with Conway’s ability to tease out deep and interesting mathematics from seemingly frivolous questions making a particular impact on me. (Some version of this talk eventually became ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3111964")[#text("this paper of Conway and Shipman")]#text(" many years later.)")

#text("Conway was fond of hanging out in the Princeton graduate lounge at the time of my studies there, often tinkering with some game or device, and often enlisting any nearby graduate students to assist him with some experiment or other. I have a vague memory of being drafted into holding various lengths of cloth with several other students in order to compute some element of a braid group; on another occasion he challenged me to a board game he recently invented (now known as “")#link("https://en.wikipedia.org/wiki/Phutball")[#text("Phutball")]#text("“) with Elwyn Berlekamp and Richard Guy (who, by sad coincidence, both also passed away in the last 12 months). I still remember being repeatedly obliterated in that game, which was a healthy and needed lesson in humility for me (and several of my fellow graduate students) at the time. I also recall Conway spending several weeks trying to construct a strange periscope-type device to try to help him visualize four-dimensional objects by giving his eyes vertical parallax in addition to the usual horizontal parallax, although he later told me that the only thing the device made him experience was a headache.")

#text("About ten years ago we ran into each other at some large mathematics conference, and lacking any other plans, we had a pleasant dinner together at the conference hotel. We talked a little bit of math, but mostly the conversation was philosophical. I regrettably do not remember precisely what we discussed, but it was very refreshing and stimulating to have an extremely frank and heartfelt interaction with someone with Conway’s level of insight and intellectual clarity.")

#text("Conway was arguably an extreme point in the convex hull of all mathematicians. He will very much be missed.")

#heading(level: 1)[#text("Comments (38)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552105")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Dear Terry, Sorry for your losses, but thank goodness for Easter, Right?")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Very sad to hear the news. His personality and enthusiasm will be remembered warmly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f86090bbdafb63e5413723967942d72d32936735e550513dad291b95f66c5f-496e402e3b1ba204923bce7da6313b07f7d06a479d6b9bdda79a4e537f99801e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bjonas")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552127")[#strong[#text("bjonas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#link("https://www.scottaaronson.com/blog/?p=4732#comment-1836693")[#text("https://www.scottaaronson.com/blog/?p=4732#comment-1836693")]#text(" Gil Kalai reports on Scott Aaronson’s blog that John H. Conway also obliterated him with the same board game.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-557633")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("Actually, it was a nice experience for me; I like to meet impressive mathematicians, and JHC was impressive in various new ways.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60ae5bd040b932d9b10f2f34c41e27276c9aa7400c9c6b4787c99c062d8b600f-24105b22984a8605ab37b5136e7841aa87ff7154c8597a80dcece7cd7ba357d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("“I have a vague memory of being drafted into holding various lengths of cloth with several other students in order to compute some element of a braid group.”")

#text("He enlisted members of the audience to do this in his “Tangles, Bangles and Knots” lecture, which he gave at several places:")

#link("https://www.uctv.tv/shows/Tangles-Bangles-and-Knots-with-John-Conway-23319")[#text("https://www.uctv.tv/shows/Tangles-Bangles-and-Knots-with-John-Conway-23319")]

#text("One of the most entertaining math lectures I’ve ever attended. May he rest in peace.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82ac299ead360a7a2ea2a3c0aa0561f1f7845932c1d61560cd1b76e6c7ff05e0-e6b5bc5a14ba513d3d81e8f222c42322d1d9ccf5086f196561422adfa4d80e44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Miller")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552512")[#strong[#text("Victor Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("I saw Conway give his Tangles and Braids talk at the Plainsboro (town next to Princeton) Public library to a bunch of young kids (ages 7 through 10) who got wonderfully involved. John was certainly one of a kind")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c7cdb2e9dddbbc3891f0f9fd758eba59c3471cd21900631f148b22baf072487-1e8898880fb5a737763d98677501b7adc451f3ba55ea4df2fd828ef74b287fcd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darsh Ranjan")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552187")[#strong[#text("Darsh Ranjan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("I’m very sad to hear this news. I had the pleasure of working on a project with Prof. Conway when I was an undergraduate at Princeton. He was really one of a kind.")

#text("I still remember the first talk of his that I ever attended. He wrote down a seemingly random (but actually carefully chosen) list of simple fractions, then explained that we should start with an integer and repeatedly multiply it by the first fraction in the list for which the product was an integer, and he demonstrated that for the rest of the talk. Occasionally we would reach a power of two, and amazingly, it was always a *prime* power of two! Of course, this was an example of FRACTRAN, just one of the many bizarre and brilliant things he came up with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552196")[#strong[#text("John Conway has died | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")]

#text("[…] Terry Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94a53001d6c71abb5a3f7b8eb27944ed663d05f00188afae176627992987cbaf-6d9072119880a45eb68e82a5fe3607c6d5688874a82b8333b19723f6a468b4d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Cosgrave")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552243")[#strong[#text("John Cosgrave")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Thank you for this lovely tribute to John Conway. He must have met hundreds – if not thousands – of mathematicians over the years, all of whom would have something of interest to relate. Here is my penny’s worth, quoting from an email I wrote to Colm Mulcahy (")#link("http://www.cardcolm.org/")[#text("http://www.cardcolm.org/")]#text(") four years ago:")

#text("” When JC gave a talk to the students [when I was an undergraduate there in the mid 60s] at Royal Holloway College (RHC) it was on his Game of Life.")

#text("Once [when I was a graduate student] he was at RHC for a week, for a graph theory conference I think. Norman Biggs, who was still at RHC then, would have organised it. It wasn’t of any interest to me, but I hoped I’d get an opportunity to chat with JC. Late one evening I heard he was over in the student union bar so I headed off there, and we passed just as he was leaving. I blurted out “oh, I was hoping to have a chat with you” – he wouldn’t have know who I was of course – and he said something like “well if you buy me a drink I’ll stay”, and he did, just the two of us [wasn’t that just great, that this famous guy would be prepared to sit and chat with some completely unknown person?]. I ought to be able to recall what we chatted about, but sadly I can’t. I can remember every detail of chats I had with Roth, or C.A.Rogers, or…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552249")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("I’m also very saddened to learn of John Conway’s passing. We first met at the social event kicking off the monthlong Regional Geometry Institute at Smith College in July, 1993 at which John explained sphere-packing in nine dimensions. A couple of weeks later he and I began talking about some math around 10 pm and by 5:30 am he was still going strong but I had to excuse myself to get to sleep (even though he was born 9 years before me). Over the next 10 years or so we interacted periodically, often on the telephone, and I learned a lot from him, especially algebra and geometry. I never got a chance to ask him for the solution to his notorious keyring problem from the 2015 Pizza Hut Pi Day math contest, where the goal was to solve one of three puzzles posed by John. Solutions eventually appeared to the other two problems, but not the keyring one:")

#text("“My key-rings are metal circles of diameter about two inches. They are all linked together in a strange jumble, so that try as I might, I can’t tell any pair from any other pair.")

#text("“However, I can tell some triple from other triples, even though I’ve never been able to distinguish left from right. What are the possible numbers of key-rings in this jumble?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552567")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("The first paragraph of Conway’s keyring puzzle seems to imply for starters that each pair of keyrings is linked, and that the keyrings are physically identical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552651")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Triples of identical pairwise-linked keyrings can I think be distinguished without left-right distinctions based on each keyring’s number of ‘over’ crossings in the central triangle of their trefoil: Balanced (1-1-1) vs. unbalanced (2-1-0). If this is the distinction relevant to Conway’s puzzle, then for the answer to be interesting, a mix of balanced and unbalanced 3-keyring subsets is presumably achievable only for certain total numbers of keyrings.")

#text("That is pretty surprising.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14a73d3d2108230caa6e2ff991849137899f8de8865aa93b0ba53ac75d838d1a-dfe1e1a935d9a5e45fe47f7b3c0ffc388349cb68970c9bd8d1575046cd934dff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of exfret")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-644301")[#strong[#text("exfret")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("I wonder if it’s still unsolved? I recently heard about this and am quite intrigued.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552258")[#strong[#text("John Conway « Statistical Modeling, Causal Inference, and Social Science")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")]

#text("[…] Terence Tao reports that “Conway was fond of hanging out in the Princeton graduate lounge at the time of my […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("It seems that John Conway was mainly interested in constructing highly symmetrical interesting mathematical structures whose constructions are based on few very simple principles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/362c99351e5f6d592ebfd10849aae94c806b98643891c7fd5ef0156157c427d5-7b8785b78391f858cff37288f7f9c5fb1acf1e3acde57f0cf9b2cab4393930c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Chillingworth")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552282")[#strong[#text("David Chillingworth")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("I was a graduate student in the mid 1960s at Cambridge when John Conway was there. My main memory is of him on all fours on the carpet in the DPMMS common room with a large set of Poppa beads (quite a fashion at the time). The beads are small plastic spheres that click together and apart quite easily: just perfect for experimenting with knots – which was exactly what JC was doing, to great effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/354954ec12796722c1a800a65c58a6c5c5e22d0ad38e761c9b7320003b7abc70-6cf0926165df5bda884ca3c4138fe8faf197178d64bf7d27859635934b6f2ad6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Larsen")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552363")[#strong[#text("Michael Larsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("I have very fond memories of talking to Conway in the common room in Princeton in the late 1980s. I was working on a problem that required more knowledge of group theory than I had at the time, and I tried to pump him for information. I learned that it was impossible (at least for me) to direct a conversation with him. He always talked about whatever he was thinking about at that moment, which was invariably more interesting than what I wanted to talk about. He had a fascinating vision of mathematics, in which the main players were complicated combinatorial objects with a wealth of interconnections, and when I was actually in his presence, I found myself half-believing in his version of mathematical reality.")

#text("At some point, a question I asked him became an entry point for a long explanation of how to use his Atlas to do group theory calculations. He was very patient, and when I got to the point that I could use the Atlas unassisted, he sold me a spare copy for a very modest sum. By a strange coincidence, I found myself using that copy the morning that he died. I wrote to a group theorist in New Zealand to report what I had found, and he told me the bad news.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc5ff249339fccfe6a90f64282930eaaca7b0eb8cbc82bfabf936691c9971742-2b8cbb7eee158dba51104b1ff1b1554848139c9441ee4917aca9c1099b31a961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Conway – Hacker News Robot")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552387")[#strong[#text("John Conway – Hacker News Robot")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2020/04/12/john-conway/")[#text("https://terrytao.wordpress.com/2020/04/12/john-conway/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552404")[#strong[#text("John Conway - anisanews.com")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")]

#text("[…] Read More : Source […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47565d499bd4bc965212d9333f13a9972928896e7cbce81f64a47c848fbab9db-d97f4da5e28f40a4e397ed7385b8057ac273b5f3e499b46c13904ed48cb351fc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John H. Conway {In memoriam} – Baking Science Traveller")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552481")[#strong[#text("John H. Conway {In memoriam} – Baking Science Traveller")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("[…] er leider zur Risikogruppe für einen schweren Verlauf von COVID-19. Ich habe davon zuerst auf dem Blog von Terence Tao gelesen, der auch ein paar Erinnerungen an Conway mit uns […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82ac299ead360a7a2ea2a3c0aa0561f1f7845932c1d61560cd1b76e6c7ff05e0-e6b5bc5a14ba513d3d81e8f222c42322d1d9ccf5086f196561422adfa4d80e44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Miller")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552516")[#strong[#text("Victor Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("A few years ago I took a class from Conway on Simple Groups. Interestingly enough, everybody else, except me, and one of my colleagues at work stopped attending, but we met, faithfully, anyway. I attended every class and took good notes. About halfway through the term I noted to him, that to my best recollection, he had never proved any of the groups to be simple. He said that that was correct, and that being simple was the least interesting property that they had! He also opined that he thought it possible that there was an additional sporadic group that had been missed! I don’t know if he did that for the effect of the statement, but it certainly got my attention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552582")[#strong[#text("John Horton Conway 1937–2020 | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")]

#text("[…] which both Dick and I attended. We wonder whether the kind of connection noted by Terry Tao in his tribute to Conway can also smooth the way to understanding […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552592")[#strong[#text("Michael Tsai - Blog - John Conway, RIP")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")]

#text("[…] Terence Tao (via Hacker News) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5dce9c4cbe94adc64baed0dd8f463a59be59076974c8a200b4918386beb35870-59702feca22c2875f8f11539e4aaa58074421918311326c7e6bb8f09af155c96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Petrie Moulton")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552602")[#strong[#text("David Petrie Moulton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Yes, I was the colleague Victor Miller mentions above. Never mind that there weren’t any more Princeton students attending; he still taught the class for us! We would audit pretty much any graduate class he was teaching, and the lectures, and random conversations we had with him, were always fascinating. My wife and I would also run into John and chat from time to time at the local cafe, Small World.")

#text("I remember the first time I met John, after a talk he gave at UC Berkeley, when I was a grad student. I don’t remember what he talked about, but I met up with him outside, and somehow he got to tell me about his new method for mental factorization. The starting point, or course, was to memorize everything up to 1000. But you don’t memorize the primes: there are 168 of them, and you have no check on them. Instead you memorize the composites not divisible by 2, 3, 5, since there are only 100 of them, and you learn their factorizations (which give you check). I had never met him, but he spent an hour or so explaining the details of that and how you use them to factorize numbers up to 5000 or 10,000 very quickly in your head.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552689")[#strong[#text("陶哲轩发文缅怀天才数学家约翰·康威：他将游戏变成了研究 | 63ke")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")]

#text("[…] 陶哲轩博客全文翻译如下（原文链接） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552694")[#strong[#text("陶哲轩发文想念数学家约翰·康威：他将游戏变成了研讨 | 28x29新闻网")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")]

#text("[…] 陶哲轩博客全文翻译以下（原文链接） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552773")[#strong[#text("陶哲轩发文缅怀因新冠去世的天才数学家约翰·康威-本站网 _盐城天气预报网")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")]

#text("[…] 陶哲轩博客全文翻译如下（原文链接） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-552948")[#strong[#text("John Conway – the latest news-world.org")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")]

#text("[…] ")#link("https://terrytao.wordpress.com/2020/04/12/john-conway/")[#text("https://terrytao.wordpress.com/2020/04/12/john-conway/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7db5a8427d22c8c56cd14d5e933d63220e2fa7884165c589680abf328fbe56e-9287b7141135b628fbde525f0a55e8b0ae492e053327c6774d9820a6943cb833.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-553035")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("John Conway had a brief but incredible impact on my life and personal research.")

#text("Thanks for sharing you personal story; we will – and certainly already do – miss him greatly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-553633")[#strong[#text("To cheer you up in difficult times II: Mysterious matching news by Gal Beniamini, Naom Nisan, Vijay Vazirani and Thorben Tröbst! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")]

#text("[…] posts on Conway’s work by Scott Aaronson (with many nice memories in the comment section), by Terry Tao, and by Dick Lipton and Ken Regan. And a moving obituary on xkcd with a touch of ingenuity of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96e2f5784bcdb6f498fc65b490e9de8b0bbd1494cba02368aa9dd7b8ca2a6296-c7042d3246b7e77e9319d3b3b2980eef3fa4398468da8107048244e07288b958.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Conway – obituary by Terence Tao – mathematics matters…")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-555483")[#strong[#text("John Conway – obituary by Terence Tao – mathematics matters…")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2020/04/12/john-conway/")[#text("https://terrytao.wordpress.com/2020/04/12/john-conway/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-555739")[#strong[#text("John H. Conway (1937-2020)​​​ un prolífico matemático británico conocido por el «juego de la vida» - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")]

#text("[…] Siobhan Roberts, «A Life in Games,» Quanta Magazine, 28 Aug 2015; Terence Tao, «John Conway,» What’s new, 12 Apr 2020; The Blog of Scott Aaronson, «John Horton Conway (1937-2020),» Shtetl-Optimized, 12 Apr […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-555740")[#strong[#text("John H. Conway (1937-2020), un prolífico matemático británico conocido por el «juego de la vida» - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")]

#text("[…] Siobhan Roberts, «A Life in Games,» Quanta Magazine, 28 Aug 2015; Terence Tao, «John Conway,» What’s new, 12 Apr 2020; The Blog of Scott Aaronson, «John Horton Conway (1937-2020),» Shtetl-Optimized, 12 Apr […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-557357")[#strong[#text("Le Monde puzzle [#1141] – JobsandVisa")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")]

#text("[…] weekly puzzle from Le Monde is in honour of John Conway, who simply handed away, ending up his personal sport of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a27aded23ed7733327e18ec5e7df663728afdaf36eaf470eac92f64896b15bd4-5c925d64362eb2a9b9f4a4032b2a85e8fd085ee564801ad0117851bb702e7afb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair201p")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-557400")[#strong[#text("jair201p")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("I am very sad to hear such sad news,great mathematican and awesome person")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0085c50c821413c085d8eaf29c9a22e41f52abd41480d57c4de26ba308bd62b8-288f8f55e8dc7c88a3b68bc66992caf0c41570a804403effd40a59db3e11b264.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario Sanhueza Villar")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-559804")[#strong[#text("Mario Sanhueza Villar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Hi Terence, Im sorry to hear John Conway passed away for that virus…life goes on.")

#text("I wanna ask you something, i just found out a new computer developed by IBM and I’m wondering if that is enough technology to come up with solution for the Navier Stokes equation. On internet there are so many comments that are not true, like the solution has been found by a Kazakh Mathematician i dont know what officially has been declared about that, hope you answer this.")

#text("Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f865710a0cd8c6185f823a901cdc6589f6cb9a7d66faa58fcf06f24a762b979-b43c560ba1dbf1e3bd2a0c01299785f1cc0ded295d52acc3dd9aad007b5dc6d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob Kusner")]], [#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-572724")[#strong[#text("Rob Kusner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2020")])]

#text("Thanks for sharing this, Terry.")

#text("One amusing comment on Conway’s experiments in 4D visualization via vertical parallax. He told me (circa 1990) that he’d first fabricated such devices when he was an undergraduate (decades earlier): these involved several prisms, effectively giving him an eye in the middle of his forehead, and another eye just below his nose, which he wore as he walked around Cambridge. When I asked if he got anything out of these experiments, he replied “Headaches — from banging into walls!”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/12/john-conway/#comment-640097")[#strong[#text("Terence Tao John Conway 06/02/2022")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2022")]

#text("[…] John Conway | What’s new – Terry Tao […]")
]
