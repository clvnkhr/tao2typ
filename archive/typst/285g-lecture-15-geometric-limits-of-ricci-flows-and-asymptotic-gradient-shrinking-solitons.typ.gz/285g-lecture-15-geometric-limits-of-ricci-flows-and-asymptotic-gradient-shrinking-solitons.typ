// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/
// Converted to Typst by tao2typ: "2026-10-14T16:35:20.523086+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now begin using the theory established in the last two lectures to rigorously extract an asymptotic gradient shrinking soliton from the scaling limit of any given ")#mi("\\kappa")#text("-solution. This will require a number of new tools, including the notion of a ")#emph[#text("geometric limit")]#text(" of pointed Ricci flows ")#mi("t \\mapsto (M, g(t), p)")#text(", which can be viewed as the analogue of the ")#link("http://en.wikipedia.org/wiki/Gromov-Hausdorff_convergence")[#text("Gromov-Hausdorff limit")]#text(" in the category of smooth Riemannian flows. A key result here is ")#link("http://www.ams.org/mathscinet-getitem?mr=1333936")[#emph[#text("Hamilton’s compactness theorem")]]#text(": a sequence of complete pointed non-collapsed Ricci flows with uniform bounds on curvature will have a subsequence which converges geometrically to another Ricci flow. This result, which one can view as an analogue of the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" for Ricci flows, relies on some parabolic regularity estimates for Ricci flow due ")#link("http://www.ams.org/mathscinet-getitem?mr=1010165")[#text("to Shi")]#text(".")

#text("Next, we use the estimates on reduced length from the Harnack inequality analysis in ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(" to locate some good regions of spacetime of a ")#mi("\\kappa")#text("-solution in which to do the asymptotic analysis. Rescaling these regions and applying Hamilton’s compactness theorem (relying heavily here on the ")#mi("\\kappa")#text("-noncollapsed nature of such solutions) we extract a limit. Formally, the reduced volume is now constant and so ")#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")[#text("Lecture 14")]#text(" suggests that this limit is a gradient soliton; however, some care is required to make this argument rigorous. In the next section we shall study such solitons, which will then reveal important information about the original ")#mi("\\kappa")#text("-solution.")

#text("Our treatment here is primarily based on ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" and the ")#link("http://www.math.ucsb.edu/%7Eyer/ricciflow.html")[#text("notes of Ye")]#text(". Other treatments can be found in ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s original paper")]#text(", the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", and the ")#link("http://arxiv.org/abs/math/0612069")[#text("paper of Cao-Zhu")]#text(". See also the foundational papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=1010165")[#text("Shi")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1333936")[#text("Hamilton")]#text(", as well as the ")#link("http://www.ams.org/mathscinet-getitem?mr=2274812")[#text("book of Chow, Lu, and Ni.")]

#metadata(none) <tao-92d239ac339e4c8b5652>

#heading(level: 1)[#text("— Geometric limits —")]

#text("To develop the theory of geometric limits for pointed Ricci flows ")#mi("t \\mapsto (M,g(t),p)")#text(", we begin by studying such limits in the simpler context of pointed Riemannian manifolds ")#mi("(M,g,p)")#text(", i.e. a Riemannian manifold ")#mi("(M,g)")#text(" together with a point ")#mi("p \\in M")#text(", which we shall call the ")#emph[#text("origin")]#text(" or distinguished point of the manifold. To simplify the discussion, let us restrict attention to complete Riemannian manifolds (though for later analysis we will eventually have to deal with incomplete manifolds).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Geometric limits) A sequence ")#mi("(M_n,g_n,p_n)")#text(" of pointed d-dimensional connected complete Riemannian manifolds is said to converge geometrically to another pointed d-dimensional connected complete Riemannian manifold ")#mi("(M_\\infty,g_\\infty,p_\\infty)")#text(" if there exists a sequence ")#mi("V_1 \\subset V_2 \\subset \\ldots")#text(" of connected neighbourhoods of ")#mi("p_\\infty")#text(" increasing to ")#mi("M_\\infty")#text(" (i.e. ")#mi("\\bigcup_n V_n = M_\\infty")#text(") and a sequence of smooth embeddings ")#mi("\\phi_n: V_n \\to M_n")#text(" mapping ")#mi("p_\\infty")#text(" to ")#mi("p_n")#text(" such that")

#enum(start: 1, 
[#text("The closure of each ")#mi("V_n")#text(" is compact and contained in ")#mi("V_{n+1}")#text(" (note that this implies that every compact subset of ")#mi("M_\\infty")#text(" will be contained in ")#mi("V_n")#text(" for sufficiently large n);")],
[#text("The pullback metric ")#mi("\\phi_n^* g_n")#text(" converges in the ")#mi("C^\\infty_{loc}(M_\\infty)")#text(" topology to ")#mi("g_\\infty")#text(" (i.e. all derivatives of the metric converge uniformly on compact sets).")]
)
]

#strong[#text("Example 1.")]#text(" The pointed round d-sphere of radius R converges geometrically to the pointed Euclidean space ")#mi("{\\Bbb R}^d")#text(" as ")#mi("R \\to \\infty")#text(". Note how this example shows that the geometric limit of compact manifolds can be non-compact. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" If (M,g) is Hamilton’s cigar (Example 3 from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text("), and ")#mi("p_n")#text(" is a sequence on M tending to infinity, then ")#mi("(M,g,p_n)")#text(" converges geometrically to the pointed round 2-cylinder. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" The d-torus of length 1/n does not converge to a geometric limit as ")#mi("n \\to \\infty")#text(", despite being flat. More generally, the sequence needs to be locally uniformly non-collapsed in order to have a geometric limit. ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" Show that the geometric limit ")#mi("(M_\\infty,g_\\infty,p_\\infty)")#text(" of a sequence ")#mi("(M_n,g_n,p_n)")#text(", if it exists, is unique up to (pointed) isometry. ")#mi("\\diamond")

#text("Geometric limits, as their name suggests, tend to preserve all (local) “geometric” or “intrinsic” information about the manifold, although ")#emph[#text("global")]#text(" information of this type can be lost. Here is a typical example:")

#strong[#text("Exercise 2.")]#text(" Suppose that ")#mi("(M_n,g_n,p_n)")#text(" converges geometrically to ")#mi("(M_\\infty,g_\\infty,p_\\infty)")#text(". Show that ")#mi("\\text{Vol}_{g_\\infty}(B_{g_\\infty}(p_\\infty,r)) = \\lim_{n \\to \\infty} \\text{Vol}_{g_n}(B_{g_n}(p_n,r))")#text(" for every ")#mi("0 < r < \\infty")#text(", and that we have the ")#link("http://en.wikipedia.org/wiki/Fatou's_lemma")[#text("Fatou")]#text("-type inequality ")#mi("\\text{Vol}_{g_\\infty}(M_\\infty) \\leq \\lim\\inf_{n \\to \\infty} \\text{Vol}_{g_n}(M_n)")#text(". Give an example to show that the latter inequality can be strict. ")#mi("\\diamond")

#text("Here is the basic compactness theorem for such limits.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text(" (Compactness theorem) Let ")#mi("(M_n,g_n,p_n)")#text(" be a sequence of connected complete Riemannian d-dimensional manifolds. Assume that")

#enum(start: 1, 
[#text("(Uniform bounds on curvature and derivatives) For all ")#mi("k, r_0 \\geq 0")#text(", one has the pointwise bound ")#tao-math("\\left|\\nabla^k \\text{Riem}_n\\right|_{g_n} \\leq C_{k,r_0}", block: false)#text(" on the ball ")#mi("B_n(p_n,r_0)")#text(" for all sufficiently large n and some constant ")#mi("C_{k,r_0}")#text(".")],
[#text("(Uniform non-collapsing) For every ")#mi("r_0 > 0")#text(" there exists ")#mi("\\delta, \\kappa > 0")#text(" such that ")#mi("\\text{Vol}_n(x,r) \\geq \\kappa r^d")#text(" for all ")#mi("x \\in B_n(p_n,r_0)")#text(" and ")#mi("0 < r \\leq \\delta")#text(", and all sufficiently large n.")]
)

#text("Then, after passing to a subsequence if necessary, the sequence ")#mi("(M_n,g_n,p_n)")#text(" has a geometric limit.")
]

#strong[#text("Proof.")]#text(" (Sketch) Let ")#mi("r_0 > 0")#text(" be an arbitrary radius. From Cheeger’s lemma (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 7")]#text(") and hypothesis 2, we know that the injectivity radius on ")#mi("B_n(p_n,2r_0)")#text(" is bounded from below by some small ")#mi("\\delta > 0")#text(" for sufficiently large n. Also, from the curvature bounds and Bishop-Gromov comparison geometry (Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text(") we know that the volume of ")#mi("B_n(p_n,2r_0)")#text(" is uniformly bounded from above for sufficiently large n.")

#text("Now find a maximal ")#mi("\\delta/4")#text("-net ")#mi("x_{n,1},\\ldots,x_{n,k}")#text(" of ")#mi("B_n(p_n,r_0)")#text(", thus the balls ")#mi("B_n(x_{n,1},\\delta/8), \\ldots, B_n(x_{n,k},\\delta/8)")#text(" are disjoint and the balls ")#mi("B_n(x_{n,1},\\delta/4), \\ldots, B_n(x_{n,k},\\delta/4)")#text(" cover ")#mi("B_n(p_n,r_0)")#text(". Volume counting shows that k is bounded for all sufficiently large n; by passing to a subsequence we may assume that it is constant. Similarly we may assume that all the distances ")#mi("d_n(x_{n,i},x_{n,j})")#text(" converge to a limit. Using the exponential map and some arbitrary identification of tangent spaces with ")#mi("{\\Bbb R}^d")#text(", we can identify each ball ")#mi("B_n(x_{n,i},\\delta/2)")#text(" with the standard Euclidean ball of radius ")#mi("\\delta/2")#text(". Any pair ")#mi("x_{n,i}, x_{n,j}")#text(" of separation less than ")#mi("\\delta/2")#text(" induces a smooth transition map from the Euclidean ball of radius ")#mi("\\delta/2")#text(" into some subset of ")#mi("{\\Bbb R}^d")#text(", which can be shown by comparison geometry to be uniformly bounded in ")#mi("C^\\infty")#text(" norms; applying the (")#mi("C^\\infty")#text(" version of the) ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" we may thus pass to a subsequence and assume that all these transition maps converge in ")#mi("C^\\infty")#text(" to a limit. It is then a routine matter to glue together all the limit transition maps to fashion an incomplete manifold to which the balls ")#mi("B_n(p_0,r_0)")#text(" converge geometrically (up to errors of ")#mi("O(\\delta)")#text(" at the boundary). Furthermore, as one increases ")#mi("r_0")#text(", one can show (by a modification of Exercise 1) that these limits are compatible. Now letting ")#mi("r_0")#text(" go to infinity (and using the usual diagonalisation trick on all the subsequences obtained), and then gluing together all the incomplete limits obtained, one can create the full geometric limit. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" One could use ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("ultrafilters")]#text(" here in place of subsequences, but this does not significantly affect any of the arguments. ")#mi("\\diamond")

#text("Now we turn to geometric limits of pointed Ricci flows (Ricci flows ")#mi("t \\mapsto (M,g(t))")#text(" with a specified origin ")#mi("p \\in M")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" Let ")#mi("t \\mapsto (M_n,g_n(t),p_n)")#text(" be a sequence of pointed d-dimensional complete connected Ricci flows, each on its own time interval ")#mi("I_n")#text(". We say that a pointed d-dimensional complete connected Ricci flow ")#mi("t \\mapsto (M_\\infty,g_\\infty(t),p_\\infty)")#text(" on a time interval I is a geometric limit of this sequence if")

#enum(start: 1, 
[#text("Every compact subinterval of I is contained in ")#mi("I_n")#text(" for all sufficiently large n.")],
[#text("There exists neighbourhoods ")#mi("V_n")#text(" of ")#mi("p_\\infty")#text(" as in Definition 1, compact time intervals ")#mi("J_n \\subset I")#text(" increasing to I, and smooth embeddings ")#mi("\\phi_n: V_n \\to M_n")#text(" preserving the origin such that the pullback of the flow ")#mi("g_n")#text(" to ")#mi("J_n \\times V_n")#text(" converges in spacetime ")#mi("C^\\infty_{loc}")#text(" to ")#mi("g_\\infty")#text(".")]
)
]

#strong[#text("Exercise 3.")]#text(" Show that if a sequence of ")#mi("\\kappa")#text("-noncollapsed Ricci flows (with a uniform value of ")#mi("\\kappa")#text(") converges geometrically to another Ricci flow, then the limit flow is also ")#mi("\\kappa")#text("-noncollapsed. ")#mi("\\diamond")

#text("Now we present ")#link("http://www.ams.org/mathscinet-getitem?mr=1333936")[#text("Hamilton’s compactness theorem")]#text(" for Ricci flows, which requires less regularity hypotheses than Theorem 1 due to the parabolic smoothing effects of Ricci flow (as captured by Shi’s estimates, see Theorem 3).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Hamilton compactness theorem) Let ")#mi("t \\mapsto (M_n,g_n(t),p_n)")#text(" and ")#mi("I_n")#text(" be as in Definition 2, and let I be an open interval obeying hypothesis 1 of that definition. Let ")#mi("t_0 \\in I")#text(" be a time. Suppose that")

#enum(start: 1, 
[#text("For every compact subinterval J of I containing ")#mi("t_0")#text(" and every ")#mi("r > 0")#text(", one has the curvature bound ")#tao-math("\\left|\\text{Riem}_n\\right|_{g_n} \\leq K", block: false)#text(" on the cylinder ")#mi("J \\times B_{g_n(t_0)}(p_n,r)")#text(" for some ")#mi("K = K(J,r)")#text(" and all sufficiently large n; and")],
[#text("One has the non-collapsing bound ")#mi("\\text{Vol}_{g_n(t_0)}(B_{g_n(t_0)}(p_n,r)) \\geq \\kappa r^d")#text(" for some ")#mi("r > 0")#text(" and ")#mi("\\kappa > 0")#text(", and all sufficiently large n.")],
[#text("(Uniform lower bound on curvature) For any compact J, there is a K such that for any ")#mi("r>0")#text(", one has the curvature lower bound ")#mi("\\text{Ric}_n(g_n) \\geq -K")#text(" on ")#mi("J \\times B_{g_n(t_0)}(p_n,r)")#text(" for all sufficiently large n. (This is not quite implied by 1. because the curvature bound K there is allowed to depend on r, whereas here we require that K is independent of r.)")]
)

#text("Then some subsequence of ")#mi("t \\mapsto (M_n,g_n(t),p_n)")#text(" converges geometrically to a limit ")#mi("t \\mapsto (M_\\infty,g_\\infty(t),p_\\infty)")#text(" on I.")
]

#text("Condition 3 is technical (and was erroneously omitted in some of the literature), but it was recently observed ")#link("http://arxiv.org/abs/1110.3714")[#text("by Topping")]#text(" that the claim fails without some hypothesis of this form. Fortunately, in the applications to the Poincare conjecture one always has a uniform lower bound on Ricci curvature, and so Condition 3 is not difficult to verify in practice.")

#strong[#text("Proof. ")]#text(" By Shi’s estimates (Theorem 3) we can upgrade the bound on curvature in hypothesis 1 to bounds on derivatives of curvature. Indeed, these estimates imply that for any J, r as in that hypothesis, and any ")#mi("k \\geq 0")#text(", we have ")#tao-math("\\left|\\nabla^k \\text{Riem}_n\\right|_{g_n} \\leq K", block: false)#text(" for some ")#mi("K = K(J,r,k)")#text(" and sufficiently large n.")

#text("Now we restrict to the time slice ")#mi("t=t_0")#text(" and apply Theorem 1. Passing to a subsequence, we can assume that ")#mi("(M_n,g_n(t_0),p_n)")#text(" converges geometrically to a limit ")#mi("(M_\\infty,g_\\infty(t_0),p_\\infty)")#text(".")

#text("For any radius r and any compact J in I containing ")#mi("t_0")#text(", we can pull back the flow ")#mi("t \\mapsto (M_n,g_n(t),p_n)")#text(" to a (spatially incomplete) flow ")#mi("t \\mapsto (B_{g_\\infty(t_0)}(p_\\infty,r), \\tilde g_n(t), p_\\infty)")#text(" on the cylinder ")#mi("J \\times B_{g_\\infty(t_0)}(p_\\infty,r)")#text(" for sufficiently large n. By construction, ")#mi("\\tilde g_n(t_0)")#text(" converges in ")#mi("C^\\infty_{loc}(B_{g_\\infty(t_0)}(p_\\infty,r))")#text(" norm to ")#mi("g_\\infty(t_0)")#text("; in particular, it is uniformly bounded in each of the seminorms of this space. Also, each ")#mi("t \\mapsto \\tilde g_n(t)")#text(" is a Ricci flow with uniform bounds on any derivative of curvature for sufficiently large n.")

#strong[#text("Exercise 4.")]#text(" Using these facts, show that the sequence of flows ")#mi("t \\mapsto \\tilde g_n")#text(" is uniformly bounded in each of the seminorms of ")#mi("C^\\infty_{loc}(J \\times B_{g_\\infty(t_0)}(p_\\infty,r))")#text(" for each fixed J, r, and for n sufficiently large. ")#mi("\\diamond")

#text("By using the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" as before, we may thus pass to a further subsequence and assume that ")#mi("t \\mapsto \\tilde g_n(t)")#text(" converges in ")#mi("C^\\infty_{loc}(J \\times B_{g_\\infty(t_0)}(p_\\infty,r))")#text(" to a limiting flow ")#mi("t \\mapsto g_\\infty(t)")#text(". Clearly this limit is a Ricci flow. Letting ")#mi("r \\to \\infty")#text(" and pasting together the resulting limits one obtains the desired geometric limit. (One has to verify that every geodesic in ")#mi("(M_\\infty,g_\\infty(t),p_\\infty)")#text(" starting from ")#mi("p_\\infty")#text(" can be extended to any desired length, thus establishing completeness by the ")#link("http://en.wikipedia.org/wiki/Hopf-Rinow_theorem")[#text("Hopf-Rinow theorem")]#text(", but this is easy to establish given all the uniform bounds on the metric and curvature, and their derivatives. It is here that hypothesis 3 is used to prevent the metric from shrinking too rapidly as one goes backwards in time. ) ")#mi("\\Box")

#heading(level: 1)[#text("— Locating an asymptotic gradient shrinking soliton —")]

#text("We now return to the study of ")#mi("\\kappa")#text("-solutions ")#mi("t \\mapsto (M,g(t))")#text(". We pick an arbitrary point ")#mi("x_0 \\in M")#text(" and consider the reduced length function ")#mi("l = l_{(0,x_0)}")#text(". Recall (see equation (18) from ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text(") that we had")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\inf_{x \\in M} l(t,x) < d/2")]]

#text("for every ")#mi("t < 0")#text(". (This bound was obtained from the parabolic inequality ")#mi("\\partial_\\tau l \\geq \\Delta l + \\frac{l-(d/2)}{\\tau}")#text(" and the maximum principle.) Thus we can find a sequence ")#mi("(-\\tau_n, x_n) \\in (-\\infty,0] \\times M")#text(" with ")#mi("\\tau_n \\to \\infty")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("l(-\\tau_n,x_n) = O(1).")]]

#text("Now recall that as a consequence of Hamilton’s Harnack inequality, we have the pointwise estimates")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("0 \\leq \\left|\\nabla l\\right|^2 + R \\leq \\frac{3l}{\\tau}", block: true)]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("-\\frac{2l}{\\tau} \\leq \\partial_t l \\leq \\frac{l}{\\tau}")]]

#text("(see equations (37), (38) from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text("). From these bounds and Gronwall’s inequality, one easily sees that we can extend (2) to say that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("l(-\\tau,x) = O_r(1)")]]

#text("for any ")#mi("(-\\tau,x)")#text(" in the cylinder ")#mi("{}[-\\tau_n/r, -r\\tau_n] \\times B_{g(-\\tau^{\\prime})}(x_n,r\\sqrt{\\tau_n})")#text(" and any ")#mi("r \\geq 1")#text(" and ")#mi("\\tau_n/r \\leq \\tau^{\\prime} \\leq r\\tau_n")#text(". Applying (3) once more, together with the hypothesis of non-negative curvature more, we also obtain bounded normalised curvature on this cylinder:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6).")])
#tao-math("\\left|\\text{Riem}(-\\tau,x)\\right|_g = O_r( \\tau^{-1} )", block: true)]]

#text("If we thus introduce the rescaled flow ")#mi("t \\mapsto (M_n, g_n(t), p_n)")#text(" by setting ")#mi("M_n := M")#text(", ")#mi("p_n := x_n")#text(", and ")#mi("g_n(t) := t_n g(t t_n)")#text(", we see that these flows obey hypothesis 1 of Theorem 2. Also, since the original ")#mi("\\kappa")#text("-solutions are ")#mi("\\kappa")#text("-noncollapsed, so are their rescalings, which (in conjunction with hypothesis 1) gives us hypothesis 2. We can thus invoke Theorem 2 and assume (after passing to a subsequence) that the rescaled flows converge geometrically to an ancient Ricci flow ")#mi("t \\mapsto (M_\\infty, g_\\infty(t), p_\\infty)")#text(" on the time interval ")#mi("t \\in (-\\infty,0)")#text(". From Exercise 3 we see that this limit is also ")#mi("\\kappa")#text("-noncollapsed. Since the rescaled flows have non-negative curvature, the limit flow has non-negative curvature also. (Note however that we do not expect in general that ")#mi("(M_\\infty,g_\\infty(t))")#text(" has bounded curvature (for instance, if the original ")#mi("\\kappa")#text("-solution was a round shrinking sphere terminating at the unit radius sphere, the limit object would be a round shrinking sphere terminating at a point). In particular we do not expect ")#mi("(M_\\infty,g_\\infty)")#text(" to be a ")#mi("\\kappa")#text("-solution.)")

#text("Let ")#mi("l_n: (-\\infty,0) \\times M_n \\to {\\Bbb R}")#text(" be the rescaled length function, thus ")#mi("l_n(t,x) := l(t t_n, x)")#text(". From (5) we see that ")#mi("l_n")#text(" is uniformly bounded on compact subsets of ")#mi("(-\\infty,0) \\times M_\\infty")#text(" for n sufficiently large (where we identify compact subsets of ")#mi("M_\\infty")#text(" with subsets of ")#mi("M_n")#text(" for n large enough). By the rescaled versions of (4) and (5) we also see that ")#tao-math("\\left|\\nabla l_n\\right|_{g_\\infty}, \\left|\\partial_t l_n\\right|", block: false)#text(" is also uniformly bounded on such compact sets for sufficiently large n; thus the ")#mi("l_n")#text(" are uniformly Lipschitz on each compact set. Applying the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" and passing to a subsequence, we may thus assume that the ")#mi("l_n")#text(" converge uniformly on compact sets to some limit ")#mi("l_\\infty")#text(", which is then locally Lipschitz.")

#strong[#text("Remark 2.")]#text(" We do not attempt to interpret ")#mi("l_\\infty")#text(" as a reduced length function arising from some point at time t=0; indeed we expect the limiting flow to develop a singularity at this time. ")#mi("\\diamond")

#text("We know that the reduced volume ")#mi("\\int_M \\tau^{-d/2} e^{-l}\\ d\\mu")#text(" is non-increasing in ")#mi("\\tau")#text(" and ranges between 0 and ")#mi("(4\\pi)^{d/2}")#text(", and so converges to a limit ")#mi("\\tilde V(-\\infty)")#text(" between 0 and ")#mi("(4\\pi)^{d/2}")#text(". This limit cannot equal ")#mi("(4\\pi)^{d/2}")#text(" since this would mean that the ")#mi("\\kappa")#text("-solution is flat (by Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")[#text("Lecture 14")]#text("), which is absurd. The limit cannot be zero either, since the bounds (5) and the non-collapsing ensure a uniform lower bound on the reduced volume. By rescaling, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_{M_n} \\tau^{-d/2} e^{-l_n}\\ d\\mu_n \\to \\tilde V(-\\infty)")]]

#text("for each fixed ")#mi("\\tau > 0")#text(".")

#text("Let us now argue informally, and then return to make the argument rigorous later. Formally taking limits in (7), we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\int_{M_\\infty} \\tau^{-d/2} e^{-l_\\infty}\\ d\\mu_\\infty = \\tilde V(-\\infty).")]]

#text("On the other hand, from the proof of the monotonicity of reduced volume from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" we have (formally, at least)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\partial_{\\tau} l - \\Delta l + \\left|\\nabla l\\right|_g^2 - R + \\frac{d}{2\\tau} \\geq 0", block: true)]]

#text("and hence by rescaling")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\partial_{\\tau} l_n - \\Delta l_n + \\left|\\nabla l_n\\right|_{g_n}^2 - R + \\frac{d}{2\\tau} \\geq 0.", block: true)]]

#text("Formally taking limits, we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\partial_{\\tau} l_\\infty - \\Delta l_\\infty + \\left|\\nabla l_\\infty\\right|_{g_\\infty}^2 - R_\\infty + \\frac{d}{2\\tau} \\geq 0.", block: true)]]

#text("We can rewrite this as the assertion that ")#mi("\\tau^{-d/2} e^{-l_\\infty}")#text(" is a subsolution of the backwards heat equation:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("(\\partial_\\tau - \\Delta_{g_\\infty} - R_\\infty) ( \\tau^{-d/2} e^{-l_\\infty} ) \\leq 0.")]]

#text("This (formally) implies that the left-hand side of (8) is non-increasing in ")#mi("\\tau")#text(". On the other hand, this quantity is constant in ")#mi("\\tau")#text("; and so (12) must be obeyed with equality, and thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\partial_{\\tau} l_\\infty - \\Delta l_\\infty + \\left|\\nabla l_\\infty\\right|^2 - R_\\infty + \\frac{d}{2\\tau} = 0.", block: true)]]

#text("Also, recall from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\partial_\\tau l = \\frac{1}{2} R - \\frac{1}{2} \\left|\\nabla l\\right|_g^2 - \\frac{1}{2\\tau} l.", block: true)]]

#text("Rescaling and taking limits, we formally conclude that the same is true for ")#mi("l_\\infty")#text(";")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\partial_\\tau l_\\infty = \\frac{1}{2} R_\\infty - \\frac{1}{2} \\left|\\nabla l_\\infty\\right|_{g_\\infty}^2 - \\frac{1}{2\\tau} l_\\infty.", block: true)]]

#text("From (14) and (15) we obtain that the Perelman ")#mi("{\\mathcal W}")#text("-functional")

#align(center)[#tao-fit-display[#mitex("{\\mathcal W}(M_\\infty,g_\\infty(t),l_\\infty,\\tau) =")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\int_{M _\\infty}(\\tau(\\left|\\nabla l_\\infty\\right|^2 + R_\\infty) + l_\\infty - d) (4\\pi\\tau)^{-d/2} e^{-l_\\infty}\\ d\\mu_\\infty", block: true)]]

#text("vanishes (cf. the last section of ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text("). In particular, it is constant. On the other hand, by (13) and the monotonicity formula for this functional (see Exercise 9 of ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(") we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\partial}{\\partial \\tau} {\\mathcal W}(M_\\infty,g_\\infty(t),l_\\infty,\\tau)  & =", block: true)



#tao-math(" & - \\int_M 2\\tau \\left|\\text{Ric}_\\infty + \\text{Hess}(l_\\infty)- \\frac{1}{2\\tau} g_\\infty\\right|_{g_\\infty}^2 (4\\pi \\tau)^{-d/2} e^{-l_\\infty}\\ d\\mu_\\infty.", block: true, numbering: n => [#text("(17)")])
]

#text("Combining this with the vanishing of (16) we thus conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\text{Ric}_\\infty + \\text{Hess}(l_\\infty)- \\frac{1}{2\\tau} g_\\infty = 0")]]

#text("and thus ")#mi("t \\mapsto (M_\\infty,g_\\infty(t))")#text(" is a gradient shrinking soliton as desired.")

#heading(level: 1)[#text("— Making the argument rigorous I. Spatial localisation —")]

#text("Now we turn to the (surprisingly delicate) task of justifying the steps from (7) to (18).")

#text("The first task is to deduce (8) from (7). From the dominated convergence theorem it is not difficult to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\int_{B_n(p_n,r)} \\tau^{-d/2} e^{-l_n}\\ d\\mu_n \\to \\int_{B_\\infty(p_\\infty,r)} \\tau^{-d/2} e^{-l_\\infty}\\ d\\mu_\\infty")]]

#text("for any fixed ")#mi("\\tau")#text(" and r; the difficulty is to prevent the escape of mass of ")#mi("e^{-l_n}")#text(" to spatial infinity. (")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(" will tell us that the left-hand side of (8) is less than or equal to the right, but this is not enough for our application.)")

#text("In order to prevent such an escape, one needs a lower bound on ")#mi("l_n(-\\tau,x)")#text(" when ")#mi("d_{g_n(-\\tau)}(x_n,x)")#text(" is large. (Note that estimates such as (3), (4) only provide upper bounds on ")#mi("l_n(-\\tau,x)")#text(".) The problem is equivalent to that of upper bounding ")#mi("d_{g_n(-\\tau)}(x_n,x)")#text(" in terms of ")#mi("l_n(-\\tau,x)")#text(". To do this we need some control on quantities related to the distance function at extremely large distances. Remarkably, such bounds are possible. We begin with a lemma ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("of Perelman")]#text(" (related to an earlier argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1375255")[#text("of Hamilton")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("(M,g)")#text(" be a d-dimensional Riemannian manifold, let ")#mi("x, y \\in M")#text(", and let ")#mi("r > 0")#text(". Suppose that ")#mi("\\text{Ric} \\leq K")#text(" on the balls ")#mi("B(x,r)")#text(" and ")#mi("B(y,r)")#text(". Then for any minimising geodesic ")#mi("\\gamma")#text(" connecting x and y, we have ")#mi("\\int_\\gamma \\text{Ric}(X,X) \\leq O_d( K r + r^{-1} )")#text(", where ")#mi("X := \\gamma^{\\prime}")#text(" is the velocity field.")
]

#strong[#text("Proof. ")]#text("We may assume that ")#mi("d(x,y) \\geq 2r")#text(", since the claim is trivial otherwise. We recall the second variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\frac{d^2}{ds^2} E(\\gamma) = \\int_\\gamma \\left|\\nabla_X Y\\right|^2 - g(\\text{Riem}(X,Y) X, Y)", block: true)]]

#text("whenever one deforms a geodesic ")#mi("\\gamma")#text(" along a vector field Y (see equation (17) of ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text("). Since ")#mi("\\gamma")#text(" is minimising, the left-hand side of (20) is non-negative when Y vanishes at the endpoints of ")#mi("\\gamma")#text(". Now let v be any unit vector at x, transported by parallel transport along ")#mi("\\gamma")#text(". Setting Y(t) to equal tv/r when ")#mi("0 \\leq t \\leq r")#text(", equal to v when ")#mi("r \\leq t \\leq d(x,y)-r")#text(", and equal to (d(x,y)-t)v/r when ")#mi("d(x,y)-r \\leq t \\leq d(x,y)")#text(", we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\int_\\gamma g(\\text{Riem}(X,Y) X, Y) \\leq O( r^{-1} ).")]]

#text("Letting v vary over an orthonormal frame and summing, we soon obtain the claim. ")#mi("\\Box")

#text("The above lemma, combined with the Ricci flow equation, gives an upper bound as to how rapidly the distance function can grow as one goes backwards in time.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional Ricci flow, let ")#mi("x,y \\in M")#text(", let t be a time, and let ")#mi("r > 0")#text(". Suppose that ")#mi("\\text{Ric} \\leq K")#text(" on ")#mi("B_{g(t)}(x,r)")#text(" and on ")#mi("B_{g(t)}(y,r)")#text(". Then ")#mi("\\frac{d}{d\\tau} d_{g(t)}(x,y) \\leq O_d( K r + r^{-1} )")#text(" (in the sense of forward difference quotients).")
]

#text("Using this estimate, we can now obtain a bound on distance in terms of reduced length.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional ")#mi("\\kappa")#text("-solution, let ")#mi("x_0, p, p^{\\prime} \\in M")#text(", and ")#mi("\\tau_1 > 0")#text(". Then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\frac{d_{g(-\\tau_1)}(p,p^{\\prime})^2}{\\tau_1} \\leq O_d( 1 + l_{(0,x_0)}(-\\tau_1,p) +l_{(0,x_0)}(-\\tau_1,p^{\\prime}) ).")]]
]

#strong[#text("Proof.")]#text(" We use an argument of Ye. Write A for the expression inside the ")#mi("O_d()")#text(" on the right-hand side, and let ")#mi("\\gamma, \\gamma^{\\prime}: [0,\\tau_1] \\to M")#text(" be minimising ")#mi("{\\mathcal L}")#text("-geodesics from ")#mi("x_0")#text(" to p, p’ respectively. By the fundamental theorem of calculus, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("d_{g(-\\tau_1)}(p,p^{\\prime}) = \\int_0^{\\tau_1} \\frac{d}{d\\tau} d_{g(-\\tau)}( \\gamma(-\\tau), \\gamma^{\\prime}(-\\tau) )\\ d\\tau.")]]

#text("Using (3) and the ")#mi("{\\mathcal L}")#text("-Gauss lemma ")#mi("\\nabla l = X")#text(" we see that ")#mi("\\gamma, \\gamma^{\\prime}")#text(" move at speed ")#mi("O(A^{1/2}/\\tau^{1/2})")#text(", and that all curvature tensors are ")#mi("O( A / \\tau )")#text(" in a ")#mi("O( \\tau^{1/2}/A^{1/2} )")#text("-neighbourhood of either curve. Applying Corollary 1, the chain rule, and the Gauss lemma we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\frac{d}{d\\tau} d_{g(-\\tau)}( \\gamma(-\\tau), \\gamma^{\\prime}(-\\tau) ) \\leq O_d(A^{1/2}/\\tau^{1/2});")]]

#text("inserting this into (24) we obtain the claim. ")#mi("\\Box")

#text("Combining this with (5) and rescaling we see that we have a bound of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("l_n( -\\tau, x ) \\geq c d_{g_n(-\\tau)}(p_n,x)^2 / \\tau - O_d(1)")]]

#text("for all x and some ")#mi("c = c_d > 0")#text("; taking limits we also obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("l_\\infty( -\\tau, x ) \\geq c d_{g_\\infty(-\\tau)}(p_\\infty,x)^2/\\tau - O_d(1).")]]

#text("On the other hand, from the Bishop-Gromov inequality we know that balls of radius r in either ")#mi("(M_n, g_n(-\\tau))")#text(" or ")#mi("(M_\\infty, g_\\infty(-\\tau))")#text(" have volume ")#mi("O_d(r^d)")#text(". These facts are enough to establish that the portion of (7) or (8) outside of the ball of radius r decays exponentially fast in r, uniformly in n, and this allows us to take limits in (19) as ")#mi("r \\to \\infty")#text(" to deduce (8) from (7).")

#heading(level: 1)[#text("— Making the argument rigorous II. Parabolic inequality for ")#mi("l_\\infty")#text(" —")]

#text("The next major task in making the previous arguments rigorous is to justify the passage from (10) to (11). First of all, because of the ")#mi("{\\mathcal L}")#text("-cut locus, (10) is only valid in the sense of distributions. We would like to take limits and conclude that (11) holds in the sense of distributions as well. There is no difficulty taking limits with the linear terms ")#mi("\\partial_\\tau l_n - \\Delta l_n")#text(" in (10), or in the zeroth order terms ")#mi("-R_n + \\frac{d}{\\tau}")#text("; the only problem is in justifying the limit from ")#tao-math("\\left|\\nabla l_n\\right|_{g_n}^2", block: false)#text(" to ")#tao-math("\\left|\\nabla l_\\infty\\right|_{g_n}^2", block: false)#text(". We know that the ")#mi("l_n")#text(" are uniformly locally Lipschitz, and converge locally uniformly to ")#mi("l_\\infty")#text("; but this is unfortunately not enough to ensure that ")#tao-math("\\left|\\nabla l_n\\right|_{g_n}^2", block: false)#text(" converges in the sense of distributions to ")#tao-math("\\left|\\nabla l_\\infty\\right|_{g_n}^2", block: false)#text(", due to possible high frequency oscillations in ")#mi("l_n")#text(". To give a toy counterexample, the one-dimensional functions ")#mi("l_n(x) := \\frac{1}{n} \\sin(nx)")#text(" are uniformly Lipschitz and converge uniformly to zero, but ")#tao-math("\\left|\\frac{d}{dx} l_n\\right|^2 = \\cos^2(nx)", block: false)#text(" converges in the distributional sense to ")#mi("\\frac{1}{2}")#text(" rather than zero.")

#text("Since ")#mi("\\nabla l_n - \\nabla l_\\infty")#text(" is bounded and converges distributionally to zero, it will be locally asymptotically orthogonal ")#mi("l_\\infty")#text(". From this and Pythagoras’ theorem we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\lim_{n \\to \\infty} \\left|\\nabla l_n\\right|_{g_n}^2 = \\left|\\nabla l_\\infty\\right|_g^2 + \\lim_{n \\to \\infty} \\left|\\nabla l_\\infty - \\nabla l_n\\right|_{g_n}^2", block: true)]]

#text("in the sense of distributions, where we pass to a subsequence in order to make the limits on both sides exist. (Note that ")#mi("g_n")#text(" converges locally uniformly to g and so there is no difficulty passing back and forth between those metrics.) The task is now to show that there is not enough oscillation to cause the second term on the right-hand side to be non-vanishing.")

#text("To do this, we observe that (10) provides an upper bound on ")#mi("\\Delta_{g_n} l_n")#text("; indeed on any fixed compact set in ")#mi("(-\\infty,0) \\times M_\\infty")#text(", we have ")#mi("\\Delta_{g_n} l_n \\leq O(1)")#text(". This one-sided bound on the Laplacian is enough to rule out the oscillation problem. Indeed, as ")#mi("l_n")#text(" converges locally uniformly to ")#mi("l_\\infty")#text(", we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\limsup_{n \\to \\infty} \\int_{M_\\infty} \\phi (l_\\infty - l_n + \\varepsilon_n) \\Delta_{g_n} l_n\\ d\\mu_n \\leq 0")]]

#text("for any non-negative bump function ")#mi("\\phi")#text(" and ")#mi("\\varepsilon_n \\to 0")#text(" chosen so that ")#mi("l_\\infty - l_n + \\varepsilon_n \\geq 0")#text(" on the support of ")#mi("\\phi")#text(". Integrating by parts and disposing of a lower order term, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\limsup_{n \\to \\infty} \\int_{M_\\infty} \\phi \\langle \\nabla (l_n-l_\\infty), \\nabla l_n \\rangle_{g_n}\\ d\\mu_n \\leq 0.")]]

#text("On the other hand, since ")#mi("\\nabla (l_n - l_\\infty)")#text(" is bounded converges weakly to zero, one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\limsup_{n \\to \\infty} \\int_M \\phi \\langle \\nabla (l_n-l_\\infty), \\nabla l_\\infty \\rangle_{g_\\infty}\\ d\\mu_\\infty \\to 0.")]]

#text("One can easily replace ")#mi("g_\\infty")#text(" and ")#mi("\\mu_\\infty")#text(" here by ")#mi("g_n")#text(" and ")#mi("\\mu_n")#text(". Combining (30) and (31) we conclude that the second term on the RHS of (28) is non-positive in the sense of distributions. But it is clearly also non-negative, and so it vanishes as required.")

#text("This gives (11); as a by-product of the argument we have also established the useful fact")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("\\lim_{n \\to \\infty} \\left|\\nabla l_n\\right|_{g_n}^2 = \\left|\\nabla l_\\infty\\right|_g^2", block: true)]]

#text("in the sense of distributions. Combining this with the growth bounds (26), (27) on ")#mi("l_n")#text(" and $l_\\infty$ from the previous section (which give exponential decay bounds on ")#mi("e^{-l_n}")#text(", ")#mi("e^{-l_\\infty}")#text(" and their first derivatives), it is not too difficult to then justify the remaining steps (12)-(18) of the argument rigorously; see Section 9.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for full details. (Note that once one reaches (13), one has a nonlinear heat equation for ")#mi("l_\\infty")#text(", and it is not difficult to use the smoothing effects of the heat kernel to then show that the locally Lipschitz function ")#mi("l_\\infty")#text(" is in fact smooth.)")

#heading(level: 1)[#text("— The asymptotic gradient shrinking soliton is not flat —")]

#text("Finally, we show that the asymptotic gradient shrinking soliton ")#mi("t \\mapsto (M_\\infty, g_\\infty(t))")#text(" is non-trivial in the sense that its curvature is not identically zero at some time. For if the curvature did vanish everywhere at time t, then the equation (18) simplifies to ")#mi("\\text{Hess}(l_\\infty) = \\frac{1}{2\\tau} g_\\infty")#text(". On the other hand, being flat, ")#mi("(M_\\infty,g_\\infty(t))")#text(" is the quotient of Euclidean space ")#mi("{\\Bbb R}^d")#text(" by some discrete subgroup. Lifting ")#mi("l_\\infty")#text(" up to this space, we thus see that f is quadratic, and more precisely is equal to ")#tao-math("\\left|x\\right|^2/4\\tau", block: false)#text(" plus an affine-linear function. Thus f has no periodicity whatsoever and so the above-mentioned discrete subgroup is trivial. If we now apply (8) we see that ")#mi("\\tilde V(-\\tau) = (4\\pi)^{d/2}")#text(". But on the other hand, as the original ")#mi("\\kappa")#text("-solution was not flat, its reduced volume was strictly less than ")#mi("(4\\pi)^{d/2}")#text(" by Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")[#text("Lecture 14")]#text(", a contradiction. Thus the asymptotic gradient soliton is not flat.")

#heading(level: 1)[#text("— Appendix: Shi’s derivative estimates —")]

#text("The purpose of this appendix is to prove the following estimate of Shi.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3. ")]#text("Suppose that ")#mi("t \\mapsto (M,g(t))")#text(" is a complete d-dimensional Ricci flow on the time interval ")#mi("{}[0,T]")#text(", and that on the cylinder ")#mi("{}[0,T] \\times B_{g(0)}(x_0,r_0)")#text(" one has the pointwise curvature bound ")#tao-math("\\left|\\text{Riem}\\right|_g \\leq K", block: false)#text(". Then on any slightly smaller cylinder ")#mi("{}(0,T] \\times B_{g(0)}(x_0,(1-\\varepsilon)r_0)")#text(" one has the curvature bounds ")#tao-math("\\left|\\nabla^k \\text{Riem}\\right|_g = O( t^{-k/2} )", block: false)#text(" for any ")#mi("k \\geq 0")#text(", where the implied constant depend on ")#mi("d, T, r_0, K, \\varepsilon, k")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) We induct on k. The case ")#mi("k = 0")#text(" is trivial, so suppose that ")#mi("k \\geq 1")#text(" and that the claim has already been proven for all smaller values of k. We allow all implied constants in the O() notation to depend on ")#mi("d, T, r_0, K, \\varepsilon, k")#text(". We refer to ")#mi("{}[0,T] \\times B_{g(0)}(x_0,r_0)")#text(" and ")#mi("{}(0,T] \\times B_{g(0)}(x_0,(1-\\varepsilon)r_0)")#text(" as the “large cylinder” and “small cylinder” respectively.")

#text("We make some reductions. It is easy to see that we can take ")#mi("r_0")#text(" and T to be small.")

#text("Since ")#tao-math("\\left|\\dot g\\right|_g = 2 \\left|\\text{Ric}\\right| = O(1)", block: false)#text(" on the cylinder, we see that the metric at later times of the large cylinder is comparable to the initial metric up to multiplicative constants. The curvature bound tells us that if ")#mi("r_0")#text(" is small, then we are inside the conjugacy radius; pulling back under the exponential map, we may thus assume that the exponential map from ")#mi("x_0")#text(" is injective on the large cylinder. Let ")#mi("r = d_{g(t)}(x_0,x)")#text(" be the ")#emph[#text("time-varying")]#text(" radial coordinate; observe that the annulus ")#mi("\\{ (1-2\\varepsilon/3)r_0 \\leq r \\leq (1-\\varepsilon/3)r_0 \\}")#text(" will be contained between the large cylinder and small cylinder for T small enough.")

#strong[#text("Exercise 5. ")]#text("Show that if ")#mi("r_0")#text(" and T are small enough, then ")#tao-math("\\left|\\text{Hess}(r)\\right|_g = O(1/r)", block: false)#text(" on the large cylinder. ")#mi("\\diamond")

#text("Let ")#mi("\\eta = \\eta(r)")#text(" be a smooth non-negative radial cutoff to the large cylinder that equals 1 on the small cylinder. From the above exercise, the Gauss lemma, and the chain rule, we see that ")#tao-math("\\left|\\nabla \\eta\\right|_g, \\left|\\partial_t \\eta\\right|, \\left|\\text{Hess} \\eta\\right|_g, \\Delta \\eta = O(1)", block: false)#text(".")

#text("Now we study the heat equation obeyed by the “energy densities” ")#tao-math("\\left|\\nabla^m \\text{Riem}\\right|_g^2", block: false)#text(" for various m.")

#strong[#text("Exercise 6. ")]#text("(")#link("http://en.wikipedia.org/wiki/Weitzenb%C3%B6ck_identity")[#text("Bochner-Weitzenböck")]#text(" type estimate) For any ")#mi("m \\geq 0")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("(\\partial_t - \\Delta) \\left|\\nabla^m \\text{Riem}\\right|_g^2  & \\leq O(\\sum_{j=0}^m \\left|\\nabla^j \\text{Riem}\\right|_g \\left|\\nabla^{m-j} \\text{Riem}\\right|_g \\left|\\nabla^m \\text{Riem}\\right|_g)", block: true)



#tao-math(" & - 2 \\left|\\nabla^{m+1} \\text{Riem}\\right|_g^2.", block: true, numbering: n => [#text("(33)")])
]

#text("(Hint: start with the equation ")#mi("\\partial_t \\text{Riem} = \\Delta \\text{Riem} + {\\mathcal O}( g^{-1} \\text{Riem}^2 )")#text(" and use the product rule and the definition of curvature repeatedly.) ")#mi("\\diamond")

#text("From this exercise and the induction hypothesis we see that")

#tao-aligned(keep: true)[


#tao-math("(\\partial_t - \\Delta) [\\eta^{2m+2} t^m \\left|\\nabla^m \\text{Riem}\\right|_g^2]  & \\leq O(1) + O(\\eta^{2m} t^{m-1} \\left|\\nabla^m \\text{Riem}\\right|_g^2)", block: true)



#tao-math(" & - 2 \\eta^{2m+2} t^m \\left|\\nabla^{m+1} \\text{Riem}\\right|_g^2", block: true, numbering: n => [#text("(34)")])
]

#text("for all ")#mi("0 \\leq m \\leq k")#text(", with the understanding that the second term on the right-hand side is absent when m=0. Telescoping this, we can thus find an expression")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("E := \\sum_{m=0}^k C^{-m} \\eta^{2m+2} t^m \\left|\\nabla^m \\text{Riem}\\right|_g^2", block: true)]]

#text("for some sufficiently large positive constant ")#mi("C")#text(", which obeys the heat equation ")#mi("(\\partial_t - \\Delta) E \\leq O(1)")#text(". Also, by hypothesis we have E=O(1) at time zero. Applying the maximum principle, we obtain the claim. ")#mi("\\Box")

#strong[#text("Exercise 6.")]#text(" Suppose that in the hypotheses of Shi’s theorem that we also have ")#tao-math("\\left|\\nabla^j \\text{Riem}\\right|=O(1)", block: false)#text(" for ")#mi("0 \\leq j \\leq m")#text(" on the large cylinder at time zero. Conclude that we have ")#tao-math("\\left|\\nabla^j \\text{Riem}\\right|=O( 1 + t^{-(j-m)/2} )", block: false)#text(" on the small cylinder for all j. ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Let ")#mi("(M,g)")#text(" be a smooth compact manifold, and let ")#mi("u: [0,T] \\times M \\to {\\Bbb R}")#text(" be a bounded solution to the heat equation ")#mi("\\partial_t u = \\Delta u")#text(" which obeys a pointwise bound ")#tao-math("\\left|u(0)\\right| \\leq K", block: false)#text(" at time zero. Establish the bounds ")#tao-math("\\left|\\nabla^k u\\right|_g = O( t^{-k/2} )", block: false)#text(" on the spacetime ")#mi("{}[0,T] \\times M")#text(" and all ")#mi("k \\geq 0")#text(", where the implied constant depends on (M,g), K, T, and k. ")#mi("\\diamond")

#text("(")#emph[#text("Update")]#text(", June 2: some corrections.)")

#text("(")#emph[#text("Update")]#text(", Oct 18 2011: A recently discovered issue with the Hamilton compactness theorem in the case where the curvature bound is not uniform in r has been addressed.)")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30088")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("I can’t make the slightest sense out of any of these lectures, but they must be incredibly exciting to those able to attend them and understand their content. I think it is not very often that there is such a deep new result, with such a level of exposition built around it so quickly. Wiles’ proof of FLT comes to mind but it really didn’t play out quite like this.")

#text("If you don’t mind my asking, how many people are showing up for the lectures? What fraction of them seem to actually follow what’s going on? What mix of grad students, faculty, undergrads, random onlookers? Are they writing out the exercises and turning them in? Just curious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30091")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("To extend Anonymous’ post, who else is tracking the on-line lectures, and why?")

#text("Our QSE Group’s interest in these lectures arises partly because the mathematics is beautiful and the results are historic and profound.")

#text("But we also have pragmatic motivations. In both the classical and quantum domains, we engineers expend a great deal of effort adapting state-spaces to suit the problems at-hand … typically this class of problems poses the biggest computational challenge in system engineering.")

#text("Sometimes the state-space adaptations we need are geometric — this leads us to study Ricci-flow methods. Sometimes the state-space adaptations are dimensional — this leads us to study topics like L1 optimization and compressive sampling.")

#text("Either way, Terence’s lectures are a tremendous source of mathematical information. The theorems are amazing and inspiring, and for us quantumm system engineers, the mathematical toolset deployed to prove the theorems is equally inspiring.")

#text("For which, thank you very much! Everybody understands that posting these lectures is a tremendous amount of work … please let us say that we hope you enjoy writing them as much as we enjoy studying them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PS")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30092")[#strong[#text("PS")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("Minor typo: In Definition 1 it looks like the freestanding “p” should be a “")#mi("p_\\infty")#text("“.")

#text("Another really small typo: The reference in Definition 2 should be to Definition 1 rather than 2.")

#text("In paragraph 3 of the proof of Hamilton’s compactness theorem it seems that the flow we want to pull back should have a “t” in it instead of a “t_0″.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("PS: thanks for the corrections!")

#text("Dear anonymous: Actually, this class is more or less similar to other topics graduate classes I have taught in terms of audience, though I have had some visitors from the optimal transport program next door at IPAM drop in from time to time, and of course our resident Ricci flow experts, Petersen and Wylie, are regularly present. The exercises are intended for self-study only and I am not grading them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Sanders")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30101")[#strong[#text("Andy Sanders")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("Just as a response to an above comment. I am a graduate student at the University of Maryland and have been following these notes on a “more than topical but less than thorough level.” I was motivated to read along since I study Geometry and Topology and am very interested in applications of PDE to topological and geometric problems, of which I will naively claim this proof is probably the most stupendous example of.")

#text("I guess while I’m at it, I’ll just let you know (Prof. Tao) that I am very appreciative of your exposition in these lectures. The wealth of material surrounding this topic is complemented nicely by your heuristic and intuitive explanations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30138")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] and consider the rescaled manifolds . Using Hamilton’s compactness theorem (Theorem 2 from Lecture 15) we may assume that these manifolds converge geometrically to a limit of nonnegative Riemann […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30177")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] we saw in Lecture 15, every -solution has at least one asymptotic gradient shrinking soliton associated to it. Suppose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30188")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("I noticed that your proof of Shi’s local derivative estimates is a bit different from the “usual” one in the book by Chow et. al. (based on Shi’s original proof, and similar to Hamilton’s refined version). This “usual” proof involves finding a quantity that satisfies a nonlinear heat inequality of the form ")#mi("\\psi_t\\leq\\Delta\\psi-\\psi^2+C")#text(" and then observing that one can essentially “localize the maximum principle argument” when such an inequality holds.")

#text("On the other hand, your proof seems much simpler, being a straightforward modification of the proof of the global derivative estimates in Chow et. al. (which I believe is Bando’s proof). In your approach (for m=1), one controls the bad terms in the evolution of ")#tao-math("\\left|\\nabla Riem\\right|^2", block: false)#text(" by adding a ")#tao-math("\\left|Riem\\right|^2", block: false)#text(" term whereas in the other approach one controls the bad terms by multiplying a ")#tao-math("\\left|Riem\\right|^2", block: false)#text(" term. I was wondering whether you had any insight into the difference between the two approaches, or if there’s just not much to it beyond computations.")

#text("Also, regarding Exercise 5, since the Hessian depends on first derivatives of the metric, one naively expects that, under Ricci flow, time derivatives of the Hessian will depend on third derivatives of the metric, or first derivatives of the curvature. But these are not controlled by the hypotheses of Shi’s local estimates. This complication seems to be a source of technical annoyance in the proof of Shi’s local estimates in Chow et. al. Is there an easier way to get around this issue?")

#text("Finally, could you explain why your refer to the inequality (33) as a Bochner-Weitzenbock inequality?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30190")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear Dan,")

#text("I adapted the proof of Shi’s estimates from the one in Morgan-Tian’s book, which they credit to Peng Lu. He also uses a multiplicative weight to damp the bad term but after playing around with it for a while I found that an additive weight works just as well. The basic point is that the only way that the m^th derivative can increase rapidly is if the m-1^th derivative is falling rapidly, so just about any suitable combination of the two terms will balance out this problem.")

#text("You’re right that Exercise 5 is a little more subtle than I thought. One can break the circularity by using a continuity method. We’re already trying to prove a bound of the form ")#tao-math("\\left|\\nabla \\text{Riem}\\right|_g \\leq C / t^{1/2}", block: false)#text(". Without loss of generality, it suffices to prove this under the bootstrap hypothesis ")#tao-math("\\left|\\nabla \\text{Riem}\\right|_g \\leq 2C / t^{1/2}", block: false)#text(", since one can then use “continuous induction” to remove this hypothesis (the set of all T for which these bounds hold will be both open and closed, and contain 0). But once one has this bootstrap hypothesis in hand, first derivatives of curvature become integrable in time and one can control the variation of the Hessian. (As long as T is small compared with C, we can close the induction, and C is ultimately just going to be an absolute constant.)")

#text("As for the Bochner-Weitzenbock type inequality, I am reasoning by analogy with the usual such inequality, which says that if u is some harmonic function or form, then ")#tao-math("\\Delta \\left|\\nabla u\\right|^2", block: false)#text(" looks like the square of a Hessian plus lower order curvature terms. The parabolic analogue of that fact is essentially what one has here, with the curvature tensor or its derivatives playing the role of the harmonic function or form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Oops, I realised that my proposed fix using the continuity method does not work (it requires gradient control on the large cylinder, but one only deduces gradient control on the small cylinder, so the induction does not close). But there is a different way, which is to make the r coordinate (and the cutoff eta) time-dependent, using the metric at time t rather than at time 0. Then one gets the bound on ")#mi("\\Delta \\eta")#text(" (and now also ")#mi("\\partial_t \\eta")#text(") from comparison geometry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-30214")[#strong[#text("285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("[…] the cylinder increasingly resembles a cone. (For instance, one can use the bound from Lemma 1 of Lecture 15, where are geodesics emanating from the infinite curvature end, to establish this sort of thing.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classification of Almost Quarter-Pinched Manifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-31160")[#strong[#text("Classification of Almost Quarter-Pinched Manifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("[…] effects of that flow allow one to take a limit in (this is the Hamilton compactness theorem, see Lecture 15 from my class) and extract a smooth limit manifold of non-negative isotropic curvature (after […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Gromov wins 2009 Abel prize « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/#comment-37507")[#strong[#text("Mikhail Gromov wins 2009 Abel prize « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] proof of the Poincaré conjecture), the concept of Gromov-Hausdorff convergence (a version of which is also key in the proof of the Poincaré conjecture), and Gromov’s celebrated theorem on groups of […]")
]
