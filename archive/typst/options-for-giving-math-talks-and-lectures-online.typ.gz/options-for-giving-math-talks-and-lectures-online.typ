// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/
// Converted to Typst by tao2typ: "2026-10-14T10:57:48.243328+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Options for giving math talks and lectures online", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Options for giving math talks and lectures online")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/")[#text("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As part of social distancing efforts to slow down the spread of the novel coronavirus, several universities have now transitioned, or begun transitioning, to online teaching models. (My home university of UCLA has not yet done so, but is certainly considering the option. UPDATE: ")#link("https://newsroom.ucla.edu/releases/ucla-transitions-to-online-instruction")[#text("we are transitioning")]#text(".) As a consequence, I thought it might be an appropriate time to start a discussion on the pros and cons of various technologies for giving talks and lectures online, particularly in the context of mathematical talks where there may be special considerations coming for instance for the need to do mathematical computations on a blackboard or equivalent. My own institution is for instance recommending the use of ")#link("https://zoom.us/ent?zcid=2582")[#text("Zoom")]#text(" for lectures and ")#link("https://web.respondus.com/")[#text("Respondus")]#text(" for giving finals, and has a limited number of classrooms set up for high quality video and audio casting, as well as a platform for discussion forums and course materials for each class. For smaller meetings, such as one-on-one meetings with graduate students, one can of course improvise using off-the-shelf tools such as Skype. I would be interested in knowing what other options are available and what success lecturers have had with them.")

#text("The same goes for giving mathematical talks. I learned recently (from Jordan Ellenberg) that Rachel Preis has recently launched a “")#link("https://sites.google.com/view/vantageseminar")[#text("virtual math seminar on open conjectures in number theory in arithmetic geometry")]#text("” (VaNTAGe) that is run using the ")#link("https://www.bluejeans.com/")[#text("BlueJeans")]#text(" platform. And for many years there has been a regular joint math seminar between UC Berkeley, U. Paris-Nord, U. Zurich, and U. Bonn (see e.g., ")#link("https://www.math.univ-paris13.fr/laga/index.php/fr/pm/seminaires?id=97:seminaire-d-analyse-appliquee-2&catid=76:seminaires-pm-edp")[#text("this calendar")]#text("), and nowadays many mathematical institutes stream their talks or at least videotape them to place them online later. Our own department does not have a dedicated lecture hall for videocasting, so I would be interested in knowing of any successful ways to improvise such casting with more portable technology. (Skype in principle could work here, but I have found this to be clunky even for smaller meetings involving just a handful of partcipants.)")

#text("EDIT: in addition to lectures and talks, it would also be topical to discuss online options for office hours, midterms, and final exams.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (62)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-2/#comment-625187")[#strong[#text("Math Blackboard Mikes Latex » LoginCast.Com")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2021")]

#text("[…] 4. Options for giving math talks and lectures online | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-2/#comment-638237")[#strong[#text("Math Blackboard Mikes Latex - BlackboardHub.Com")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2021")]

#text("[…] 4. Options for giving math talks and lectures online | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d23192cfecbc423d98035f908757fe7a9f21cdb4da3807a91cdd0ff66ce959-26c6aa75582f16b8be1a31b8c28fab40b588ff1cdb15305adac5e88a0a45dd28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tara Holm")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544817")[#strong[#text("Tara Holm")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("With talks on a wide variety of topics relating to teaching mathematics to undergraduates, the Electronic Seminar on Mathematics Education (")#link("https://math.mit.edu/seminars/esme/")[#text("https://math.mit.edu/seminars/esme/")]#text(") has been meeting on Zoom for a few years now. The platform works quite well, a number of speakers have employed some interesting features to make the lectures interactive. Groups of grad students at Cornell enjoy watching the talks together, bringing their lunches to a seminar room where they can watch on a big screen. Next talk: Tuesday March 17 at 12pm Eastern.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/216bcf8eb10178ae7ea80614e44322fe680b8b2c4678854f1f4f8ed147615d82-18d0d22d74e04d88bec86fb88743f14847852074577defc3d58d5f75272320f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aguy")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544820")[#strong[#text("aguy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("MIT films all their lectures, if you check the most recent Stellar page for 18.085 Gilbert Strangs class. It seems automatic as in multiple cameras follow the lecturer. CMU has a few ‘flipped classes’ like their Math for ML course on YouTube where students all participate live in YouTube and this is recorded then left up for other people like non students to audit. Brown and CMU also use Panopoto which I don’t like because it forces logins.")

#text("Anything thats doesn’t force a proprietary codec, or force logins is generally pretty good. MIT/Erik Demaine have a blog about how to do this ")#link("https://erikdemaine.org/classes/recording/")[#text("https://erikdemaine.org/classes/recording/")]#text(" and participation can just be a discord channel, slack, or YouTube like how CMU does it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03ecbae8784286921367d68217d35bfe77ebad24a79eb5e11604219f56b55a74-0eb6a25531341fb9165226ec2b7da6288d550fde45aee59e0462ec8dc4857f3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peeterjoot")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544822")[#strong[#text("peeterjoot")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("You could probably improvise with OBS screen casting software (which is free but powerful). It’s normally used for video game session sharing, but has capabilities for sharing both a screen and camera and more. I tried using this with a Wacom tablet and a simple drawing app, and was able to stream a virtual “chalkboard” fairly easily to youtube.")

#text("For my own OBS chalkboard experiment, I had the somewhat esoteric requirement to find a MacOS kernel extension to turn off the Intel “turbo” mode that my laptop had, as it made the fan too noisy.")

#text("In my case, I happened to have my video game addicted son around to show me how to use the software, but I’d guess you can find similarly addicted students in a math department to show you the ropes. I’d guess there are also many youtube howtos on this too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544824")[#strong[#text("Options for giving math talks and lectures online - Proxap")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")]

#text("[…] For complete news please follow article link on chmaynard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32bc2e9938058f47edabbb13cc160d2f24000b94c46c29b79d72833d5091467e-336df5db4a1d1406ea8c4c36fed83b549b3910314e2cdc6deffcbdfaee43c6c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grant")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544827")[#strong[#text("Grant")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Hi Terry, I have been working on building something for this: ")#link("https://www.eonias.org")[#text("https://www.eonias.org")]#text(", and specifically the livestream page ")#link("https://www.eonias.org/media/livestream")[#text("https://www.eonias.org/media/livestream")]#text(". I’m not all the way there yet, as it’s a project I have worked on in my spare time. That said, you can type latex in the chat using MathJax, the main upper left video is a live stream, and the right hand side was meant to be video chat. It’s not anything more than Zoom can do with slack etc, but the intention was to develop it with a specific technical teaching focus.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/147a08d7af6f1f3381d408231160b7c64beb20bb39371286704dfd06d4e6f45a-04c4f961a7300ed564d140cc1f6a3afeb610e00b8b6251d3316f972e91390223.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr Mitros")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544831")[#strong[#text("Piotr Mitros")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("I point a camera at a piece of quadrille paper. It’s simple, and works really well. It took a few iterations to get the setup right. Copy stands are massive, cumbersome and bulky, but do work off-the-shelf. I find it more pleasant to work with something less bulky, though.")

#text("Examples of setups which have worked well:")

#text("* Attaching a camera to a monitor arm clamped to a desk")#linebreak()#text(" * A $6 Harbor Freight clamp, a piece of wood, and a webcam")#linebreak()#text(" * A $25 Joby GorillaPod stuck to more-or-less anything and a cell phone")

#text("It is important to get parallax correct; the camera should be perpendicular to the paper. That’s pretty easy to do, though.")

#text("I use a nice set of colored fountain pens (Pilot Varsity, $12), and a nice quadrille pad (surprisingly expensive but on sale now e.g. Tops Engineering Computation Pad, green tint).")

#text("At that point, the critical piece is to have the microphone near the mouth. It’s super-critical. Do not use your built-in microphone. A $5 headset is good enough, but I use a Sennheiser PC-36 USB headset if on a PC. The nice thing is it has a fixed arm holding the microphone next to your mouth, so the microphone is always in the same place, so you can record several times, and edit together. It sounds seamless. Lav mikes, or other models tend to have little differences depending on where exactly they are each day, which makes that sound less seamless.")

#text("My setup for talking to people from home has:")

#text("* One camera looking at me, and a green screen")#linebreak()#text(" * One camera looking at a piece of paper")

#text("That goes into OBS, which is pretty easy-to-use, and lets me set what I’m showing (me, paper, screen share, or any combination). I have a spare monitor for screen sharing (actually, a tablet monitor, but I found the tablet functionality to be less than helpful). That way, my email, OBS, etc. are on my main screen, and I’m only sharing what I want.")

#text("The key thing is to avoid “smart” videoconferencing tools which might e.g. crop your head. Bandwidth is an issue too — you don’t want to be pixellated.")

#text("But on the whole, it works well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pzorin")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544835")[#strong[#text("pzorin")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Similar discussion on Mathoverflow:")#linebreak()#text(" ")#link("https://mathoverflow.net/questions/349283/software-and-ideas-for-workshops-and-conferences-with-long-distance-participants")[#text("https://mathoverflow.net/questions/349283/software-and-ideas-for-workshops-and-conferences-with-long-distance-participants")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544836")[#strong[#text("New top story on Hacker News: Options for giving math talks and lectures online – newsreader")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")]

#text("[…] Options for giving math talks and lectures online 16 by chmaynard | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544840")[#strong[#text("Options for giving math talks and lectures online")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")]

#text("[…] I point a camera at a piece of quadrille paper. Its simple, and works really well. It took a few iterations to get the setup right. Copy stands are massive, cumbersome and bulky, but do work off-the-shelf. I find it more pleasant to work with something less b… Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d01db40902785924ec75d934167271e9e15de30cc17e50adf769d2d204e668f1-8eee95cf3e7d901e3e34edc8bccc7607403c9831c1f1693056b75a189630c5d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shir")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544847")[#strong[#text("Shir")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Unicko Virtual Classroom has a great whiteboard:")#linebreak()

#link("https://www.unicko.com")[#text("https://www.unicko.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc5ff249339fccfe6a90f64282930eaaca7b0eb8cbc82bfabf936691c9971742-2b8cbb7eee158dba51104b1ff1b1554848139c9441ee4917aca9c1099b31a961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Options for giving math talks and lectures online – Hacker News Robot")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544865")[#strong[#text("Options for giving math talks and lectures online – Hacker News Robot")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/")[#text("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544869")[#strong[#text("Options for giving math talks and lectures online – Pipiasi Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/321c5699d100bf89bb3557b05d4282005643d510e7dde4164cd22ed2bc333403-b54e6e5e5b9fd88e1d16f1f25552c15d5983315b7e12e24037126746417cba32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Gent")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544873")[#strong[#text("Peter Gent")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Hi Terry,")

#text("I teach mathematics online in South Australia at Open Access College. We use Webex as our platform for giving lessons. It’s definitely not all smooth sailing with Webex—it’s optimized for holding “meetings” rather than “lessons” I feel.")

#text("I use the free software Autodesk Sketchbook as my “whiteboard” with a Wacom Intuos Pro writing tablet. This combination works really well. The students can see what I’m doing because I share my desktop through Webex.")

#text("You may be aware that there’s talk in South Australia about moving to digital delivery of end-of-year SACE examinations in maths. I wonder what your thoughts are on this idea? Do you think it could work?")

#text("Regards,")

#text("Peter Gent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cda79b1937ff4bbf7e0c18555dc90ad834ff4e6c0b10d8c438936ed3f70b6ad4-dc5f47a6ac8dc2dd3918d0253cb6fe02fcf375fd8db079caddc9931c69fa853c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wes Turner")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544875")[#strong[#text("Wes Turner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("One option: screencast development of a Jupyter notebook.")

#text("Jupyter Notebook supports LaTeX (MathTeX) and inline charts. You can create graded notebooks with nbgrader and/or with CoCalc (which records all (optionally multi-user) input such that you can replay it with a time slider).")

#text("Jupyter Notebooks can be saved to HTML slides with reveal.js, but if you want to execute code cells within a slide, you’ll need to install RISE: ")#link("https://rise.readthedocs.io/en/stable/")[#text("https://rise.readthedocs.io/en/stable/")]

#text("Here are the docs for CoCalc Course Management; Handouts, Assignments, nbgrader: ")#link("https://doc.cocalc.com/teaching-course-management.html")[#text("https://doc.cocalc.com/teaching-course-management.html")]

#text("Here are the docs for nbgrader: ")#link("https://nbgrader.readthedocs.io/en/stable/")[#text("https://nbgrader.readthedocs.io/en/stable/")]

#text("You can also grade Jupyter notebooks in Open edX:")

#text("> *Auto-grade a student assignment created as a Jupyter notebook, using the nbgrader Jupyter extension, and write the score in the Open edX gradebook*")

#link("https://github.com/ibleducation/jupyter-edx-grader-xblock")[#text("https://github.com/ibleducation/jupyter-edx-grader-xblock")]

#text("Or just show the Jupyter notebook within an edX course:")#linebreak()#text(" ")#link("https://github.com/ibleducation/jupyter-edx-viewer-xblock")[#text("https://github.com/ibleducation/jupyter-edx-viewer-xblock")]

#text("There are also ways to integrate Jupyter notebooks with various LMS / LRS systems (like Canvas, Blackboard, etc)")#linebreak()#text(" “nbgrader and LMS / LRS; LTI, xAPI” on the “Teaching with Jupyter Notebooks” mailing list:")#linebreak()#text(" ")#link("https://groups.google.com/forum/#!topic/jupyter-education/_UP-VjBYXJE")[#text("https://groups.google.com/forum/#!topic/jupyter-education/_UP-VjBYXJE")]

#text("“Teaching and Learning with Jupyter” (“An open book about Jupyter and its use in teaching and learning.”)")#linebreak()#text(" ")#link("https://jupyter4edu.github.io/jupyter-edu-book/")[#text("https://jupyter4edu.github.io/jupyter-edu-book/")]

#text("(re-posted from ")#link("https://news.ycombinator.com/item?id=22539537")[#text("https://news.ycombinator.com/item?id=22539537")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cda79b1937ff4bbf7e0c18555dc90ad834ff4e6c0b10d8c438936ed3f70b6ad4-dc5f47a6ac8dc2dd3918d0253cb6fe02fcf375fd8db079caddc9931c69fa853c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wes Turner")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544878")[#strong[#text("Wes Turner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("> *TLJH: “The Littlest JupyterHub” describes how to setup multi-user JupyterHub with e.g. Docker spawners that isolate workloads running with shared resources like GPUs and TPUs: ")#link("http://tljh.jupyter.org/en/latest/")[#text("http://tljh.jupyter.org/en/latest/")]#text(" *")

#text("> *”Zero to BinderHub” describes how to setup BinderHub on a k8s cluster: ")#link("https://binderhub.readthedocs.io/en/latest/zero-to-binderhub/")[#text("https://binderhub.readthedocs.io/en/latest/zero-to-binderhub/")]#text(" *")

#text("If you create a git repository with REES-compatible dependency specification file(s), students can generate a container with all of the same software at home with repo2docker or with BinderHub.")

#text("> *REES is one solution to reproducibility of the computational environment.*")

#text(">> *BinderHub ( ")#link("https://mybinder.org/")[#text("https://mybinder.org/")]#text(" ) creates docker containers from {git repos, Zenodo, FigShare,} and launches them in free cloud instances also running JupyterLab by building containers with repo2docker (with REES (Reproducible Execution Environment Specification)). This means that all I have to do is add an environment.yml to my git repo in order to get Binder support so that people can just click on the badge in the README to launch JupyterLab with all of the dependencies installed.*")

#text(">> *REES supports a number of dependency specifications: requirements.txt, Pipfile.lock, environment.yml, aptSources, postBuild. With an environment.yml, I can install the necessary CPython/PyPy version and everything else.*")

#text("> *REES:")#linebreak()#text(" ")#link("https://repo2docker.readthedocs.io/en/latest/specification.html")[#text("https://repo2docker.readthedocs.io/en/latest/specification.html")]#text(" *")

#text("> *REES configuration files: ")#link("https://repo2docker.readthedocs.io/en/latest/config_files.html")[#text("https://repo2docker.readthedocs.io/en/latest/config_files.html")]#text(" *")

#text("> *Storing a container built with repo2docker in a container registry is one way to increase the likelihood that it’ll be possible to run the same analysis pipeline with the same data and get the same results years later.*")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64e214fc746669567607a1ec4066723edb22e8725e213e1bbcbecac203c943-36874a185a204444f18d8fa59d36c4b3591cdd129ef5ad45dc00317c12321cc7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Byron Gibson (@byrongibson)")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544880")[#strong[#text("Byron Gibson (@byrongibson)")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Stanford is moving all spring quarter classes to online. The hub of info and best practices for that is here: ")#link("https://teachanywhere.stanford.edu/")[#text("https://teachanywhere.stanford.edu/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d05d14d3c276b3f3fda1e397003f591507b2b272dcffb7b879aacca4b8f8ee6-191fb42b88f9f6d806f6c656ff1b821534667980d7d619f0969a44db2916218c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Callen")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544884")[#strong[#text("Callen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Google Meet might be a good idea for remote live streaming. I’ve heard google jamboard is great for interview design questions. Might work for teaching as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544887")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Terry, how would a Zoom lecture go? Since I teach small classes this semester, a laptop in front of the black (or white) board would be almost suitable, except the camera and microphone quality needs to be much better. I am thinking about live Zoom meeting, so not taped lectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeeaa4b2bda59bae613b37640cb4440849095468b409134742a5dabcbd60d48-d356d50030c765560f4944592488f9580b76304fec73ce32d9a64535619a0180.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geetha Venkataraman")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544903")[#strong[#text("Geetha Venkataraman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Hi Terence,")#linebreak()#text(" Recently we had an ‘online’ group theory seminar for my research students at Dr B R Ambedkar University Delhi, India. The speaker was in the US (Dr William Cocke, PhD from Univ of Wisconsin).")

#text("We used zoom. However, there was no board use.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9627b4c33edd7aa71d6eeca5f2602e8c3612d0a5759d52f9c73ea6eb386699d4-5c92ff399f645584dfe4c3d5b19c463225403c5686ef9475e13dcce746aaf1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Gutperle")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544920")[#strong[#text("Michael Gutperle")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("We have a setup in the Schwinger Lounge in PAB using a Logitech Group HD Video and Audio Conferencing System and Zoom. I am going to teach my last class on Thursday using this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544943")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("This looks promising. I am assuming, this can work for a lecture in front of a board. Now what if the university really closes and we have to lecture from home? Can this be set up so that I write on paper? Perhaps a portable white board would do ? LIke one of these?")

#link("https://www.amazon.com/pictionary-easel/s?k=pictionary+easel")[#text("https://www.amazon.com/pictionary-easel/s?k=pictionary+easel")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-549504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("I think iPad + “pencil” is a good substitute for a whiteboard. I’m told that it works well to connect to the lecture twice; once with a PC and once with a tablet. The PC captures video/audio; the tablet is used as a good whiteboard. The difficulty (of course) is that the board space is small.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d92531d9450ec4a9b7dc20cc660b1f2ad08a38b5b6dde1d3032157d4a5004984-31ca5f0242c19a415e410a746580eb85aecfc9d964a5274ae416ee48d9796868.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumeet Patel (@sumeetkpatel)")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544927")[#strong[#text("Sumeet Patel (@sumeetkpatel)")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("One of our very strong use-cases at Collusion is maths and tutoring. It’s also free if for this type of use. See collusionapp.com. Please get in touch if you have any feedback about it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-544960")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("I don’t have a suggestion re options for office hours. But many times I’ve wanted to have a math discussion with another mathematician when distance makes it inconvenient for us to meet in person. But neither of us had any software that would allow us to easily see what each other is writing, much like sitting together at a blackboard. I would love to know if there is readily available software makes that kind of thing easy, especially if it works across platforms like Unix, Linux, Macs, and PC’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bunyamin Sari")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545011")[#strong[#text("Bunyamin Sari")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("We just started a Banach spaces webinar on zoom. This was launched in February before the corona craze, and the idea was to connect people in the field scattered around the world. With the epidemic now this seems even more important. Tech-wise zoom worked great. It lets you share your computer screen, or you can share the screen of a connected device. When giving a talk I wrote on my ipad connected to the computer. There are many other ways of doing it and i am looking forward to other comments here for more. And a shameless plug: our seminar runs on Fridays at 9am central. The next one is on April 3rd, you can join here ")#link("https://unt.zoom.us/j/512907580")[#text("https://unt.zoom.us/j/512907580")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545038")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("What video equipment do you use?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bunyamin Sari")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545055")[#strong[#text("Bunyamin Sari")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("No video equipment is used. Just the computer webcam. You will have much better results by writing on a touchscreen laptop or tablet and share the screen than trying to videotape a whiteboard. If you like to write on a paper you could use a document cam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545061")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("The first day of online teaching and seminars here at UCLA (primarily relying on Zoom) went reasonably well for me and my postdocs. For instance the process of asking and answering questions is smoother with chat rooms, the ability to mute/unmute students, electronic raising of hands, and so forth. One of my postdocs made the interesting observation that the online format produced a more diverse set of students asking questions than the traditional physical classroom. At a technical level there were fewer difficulties setting things up than we had feared.")

#text("On the other hand trying to track the speaker and slides in a seminar with a cheap webcam was quite awkward, as I ended up manually repositioning the webcam as the speaker moved or transitioned between slides and the blackboard. I may have to invest in some sort of stand for the webcam to run this more smoothly. (Hopefully in a few months we will have a more permanent solution, such as dedicated cameras in the lecture rooms, but this will take a while.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545103")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("Hi")#linebreak()#text(" which tools did the students use, to ask questions? An iPad, the keyboard?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2020")])]

#text("After streaming a seminar online, we have discovered that a good format is to have the speaker’s laptop share the PDF slides as the speaker advances them, while other members in the physical audience stream video of the speaker from various angles, so that virtual participants can view both the slides and the speaker, switching between the two as desired. Questions are asked either through chat, through the audience members unmuting their audio, or (for large groups) by electronically “raising their hand”, which is a feature in Zoom.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545974")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("I am not sure of how much extra effort it would take, or whether it will be reasonable at all, but one may consider bringing into scene some sort of auto-built videos, where one needs to feed an image consisting of math equations (such as the blackboard image in your case), which automatically translates it to a digital image, which can be read easily.")

#text("Actually this reply started on a different note and got edited to this because I recalled a particular phone application which I once used to scan equations written on paper and translate them to output of corresponding correct TeX codes for the same lines of equations. In some sense it was like something the Detexify application would become if scanning images were allowed there. But definitely it is a bit slow, and I needed to scan the pages everytime I turned to a new page, and in my opinion this process of repeatedly picking up a scanner to scan something is frustrating. And to some extent it also relies on the camera quality.")

#text("But now, let me come to the suggestion. We can actually design something really efficient in this regard. We can use some image reconstruction method, and then develop an automatic scanner which uses this reconstruction method to reconstruct the image efficiently and then sends it as input to some software which can obtain the TeX code of it, and then this again sends it to some TeX compiler which renders the Latexified line of math corresponding to the line that was originally hand-written.")

#text("This would give us an immediate advantage of making use of a more reliable technology to reconstruct the image that was written on the blackboard, using the images of the same taken by some possibly low grade webcam, instead of relying simply on the eye-judgement of the students to reconstruct the line of math that was originally written.")

#text("And now, ultimately one can use the robust image reconstruction method which was devised by none other than you (alongwith professor Emanuel Candes et al.) in a setting where the model matrix is sparse. Here sparsity can be incorporated in the board image for instance.")

#text("Hope this is one way, which may come useful or get dismissed in favour of some better alternative sometime soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545102")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2020")])]

#text("Hi")

#text("As of Tuesday night, all face to face classes have been suspended for all universities in Madrid by the local government. The same government encouraged (but did not oblige) us, to switch to online courses.")

#text("However given the current infrastructure and software, or better the lack of it, this proposal is a pure phantasy. In addition, not all of our students have a decent internet connection at home.")

#text("In the mathematical department, the dean presented us with google meet, which at first looked nice, has a whiteboard, but has some severe problems.")

#text("1. There is no administrator mode, so students can kick each other out, without any problem.")

#text("2. The whiteboard is a bit primitive compared to the note-taking apps of the iPad (more about that later).")

#text("Another option is Moodle, which we are currently using and which provides two online tools, one is called collaboration, the other video. Video classes are currently not working, this activity has in principle the possibility for the students to ask questions, but again, that feature must be disabled because of bandwidth problems.")

#text("Now, in general, what should an online course software provide, for subjects that require highly formalized languages (mathematics, physics etc)?")

#text("In my opinion, it should provide some sort of interactivity. Students attend classes mainly because they can ask questions, which the lecture in turn can answer.")

#text("That excludes classes that just provide latex-beamer based transparencies since they are too static.")

#text("For me, the ideal tool (and I spend quite some time investigating) is the iPad Pro (the windows surface might be an alternative, but it lacks the wide offer of note-taking apps, the Ipad provides via the app store).")

#text("Students tend to use either GoodNotes or Notablity, because it is usually installed in demo mode in the Apple shops. I use ZoomNotes a very feature-rich app, which I can only warmly recommend.")

#text("However, there does not exist a tool, for interactive sessions with several users. What does exist is jamboard that seems only to allow two users to interact. However, again, its whiteboard is not very sophisticated. It might however be a good choice for one to one tutorial classes.")

#text("So there are two options left: video recording of a blackboard class, for which you need a more professional equipment, the camera and audio of a laptop is not good enough.")

#text("The other option is to use the iPad for video recording the lectures using one of the Notetaking apps I mentioned. That, however, is a bit dull.")

#text("regards")

#text("Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2020")])]

#text("Samuel Watson has a webpage on various teaching technologies, ")#link("http://www.math.brown.edu/~sswatson/teachingtechnology/")[#text("http://www.math.brown.edu/~sswatson/teachingtechnology/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e83045ee1784bf91fa9a10805f1a09bdafc4ac7f1a2743390ede8176c2d38fe-191cf52af127f77cd932fc2fccbb2837fcd12d24c40d08604fec95a4ed47c6e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Zhao")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545449")[#strong[#text("Jason Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2020")])]

#text("A slightly heterodox suggestion, but I would recommend using Discord. The software allows for creation of multiple chat channels (e.g. one could be made for exercises, one for lectures, etc.), screensharing, and most importantly supports bots which can render LaTeX into text images (e.g. ")#link("https://top.gg/bot/mathbot")[#text("https://top.gg/bot/mathbot")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcc8dd35fd3341bd1f47d9472063440b46e7b5f3ab73ea865fb54e45ee88722f-bb4be7f57e927f772a1e062ffc44ee78703e605f4e8c811c8e97971d91ad5d36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545512")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("For one to one or occasionally one to a few tuition, for years I have been using Google Hangouts with a webcam pointing down at some paper on the desk for both me and my tutees. I now have a cheap articulated arm for the webcam, previous to that I used to simply gaffer tape the webcam to a lamp.")

#text("Once you’re used to it, this setup works extremely well. I’d go so far as to say that it works better than sitting right next to or opposite a tutee, since you both have a lot more personal space. For supervisions I think it would be more than acceptable.")

#text("The only problem I have is that lessons are frequently interrupted by the cat, however I doubt this will be a problem in a college department.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3bc91bf3d639f51057c4473f2c2bf52798eaab39d825329014abd9c64ecddc7-9dbd30ef396a4e0bd47b41b0b2b80df9d495b535b4652307a98544258455f2e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545543")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("Has anyone tried to proctor a mathematics exam online yet? Perhaps via the tool that Terry mentioned, Respondus.")

#text("The Respondus documentation seems to suggest that they can offer fully automated proctoring. Does anyone know how well that works in practice?")

#text("Another wrinkle is that most of my students do not know latex. Anyone have any insights or experience with any of these issues?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("A wikipedia article on modeling of infectious disease is")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Mathematical_modelling_of_infectious_disease")[#text("https://en.wikipedia.org/wiki/Mathematical_modelling_of_infectious_disease")]#linebreak()#text(" It seems that estimation of the model parameters may be used to predict the future disease dynamics, and to find the best ways to control it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545558")[#strong[#text("To cheer you up in complicated times – A book proof by Rom Pinchasi and Alexandr Polyanskii for a 1978 Conjecture by Erdős and Purdy! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")]

#text("[…] moving on, let me mention that there is a timely blog post by Terry Tao on Online teaching, and here is a related MO question about online conferences that I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-545964")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("Recently I also heard about cancellation of several mathematics competitions due to social distancing as a precaution to safeguard against novel coronavirus. I think (especially taking into account an uncertainty regarding the duration such social distancing will be performed) one may use a similar method to take exams as one does in taking interviews. Just that for competitions where a large number of participants write the test (so that it is practically not viable to assign an invigilator for each exam writer), one uses some software invigilation instead of human invigilation. So, one has some software which detects activities performed by a person while he is being watched by the software (it may be ensured that the software requires confirmation at both the ends for it to actually work, so that there is no harm to privacy of people due to the software), and stores these records somewhere. Now, in case, one considers that storing such a huge bulk of data is a problem, we can do some probabilistic sampling to keep some of these data and ignore the rest. One may like to actually design a sampling scheme to get a good control on probabilities of non-detecting a to-be -detected activity. So, we can basically compensate for the role of invigilators, and conduct the exams smoothly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fee27f5b51397c6635c1658360405008d3983cddee6d3d878831b3617d5a2b82-83e534486370efa33e8c3d9756a9bb148f3a86417dd91859ccdc2f1d68defdca.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Akhmerov")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-546414")[#strong[#text("Anton Akhmerov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("About scientific talks: zoom works just fine. Figuring out the logistics and the organization detail is a bit of work. Together with several colleagues I’ve tried to collect best practices at ")#link("https://virtualscienceforum.org/")[#text("https://virtualscienceforum.org/")]#text(" ; you can also see how the talks look like at ")#link("https://virtualscienceforum.org/#/inauguralsession")[#text("https://virtualscienceforum.org/#/inauguralsession")]

#text("Today we also had the first zoom lecture, and it worked really well when the lecturer used a tablet instead of a whiteboard, and a separate laptop for a webcam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98fb696ce71905c1b69a0426ec69cf39c89686c19146ad4da568836f8f42e54f-9985afb38031f43ccc3a1e47beef2df6a61cabb02139e9f1fc97e937e062d974.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Burgarth")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-546517")[#strong[#text("Daniel Burgarth")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("I highly recommend smart pens ")#link("https://stempen.org/covid19.svg")[#text("https://stempen.org/covid19.svg")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 数学的学生")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547122")[#strong[#text("数学的学生")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Well, quite fortunately, it seems as though the death rates are based on a simple maths error: If one suffers from severe symptoms, one certainly is much more likely to be tested. Therefore, the Corona virus is arguably much less deadly than previously thought. Nevertheless, I am personally staying at home for the coming weeks and not putting the elderly at risk of getting an infection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547151")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("My understanding is that it’s not the death rate which is significant, but the potential that hospitals get overwhelmed, and then they have to make decisions who lives and who dies using wartime methodology. So what they try to do is slow down the spread of the disease, so the primary purpose of staying away from other people is this, and not directly saving the lives of loved ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 数学的学生")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547155")[#strong[#text("数学的学生")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Obviously, the death rate is very significant. (What a strange comment indeed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547216")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("You are correct. What I meant to say is that the “feature” which makes this virus different from others is how quickly it spreads, and hence it overwhelms hospitals. There have been viruses with much higher mortality rates, though the mortality rate of this one is higher than a “normal” flu’s.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 数学的学生")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547127")[#strong[#text("数学的学生")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Oh, and by the way, in case you don’t want to give all your personal data to Google, it is possible to stream videos using the VLC Media Player (cf. ")#link("https://www.videolan.org/vlc/streaming.html")[#text("https://www.videolan.org/vlc/streaming.html")]#text(") while simultaneously using the IRC as an online chat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 数学的学生")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547133")[#strong[#text("数学的学生")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("In order to start a stream, you’ve got to click the “advanced open file” menu item in order to select a webcam.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 数学生")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547210")[#strong[#text("数学生")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Let me add that I’ve just found the correct spelling of what my username is supposed to be. I knew there couldn’t be a double 学.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547153")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("I wrote up a webpage for my faculty about how to use zoom to stream live lectures, record it and share the link to the recording with the students. The details (like where to log in for Zoom and Onedrive) are specific to my university, but the general scheme is applicable to all. The first link is the webpage, the second one is to the markdown file you can easily modify for your university’s set up.")

#link("http://wd369.csi.hu/apu/zooming.html")[#text("http://wd369.csi.hu/apu/zooming.html")]

#link("http://wd369.csi.hu/apu/zooming.md")[#text("http://wd369.csi.hu/apu/zooming.md")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17f59ccce62e6cb746d600d5dac52e21014ad7dc73e84e0c2d8637e53e47f078-d2ac416ca8d524fa152beca6be06826768c8c307686526819ca2cf3c011d160e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alasdair McAndrew")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547187")[#strong[#text("Alasdair McAndrew")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("My university is moving to Zoom (from WebEx) which will work well. In the dim distant past I’ve used the Access Grid for delivering remotely: I used to give classes to people in multiple locations simultaneously. My main concern is how the students will cope: if a student wants to show me how they’re managing, or struggling, with their mathematics – how do they do that? I myself will have various electronic boards and styluses, but I can’t expect students to have any more than a laptop or tablet with a webcam. Zoom has a whiteboard, which you can indeed draw on, or type on, but without a stylus-enabled pad it’s useless for mathematics. This is my main concern – not how I communicate with students, but how students communicate with me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ca5c8dabf32d42408018a2211785c9c669ed292af8111baecb8f69dfe85bf15-6fd45ac41e494bc49960a49fc94ccbfac5d2d0ade306bc7e3fba01e402983bc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Noel")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547681")[#strong[#text("Jon Noel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("A workshop on graph colouring was scheduled to happen from March 15-20, 2020 at BIRS in Banff. It was cancelled and all of the talks were done online using Zoom. Recordings of the talks can be found here:")

#link("https://www.birs.ca/events/2020/5-day-workshops/20w5143/videos")[#text("https://www.birs.ca/events/2020/5-day-workshops/20w5143/videos")]

#text("There were technical difficulties here and there but, overall, they were very few and very minor. Perhaps these videos are helpful examples for how math talks over Zoom can work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/915b2787ddfbb426410532cb6da9ba67deb7975d906c3babc99270c95e6e70cf-1e24ea8cce7951d8bdabae5f33c3af5f83be3d7e3e7a8dc99997d86f142a355e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel S. Watson")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547713")[#strong[#text("Samuel S. Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("I put together a blog post describing a setup I recommend. There’s a particular emphasis here on maintaining a dialogue with the class, because of the tendency for students to disengage or feel less of a connection with the professor in an online setting:")

#link("https://medium.com/@samuel.s.watson/a-tech-stack-for-virtual-classes-96a1f94a82ee")[#text("View at Medium.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f160c53476fd365d2a8ac703b485164faf99be0e235001d35d3d49c17c4c79f2-2e70b2f99212790f83b6bd6b806f645059861d75c4c5fe6cd1426e494fd70bf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Massimiliano Gubinelli")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-547752")[#strong[#text("Massimiliano Gubinelli")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("An option not yet mentioned is to use the GNU TeXmacs program (www.texmacs.org) to replace whiteboard/tablet in a Zoom conference (or with similar teleconferencing software) or for recording. TeXmacs allows to type mathematics “live”, draw and produce plots with external software. One very nice example is this lecture on ODEs on youtube (")#link("https://youtu.be/ILiL4m61BLw")[#text("https://youtu.be/ILiL4m61BLw")]#text("). I’ve collected in a youtube playlist here (")#link("https://www.youtube.com/playlist?list=PLjXdYclFpynD0ufg_pp-5MT5-X-57Okvs")[#text("https://www.youtube.com/playlist?list=PLjXdYclFpynD0ufg_pp-5MT5-X-57Okvs")]#text(") a series of similar lectures and tutorial done with TeXmacs (some in french) which display the possibilities of using this program for “live” teaching (in comparison to prepare slides in advance).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a314cee2c3d04267f7fe05c87f7ecea9af1f545e0b237d901926c23ced0723e-dbe5dc8a4b3a9547e59701af8d083a60c5e0558e7c8fcdc8ba3c7183a7dcde19.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-548021")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2020")])]

#text("My solution (so far) is a hack, but two components may be useful as they can process TeX (as well as markdown) on the fly:")#linebreak()#text(" (1) gitter chat (my students also like this)..")#linebreak()#text(" (2) Jupyter notebooks – in addtion to processing TeX and markdown, one can also upload an image on the fly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da3e853aabf3634c2a9cff6533fafd00c4d6f2cde1d7362ebe283f2761f5ccc9-c5d00bd5dfdf045b21c8a4392344d5f38264eb338dd7a254b599682e0d648041.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jsiktar")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-553954")[#strong[#text("jsiktar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("I teach calculus right now and all the instructors for this course use a common Zoom conference room to hold office hours. It is definitely very efficient and convenient for our students")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f49a3643fb9d7938e99c617795a6ebd6ced5f5e3dedb53698c16174dfbe80feb-8c29639b50c9047cf61e6670f70478b1094c9a282fec612e88d00159f27ffc43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henrik Shahgholian")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-554120")[#strong[#text("Henrik Shahgholian")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("We are happy to announce all such online talks at our webpage:")#linebreak()#text(" ")#link("https://www.facebook.com/SciLag.math/")[#text("https://www.facebook.com/SciLag.math/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-559697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Just a short comment to note that on May 20 there will be an online panel discussion on how to host virtual mathematical events: ")#link("https://math.mit.edu/~drew/MathOnline20May2020.html")[#text("https://math.mit.edu/~drew/MathOnline20May2020.html")]#text(" . (Thanks to Drew Sutherland for the link.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6903009ef14c5d03924f633bcb0cc51300a8f60d31193b3dee2e0447528690-b85c3528dd9fc627686ecb36265c26512c6f006c20dc3ec961820231450e21c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hugovelozo")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-574457")[#strong[#text("hugovelozo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2020")])]

#text("Folks,")

#text("Does anyone know any PDF presentation software generated by the beamer (latex) with features (stopwatch, laser pointer, pens and others) similar to PowerPoint?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bead2b8946d6ea76505ed2e9cac7e233b6a910f9088dbf4c25b02bff2dead1ea-0b4f33cda2a60355ef29cfc1339b9306da66ea6960a0b32537fd374dec231243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of algline")]], [#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-578600")[#strong[#text("algline")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2020")])]

#text("Old thread but have you seen what Poh-Shen Loh has been doing with his live broadcasts? He explains it here at 1:21:00 ")#link("https://www.youtube.com/watch?v=5__JFBncHAA")[#text("https://www.youtube.com/watch?v=5__JFBncHAA")]#text(" his setup is a $30 Amazon green screen he bought that he evenly lights up, a digital film camera you can either rent or buy the cheapest one, a laptop with a touchscreen he uses as a tablet, and OBS Studio (free) he uses to overlay the green screen with whatever he’s writing on the tablet, that merges the tablet writing with his video stream (OBS you push a button and it automatically broadcasts on youtube) plus obviously another screen set up so he can see himself what he’s pointing to. He does everything over YouTube live and then Zoom he has set up in front of him to see students who then use a chat to communicate with him, because audio from Zoom is too distracting when giving a lecture but he always has the option to enable it if needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/10/options-for-giving-math-talks-and-lectures-online/comment-page-1/#comment-579206")[#strong[#text("xincheng (@pointeurlasers)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")]

#text("You could use a graphics tablet with any program, probably even Paint / whiteboard app , for actually doing the math on screen. I teach using a XP-PEN Star G960S ")#link("https://www.xp-pen.es/product/580.html")[#text("https://www.xp-pen.es/product/580.html")]#text(" tablet and OneNote , Zoom .")
]
