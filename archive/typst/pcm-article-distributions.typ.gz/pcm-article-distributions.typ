// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/
// Converted to Typst by tao2typ: "2026-10-14T06:53:02.869685+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Distributions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Distributions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")[#text("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" through the winter break with my ")#link("http://www.math.ucla.edu/~tao/preprints/distribution.pdf")[#text("article on distributions")]#text(". These “generalised functions” can be viewed either as the limits of actual functions, as well as the dual of suitable “test” functions. Having such a space of virtual functions to work in is very convenient for several reasons, in particular it allws one to perform various algebraic manipulations while avoiding (or at least deferring) technical analytical issues, such as how to differentiate a non-differentiable function. You can also find a more recent draft of my article at the ")#link("http://pcm.tandtproductions.com/")[#text("PCM web site")]#text(" (username Guest, password PCM).")

#text("Today I will highlight ")#link("http://en.wikipedia.org/wiki/Carl_Pomerance")[#text("Carl Pomerance")]#text("‘s informative PCM article on “")#link("http://www.math.dartmouth.edu/%7Ecarlp/PDF/pcm0049.pdf")[#text("Computational number theory")]#text("“, which in particular focuses on topics such as primality testing and factoring, which are of major importance in modern cryptography. Interestingly, sieve methods play a critical role in making modern factoring arguments (such as the ")#link("http://en.wikipedia.org/wiki/Quadratic_sieve")[#text("quadratic sieve")]#text(" and ")#link("http://en.wikipedia.org/wiki/Number_field_sieve")[#text("number field sieve")]#text(") practical even for rather large numbers, although the use of sieves here is rather different from the use of sieves in additive prime number theory.")

#text("[")#emph[#text("Update")]#text(", Jan 1: Link fixed.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22776")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2008")])]

#text("Professor Tao,")

#text("The link is not working.")

#text("If you have time, can you please clarify differences between weak, strong, and classical solutions in PDE setting? I heard that Leray showed existence of weak solutions to Navier-Stokes, if it is true why is it not enough?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2008")])]

#text("Sorry about that! It should work now.")

#text("I discuss Leray’s weak solutions to Navier-Stokes in this article:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("Why global regularity for Navier-Stokes is hard")]
]

#text("More generally, I discuss the difference between weak, strong, and classical solutions in Chapter 3.2 of my book,")

#link("http://www.math.ucla.edu/~tao/preprints/chapter.pdf")[#text("Click to access chapter.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heinrich")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22819")[#strong[#text("Heinrich")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#text("Marvelous, the PCM is destined to become a mathematical gemstone :-)")

#text("However, my opinion is that your article about distributions could shine even more. I mean, there are two questions about any concept: ")#emph[#text("why")]#text(" do I want to use it and ")#emph[#text("how")]#text(" do I use it. In other words, what problems can I solve with it, what does it explain/clarify/enlighten on one hand and how does the machinery work, how to define/construct it to have it ready for calculations/proofs. Mainly the latter is addressed in the article, imho the former is lacking.")

#text("For distributions, the second question is of course the oxymoron “how to define the differentiation of a non-differentiable function?” and the answer is basically to look for such things in the dual space of the test functions ")#tao-fit-display[#mitex("C^{\\infty}")]#text(" as your article shows. I think the article is beating about the bush a bit in the second last paragraph by reassuring many times that most operations like addition and stuff still work but that one has to be a bit careful, too (notably concerning multiplication). Sure thing, but that doesn’t make me feel so reassured at all, since I basically still don’t know how distributions look like, I still “can’t draw one on paper”, and actually checking the formalism is out of the question for the article. I believe that this itchy feeling could be relieved by presenting some simple hands-on examples: differentiate ")#tao-fit-display[#tao-math("\\left|x\\right|", block: true)]#text(" two times and see that the machinery with duality indeed works. I’d even draw pictures (which eat up a lot of time to produce but are definitively worth it for the reader). Of course, the calculation should have the property to be very “easy to the eye” (f.i. no pesky boundary conditions), there is no point in presenting a calculation that is not “obviously correct by looking” since the reader is better off doing it himself in that case.")

#text("Unfortunately, the first question is left largely unanswered by the article. I mean, it tells me that I can do “analysis”, “many operations” and “differentiate the undifferentiable”, but, well … :-) How about some examples, like physicists using the dirac “function” for discrete mass or electron distributions? For instance, the tensor of inertia, or better the center of gravity, is usually expressed as an integral. By using ")#tao-fit-display[#mitex("\\delta")]#text(", this integral can be applied to a collection of discrete mass points, too, yielding the good old sum. A less trivial but in spirit similar example is Green’s function, of course. How to solve Laplace’s equation ")#tao-fit-display[#mitex("\\Delta u=0")]#text(" with Dirichlet boundary conditions ")#tao-fit-display[#mitex("u=f")]#text(" on ")#tao-fit-display[#mitex("\\partial D")]#text("? Well, just solve it for discrete “point masses” ")#tao-fit-display[#mitex("f(x) = \\delta(x-x_0)")]#text(" on the boundary and get the solution for general ")#tao-fit-display[#mitex("f")]#text(" by representing it as a continuous sum of such point masses. I’m sure you know these and much better examples than I do, in which case I’m of course interested in learning them too, for instance by reading your (PCM) articles :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/086fffb5e07bc6794374ab66b785bda9fffab5f3f33bdd6aa42a199d09d101a2-91fbf3eed2d2c362cffe07e05a089b5971e48081078cd2e95a3747e0ac183ef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kinyon")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22855")[#strong[#text("Michael Kinyon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#text("Terry:")#linebreak()#text(" Very nice work. Have you considered writing an article for PCM about Colombeau algebras, the gadgets designed to extend the space of Schwarz distributions so as to allow multiplication?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22861")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")]

#text("[…] PCM article: Distributions I’m continuing my series of articles for the Princeton Companion to Mathematics through the winter break with my […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-22968")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2008")])]

#text("Dear Heinrich: thank you for the comments. It is true that I did not discuss much the “why” of distributions, focusing more on the “how”. One reason for this is severe space limitations; the other is that I find that students seem to have quite significant conceptual difficulties with treating distributions as a generalisation of that of a function, due to (a) set theory teaching them that functions need to assign a specific value to every point in the domain, and (b) analysis giving a whole lot of commandments (“thou shalt not exchange integrals without justification”, etc.) which can seem to be disregarded in a rather cavalier manner by distributions. For instance, trying to describe the Dirac delta function ")#mi("\\delta(x)")#text(" as the function which is zero when x is non-zero, and infinite when x is zero, with total area ")#mi("\\infty \\times 0 = 1")#text(", is a good description if one is already firmly grounded in distribution theory, but can be very confusing and suspicious-looking to a student fresh from a first real analysis course (especially if one then tries to think about what the graph of ")#mi("\\delta^{\\prime}(x)")#text(" would look like). So I focused my article on addressing these issues than on computation (which can be done in more traditional treatments of distributions) or on motivation. But I will add one final paragraph about the application to solving linear PDE, which is probably the main application of distribution theory. (For nonlinear PDE, the fact that distributions usually cannot be multiplied together means that distributions are not as central to the subject as they are for linear PDE.) For technical reasons it will be difficult to make really major changes to the draft article at this point.")

#text("Dear Michael: I know of Columbeau algebras, but to my knowledge they have not played as decisive a role in PDE as distributions (though perhaps they have applications to other subjects that I am unaware of). The reason for this seems to be that it is possible to return from “distribution land” to “classical function land” by devices such as convolution: in particular, convolving a test function f with a distribution K recovers a smooth function f*K, which is a principal reason why the description of fundamental solutions K of linear PDE as a distribution is extremely useful even if one is ostensibly only interested in smooth solutions. But if one has managed to solve a PDE in the Columbeau algebra category, there does not appear to be a similar device known to convert that information into say something about classical solutions to that PDE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PCM article: Generalised solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-23040")[#strong[#text("PCM article: Generalised solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("[…] here, but they may have to wait until spring break.) This article ties in to some extent with my previous PCM article on distributions, because distributional solutions are one good example of a “generalised solution” or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-23279")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2008")])]

#text("Just wanted to say thanks for the links!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Give yourself an epsilon of room « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-36201")[#strong[#text("Tricks Wiki: Give yourself an epsilon of room « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("[…] Sometimes, these solutions are so rough that they are no longer functions, but are measures, distributions, or some other concept of “generalised function” or “generalised […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-42554")[#strong[#text("From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")])]

#text("[…] how to perform operations such as derivatives on Dirac masses; this can be accomplished using the theory of distributions (or, equivalently, by working in the dual setting of observables) but this is not our concern […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/#comment-671303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2023")])]

#text("The link ")#link("http://pcm.tandtproductions.com/")[#text("http://pcm.tandtproductions.com/")]#text(" to the PCM web site mentioned at the end of the first paragraph seems no longer working.")
]
