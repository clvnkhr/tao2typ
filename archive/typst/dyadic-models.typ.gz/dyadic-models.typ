// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/27/dyadic-models/
// Converted to Typst by tao2typ: "2026-10-25T11:48:09.822223+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Dyadic models", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Dyadic models")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the oldest and most fundamental concepts in mathematics is the ")#emph[#text("line")]#text(". Depending on exactly what mathematical structures we want to study (algebraic, geometric, topological, order-theoretic, etc.), we model lines nowadays by a variety of standard mathematical objects, such as the real line ")#mi("{\\Bbb R}")#text(", the complex line ")#mi("{\\Bbb C}")#text(", the ")#link("http://en.wikipedia.org/wiki/Projective_line")[#text("projective line")]#text(" ")#mi("\\Bbb{RP}^1")#text(", the ")#link("http://en.wikipedia.org/wiki/Extended_real_number_line")[#text("extended real line")]#text(" ")#mi("{}[-\\infty,+\\infty]")#text(", the ")#link("http://en.wikipedia.org/wiki/Affine_line")[#text("affine line")]#text(" ")#mi("{\\Bbb A}^1")#text(", the ")#link("http://en.wikipedia.org/wiki/Continuum_%28mathematics%29")[#text("continuum")]#text(" ")#mi("c")#text(", the ")#link("http://en.wikipedia.org/wiki/Long_line_(topology)")[#text("long line")]#text(" ")#mi("L")#text(", etc. We also have discrete versions of the line, such as the natural numbers ")#mi("{\\Bbb N}")#text(", the integers ")#mi("{\\Bbb Z}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Ordinal")[#text("ordinal")]#text(" ")#mi("\\omega")#text(", as well as compact versions of the line, such as the unit interval ")#mi("{}[0,1]")#text(" or the unit circle ")#mi("{\\Bbb T} := {\\Bbb R}/{\\Bbb Z}")#text(". Finally we have discrete ")#emph[#text("and")]#text(" compact versions of the line, such as the cyclic groups ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" and the discrete intervals ")#mi("\\{1,\\ldots,N\\}")#text(" and ")#mi("\\{0,\\ldots,N-1\\}")#text(". By taking Cartesian products we then obtain higher-dimensional objects such as Euclidean space ")#mi("{\\Bbb R}^n")#text(", the standard lattice ")#mi("{\\Bbb Z}^n")#text(", the standard torus ")#mi("{\\Bbb T}^n = {\\Bbb R}^n/{\\Bbb Z}^n")#text(", and so forth. These objects of course form the background on which a very large fraction of modern mathematics is set.")

#text("Broadly speaking, the line has three major families of structures on it:")

#enum(start: 1, 
[#strong[#text("Geometric structures")]#text(", such as a metric or a measure, ")#link("http://en.wikipedia.org/wiki/Complete_space")[#text("completeness")]#text(", scales (coarse and fine), rigid motions (translations and reflection), similarities (dilation, affine maps), and differential structures (tangent bundle, etc.);")],
[#strong[#text("Algebraic structures")]#text(", such group, ring, or field structures, and everything else that comes from those categories (e.g. subgroups, homomorphisms, involutions, etc.); and")],
[#strong[#text("One-dimensional structures")]#text(", such as order, a ")#link("http://en.wikipedia.org/wiki/Intrinsic_metric")[#text("length space")]#text(" structure (in particular, path-connectedness structure), a singleton generator, the ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean property")]#text(", the ability to use mathematical induction (i.e. ")#link("http://en.wikipedia.org/wiki/Well-ordering_property")[#text("well-ordering")]#text("), convexity, or the ability to disconnect the line by removing a single point.")]
)

#text("Of course, these structures are inter-related, and it is an important phenomenon that a mathematical concept which appears to be native to one structure, can often be equivalently defined in terms of other structures. For instance, the absolute value ")#tao-math("\\left|n\\right|", block: false)#text(" of an integer ")#mi("n")#text(" can be defined ")#emph[#text("geometrically")]#text(" as the distance from 0 to ")#mi("n")#text(", ")#emph[#text("algebraically")]#text(" as the ")#link("http://en.wikipedia.org/wiki/Index_of_a_subgroup")[#text("index")]#text(" of the subgroup ")#mi("\\langle n \\rangle = n \\cdot \\Bbb Z")#text(" of the integers ")#mi("{\\Bbb Z}")#text(" generated by n, or ")#emph[#text("one-dimensionally")]#text(" as the number of integers between 0 and ")#mi("n")#text(" (including 0, but excluding ")#mi("n")#text("). This equivalence of definitions becomes important when one wants to work in more general contexts in which one or more of the above structures is missing or otherwise weakened.")

#text("What I want to talk about today is an important toy model for the line (in any of its incarnations), in which the geometric and algebraic structures are enhanced (and become neatly nested and recursive), at the expense of the one-dimensional structure (which is largely destroyed). This model has many different names, depending on what field of mathematics one is working in and which structures one is interested in. In harmonic analysis it is called the ")#link("http://en.wikipedia.org/wiki/Dyadic_interval")[#text("dyadic")]#text(" model, the ")#link("http://en.wikipedia.org/wiki/Walsh_function")[#text("Walsh")]#text(" model, or the Cantor group model; in number theory and arithmetic geometry it is known as the ")#link("http://en.wikipedia.org/wiki/Function_field_of_an_algebraic_variety")[#text("function field")]#text(" model; in topology it is the ")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(" model; in probability it is the ")#link("http://en.wikipedia.org/wiki/Martingale_%28probability_theory%29")[#text("martingale")]#text(" model; in metric geometry it is the ")#link("http://en.wikipedia.org/wiki/Ultrametric")[#text("ultrametric")]#text(", ")#link("http://en.wikipedia.org/wiki/Tree_%28graph_theory%29")[#text("tree")]#text(", or non-")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean")]#text(" model; in algebraic geometry it is the ")#link("http://en.wikipedia.org/wiki/Puiseux_expansion")[#text("Puiseux series")]#text(" model; in additive combinatorics it is the bounded ")#link("http://en.wikipedia.org/wiki/Torsion_%28algebra%29")[#text("torsion")]#text(" or ")#link("http://www.dpmms.cam.ac.uk/~bjg23/images/abs.gif")[#text("finite field model")]#text("; in computer science and information theory it is the ")#link("http://en.wikipedia.org/wiki/Hamming_distance")[#text("Hamming cube")]#text(" model; in representation theory it is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1090425")[#text("Kashiwara crystal")]#text(" model. Let me arbitrarily select one of these terms, and refer to all of these models as ")#emph[#text("dyadic models")]#text(" for the line (or of objects derived from the line). While there is often no direct link between a dyadic model and a non-dyadic model, dyadic models serve as incredibly useful laboratories in which to gain insight and intuition for the “real-world” non-dyadic model, since one has much more powerful and elegant algebraic and geometric structure to play with in this setting (though the loss of one-dimensional structure can be a significant concern). Perhaps the most striking example of this is the three-line proof of the Riemann hypothesis in the function field model of the integers, which I will discuss a little later.")

#heading(level: 1)[#text("— Dyadic integers and reals —")]

#text("Very broadly speaking, one of the key advantages that dyadic models offer over non-dyadic models is that they do not have any “spillover” from one scale to the next. This spillover is introduced to us all the way back in primary school, when we learn about the algorithms for decimal notation arithmetic: ")#link("http://en.wikipedia.org/wiki/Elementary_arithmetic#Addition")[#text("long addition")]#text(", ")#link("http://en.wikipedia.org/wiki/Elementary_arithmetic#Addition")[#text("long subtraction")]#text(", ")#link("http://en.wikipedia.org/wiki/Multiplication_algorithm#Long_multiplication")[#text("long multiplication")]#text(", and ")#link("http://en.wikipedia.org/wiki/Long_division")[#text("long division")]#text(". In decimal notation, the notion of scale is given to us by powers of ten (with higher powers corresponding to coarse scales, and lower powers to fine scales), but in order to perform arithmetic properly in this notation, we must constantly “carry” digits from one scale to the next coarser scale, or conversely to “borrow” digits from one scale to the next finer one. These interactions between digits from adjacent scales (which in modern terminology, would be described as ")#link("http://en.wikipedia.org/wiki/Oseledec_theorem#Cocycles")[#text("cocycles")]#text(") make the arithmetic operations look rather complicated in decimal notation, although one can at least isolate the fine-scale behaviour from the coarse-scale digits (but not vice versa) through ")#link("http://en.wikipedia.org/wiki/Modular_arithmetic")[#text("modular arithmetic")]#text(". (To put it a bit more algebraically, the integers or real numbers can quotient out the coarse scales via normal subgroups (or ideals) such as ")#mi("N \\cdot {\\Bbb Z}")#text(", but do not have a corresponding normal subgroup or ideal to quotient out the fine scales.)")

#text("It is thus natural to look for models of arithmetic in which this spillover is not present. One is first exposed to such models in high school, when the ")#link("http://en.wikipedia.org/wiki/Polynomial_ring")[#text("arithmetic of polynomials")]#text(" in one unknown ")#mi("t")#text(" is introduced (i.e. one works with rings such as ")#mi("{\\Bbb Z}[t]")#text(" or ")#mi("{\\Bbb R}[t]")#text(" rather than ")#mi("{\\Bbb Z}")#text(" or ")#mi("{\\Bbb R}")#text("). For instance, to quotient one polynomial by another, one uses the ")#link("http://en.wikipedia.org/wiki/Polynomial_long_division")[#text("polynomial long division")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Synthetic_division")[#text("synthetic division")]#text(") algorithm, which is formally identical to long division for integers in decimal notation but without all the borrowing from one scale to the next. Here scales are represented by powers of ")#mi("t")#text(", rather than powers of 10. As with the reals or integers, the coarse scales can be contained in a normal subgroups (and ideals) such as ")#mi("t^d \\cdot {\\Bbb R}[t]")#text(", but now the fine scales can ")#emph[#text("also")]#text(" be contained in normal subgroups (though not ideals) such as ")#mi("\\langle 1, t, \\ldots, t^{d-1} \\rangle")#text(", the group generated by ")#mi("1, t, \\ldots, t^{d-1}")#text(" (i.e. the group of polynomials of degree less than ")#mi("d")#text("). (From a category theory perspective, things are better here because various short ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("exact sequences")]#text(" involving the scales are now split.)")

#text("Now, polynomial rings such as ")#mi("{\\Bbb Z}[t]")#text(" or ")#mi("{\\Bbb R}[t]")#text(" are a bit “too big” to serve as models for ")#mi("{\\Bbb Z}")#text(" or ")#mi("{\\Bbb R}")#text(" (unless one adjoins some infinitesimals, but that’s another story), as they have one more dimension. One can get a more accurate model by considering the decimal representation again, which identifies natural numbers as polynomials over the space of digits ")#mi("\\{0,1,\\ldots,9\\}")#text(". This space is not closed under addition (which is what causes spillover in the first place); but we can remedy this by replacing this space of digits with the cyclic group ")#mi("{\\Bbb Z}/10{\\Bbb Z}")#text(". This gives us the model ")#mi("({\\Bbb Z}/10{\\Bbb Z})[t]")#text(" for the integers; this is the decimal representation without the operation of carrying. If we follow the usual decimal notation and identify polynomials in ")#mi("({\\Bbb Z}/10{\\Bbb Z})[t]")#text(" with strings of digits in the usual manner (e.g. identifying ")#mi("3t+2")#text(" with 32) then we obtain a number system which is similar, but not quite identical, to the integers. For instance, 66 + 77 now equals 33 rather than 143; 25*4 now equals 80 rather than 100; and so forth. Note that unlike the natural numbers, the space of polynomials is already closed under negation and so there is no need to introduce negative numbers; for instance, in this system we have -12 = 98. I’ll refer to ")#mi("({\\Bbb Z}/10{\\Bbb Z})[t]")#text(" as the “base 10 dyadic” model for the integers (somewhat annoyingly, the term “10-adic” is ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("already taken")]#text(" to mean something slightly different).")

#text("There is also a base 10 dyadic model for the real numbers, in which we allow infinitely many negative powers of t but only finitely many positive powers in t; in other words, the model is ")#mi("({\\Bbb Z}/10{\\Bbb Z})((1/t))")#text(", the ring of formal Laurent series in ")#mi("1/t")#text(". This ring again differs slightly from the reals; for instance, ")#mi("0.999\\ldots")#text(" is now no longer equal to ")#mi("1.000\\ldots")#text(" (in fact, they differ by ")#mi("1.111\\ldots")#text("). So the decimal notation maps ")#mi("({\\Bbb Z}/10{\\Bbb Z})((1/t))")#text(" onto the positive real axis ")#mi("{\\Bbb R}^+")#text(", but there is a small amount of non-injectivity caused by this map.")

#text("The base 10 dyadic models for the reals and integers are not particularly accurate, due to the presence of zero divisors in the underlying base ring ")#mi("{\\Bbb Z}/10{\\Bbb Z}")#text(". For instance, we have ")#mi("2 \\times 5 = 0")#text(" in this model. One can do a lot better by working over a finite field F, such as the field ")#mi("{\\Bbb F}_2")#text(" of two elements. This gives us dyadic models ")#mi("F[t]")#text(" and ")#mi("F((1/t))")#text(" for the integers and reals respectively which turn out to be much closer analogues than the base 10 model. For instance, ")#mi("F[t]")#text(", like the integers, is an ")#link("http://en.wikipedia.org/wiki/Euclidean_domain")[#text("Euclidean domain")]#text(", and ")#mi("F((1/t))")#text(" is a field. (In the binary case ")#mi("F = {\\Bbb F}_2")#text(", the addition operation is just ")#link("http://en.wikipedia.org/wiki/Bitwise_operation#XOR")[#text("bitwise XOR")]#text(", and multiplication is bitwise ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(".) We can also model many other non-dyadic objects, as the following table illustrates:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Non-dyadic")],
table.cell(colspan: 1, rowspan: 1)[#text("Dyadic")],
table.cell(colspan: 1, rowspan: 1)[#text("Integers ")#mi("{\\Bbb Z}")],
table.cell(colspan: 1, rowspan: 1)[#text("Polynomials ")#mi("F[t]")],
table.cell(colspan: 1, rowspan: 1)[#text("Rationals ")#mi("{\\Bbb Q}")],
table.cell(colspan: 1, rowspan: 1)[#text("Rational functions ")#mi("F(t)")],
table.cell(colspan: 1, rowspan: 1)[#text("Reals ")#mi("{\\Bbb R}")],
table.cell(colspan: 1, rowspan: 1)[#text("Laurent polynomials ")#mi("F((1/t))")],
table.cell(colspan: 1, rowspan: 1)[#text("Unit circle ")#mi("{\\Bbb R}/{\\Bbb  Z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("F((1/t))/F[t] \\equiv \\frac{1}{t} F[\\frac{1}{t}]")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("\\left|F\\right|^d \\cdot {\\Bbb Z}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("t^d \\cdot F[t]")],
table.cell(colspan: 1, rowspan: 1)[#text("Cyclic group ")#tao-math("{\\Bbb Z}/\\left|F\\right|^d \\cdot {\\Bbb Z}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Vector space ")#mi("F^d")],
table.cell(colspan: 1, rowspan: 1)[#text("Finite field ")#mi("{\\Bbb Z}/p \\cdot {\\Bbb Z}")],
table.cell(colspan: 1, rowspan: 1)[#text("Finite field ")#mi("F[t]/p(t) \\cdot F[t]")],
table.cell(colspan: 1, rowspan: 1)[#text("Absolute value")],
table.cell(colspan: 1, rowspan: 1)[#text("(Exponential of) degree")],
table.cell(colspan: 1, rowspan: 1)[#text("Plane wave")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Walsh_function")[#text("Walsh function")#linebreak()#text(" ")]],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Wavelet")[#text("Wavelet")]],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Haar_wavelet")[#text("Haar wavelet")]],
table.cell(colspan: 1, rowspan: 1)[#text("Gaussian")],
table.cell(colspan: 1, rowspan: 1)[#text("Step function")],
table.cell(colspan: 1, rowspan: 1)[#text("Ball")],
table.cell(colspan: 1, rowspan: 1)[#text("Dyadic interval")],
table.cell(colspan: 1, rowspan: 1)[#text("Heat operators")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Martingale_%28probability_theory%29")[#text("Martingale")]#text(" conditional expectations")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Band-limited")[#text("Band-limited")]],
table.cell(colspan: 1, rowspan: 1)[#text("Locally constant")],
table.cell(colspan: 1, rowspan: 1)[#text("Interval / arithmetic progression")],
table.cell(colspan: 1, rowspan: 1)[#text("Subspace / subgroup")],
table.cell(colspan: 1, rowspan: 1)[#text("Bohr set")],
table.cell(colspan: 1, rowspan: 1)[#text("Hyperplane")]
)

#text("Recall that we can define the absolute value (or norm) of an integer n as the index of the subgroup ")#mi("\\langle n \\rangle")#text(" of the integers. Exactly the same definition can be applied to the dyadic model ")#mi("F[t]")#text(" of the integers; the absolute value of an element ")#mi("n \\in F[t]")#text(" can then be seen to equal ")#tao-math("\\left|n\\right| = \\left|F\\right|^{\\deg(n)} \\in {\\Bbb Z}^+", block: false)#text(", where ")#mi("\\deg(n)")#text(" is the degree of t in n (with the convention that 0 has a degree of ")#mi("-\\infty")#text(" and thus an absolute value of 0). For instance, in the binary case, ")#mi("t^3 + t + 1")#text(" (or 1011) has a norm of 8. Like the absolute value on the integers, the absolute value on the dyadic model ")#mi("F[t]")#text(" of the integers is multiplicative and obeys the triangle inequality, giving rise to a metric on ")#mi("F[t]")#text(" by the usual formula ")#tao-math("d(n,m) := \\left|n-m\\right|", block: false)#text(". In fact, we have something better than a metric, namely an ")#link("http://en.wikipedia.org/wiki/Ultrametric")[#text("ultrametric")]#text("; in the dyadic world, the triangle inequality")

#align(center)[#tao-fit-display[#mitex("d(x,z) \\leq d(x,y) + d(y,z)")]]

#text("can be strengthened to the ")#emph[#text("ultratriangle inequality")]

#align(center)[#mi("d(x,z) \\leq \\max(d(x,y),d(y,z))")#text(".")]

#text("One can then uniquely extend this absolute value multiplicatively to the dyadic model ")#mi("F((1/t))")#text(" of the reals, which is given by the same formula ")#tao-math("\\left|n\\right|=\\left|F\\right|^{\\deg(n)} \\in {\\Bbb R}^+", block: false)#text(", where ")#mi("\\deg(n)")#text(" is now understood to be the highest exponent of t which appears in the expansion of n (or ")#mi("-\\infty")#text(" of no such exponent appears). Thus for instance in the binary case ")#mi("1/t + 1/t^2 +  1/t^3 + \\ldots")#text(" (or ")#mi("0.111\\ldots")#text(") has a norm of 1/2. Just as with the real line, this absolute value turns the dyadic real line ")#mi("F((1/t))")#text(" into a complete metric space. The metric space then generates balls ")#tao-math("B(x,r) := \\{ y \\in F((1/t)): \\left|y-x\\right| < r \\}", block: false)#text(", which in the binary case are identifiable with ")#link("http://en.wikipedia.org/wiki/Dyadic_interval")[#text("dyadic intervals")]#text(". The fact that we have an ultrametric instead of a metric means that the balls enjoy a very useful ")#emph[#text("nesting property")]#text(", which is unavailable in the non-dyadic setting: if two balls intersect, then the larger one must necessarily contain the smaller one.")

#text("On the other hand, all the “one-dimensional” structure of the real line is lost when one passes to the dyadic model. For instance, the dyadic real line is still locally compact, but not locally connected; the topology is instead locally that of a ")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(". There is no natural notion of order on the dyadic integers or real line, and the metric is ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("non-Archimedean")]#text(". Related to this, mathematical induction no longer applies to the dyadic integers. Nevertheless, and somewhat counter-intuitively, one can go remarkably far in mimicking many features of the integers and real numbers without using any one-dimensional structure. I’ll try to illustrate this in a number of contexts.")

#heading(level: 1)[#text("— Dyadic models in harmonic analysis —")]

#text("Let us first compare the harmonic analysis of the dyadic and non-dyadic models. Lebesgue measure dx is the unique ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" on the real line which assigns a measure of 1 to the unit interval ")#mi("[0,1]")#text(". Similarly, the dyadic real line ")#mi("F((1/t))")#text(", there is a unique Haar measure dx which assigns a measure of 1 to the unit ball B(0,1). Indeed, this measure can be defined by pulling back Lebesgue measure on the positive real axis ")#mi("{\\Bbb R}^+")#text(" via the decimal map which maps elements of ")#mi("F((1/t))")#text(" to the corresponding base |F| expansion in the reals (e.g. in the binary case, ")#mi("t^2 + 1/t")#text(" would be mapped to ")#mi("100.1_2 = 4.5")#text(").")

#text("The")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text(" general theory of harmonic analysis on locally compact abelian groups")]#text(" then shows that there is a theory of the Fourier transform on the dyadic real line ")#mi("F((1/t))")#text(", which turns out to be closely analogous to that on the non-dyadic real line ")#mi("{\\Bbb R}")#text(". (There is also a Fourier theory relating the dyadic integers ")#mi("F[t]")#text(" with the dyadic unit circle ")#mi("F((1/t))/F[t] \\equiv \\frac{1}{t} \\cdot F[\\frac{1}{t}]")#text(", which we leave to the reader.) Recall that the Fourier transform on the real line is built out of the 1-periodic character ")#mi("e: {\\Bbb R} \\to {\\Bbb C}")#text(" defined by ")#mi("e(x) := e^{2\\pi i x}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{\\Bbb R} f(x) e(-x \\xi )\\ dx")]]

#text("for all well-behaved ")#mi("f: {\\Bbb R} \\to {\\Bbb C}")#text(" (e.g. absolutely integrable f). Similarly, the Fourier transform on ")#mi("F((1/t))")#text(" (assuming F to be a prime field ")#mi("F = {\\Bbb F}_p \\equiv {\\Bbb Z}/p{\\Bbb Z}")#text(" for simplicity) can be built out of the 1-periodic character ")#mi("e_p: F((1/t)) \\to {\\Bbb C}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("e_p( \\sum_{j=-\\infty}^d a_j t^j ) := e( a_{-1} / p )")]]

#text("(which would be a ")#link("http://en.wikipedia.org/wiki/Square_wave")[#text("square wave")]#text(" in the binary case) using almost exactly the same formula, namely")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{F((1/t))} f(x) e_p(-x \\xi)\\ dx")]]

#text("for all well-behaved ")#mi("f: F((1/t)) \\to {\\Bbb C}")#text(". One can then show that this dyadic Fourier transform (known as the ")#link("http://en.wikipedia.org/wiki/Walsh_function")[#text("Walsh-Fourier transform")]#text(" in the binary case) enjoys all the usual algebraic properties that the non-dyadic Fourier transform does – for instance, it reacts with convolution, translation, modulation, and dilation in exactly the same way as its non-dyadic counterpart, and also enjoys a perfect analogue of ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(". (It also has a more pleasant ")#link("http://en.wikipedia.org/wiki/Fast_Fourier_transform")[#text("fast Fourier transform")]#text(" algorithm than its non-dyadic counterpart, as one no longer needs the additional step of taking care of the spillover from one scale to the next.) In fact, the dyadic structure makes the harmonic analysis on ")#mi("F((1/t))")#text(" somewhat simpler than that on ")#mi("{\\Bbb R}")#text(", because of the ability to have ")#emph[#text("perfect phase space localisation")]#text(". In the real line, it is well-known that a function and its Fourier transform cannot simultaneously be compactly supported without vanishing completely (because if a function was compactly supported, then its Fourier transform would be a real analytic function, which cannot be compactly supported without vanishing completely, due to ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text("). However, analytic continuation is a highly “one-dimensional” property (it exploits connectedness). Furthermore, it is not a robust property, and it is possible to have functions f on the real line such that f and its Fourier transform are “almost compactly supported”, or more precisely ")#link("http://en.wikipedia.org/wiki/Rapidly_decreasing")[#text("rapidly decreasing")]#text("; the Gaussian function ")#tao-math("f(x) = \\exp(-\\pi \\left|x\\right|^2)", block: false)#text(", which is its own Fourier transform, is a particularly good example. In the dyadic world, the analogue of the Gaussian function is the step function ")#mi("1_{B(0,1)}")#text(", which is also its own Fourier transform, and thus demonstrates that it is possible for a function and its Fourier transform to both be compactly supported. More generally, it is possible for a function ")#mi("f: F((1/t)) \\to {\\Bbb C}")#text(" to be supported on a dyadic interval I, and for its Fourier transform to be supported on another dyadic interval J, as long as the uncertainty principle ")#tao-math("\\left|I\\right| \\left|J\\right| \\geq 1", block: false)#text(" is respected. One can use these “Walsh wave packets” (which include the ")#link("http://en.wikipedia.org/wiki/Haar_wavelet")[#text("Haar wavelets")]#text(" and Radamacher functions as special cases) to elegantly and efficiently perform time-frequency analysis in the dyadic setting. This has proven to be an invaluable model to work with before tackling the more interesting time-frequency problems in the non-dyadic setting (such as those relating to Carleson’s theorem, or to various multilinear singular integrals), as many technical headaches (such as those involving “Schwartz tails”) are absent in the dyadic setting, while the time-frequency combinatorics (which is really the heart of the matter) stays largely intact. (To give just one example, the ")#link("http://en.wikipedia.org/wiki/Shannon_sampling_theorem")[#text("Shannon sampling theorem")]#text(" collapses in the dyadic setting to the trivial statement that a function which is locally constant on dyadic intervals of length ")#mi("2^{-n}")#text(", can be reconstructed exactly by sampling that function at intervals of ")#mi("2^{-n}")#text(".) See these ")#link("http://www.math.unm.edu/~crisp/papers/lectures.pdf")[#text("lecture notes of Pereyra")]#text(" or ")#link("http://www.math.ucla.edu/%7Etao/254a.1.01w/notes5.ps")[#text("of myself")]#text(" for more discussion. In some cases one can in fact deduce a non-dyadic harmonic analysis result directly from a dyadic one via some sort of averaging argument (or the ")#emph[#text("1/3 translation trick")]#text(" of Michael Christ, which is the observation that every non-dyadic interval (in, say, [0,1]) is contained either in a dyadic interval of comparable size, or the 1/3 translation of a dyadic interval of comparable size). In particular the “Bellman function” approach to harmonic analysis often proceeds via this averaging, as the Bellman function method requires a recursive dyadic structure (or a continuous heat kernel-type structure) in order to work properly. In general, though, the dyadic argument only serves as a model “road map” for the non-dyadic argument, rather than a formal component. There are only a few cases known where a dyadic result in harmonic analysis has not shown the way towards proving the non-dyadic analogue; one of these exceptions is the problem of establishing a nonlinear analogue of Carleson’s theorem, which was ")#link("http://front.math.ucdavis.edu/math.CA/0205139")[#text("achieved in the dyadic setting")]#text(" but remains open in the non-dyadic setting.")

#heading(level: 1)[#text("— Dyadic models in PDE —")]

#text("Let us now leave harmonic analysis and turn to dyadic and non-dyadic models of other parts of mathematics. I should briefly discuss PDEs, which is one field in which the dyadic models have proven to have only a limited impact (though the ")#link("http://www.ams.org/mathscinet-getitem?mr=2095627")[#text("Katz-Pavlovic dyadic model")]#text(" for the Euler and Navier-Stokes equations is perhaps a counterexample). This is partly because, in contrast to harmonic analysis, the analysis of PDEs ")#emph[#text("do")]#text("es heavily exploit the one-dimensionality of the real line (and in particular, the time axis), for instance via the use of continuity arguments or monotonicity formulae. Nevertheless one can still obtain some partial analogues of various PDE objects, most notably those connected to the heat equation, as long as one is willing to work with dyadic notions of time. For instance, in the binary case ")#mi("F = {\\Bbb F}_2")#text(", the dyadic analogue of the heat operator ")#mi("e^{t\\Delta}")#text(" when ")#mi("t= 2^{2n}")#text(" is a power of 4 would be the conditional expectation operator to the ")#mi("\\sigma")#text("-algebra generated by dyadic intervals of length ")#mi("2^n")#text(". These conditional expectations are nested in n, yielding a ")#link("http://en.wikipedia.org/wiki/Martingale_%28probability_theory%29")[#text("martingale")]#text(" structure. There is in fact a very strong (and well known) analogy between heat operators and conditional expectations with respect to a martingale; to give just one example, the sharp ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]#text(" on the real line ")#link("http://arxiv.org/abs/math.MG/0505065")[#text("can be proven")]#text(" by a heat flow method (ensuring that a certain multilinear expression is monotone along heat flow), and the corresponding sharp Young’s inequality on ")#mi("F((1/t))")#text(" or ")#mi("F^n")#text(" can similarly be proven (with a somewhat shorter proof) by a nested conditional expectation argument.")

#heading(level: 1)[#text("— Dyadic models in additive combinatorics —")]

#text("We now briefly turn to additive combinatorics. Here, it is often convenient for combinatorial reasons to work not on an infinite additive group such as ")#mi("{\\Bbb R}")#text(" or ")#mi("{\\Bbb Z}")#text(", but in a finite additive group. In the non-dyadic setting, one usually uses a cyclic group such as ")#mi("{\\Bbb Z}/N {\\Bbb Z}")#text("; in the dyadic setting, one uses a vector space such as ")#mi("F^n")#text(" (one should think of F as being fixed, e.g. ")#mi("F = {\\Bbb F}_2")#text(" or ")#mi("F = {\\Bbb F}_3")#text(", and n as being large). A general philosophy is that as long as these two groups have roughly the same size (i.e. ")#tao-math("N \\approx \\left|F\\right|^n", block: false)#text("), then the additive combinatorics of these two groups will be broadly analogous, even if algebraically the groups are rather different (the former can be generated by a single generator, but most elements have large order, whereas the latter needs many generators, and all elements have small order). But the dyadic model tends to be significantly more tractable for a number of reasons. Most obviously, the group ")#mi("F^n")#text(" is also a vector space, and thus one can apply the powerful tools of linear algebra. A cyclic group only has some partial (and messy) analogues of linear algebraic tools; for instance, in cyclic groups generalised arithmetic progressions are somewhat analogous to vector spaces spanned by a given set of vectors, has a lot of subgroups; dually, Bohr sets (level sets of one or more characters) play a role in cyclic groups analogous to the intersection of one or more hyperplanes in ")#mi("F^n")#text(". See ")#link("http://www.arxiv.org/abs/math.NT/0409420")[#text("this survey paper of Green")]#text(" for further discussion. Another useful feature of the group ")#mi("F^n")#text(" is the presence of ")#link("http://en.wikipedia.org/wiki/Flag_%28linear_algebra%29")[#text("flags")]#text(" of subspaces, e.g. the coordinate flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = F^0 \\subset F^1 \\subset \\ldots \\subset F^n")]]

#text("which allows one in some cases to prove combinatorial facts in ")#mi("F^n")#text(" by an induction on dimension, and to use tools related to such flags such as the combinatorial technique of ")#emph[#text("compression")]#text(". See this ")#link("https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/")[#text("previous blog post")]#text(" for some examples of this.")

#text("Very recently, though, Ben Green and I have discovered that the lack of one-dimensionality in the finite field model can make that model ")#emph[#text("less ")]#text("tractable than the cyclic group model in certain technical senses. For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("Gowers’ celebrated proof")]#text(" of ")#link("http://www.scholarpedia.org/article/Szemeredi%27s_Theorem")[#text("Szemerèdi’s theorem")]#text(" does not quite work in finite field models because of this little wrinkle. This seems to have something to do with the (still poorly understood) analogy between nilsequences in the non-dyadic setting, and polynomials in the dyadic setting. Hopefully we’ll have more to say about this in the future.")

#heading(level: 1)[#text("— Dyadic models in algebraic combinatorics —")]

#text("I’ll now touch briefly on the role of dyadic models in algebraic combinatorics. Here it seems that many algebraic questions that are over the field ")#mi("{\\Bbb R}")#text(" or ")#mi("{\\Bbb C}")#text(" collapse to purely combinatorial questions once one “")#link("http://en.wikipedia.org/wiki/Tropical_geometry")[#text("tropicalises")]#text("” by passing to a dyadic model field, such as the field of ")#link("http://en.wikipedia.org/wiki/Puiseux_series")[#text("Puiseux series")]#text(" ")#mi("{\\Bbb C}\\{t\\}")#text(". Furthermore (and rather miraculously), certain questions have ")#emph[#text("identical")]#text(" answers in the dyadic and non-dyadic settings, thus allowing one to use combinatorial gadgets to solve algebraic problems. For instance, the question of understanding the possible relationships between eigenvalues of a sum A+B of Hermitian matrices, with the eigenvalues of A and B separately, is a non-trivial algebraic problem; but by passing to the dyadic model of Puiseux series and extracting the leading exponents (which does not affect the final answer) it was ")#link("http://arxiv.org/abs/math.AG/0311428")[#text("shown by Speyer")]#text(" that the problem collapses to the combinatorial problem of locating a ")#link("https://terrytao.wordpress.com/2007/04/19/open-question-what-is-a-quantum-honeycomb/")[#text("honeycomb")]#text(" between the three sets of putative eigenvalues. (This fact, as well as the one below, had been established earlier ")#link("http://front.math.ucdavis.edu/math.RT/9807160")[#text("by Knutson and myself")]#text(" by a much more indirect method.) There is also a discrete (representation-theoretic) counterpart to this phenomenon; the question of computing tensor product multiplicities for the unitary group U(n) is also a non-trivial algebraic problem, in large part due to the “mixing” between basis elements of irreducible representations when one takes tensor products and then decomposes again into irreducibles (in the case n=2, this mixing is described by the ")#link("http://en.wikipedia.org/wiki/Clebsch-Gordan_coefficients")[#text("Clebsch-Gordan coefficients")]#text("; the situation is more complicated in higher n due to multiplicities in the decomposition). But if one replaces the notion of a representation with the “dyadic” model of a ")#link("http://www.ams.org/mathscinet-getitem?mr=1090425")[#text("crystal representation")]#text(", the mixing is eliminated (without affecting the multiplicities), and it was shown ")#link("http://front.math.ucdavis.edu/math.CO/0408114")[#text("by Henriques and Kamnitzer")]#text(" that the problem of computing tensor product multiplicities again collapses to a honeycomb problem. It would be interesting to get a more general explanation of why these phenomena occur.")

#heading(level: 1)[#text("— Dyadic models in number theory —")]

#text("Finally, I want to discuss the role of dyadic models in number theory – a topic which has in fact been the subject of at least ")#link("http://www.ams.org/mathscinet-getitem?mr=1876657")[#text("one entire graduate text")]#text(". In contrast to the other settings discussed above, there is a fantastic disparity in number theory between our understanding of the dyadic model and that of the non-dyadic model; several of the most famous problems in non-dyadic number theory (e.g. Riemann hypothesis, Fermat’s last theorem, twin prime conjecture, abc conjecture, factorisation of large numbers) are surprisingly easy to solve in the dyadic world (see e.g. ")#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/")[#text("Zhang’s talk")]#text(" for the dyadic version of FLT), but nobody knows how to convert the dyadic arguments to the non-dyadic setting (although the converse step of converting non-dyadic arguments to dyadic ones is usually rather straightforward). One notable exception here is the ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity problem")]#text(", which has resisted progress in both dyadic and non-dyadic settings.")

#text("Let’s now turn to the Riemann hypothesis. Classically, number theory has focused on the multiplicative structure of the ring of integers ")#mi("{\\Bbb Z}")#text(". After factoring out the group of units ")#mi("\\{-1,+1\\}")#text(", we usually restrict attention to the positive integers ")#mi("{\\Bbb Z}^+")#text(". In the dyadic model, we study the multiplicative structure of the ring ")#mi("F[t]")#text(" of polynomials for some finite field F. After factoring out the group ")#mi("F^\\times")#text(" of units, we can restrict attention to the ")#link("http://en.wikipedia.org/wiki/Monic_polynomial")[#text("monic")]#text(" polynomials ")#mi("F[t]_m")#text(". As the ring of polynomials is a Euclidean domain, it has unique factorisation, and in particular every monic polynomial can be expressed uniquely (up to permutation) as the product of irreducible monic polynomials, which we shall call ")#emph[#text("prime")]#text(" polynomials.We can analyse the problem of counting primes in ")#mi("F[t]")#text(" by using zeta functions, in complete analogy with the integer case. The Riemann zeta function is of course given by")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) := \\sum_{n \\in {\\Bbb Z}^+} \\frac{1}{n^s}")]]

#text("(for ")#mi("\\text{Re}(s) > 1")#text(") and we introduce the analogous zeta function")

#align(center)[#tao-math("\\zeta_{F[t]}(s) := \\sum_{n \\in F[t]_m} \\frac{1}{\\left|n\\right|^s}", block: false)#text(".")]

#text("In the integers, unique factorisation gives the identity")

#align(center)[#tao-fit-display[#mitex("\\log n = \\sum_{d|n} \\Lambda(d)")]]

#text("where ")#mi("\\Lambda(d)")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", defined to equal ")#mi("\\log p")#text(" when d is the power of a prime p and 0 otherwise. Taking the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text(" of this identity, we conclude that")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\sum_{n \\in {\\Bbb Z}^+} \\frac{\\Lambda(n)}{n^s},")]]

#text("which is the fundamental identity linking the zeroes of the zeta function to the distribution of the primes. We can do the same thing in the dyadic case, obtaining the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("-\\frac{\\zeta^{\\prime}_{F[t]}(s)}{\\zeta_{F[t]}(s)} = \\sum_{n \\in F[t]_m} \\frac{\\Lambda_{F[t]}(n)}{\\left|n\\right|^s},", block: true)]]

#text("where the von Mangoldt function ")#mi("\\Lambda_{F[t]}(n)")#text(" for F[t] is defined as ")#tao-math("\\log \\left|p\\right|", block: false)#text(" when n is the power of a prime polynomial p, and 0 otherwise.")

#text("So far, the dyadic and non-dyadic situations are very closely analogous. But now we can do something special in the dyadic world: we can compute the zeta function explicitly by summing by degree. Indeed, we have")

#align(center)[#tao-math("\\zeta_{F[t]}(s) = \\sum_{d=0}^\\infty \\sum_{n \\in F[t]_m: \\text{deg}(n)=d} \\frac{1}{\\left|F\\right|^{ds}}", block: false)#text(".")]

#text("The number of monic polynomials of degree d is ")#tao-math("\\left|F\\right|^{d}", block: false)#text(". Summing the geometric series, we obtain an exact formula for the zeta function:")

#align(center)[#tao-math("\\zeta_{F[t]}(s) = (1 - \\left|F\\right|^{s-1})^{-1}", block: false)#text(".")]

#text("In particular, the Riemann hypothesis for F[t] is a triviality – there are clearly no zeroes whatsoever! Inserting this back into (1) and comparing coefficients, one soon ends up with an ")#emph[#text("exact")]#text(" prime number theorem for F[t]:")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in F[t]_m: \\text{deg}(n)=d} \\Lambda(n) = \\left|F\\right|^d \\log \\left|F\\right|", block: true)]]

#text("which quickly implies that the number of prime polynomials of degree d is ")#tao-math("\\frac{1}{d} \\left|F\\right|^d + O( \\left|F\\right|^{d/2} )", block: false)#text(". (One can generalise the above analysis to other varieties over finite fields, leading ultimately to the (now-proven) ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(", which include the “Riemann hypothesis for function fields”.)")

#text("Another example of a problem which is hard in non-dyadic number theory but trivial in dyadic number theory is ")#emph[#text("factorisation")]#text(". In the integers, it is not known whether a number which is n digits long can be factored (probabilistically) in time polynomial in n (the best known algorithm for large n, the ")#link("http://en.wikipedia.org/wiki/Number_field_sieve")[#text("number field sieve")]#text(", takes a little longer than ")#mi("\\exp( O( \\log^{1/3} n ) )")#text(" time); indeed, the presumed hardness of factoring underlies many popular cryptographic protocols such as ")#link("http://en.wikipedia.org/wiki/RSA")[#text("RSA")]#text(". However, in ")#mi("F[t]")#text(" with F fixed, a polynomial f of degree n can be factored (probabilistically) in time polynomial in n by the following three-stage algorithm:")

#enum(start: 1, 
[#text("Compute the gcd of f and its derivative f’ using the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text(" (which is polynomial time in the degree). This locates all the repeated factors of f, and lets one quickly reduce to the case when f is squarefree. (This trick is unavailable in the integer case, due to the lack of a good notion of derivative.)")],
[#text("Observe (from ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_theorem_%28group_theory%29")[#text("Cauchy’s theorem")]#text(") that for any prime polynomial g of degree d, we have ")#tao-math("t^{\\left|F\\right|^d} = t \\text{ mod } g", block: false)#text(". Thus the polynomial ")#tao-math("t^{\\left|F\\right|^d}-t", block: false)#text(" contains the product of all the primes of this degree (and of all primes of degree dividing d); indeed, by the exact prime number theorem and a degree count, these are the only possible factors of ")#tao-math("t^{\\left|F\\right|^d}-t", block: false)#text(". It is easy to compute the remainder of ")#tao-math("t^{\\left|F\\right|^d}-t", block: false)#text(" modulo f in polynomial time, and then one can compute gcd of f with ")#tao-math("t^{\\left|F\\right|^d}-t", block: false)#text(" in polynomial time also. This essentially isolates the prime factors of a fixed degree, and quickly lets one reduce to the case when f is the product of distinct primes of the same degree d. (Here we have exploited the fact that there are many primes with exactly the same norm – which is of course highly false in the integers. Similarly in Step 3 below.)")],
[#text("Now we apply the ")#link("http://en.wikipedia.org/wiki/Cantor-Zassenhaus_algorithm")[#text("Cantor-Zassenhaus algorithm")]#text(". Let us assume that |F| is odd (the case |F|=2 can be treated by a modification of this method). By computing ")#tao-math("g^{(\\left|F\\right|^d-1)/2} \\text{ mod } f", block: false)#text(" for randomly selected g, we can generate some random square roots a of 1 modulo f (thanks to Cauchy’s theorem and the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text("; there is also a small chance we generate a non-invertible element, but this is easily dealt with). These square roots a will be either +1 or -1 modulo each of the prime factors of f. If we take the gcd of f with a+1 or a-1 we have a high probability of splitting up the prime factors of f; doing this a few times one soon isolates all the prime factors separately.")]
)

#heading(level: 1)[#text("— Conclusion —")]

#text("As the above whirlwind tour hopefully demonstrates, dyadic models for the integers, reals, and other “linear” objects show up in many different areas of mathematics. In some areas they are an oversimplified and overly easy toy model; in other areas they get at the heart of the matter by providing a model in which all irrelevant technicalities are stripped away; and in yet other areas they are a crucial component in the analysis of the non-dyadic case. In all of these cases, though, it seems that the contribution that dyadic models provide in helping us understand the non-dyadic world is immense.")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05307d96b27beeb0f822ca53a149d53522d1cc46f53bada0d2bf178d6e528c16-4e4a71d9f5170bbb87027e1abeb70861782075ed3820f7187173e374f7b2b379.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5160")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("These interactions between digits from adjacent scales (which in modern terminology, would be described as cocycles)")
]

#text("Would it then be fair to say that the difference between dyadic models and non-dyadic models is parallel to the difference between abelian and non-abelian gauge field theories?")

#text("You seem to indicate that one can use a dyadic analogue to get at the heart of a problem, and then try to adapt that proof to the original setting. In that approach, one must get a handle on the messiness that comes with using a nontrivial cocycle that crosses the scales. To what extent can an appropriate classification of “bundles” (or “gerbes”) help this effort?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5161")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")])]

#text("Dear John,")

#text("That’s an interesting analogy. Dyadic models are suppressing cocycles rather than commutators, but there is certainly a similar theme in that both types of objects destroy “perfect decoupling” in some sense. But the cocycles tend to be a little more pleasant to deal with, because they seem to be a bit more unidirectional or “nilpotent”. For instance, one can add a small number to a large number to move the large number to the next largest scale, but you can’t get the large number to modify the small number in a similar manner. Whereas in a non-abelian gauge theory, if the gauge group is simple then you’re going to see every component of the gauge group interact, eventually, with every other. This “nilpotency” seems to be an important enabler for letting one generalise a dyadic argument to a non-dyadic argument; often the key is to attend to the scales in the right order (either working on coarse scales first and only then tackling the fine, or vice versa, or doing a preliminary sparsification of the scales to make the non-dyadic model look more dyadic), and to make sure that the various errors caused by spillover effects don’t blow up while doing so.")

#text("Regarding classification of bundles and gerbes, I feel that the concepts of dyadic vs non-dyadic are still rather vague and certainly not at the point where one can use cohomological tools to concretely identify what obstruction the non-dyadic world has that the dyadic world doesn’t. Part of the problem is that we don’t really have a family of continuous deformations from the dyadic world to the non-dyadic world (except possibly in the algebraic combinatorics setting, where various quantum algebras, as well as the process of tropicalisation and detropicalisation, seem to be filling this role). This, by the way, would be a fantastic way to prove the Riemann hypothesis for integers, by continuously deforming from the function field model! This seems wildly optimistic to me, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5162")[#strong[#text("Dyadic models and magnetic order « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")]

#text("[…] models and magnetic order Terry Tao gives a whirlwind tour of dyadic models: … an important toy model for the line (in any of its incarnations), in which the geometric […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05307d96b27beeb0f822ca53a149d53522d1cc46f53bada0d2bf178d6e528c16-4e4a71d9f5170bbb87027e1abeb70861782075ed3820f7187173e374f7b2b379.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5163")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Dyadic models are suppressing cocycles rather than commutators")
]

#text("But isn’t a commutator a sort of cocycle? Maybe a more apt analogy is conformal field theory, where one must add central charges (a cocycle) to properly lift the representation theories at hand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5168")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")])]

#text("Hmm, I never thought of them that way before, but I guess you’re right, a commutator is indeed a special type of cocycle. On the other hand, it seems to a somewhat different type of cocycle from that which appears in the interactions between scales for the integers and reals (which don’t appear to have any particularly non-commutative structure in them :-).")

#text("My knowledge of CFTs is pretty minimal, but the central charge c appears to be a deformation parameter for some sort of algebra, which does look (on a superficial level, at least) like how the quantum parameter q is a deformation parameter for the universal enveloping algebra for, say, sl_n, which is how the Kashiwara crystal representations arise as deformations of the representation theory of a Lie group. So the analogy might have some substance to it, at least for the dyadic models that come up in algebraic combinatorics. [On the other hand, from a physical perspective q is usually interpreted as a “temperature” rather than a “charge”, which fits with the more general philosophy of interpreting these scale-mixing cocycles as being some sort of messy, entropy-producing phenomenon.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5172")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")]

#text("[…] Dyadic models One of the oldest and most fundamental concepts in mathematics is the line. Depending on exactly what mathematical […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3948c22798e2632c39acdcd2036dd86c420c70658eef3dc0b2edf2b9423e6b0b-0b5da07b38d6f022723acd140c3a610919f38899ff51fd3e4d3542cc704ae10e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5263")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2007")])]

#text("Hi Terence,")

#text("Your use of “tropicalises” suggests to me either tropical geometry or tropical algebra.")

#text("Are these also referred to as Min-Plus Algebra [Geometry], related to Max-Plus algebra? I am more familiar with the latter.")

#text("The terminology is similar but not identical:")#linebreak()#text(" dioid algebra rather than dyadic")#linebreak()#text(" and")#linebreak()#text(" idempotent semiring rather than nilpotent.")

#text("These algebras are extensions of mathematical game theory.")

#text("I am most familiar with:")#linebreak()#text(" 1 – ‘Dynamic Noncooperative Game Theory’, Tamer Basar, Geert Jan Olsder")#linebreak()#text(" 2 – Max-Plus at Work: …”, Bernd Heidergott, Geert Jan Olsder, and Jacob van der Woude")#linebreak()#text(" 3 – Some of the arxiv papers of Stephane Gaubert, INRIA.")

#text("I suspect some type of rigorous relation [beyond my ability], since John von Neumann had ‘rings of operators’ algebra for physics and ‘minimax’ game theory for engineering and economics?")

#text("They may also be related via trajectory curves [ballistics] through Euler?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5280")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2007")])]

#text("Dear Doug,")

#text("There is indeed a connection. If you take the semi-ring of polynomials ")#mi("{\\Bbb R}_+[t]")#text(" with non-negative coefficients in one variable t (which can be thought of as one of the dyadic models of the line), then the degree map ")#mi("\\text{deg}: P \\mapsto \\text{deg}(P)")#text(" is a homomorphism from that semi-ring to the max-plus algebra of the natural numbers: ")#mi("\\text{deg}(f+g) = \\max( \\text{deg}(f), \\text{deg}(g) )")#text(", ")#mi("\\text{deg}(f g) =  \\text{deg}(f) + \\text{deg}(g)")#text(". If you want the max-plus algebra of the reals rather than the natural numbers, use Puiseux series instead of polynomials. The paper of Speyer referenced above exploits this connection.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3948c22798e2632c39acdcd2036dd86c420c70658eef3dc0b2edf2b9423e6b0b-0b5da07b38d6f022723acd140c3a610919f38899ff51fd3e4d3542cc704ae10e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5626")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Hi Terence,")

#text("I remain stunned at the simple elegance of your equations using a degree map.")

#text("I had thought that the more complicated mathematics of dynamic noncoopertive game theory would be needed.")

#text("You seem to have unified the Nobel categories of Physics and Economics?")

#text("Thanks for the Speyer reference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-5647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2007")])]

#text("Dear Doug,")

#text("Mathematics is the common language of all the sciences, so it is actually not that surprising that a single mathematical concept can appear two unrelated disciplines. As an analogy, a Harry Potter novel and a legal contract may share some words of English in common (including perhaps some rare or unusual words), but this is not exactly a “unification” of the two documents. In particular, reading one is unlikely to inform the other, except possibly for the fact that you may need to look up the same word in the dictionary in both cases.")

#text("On the other hand, if two documents had several ")#emph[#text("sentences")]#text(" in common (up to trivial rewordings), then there is a more serious connection. Similarly, if two areas of science are using the same (or very similar) ")#emph[#text("theorems")]#text(" about mathematical objects, then it can become profitable to consider the analogies between those two areas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d5d8a4e75ead6e0f6a1731dd69f9a4e3fd380e3b23de1153950815950ee47d5-8c73e2eef92fe9c74874c64dc3dea3e55e9cafd3f3e37e5600c3827d4ec6b1d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Isett")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-10129")[#strong[#text("Phil Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")])]

#text("Dear Terence,")

#text("I did a little work on a certain generalization of Haar Wavelets to (compact) groups which were “solvable” in a sense like that of Galois Theory; formal Laurent series over a finite field being just one example. I just gave a seminar on it at the University of Maryland, where I’m currently a senior. (The seminar didn’t go too well for various reasons, including both a concurrent football game and my own inexperience in this sort of thing)")

#text("After reading this entry I thought you might have been interested in the work. If you’d care, I could send you the paper in a PDF file.")

#text("~Phil Isett")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Walsh model for M_2^* Carleson « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-19967")[#strong[#text("The Walsh model for M_2^* Carleson « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2007")])]

#text("[…] of ours on the return times theorem of Bourgain, in which the Fourier transform is replaced by its dyadic analogue, the Walsh-Fourier transform. This model estimate is established by the now-standard techniques of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multi-linear multipliers associated to simplexes of arbitrary length « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-20830")[#strong[#text("Multi-linear multipliers associated to simplexes of arbitrary length « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2007")])]

#text("[…] using a trace formula (a nonlinear analogue to Plancherel’s formula). Also, the “dyadic” or “function field” model of the conjecture is known, by a modification of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dvir’s proof of the finite field Kakeya conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-27586")[#strong[#text("Dvir’s proof of the finite field Kakeya conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("[…] 1999, Wolff proposed a simpler finite field analogue of the Kakeya conjecture as a model problem that avoided all the technical issues involving […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tate’s proof of the functional equation « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-31559")[#strong[#text("Tate’s proof of the functional equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2008")])]

#text("[…] analogues in the p-adic completions of the rationals . (This is analogous to my discussion of dyadic models, although the p-adics are still characteristic 0 and are not as dyadic as their function field […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-44742")[#strong[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("[…] when ) and also in number theory; but they also serve as an important simplified “dyadic model” for the integers. See this survey article of Green for further discussion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-45695")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] fraction of the time”; for a precise definition, see my book with Van Vu). However, there are dyadic models of Euclidean domains, such as the field of formal Laurent series in a variable over a finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc065b2fdf83a2e01996123d3cceaded78165c312ddd76b387acbb2b3bae36a2-29e2d36262003cfb3520dca2dfed3d0a3811ed77ebe69042e9fe376ef2a40997.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bilboy")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-47731")[#strong[#text("bilboy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("Most of the number systems have a basis of the form ")#mi("\\{1,b,b^2,b^3...\\}")#text(", essentially the basis is a geometric series.")

#text("Can there be a bijection between integers and an additive basis, i.e, can every integer be represented as ")#mi("\\sum_{i=0}^{\\infty}c_i  b_i")#text(", where $b_i$ is not an geometric series (does not grow as fast as b^n for some fixed b). Can we restrict $b_i$ to be an arithmetic series with varying gap. If not for the entire integer set, does such a bijection for a fraction of integers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3111d31438d1140f8c19261f0f9e64fe85415c82bdb999ba9ef140463b95771-81e49f3a6caba6fcbbf8c7f2ac2a009e2c49b54a59d7b10a201173aefa6c6b99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LifeIsChill")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-47747")[#strong[#text("LifeIsChill")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("There is a motivic description of some of the algebraic structures starting with the line you are commenting on. Does your description have any connection to motivic models?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rohlin’s problem on strongly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-50644")[#strong[#text("Rohlin’s problem on strongly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2011")])]

#text("[…] is a “dyadic” (or more precisely, “triadic”) model for the integers (cf. this earlier blog post of mine). In other words: Theorem 2 There exists a -system that is strongly -mixing but not strongly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b78dbc8ad74be22afeab4474eef66914b433980e4d8394657a8af54229e718e-2ff96ac7a9a712518548ebd4c1bbbd2e24a3bd628f4ed8b699cbd7fbc8034e63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of binary transforms | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-95545")[#strong[#text("binary transforms | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2011")])]

#text("[…] See ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-143820")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] located. On the other hand, the situation is significantly more promising if one works in the function field model in which the integers are replaced by the ring of polynomials of one variable over a finite field, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b78dbc8ad74be22afeab4474eef66914b433980e4d8394657a8af54229e718e-2ff96ac7a9a712518548ebd4c1bbbd2e24a3bd628f4ed8b699cbd7fbc8034e63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dyadic models in number theory–would NSA *want* to suppress results? | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-148218")[#strong[#text("dyadic models in number theory–would NSA *want* to suppress results? | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-433525")[#strong[#text("Mark Keith’s constrained writing | The Daily Pochemuchka")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")]

#text("[…] easily appreciated as very very hard because we can immediately think of toy examples (to bastardize Tao), for instance writing a ten-word sentence that reads the same forwards and backwards instead of a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0cc10090fee76f8e9937218e2a7d82a6e9bf25fac60f490f51fc69cd2e038e6-f74bbb484ccfd7cf0c3525f69f18d3d70115771f063db44e1d6160ec5ee33f76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelmalek Abdesselam")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-445176")[#strong[#text("Abdelmalek Abdesselam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("That’s a terrific post!! It’s too bad however that the discussion did not include sections on the dyadic models in probability and in physics. In physics, a ubiquitous framework for trying to understand a wide variety of phenomena is the quantum field theory formalism and at the heart of it is Wilson’s renormalization group. There too there are Euclidean (non-dyadic) models and their hierarchical (dyadic) version. Wilson himself referred to dyadic models as “the approximate recursion”. Working with this toy model was in fact crucial to the discoveries made by Wilson (such as the epsilon-expansion). I explained some of this in")#linebreak()#text(" ")#link("http://arxiv.org/abs/1311.4897")[#text("http://arxiv.org/abs/1311.4897")]#text(" In probability theory the dyadic models such as the branching Brownian motion or random walk are a useful toy model for the so-called Gaussian free field. A similar idea is that of Mandelbrot cascades.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-447090")[#strong[#text("What are examples of good toy models in mathematics? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")]

#text("[…] comment on another question reminded me of this old post of Terence Tao’s about toy models. I really like the idea of using toy models of a difficult object to understand it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-457345")[#strong[#text("Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2015")])]

#text("[…] the analogy between integers and polynomials over a finite field , discussed for instance in this previous post; this is the simplest case of the more general function field analogy between number fields and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54683340484a57865cd47ec86c32c81e2a3f25006bb95cf5ba696c5fd996720d-9ee65a59b018e08c7e21806e1105f9f3ece22561db2131fd28e9c23f2f658626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curiousquery.")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-479183")[#strong[#text("curiousquery.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2017")])]

#text("You say in Cantor-Zassenhaus algorithm. Let us assume that |F| is odd (the case |F|=2 can be treated by a modification of this method). By computing $g^{(|F|^d-1)/2} \\hbox{ mod } f$ for randomly selected g, we can generate some random square roots a of 1 modulo f and gcd of a +/- 1 mod f factors f with high probability. Will this work over Z? then we would have a probabilistic reduction from factoring to quadratic residue which is an open problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-479257")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("As mentioned in the blog post, this step relies crucially on the fact that all the prime factors of a given degree ")#mi("d")#text(" have exactly the same magnitude (so the same exponent ")#tao-math("(\\left|F\\right|^d-1)/2", block: false)#text(" works regardless of what the factors are). In the integer case, the prime factors have different magnitudes, and it is not clear how to proceed this way. (If we somehow were able to compute the Euler totient function ")#mi("\\phi(n)")#text(" of the number ")#mi("n")#text(" we wished to factor, we would be in much better shape, but this may well be as hard as the original factoring problem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-491095")[#strong[#text("The Dyadic Riemann hypothesis - Quantum Calculus")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2018")]

#text("[…] The Dyadic group of integers is not so familiar to us that the circle. It is a much simpler space however as it is quantized, (we have a smallest translation, a dynamical system which is also called the “adding machine”), it is still a compact space and a natural limit of one-dimensional geometric spaces in the Barycentric limit. Also, its dual, the Prüfer group does not have any interesting primes. The Prüfer group is the spectrum of the Koopman operator of the adding machine. I got to this when looking at renormalizations of random Jacobi matrices. The Dyadic group appeared there naturally as a limit of a 2:1 integral extension in ergodic theory: the group translation is called the von Neumann-Kakutani system. The limiting operators are almost periodic operators defined over that system. The spectra are on located Julia sets, the density of states are the equilibrium measures on that sets. In some sense, these Jacobi operators define “quantized Julia sets” as they are operators for which the spectra are Julia sets. Some other mathematical connections to the dyadic world are discussed here, in a blog of Tao from more than 10 years ago. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d191384a03ca4f2dcf5a89eb253c7c8c3b3e8e5a618a06698b97dc65d3d16bc-be770b64e6ecb1ffb723375ca6c86a310d2cef96c600036808e6c2d572c04abf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-517516")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2019")])]

#text("Are there models derived from non-one dimensional objects such as the plane?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4ac78e149399b6bb2ab69c5d724bf59624307f79c17a015120c25c0a0e087b0-1cc42654ca35804d1694e78ae8a1f8121c78f1ac9436653475c1deccac233b61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-601951")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2020")])]

#text("Is there a dyadic and non-dyadic interpretation for matrix products?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-607417")[#strong[#text("Dyadic models in number theory and \"spillover\" ~ MathOverflow ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")]

#text("[…] a classic blog post, Tao discusses the appearance of \"dyadic models\" in various guises in various areas of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff3d4fdbdb67eb0e6cb0b8cb0829383e3fb5619efe04424d9bf1676634c166e-3816a7bce7463b0d8e3a6bf0d991831f215daa8c6f7598a097fd0730548ec22d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Onsprctrsl")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-614103")[#strong[#text("Onsprctrsl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("Would the laplacian operator in spectral graph theory and geometry be considered non-dyadic? If so what would be the dyadic version? Any references?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-614231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("The spectrum of most Laplacians are not concentrated in a lacunary set such as the powers of two, so would not be considered dyadic operators, although it is often profitable to treat them as if they were dyadic using the device of Littlewood-Paley theory. Given a dyadic mesh structure on a space one can create a dyadic analogue of a Laplacian (or more generally fractional powers of the Laplacian), though they do not have as much of a geometric interpretation as the more traditional Laplacians. See for instance ")#link("https://arxiv.org/abs/2004.10940")[#text("https://arxiv.org/abs/2004.10940")]#text(" for a recent treatment of such operators.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f1b31d0c38f519f1544136e5fa5c2d1028118b6516924553b21544bed2c6327-f394dc1d38577ac8710e3f6c590d06047c037552ca75da73287187acb1ecec39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chasing integers")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-675491")[#strong[#text("Chasing integers")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2023")])]

#text("Why are polynomials ‘the’ dyadic model for integers? Are there other ‘types’ of models for integers other than dyadic models?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-675754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2023")])]

#text("It comes down to the fact that there are only two types of ")#link("https://en.wikipedia.org/wiki/Global_field")[#text("global fields")]#text(": number fields and function fields. The integers are the ring of integers for the simplest number field ")#mi("{\\mathbf Q}")#text(", while polynomials ")#mi("{\\bf F}_q[T]")#text(" over a finite field are the ring of integers for the simplest function field ")#mi("{\\bf F}_q(T)")#text(". (One can axiomatically define what a global field is in terms of valuations without reference to either number fields or function fields.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-691896")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2026")])]

#text("Is there a good reference for dyadic models for pde heat and diffusion equations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-691897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2026")])]

#text("For fluid equations, dyadic shell models are fairly popular. In general, ")#link("https://gemini.google.com/share/8eba92bd87cf")[#text("see this AI query")]#text(" for several references.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-691898")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2026")])]

#text("many thanks I will look into them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-692132")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#text("Dr Tao,")

#text("Why would completion be a geometric structure? Like why would completion of measure space have a connection with geometric structure?")

#emph[#text("[As the Wikipedia link indicates, I am referring here to completeness of metric spaces, rather than completeness of measure spaces. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-692315")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2026")])]

#text("Hi Terry, Could speficy on why martingale structure is a dyadic structure? I do not know analysis well, is martingale structure a common topic in analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-692468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2026")])]

#text("I am ")#link("https://claude.ai/share/3bfaa385-b88f-4df3-9eb3-48d424091eba")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-693197")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2026")])]

#text("in the setting of tropical geometry with min and + do we have dyadic and non-dyadic models?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-693207")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2026")])]

#text("Tropical geometry, with its ultrametric structure, already captures most of the key features of dyadic models anyway, even if it does not explicitly involve powers of two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-693210")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2026")])]

#text("Ok thank you. Is there a ‘CRT’ and ‘Euclidean algorithm’ in tropical geometry? Is there an algorithm for ‘CRT’?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/comment-page-1/#comment-698740")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#link("https://www.emergentmind.com/openai-math-explorer/results/142")[#text("https://www.emergentmind.com/openai-math-explorer/results/142")]#text(" provides improvements. Could you comment similar to QRH .. is it appearing right or not? Similar to QRH it stitches seemingly unrelated territories and perhaps portrays useful dyadic models in algebraic geometry?")
]
