// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/
// Converted to Typst by tao2typ: "2026-10-14T08:58:58.881010+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Localization of the eigenvalues and the necessity of four moments", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Localization of the eigenvalues and the necessity of four moments")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/")[#text("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/1005.2901")[#text("Random matrices: Localization of the eigenvalues and the necessity of four moments")]#text("“, submitted to ")#link("http://www.springerlink.com/content/100451/")[#text("Probability Theory and Related Fields")]#text(". This paper concerns the distribution of the eigenvalues")

#align(center)[#tao-fit-display[#mitex("\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)")]]

#text("of a ")#emph[#text("Wigner random matrix")]#text(" ")#mi("{M_n}")#text(". More specifically, we consider ")#mi("{n \\times n}")#text(" Hermitian random matrices whose entries have mean zero and variance one, with the upper-triangular portion of the matrix independent, with the diagonal elements iid, and the real and imaginary parts of the strictly upper-triangular portion of the matrix iid. For technical reasons we also assume that the distribution of the coefficients decays exponentially or better. Examples of Wigner matrices include the Gaussian Unitary Ensemble (GUE) and random symmetric complex Bernoulli matrices (which equal ")#mi("{\\pm 1}")#text(" on the diagonal, and ")#mi("{\\pm \\frac{1}{2} \\pm \\frac{i}{2}}")#text(" off the diagonal). The Gaussian Orthogonal Ensemble (GOE) is also an example once one makes the minor change of setting the diagonal entries to have variance two instead of one.")

#text("The most fundamental theorem about the distribution of these eigenvalues is the ")#emph[#text("Wigner semi-circular law")]#text(", which asserts that (almost surely) one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n \\delta_{\\lambda_i(M_n)/\\sqrt{n}} \\rightarrow \\rho_{sc}(x)\\ dx")]]

#text("(in the vague topology) where ")#mi("{\\rho_{sc}(x) := \\frac{1}{\\pi} (4-x^2)_+^{1/2}}")#text(" is the semicircular distribution. (See ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("these lecture notes")]#text(" on this blog for more discusssion of this law.)")

#text("One can phrase this law in a number of equivalent ways. For instance, in the bulk region ")#mi("{\\epsilon n \\leq i \\leq (1-\\epsilon) n}")#text(", one almost surely has ")#metadata(none) <tao-9d23384be3fd6cce0529>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lambda_i(M_n) = \\gamma_i \\sqrt{n} + o(\\sqrt{n})")]]

#text("uniformly for in ")#mi("{i}")#text(", where the ")#emph[#text("classical location")]#text(" ")#mi("{\\gamma_i \\in [-2,2]}")#text(" of the (normalised) ")#mi("{i^{th}}")#text(" eigenvalue ")#mi("{\\frac{1}{\\sqrt{n}} \\lambda_i}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{-2}^{\\gamma_i} \\rho_{sc}(x)\\ dx := \\frac{i}{n}.")]]

#text("The bound ")#link(<tao-9d23384be3fd6cce0529>)[#text("(1)")]#text(" also holds in the edge case (by using the operator norm bound ")#tao-math("{\\left\\| M_n\\right\\|_{op} = (2+o(1)) \\sqrt{n}}", block: false)#text(", due ")#link("http://www.ams.org/mathscinet-getitem?mr=958213")[#text("to Bai and Yin")]#text("), but for sake of exposition we shall restriction attention here only to the bulk case.")

#text("From ")#link(<tao-9d23384be3fd6cce0529>)[#text("(1)")]#text(" we see that the semicircular law controls the eigenvalues at the coarse scale of ")#mi("{\\sqrt{n}}")#text(". There has been a significant amount of work in the literature in obtaining control at finer scales, and in particular at the scale of the average eigenvalue spacing, which is of the order of ")#mi("{\\sqrt{n}/n = n^{-1/2}}")#text(". For instance, we now have a universal limit theorem for the normalised eigenvalue spacing ")#mi("{\\sqrt{n}(\\lambda_{i+1}(M_n) - \\lambda_i(M_n))}")#text(" in the bulk for all Wigner matrices, a ")#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("result of Erdos, Ramirez, Schlein, Vu, Yau, and myself")]#text(". One tool for this is the ")#emph[#text("four moment theorem")]#text(" ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("of Van and myself")]#text(", which roughly speaking shows that the behaviour of the eigenvalues at the scale ")#mi("{n^{-1/2}}")#text(" (and even at the slightly finer scale of ")#mi("{n^{-1/2-c}}")#text(" for some absolute constant ")#mi("{c>0}")#text(") depends only on the first four moments of the matrix entries. There is also a slight variant, the ")#emph[#text("three moment theorem")]#text(", which asserts that the behaviour of the eigenvalues at the slightly coarser scale of ")#mi("{n^{-1/2+\\epsilon}}")#text(" depends only on the first three moments of the matrix entries.")

#text("It is natural to ask whether these moment conditions are necessary. From the result of Erdos, Ramirez, Schlein, Vu, Yau, and myself, it is known that to control the eigenvalue ")#emph[#text("spacing")]#text(" ")#mi("{\\lambda_{i+1}(M_n) - \\lambda_i(M_n)}")#text(" at the critical scale ")#mi("{n^{-1/2}}")#text(", no knowledge of any moments beyond the second (i.e. beyond the mean and variance) are needed. So it is natural to conjecture that the same is true for the eigenvalues themselves.")

#text("The main result of this paper is to show that this is not the case; that at the critical scale ")#mi("{n^{-1/2}}")#text(", the distribution of eigenvalues ")#mi("{\\lambda_i(M_n)}")#text(" ")#emph[#text("is")]#text(" sensitive to the fourth moment, and so the hypothesis of the four moment theorem cannot be relaxed.")

#text("Heuristically, the reason for this is easy to explain. One begins with an inspection of the expected fourth moment")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n {\\bf E}(\\lambda_i(M_n)^4) = {\\bf E} \\text{tr} M_n^4.")]]

#text("A standard moment method computation shows that the right hand side is equal to")

#align(center)[#tao-fit-display[#mitex("2n^3 + 2a n^2 + \\ldots")]]

#text("where ")#mi("{a}")#text(" is the fourth moment of the real part of the off-diagonal coefficients of ")#mi("{M_n}")#text(". In particular, a change in the fourth moment ")#mi("{a}")#text(" by ")#mi("{O(1)}")#text(" leads to a change in the expression ")#mi("{\\sum_{i=1}^n {\\bf E}(\\lambda_i(M_n)^4)}")#text(" by ")#mi("{O(n^2)}")#text(". Thus, for a typical ")#mi("{i}")#text(", one expects ")#mi("{{\\bf E}(\\lambda_i(M_n)^4)}")#text(" to shift by ")#mi("{O(n)}")#text("; since ")#mi("{\\lambda_i(M_n) = O(\\sqrt{n})}")#text(" on the average, we thus expect ")#mi("{\\lambda_i(M_n)}")#text(" itself to shift by about ")#mi("{O(n^{-1/2})}")#text(" by the mean-value theorem.")

#text("To make this rigorous, one needs a sufficiently strong concentration of measure result for ")#mi("{\\lambda_i(M_n)}")#text(" that keeps it close to its mean value. There are already a number of such results in the literature. For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=1781846")[#text("Guionnet and Zeitouni")]#text(" showed that ")#mi("{\\lambda_i(M_n)}")#text(" was sharply concentrated around an interval of size ")#mi("{O(n^\\epsilon)}")#text(" around ")#mi("{\\sqrt{n} \\gamma_i}")#text(" for any ")#mi("{\\epsilon > 0}")#text(" (in the sense that the probability that one was outside this interval was exponentially small). In one of ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("my papers with Van")]#text(", we showed that ")#mi("{\\lambda_i(M_n)}")#text(" was also weakly concentrated around an interval of size ")#mi("{O(n^{-1/2+\\epsilon})}")#text(" around ")#mi("{\\sqrt{n} \\gamma_i}")#text(", in the sense that the probability that one was outside this interval was ")#mi("{O(n^{-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text(". Finally, if one made an additional log-Sobolev hypothesis on the entries, it was shown by ")#link("http://arxiv.org/abs/1001.3453")[#text("by Erdos, Yau, and Yin")]#text(" that the average variance of ")#mi("{\\lambda_i(M_n)}")#text(" as ")#mi("{i}")#text(" varied from ")#mi("{1}")#text(" to ")#mi("{n}")#text(" was of the size of ")#mi("{O(n^{-c})}")#text(" for some absolute ")#mi("{c>0}")#text(".")

#text("As it turns out, the first two concentration results are not sufficient to justify the previous heuristic argument. The Erdos-Yau-Yin argument suffices, but requires a log-Sobolev hypothesis. In our paper, we argue differently, using the three moment theorem (together with the theory of the eigenvalues of GUE, which is extremely well developed) to show that the variance of each individual ")#mi("{\\lambda_i(M_n)}")#text(" is ")#mi("{O(n^{-c})}")#text(" (without averaging in ")#mi("{i}")#text("). No log-Sobolev hypothesis is required, but instead we need to assume that the third moment of the coefficients vanishes (because we want to use the three moment theorem to compare the Wigner matrix to GUE, and the coefficients of the latter have a vanishing third moment). From this we are able to make the previous arguments rigorous, and show that the mean ")#mi("{{\\bf E} \\lambda_i(M_n)}")#text(" is indeed sensitive to the fourth moment of the entries at the critical scale ")#mi("{n^{-1/2}}")#text(".")

#text("One curious feature of the analysis is how differently the ")#emph[#text("median")]#text(" and the ")#emph[#text("mean")]#text(" of the eigenvalue ")#mi("{\\lambda_i(M_n)}")#text(" react to the available technology. To control the global behaviour of the eigenvalues (after averaging in ")#mi("{i}")#text("), it is much more convenient to use the mean, and we have very precise control on global averages of these means thanks to the moment method. But to control local behaviour, it is the median which is much better controlled. For instance, we can localise the median of ")#mi("{\\lambda_i(M_n)}")#text(" to an interval of size ")#mi("{O(n^{-1/2+\\epsilon})}")#text(", but can only localise the mean to a much larger interval of size ")#mi("{O(n^{-c})}")#text(". Ultimately, this is because with our current technology there is a possible exceptional event of probability as large as ")#mi("{O(n^{-c})}")#text(" for which all eigenvalues could deviate as far as ")#mi("{O(n^\\epsilon)}")#text(" from their expected location, instead of their typical deviation of ")#mi("{O(n^{-1/2})}")#text(". The reason for this is technical, coming from the fact that the four moment theorem method breaks down when two eigenvalues are very close together (less than ")#mi("{n^{-c}}")#text(" times the average eigenvalue spacing), and so one has to cut out this event, which occurs with a probability of the shape ")#mi("{O(n^{-c})}")#text(". It may be possible to improve the four moment theorem proof to be less sensitive to eigenvalue near-collisions, in which case the above bounds are likely to improve.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/#comment-44956")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("One very minor comment on the paper: you list reference [2] (the Anderson-Guionnet-Zeitouni book) as “to be published”, but I already have a published copy on my bookshelf.")

#text("And a related question: you refer to that book for detailed discussion of the representation of the number of GUE eigenvalues in an interval as a sum of independent random variables. Can you point me to the relevant section?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/#comment-44958")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("Ah, I was not aware that the book has now been published, thanks!")

#text("On the web copy of the book at")

#link("http://www.math.umn.edu/~zeitouni/technion/cupbook.pdf")[#text("Click to access cupbook.pdf")]

#text("the relevant discussion is in Section 4.2, particularly the material near Corollary 4.2.24. One can get the desired concentration of measure result from this corollary and the Hoeffding inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/#comment-44959")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("Thanks! The numbering here appears to be the same in the published version.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/05/18/random-matrices-localization-of-the-eigenvalues-and-the-necessity-of-four-moments/#comment-44965")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("Prof. Tao")#linebreak()#text(" I am actually wondering if you and Prof. Vu are planning to write a book on the topic “random matrices”. I was pretty enjoying your book additive combinatorics. I personally like your writing styles along with Vu. By any chances, if you will publish a book on Random Matrices, I will definitely get one copy.")
]
