// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/
// Converted to Typst by tao2typ: "2026-10-14T16:39:34.229595+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Recommendations of the Summit on PhD Math Education in the Age of AI", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Recommendations of the Summit on PhD Math Education in the Age of AI")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")[#text("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.northwestern.edu/people/faculty/bryna-kra.html")[#text("Bryna Kra")]#text(" and ")#link("https://oden.utexas.edu/people/directory/rachel--ward/")[#text("Rachel Ward")]#text(". -T.]")]

#text("The ")#link("https://cmsa.fas.harvard.edu/aimathphd_summit/")[#text("Summit on PhD Math Education in the Age of AI")]#text(" was held September 17–18, 2026, jointly hosted by the Harvard Department of Mathematics and the Center of Mathematical Sciences and Applications (CMSA). It brought together twenty-four senior mathematicians from across the discipline, along with several current PhD students and postdocs, to examine which aspects of the mathematics PhD need rethinking as AI reshapes thinking-based work.")

#link("https://cmsa.fas.harvard.edu/media/2026/09/Summit-on-PhD-Math-Education-in-the-Age-of-AI.pdf")[#text("This document")]#text(" is a first draft of our recommendations; we expect to refine our recommendations over the coming months according to changing landscapes and your feedback. We encourage feedback in the form of comments on this post, or by sending email to ")#link("mailto:education-summit@cmsa.fas.harvard.edu")[#text("education-summit@cmsa.fas.harvard.edu")]#text(".")

#text("To graduate students and early-career mathematicians: We know this uncertainty is weighing heavily on you as you plan your next steps. Your concerns matter, and we want to hear them. We are gathering information, keeping communication open, and working to support your opportunities and your future in mathematics.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Love recommendation 3. Now I no longer need to be telling that if you are using homework to evaluate individual work, you are using homework wrong.")

#text("There is an interesting possible extension of “assessment should be based on in-person written or oral assessments” to the jobs in the academic world. Potentially, this can move from using publications, and move to using contests. Want a position? OK, we look at publications a bit, but the shortlist of candidates come in person for a week to be grilled in problem solving skills and teaching.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696371")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Teaching abilities should become more important than they are today. And in smaller universities, if using an LLM becomes more expensive, it may be required to have some (almost) teaching-only professorships, so that funding can concentrate to the research professors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696432")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("But the teaching profs will also need skills in AI-use – as AI-use will ahve to be trained in class and in exercise groups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("AI use is a trivial activity which needs no training. Indeed, AI uses AI better than people do. Just prompt it to give you the right prompt!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Wouldn’t it mean that hiring will be based on “convincing”? This would be enough to scare many people away from academia (and math). One may look at humanities departments to see how it goes?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Pleasantly surprised, especially around the privacy part. It is heartening to see that the mathematics community understand how these vendors operate, and the value of their guarantees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ed2c4277a93097ab50d9c470af512717c44dcec79799824d02a7a66f4c96f5c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hume Chang")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696353")[#strong[#text("Hume Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("When would Harvard Math drop the requirement of second language in their Ph.D. curriculum? It’s a total waste of time given LLM’s translation capability. I’d rather learn some Japanese instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Recommendation 6(iii) makes no sense whatsoever. If the material is public, maybe it has already been involved in the training of the model.")

#text("It is an unnecessary burden, asking for permission on public material, if one is in an exploratory phase of research. Even if the research yields results, one does not ask for permission when reading a paper. What is ethical is including it in the references.")

#text("Non public material, in that case the topic of AI is irrelevant. It is ethical to have explicit permission for whatever use.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696368")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I agree. I enter public research material into AI at the rate of several papers a day in the course of my ordinary work. I am not a mathematician (although I have first-class honours in Pure Mathematics), but it would be a similarly unworkable burden if I had to ask permission for every paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696376")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I assume this recommendation 6 (iii) is meant only to apply to material within a collaboration, e.g. the problem at hand, ideas people have thrown out in meetings, chats, etc. And read like that it seems entirely reasonable. The whole document seems very useful as a reference for discussions on this issue, which are going to be happening in many places over the next few weeks (certainly here). Thanks to the authors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("That also has nothing to do with AI. It applies regardless of the medium.")

#text("Just follow your own examples with AI out of the picture. One hears an idea during a meeting, goes back to the office and thinks about possible applications. Assuming it yielded something and publication comes out of it, then is when the origin of the idea is given as a reference. Or if one goes to think on the idea with the person, then they become a collaborator. There is no explicit consent required before the act of thinking alone about the uses of an idea.")

#text("There is no fundamental difference between starting to think about an idea and feeding it to AI as part of a prompt. Both are data crunching, and both can end up not producing anything useful. Asking for consent for the latter is inconsistent and it is an obstruction on the early stages of research, when it hasn’t produced anything.")

#text("That point 6(iii) is clearly reactionary, and inspired on the potential use of non-public data that might happened during the Navier-Stokes events, and on the general objections that some people have on using for training everything under the sun, including non-public data. But key there is “non-public” and its ethics are general, unrelated to AI use. 6(iii) is just badly written.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Excellent post! Probably the most concrete statements I have seen. Some suggestions.")

#enum(start: 1, 
[#text("For self consistency, the recommendations should include an AI use disclosure statement.")],
[#text("I think the rule about putting work into an AI should be strengthened. Collaborations should involve ongoing discussions about appropriate AI use, and all AI use should be disclosed to collaborators. This avoids the situation where one collaborator intends to work by hand, while another puts the problem into an LLM and generates an answer.")],
[#text("Advisors should disclose their AI use to students, especially whether they are using AI to write recommendations. A student should be able to opt out of this.")],
[#text("Departments should not use AI to evaluate graduate students or faculty applications.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Thanks for sharing this. I’m glad to see these questions getting serious attention.")

#text("I recently wrote about Graduate Mathematics in the Age of AI ")#link("https://arxiv.org/abs/2609.22891")[#text("https://arxiv.org/abs/2609.22891")]#text(".")

#text("I think AI’s capabilities in mathematics call for major changes to how we train, advise, and assess PhD students, while making good use of AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696408")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("In principle I like the 8-page document. One caveat: in my eyes it stresses too much on ")#strong[#text("communication")]#text(". For me personally it would be fine, because I am more of a communicator than a prover. But there were and are and also will be mathematicians who are not good communicators, but who are strong mathematicians (even in the world of AI tools).")

#text("One example: Bernd Fischer, one of the hunters for large sporadic groups in the 70’s and 80’s. One day he gave a presentation on the baby monster which he had identified in many night sessions in front of computer screens. The presentation was only for the Professor colleagues in Bielefeld. Next morning “we” asked our co-student Folker Mennicke, the son of math prof Jens Mennicke: “And what did your father tell about Fischer’s presentation.” “It was absolutely amazing. Nobody understood anything. But we all were fully impressed.”")

#text("Another example from my mathematical grandfather, Konrad Jacobs. He was an impressive teacher, had many good doctoral students; but mathematically in research he was average. When Ornstein achieved his famous result in ergodic theory, Jacobs toured the European Math institutes and gave fine presentations on Ornstein’s proof.")

#text("Ingo Althöfer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Of course text is irrelevant now and oral exams are a must. An editor of a top journal asked ")#strong[#text("authors to explain their own papers")]#text(". Things did not go well.")

#link("https://medium.com/@TmlrOrg/asking-authors-about-their-own-papers-3d2e04e5dee0")[#text("https://medium.com/@TmlrOrg/asking-authors-about-their-own-papers-3d2e04e5dee0")]

#text("This is the sorry state with AI today.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("This whole battle is mostly originating from these four reasons")

#enum(start: 1, 
[#text("Now doing research by one own’s mind IS SAME as just getting work done through Ai models and be able to explain well.")],
[#text("The one who has better ai Models needs only to know and understand and communicate well. The heavy thinking can be avoided here and transferred for the Models.")],
[#text("How are you going to battle out the ethical issue of ai disclosure. No way to check it.")],
[#text("How would one know the work done by someone is not already doable with just one prompt from upcoming ultra powerful models.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696437")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I feel that this is an excellent approach; reminiscent of classical approaches in centuries past.")

#text("If one can engage fluently on topics that combine multiple disciplines, while at the same time maintaining global cohesion/coherence, it greatly improves the overall ability of professors/mentors, to quantify/qualify the abilities/capabilities of students/doctoral candidates.")

#text("Just my two cents!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/#comment-696477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("This is not exactly true: being able to read across multiple disciplines (areas in math) does necessarily mean being able to do mathematical work. The essence of doctoral study is to acquire mastery/ability to apply the (technical) methods of a specialty. This can be achieved only by doing specialized technical work. If this cannot be enforced, then math PhD will basically be a decoration of M.Sc. (eventually causing the extinction of working mathematicians).")
]
