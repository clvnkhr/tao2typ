// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/
// Converted to Typst by tao2typ: "2026-10-14T09:04:51.146398+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Dyson and Airy kernels of GUE via semiclassical analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Dyson and Airy kernels of GUE via semiclassical analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/")[#text("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{n}")#text(" be a large integer, and let ")#mi("{M_n}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), i.e. the random Hermitian matrix with probability distribution")

#align(center)[#tao-fit-display[#mitex("C_n e^{-\\text{tr}(M_n^2)/2} dM_n")]]

#text("where ")#mi("{dM_n}")#text(" is a Haar measure on Hermitian matrices and ")#mi("{C_n}")#text(" is the normalisation constant required to make the distribution of unit mass. The eigenvalues ")#mi("{\\lambda_1 < \\ldots < \\lambda_n}")#text(" of this matrix are then a coupled family of ")#mi("{n}")#text(" real random variables. For any ")#mi("{1 \\leq k \\leq n}")#text(", we can define the ")#emph[#mi("{k}")#text("-point correlation function")]#text(" ")#mi("{\\rho_k( x_1,\\ldots,x_k )}")#text(" to be the unique symmetric measure on ")#mi("{{\\bf R}^k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^k} F(x_1,\\ldots,x_k) \\rho_k(x_1,\\ldots,x_k) = {\\bf E} \\sum_{1 \\leq i_1 < \\ldots < i_k \\leq n} F( \\lambda_{i_1}, \\ldots, \\lambda_{i_k} ).")]]

#text("A standard computation (given for instance in ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("these lecture notes")]#text(" of mine) gives the ")#emph[#text("Ginebre formula")]

#align(center)[#tao-fit-display[#tao-math("\\rho_n(x_1,\\ldots,x_n) = C^{\\prime}_n (\\prod_{1 \\leq i < j \\leq n} \\left|x_i-x_j\\right|^2) e^{-\\sum_{j=1}^n \\left|x_j\\right|^2/2}.", block: true)]]

#text("for the ")#mi("{n}")#text("-point correlation function, where ")#mi("{C^{\\prime}_n}")#text(" is another normalisation constant. Using Vandermonde determinants, one can rewrite this expression in determinantal form as")

#align(center)[#tao-fit-display[#mitex("\\rho_n(x_1,\\ldots,x_n) = C^{\\prime\\prime}_n \\det(K_n(x_i,x_j))_{1 \\leq i, j \\leq n}")]]

#text("where the kernel ")#mi("{K_n}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("K_n(x,y) := \\sum_{k=0}^{n-1} \\phi_k(x) \\phi_k(y)")]]

#text("where ")#mi("{\\phi_k(x) := P_k(x) e^{-x^2/4}}")#text(" and ")#mi("{P_0, P_1, \\ldots}")#text(" are the (")#mi("{L^2}")#text("-normalised) ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomials")]#text(" (thus the ")#mi("{\\phi_k}")#text(" are an orthonormal family, with each ")#mi("{P_k}")#text(" being a polynomial of degree ")#mi("{k}")#text("). Integrating out one or more of the variables, one is led to the ")#emph[#text("Gaudin-Mehta formula")]#text(" ")#metadata(none) <tao-ff5d78e904165e4d4d70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho_k(x_1,\\ldots,x_k) = \\det(K_n(x_i,x_j))_{1 \\leq i, j \\leq k}.")]]

#text("(In particular, the normalisation constant ")#mi("{C^{\\prime\\prime}_n}")#text(" in the previous formula turns out to simply be equal to ")#mi("{1}")#text(".) Again, see ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("these lecture notes")]#text(" for details.")

#text("The functions ")#mi("{\\phi_k(x)}")#text(" can be viewed as an orthonormal basis of eigenfunctions for the ")#emph[#text("harmonic oscillator operator")]

#align(center)[#tao-fit-display[#mitex("L \\phi := (-\\frac{d^2}{dx^2} + \\frac{x^2}{4})\\phi;")]]

#text("indeed it is a classical fact that")

#align(center)[#tao-fit-display[#mitex("L \\phi_k = (k + \\frac{1}{2}) \\phi_k.")]]

#text("As such, the kernel ")#mi("{K_n}")#text(" can be viewed as the integral kernel of the spectral projection operator ")#mi("{1_{(-\\infty,n+\\frac{1}{2}]}(L)}")#text(".")

#text("From ")#link(<tao-ff5d78e904165e4d4d70>)[#text("(1)")]#text(" we see that the fine-scale structure of the eigenvalues of GUE are controlled by the asymptotics of ")#mi("{K_n}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". The two main asymptotics of interest are given by the following lemmas:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Asymptotics of ")#mi("{K_n}")#text(" in the bulk)")]#text(" ")#metadata(none) <tao-bf8348b4107daaacf154>#text(" Let ")#mi("{x_0 \\in (-2,2)}")#text(", and let ")#mi("{\\rho_{sc}(x_0) := \\frac{1}{2\\pi} (4-x_0^2)^{1/2}_+}")#text(" be the semicircular law density at ")#mi("{x_0}")#text(". Then, we have")

#align(center)[#tao-fit-display[#mitex("K_n( x_0 \\sqrt{n} + \\frac{y}{\\sqrt{n} \\rho_{sc}(x_0)}, x_0 \\sqrt{n} + \\frac{z}{\\sqrt{n} \\rho_{sc}(x_0)} )")]]

#metadata(none) <tao-60fc91326964f086b602>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\rightarrow \\frac{\\sin(\\pi(y-z))}{\\pi(y-z)}")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{y,z \\in {\\bf R}}")#text(" (removing the singularity at ")#mi("{y=z}")#text(" in the usual manner).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Asymptotics of ")#mi("{K_n}")#text(" at the edge)")]#text(" ")#metadata(none) <tao-41164471862a006261fe>#text(" We have")

#align(center)[#tao-fit-display[#mitex("K_n( 2\\sqrt{n} + \\frac{y}{n^{1/6}}, 2\\sqrt{n} + \\frac{z}{n^{1/6}} )")]]

#metadata(none) <tao-14072c7328dd61dc7438>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\rightarrow \\frac{Ai(y) Ai^{\\prime}(z) - Ai^{\\prime}(y) Ai(z)}{y-z}")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{y,z \\in {\\bf R}}")#text(", where ")#mi("{Ai}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Airy_function")[#text("Airy function")]

#align(center)[#tao-fit-display[#mitex("Ai(x) := \\frac{1}{\\pi} \\int_0^\\infty \\cos( \\frac{t^3}{3} + tx )\\ dt")]]

#text("and again removing the singularity at ")#mi("{y=z}")#text(" in the usual manner.")
]

#text("The proof of these asymptotics usually proceeds via computing the asymptotics of Hermite polynomials, together with the Christoffel-Darboux formula; this is for instance the approach taken in ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("the previous notes")]#text(". However, there is a slightly different approach that is closer in spirit to the methods of semi-classical analysis, which was briefly mentioned in the previous notes but not elaborated upon. For sake of completeness, I am recording some notes on this approach here, although to focus on the main ideas I will not be completely rigorous in the derivation (ignoring issues such as convegence of integrals or of operators, or (removable) singularities in kernels caused by zeroes in the denominator).")

#metadata(none) <tao-8478b35fce53b0976f75>

#heading(level: 1)[#strong[#text(" — 1. The bulk asymptotics — ")]]

#text("We begin with the bulk asymptotics, Lemma ")#link(<tao-bf8348b4107daaacf154>)[#text("1")]#text(". Fix ")#mi("{x_0}")#text(" in the bulk region ")#mi("{(-2,2)}")#text(". Applying the change of variables")

#align(center)[#tao-fit-display[#mitex("x = x_0 \\sqrt{n} + \\frac{y}{\\sqrt{n} \\rho_{sc}(x_0)}")]]

#text("we see that the harmonic oscillator ")#mi("{L}")#text(" becomes")

#align(center)[#tao-fit-display[#mitex("- n \\rho_{sc}(x_0)^2 \\frac{d^2}{dy^2} + \\frac{1}{4} (x_0 \\sqrt{n} + \\frac{y}{\\sqrt{n} \\rho_{sc}(x_0)})^2")]]

#text("Since ")#mi("{K_n}")#text(" is the integral kernel of the spectral projection to the region ")#mi("{L \\leq n+\\frac{1}{2}}")#text(", we conclude that the left-hand side of ")#link(<tao-60fc91326964f086b602>)[#text("(2)")]#text(" (as a function of ")#mi("{y,z}")#text(") is the integral kernel of the spectral projection to the region")

#align(center)[#tao-fit-display[#mitex("- n \\rho_{sc}(x_0)^2 \\frac{d^2}{dy^2} + \\frac{1}{4} (x_0 \\sqrt{n} + \\frac{y}{\\sqrt{n} \\rho_{sc}(x_0)})^2 \\leq n + \\frac{1}{2}.")]]

#text("Isolating out the top order terms in ")#mi("{n}")#text(", we can rearrange this as")

#align(center)[#tao-fit-display[#mitex("-\\frac{d^2}{dy^2} \\leq \\pi^2 + o(1).")]]

#text("Thus, in the limit ")#mi("{n \\rightarrow \\infty}")#text(", we expect (heuristically, at least) that the left-hand side of ")#link(<tao-60fc91326964f086b602>)[#text("(2)")]#text(" to converge as ")#mi("{n \\rightarrow \\infty}")#text(" to the integral kernel of the spectral projection to the region")

#align(center)[#tao-fit-display[#mitex("-\\frac{d^2}{dy^2} \\leq \\pi^2.")]]

#text("Introducing the Fourier dual variable ")#mi("{\\xi}")#text(" to ")#mi("{y}")#text(", as manifested by the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\int_{\\bf R} e^{-2\\pi i \\xi y} f(y)\\ dy")]]

#text("and its inverse")

#align(center)[#tao-fit-display[#mitex("\\check F(y) = \\int_{\\bf R} e^{2\\pi i \\xi y} F(\\xi)\\ d\\xi,")]]

#text("then we (heuristically) have ")#mi("{\\frac{d}{dy} = 2\\pi i \\xi}")#text(", and so we are now projecting to the region ")#metadata(none) <tao-20a64d703ec63db529cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\xi\\right|^2 \\leq 1/4,", block: true)]]

#text("i.e. we are restricting the Fourier variable to the interval ")#mi("{[-1/2,1/2]}")#text(". Back in physical space, the associated projection ")#mi("{P}")#text(" thus takes the form")

#tao-aligned(keep: true)[


#tao-math("P f(y)  & = \\int_{[-1/2,1/2]} e^{2\\pi i \\xi y} \\hat f(\\xi)\\ d\\xi", block: true)



#tao-math(" & = \\int_{\\bf R} \\int_{[-1/2,1/2]} e^{2\\pi i \\xi y} e^{-2\\pi i \\xi z}\\ d\\xi f(z)\\ dz", block: true)



#tao-math(" & = \\int_{\\bf R} \\frac{\\sin(\\pi(y-z))}{y-z} f(z)\\ dz", block: true)
]

#text("and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" From a semiclassical perspective, the original spectral projection ")#mi("{L \\leq n+\\frac{1}{2}}")#text(" can be expressed in phase space (using the dual frequency variable ")#mi("{\\eta}")#text(" to ")#mi("{x}")#text(") as the ellipse ")#metadata(none) <tao-c613c7687a303c38a020>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("4 \\pi^2 \\eta^2 + \\frac{x^2}{4} \\leq n+\\frac{1}{2}")]]

#text("which after the indicated change of variables becomes the elongated ellipse")

#align(center)[#tao-fit-display[#mitex("\\xi^2 + \\frac{1}{2n \\rho_{sc}(x_0)(4-x_0^2)} y + \\frac{1}{4n^2 \\rho_{sc}(x_0)^2 (4-x_0^2)} y^2")]]

#align(center)[#tao-fit-display[#mitex("\\leq \\frac{1}{4} + \\frac{1}{2n (4-x_0^2)}")]]

#text("which converges (in some suitably weak sense) to the strip ")#link(<tao-20a64d703ec63db529cd>)[#text("(4)")]#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. The edge asymptotics — ")]]

#text("A similar (heuristic) argument gives the edge asymptotics, Lemma ")#link(<tao-41164471862a006261fe>)[#text("2")]#text(". Starting with the change of variables")

#align(center)[#tao-fit-display[#mitex("x = 2 \\sqrt{n} + \\frac{y}{n^{1/6}}")]]

#text("the harmonic oscillator ")#mi("{L}")#text(" now becomes")

#align(center)[#tao-fit-display[#mitex("- n^{1/3} \\frac{d^2}{dy^2} + \\frac{1}{4} (2 \\sqrt{n} + \\frac{y}{n^{1/6}})^2.")]]

#text("Thus, the left-hand side of ")#link(<tao-14072c7328dd61dc7438>)[#text("(3)")]#text(" becomes the kernel of the spectral projection to the region")

#align(center)[#tao-fit-display[#mitex("- n^{1/3} \\frac{d^2}{dy^2} + \\frac{1}{4} (2 \\sqrt{n} + \\frac{y}{n^{1/6}})^2 \\leq n + \\frac{1}{2}.")]]

#text("Expanding out, computing all terms of size ")#mi("{n^{1/3}}")#text(" or larger, and rearranging, this (heuristically) becomes")

#align(center)[#tao-fit-display[#mitex("- \\frac{d^2}{dy^2} + y \\leq o(1)")]]

#text("and so, heuristically at least, we expect ")#link(<tao-14072c7328dd61dc7438>)[#text("(3)")]#text(" to converge to the kernel of the projection to the region ")#metadata(none) <tao-49c6723515ed85bfc723>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("- \\frac{d^2}{dy^2} + y \\leq 0.")]]

#text("To compute this, we again pass to the Fourier variable ")#mi("{\\xi}")#text(", converting the above to")

#align(center)[#tao-fit-display[#mitex("4 \\pi^2 \\xi^2 + \\frac{1}{2\\pi i} \\frac{d}{d\\xi} \\leq 0")]]

#text("using the usual Fourier-analytic correspondences between multiplication and differentiation. If we then use the integrating factor transformation")

#align(center)[#tao-fit-display[#mitex("F(\\xi) \\mapsto e^{8 \\pi^3 i \\xi^3 / 3} F(\\xi)")]]

#text("we can convert the above region to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\frac{d}{d\\xi} \\leq 0")]]

#text("which on undoing the Fourier transformation becomes")

#align(center)[#tao-fit-display[#mitex("y \\leq 0,")]]

#text("and the spectral projection operation for this is simply the spatial multiplier ")#mi("{1_{(-\\infty,0]}}")#text(". Thus, informally at least, we see that the spectral projection ")#mi("{P}")#text(" to the region ")#link(<tao-49c6723515ed85bfc723>)[#text("(6)")]#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("P = M^{-1} 1_{(-\\infty,0]} M")]]

#text("where the Fourier multiplier ")#mi("{M}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\widehat{Mf}(\\xi) := e^{8 \\pi^3 i \\xi^3 / 3} \\hat f(\\xi).")]]

#text("In other words (ignoring issues about convergence of the integrals),")

#tao-aligned(keep: true)[


#tao-math("Mf(y)  & = \\int_{\\bf R} (\\int_{\\bf R} e^{2\\pi i y \\xi} e^{8 \\pi^3 i \\xi^3 / 3} e^{-2\\pi i z \\xi}\\ d\\xi) f(z)\\ dz", block: true)



#tao-math(" & = 2 \\int_{\\bf R} (\\int_0^\\infty \\cos( 2\\pi (y-z) \\xi + 8 \\pi^3 \\xi^3 / 3 )\\ d\\xi) f(z)\\ dz", block: true)



#tao-math(" & = \\frac{1}{\\pi} \\int_{\\bf R} (\\int_0^\\infty \\cos( t (y-z) + t^3 / 3 )\\ dt) f(z)\\ dz", block: true)



#tao-math(" & = \\int_{\\bf R} Ai(y-z) f(z)\\ dz", block: true)
]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("M^{-1} f(z) = \\int_{\\bf R} Ai(y-z) f(y)\\ dy")]]

#text("(this reflects the unitary nature of ")#mi("{M}")#text("). We thus see (formally, at least) that")

#align(center)[#tao-fit-display[#mitex("P f(y) = \\int_{\\bf R} (\\int_{(-\\infty,0]} Ai(y-w) Ai(z-w)\\ dw) f(z)\\ dz.")]]

#text("To simplify this expression we perform some computations closely related to the ones above. From the Fourier representation")

#tao-aligned(keep: true)[


#tao-math("Ai(y)  & = \\frac{1}{\\pi} \\int_0^\\infty \\cos(ty + t^3/3)\\ dt", block: true)



#tao-math(" & = \\int_{\\bf R} e^{2\\pi i y \\xi} e^{8 \\pi i \\xi^3/3}\\ d\\xi", block: true)
]

#text("we see that")

#align(center)[#tao-fit-display[#mitex("\\widehat{Ai}(\\xi) = e^{8 \\pi^3 i \\xi^3/3}")]]

#text("which means that")

#align(center)[#tao-fit-display[#mitex("(4 \\pi^2 \\xi^2 + \\frac{1}{2\\pi i} \\frac{d}{d\\xi}) \\widehat{Ai}(\\xi) = 0")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("(- \\frac{d^2}{dy^2} + y) Ai(y) = 0,")]]

#text("thus ")#mi("{Ai}")#text(" obeys the ")#emph[#text("Airy equation")]

#align(center)[#tao-fit-display[#mitex("Ai^{\\prime\\prime}(y) = y Ai(y).")]]

#text("Using this, one soon computes that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dw} \\frac{Ai(y-w) Ai^{\\prime}(z-w) - Ai^{\\prime}(y-w) Ai(z-w)}{y-z} = Ai(y-w) Ai(z-w).")]]

#text("Also, stationary phase asymptotics tell us that ")#mi("{Ai(y)}")#text(" decays exponentially fast as ")#mi("{y \\rightarrow +\\infty}")#text(", and hence ")#mi("{Ai(y-w)}")#text(" decays exponentially fast as ")#mi("{w \\rightarrow -\\infty}")#text(" for fixed ")#mi("{y}")#text("; similarly for ")#mi("{Ai^{\\prime}(z-w), Ai^{\\prime}(y-w), Ai(z-w)}")#text(". From the fundamental theorem of calculus, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{(-\\infty,0]} Ai(y-w) Ai(z-w)\\ dw = \\frac{Ai(y) Ai^{\\prime}(z) - Ai^{\\prime}(y) Ai(z)}{y-z},")]]

#text("(this is a continuous analogue of the Christoffel-Darboux formula), and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" As in the bulk case, one can take a semi-classical analysis perspective and track what is going on in phase space. With the scaling we have selected, the ellipse ")#link(<tao-c613c7687a303c38a020>)[#text("(5)")]#text(" has become")

#align(center)[#tao-fit-display[#mitex("4 \\pi^2 n^{1/3} \\xi^2 + \\frac{(2\\sqrt{n} + y/n^{1/6})^2}{4} \\leq n+\\frac{1}{2},")]]

#text("which we can rearrange as the eccentric ellipse")

#align(center)[#tao-fit-display[#mitex("4\\pi^2 \\xi^2 + y \\leq \\frac{1}{2n^{1/3}} - \\frac{y^2}{4 n^{2/3}}")]]

#text("which is converging as ")#mi("{n \\rightarrow \\infty}")#text(" to the parabolic region")

#align(center)[#tao-fit-display[#mitex("4\\pi^2 \\xi^2 + y \\leq 0")]]

#text("which can then be shifted to the half-plane ")#mi("{y \\leq 0}")#text(" by the parabolic shear transformation ")#mi("{(y,\\xi) \\mapsto (y+4\\pi^2\\xi^2,\\xi)}")#text(", which is the canonical relation of the Fourier multiplier ")#mi("{M}")#text(". (The rapid decay of the kernel ")#mi("{Ai}")#text(" of ")#mi("{M}")#text(" at ")#mi("{+\\infty}")#text(" is then reflected in the fact that this transformation only shears to the right and not the left.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Presumably one should also be able to apply the same heuristics to other invariant ensembles, such as those given by probability distributions of the form")

#align(center)[#tao-fit-display[#mitex("C_n e^{-\\text{tr}(P(M_n))} dM_n")]]

#text("for some potential function ")#mi("{P}")#text(". Certainly one can soon get to an orthogonal polynomial formulation of the determinantal kernel for such ensembles, but I do not know if the projection operators for such kernels can be viewed as spectral projections to a phase space region as was the case for GUE. But if one could do this, this would provide a heuristic explanation as to the universality phenomenon for such ensembles, as Taylor expansion shows that all (reasonably smooth) regions of phase space converge to universal limits (such as a strip or paraboloid) after rescaling around either a non-critical point or a critical point of the region with the appropriate normalisation.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ce696ef79e2ba743a9916d4fab3a3ce0b2f3e74d431c9ee0d63f3ae0356622-364c90c675d584f7e6f91e97cc231db2864737b215a2c843bb8b9a385c285d10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonid Petrov")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-47818")[#strong[#text("Leonid Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("In fact, the same approach is possible for random partitions. Here one obtains difference operators instead of differential ones. E.g., this explained in this paper by G. Olshanski: arXiv:0810.3751.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a017b8f2b0294c9e3e23cf4f0944b7c908e9c85d8e1b1f3f3151b53eb6aa873a-eea09db74ebcbccbf776df340caf60319e7fead2e4d59eb7d7b99a513e87582d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Instalaciones Deportivas")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-47841")[#strong[#text("Instalaciones Deportivas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("shouldn`t it be different for random partitions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ce696ef79e2ba743a9916d4fab3a3ce0b2f3e74d431c9ee0d63f3ae0356622-364c90c675d584f7e6f91e97cc231db2864737b215a2c843bb8b9a385c285d10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonid Petrov")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-47842")[#strong[#text("Leonid Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("Well, what exactly do you mean?")#linebreak()#text(" I meant that for certain ensembles of random partitions the correlation kernels are spectral projections for certain difference operators. This heuristics (carried out rigorously in that paper) allows to obtain bulk and edge asymptotics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2010")])]

#text("Dear Prof. Tao,")

#text("in lemma 2, how can we show that the integral exists in the definition of Airy function?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("A single integration by parts will convert the improper integral into an absolutely convergent one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("Do we need to use complex analysis or just ")#mi("u=\\cos(\\frac{t^3}{3}+tx)")#text(" and ")#mi("dv=dt")#text("? I am still having problem in that case…")

#text("thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("Use ")#mi("v = \\sin(\\frac{t^3}{3} + tx)")#text(" and ")#mi("u = \\frac{1}{t^2 + x}")#text(". The basic point is that ")#mi("\\frac{1}{t^2+x} \\sin(\\frac{t^3}{3}+tx)")#text(" is an approximate antiderivative of ")#mi("\\cos(\\frac{t^3}{3}+tx)")#text(", in analogy with the fact that ")#mi("\\frac{1}{k} \\sin(kx)")#text(" is an antiderivative of ")#mi("\\cos(kx)")#text(".")

#text("More generally, when using integration by parts to deal with a highly oscillatory term, one wants to “integrate” the oscillatory component and differentiate the more slowly varying components in order to fully exploit cancellation. In some cases this means that one has to multiply and divide by a chain rule factor in order to easily obtain the required integration.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("Thanks Prof. Tao. you are great. I see it now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-49860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")])]

#text("Dear Prof. Tao,")

#text("Here when use integration by parts, do we assume that the integration is improper Riemann integral? is integration by parts true for Lebesque integral for finite or infinite domains?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-49871")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2011")])]

#text("There are many rigorous justifications of the integration by parts formula under a variety of hypotheses; there is no one “best” formulation here, but rather a family of such formulations. It is not just a matter of choosing the nature of the integral and selecting the domain; some regularity and decay conditions on the functions in the formula must also be assumed (e.g. on compact smooth domains, continuous differentiability would suffice. In such cases there is no distinction between the Lebesgue and Riemann integral). Some other examples of integration by parts theorems are given in ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the second formula the summation is over i_1 < i_2 < .., but I guess they would appear as subscripts for the lambda's as well. Also how should one think about the ordered eigenvalue distribution? I try to form an analogy with a set of n uniform iid points on the interval. There one gets for ordered X_i's, P(X_1 = dy_1, \\ldots, X_k = dy_k) = dy_1 .. dy_k, and unordered X_i's P(X_1 =dy_1, \\ldots, X_k = dy_k) = n!/(n-k)! dy_1 .. dy_k, since the latter random vector lives on the simplex {x_1 < x_2 < .. < x_k}. I guess my question is does the notion of ordered probability distribution for eigenvalues have a natural interpretation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2010")])]

#text("Thanks for the correction!")

#text("One can certainly view the ordered eigenvalues as a probability distribution on the simplex ")#mi("\\{ (x_1,\\ldots,x_n) \\in {\\bf R}^n: x_1 \\leq \\ldots \\leq x_n \\}")#text("; the density function of this distribution is ")#mi("n! \\rho(x_1,\\ldots,x_n)")#text(". The notion of a k-point correlation function, though, is best interpreted using the unordered formalism. (In some sense, the eigenvalues behave a little bit like quantum-mechanical bosons, in that the mathematics is a bit simpler if one views them as interchangable with each other, though the analogy is not perfect.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4df46ae82110da63185b49b4f0402479484431fa9641cc7179d38623c45bba48-ed7fea971c19aa6d9cac479b5b896072dbdbd290e9114bcb26e73136a46c880d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Monnier")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-48999")[#strong[#text("Samuel Monnier")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2010")])]

#text("I think there is a typo in the Gaudin-Mehta formula (1). The indices i and j on the right-hand side should be bounded above by k instead of n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The mesoscopic structure of GUE eigenvalues « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-49145")[#strong[#text("The mesoscopic structure of GUE eigenvalues « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("[…] At the other extreme, at the microscopic scale of the mean eigenvalue spacing (which is comparable to in the bulk, but can be as large as at the edge), the eigenvalues are asymptotically distributed with respect to a special determinantal point process, namely the Dyson sine process in the bulk (and the Airy process on the edge), as discussed in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Topics in random matrix theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/#comment-50427")[#strong[#text("Topics in random matrix theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2011")])]

#text("[…] was based primarily on my graduate course in the topic, though it also contains material from some additional posts related to random matrices on the blog. It is available online here. As usual, comments […]")
]
