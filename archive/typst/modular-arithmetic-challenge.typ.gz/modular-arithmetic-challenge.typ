// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/
// Converted to Typst by tao2typ: "2026-10-14T11:15:55.637296+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Modular Arithmetic Challenge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Modular Arithmetic Challenge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 June 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/")[#text("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A couple months ago, ")#link("https://damek.github.io/")[#text("Damek Davis")]#text(" and I launched ")#link("https://competition.sair.foundation/competitions/mathematics-distillation-challenge-equational-theories-stage1/overview")[#text("the first mathematical challenge")]#text(" at the ")#link("https://sair.foundation/")[#text("SAIR Foundation")]#text(", aimed at “distilling” the ability to solve 22 million problems in universal algebra into a condensed form. Stage one of that challenge has now been completed, with several effective “cheat sheets” generated to guess the truth or falsity of these problems to reasonable accuracy; the leaderboard for that stage, with their winning cheatsheets ")#link("https://competition.sair.foundation/leaderboard/mathematics-distillation-challenge-equational-theories-stage1")[#text("can be found here")]#text(". Stage two of that challenge, in which the competitors now have access to Python code as well as modest LLMs, and now need to generate Lean proofs or disproofs rather than just true-false answers, is currently underway.")

#text("With Alberto Alfarano, ")#link("https://f-charton.github.io/about/")[#text("François Charton")]#text(", Yongzheng Jia, ")#link("https://math.washington.edu/people/kristin-lauter")[#text("Kristin Lauter")]#text(", ")#link("https://cathyliyuanchen.github.io/")[#text("Cathy Li")]#text(", and ")#link("https://www.emilywenger.com/")[#text("Emily Wenger")]#text(", are launching a ")#link("https://competition.sair.foundation/competitions/modular-arithmetic-challenge/overview")[#text("second challenge at SAIR")]#text(", this time focused on seeing how efficiently neural networks can execute simple modular arithmetic operations. For this challenge we are focusing on the simple operation of modular multiplication: taking a prime modulus ")#mi("{p}")#text(" (up to about a thousand digits long) and two integers ")#mi("{a}")#text(" and ")#mi("{b}")#text(" between ")#mi("{0}")#text(" and ")#mi("{p-1}")#text(", and computing the product ")#mi("{a \\cdot b \\pmod{p}}")#text(". This is of course a solved problem using traditional computation, being a single line of code in any modern programming language. But it has been a fascinating toy problem in which to explore the basic capabilities of neural networks.")

#text("For instance, this problem has revealed the mysterious phenomenon of “")#link("https://en.wikipedia.org/wiki/Grokking_(machine_learning)")[#text("grokking")]#text("“. When one tries to train a neural network on this problem for small sizes of inputs ")#mi("{a,b,p}")#text(", then initially one runs into the familiar problem of ")#link("https://en.wikipedia.org/wiki/Overfitting")[#text("overfitting")]#text(": the network learns to solve the problem for the training data too well, at the expense of performing well for held-out test data. However, if one continues training for sufficiently long periods of time, then the network can suddenly “grok” the problem and generalize surprisingly well to the test data. It appears that the neural network can suddenly “learn” powerful computational tricks, such as taking discrete logarithms, to find accurate and efficient ways to arrive at the correct answer.")

#link("https://competition.sair.foundation/competitions/modular-arithmetic-challenge/overview")[#text("This challenge")]#text(" is not about grokking, but instead about scaleability: we can create neural network models for modular multiplication that are extremely accurate for, say, 10-bit inputs, but they struggle at handling larger bit sizes. The competition is then simple: submit a neural network (with fixed weights) that can solve this task for larger input sizes with as high an accuracy as possible. Some pre-processing of the individual inputs ")#mi("{a}")#text(", ")#mi("{b}")#text(", ")#mi("{p}")#text(" is permitted (e.g., to convert these numbers into decimal or some other convenient representation), but other than that the main computation has to be neural in nature; one cannot simply run some Python code, for instance, to compute the multiplication. We are imposing limits on the size and allocated run time on the neural network, but otherwise we are deliberately being flexible in the architecture requirements, in order to encourage creative experimentation; in particular, we permit networks whose weights were arrived at by other means than the usual machine learning training process.")

#text("This is a relatively simple challenge to state, but we genuinely do not know what to expect from the competitor entries – is there a clever way to encode modular arithmetic for even quite large numbers into a medium size neural network, or is it going to be an exceptionally difficult task? Hopefully we will find out in a few months! Discussion of the ongoing challenge will take place on ")#link("https://zulip.sair.foundation/#narrow/channel/20-Modular-Arithmetic-Challenge")[#text("this Zulip")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Alexeev")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692835")[#strong[#text("Boris Alexeev")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("This challenge reminds me of ")#link("https://codegolf.stackexchange.com/questions/183036/can-a-neural-network-recognize-primes")[#text("https://codegolf.stackexchange.com/questions/183036/can-a-neural-network-recognize-primes")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("I do think discrete logarithm has an easy algorithm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692851")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Yes, we did discuss this as a possible “exploit” to the challenge; but for larger moduli (e.g., 1000 bits), we expect the computation of the discrete logarithm to be prohibitively expensive for the time budget allocated for competition submissions (which is to solve 1100 modular multiplication problems – each with a different modulus – in 5 minutes).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("here too smooth moduli failures may illuminate prime moduli failure")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692848")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("There are alternative models of neural networks which do not depend on threshold neurons and endlessly fiddling with weights.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692852")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("We decided to be permissive as to what counts as a “neural network” to encourage creative solutions to the challenge. It is theoretically possible that one might be able to hand-code an efficient arithmetic circuit into such a network that basically performs a traditional computation, in which case we have to carefully adjudicate whether such a submission would be in both the letter and the spirit of the competition, but we decided not to prohibit such edge cases, at least initially, as such an encoding might be independently interesting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692855")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("From the website “For a neural network, it is an open problem.”")

#text("It seems like a stretch to consider this an open problem? The rules are subject to interpretation of course, but “On the Turing Completeness of Modern Neural Network Architectures” ")#link("https://arxiv.org/abs/1901.03429")[#text("https://arxiv.org/abs/1901.03429")]#text(" would seem to prove it is possible, even if they didn’t apply it to this specific problem.")

#text("So although it is an interesting “engineering” project I don’t think I’d consider the problem open.")

#text("Or if that paper and previous papers doesn’t close the open problem, it would be useful for the website to explain why!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692864")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Fair enough; we should insert the word “efficiently” at the end of the basic question. We’ll get that changed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2026")])]

#text("Dr Tao, in your ")#link("https://arxiv.org/abs/1509.05422")[#text("paper")]#text(" you used the concentration of measure result for the uniform random variable ")#mi("Y_H")#text(", whereas we need the concentration of measure for the random variables ")#mi("Y_H|X_H=x")#text(" for each ")#mi("x")#text(". The independence condition for primes ")#mi("p")#text(" now seems to be nontrivial for each individual ")#mi("x")#text(". Can you explain this in slightly more detail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("It is true that the random variables ")#mi("Y_H | X_H = x")#text(" are no longer uniformly distributed, and so concentration of measure theorems cannot directly be applied to that variable. However, because of (3.14), we can still transfer concentration results from the uniform variable to the non-uniform variable, at the cost of a significantly worse bound: see Lemma 3.3.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-692871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("what would be better is discrete log modulus is smooth. We low there is an east algorithm. But may be nn does find something else which solves for smooth moduli in a different way in a probabilistic sense (say 2/3 success)which might illuminate the difficult prime moduli case through the 1/3 failures because 2/3 success is no fluke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("On the challenge website it says you get $a, b$ and $p$ as input and then need to output $a*b \\mod p$ as a list of base-$b$ digits. This seems very weird since $b$ can be 100s of (base-10) digits long according to the website. What kind of insanely long alphabet am I supposed to use to represent these base $b$ digits? Also it breaks the nice symmetry between $a$ and $b$. What is the reason for this strange requirement?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("Okay, reading further along the website I figured out that the $b$ in base-$b$ is supposed to be a different $b$, to be chosen by the contestant, than the $b$ given as input. That makes things a bit easier. But my initial confusion was real. Perhaps it is possible to change this and use two different letters?")

#emph[#text("[We have updated the website to disambiguate these quantities. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2026")])]

#text("Thanks! Also I didn’t intend to write this anonymous, but I somehow misunderstood the comment system")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/08/modular-arithmetic-challenge/#comment-693239")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("For a beautiful communication of the grokking going on with Modular arithmetic, see the Welch Labs youtube video")
]
