// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/
// Converted to Typst by tao2typ: "2026-10-14T15:18:12.341981+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this set of notes, we describe the basic analytic structure theory of ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(", by relating them to the simpler concept of a ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(". Roughly speaking, the Lie algebra encodes the “infinitesimal” structure of a Lie group, but is a simpler object, being a vector space rather than a nonlinear manifold. Nevertheless, thanks to the fundamental theorems of Lie, the Lie algebra can be used to reconstruct the Lie group (at a local level, at least), by means of the ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(". As such, the local theory of Lie groups is completely described (in principle, at least) by the theory of Lie algebras, which leads to a number of useful consequences, such as the following:")

#list(
[#text("(Local Lie implies Lie) A topological group ")#mi("{G}")#text(" is Lie (i.e. it is isomorphic to a Lie group) if and only if it is locally Lie (i.e. the group operations are smooth near the origin).")],
[#text("(Uniqueness of Lie structure) A topological group has at most one smooth structure on it that makes it Lie.")],
[#text("(Weak regularity implies strong regularity, I) Lie groups are automatically real analytic. (In fact one only needs a “local ")#mi("{C^{1,1}}")#text("” regularity on the group structure to obtain real analyticity.)")],
[#text("(Weak regularity implies strong regularity, II) A continuous homomorphism from one Lie group to another is automatically smooth (and real analytic).")]
)

#text("The connection between Lie groups and Lie algebras also highlights the role of ")#emph[#text("one-parameter subgroups")]#text(" of a topological group, which will play a central role in the solution of Hilbert’s fifth problem.")

#text("We note that there is also a very important ")#emph[#text("algebraic")]#text(" structure theory of Lie groups and Lie algebras, in which the Lie algebra is split into ")#link("http://en.wikipedia.org/wiki/Solvable_Lie_algebra")[#text("solvable")]#text(" and ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(" components, with the latter being decomposed further into ")#link("http://en.wikipedia.org/wiki/Simple_Lie_algebra")[#text("simple components")]#text(", which can then be completely classified using ")#link("http://en.wikipedia.org/wiki/Dynkin_diagram")[#text("Dynkin diagrams")]#text(". This classification is of fundamental importance in many areas of mathematics (e.g. representation theory, arithmetic geometry, and group theory), and many of the deeper facts about Lie groups and Lie algebras are proven via this classification (although in such cases it can be of interest to also find alternate proofs that avoid the classification). However, it turns out that we will not need this theory in this course, and so we will not discuss it further here (though it can of course be found in any graduate text on Lie groups and Lie algebras).")

#metadata(none) <tao-2b526279097560f7b2fb>

#heading(level: 1)[#strong[#text(" — 1. Local groups — ")]]

#text("The connection between Lie groups and Lie algebras will be ")#emph[#text("local")]#text(" in nature – the only portion of the Lie group that will be of importance will be the portion that is close to the group identity ")#mi("{1}")#text(". To formalise this locality, it is convenient to introduce the notion of a ")#emph[#text("local group")]#text(" and a ")#emph[#text("local Lie group")]#text(", which are local versions of the concept of a topological group and a Lie group respectively. We will only set up the barest bones of the theory of local groups here; a more detailed discussion may be found at ")#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("this previous blog post")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Local group)")]#text(" A ")#emph[#text("local topological group")]#text(" ")#mi("{G = (G, \\Omega, \\Lambda, 1, \\cdot, ()^{-1})}")#text(", or ")#emph[#text("local group")]#text(" for short, is a topological space ")#mi("{G}")#text(" equipped with an identity element ")#mi("{1 \\in G}")#text(", a partially defined but continuous multiplication operation ")#mi("{\\cdot: \\Omega \\rightarrow G}")#text(" for some domain ")#mi("{\\Omega \\subset G \\times G}")#text(", and a partially defined but continuous inversion operation ")#mi("{()^{-1}: \\Lambda \\rightarrow G}")#text(", where ")#mi("{\\Lambda \\subset G}")#text(", obeying the following axioms:")

#list(
[#text("(Local closure) ")#mi("{\\Omega}")#text(" is an open neighbourhood of ")#mi("{G \\times \\{1\\} \\cup \\{1\\} \\times G}")#text(", and ")#mi("{\\Lambda}")#text(" is an open neighbourhood of ")#mi("{1}")#text(".")],
[#text("(Local associativity) If ")#mi("{g, h, k \\in G}")#text(" are such that ")#mi("{(g \\cdot h) \\cdot k}")#text(" and ")#mi("{g \\cdot (h \\cdot k)}")#text(" are both well-defined in ")#mi("{G}")#text(", then they are equal. (Note however that it may be possible for one of these products to be defined but not the other.)")],
[#text("(Identity) For all ")#mi("{g \\in G}")#text(", ")#mi("{g \\cdot 1 = 1 \\cdot g = g}")#text(".")],
[#text("(Local inverse) If ")#mi("{g \\in G}")#text(" and ")#mi("{g^{-1}}")#text(" is well-defined in ")#mi("{G}")#text(", then ")#mi("{g \\cdot g^{-1} = g^{-1} \\cdot g = 1}")#text(". (In particular this, together with the other axioms, forces ")#mi("{1^{-1} = 1}")#text(".)")]
)

#text("We will sometimes use additive notation for local groups if the groups are locally abelian (thus if ")#mi("{g+h}")#text(" is defined, then ")#mi("{h+g}")#text(" is also defined and equal to ")#mi("{g+h}")#text(".)")

#text("A local group is said to be ")#emph[#text("symmetric")]#text(" if ")#mi("{\\Lambda = G}")#text(", i.e. if every element ")#mi("{g}")#text(" in ")#mi("{G}")#text(" has an inverse ")#mi("{g^{-1}}")#text(" that is also in ")#mi("{G}")#text(".")

#text("A ")#emph[#text("local Lie group")]#text(" is a local group that is also a smooth manifold, in such a fashion that the partially defined group operations ")#mi("{\\cdot, ()^{-1}}")#text(" are smooth on their domain of definition.")
]

#text("Clearly, every topological group is a local group, and every Lie group is a local Lie group. We will sometimes refer to the former concepts as ")#emph[#text("global")]#text(" topological groups and ")#emph[#text("global")]#text(" Lie groups in order to distinguish them from their local counterparts. One could also consider local discrete groups, in which the topological structure is just the discrete topology, but we will not need to study such objects in this course.")

#text("A model class of examples of a local (Lie) group comes from ")#emph[#text("restricting")]#text(" a global (Lie) group to an open neighbourhood of the identity. Let us formalise this concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Restriction)")]#text(" If ")#mi("{G}")#text(" is a local group, and ")#mi("{U}")#text(" is an open neighbourhood of the identity in ")#mi("{G}")#text(", then we define the ")#emph[#text("restriction")]#text(" ")#mi("{G\\downharpoonright_U}")#text(" of ")#mi("{G}")#text(" to ")#mi("{U}")#text(" to be the topological space ")#mi("{U}")#text(" with domains ")#mi("{\\Omega\\downharpoonright_U := \\{ (g,h) \\in \\Omega: g, h, g \\cdot h \\in U \\}}")#text(" and ")#mi("{\\Lambda\\downharpoonright_U := \\{ g \\in \\Lambda: g, g^{-1} \\in U \\}}")#text(", and with the group operations ")#mi("{\\cdot, ()^{-1}}")#text(" being the restriction of the group operations of ")#mi("{G}")#text(" to ")#mi("{\\Omega\\downharpoonright_U}")#text(", ")#mi("{\\Lambda\\downharpoonright_U}")#text(" respectively. If ")#mi("{U}")#text(" is symmetric (in the sense that ")#mi("{g^{-1}}")#text(" is well-defined and lies in ")#mi("{U}")#text(" for all ")#mi("{g \\in U}")#text("), then this restriction ")#mi("{G\\downharpoonright_U}")#text(" will also be symmetric. If ")#mi("{G}")#text(" is a global or local Lie group, then ")#mi("{G\\downharpoonright_U}")#text(" will also be a local Lie group. We will sometimes abuse notation and refer to the local group ")#mi("{G\\downharpoonright_U}")#text(" simply as ")#mi("{U}")#text(".")
]

#text("Thus, for instance, one can take the Euclidean space ")#mi("{{\\bf R}^d}")#text(", and restrict it to a ball ")#mi("{B}")#text(" centred at the origin, to obtain an additive local group ")#mi("{{\\bf R}^d\\downharpoonright_B}")#text(". In this group, two elements ")#mi("{x, y}")#text(" in ")#mi("{B}")#text(" have a well-defined sum ")#mi("{x+y}")#text(" only when their sum in ")#mi("{{\\bf R}^d}")#text(" stays inside ")#mi("{B}")#text(". Intuitively, this local group behaves like the global group ")#mi("{{\\bf R}^d}")#text(" as long as one is close enough to the identity element ")#mi("{0}")#text(", but as one gets closer to the boundary of ")#mi("{B}")#text(", the group structure begins to break down.")

#text("It is natural to ask the question as to whether ")#emph[#text("every")]#text(" local group arises as the restriction of a global group. The answer to this question is somewhat complicated, and can be summarised as “essentially yes in certain circumstances, but not in general”. See ")#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("this previous blog post")]#text(" for more discussion.")

#text("A key example of a local Lie group for this blog post will come from pushing forward a Lie group via a coordinate chart near the origin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-cc57fc1903e444cf6a72>#text(" Let ")#mi("{G}")#text(" be a global or local Lie group of some dimension ")#mi("{d}")#text(", and let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a smooth coordinate chart from a neighbourhood ")#mi("{U}")#text(" of the identity ")#mi("{1}")#text(" in ")#mi("{G}")#text(" to a neighbourhood ")#mi("{V}")#text(" of the origin ")#mi("{0}")#text(" in ")#mi("{{\\bf R}^d}")#text(", such that ")#mi("{\\phi}")#text(" maps ")#mi("{1}")#text(" to ")#mi("{0}")#text(". Then we can define a local group ")#mi("{\\phi_* G\\downharpoonright_U}")#text(" which is the set ")#mi("{V}")#text(" (viewed as a smooth submanifold of ")#mi("{{\\bf R}^d}")#text(") with the local group identity ")#mi("{0}")#text(", the local group multiplication law ")#mi("{\\ast}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("x \\ast y := \\phi( \\phi^{-1}(x) \\cdot \\phi^{-1}(y) )")]]

#text("defined whenever ")#mi("{\\phi^{-1}(x), \\phi^{-1}(y), \\phi^{-1}(x) \\cdot \\phi^{-1}(y)}")#text(" are well-defined and lie in ")#mi("{U}")#text(", and the local group inversion law ")#mi("{()^{\\ast-1}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("x^{\\ast -1} := \\phi( \\phi^{-1}(x)^{-1} )")]]

#text("defined whenever ")#mi("{\\phi^{-1}(x), \\phi^{-1}(x)^{-1}}")#text(" are well-defined and lie in ")#mi("{U}")#text(". One easily verifies that ")#mi("{\\phi_* G \\downharpoonright_U}")#text(" is a local Lie group. We will sometimes denote this local Lie group as ")#mi("{(V,\\ast)}")#text(", to distinguish it from the additive local Lie group ")#mi("{(V,+)}")#text(" arising by restriction of ")#mi("{({\\bf R}^d,+)}")#text(" to ")#mi("{V}")#text(". The precise distinction between the two local Lie groups will in fact be a major focus of this post.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Let ")#mi("{G}")#text(" be the Lie group ")#mi("{GL_n({\\bf R})}")#text(", and let ")#mi("{U}")#text(" be the ball ")#tao-math("{U := \\{ g \\in GL_n({\\bf R}): \\left\\|g-1\\right\\|_{op} < 1 \\}}", block: false)#text(". If we then let ")#mi("{V \\subset M_n({\\bf R})}")#text(" be the ball ")#tao-math("{V := \\{ x \\in M_n({\\bf R}): \\left\\|x\\right\\|_{op} < 1 \\}}", block: false)#text(" and ")#mi("{\\phi}")#text(" be the map ")#mi("{\\phi(g) := g-1}")#text(", then ")#mi("{\\phi}")#text(" is a smooth coordinate chart (after identifying ")#mi("{M_n({\\bf R})}")#text(" with ")#mi("{{\\bf R}^{n \\times n}}")#text("), and by the construction in the preceding exercise, ")#mi("{V = \\phi_* G\\downharpoonright_U}")#text(" becomes a local Lie group with the operations")

#align(center)[#tao-fit-display[#mitex("x \\ast y := x + y + xy")]]

#text("(defined whenever ")#mi("{x, y, x+y+xy}")#text(" all lie in ")#mi("{V}")#text(") and")

#align(center)[#tao-fit-display[#mitex("x^{\\ast -1} := (1+x)^{-1} - 1 = x - x^2 + x^3 - \\ldots")]]

#text("(defined whenever ")#mi("{x}")#text(" and ")#mi("{(1+x)^{-1} - 1}")#text(" both lie in ")#mi("{V}")#text("). Note that this Lie group structure is not equal to the additive structure ")#mi("{(V,+)}")#text(" on ")#mi("{V}")#text(", nor is it equal to the multiplicative structure ")#mi("{(V,\\cdot)}")#text(" on ")#mi("{V}")#text(" given by matrix multiplication, which is one of the reasons why we use the symbol ")#mi("{\\ast}")#text(" instead of ")#mi("{+}")#text(" or ")#mi("{\\cdot}")#text(" for such structures.")
]

#text("Many (though not all) of the familiar constructions in group theory can be generalised to the local setting, though often with some slight additional subtleties. We will not systematically do so here, but we give a single such generalisation for now:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Homomorphism)")]#text(" A ")#emph[#text("continuous homomorphism")]#text(" ")#mi("{\\phi: G \\rightarrow H}")#text(" between two local groups ")#mi("{G, H}")#text(" is a continuous map from ")#mi("{G}")#text(" to ")#mi("{H}")#text(" with the following properties:")

#list(
[#mi("{\\phi}")#text(" maps the identity ")#mi("{1_G}")#text(" of ")#mi("{G}")#text(" to the identity ")#mi("{1_H}")#text(" of ")#mi("{H}")#text(": ")#mi("{\\phi(1_G) = 1_H}")#text(".")],
[#text("If ")#mi("{g \\in G}")#text(" is such that ")#mi("{g^{-1}}")#text(" is well-defined in ")#mi("{G}")#text(", then ")#mi("{\\phi(g)^{-1}}")#text(" is well-defined in ")#mi("{H}")#text(" and is equal to ")#mi("{\\phi(g^{-1})}")#text(".")],
[#text("If ")#mi("{g, h \\in G}")#text(" are such that ")#mi("{g \\cdot h}")#text(" is well-defined in ")#mi("{G}")#text(", then ")#mi("{\\phi(g) \\cdot \\phi(h)}")#text(" is well-defined and equal to ")#mi("{\\phi(g \\cdot h)}")#text(".")]
)

#text("A ")#emph[#text("smooth homomorphism")]#text(" ")#mi("{\\phi: G \\rightarrow H}")#text(" between two local Lie groups ")#mi("{G, H}")#text(" is a continuous homomorphism that is also smooth.")
]

#text("It is easy to see that the composition of two continuous homomorphisms is again a continuous homomorphism; this gives the class of local groups the structure of a ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category")]#text(". Similarly, the class of local Lie groups with their smooth homomorphisms is also a category.")

#text("Note that homomorphisms on a local group ")#mi("{G}")#text(" are defined on the entirety of ")#mi("{G}")#text("; it is also natural to consider (continuous or smooth) ")#emph[#text("local homomorphisms")]#text(", which are only defined on an open neighbourhood of the identity in ")#mi("{G}")#text(", with two local homomorphisms considered equivalent if they agree on a (possibly smaller) open neighbourhood of the identity. We will not need to do so for now, however.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" With the notation of Example ")#link(<tao-cc57fc1903e444cf6a72>)[#text("1")]#text(", ")#mi("{\\phi: U \\rightarrow V}")#text(" is a smooth homomorphism from the local Lie group ")#mi("{G\\downharpoonright_U}")#text(" to the local Lie group ")#mi("{\\phi_* G\\downharpoonright_U}")#text(". In fact, it is a smooth isomorphism, since ")#mi("{\\phi^{-1}: V \\rightarrow U}")#text(" provides the inverse homomorphism.")
]

#text("Let us say that a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group ")#mi("{G}")#text(" is ")#emph[#text("well-defined in ")#mi("{G}")]#text(" (or ")#emph[#text("well-defined")]#text(", for short) if every possible way of associating this word using parentheses is well-defined from applying the product operation. For instance, in order for ")#mi("{abcd}")#text(" to be well-defined, ")#mi("{((ab)c)d}")#text(", ")#mi("{(a(bc))d}")#text(", ")#mi("{(ab)(cd)}")#text(", ")#mi("{a(b(cd))}")#text(", and ")#mi("{a((bc)d)}")#text(" must all be well-defined. For instance, in the additive local group ")#mi("{\\{-9,\\ldots,9\\}}")#text(" (with the group structure restricted from that of the integers ")#mi("{{\\bf Z}}")#text("), ")#mi("{-2+6+5}")#text(" is not well-defined because one of the ways of associating this sum, namely ")#mi("{-2+(6+5)}")#text(", is not well-defined (even though ")#mi("{(-2+6)+5}")#text(" is well-defined).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Iterating the associative law)")]

#list(
[#text("Show that if a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group ")#mi("{G}")#text(" is well-defined, then all ways of associating this word give the same answer, and so we can uniquely evaluate ")#mi("{g_1 \\ldots g_n}")#text(" as an element in ")#mi("{G}")#text(".")],
[#text("Give an example of a word ")#mi("{g_1 \\ldots g_n}")#text(" in a local group ")#mi("{G}")#text(" which has two ways of being associated that are both well-defined, but give ")#emph[#text("different")]#text(" answers. (")#emph[#text("Hint:")]#text(" the local associativity axiom prevents this from happening for ")#mi("{n \\leq 3}")#text(", so try ")#mi("{n=4}")#text(". A small discrete local group will already suffice to give a counterexample; verifying the local group axioms are easier if one makes the domain of definition of the group operations as small as one can get away with while still having the counterexample.)")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Some differential geometry — ")]]

#text("To define the Lie algebra of a Lie group, we must first quickly recall some basic notions from differential geometry associated to smooth manifolds (which are not necessarily embedded in some larger Euclidean space, but instead exist intrinsically as abstract geometric structures). This requires a certain amount of abstract formalism in order to define things rigorously, though for the purposes of visualisation, it is more intuitive to view these concepts from a more informal geometric perspective.")

#text("We begin with the concept of the tangent space and related structures.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Tangent space)")]#text(" Let ")#mi("{M}")#text(" be a smooth ")#mi("{d}")#text("-dimensional manifold. At every point ")#mi("{x}")#text(" of this manifold, we can define the ")#link("http://en.wikipedia.org/wiki/Tangent_space")[#text("tangent space")]#text(" ")#mi("{T_x M}")#text(" of ")#mi("{M}")#text(" at ")#mi("{x}")#text(". Formally, this tangent space can be defined as the space of all continuously differentiable curves ")#mi("{\\gamma: I \\rightarrow M}")#text(" defined on an open interval ")#mi("{I}")#text(" containing ")#mi("{0}")#text(" with ")#mi("{\\gamma(0)=x}")#text(", modulo the relation that two curves ")#mi("{\\gamma_1, \\gamma_2}")#text(" are considered equivalent if they have the same derivative at ")#mi("{0}")#text(", in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\frac{d}{dt} \\phi(\\gamma_1(t))\\left|_{t=0} = \\frac{d}{dt} \\phi(\\gamma_2(t))\\right|_{t=0}", block: true)]]

#text("where ")#mi("{\\phi:U \\rightarrow V}")#text(" is a coordinate chart of ")#mi("{G}")#text(" defined in a neighbourhood of ")#mi("{x}")#text("; it is easy to see from the chain rule that this equivalence is independent of the actual choice of ")#mi("{\\phi}")#text(". Using such a coordinate chart, one can identify the tangent space ")#mi("{T_x M}")#text(" with the Euclidean space ")#mi("{{\\bf R}^d}")#text(", by identifying ")#mi("{\\gamma}")#text(" with ")#mi("{\\frac{d}{dt} \\phi(\\gamma(t))|_{t=0}}")#text(". One easily verifies that this gives ")#mi("{T_x M}")#text(" the structure of a ")#mi("{d}")#text("-dimensional vector space, in a manner which is independent of the choice of coordinate chart ")#mi("{\\phi}")#text(". Elements of ")#mi("{T_x M}")#text(" are called ")#emph[#text("tangent vectors")]#text(" of ")#mi("{M}")#text(" at ")#mi("{x}")#text(". If ")#mi("{\\gamma: I \\rightarrow M}")#text(" is a continuously differentiable curve with ")#mi("{\\gamma(0)=x}")#text(", the equivalence class of ")#mi("{\\gamma}")#text(" in ")#mi("{T_x M}")#text(" will be denoted ")#mi("{\\gamma^{\\prime}(0)}")#text(".")

#text("The space ")#mi("{TM := \\bigcup_{x \\in M} (\\{x\\} \\times T_x M)}")#text(" of pairs ")#mi("{(x,v)}")#text(", where ")#mi("{x}")#text(" is a point in ")#mi("{M}")#text(" and ")#mi("{v}")#text(" is a tangent vector of ")#mi("{M}")#text(" at ")#mi("{x}")#text(", is called the ")#link("http://en.wikipedia.org/wiki/Tangent_bundle")[#text("tangent bundle")]#text(".")

#text("If ")#mi("{\\Phi: M \\rightarrow N}")#text(" is a smooth map between two manifolds, we define the ")#link("http://en.wikipedia.org/wiki/Tangent_space#The_derivative_of_a_map")[#text("derivative map")]#text(" ")#mi("{D\\Phi: TM \\rightarrow TN}")#text(" to be the map defined by setting")

#align(center)[#tao-fit-display[#mitex("D\\Phi( (x, \\gamma^{\\prime}(0)) ) := (\\Phi(x), (\\Phi \\circ \\gamma)^{\\prime}(0))")]]

#text("for all continously differentiable curves ")#mi("{\\gamma: I \\rightarrow M}")#text(" with ")#mi("{\\gamma(0)=x}")#text(" for some ")#mi("{x \\in M}")#text(". We also write ")#mi("{(\\Phi(x), D\\Phi(x)(v))}")#text(" for ")#mi("{D\\Phi(x,v)}")#text(", so that for each ")#mi("{x \\in M}")#text(", ")#mi("{D\\Phi(x)}")#text(" is a map from ")#mi("{T_x M}")#text(" to ")#mi("{T_{\\Phi(x)} N}")#text(". One can easily verify that this latter map is linear. We observe the ")#emph[#text("chain rule")]#text(" ")#metadata(none) <tao-9414886b1ebf025db067>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("D(\\Psi \\circ \\Phi) = (D\\Psi) \\circ (D\\Phi)")]]

#text("for any smooth maps ")#mi("{\\Phi: M \\rightarrow N}")#text(", ")#mi("{\\Psi: N \\rightarrow O}")#text(". (Indeed, one can view the tangent operator ")#mi("{T}")#text(" and the derivative operator ")#mi("{D}")#text(" together as a single ")#link("http://en.wikipedia.org/wiki/Functor")[#text("covariant functor")]#text(" from the category of smooth manifolds to itself, although we will not need to use this perspective here.)")

#text("Observe that if ")#mi("{V}")#text(" is an open subset of ")#mi("{{\\bf R}^d}")#text(", then ")#mi("{TV}")#text(" may be identified with ")#mi("{V \\times {\\bf R}^d}")#text(". In particular, every coordinate chart ")#mi("{\\phi: U \\rightarrow V}")#text(" of ")#mi("{M}")#text(" gives rise to a coordinate chart ")#mi("{D\\phi: TU \\rightarrow V \\times {\\bf R}^d}")#text(" of ")#mi("{TM}")#text(", which gives ")#mi("{TM}")#text(" the structure of a smooth ")#mi("{2d}")#text("-dimensional manifold.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Informally, one can think of a tangent vector ")#mi("{(x,v)}")#text(" as an infinitesimal vector from the point ")#mi("{x}")#text(" of ")#mi("{M}")#text(" to a nearby point ")#mi("{x + \\epsilon v + O(\\epsilon^2)}")#text(" on ")#mi("{M}")#text(", where ")#mi("{\\epsilon>0}")#text(" is infinitesimally small; a smooth map ")#mi("{\\phi}")#text(" then sends ")#mi("{x + \\epsilon v + O(\\epsilon^2)}")#text(" to ")#mi("{\\phi(x) + \\epsilon D\\phi(x)(v) + O(\\epsilon^2)}")#text(". One can make this informal perspective rigorous by means of ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(", but we will not do so here.")
]

#text("Once one has the notion of a tangent bundle, one can define the notion of a smooth vector field:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Vector fields)")]#text(" A ")#link("http://en.wikipedia.org/wiki/Vector_field")[#text("smooth vector field")]#text(" on ")#mi("{M}")#text(" is a smooth map ")#mi("{X: M \\rightarrow TM}")#text(" which is a right inverse for the projection map ")#mi("{\\pi: TM \\rightarrow M}")#text(", thus (by slight abuse of notation) ")#mi("{X}")#text(" maps ")#mi("{x}")#text(" to ")#mi("{(x,X(x))}")#text(" for some ")#mi("{X(x) \\in T_x M}")#text(". The space of all smooth vector fields is denoted ")#mi("{\\Gamma(TM)}")#text(". It is clearly a real vector space. In fact, it is a ")#mi("{C^\\infty(M)}")#text("-module: given a smooth vector field ")#mi("{X \\in \\Gamma(TM)}")#text(" and a smooth function ")#mi("{f \\in C^\\infty(M)}")#text(" (i.e. a smooth map ")#mi("{f: M \\rightarrow {\\bf R}}")#text("), one can define the product ")#mi("{fX}")#text(" in the obvious manner: ")#mi("{fX(x) := f(x) X(x)}")#text(", and one easily verifies the ")#link("http://en.wikipedia.org/wiki/Module_(mathematics)")[#text("module axioms")]#text(".")

#text("Given a smooth function ")#mi("{f \\in C^\\infty(M)}")#text(" and a smooth vector field ")#mi("{X \\in \\Gamma(TM)}")#text(", we define the ")#link("http://en.wikipedia.org/wiki/Directional_derivative")[#text("directional derivative")]#text(" ")#mi("{\\nabla_X f \\in C^\\infty(M)}")#text(" of ")#mi("{f}")#text(" along ")#mi("{X}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\nabla_X f(x) := \\frac{d}{dt} f(\\gamma(t))|_{t=0}")]]

#text("whenever ")#mi("{\\gamma: I \\rightarrow M}")#text(" is a continuously differentiable function with ")#mi("{\\gamma(0)=x}")#text(" and ")#mi("{\\gamma^{\\prime}(0)=X(x)}")#text("; one easily verifies that ")#mi("{\\nabla_X f}")#text(" is well-defined and is an element of ")#mi("{C^\\infty(M)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can define ")#mi("{\\nabla_X f}")#text(" in a more “co-ordinate free” manner as")

#align(center)[#tao-fit-display[#mitex("\\nabla_X f = \\eta \\circ Df \\circ X,")]]

#text("where ")#mi("{\\eta: T{\\bf R} \\rightarrow {\\bf R}}")#text(" is the projection map to the second coordinate of ")#mi("{T{\\bf R} \\equiv {\\bf R} \\times {\\bf R}}")#text("; one can also view ")#mi("{\\nabla_X f}")#text(" as the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" of ")#mi("{f}")#text(" along ")#mi("{X}")#text(" (although, in most texts, the latter definition would be circular, because the Lie derivative is usually defined using the directional derivative).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" If ")#mi("{V}")#text(" is an open subset of ")#mi("{{\\bf R}^d}")#text(", a smooth vector field on ")#mi("{V}")#text(" can be identified with a smooth map ")#mi("{X: V \\rightarrow {\\bf R}^d}")#text(" from ")#mi("{V}")#text(" to ")#mi("{{\\bf R}^d}")#text(". If ")#mi("{X: M \\rightarrow TM}")#text(" is a smooth vector field on ")#mi("{M}")#text(" and ")#mi("{\\phi: U \\rightarrow V}")#text(" is a coordinate chart of ")#mi("{M}")#text(", then the ")#emph[#text("pushforward")]#text(" ")#mi("{\\phi_* X := D\\phi \\circ X \\circ \\phi^{-1}: V \\rightarrow TV}")#text(" of ")#mi("{X}")#text(" by ")#mi("{\\phi}")#text(" is a smooth vector field of ")#mi("{V}")#text(". Thus, in coordinates, one can view vector fields as maps from open subsets of ")#mi("{{\\bf R}^d}")#text(" to ")#mi("{{\\bf R}^d}")#text(". This perspective is convenient for quick and dirty calculations; for instance, in coordinates, the directional derivative ")#mi("{\\nabla_X f}")#text(" is the same as the familiar directional derivative ")#mi("{X \\cdot \\nabla f}")#text(" from several variable calculus. If however one wishes to perform several changes of variable, then the more intrinsically geometric (and “coordinate-free”) perspective outlined above can be more helpful.")
]

#text("There is a fundamental link between smooth vector fields and derivations of ")#mi("{C^\\infty(M)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Correspondence between smooth vector fields and derivations)")]#text(" Let ")#mi("{M}")#text(" be a smooth manifold.")

#list(
[#text("If ")#mi("{X \\in \\Gamma(TM)}")#text(" is a smooth vector field, show that ")#mi("{\\nabla_X: C^\\infty(M) \\rightarrow C^\\infty(M)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivation")]#text(" on the (real) ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" ")#mi("{C^\\infty(M)}")#text(", i.e. a (real) linear map that obeys the Leibniz rule")

#metadata(none) <tao-6a63d2deee991139261b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\nabla_X(fg) = f \\nabla_X g + (\\nabla_X f) g")]]

#text("for all ")#mi("{f, g \\in C^\\infty(M)}")#text(".")],
[#text("Conversely, if ")#mi("{d: C^\\infty(M) \\rightarrow C^\\infty(M)}")#text(" is a derivation on ")#mi("{C^\\infty(M)}")#text(", show that there exists a unique smooth vector field ")#mi("{X}")#text(" such that ")#mi("{d = \\nabla_X}")#text(".")]
)
]

#text("We see from the above exercise that smooth vector fields can be interpreted as a purely algebraic construction associated to the real algebra ")#mi("{C^\\infty(M)}")#text(", namely as the space of derivations on that vector space. This can be useful for analysing the algebraic structure of such vector fields. Indeed, we have the following basic algebraic observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Commutator of derivations is a derivation)")]#text(" Let ")#mi("{d_1, d_2: A \\rightarrow A}")#text(" be two derivations on an algebra ")#mi("{A}")#text(". Show that the commutator ")#mi("{[d_1,d_2] := d_1 \\circ d_2 - d_2 \\circ d_1}")#text(" is also a derivation on ")#mi("{A}")#text(".")
]

#text("From the preceding two exercises, we can define the ")#link("http://en.wikipedia.org/wiki/Lie_bracket_of_vector_fields")[#text("Lie bracket")]#text(" ")#mi("{[X,Y]}")#text(" of two vector fields ")#mi("{X, Y \\in \\Gamma(TM)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\nabla_{[X,Y]} := [\\nabla_X, \\nabla_Y].")]]

#text("This gives the space ")#mi("{\\Gamma(TM)}")#text(" of smooth vector fields the structure of an (infinite-dimensional) ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Lie algebra)")]#text(" A (real) Lie algebra is a real vector space ")#mi("{V}")#text(" (possibly infinite dimensional), together with a bilinear map ")#mi("{[,]: V \\times V \\rightarrow V}")#text(" which is anti-symmetric (thus ")#mi("{[X,Y] = -[Y,X]}")#text(" for all ")#mi("{X,Y \\in V}")#text(", or equivalently ")#mi("{[X,X] = 0}")#text(" for all ")#mi("{X \\in V}")#text(") and obeys the ")#link("http://en.wikipedia.org/wiki/Jacobi_identity")[#text("Jacobi identity")]#text(" ")#metadata(none) <tao-9dcc6fbbb4f3d0969043>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("[[X,Y],Z] + [[Y,Z],X] + [[Z,X],Y] = 0")]]

#text("for all ")#mi("{X,Y,Z \\in V}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" If ")#mi("{M}")#text(" is a smooth manifold, show that ")#mi("{\\Gamma(TM)}")#text(" (equipped with the Lie bracket) is a Lie algebra.")
]

#heading(level: 1)[#strong[#text(" — 3. The Lie algebra of a Lie group — ")]]

#text("Let ")#mi("{G}")#text(" be a (global) Lie group. By definition, ")#mi("{G}")#text(" is then a smooth manifolds, so we can thus define the tangent bundle ")#mi("{TG}")#text(" and smooth vector fields ")#mi("{X \\in \\Gamma(TG)}")#text(" as in the preceding section. In particular, we can define the tangent space ")#mi("{T_1 G}")#text(" of ")#mi("{G}")#text(" at the identity element ")#mi("{1}")#text(".")

#text("If ")#mi("{g \\in G}")#text(", then the left multiplication operation ")#mi("{\\rho_g^{left}: x \\mapsto gx}")#text(" is, by definition of a Lie group, a smooth map from ")#mi("{G}")#text(" to ")#mi("{G}")#text(". This creates a derivative map ")#mi("{D \\rho_g^{left}: TG \\rightarrow TG}")#text(" from the tangent bundle ")#mi("{TG}")#text(" to itself. We say that a vector field ")#mi("{X \\in \\Gamma(TG)}")#text(" is ")#emph[#text("left-invariant")]#text(" if one has ")#mi("{(\\rho_g^{left})_* X = X}")#text(" for all ")#mi("{g \\in G}")#text(", or equivalently if ")#mi("{(D \\rho_g^{left}) \\circ X = X \\circ \\rho_g^{left}}")#text(" for all ")#mi("{g \\in G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-2a1073a6e67f0e5f09a5>#text(" Let ")#mi("{G}")#text(" be a (global) Lie group.")

#list(
[#text("Show that for every element ")#mi("{x}")#text(" of ")#mi("{T_1 G}")#text(" there is a unique left-invariant vector field ")#mi("{X \\in \\Gamma(TG)}")#text(" such that ")#mi("{X(1)=x}")#text(".")],
[#text("Show that the commutator ")#mi("{[X,Y]}")#text(" of two left-invariant vector fields is again a left-invariant vector field.")]
)
]

#text("From the above exercise, we can identify the tangent space ")#mi("{T_1 G}")#text(" with the left-invariant vector fields on ")#mi("{TG}")#text(", and the Lie bracket structure on the latter then induces a Lie bracket (which we also call ")#mi("{[,]}")#text(") on ")#mi("{T_1 G}")#text(". The vector space ")#mi("{T_1 G}")#text(" together with this Lie bracket is then a (finite-dimensional) Lie algebra, which we call the ")#emph[#text("Lie algebra")]#text(" of the Lie group ")#mi("{G}")#text(", and we write as ")#mi("{{\\mathfrak g}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Informally, an element ")#mi("{x}")#text(" of the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is associated with an infinitesimal perturbation ")#mi("{1 + \\epsilon x + O(\\epsilon^2)}")#text(" of the identity in the Lie group ")#mi("{G}")#text(". This intuition can be formalised fairly easily in the case of matrix Lie groups such as ")#mi("{GL_n({\\bf C})}")#text("; for more abstract Lie groups, one can still formalise things using nonstandard analysis, but we will not do so here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]

#list(
[#text("Show that the Lie algebra ")#mi("{{\\mathfrak gl}_n({\\bf C})}")#text(" of the general linear group ")#mi("{GL_n({\\bf C})}")#text(" can be identified with the space ")#mi("{M_n({\\bf C})}")#text(" of ")#mi("{n \\times n}")#text(" complex matrices, with the Lie bracket ")#mi("{[A,B] := AB-BA}")#text(".")],
[#text("Describe the Lie algebra ")#mi("{{\\mathfrak u}_n({\\bf C})}")#text(" of the unitary group ")#mi("{U_n({\\bf C})}")#text(".")],
[#text("Describe the Lie algebra ")#mi("{\\mathfrak{su}_n({\\bf C})}")#text(" of the special unitary group ")#mi("{SU_n({\\bf C})}")#text(".")],
[#text("Describe the Lie algebra ")#mi("{{\\mathfrak o}_n({\\bf R})}")#text(" of the orthogonal ")#mi("{O_n({\\bf R})}")#text(".")],
[#text("Describe the Lie algebra ")#mi("{\\mathfrak{so}_n({\\bf R})}")#text(" of the special orthogonal ")#mi("{SO_n({\\bf R})}")#text(".")],
[#text("Describe the Lie algebra of the Heisenberg group ")#mi("{\\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-a821c62e8104f8519d63>#text(" Let ")#mi("{\\phi: G \\rightarrow H}")#text(" be a smooth homomorphism between (global) Lie groups. Show that the derivative map ")#mi("{D\\phi(1_G)}")#text(" at the identity element ")#mi("{1_G}")#text(" is then a Lie algebra homomorphism from the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" of ")#mi("{G}")#text(" to the Lie algebra ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{H}")#text(" (thus this map is linear and preserves the Lie bracket). (From this and the chain rule ")#link(<tao-9414886b1ebf025db067>)[#text("(1)")]#text(", we see that the map ")#mi("{\\phi \\mapsto D\\phi(1_G)}")#text(" creates a covariant functor from the category of Lie groups to the category of Lie algebras.)")
]

#text("We have seen that every global Lie group gives rise to a Lie algebra. One can also associate Lie algebras to ")#emph[#text("local")]#text(" Lie groups as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-6f1eb246f9c696c29499>#text(" Let ")#mi("{G}")#text(" be a local Lie group. Let ")#mi("{U}")#text(" be a symmetric neighbourhood of the identity in ")#mi("{G}")#text(". (It is not difficult to see that least one such neighbourhood exists.) Call a vector field ")#mi("{X \\in \\Gamma(TU)}")#text(" ")#emph[#text("left-invariant")]#text(" if, for every ")#mi("{g \\in U}")#text(", one has ")#mi("{(\\rho_g^{left})_* X(g) = X(g)}")#text(", where ")#mi("{\\rho_g^{left}}")#text(" is the left-multiplication map ")#mi("{x \\mapsto gx}")#text(", defined on the open set ")#mi("{\\{ x \\in U: gx \\in U \\}}")#text(" (where we adopt the convention that ")#mi("{gx \\in U}")#text(" is shorthand for “")#mi("{g \\cdot x}")#text(" is well-defined and lies in ")#mi("{U}")#text("“).")

#list(
[#text("Establish the analogue of Exercise ")#link(<tao-2a1073a6e67f0e5f09a5>)[#text("5")]#text(" in this setting. Conclude that one can give ")#mi("{T_1 G}")#text(" the structure of a Lie algebra, which is independent of the choice of ")#mi("{U}")#text(".")],
[#text("Establish the analogue of Exercise ")#link(<tao-a821c62e8104f8519d63>)[#text("7")]#text(" in this setting.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" In the converse direction, it is also true that every finite-dimensional Lie algebra can be associated to either a local or a global Lie group; this is known as ")#emph[#text("Lie’s third theorem")]#text(". However, this theorem is somewhat tricky to prove (particularly if one wants to associate the Lie algebra with a ")#emph[#text("global")]#text(" Lie group), requiring the non-trivial algebraic tool of ")#link("http://en.wikipedia.org/wiki/Ado's_theorem")[#text("Ado’s theorem")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous blog post")]#text("); see Exercise ")#link(<tao-b1e99324505bd32da0e1>)[#text("21")]#text(" below.")
]

#heading(level: 1)[#strong[#text(" — 4. The exponential map — ")]]

#text("The ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map")]#text(" ")#mi("{x \\mapsto \\exp(x)}")#text(" on the reals ")#mi("{{\\bf R}}")#text(" (or its extension to the complex numbers ")#mi("{{\\bf C}}")#text(") is of course fundamental to modern analysis. It can be defined in a variety of ways, such as the following:")

#list(
[#text("(i) ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the differentiable map obeying the ODE ")#mi("{\\frac{d}{dx} \\exp(x) = \\exp(x)}")#text(" and the initial condition ")#mi("{\\exp(0)=1}")#text(".")],
[#text("(ii) ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the differentiable map obeying the homomorphism property ")#mi("{\\exp(x+y) = \\exp(x) \\exp(y)}")#text(" and the initial condition ")#mi("{\\frac{d}{dx} \\exp(x)|_{x=0}=1}")#text(".")],
[#text("(iii) ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the limit of the functions ")#mi("{x \\mapsto (1+\\frac{x}{n})^n}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(iv) ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(" is the limit of the infinite series ")#mi("{x \\mapsto \\sum_{n=0}^\\infty \\frac{x^n}{n!}}")#text(".")]
)

#text("We will need to generalise this map to arbitrary Lie algebras and Lie groups. In the case of matrix Lie groups (and matrix Lie algebras), one can use the matrix exponential, which can be defined efficiently by modifying definition (iv) above, and which was already discussed in ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("the previous set of notes")]#text(". It is however difficult to use this definition for abstract Lie algebras and Lie groups. The definition based on (ii) will ultimately be the best one to use for the purposes of this course, but for foundational purposes (i) or (iii) is initially easier to work with. In most of the foundational literature on Lie groups and Lie algebras, one uses (i), in which case the existence and basic properties of the exponential map can be provided by the ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence theorem")]#text(" from the theory of ordinary differential equations. However, we will use (iii), because it relies less heavily on the smooth structure of the Lie group, and will therefore be more aligned with the spirit of Hilbert’s fifth problem (which seeks to minimise the reliance of smoothness hypotheses whenever possible). Actually, for minor technical reasons it is slightly more convenient to work with the limit of ")#mi("{(1+\\frac{x}{2^n})^{2^n}}")#text(" rather than ")#mi("{(1+\\frac{x}{n})^{n}}")#text(".")

#text("We turn to the details. It will be convenient to work in local coordinates, and for applications to Hilbert’s fifth problem it will be useful to “forget” almost all of the smooth structure. We make the following definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (")#mi("{C^{1,1}}")#text(" local group)")]#text(" A ")#emph[#mi("{C^{1,1}}")#text(" local group")]#text(" is a local group ")#mi("{V}")#text(" that is an open neighbourhood of the origin ")#mi("{0}")#text(" in a Euclidean space ")#mi("{{\\bf R}^d}")#text(", with group identity ")#mi("{0}")#text(", and whose group operation ")#mi("{\\ast}")#text(" obeys the estimate ")#metadata(none) <tao-8cf107bbea706c3ab8da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("x \\ast y = x + y + O(\\left|x\\right| \\left|y\\right|)", block: true)]]

#text("for all sufficiently small ")#mi("{x, y}")#text(", where the implied constant in the ")#mi("{O()}")#text(" notation can depend on ")#mi("{V}")#text(" but is uniform in ")#mi("{x, y}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Let ")#mi("{G}")#text(" be a local Lie group of some dimension ")#mi("{d}")#text(", and let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a smooth coordinate chart that maps a neighbourhood ")#mi("{U}")#text(" of the group identity ")#mi("{1}")#text(" to a neighbourhood ")#mi("{V}")#text(" of the origin ")#mi("{0}")#text(" in ")#mi("{{\\bf R}^d}")#text(", with ")#mi("{\\phi(1)=0}")#text(". Then, as explained in Example ")#link(<tao-cc57fc1903e444cf6a72>)[#text("1")]#text(", ")#mi("{V = (V,\\ast) = \\phi_* G\\downharpoonright_U}")#text(" is a local Lie group with identity ")#mi("{0}")#text("; in particular, one has")

#align(center)[#tao-fit-display[#mitex("0 \\ast x = x \\ast 0 = x.")]]

#text("From Taylor expansion (using the smoothness of ")#mi("{\\ast}")#text(") we thus have ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" for sufficiently small ")#mi("{x,y}")#text(". Thus we see that every local Lie group generates a ")#mi("{C^{1,1}}")#text(" local group when viewed in coordinates.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" In real analysis, a (locally) ")#mi("{C^{1,1}}")#text(" function is a function ")#mi("{f: U \\rightarrow {\\bf R}^m}")#text(" on a domain ")#mi("{U \\subset {\\bf R}^n}")#text(" which is continuously differentiable (i.e. in the regularity class ")#mi("{C^1}")#text("), and whose first derivatives ")#mi("{\\nabla f}")#text(" are (locally) Lipschitz (i.e. in the regularity class ")#mi("{C^{0,1}}")#text(") the ")#mi("{C^{1,1}}")#text(" regularity class is slightly weaker (i.e. larger) than the class ")#mi("{C^2}")#text(" of twice continuously differentiable functions, but much stronger than the class ")#mi("{C^1}")#text(" of singly continuously differentiable functions. See ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("this previous blog post")]#text(" for more on these sorts of regularity classes. The reason for the terminology ")#mi("{C^{1,1}}")#text(" in the above definition is that ")#mi("{C^{1,1}}")#text(" regularity is essentially the minimal regularity for which one has the Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f(x) = f(x_0) + \\nabla f(x_0) \\cdot (x-x_0) + O(\\left|x-x_0\\right|^2)", block: true)]]

#text("for any ")#mi("{x_0}")#text(" in the domain of ")#mi("{f}")#text(", and any ")#mi("{x}")#text(" sufficiently close to ")#mi("{x_0}")#text("; note that the asymptotic ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" is of this form.")
]

#text("We now estimate various expressions in a ")#mi("{C^{1,1}}")#text(" local group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-4a630b8e79a0cd2fbae3>#text(" Let ")#mi("{V}")#text(" be a ")#mi("{C^{1,1}}")#text(" local group. Throughout this exercise, the implied constants in the ")#mi("{O()}")#text(" notation can depend on ")#mi("{V}")#text(", but not on parameters such as ")#mi("{x, y, \\epsilon, k, n}")#text(".")

#list(
[#text("(i) Show that there exists an ")#mi("{\\epsilon>0}")#text(" such that one has")

#metadata(none) <tao-49a48456c76d5fd456b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("x_1 \\ast \\ldots \\ast x_k = x_1 + \\ldots + x_k + O( \\sum_{1 \\leq i < j \\leq k} \\left|x_i\\right| \\left|x_j\\right| )", block: true)]]

#text("whenever ")#mi("{k \\geq 1}")#text(" and ")#mi("{x_1,\\ldots,x_k \\in V}")#text(" are such that ")#tao-math("{\\sum_{i=1}^k \\left|x_i\\right| \\leq \\epsilon}", block: false)#text(", and the implied constant is uniform in ")#mi("{k}")#text(". Here and in the sequel we adopt the convention that a statement such as ")#link(<tao-49a48456c76d5fd456b7>)[#text("(5)")]#text(" is automatically false unless all expressions in that statement are well-defined. (")#emph[#text("Hint:")]#text(" induct on ")#mi("{k}")#text(" using ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(". It is best to replace the asymptotic ")#mi("{O()}")#text(" notation by explicit constants ")#mi("{C}")#text(" in order to ensure that such constants remain uniform in ")#mi("{k}")#text(".) In particular, one has the crude estimate")

#align(center)[#tao-fit-display[#tao-math("x_1 \\ast \\ldots \\ast x_k = O( \\sum_{i=1}^k \\left|x_i\\right| )", block: true)]]

#text("under the same hypotheses as above.")],
[#text("(ii) Show that one has")

#align(center)[#tao-fit-display[#tao-math("x^{\\ast -1} = -x + O( \\left|x\\right|^2 )", block: true)]]

#text("for ")#mi("{x}")#text(" sufficiently close to the origin.")],
[#text("(iii) Show that")

#align(center)[#tao-fit-display[#tao-math("x \\ast y \\ast x^{\\ast -1} \\ast y^{\\ast -1} = O( \\left|x\\right| \\left|y\\right| )", block: true)]]

#text("for ")#mi("{x,y}")#text(" sufficiently close to the origin. (")#emph[#text("Hint:")]#text(" first show that ")#tao-math("{x \\ast y = y \\ast x + O( \\left|x\\right| \\left|y\\right| )}", block: false)#text(", then express ")#mi("{x \\ast y}")#text(" as the product of ")#mi("{x \\ast y \\ast x^{\\ast -1} \\ast y^{\\ast -1}}")#text(" and ")#mi("{y \\ast x}")#text(".)")],
[#text("(iv) Show that")

#align(center)[#tao-fit-display[#tao-math("x \\ast y \\ast x^{\\ast -1} = y + O( \\left|x\\right| \\left|y\\right| )", block: true)]]

#text("whenever ")#mi("{x, y}")#text(" are sufficiently close to the origin.")],
[#text("(v) Show that")

#align(center)[#tao-fit-display[#tao-math("y \\ast x^{\\ast -1}, x^{\\ast -1} \\ast y = O( \\left|x-y\\right| )", block: true)]]

#text("whenever ")#mi("{x, y}")#text(" are sufficiently close to the origin.")],
[#text("(vi) Show that there exists an ")#mi("{\\epsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("x_1 \\ast \\ldots \\ast x_k = y_1 \\ast \\ldots \\ast y_k + O( \\sum_{i=1}^k \\left|x_i-y_i\\right| )", block: true)]]

#text("whenever ")#mi("{k \\geq 1}")#text(" and ")#mi("{x_1,\\ldots,x_k, y_1,\\ldots,y_k}")#text(" are such that ")#tao-math("{\\sum_{i=1}^k \\left|x_i\\right|, \\sum_{j=1}^k \\left|y_i\\right| \\leq \\epsilon}", block: false)#text(".")],
[#text("(vii) Show that there exists an ")#mi("{\\epsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\left|n\\right| \\left|x-y\\right| \\leq \\left|x^{\\ast n} - y^{\\ast n}\\right| \\leq 2 \\left|n\\right| \\left|x-y\\right|", block: true)]]

#text("for all ")#mi("{n \\in {\\bf Z}}")#text(" and ")#mi("{x,y \\in {\\bf R}^d}")#text(" such that ")#tao-math("{\\left|nx\\right|, \\left|ny\\right| \\leq \\epsilon}", block: false)#text(", where ")#mi("{x^{\\ast n} = x \\ast \\ldots \\ast x}")#text(" is the product of ")#mi("{n}")#text(" copies of ")#mi("{x}")#text(" (assuming of course that this product is well-defined) for ")#mi("{n \\geq 0}")#text(", and ")#mi("{x^{\\ast -n} := (x^{\\ast n})^{\\ast -1}}")#text(".")],
[#text("(viii) Show that there exists an ")#mi("{\\epsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("(xy)^{\\ast n} = x^{\\ast n} y^{\\ast n} + O( \\left|n\\right|^2 \\left|x\\right| \\left|y\\right| )", block: true)]]

#text("for all ")#mi("{n \\in {\\bf Z}}")#text(" and ")#mi("{x,y \\in {\\bf R}^d}")#text(" such that ")#tao-math("{\\left|nx\\right|, \\left|ny\\right| \\leq \\epsilon}", block: false)#text(". (")#emph[#text("Hint:")]#text(" do the case when ")#mi("{n}")#text(" is positive first. In that case, express ")#mi("{x^{\\ast -n} \\ast (xy)^{\\ast n}}")#text(" as the product of ")#mi("{n}")#text(" conjugates of ")#mi("{y}")#text(" by various powers of ")#mi("{x}")#text(".)")]
)
]

#text("We can now define the ")#emph[#text("exponential map")]#text(" ")#mi("{\\exp: V^{\\prime} \\rightarrow V}")#text(" on this ")#mi("{C^{1,1}}")#text(" local group by defining ")#metadata(none) <tao-ffc150be8aab612b8381>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\exp(x) := \\lim_{n \\rightarrow \\infty} (\\frac{1}{2^n} x)^{\\ast 2^n}")]]

#text("for any ")#mi("{x}")#text(" in a sufficiently small neighbourhood ")#mi("{V^{\\prime}}")#text(" of the origin in ")#mi("{V}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{V}")#text(" be a local ")#mi("{C^{1,1}}")#text(" group.")

#list(
[#text("(i) Show that if ")#mi("{V^{\\prime}}")#text(" is a sufficiently small neighbourhood of the origin in ")#mi("{V}")#text(", then the limit in ")#link(<tao-ffc150be8aab612b8381>)[#text("(6)")]#text(" exists for all ")#mi("{x \\in V^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" use the previous exercise to estimate the distance between ")#mi("{(\\frac{1}{2^n} x)^{\\ast 2^n}}")#text(" and ")#mi("{(\\frac{1}{2^{n+1}} x)^{\\ast 2^{n+1}}}")#text(".) Establish the additional estimate")

#metadata(none) <tao-8ad0a438e281bcd7e9d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\exp(x) = x + O(\\left|x\\right|^2).", block: true)]]],
[#text("(ii) Show that if ")#mi("{\\gamma: I \\rightarrow G}")#text(" is a smooth curve with ")#mi("{\\gamma(0)=1}")#text(", and ")#mi("{\\gamma^{\\prime}(0)}")#text(" is sufficiently small, then")

#align(center)[#tao-fit-display[#mitex("\\exp( \\gamma^{\\prime}(0) ) = \\lim_{n \\rightarrow \\infty} \\gamma(1/2^n)^{\\ast 2^n}.")]]],
[#text("(iii) Show that for all sufficiently small ")#mi("{x, y}")#text(", one has the bilipschitz property")

#align(center)[#tao-fit-display[#tao-math("\\left|(\\exp(x)-\\exp(y)) - (x-y)\\right| \\leq \\frac{1}{2} |x-y|.", block: true)]]

#text("Conclude in particular that for ")#mi("{V^{\\prime}}")#text(" sufficiently small, ")#mi("{\\exp}")#text(" is a homeomorphism between ")#mi("{V^{\\prime}}")#text(" and an open neighbourhood ")#mi("{\\exp(V^{\\prime})}")#text(" of the origin. (")#emph[#text("Hint:")]#text(" To show that ")#mi("{\\exp(V^{\\prime})}")#text(" contains a neighbourhood of the origin, use ")#link(<tao-8ad0a438e281bcd7e9d0>)[#text("(7)")]#text(" and the contraction mapping theorem.)")],
[#text("Show that")

#metadata(none) <tao-c8268a17f98e2f98757d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\exp(sx) \\ast \\exp(tx) = \\exp((s+t)x)")]]

#text("for ")#mi("{s,t \\in {\\bf R}}")#text(" and ")#mi("{x \\in {\\bf R}^d}")#text(" with ")#mi("{sx, tx}")#text(" sufficiently small. (")#emph[#text("Hint:")]#text(" first handle the case when ")#mi("{s,t \\in {\\bf Z}[\\frac{1}{2}]}")#text(" are dyadic numbers.)")],
[#text("(iv) Show that for any sufficiently small ")#mi("{x,y \\in {\\bf R}^d}")#text(", one has")

#metadata(none) <tao-559390f773129e9a9d49>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\exp(x+y) = \\lim_{n \\rightarrow \\infty} (\\exp(x/2^n) \\ast \\exp(y/2^n))^{\\ast 2^n}.")]]

#text("Then conclude the stronger estimate")

#metadata(none) <tao-3a51d1cdf15454cad5c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\exp(x+y) = \\lim_{n \\rightarrow \\infty} (\\exp(x/n) \\ast \\exp(y/n))^{\\ast n}.")]]],
[#text("(v) Show that for any sufficiently small ")#mi("{x,y \\in {\\bf R}^d}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\exp(x+y) = \\exp(x) \\ast \\exp(y) + O( \\left|x\\right| \\left|y\\right| ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the previous part, as well as (viii) of Exercise ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("9")]#text(".)")]
)
]

#text("Let us say that a ")#mi("{C^{1,1}}")#text(" local group is ")#emph[#text("radially homogeneous")]#text(" if one has ")#metadata(none) <tao-525eca1d5089dbdcbb67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("sx \\ast tx = (s+t)x")]]

#text("whenever ")#mi("{s,t \\in {\\bf R}}")#text(" and ")#mi("{x \\in {\\bf R}^d}")#text(" are such that ")#mi("{sx, tx}")#text(" are sufficiently small. (In particular, this implies that ")#mi("{x^{\\ast -1} = -x}")#text(" for sufficiently small ")#mi("{x}")#text(".) From the above exercise, we see that any ")#mi("{C^{1,1}}")#text(" local group ")#mi("{V}")#text(" can be made into a radially homogeneous ")#mi("{C^{1,1}}")#text(" local group ")#mi("{V^{\\prime}}")#text(" by first restricting to an open neighbourhood ")#mi("{\\exp(V^{\\prime})}")#text(" of the identity, and then applying the logarithmic homeomorphism ")#mi("{\\exp^{-1}}")#text(". Thus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8")]#text(" ")#metadata(none) <tao-114a8528ac63106c70e0>#text(" Every ")#mi("{C^{1,1}}")#text(" local group has a neighbourhood of the identity which is isomorphic (as a topological group) to a radially homogeneous ")#mi("{C^{1,1}}")#text(" local group.")
]

#text("Now we study the exponential map on global Lie groups. If ")#mi("{G}")#text(" is a global Lie group, and ")#mi("{{\\mathfrak g}}")#text(" is its Lie algebra, we define the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" on a global Lie group ")#mi("{G}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\exp( \\gamma^{\\prime}(0) ) := \\lim_{n \\rightarrow \\infty} \\gamma(1/2^n)^{2^n}")]]

#text("whenever ")#mi("{\\gamma: I \\rightarrow G}")#text(" is a smooth curve with ")#mi("{\\gamma(0)=1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{G}")#text(" be a global Lie group.")

#list(
[#text("(i) Show that the exponential map is well-defined. (")#emph[#text("Hint:")]#text(" First handle the case when ")#mi("{\\gamma^{\\prime}(0)}")#text(" is small, using the previous exercise, then bootstrap to larger values of ")#mi("{\\gamma^{\\prime}(0)}")#text(".)")],
[#text("(ii) Show that for all ")#mi("{x, y \\in {\\mathfrak g}}")#text(" and ")#mi("{s,t \\in {\\bf R}}")#text(", one has")

#metadata(none) <tao-8b66f07607fc48eee510>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\exp(sx) \\exp(tx) = \\exp((s+t)x)")]]

#text("and")

#metadata(none) <tao-0757ad61d84a3f0ca6db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\exp(x+y) = \\lim_{n \\rightarrow \\infty} (\\exp(x/n) \\exp(y/n))^{n}.")]]

#text("(")#emph[#text("Hint:")]#text(" again, begin with the case when ")#mi("{x, y}")#text(" are small.)")],
[#text("(iii) Show that the exponential map is continuous.")],
[#text("(iv) Show that for each ")#mi("{x \\in {\\mathfrak g}}")#text(", the function ")#mi("{t \\mapsto \\exp(tx)}")#text(" is the unique homomorphism from ")#mi("{{\\bf R}}")#text(" to ")#mi("{G}")#text(" that is differentiable at ")#mi("{t=0}")#text(" with derivative equal to ")#mi("{x}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Lie’s first theorem)")]#text(" Let ")#mi("{G}")#text(" be a Lie group. Then the exponential map is smooth. Furthermore, there is an open neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{{\\mathfrak g}}")#text(" and an open neighbourhood ")#mi("{V}")#text(" of the identity in ")#mi("{G}")#text(" such that the exponential map ")#mi("{\\exp}")#text(" is a diffeomorphism from ")#mi("{U}")#text(" to ")#mi("{V}")#text(".")
]

#emph[#text("Proof:")]#text(" We begin with the smoothness. From the homomorphism property we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\exp(tx) = (\\rho_{\\exp(tx)}^{left})_* x")]]

#text("for all ")#mi("{x \\in {\\mathfrak g}}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". If ")#mi("{x}")#text(" and ")#mi("{t}")#text(" are sufficiently small, and one uses a coordinate chart ")#mi("{\\phi}")#text(" near the origin, the function ")#mi("{f(t,x) := \\phi(\\exp(tx))}")#text(" then satisfies an ODE of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} f(t,x) = F( f(t,x), x )")]]

#text("for some smooth function ")#mi("{F}")#text(", with initial condition ")#mi("{f(0,x) = 0}")#text("; thus by the fundamental theorem of calculus we have ")#metadata(none) <tao-972e481b1ad7de2c243d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("f(t,x) = \\int_0^t F(f(t^{\\prime},x), x)\\ dt^{\\prime}.")]]

#text("Now let ")#mi("{k \\geq 0}")#text(". An application of the contraction mapping theorem (in the function space ")#mi("{L^\\infty_t C^k_x}")#text(" localised to small region of spacetime) then shows that ")#mi("{f}")#text(" lies in ")#mi("{L^\\infty_t C^k_x}")#text(" for small enough ")#mi("{t,x}")#text(", and by further iteration of the integral equation we then conclude that ")#mi("{f(t,x)}")#text(" is ")#mi("{k}")#text(" times continuously differentiable for small enough ")#mi("{t,x}")#text(". By ")#link(<tao-c8268a17f98e2f98757d>)[#text("(8)")]#text(" we then conclude that ")#mi("{\\exp}")#text(" is smooth everywhere.")

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\exp(tx)|_{t=0} = x")]]

#text("we see that the derivative of the exponential map at the origin is the identity map on ")#mi("{{\\mathfrak g}}")#text(". The second claim of the proposition thus follows from the inverse function theorem. ")#mi("\\Box")

#text("In view of this proposition, we see that given a vector space basis ")#mi("{X_1,\\ldots,X_d}")#text(" for the Lie algebra ")#mi("{{\\mathfrak g}}")#text(", we may obtain a smooth coordinate chart ")#mi("{\\phi: U \\rightarrow V}")#text(" for some neighbourhood ")#mi("{U}")#text(" of the identity and neighbourhood ")#mi("{V}")#text(" of the origin in ")#mi("{{\\bf R}^d}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi( \\exp( t_1 X_1 + \\ldots + t_d X_d ) ) := (t_1,\\ldots,t_d)")]]

#text("for sufficiently small ")#mi("{t_1,\\ldots,t_d \\in {\\bf R}}")#text(". These are known as ")#emph[#text("exponential coordinates of the first kind")]#text(". Although we will not use them much here, we also note that there are ")#emph[#text("exponential coordinates of the second kind")]#text(", in which the expression ")#mi("{\\exp(t_1 X_1 + \\ldots + t_d X_d)}")#text(" is replaced by the slight variant ")#mi("{\\exp(t_1 X_1) \\ldots \\exp(t_d X_d)}")#text(".")

#text("Using exponential coordinates of the first kind, we see that we may identify a local piece ")#mi("{U}")#text(" of the Lie group ")#mi("{G}")#text(" with the radially homogeneous ")#mi("{C^{1,1}}")#text(" local group ")#mi("{V}")#text(". In the next section, we will analyse such radially homogeneous ")#mi("{C^{1,1}}")#text(" groups further. For now, let us record some easy consequences of the existence of exponential coordinates. Define a ")#emph[#text("one-parameter subgroup")]#text(" of a topological group ")#mi("{G}")#text(" to be a continuous homomorphism ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(" from ")#mi("{{\\bf R}}")#text(" to ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Classification of one-parameter subgroups)")]#text(" Let ")#mi("{G}")#text(" be a Lie group. For any ")#mi("{X \\in {\\mathfrak g}}")#text(", show that the map ")#mi("{t \\mapsto \\exp(tX)}")#text(" is a one-parameter subgroup. Conversely, if ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(" is a one-parameter subgroup, there exists a unique ")#mi("{X \\in {\\mathfrak g}}")#text(" such that ")#mi("{\\phi(t) = \\exp(tX)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" mimic the proof of ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Proposition 1 of Notes 0")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Weak regularity implies strong regularity)")]#text(" ")#metadata(none) <tao-19b738c219c435150a1b>#text(" Let ")#mi("{G, H}")#text(" be global Lie groups, and let ")#mi("{\\Phi: G \\rightarrow H}")#text(" be a continuous homomorphism. Then ")#mi("{\\Phi}")#text(" is smooth.")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{\\Phi}")#text(" is a continuous homomorphism, it maps one-parameter subgroups of ")#mi("{G}")#text(" to one-parameter subgroups of ")#mi("{H}")#text(". Thus, for every ")#mi("{X \\in {\\mathfrak g}}")#text(", there exists a unique element ")#mi("{L(X) \\in {\\mathfrak h}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\Phi(\\exp(tX)) = \\exp(tL(X))")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". In particular, we see that ")#mi("{L}")#text(" is homogeneous: ")#mi("{L(sX) = sL(X)}")#text(" for all ")#mi("{X \\in {\\mathfrak g}}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(". Next, we observe using ")#link(<tao-559390f773129e9a9d49>)[#text("(9)")]#text(" and the fact that ")#mi("{\\Phi}")#text(" is a continuous homomorphism that for any ")#mi("{X, Y \\in {\\mathfrak g}}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("\\Phi(\\exp(t(X+Y)))  & = \\Phi( \\lim_{n\\rightarrow \\infty} (\\exp(tX/2^n) \\exp(tY/2^n))^{2^n} )", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\Phi(\\exp(tX/2^n)) \\Phi(\\exp(tY/2^n)))^{2^n}", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\exp(tL(X)/2^n) \\exp(tL(Y)/2^n))^{2^n}", block: true)



#tao-math(" & = \\exp( t(L(X)+L(Y)) )", block: true)
]

#text("and thus ")#mi("{L}")#text(" is additive:")

#align(center)[#tao-fit-display[#mitex("L(X+Y) = L(X)+L(Y).")]]

#text("We conclude that ")#mi("{L}")#text(" is a linear transformation from the finite-dimensional vector space ")#mi("{{\\mathfrak g}}")#text(" to the finite-dimensional vector space ")#mi("{{\\mathfrak h}}")#text(". In particular, ")#mi("{L}")#text(" is smooth. On the other hand, we have")

#align(center)[#tao-fit-display[#mitex("\\Phi(\\exp(X)) = \\exp(L(X)).")]]

#text("Since ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" and ")#mi("{\\exp: {\\mathfrak h} \\rightarrow H}")#text(" are diffeomorphisms near the origin, we conclude that ")#mi("{\\Phi}")#text(" is smooth in a neighbourhood of the identity. Using the homomorphism property (and the fact that the group operations are smooth for both ")#mi("{G}")#text(" and ")#mi("{H}")#text(") we conclude that ")#mi("{\\Phi}")#text(" is smooth everywhere, as required. ")#mi("\\Box")

#text("This fact has a pleasant corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Uniqueness of Lie structure)")]#text(" Any (global) topological group can be made into a Lie group in at most one manner. More precisely, given a topological group ")#mi("{G}")#text(", there is at most one smooth structure one can place on ")#mi("{G}")#text(" that makes the group operations smooth.")
]

#emph[#text("Proof:")]#text(" Suppose for sake of contradiction that one could find two different smooth structures on ")#mi("{G}")#text(" that make the group operations smooth, leading to two different Lie groups ")#mi("{G^{\\prime}, G^{\\prime\\prime}}")#text(" based on ")#mi("{G}")#text(". The identity map from ")#mi("{G^{\\prime}}")#text(" to ")#mi("{G^{\\prime\\prime}}")#text(" is a continuous homomorphism, and hence smooth by the preceding proposition; similarly for the inverse map from ")#mi("{G^{\\prime\\prime}}")#text(" to ")#mi("{G^{\\prime}}")#text(". This implies that the smooth structures coincide, and the claim follows. ")#mi("\\Box")

#text("Note that a general high-dimensional topological manifold may have more than one smooth structure, which may even be non-diffeomorphic to each other (as the example of ")#link("http://en.wikipedia.org/wiki/Exotic_sphere")[#text("exotic spheres")]#text(" demonstrates), so this corollary is not entirely vacuous.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{G}")#text(" be a connected (global) Lie group, let ")#mi("{H}")#text(" be another (global) Lie group, and let ")#mi("{\\Phi: G \\rightarrow H}")#text(" be a continuous homomorphism (which is thus smooth by Proposition ")#link(<tao-19b738c219c435150a1b>)[#text("10")]#text("). Show that ")#mi("{\\Phi}")#text(" is uniquely determined by the derivative map ")#mi("{D\\Phi(1): {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(". In other words, if ")#mi("{\\Phi^{\\prime}: G \\rightarrow H}")#text(" is another continuous homomorphism with ")#mi("{D\\Phi(1)=D\\Phi^{\\prime}(1)}")#text(", then ")#mi("{\\Phi = \\Phi^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" first prove this in a small neighbourhood of the origin. What group does this neighbourhood generate?) What happens if ")#mi("{G}")#text(" is not connected?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Weak regularity implies strong regularity, local version)")]#text(" ")#metadata(none) <tao-8ee534170dedf0d82069>#text(" Let ")#mi("{G, H}")#text(" be local Lie groups, and let ")#mi("{\\Phi: G \\rightarrow H}")#text(" be a continuous homomorphism. Show that ")#mi("{\\Phi}")#text(" is smooth in a neighbourhood of the identity in ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Local Lie implies Lie)")]#text(" ")#metadata(none) <tao-caa22ef5a129da7f1dd3>#text(" Let ")#mi("{G}")#text(" be a global topological group. Suppose that there is an open neighbourhood ")#mi("{U}")#text(" of the identity such that the local group ")#mi("{G\\downharpoonright_U}")#text(" can be given the structure of a local Lie group. Show that ")#mi("{G}")#text(" can be given the structure of a global Lie group. (")#emph[#text("Hint:")]#text(" We already have at least one coordinate chart on ")#mi("{G}")#text("; translate it around to create an atlas of such charts. To show compatibility of the charts and global smoothness of the group, one needs to show that the conjugation maps ")#mi("{x \\mapsto gxg^{-1}}")#text(" are smooth near the origin for any ")#mi("{g \\in G}")#text(". To prove this, use Exercise ")#link(<tao-8ee534170dedf0d82069>)[#text("14")]#text(".)")
]

#heading(level: 1)[#strong[#text(" — 5. The Baker-Campbell-Hausdorff formula — ")]]

#text("We now study radially homogeneous ")#mi("{C^{1,1}}")#text(" local groups in more detail. We will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Baker-Campbell-Hausdorff formula, qualitative version)")]#text(" ")#metadata(none) <tao-833a61955631ab7a5609>#text(" Let ")#mi("{V \\subset {\\bf R}^d}")#text(" be a radially homogeneous ")#mi("{C^{1,1}}")#text(" local group. Then the group operation ")#mi("{\\ast}")#text(" is real analytic near the origin. In particular, after restricting ")#mi("{V}")#text(" to a sufficiently small neighbourhood of the origin, one obtains a local Lie group.")
]

#text("We will in fact give a more precise formula for ")#mi("{\\ast}")#text(", known as the ")#emph[#text("Baker-Campbell-Haudorff-Dynkin formula")]#text(", in the course of proving Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-0c1c541af9cc252a1c75>#text(" In the case where ")#mi("{V}")#text(" comes from viewing a general linear group ")#mi("{GL_n({\\bf C})}")#text(" in local exponential coordinates, the group operation ")#mi("{\\ast}")#text(" is given by ")#mi("{x \\ast y = \\log(\\exp(x) \\exp(y))}")#text(" for sufficiently small ")#mi("{x,y \\in M_n({\\bf C})}")#text(". Thus, a corollary of Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(" is that this map is real analytic.")
]

#text("We begin the proof of Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(". Throughout this section, ")#mi("{V \\subset {\\bf R}^d}")#text(" is a fixed radially homogeneous ")#mi("{C^{1,1}}")#text(" local group. We will need some variants of the basic bound ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Lipschitz bounds)")]#text(" ")#metadata(none) <tao-8ac1ef5381caf75418d7>#text(" If ")#mi("{x,y,z \\in V}")#text(" are sufficiently small, establish the bounds ")#metadata(none) <tao-723013d616bc63f2582f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("x \\ast y = x + y + O( \\left|x+y\\right| \\left|y\\right| )", block: true)]]

#metadata(none) <tao-d8150a8f796972239933>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("x \\ast y = x + y + O( \\left|x+y\\right| \\left|x\\right| )", block: true)]]

#metadata(none) <tao-fc60dfc45dcf693f71be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("x \\ast y = x \\ast z + O( \\left|y-z\\right| )", block: true)]]

#text("and ")#metadata(none) <tao-de3c66d3e51b7c1d670e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("y \\ast x = z \\ast x + O( \\left|y-z\\right| ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" to prove ")#link(<tao-723013d616bc63f2582f>)[#text("(15)")]#text(", start with the identity ")#mi("{(x \\ast y) \\ast (-y) = x}")#text(".)")
]

#text("Now we exploit the radial homogeneity to describe the conjugation operation ")#mi("{y \\mapsto x \\ast y \\ast (-x)}")#text(" as a linear map:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Adjoint representation)")]#text(" For all ")#mi("{x}")#text(" sufficiently close to the origin, there exists a linear transformation ")#mi("{\\text{Ad}_x: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" such that ")#mi("{x \\ast y \\ast (-x) = \\text{Ad}_x(y)}")#text(" for all ")#mi("{y}")#text(" sufficiently close to the origin.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Using the matrix example from Remark ")#link(<tao-0c1c541af9cc252a1c75>)[#text("7")]#text(", we are asserting here that")

#align(center)[#tao-fit-display[#mitex("\\exp(x) \\exp(y) \\exp(-x) = \\exp( \\text{Ad}_x(y) )")]]

#text("for some linear transform ")#mi("{\\text{Ad}_x(y)}")#text(" of ")#mi("{y}")#text(", and all sufficiently small ")#mi("{x,y}")#text(". Indeed, using the basic matrix identity ")#mi("{\\exp(AxA^{-1}) = A\\exp(x)A^{-1}}")#text(" for invertible ")#mi("{A}")#text(" (coming from the fact that the conjugation map ")#mi("{x \\mapsto A x A^{-1}}")#text(" is a continuous ring homomorphism) we see that we may take ")#mi("{\\text{Ad}(x) = \\exp(x) y \\exp(-x)}")#text(" here.")
]

#emph[#text("Proof:")]#text(" Fix ")#mi("{x}")#text(". The map ")#mi("{y \\mapsto x \\ast y \\ast (-x)}")#text(" is continuous near the origin, so it will suffice to establish additivity, in the sense that")

#align(center)[#tao-fit-display[#mitex("x \\ast (y+z) \\ast (-x) = (x \\ast y \\ast (-x)) + (x \\ast z \\ast (-x))")]]

#text("for ")#mi("{y,z}")#text(" sufficiently close to the origin.")

#text("Let ")#mi("{n}")#text(" be a large natural number. Then from ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("(y+z) = (\\frac{1}{n} y + \\frac{1}{n} z)^{\\ast n}.")]]

#text("Conjugating this by ")#mi("{x}")#text(", we see that")

#tao-aligned(keep: true)[


#tao-math("x \\ast (y+z) \\ast (-x)  & = (x \\ast (\\frac{1}{n} y + \\frac{1}{n} z) \\ast (-x))^n", block: true)



#tao-math(" & = n (x \\ast (\\frac{1}{n} y + \\frac{1}{n} z) \\ast (-x)).", block: true)
]

#text("But from ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} y + \\frac{1}{n} z = \\frac{1}{n} y \\ast \\frac{1}{n} z + O( \\frac{1}{n^2} )")]]

#text("and thus (by Exercise ")#link(<tao-8ac1ef5381caf75418d7>)[#text("16")]#text(")")

#align(center)[#tao-fit-display[#mitex("x \\ast (\\frac{1}{n} y + \\frac{1}{n} z) \\ast (-x) = x \\ast \\frac{1}{n} y \\ast \\frac{1}{n} z \\ast (-x) + O( \\frac{1}{n^2} ).")]]

#text("But if we split ")#mi("{x \\ast \\frac{1}{n} y \\ast \\frac{1}{n} z \\ast (-x)}")#text(" as the product of ")#mi("{x \\ast \\frac{1}{n} y \\ast (-x) }")#text(" and ")#mi("{x \\ast \\frac{1}{n} z \\ast (-x)}")#text(" and use ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("x \\ast \\frac{1}{n} y \\ast \\frac{1}{n} z \\ast (-x) = x \\ast \\frac{1}{n} y \\ast (-x) + x \\ast \\frac{1}{n} z \\ast (-x) + O(\\frac{1}{n^2}).")]]

#text("Putting all this together we see that")

#tao-aligned(keep: true)[


#tao-math("x \\ast (y+z) \\ast (-x)  & = n( x \\ast \\frac{1}{n} y \\ast (-x) + x \\ast \\frac{1}{n} z \\ast (-x) + O(\\frac{1}{n^2}) )", block: true)



#tao-math(" & = x \\ast y \\ast (-x) + x \\ast z \\ast (-x) + O(\\frac{1}{n});", block: true)
]

#text("sending ")#mi("{n \\rightarrow \\infty}")#text(" we obtain the claim. ")#mi("\\Box")

#text("From ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{Ad}_x - I \\right\\|_{op} = O(\\left|x\\right|)", block: true)]]

#text("for ")#mi("{x}")#text(" sufficiently small. Also from the associativity property we see that ")#metadata(none) <tao-a116a1e6cc53a1c07bd1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\text{Ad}_{x\\ast y} = \\text{Ad}_x \\text{Ad}_y")]]

#text("for all ")#mi("{x,y}")#text(" sufficiently small. Combining these two properties (and using ")#link(<tao-723013d616bc63f2582f>)[#text("(15)")]#text(") we conclude in particular that ")#metadata(none) <tao-b6b7e9c088359e36f5de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\| \\text{Ad}_x - \\text{Ad}_y \\right\\|_{op} = O(\\left|x-y\\right|)", block: true)]]

#text("for ")#mi("{x,y}")#text(" sufficiently small. Thus we see that ")#mi("{Ad}")#text(" is a (locally) continuous linear representation. In particular, ")#mi("{t \\mapsto \\text{Ad}_{tx}}")#text(" is a (locally) continuous homomorphism into a linear group, and so (by ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Proposition 1 of Notes 0")]#text(") we have the ")#emph[#text("Hadamard lemma")]

#align(center)[#tao-fit-display[#mitex("\\text{Ad}_x = \\exp( \\text{ad}_x )")]]

#text("for all sufficiently small ")#mi("{x}")#text(", where ")#mi("{\\text{ad}_x: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is the linear transformation")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_x = \\frac{d}{dt} \\text{Ad}_{tx} |_{t=0}.")]]

#text("From ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(21)")]#text(", ")#link(<tao-b6b7e9c088359e36f5de>)[#text("(20)")]#text(", ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\text{Ad}_{tx} \\text{Ad}_{ty} = \\text{Ad}_{t(x+y)} + O(\\left|t\\right|^2)", block: true)]]

#text("for ")#mi("{x,y,t}")#text(" sufficiently small, and so by the product rule we have")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_{x+y} = \\text{ad}_x + \\text{ad}_y.")]]

#text("Also we clearly have ")#mi("{\\text{ad}_{tx} = t \\text{ad}_x}")#text(" for ")#mi("{x, t}")#text(" small. Thus we see that ")#mi("{\\text{ad}_x}")#text(" is linear in ")#mi("{x}")#text(", and so we have ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\text{ad}_x y = [x,y]")]]

#text("for some bilinear form ")#mi("{[,]: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(".")

#text("One can show that this bilinear form in fact defines a Lie bracket (i.e. it is anti-symmetric and obeys the Jacobi identity), but for now, all we need is that it is manifestly real analytic (since all bilinear forms are polynomial and thus analytic). In particular ")#mi("{\\text{ad}_x}")#text(" and ")#mi("{\\text{Ad}_x}")#text(" depend analytically on ")#mi("{x}")#text(".")

#text("We now give an important approximation to ")#mi("{x\\ast y}")#text(" in the case when ")#mi("{y}")#text(" is small:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14")]#text(" ")#metadata(none) <tao-8e76e9a00cae1534d7e0>#text(" For ")#mi("{x,y}")#text(" sufficiently small, we have")

#align(center)[#tao-fit-display[#tao-math("x \\ast y = x + F(\\text{Ad}_x) y + O(\\left|y\\right|^2)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(z) := \\frac{z \\log z}{z-1}.")]]
]

#emph[#text("Proof:")]#text(" If we write ")#mi("{z := x\\ast y - x}")#text(", then ")#tao-math("{z = O(\\left|y\\right|)}", block: false)#text(" (by ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(") and")

#align(center)[#tao-fit-display[#mitex("(-x) \\ast (x+z) = y.")]]

#text("We will shortly establish the approximation ")#metadata(none) <tao-3fc7c96a56b6e20ca727>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("(-x) \\ast (x+z) = \\frac{1-\\exp(-\\text{ad}_x)}{\\text{ad}_x} z + O( \\left|z\\right|^2 );", block: true)]]

#text("inverting")

#align(center)[#tao-fit-display[#mitex("\\frac{1-\\exp(-\\text{ad}_x)}{\\text{ad}_x} = \\frac{\\text{Ad}_x - 1}{\\text{Ad}_x \\log \\text{Ad}_x}")]]

#text("we obtain the claim.")

#text("It remains to verify ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(22)")]#text(". Let ")#mi("{n}")#text(" be a large natural number. We can expand the left-hand side of ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(22)")]#text(" as a telescoping series ")#metadata(none) <tao-d2dae6d1b4625413eade>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{j=0}^{n-1} (-\\frac{j+1}{n} x) \\ast (\\frac{j+1}{n} x + \\frac{j+1}{n} z) - (-\\frac{j}{n} x) \\ast (\\frac{j}{n} x + \\frac{j}{n} z).")]]

#text("Using ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(11)")]#text(", the first summand can be expanded as")

#align(center)[#tao-fit-display[#mitex("(-\\frac{j}{n} x) \\ast (-\\frac{x}{n})\\ast (\\frac{x}{n} + \\frac{z}{n}) \\ast (\\frac{j}{n} x + \\frac{j}{n} z).")]]

#text("From ")#link(<tao-723013d616bc63f2582f>)[#text("(15)")]#text(" one has ")#tao-math("{(-\\frac{x}{n}) \\ast (\\frac{x}{n} + \\frac{z}{n}) = \\frac{z}{n} + O( \\frac{\\left|z\\right|}{n^2} )}", block: false)#text(", so by ")#link(<tao-fc60dfc45dcf693f71be>)[#text("(17)")]#text(", ")#link(<tao-de3c66d3e51b7c1d670e>)[#text("(18)")]#text(" we can write the preceding expression as")

#align(center)[#tao-fit-display[#tao-math("(-\\frac{j}{n} x) \\ast \\frac{z}{n} \\ast (\\frac{j}{n} x + \\frac{j}{n} z) + O( \\frac{\\left|z\\right|}{n^2} )", block: true)]]

#text("which by definition of ")#mi("{\\text{Ad}}")#text(" can be rewritten as ")#metadata(none) <tao-882faefe28371f8145b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("(\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n}) \\ast (-\\frac{j}{n} x) \\ast (\\frac{j}{n} x + \\frac{j}{n} z) + O( \\frac{\\left|z\\right|}{n^2} ).", block: true)]]

#text("From ")#link(<tao-723013d616bc63f2582f>)[#text("(15)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("(-\\frac{j}{n} x) \\ast (\\frac{j}{n} x + \\frac{j}{n} z) = O( \\left|z\\right| )", block: true)]]

#text("while from ")#link(<tao-b6b7e9c088359e36f5de>)[#text("(20)")]#text(" one has ")#tao-math("{\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n} = O( \\left|z\\right|/n )}", block: false)#text(", hence from ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text(" we can rewrite ")#link(<tao-882faefe28371f8145b8>)[#text("(24)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n} + (-\\frac{j}{n} x) * (\\frac{j}{n} x + \\frac{j}{n} z) + O(\\frac{\\left|z\\right|^2}{n}) + O( \\frac{\\left|z\\right|}{n^2} ).", block: true)]]

#text("Inserting this back into ")#link(<tao-d2dae6d1b4625413eade>)[#text("(23)")]#text(", we can thus write the left-hand side of ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(22)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{j=0}^{n-1} \\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n}) + O( \\left|z\\right|^2 ) + O( \\frac{\\left|z\\right|}{n} ).", block: true)]]

#text("Writing ")#mi("{\\text{Ad}_{-\\frac{j}{n} x} = \\exp( - \\frac{j}{n} \\text{ad}_x )}")#text(", and then letting ")#mi("{n \\rightarrow \\infty}")#text(", we conclude (from the convergence of the Riemann sum to the Riemann integral) that")

#align(center)[#tao-fit-display[#tao-math("(-x) \\ast (x+z) = \\int_0^1 \\exp(-t \\text{ad}_x) z\\ dt + O( \\left|z\\right|^2 )", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" In the matrix case, the key computation is to show that")

#align(center)[#tao-fit-display[#tao-math("\\exp( -x ) \\exp( x+z ) = 1 + \\frac{1-\\exp(-\\text{ad}_x)}{\\text{ad}_x} z + O( \\left|z\\right|^2 ).", block: true)]]

#text("To see this, we can use the fundamental theorem of calculus to write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("1 + \\int_0^1 \\frac{d}{dt} (\\exp(-tx) \\exp(t(x+z)))\\ dt.")]]

#text("Since ")#mi("{\\frac{d}{dt} \\exp(-tx) = \\exp(-tx) (-x)}")#text(" and ")#mi("{\\frac{d}{dt} \\exp(t(x+z)) = (x+z) \\exp(t(x+z))}")#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("1 + \\int_0^1 \\exp(-tx) z \\exp(t(x+z))\\ dt.")]]

#text("Since ")#tao-math("{\\exp(t(x+z)) = \\exp(tx) + O(\\left|z\\right|)}", block: false)#text(", this becomes")

#align(center)[#tao-fit-display[#tao-math("1 + \\int_0^1 \\exp(-tx) z \\exp(tx)\\ dt + O(\\left|z\\right|^2);", block: true)]]

#text("since ")#mi("{\\exp(-tx) z \\exp(tx) = \\exp(-t \\text{ad}_x) z}")#text(", we obtain the desired claim.")
]

#text("We can integrate the above formula to obtain an exact formula for ")#mi("{\\ast}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15 (Baker-Campbell-Hausdorff-Dynkin formula)")]#text(" For ")#mi("{x, y}")#text(" sufficiently small, one has")

#align(center)[#tao-fit-display[#mitex("x \\ast y = x + \\int_0^1 F( \\text{Ad}_x \\text{Ad}_{ty} ) y\\ dt.")]]
]

#text("The right-hand side is clearly real analytic in ")#mi("{x}")#text(" and ")#mi("{y}")#text(", and Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(" follows.")

#emph[#text("Proof:")]#text(" Let ")#mi("{n}")#text(" be a large natural number. We can express ")#mi("{x\\ast y}")#text(" as the telescoping sum")

#align(center)[#tao-fit-display[#mitex("x + \\sum_{j=0}^{n-1} x \\ast (\\frac{j+1}{n} y) - x \\ast (\\frac{j}{n} y).")]]

#text("From ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(11)")]#text(" followed by Lemma ")#link(<tao-8e76e9a00cae1534d7e0>)[#text("14")]#text(" and ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(21)")]#text(", one has")

#tao-aligned(keep: true)[


#tao-math("x \\ast (\\frac{j+1}{n} y)  & = x \\ast (\\frac{j}{n} y) \\ast \\frac{y}{n}", block: true)



#tao-math(" & = x \\ast (\\frac{j}{n} y) + F( \\text{Ad}_x \\text{Ad}_{\\frac{j}{n} y} ) \\frac{y}{n} + O( \\frac{1}{n^2} ).", block: true)
]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("x\\ast y = x + \\frac{1}{n} \\sum_{j=0}^{n-1} F( \\text{Ad}_x \\text{Ad}_{\\frac{j}{n} y} ) y + O( \\frac{1}{n} ).")]]

#text("Sending ")#mi("{n \\rightarrow \\infty}")#text(", so that the Riemann sum converges to a Riemann integral, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-8e924025a26c584ad4ac>#text(" Use the Taylor-type expansion")

#align(center)[#tao-fit-display[#mitex("F(z) = 1 - \\frac{1/z - 1}{2} + \\frac{(1/z-1)^2}{3} - \\frac{(1/z-1)^3}{4} + \\ldots")]]

#text("to obtain the explicit expansion")

#align(center)[#tao-fit-display[#mitex("x \\ast y = x + \\sum_{n=0}^\\infty \\frac{(-1)^m}{n+1}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{\\stackrel{r_i,s_i \\geq 0}{(r_i,s_i) \\neq (0,0)}} \\frac{(\\text{ad}_y)^{r_1} (\\text{ad}_x)^{s_1} \\ldots (\\text{ad}_y)^{r_n} (\\text{ad}_x)^{s_n} }{r_1! s_1! \\ldots r_n! s_n! (r_1+\\ldots+r_n+1)} y")]]

#text("where ")#mi("{m := n+r_1+\\ldots+r_n+s_1+\\ldots+s_n+1}")#text(", and show that the series is absolutely convergent for ")#mi("{x, y}")#text(" small enough. Invert this to obtain the alternate expansion")

#align(center)[#tao-fit-display[#mitex("x \\ast y = y + \\sum_{n=0}^\\infty \\frac{(-1)^n}{n+1}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{\\stackrel{r_i,s_i \\geq 0}{(r_i,s_i) \\neq (0,0)}} \\frac{(\\text{ad}_x)^{r_1} (\\text{ad}_y)^{s_1} \\ldots (\\text{ad}_x)^{r_n} (\\text{ad}_y)^{s_n} }{r_1! s_1! \\ldots r_n! s_n! (r_1+\\ldots+r_n+1)} x.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{V}")#text(" be a radially homogeneous ")#mi("{C^{1,1}}")#text(" local group. By Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(", an open neighbourhood of the origin in ")#mi("{V}")#text(" has the structure of a local Lie group, and thus by Exercise ")#link(<tao-6f1eb246f9c696c29499>)[#text("8")]#text(" is associated to a Lie algebra. Show that this Lie algebra is isomorphic to ")#mi("{{\\bf R}^d}")#text(" and the Lie bracket ")#mi("{[,]}")#text(" is given by ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(21)")]#text(". Note that this establishes ")#emph[#text("a posteriori")]#text(" the fact that the bracket ")#mi("{[,]}")#text(" occurring in ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(21)")]#text(" is anti-symmetric and obeys the Jacobi identity.")
]

#text("We now record some consequences of the Baker-Campbell-Hausdorff formula.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Lie groups are analytic)")]#text(" Let ")#mi("{G}")#text(" be a global Lie group. Show that ")#mi("{G}")#text(" is a real analytic manifold (i.e. one can find an atlas of smooth coordinate charts whose transition maps are all real analytic), and that the group operations are also real analytic (i.e. they are real analytic when viewed in the above-mentioned coordinate charts). Furthermore, show that any continuous homomorphism between Lie groups is also real analytic.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Lie’s second theorem)")]#text(" Let ")#mi("{G, H}")#text(" be global Lie groups, and let ")#mi("{\\phi: {\\mathfrak g} \\rightarrow {\\mathfrak h}}")#text(" be a Lie algebra homomorphism. Show that there exists an open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" and a homomorphism ")#mi("{\\Phi: U \\rightarrow H}")#text(" from the local Lie group ")#mi("{G\\downharpoonright_U}")#text(" to ")#mi("{H}")#text(" such that ")#mi("{D\\Phi(1) = \\phi}")#text(". If ")#mi("{G}")#text(" is connected and simply connected, show that one can take ")#mi("{U}")#text(" to be all of ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Lie’s third theorem)")]#text(" ")#metadata(none) <tao-b1e99324505bd32da0e1>#text(" ")#link("http://en.wikipedia.org/wiki/Ado's_theorem")[#text("Ado’s theorem")]#text(" asserts that every finite-dimensional Lie algebra is isomorphic to a subalgebra of ")#mi("{{\\mathfrak gl}_n({\\bf R})}")#text(" for some ")#mi("{n}")#text(". This (somewhat difficult) theorem and its proof is discussed in ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous blog post")]#text(". Assuming Ado’s theorem as a “black box”, conclude the following claims:")

#list(
[#text("(i) (Lie’s third theorem, local version) Every finite-dimensional Lie algebra is isomorphic to the Lie algebra of some local Lie group.")],
[#text("(ii) Every local or global Lie group has a neighbourhood of the identity that is isomorphic to a local ")#emph[#text("linear")]#text(" Lie group (i.e. a local Lie group contained in ")#mi("{GL_n({\\bf R})}")#text(" or ")#mi("{GL_n({\\bf C})}")#text(" for some ")#mi("{n}")#text(").")],
[#text("(iii) (Lie’s third theorem, global version) Every finite-dimensional Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to the Lie algebra of some global Lie group. (")#emph[#text("Hint:")]#text(" from (i) and (ii), one may identify ")#mi("{{\\mathfrak g}}")#text(" with the Lie algebra of a local linear Lie group. Now consider the space of all smooth curves in the ambient linear group that are everywhere “tangent” to this local linear Lie group modulo “homotopy”, and use this to build the global Lie group.)")],
[#text("(iv) (Lie’s third theorem, simply connected version) Every finite-dimensional Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is isomorphic to the Lie algebra of some global connected, simply connected Lie group. Furthermore, this Lie group is unique up to isomorphism.")],
[#text("(v) Show that every local Lie group ")#mi("{G}")#text(" has a neighbourhood of the identity that is isomorphic to a neighbourhood of the identity of a global connected, simply connected Lie group. Furthermore, this Lie group is unique up to isomorphism.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" One does not need the full strength of Ado’s theorem to establish conclusion (i) of the above exercise. Indeed, it suffices to show that the operation ")#mi("{\\ast}")#text(" defined in Exercise ")#link(<tao-8e924025a26c584ad4ac>)[#text("17")]#text(" is associative near the origin. To do this, it suffices to verify associativity in the sense of formal power series; and then by abstract nonsense one can lift up to the free Lie algebra on ")#mi("{d}")#text(" generators, and then down to the free ")#emph[#text("nilpotent")]#text(" Lie algebra on ")#mi("{d}")#text(" generators and of some arbitrary finite step ")#mi("{s}")#text(", which one can verify to be a finite dimensional Lie algebra. Applying Ado’s theorem for the special case of nilpotent Lie algebras (which is easier to establish than the general case of Ado’s theorem, as discussed in ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous blog post")]#text("), one can identify this nilpotent Lie algebra with a subalgebra of ")#mi("{{\\mathfrak g}_n({\\bf R})}")#text(" for some ")#mi("{n}")#text(", and then one can argue as in the above exercise to conclude. However, I do not know how to establish conclusions (ii), (iii) or (iv) without using Ado’s theorem in full generality (and (ii) is in fact ")#emph[#text("equivalent")]#text(" to this theorem, at least in characteristic ")#mi("{0}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" Lie’s three theorems can be interpreted as establishing an ")#link("http://en.wikipedia.org/wiki/Equivalence_of_categories")[#text("equivalence")]#text(" between three different categories: the category of finite-dimensional Lie algebras; the category of local Lie groups (or more precisely, the category of local Lie group ")#link("http://en.wikipedia.org/wiki/Germ_(mathematics)")[#text("germs")]#text(", formed by identifying local Lie groups that are identical near the origin); and the category of global connected, simply connected Lie groups. See ")#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("this blog post")]#text(" for further discussion.")
]

#text("The fact that we were able to establish the Baker-Campbell-Hausdorff formula at the ")#mi("{C^{1,1}}")#text(" regularity level will be useful for the purposes of proving results related to Hilbert’s fifth problem. In particular, we have the following criterion for a group to be Lie (very much in accordance with the “weak regularity implies strong regularity for group-like objects” principle):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Criterion for Lie structure)")]#text(" ")#metadata(none) <tao-a6623e674352bda12d9c>#text(" Let ")#mi("{G}")#text(" be a topological group. Show that ")#mi("{G}")#text(" is Lie if and only if there is a neighbourhood of the identity in ")#mi("{G}")#text(" which is isomorphic (as a topological group) to a ")#mi("{C^{1,1}}")#text(" local group.")
]

#emph[#text("Proof:")]#text(" The “only if” direction is trivial. For the “if” direction, combine Corollary ")#link(<tao-114a8528ac63106c70e0>)[#text("8")]#text(" with Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("12")]#text(" and Exercise ")#link(<tao-caa22ef5a129da7f1dd3>)[#text("15")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" Informally, Lemma ")#link(<tao-a6623e674352bda12d9c>)[#text("16")]#text(" asserts that ")#mi("{C^{1,1}}")#text(" regularity can automatically be upgraded to smooth (")#mi("{C^\\infty}")#text(") or even real analytic (")#mi("{C^\\omega}")#text(") regularity for topological groups. In contrast, note that a locally Euclidean group has neighbourhoods of the identity that are isomorphic to a “")#mi("{C^0}")#text(" local group” (which is the same concept as a ")#mi("{C^{1,1}}")#text(" local group, but without the asymptotic ")#link(<tao-8cf107bbea706c3ab8da>)[#text("(4)")]#text("). Thus we have reduced Hilbert’s fifth problem to the task of boosting ")#mi("{C^0}")#text(" regularity to ")#mi("{C^{1,1}}")#text(" regularity, rather than that of boosting ")#mi("{C^0}")#text(" regularity to ")#mi("{C^\\infty}")#text(" regularity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{G}")#text(" be a Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(". For any ")#mi("{X, Y \\in {\\mathfrak g}}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\exp([X,Y]) = \\lim_{n \\rightarrow \\infty} (\\exp(X/n) \\exp(Y/n)")]]

#align(center)[#tao-fit-display[#mitex("\\exp(-X/n) \\exp(-Y/n))^{n^2}.")]]
]

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Combinatorics versus geometric… | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-72572")[#strong[#text("Combinatorics versus geometric… | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2011")])]

#text("[…] of using knowledge concerning topological groups in order to study discrete approximate groups, as Tao proposes in his new course, it is about discrete finitely generated groups with polynomial growth which, as Gromov taught us, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tanaka")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-72581")[#strong[#text("tanaka")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2011")])]

#text("Thank you for your good post.")#linebreak()#text(" By the way ,In Remark2, where does “Y” comes from?")

#emph[#text("[Oops, that was meant to be an X. Corrected, thanks – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-72813")[#strong[#text("254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula (via What's new) « Human Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2011")]

#text("[…] 254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula (via What's new) By human mathematics In this set of notes, we describe the basic analytic structure theory of Lie groups, by relating them to the simpler concept of a Lie algebra. Roughly speaking, the Lie algebra encodes the “infinitesimal” structure of a Lie group, but is a simpler object, being a vector space rather than a nonlinear manifold. Nevertheless, thanks to the fundamental theorems of Lie, the Lie algebra can be used to reconstruct the Lie group (at a local l … Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-72921")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2011")])]

#text("Typo: In the sentence beginning “However, we will use (iv)”, I imagine you mean (iii). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98573df78f21738ee208f46fda080b63615a41ce5430e3c317e3486a824e3f31-80e52398808cb1c9751e2014daffca486d9666169325f07daef7e4b24e348b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E. Mehmet Kiral")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-73939")[#strong[#text("E. Mehmet Kiral")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")])]

#text("The fifth bullet point in exercise 6 seems to have a typo, $\\mathbb{R}$ versus $\\mathbb{C}$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0d8a003af138ca1f68e7d3b582c1280566a5901d3b7cd485861da9a2d6fae7b-8c29d677a7209f96ed5d8d4315a5d18db03fa50b3a504f005c3e12f58e11b3dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-73946")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")])]

#text("It looks like you should have “..are well defined and lie in ")#mi("U")#text("” and ")#mi("x^{-1}")#text(" instead of ")#mi("x^{*-1}")#text(" in example 1. ")#emph[#text("[Corrected, thanks, although ")#mi("x^{*-1}")#text(" is actually not a typo. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-74631")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2011")]

#text("[…] compactness theorem, n-Category Café on Hadwiger’s theorem, Terry Tao starting a series of posts on Hilbert’s fifth problem, and Vismath (in German, translation) and 0xDE on tilings. Also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-75271")[#strong[#text("254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2011")])]

#text("[…] one-parameter subgroups to convert from the nonlinear setting to the linear setting. Recall from the previous notes that in a Lie group , the one-parameter subgroups are in one-to-one correspondence with the Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-80850")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2011")])]

#text("Dear Prof. Tao,")

#text("I have some trouble with Exercise 9(v). Even in the easiest situation, that of Exercise 16(17), I keep getting terms like ")#tao-math("\\left|y+z^{*-1}\\right|", block: false)#text(" instead of |y-z| in the estimates. With the radial homogeneity assumption the two are equal, but otherwise there remains an error of O(|z|)². What can be done about it?")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-80931")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2011")])]

#text("Ah yes, this requires an estimate which wasn’t explicitly in the previous exercises but which I’ve now added as Exercise 9(viii) (note that there has been some renumbering of exercises).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-82470")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Thank you, this has helped me to show the Lipschitzianity of left and right translation, and thus Ex. 9 (vi) and (viii). I am however still lost with (vii), the asymptotics for ")#mi("x^{*n}-y^{*n}")#text(".")

#text("What I think I can show is that it is ")#mi("n(x-y)")#text(" up to an arbitrarily small relative error, if ")#mi("x")#text(" is small enough (from the analogous result ")#mi("x*y^{*-1} \\approx x-y")#text(" up to a small relative error). Unfortunately, this is much weaker then the error being ")#tao-math("O(n^2 \\left|x-y\\right|^2)", block: false)#text(".")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-82503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Oops, that bound is indeed too strong to be true in general. I’ve replaced it with the bilipschitz bound as you indicated (which is what is actually needed going forward in the argument.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ded5fafcbc95a8f9d4ade190dc72a40a9124cb69a377aaeb2498b70ac88b1ad-4d611d8ded45e2b0d527bb6a7afb21f9febb2f8ccf9a29e5152b1f2889a1d2dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of THLee")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-221915")[#strong[#text("THLee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2013")])]

#text("I am looking for proofs for equivalence of any decomposition of a general anti-hermitain matrix when canonical coordinates of the first kind is mapped to the second kind in exponential map of SU(N) group. Can anyone suggest me any textbook or reference for this question?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-82564")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("I’m having trouble understanding the term ")#mi("exp(\\gamma^{\\prime}(0)")#text(" in exercise 10 (ii). I think this means the exponential map of a member of the equivalence class ")#mi("\\gamma^{\\prime}(0)")#text(" – in other words, a curve ")#mi("\\gamma(t)")#text(" in ")#mi("G")#text(". But then this can’t be equal to the limit on the right since ")#mi("t")#text(" is (somewhat) arbitrary. Also, what does it mean to say that ")#mi("\\gamma^{\\prime}(0)")#text(" is sufficiently small.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-82572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Note that while there are multiple curves ")#mi("\\gamma")#text(" with the same derivative ")#mi("\\gamma^{\\prime}(0)")#text(" at zero, it will turn out that each of these curves ends up with the same limiting value of ")#mi("\\lim_{n \\to \\infty} \\gamma(1/2^n)^{*2^n}")#text(", thus the apparent ambiguity of ")#mi("\\gamma")#text(" will disappear in the limit.")

#text("In any event, in a local ")#mi("C^{1,1}")#text(" group, G is a subset of a Euclidean space, so one can use the Euclidean definition of ")#mi("\\gamma^{\\prime}(0)")#text(" in this case if one wishes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-82601")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Thank you")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-85823")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("[…] the last few notes, we have been steadily reducing the amount of regularity needed on a topological group in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-90806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("Professor Tao,")

#text("In exercise 14, should G and H be local Lie groups?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-90902")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("At the beginning of the proof of Proposition 9, shouldn’t it be ")#mi("(\\rho_{\\exp(tx)}^{left})_* x")#text(", and not just $\\rho_{\\exp(tx)}^{left} x$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5eea1bf9e77b33db043998971c24f9ef51509e0863dbef171dc904189e214c4-60e2e0a5f3a259a5b3ceeb4c3dd62870db3ebd32f1f04a11933bf1e227b7a9a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruce Bartlett")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-97644")[#strong[#text("Bruce Bartlett")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("I think that another way of integrating a Lie algebra to a Lie group (this is in regard to Remark 5), which doesn’t proceed via Ado’s theorem, is to define the group elements as equivalence classes of paths in the Lie algebra. My understanding is that there are two different equivalence relations one can put on the paths: the first can be found in the book “Lie Groups” by Duistermaat and Kolk, and the second can be found in Segal’s section of the book “Lectures on Lie Groups and Lie Algebras” by Carter, Segal and Macdonald. Both of these give rise to the same group I believe.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-97773")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("I took a look at Carter-Segal-Macdonald (our library doesn’t have Duistermaat-Kolk). Unfortunately they omit the most crucial step of the argument, namely to show that two short paths are equivalent whenever they integrate out (via the infinitesimal form of BCH, i.e. Lemma 14 above) to the same element of the Lie algebra; they prove it using Ado’s theorem, but don’t indicate how to do it without that theorem (other than to say that it is “difficult”). So I suspect that the difficulty is simply being moved elsewhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Associativity of the Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-98101")[#strong[#text("Associativity of the Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2011")])]

#text("[…] for instance these notes of mine for a proof of this formula (it is for , but one easily obtains a similar proof for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98a9d3ea8df6b4c2b314e7ed3e68f51246471d48a2d203cce0f02817a591e7ff-3faacd5d57eecd7bfd337c7902992e31c6539881163762187952294b42426f8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johnny")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-131701")[#strong[#text("Johnny")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")])]

#text("I think ready solutions makes it easier.")#linebreak()#text(" I use Differential Geometry Library:")#linebreak()#text(" ")#link("http://digi-area.com/DifferentialGeometryLibrary/")[#text("http://digi-area.com/DifferentialGeometryLibrary/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-141713")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("I think there’s a typo in the definition 4 of the tangent space.")#linebreak()#text(" M instead of G.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some notes on Weyl quantisation « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-179418")[#strong[#text("Some notes on Weyl quantisation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2012")])]

#text("[…] as well as exponential coordinates (of the first kind) on Lie groups, discussed for instance in this previous blog post. In contrast, the Kohn-Nirenberg quantisation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the classification of complex Lie algebras | What's new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-226582")[#strong[#text("Notes on the classification of complex Lie algebras | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("[…] counterparts in the category of Lie algebras (often with exactly the same terminology). See this previous blog post for more discussion about the connection between Lie algebras and Lie groups (that post was focused […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-243957")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] (This statement can be made more precise using the Baker-Campbell-Hausdorff formula, discussed in this previous post.) On the other hand, every connected Lie group has a universal cover with the same Lie algebra […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f5b2b811b03ee76477ed89bdfac88b582e97d83ba6535b1522d4bc7e4dde9a3-5d68d0530ee220e933b76151cee51130d111891c8ca58689cffe7df09b8b63de.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao Zhuang")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-452809")[#strong[#text("Hao Zhuang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2015")])]

#text("Reblogged this on ")#link("https://hzhuang.wordpress.com/2015/03/08/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("Exponentials")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-452811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2015")])]

#text("In definition 4, it seems that the (undefined) ")#mi("G")#text(" (appearing in line 4 and several other places) should be ")#mi("M")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative continuity estimates | What's new")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-481106")[#strong[#text("Quantitative continuity estimates | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("[…] We remark that further manipulation of (iv) of the above exercise using the fundamental theorem of calculus eventually leads to the Baker-Campbell-Hausdorff-Dynkin formula, as discussed in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4774596e45dca160be5aa2a18445143dc45ff41dff7be1904c54f961d8c53d1f-a3e746399be0fcfd579a9246b2ade6fb3b503db955e51955e3e1089934b1b44b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Rodríguez Fanlo")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-515362")[#strong[#text("Arturo Rodríguez Fanlo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2019")])]

#text("Dear Prof. Tao,")

#text("Thank you very much. If it is possible, I would sincerely appreciate any hint to show the lower bound of point (vii) of exercise 9:")

#text("In a ")#mi("\\mathcal{C}^{1,1}")#text(" local group, there is ")#mi("\\varepsilon>0")#text(" such that for any natural number ")#mi("n")#text(" and any ")#mi("x,y")#text(" with ")#tao-math("\\left\\|x\\right\\|,\\left\\|y\\right\\|\\leq \\varepsilon/n", block: false)

#tao-math("\\displaystyle n\\left\\|x-y\\right\\|\\leq 2\\left\\|x^{*n}-y^{*n}\\right\\|", block: false)

#text("Again, thank you very much for everything.")

#text("Best wishes,")#linebreak()#text(" Arturo")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-515363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2019")])]

#text("Can you do the case ")#mi("n=2")#text("? You may find it helpful to write ")#mi("y = x * z")#text(" and try to estimate both ")#tao-math("\\left\\|x-y\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|x^{*2} - y^{*2} \\right\\|", block: false)#text(" in terms of ")#tao-math("\\left\\|z\\right\\|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4774596e45dca160be5aa2a18445143dc45ff41dff7be1904c54f961d8c53d1f-a3e746399be0fcfd579a9246b2ade6fb3b503db955e51955e3e1089934b1b44b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Rodriguez Fanlo")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-515668")[#strong[#text("Arturo Rodriguez Fanlo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2019")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for your attention.")

#text("Best wishes,")#linebreak()#text(" Arturo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/#comment-685145")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2024")])]

#text("I just want to clarify Remark 10 since I was confused by the wording: The goal is to prove * is associative, and it is enough to show in the sense of formal power series, so we can just prove * is associative for the free Lie algebra on d generators.")

#text("If we show * is associative for the free nilpotent Lie algebra on d generators of step s for all s (this nilpotent algebra is finite-dimensional), this implies * is associative for the free Lie algebra on d generators. Since we are allowed to use Ado’s theorem for finite-dimensional nilpotent Lie algebras, by embedding in gl_n(R) it is clear that * is associative for the free nilpotent Lie algebra on d generators of step s for all s.")
]
