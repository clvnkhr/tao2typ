// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/
// Converted to Typst by tao2typ: "2026-10-14T16:36:16.635571+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A second draft of a non-technical article on universality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A second draft of a non-technical article on universality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve spent the last week or so reworking ")#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/")[#text("the first draft of my universality article")]#text(" for ")#link("http://www.mathaware.org/index.html")[#text("Mathematics Awareness Month")]#text(", in view of the useful comments and feedback received on that draft here on this blog, as well as elsewhere. In fact, I ended up rewriting the article from scratch, and expanding it substantially, in order to focus on a more engaging and less technical narrative. I found that I had to use a substantially different mindset than the one I am used to having for technical expository writing; indeed, the exercise reminded me more of my high school English assignments than of my professional work. (This is perhaps a bad sign: English was not exactly my strongest subject as a student.)")

#text("The piece now has title: “")#emph[#text("E pluribus unum")]#text(": from complexity, universality”. This is a somewhat US-centric piece of wordplay, but Mathematics Awareness Month is, after all, a US-based initiative, even though awareness of mathematics certainly transcends national boundaries. Still, it is a trivial matter to modify the title later if a better proposal arises, and I am sure that if I send this text to be published, that the editors may have some suggestions in this regard.")

#text("By coincidence, I moved up and expanded the other US-centric item – the discussion of the 2008 US presidential elections – to the front of the paper to play the role of the hook. I’ll try to keep the Commonwealth spelling conventions, though. :-)")

#text("I decided to cut out the discussion of the N-body problem for various values of N, in part due to the confusion over the notion of a “solution”; there is a nice mathematical story there, but perhaps one that gets in the way of the main story of universality.")

#text("I have added a fair number of relevant images, though some of them will have to be changed in the final version for copyright reasons. The narrow column format of this blog means that the image placement is not optimal, but I am sure that this can be rectified if this article is published professionally.")

#heading(level: 1)[#metadata(none) <tao-01e9db94902aba4b917e>#text("— ")#emph[#text("E pluribus unum")]#text(": from complexity, universality —")]

#heading(level: 1)[#strong[#text("A brief tour of the mysteriously universal laws of mathematics and nature.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("Nature is a mutable cloud, which is always and never the same.")]#text(" (")#link("http://en.wikipedia.org/wiki/Ralph_Waldo_Emerson")[#text("Ralph Waldo Emerson")]#text(", “")#link("http://www.rwe.org/works/Essays-1st_Series_01_History.htm")[#text("History")]#text("“, from Essays: First Series, 1841)")
]

#heading(level: 2)[#text("1. Prologue: the 2008 US presidential election and the law of large numbers.")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("Do I contradict myself?")#linebreak()#text(" Very well then I contradict myself,")#linebreak()#text(" (I am large, I contain multitudes.)")]

#text("(")#link("http://en.wikipedia.org/wiki/Walt_Whitman")[#text("Walt Whitman")]#text(", “")#link("http://en.wikipedia.org/wiki/Song_of_Myself")[#text("Song of myself")]#text("“, 1855)")
]

#text("The US presidential elections of November 4, 2008 were a massively complicated affair. Over a hundred million voters from fifty states cast their ballot, with each voter’s decision being influenced in countless different ways by the campaign rhetoric, the media coverage, rumors, personal impressions of the candidates, or from discussing politics with friends and colleagues. There were millions of “swing” voters that were not firmly supporting either of the two major candidates; their final decision would be unpredictable, and perhaps even random in some cases. There was the same uncertainty at the state level: while many states were considered safe for one candidate or the other, at least a dozen states were considered “in play”, and could conceivably have gone either way.")

#text("In such a situation, it would seem impossible to be able to accurately forecast the election outcome in advance. Sure, there were electoral polls – hundreds of them – but each poll only surveyed a few hundred or a few thousand likely voters, which is only a tiny fraction of the entire population. And the polls often fluctuated wildly and disagreed with each other; not all polls were equally reliable or unbiased, and no two polling organisations used exactly the same methodology.")

#text("Nevertheless, well before election night was over, the polls had predicted the outcome of the presidential election, and most of the other elections taking place that night, quite accurately. Perhaps the most spectacular instance of this was the predictions of the statistician ")#link("http://en.wikipedia.org/wiki/Nate_Silver")[#text("Nate Silver")]#text(", who used a weighted analysis of all existing polls to correctly predict the outcome of the presidential election in 49 out of 50 states, as well as of all 35 of the 35 US senate races. (The lone exception was the presidential election in Indiana, which Silver called narrowly for McCain, but which eventually favoured Obama by just 0.9%.)")

#link("http://en.wikipedia.org/wiki/File:Current_2008_US_Electoral_College_Polling_Map.PNG")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("2008 Presidential Election projections by Nate Silver on election night (Nov 4, 2008)") · #link("https://i0.wp.com/upload.wikimedia.org/wikipedia/commons/6/6f/Current_2008_US_Electoral_College_Polling_Map.PNG")[Original image]]]]

#text("Fig 1. 2008 Presidential Election projections by Nate Silver on election night (Nov 4, 2008). (Source: Wikipedia)")

#metadata(none) <tao-727b788f0c9af4f061f5>

#link("http://elections.nytimes.com/2008/results/president/map.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("Actual 2008 Presidential election results.") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/2008-election-map-nytimes.png?w=490&h=350")[Original image]]]]

#metadata(none) <tao-17422a988e992811894e>

#text("Fig 2. Actual 2008 Presidential election results. (Source: the New York Times)")

#text("The theoretical basis for polling is a mathematical law known as the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(". Roughly speaking, this law asserts that if one is making a set of samples via some random method, then as one makes the sample size larger and larger, the average outcome of those samples will almost always converge to a single number, known as the ")#emph[#text("expected outcome")]#text(" of that random method. For instance, if one flips a fair coin a thousand times, then one can use this law to show that the proportion of heads one gets from doing so will usually be quite close to the expected value of 50%; indeed, it will be within 3% of 50% (i.e. between 470 and 530 heads out of 1000) about 95% of the time.")

#text("In a very similar vein, if one selects a thousand voters at random and in an unbiased fashion (so that each voter is equally likely to be selected by the poll), and finds out who they would vote for (out of two choices, such as Obama and McCain; assume for simplicity that third-party votes are negligible), then the outcome of this poll has a ")#link("http://en.wikipedia.org/wiki/Margin_of_error")[#text("margin of error")]#text(" of about 3% with a 95% ")#link("http://en.wikipedia.org/wiki/Confidence_level")[#text("confidence level")]#text(", which means that 95% of the time that such a poll is conducted, the result of the poll will be within 3% of the true result of the election.")

#text("One of the remarkable things about the law of large numbers is that it is ")#emph[#text("universal. ")]#text(" Does the election involve a hundred thousand voters, or a hundred million voters? It doesn’t matter – the margin of error for the poll will still be 3%. Is it a state that favors McCain to Obama 55% to 45%, or Obama to McCain 60% to 40%? Again, it doesn’t matter – the margin of error for the poll will still be 3%. Is the state a homogeneous bloc of (say) affluent white urban voters, or is the state instead a mix of voters of all incomes, races, and backgrounds? It still doesn’t matter – the margin of error for the poll will still be 3%. And so on and so forth. The only factor which really makes a significant difference")#super[#text("1")]#text(" is the size of the poll; the larger the poll, the smaller the margin of error.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("Margin of error for various poll sizes, at the 95% confidence level.") · #link("https://i0.wp.com/upload.wikimedia.org/wikipedia/en/1/1d/Marginoferror95.PNG")[Original image]]]

#text("Fig 3. Margin of error for various poll sizes, at the 95% confidence level, assuming that the electorate is split 50%-50% between two candidates. The horizontal axis represents the outcome of the poll. The error distributions are examples of the normal distribution, that arises in the central limit theorem discussed below; indeed, the law of large numbers and the central limit theorem are closely related. (Source: Wikipedia)")

#text("In 2008, reliably accurate meta-polls were still something of a novelty. But they seem here to stay, particularly in high-profile elections in which hundreds of polls are conducted; expect to see more from them in the future.")

#strong[#text("2. Approaching normal: bell curves and other universal laws.")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("I know of scarcely anything so apt to impress the imagination as the wonderful form of cosmic order expressed by the “Law of Frequency of Error”. The law would have been personified by the Greeks and deified, if they had known of it. It reigns with serenity and in complete self-effacement, amidst the wildest confusion. The huger the mob, and the greater the apparent anarchy, the more perfect is its sway. It is the supreme law of Unreason. Whenever a large sample of chaotic elements are taken in hand and marshaled in the order of their magnitude, an unsuspected and most beautiful form of regularity proves to have been latent all along.")]#text(" (Sir Francis Galton, Natural Inheritance, 1889, describing what is now known as the central limit theorem.)")
]

#text("The law of large numbers is one of the simplest and best understood of the universal laws in mathematics and nature, but it is by no means the only one. Over the decades, many such universal laws have been found, that govern the behaviour of wide classes of complex systems, regardless of what the components of that system are, or even how they interact with each other. In this article we will have a quick tour of some of these remarkable laws.")

#text("After the law of large numbers, perhaps the next most fundamental example of a universal law is the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(". Roughly speaking, this theorem asserts that if one takes a statistic that is a combination of many independent and randomly fluctuating components, with no one component having a decisive influence on the whole, then that statistic will be approximately distributed according to a law called the ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution")]#text(" (or Gaussian distribution), and more popularly known as the ")#emph[#text("bell curve")]#text("; some examples of this mathematical curve already appeared above in Figure 3. The law is universal because it holds regardless of exactly how the individual components fluctuate, or how many components there are (although the accuracy of the law improves when the number of components increases); it can be seen")#super[#text("2")]#text(" in a staggeringly diverse range of statistics, from the incidence rate of accidents, to the variation of height, weight, or other vital statistics amongst a species, to the financial gains or losses caused by chance, to the velocities of the component particles of a physical system. The size, width, location, and even the units of measurement of the distribution varies from statistic to statistic, but the bell curve shape can be discerned in all cases. This convergence arises not because of any “low-level” or “microscopic” connection between such diverse phenomena as car crashes, human height, trading profits, or stellar velocities, but because in all of these cases the “high-level” or “macroscopic” structure is the same, namely a compound statistic formed from a combination of the small influences of many independent factors. This is the essence of universality: the macroscopic behaviour of a large, complex system can be almost totally independent of its microscopic structure.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("A histogram of monthly deaths from automobile statistics in the US from 1973 to 1978. ") · #link("https://i0.wp.com/upload.wikimedia.org/wikipedia/en/e/ec/UsaccHistogram.png")[Original image]]]

#text("Fig 4. A histogram of monthly deaths from automobile statistics in the US from 1973 to 1978. (Source: Wikipedia)")

#link("http://www.ibm.com/developerworks/opensource/library/wa-probab/index.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("A histogram of the height of adult human males in inches.") · #link("https://i0.wp.com/www.ibm.com/developerworks/opensource/library/wa-probab/male_height.gif")[Original image]]]]

#text("Fig 5. A histogram of the height of 1,000 adult human males in inches. (Source: IBM) It is important here that we restrict to a single gender; we return to this point later in this article.")

#link("http://ftalphaville.ft.com/blog/2008/02/26/11182/beyond-subprime-citis-writedowns/")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/av.r.ftdata.co.uk/files/2008/02/842.jpg")[Original image]]]]

#text("Fig 6. A histogram of daily profits or losses from the Citigroup's trading activities in 2007, excluding CDO activity (discussed at the end of this article). (Source: Financial Times)")

#link("http://quarknet.fnal.gov/eeu/hubblediagram/")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("A histogram of observed velocities (or more precisely, velocity dispersion inferred from redshift data) of stars in a single galaxy. ") · #link("https://i0.wp.com/quarknet.fnal.gov/eeu/hubblediagram/histogram.jpg")[Original image]]]]

#text("Fig 7. A histogram of observed velocities (or more precisely, velocity dispersion inferred from redshift data) of stars in a single galaxy. (Source: Quarknet)")

#text("The universal nature of the central limit theorem is tremendously useful in many industries, allowing them to manage what would otherwise be an intractably complex and chaotic system. With this theorem, insurers can manage the risk of, say, their car insurance policies, without having to know all the complicated details of how car crashes actually occur; astronomers can measure the size and location of distant galaxies, without having to solve the complicated equations of celestial mechanics; electrical engineers can predict the effect of noise and interference on electronic communications, without having to know exactly how this noise was generated; and so forth. It is important to note, though that the central limit theorem is not ")#emph[#text("completely")]#text(" universal; there are important cases when the theorem does not apply, giving statistics with a distribution quite different from the bell curve. I’ll return to this point later.")

#text("There are some other distant cousins of the central limit theorem that are universal laws for slightly different types of statistics. For instance, ")#link("http://en.wikipedia.org/wiki/Benford's_law")[#text("Benford’s law")]#text(" is a universal law for the first few digits of a large statistic, such as the population of a country or the size of an account; it gives a number of counterintuitive predictions, for instance that any given statistic occurring in nature is more than six times as likely to start with the digit 1, than with the digit 9. Among other things, this law (which can be explained by combining the central limit theorem with the mathematical theory of ")#link("http://en.wikipedia.org/wiki/Logarithm")[#text("logarithms")]#text(") has been used to detect accounting fraud, since numbers that are simply made up, as opposed to arising naturally in nature, often do not obey this law.")

#image("../assets/723bc33d4d5cc240a8ed38ce47c78a26cff56d55f007be49ea86d9b23e407148-aeb61e4d977ad23f31309bcf48a3b0713ac706be154ffc0561bf14c714efec73.png", width: 90%, alt: "Histogram of the first digits of the population of the 237 countries of the world in 2010.")

#text("Fig 8. Histogram of the first digits of the population of the 237 countries of the world in 2010; the Benford's law prediction is given by the black dots. (Source: Wikipedia)")

#link("http://www.journalofaccountancy.com/Issues/1999/May/nigrini.htm")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("A histogram of the first two digits of accounts payable data of a major software company.") · #link("https://i0.wp.com/media.journalofaccountancy.com/JOA/Issues/1999/05/Ex4cht.eps.gif")[Original image]]]]

#text("Fig 9. A histogram of the first two digits of accounts payable data of a major software company, together with the Benford's law prediction. (Source: Journal of Accountancy)")

#text("In a similar vein, ")#link("http://en.wikipedia.org/wiki/Zipf's_law")[#text("Zipf’s law")]#text(" is a universal law that governs the largest statistics in a given category, such as the largest country populations in the world, or the most frequent words in the English language. It asserts that the size of a statistic is usually inversely proportional to its ranking; thus for instance the tenth largest statistic should be about half the size of the fifth largest statistic. (The law tends not to work so well for the top two or three statistics, but becomes more accurate after that.) Unlike the central limit theorem and Benford’s law, this law is primarily an empirical law; it is observed in practice, but mathematicians still do not have a fully satisfactory and convincing explanation for how the law comes about, and why it is so universal.")

#link("http://searchengineland.com/the-long-tail-of-search-12198")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("Histogram of the most frequently used words in \"Moby Dick\".") · #link("https://i0.wp.com/www.rimmkaufman.com/content/mobydick.png")[Original image]]]]

#text("Fig 10. Histogram of the most frequently used words in \"Moby Dick\". (Source: searchengineland)")

#link("http://midwest.chicagofedblogs.org/archives/2006/10/")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("The most populous cities in the US Midwest. ") · #link("https://i0.wp.com/midwest.chicagofedblogs.org/archives/MSARank.gif")[Original image]]]]

#text("Fig 11. The most populous cities in the US Midwest in 2006. (Source: Federal Reserve Bank of Chicago)")

#link("http://www.raphkoster.com/2007/05/29/mmo-long-tails/")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("The population of the most popular Massively Multiplayer Online Games (MMOG) in 2003.") · #link("https://i0.wp.com/www.raphkoster.com/wp-content/uploads/2007/05/oldmmogchartdata.jpg")[Original image]]]]

#text("Fig 12. The population of the most popular Massively Multiplayer Online Games (MMOG) in 2003. (Source: Raph Koster)")

#heading(level: 2)[#text("3. At the threshold: the universality of phase transitions")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#align(center)[#emph[#text("There is nothing so stable as change.")]#text(" (")#link("http://en.wikipedia.org/wiki/Bob_Dylan")[#text("Bob Dylan")]#text(", 1963. From “No Direction Home”, by Robert Shelton)")]
]

#text("We’ve been discussing universal laws for individual statistics: complex numerical quantities that arise as the combination of many smaller and independent factors. But universal laws have also been found for more complicated objects than mere numerical statistics. One example of this is the laws governing the complicated shapes and structures that arise from ")#link("http://en.wikipedia.org/wiki/Phase_transition")[#text("phase transitions")]#text(" in physics and chemistry.")

#text("As we learn in high school science classes, matter comes in various states, including the three classic states of solid, liquid, and gas, but also a number of exotic states such as ")#link("http://en.wikipedia.org/wiki/Plasma_(physics)")[#text("plasmas")]#text(" or ")#link("http://en.wikipedia.org/wiki/Superfluid")[#text("superfluids")]#text(". Ferromagnetic materials, such as iron, also have magnetised and non-magnetised states; other materials become electrical conductors at some temperatures and insulators at others. What state a given material is in depends on a number of factors, most notably the ")#emph[#text("temperature")]#text(" and, in some cases, the ")#emph[#text("pressure")]#text(". (For some materials, the level of impurities is also relevant.) For a fixed value of the pressure, most materials tend to be in one state (e.g. a solid) for one range of temperatures, and in another state (e.g. a liquid) for another range. But when the material is at or very close to the temperature dividing these two ranges, interesting ")#emph[#text("phase transitions")]#text(" occur, in which the material is not fully in one state or the other, but tends")#super[#text("3")]#text(" to split up into beautifully fractal shapes known as ")#emph[#text("clusters")]#text(", each of which embodies one or the other of the two states.")

#text("There are countless different materials in existence, each of which having a different set of key parameters (such as the boiling point at a given pressure). There are also a large number of different mathematical models that physicists and chemists use to model these materials and their phase transitions, in which individual atoms or molecues are assumed to be connected to some of their neighbours by a random number of bonds, assigned according to some probabilistic rule. At the microscopic level, these models can look quite different from each other. For instance, the figures below display the small-scale structure of two typical such models: a ")#link("http://en.wikipedia.org/wiki/Percolation_theory")[#text("site percolation")]#text(" model on a hexagonal lattice, in which each hexagon (or")#emph[#text(" site")]#text(") is an abstraction of an atom or molecule randomly placed in one of two states, with the clusters being the connected regions of a single colour; and a ")#link("http://en.wikipedia.org/wiki/Percolation_theory")[#text("bond percolation")]#text(" model on a square lattice, in which the edges of the lattice are abstractions of molecular bonds that each have some probability of being activated, with the clusters being the connected regions given by the active bonds.")

#link("http://stat.math.uregina.ca/~kozdron/Simulations/Percolation/percolation.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/stat.math.uregina.ca/~kozdron/Simulations/Percolation/percolate_a.jpg")[Original image]]]]

#text("Fig 13. Site percolation on the hexagonal lattice at the critical threshold. (Source: Michael Kozdron)")

#link("http://pages.physics.cornell.edu/~myers/teaching/ComputationalMethods/ComputerExercises/Percolation/Percolation.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/pages.physics.cornell.edu/~myers/teaching/ComputationalMethods/ComputerExercises/Fig/BondPercolation_10_0.4_1.gif")[Original image]]]]

#text("Fig 14. Bond percolation on the square lattice at the critical threshold. Each cluster has been coloured with a single colour to make them more visible. (Source: Christopher Myers).")

#text("If, however, one zooms out to a more macroscopic scale, and looks at the large-scale structure of clusters when one is at or near the critical value of parameters such as temperature, the differences in microscopic structure fade away, and one begins to see a number of universal laws emerging. While the clusters have a random size and shape, they almost always have a ")#link("http://en.wikipedia.org/wiki/Fractal")[#text("fractal")]#text(" structure, which roughly speaking means that if one zooms in a little on any portion of the cluster, the resulting image resembles the cluster as a whole. Basic statistics such as the number of clusters, the average size of the clusters, or how often a cluster connects two given regions of space, appear to obey some specific universal laws, known as ")#link("http://en.wikipedia.org/wiki/Power_law")[#text("power laws")]#text(" (which are somewhat similar, though not quite the same, as Zipf’s law, which was mentioned earlier). These laws seem to arise in almost every mathematical model that has been put forward to explain (continuous) phase transitions), and have also been observed many times in nature. As with other universal laws, the precise microscopic structure of the model or the material may affect some basic parameters, such as the phase transition temperature, but the underlying structure of the law is the same across all such models and materials.")

#metadata(none) <tao-32ec09eda78564924f24>

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/vanadium.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("http://www.lanl.gov/news/index.php/fuseaction/home.story/story_id/12184") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/vanadium.png?w=490")[Original image]]]]

#metadata(none) <tao-10f661a098a95e01dadc>

#text("Fig 15. Transition of vanadium dioxide from an insulator (blue) to conductor (green) at the critical temperature. (Source: Los Alamos National Laboratories.)")

#link("http://www.cs.adelaide.edu.au/~paulc/physics/spinmodels.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/www.cs.adelaide.edu.au/~paulc/physics/ising.gif")[Original image]]]]

#text("Fig 16. A simulation of the Ising model (a model for ferromagnetic phase transitions) at the critical temperature. (Source: Paul Coddington)")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("A percolation cluster occurring just below the critical threshold.") · #link("https://i0.wp.com/upload.wikimedia.org/wikipedia/commons/1/17/Amas_de_percolation.png")[Original image]]]

#text("Fig 17. A percolation cluster occurring just below the critical threshold. (Source: Wikipedia)")

#text("In contrast to more classical universal laws such as the central limit theorem, our understanding of the universal laws of phase transition are still incomplete. Physicists have put forward some compelling heuristic arguments that explain or support many of these laws (based on a powerful, but not fully rigorous, tool known as the ")#link("http://en.wikipedia.org/wiki/Renormalization_group")[#text("renormalisation group method")]#text("), but a completely rigorous proof of these laws has not yet been obtained in all cases. This is very much a current area of research; for instance, in August of 2010 a Fields medal (one of the most prestigious prizes in mathematics) was awarded to ")#link("http://en.wikipedia.org/wiki/Stanislav_Smirnov")[#text("Stanislav Smirnov")]#text(" for his breakthroughs in rigorously establishing the validity of these universal laws for some key models (such as percolation models on a triangular lattice).")

#heading(level: 2)[#text("4. Nuclear resonance and the music of the primes: the universality of spectra")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("Even without Hollywood hyperbole, however, the chance encounter of Montgomery and Dyson was a genuinely dramatic moment. Their conversation revealed an unsuspected connection between areas of mathematics and physics that had seemed remote. Why should the same equation describe both the structure of an atomic nucleus and a sequence at the heart of number theory? And what do random matrices have to do with either of those realms? In recent years, the plot has thickened further, as random matrices have turned up in other unlikely places, such as games of solitaire, one-dimensional gases and chaotic quantum systems. Is it all just a cosmic coincidence, or is there something going on behind the scenes?")]#text(" (Brian Hayes, “")#link("http://www.americanscientist.org/issues/pub/the-spectrum-of-riemannium")[#text("The spectrum of Riemannium")]#text("“, American Scientist, 2003).")
]

#text("We are nearing the end of our tour of universal laws, and I’ll now turn to another example of this phenomenon which is closer to my own area of research. Here, the object of study is not a single numerical statistic (as was the case of the central limit theorem) or a shape (as was the case for phase transitions), but a ")#emph[#text("discrete spectrum")]#text(": a sequence of points (or numbers, or frequencies, or energy levels) spread out along a line.")

#text("Perhaps the most familiar example of a discrete spectrum is the radio frequencies emitted by local radio stations; this is a sequence of frequencies in the radio portion of the electromagnetic spectrum, which one can of course access by turning a radio dial. These frequencies are not evenly spaced, but usually some effort is made to keep any two station frequencies separated from each other, to reduce interference.")

#text("Another familiar example of a discrete spectrum is the spectral lines of an atomic element that come from the frequencies that the electrons in the atomic shells can absorb and emit, according to the laws of quantum mechanics. When these frequencies lie in the visible portion of the electromagnetic spectrum, they give individual elements their distinctive colour, from the blue light of argon gas (which, confusingly, is often used in neon lamps, as pure neon emits orange-red light) to the yellow light of sodium. For simple elements, such as hydrogen, the equations of quantum mechanics can be solved relatively easily, and the spectral lines follow a regular pattern; but for heavier elements, the spectral lines become quite complicated, and not easy to work out just from first principles.")

#link("http://www.chem1.com/acad/webtext/atoms/atpt-2.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/www.chem1.com/acad/webtext/atoms/atpt-images/atomic_line_spectra.png")[Original image]]]]

#text("Fig 18. Atomic spectral emission lines for various elements. (Source: Stephen Lower)")

#text("An analogous, but less familiar, example of spectra comes from the scattering of neutrons off of atomic nuclei, such as the Uranium-238 nucleus. The electromagnetic and nuclear forces of a nucleus, when combined with the laws of quantum mechanics, predict that a neutron will pass through a nucleus virtually unimpeded for some energies, but will bounce off that nucleus at other energies, known as ")#emph[#text("scattering resonances")]#text(". The internal structures of such large nuclei are so complex that it has not been possible to compute these resonances either theoretically or numerically, leaving experimental data as the only option.")

#metadata(none) <tao-7767865afd46fc663830>

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/gadolinium-156.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/gadolinium-156.png?w=490&h=259")[Original image]]]]

#metadata(none) <tao-ba9978dbe9b55d25245d>

#text("Fig 19. Scattering cross-section of neutron scattering for the Gadolinium-156 nucleus at various energy levels. (Roughly speaking, the scattering cross-section determines how likely the neutron is to bounce off the nucleus.) The scattering resonances (indicated by arrows) correspond to peaks in the cross-section. (Source: Coceva and Stefanon, Nuclear Physics A, 1979)")

#text("These resonances have an interesting distribution; they are not independent of each other, but instead seem to obey a precise repulsion law that makes it quite unlikely that two adjacent resonances are too close to each other, somewhat in analogy to how radio station frequencies tend to avoid being too close together, except that the former phenomenon arises from the laws of nature rather than from government regulation of the spectrum. In the 1950s, the renowned physicist and Nobel laureate ")#link("http://en.wikipedia.org/wiki/Eugene_wigner")[#text("Eugene Wigner")]#text(" investigated these resonance statistics and proposed a remarkable mathematical model to explain them, an example of what we now call a ")#link("http://en.wikipedia.org/wiki/Random_matrix")[#text("random matrix model")]#text(". The precise mathematical details of these models are too technical to describe here, but roughly speaking one can view such models as a large collection of masses, all connected to each other by springs of various randomly selected strengths. Such a mechanical system will oscillate (or ")#emph[#text("resonate")]#text(") at a certain set of frequencies; and the Wigner hypothesis asserts that the resonances of a large atomic nucleus should resemble that of the resonances of such a random matrix model. In particular, they should experience the same repulsion phenomenon. Since it is possible to rigorously prove repulsion of the frequencies of a random matrix model, this gives a heuristic explanation for the same phenomenon that is experimentally observed for nuclei.")

#metadata(none) <tao-811e53517da9eb89d3df>

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/porter.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/porter.png?w=490")[Original image]]]]

#metadata(none) <tao-4c92b9ef8c9aec1a0d70>

#text("Fig 20. Spacing distribution for the resonances of various heavy nuclei, compared with the random matrix theory prediction. The repulsion effect is manifested in the relative scarcity of small spacings. (Source: Rosenzweig-Porter, Phys. Rev. 120 (1960))")

#text("Now, of course, an atomic nucleus does not actually resemble a large system of masses and springs (among other things, it is governed by the laws of quantum mechanics rather than of classical mechanics). Instead, as we have since discovered, Wigner’s hypothesis is a manifestation of a universal law that govern many types of spectral lines, including those that ostensibly have little in common with atomic nuclei or random matrix models. For instance, the same spacing distribution has been found in the waiting times between buses arriving at a bus stop:")

#metadata(none) <tao-8a297867a8fc434a5f2e>

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/busgraph.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/busgraph.png?w=490&h=391")[Original image]]]]

#metadata(none) <tao-fdd7b6dcb0dc213a46f2>

#text("Fig 21. A histogram of spacings between bus arrival times in Cuernavaca (Mexico), in crosses; the solid line is the prediction from random matrix theory. (Source: Krbalek-Seba, J. Phys. A., 2000)")

#text("But perhaps the most unexpected demonstration of the universality of these laws came from the wholly unrelated area of number theory, and in particular the distribution of the ")#link("http://en.wikipedia.org/wiki/Prime_number")[#text("prime numbers")]#text(" 2, 3, 5, 7, 11, … – the natural numbers greater than 1 that cannot be factored into smaller natural numbers. The prime numbers are distributed in an irregular fashion through the integers; but if one performs a spectral analysis on this distribution, one can discern certain long-term oscillations in this distribution (sometimes known as the music of the primes), the frequencies of which are described by a sequence of complex numbers known as the ")#emph[#text("(non-trivial) zeroes of the ")]#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#emph[#text("Riemann zeta function")]]#text(", which were first studied by ")#link("http://en.wikipedia.org/wiki/Bernhard_Riemann")[#text("Bernhard Riemann")]#text(" in 1859. (For this discussion, it is not important to know exactly what the Riemann zeta function is.) In principle, these numbers tell us everything we would wish to know about the primes. One of the most famous and important problems in number theory is the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(", which asserts that these numbers all lie on a single line in the complex plane. It has many consequences in number theory, and in particular gives many important consequences about the prime numbers. However, even the powerful Riemann hypothesis does not settle everything in this subject, in part because it does not directly say much about how the zeroes are distributed on this line. But there is extremely strong numerical evidence that these zeroes obey the same precise law that is observed in neutron scattering and in other systems; in particular, the zeroes seem to “repel” each other in manner that matches the predictions of random matrix theory with uncanny accuracy. The formal description of this law is known as the ")#link("http://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE) hypothesis. (The Gaussian Unitary Ensemble is a fundamental example of a random matrix model.) Like the Riemann hypothesis, it is currently unproven, but it has powerful consequences for the distribution of the prime numbers.")

#metadata(none) <tao-5eb4b387effbcaf77b5a>

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/odlyzko.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/odlyzko.png?w=490")[Original image]]]]

#metadata(none) <tao-dcfe9a8bd2dec5e4623a>

#text("Fig 22. Spacing distribution for a billion zeroes of the Riemann zeta function, and the corresponding prediction from random matrix theory. (Source: Andrew Odlyzko, Contemp. Math. 2001)")

#text("The discovery of the GUE hypothesis, connecting the music of the primes and the energy levels of nuclei, occurred at the Institute of Advanced Study in 1972, and the story is legendary in mathematical circles. It concerns a chance meeting between the mathematician ")#link("http://en.wikipedia.org/wiki/Hugh_Montgomery_(mathematician)")[#text("Hugh Montgomery")]#text(", who had been working on the distribution of zeroes of the zeta function (and more specifically, on a certain statistic relating to that distribution known as the ")#emph[#text("pair correlation function")]#text("), and the renowned physicist ")#link("http://en.wikipedia.org/wiki/Freeman_dyson")[#text("Freeman Dyson")]#text(". To tell the story, I will quote from Dan Rockmore’s book “Stalking the Riemann hypothesis”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("As Dyson recalls it, he and Montgomery had crossed paths from time to time at the Institute nursery")#super[#text("4")]#text(" when picking up and dropping off their children. Nevertheless, they had not been formally introduced. In spite of Dyson’s fame, Montgomery hadn’t seen any purpose in meeting him. “What will we talk about?” is what Montgomery purportedly said when brought to tea. Nevertheless, Montgomery relented and upon being introduced, the amiable physicist asked the young number theorist about his work. Montgomery began to explain his recent results on the pair correlation, and Dyson stopped him short – “Did you get this?” he asked, writing down a particular mathematical formula. Montgomery almost fell over in surprise: Dyson had written down the sinc-infused pair correlation function. … Whereas Montgomery had traveled a number theorist’s road to a “prime picture” of the pair correlation, Dyson had arrived at this formula through the study of these energy levels in the mathematics of matrices…")
]

#text("The chance discovery by Montgomery and Dyson that the same universal law that governs random matrices and atomic spectra, also applies to the zeta function, was given substantial numerical support by the computational work of Andrew Odlyzko from the 1980s onwards (see Figure 22). But this does not mean that the primes are somehow nuclear-powered, or that atomic physics is somehow driven by the prime numbers; instead, it is evidence that a single law for spectra is so universal that it is the natural end product of any number of different processes, whether it comes from nuclear physics, random matrix models, or number theory.")

#text("The precise mechanism underlying this law has not yet been fully unearthed; in particular, we still do not have a compelling explanation, let alone a rigorous proof, of ")#emph[#text("why")]#text(" the zeroes of the zeta function are subject to the GUE hypothesis. However, there is now a substantial body of rigorous work (including some by myself, and including some substantial breakthroughs in just the last one or two years) that gives support to the universality of this hypothesis, by showing that a wide variety of random matrix models (not just the most famous model of the Gaussian Unitary Ensemble) are all governed by essentially the same law for their spacings. At present, these demonstrations of universality have not extended to the number theoretic or physical settings, but they do give indirect support to the law being applicable in those cases.")

#text("The arguments used in this recent work are too technical to give here, but I will just mention one of the key ideas, which my co-author, Van Vu, and I borrowed from an old proof of the central limit theorem by ")#link("http://en.wikipedia.org/wiki/Jarl_Waldemar_Lindeberg")[#text("Jarl Lindeberg")]#text(" in 1922. In terms of the mechanical analogy of a system of masses and springs mentioned earlier, the key strategy was to replace just one of the springs by another, randomly selected, spring, and show that the distribution of the frequencies of this system did not change significantly when doing so. Applying this replacement operation to each spring in turn, one can eventually replace a given random matrix model with a completely different model while keeping the distribution mostly unchanged, and this can be used to show that large classes of random matrix models have essentially the same distribution.")

#text("This is currently a very active area of research; for instance, simultaneously with my work with Van Vu last year, Laszlo Erdos, Benjamin Schlein, and Horng-Tzer Yau have also given a number of other demonstrations of universality for random matrix models, based on ideas from mathematical physics. The field is moving quickly, and in a few years we may have many more insights as to the nature of this still-mysterious universal law.")

#heading(level: 2)[#text("5. When universality fails: the complex middle ground")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("The universe is change; our life is what our thoughts make it.")]#text(" (")#link("http://en.wikipedia.org/wiki/Marcus_Aurelius")[#text("Marcus Aurelius Antonius")]#text(", ")#link("http://en.wikipedia.org/wiki/Meditations")[#text("Meditations")]#text(")")
]

#text("There are many, many other universal laws of mathematics and nature out there; the examples given above are only a small fraction of those that have been discovered over the years, from such diverse subjects as dynamical systems and quantum field theory. For instance, many of the “macroscopic” laws of physics, such as the laws of thermodynamics or the equations of fluid motion, are quite universal in nature, with the microscopic structure of the material or fluid being studied being almost completely irrelevant, other than via some key parameters such as viscosity, compressibility, or entropy.")

#text("However, the principle of universality does have definite limitations. Take for instance the central limit theorem, which gives a bell curve distribution to any quantity that arises from a combination of many small and independent factors. This theorem can fail when the required hypotheses are not met. For instance, the distribution of the heights of all human adults (male and female) does ")#emph[#text("not")]#text(" obey a bell curve distribution, because one single factor – gender – makes so much of an impact on height that it is not averaged out by all the other environmental and genetic factors that influence this statistic.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/mindprod.com/image/math/livinghistogram.jpg")[Original image]]]

#text("Fig 23. A \"living histogram\" of 143 students at the University of Connecticut, with females in white and males in black. (Source: The Hartford Courant, “Reaching New Heights,” November 23, 1996) Compare this non-bell-shaped distribution with Figure 5.")

#text("Another very important way in which the central limit fails is when the individual factors that make up a quantity do not fluctuate independently of each other, but are instead ")#emph[#text("correlated")]#text(", so that they tend to rise or fall in unison. In such cases, “fat tails” or “black swans” can develop, in which the quantity moves much further from its average value than the central limit theorem would predict. This phenomenon is particularly important in financial modeling, especially when dealing with complex financial instruments such as the ")#link("http://en.wikipedia.org/wiki/Collateralized_debt_obligation")[#text("collateralised debt obligations")]#text(" (CDOs) that were formed by aggregating several mortgages together. As long as the mortgages behaved independently of each other, the central limit theorem could be used to model the risk of these instruments; but in the recent financial crisis, this independence hypothesis broke down spectacularly, leading to significant financial losses for many holders of these obligations (and for their insurers). A mathematical model is only as strong as the assumptions behind it.")

#link("http://seekingalpha.com/article/108867-the-capitalism-distribution-fat-tails-in-motion")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/static.seekingalpha.com/uploads/2008/12/3/saupload_chartwwww_1.jpg")[Original image]]]]

#text("Fig 24. A histogram of returns for individual stocks, when compared against the Russell 3000 average. Note the fat tails and the large number of extreme deviations from the mean. (Source: seekingalpha)")

#text("A third way in which a universal law can break down is if the system does not have enough degrees of freedom for the law to take effect. For instance, cosmologists can use universal laws of fluid mechanics to describe the motion of entire galaxies, but the motion of a single satellite under the influence of just three gravitational bodies can be far more complicated, as the next figure shows.")

#link("http://www.nasa.gov/mission_pages/themis/news/artemis-orbit.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/www.nasa.gov/images/content/477658main_Artemis.jpg")[Original image]]]]

#text("Fig 25. The trajectory of the ARTEMIS-P1 Earth-Moon orbiter. The gravitational effects of the earth, moon, and sun combine to create an orbit which is chaotic, despite the relatively low number of degrees of freedom. The transition between the L1 and L2 orbits are powered, but the L1 and L2 orbits themselves are unpowered. (Source: NASA)")

#text("Another instance where the universal laws of fluid mechanics break down is at the ")#link("http://en.wikipedia.org/wiki/Mesoscopic")[#text("mesoscopic")]#text(" scale – larger than the microscopic scale of individual molecues, but smaller than the macroscopic scales for which universality applies. An important example of a mesoscopic fluid is the blood flowing through blood vessels; the blood cells that make up this liquid are so large that they cannot be treated merely as an ensemble of microscopic molecues, but as mesoscopic agents with complex behaviour. Other examples of materials with interesting mesoscopic behaviour include ")#link("http://en.wikipedia.org/wiki/Colloid")[#text("colloidal")]#text(" fluids (such as mud), and certain types of ")#link("http://en.wikipedia.org/wiki/Nanomaterials")[#text("nanomaterials")]#text("; it is a continuing challenge to mathematically model such materials properly.")

#metadata(none) <tao-2a22c47c22aa6bb8d898>

#link("http://www.nature.com/nm/journal/v9/n5/full/nm0503-481.html")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/blood.jpg?w=490")[Original image]]]]

#metadata(none) <tao-66e01874a6eed1af488a>

#text("Fig 26. Red blood cells in an arteriole. (Source: P.M. Motter and S. Correr, Science Photo Library)")

#text("There are also many macroscopic situations in which no universal law is known to exist, particularly in cases where the system contains human agents. The stock market is a good example: despite extremely intensive efforts, no satisfactory universal laws to describe the movement of stock prices have been discovered (the central limit theorem, for instance, does not seem to be a good model, as discussed earlier). One reason for this, of course, is that any regularity in the market that ")#emph[#text("is")]#text(" discovered, is likely to be exploited by arbitrageurs until it disappears. For similar reasons, finding universal laws for macroeconomics appears to be a moving target; according to ")#link("http://en.wikipedia.org/wiki/Goodhart's_law")[#text("Goodhart’s law")]#text(", if an observed statistical regularity in economic data is exploited for policy purposes, it tends to collapse. (Ironically, Goodhart’s law is itself arguably an example of a universal law…)")

#text("Even when universal laws do exist, it may still be practically impossible to use them to predict what happens next. For instance, we have universal laws for the motion of fluids, such as the Navier-Stokes equations, and these are certainly used all the time in such tasks as weather prediction, but these equations are so complex and unstable that even with the most powerful computers, we are still unable to accurately predict the weather more than a week or two into the future.")

#text("In conclusion, we see that between the vast, macroscopic systems for which universal laws hold sway, and the simple systems that can be analysed using the fundamental laws of nature, there is a substantial middle ground of systems that are too complex for fundamental analysis, but too simple to be universal. Plenty of room, in short, for all the complexities of life as we know it.")

#heading(level: 2)[#text("6. Further reading")]

#list(
[#text("Percy Deift, “")#link("http://arxiv.org/abs/math-ph/0603038")[#text("Universality for physical and dynamical systems")]#text("“, International Congress of Mathematicians, Vol. I, 125–152, Eur. Math. Soc., Zürich, 2007.")],
[#text("Brian Hayes, “")#link("http://www.americanscientist.org/issues/pub/the-spectrum-of-riemannium")[#text("The spectrum of Riemannium")]#text("“, American Scientist, 2003.")],
[#text("Dan Rockmore, “Stalking the Riemann hypothesis”, Pantheon Books, New York, 2005.")],
[#text("Terence Tao, “")#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("Small samples and the margin of error")]#text("“, blog post, 2008.")],
[#text("Terence Tao, “")#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")[#text("Benford’s law, Zipf’s law, and the Pareto distribution")]#text("“, blog post, 2009.")]
)

#heading(level: 2)[#text("7. Footnotes")]

#enum(start: 1, 
[#text("Actually, this is an oversimplification: some of the factors mentioned in the text ")#emph[#text("do")]#text(" make a slight difference to the margin of error. For instance, the margin of error when there are a hundred million voters is actually closer to 3.1%, while for a hundred thousand voters it turns out to be about 3.08%. More significantly, the idealised assumptions applied here do not hold in real-world polling. Not every voter is equally likely to be polled; for instance, in a telephone poll, voters with telephones clearly have a greater chance of being polled than voters without telephones. Not every person polled will eventually vote. Not every person polled will actually answer the pollster’s questions correctly, or at all. And, if a poll organisation is partisan, it may give favorable polls more publicity than unfavorable polls. All of these factors can widen the margin of error, or bias the result one way or another, although this can often be compensated for by using the correct methodology. On the other hand, the accuracy and bias of a polling organisation can be discerned through the long term record of that organisation’s polls, by yet another application of the law of large numbers. Once one has this information, one can combine the most recent polls from several organisations via a weighted average into what is effectively a single large poll, which in principle has a smaller margin of error and less bias than any individual poll. These meta-analyses of polls, which exploited the universal law of large numbers multiple times, ended up giving among the most accurate predictions of the election. (In the case of Nate Silver’s predictions, this method was also combined with a demographic analysis, for instance using polls from counties with similar demographic features to calibrate each other by a statistical technique known as ")#link("http://en.wikipedia.org/wiki/Regression_analysis")[#text("regression")]#text(", to increase the accuracy even further.)")],
[#text("Again, this is an oversimplification; when dealing with statistics that cannot be negative numbers (such as number of car crashes, or human height, but not the profit or loss from a day of trading), then one often has to replace the normal distribution by a slight variant known as the ")#link("http://en.wikipedia.org/wiki/Log-normal_distribution")[#text("log-normal distribution")]#text("; when dealing with statistics of a multi-dimensional nature, such as a three-dimensional velocity, then another variant known as the ")#link("http://en.wikipedia.org/wiki/Chi-square_distribution")[#text("chi-squared distribution")]#text(" may be needed; and so forth.")],
[#text("Strictly speaking, this clustering behaviour only occurs for a certain subclass of phase transitions known as ")#emph[#text("continuous")]#text(" or ")#emph[#text("second-order")]#text(" phase transitions, which do not involve the additional complication of ")#link("http://en.wikipedia.org/wiki/Latent_heat")[#text("latent heat")]#text(".")],
[#text("The role of child care in mathematical research should not be underestimated. One of my own collaborations, with Emmanuel Candés in the subject of compressed sensing, took place in no small part in the preschool where we dropped off our respective children.")]
)

#heading(level: 1)[#text("Comments (53)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Einfach genial ! « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-46997")[#strong[#text("Einfach genial ! « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("[…] September 2010 in Allgemeines, Mathematik | Tags: terence Tao über Man muss dieses einfach lesen. Was er als „A second draft ..“ bezeichnet ist mehr als genial. Wie sieht dann erst die […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d4121c1b1a94d832990865939158fdff7ef16b22a2de4c0a9f58b4e829924e-924c4de11387f3dd841345d05b12a9736ceef58a9bae3acd0b253e5fe35d1675.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maya Incaand")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-46999")[#strong[#text("Maya Incaand")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Nice job!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47002")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Microscopics:")

#text("1. “an infinitesimal fraction of the entire population” could be “a tiny fraction of the entire population” as “infinitesimal” is mathematical jargon and the fraction is actually finite. ")#emph[#text("[Reworded. -T.]")]

#text("2. “Perhaps the most spectacular instance of this was the predictions of the statistician Nate Silver”. I do not find it spectacular that amongst a huge number of statisticians a few ones are correct by chance. ")#emph[#text("[Well, this would be true if everyone was only guessing the answer to a binary question (Obama or McCain?), but here the record is 49/50 states and 35/35 Senate elections, which is quite difficult to explain as a consequence of survivor bias alone. Of course, the upcoming 2010 midterm elections should provide a good test of Silver’s long term accuracy with these matters, and presumably I will have to update the text to reflect that outcome. – T.]")]

#text("3. See ")#link("http://en.wikipedia.org/wiki/Wikipedia:Reference_desk/Mathematics#basic_probability_.2F_stats_question")[#text("http://en.wikipedia.org/wiki/Wikipedia:Reference_desk/Mathematics#basic_probability_.2F_stats_question")]#text(" regarding how to predict populations based on perhaps very small samples.")

#text("4. “A histogram of the height of adult human males” is “A histogram of the height of 1000 adult human males” ? ")#emph[#text("[Corrected, thanks – T.]")]

#text("5. “the zeroes seem to “repel” each other”. Zeroes of polynomials always repel each other when the cooefficients are perturbated. The square roots of a random variable which is uniformly distributed inside the unit disk, are close to the rim. ")#emph[#text("[Yes, though this doesn’t fully explain the amazing fit between the zeta zero spacings and the random matrix predictions in Fig 22. I’m not sure how to raise this point without the text becoming more technical, though. -T]")]

#text("Macroscopics: Very nice article. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47003")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("“A homogeneous bloc of (say) affluent white urban voters, or a mix of voters of all incomes, races, and backgrounds? ”")

#text("This might be a slightly confusing formulation. If the voters are all affluent whites the error will be low, but some people might take it to mean that if you sample only white affluent voters, by choice or chance, the error bars will still be low even if there are other kinds of voters.")

#emph[#text("[Reworded slightly. Actually, the margin of error of a poll (which measures the deviation of the poll result from the actual electoral result) is indeed independent of how homogeneous the voter population is, except in the very extreme case where the population is so homogeneous that it votes at something like 99% or more for one candidate instead of another. -T.]")]

#text("The upper part of figure 3 is also confusing because of lack of explanation. 50% of what? ")#emph[#text("[Also reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcaa3ebf7832d779b8ce96bdeb0d8775a03eea1df582551a20dc006ddd073824-2b783f3dda511e0bb06e07391363fab592c2b4969a53655726511ffbe2b34d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MCapel")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47004")[#strong[#text("MCapel")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Very nice article!")#linebreak()#text(" I have a question about Benford’s law: the probability that a number begins with the digits 3, 1, 4 is log(1+1/314), right? Does it means, that a number with an infinite number of digits (not equal to 0) is impossible to found in “real life”?")

#emph[#text("[Well, yes, it is quite unlikely for a given statistic to begin with a specific three-digit number, such as 314 – but on the other hand, there are 900 different three-digit combinations that a statistic could have as its leading digits, and the total probability still adds up to 1. In the infinite limit, each individual infinite string of digits has a zero probability of coming up, but there are an infinite number (in fact, an uncountable number) of such strings, so this is not incompatible with the basic axiom of probability that the total probability must always be equal to 1. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47008")[#strong[#text("Phil")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("“There was the same uncertainty at the state level: while many states were considered safe for one candidate or the other, at least a dozen states were considered “in play”, and which could conceivably go either way.”")

#text("“Which” is presumably a typo here.")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb8da7504f1625a4ae79f32845c07186f254b1c555c232ab5f8c9aff512c9127-0910c835590111778f5dbfc0e41ba7940c6beff67d73a78ab0c2ee273f06c727.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen K.")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47010")[#strong[#text("Allen K.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#emph[#text("These effects can be compensated for to some extent by the proper methodology, but some poll organisations are more careful about this than others.")]

#text("I think “less careful” makes more sense. (And “more careful” makes less sense.)")

#text("Unless you snarkily meant that some are more careful to downplay the polls they don’t like, in which case I approve.")

#emph[#text("[Reworded to be more neutral in tone – T.]")]

#emph[#text("our ")]#text("respective")#emph[#text(" children")]

#text("I’m pretty sure that not many readers would have inferred that, if you and Candes had children in common, that you would principally encounter one another at preschool. But it’s good to be clear about these things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b4b839e096870bd0a232e5aa9457125af1c2515d8a27c51f3f43896bbce740b-ab922a9613e39f5f7a45c484e5a137613e8928de1fbfde28f3953381436e9307.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Vladusich")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47011")[#strong[#text("Tony Vladusich")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Reads quite nicely! Figure 3 seems to imply a relationship between the law of large numbers and the central limit theorem. If true, is this something worth mentioning? ")#emph[#text("[Added a comment to this effect – T.]")]

#text("The fragments below all contain minor typos or word omissions:")

#text("a site percolation model on a hexagonal lattice, in which each hexagon (or site) is an abstraction of an atom or molecule is randomly placed one of two states")

#text("These laws seem arise in almost every mathematical model")

#text("but the internal structure of larger nuclei are so complex …(should read “structures”)")

#text("known as the (non-trivial)zeroes")

#text("”What will we talk about?” is (first quotation mark is back-to-front)")

#text("Montgomery begin to explain his recent results")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of temur")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47012")[#strong[#text("temur")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("There seems to be a typo in the second paragraph after the two election maps:")

#text("One of the remarkable thing about the law of large numbers ")#strong[#text("it")]#text(" is that it is universal. ")#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2c4d6a5fdd44d20029d8dc8e4a9b65cc5055c071b2742c8e68fbae15967758f-af45f4f1844ea1c8ee5e4077883386f4173087541373b20b3039bb9f9f849bef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47014")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Dear Terry,")

#text("What type of laptop do you use?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michelle")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47016")[#strong[#text("Michelle")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("can you include a brief example of positive vs negative statistics, as you do with multi-dimensional cases. ")#emph[#text("[The daily profits and losses at Citigroup were intended as an example of a signed statistic; reworded to emphasise this. -T]")]

#text("you start referring to the zeta function without explicitly defining it, would that be helpful or just confusing? ")#emph[#text("[Added a note that the precise definition of zeta is not necessary to follow the article. – T.]")]

#text("great article!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47017")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("A fun read! The images are a great addition and I’m very impressed by how you manage to reference so many different kinds of science in one article.")

#text("My two cents regarding ‘hooks’ etc. follow:")

#text("While leading with Nate Silver’s success story is a pretty good way to start, that story is well-known and, more generally, political polling is familiar to most people; even if they don’t understand the math, the idea that these polls ‘work’ to a certain degree isn’t as compelling as it might be .")

#text("I question that hook because perhaps you’ve got a much better lead already in the article! Specifically, I’m referring to the narrative about Dyson and Montgomery. This is an excellent lead for several reasons:")

#text("It puts a human face on the story.")#linebreak()#text(" It’s a very literal, easy-to-grasp manifestation of universality – the same idea showing up in two seemingly disparate fields! Even the experts didn’t see it coming! Wow!")#linebreak()#text(" It conveys the sense of wonder, discovery, epiphany, and fruitful collaboration that people find compelling (and relatable to) in writing about science that they don’t understand directly. The reader might not understand random matrix theory, or even have heard of it, but they can certainly relate to the joy of finding an unseen connection, of the joy of productive work with someone else.")#linebreak()#text(" The best part from a narrative perspective is your author’s note that you had a parallel experience! This is absolute ")#emph[#text("gold")]#text(" . It humanizes you, the author, it makes the whole thing instantly more relatable to most readers, it’s a fascinating insight into the way scientific discovery and human interaction are linked, etc. etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47025")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("I’m not so sure about this paragraph:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Most materials have one or more critical temperatures, below which the material is in one state (e.g. a solid), and above which the material is in another (e.g. a liquid). But when the material is at or very close to the critical temperature, interesting phase transitions occur, in which the material is not fully in one state or the other, but tends to split up into beautifully fractal shapes known as clusters, each of which embodies one or the other of the two states.")
]

#text("100 degrees Celsius at one atmosphere is not a critical point of H20; 374 degrees and 218 atmospheres is. You don’t see critical opalescence when boiling water on the stove.")

#emph[#text("[Ah, you caught me out here. I was trying to sweep the two-parameter nature of the phase diagram under the rug to simplify things, but you’re right, this leads to a misleadingly oversimplified picture. I’ve reworded somewhat, though I still want to avoid getting overly technical regarding this point, especially since how many of the toy models, e.g. percolation and Ising type models, have only one key parameter rather than two")#strike[#text(", as they are modeling first-order phase transitions rather than second-order ones")]#text(". – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47026")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("I like the rewording!")

#text("There’s ")#link("http://arxiv.org/abs/0905.1886")[#text("so much interesting history")]#text(" and so many lovely technicalities in this subject, it’s hard to stop talking about them. But, I agree: they’d really be a distraction in this piece.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47027")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("The Ising model without applied magnetic field has one dimensionless parameter (the ratio of coupling energy to thermal energy) but its phase transition at ")#mi("T_C")#text(" is ")#link("http://farside.ph.utexas.edu/teaching/329/lectures/node110.html")[#text("second-order")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47028")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text(". . . or are we defining “order” in two different ways? E.g., “a second-order transition is where a line of first-order transitions stops” versus using the discontinuities in the free energy or its derivatives.")

#emph[#text("[Hmm, it’s only after you pointed this out to me that I realised that I did not quite have the right definition of order in a phase transition. Sorry for any confusion. – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47029")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Dear Terry,")

#text("Searching in the Wikipedia, the latin motto in your title also has some classical reminiscences of universality, e.g. when Virgil describes the blending of colors into one as ")#emph[#text("color est e pluribus unus.")]

#text("All my best,")#linebreak()#text(" Miguel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47030")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("I liked really a lot the second part, let’s say from chapter 3 on. The intro is great too. However, as a first impression, I have found the first part perhaps a little too long and wordy. I am afraid that with so many details the reader could miss the main points that you are trying to make and just quit right away.")

#text("I’d like to second Johan comment above. I would actually remove that paragraph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47032")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("i just read the voting part, it was interesting but can be shortened slightly may be. One suggestion though for the intro…before launching into the entire 2008 story, you could use a short paragraph saying many laws of maths are universal, one example being LLN. and then may be say LLN concerns, number of times a coin lands heads or number of mornings it will rain etc. and then say a nice application of LLN is exit polls….")

#emph[#text("[Added a short description of the LLN. Not sure where to cut the first section though without losing some of the larger structure – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47053")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#text("The place to cut or reduce could be the discussion starting from “The above discussion was an oversimplification for several reasons” to “technique known as regression, to increase the accuracy even further.” Oversimplification is fine for a popular article if it helps to keep the flow easy. This applies more generally, you have tried to be very careful at some places pointing technical caveats in parenthesis. If you really want to be that careful you could say it in one line at the end of the article that some minor simplifications have been made etc….")

#emph[#text("[I’ve started moving some of the caveats and side remarks to footnotes. Will keep working on this aspect of the text. – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75e777514f5b1c071a5889cfc83f2e7d595daba29908aef18a101e2efa86334b-c73ddc684cda3c4ec527fbeb1c3374290457435b3822877034c686dfd541c585.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ionica")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47035")[#strong[#text("Ionica")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Wow, you improved the text in so many ways! The sections are well-chosen and I like the quotes at the beginning of each one. The images are also great, I love the living histogram. It is also very nice how you keep emphasizing things we do not know and current research (without going into the technicalities).")

#text("Some small remarks:")

#text("* I think the first section is great for drawing non-mathematical readers in, though I second the commenters who suggest it might be shortened a bit.")

#text("* In the second section it would be good to add Zipf’s law predictions in the figures (as you did for Benford’s law). You might also consider adding a rudimentary bell shape in the histograms for the CLT.")

#text("* The beginning of the third section was the hardest for me to read. I am afraid this might be a drop-out point for some readers. Maybe you could put one of the images earlier, or give an example to motivate people to keep reading.")

#text("* In section 4 you should remind people (briefly) of the definition of prime numbers. ")#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott McKuen")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47038")[#strong[#text("Scott McKuen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("“does not have not enough degrees of freedom” – two uses of “not” ")#emph[#text("[Corrected, thanks – T.]")]

#text("I’ve gotten a lot of enjoyment from both versions of this article – as you said, they are really different. Definitely this one has a breezier tone and is friendlier to the lay reader, and I think it’s better for the stated purpose. That said, the first version is the one that makes me want to read more about random matrix theory….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96b296a65baa000a9b3d86746b6f6bf97e6b04a8cb0ba2c7974c009e9648685a-cf444f34139523566652e214b6c0941d838fa2017da7cc07b2a870d88aedbde8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu Raghavan")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47044")[#strong[#text("Raghu Raghavan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("Should you not mention the renormalization group that revolutionized the understanding of universality in physics, and has such a nice dynamical systems picture? ")#emph[#text("[Added a brief note, though I wish to avoid technical details in this article. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47049")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("very nice article….the part about resonance was not very clear to me. also may be you should consider explaining the term “distribution” somewhere, its used quite often. last paragraph “the simple systems that can be analyzed using the fundamental laws of nature” not really clear what you mean, may be I missed an earlier reference to simple systems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#text("Thanks for all the feedback! I will try to incorporate the feedback to the draft over time, though I may hold off on major reorganisation until later (but I am unlikely to try to rewrite the article from scratch a third time…). I will also probably err on the side of adding material for now, rather than deleting it, as deletion is relatively easy to accomplish later.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7c3fc34d374d3629eeff64b47ae8383d6004c985a6c827db81e96d036264ce4-ef0dbc61a11a9725a0f3946de542561e362be1bcb51b69edb465bff94c6bbade.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julie Rehmeyer")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47054")[#strong[#text("Julie Rehmeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#text("Writing for the public is pretty interesting, isn’t it? Certainly keeps me on my toes.")

#text("Here are some comments on the first three sections. I should be able to get you more later.")

#text("Huge improvement, and I like your lead.")

#text("You need a new fourth paragraph. Instead of jumping into the mathematics, you need to tell the reader what it all adds up to and give them a sense of what’s to come, and do it in a way that’s going to entice them to keep reading to find out the details. This is what journalists call the “nut graph,” giving readers the nut of the story.")

#text("Do more of the kind of thing you do in the lead. When you discuss the central limit theorem, get us there through a well-told example. Benford’s Law is a rich source of compelling examples, of course. I also think you should introduce Zipf’s Law in a more dramatic fashion — it’s pretty amazing that such a phenomenon could be so widespread and yet so poorly understood mathematically. I also think that could lead into the discussion of phase transitions nicely: Hey look, here’s an area at the cutting edge of math research where we also don’t understand how universality comes about!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9c497f69523d5d7cd6b5a133d93c6a95262fa19b1701682c467547eaa62308f-0c541b538cfed6b9d52be64079e2509a6e3e1873d23750ceab02473be5d8da5e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sterling")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47056")[#strong[#text("Aaron Sterling")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#emph[#text("You need a new fourth paragraph. Instead of jumping into the mathematics, you need to tell the reader what it all adds up to and give them a sense of what’s to come, and do it in a way that’s going to entice them to keep reading to find out the details.")]

#text("I agree, and I also believe examples of the strong law of large numbers should precede the formal statement of it. This is more important than “normal” because “if one flips” and “if one selects” is a standoffish style, so the text as is will jar a lot of readers into a sudden “oh I’m in math class again” mode. One possible strengthening: have a specific human being the reader can identify with conducting the random experiments, instead of/before abstracting out to the generic “one.”")

#text("If I might suggest a general principle: use words to paint a picture of an allegorical representation of the concept. Parables, Aesop’s fables. A good example of this principle applied to mathematical exposition is Feynman’s story of the mother, the child and the 28 blocks, which he used in his third lecture on the character of physical law. (Video three here: ")#link("http://research.microsoft.com/apps/tools/tuva/index.html#data=4")[#text("http://research.microsoft.com/apps/tools/tuva/index.html#data=4")]#text("|84edf183-7993-4b5b-9050-7ea34f236045|| )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700ab9f86612d3fbb55778d307f50d45851d62f8a301710b8c6150123ae5c040-7ca199af677ea05871200f3b5779678b6d3938c79b5a64268da03358a6ad0ab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grad Student")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47090")[#strong[#text("Grad Student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2010")])]

#text("I liked your first draft, but this one is much better and more fun to read, even though I am familiar enough with the field to have understood the previous one just the same.")

#text("For us more technical folks, it would be nice if you could post separately the academic papers that you mention without citing in the popular article, so that we can take a look at them ourselves.")

#text("A typo:")#linebreak()#text(" “This convergence arises not because there of any “low-level” or “microscopic” connection…”")#linebreak()#text(" It seems like the word “there” should be removed. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rebelJinn")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47109")[#strong[#text("rebelJinn")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("Shouldn’t")

#text("“other materials become electrical conductors at some temperatures and insulators in others. ”")

#text("be")

#text("“other materials become electrical conductors at some temperatures and insulators at others. “? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47330")[#strong[#text("עדכונים: מתמטיים | ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2010")]

#text("[…] קצת על מתמטיקה בלי הפרטים הטכניים – תעיפו מבט בטיוטה של טרנס טאו על תיאוריות אוניברסליות. מדובר בתיאוריות מתמטיות כלליות שנכונות לכל נושא […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47338")[#strong[#text("Wiskundemeisjes » Blog Archive » Levende histogrammen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")]

#text("[…] ontdekte deze mooie foto’s dankzij Terence Tao’s (zeer aan te bevelen) artikel over universaliteit. Kennen jullie meer voorbeelden van mensen die grafieken uitbeelden? « Slangen en […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fb06dfb615ee8973b175e406fd3e81ba4006d6578f4f9f2a6260aa3bcccb8ab-a9004eb4217989ea1a7e1078ac510d9ca5ba215ea417c773e93df17c7bb15f63.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian S. Perone")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47352")[#strong[#text("Christian S. Perone")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Great thanks for that man ! A very nice reading, keep going !!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6351b8ac7aaaf1226949432cb775f977c07e0da0338f15b40ab464bfaa5b15c-b8faa30f60ad996e03e225c56fee47f31cf1f4df586a575cda27acb2fd46e63d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AGT")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47359")[#strong[#text("AGT")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Nate Silver’s three part (blog) series “The Uncanny Accuracy of Polling Averages” on nytimes.com ties in nicely with this piece.")

#text("I especially liked the bit where he says “…it’s tempting to think of each Senate race as its own little unique snowflake. But the polling has provided a reliable guide in the vast majority of races. It is not enough for a race to be unique: it has to be unique in a way that renders the polling much less accurate than it ordinarily would be. If you think you’ve encountered such a case, you should be prepared to make a strenuous argument for it.”")

#text("It is amazing how robust some predictions in the face of uncertainty are.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-47381")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#text("Fat tails in price distribution are ubiquitous in all and any kinds of assets, not just those composed of other, more atomic, assets. Anyway, wouldn’t an asset composed of correlated assets with Gaussian price distribution, have a Gaussian price distribution? The remarkable phenomenon is that the fat tailness of individual assets survives when they are combined in a portfolio, instead of becoming Gaussian, the fact that is “explained” by the stability of Levy distribution. Thanks for the article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b3c4469088543cc994173661acb4f8b6365b2e98984dfaa87523edfb26a23c0-56b60a7063d4006fff7dd34809eaa6b004c4f19eefc7c26d1483318432e45bd1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carcar")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-49475")[#strong[#text("carcar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2011")])]

#text("Why don’t you upload it on arxiv? It would make reading easier.")

#text("Of course, the blog version is useful anyway (it allows comments).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-49852")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")]

#strong[#text("In what conditions would you expect a power-law distribution curve to emerge?…")]

#text("The basic reason is that the power law is one of two (!) possible kinds of distributions we can get when we look at the “top few” outcomes of a lot of random draws. Since cities are the largest human settlements, we shouldn’t be too surprised to see…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Universality « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-49929")[#strong[#text("Universality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2011")])]

#text("[…] undergraduate, I gave a fairly non-technical talk on the universality phenomenon, based on this blog article of mine on the same topic. It was a quite light and informal affair, and this is reflected in the talk slides (which, in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-50067")[#strong[#text("Letture e suoni per il sabato – 6 Febbraio 2010 | Se me lo dicevi prima")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2011")]

#text("[…] (medaglia Fields a 21 anni) e i contenuti del suo blog sono di solito incomprensibili ai più. A second draft of a non-technical article on universality fa parte dei rari post per il grand public, ben scritti e godibili a chiunque sia abbastanza […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-50285")[#strong[#text("Links « Epanechnikov's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2011")]

#text("[…] A non-technical article on universality (Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-52660")[#strong[#text("Maples on Cohen-Lenstra for matrices with iid entries « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2011")]

#text("[…] Universality of random matrix laws is a very active and fast-moving topic, but Maples’ result is the first universality result for p-adic matrices that I know of. More generally, I think there’s a lot to be gained by understanding how well the richly developed theory of random large real and complex matrices carries over to the p-adic case. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-94234")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2011")])]

#text("First of all Terry, I think it’s admirable that you rewrote the article from scratch.")

#text("In my opinion, a strong title and first paragraph require the most time and attention. Second and third paragraph less so, and thereafter you’ve more or less won the reader’s time.")

#text("With that in mind here are a few suggestions for the start:")

#text("* countless — does that mean anything? Could be omitted / avoided.")

#text("Maybe start with a question.")

#text("*Even more* concrete language than “campaign rhetoric, the media coverage, rumors, personal impressions of the candidates, or from discussing politics with friends and colleagues”")

#text("* For example give some examples of the incendiary rhetoric, especially sound bites that demonstrate your overall point.")

#text("The quotes are good, though perhaps a little too close together.")

#text("Consider this opening.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("On Oct 8, 2008, the United States was about to elect its first black President in a 250-year history dominated by whites. But we didn’t know that then. Or did we? What if I had said eighteen months prior to Barack Obama’s electoral victory over John McCain that I could tell you, with certainty, that he would be the next Commander in Chief of the most powerful army in the world?")

#text("(Perhaps consider the eve of the Democratic Primary — would the US put forward a woman, or a (half) black, as its major candidate? Either would be an historical event.)")

#text("Elections, it would seem, are inherently unpredictable. After all, there are at least 900 million questions to be answered in a US Presidential election — for each of the 300 million potential voters, how many (1) will register, (2) will actually vote, and (3) who will s/he vote for?")

#text("Too, their electoral decisions are swayed by who-knows-how-many “soft” factors: a candidate’s shave; discussions with one’s pastor or squash partner; what CNN says about Michelle Obama’s sweater; or one’s position on gay rights, healthcare, the economy, abortion, and so on. (And which single issue or combination of issues is determinate for a particular person? How could we know?) Besides the quantity of actors and factors, each individual has free will. Predicting voting behaviour is unlike solving differential equations to predict how a baseball pitch will curve. The baseball doesn’t have a choice. But a poor, black, unionised, female, lifelong Democrat can and might still vote for John McCain, despite all the assumptions we might make about her based on demographics. (Is there an example of such?) A white, racist, union-hating, lifelong Republican might vote for Barack Obama despite what we would assume based on psychographics. (Maybe that person felt strongly about healthcare for example.)")

#text("The total uncertainty is mogrified by the United States’ nontrivial vote-counting system. Mathematically speaking, one doesn’t just answer whether 50% + 1 voters would support John McCain or Barack Obama. Third party candidates may change the winning-plurality figure to maybe 48% (Bill Clinton earned …42% of the popular vote..). More vexingly, the electoral college system splinters the prediction problem. One has to consider different plurality-percents in 50 different states, and instead of one vote mattering one 105-millionth anywhere in the nation, one vote in Broward County, FL, might be worth all of Florida’s 20 million votes combined.")
]

#text("The above is no Chuck Palahniuk. But what I’m trying to do differently than your opening is:")

#text("* be more punchy")

#text("* use concrete examples")

#text("* the examples allude to other things that were said around election time")

#text("* set up something big which I claim I will knock down.")

#text("Roughly speaking … converge to a certain number, known as the expected outcome of that random method.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Mathematics may actually suggest that predicting the average of what 200 million people do is EASIER than predicting what just one person will do. How could that be so? How could 200 million equations be easier to solve than just one?")

#text("Let’s admit that we don’t know how anyone will vote. Let’s think of their vote like a completely random coin toss. Heads, Republican; tails, Democrat. On an individual level, you never know whether a coin will turn up heads or tails. It could be 1 or it could be 0. But you DO know that, after a thousand tosses, you almost certainly won’t have just 1 head to 999 tails. In fact, the number of heads out of a thousand tosses probably should be in the neighbourhood of 460-540. (calculate) Paradoxically, it may seem, it’s EASIER to predict a thousand coin tosses than to predict just one. It’s easier still to predict the result of a million, a billion, a vinilennidecillion coin tosses.")

#text("There is a natural law, a logical, mathematically derived, reason that predicting 200 million random factors is easier than predicting just a few: the Law of Large Numbers. Roughly speaking, the LLN states that (1) we can calculate what outcome is most likely to occur, and (2) we can calculate the PROBABILITY that that most-likely outcome occurs, as the number of coins, voters, gas particles, …. increases.")

#text("The black female unionist lifelong Democrat does have a choice in her vote, but maybe we should think of her as a WEIGHTED coin — with odds very much biased in favour of 2008’s Democratic candidate.")
]

#text("* work from specific to general")

#text("* short sentences")

#text("* you don’t need to be precise")

#text("One more thought: the subtitle doesn’t distinguish your article from hundreds of other non-technical math articles on any topic. Specificity, senses, hooks.")

#text("Good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca0a6624b26101f5bdb310233fa10a408a695e79ea614dbe7de5c4a8a62fee4e-24966f52b60597b4192d6bc22d38f7e45812802ae1c1f344fbdbc2e48f150a45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TBA")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-206642")[#strong[#text("TBA")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2012")])]

#text("Great article! But Fig 4 confused me because it doesn’t look Gaussian (it isn’t very symmetrical). Wouldn’t a histogram of accidental deaths per month be Poisson distributed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-206919")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2012")])]

#text("The Poisson distribution asymptotically approaches a Gaussian distribution when the expectation parameter ")#mi("\\lambda")#text(" becomes large (this is a variant of the central limit theorem). (It is true, though, that the Poisson distribution would be a slightly better approximation in this case, though for the purposes of this non-technical talk I prefer not to highlight these subtle distinctions.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-216015")[#strong[#text("The Spectral Beauty of Universality | REALscience")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2013")]

#text("[…] mathematics awareness month in 2010 Tao describes universality in the distribution of prime numbers. He says, “The prime numbers are distributed in an irregular fashion through the integers; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-218344")[#strong[#text("The Universal laws behind growth patterns, or what Tetris can teach us about coffee stains | Empirical Zeal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")]

#text("[…] You can think of universality classes like a sort of mathematical filing cabinet. Say that you’re studying how ice particles clunk together on your windshield. If the rate at which the skyline widens matches the blue curve above, ice clunking is in the same universality class as Tetris. If it matches the purple curve, then ice clunking is in the same universality class as Sticky Tetris. Now, there are other universality classes out there, and not all growth processes can be neatly filed into a universality class. But the key point is that many seemingly different physical systems, when analyzed mathematically, show identical patterns of growth. This slightly mysterious tendency for very different things to behave in very similar ways is the essence of universality. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6830c6beca1a584689d6d1f956e65d98c97f68f8a883082f0db3c64b30bc2cb7-a0305212d0bfe01cae89ee27eac506cc960f52322c1643f37022f64666c50561.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan S")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-218914")[#strong[#text("Dan S")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2013")])]

#text("Very interesting article – thanks. I was glad to see the “When it fails” section, because sometimes articles can become too “just-so”.")

#text("Two bits of feedback on the writing: (1) the length will be difficult for some generalist readers – consider serialising perhaps; (2) please don’t use phrases like “the details are too technical to give here” – it foregrounds the reader’s incompetence. There are better ways to let us know you’re skipping over something which you regard as part of the “proof”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-320139")[#strong[#text("Universality and Random Matrices | Vuhavan's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")]

#text("[…] weeks ago, I gave a survey talk at IAS on random matrices. The topic is the Universality Phenomenon (click on the link to see an informal discussion by my coauthor T. Tao) which has been one of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-429780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("A translated version of this talk (in German), illustrated with photographs and other imagery by Jochem Berlemann, has now been published at ")#link("http://www.e-enterprise.de/Mathematik-Programm/Komplexitaet-und-Universalitaet.html")[#text("http://www.e-enterprise.de/Mathematik-Programm/Komplexitaet-und-Universalitaet.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-446921")[#strong[#text("Random matrix theory (RMT) in finance | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")]

#text("[…] For a good first treatment see this non-technical article by Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-456330")[#strong[#text("Universality and orthogonal polynomials | Nonempty Spaces")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2015")]

#text("[…] plot for Gadolinium 156 nucleus. (The source of the image is ")#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")]#text(" , but the original one can be found in the article C. Coceva and M. Stefanon, Experimental aspects […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-487947")[#strong[#text("Universality and orthogonal polynomials – Tivadar Danka")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2017")]

#text("[…] plot for Gadolinium 156 nucleus. (The source of the image is ")#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")]#text(" , but the original one can be found in the article C. Coceva and M. Stefanon, Experimental aspects […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-625192")[#strong[#text("Why do my Stack Exchange reps follow a power law? ~ Mathematics ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")]

#text("[…] there a universality argument for why this power law might […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/#comment-641001")[#strong[#text("Random matrix theory (RMT) in finance - Finance Money")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2022")]

#text("[…] For a good first treatment see this non-technical article by Terence Tao. […]")
]
