// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/
// Converted to Typst by tao2typ: "2026-10-14T10:52:23.318815+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Living Proof: Stories of Resilience Along the Mathematical Journey", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Living Proof: Stories of Resilience Along the Mathematical Journey")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 June 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/")[#text("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The AMS and MAA have ")#link("https://blogs.ams.org/inclusionexclusion/2019/06/26/living-proof-a-must-read/")[#text("recently published")]#text(" (and made ")#link("https://www.ams.org/about-us/LivingProof.pdf")[#text("available online")]#text(") a collection of essays entitled “")#link("https://blogs.ams.org/inclusionexclusion/2019/06/26/living-proof-a-must-read/")[#text("Living Proof: Stories of Resilience Along the Mathematical Journey")]#text("”. Each author contributes a story of how they encountered some internal or external difficulty in advancing their mathematical career, and how they were able to deal with such difficulties. I myself have contributed ")#link("https://www.ams.org/about-us/LivingProof.pdf#%5B%7B%22num%22%3A351%2C%22gen%22%3A0%7D%2C%7B%22name%22%3A%22FitH%22%7D%2C648%5D")[#text("one of these essays")]#text("; I was initially somewhat surprised when I was approached for a contribution, as my career trajectory has been somewhat of an outlier, and I have been very fortunate to not experience to the same extent many of the obstacles that other contributors write about in this text. Nevertheless there was a turning point in my career that I write about here during my graduate years, when I found that the improvised and poorly disciplined study habits that were able to get me into graduate school due to an over-reliance on raw mathematical ability were completely inadequate to handle the graduate qualifying exam. With a combination of an astute advisor and some sheer luck, I was able to pass the exam and finally develop a more sustainable approach to learning and doing mathematics, but it could easily have gone quite differently. (My ")#strike[#text("20")]#text(" 25-year old writeup of this examination, complete with spelling errors, may be found ")#link("https://web.math.princeton.edu/generals/tao_terence")[#text("here")]#text(".)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686de7c56e01b9812b7dab89e546012de642bacbe076abbb729dc42f7ff8089a-e85a696188abca866bc724d3304752748cfcf62e5c8c2de35fe8a6be3c205525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omarleoblog")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517898")[#strong[#text("omarleoblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Thanks so much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of little man")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517900")[#strong[#text("little man")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("You are a gem. I am struggling with my scientific career since about 25 years and such experience reports help me a lot to cope with my fate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75cab974d3e4b36d278f8d4f55e5561ef1f5c2e617221aa4785aeeb609de8914-7c7719acb3209aefbac96b72879bf9fb02032b2907f1a7d31cae1f59cc60695c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517901")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Ha! I remember that occasion. You cut down on gaming afterward, you say? _That_ I don’t remember.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Haha, well I didn’t specify how quickly that happened and to what extent :-). I did phase the gaming out though over the next two or so years, though not completely; a combination of having the time displaced by actual research, and also losing regular access to the graduate college computer room…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517916")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Now I have to ask what games you were into! Was computer gaming already a thing in that era, or are we talking about Hex, chess variants, Avalon Hill / D&D, or that sort of thing? I’m sure lots of us want to know…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("I’m the same age and in that era we had games like quake, diablo, starcraft, warcraft 2, command and conquer, baldur’s gate, civilization 2, grand theft auto, etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14593b0d9d47a4ba3439e251da25c5cc7103bd63ae55ba76c272ef902973f827-eb20077f70d0b9be052530f6bbf5df9c0610813132524f8cb1120d6df3aa18a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avanti")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-519662")[#strong[#text("Avanti")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("Dear Terence,")#linebreak()#text(" Since you are a prodigy with such a high IQ I was wondering how come you didn’t memorize the pages of the textbook verbatim for your generals? I mean you could then recall the theorems and proofs without necessarily understanding them but sufficient for the purposes of the exam.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb6185451c5bc63a83e94a1fe6a6cb61c4d4f643497af737916f8913653a49be-bfea5452ee4f6b95ca700c08f8da8d82b6907f5531a87afd074823c786f35e77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Davis")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517905")[#strong[#text("David Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Glad it worked out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("Wow! ‘Living Proof: Stories of Resilience Along the Mathematical Journey’ is very good! And I can relate to it…")

#text("Best wishes and success to all! And please stay passionate about mathematics and learning.")

#text("We are lucky since mathematics is the best science! :-0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("Some Food for Thought:")

#text("“Science is an adventure of the human spirit. It is essentially an artistic enterprise, stimulated largely by curiosity, served largely by disciplined imagination, and based largely on faith in the reasonableness, order, and beauty of the universe.” — Warren Weaver.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("‘So you want to be a mathematician?’ is a good story too.")

#text("Relevant Reference Link:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://anthonybonato.com/2017/08/23/so-you-want-to-be-a-mathematician/")[#text("So you want to be a mathematician?")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("What happens if you fail the general? Do you get to take it again?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("Unfortunately, several famous young mathematicians (Abel, Eisenstein, Riemann, Ramanujan) died from tuberculosis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("Some well known bad examples are")

#text("1. Galois repeated failure to pass entrance examinations to the Ecole Polytechnique (because he made too many logical leaps that baffled his examiners.)")

#text("2.Ramanujan lost his fellowships by neglecting all non-mathematical courses.")

#text("3 Einstein as a student also neglected his studies and prepared only few weeks before the examinations (with the help of the well written lecture notes made by his friend Marcel Grossmann.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("I’m reminded of the Calvin & Hobbes where Calvin says “you know how bad Einstein’s grades were as a kid? Well, mine are even worse!”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517928")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2019/06/28/living-proof-stories-of-resilience-along-the-mathematical-journey/")[#text("Singapore Maths Tuition")]#text(" and commented:")#linebreak()#text(" Very inspirational collection of essays on stories of resilience in the lives of mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517935")[#strong[#text("TIL that Terence Tao struggled to pass his qualifying exams at Princeton and benefitted from \"some sheer luck.\" - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")]

#text("[…] by /u/boutandabout [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87da479966e9b01927993aac9869d90a386a1317323dace2ef2d1c3e8321622d-71aef8fa9ea1253772ba6af129f14e96ed7597d3e302c0f19f029df78c06eade.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Melissa Tacy")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517954")[#strong[#text("Melissa Tacy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("It’s great to see AMS and MAA getting into this kind of thing, particularly as it seems like they have recruited over a pretty wide range of mathematicians. It’s important to hear stories and advice not only from those who have had exceptional careers (though it is reassuring to know that even they have had occasions where things haven’t gone to plan) but also from people who have been successful in a more “normal” path.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/814e586714398e8829ce8b0a74ddd5ddd24745df9d8d4cb54d6f5ddac74ae465-063a2d3ae67c8f93b42d06be9a32332ce3f2ec9369a41954e2f1f295cce4edf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 1900")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517958")[#strong[#text("1900")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("Hello, I found an interesting phenomenon, but my math ability is very poor, I can’t check it in more places, but I think this phenomenon will be very useful.")#linebreak()#text(" A new solution to the Hilbert hotel paradox(the real nature of 0)")#linebreak()#text(" 0 is a combination of real and virtual numbers. When the observer looks at it from different angles, it will show different properties.")#linebreak()#text(" When 0 tends to infinitesimal , it is infinitely close to real, we denote it 0↓;")#linebreak()#text(" When 0 tends to infinity, its infinity is close to imaginary, we denote it 0↑；")#linebreak()#text(" Then when a guest wants to stay in a hotel with unlimited guests, whether he can live in it depends on whether the hotel is real or virtual;")#linebreak()#text(" It is expressed as follows by mathematical formula:")#linebreak()#text(" 1+0↓=1 Then the guest can’t enter the hotel because every house has a corresponding guest (you can understand that 0 tends to infinitesimal,if someone can only count to 9, the number 10 for him is an infinite number,then in his understanding the hotel can only accommodate a maximum of 9 people, so new guests can not stay at the hotel);")#linebreak()#text(" 1+0↑=0↑ Then the guest can stay in the hotel, because there are infinite rooms, there must be room for the limited guests (ie, if someone can count 10 in the previous example, then customers can be arranged)")#linebreak()#text(" The virtual and real properties of 0 can also be reflected in other operations, as follows:")#linebreak()#text(" 1×0↓ =0↓ 1×0↑=0↑ So 1×0=0")#linebreak()#text(" 1÷0↓=0↑ 1÷0↑=0↓ So 1÷0=0")#linebreak()#text(" (If the understanding of the real and virtual Numbers is difficult, then if you compare people to 0, you will understand a little better; people’s thinking is virtual, the human body is real; that is, when you see a person lying flat, his next action is 0, I call it behavior association,and we’ll talk about that if you’re interested.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-517980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("An extraordinary example of resilience was given by Hawking who was able to cope with his illness for decades and still remaining a leading physicist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71280b536b1432843064021ecbabec32996edc30f12b8acfafc84b23bab30255-89664768714fbf7bf0cdb2537f159120e7a7041707c42ffc99959ecf53e57175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuvallevental")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-568111")[#strong[#text("yuvallevental")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2020")])]

#text("True, but I don’t want to make this into a competition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bc9428fa889115c0647fc8b24e85e02c3e457335416e325ade339d2985cc356-8b4515e5b6b5f55f9eef7afce2cd8648b58050674c54c3fb4dfc6d3916bb7bbe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Living Proof | Solvable by Radicals")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-518013")[#strong[#text("Living Proof | Solvable by Radicals")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2019")])]

#text("[…] am going to add my voice to the others talking about Living Proof (which was originally brought to my attention by a biology […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58af4d920c3f5d519bd89554671feee9e6335dea9ccd73c3196a53b509d568f9-9f54804ccf6503fbf1a761dbf332b2ee1e4819ec31c326dc3eabc496877df70c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Augusto Gabriel Rodrigues")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-518350")[#strong[#text("Augusto Gabriel Rodrigues")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")])]

#text("Dear professor i am from Angola. We would like to know If you accept ti visit our country!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3842868384da81254f483a55b3dca8f86efde15487dfd3cc95cbfa6de1cda82c-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arsene1412")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-518583")[#strong[#text("Arsene1412")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2019")])]

#text("Thanks for sharing this, It is very encouraging to remember that other people beside myself are going through the same road.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2add68dec7f00ec44c3f78eb1dfd5f1a59030eb26417155c4fe939cbcbc75dc4-9b0f3b85c5d31d057a2e577da2a3abe2e29e67744bb7aec827739bf39c0ee92a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yhl3051")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-643690")[#strong[#text("yhl3051")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2022")])]

#text("I noticed you said the following: “this was the first time I had performed poorly on an exam that I was genuinely interested in performing well in.”")

#text("I have noticed that sometimes, you have to study what you don’t want to learn in order to achieve what you want in the end. It’s about reprioritizing your interests. Also, why didn’t you choose to learn with your fellow grad students that year? They would have really enjoyed working with you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2019/06/27/living-proof-stories-of-resilience-along-the-mathematical-journey/#comment-643744")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("I’d definitely be interested in contributing a belated addition to this collection!")
]
