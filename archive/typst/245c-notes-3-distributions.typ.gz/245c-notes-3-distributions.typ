// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/
// Converted to Typst by tao2typ: "2026-10-14T15:17:12.237889+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245C, Notes 3: Distributions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245C, Notes 3: Distributions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In set theory, a function ")#mi("{f: X \\rightarrow Y}")#text(" is defined as an object that ")#emph[#text("evaluates")]#text(" every input ")#mi("{x}")#text(" to exactly one output ")#mi("{f(x)}")#text(". However, in various branches of mathematics, it has become convenient to generalise this classical concept of a function to a more abstract one. For instance, in ")#link("http://en.wikipedia.org/wiki/Operator_algebra")[#text("operator algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Quantum_mechanics")[#text("quantum mechanics")]#text(", or ")#link("http://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("non-commutative geometry")]#text(", one often replaces commutative algebras of (real or complex-valued) functions on some space ")#mi("{X}")#text(", such as ")#mi("{C(X)}")#text(" or ")#mi("{L^\\infty(X)}")#text(", with a more general – and possibly non-commutative – algebra (e.g. a ")#link("http://en.wikipedia.org/wiki/C*_algebra")[#mi("{C^*}")#text("-algebra")]#text(" or a ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text("). Elements in this more abstract algebra are no longer definable as functions in the classical sense of assigning a single value ")#mi("{f(x)}")#text(" to every point ")#mi("{x \\in X}")#text(", but one can still define other operations on these “")#link("http://en.wikipedia.org/wiki/Generalized_function")[#text("generalised functions")]#text("” (e.g. one can multiply or take inner products between two such objects).")

#text("Generalisations of functions are also very useful in analysis. In our study of ")#mi("{L^p}")#text(" spaces, we have already seen one such generalisation, namely the concept of a function defined up to almost everywhere equivalence. Such a function ")#mi("{f}")#text(" (or more precisely, an equivalence class of classical functions) cannot be evaluated at any given point ")#mi("{x}")#text(", if that point has measure zero. However, it is still possible to perform algebraic operations on such functions (e.g. multiplying or adding two functions together), and one can also integrate such functions on measurable sets (provided, of course, that the function has some suitable integrability condition). We also know that the ")#mi("{L^p}")#text(" spaces can usually be described via duality, as the dual space of ")#mi("{L^{p^{\\prime}}}")#text(" (except in some endpoint cases, namely when ")#mi("{p=\\infty}")#text(", or when ")#mi("{p=1}")#text(" and the underlying space is not ")#mi("{\\sigma}")#text("-finite).")

#text("We have also seen (via the ")#link("http://en.wikipedia.org/wiki/Radon%E2%80%93Nikodym_theorem")[#text("Lebesgue-Radon-Nikodym theorem")]#text(") that locally integrable functions ")#mi("{f \\in L^1_{\\text{loc}}({\\bf R})}")#text(" on, say, the real line ")#mi("{{\\bf R}}")#text(", can be identified with locally finite absolutely continuous measures ")#mi("{m_f}")#text(" on the line, by multiplying Lebesgue measure ")#mi("{m}")#text(" by the function ")#mi("{f}")#text(". So another way to generalise the concept of a function is to consider arbitrary locally finite ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]#text(" ")#mi("{\\mu}")#text(" (not necessarily absolutely continuous), such as the ")#link("http://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac measure")]#text(" ")#mi("{\\delta_0}")#text(". With this concept of “generalised function”, one can still add and subtract two measures ")#mi("{\\mu, \\nu}")#text(", and integrate any measure ")#mi("{\\mu}")#text(" against a (bounded) measurable set ")#mi("{E}")#text(" to obtain a number ")#mi("{\\mu(E)}")#text(", but one cannot evaluate a measure ")#mi("{\\mu}")#text(" (or more precisely, the Radon-Nikodym derivative ")#mi("{d\\mu/dm}")#text(" of that measure) at a single point ")#mi("{x}")#text(", and one also cannot multiply two measures together to obtain another measure. From the Riesz representation theorem, we also know that the space of (finite) Radon measures can be described via duality, as linear functionals on ")#mi("{C_c({\\bf R})}")#text(".")

#text("There is an even larger class of generalised functions that is very useful, particularly in linear PDE, namely the space of ")#link("http://en.wikipedia.org/wiki/Distribution_(mathematics)")[#text("distributions")]#text(", say on a Euclidean space ")#mi("{{\\bf R}^d}")#text(". In contrast to Radon measures ")#mi("{\\mu}")#text(", which can be defined by how they “pair up” against continuous, compactly supported test functions ")#mi("{f \\in C_c({\\bf R}^d)}")#text(" to create numbers ")#mi("{\\langle f, \\mu \\rangle := \\int_{{\\bf R}^d} f\\ d\\overline{\\mu}}")#text(", a distribution ")#mi("{\\lambda}")#text(" is defined by how it pairs up against a ")#emph[#text("smooth")]#text(" compactly supported function ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(" to create a number ")#mi("{\\langle f, \\lambda \\rangle}")#text(". As the space ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" of smooth compactly supported functions is smaller than (but dense in) the space ")#mi("{C_c({\\bf R}^d)}")#text(" of continuous compactly supported functions (and has a stronger topology), the space of distributions is larger than that of measures. But the space ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is closed under more operations than ")#mi("{C_c({\\bf R}^d)}")#text(", and in particular is closed under differential operators (with smooth coefficients). Because of this, the space of distributions is similarly closed under such operations; in particular, one can differentiate a distribution and get another distribution, which is something that is not always possible with measures or ")#mi("{L^p}")#text(" functions. But as measures or functions can be interpreted as distributions, this leads to the notion of a ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(" for such objects, which makes sense (but only as a distribution) even for functions that are not classically differentiable. Thus the theory of distributions can allow one to rigorously manipulate rough functions “as if” they were smooth, although one must still be careful as some operations on distributions are not well-defined, most notably the operation of multiplying two distributions together. Nevertheless one can use this theory to justify many formal computations involving derivatives, integrals, etc. (including several computations used routinely in physics) that would be difficult to formalise rigorously in a purely classical framework.")

#text("If one shrinks the space of distributions slightly, to the space of ")#emph[#text("tempered distributions")]#text(" (which is formed by enlarging dual class ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz class")]#text(" ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text("), then one obtains closure under another important operation, namely the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(". This allows one to define various Fourier-analytic operations (e.g. ")#link("http://en.wikipedia.org/wiki/Pseudodifferential_operator")[#text("pseudodifferential operators")]#text(") on such distributions.")

#text("Of course, at the end of the day, one is usually not all that interested in distributions in their own right, but would like to be able to use them as a tool to study more classical objects, such as smooth functions. Fortunately, one can recover facts about smooth functions from facts about the (far rougher) space of distributions in a number of ways. For instance, if one convolves a distribution with a smooth, compactly supported function, one gets back a smooth function. This is a particularly useful fact in the theory of constant-coefficient linear partial differential equations such as ")#mi("{Lu=f}")#text(", as it allows one to recover a smooth solution ")#mi("{u}")#text(" from smooth, compactly supported data ")#mi("{f}")#text(" by convolving ")#mi("{f}")#text(" with a specific distribution ")#mi("{G}")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Fundamental_solution")[#text("fundamental solution")]#text(" of ")#mi("{L}")#text(". We will give some examples of this later in these notes.")

#text("It is this unusual and useful combination of both being able to pass from classical functions to generalised functions (e.g. by differentiation) and then back from generalised functions to classical functions (e.g. by convolution) that sets the theory of distributions apart from other competing theories of generalised functions, in particular allowing one to justify many formal calculations in PDE and Fourier analysis rigorously with relatively little additional effort. On the other hand, being defined by linear duality, the theory of distributions becomes somewhat less useful when one moves to more nonlinear problems, such as nonlinear PDE. However, they still serve an important supporting role in such problems as a “ambient space” of functions, inside of which one carves out more useful function spaces, such as Sobolev spaces, which we will discuss in the next set of notes.")

#metadata(none) <tao-ab20bb57db84b8144e7b>

#heading(level: 1)[#strong[#text(" — 1. Smooth functions with compact support — ")]]

#text("In the rest of the notes we will work on a fixed Euclidean space ")#mi("{{\\bf R}^d}")#text(". (One can also define distributions on other domains related to ")#mi("{{\\bf R}^d}")#text(", such as open subsets of ")#mi("{{\\bf R}^d}")#text(", or ")#mi("{d}")#text("-dimensional manifolds, but for simplicity we shall restrict attention to Euclidean spaces in these notes.)")

#text("A ")#link("http://en.wikipedia.org/wiki/Bump_function")[#text("test function")]#text(" is any smooth, compactly supported function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text("; the space of such functions is denoted ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(". (In some texts, this space is denoted ")#mi("{C^\\infty_0({\\bf R}^d)}")#text(" instead.)")

#text("From ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(" one sees that there are no real-analytic test functions other than the zero function. Despite this negative result, test functions actually exist in abundance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-2cfa257a83b95f9387d5>

#list(
[#text("(i) Show that there exists at least one test function that is not identically zero. (")#emph[#text("Hint")]#text(": it suffices to do this for ")#mi("{d=1}")#text(". One starting point is to use the fact that the function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by ")#mi("{f(x) := e^{-1/x}}")#text(" for ")#mi("{x > 0}")#text(" and ")#mi("{f(x) := 0}")#text(" otherwise is smooth, even at the origin ")#mi("{0}")#text(".)")],
[#text("(ii) Show that if ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(" and ")#mi("{g: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is absolutely integrable and compactly supported, then the convolution ")#mi("{f*g}")#text(" is also in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" first show that ")#mi("{f*g}")#text(" is continuously differentiable with ")#mi("{\\nabla(f*g) = (\\nabla f)*g}")#text(".)")],
[#text("(iii) (")#mi("{C^\\infty}")#text(" Urysohn lemma) Let ")#mi("{K}")#text(" be a compact subset of ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{U}")#text(" be an open neighbourhood of ")#mi("{K}")#text(". Show that there exists a function ")#mi("{f: C^\\infty_c({\\bf R}^d)}")#text(" supported in ")#mi("{U}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{K}")#text(". (Hint: use the ordinary Urysohn lemma to find a function in ")#mi("{C_c({\\bf R}^d)}")#text(" that equals ")#mi("{1}")#text(" on a neighbourhood of ")#mi("{K}")#text(" and is supported in a compact subset of ")#mi("{U}")#text(", then convolve this function by a suitable test function.)")],
[#text("(iv) Show that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is dense in ")#mi("{C_0({\\bf R}^d)}")#text(" (in the uniform topology), and dense in ")#mi("{L^p({\\bf R}^d)}")#text(" (with the ")#mi("{L^p}")#text(" topology) for all ")#mi("{0 < p < \\infty}")#text(".")]
)
]

#text("The space ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is clearly a vector space. Now we place a (very strong!) topology on it. We first observe that ")#mi("{C^\\infty_c({\\bf R}^d) = \\bigcup_K C^\\infty_c(K)}")#text(", where ")#mi("{K}")#text(" ranges over all compact subsets of ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{C^\\infty_c(K)}")#text(" consists of those functions ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(" which are supported in ")#mi("{K}")#text(". Each ")#mi("{C^\\infty_c(K)}")#text(" will be given a topology (called the ")#emph[#text("smooth topology")]#text(") generated by the norms")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{C^k} := \\sup_{x \\in {\\bf R}^d} \\sum_{j=0}^k\\left|\\nabla^j f(x)\\right|", block: true)]]

#text("for ")#mi("{k=0,1,\\ldots}")#text(", where we view ")#mi("{\\nabla^j f(x)}")#text(" as a ")#mi("{d^j}")#text("-dimensional vector (or, if one wishes, a ")#mi("{d}")#text("-dimensional rank ")#mi("{j}")#text(" tensor); thus a sequence ")#mi("{f_n \\in C^\\infty_c(K)}")#text(" converges to a limit ")#mi("{f \\in C^\\infty_c(K)}")#text(" if and only if ")#mi("{\\nabla^j f_n}")#text(" converges uniformly to ")#mi("{\\nabla^j f}")#text(" for all ")#mi("{j=0,1,\\ldots}")#text(". (This gives ")#mi("{C^\\infty_c(K)}")#text(" the structure of a ")#link("http://en.wikipedia.org/wiki/Fr%C3%A9chet_space")[#text("Fréchet space")]#text(", though we will not use this fact here.)")

#text("We are able to give ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" a (very strong) topology as follows. Call a seminorm ")#mi("{\\| \\|}")#text(" on ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" ")#emph[#text("good")]#text(" if it is continuous function on ")#mi("{C^\\infty_c(K)}")#text(" for each compact ")#mi("{K}")#text(" (or equivalently, the ball ")#tao-math("{\\{ f \\in C^\\infty_c(K): \\left\\|f\\right\\| < 1 \\}}", block: false)#text(" is open in ")#mi("{C^\\infty_c(K)}")#text(" for each compact ")#mi("{K}")#text("). We then give ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" the topology defined by all good seminorms. Clearly, this makes ")#mi("C^\\infty_c({\\bf R}^d)")#text(" a (locally convex) topological vector space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{f_n}")#text(" be a sequence in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(", and let ")#mi("{f}")#text(" be another function in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(". Show that ")#mi("{f_n}")#text(" converges in the topology of ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{f}")#text(" if and only if there exists a compact set ")#mi("{K}")#text(" such that ")#mi("{f_n, f}")#text(" are all supported in ")#mi("{K}")#text(", and ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in the smooth topology of ")#mi("{C^\\infty_c(K)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]

#list(
[#text("(i) Show that the topology of ")#mi("{C^\\infty_c(K)}")#text(" is ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first countable")]#text(" for every compact ")#mi("{K}")#text(".")],
[#text("(ii) Show that the topology of ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is ")#emph[#text("not")]#text(" first countable. (")#emph[#text("Hint:")]#text(" given any countable sequence of open neighbourhoods of ")#mi("{0}")#text(", build a new open neighbourhood that does not contain any of the previous ones, using the ")#mi("{\\sigma}")#text("-compact nature of ")#mi("{{\\bf R}^d}")#text(".)")],
[#text("(iii) As an additional challenge, construct a set ")#mi("{E \\subset C^\\infty({\\bf R}^d)}")#text(" such that ")#mi("{0}")#text(" is an adherent point of ")#mi("{E}")#text(", but ")#mi("{0}")#text(" is not as the limit of any sequence in ")#mi("{E}")#text(".")]
)
]

#text("There are plenty of continuous operations on ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-09782dc5ead2ce0cd7e6>

#list(
[#text("(i) Let ")#mi("{K}")#text(" be a compact set. Show that a linear map ")#mi("{T: C^\\infty_c(K) \\rightarrow X}")#text(" into a normed vector space ")#mi("{X}")#text(" is continuous if and only if there exists ")#mi("{k \\geq 0}")#text(" and ")#mi("{C > 0}")#text(" such that ")#tao-math("{\\left\\| Tf \\right\\|_X \\leq C \\left\\|f\\right\\|_{C^{k}}}", block: false)#text(" for all ")#mi("{f \\in C^\\infty_c(K)}")#text(".")],
[#text("(ii) Let ")#mi("{K, K^{\\prime}}")#text(" be compact sets. Show that a linear map ")#mi("{T: C^\\infty_c(K) \\rightarrow C^\\infty_c(K^{\\prime})}")#text(" is continuous if and only if for every ")#mi("{k^{\\prime} \\geq 0}")#text(" there exists ")#mi("{k \\geq 0}")#text(" and a constant ")#mi("{C_{k^{\\prime}} > 0}")#text(" such that ")#tao-math("{\\left\\| Tf \\right\\|_{C^{k^{\\prime}}(K^{\\prime})} \\leq C_{k^{\\prime}} \\left\\|f\\right\\|_{C^{k}(K)}}", block: false)#text(" for all ")#mi("{f \\in C^\\infty_c(K)}")#text(".")],
[#text("(iii) Show that a linear map ")#mi("{T: C^\\infty_c({\\bf R}^d) \\rightarrow X}")#text(" from the space of test functions into a topological vector space generated by some family of seminorms (i.e., a ")#link("http://en.wikipedia.org/wiki/Locally_convex_topological_vector_space")[#text("locally convex topological vector space")]#text(") is continuous if and only if it is sequentially continuous (i.e. whenever ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(", ")#mi("{Tf_n}")#text(" converges to ")#mi("{Tf}")#text(" in ")#mi("{X}")#text("), and if and only if ")#mi("{T: C^\\infty_c(K) \\rightarrow X}")#text(" is continuous for each compact ")#mi("{K \\subset {\\bf R}^d}")#text(". Thus while first countability fails for ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(", we have a serviceable substitute for this property.")],
[#text("(iv) Show that the inclusion map from ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{L^p({\\bf R}^d)}")#text(" is continuous for every ")#mi("{0 < p \\leq \\infty}")#text(".")],
[#text("(v) Show that a linear map ")#mi("{T: C^\\infty_c({\\bf R}^d) \\rightarrow C^\\infty_c({\\bf R}^d)}")#text(" is continuous if and only if for every compact set ")#mi("{K \\subset {\\bf R}^d}")#text(" there exists a compact set ")#mi("{K^{\\prime}}")#text(" such that ")#mi("{T}")#text(" maps ")#mi("{C^\\infty_c(K)}")#text(" continuously to ")#mi("{C^\\infty_c(K^{\\prime})}")#text(".")],
[#text("(vi) Show that every linear differential operator with smooth coefficients is a continuous operation on ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(".")],
[#text("(vii) Show that convolution with any absolutely integrable, compactly supported function is a continuous operation on ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(".")],
[#text("(viii) Show that the product operation ")#mi("{f, g \\mapsto fg}")#text(" is continuous from ")#mi("{C^\\infty_c({\\bf R}^d) \\times C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(".")]
)
]

#text("A sequence ")#mi("{\\phi_n \\in C_c({\\bf R}^d)}")#text(" of continuous, compactly supported functions is said to be an ")#link("http://en.wikipedia.org/wiki/Nascent_delta_function#nascent_delta_function")[#text("approximation to the identity")]#text(" if the ")#mi("{\\phi_n}")#text(" are non-negative, have total mass ")#mi("{\\int_{{\\bf R}^n} \\phi_n}")#text(" equal to ")#mi("{1}")#text(", and whose supports shrink to the origin, thus for any fixed ")#mi("{r}")#text(", ")#mi("{\\phi_n}")#text(" is supported on the ball ")#mi("{B(0,r)}")#text(" for ")#mi("{n}")#text(" sufficiently large. One can generate such a sequence by starting with a single non-negative continuous compactly supported function ")#mi("{\\phi}")#text(" of total mass ")#mi("{1}")#text(", and then setting ")#mi("{\\phi_n(x) := n^d \\phi(nx)}")#text("; many other constructions are possible also.")

#text("One has the following useful fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-61597957b3ffcfaee94d>#text(" Let ")#mi("{\\phi_n \\in C^\\infty_c({\\bf R}^d)}")#text(" be a sequence of approximations to the identity.")

#list(
[#text("(i) If ")#mi("{f \\in C({\\bf R}^d)}")#text(" is continuous, show that ")#mi("{f*\\phi_n}")#text(" converges uniformly on compact sets to ")#mi("{f}")#text(".")],
[#text("(ii) If ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" for some ")#mi("{1 \\leq p < \\infty}")#text(", show that ")#mi("{f*\\phi_n}")#text(" converges in ")#mi("{L^p({\\bf R}^d)}")#text(" to ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" use (i), the density of ")#mi("{C_c({\\bf R}^d)}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(", and Young’s inequality.)")],
[#text("(iii) If ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(", show that ")#mi("{f*\\phi_n}")#text(" converges in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{f}")#text(". (Hint: use the identity ")#mi("{\\nabla( f * \\phi_n ) = (\\nabla f ) * \\phi_n}")#text(", cf. Exercise ")#link(<tao-2cfa257a83b95f9387d5>)[#text("1")]#text("(ii).)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is separable. (")#emph[#text("Hint:")]#text(" it suffices to show that ")#mi("{C^\\infty_c(K)}")#text(" is separable for each compact ")#mi("{K}")#text(". There are several ways to accomplish this. One is to begin with the Stone-Weierstrass theorem, which will give a countable set which is dense in the uniform topology, then use the fundamental theorem of calculus to strengthen the topology. Another is to use Exercise ")#link(<tao-61597957b3ffcfaee94d>)[#text("5")]#text(" and then discretise the convolution. Another is to embed ")#mi("{K}")#text(" into a torus and use Fourier series, noting that the Fourier coefficients ")#mi("{\\hat f}")#text(" of a smooth function ")#mi("{f: {\\Bbb T}^d \\rightarrow {\\bf C}}")#text(" decay faster than any power of ")#tao-math("{\\left|n\\right|}", block: false)#text(".)")
]

#heading(level: 1)[#strong[#text(" — 2. Distributions — ")]]

#text("Now we can define the concept of a ")#link("http://en.wikipedia.org/wiki/Distribution_(mathematics)")[#text("distribution")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Distribution)")]#text(" A ")#emph[#text("distribution")]#text(" on ")#mi("{{\\bf R}^d}")#text(" is a continuous linear functional ")#mi("{\\lambda: f \\mapsto \\langle f,\\lambda\\rangle}")#text(" from ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{{\\bf C}}")#text(". The space of such distributions is denoted ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text(", and is given the ")#link("http://en.wikipedia.org/wiki/Weak-*_topology")[#text("weak-* topology")]#text(". In particular, a sequence of distributions ")#mi("{\\lambda_n}")#text(" converges (in the sense of distributions) to a limit ")#mi("{\\lambda}")#text(" if one has ")#mi("{\\langle f, \\lambda_n \\rangle \\rightarrow \\langle f,\\lambda \\rangle}")#text(" for all ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(".")

#text("A technical point: we endow the space ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text(" with the ")#emph[#text("conjugate")]#text(" complex structure. Thus, if ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(", and ")#mi("{c}")#text(" is a complex number, then ")#mi("{c\\lambda}")#text(" is the distribution that maps a test function ")#mi("{f}")#text(" to ")#mi("{\\overline{c} \\langle f, \\lambda \\rangle}")#text(" rather than ")#mi("{c \\langle f, \\lambda \\rangle}")#text("; thus ")#mi("{\\langle f, c\\lambda \\rangle = \\overline{c} \\langle f, \\lambda \\rangle}")#text(". This is to keep the analogy between the evaluation of a distribution against a function, and the usual Hermitian inner product ")#mi("{\\langle f, g \\rangle = \\int_{{\\bf R}^d} f \\overline{g}}")#text(" of two test functions.")
]

#text("From Exercise ")#link(<tao-09782dc5ead2ce0cd7e6>)[#text("4")]#text(", we see that a linear functional ")#mi("{\\lambda: C^\\infty_c({\\bf R}^d)\\rightarrow {\\bf C}}")#text(" is a distribution if, for every compact set ")#mi("{K \\subset {\\bf R}^d}")#text(", there exists ")#mi("{k \\geq 0}")#text(" and ")#mi("{C > 0}")#text(" such that ")#metadata(none) <tao-1ae1dd29593288ec07a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\langle f,\\lambda\\rangle\\right| \\leq C \\left\\|f\\right\\|_{C^k}", block: true)]]

#text(" for all ")#mi("{f \\in C^\\infty_c(K)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text(" is a Hausdorff topological vector space.")
]

#text("We note two basic examples of distributions:")

#list(
[#text("Any locally integrable function ")#mi("{g \\in L^1_{\\text{loc}}({\\bf R}^d)}")#text(" can be viewed as a distribution, by writing ")#mi("{\\langle f, g \\rangle := \\int_{{\\bf R}^d} f(x) \\overline{g(x)}\\ dx}")#text(" for all test functions ")#mi("{f}")#text(".")],
[#text("Any complex Radon measure ")#mi("{\\mu}")#text(" can be viewed as a distribution, by writing ")#mi("{\\langle f, \\mu \\rangle := \\int_{{\\bf R}^d} f(x)\\ d\\overline{\\mu}}")#text(", where ")#mi("{\\overline{\\mu}}")#text(" is the complex conjugate of ")#mi("{\\mu}")#text(" (thus ")#mi("{\\overline{\\mu}(E) := \\overline{\\mu(E)}}")#text("). (Note that this example generalises the preceding one, which corresponds to the case when ")#mi("{\\mu}")#text(" is absolutely continuous with respect to Lebesgue measure.) Thus, for instance, the Dirac measure ")#mi("{\\delta}")#text(" at the origin is a distribution, with ")#mi("{\\langle f, \\delta \\rangle = f(0)}")#text(" for all test functions ")#mi("{f}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that the above identifications of locally integrable functions or complex Radon measures with distributions are injective. (Hint: use Exercise ")#link(<tao-2cfa257a83b95f9387d5>)[#text("1")]#text("(iv).)")
]

#text("From the above exercise, we may view locally integrable functions and locally finite measures as a special type of distribution. In particular, ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" and ")#mi("{L^p({\\bf R}^d)}")#text(" are now contained in ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text(" for all ")#mi("{1 \\leq p \\leq \\infty}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that if a sequence of locally integrable functions converge in ")#mi("{L^1_{\\text{loc}}}")#text(" to a limit, then they also converge in the sense of distributions; similarly, if a sequence of complex Radon measures converge in the vague topology to a limit, then they also converge in the sense of distributions.")
]

#text("Thus we see that convergence in the sense of distributions is among the weakest of the notions of convergence used in analysis; however, from the Hausdorff property, distributional limits are still ")#emph[#text("unique")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" If ")#mi("{\\phi_n}")#text(" is a sequence of approximations to the identity, show that ")#mi("{\\phi_n}")#text(" converges in the sense of distributions to the Dirac distribution ")#mi("{\\delta}")#text(".")
]

#text("More exotic examples of distributions can be given:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Derivative of the delta function)")]#text(" ")#metadata(none) <tao-ceae8d6de886787cb850>#text(" Let ")#mi("{d=1}")#text(". Show that the functional ")#mi("{\\delta^{\\prime}: f \\mapsto - f^{\\prime}(0)}")#text(" for all test functions ")#mi("{f}")#text(" is a distribution which does not arise from either a locally integrable function or a Radon measure. (Note how it is important here that ")#mi("{f}")#text(" is smooth (and in particular differentiable, and not merely continuous.) The presence of the minus sign will be explained shortly.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Principal value of ")#mi("{1/x}")#text(")")]#text(" ")#metadata(none) <tao-0bebf1a578c50388f7a7>#text(" Let ")#mi("{d=1}")#text(". Show that the functional ")#mi("{\\text{p.v.} 1/x}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\langle f, \\text{p.v.} \\frac{1}{x} \\rangle := \\lim_{\\epsilon \\rightarrow 0} \\int_{\\left|x\\right| > \\epsilon} \\frac{f(x)}{x}\\ dx", block: true)]]

#text("is a distribution which does not arise from either a locally integrable function or a Radon measure. (Note that ")#mi("{1/x}")#text(" is not a locally integrable function!)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Distributional interpretations of ")#tao-math("{1/\\left|x\\right|}", block: false)#text(")")]#text(" ")#metadata(none) <tao-bef0ae27c378eb653a57>#text(" Let ")#mi("{d=1}")#text(". For any ")#mi("{r > 0}")#text(", show that the functional ")#mi("{\\lambda_r}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\langle f, \\lambda_r \\rangle := \\int_{\\left|x\\right| < r} \\frac{f(x)-f(0)}{\\left|x\\right|}\\ dx + \\int_{\\left|x\\right| \\geq r} \\frac{f(x)}{\\left|x\\right|}\\ dx", block: true)]]

#text("is a distribution that does not arise from either a locally integrable function or a Radon measure. Note that any two such functionals ")#mi("{\\lambda_r, \\lambda_{r^{\\prime}}}")#text(" differ by a constant multiple of the Dirac delta distribution.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" A distribution ")#mi("{\\lambda}")#text(" is said to be ")#emph[#text("real")]#text(" if ")#mi("{\\langle f,\\lambda\\rangle}")#text(" is real for every real-valued test function ")#mi("{f}")#text(". Show that every distribution ")#mi("{\\lambda}")#text(" can be uniquely expressed as ")#mi("{\\text{Re}(\\lambda) + i \\text{Im}(\\lambda)}")#text(" for some real distributions ")#mi("{\\text{Re}(\\lambda), \\text{Im}(\\lambda)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" A distribution ")#mi("{\\lambda}")#text(" is said to be ")#emph[#text("non-negative")]#text(" if ")#mi("{\\langle f,\\lambda\\rangle}")#text(" is non-negative for every non-negative test function ")#mi("{f}")#text(". Show that a distribution is non-negative if and only if it is a non-negative Radon measure. (Hint: use the Riesz representation theorem and Exercise ")#link(<tao-2cfa257a83b95f9387d5>)[#text("1")]#text("(iv).) Note that this implies that the analogue of the ")#link("http://en.wikipedia.org/wiki/Hahn_decomposition")[#text("Jordan decomposition")]#text(" fails for distributions; any distribution which is not a Radon measure will not be the difference of non-negative distributions.")
]

#text("We will now extend various operations on locally integrable functions or Radon measures to distributions by arguing by analogy. (Shortly we will give a more formal approach, based on density.)")

#text("We begin with the operation of multiplying a distribution ")#mi("{\\lambda}")#text(" by a smooth function ")#mi("{h: {\\bf R}^d \\rightarrow {\\bf C}}")#text(". Observe that")

#align(center)[#tao-fit-display[#mitex("\\langle f, gh \\rangle = \\langle f \\overline{h}, g \\rangle")]]

#text("for all test functions ")#mi("{f,g,h}")#text(". Inspired by this formula, we define the product ")#mi("{\\lambda h = h \\lambda}")#text(" of a distribution with a smooth function by setting")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\lambda h \\rangle := \\langle f \\overline{h}, \\lambda \\rangle")]]

#text("for all test functions ")#mi("{f}")#text(". It is easy to see (e.g. using Exercise ")#link(<tao-09782dc5ead2ce0cd7e6>)[#text("4")]#text("(vi)) that this defines a distribution ")#mi("{\\lambda h}")#text(", and that this operation is compatible with existing definitions of products between a locally integrable function (or Radon measure) with a smooth function. It is important that ")#mi("{h}")#text(" is smooth (and not merely, say, continuous) because one needs the product of a test function ")#mi("{f}")#text(" with ")#mi("{\\overline{h}}")#text(" to still be a test function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-f2ad8f292453bfebf871>#text(" Let ")#mi("{d=1}")#text(". Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\delta f = f(0) \\delta")]]

#text("for any smooth function ")#mi("{f}")#text(". In particular,")

#align(center)[#tao-fit-display[#mitex("\\delta x = 0")]]

#text("where we abuse notation slightly and write ")#mi("{x}")#text(" for the identity function ")#mi("{x \\mapsto x}")#text(". Conversely, if ")#mi("{\\lambda}")#text(" is a distribution such that")

#align(center)[#tao-fit-display[#mitex("\\lambda x = 0,")]]

#text("show that ")#mi("{\\lambda}")#text(" is a constant multiple of ")#mi("{\\delta}")#text(". (")#emph[#text("Hint:")]#text(" Use the identity ")#mi("{f(x) = f(0) + x \\int_0^1 f^{\\prime}(tx)\\ dt}")#text(" to write ")#mi("{f(x)}")#text(" as the sum of ")#mi("{f(0) \\psi}")#text(" and ")#mi("{x}")#text(" times a test function for any test function ")#mi("{f}")#text(", where ")#mi("{\\psi}")#text(" is a fixed test function equalling ")#mi("{1}")#text(" at the origin.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Even though distributions are not, strictly speaking, functions, it is often useful heuristically to view them as such, thus for instance one might write a distributional identity such as ")#mi("{\\delta x = 0}")#text(" suggestively as ")#mi("{\\delta(x) x = 0}")#text(". Another useful (and rigorous) way to view such identities is to write distributions such as ")#mi("{\\delta}")#text(" as a limit of approximations to the identity ")#mi("{\\psi_n}")#text(", and show that the relevant identity becomes true in the limit; thus, for instance, to show that ")#mi("{\\delta x = 0}")#text(", one can show that ")#mi("{\\psi_n x \\rightarrow 0}")#text(" in the sense of distributions as ")#mi("{n \\rightarrow \\infty}")#text(". (In fact, ")#mi("{\\psi_n x}")#text(" converges to zero in the ")#mi("{L^1}")#text(" norm.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{d=1}")#text(". With the distribution ")#mi("{\\text{p.v.} \\frac{1}{x}}")#text(" from Exercise ")#link(<tao-0bebf1a578c50388f7a7>)[#text("12")]#text(", show that ")#mi("{(\\text{p.v.} \\frac{1}{x}) x}")#text(" is equal to ")#mi("{1}")#text(". With the distributions ")#mi("{\\lambda_r}")#text(" from Exercise ")#link(<tao-bef0ae27c378eb653a57>)[#text("13")]#text(", show that ")#mi("{\\lambda_r x = \\text{sgn}}")#text(", where ")#mi("{\\text{sgn}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Signum_function")[#text("signum function")]#text(".")
]

#text("A distribution ")#mi("{\\lambda}")#text(" is said to be ")#emph[#text("supported")]#text(" in a closed set ")#mi("{K}")#text(" in ")#mi("{\\langle f, \\lambda \\rangle = 0}")#text(" for all ")#mi("{f}")#text(" that vanish on an open neighbourhood of ")#mi("{K}")#text(". The intersection of all ")#mi("{K}")#text(" that ")#mi("{\\lambda}")#text(" is supported on is denoted ")#mi("{\\text{supp}(\\lambda)}")#text(" and is referred to as the ")#emph[#text("support")]#text(" of the distribution; this is the smallest closed set that ")#mi("{\\lambda}")#text(" is supported on. Thus, for instance, the Dirac delta function is supported on ")#mi("{\\{0\\}}")#text(", as are all derivatives of that function. (Note here that it is important that ")#mi("{f}")#text(" vanish on a ")#emph[#text("neighbourhood")]#text(" of ")#mi("{K}")#text(", rather than merely vanishing on ")#mi("{K}")#text(" itself; for instance, in one dimension, there certainly exist test functions ")#mi("{f}")#text(" that vanish at ")#mi("{0}")#text(" but nevertheless have a non-zero inner product with ")#mi("{\\delta^{\\prime}}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-40bcbcb4c517eda47f60>#text(" Show that every distribution is the limit of a sequence of compactly supported distributions (using the weak-* topology, of course). (")#emph[#text("Hint:")]#text(" Approximate a distribution ")#mi("{\\lambda}")#text(" by the truncated distributions ")#mi("{\\lambda \\eta_n}")#text(" for some smooth cutoff functions ")#mi("{\\eta_n}")#text(" constructed using Exercise ")#link(<tao-2cfa257a83b95f9387d5>)[#text("1")]#text("(iii).)")
]

#text("In a similar spirit, we can convolve a distribution ")#mi("{\\lambda}")#text(" by an absolutely integrable, compactly supported function ")#mi("{h \\in L^1({\\bf R}^d)}")#text(". From Fubini’s theorem we observe the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, g*h \\rangle = \\langle f * \\tilde h, g \\rangle")]]

#text("for all test functions ")#mi("{f,g,h}")#text(", where ")#mi("{\\tilde h(x) := \\overline{h(-x)}}")#text(". Inspired by this formula, we define the convolution ")#mi("{\\lambda * h = h*\\lambda}")#text(" of a distribution with an absolutely integrable, compactly supported function by the formula ")#metadata(none) <tao-915a7a6485bc6d8886bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle f, \\lambda*h \\rangle := \\langle f * \\tilde h, \\lambda \\rangle")]]

#text(" for all test functions ")#mi("{f}")#text(". This gives a well-defined distribution ")#mi("{\\lambda h}")#text(" (thanks to Exercise ")#link(<tao-09782dc5ead2ce0cd7e6>)[#text("4")]#text("(vii)) which is compatible with previous notions of convolution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" One has ")#mi("{\\delta*f=f*\\delta=f}")#text(" for all test functions ")#mi("{f}")#text(". In one dimension, we have ")#mi("{\\delta^{\\prime} * f = f^{\\prime}}")#text(" (why?), thus differentiation can be viewed as convolution with a distribution.")
]

#text("A remarkable fact about convolutions of two functions ")#mi("{f*g}")#text(" is that they inherit the regularity of the ")#emph[#text("smoother")]#text(" of the two factors ")#mi("{f, g}")#text(" (in contrast to products ")#mi("{fg}")#text(", which tend to inherit the regularity of the ")#emph[#text("rougher")]#text(" of the two factors). (This disparity can be also be seen by contrasting the identity ")#mi("{\\nabla (f*g) = (\\nabla f)*g = f * (\\nabla g)}")#text(" with the identity ")#mi("{\\nabla (fg) = (\\nabla f) g + f (\\nabla g)}")#text(".) In the case of convolving distributions with test functions, this phenomenon is manifested as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-fb82ccc9ef9afd279416>#text(" Let ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(" be a distribution, and let ")#mi("{h \\in C^\\infty_c({\\bf R}^d)}")#text(" be a test function. Then ")#mi("{\\lambda*h}")#text(" is equal to a smooth function.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{\\lambda}")#text(" were itself a smooth function, then one could easily verify the identity ")#metadata(none) <tao-a63bbe081aada9b2b023>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lambda * h(x) = \\overline{\\langle h_x, \\lambda\\rangle}")]]

#text(" where ")#mi("{h_x(y) := \\overline{h}(x-y)}")#text(". As ")#mi("{h}")#text(" is a test function, it is easy to see that ")#mi("{h_x}")#text(" varies smoothly in ")#mi("{x}")#text(" in any ")#mi("{C^k}")#text(" norm (indeed, it has Taylor expansions to any order in such norms) and so the right-hand side is a smooth function of ")#mi("{x}")#text(". So it suffices to verify the identity ")#link(<tao-a63bbe081aada9b2b023>)[#text("(3)")]#text(". As distributions are defined against test functions ")#mi("{f}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\lambda*h \\rangle = \\int_{{\\bf R}^d} f(x) \\langle h_x, \\lambda \\rangle\\ dx.")]]

#text("On the other hand, we have from ")#link(<tao-915a7a6485bc6d8886bf>)[#text("(2)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\lambda*h \\rangle = \\langle f * \\tilde h, \\lambda \\rangle = \\langle \\int_{{\\bf R}^d} f(x) h_x\\ dx, \\lambda \\rangle.")]]

#text("So the only issue is to justify the interchange of integral and inner product:")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x) \\langle h_x, \\lambda \\rangle\\ dx = \\langle \\int_{{\\bf R}^d} f(x) h_x\\ dx, \\lambda \\rangle.")]]

#text("Certainly, (from the compact support of ")#mi("{f}")#text(") any Riemann sum can be interchanged with the inner product:")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(x_n) \\langle h_{x_n}, \\lambda \\rangle \\Delta x = \\langle \\sum_n f(x_n) h_{x_n} \\Delta x, \\lambda \\rangle,")]]

#text("where ")#mi("{x_n}")#text(" ranges over some lattice and ")#mi("{\\Delta x}")#text(" is the volume of the fundamental domain. A modification of the argument that shows convergence of the Riemann integral for smooth, compactly supported functions then works here and allows one to take limits; we omit the details. ")#mi("\\Box")

#text("This has an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-b0defd7b50dc682eb067>#text(" Every distribution is the limit of a sequence of test functions. In particular, ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is dense in ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text(".")
]

#emph[#text("Proof:")]#text(" By Exercise ")#link(<tao-40bcbcb4c517eda47f60>)[#text("18")]#text(", it suffices to verify this for compactly supported distributions ")#mi("{\\lambda}")#text(". We let ")#mi("{\\phi_n}")#text(" be a sequence of approximations to the identity. By Exercise ")#link(<tao-61597957b3ffcfaee94d>)[#text("5")]#text("(iii) and ")#link(<tao-915a7a6485bc6d8886bf>)[#text("(2)")]#text(", we see that ")#mi("{\\lambda * \\phi_n}")#text(" converges in the sense of distributions to ")#mi("{\\lambda}")#text(". By Lemma ")#link(<tao-fb82ccc9ef9afd279416>)[#text("2")]#text(", ")#mi("{\\lambda * \\phi_n}")#text(" is a smooth function; as ")#mi("{\\lambda}")#text(" and ")#mi("{\\phi_n}")#text(" are both compactly supported, ")#mi("{\\lambda*\\phi_n}")#text(" is compactly supported also. The claim follows. ")#mi("\\Box")

#text("Because of this lemma, we can formalise the previous procedure of extending operations that were previously defined on test functions, to distributions, provided that these operations were continuous in distributional topologies. However, we shall continue to proceed by analogy as it requires fewer verifications in order to motivate the definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Another consequence of Lemma ")#link(<tao-fb82ccc9ef9afd279416>)[#text("2")]#text(" is that it allows one to extend the definition ")#link(<tao-915a7a6485bc6d8886bf>)[#text("(2)")]#text(" of convolution to the case when ")#mi("{h}")#text(" is not an integrable function of compact support, but is instead merely a distribution of compact support. Adopting this convention, show that convolution of distributions of compact support is both commutative and associative. (")#emph[#text("Hint:")]#text(" this can either be done directly, or by carefully taking limits using Lemma ")#link(<tao-b0defd7b50dc682eb067>)[#text("3")]#text(".)")
]

#text("The next operation we will introduce is that of differentiation. An integration by parts reveals the identity")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\frac{\\partial}{\\partial x_j} g \\rangle = - \\langle \\frac{\\partial}{\\partial x_j} f, g \\rangle")]]

#text("for any test functions ")#mi("{f, g}")#text(" and ")#mi("{j=1,\\ldots,d}")#text(". Inspired by this, we define the (distributional) partial derivative ")#mi("{\\frac{\\partial}{\\partial x_j} \\lambda}")#text(" of a distribution ")#mi("{\\lambda}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\frac{\\partial}{\\partial x_j} \\lambda \\rangle := - \\langle \\frac{\\partial}{\\partial x_j} f, \\lambda \\rangle.")]]

#text("This can be verified to still be a distribution, and by Exercise ")#link(<tao-09782dc5ead2ce0cd7e6>)[#text("4")]#text("(vi), the operation of differentiation is a continuous one on distributions. More generally, given any linear differential operator ")#mi("{P}")#text(" with smooth coefficients, one can define ")#mi("{P\\lambda}")#text(" for a distribution ")#mi("{\\lambda}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, P\\lambda \\rangle := \\langle P^* f, \\lambda \\rangle")]]

#text("where ")#mi("{P^*}")#text(" is the adjoint differential operator ")#mi("{P}")#text(", which can be defined implicitly by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, P g \\rangle = \\langle P^* f, g \\rangle")]]

#text("for test functions ")#mi("{f,g}")#text(", or more explicitly by replacing all coefficients with complex conjugates, replacing each partial derivative ")#mi("{\\frac{\\partial}{\\partial x_j}}")#text(" with its negative, and reversing the order of operations (thus for instance the adjoint of the first-order operator ")#mi("{a(x) \\frac{d}{dx}: f \\mapsto af^{\\prime}}")#text(" would be ")#mi("{-\\frac{d}{dx} a(x): f \\mapsto - (af)^{\\prime}}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" The distribution ")#mi("{\\delta^{\\prime}}")#text(" defined in Exercise ")#link(<tao-ceae8d6de886787cb850>)[#text("11")]#text(" is the derivative ")#mi("{\\frac{d}{dx} \\delta}")#text(" of ")#mi("{\\delta}")#text(", as defined by the above formula.")
]

#text("Many of the identities one is used to in classical calculus extend to the distributional setting (as one would already expect from Lemma ")#link(<tao-b0defd7b50dc682eb067>)[#text("3")]#text("). For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Product rule)")]#text(" Let ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(" be a distribution, and let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be smooth. Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x_j}(\\lambda f) = (\\frac{\\partial}{\\partial x_j} \\lambda) f + \\lambda (\\frac{\\partial}{\\partial x_j} f)")]]

#text("for all ")#mi("{j=1,\\ldots,d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{d=1}")#text(". Show that ")#mi("{\\delta^{\\prime} x = - \\delta}")#text(" in three different ways:")

#list(
[#text("Directly from the definitions;")],
[#text("using the product rule;")],
[#text("Writing ")#mi("{\\delta}")#text(" as the limit of approximations ")#mi("{\\psi_n}")#text(" to the identity.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-82dfec6fd3c2e148c7cb>#text(" Let ")#mi("{d=1}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{\\lambda}")#text(" is a distribution and ")#mi("{n \\geq 1}")#text(" is an integer, then ")#mi("{\\lambda x^n = 0}")#text(" if and only if is a linear combination of ")#mi("{\\delta}")#text(" and its first ")#mi("{n-1}")#text(" derivatives ")#mi("{\\delta^{\\prime}, \\delta^{\\prime\\prime}, \\ldots, \\delta^{(n-1)}}")#text(".")],
[#text("(ii) Show that a distribution ")#mi("{\\lambda}")#text(" is supported on ")#mi("{\\{0\\}}")#text(" if and only if it is a linear combination of ")#mi("{\\delta}")#text(" and finitely many of its derivatives.")],
[#text("(iii) Generalise (ii) to the case of general dimension ")#mi("{d}")#text(" (where of course one now uses partial derivatives instead of derivatives).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{d=1}")#text(".")

#list(
[#text("Show that the derivative of the ")#link("http://en.wikipedia.org/wiki/Heaviside_function")[#text("Heaviside function")]#text(" ")#mi("{1_{[0,+\\infty)}}")#text(" is equal to ")#mi("{\\delta}")#text(".")],
[#text("Show that the derivative of the signum function ")#mi("{\\text{sgn}(x)}")#text(" is equal to ")#mi("{2\\delta}")#text(".")],
[#text("Show that the derivative of the locally integrable function ")#tao-math("{\\log \\left|x\\right|}", block: false)#text(" is equal to ")#mi("{\\text{p.v.} \\frac{1}{x}}")#text(".")],
[#text("Show that the derivative of the locally integrable function ")#tao-math("{\\log \\left|x\\right| \\text{sgn}(x)}", block: false)#text(" is equal to the distribution ")#mi("{\\lambda_1}")#text(" from Exercise ")#link(<tao-bef0ae27c378eb653a57>)[#text("13")]#text(".")],
[#text("Show that the derivative of the locally integrable function ")#tao-math("{\\left|x\\right|}", block: false)#text(" is the locally integrable function ")#mi("{\\text{sgn}(x)}")#text(".")]
)
]

#text("If a locally integrable function has a distributional derivative which is also a locally integrable function, we refer to the latter as the ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(" of the former. Thus, for instance, the weak derivative of ")#tao-math("{\\left|x\\right|}", block: false)#text(" is ")#mi("{\\text{sgn}(x)}")#text(" (as one would expect), but ")#mi("{\\text{sgn}(x)}")#text(" does not have a weak derivative (despite being (classically) differentiable almost everywhere), because the distributional derivative ")#mi("{2\\delta}")#text(" of this function is not itself a locally integrable function. Thus weak derivatives differ in some respects from their classical counterparts, though of course the two concepts agree for smooth functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{d \\geq 1}")#text(". Show that for any ")#mi("{1 \\leq i,j \\leq d}")#text(", and any distribution ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(", we have ")#mi("{\\frac{\\partial}{\\partial x_i} \\frac{\\partial}{\\partial x_j} \\lambda = \\frac{\\partial}{\\partial x_j} \\frac{\\partial}{\\partial x_i} \\lambda}")#text(", thus weak derivatives commute with each other. (This is in contrast to classical derivatives, which can fail to commute for non-smooth functions; for instance, ")#mi("{\\frac{\\partial}{\\partial x} \\frac{\\partial}{\\partial y} \\frac{xy^3}{x^2 + y^2} \\neq \\frac{\\partial}{\\partial y} \\frac{\\partial}{\\partial x} \\frac{xy^3}{x^2 + y^2}}")#text(" at the origin ")#mi("{(x,y)=0}")#text(", despite both derivatives being defined. More generally, weak derivatives tend to be less pathological than classical derivatives, but of course the downside is that weak derivatives do not always have a classical interpretation as a limit of a Newton quotient.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Let ")#mi("{d=1}")#text(", and let ")#mi("{k \\geq 0}")#text(" be an integer. Let us say that a compactly supported distribution ")#mi("{\\lambda \\in C^\\infty_c({\\bf R})^*}")#text(" ")#emph[#text("has of order at most ")#mi("{k}")]#text(" if the functional ")#mi("{f \\mapsto \\langle f,\\lambda \\rangle}")#text(" is continuous in the ")#mi("{C^k}")#text(" norm. Thus, for instance, ")#mi("{\\delta}")#text(" has order at most ")#mi("{0}")#text(", and ")#mi("{\\delta^{\\prime}}")#text(" has order at most ")#mi("{1}")#text(", and every compactly supported distribution is of order at most ")#mi("{k}")#text(" for some sufficiently large ")#mi("{k}")#text(".")

#list(
[#text("Show that if ")#mi("{\\lambda}")#text(" is a compactly supported distribution of order at most ")#mi("{0}")#text(", then it is a compactly supported Radon measure.")],
[#text("Show that if ")#mi("{\\lambda}")#text(" is a compactly supported distribution of order at most ")#mi("{k}")#text(", then ")#mi("{\\lambda^{\\prime}}")#text(" has order at most ")#mi("{k+1}")#text(".")],
[#text("Conversely, if ")#mi("{\\lambda}")#text(" is a compactly supported distribution of order ")#mi("{k+1}")#text(", then we can write ")#mi("{\\lambda = \\rho^{\\prime} + \\nu}")#text(" for some compactly supported distributions of order ")#mi("{k}")#text(". (")#emph[#text("Hint:")]#text(" one has to “dualise” the fundamental theorem of calculus, and then apply smooth cutoffs to recover compact support.)")],
[#text("Show that every compactly supported distribution can be expressed as a finite linear combination of (distributional) derivatives of compactly supported Radon measures.")],
[#text("Show that every compactly supported distribution can be expressed as a finite linear combination of (distributional) derivatives of functions in ")#mi("{C^k_0({\\bf R})}")#text(", for any fixed ")#mi("{k}")#text(".")]
)
]

#text("We now set out some other operations on distributions. If we define the translation ")#mi("{\\tau_x f}")#text(" of a test function ")#mi("{f}")#text(" by a shift ")#mi("{x \\in {\\bf R}^d}")#text(" by the formula ")#mi("{\\tau_x f(y) := f(y-x)}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\tau_x g \\rangle = \\langle \\tau_{-x} f, g \\rangle")]]

#text("for all test functions ")#mi("{f,g}")#text(", so it is natural to define the translation ")#mi("{\\tau_x \\lambda}")#text(" of a distribution ")#mi("{\\lambda}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\tau_x \\lambda \\rangle := \\langle \\tau_{-x} f, \\lambda \\rangle.")]]

#text("Next, we consider linear changes of variable.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Linear changes of variable)")]#text(" Let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be a linear transformation. Given a distribution ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(", let ")#mi("{\\lambda \\circ L}")#text(" be the distribution given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\langle f, \\lambda \\circ L \\rangle := \\frac{1}{\\left|\\det L\\right|} \\langle f \\circ L^{-1}, \\lambda \\rangle", block: true)]]

#text("for all test functions ")#mi("{f}")#text(". (How would one motivate this formula?)")

#list(
[#text("Show that ")#tao-math("{\\delta \\circ L = \\frac{1}{\\left|\\det L\\right|} \\delta}", block: false)#text(" for all linear transformations ")#mi("{L}")#text(".")],
[#text("If ")#mi("{d=1}")#text(", show that ")#tao-math("{\\text{p.v.} \\frac{1}{x} \\circ L = \\frac{1}{\\left|\\det L\\right|} \\text{p.v.} \\frac{1}{x}}", block: false)#text(" for all linear transformations ")#mi("{L}")#text(".")],
[#text("Conversely, if ")#mi("{d=1}")#text(" and ")#mi("{\\lambda}")#text(" is a distribution such that ")#tao-math("{\\lambda \\cdot L = \\frac{1}{\\left|\\det L\\right|} \\lambda}", block: false)#text(" for all linear transformations ")#mi("{L}")#text(", show that ")#mi("{\\lambda}")#text(" is a linear combination of the delta distribution and ")#mi("{\\text{p.v.} \\frac{1}{x}}")#text(". (")#emph[#text("Hint:")]#text(" first show that there exists a constant ")#mi("{c}")#text(" such that ")#mi("{\\langle f, \\lambda \\rangle = c \\int_0^\\infty \\frac{f(x)}{x}\\ dx}")#text(" whenever ")#mi("{f}")#text(" is a bump function supported in ")#mi("{(0,+\\infty)}")#text(". To show this, approximate ")#mi("{f}")#text(" by the function")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^\\infty f(e^t x) \\psi_n(t)\\ dt = \\int_0^\\infty \\frac{f(y)}{y} \\psi_n( \\log \\frac{x}{y} ) 1_{x>0}\\ dy")]]

#text("for ")#mi("{\\psi_n}")#text(" an approximation to the identity.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can also compose distributions with ")#link("http://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphisms")]#text(". However, things become much more delicate if the map one is composing with contains stationary points; for instance, in one dimension, one cannot meaningfully make sense of ")#mi("{\\delta(x^2)}")#text(" (the composition of the Dirac delta distribution with ")#mi("{x \\mapsto x^2}")#text("); this can be seen by first noting that for an approximation ")#mi("{\\psi_n}")#text(" to the identity, ")#mi("{\\psi_n(x^2)}")#text(" does not converge to a limit in the distributional sense.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Tensor product of distributions)")]#text(" Let ")#mi("{d, d^{\\prime} \\geq 1}")#text(" be integers. If ")#mi("{\\lambda \\in C^\\infty_c({\\bf R}^d)^*}")#text(" and ")#mi("{\\rho \\in C^\\infty_c({\\bf R}^{d^{\\prime}})^*}")#text(" are distributions, show that there is a unique distribution ")#mi("{\\lambda \\otimes \\rho \\in C^\\infty_c({\\bf R}^{d+d^{\\prime}})^*}")#text(" with the property that ")#metadata(none) <tao-b04216546057e8659fec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\langle f \\otimes g, \\lambda \\otimes \\rho \\rangle = \\langle f, \\lambda \\rangle \\langle g, \\rho \\rangle")]]

#text(" for all test functions ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(", ")#mi("{g \\in C^\\infty_c({\\bf R}^{d^{\\prime}})}")#text(", where ")#mi("{f \\otimes g: C^\\infty_c({\\bf R}^{d+d^{\\prime}})}")#text(" is the tensor product ")#mi("{f \\otimes g(x,x^{\\prime}) := f(x) g(x^{\\prime})}")#text(" of ")#mi("{f}")#text(" and ")#mi("{g}")#text(". (")#emph[#text("Hint:")]#text(" like many other constructions of tensor products, this is rather intricate. One way is to start by fixing two cutoff functions ")#mi("{\\psi, \\psi^{\\prime}}")#text(" on ")#mi("{{\\bf R}^d, {\\bf R}^{d^{\\prime}}}")#text(" respectively, and define ")#mi("{\\lambda \\otimes \\rho}")#text(" on modulated test functions ")#mi("{e^{2\\pi i \\xi \\cdot x} e^{2\\pi i \\xi^{\\prime} \\cdot x} \\psi(x) \\psi^{\\prime}(x^{\\prime})}")#text(" for various frequencies ")#mi("{\\xi, \\xi^{\\prime}}")#text(", and then use Fourier series to define ")#mi("{\\lambda \\otimes \\rho}")#text(" on ")#mi("{F(x,x^{\\prime}) \\psi(x) \\psi^{\\prime}(x^{\\prime})}")#text(" for smooth ")#mi("{F}")#text(". Then show that these definitions of ")#mi("{\\lambda \\otimes \\rho}")#text(" are compatible for different choices of ")#mi("{\\psi, \\psi^{\\prime}}")#text(" and can be glued together to form a distribution; finally, go back and verify ")#link(<tao-b04216546057e8659fec>)[#text("(4)")]#text(".)")
]

#text("We close this section with one caveat. Despite the many operations that one can perform on distributions, there are two types of operations which cannot, in general, be defined on arbitrary distributions (at least while remaining in the class of distributions):")

#list(
[#text("Nonlinear operations (e.g. taking the absolute value of a distribution); or")],
[#text("Multiplying a distribution by anything rougher than a smooth function.")]
)

#text("Thus, for instance, there is no meaningful way to interpret the square ")#mi("{\\delta^2}")#text(" of the Dirac delta function as a distribution. This is perhaps easiest to see using an approximation ")#mi("{\\psi_n}")#text(" to the identity: ")#mi("{\\psi_n}")#text(" converges to ")#mi("{\\delta}")#text(" in the sense of distributions, but ")#mi("{\\psi_n^2}")#text(" does not converge to anything (the integral against a test function that does not vanish at the origin will go to infinity as ")#mi("{n \\rightarrow \\infty}")#text("). For similar reasons, one cannot meaningfully interpret the absolute value ")#tao-math("{\\left|\\delta^{\\prime}\\right|}", block: false)#text(" of the derivative of the delta function. (One also cannot multiply ")#mi("{\\delta}")#text(" by ")#mi("{\\text{sgn}(x)}")#text(" – why?)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{X}")#text(" be a normed vector space which contains ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" as a dense subspace (and such that the inclusion of ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" to ")#mi("{X}")#text(" is continuous). The adjoint (or transpose) of this inclusion map is then an injection from ")#mi("{X^*}")#text(" to the space of distributions ")#mi("{C^\\infty_c({\\bf R}^d)^*}")#text("; thus ")#mi("{X^*}")#text(" can be viewed as a subspace of the space of distributions.")

#list(
[#text("Show that the closed unit ball in ")#mi("{X^*}")#text(" is also closed in the space of distributions.")],
[#text("Conclude that any distributional limit of a bounded sequence in ")#mi("{L^p({\\bf R}^d)}")#text(" for ")#mi("{1 < p \\leq \\infty}")#text(", is still in ")#mi("{L^p({\\bf R}^d)}")#text(".")],
[#text("Show that the previous claim fails for ")#mi("{L^1({\\bf R}^d)}")#text(", but holds for the space ")#mi("{M({\\bf R}^d)}")#text(" of finite measures.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Tempered distributions — ")]]

#text("The list of operations one can define on distributions has one major omission – the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("{{\\mathcal F}}")#text(". Unfortunately, one cannot easily define the Fourier transform for all distributions. One can see this as follows. From ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(" one has the identity")

#align(center)[#tao-fit-display[#mitex("\\langle f, {\\mathcal F} g \\rangle = \\langle {\\mathcal F}^* f, g \\rangle")]]

#text("for test functions ")#mi("{f, g}")#text(", so one would like to define the Fourier transform ")#mi("{{\\mathcal F} \\lambda = \\hat \\lambda}")#text(" of a distribution ")#mi("{\\lambda}")#text(" by the formula ")#metadata(none) <tao-574fd8cfe32d9ed52e33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\langle f, {\\mathcal F} \\lambda \\rangle := \\langle {\\mathcal F}^* f, \\lambda \\rangle.")]]

#text(" Unfortunately this does not quite work, because the adjoint Fourier transform ")#mi("{{\\mathcal F}^*}")#text(" of a test function is not a test function, but is instead just a Schwartz function. (Indeed, by Exercise 55 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("Notes 2")]#text(", it is not possible to find a non-trivial test function whose Fourier transform is again a test function.) To address this, we need to work with a slightly smaller space than that of all distributions, namely those of ")#emph[#text("tempered")]#text(" distributions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Tempered distributions)")]#text(" A tempered distribution is a continuous linear functional ")#mi("{\\lambda: f \\mapsto \\langle f, \\lambda \\rangle}")#text(" on the Schwartz space ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" (with the topology given by Exercise 25 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("Notes 2")]#text("), i.e. an element of ")#mi("{{\\mathcal S}({\\bf R}^d)^*}")#text(".")
]

#text("Since ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" (with a dense image), we see that the space of tempered distributions can be embedded into the space of distributions. However, not every distribution is tempered:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" The distribution ")#mi("{e^x}")#text(" is not tempered. Indeed, if ")#mi("{\\psi}")#text(" is a bump function, observe that the sequence of functions ")#mi("{e^{-n} \\psi(x-n)}")#text(" converges to zero in the Schwartz space topology, but ")#mi("{\\langle e^{-n} \\psi(x-n), e^x \\rangle}")#text(" does not go to zero, and so this distribution does not correspond to a tempered distribution.")
]

#text("On the other hand, distributions which avoid this sort of exponential growth, and instead only grow polynomially, tend to be tempered:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Show that any Radon measure ")#mi("{\\mu}")#text(" which is of ")#emph[#text("polynomial growth")]#text(" in the sense that ")#tao-math("{\\left|\\mu\\right|(B(0,R)) \\leq C R^k}", block: false)#text(" for all ")#mi("{R \\geq 1}")#text(" and some constants ")#mi("{C, k > 0}")#text(", where ")#mi("{B(0,R)}")#text(" is the ball of radius ")#mi("{R}")#text(" centred at the origin in ")#mi("{{\\bf R}^d}")#text(", is tempered.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" As a zeroth approximation, one can roughly think of “tempered” as being synonymous with “polynomial growth”. However, this is not strictly true: for instance, the (weak) derivative of a function of polynomial growth will still be tempered, but need not be of polynomial growth (for instance, the derivative ")#mi("{e^x \\cos(e^x)}")#text(" of ")#mi("{\\sin(e^x)}")#text(" is a tempered distribution, despite having exponential growth). While one can eventually describe which distributions are tempered by measuring their “growth” in both physical space and in frequency space, we will not do so here.")
]

#text("Most of the operations that preserve the space of distributions, also preserve the space of tempered distributions. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]

#list(
[#text("Show that any derivative of a tempered distribution is again a tempered distribution.")],
[#text("Show that and any convolution of a tempered distribution with a compactly supported distribution is again a tempered distribution.")],
[#text("Show that if ")#mi("{f}")#text(" is a measurable function which is ")#emph[#text("rapidly decreasing")]#text(" in the sense that ")#tao-math("{\\left|x\\right|^k f(x)}", block: false)#text(" is an ")#mi("{L^\\infty({\\bf R}^d)}")#text(" function for each ")#mi("{k=0,1,2,\\ldots}")#text(", then a convolution of a tempered distribution with ")#mi("{f}")#text(" can be defined, and is again a tempered distribution.")],
[#text("Show that if ")#mi("{f}")#text(" is a smooth function such that ")#mi("{f}")#text(" and all its derivatives have ")#emph[#text("at most polynomial growth")]#text(" (thus for each ")#mi("{j \\geq 0}")#text(" there exists ")#mi("{C, k \\geq 0}")#text(" such that ")#tao-math("{\\left|\\nabla^j f(x)\\right| \\leq C (1 + \\left|x\\right|)^k}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}^d}")#text(") then the product of a tempered distribution with ")#mi("{f}")#text(" is again a tempered distribution. Give a counterexample to show that this statement fails if the polynomial growth hypotheses are dropped.")],
[#text("Show that the translate of a tempered distribution is again a tempered distribution.")]
)
]

#text("But we can now add a new operation to this list using ")#link(<tao-574fd8cfe32d9ed52e33>)[#text("(5)")]#text(": as the Fourier transform ")#mi("{{\\mathcal F}}")#text(" maps Schwartz functions continuously to Schwartz functions, it also continuously maps the space of tempered distributions to itself. One can also define the inverse Fourier transform ")#mi("{{\\mathcal F}^* = {\\mathcal F}^{-1}}")#text(" on tempered distributions in a similar manner.")

#text("It is not difficult to extend many of the properties of the Fourier transform from Schwartz functions to distributions. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" ")#metadata(none) <tao-9a6c847424f1483fa41c>#text(" Let ")#mi("{\\lambda \\in {\\mathcal S}({\\bf R}^d)^*}")#text(" be a tempered distribution, and let ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" be a Schwartz function.")

#list(
[#text("(Inversion formula) Show that ")#mi("{{\\mathcal F}^* {\\mathcal F} \\lambda = {\\mathcal F} {\\mathcal F}^* \\lambda = \\lambda}")#text(".")],
[#text("(Multiplication intertwines with convolution) Show that ")#mi("{{\\mathcal F}(\\lambda f) = ({\\mathcal F} \\lambda) * ({\\mathcal F} f)}")#text(" and ")#mi("{{\\mathcal F}(\\lambda * f) = ({\\mathcal F} \\lambda) ({\\mathcal F} f)}")#text(".")],
[#text("(Translation intertwines with modulation) For any ")#mi("{x_0 \\in {\\bf R}^d}")#text(", show that ")#mi("{{\\mathcal F}(\\tau_{x_0} \\lambda) = e_{-x_0} {\\mathcal F} \\lambda}")#text(", where ")#mi("{e_{-x_0}(\\xi) := e^{-2\\pi i \\xi \\cdot x_0}}")#text(". Similarly, show that for any ")#mi("{\\xi_0 \\in {\\bf R}^d}")#text(", one has ")#mi("{{\\mathcal F}( e_{\\xi_0} \\lambda ) = \\tau_{\\xi_0} {\\mathcal F} \\lambda}")#text(".")],
[#text("(Linear transformations) For any invertible linear transformation ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", show that ")#tao-math("{{\\mathcal F}(\\lambda \\circ L) = \\frac{1}{\\left|\\det L\\right|} ({\\mathcal F} \\lambda) \\circ (L^*)^{-1}}", block: false)#text(".")],
[#text("(Differentiation intertwines with polynomial multiplication) For any ")#mi("{1 \\leq j \\leq d}")#text(", show that ")#mi("{{\\mathcal F}( \\frac{\\partial}{\\partial x_j} \\lambda ) = 2\\pi i \\xi_j {\\mathcal F} \\lambda}")#text(", where ")#mi("{x_j}")#text(" and ")#mi("{\\xi_j}")#text(" is the ")#mi("{j^{th}}")#text(" coordinate function in physical space and frequency space respectively, and similarly ")#mi("{{\\mathcal F}( - 2\\pi i x_j \\lambda ) = \\frac{\\partial}{\\partial \\xi_j} {\\mathcal F} \\lambda}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Let ")#mi("{d \\geq 1}")#text(".")

#list(
[#text("(Inversion formula) Show that ")#mi("{{\\mathcal F} \\delta = 1}")#text(" and ")#mi("{{\\mathcal F} 1 = \\delta}")#text(".")],
[#text("(Orthogonality) Let ")#mi("{V}")#text(" be a subspace of ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{\\mu}")#text(" be Lebesgue measure on ")#mi("{V}")#text(". Show that ")#mi("{{\\mathcal F} \\mu}")#text(" is Lebesgue measure on the orthogonal complement ")#mi("{V^\\perp}")#text(" of ")#mi("{V}")#text(". (Note that this generalises the previous exercise.)")],
[#text("(Poisson summation formula) Let ")#mi("{\\sum_{k \\in {\\bf Z}^d} \\tau_k \\delta}")#text(" be the distribution")

#align(center)[#tao-fit-display[#mitex("\\langle f, \\sum_{k \\in {\\bf Z}^d} \\tau_k \\delta\\rangle := \\sum_{k \\in {\\bf Z}^d} f(k).")]]

#text("Show that this is a tempered distribution which is equal to its own Fourier transform.")]
)
]

#text("One can use these properties of tempered distributions to start solving constant-coefficient PDE. We first illustrate this by an ODE example, showing how the formal symbolic calculus for solving such ODE that you may have seen as an undergraduate, can now be (sometimes) justified using tempered distributions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{d=1}")#text(", let ")#mi("{a,b}")#text(" be real numbers, and let ")#mi("{D}")#text(" be the operator ")#mi("{D = \\frac{d}{dx}}")#text(".")

#list(
[#text("If ")#mi("{a \\neq b}")#text(", use the Fourier transform to show that all tempered distribution solutions to the ODE ")#mi("{(D-ia)(D-ib) \\lambda = 0}")#text(" are of the form ")#mi("{\\lambda = A e^{iax} + B e^{ibx}}")#text(" for some constants ")#mi("{A, B}")#text(".")],
[#text("If ")#mi("{a = b}")#text(", show that all tempered distribution solutions to the ODE ")#mi("{(D-ia)(D-ib) \\lambda = 0}")#text(" are of the form ")#mi("{\\lambda = A e^{iax} + B x e^{iax}}")#text(" for some constants ")#mi("{A, B}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" More generally, one can solve any homogeneous constant-coefficient ODE using tempered distributions and the Fourier transform so long as the roots of the ")#link("http://en.wikipedia.org/wiki/Characteristic_polynomial")[#text("characteristic polynomial")]#text(" are purely imaginary. In all other cases, solutions can grow exponentially as ")#mi("{x \\rightarrow +\\infty}")#text(" or ")#mi("{x \\rightarrow -\\infty}")#text(" and so are not tempered. There are other theories of generalised functions that can handle these objects (e.g. ")#link("http://en.wikipedia.org/wiki/Hyperfunction")[#text("hyperfunctions")]#text(") but we will not discuss them here.")
]

#text("Now we turn to PDE. To illustrate the method, let us focus on solving ")#link("http://en.wikipedia.org/wiki/Poisson%27s_equation")[#text("Poisson’s equation")]#text(" ")#metadata(none) <tao-c8c3727df724362b5453>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\Delta u = f")]]

#text(" in ")#mi("{{\\bf R}^d}")#text(", where ")#mi("{f}")#text(" is a Schwartz function and ")#mi("{u}")#text(" is a distribution, where ")#mi("{\\Delta = \\sum_{j=1}^d \\frac{\\partial^2}{\\partial x_j^2}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Laplace_operator")[#text("Laplacian")]#text(". (In some texts, particularly those using spectral analysis, the Laplacian is occasionally defined instead as ")#mi("{-\\sum_{j=1}^d \\frac{\\partial^2}{\\partial x_j^2}}")#text(", to make it positive semi-definite, but we will eschew that sign convention here, though of course the theory is only changed in a trivial fashion if one adopts it.)")

#text("We first settle the question of uniqueness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Let ")#mi("{d \\geq 1}")#text(". Using the Fourier transform, show that the only tempered distributions ")#mi("{\\lambda \\in {\\mathcal S}({\\bf R}^d)^*}")#text(" which are harmonic (by which we mean that ")#mi("{\\Delta \\lambda = 0}")#text(" in the sense of distributions) are the harmonic polynomials. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-82dfec6fd3c2e148c7cb>)[#text("22")]#text(".) Note that this generalises ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(". There are of course many other harmonic functions than the harmonic polynomials, e.g. ")#mi("{e^x \\cos(y)}")#text(", but such functions are not tempered distributions.")
]

#text("From the above exercise, we know that the solution ")#mi("{u}")#text(" to ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(", if tempered, is defined up to harmonic polynomials. To find a solution, we observe that it is enough to find a ")#emph[#text("fundamental solution")]#text(", i.e. a tempered distribution ")#mi("{K}")#text(" solving the equation")

#align(center)[#tao-fit-display[#mitex("\\Delta K = \\delta.")]]

#text("Indeed, if one then convolves this equation with the Schwartz function ")#mi("{f}")#text(", and uses the identity ")#mi("{(\\Delta K) * f = \\Delta(K*f)}")#text(" (which can either be seen directly, or by using Exercise ")#link(<tao-9a6c847424f1483fa41c>)[#text("31")]#text("), we see that ")#mi("{u=K*f}")#text(" will be a tempered distribution solution to ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(" (and all the other solutions will equal this solution plus a harmonic polynomial). So, it is enough to locate a fundamental solution ")#mi("{K}")#text(". We can take Fourier transforms and rewrite this equation as")

#align(center)[#tao-fit-display[#tao-math("-4\\pi^2 \\left|\\xi\\right|^2 \\hat K(\\xi) = 1", block: true)]]

#text("(here we are treating the tempered distribution ")#mi("{\\hat K}")#text(" as a function to emphasise that the dependent variable is now ")#mi("{\\xi}")#text("). It is then natural to propose to solve this equation as ")#metadata(none) <tao-f3514f7d40a5aa298ea6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\hat K(\\xi) = \\frac{1}{-4\\pi^2 \\left|\\xi\\right|^2},", block: true)]]

#text(" though this may not be the unique solution (for instance, one is free to modify ")#mi("{K}")#text(" by a multiple of the Dirac delta function, cf. Exercise ")#link(<tao-f2ad8f292453bfebf871>)[#text("16")]#text(").")

#text("A short computation in polar coordinates shows that ")#tao-math("{\\frac{1}{-4\\pi^2 \\left|\\xi\\right|^2}}", block: false)#text(" is locally integrable in dimensions ")#mi("{d \\geq 3}")#text(", so the right-hand side of ")#link(<tao-f3514f7d40a5aa298ea6>)[#text("(7)")]#text(" makes sense. To then compute ")#mi("{K}")#text(" explicitly, we have from the distributional inversion formula that")

#align(center)[#tao-fit-display[#tao-math("K = \\frac{-1}{4\\pi^2} {\\mathcal F}^* \\left|\\xi\\right|^{-2}", block: true)]]

#text("so we now need to figure out what the Fourier transform of a negative power of ")#tao-math("{\\left|x\\right|}", block: false)#text(" (or the adjoint Fourier transform of a negative power of ")#tao-math("{\\left|\\xi\\right|}", block: false)#text(") is.")

#text("Let us work formally at first, and consider the problem of computing the Fourier transform of the function ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" in ")#mi("{{\\bf R}^d}")#text(" for some exponent ")#mi("{\\alpha}")#text(". A direct attack, based on evaluating the (formal) Fourier integral ")#metadata(none) <tao-f422f1dba3be35b17f4e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\widehat{\\left|x\\right|^{-\\alpha}}(\\xi) = \\int_{{\\bf R}^d} \\left|x\\right|^{-\\alpha} e^{-2\\pi i \\xi \\cdot x}\\ dx", block: true)]]

#text(" does not seem to make much sense (the integral is not absolutely integrable), although a change of variables (or dimensional analysis) heuristic can at least lead to the prediction that the integral ")#link(<tao-f422f1dba3be35b17f4e>)[#text("(8)")]#text(" should be some multiple of ")#tao-math("{\\left|\\xi\\right|^{\\alpha-d}}", block: false)#text(". But which multiple should it be? To continue the formal calculation, we can write the non-integrable function ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" as an average of integrable functions whose Fourier transforms are already known. There are many such functions that one could use here, but it is natural to use Gaussians, as they have a particularly pleasant Fourier transform, namely")

#align(center)[#tao-fit-display[#tao-math("\\widehat{ e^{-\\pi t^2 \\left|x\\right|^2} }(\\xi) = t^{d} e^{-\\pi \\left|\\xi\\right|^2 / t^2}", block: true)]]

#text("for ")#mi("{t>0}")#text(" (see Exercise 42 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("Notes 2")]#text("). To get from Gaussians to ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(", one can observe that ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" is invariant under the scaling ")#mi("{f(x) \\mapsto t^{\\alpha} f(tx)}")#text(" for ")#mi("{t>0}")#text(". Thus, it is natural to average the standard Gaussian ")#tao-math("{e^{-\\pi \\left|x\\right|^2}}", block: false)#text(" with respect to this scaling, thus producing the function ")#tao-math("{t^{\\alpha} e^{-\\pi t^2 \\left|x\\right|^2}}", block: false)#text(", then integrate with respect to the multiplicative Haar measure ")#mi("{\\frac{dt}{t}}")#text(". A straightforward change of variables then gives the identity")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty t^{\\alpha} e^{-\\pi t^2 \\left|x\\right|^2} \\frac{dt}{t} = \\frac{1}{2} \\pi^{-\\alpha/2} \\left|x\\right|^{-\\alpha} \\Gamma(\\alpha/2)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) := \\int_0^\\infty t^s e^{-t} \\frac{dt}{t}")]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(". If we formally take Fourier transforms of this identity, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty t^{\\alpha} t^{-d} e^{-\\pi \\left|x\\right|^2/t^2} \\frac{dt}{t} = \\frac{1}{2} \\pi^{-\\alpha/2} \\widehat{\\left|x\\right|^{-\\alpha}}(\\xi) \\Gamma(\\alpha/2).", block: true)]]

#text("Another change of variables shows that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty t^{\\alpha} t^{-d} e^{-\\pi \\left|x\\right|^2/t^2} \\frac{dt}{t} = \\frac{1}{2} \\pi^{-(d-\\alpha)/2} \\left|\\xi\\right|^{-(d-\\alpha)} \\Gamma((d-\\alpha)/2)", block: true)]]

#text("and so we conclude (formally) that ")#metadata(none) <tao-91a65f413289298e4283>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\widehat{\\left|x\\right|^{-\\alpha}}(\\xi) = \\frac{\\pi^{-(d-\\alpha)/2} \\Gamma((d-\\alpha)/2)}{\\pi^{-\\alpha/2} \\Gamma(\\alpha/2)} \\left|\\xi\\right|^{-(d-\\alpha)}", block: true)]]

#text(" thus solving the problem of what the constant multiple of ")#tao-math("{\\left|\\xi\\right|^{-(d-\\alpha)}}", block: false)#text(" should be.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Give a rigorous proof of ")#link(<tao-91a65f413289298e4283>)[#text("(9)")]#text(" for ")#mi("{0 < \\alpha < d}")#text(" (when both sides are locally integrable) in the sense of distributions. (")#emph[#text("Hint:")]#text(" basically, one needs to test the entire formal argument against an arbitrary Schwartz function.) The identity ")#link(<tao-91a65f413289298e4283>)[#text("(9)")]#text(" can in fact be continued meromorphically in ")#mi("{\\alpha}")#text(", but the interpretation of distributions such as ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" when ")#tao-math("{\\left|x\\right|^{-\\alpha}}", block: false)#text(" is not locally integrable is somewhat complicated (cf. Exercise ")#link(<tao-0bebf1a578c50388f7a7>)[#text("12")]#text(") and will not be discussed here.")
]

#text("Specialising back to the current situation with ")#mi("{d=3, \\alpha=2}")#text(", and using the standard identities")

#align(center)[#tao-fit-display[#mitex("\\Gamma(n) = (n-1)!; \\quad \\Gamma(\\frac{1}{2}) = \\sqrt{\\pi}")]]

#text("we see that")

#align(center)[#tao-fit-display[#tao-math("\\widehat{\\frac{1}{\\left|x\\right|^2}}(\\xi) = \\pi \\left|\\xi\\right|^{-1}", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal F}^* \\frac{1}{\\left|\\xi\\right|^2} = \\pi \\left|x\\right|^{-1}", block: true)]]

#text("and so from ")#link(<tao-f3514f7d40a5aa298ea6>)[#text("(7)")]#text(" we see that one choice of the fundamental solution ")#mi("{K}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newton potential")]

#align(center)[#tao-fit-display[#tao-math("K = \\frac{-1}{4\\pi \\left|x\\right|},", block: true)]]

#text("leading to an explicit (and rigorously derived) solution ")#metadata(none) <tao-25d83a47ab68b8a7a86e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("u(x) := f*K(x) = -\\frac{1}{4\\pi} \\int_{{\\bf R}^3} \\frac{f(y)}{\\left|x-y\\right|}\\ dy", block: true)]]

#text(" to the Poisson equation ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(" in ")#mi("{d=3}")#text(" for Schwartz functions ")#mi("{f}")#text(". (This is not quite the only fundamental solution ")#mi("{K}")#text(" available; one can add a harmonic polynomial to ")#mi("{K}")#text(", which will end up adding a harmonic polynomial to ")#mi("{u}")#text(", since the convolution of a harmonic polynomial with a Schwartz function is easily seen to still be harmonic.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Without using the theory of distributions, give an alternate (and still rigorous) proof that the function ")#mi("{u}")#text(" defined in ")#link(<tao-25d83a47ab68b8a7a86e>)[#text("(10)")]#text(" solves ")#link(<tao-c8c3727df724362b5453>)[#text("(6)")]#text(" in ")#mi("{d=3}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]

#list(
[#text("Show that for any ")#mi("{d \\geq 3}")#text(", a fundamental solution ")#mi("{K}")#text(" to the Poisson equation is given by the locally integrable function")

#align(center)[#tao-fit-display[#tao-math("K(x) = \\frac{1}{d(d-2) \\omega_d} \\frac{1}{\\left|x\\right|^{d-2}},", block: true)]]

#text("where ")#mi("{\\omega_d = \\pi^{d/2} / \\Gamma(\\frac{d}{2}+1)}")#text(" is the volume of the unit ball in ")#mi("{d}")#text(" dimensions.")],
[#text("Show that for ")#mi("{d=1}")#text(", a fundamental solution is given by the locally integrable function ")#tao-math("{K(x)=\\left|x\\right|/2}", block: false)#text(".")],
[#text("Show that for ")#mi("{d=2}")#text(", a fundamental solution is given by the locally integrable function ")#tao-math("{K(x)= \\frac{1}{2\\pi} \\log \\left|x\\right|}", block: false)#text(".")]
)

#text("This we see that for the Poisson equation, ")#mi("{d=2}")#text(" is a “critical” dimension, requiring a logarithmic correction to the usual formula.")
]

#text("Similar methods can solve other constant coefficient linear PDE. We give some standard examples in the exercises below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Let ")#mi("{d \\geq 1}")#text(". Show that a smooth solution ")#mi("{u: {\\bf R}^+ \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]#text(" ")#mi("{\\partial_t u = \\Delta u}")#text(" with initial data ")#mi("{u(0,x) = f(x)}")#text(" for some Schwartz function ")#mi("{f}")#text(" is given by ")#mi("{u(t) = f * K_t}")#text(" for ")#mi("{t>0}")#text(", where ")#mi("{K_t}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Heat_kernel")[#text("heat kernel")]

#align(center)[#tao-fit-display[#tao-math("K_t(x) = \\frac{1}{(4\\pi t)^{d/2}} e^{-\\left|x\\right|^2/4t}.", block: true)]]

#text("(This solution is unique assuming certain smoothness and decay conditions at infinity, but we will not pursue this issue here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Let ")#mi("{d \\geq 1}")#text(". Show that a smooth solution ")#mi("{u: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger equation")]#text(" ")#mi("{\\partial_t u = i \\Delta u}")#text(" with initial data ")#mi("{u(0,x) = f(x)}")#text(" for some Schwartz function ")#mi("{f}")#text(" is given by ")#mi("{u(t) = f * K_t}")#text(" for ")#mi("{t \\neq 0}")#text(", where ")#mi("{K_t}")#text(" is the ")#emph[#text("Schrödinger kernel")]

#align(center)[#tao-fit-display[#tao-math("K_t(x) = \\frac{1}{(4\\pi i t)^{d/2}} e^{i\\left|x\\right|^2/4t}", block: true)]]

#text("and we use the standard branch of the complex logarithm (with cut on the negative real axis) to define ")#mi("{(4\\pi i t)^{d/2}}")#text(". (")#emph[#text("Hint:")]#text(" You may wish to investigate the Fourier transform of ")#tao-math("{e^{-z\\left|\\xi\\right|^2}}", block: false)#text(", where ")#mi("{z}")#text(" is a complex number with positive real part, and then let ")#mi("{z}")#text(" approach the imaginary axis.) (The close similarity with the heat kernel is a manifestation of ")#link("http://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text(" in action. However, from an analytical viewpoint, the two kernels are very different. For instance, the convergence of ")#mi("{f*K_t}")#text(" to ")#mi("{f}")#text(" as ")#mi("{t \\rightarrow 0}")#text(" follows in the heat kernel case by the theory of approximations to the identity, whereas the convergence in the Schrödinger case is much more subtle, and is best seen via Fourier analysis.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Let ")#mi("{d=3}")#text(". Show that a smooth solution ")#mi("{u: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf C}}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave equation")]#text(" ")#mi("{-\\partial_{tt} u + \\Delta u=0}")#text(" with initial data ")#mi("{u(0,x) = f(x), \\partial_t u(0,x) = g(x)}")#text(" for some Schwartz functions ")#mi("{f,g}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("u(t) = f * \\partial_t K_t + g * K_t")]]

#text("for ")#mi("{t \\neq 0}")#text(", where ")#mi("{K_t}")#text(" is the distribution")

#align(center)[#tao-fit-display[#mitex("\\langle f, K_t \\rangle := \\frac{t}{4\\pi} \\int_{S^2} f(t\\omega)\\ d\\omega")]]

#text("where ")#mi("{\\omega}")#text(" is Lebesgue measure on the sphere ")#mi("{S^2}")#text(", and the derivative ")#mi("{\\partial_t K_t}")#text(" is defined in the Newtonian sense ")#mi("{\\lim_{dt \\rightarrow 0} \\frac{K_{t+dt}-K_t}{dt}}")#text(", with the limit taken in the sense of distributions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The theory of (tempered) distributions is also highly effective for studying variable coefficient linear PDE, especially if the coefficients are fairly smooth, and particularly if one is primarily interested in the singularities of solutions to such PDE and how they propagate; here the Fourier transform must be augmented with more general transforms of this type, such as ")#link("http://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(". A classic reference for this topic is the four volumes of Hörmander’s “The analysis of linear partial differential operators”. For nonlinear PDE, subspaces of the space of distributions, such as ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev spaces")]#text(", tend to be more useful.")
]

#heading(level: 1)[#text("Comments (177)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2022")])]

#text("Does one have a nontrivial example of good seminorms on ")#mi("C_c^\\infty(\\mathbf{R}^d)")#text("?")

#emph[#text("[Pretty much all of the standard seminorms are good, e.g., the ")#mi("L^p")#text(" or ")#mi("C^k")#text(" norms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("In Exercise 11, how to show that ")#mi("\\delta^{\\prime}")#text(" does not arise from a locally integrable function? Suppose ")#mi("g\\in L_{\\text{loc}}^1(\\mathbf{R})")#text(" is such that for all test function ")#mi("f")#text(",")

#mi("\\displaystyle -f^{\\prime}(0) = \\int_{\\mathbf{R}} f(x)g(x)\\;dx")

#text("If this is not possible, for any ")#mi("g\\in L_{\\text{loc}}^1")#text(", one can find a text function ")#mi("f")#text(" such that the identity above does not hold. How can one find ")#mi("f")#text("? Or does one need another approach?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671258")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("Use a sequence of test functions ")#mi("f_n")#text(" which are uniformly bounded and have uniformly bounded support, but for which ")#mi("f^{\\prime}_n(0)")#text(" goes to infinity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2023")])]

#emph[#linebreak()#text(" … We make the trivial remark that if ")#mi("{K \\subset K^{\\prime}}")#text(" are compact sets, then ")#mi("{C^\\infty_c(K)}")#text(" is a subspace of ")#mi("{C^\\infty_c(K^{\\prime})}")#text(", and the topology on the former space is the restriction of the topology of the latter space. Because of this, we are able to give ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" a (very strong) topology as follows. …")#linebreak()#text(" ")]

#text("Where is the remark used when defining the topology on ")#mi("{C^\\infty_c({\\bf R}^d)}")#text("?")

#emph[#text("[Oops, this was from an earlier version of the notes; this remark can be safely deleted. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671302")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2023")])]

#text("If ")#mi("\\mu")#text(" and ")#mi("\\lambda")#text(" are two different distributions in ")#mi("C_c^\\infty(\\mathbf{R}^d)^*")#text(". how can one find two disjoint open sets to separate ")#mi("\\mu")#text(" and ")#mi("\\lambda")#text(" for showing Hausdorff in Exercise 7? While it is clear to see what convergence in ")#mi("C_c^\\infty(\\mathbf{R}^d)^*")#text(" means from Definition 1, it is unclear how one can construct the desired open sets in the weak* topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("If ")#mi("\\mu")#text(" and ")#mi("\\lambda")#text(" are distinct distributions, then there is a test function ")#mi("f")#text(" such that ")#mi("\\langle f, \\mu \\rangle \\neq \\langle f, \\lambda \\rangle")#text(". One can then use the level sets of the linear functional ")#mi("\\langle f, \\cdot \\rangle")#text(" to separate ")#mi("\\mu")#text(" and ")#mi("\\lambda")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2023")])]

#text("So, since one can separate two real numbers by disjoint intervals ")#mi("U")#text(" and ")#mi("V")#text(", and the linear functional associated with ")#mi("f")#text(" is continuous, the inverse images of ")#mi("U")#text(" and ")#mi("V")#text(" under ")#mi("\\langle f, \\cdot \\rangle")#text(" give the open sets separating ")#mi("\\mu")#text(" and ")#mi("\\lambda")#text(".")

#text("The way a linear functional is used to separate things looks like something very similar to the spirit of the Geometric Hahn-Banach theorem in Notes 6 of 245B. Are there any connections?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2023")])]

#text("If ")#mi("f\\in L^p")#text(", can one define the weak derivative as ")#mi("\\lim_{h\\to 0}\\frac{f(x+h)-f(x)}{h}")#text(" where the limit is taken as a ")#mi("L^p")#text(" limit? How strong is this one compared to the distributional limit?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-671975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("This is basically the ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_derivative")[#text("Fréchet derivativederivative")]#text(", and is more restrictive than the weak derivative (if a function is Fréchet differentiable, then it is weakly differentiable and the two derivatives agree, but not every weakly differentiable function will be Fréchet differentiable – you are invited to come up with a counterexample).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-672227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2023")])]

#text("A minor typo above Exercise 2: ")#mi("C^\\infty_c({\\bf R})^d")#text(" is supposed to be ")#mi("C^\\infty_c({\\bf R}^d)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-673750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#text("In Folland’s ")#emph[#text("Real Analysis")]#text(", the author makes a comment in his book that:")

#text("… the definition (of the topology on ")#mi("C_c^\\infty")#text(") is rather complicated and of little importance for the elementary theory of distributions, so we shall omit it.")

#text("In Rudin’s ")#emph[#text("Functional Analysis")]#text(", Section 6, it is indeed in a rather complicated way:")

#text("6.3 Definitions Let ")#mi("\\Omega")#text(" be a nonempty open set in ")#mi("{\\bf R}^n")#text(".")

#text("(a) For every compact ")#mi("K \\subset \\Omega, \\tau_K")#text(" denotes the Fréchet space topology of ")#mi("\\mathscr{D}_{\\mathrm{K}}")#text(", as described in Sections 1.46 and 6.2.")

#text("(b) ")#mi("\\beta")#text(" is the collection of all convex balanced sets ")#mi("W \\subset \\mathscr{D}(\\Omega)")#text(" such that ")#mi("\\mathscr{D}_{\\mathbf{K}} \\cap W \\in \\tau_{\\mathbf{K}}")#text(" for every compact ")#mi("K \\subset \\Omega")#text(".")

#text("(c) ")#mi("\\tau")#text(" is the collection of all unions of sets of the form ")#mi("\\phi+W")#text(", with ")#mi("\\phi \\in \\mathscr{D}(\\Omega)")#text(" and ")#mi("W \\in \\beta")#text(". This will be the topology on ")#mi("\\mathscr{D}(\\Omega)")#text(".")

#text("But in this set of notes, the definition of the topology above Exercise 2 seems rather simple compared to the mentioned ones: all one needs are nothing but the notion of “good” seminorms! Are they all equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-673908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2023")])]

#text("Sorry if the question above is unclear. Here is a modified version of the question.")

#text("The following is a sketch of how Rudin in his Functional Analysis defines the topology on the space ")#mi("D(\\Omega)=C_c^\\infty(\\Omega)")#text(" of test functions where ")#mi("\\Omega")#text(" is a nonempty open subset of ")#mi("{\\bf R}^d")#text(". I am wondering if the special case when ")#mi("\\Omega=latex {\\bf R}^d")#text(" in Rudin gives exactly the same topology as the one in this set of notes. (There are several other definitions on Wikipedia (")#link("https://en.wikipedia.org/wiki/Spaces_of_test_functions_and_distributions")[#text("https://en.wikipedia.org/wiki/Spaces_of_test_functions_and_distributions")]#text("): none of those looks like the one in this note.)")

#text("– For each compact ")#mi("K\\subset \\Omega")#text(", define ")#mi("D_K")#text(", which is the same as ")#mi("C_c^\\infty(K)")#text(" in this note.")

#text("– Define the smooth topology on ")#mi("C^\\infty(\\Omega)")#text(" with the seminorms")

#tao-math("\\displaystyle p_N(f)=\\max\\{\\left|D^\\alpha f(x)\\right|:x\\in K_N, \\left|\\alpha\\right|\\le N\\}, N = 1,2,\\cdots", block: false)

#text("where ")#mi("\\Omega")#text(" is the union of the compact set ")#mi("K_i")#text(" and ")#mi("K_i")#text(" is contained in the interior of ")#mi("K_{i+1}")#text(".")

#text("– ")#mi("D_K")#text(" is a closed subspace of ")#mi("C^\\infty(\\Omega)")#text(" with the smooth topology. (The topology ")#mi("\\tau_K")#text(" on ")#mi("D_K")#text(" should be the same as the smooth topology on ")#mi("C_c^\\infty(K)")#text(" in this note.)")

#text("– Let ")#mi("\\beta")#text(" be the set of convex balanced sets ")#mi("W\\subset D(\\Omega)")#text(" such that ")#mi("W\\cap D_K\\in\\tau_K")#text(" for every compact ")#mi("K\\subset \\Omega")#text(".")

#text("– The topology on ")#mi("D(\\Omega)")#text(" is then defined by sets of the form ")#mi("\\cup \\phi+W")#text(" with ")#mi("\\phi\\in D(\\Omega)")#text(" and ")#mi("W\\in\\beta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-681940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("Hi Prof. Tao,")#linebreak()#text(" Thanks for the wonderful notes. I really admire the procedure for computing the Fourier transform of ")#tao-math("\\left|x\\right|^{-\\alpha}", block: false)#text(". So what about the Fourier transform of ")#tao-math("\\left|x\\right|^{\\alpha}", block: false)#text(" with positive ")#mi("\\alpha")#text("? Can we apply the same technique?")

#emph[#text("[Sure, though the result will be a somewhat exotic distribution, not given as a locally integrable function. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-685300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("Is this blog a citeable as a source? In particular, I would like to support the claim that in mathematics, a “common” way to interpret $1/|x|$ as a distribution is via the definition in exercise 13. However, beside this blog post and some mathematics stackexchange pages (linking to this blog) I have actually never seen this before. Or could someone link some other source for this interpretation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-691547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2026")])]

#text("Minor typo: in exercise 4(ii) the lowercase $k$ corresponds to the compact $K’$ and $k’$ corresponds to $K$. The statement is true, but is confusing (I accidentally read it wrong and tried to prove the wrong implication).")

#emph[#text("[Swapped ")#mi("k")#text(" and ")#mi("k^{\\prime}")#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-691778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2026")])]

#text("Another typo: Exercise 4(v) as written is wrong. The map must be required to be linear.")

#text("Counterexample for nonlinear map: ")#tao-math("Tf(x)=f(x)+g(x-e^{{\\left|\\left|f\\right|\\right|}_2}*v)", block: false)#text(" for some fixed vector ")#mi("v")#text(" and any ")#mi("C^\\infty")#text(" function ")#mi("g")#text(" supported on the unit ball. Take any sequence ")#mi("f_n")#text(" with common support ")#mi("K")#text(" with ")#tao-math("{\\left|\\left|f_n\\right|\\right|}_2=n", block: false)#text(", then the support of ")#mi("Tf_n")#text(" is a translate of ")#mi("K")#text(" which drifts in the direction of ")#mi("v")#text(" and is unbounded as ")#mi("n\\to\\infty")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-691814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("Question: in exercises 1(iv) and 4(iv) you wrote the $L^p$ space for $0<p<\\infty$. But for $0<p<1$ the topology is not locally convex, and it needs special treatment and different proofs. Is this intentional?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-691818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("The non-convex ")#mi("L^p")#text(" spaces (")#mi("0 < p < 1")#text(") are occasionally useful in analysis, and it is still worth knowing that they interact well with test functions, although they are not locally integrable in general and so do not automatically give rise to distributions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-3/#comment-691958")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2026")])]

#text("Something is wrong in Exercise 26: the third bullet is missing the conclusion to prove, and the second bullet is wrong (probably a typo) — it should be composition instead of multiplication, but in that case, there should not be an absolute value for the determinant, i.e. it should read $ \\text{p.v.} \\frac{1}{x} \\circ L = \\frac{1}{det(L)}\\text{p.v.} \\frac{1}{x}$.")

#text("I’m not sure what the third bullet should exactly prove. It is obviously some converse to the first two bullets, but due to no absolute value in the second bullet, the first two bullets’ conclusions don’t match exactly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-329740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2014")])]

#text("Dear Dr. Tao,")

#text("In the process of solving Exercise 40, how do we define the in Fourier transform of a tempered distribution? For, example, let \\lambda be a tempered distribution then (F\\lambda) (f)=\\lambda(Ff) or (F\\lambda) (f)=\\lambda(F^{-1}f), where F is denoting the Fourier transform?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-330348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("See equation (5).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-331346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("Dear Dr. Tao,")

#text("Are we supposed to use Kirchhoff’s formula to get the distribution K_{t} in Exercise 40?")

#text("Thanks")#linebreak()#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-339989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("Dear Dr. Tao,")

#text("In Exercise 40, what is the meaning of “Newtonian Sense” and how to use it in solving this Exercise?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-340004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#link("http://en.wikipedia.org/wiki/Newton_quotient")[#text("http://en.wikipedia.org/wiki/Newton_quotient")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-340113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("Just a minor comment for correction, in Exercise 40 isn’t it “… for some Schwartz functions {f} and {g} …” instead of “… for some Schwartz functions {f} is given by the formula …?”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458292")[#strong[#text("KE operator and eigenfunctions")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2015")]

#text("[…] I could explain what's going on but it will involve a long sojourn into distribution theory: ")#link(<tao-ab20bb57db84b8144e7b>)[#text("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/#more-2072")]#text(" Really your teacher needs to explain it – post here with what he/she says – it should prove […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("In some books, a distribution on ")#mi("{\\Bbb R}^d")#text(" is defined as a linear functional ")#mi("\\psi:C_c^\\infty(\\Bbb{R}^d)\\to\\Bbb{R}")#text(" with the following property")

#text("Suppose ")#mi("\\{\\varphi_n\\}")#text(" is a sequence in ")#mi("D(\\Omega):=C_c^\\infty(\\Bbb{R}^d)")#text(" such that")

#text("There exists a compact subset ")#mi("K")#text(" of ")#mi("\\Omega:=\\Bbb{R}^d")#text(" such that")

#mi("supp\\ \\varphi_n\\subset K\\Subset\\Omega")

#text("for all ")#mi("n")#linebreak()#text(" and")

#mi("D^\\alpha\\varphi_n\\to 0")#text(" uniformly")#linebreak()#text(" as ")#mi("n\\to\\infty")#text(" for all ")#mi("\\alpha\\in {\\bf Z}_+^d")

#text("Then ")#mi("\\psi(\\varphi_n)\\to 0")#text(" as ")#mi("n\\to\\infty")#text(".")

#text("Is it exactly the same as the distributions defined in this note?")

#emph[#text("[Yes; see Exercise 4(iii). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458508")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("What is the weak derivative of the distribution defined in Exercise 12? It seems that p.v.(1/x^2) is not well defined…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("If one chases the definitions and integrates by parts, one has")

#mi("\\displaystyle \\langle f, \\frac{d}{dx} p.v. \\frac{1}{x} \\rangle = \\langle - f^{\\prime}, p.v. \\frac{1}{x} \\rangle")

#tao-math("\\displaystyle = \\lim_{\\varepsilon \\to 0} - \\int_{\\left|x\\right| > \\varepsilon} \\frac{f^{\\prime}(x)}{x}\\ dx", block: false)

#tao-math("\\displaystyle = \\lim_{\\varepsilon \\to 0} - \\int_{\\left|x\\right| > \\varepsilon} \\frac{f(x)}{x^2}\\ dx + \\frac{f(\\varepsilon) + f(-\\varepsilon)}{\\varepsilon}", block: false)

#tao-math("\\displaystyle = \\lim_{\\varepsilon \\to 0} - \\int_{\\left|x\\right| > \\varepsilon} \\frac{f(x)}{x^2}\\ dx + \\frac{2f(0)}{\\varepsilon}.", block: false)

#text("So the derivative of p.v. 1/x is a renormalised principal value of -1/x^2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("Hmm, how can one get the last line?")

#emph[#text("[Taylor expansion -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2015")])]

#text("It seems that this relates to ")#link("https://en.wikipedia.org/wiki/Hadamard_regularization")[#text("https://en.wikipedia.org/wiki/Hadamard_regularization")]

#text("But I don’t see why the limit exists…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2015")])]

#text("Can one say that the limit in the last line exists since it is “equal” to ")#mi("\\langle -f^{\\prime},p.v.\\frac{1}{x}\\rangle")#text(", the existence of which has been proven in Ex. 12? It looks like a circular argument to me since in the very beginning one assumes the existence of ")#mi("\\frac{d}{dx}p.v.\\frac{1}{x}")#text(".")

#emph[#text("[Yes, the existence of the earlier limits (which indeed follows from the easily verified fact that the distributional derivative of a distribution is again a distribution, together with Exercise 12) can be used to establish the existence of the later limits. It is also instructive to establish (again, using Taylor expansion) directly that the later limit is of a Cauchy sequence and thus convergent. -T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-458595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2015")])]

#text("I read somewhere before but I don’t remember exactly in what book:")

#text("Let $(a_n)$ be a strictly decreasing (I don’t remember if it is increasing or decreasing) positive sequence such that ")#mi("\\sum_{n=0}^\\infty a_n<+\\infty")#text(". If we defines")

#mi("g_n=h_0*h_1*\\cdots*h_n")

#text("where ")#mi("h_n=1_{0,a_n}/a_n")#text(", then ")#mi("g_n")#text(" converges (uniformly) to a function in ")#mi("C_c^\\infty(\\Bbb{R})")#text(".")

#text("Has anybody here seen a reference for such constructions of a nontrivial test function before? It seems that Exercise 1(i) is more standard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-459404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("Stop cheating on math M541 homework.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461364")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] in the sense of distributions that arises in distribution theory (discussed for instance in this previous blog post), however strictly speaking the two notions of convergence are distinct and should not be confused […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("When construct an approximation to the identity, is there a particular reason that one chooses sequence ")#mi("\\phi_n")#text(" instead of a continuous version ")#mi("(\\phi_\\varepsilon)_{\\varepsilon>0}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("In Exercise 5(ii), does one need to ")#emph[#text("assume")]#text(" that ")#mi("f*\\phi_n\\in L^p(\\Bbb{R}^d)")#text(" first in order to argue that “")#mi("f*\\phi_n")#text(" converges in ")#mi("L^p(\\Bbb{R}^d)")#text(" to ")#mi("f")#text("“?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461683")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("No, this is implicitly part of the conclusion (but this follows easily from Young’s inequality or Minkowski’s inequality).")

#text("If one only assumes local integrability or ")#mi("L^p")#text(" on ")#mi("f")#text(", then one needs compact support of the approximating sequence ")#mi("\\phi_n")#text(", as otherwise the tail of ")#mi("\\phi_n")#text(" could interact with an arbitrarily large growth of ")#mi("f")#text(" and it is not even immediate that ")#mi("f * \\phi_n")#text(" is anywhere finite, let alone convergent to anything interesting.")

#text("In most applications there is not much difference between using a discrete sequence of approximations rather than a continuous sequence, but using a countable discrete sequence makes it essentially trivial to establish measurability of any limit objects obtained, and also there are some sequential compactness results one can exploit when working with a discrete sequence that are not easily available in the continuous setting. (Of course in many situations one can use topological compactness as a substitute for sequential compactness, e.g. use topological Banach-Alaoglu in place of sequential Banach-Alaoglu.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461679")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("If ")#mi("f")#text(" is locally integrable or more generally ")#mi("L^p_{\\text{loc}}(\\Bbb{R}^d)")#text(", can one have the similar fact in Exercise 5?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("In Exercise 1(iv), what is ")#mi("C_0(\\bf{R}^d)")#text("? I’ve looked it up in your textbook and I didn’t find it there.")

#emph[#text("[See Exercise 1.10.7 (or Exercise 7 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text("), or also Exercise 1.10.17, Remark 1.10.16, etc..]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-461687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2015")])]

#text("In Exercise 9")

#emph[#text("if a sequence of locally integrable functions converge in ")#mi("{L^1_{\\text{loc}}}")#text(" to a limit…")]

#text("What is the topology defined for ")#mi("L^1_{\\text{loc}}")#text("?")

#emph[#text("[The topology of ")#mi("L^1_{\\text{loc}}")#text(" is the topology generated by the seminorms ")#mi("\\| \\|_{L^1(K)}")#text(" for compact ")#mi("K")#text(", as in Example 1.9.5. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-462733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("Can one safely replace ")#mi("\\mathbb{R}^d")#text(" with any open set ")#mi("\\Omega\\subset \\mathbb{R}^d")#text(" in this note to get the theory of distribution on ")#mi("\\Omega")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-462734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("The theory of distributions localises fairly easily (basically just replace ")#mi("C^\\infty_c(\\mathbb{R}^d)")#text(" with ")#mi("C^\\infty_c(\\Omega)")#text("). But the theory of ")#emph[#text("tempered")]#text(" distributions is significantly more difficult to work with on domains, because it is not obvious how to define the Schwartz class on a domain (and because the main tool that makes the tempered distribution concept useful, namely the distributional Fourier transform, is not obviously available).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-466763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2016")])]

#text("I’m confused with the distributional derivatives in the setting of linear PDE. When one uses the formula")

#mi("\\displaystyle  \\langle f, P\\lambda \\rangle := \\langle P^* f, \\lambda \\rangle")

#text("to define ")#mi("P\\lambda")#text(", is ")#mi("P^*")#text(" just the “formal adjoint” of ")#mi("P")#text("? For general ")#mi("\\Omega\\subset{\\bf R}^d")#text(", when one works in a boundary value problem in PDE (say Dirichlet problem or the Neumann problem for the Laplacian equations), should the adjoint ")#mi("P^*")#text(" depend also on the boundary conditions so that one has different definitions of the distributional derivative of the same differential operator ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-466764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2016")])]

#text("For distributions on a domain ")#mi("\\Omega")#text(", the test functions ")#mi("f")#text(" involved are in ")#mi("C^\\infty_c(\\Omega)")#text(", so they vanish to infinite order on the boundary. In particular, the precise notion of adjoint used is not relevant, as they will all agree on these test functions; in particular, the formal adjoint suffices. But one certainly has to take boundary issues into account when attempting to extend a distribution on ")#mi("\\Omega")#text(" to all of ")#mi("{\\bf R}^d")#text("; the situation here is more subtle than the corresponding situation with measurable functions, in which one can simply extend the function by zero outside of the domain. In general, the extension operation on distributions is not unique, which is related to the non-uniqueness of the adjoint operator when applied to more general functions than ")#mi("C^\\infty_c(\\Omega)")#text(" functions.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-464600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")])]

#text("Given a distribution ")#mi("\\lambda")#text(", can we in general find a distribution ")#mi("\\mu")#text(" with ")#mi("\\lambda")#text(" as its distributional derivative?")

#emph[#text("[Yes; this is a good exercise for you to establish. The key point is that the test functions of mean zero form a hyperplane in the space of all test functions, in that any test function can be made mean zero by subtraction of a scalar multiple of a fixed reference test function. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous2")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-468517")[#strong[#text("Anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("A result due to de Rham says the following:")

#text("Let ")#mi("f_i\\in D^{\\prime}(\\Omega)")#text(", ")#mi("i=1,2,\\cdots,n")#text(", be distributions, where ")#mi("\\Omega")#text(" is a domain in ")#mi("\\mathbb{R}^n")#text(". Then ")#mi("f=\\nabla p")#text(" for some ")#mi("p\\in D^{\\prime}(\\Omega)")#text(" iff ")#mi("\\langle f,v\\rangle=0")#text(" for all ")#mi("v\\in C_0^\\infty(\\Omega)^n")#text(" with ")#mi("\\nabla\\cdot v=0")#text(".")

#text("Does this contradicts the positive answer to the question above?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-468519")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("No; the previous question concerned only the one-dimensional case ")#mi("n=1")#text(" (or of a single partial derivative, rather than the full gradient), in which case the condition ")#mi("\\nabla \\cdot v = 0")#text(" forces ")#mi("v")#text(" to vanish identically.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56d530d34fffa7f615cca018c65b96a5067f11ba4be3930f795d185c0b191521-d209e71f64bb6a0c9570ebbca16a54b1e6bdd1c84825245a58304e37da01adff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-465520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2016")])]

#text("How do we see that ” ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" embeds ‘continuously’ into ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text("”")

#emph[#text("[Easiest way is via nets – show that every net that converges in ")#mi("C^\\infty_c")#text(" also converges in the Schwartz topology. Or one can explicitly show that pullbacks of basic open sets are open. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d1c08e2d09727405518ef7a9bf594ebe1ac758aab019ea34841a043670f1707-895b469a4c7b1e891af892289a4708ebe690113c662d61f94ad00388a19ac97f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debanjana Kundu")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-466315")[#strong[#text("Debanjana Kundu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2016")])]

#text("I was wondering if when we’re in ")#mi("\\mathbb{R}^n")#text(" and we know that ")#mi("\\lambda>n")#text(", also ")#mi("k>\\lambda-n-1 \\ (k\\in \\mathbb{Z})")#text("; for a test function ")#mi("\\phi")#text(" if ")#mi("0")#text(" is not in the support of ")#mi("\\phi")#text(" can we say ")#mi("\\partial^{\\alpha}\\phi(0) = 0")#text(" for all ")#tao-math("\\left|\\alpha\\right| \\leq k", block: false)#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-466771")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2016")])]

#text("i am in grade 7 and i knew about your iq")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("In Exercise 5(i), I get")

#mi("\\displaystyle f*\\phi_n(x)=\\int f(x-y)\\phi_n(y)\\ dy")

#text("and")

#mi("\\displaystyle f(x)=\\int f(x)\\phi_n(y)\\ dy")#text(". I want to do the estimate")

#tao-math("\\displaystyle \\left|\\int_K [f(x-y)-f(y)]\\phi_n(y)\\right|", block: false)

#text("But I don’t see how to go on. Do you have a hint?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467384")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#mi("f")#text(" is continuous and compactly supported, and hence uniformly continuous. ")#mi("\\phi_n(y)")#text(" is mostly concentrated in the region where ")#mi("y")#text(" is small, which by uniform continuity lets one place a bound on ")#mi("f(x-y) - f(y)")#text(". So one should chop up the integral into two pieces, one where ")#mi("y")#text(" is small and one where ")#mi("y")#text(" is large, and use two different estimates for each component.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467394")[#strong[#text("jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Instead of ")#mi("f(x-y)-f(y)")#text(", one needs a bounded for ")#mi("f(x-y)-f(x)")#text(", I think?")

#text("Consider the standard symmetric mollifier ")#mi("\\phi")#text(" and ")#mi("phi_n(x)=(1/n)^{-d}\\phi(nx)")#text(". Fix ")#mi("\\epsilon>0")#text(". For large enough ")#mi("n")#text(", ")#tao-math("\\left|f(x-y)-f(x)\\right|<\\epsilon", block: false)#text(" uniformly in ")#mi("B(0,1/n)")

#tao-math("\\displaystyle \\left|\\int_K [f(x-y)-f(x)]\\phi_n(y) \\ dy\\right|=\\left|\\int_{B(0,1/n)} [f(x-y)-f(x)]\\phi_n(y)\\ dy\\right|\\leq \\int_{B(0,1/n)} |f(x-y)-f(x)|\\phi_n(y)\\ dy\\leq\\epsilon", block: false)

#text("Why do we need \"chop up the integral into two pieces\"? Am I doing something wrong here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467395")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Thanks for the correction. I had in mind a more general notion of approximation to the identity than the one that is in this post (in which some leakage of mass outside of a small ball is permitted), but you are right that with the notion of approximation to the identity used here, one does not need to decompose the integral.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")])]

#text("When one tries to upgrade the convergence to uniform convergence on ")#mi("{\\bf R}^d")#text(", the proof above certainly would not work. But do you have a counterexample that one cannot upgrade the compact convergence? Why is compactness crucial here?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("What can one say in general for Exercise 5? Let ")#mi("f\\in X")#text(" for some function space ")#mi("X")#text(" such that ")#mi("f*\\phi_n")#text(" makes sense. Can one always expect that ")#mi("f*\\phi_n\\to f")#text(" in some convergence mode $latex $Y$ (or there are cases that not convergent in any mode at all)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2016")])]

#text("In Exercise 5(ii), do you have a quick counterexample for ")#mi("p=\\infty")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2016")])]

#text("Uniform limits of continuous functions are necessarily continuous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")])]

#text("In Exercise 5(iii), what is the definition of ")#mi("(\\nabla f)*\\phi_n")#text(" when ")#mi("\\nabla f")#text(" is a vector value function? Perhaps you mean")#linebreak()#text(" ")#mi("\\displaystyle \\partial^\\alpha (f*\\phi_n)=(\\partial^\\alpha f)*\\phi_n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-467532")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")])]

#text("Yes. By default, operations on scalar-valued functions are understood to act componentwise on vector-valued functions unless otherwise stated.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-470329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#emph[#text("Since ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" (with a dense image), we see that the space of tempered distributions can be embedded into the space of distributions.")]

#text("How “good” is the embedding? In other words, is every tempered distribution locally integrable? Or is it in the “basic two examples of distributions”?")

#emph[#text("[No. For instance, the Dirac delta distribution is tempered, but not locally integrable. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-472003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("In your definition of the “approximation to the identity”, is the third condition “whose supports shrink to the origin” equivalent to the following condition?")

#mi("\\displaystyle \\lim_{n \\to \\infty}n^{d}\\varphi (nx)=\\delta (x)")

#text("where the limit is understood in the space of Schwartz distributions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 1: Complex differentiation | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-472501")[#strong[#text("246A, Notes 1: Complex differentiation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] by the way, can be largely explained using the theory of distributions, as covered for instance in this previous post, but this is beyond the scope of the current […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-473343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("I don’t see in the notes if the following is true:")

#text("the weak derivative, if exists, must be unique.")

#text("I found that I end up with examining the following")

#text("if ")#mi("f")#text(" is locally integrable and")

#mi("\\displaystyle \\int fg=0")

#text("for all test functions ")#mi("g")#text(", then ")#mi("f=0")#text(" a.e.")

#text("I don’t find a proof here. Would you give me a hint that how this can be proved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-473350")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("Use a limiting argument to show that if ")#mi("f")#text(" is orthogonal to all test functions, then it is also orthogonal to indicator functions of bounded measurable sets. Then argue by contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-491972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("Would anyone elaborate the hint? (1)Where does this set of notes show that the set of test functions is dense in the set of indicator functions of bounded measurable sets? (2) What does the “contradiction” mentioned above refer to?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-478163")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] in the sense of distributions that arises in distribution theory (discussed for instance in this previous blog post), however strictly speaking the two notions of convergence are distinct and should not be confused […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02527872c8e2b1c65c34c5aad9527a15ede351246056aa5a98c57649d04d7661-61c2c76367635e8691b75a2d506a7281c01aa133db6592a1840e16a8a66b3e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LR")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-484504")[#strong[#text("LR")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2017")])]

#text("Dear Prof. Tao,")

#text("I suggest you to take a look at “Multiplication of the Distributions”, by Colombeau, which have some thoughts about applying it to nonlinear problems and the “Impossibility of multiplication” cited by Schwartz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebf33b531b4e8dd08b454c5f771488c3eb69eefb28c1522dfd6abd7b5de3e90-3648a13ba16939805f798516267ff2452301134564bb5f7b96b681c1828ceb20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-492457")[#strong[#text("Sébastien")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("In your excellent PCM note on distributions, you mention that distributions can be composed both ways by suitably smooth functions. Was this a typo or not? Indeed, here and on the internet, I can only find composition in the “apply the true function first” order, and whenever people speak of the exponential of the Gaussian Free Field, they insist on the “one cannot a priori take the exponential of a distribution” issue, so I am confused now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-492464")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("Oops, that is indeed a typo. Distributions can be composed on the right with smooth functions but not on the left in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebf33b531b4e8dd08b454c5f771488c3eb69eefb28c1522dfd6abd7b5de3e90-3648a13ba16939805f798516267ff2452301134564bb5f7b96b681c1828ceb20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-492469")[#strong[#text("Sébastien")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("Thank you very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-494037")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Probably too late but I am curious. Would you define |delta(x)|=delta(x)?")#linebreak()#text(" I think there might be reasons for doing it but also reasons for not doing it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-494060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Sure; one can for instance view this as a (somewhat degenerate) special case of the concept of a ")#link("https://en.wikipedia.org/wiki/Total_variation#Total_variation_of_a_measure")[#text("total variation of a measure")]#text(". In general, though, it is only the measures of finite total variation for which one has a meaningful absolute value; more general distributions, such as the (distributional) derivative ")#mi("\\delta^{\\prime}")#text(" of ")#mi("\\delta")#text(", do not have any particularly useful notion of an absolute value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-494070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("[sorry I am messing up with latex]")

#text("Thank you very much for your answer. What bothers me is that the reasoning used to explain why we do not define \\delta^2 also might be invoked for |\\delta|. If one takes the functions f_n(x)= n*c_n*\\mbox{sinc}(n*x)/\\mbox{rect}(x)")#linebreak()#text(" where c_n is an appropriate constant, then it seems to me that f_n\\to \\delta, but |f_n| does not converge. Am I missing something here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-494078")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("I do not know what the rect(x) function is, but it is certainly the case that the operation ")#tao-math("f \\mapsto \\left|f\\right|", block: false)#text(" (as defined on “nice” functions) is not continuously extendible to the space of all distributions, much as is the case with ")#mi("f \\mapsto f^2")#text(". So there is no meaningful notion of the absolute value of an ")#emph[#text("arbitrary")]#text(" distribution. However, if one restricts to the subclass of distributions that are measures of finite total variation, then ")#tao-math("f \\mapsto \\left|f\\right|", block: false)#text(" becomes a continuous operation (using now the total variation topology), and so one can define ")#tao-math("\\left|\\mu\\right|", block: false)#text(" for ")#mi("\\mu")#text(" in this class. (The sequence you provide will likely not converge in the total variation topology, but only in the distributional topology.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-494086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Thank you very much, I think I understand although I am a bit surprised by this idea of considering a subclass of measures of finite total variation. I wrote the functions in a wrong way but I meant to multiply n*sinc(n*x) by the indicator function of an interval say like [-1,1] and rescale appropriately to have integral =1. But actually even n*sinc(n*x) would have worked for my concern.")#linebreak()#text(" I thought (I am not a professional mathematician) one should usually require nice behaviour over any converging sequence in the distributional topology. I will think more about it.")#linebreak()#text(" – Actually, now I am puzzled by ")#mi("\\delta^2")#text("; if I consider again n*sinc(n*x) then this converges to ")#mi("\\delta")#text(" in distribution and its square does converge to \\delta too… so we might consider L_2 and define \\delta^2?… mm…. ok I don’t want to bother further, you helped already enough, thank you very much again! :)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-497452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("Since Wolff’s notes are used in 271A, I think my following question is related to this post.")

#text("In an estimate, the author gets (the appendix of Chapter 2 The Schwartz Space) a pointwise bound:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|f(x)\\right|\\lesssim \\sum_{j\\leqslant k-1}\\left\\|\\Delta_j^f\\right\\|_{L^1(D(x,2))} +\\int_{D(x,2)}\\left|x-z\\right|^{-(n-k)}\\Delta_k^f(z)\\ dz,", block: false)#linebreak()#text(" where")#linebreak()#text(" ")#tao-math("\\displaystyle \\Delta_j^f(x) = \\sum_{\\left|\\alpha\\right|=j}|D^\\alpha f(x)|.", block: false)#linebreak()#text(" But what one really needs is the bound with ")#mi("D(x,2)")#text(" instead of ")#mi("D(x,1)")#text(". It is said in Wolff’s notes that one can simply do it using rescaling. Can any one elaborate how the rescaling is done?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-497454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("The original goal is to prove by induction that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|f(x)\\right|\\lesssim \\sum_{j\\leqslant k-1}\\left\\|\\Delta_j^f\\right\\|_{L^1(D(x,1))} +\\int_{D(x,1)}\\left|x-z\\right|^{-(n-k)}\\Delta_k^f(z)\\ dz", block: false)#linebreak()#text(" with ")#mi("1\\leqslant k\\leqslant n-1")#text(" where ")#mi("x\\in{\\bf R}^n")#text(".")#linebreak()#text(" The course should be MATH 247A: ")#link("http://www.math.ucla.edu/~tao/247a.1.06f/")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-497493")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("Apply the previous bound to the function ")#mi("\\tilde f(x) := f(x/2)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-497496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("In the first comment, it should be that “But what one really needs is the bound with ")#mi("D(x,1)")#text(" instead of ")#mi("D(x,2)")#text(".")

#text("I find that I messed up with the change of variables calculations. In the simplest case, one has")

#tao-math("\\displaystyle \\left|\\tilde{f}(x)\\right|\\lesssim \\int_{D(x,2)}|\\tilde{f}(y)|\\ dy", block: false)

#text("and hence")

#tao-math("\\displaystyle \\left|f(\\frac{x}{2})\\right|\\lesssim \\int_{D(x,2)}|f(\\frac{y}{2})|\\ dy \\lesssim \\int_{D(\\frac{x}{2},1)}|f(w)|\\ dw", block: false)

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-498200")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2018")])]

#text("Considering both Exercise 1 and 5, I still can’t see how to answer the question in ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/#comment-498013")[#text("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/#comment-498013")]

#text("If one uses an approximation to the identity, ")#mi("\\phi_n\\in C_c^\\infty")#text(", then")#linebreak()#text(" ")#mi("\\displaystyle \\phi_n*f\\to f")#linebreak()#text(" in both ")#mi("L^1")#text(" and ")#mi("L^2")#text(" for ")#mi("f\\in L^1\\cap L^2")#text(". This seems to be quite close to what I want. But there is no guarantee that")#linebreak()#text(" ")#mi("\\displaystyle \\phi_n*f\\in \\mathcal{S}.")

#text("On the other hand, since ")#mi("f\\in L^1")#text(", there exists ")#mi("g\\in C_c")#text(" so that ")#tao-math("\\left\\|f-g\\right\\|_1\\leq\\epsilon and \\left\\|\\phi_n*g-g\\right\\|_1<\\epsilon", block: false)#text(". So one can approximate ")#mi("f\\in L^1")#text(" by")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f-\\phi_n*g\\right\\|_1\\leq 2\\epsilon.", block: false)#linebreak()#text(" where")#linebreak()#text(" ")#mi("\\phi_n*g\\in C_c^\\infty")#text(".")

#text("Since ")#mi("f\\in L^2")#text(" as well, similarly one has")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f-\\phi_n*h\\right\\|_2\\leq 2\\epsilon", block: false)#linebreak()#text(" where ")#mi("\\phi_n*h\\in C_c^\\infty.")#text(" But then one has two different sequences, $\\phi_n*h and \\phi_n*g$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-498201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2018")])]

#text("In the first case, I have already had")

#mi("\\displaystyle \\phi_n*f\\to f")#linebreak()#text(" in both the ")#mi("L^1")#text(" and the ")#mi("L^2")#text(" topologies. What I want is")

#mi("\\displaystyle f_n\\to f")#linebreak()#text(" where ")#mi("f_n\\in\\mathcal{S}")#text(".")

#text("But it is known that ")#mi("\\phi_n*f\\in C^\\infty")#text(". If one can control the decay (and retain the differentiability) of ")#mi("\\phi_n*f")#text(" to get ")#mi("f_n\\in \\mathcal{S}")#text(", then the proof would be complete…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-498256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2018")])]

#text("In addition to convolving with a mollifier, one should also multiply by a smooth cutoff such as ")#mi("x \\mapsto \\phi(x/R)")#text(" to obtain compact support (which, together with the smoothness provided by the mollifier, place one in the Schwartz class without difficulty).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a50c0b2d06f022aa939acf2a10186bfac2ad0f23dea94b5d3505df8866b2f309-c218d4c0677d306b110ec512d74d4d63443697bb08b36015b804fa8f30cfb0b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Chen")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-502325")[#strong[#text("Josh Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Is there any reference or literature you might point to for generalized functions/distributions/Schwartz functions in infinite dimensions? It’s interesting to consider tempered distributions rather than for example Gaussian measures for PDEs with random coefficient fields or time stochastic PDE processes..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb907660e1c9a2662e2a430cfa40d1af0a875c4be3f4c146a39e902c9a08b316-f0be2a2b83c6e6986a212868ce7666d2e6e118ca57e9696538a08fceda03a439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Pires")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-503903")[#strong[#text("Daniel Pires")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2018")])]

#text("Hi professor Tao! I was trying to solve this one problem and I thought it was related to this notes")#linebreak()#text(" if ")#mi("k\\geq 0")#text(" than")

#tao-math("\\displaystyle \\mathcal{F}^{-1}(\\left| \\xi \\right|^ke^{-\\left|\\xi\\right|^2})\\in L^1(\\mathbb{R}^2)\\cap L^\\infty(\\mathbb{R}^2)", block: false)

#text("(here ")#mi("\\mathcal{F}^{-1}")#text(" denotes the inverse Fourier Transform).")

#text("Do you have any hint for how can I solve this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-503916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2018")])]

#text("Basically one needs some decay estimates on the Fourier transform (it turns out in this case that it decays like ")#tao-math("\\left|x\\right|^{-2-k}", block: false)#text("). One can see this for instance by dyadic decomposition (splitting ")#tao-math("\\left|\\xi\\right|^k e^{-\\left|\\xi\\right|^2}", block: false)#text(" into a bunch of rescaled bump functions). In this particular case there may also be some exact formulae that could be helpful (there are some computations of related kernels for instance in Stein’s “singular integrals”, possibly also in Stein-Weiss’s “Fourier analysis on Euclidean spaces”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: Physical derivation of the incompressible Euler and Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-504503")[#strong[#text("254A, Notes 0: Physical derivation of the incompressible Euler and Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("[…] but we will adopt the viewpoint of the theory of distributions (as reviewed for instance in these old lecture notes of mine) and consider approximation against test functions in spacetime, thus we assume […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-505508")[#strong[#text("254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("[…] some key aspects of the theory. A more comprehensive discussion of distributions may be found in this previous blog post. To avoid some minor subtleties involving complex conjugation that are not relevant for this post, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da54eac2367a9611fd10c1f804777d57b9d9d58ca5004d5cb74a88afdfbba6d7-eb414bf1a9a4bb70c80412299c76d2abb38d103d69c0c448a0ed324568e52d63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajnikant Snha")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-506549")[#strong[#text("Rajnikant Snha")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("Dear Professor Tao,")

#text("On p 172, line number 5, Rudin’s Functional Analysis, there is a limit in the space of test functions. It seems to me wrong. Can you supply its intelligible proof.")

#text("With thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Local well-posedness for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-507829")[#strong[#text("254A, Notes 3: Local well-posedness for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2018")])]

#text("[…] some key aspects of the theory. A more comprehensive discussion of distributions may be found in this previous blog post. To avoid some minor subtleties involving complex conjugation that are not relevant for this post, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b2d1a383300b39fa8694da2dd9ae09f42ab263fc8e79448be662de0be9533f6-f9ed6cd31021e20d6cfc633375639e0413ea762f943ab43e8a9abd4d4f7c434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laszlo")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-512283")[#strong[#text("Laszlo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2019")])]

#text("Does the convolution algebra of compactly supported distributions on $R^n$ have any delicate algebraic properties (like Noether ring, etc.)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-512286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2019")])]

#text("I did a bit of poking around and found this recent paper by Vogt on the subject: ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3858282")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=3858282")]#text(" . Presumably the references cited in the introduction will describe the current state of knowledge in this direction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b2d1a383300b39fa8694da2dd9ae09f42ab263fc8e79448be662de0be9533f6-f9ed6cd31021e20d6cfc633375639e0413ea762f943ab43e8a9abd4d4f7c434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laszlo")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-512297")[#strong[#text("Laszlo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2019")])]

#text("Thx!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ce22dfbef696e0ec0df3642b2dc231542108f6a976a14364c22e13705841b3f-c1c09f6011b098686045b40250fe1dcc6f84ca6879e22c088dc92ca89e390e11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acx01bc")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-517941")[#strong[#text("acx01bc")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2019")])]

#text("You should mention ")#mi("\\delta(t) = \\lim_{n \\to \\infty} n 1_{t \\in [0,1/n]}")#text(" which works everywhere even for things such as ")#mi("\\int_{\\Bbb{R}^2} f(x,y)\\delta(x^2+2y)dxdy")#text(", the only point is that the limit doesn’t need to converge in the sense of distributions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff13eab2330c45e415ae25b1be08b3d87ab88c68b03bdca53fab0061825e8d06-5d81f8253547f30e2b221591d136896d586a05fc3f9de19168b1404b373bb93e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-520702")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2019")])]

#text("Dear Professor Tao, I am trying to prove the following statement:")

#text("Let ")#mi("\\mathcal{E}^{\\prime}(\\Omega)")#text(" be the space of the distributions with compact support. Suppose that ")#mi("u_n \\rightarrow u")#text(" in ")#mi("\\mathcal{E}^{\\prime}(\\Omega)")#text(" (In the sense ")#mi("\\langle u_n,v\\rangle_{\\mathcal{E}^{\\prime}(\\Omega),\\mathcal{E}(\\Omega)} \\rightarrow \\langle u,v \\rangle_{\\mathcal{E}^{\\prime}(\\Omega),\\mathcal{E}(\\Omega)}")#text(" for all ")#mi("v \\in \\mathcal{E}(\\Omega)")#text(".Then, there exist a compact ")#mi("K\\subset \\Omega")#text(" such that ")#mi("\\mathrm{supp} u_n, \\mathrm{supp} u \\subset K")#text(" for all ")#mi("n \\in \\mathbb{N}")#text(".")

#text("Is there an easy way to prove it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-520754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Perhaps I am misreading your question, but it appears that “moving bump” type examples such as ")#mi("u_n = 1_{[n,n+1]}")#text(" or “spreading bump” examples such as ")#mi("u_n = \\frac{1}{n} 1_{[0,n]}")#text(" would give counterexamples to your claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-684860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2024")])]

#text("I think these examples don’t work, since we can construct a smooth function ")#mi("\\varphi")#text(" such that ")#mi("\\langle u_n, \\varphi \\rangle \\rightarrow \\infty.")

#emph[#text("[Not if ")#mi("\\varphi")#text(" is required to also be compactly supported – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 2: A little bit of complex and Fourier analysis | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-527884")[#strong[#text("254A, Supplement 2: A little bit of complex and Fourier analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2019")])]

#text("[…] exercise is intended for readers familiar with distribution theory, as discussed for instance in this previous blog post.) If is holomorphic on an open set , establish the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3996143719c8f6ee5fd2da8a1b98d88616f5ebbeeb8bc100d00762fa84326009-793cd9049117ebf563a21572b87e1aaeb88b8608fdd1832c51bfbcd6165dafa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tingzhou")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-551104")[#strong[#text("Tingzhou")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Hi Prof. Tao")

#text("Can you give more hints about Exercise 37: “This we see that for the Poisson equation, {d=2} is a “critical” dimension, requiring a logarithmic correction to the usual formula?” How can we get the “logarithmic correction” to the Fourier transform of ")#tao-math("\\left|x\\right|^{-\\alpha}?", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-551125")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("The logarithmic correction basically arises from the need to add a correction term (in the spirit of Exercise 13) to interpret ")#tao-math("1/\\left|\\xi\\right|^2", block: false)#text(" as a distribution as it is no longer absolutely integrable in dimensions ")#mi("d=1,2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-600227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#emph[#linebreak()#text(" (Indeed, by Exercise 46 of Notes 2, it is not possible to find a non-trivial test function whose Fourier transform is again a test function.)")#linebreak()#text(" ")]

#text("There is no Exercise 46 in Notes 2. Typo?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")])]

#text("In, Exercise 1(iii) (")#mi("C^\\infty")#text(" Urysohn lemma), let ")#mi("\\psi")#text(" be the test function in 1(i). By scaling, one can define ")#mi("\\psi_\\varepsilon(x)=\\psi(x/\\varepsilon)")#text(" to control the size of its support.")

#text("By the Urysohn lemma, one can find ")#mi("f\\in C_c(\\mathbf{R}^d)")#text(" such that it equals ")#mi("1")#text(" in the compact set ")#mi("K")#text(" and ")#mi("0")#text(" in the complement of a compact set ")#mi("W")#text(" where ")#mi("K\\subsetneq W\\subsetneq U")#text(". To get the desired ")#mi("C^\\infty")#text(" function, take ")#mi("g:=f*\\psi_\\varepsilon")#text(" where ")#mi("\\varepsilon>0")#text(" is chosen so that the (compact) support ")#mi("V")#text(" of ")#mi("g")#text(" is contained in ")#mi("U")#text(".")

#text("How can one construct ")#mi("\\psi")#text(" so that taking convolution should not “contaminate” the value ")#mi("1")#text(" of the function ")#mi("f")#text(" on ")#mi("K")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671249")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("Choose ")#mi("f")#text(" to equal ")#mi("1")#text(" on a slightly larger region than ")#mi("K")#text(". I’m not aware of a completely soft argument to construct the smooth cutoff function without using an explicit device such as convolution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")])]

#text("Is some sort of “existence argument” rather than explicit construction proof possible for Exercise 1(iii)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2022")])]

#emph[#linebreak()#text(" … or equivalently, the ball ")#tao-math("{\\{ f \\in C^\\infty_c(K): \\left\\|f\\right\\| < 1 \\}}", block: false)#text(" is open in ")#mi("{C^\\infty_c(K)}")#text(" for each compact ")#mi("{K}")#linebreak()#text(" ")]

#text("Could you elaborate on how this is equivalent to continuity of the seminorm ")#mi("\\|\\|")#text("? By homogeneity, the condition above implies that the ball ")#tao-math("{\\{ f \\in C^\\infty_c(K): \\left\\|f\\right\\| < c \\}}", block: false)#text(" is open in ")#mi("{C^\\infty_c(K)}")#text(" for every positive constant ")#mi("c")#text(". How does one show that ")#tao-math("{\\{ f \\in C^\\infty_c(K): \\left\\|f\\right\\| > c \\}}", block: false)#text(" is also open?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671254")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("By the triangle inequality, ")#tao-math("\\{ f \\in C^\\infty_c(K): \\left\\|f\\right\\| > c \\}", block: false)#text(" is the union of open balls in the ")#mi("\\| \\|")#text(" seminorm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-2/#comment-671177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2022")])]

#text("In Exercise 2, one direction follows directly from the definition of “good” seminorms:")

#text("Suppose for some compact ")#mi("K")#text(", which contains the supports of ")#mi("f_n")#text(" and ")#mi("f")#text(", one has ")#mi("f_n")#text(" converges to ")#mi("f")#text(" in the smooth topology of ")#mi("C_c^\\infty(K)")#text(". If ")#mi("\\|\\cdot\\|")#text(" is a good seminorm on ")#mi("C_c^\\infty(\\mathbf{R}^d)")#text(", then by continuity, one has ")#tao-math("\\left\\|f_n-f\\right\\|\\to 0", block: false)#text(".")

#text("How does one show the other direction? If ")#mi("f_n")#text(" converges to ")#mi("f")#text(" in the topology of ")#mi("C_c^\\infty(\\mathbf{R}^d)")#text(", equivalently, in every good seminorm ")#mi("\\|\\cdot\\|_\\alpha")#text(", how can one identify the compact ")#mi("K")#text(" that contains all the supports of ")#mi("f_n")#text(" and ")#mi("f")#text("?")

#emph[#text("[Argue by contradiction – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("WONDERFUL POST.")

#text("THANK YOU PROF. TAO")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11cac8bde0677bc43849cc66b6c6c521d3d5a7cf91c7fdeac73e56aae0504d7d-8314babeb03af470dda611f556254e78f7322714dcc217a2d0f56def9d134eaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Successful Researcher")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38253")[#strong[#text("Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Superb! Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bird")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38265")[#strong[#text("bird")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Dear Prof. Tao,")

#text("in some places, you write ” absolutely integrable and compactly supported”…")

#text("but if a function is compactly supported, then isn’t it absolutely integrable? is there a specific reason that you are writing in that way?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("When we say ” a function f is supported in a set V”, do we mean that the set where f is nonzero is a subset of V or the closure of the set where f is nonzero is a subset of V?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bird")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38270")[#strong[#text("bird")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("in exercise 16, on the right hand side is it ")#mi("\\overline{f(0)}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Dear Prof. Tao,")

#text("in execise 17,")

#text("is that right ")#mi("\\lim_{\\epsilon \\rightarrow 0}\\int_{x \\geq \\epsilon}f(x)dx=")#text(" integral value of f?")

#text("if it is right, why the answer is 1, I did not understand?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4607687ed684e502e90fc5417cc8a5e317587d2f0dadc729200a53aaa0e5e718-4bb893a1a1f807ccdb843b70c3ad3a502a7c35bdded1110b07ad5a6c852f2e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dale Roberts")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38274")[#strong[#text("Dale Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Typo: The display eq. between (7) & (8), shouldn’t RHS be K (without hat)?")

#text("Like all your (analysis course) posts, your exposition really clarifies some subtle points that were glossed over in a course that I took as an undergrad and provide a lot of great intuition.")

#text("IMHO, your blog posts really help fill the lack of good graduate-level analysis courses in Australia. It is true that we can sit down and plough through the books but your style really brings it to life. Thanks, I personally really appreciate it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38296")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Not all compactly supported functions are absolutely integrable, e.g. the restriction of 1/x to the interval [0,1].")

#text("Either definition of support would work here, but one can for sake of concreteness take the closure of the set where the function is non-zero.")

#text("For exercise 16, I forgot to mention that to make the various notions of multiplication consistent, distributions should be given the anti-complex structure rather than the complex structure; thus if ")#mi("\\lambda")#text(" is a distribution and ")#mi("c")#text(" is a complex number, then ")#mi("c\\lambda")#text(" is the distribution given by ")#mi("\\langle f, c\\lambda \\rangle := \\overline{c} \\langle f, \\lambda \\rangle")#text(" rather than ")#mi("c \\langle f, \\lambda \\rangle")#text(". This conjugation is always something of an irritant (the same technicality shows up when considering duals of complex Hilbert spaces), though if one wishes one can avoid this issue by restricting attention to real-valued functions (but then it becomes harder to implement Fourier analysis).")

#text("For exercise 17, 1 is indeed the distribution that maps any test function f to its integral value: ")#mi("\\langle f, 1 \\rangle = \\int_{{\\Bbb R}} f")#text(".")

#text("Dale: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38302")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear Prof. Tao,")

#text("for Exc 11,12,13 showing that they define a distribution is not too hard but the second part, i.e showing that they does not arise from either a locally integrable function or a Radon measure is not easy.")

#text("Could you please give some hint for anyone of them?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("Dear Lutfu,")

#text("In all of these exercises you should try arguing by contradiction, assuming that, say, ")#mi("p.v. 1/x")#text(" arises from a Radon measure ")#mi("\\mu")#text(" and then trying to deduce as much about ")#mi("\\mu")#text(" as possible. For instance, in that specific example one can look at lower bounds for the total variation of ")#mi("\\mu")#text(" on the interval ")#mi("[\\varepsilon,1]")#text(" for small ")#mi("\\varepsilon")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 4: Sobolev spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38480")[#strong[#text("245C, Notes 4: Sobolev spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("[…] dual space of , the distributional limit of any sequence bounded in remains in , by Exercise 28 of Notes 3.) To prove (1), observe from the fundamental theorem of calculus […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38507")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("I’m sorry if it’s a dumb question, but I don’t understand how you can take a Fourier Transform of the right hand side of the equation that is 2lines after (8). It’s not in L^1 as it blows up at the origin.")

#text("If you could specify the change of variables you are using, that would be appreciated too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38510")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("Ah, several of the powers of ")#mi("t^{-\\alpha}")#text(" in the text should have been ")#mi("t^{\\alpha}")#text(" instead. This should be fixed now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of At the Fefferman conference « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38592")[#strong[#text("At the Fefferman conference « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("[…] some explicit constant (this can be seen by computations similar to those in my recent lecture notes on distributions, or by analytically continuing such computations; see also Stein’s “Singular integrals […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38702")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("There is a disparity in Exercise 19’s hint. Your hint’s text references Exercise 3, but links to Lemma 3. ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1013eb9df3fb1866c715a1ceb8fa1e9ab166610a95f470d9ef576d3b9bf05b39-94fe98c03916903d8e96bf2e3d0505a842bd5be8c8a301baff405f8bea459f3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yasser Taima")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38747")[#strong[#text("Yasser Taima")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")])]

#text("Dear Professor Tao,")

#text("In lemma 2, isn’t it that the Riemann sum can be interchanged with the inner product because of the linearity of the inner product, rather than the compactness of the support of f?")

#text("It was mentioned in lecture that ")#mi("h_{x+t}(y) - h_{x}(y) / t")#text(" converges to ")#mi("\\overline{h^{\\prime}(x-y)}")#text(" as ")#mi("t \\rightarrow 0")#text(" pointwise. We then said that the convergence is uniform. Why is that?")

#text("This appears to be useful to obtain the Lipschitz condition needed for the convergence of the Riemann sum. Is that right?")

#text("Thanks and apologies as I’m new to latex.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")])]

#text("Dear Yasser,")

#text("The compactness of f is needed to make the Riemann sum finite, at which point the sum and inner product can be interchanged by linearity.")

#text("The uniform convergence of the Newton quotients to the derivative (i.e. the uniform differentiability of ")#mi("h_x")#text(" in x) is a consequence of the smoothness of h. For instance, one can use Taylor’s theorem with remainder to get a uniform bound on the error between ")#mi("(h_{x+t}(y)-h_x(y))/t")#text(" and ")#mi("\\overline{h^{\\prime}(x-y)}")#text(" in terms of the ")#mi("C^2")#text(" norm of h. (Actually, this is overkill; having h be ")#mi("C^1")#text(" would already be sufficient thanks to the fundamental theorem of calculus or mean value theorem and the uniform continuity of h’, although one wouldn’t get as quantitative a decay rate as ")#mi("t \\to 0")#text(" with that approach.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38879")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")])]

#text("I believe there’s a typo in Exercise 16’s hint.")#linebreak()#text(" I believe it should read ")#mi("f(x)=f(0)+x \\int_0^1 f^\\prime (tx) dt")#text(". ")#emph[#text("[Corrected, thanks, -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38883")[#strong[#text("Solutions to Selected Exercises from 245C, Notes 3: Distributions « Less Incompetence")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")]

#text("[…] Of course, the actual exercises can be found at Professor Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/349a7f1ba8257e3f428c826fd5a93f3db598f9a872c3bc33d116761bbfe74096-879e6a89b34bad238aabcab5f210b5dd57b5c144820018f3e2e11428f80c2cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cloclo")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38910")[#strong[#text("Cloclo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Thank you very much for this very very interesting post, as usual !!")

#text("I would like to ask you the following question since I couldn’t find an answer in the references I looked at:")

#text("Given two functions, f in ")#mi("L^1(\\mathbb{R})")#text(", g in ")#mi("L^p(\\mathbb{R})")#text(" (")#mi("1<p<\\infty")#text("), let h be their convolution in the \"classical\" sense (without the help of the theory of distribution) ")#mi("h=f\\star g")#text(". Thus h is a function in ")#mi("L^p(\\mathbb{R})")#text(" and its Fourier transform is a tempered distribution.")#linebreak()#text(" Can we relate it to the Fourier transform of f and g ?")

#text("Or in other words is it possible under maybe given assumptions to have the formula ")#mi("\\mathcal{F}(f) \\mathcal{F}(g)=\\mathcal{F}(h)")#text(" ?")

#text("Thank you by advance !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Cloclo,")

#text("Yes, this is true for ")#mi("1 \\leq p \\leq 2")#text(". The easiest way to prove this is to express f and g as the limit (in ")#mi("L^1")#text(" and ")#mi("L^p")#text(" respectively) of test functions, which by Young’s inequality gives h as the limit (in ")#mi("L^p")#text(") of the convolution of those test functions. In particular, all the convergences here are also in the sense of tempered distributions, and so their Fourier transforms will also converge in this sense. Meanwhile, one gets a similar convergence to ")#mi("{\\mathcal F}(f) {\\mathcal F}(g)")#text(" by their test function counterparts using Hausdorff-Young and Holder’s inequality. Since the Fourier transform is already known to intertwine convolution and multiplication for test functions, one can now take distributional limits to conclude the claim (note that the space of distributions is Hausdorff and so limits are unique).")

#text("For ")#mi("p>2")#text(" the situation is more subtle, because the expression ")#mi("{\\mathcal F}(f) {\\mathcal F}(g)")#text(" does not necessarily make sense (")#mi("{\\mathcal F}(g)")#text(" need not be a locally integrable function, instead being merely a distribution in general; meanwhile, ")#mi("{\\mathcal F}(f)")#text(" is continuous but need not be smooth). One could ")#emph[#text("define")]#text(" this product by fiat to be ")#mi("{\\mathcal F}(h)")#text(", but this is a tautological way to solve the problem and does not have any actual content.")

#text("This general strategy (establishing identities for rough functions by taking limits of the corresponding identity for classical functions) is generally quite a good way to establish identities for rough functions, especially if they are somehow “linear” or otherwise likely to obey good continuity properties.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/349a7f1ba8257e3f428c826fd5a93f3db598f9a872c3bc33d116761bbfe74096-879e6a89b34bad238aabcab5f210b5dd57b5c144820018f3e2e11428f80c2cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cloclo")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38918")[#strong[#text("Cloclo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Thank you so much for your answer.")#linebreak()#text(" And I am really sorry for bothering you once again. But I am not sure I understand how you prove that (if ")#mi("f_n\\rightarrow f")#text(" and ")#mi("g_n\\rightarrow g")#text("), then ")#mi("\\mathcal{F}(f_n)\\mathcal{F}(g_n)\\rightarrow \\mathcal{F}(f)\\mathcal{F}(g)")#text(", indeed ")#mi("\\mathcal{F}(f)")#text(" may be just a continuous but not a smooth function.")

#text("Thank you so much once again and sorry !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38921")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("If ")#mi("f_n")#text(" converges to f in ")#mi("L^1")#text(", then ")#mi("{\\mathcal F}(f_n)")#text(" will converge to ")#mi("{\\mathcal F}(f)")#text(" in ")#mi("L^\\infty")#text(" by Hausdorff-Young; similarly, ")#mi("{\\mathcal F}(g_n)")#text(" will converge to g in ")#mi("L^{p^{\\prime}}")#text(" (here we need p to be at most 2). From Holder’s inequality we conclude that ")#mi("{\\mathcal F}(f_n) {\\mathcal F}(g_n)")#text(" converges to ")#mi("{\\mathcal F}(f) {\\mathcal F}(g)")#text(" in ")#mi("L^{p^{\\prime}}")#text(" and thus in the sense of tempered distributions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/349a7f1ba8257e3f428c826fd5a93f3db598f9a872c3bc33d116761bbfe74096-879e6a89b34bad238aabcab5f210b5dd57b5c144820018f3e2e11428f80c2cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cloclo")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-38922")[#strong[#text("Cloclo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Thank you very much. I have now to study carefully your answer (I didn’t get it in time). So don’t take into account my last questions and sorry for that.")#linebreak()#text(" with best regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-39336")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2009")])]

#text("Dear Prof Tao,")

#text("in dimension 1, for the wave equation, if the given initial data are distributions, how do we define the solution for the equation? how do we interpret the equation?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-39355")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2009")])]

#text("Dear student,")

#text("There are a number of different ways to define “weak” solutions to these sorts of equations, which are mostly equivalent for linear equations such as the free wave equation, but which are subtly different for nonlinear equations. For instance, one can integrate the equation against a test function in spacetime in the half-space ")#mi("\\{ (t,x): t \\geq 0 \\}")#text(", and interpret the resulting integral equation in a distributional sense. Or, one can take Fourier transforms in space, solve the equation in time using the fundamental solution, and then interpret everything distributionally. A closely related approach is to use the Duhamel formula to define the notion of a solution. Yet another approach is to interpret a rough solution as a limit of smooth solutions to the same equation (or a regularised or “viscosity” version of that equation) in suitable topologies (e.g. the distributional topology). Then there are other approaches based on comparison with subsolutions or supersolutions, or based on variational characterisations of the equation, or on entropy or kinetic formulations of the equation; as one can imagine, the topic of how to properly define a rough solution is quite a subtle one in general, particularly for nonlinear equations.")

#text("For wave equations, there is some discussion of this in Sogge’s book “nonlinear wave equations”; I also discuss this a little in my own PDE book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-39356")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2009")])]

#text("Thank you very much Prof Tao, you are really very kind person. you are always trying to help everyone as much as you can….")

#text("thanks again….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-40800")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("Why isn’t the following a counterexample to exercise 2 section 1?")

#text("Assume that d=1 and the limit function f is identically 0.")#linebreak()#text(" Take a positive bump function b(x) with support [-1,1] . And let f_n(x) be b(x/n)/n.")

#text("The support of f_n is [-n,n] (so that the union of supports is all R).")#linebreak()#text(" And on each compact K, (f_n)^(j) tends uniformly to 0 for each j.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-40806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("Dear George,")

#text("This sequence does not converge to zero in the ")#mi("C^\\infty_c({\\Bbb R})")#text(" topology. Indeed, consider the set of all f in ")#mi("C^\\infty_c({\\Bbb R})")#text(" such that ")#tao-math("\\left|f(x)\\right| < \\frac{1}{\\left|x\\right|^{1/2}}", block: false)#text(" (say) for all x. It is not hard to see that the restriction of this set to ")#mi("C^\\infty_c(K)")#text(" is open in ")#mi("C^\\infty_c(K)")#text(" for every compact K, so this set is an open neighbourhood of the origin in the final topology of ")#mi("C^\\infty_c({\\Bbb R})")#text("; however, it does not absorb the sequence ")#mi("f_n")#text(".")

#text("One can modify this argument to show that in order to get convergence in this topology, the supports of the ")#mi("f_n")#text(" must be uniformly bounded (indeed, this is the bulk of the work in establishing Exercise 2).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-40811")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you for your explanation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mean field games « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-43137")[#strong[#text("Mean field games « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("[…] will evolve as time goes forward. There are several ways to find the answer, but we will take a distributional viewpoint and test the density against various test functions – smooth, compactly supported […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-43272")[#strong[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] the sense of (tempered) distributions (see e.g. my earlier notes on this topic). In other words, is a (tempered distributional) solution to the heat equation (3). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-43467")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] of approximations to the identity, and thus converges in the vague topology to (see e.g. my notes on distributions). Thus we see […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-43787")[#strong[#text("2010 Mar 消磨时间 « 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")]

#text("[…] then use the fundamental theorem of calculus to strengthen the topology. Another is to use Exercise 5 and then discretise the convolution. Another is to embed into a torus and use Fourier series, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-47162")[#strong[#text("245A, Notes 2: The Lebesgue integral « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("[…] functions are all dense subsets of with respect to the (semi-)metric. Much later in the course (in 245C), we will see that a similar statement holds if one replaces continuous, compactly supported […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-47643")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] and its derivative is continuous, then we say that is continuously differentiable. Remark 1 Much later in this sequence, when we cover the theory of distributions, we will see the notion of a weak derivative or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 4: Modes of convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-48071")[#strong[#text("245A, Notes 4: Modes of convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2010")])]

#text("[…] (not to be confused with convergence in the sense of distributions, which we will study later in this sequence) is commonly used in probability; but, as the above exercise demonstrates, it is quite a weak […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-48943")[#strong[#text("245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("[…] functions are all dense subsets of with respect to the (semi-)metric. Much later in the course (in 245C), we will see that a similar statement holds if one replaces continuous, compactly supported […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-52135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2011")])]

#text("In Exercise 23, I used integral by part and finally get")

#tao-math("\\lim_{\\epsilon\\to 0^+}(\\log\\left|x\\right|)^{\\prime}\\phi(x)dx = \\lim_{\\epsilon\\to 0^+}\\log x[\\phi(-x)-\\phi(-x)]|_{\\epsilon}^{\\infty}+p.v.(\\frac{1}{x})(\\phi)", block: false)

#text("How can I get rid of the first term on the right hand side? Since ")#mi("\\phi\\in S({\\mathbb R})")#text(", one may get ")#mi("\\lim_{x\\to+\\infty}\\log x[\\phi(-x)-\\phi(-x)]=0")#text(". But how to deal with the ")#mi("\\epsilon")#text(" part?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-52139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2011")])]

#text("Try the mean value theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5bcc51739f7286bc0fcc2d87a91dd972e088bc90a4e0aa786248e2cf0b996a3-639f35fd544b71ff1ccc4df52bc7966a2d138cf87fca9d014cd18c55de99491e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedfue")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-83693")[#strong[#text("fedfue")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2011")])]

#text("A technical question: Don’t you need that the topology on $C_c^\\infty(\\R^d)$ be defined as a locally convex topology (and not simply as the final topology)? My question is because Rudin and other books have this requirement, but I’m not really sure. If not, why do these books make this more complex construction, when a much simpler and natural one can be defined (as done here)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-116200")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] See for instance this blog post for a very brief introduction to Riemannian geometry, and these two previous posts for an introduction to distributions and Sobolev […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-130837")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2012")])]

#text("For Exercise 5, it seems to me that, because of the fact that ")#mi("\\mathbb{R}")#text(" is not compact, we need something a little stronger in the definition of “approximations to the identity” than just uniformly converging to zero away from the origin for the convolution ")#mi("f \\ast \\phi_n")#text(" o converge pointwise to ")#mi("f")#text(". Perhaps we need to require that the support of ")#mi("\\phi_n")#text(" is also shrinking to the origin as well.")

#text("Here is the situation I am worried about: suppose that ")#mi("phi_n")#text(" is a sequence of kernels which actually has increasing support as ")#mi("n")#text(" goes to infinity. We can arrange ")#mi("phi_n")#text(" to have a big “spike” of width ")#mi("1/n")#text(" centered at the origin, but also a long “tail” of height ")#mi("\\epsilon^n")#text(" along the interval of length ")#mi("2n")#text(" centered at the origin. Thus ")#mi("\\phi_n")#text(" is supported on an interval of length ")#mi("2n")#text(". For most of this interval, ")#mi("\\phi_n(x) = \\epsilon^n")#text(" (which is close to zero), with the exception of the spike in the center. Set up correctly, we should be able to make ")#mi("\\phi_n")#text(" into a sequence of approximations of the identity satisfying the definition you’ve given.")

#text("However, suppose we now choose a continuous ")#mi("f")#text(" such that ")#mi("f(0) = 0")#text(" and ")#mi("f(x)")#text(" increases very rapidly as ")#mi("x")#text(" moves away from the origin. So rapidly, in fact, that if we convolve ")#mi("f")#text(" with ")#mi("\\phi_n")#text(", then the “tail” portion of the function ")#mi("\\phi_n")#text(" collects a very large contribution to the integral ")#mi("f \\ast \\phi_n (0)")#text(" because ")#mi("f(x)")#text(" is very large when ")#mi("x")#text(" is around ")#mi("n, -n")#text(". Then it seems that ")#mi("f \\ast \\phi_n(0)")#text(" will not even converge to ")#mi("0")#text(".")

#text("This can’t happen if ")#mi("f")#text(" has compact support, but in Exercise 5, ")#mi("f")#text(" is only assumed to be continuous.")

#emph[#text("[Thanks, I’ve altered the definition of approximation to the identity suitably. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-153117")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("Professor, what is a good way to define the convolution of multiple distributions? Do we need at least one of them having compact support? I have been thinking about this for a while but feel uncertain what is the best way to define it. The textbook (Friedlander) used the notion of proper maps, but unfortunately his ‘proof’ has a technical flow that made the support of convolutions of distributions closed but could be non-compact. So I am looking an alternative.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-153125")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("Sorry I made a mistake, Friedlander is right.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6d99984cca02f21f3f74e6fb7af0d12565179e72ad32c2a2d0f2b0bf4132db8-861615370ca621eb4683e5d8f61c199f7e9809a99a3372efa45e17dacc02ae5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sriyan Wickramasuriya")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-218920")[#strong[#text("Sriyan Wickramasuriya")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2013")])]

#text("Dear Professor Tao,")#linebreak()#text(" Your notes are just brilliant! When we restrict the metric defined on Schwartz Space(pg 204 of Mike Taylor’s PDE book) to C_c^{infinity}(R^n) we do not get a complete metric topology and therefore we put the inductive limit topology on C_c^{infinity}(R^n). But this inductive limit topology is not metrizable and the proof of this fact involves Baire’s Category theorem.")#linebreak()#text(" Is there any way we prove that the inductive limit topology on C_c^{infinity}(R^n) is not metrizable without using the Baire’s Category Theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-218922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2013")])]

#text("See exercise 3 (metrizable topologies are necessarily first countable).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6d99984cca02f21f3f74e6fb7af0d12565179e72ad32c2a2d0f2b0bf4132db8-861615370ca621eb4683e5d8f61c199f7e9809a99a3372efa45e17dacc02ae5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sriyan Wickramasuriya")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-218955")[#strong[#text("Sriyan Wickramasuriya")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2013")])]

#text("Dear Professor Tao,")#linebreak()#text(" Thank you very very much!")

#text("Best Wishes,")

#text("Sriyan")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/588bdbeddb71b86eee001d4695e578ac869876567c0235604db9bd7daddd54c5-ae3d53ee3b45ccb2e89a08cd0a4fc9e4861ce29f2ac225554e7d1d9efe75e2c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sara")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-230511")[#strong[#text("Sara")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")])]

#text("Respected Terence Tao,")#linebreak()#text(" How will prove that sin(nx)—>0 as n goes to infinity in D'(R),")#linebreak()#text(" but sin^2(nx) –/->0 as n goes to infinity.")#linebreak()#text(" That is, multiplication of distn. is not a continuous operation even it is defined.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6521593223e6c0ecd7879f232f5f613b43e3a80a39b3a4e83b42beec1346f7c-733c876b04f4a69bbbc1e30cfce9d6166ea472bfe8312285be71b2ef68973c6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debdeep")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-237471")[#strong[#text("Debdeep")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("Dear Prof. Tao")#linebreak()#text(" I want to construct a function f which is in Holder \\alpha space for some \\alpha > 0 and compactly supported such that the tail of the L_2 integral of the Fourier transform is lower bounded by |x|^{-\\beta} for some \\beta i.e.")#linebreak()#text(" int_{|t| > x} |\\hat{f}(t)|^2 dt > = |x|^{-\\beta}")#linebreak()#text(" What is the smallest \\beta (related to \\alpha) (tightest lower bound) we can achieve?")#linebreak()#text(" Can \\beta = \\alpha achievable? Thanks for your reply")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc50c332f578f8220f75074fffde1d2c5fb483a09697fadd803ef240596500c-98351340ba808b58cdcf10e0176cff4121bb6831c0459c095dd64e903885a836.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Federico")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275420")[#strong[#text("Federico")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Dear Professor Tao,")

#text("These notes are great! However, I’m having a hard time to believe (and prove) the last part of exercise 3. You seem to suggest that the space of test functions is sequential with that topology (despite not being first countable). However I do not think this is true. A question I asked ")#link("http://math.stackexchange.com/questions/706061/topologies-of-test-functions-and-distributions")[#text("here")]#text(" and an article by ")#link("http://www.ams.org/journals/proc/1971-027-03/S0002-9939-1971-0270145-X/S0002-9939-1971-0270145-X.pdf")[#text("Dudley")]#text(" seem to suggest otherwise. Indeed, sequential continuity is enough for proving continuity only in the case of linear maps, but to me this does not imply the space itself is sequential. Naturally, I could be wrong, but could you please clarify this subtle point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275445")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2014")])]

#text("Yes, you’re right; this issue had been pointed out to me before but I had neglected to update the exercise. But now I’ve altered it to just assert that continuity is equivalent to sequential continuity (which is actually relatively easy to prove, and is what is actually needed in applications).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc50c332f578f8220f75074fffde1d2c5fb483a09697fadd803ef240596500c-98351340ba808b58cdcf10e0176cff4121bb6831c0459c095dd64e903885a836.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Federico")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275598")[#strong[#text("Federico")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("Thanks for the update Professor Tao! It is a relief. Just to finish clearing things up in my head: Isn’t sequential continuity (for the space of test functions) equivalent to continuity only in the case of ")#emph[#text("linear")]#text(" maps to another locally convex topological vector space? Or is it true for arbitrary maps as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275608")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("Linearity is not required (in fact the range can be an arbitrary topological space). If ")#mi("X = \\bigcup_\\alpha X_\\alpha")#text(" is given the final topology from topological spaces ")#mi("X_\\alpha")#text(", then a map ")#mi("f: X \\to Y")#text(" to any topological space ")#mi("Y")#text(" is continuous if and only if its restrictions to each ")#mi("X_\\alpha")#text(" are continuous. From this it is not difficult to see the equivalence of continuity and sequential continuity for maps from ")#mi("C^\\infty({\\bf R}^n)")#text(" to any topological space.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc50c332f578f8220f75074fffde1d2c5fb483a09697fadd803ef240596500c-98351340ba808b58cdcf10e0176cff4121bb6831c0459c095dd64e903885a836.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Federico")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275611")[#strong[#text("Federico")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("Thank you for your reply! Yes, I agree with you regarding the final topology. Indeed this was my first approach to the exercise. But isn’t the test function space an inductive limit in the category of locally convex topological vector spaces (which is different from the typical inductive limit, which in turn is equivalent to the final topology induced by these identity maps)? I mean, isn’t the test function topology the finest (largest) ")#emph[#text("locally convex")]#text(" topology on ")#mi("X")#text(" which makes the identity maps ")#mi("X_\\alpha \\rightarrow X")#text(" continuous as opposed to simply the final topology induced by the identity maps ")#mi("X_\\alpha \\rightarrow X")#text("? I think this subtle difference in the inductive limit topology (of LF spaces in general, I believe) might make a difference in regard to the sequential properties of the test function space. This is the true source of my doubt.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("You’re right, I had not realised this subtlety between the two different notions of a final topology. I’ve modified the text (using the locally convex final topology rather than just the plain final topology), and hopefully all these issues are fixed now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc50c332f578f8220f75074fffde1d2c5fb483a09697fadd803ef240596500c-98351340ba808b58cdcf10e0176cff4121bb6831c0459c095dd64e903885a836.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Federico")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-275663")[#strong[#text("Federico")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("Professor Tao, I really appreciate your answers very much! Thank you for your attention to this issue and for making this clearer for everyone.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-282703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2014")])]

#text("Dear Prof. Tao,")

#text("I am struggling to solve all the exercises from section 1. I am pretty sure I solved from 1 through 5 but I am lost in Exercise 6. There I am trying to use Exercise 5 but I don’t understand what you mean by discretise the convolution and how we can discretise the convolution?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-283296")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("If one approximates an integral by a Riemann sum, one can approximate ")#mi("f * \\phi_n")#text(" by a finite linear combination of translates of ")#mi("\\phi_n")#text(", which is one way to approach separability. (There are many others.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-283930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("Thanks Prof. Tao!")

#text("Yes, i know f*\\phi_n is infinitely differential but we we discretise with Riemann Sum then the Riemann Sum not gonna be in C_c^\\infty. How do we make this precise?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-283945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("If one replaces the convolution ")#mi("x \\mapsto \\int f(y) \\phi(x-y)\\ dy")#text(" with a Riemann sum approximant ")#mi("x \\mapsto \\sum_i f(y_i) \\phi(x-y_i) \\Delta y_i")#text(", one will obtain a function in ")#mi("C^\\infty_c")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-286134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2014")])]

#text("Thank you very much, Professor Tao for your guidance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-309144")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("Dear Dr. Tao, I am not sure what you mean by ‘dualise’ the Fundamental Theorem of Calculus in Exercise 25 (iii). So, would you mind giving me more details?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-309789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2014")])]

#text("As a model case, try k=0 and assume the “cheat” that the antiderivative of a test function supported on an interval is again a test function supported on that interval. (In this case, the additional distribution ")#mi("\\nu")#text(" would not be required.) The fundamental theorem of calculus, which guarantees the existence of an antiderivative for any test function, is what will be needed to construct ")#mi("\\rho")#text(" in this case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-311069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("So, do you mean to define ")#mi("\\rho^{\\prime}(\\phi)=-\\lambda(\\mu)")#text(" where ")#mi("\\mu(t)=\\int_0^t\\phi(s)ds")#text("?")

#text("Then order of ")#mi("\\rho")#text(" not gonna be ")#mi("k")#text(", right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-320514")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("Professor T. Tao,")

#text("I am teaching your notes for the first time and I am also getting better understanding with my students. But I have almost don’t have knowledge of PDE and we are struggling to solve Exercise 40. So , it would be great help if you direct us in this Exercise.")

#text("Thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-322614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("Dear Dr. Tao,")

#text("In Exercise 40, is it $t/4\\pi$ or 1/4\\pi t$ ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-322647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("It is ")#mi("\\frac{t}{4\\pi}")#text(", due to the rescaling of the integral to the unit sphere, rather than the sphere of radius t.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/comment-page-1/#comment-323639")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("Thanks Dr. Tao for your response.")

#text("I have again couple of confusions and it would be great if you clarify these too.")

#text("For Exercise 38 an 39, in most of the text book of PDE I found just {e^{-|x|^2/4t}} and {e^{i|x|^2/4t}} respectively instead of {e^{-|x-y|^2/4t}} and {e^{i|x-|^2/4t}}. Is there any special reason subtracting {y} from {x}?")

#text("In Exercise 40, you said just wave equation {-\\partial_{tt} u + \\Delta u}. Do you mean {-\\partial_{tt} u + \\Delta u =0}?")

#text("Thanks in advance!")

#emph[#text("[Corrected, thanks – T.]")]
]
