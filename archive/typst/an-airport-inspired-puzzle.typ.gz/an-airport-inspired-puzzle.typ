// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/
// Converted to Typst by tao2typ: "2026-10-14T07:07:55.118704+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An airport-inspired puzzle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An airport-inspired puzzle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/")[#text("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I was recently at an international airport, trying to get from one end of a very long terminal to another. It inspired in me the following simple maths puzzle, which I thought I would share here:")

#text("Suppose you are trying to get from one end A of a terminal to the other end B. (For simplicity, assume the terminal is a one-dimensional line segment.) Some portions of the terminal have moving walkways (in both directions); other portions do not. Your walking speed is a constant ")#mi("v")#text(", but while on a walkway, it is boosted by the speed ")#mi("u")#text(" of the walkway for a net speed of ")#mi("v+u")#text(". (Obviously, given a choice, one would only take those walkways that are going in the direction one wishes to travel in.) Your objective is to get from A to B in the shortest time possible.")

#enum(start: 1, 
[#text("Suppose you need to pause for some period of time, say to tie your shoe. Is it more efficient to do so while on a walkway, or off the walkway? Assume the period of time required is the same in both cases.")],
[#text("Suppose you have a limited amount of energy available to run and increase your speed to a higher quantity ")#mi("v^{\\prime}")#text(" (or ")#mi("v^{\\prime}+u")#text(", if you are on a walkway). Is it more efficient to run while on a walkway, or off the walkway? Assume that the energy expenditure is the same in both cases.")],
[#text("Do the answers to the above questions change if one takes into account the ")#link("http://en.wikipedia.org/wiki/Time_dilation")[#text("various")]#text(" ")#link("http://en.wikipedia.org/wiki/Velocity-addition_formula")[#text("effects of special relativity")]#text("? (This is of course an academic question rather than a practical one. But presumably it should be the time in the airport frame that one wants to minimise, not time in one’s personal frame.)")]
)

#text("It is not too difficult to answer these questions on both a rigorous mathematical level and a physically intuitive level, but ideally one should be able to come up with a satisfying mathematical explanation that also corresponds well with one’s intuition.")

#text("[")#emph[#text("Update")]#text(", Dec 11: Hints deleted, as they were based on an incorrect calculation of mine.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (145)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eaf4dce02528842e0746ecd77559cb4d2cfe81f6343c8010ff3a1732a0b3f50a-02aba4521e02af75c384bd51238bd8af360222e8d574c2c687ca5d4518088ae0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lhm")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-95907")[#strong[#text("lhm")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("The optimal strategy of pausing on moving walkways and running between walkways can be seen as a consequence of unit-elasticity. The slope of a tangent to the “isodisplacement” curves gives the time change for a unit change in velocity. this is greater at lower speeds than higher ones due to the convex shape.")

#text("In the relativistic case one can draw a similar picture by replacing the velocity v with the rapidity r = atanh v/c. The isodisplacement curves are also convex but are relative to half the rapidity r. To see this let v’->v in the equation from TT’s comment so that dT/dv = -T/v√(1-v²/c²) and solve for r to find T tanh r/2 = const.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/483bd0c1be748eb7a3354edbf0d79613a00a69168d4c92bde659316349d06d80-09f95824398c544b76813701d67687b819cfda103673cda6b23960f1cbcb2fb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lori")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-144329")[#strong[#text("Lori")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2012")])]

#text("Nice puzzle. I realise this is a late response but I didn’t see an intuitive explanation to all three parts without significant algebra manipulations. One possibility is to use a displacement-time (Minkowski) diagram to compare the time taken to cover a given distance at different speeds as shown below (which I hope comes out OK!). Define:")

#text("T1(u;v)=net additional time when speed is decreased to u by an amount v")#linebreak()#text(" T2(u;v)=net time reduction when speed is increased from u by an amount v")

#text("The first diagram shows the Newtonian case in which times in all frames of reference are equal. The three lines T,T’ and T” represent stationary, slower and faster frames of reference respectively. It’s clear that for fixed v, T1(u;v) is increasing in u and T2(u;v) is decreasing in u which implies the answers to parts 1 & 2 respectively.")

#text("In the second diagram, time and displacement are now relative to frame of reference and so the X axis label has been omitted. The line segments u and v are orthogonal to the lines T’ or T” for the corresponding times T1′ or T2” respectively (these two cases are actually distinct but have been combined for economy). The T-intercept represents the time dilation for a unit of time in the moving frame T’ or T”. Changing u and holding v fixed in the reference frame T’ or T” implies the slope of the line segments u and v change orthogonal to the lines T’ or T” but the same relationships apply as in the Newtonian case hence the answer to part 3.")

#raw("Newton                             SR\n\nT                                  T\n                  T'                                T'\n|               /                  |               /\n|              +             T''   |_             X             T''\n|             /|           _/      | \\_          /|           _/\n|            / |         _/        |   \\_ u     / |         _/\n|           /  |       _/          |     \\_    /  |       _/\n|          /   |T2   _/            |       \\_ /   |T2'' _/\n|         /    |   _/              |  X_ v |   _/\n|   u    /  V  | _/                |        /| \\_ | _/         \n|+------+/                  |       / |   \\X/           \n|      /|    _/                    |      /  |  _/             \n|     / |  _/                      |     /T1'|_/               \n|    /T1|_/                        |    /   _X                 \n|   /  _+                          |   /  _/                   \n|  / _/                            |  / _/                    \n| /_/                              | /_/                      \n|//___________________ X           |//____________________ ", block: true)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/483bd0c1be748eb7a3354edbf0d79613a00a69168d4c92bde659316349d06d80-09f95824398c544b76813701d67687b819cfda103673cda6b23960f1cbcb2fb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lori")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-144330")[#strong[#text("Lori")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2012")])]

#text("Above diagram again (some of the symbols were interpreted as html tags):")

#raw("Newton                             SR\n\nT                                  T\n                  T'                                T'\n|               /                  |               /\n|              +             T''   |_             X             T''\n|             /|           _/      | \\_          /|           _/\n|            / |         _/        |   \\_ u     / |         _/\n|           /  |       _/          |     \\_    /  |       _/\n|          /   |T2   _/            |       \\_ /   |T2'' _/\n|         /    |   _/              |         X_ v |   _/\n|   u    /  V  | _/                |        /| \\_ | _/         \n|-------+------+/                  |       / |   \\X/           \n|      /|    _/                    |      /  |  _/             \n|     / |  _/                      |     /T1'|_/               \n|    /T1|_/                        |    /   _X                 \n|   /  _+                          |   /  _/                   \n|  / _/                            |  / _/                    \n| /_/                              | /_/                      \n|//___________________ X           |//____________________ ", block: true)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-146337")[#strong[#text("How should mathematics be taught to non-mathematicians? « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")]

#text("[…] question comes from a blog post of Terence Tao, and the response to it provides us with strong empirical evidence that people find it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-150545")[#strong[#text("A trip to Watford Grammar School for Boys « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")]

#text("[…] was a short break — not that it is too important. Anyhow, at some point round now I described Terence Tao’s airport-inspired puzzle, which is the following question. You want to get from one end of an airport to the other and your […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-153138")[#strong[#text("Some Miscellaneous Awesomeness « Research in Practice")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")]

#text("[…] Terry Tao’s airport puzzle. If you have to get from one end of the airport to the other to catch a plane, but you really need to stop for a minute to tie your shoe, is it best to do it while you’re on the moving walkway or not? (I learned this problem from Tim Gowers’ blog.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-155568")[#strong[#text("Assorted free entertainment #1 « Unabashed Naïveté")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2012")]

#text("[…] finally another one from Terry Tao: this time a little puzzle. Share this:TwitterFacebookMoreLike this:LikeBe the first to like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An introduction to special relativity for a high school math circle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-209604")[#strong[#text("An introduction to special relativity for a high school math circle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("[…] relativity per se, such as spacetime diagrams, the Doppler shift effect, and an analysis of my airport puzzle. This will be my first time doing something of this sort (in which I will be spending as much […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efeca458a52be40822616b67194dd482e1d7f5b8afadea018935b5d3fafd56be-004d41fcd560343481b11111a0ee0547e990fe7bed161dfc417cebca604c64fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ybing81")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-227493")[#strong[#text("ybing81")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("Such a model seems to be somewhat similar to the charge transportation in semiconductors, where concepts like “trap” and “mean free path” may find analogues in this ingenious puzzle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-244437")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("I can’t resist mentioning another airport-inspired puzzle that I heard from Isaac Kornfeld. Many airlines have a policy that they will only transport suitcases up to a maximum “linear dimension” (that is height + width + depth). The question is “can one cheat?”")

#text("More specifically, do exist suitcases S1 and S2, where the linear dimension of S1 is more than the linear dimension of S2, but still S1 fits completely inside S2 (for example diagonally)???")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-446154")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("Assuming a two dimensional suitcase, the answer is no, basically by repeated use of the triangle inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-269550")[#strong[#text("Monday puzzle: Moving walkway - Mind Your Decisions")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")]

#text("[…] While researching this article, I came across a post from the mathematician Terrence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-273053")[#strong[#text("The Blogging So Far | Bytes and Beats: A Strumming Engineer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")]

#text("[…] extremely interesting and may make me want to take out a pen and paper and work it out, like this puzzle prompt. In this way my blogging experience has expanded my knowledge of relevant fields, and has thus been […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45cb9b8a4530fa004e2744003a66b8e3cc5df633f05c302fce5b49eda1c106ea-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frances Winters")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-416405")[#strong[#text("Frances Winters")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2014")])]

#text("Clearly the best choice is to avoid the walkways completely. They will be completely blocked by mathematicians tying their shoelaces, cleaning their teeth or whatever.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-433711")[#strong[#text("Solution to 26 October fortnightly prize question | Maths resources")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")]

#text("[…] I borrowed the question from Terry Tao, who discusses it and some extensions on this web page. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-442655")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("Simple solution to 2:")

#text("Let G be the length of the ground, W the length of the walkways in total.")

#text("Let T be the amount of time you can run at the higher speed, v’. Let T_G be the portion of that time running on the ground.")

#text("Assume that you spend T time running at speed v’ and don’t complete the journey, otherwise obviously you just run at full speed the whole time.")

#text("Then the time to complete the journey is simply:")

#text("T + (G-v’ * T_G)/v + w – (v’+u)(T-T_G)/(v+u). This is a linear function of T_G and the coefficient of T_G is:")

#text("(v’+u)/(v+u) – v’/v which can easily be verified to be negative because v’ > v. Therefore to minimize the time, T_G should be as large as possible (i.e you should run on the ground as long as you can).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-447052")[#strong[#text("easy(?) probability/diff eq. question | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")]

#text("[…] an interesting set of problems here – I thought about it myself some time ago, and I’m not the only one (if you’re too lazy to follow the link, this is Tim Gowers posing exactly this question on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-448650")[#strong[#text("Moving walkway puzzle | nickelbook")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")]

#text("[…] Issa Rice has informed me that the puzzle originated here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-456357")[#strong[#text("Joker大人 | 在机场赶时间时，你应该怎么做？")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2015")]

#text("[…] 这个有趣的问题的提出者，正是大名鼎鼎的陶哲轩（Terence Tao），是他在一次乘坐国际航班前突然想到的。随后他便将这个问题放在了他的博客上（链接），引发了大量的回复讨论，我们先看下这个问题的具体描述： […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27977f094e08dfea6e5779763867c956feb2ff83989c686530e4176b111fd7a0-873ca40d593e190dfc3a410affa663c391e0c792f884ecc44d89d2d6cec93edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Basil")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-457811")[#strong[#text("Basil")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("Moving on platforms provides you with a speed boost(provided the platform is moving your way of course) for as long as the platform lasts.")#linebreak()#text(" so it’s an issue of maximising te spent on the platforms therefore your downtime tying your shoelace should be wgile on the platform while spending up your energy to run should happen off the platform since running on the platform would get you less time od the speed boost.")#linebreak()#text(" I did happen to have the same thoughts on my last trip to england as well and did in fact postpone tying my shoelace till i got on a platform :) I ran without regard for optimising my route though as they were shouting my name for i was late..")

#text("regarding Q3 i’m not familiar with relativity so i cant give an opinion but i’d like to consider how the problem would change given a stamina regeneration factor(although i guess the answer there would be run off platforms, rest on platforms unless youre full rested while on thr platform. also run with a platform within sight to regen stamina on it :p)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dff1abf388f64a38fefd2e0f4612af9f25cf64e6a64d7867173328bee371220-42da38440175040331775cfadbf73d3559b11bf3c4496a92eff11a293d443efd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abhishek")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-459610")[#strong[#text("abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2015")])]

#text("the problem is really simple.its the math that you all invoke is complicated.here a simple rigorous solution:")#linebreak()#text(" q1:let the total time taken be T if you dont tie your shoeson your optimal route.let t be the time you take to tie your shoes.")#linebreak()#text(" 1:if you tie your shoes on ground you take T+t total time.")#linebreak()#text(" 2:if you tie your shoes on walkway you take T+tv/(u+v).since v/(u+v)<1,therefore T+tv/(u+v)<T+t.therefore tie your shoes on walkway")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e1fc09b714df4ed7b5101a4440d98a12100b9f8ae9fa879e0228624904005ae-231834d2b688a2c72ef0876f4330911a551f6a487445684c0769986b18483455.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-463310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("I have a similar problem/puzzle that I think would be interesting – can anyone point me to a place where people pose puzzles (and no, it is not a homework problem I am trying to dupe someone into helping me with :) .")

#text("It comes from the world of almond harvesting and uncertainty in nut cart positions!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50a18864621292782db07eb605562ee544843805cb963a63ed3152a495f0ecb-7431f815fa0f8027987da7f284049d0695bbf34ff93e3926ef347db4fef431d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-465694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2016")])]

#text("Take your shoe off and run the whole way, using the walkways when possible. Tie your shoe on the plane.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15ae937ec9abc6af21049189532100f0be3c1d0198ac3df25581eaf278982285-fb1e5947b9c7a6aa83375d2467bfeed6f87bf7c51f2590a108b8765748029423.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Socrates and Shoelaces – johnvagabondsblog")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-471861")[#strong[#text("Socrates and Shoelaces – johnvagabondsblog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("[…] while you are on a moving walkway or while you are between walkways? This question comes from a blog post ofTerence Tao 10. You have a collection of suitcases, boxes and bags of various sizes, shapes and degrees of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-491489")[#strong[#text("Souvenirs from San Diego | Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2018")]

#text("[…] time that I fly to a conference, I think about the airport puzzle that I once read in Terry Tao’s blog. Suppose that you are trying to get quickly from point A to point B in an airport, and that part of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27516e89dc402cc192958930cfffea552f9f3ad0e26aa22ddd871d704c58f513-e3efb0c7a383d3e32b33f1e384dc9d8d749702b643bc1ab1cdcbcceac251556d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven E Landsburg")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-509049")[#strong[#text("Steven E Landsburg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("My blog post ")#link("http://www.thebigquestions.com/2018/12/19/ups-and-downs/")[#text("here")]#text(" tries to get at why people find this problem surprisingly hard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1fb6fdfcc124d8bfa9c7c7ae508800e0aa03e34ac7f7b8200510d0cacbc21c1-71d5546ca3dedf7a748e59a05e86d3be29a7226337889162a9d29c17f97088cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evan")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-512197")[#strong[#text("Evan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("I still can’t solve it")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb97baf01a8d8775dba0d42cd12419b2a87d303517e0d16d5416e74581fb516-12159c9e4bce1855eee77e6a392e93d0aadb07ea32098b52903e77dded9b9835.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skylin Chern")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-519397")[#strong[#text("Skylin Chern")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2019")])]

#text("Hello, Terry.")

#text("A teleplay,小欢喜(Little Joy) has been released in China recently. One scene in it is about walking up and down an escalator in a shopping mall, and then it mentions “Uniqueness of Terrence Tao’s problem”(陶哲轩问题的唯一性).")

#text("I don’t know what the “Terrence Tao’s problem” in it means, but I guess it refers to this puzzle. However, if my guess is true, I don’t understand the uniqueness here–the solution to this puzzle is not unique, right?")

#text("Have you raised other problem which is unique or whose solution is unique?")

#text("Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grüße an die UNI Tübingen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-603711")[#strong[#text("Grüße an die UNI Tübingen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("well, thanks mate, we now have to solve this for my physics I course. still no idea but lets try this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-622306")[#strong[#text("Puzzle #100: Late for the gate | Enigmatic Code")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")]

#text("[…] deceptively tricky everyday problem set in an airport was first posed by the US mathematician Terence Tao in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-622447")[#strong[#text("Puzzle #100: Can you work out how to reach your flight on time? - INFOSHRI")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")]

#text("[…] deceptively tricky everyday problem set in an airport was first posed by the US mathematician Terence Tao in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-632979")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2021")])]

#text("I just came across this puzzle and coincidentally I thought of something similar while travelling recently. Let me share my thoughts regarding the shoelace tying puzzle which is almost totally devoid of any calculations. Suppose ")#mi("t")#text(" is the time required to tie the shoelace. Consider two people ")#mi("A, B")#text(" travelling along the same path where ")#mi("A")#text(" ties his shoelace on the walkway, and ")#mi("B")#text(" ties his shoelace by halting on the ground outside the walkways. Then we can translate the movements of A and B as follows: imagine that A comes optimally till a point ")#mi("P")#text(" located at a distance of ")#mi("ut")#text(" away from his destination, and then boards a special lift instantaneously which takes it to the destination with a constant velocity ")#mi("u")#text("; this lift is the part of the walkway where ")#mi("A")#text(" ties his shoelace. Now for B we take B optimally without tying shoelace till the same point where A boarded the lift. Then we let B tie his shoelace without moving any distance and it takes time ")#mi("t")#text(" and then after this additional time ")#mi("t")#text(" B is allowed to board a lift which travels the distance of $ut$ with a speed of $u+v$; this corresponds to the additional length of the walkway where B travelled at a higher speed. We see that B takes more time to reach the destination than A.")#linebreak()#text(" A careful observation would show us that on ground there is a boost of 0 and on the walkway there is a strictly positive boost of ")#mi("v")#text(", thus walkways are more optimal than the ground in the sense that the more the time you spend on ground the slower you reach the destination; this is exactly what the above thought translates to in simple words.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-632980")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2021")])]

#text("Similarly for part 2 one should consider running outside the walkway in quest to reduce the time spent on ground.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-633021")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/08/19/an-airport-inspired-puzzle/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-640589")[#strong[#text("Escalator Problems - MetaSD")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2022")]

#text("[…] also an airport-walkway version that adds special relativity as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A puzzle inspired by Professor Tao’s airport-inspired-puzzle | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-642867")[#strong[#text("A puzzle inspired by Professor Tao’s airport-inspired-puzzle | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2022")])]

#text("[…] than a decade ago, Professor Terence Tao posted a nice puzzle here on his weblog. Recently, I was talking to my friend about this and he being a physics student was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be3f20c4f20ea57640f1f355239ee02bb63b60a06eb287c5608b191467becf80-cd246a5ba576b28859f2b387e6be2e4001851af0f6ecda466d6560ebdaef199c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Susan Elizabeth Mango")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-644083")[#strong[#text("Susan Elizabeth Mango")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2022")])]

#text("Did you give the solutions someplace, for the less mathematically inclined, like myself?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-657326")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2022")])]

#text("Why would it even be a math problem? It is obvious that one should tie the shoe lace on the walkway. One is still moving while on the walkway, but the velocity will be zero if one stops to tie the shoe lace off the walkway. Isn’t it just common sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-684779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2024")])]

#text("Ignore the non-walkway portion as this is common to both. Side by side comparison. A ties his shoelace then steps on the walkway. B steps on the walkway and the ties his shoelace. It’s clear B will always be ahead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-684783")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2024")])]

#text("Refining my last comment suppose the walkway is just long enough to tie your shoes, then as A is stepping on the walkway, B is stepping off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A puzzle inspired by Terry Tao’s airport inspired puzzle | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-3/#comment-686581")[#strong[#text("A puzzle inspired by Terry Tao’s airport inspired puzzle | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2024")])]

#text("[…] than a decade ago, Terence Tao shared an interesting puzzle on his weblog. A more recent mention of this puzzle was found in one of his Masterclass discussions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerald")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-33994")[#strong[#text("Gerald")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I’m just an humble undergraduate with a double major in mathematics and economics. And I’m only a freshman, to boot. But my attempt to solve the problem algebraically got the same results as Dr. Hanche-Olsen’s thought experiment.")

#text("Let:")#linebreak()#text(" D1 = distance with no walkway.")#linebreak()#text(" D2 = distance with walkway")#linebreak()#text(" V=walking speed")#linebreak()#text(" U=speed of moving walkway")#linebreak()#text(" p=time paused to tie shoe")

#text("Then time from A to B if you pause while not on the belt:")#linebreak()#text(" T1=(D1/V)+(D2/V+U)+P")

#text("and time from A to B if you pause on the belt:")#linebreak()#text(" T2=(D1/V)+((D2-pU)/(V+U))+P")

#text("The difference T1-T2 = -pU/V+U")

#text("so T2 is smaller than T1, and it is faster to tie your shoes while on the moving belt.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1021184a6da538d9142ac83d34cba06cabd2a6007c7f07890004fc0cedb579-569fd4c4f70a8d551d019c6ee1379e2f3bd35638af37751bf1a30bc521803a76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasha")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-33995")[#strong[#text("Jasha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I am sure Professor Tao has found the correct answer by now, I am also pretty sure he believed it made no difference how you do it when he posted the questions, number 3 makes otherwise just no sense. Moreover see above: “Update, Dec 11: Hints deleted, as they were based on an incorrect calculation of mine”. I haven’t seen the hints but obviously he had something wrong. Admitting that I have a knowledge about relative relativity that is close to zero I suppose whatever the effects are they can only be small, otherwise it could not generally be allright to ignore such things in real life situations as on the airport and to the best of my limited knowledge this is the case. Moreover there is no exact size of anything given so even if the effects of relativity were large there was no way to compare them to the more direct effects pointed out in the correct solution that are due to the fact that you maximize the time on the moving walkways. So relativiy can only become relevant for solving the time minimization problem if the questions to answer 1 and 2 is that it makes no difference where you run or rest. Conclusion: Professor Tao must have believed in a wrong answer when he posted the question.")

#text("Maybe I am wrong but there is one person who can tell us, I hope he will")

#text("Back to the economists:")

#text("They never had any problem in seeing that one way of moving was clearly superior to the other one because that is very obious if the question is formulated as in the slate article. They just didn’t have a good economic explanation. Yes, they should have figured it out faster. And of course the solution is obvious once you see it but this is actually true for many things smart people need a long time to figure out.")

#text("Moreover the things economist figure out faster are not put on an economist blog because in that case there is no story to tell. So you will only here about the few embarrasing cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34002")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Dear Jasha,")

#text("While I would have liked to have claimed to be playing some fiendish metagame in which the choice of questions was deliberately designed to cause one to overthink the problem (a danger which, coincidentally, I also discussed in ")#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")[#text("my recent post on multiple choice quizzes")]#text("), the third question just arose naturally to me as soon as I had formulated the first two. (In mathematics, it is often worthwhile to ask questions even if it turns out that their answer ends up being an easy corollary of previous known results; “trivial” or “easy” is not the same as “nonsensical” or “worthless”.)")

#text("Actually, as pointed out above by meichenl, Q3 does have some interesting subtleties to it when one does not assume that u, v, v’ are negligible compared to the speed of light c, since the effect of time dilation does act in the opposite direction to the effects that underlie the solution to Q1 and Q2. Consider for instance the relativistic version of Q1 (minimising airport time rather than wristwatch time). Suppose it takes an amount T of wristwatch time to tie one’s shoe. Then doing so off the walkway would clearly cost T units of time in one’s estimated time of arrival, whereas the ETA cost when tying the shoe on the walkway can be calculated to be")

#mi("\\displaystyle \\frac{T}{\\sqrt{1-u^2/c^2}} (1 - \\frac{u}{(u+v)/(1+uv/c^2)} )")#text(".")

#text("[This differs slightly from meichenl’s analysis, which did not have the time dilation factor affecting the second term.] This does indeed turn out to be smaller than T for any u, v between 0 and c, but this is not immediately obvious, and I do not know of a qualitative explanation (similar to Harald’s explanation of the non-relativistic case) of this.")

#text("Similarly, if one can run for T units of wristwatch time, then the ETA saving while running off the walkway is")

#mi("\\displaystyle \\frac{T}{\\sqrt{1-(v^{\\prime})^2/c^2}} ( \\frac{v^{\\prime}}{v} - 1 )")

#text("while the ETA saving while running on the walkway is")

#mi("\\displaystyle \\frac{T}{\\sqrt{1-(w^{\\prime})^2/c^2}} ( \\frac{w^{\\prime}}{w} - 1 )")

#text("where ")#mi("w^{\\prime} := (u+v^{\\prime})/(1+uv^{\\prime}/c^2)")#text(" and ")#mi("w := (u+v)/(1+uv/c^2)")#text(". One can again show that the former saving is larger, though this is certainly not obvious. (I recommend setting ")#mi("c=1")#text(" and showing that the latter function is a decreasing function of u by differentiation.) Again, it would be good to have an intuitive proof of this fact; it seems some convexity effect is in play here, but it is not exactly clear how it enters in precisely.")

#text("Incidentally, the miscalculation I alluded to in the post was to assume that actions such as tying one’s shoe or running occupy a fixed amount of distance, when instead they of course occupy a fixed amount of time (in the reference frame of the person). This came about because I had been working in terms of inverse speeds (time elapsed per unit distance) and exploiting convexity, as suggested by some of the comments above. Amusingly, the assumption of fixed distance, while incorrect, is close enough to the truth that the calculation (which is accurate to first order) did actually give the right answer to all three questions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74810998acfcdb45b91504adbfa11ea293b84b1b94b252509cf4aae36044c5ec-a1bdf7d22316ef6cc7f65ffa79d4264efd16ff69637934fb8ac7ef4260c20ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maputoman")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34003")[#strong[#text("Maputoman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("To revert to Harald Hanche-Olsen’s example, if the twin stops immediately before Harald gets on the escalator, the brother will be gaining when Harald gets off, and should catch up (as Michael Griffiths notes) as Harald gets off. Looking at it from the other end, if the traveler stops for b (seconds), he will add b time to his journey wherever the stop occurs. How could it be otherwise? If the stop is during the walking portion, it will take b longer than otherwise. If the stop is during the escalator portion, it will take b longer than otherwise.")

#text("Andrew Harvey’s response skips the algebra that leads to his conclusion. It could be that he’s onto something that counters this, but he didn’t present it.")

#text("Simply put, if someone stops for 15 seconds (or any other period) along the way, how would it make any difference where s/he stopped? The math seems to be a bit tricky, but the basic concept is pretty straightforward.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af3caf088a0868d5bc0994678535de0128556b2c28d7a41186d304446d5802de-97fa5a35ebcb5f87ba7c244934c934966c05857646d56984668a739557df49c6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl Smith")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34006")[#strong[#text("Karl Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("My shot at an answer that is both satisfying and could be explained to a child.")

#text("For Q1 and Q2:")#linebreak()#text(" The walkway increases your speed. This means that can it increases the distance you travel in any given time.")

#text("So the higher percentage of your time you are on the walkway the further you will travel in a given time.")

#text("Yet if you travel further in a given time, that must mean you are traveling faster.")

#text("Thus the higher percentage of the time you are on the walkway, the faster you travel.")

#text("Tying your shoe is just extra time so clearly it should be put on the walkway.")

#text("Walking as opposed to running is the same as tying your shoe for some period of time then running. Since tying your shoe on should be done on the walkway, so should walking.")

#text("For:Q3")

#text("As the walkway speed gets closer to the speed of light objects on it appear to move in slow motion.")

#text("Therefore the higher percentage of time spent on the walkway the higher the percentage of time spent in slow motion.")

#text("This means one would not want to put extra time on the walkway.")

#text("What I can’t answer simply but soundly is when the two effects would balance and why one doesn’t always dominate the other.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92cd6209c67cbfd1d9b58a2b305175df1d66d8ec03554d30cc02532cc55276a2-4f5d806c86f60252b7919cb34aff4d090ce875e52cccb97531fa800594b9b766.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wayne")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34009")[#strong[#text("Wayne")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Doesn’t the answer to Q1 depend critically on when you stop to tie your shoe, if v>u or u>v, and how fast you walk compared to the speed of the moving walkway?")

#text("In the example Harald Hanche-Olsen gave, twins start to walk down the terminal at the same time, however twin (1) stops to tie his shoes immediately before he gets on the moving walkway while twin (2) stops immediately after he steps on the moving walkway. In this case, both will be done at roughly the same time, but twin (2) will be t*u ahead of twin (1). Clearly, twin (2) would arrive at the terminal before twin (1) in this case.")

#text("But what if both get on the moving walkway at the same time and twin (1) walks while on the walkway and twin (2) again ties his shoes immediately after stepping on the walkway. Twin (1) finishes on the walkway and then stops to tie his shoes. Now is the chance for twin (2) to catch up. At this point, twin (1) is t*v ahead of twin (2). Therefore, twin (2) will only catch up if u>v. If u<v, then stopping to tie your shoe while NOT on the moving terminal would be quicker.")

#text("Finally, depending on how many moving walkways there are (and how long each is) and on the speed of the walkway, the answer depends on how fast you walk. Relatively fast walkers should tie their shoes while NOT on the walkway so they can take advantage of moving quickly while walking on the walkway. Relatively slow walkers (people who walk slower than the speed of the walkway) should tie their shoes will on the moving walkway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34016")[#strong[#text("Viktor")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("As far as I understand, the puzzle says, that you don’t stop walking while on the walkway, so your speed will be u+v there. In the second case Wayne mentions, when twin (1) stops to tie his shoes twin (2) will still be on the walkway, so his speed will be u+v for a while instead of v, which means that he will always beat the t*v distance under t time, however slow the walkway is. This means that it doesn’t matter whether u or v is bigger, so Harald Hanche-Olsen’s example should be fine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74810998acfcdb45b91504adbfa11ea293b84b1b94b252509cf4aae36044c5ec-a1bdf7d22316ef6cc7f65ffa79d4264efd16ff69637934fb8ac7ef4260c20ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maputoman")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34029")[#strong[#text("Maputoman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("OK. If twin(1) stops for 15 seconds on solid ground while twin(2) keeps walking, twin(2) will arrive 15 seconds earlier. If twin(1) stops on the moving walkway while twin(2) keeps walking, twin(2) will arrive 15 seconds earlier. How can there be a difference? (In either case, twin(1) will catch up if twin(2) stops for the same period.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30669e12ae7a9eec7473313bf145d4493823d0506a5e05c708c71197acfffb27-3e9f05089c5b01c60c0ab9492c8a59ee217d5698d9e8ee71c58d2a6971cc2a77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steko")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34037")[#strong[#text("Steko")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("This is why cars and bikes have gearing. The escalators are like downhill portions or a race course (or uphill for reverse escalators you are forced to take). Although gravity does not impart a constant velocity like the escalators, the same result is achieved: you gear down and work harder to minimize the time spent going uphill (or at low/starting speed) and conserve energy while going downhill to maximize the time spent under the advantage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d2333e7497f5098466fc53e27173fcb6761b9e9ec3740d6c36d56c478462cc6-034e2852e455ba824e77ecbf7385c510f008d5f3d34c3bf40506af174f6e432c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CN")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34041")[#strong[#text("CN")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("If the walkway is moving a velocity v approaching c, don’t take it, you’ll miss your flight. Time will slow in the walkway frame so that by the time you get off it, your watch will be behind relative to airport time. If you don’t recalibrate it, you’ll think you have more time in duty-free than you actually do!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa484a1dd94452114a2d0d82732722b3deb0c8851fb8f36048805e1d5ab9ba15-206c80a3bb5cb8a826c5e5fbac91ac3189fa3dde5d8fb1d592a99e0f9a36a605.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B. Narayanaswamy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34042")[#strong[#text("B. Narayanaswamy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Beautiful puzzle. Even after working out the math I took a while to get it into an intuition level – still difficult though!")

#text("I am reminded of how in a relay race, say a 4 X 100 m relay. The baton keeps moving at the hand-over phase – so the speed never really comes to zero. The [ record] average time for 100m in such a relay is hence less than the record for 100m sprint.")

#text("M. ‘Nary’ Narayanaswamy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1021184a6da538d9142ac83d34cba06cabd2a6007c7f07890004fc0cedb579-569fd4c4f70a8d551d019c6ee1379e2f3bd35638af37751bf1a30bc521803a76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasha")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34045")[#strong[#text("Jasha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Interesting that people keep posting wrong as well as correct solutions despite of Harald Hanche-Olsen and An Economist and probably some other posts I haven’t read carefully providing correct answers that should be easy to understand and that somewhat complement each other. Harald Hanche-Olsen gives an example that nobody could seriously doubt and an economist gives some economic intuition in addition.")

#text("I admit not feeling superior to Mathematicians, I just was annoyed by Harald Hanche-Olsen comment about economists.")

#text("Actually I feel superior to Sociologists who often make statements that come close to: “If a black homosexual woman and a straight wite guy both walk with the same constant speed and the guy ties his shoes on the moving walkways but the woman ties hers while she is not and in the end the guy gets the plane whereas the woman misses it this must be due to discrimination of homosexuals, minorities and gays”.")

#text("Interesting that Terence Tao made in his first calculations a mistake that is actually somewhat similar to the one the economist Harald Hanche-Olsen pokes fun at make. They also got confused with distance and time but as far as I can see in a different way. I got confused with it in a third way when I first tried to solve the problem. Seems this is somehow inherently different for humans.")

#text("Also interesting why I got it wrong when I was sure that Mr. Tao had believed that in case 1 and 2 there is no difference. I thought problem 3 was not interesting otherwise because no doubt the economic (maximization) problem is solved anyway if this is not the case. As an economist I found this a sufficient reason to find question 3 not interesting anymore in such a case.")

#text("I don’t say all economist think about this like me but I think it shows a certain pragmatism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerald")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34048")[#strong[#text("Gerald")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Wayne,")

#text("You said “To revert to Harald Hanche-Olsen’s example, if the twin stops immediately before Harald gets on the escalator, the brother will be gaining when Harald gets off, and should catch up (as Michael Griffiths notes) as Harald gets off.”")

#text("Picture this… the twins in Harald Hanche-Olsen’s example are on the belt, walking, and one is ahead of the other (because he was on the moving belt when he tied his shoe and the other wasn’t). The twin who is in front steps off the end of the belt and keeps walking. The twin behind him is now gaining on him, but not fast enough to catch him. When the twin who is behind reaches the end of the belt, his brother will have walked some distance from the end of the belt. Both are walking at the same speed, so the rearmost twin will never catch up.")

#text("So you are correct that the brother will be gaining when Harald gets off. But he won’t catch up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerald")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34049")[#strong[#text("Gerald")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Oops, that wasn’t Wayne I was quoting, it was Maputoman. Sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34051")[#strong[#text("Joen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("I think this is a good example of what happens to people who are smart (and I mean Dr. Tao and the economists from Rochester) but sometimes overconfident on their “intuition”. If intuitive answers were proofs then scientific journals wouldn’t have so many equations. I thought the answer to Q1 and Q2 was that it doesn’t matter, and I had my intuitive explanation, then I read other intuitive explanations that said you have to stop on the walkway and to my surpise they made sense, but so did the other explanations. Then someone wrote the math and showed that it was better to stop on the walkway, you might not be able to get any intuituion from the equations or maybe you do but in the end you know that it is right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Berry")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34055")[#strong[#text("Brian Berry")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("While I skipped reading most of the comments, early guesses show that most people have no idea which answers are correct or why they are. So here is my futile attempt to clarify the why’s (with logic but no math).")

#text("The answers is to stop on the escalator and run off the escalator. The logic is simple when you come onto it: You want to maximize your time spent on the escalators.")

#text("the escalators are a fixed length. since you have a limited amount of “energy.” if you spend as much of it as possible off the escalators you will take full advantage of the work potential of the escalators.")

#text("Imagine you run on the escalator, well, now you’ve received the extra speed of the escalator for less time than if you were walking.")

#text("Imagine you stop on the escalator. You’re effectively increasing the time you get the benefit of the escalator.")

#text("I hope this is a clear enough explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34063")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Jasha, didn’t you see the tongue planted in my cheek when I made that comment on the economist? There is a difference between ")#emph[#text("feeling")]#text(" superior to economists and actually ")#emph[#text("being")]#text(" superior. I did not claim the latter. (Besides, I expect that Slate article somewhat exaggerated the economists’ difficulties in order to be more entertaining.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa484a1dd94452114a2d0d82732722b3deb0c8851fb8f36048805e1d5ab9ba15-206c80a3bb5cb8a826c5e5fbac91ac3189fa3dde5d8fb1d592a99e0f9a36a605.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B. Narayanaswamy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34083")[#strong[#text("B. Narayanaswamy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("A comment on Harald Hanche-Olsen’s ‘Twin Brother’ approach to Qn. 2.")

#text("The Approach is great , and it’s clear in Q1 when we plot the distance X Time. When one stops to tie the laces on the firm ground it’s a horizontal line; but if it’s done on the walkway, then it’s still a sloping line, at the spped of the walkway. So you reach faster.")

#text("But I am not able to figure out the analogous argument for Q2, where there is no stoppage involved.")

#text("Mr. Hanche- Olsen’s post says ” … But you are now on the walkway, so the distance to your brother keeps increasing beyond D. Once he gets on the walkway too, he starts running, but since the distance is greater than D it would now take him longer than T to catch up while you are both still on the walkway”.")

#text("But, when the brother starts to run on the walkway, won’t the speed of the walkway help him also to get the same increase? That is, the line for both the brothers will ‘straighten up’ the same way ? I am missing something here.")

#text("Nary / 17 Dec.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34085")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Move to a coordinate system moving with the walkway. The situation is exactly the same as it was off the walkway, with the exception of the relative positions of the two brothers, so the running brother will close the distance by an amount D in the alotted time for running. Since the other brother was further than D ahead of him, the running one won’t catch up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e026a142f38b7e8d90ad083036822ee6f70ceee4e7f4c63234a7277d87ece5d9-8085d1a0236c8431f91dd8faf977dca5761248cb271da8e1dda1b0e30612885b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Incognito Citizen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34086")[#strong[#text("Incognito Citizen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Q1. tying shoe on walkway is more efficient")

#text("For Q2 – I am confused. As the energy is limited – increased speed of v’ on walkway or off walkway would imply that less than v speed on off walkway or on walkway respectively. Let us assume that v’ = v+a and when man uses v’ speed on either walkway or off walkway, the remaining distance is covered with speed of v-a. Simplistic assumption to regard limited energy constraint.")

#text("Total Travel Time when v’ used on walk way = D1/(v+a) +D2/(v-a)")#linebreak()#text(" Total Travel Time when v’ used off walk way = D1/(v – a) +D2/(v+a)")

#text("Clearly if D1(walkway distance) and D2(off walkway distance) are equal then choosing to increase speed on either walkway or off walkway is SAME.")#linebreak()#text(" However, if D1 and D2 are unequal:")#linebreak()#text(" I) D1 > D2")#linebreak()#text(" bigger distance is covered with higher speed. Good gain.")#linebreak()#text(" and shorter distance is covered with smaller speed. Not bad either.")#linebreak()#text(" Running on walkway is better.")

#text("II) D1 < D2")#linebreak()#text(" running on off walkway better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e026a142f38b7e8d90ad083036822ee6f70ceee4e7f4c63234a7277d87ece5d9-8085d1a0236c8431f91dd8faf977dca5761248cb271da8e1dda1b0e30612885b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Incognito Citizen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34087")[#strong[#text("Incognito Citizen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Sorry above, equations should be:")#linebreak()#text(" Total Travel Time when v’ used on walk way T1 = D1/(u+v+a) +D2/(v-a)")#linebreak()#text(" Total Travel Time when v’ used off walk way T2 = D1/(u+v – a) +D2/(v+a)")

#text("given so many variables – let us first assume D1=D2 = 1")

#text("Now let us assume T1 > T2 and work out logically if this is true ( I guess its called principle of mathematical induction )")

#text("1/(u+v+a) + 1/(v-a) > 1/(u+v-a) + 1/(v+a)")

#text("or, (2v+u)/ (u+v+a)(v-a) > (2v+u)/ (u+v-a)(v+a)")

#text("or, 1/ (u+v+a)(v-a) > 1/ (u+v-a)(v+a)")

#text("or, (u+v-a)(v+a) > (u+v+a)(v-a)")

#text("still not easy for me to say if this inequality is always valid. let us say u= 4, v = 2, a=1 (reasonable proportionate values)")#linebreak()#text(" then ,")

#text("(4+2-1)(2+1) > (4+2+1 )(2-1)")#linebreak()#text(" or 15 > 7 OK. Assumption seems to be true.")

#text("lets take another set of values, u=5, v=3, a=1")

#text("7×4 > 9×2 . OK. Assumption seems to be true.Running on Walkway is better – provided D1=D2. Still clueless when D1, D2 are variable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34088")[#strong[#text("Napi érdekességek « banyablog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")]

#text("[…] érdekes egydimenziós matek feladvány amire sikerült tök rossz hasraütős választ adnom, papíron viszonylag gyorsan […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e987815bb317a960acfd857bc320f62c6e164e8ae93200fb41f7e182c22f8c44-9bc2b47f11cf35c567fe728b9bcc4419fd26209d30ec0fbe318b46ad2efdc246.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of akos")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34090")[#strong[#text("akos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Incognito, my humble solution:")

#text("let d1 be the length of the non-moving walkway and d2 be the length of the moving walkway (assuming that t1*u < d2 , not that it would change the solution) :")

#text("1. if we stand still on d1 : t=d1/v+t1+d2/(u+v)")#linebreak()#text(" if we stand still on d2 : t=d1/v+t1+(d2-t1*u)/(u+v)")

#text("thus standing still on d2 is better.")

#text("2. if we run (for t2 time) on d1 : t= t2 + (d1-t2*v’)/(v)+d2/(u+v)")#linebreak()#text(" if we run on d2 : t=d1/v+t2+(d2-t2(v’+u))/(u+v)")

#text("from these (and because v’=v+v”, and let t0=d1/v+d2/(u+v) )")

#text("on d1: t=t0-t2*v”/v")#linebreak()#text(" on d2: t=t0-t2*v”/(u+v)")

#text("we can see that running on d1 is better.")

#text("Lorenz transformations would only give a speed penalty to running on the walkway (and walking more on the walkway), so this doesn’t change unless we care about the walkers own time. That one is interesting though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Jackson-Hanen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34091")[#strong[#text("David Jackson-Hanen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("I read this thread yesterday before my red-eye flight to London, and so of course when walking through the terminal this morning my shoelace came undone. Thanks for helping minimize my time getting through the airport!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8234aa504b9db8a8fa4df4e90d140f20c13796a74fac56bbd98f26cf9843b153-6beec816ed148a66390c867af1b9d0bf1b9088f9a9445b7ac3522d93c81858d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jay french")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34109")[#strong[#text("jay french")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Distance is velocity times time. So let’s say the off ramp time is a, the on ramp time is b, and the time to lace up is x. Also the velocity walking is v and the velocity of the ramp is u (and for convenience we can say that v+u=y). Then the distance (D1) covered by lacing up off the ramp is")

#text("D1 = (a-x)v + yb or va – vx + yb")

#text("The distance D2 covered by lacing up on the ramp is")

#text("D2 = va + y(b-x) + ux or va + yb – yx + ux, but if we replace u with (y-v)")#linebreak()#text(" D2 = va + yb – vx + yx – vx")

#text("We know that the velocity walking on the ramp (y) is more than the velocity walking off the ramp (v), so we know yx is greater than vx, and hence when we compare D1 and D2 we find that subtracting the value of D1 from each side leaves D1 at zero and leaves D2 with a positive number (yx-vx) so the tying of the shoe on the ramp gets you further in a given time.")

#text("Many may have figured this out, but I have not the energy to check all these blogs. Whew!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8234aa504b9db8a8fa4df4e90d140f20c13796a74fac56bbd98f26cf9843b153-6beec816ed148a66390c867af1b9d0bf1b9088f9a9445b7ac3522d93c81858d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jay french")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34115")[#strong[#text("jay french")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("So getting on to puzzle no. 2, it seems intuitive that if you can cover more distance in a given time by stopping to tie your shoes on a walkway ramp, it must be more efficient as well to do whatever running you intend to do on that walkway ramp. So, let’s see . . .")

#text("Again, off ramp time is a, and on ramp time is b, and the time that you are sprinting (presumably at constant velocity) is x. We will call the velocity at which you walk v, the velocity at which you run v +v1 (where for convenience v+ u = w), and the velocity of the ramp u. Then the distance (D1)covered by running down the terminal not on the ramp is")

#text("D1 = v(a-x) + x(v +v1) + (b – x)w OR va – vx + vx + v1x + bw – xw OR")

#text("D1 = va – vx + vx + v1x + bv + bu – vx – ux")

#text("The distance covered by running on the ramp is")

#text("D2 = va + x(v + v1 + u) + (b – x)w or va + vx + v1x + ux + bw – xw OR")

#text("va + vx + v1x + ux + bv + bu – vx – ux")

#text("If I am getting this nuttiness correctly, if again you subtract the value of D1 from both D1 and D2, D1 is zero and D2 is a positive number (vx + ux), and hence since D2 is a greater distance, again it is more efficient to do expend the speed-up energy on the ramp, i.e., one goes further in the same time by running on the ramp than to spend the same time running off the ramp.")

#text("Say goodnight Gracie . . .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinwei")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34169")[#strong[#text("Xinwei")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2008")])]

#text("Still in the twins’ scenario.")

#text("Suppose the initial part of the terminal is walkway and all the following part is solid ground. On the walkway, you run for T seconds and then you are D meters ahead of your brother temporally.But when you finish walkway and begin to walk in solid ground, your brother is still on walkway. so the distance to your brother decrease to smaller than D. When Both your brother and you are on solid ground, your brother begin to run and after running, your brother will be ahead of you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa484a1dd94452114a2d0d82732722b3deb0c8851fb8f36048805e1d5ab9ba15-206c80a3bb5cb8a826c5e5fbac91ac3189fa3dde5d8fb1d592a99e0f9a36a605.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B. Narayanaswamy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34176")[#strong[#text("B. Narayanaswamy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2008")])]

#text("Got it! Thx, Xinwei. Very clear.")

#text("Nary")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34184")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2008")])]

#text("I’m unhappy that the airport seems to be embedded in flat Minkowski 4-space. The mass of the planet, planes, passengers, and luggage forces non-zero Gaussian curvature. The General Theory of Relative Walkways is yet to be discussed. Particularly important for airports near black holes. Passengers on closed time-like curves need not pay infinitely for round trips. Passengers will please refrain from throwing objects at singularities, as the Hawking radiation violates local health codes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76ba48a41020c3c66f8616d3557759f2b28eab1c84b9db45feb3eff2e7e7e38-2736e801fa6504beaf7a9b60240cb6d8201f80839f01a540b67a478fc0083e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Blackmor")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34279")[#strong[#text("Aaron Blackmor")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("I believe that all decisions are a complete toss-up. There is nothing to be gained or lost by choosing to stop or run on vs. off the moving walkway. It is more a question of risk. Should you stop at all or run at all? It is riskier to tie your shoe on the walkway because a) it has a fixed width and someone could run over you, and b) you could get your laces caught and your leg ripped off.")

#text("Running also poses some risks, and the risk is compounded every second you delay tying your shoe. Ergo, the optimal decision is to tie your shoe off to the side (out of people’s way) immediately, whether you’re on or off the walkway, and then run immediately as much as possible, again, whether you’re on or off the walkway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhou Fang")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34297")[#strong[#text("Zhou Fang")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("1. Doing the maths, it seems it would be always better to tie your shoelaces on the conveyer belt.")

#text("I think the idea is this: We are going to spend some time tying our laces in either case. We might as well spend it productively, making progress, than spend it standing still.")

#text("2. Assume that equal energy means that we run for the same period of time in both cases. Then it doesn’t matter whether we run off or on the walkway.")

#text("I’m not sure if there is a very intuitive interpretation to this. One argument is that we are maximising the average speed – so no matter if we run on or off the walkway, we are providing the same boost.")

#text("3. Argh, my special relativity is terrible. Maybe I’ll think about this some other time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34325")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2008")])]

#text("[truncated version of a too-long and too-contentious prior submission]")

#text("I had a dream one night when I was at Caltech (1968-1973) where I’d spoken at length with John Horton Conway, that the universe was filled with an infinite 3-D array of shoes with tied shoelaces. One shoe spontaneously untied, and a wavefront of untying rippled outwards. No, on looking more deeply, it was an infinite number of spontaneously untied shoes, and the interfering wavefronts combined in a Game-of-Life-like way to make a universal assembler/Turing machine. Then I realized that what we thought was the actual physical universe was merely a simulation embedded in shoelace-cosmos. Surely this affected my definitive publication on our being mere simulations in 1991.")

#text("“Human Destiny and the End of Time” [Quantum, No.39, Winter 1991/1992,Thrust Publications, 8217 Langport Terrace, Gaithersburg, MD")#linebreak()#text(" 20877] ISSN 0198-6686")

#text("Now, as to the airports, will they run better when cryogenically cooled? That will bring in cooperative quantum effects on sufficiently large number of people, as was the basis for Isaac Asimov’s Psychohistory. By the way, Asimov rarely if ever visited airports, as he did not fly. He agreed with my suggestion that “Trantor” — the ceilinged-over capital of the Galaxy — was based on his childhood memories of the vast vaulted roof of (since demolished aboveground) Pennsylvania Station in New York City.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/441fda2323a8a25f72dba1eca93d0d2ab7007e1da5561ce1610adaf0aea05f84-66d89e932870e2b814c75ce81d75e047b30161cd0b4eab5f4c70b52d59bad083.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Baloglou")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34392")[#strong[#text("George Baloglou")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2008")])]

#text("An intuitive (?) response to both Q1 and Q2 (and more) is “spend as much time as possible on the faster media (in this case the walkway)”. Here is a simple mathematical confirmation of this (again covering both Q1 and Q2, but starting with Q2).")

#text("Running ON walkway:")

#text("X seconds walking on walkway: speed = u+v, distance = (u+v)X")#linebreak()#text(" x seconds walking off walkway: speed = v, distance = vx")#linebreak()#text(" r seconds running on walkway: speed = u+v’, distance = (u+v’)r")

#text("Running OFF walkway:")

#text("Y seconds walking on walkway: speed = u+v, distance = (u+v)Y")#linebreak()#text(" y seconds walking off walkway: speed = v, distance = vy")#linebreak()#text(" r seconds running off walkway: speed = v’, distance = v’r")

#text("We need to compare X+x+r to Y+y+r, that is X+x to Y+y.")

#text("Since the total distance covered (airport corridor length) is the same in both cases, the sums of the two triplets of distances above must be equal, so that")

#text("v(X+x) + u(X+r) = v(Y+y) + uY (*)")

#text("Since the total time spent on the walkway in the first case is less than the time spent walking on the walkway in the second case, that is X+r < Y, which implies that X+x > Y+y: running OFF the walkway is faster, which settles Q2.")

#text("Concerning Q1, notice that (*) remains valid when v’ < v (walking at slower pace) Y and, in particular when v’ = 0 (tying the shoe), (*) remains valid; in this case X+r is bigger than Y, so by (*) again, X+x < Y+y: tying the shoes ON the walkway is faster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhou Fang")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34407")[#strong[#text("Zhou Fang")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2008")])]

#text("Uh doh, I realised the mistake in my earlier answer for Q2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/441fda2323a8a25f72dba1eca93d0d2ab7007e1da5561ce1610adaf0aea05f84-66d89e932870e2b814c75ce81d75e047b30161cd0b4eab5f4c70b52d59bad083.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Baloglou")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34598")[#strong[#text("George Baloglou")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Here is a proposal for a modest generalization. Consider a ‘river’ from, say, 0 to 1 with fixed speed u(x) and a ‘kayak’ of varying speed w(x) (determined by the kayaker’s strategy — that is depending on u(x) — and strength and subject to a constraint like “integral of w(x) over [0, 1] is bounded by M”). How/when is the time needed for traveling from 0 to 1 minimal?")

#text("In the original problem u(x) was a step function, here it is an arbitrary positive continuous function. Both speeds are functions of location rather than time, which probably makes time minimization harder. Possible naive conjectures here, in the spirit of the original problem always, could read like “time is minimal when the integral of u(x)/(1+w(x)) over [0, 1] is minimal”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74810998acfcdb45b91504adbfa11ea293b84b1b94b252509cf4aae36044c5ec-a1bdf7d22316ef6cc7f65ffa79d4264efd16ff69637934fb8ac7ef4260c20ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maputoman")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34640")[#strong[#text("Maputoman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("We may be approaching unanimity here. I, at least, would like to confess the error of my previous comment and say that I now agree that it is better to stop on the moving walkway. There’s been enough math on this that I don’t think it would enlightening to add the formulas by which I convinced myself. For structure, time is the essential variable, and total time elapsed is clearly shorter if the stop is on the moving walkway. That falls out of plugging the problem into d=rt, recast as t=d/r.")

#text("Happy New Year to you all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2009")])]

#text("I don’t know if it’s too late to get in on this, but I would think that, at least for Q1, it wouldn’t make a difference. I’m no mathematician, but here’s an intuitive reply from a bricklayer.")

#text("1) Assuming there are equivalent lengths of walkways and that you would opt to take the walkway whenever possible, and that it takes the same amount of time:")

#text("– If I decide to tie my shoes off the walkway, then yes, I lose ground because I’m staying still. However, when I do get to the walkway, I’ll be walking, which therefore amplifies my speed by a factor.")

#text("– If I decide to tie my shoes on the walkway, then my speed while tying my shoelace is determined by the speed of the walkway. However, it is evident that the speed here is slower than the above where I am walking on the walkway.")

#text("To use the example of the twins, and again assuming a similar length of walkways (perhaps a parallel set of walkways positioned differently?)")

#text("We walk down together, I encounter a walkway, my twin doesn’t. We both stop to tie our shoelaces and I get propelled forward. Then we both start walking. My walkway ends and my twin’s walkway begins. His speed is amplified and pretty soon, he catches up to me.")

#text("Assuming similar lengths of walkways, then at some point my walkway will end while his extends forward, thereby allowing him to catch up with me.")

#text("As for what’s more efficient? Well, I’ve seen a guy fall off a walkway while distracted doing something else, so I’d rather tie my shoes off the walkway personally.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2009")])]

#text("And adding to that:")

#text("suppose the walkways are placed in the exact same locations, but me and my twin decide on different times to stop and walk. Assuming the amount of time used to tie the shoelaces are the same:")

#text("Say one twin will always tie his shoelace on the walkway and the other one off the walkway – this implies that one will always walk on the walkway and the other one won’t.")

#text("All things being equal, they should still take the same amount of time based on the premises above, wouldn’t they? That is, walking on the walkway will allow the twin who stops off the walkway to tie his laces to catch up to the next one who ties his laces on the walkway.")

#text("Unless walking on the walkway somehow boosts your speed such that it is greater than the speed of the walkway plus the speed of your walking, they should both take the same amount of time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e5c955df11a312d0611aa9c081aa8500e8ed7ee71a16d68b69a79f8625d1874-4fce5b9789a66c355378faae347b214fdb4e1f9076d8ba5c22b58efdc263df79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Professor Shoelace")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34805")[#strong[#text("Professor Shoelace")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("“Is it more efficient to do so while on a walkway, or off the walkway?”.")

#text("If our ONLY concern is the total time taken to get from A to B, then pausing to tie while on the walkway is indeed both intuitively and mathematically a “more efficient” use of our time.")

#text("Personally, I believe it would be “more efficient” to tie your shoes immediately upon noticing that they had come undone, regardless of whether that occurred on a walkway or not. That way, one’s energies could be devoted to pondering other more worthwhile things (such as mathematics) rather than concentrating on stepping carefully to avoid an accident due to an untied shoelace.")

#text("For even greater efficiency, those who regularly suffer from untied shoelaces would be well advised to Google the problem. The short time spent learning a better shoelace knot will invariably be far less than the combined times of thousands of re-ties over the space of a lifetime.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a6d2377463a70198e77786faf900b1c7a1c04dd3e7c8ebdeaacc3de2f893fc4-03b6d54b708e21dcba44527d19142d464269ca4009dc1d8edc28956ebc80979b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of free online jigsaw")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-34906")[#strong[#text("free online jigsaw")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("t_1 = d_1/v’ + d_e/(v+u) + (d – d_e – d_1)/v. But t_2 = d_2/(v’ + u) + (d_e – d_2)/(v + u) + (d – d_e)/v. Now t_1 – t_2 = d_2 (1/(v+u) – 1/(v’+u)) – d1 (1/v – 1/v’) = (v’-v) (d_2/(v+u)(v’+u) – d_1/vv’). Now if you assume d_1 = t_e v’ and d_2 = t_e (v’ + u), we see that t_1 < t_2 by a factor of t_e u(v’-v)/v(v+u). Note that v’ = 0 brings us solution of 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d0e1aaea3fdf04e65d9d96419f51fdb0f8891fc7ff1c4a7e2004159f04d0db0-232f6cda2188dfb2f83c41b39d9cae0dec16b4be6725ad721b318f585ec2d0c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peili Dai")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-36568")[#strong[#text("Peili Dai")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("if you change the walkway to a circular orbit vertical to the ground, and there is no moving walk ways. what is the least amount of energy required to travel one cycle?")#linebreak()#text(" what if there is moving walkway?")#linebreak()#text(" when do u tie your shoes? on the walkway or off the walkway?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/103b2eb7dae83b49f59e81d000ea2a644cfc10a64570cb5c5537d13e8246fc63-b3481c47364b3e217d706efae05667781dd3d9212cd5cbb154ec30472e263890.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-39843")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("For questions 1 and 2, it makes no difference whether you choose to tie your shoelaces (or run) on or off the walkway. I intend to write up a proof shortly.")

#text("I’m afraid I don’t know much about special relativity, but will try to read up on some.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-40078")[#strong[#text("Answer: Exhaustion at the Airport « Arcsecond")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")]

#text("[…] problem comes from Terence Tao’s blog. The solution appears in the comment thread there. Somewhere midway down I attempt to answer the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4eb893ae2326480db8995a91a9e7207931fb9351be4c8e60f589759e2aa19f13-4855e36daeeb8e6e158ee8ba492fca8986ccd09b89896f36d501e9d06f659400.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manoj Srinivasan")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-41658")[#strong[#text("Manoj Srinivasan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("I recently wrote a paper about walking in general, and walking on moving walkways in particular, that is perhaps of interest to the readers of this blog.")

#text("Manoj Srinivasan. Optimal speeds for walking and running, and walking on a moving walkway. Chaos 19, 026112 (2009); doi:10.1063/1.3141428")

#link("http://link.aip.org/link/?CHAOEH/19/026112/1")[#text("http://link.aip.org/link/?CHAOEH/19/026112/1")]

#text("The paper does not address at all the question that Terrence posed, but is concerned with the biomechanics of walking on moving walkways, in particular the speeds at which people might walk on moving walkways, if they are not consciously thinking about how fast they are going (as when they are in a hurry).")

#text("The paper generated some popular press attention, but I must warn you that some of the popular write-ups are somewhat misleading.")

#text("This one is somewhat reasonable:")#linebreak()#text(" ")#link("http://www.dailyprincetonian.com/2009/09/29/23939/")[#text("http://www.dailyprincetonian.com/2009/09/29/23939/")]

#text("Thanks to Terrence for suggesting that I post a comment in this blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-44392")[#strong[#text("一道有意思的数学题-Monty Hall problem : 艾思克特")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2010")]

#text("[…] “陶哲轩blog上的另一道数学题” 。没听说过陶哲轩的google一下 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Provence 2010 « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-44458")[#strong[#text("Provence 2010 « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("[…] dies nicht genug war, wandte man sich einem Problem des Meisters Terence Tao zu, dem “Airport Inspired Puzzle”. Die Praktiker lösten diese Aufgabe mit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3113063b5b372c4a07a1ff3dd1311f4c1637f83a2fb4d47e7a46079fd65553ca-07b88b0879a945440dbf8b8eea7efa7e2b7d7c968731e56a7f8835a9565da04e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-46382")[#strong[#text("Attila")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2010")])]

#text("I agree with those saying 1. on, 2 off")

#text("But I think it is much easier to think about the problem as how much distance you lose when tying your shoes for 5 seconds – instead of what are the relative speeds of the two”twins”.")#linebreak()#text(" Also, for the second question, if you consider a bit of running as the “normal” behaviour, then how much distance do you lose when only walking for a while on or off… etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c1e2ddc6e1564fd7d9e9b39463d3d9566d14f650310dd090cffa471d577bd8-596bf8ff3666074677546ac165e54a596c7a839fd86f4e5d9caf1de7de0685a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aleks")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-46409")[#strong[#text("aleks")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2010")])]

#text("Normally run when off, tie shoes when on the walkway.")

#text("See also: ")#link("http://en.wikipedia.org/wiki/E%C3%B6tv%C3%B6s_effect")[#text("http://en.wikipedia.org/wiki/E%C3%B6tv%C3%B6s_effect")]#linebreak()#text(" and ")#link("http://en.wikipedia.org/wiki/Coriolis_effect")[#text("http://en.wikipedia.org/wiki/Coriolis_effect")]

#text("Is there any wind on the walkway? If the speed of the walkway is 1000mph will it pay off to curl like a ball (while tying shoelaces)? Size of airport (and walkway) could be important (if say it stretched a million miles) also the size and location of the planet (or moon) where located. As you see the important task is to stay on the walkway (at any speed) and to run as effectively as possible in accordance to surrounding conditions.")

#text("The maths behind any possible combination of factors is in reality quite difficult. To solve the puzzle specification could be needed (like max limits). Etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5744361bdbf9984d2ca8d5bd0655d83f3da140958e995b2a6b32a4249bf2df54-44d25a352259da6fd1153bf765b245031318841cb66f2ac5190812cea0560c42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerome JEAN-CHARLES")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-47275")[#strong[#text("Jerome JEAN-CHARLES")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("Here is a solution that I think is intuitively very clear and give also the solution, at least for question 1.")

#text("Change the problem to: You are going on foot from A to B. Part of the way is in tar (for cars but faster than sand by when on foot) part is of the way is in sand (for leisurely stroll, slower on foot that tar). So clearly your speed is better on tar than on sand as real world dictates.")

#text("Now I hope you will agree that if you must loose a minute (to talk or lace your shoe or whatsoever) it DOES NOT matter where you do it: it will simply add a minute to the time you normally take from A to B. In fact any losses of time wherever and whenever will simply add up.")

#text("So now you need only to be convinced that this is the same problem as the original one ( that is it models the original properly).")

#text("The tar models the walkway part and the sand models the plain walking.")

#text("Say speed u is that on sand and speed u+v is that on tar.")#linebreak()#text(" That it.")

#text("A small variation:")#linebreak()#text(" Please note also that we also have independence from where you lace if the original problem had said : you do not walk on the walkway : in which case the mapping would be speed u for sand and speed v for tar.")

#text("Comment for best solution:")#linebreak()#text(" I think this is close to the best solution for question 1 , yet there must be a better solution still with a natural setting where you spend some stuff and suspend spending it for a while. But I cannot find it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc1406075adff5da80faf4ff8ffc927ac801c60f21a23d015ed4a8340855f569-e33ebf2fea1aa3d014287831393b291640a53dca081ae5bc304dccbbaaac4742.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Billy")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-2/#comment-74010")[#strong[#text("Billy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")])]

#text("Jerome, I must disagree, I think it does matter where you do it. I’ve just worked out an example for this walkway scenario.")

#text("Say the distance in the airport one needs to walk is made out of one 5 km road then one 5 km walkway, for a total distance of 10 km. I walk at the speed of 5 km an hour, and the walkway moves at 5 km an hour as well, so on the walkway I move at the speed of 10 km/h while on the road I move at 5km/h.")

#text("Say I have an amazingly complicated shoelace that takes one hour to tie. If I choose to tie the shoelace on the road, then my total traveling time will be road walking time + pause to tie shoelace + walkway traveling time. (5km divided by 5km/h = 1 h) + (1h for tying shoelace) + (5km/10km/h = 30 min). The total time will be 2 hours and 30 minutes.")

#text("If I choose to tie the shoelace on the walkway, my total traveling time will be walking time + walkway traveling time, as I just stand still on the walkway tying my shoelaces for an hour, I will reach it’s end just as I finish tying my shoelace due to the walkway speed being 5km/h. So the total time is (5km divided by 5km/h = 1 h) + (5km divided by 5km/h = 1 h), giving a time of 2 hours.")

#text("We can clearly see that tying the shoelace on the walkway is the superior choice. By extrapolating this, it would be better to run on the road instead of the walkway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of discreter")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33834")[#strong[#text("discreter")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("My first idea is, suppose the speed of the walkway is infinity. Then it is easy to get a good guess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/383018c1e6414f09aa942e71a396c8aae63b54b83f60ac7f3a1a9061305fc1db-a5d7e03bf30ace7d9a5ee76f39a54c101f914ad5df8381f97a05de5475338a6c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Harvey")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33836")[#strong[#text("Andrew Harvey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("for q1, it takes less time to travel the total distance if you tie your shoe laces while on the escalator right? (thats what my algebra is telling me at least)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("Flown through Detroit lately?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33838")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("Lovely puzzle! One crucial observation is that it is never optimal to take the walkways (or escalaters) in the wrong direction. Now, try to explain it to your children!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-457858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")])]

#text("Well, they don’t necessarily want to minimize the time taken to move a certain distance, so depending on their goals, it may not be optimal for them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-457874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2015")])]

#text("@Anonymous Apart form the fact that your comment is completely irrelevant, you are right. (From TT: “Your objective is to get from A to B in the shortest time possible.”)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33839")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("for Q1, the total time = (time spent tying shoelace) + (time spent moving on solid ground) + (time spent moving on escalator). The first two terms are equal in each case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("For Q1&2: I’m to lazy to do the algebra, but isn’t the distance lost (through pausing) or gained (through running) the same on and off the walkway? Since moving on the walkway is faster, one loses less time tying the laces on the walkway whereas running should be done off the walkway.")

#text("This fits also with observing the difference between (a) stopping one step before a walkway for a minute and then doing a step and (b) doing the step before (onto the walkway) and then waiting a minute.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b5c602c4b9e5e170b3e853a4a50d9963e477b51ac216f356cd5cd5a9c2dc069-e6e4330eb9dab5edc9bbed4c0176341a76827bba23c9be6293b3c7c5ca7a5c1c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33841")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("I asked myself exactly the same questions the first time I was in an airport, namely when I was 15. So, once in my life, I can say I have investigated and solved a mathematical problem in which Terence Tao was also interested, before he did :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33842")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("I think you’re better off on the moving walkways in both cases becasue the “time scale” of the moving walkways is “faster,” i.e., the same experiment conducted on the moving walkways takes less time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33845")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("Imagine you are traveling with your twin brother. At the start of the moving walkway, you step onto the walkway and immediately stop to tie your shoelaces. Your brother stops to tie his before stepping on the walkway. You finish simultaneously and move on. But now you are ahead, and your brother never catches up since you both have the same walking speed.")

#text("As for the running part, you run ahead for T seconds until you reach a walkway D meters ahead of your brother, then you revert to your normal walking speed. But you are now on the walkway, so the distance to your brother keeps increasing beyond D. Once he gets on the walkway too, he starts running, but since the distance is greater than D it would now take him longer than T to catch up while you are both still on the walkway.")

#text("These arguments should work in special relativity too, I think.")#linebreak()#text(" Just before your brother steps onto the moving walkway, he sees the distance to you being bigger than D. That distance, seen as a bit of moving walkway, will suddenly seem even bigger to him once he steps onto the walkway. Again, he can’t catch up.")

#text("Anyway, I hope you made it home safely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-216442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2013")])]

#text("Your situations are only correct if the walkway stretches until ten end of the terminal. As soon as the walkway ends before your arrival point the advantage you gained starts disappearing.")

#text("So it is not as easy as you believe..it depends on how long are the walkways and how long the distance between them, and if the point b is just at the end of a walkway or not…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33846")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("(Aargh, on my first attempt to post the previous comment I god a complaint that the server was busy, and please try again. So I tried again, and was politely told I already said that … and indeed, my comment did go through. Are these hiccups common here?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/530672e6da4c0a6b9009100394ebc8b616285ca98f5bfee8f3dd146d0c049ff4-b453f1c3c353ae23bf2d6ba258f52aa3863903784fcb7abe192e8375c5be361c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bryan")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33852")[#strong[#text("bryan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("My intuition on the problem (that it made no difference where you tie your shoe) was decidedly wrong! I think the following scenario is the easiest way to visualize the puzzle: Imagine 2 situations: one where you tie your shoe one step before the walkway, and the other where you tie your shoe one step on the walkway. It’s clear that after tying your shoe, in case 1 you are a distance ")#mi("d")#text(" from your plane, while in case 2 you are only distance ")#mi("d-(u*t)")#text(" from your plane!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07fec11a230938c944b3c89299432dc226468a5e944ee0f41c33792218fe3147-96ec10ae2ca09d3c87371e9e0a4be1dfb5b45463ab1c192fc7ff0f43e0c88a7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saurabh")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33853")[#strong[#text("saurabh")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("1. is obvious. It’s better to do it on the walkway because in that same time you’re being transported further. t_1 = t_t + d_e/(v+u) + (d – d_e)/v and t_2 = d_t/u + (d_e – d_t)/(v+u) + (d – d_e)/v; where d is the total distance of which d_e is the escalator distance. t_1, t_2 are time taken when the tying is done off/on the escalator. t_t is tying time. In second case, d_t is the distance the escalator travels at tying = t_t u. d_e > d_t is assumed. Note that t1 – t2 = t_t u/(v+u).")

#text("2. This is more interesting! t_1 = d_1/v’ + d_e/(v+u) + (d – d_e – d_1)/v. But t_2 = d_2/(v’ + u) + (d_e – d_2)/(v + u) + (d – d_e)/v. Now t_1 – t_2 = d_2 (1/(v+u) – 1/(v’+u)) – d1 (1/v – 1/v’) = (v’-v) (d_2/(v+u)(v’+u) – d_1/vv’). Now if you assume d_1 = t_e v’ and d_2 = t_e (v’ + u), we see that t_1 < t_2 by a factor of t_e u(v’-v)/v(v+u). Note that v’ = 0 brings us solution of 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8474a7f7ada32722d66bb6f4f65d8dbe543faa7b007eaa455173fa29a2588c1-5d3c79cb277d237a6171eeee03b5acb6fee165c0bb17c795463a168278d58bf4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of secret law of attraction")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33856")[#strong[#text("secret law of attraction")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("this is very difficult mathematics puzzle…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c77d82ac643b7d1827bcd864009ef9ad88b77a7972190822eaf1b43d1a6aeff8-8ee6b886bdc968358a6e64e2eaefad3500d15af05560f58b741ff0ae48cae0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33857")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("Okay, it was harder to figure out how to comment than to solve the puzzle. (It would be nice if there were a link. I didn’t realize I had to scroll all the way down. :))")

#text("“(Obviously, one would only take those walkway that are going in the direction one wishes to travel in.)”")

#text("This is not true. Note that these walkways always have railings, so once you get on you have to stay on until the end. Consider this terminal:")#linebreak()#text(" A B C D")#linebreak()#text(" with walkways A->C, C->B and B->D. If the lengths and speeds are set right, then the fastest way from A to D will be to take all three walkways, including the one that goes backward.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a19e1527a5a5e5ce6cc69e0ee5e0af051d83cf8781a0459eb871c19697de474-14785f94a667cea5537939b4c41d289fd45219cf34cffb52ca2c456c929e062b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Triscari")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33858")[#strong[#text("Joe Triscari")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("Easiest way to see the relativity part is to use the the gate’s reference frame. Answers to Q1&2 are the same and there’s no reference frame that can reorder events so SR has no effect.")

#text("In fact, SR can make you seem to take less time to get to the gate because your watch slows down but when you get there, you’re still late if the Newtonian considerations don’t get you there on time.")

#text("In any case, the airline overbooked the flight and gave your seat away.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c58d20ac76d30688691ba02cd1ba2090efa08a031aa044e1c84aebfd3e7a2b2-c6238ca5fb438c878029dd135258924aab53e9fd3b29079ad77063ed9f9048bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Snyder")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33859")[#strong[#text("Noah Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("A while back Slate had an ")#link("http://www.slate.com/id/2070182/")[#text("article")]#text(" on this question from an economics perspective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33860")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("Ben: Nicely spotted. But when did you see an airport where the walkways are laid out like that?")

#text("And Noah: Thanks for the reference to the Slate article. It made me feel infinitely superior to the economists, as I could spot the problem with the benefit side of the equation the moment it was stated. (Insert your own economist joke here.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56088932c6318ccb5266580a9b56711e94d09198cd18769fe84da7450c5a37e1-4e778f5d223adde7456f58ac8d571d8db111c88a1bacec1396cf77cd762ac9d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meichenl")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33862")[#strong[#text("meichenl")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2008")])]

#text("I’ll be honest. It’s getting late, and I’m not feeling up to reworking all my algebra for a blog comment. But I think there are some subtleties to the special relativity case. For example, there is not a single answer to question one if you analyze if from your own point of view (get there are fast as possible, by the time on your wristwatch.) Instead, the answer of where you should tie your shoe actually depends on ")#mi("u")#text(" and ")#mi("v")

#text("The problem states,")

#text("“Your objective is to get from A to B in the shortest time possible.”")

#text("But it does not state in the shortest time possible ")#emph[#text("according to whom")]#text(". In SR, you will perceive the journey to take a shorter time than the airport clocks indicate, because you are moving. So do you want to minimize the time on your wristwatch, due to impatience, or minimize the time on the airport clocks, due to being late?")

#text("Let all velocities be proportions of the speed of light. i.e. c=1. You have to cover a distance ")#mi("d_n")#text(" of non-moving and ")#mi("d_m")#text(" of moving floor.")

#text("Q1, SR) airport time")#linebreak()#text(" Your speed while walking is still ")#mi("v")#text(", but your speed while walking on the walkway is")

#mi("\\frac{v+u}{1+vu}")#text(".")

#text("If you tie your shoe for a time ")#mi("t")#text(" while on the non-moving part, your total time is the time spent walking the non-moving distance, the time spent tying your shoe, and the time spent walking the moving distance:")

#mi("t_n = \\frac{d_n}{v} + t + \\frac{d_m (1+uv)}{u+v}")

#text("If you tie it while on the moving part, your total time will different for two reasons:")#linebreak()#text(" 1) you perceive yourself to spend ")#mi("t")#text(" seconds tying your shoe, but from the airport’s point of view you are experiencing time dilation. They think you take longer to tie your shoe.")#linebreak()#text(" 2) the distance you walk on the moving platform is reduced because you are getting closer to the end of it while you tie your shoe.")

#text("Note that these effects work in opposite directions. Effect 1) means you take longer than you did before, while effect 2) means you take less time to get there. The relativistic solution must converge to the nonrelativistic one in the limit where the velocities are much smaller than one, but we might look for some transition velocity at which it is no longer beneficial to wait for the moving walkway to tie your shoe. The equation for the case where you tie on the moving part is")

#mi("t_m = \\frac{d_n}{v} + \\frac{t}{\\sqrt{1-u^2}} + \\frac{(d_m - \\frac{t}{\\sqrt{1-u^2}}u)(1+uv)}{u+v}")

#text("Subtract to get the delta. The first term is the same, but the other terms don’t cancel exactly. Here are the leftovers:")

#mi("\\Delta t = t \\left(1 - \\frac{1}{\\sqrt{1-u^2}} + \\frac{tu(1+uv)}{u+v} \\right)")

#text("Limiting cases: u->0, we get zero. This means that if the sidewalk isn’t moving, it doesn’t matter where you tie your shoe.")#linebreak()#text(" u->1, we get infinity. This gives the result that if the sidewalk is moving near the speed of light, tying your shoe on it is a terrible idea. You’re already going close to the speed of light, so the time dilation factor is huge, and you will be tying your shoe in super-slow motion. For any given ")#mi("v")#text(", there is eventually some speed of the moving sidewalk above which you are better off tying on the non-moving portion. However, this equation only makes sense as long as ")#mi("dm - \\frac{tu}{\\sqrt{1-u^2}}")#text(" is positive, because that’s the distance you walk on the walkway. Eventually, for very high ")#mi("u")#text(", you’ll spend the entire walkway tying your shoe and still not be done yet. At that point the formula breaks down.")

#text("There is a 1-D family of values of ")#mi("(u,v)")#text(" such that it doesn’t matter whether you tie your shoe on the walkway or off it. If I did the algebra right, ")#mi("v_{crit}")#text(", the critical transition velocity, turns out to be quadratic in ")#mi("u")#text(". The solution I got was:")

#mi("v = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}")

#text("with")

#mi("a = u^2(1-u^2-u^4)")

#mi("b = 2u(1-2u^4)")

#mi("c = u^2(3-4u^2)")

#text("I might have preferred to solve for ")#mi("u(v)")#text(", but that was a sixth degree polynomial.")

#text("At this point, you’d want to check where the determinant of that solution was positive and where you get unphysical solutions, and throw those out. But the interesting conclusion was that this transition velocity does exist.")

#text("Q1 SR) wristwatch time")#linebreak()#text(" The time that passes for you, ")#mi("dt_y")#text(", analyzed from the airport frame as a function of airport time ")#mi("dt_a")#text(" is")

#mi("dt_y = \\frac{dt_a}{\\sqrt{1-v_r^2}}")

#text("where ")#mi("v_r")#text(" is the relative speed between you and the airport floor. So the total time that passes on your wristwatch if you tie you shoe on the non-moving portion is")

#mi("t_n = \\frac{d_n \\sqrt{1-v^2}}{v} + t + \\frac{d_m (1+uv)\\sqrt{1-\\left(\\frac{u+v}{1+uv}\\right)^2}}{(u+v)}")

#text("I got this by taking the answer for Q1 and multiplying by the time-dilation factor in each term. For the case where you tie your shoe in the moving portion, the total time elapsed on your wristwatch is")

#mi("t_m = \\frac{d_n \\sqrt{1-v^2}}{v} + t + \\frac{(d_m - \\frac{tu}{\\sqrt{1-u^2}})(1+uv)\\sqrt{1-\\left(\\frac{u+v}{1+uv}\\right)^2}}{u+v}")

#text("Again perform the subtraction. The first two terms are identical, which is good news since the last term is getting ridiculous.")

#mi("\\Delta t = \\frac{tu(1+uv)\\sqrt{1-\\frac{u+v}{1+uv}^2}}{(u+v)\\sqrt{1-u^2}}")

#text("This quantity is always positive, so from the standpoint of listening to the fewest number of songs on your ipod, it’s always best to tie your shoe on the walkway. That makes good sense because the effect of drawing out the time it takes to tie your shoe is gone in this frame. Three seconds from your point of view is always three seconds.")

#text("It’s interesting to note that for certain values of ")#mi("u")#text(" and ")#mi("v")#text(", it’s actually possible for one strategy to be best in terms of minimizing your personal time, while a different strategy can be best for minimizing how late you are to the flight.")

#text("For the special relativistic case of question 2, I’ll leave the details to somebody else. From the standpoint of airport time, running on the walkway is not going to help you as much as running on the nonmoving portions, due to velocity addition. So like the nonrelativistic case, you should always save your running for the nonmoving portions (or run those entire things if you have the energy).")

#text("From the standpoint of your wristwatch, time dilation is much more effective if you run while on the walkway, if the walkway is pretty fast. So it feels like there should again be transition velocities at which you best strategy switches.")

#text("Okay, please tell me about the copious mistakes I made, since it’ll actually be interesting to know the real answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33870")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2008")])]

#text("It’s interesting that Harold’s very simple mental trick, of picturing two people starting at the same time and tying their shoes at different places, makes the puzzle so much easier to solve (at least for me). It’s as if the brain has 1 “time evolution simulator” and running two simulations in parallel to compare them is much easier than running them separately and then trying to compare them. I guess if you’re going to do thought experiments, you have to be very careful to do the right ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33872")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2008")])]

#text("Peter,")

#text("The first solution offered by Harald Hanche-Olsen is very similar to a couple that Gil Kalai wrote about some time ago in his blog post, titled ")#link("http://gilkalai.wordpress.com/2008/10/23/two-math-riddles/")[#text("Two Math Riddles")]#text(". Indeed, Harald’s solution is a nice one!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33878")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")])]

#text("I wonder how many mathematicians secretly try to solve optimization problems that arise in everyday life. I recently had a conversation with another mathematician, in which we discovered that we had both had the thought that if you want to catch a train but don’t know what time the trains leave, then if at some stage of the journey you run (to avoid just missing a train and having to wait for the next one) that is irrational (unless, say, you are in such a hurry to reach your final destination that you would run from the station after your train journey), since the average time you save is equal to the time you save on that leg of it by running rather than walking. And yet both of us find it very hard to avoid the temptation to run when going down an escalator into the London Underground, say, even if we are too far from the platform to have any information about whether a train is arriving.")

#text("An optimization problem I’ve often wondered about is the best strategy when approaching a red traffic light by car or bike. The ideal outcome is to pass it at full (legal) speed just as it turns green, but obviously that can’t be achieved unless one is very lucky. But how does one minimize one’s expected time to some distant point (assuming no other traffic of course)? It’s not even obvious how best to model the problem. Probably some more realistic models would lead to less tractable mathematical problems: for example, a memoryless distribution for the time taken until the traffic light changes would probably be easier to handle. Someone once told me that there had been an article on this in something like the American Math Monthly, but I’ve never actually seen one — does anyone know of a reference?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Rabinovitch")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33879")[#strong[#text("Peter Rabinovitch")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")])]

#text("I bet there will be some F1 race strategists looking at these kind of problems now, as in 2009 the cars will have an additional ‘boost’ they can use for a few seconds each lap. The obvious question: use it on a slow part of the track or a fast part?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33880")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")])]

#text("Mr. Gowers, I’ve often thought about the same problem while driving. There are two optimization problems to consider: one in which you minimize expected time and one in which you minimize fuel consumption. Although I am not certain it is entirely accurate, I took as my approximation that minimizing fuel consumption was equivalent to minimizing both time on the gas pedal and time on the brake, so I developed a habit of letting off the gas pedal whenever I saw a red light and coasting without braking or accelerating. I notice that many drivers prefer to accelerate up to the red light and then brake, which is an enormous waste since it confers no benefits timewise (because even if the light turns green there’s lag from the cars already stopped accelerating that will force you to brake anyway) and needlessly increases gas consumption. The only time I ever saw a need to do this was to avoid congestion.")

#text("I remember thinking about the time optimization and concluding that the above strategy wasn’t bad for that problem. No braking means you tend to be at a reasonably high speed (though certainly not maximum) once the light does turn green, so it’s possible to get through the intersection a fair percentage of the time without ever having stepped on the brake. I have no illusions about whether this strategy is optimal, though I think it has the benefit of making the fewest assumptions about the light.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33882")[#strong[#text("A Response to Terence Tao’s “An airport-inspired puzzle” « Andrew Harvey’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")]

#text("[…] Source: Terence Tao, ")#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/")[#text("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")])]

#text("Dear Gowers:")

#text("I slightly object to your argument about it being irrational to run to the train. In practice, when one is in a hurry, it is because the person desires to arrive at her destination by a certain time. Before getting to the train station the traveler is unsure when the train departs and, say, realizes that she might or might not get to her destination on time, depending on the (unknown) schedule of the train. She then wants to ensure that she gets on the earliest departing train, by running to the station. Now once she has gotten off the train ride, the uncertainty has been removed from the situation and our traveler can calculate the speed at which she needs to walk to arrive at her final destination on time. It may be rational (maybe even with high probability, depending on the set up) for her to carry out the remainder of her journey at a leisurely stroll.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33887")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2008")])]

#text("The cost of running to the train station may be considered lower than running at a different part of your journey because you know you will be able to rest after your sprint, whether on the train or on the platform. Because of this, and the uncertainty argument above, it is not the equivalent of running after the train journey.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davetweed")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33890")[#strong[#text("davetweed")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2008")])]

#text("In connection with Tim Gowers comment, my reasoning would be that it also depends on the period of the train departure times relative to the remaining time before the deadline for your journey. (Clearly the train journey itself should take constant whenever one catches the train, so you can subtract that from the time you need to arrive at the destination, so that the remaining time gets split between travel to the station and travel onward from the destination station.) If the period of the train times is small compared to that time, then your argument seems fine. If it’s significantly larger than the time to your deadline, then arriving at the station as early as possible maximises the length of time in which a train could arrive that you could get on that would get you to your destination before your deadline. You could be unlucky and have no arrive train arrive within that window, in which case you are unavoidably going to be late. (This is a variation of Anonymous point above taking into account the periodicity of services.)")

#text("This is the algorithm I use for evening every hour buses when I can’t remember the time they depart from a specific stop (that I can’t see until I turn onto the street about 20 yards from them). Of course, if I really cared I could just leave earlier!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba11c8cf2988b50e1e777cc2ef5907b18bc8dd9858b977bc04a6a3db092b5ce-02b5b75697837756a638d71b872e1b2446ef6f329912f507a3a0122ccfd234a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clayton")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33923")[#strong[#text("Clayton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("For 1 & 2")

#text("My intuition is that you want to maximize the amount of time you spend on the moving walkway (each second providing you u*t distance that you would not cover off the walkway). If you tie on the walkway, you extend the amont of time on the walkway (versus walking and again versus running).")

#text("For 3")

#text("My intuition was that the closer your speed is to C, the more the timeframe of the walker slows (and that the effect is progressive). If the trip took the same time in the walker’s timeframe, it would take longer in the airport’s timeframe. My problem is that I had a feeling that relativity distorts distances from the walker’s perspective and thus my half shod assumption about the trip in the walker’s timeframe might be wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba11c8cf2988b50e1e777cc2ef5907b18bc8dd9858b977bc04a6a3db092b5ce-02b5b75697837756a638d71b872e1b2446ef6f329912f507a3a0122ccfd234a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clayton")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33925")[#strong[#text("Clayton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Gowers…")

#text("Ignoring the time with the doors open, i believe that your “naive” average wait time for a train once reaching the platform is the period of the train’s arrival over 2… *regardless* of when you show up.")

#text("By running, you bring this fixed window forward in time, causing your average departure to move forward in time. While, at some times, you may not catch the previous train despite your efforts… there are a sufficient number of times when you do catch the train so that it is a superior strategy for reducing your overall travel time.")

#text("You could obviously make the intuition more obvious by making your escalator time so long that running ensures that you show up a full period early… guaranteeing you the previous train under any conditions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5736ac1ae7cca0a36d66ed58035fa54206a6a08485e633b180f7e356c1b9d08e-31d5baf74842770e34ffe1e6d2f87b447140cb4bcc88a88eb0d1d0904bb3a3ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rory")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33930")[#strong[#text("Rory")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("The first two don’t matter, since either way you’re slowing down by v or speeding up by v’, so the time you lose doesn’t change.")

#text("On the third, it’s better to tie your shoes on the walkway and run while off it, because that same energy will provide less acceleration as velocity increases, so -v (the speed you lose by stopping to tie your shoe) would be higher on the walkway (that is, +v would be lower) and v’ would be higher off the walkway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c16d0dcc29ed523031a9e6af59b6c2f607b4a44b6d7c0f533af9cb3e27c962-c434277eef358d1a18a12ce270293a3c2e4327c2e5c2f16c8409f64fbe5f5197.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33932")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I love this puzzle. The way you have to warp your thinking to get your head around it is oddly similar to the way you have to warp your thinking to figure out whether you will save more gas moving from a car that gets 10mpg to one that gets 15mpg or whether you will save more gas moving from a car that gets 20mpg to one that gets 30mpg.")

#text("I think I just found a new interview question :-D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57d7aeda923c6b0d94d2fb2da44dc81aba5408ecd40856760b4d8c8acfdc6025-8aa9a4fbd54114bbdaabc773b53b340d357af48b55688ba50ad3f3dad9eaeb8e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Griffiths")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33935")[#strong[#text("Michael Griffiths")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("What?")

#text("Correct me if I’m wrong – I’m not a math major, and an undergraduate to boot – but surely in the case of #1, it bloody well doesn’t matter?")

#text("Let’s take Harold’s example, which has received praise, and correct it: because the length of the walkway is FINITE (an assumption), when you step of the walkway your speed drops to v, where your brother’s is still at v+u. Indeed, your brother is at speed v+u for the same amount of time you were at speed u; the difference in your speed and your brother’s is u for time t – meaning that you travel the same distance. So really, your twin catches up to you shortly after you get off the walkway.")

#text("Of course, if the walkway is infinite, then you are always ahead because you have gained distance u.t and your brother can never catch up.")

#text("I, of course, would prefer to tie my shoe on the walkway – but that has more to do with preferring not to stop.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-56443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")])]

#text("This is what I thought at first, but your brother is not at speed v+u for the same amount of time you were at speed u. He is traveling faster (v+u instead of u), so he will reach the end of the moving walkway sooner and will therefore spend less time with that +u speed boost.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c0cfd8e99701bacfdcf7a9f3084f10faf6c1a2a7917b5beafdb55336891d1e-e4669f9772e7d23eae3aa1c05f5f6c138d68bc2dd7e0ffe1d2fa7d2b5d91f15b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robbie")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33936")[#strong[#text("robbie")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("@M Griffiths")#linebreak()#text(" True, all these mathematicians have just been thinking about it wrong.")

#text("This is just a simple problem of having the wrong numerator. In other words, we should be thinking about h per km not km per h. It’s pretty obvious that you wouldn’t want to increase 1h/10km to 1h/15 km but instead 1h/5km to 1h/10km.")

#text("It’s why mpg is so stupid–we should be using gpm instead. We care about how many gallons we use not how many miles we can get out of one gallon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4450e4147da948396f9d590eb40b1246afeb87db0fd0a8ec51bbcc51fe1eac21-ae1f804a76f2a60c4772084e2489da8325de083c3b3918ded8ea25acd323a3ae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neil Strickland")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33937")[#strong[#text("Neil Strickland")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I find that the following problem occurs more often in practice. You approach the moving walkway, and have to decide whether to get on or walk along the side instead. If you can walk unobstructed along the walkway, that will certainly be quicker. However, if there are people standing or walking slowly on the walkway, and they are unwilling to move to the side and let you pass, then it may well be quicker to forgo mechanical assistance. Of course you can observe the distribution of people on the walkway as you approach. What is the best decision procedure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d56397c53ce526a8654e1b556e5c66130d49eff5a1f59e9c4c4241581a784cd-66407894876b7e38d769ed14c704763108a0b94f3b8fa61430c73f90c2d8941d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael F. Martin")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33938")[#strong[#text("Michael F. Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I’m thinking the same way as Rory. Harold’s thought experiment seems flawed somehow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1938c223bcde78ed2cdd4c8f02cc661ebc7c03e0d9ee4ea157778de4942bbb-3a307de0a1e1240575b1a2af006baa93a0acd92ba067722bcc85e07641b7dd3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harryh")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33939")[#strong[#text("harryh")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("@M Griffiths")

#text("This is where your logic fails:")

#text("> Indeed, your brother is at speed v+u for the same amount of time you")#linebreak()#text(" > were at speed u;")

#text("Your brother will be at speed v+u for less time than you were at speed u.")

#text("Let’s say the walkway is length d. You are on the walkway for time = d / u. Your brother will be on the walkway for time = d / (u+v).")

#text("The key to understanding the problem intuitively is realizing that you want to maximize time spent on the walkway to get maximum advantage from it. So if you have to stop, stop there. And if you’re only going to run for a bit, don’t run on the walkway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1021184a6da538d9142ac83d34cba06cabd2a6007c7f07890004fc0cedb579-569fd4c4f70a8d551d019c6ee1379e2f3bd35638af37751bf1a30bc521803a76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasha")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33940")[#strong[#text("Jasha")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Harald Hanche-Olsen,")

#text("you got the problem right. But the economists got it finally right too, contrary to Mr. Terence Tao who obviously wouldn’t have asked question Nr.3 if he had not believed that in question 1 and 2 the answer was that it doesn’t matter. Every economist can solve the problem easily if the question is asked like in the formulation in this blog. The question that drove economist’s crazy was slightly differently formulated and an algebraic formulation therefore less straightforward. So what you can really accuse them off is not finding a better way to formulate the question.")

#text("And now back to writing my own economics paper. My intuition tells me that there is something wrong with my algebra there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25a5fd5b57fe7d9c910467075b4a472dd4d39377fc9ca69d4a2f45e7ffbc2ed0-07aa004ec153073adeb365e32b108c489276ca125fe9e982f298df46088caa09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tchad")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33945")[#strong[#text("Tchad")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("It seems that it would be wise to tie one’s shoe before getting on the walk-way or the split second that the shoelace enters the walk-way gears will feel like an eternity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33946")[#strong[#text("CoreEcon » Blog Archive » Airport puzzler")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")]

#text("[…] Australian mathematician Terry Tao [HT: Greg Mankiw]: Suppose you are trying to get from one end A of a terminal to the other end B. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("For questions 1 and 2: The amount of time it takes to cover a distance d is a decreasing, convex function of the velocity that you’re traveling at. So in order to minimize the total time it takes to travel, you would rather have your relatively constant near some average as opposed to moving very fast in one portion and very slowly on another portion (which would happen if you walked during the moving-way and stood still to tie your shoes on non-moving ground).")

#text("So it seems like the answer for question 2 depends on whether u’>u>=v’>v or v’>v>=u’>u.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f5ed55b208ecc771c18792f9c2286c1ea6e70fa90ba1e6744b796edfcf0bc1c-754561150d0302c2f00a9fdaef3a8b71eb4fa33e8c5051120c9df1c4fc9213de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 善用佳软 xbeta")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33958")[#strong[#text("善用佳软 xbeta")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("q1. pause on walkway.")#linebreak()#text(" q2. run off walkway")#linebreak()#text(" q3. the same")

#text("q1:")#linebreak()#text(" ——————————–")#linebreak()#text(" 3 people:")#linebreak()#text(" A normal, B pause on walkway, C pause off walkway.")

#text("A&B: on foot, then walkway.")#linebreak()#text(" so A reach end first.")#linebreak()#text(" At that time, B need more time to reach: vT/(u+v)")

#text("A&C: walkway, then on foot.")#linebreak()#text(" so A reach end first.")#linebreak()#text(" At that time, C need more time to reach: vt/u")

#text("So, B better than C.")

#text("q2:")#linebreak()#text(" ——————————–")#linebreak()#text(" 3 people:")#linebreak()#text(" A normal, B run off walkway, C run on walkway.")

#text("A&B: walkway, then on foot.")#linebreak()#text(" So B reach end ealier.")#linebreak()#text(" At that time, A need more time to reach: dTdV/v")

#text("A&C: on foot, then walkway.")#linebreak()#text(" So C reach end earlier.")#linebreak()#text(" At that time, A need more time to reach: dTdV/(v+u)")

#text("So, B is most ealier, better than C.")

#text("q3:")#linebreak()#text(" ——————————–")#linebreak()#text(" advacned theory should not be conflict with obvious analization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f5ed55b208ecc771c18792f9c2286c1ea6e70fa90ba1e6744b796edfcf0bc1c-754561150d0302c2f00a9fdaef3a8b71eb4fa33e8c5051120c9df1c4fc9213de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 善用佳软 xbeta")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33959")[#strong[#text("善用佳软 xbeta")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("treat walkway as a good time, on foot is a bad time.")#linebreak()#text(" so the conclusion is :")#linebreak()#text(" dont stop in bad time, if you have to pause, do it in good time. (q1)")#linebreak()#text(" work harder in bad time, if you have limited energy, use it for bad time. (q2)")

#text("same as The law of diminishing marginal utility.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f9de2c933e4cebec253787a9e03a0d1034c0a6a32e7de806c9020eff118345-b2d7ad5848e3cfeb1d93843da4ef64b7043756658dec24ccb479bd3e7d0ac0a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of christophermoore")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33961")[#strong[#text("christophermoore")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Does nobody continue walking when they’re on a moving walkway? That’s what I do; you get there quicker while maintaining the same level of energy expenditure (the extra wind resistance caused by your increased velocity is tiny). It also makes this puzzle easier to solve, as it won’t matter where you stop to tie your shoelaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yor Naim")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33963")[#strong[#text("Yor Naim")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("A possibly relevant candidate:")

#text("J. I. Katz")#linebreak()#text(" How to Approach a Traffic Light")#linebreak()#text(" Mathematics Magazine, v63 n4 226-230 Oct 1990.")

#text("Abstract: The problem of determining the most energy-efficient strategy to use in approaching a traffic light that is sighted at an unknown phase in its cycle is discussed. Included are calculations, results, and conclusions.")

#text("The note may be available via JSTOR, but I haven’t a subscription. There is a copy in a closet at my parents house, but that is also out of reach. If memory serves: The author remarks on the many unknowns and shows under certain assumptions that it’s best to maintain a constant speed. High school was long ago, however, so I’m happy to be corrected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eb765e0b01c22314d4e47b360d11f9098c89371b0bc17ecde979b882337ae59-e7768c3358004a60ba4ac48f33d916f17c4b365165406780ecb0c95bddedb082.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yor Naim")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33965")[#strong[#text("Yor Naim")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I think physicists, too, may approach many everyday problems as optimization problems. If it’s raining and I don’t have an umbrella, but there are various bits of cover between me and my destination, then I try to find a zig-zag path which meets my constraints on time, energy, getting wet, having fun, etc.")

#text("Absolutely fascinating, at least to me, is R. P. Feynman’s “special lecture” on the Principle of Least Action in Vol. 2 of his Lectures (cf. Chapter 19). The power of instruction, indeed.")

#text("What sorts of everyday problems have “optimal” solutions which are really saddle points? All of them? Any particularly interesting examples of balance, delicate or shallow, or of “threading the pass?” (I believe John Baez calls this “criticizing” the action, in the context of quantization, but I may be very wrong.)")

#text("A question born of much ignorance: Does Morse theory have everyday applications?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jc")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33969")[#strong[#text("jc")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I think for question 1, it’s good to stop at moving walkway and for question 2 it’s good to run on off the walkway.")

#text("From the intuition of convexity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f39ef7eed64a14ac9445c8ae0de3d7f741b7db364875ad5e5789cdb8a2ee934f-0e630224648cd49bf63e4b99454a53e79e930ab2b282e3e2b3ea1bcf15d579e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Thomas")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33980")[#strong[#text("Chris Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("All of the modelling so far has missed a key point: the optimal time to tie your shoe lace is when your shoe lace comes undone. That is unless the paramedics, having unmangled your leg from the walkway, can somehow get you to your final destination faster than all of the walking and running…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e16bbd9e1cfaa3e6f40c28e6305bb870846f7ade5622c34d1d33b6635bfdd7f0-274d9fb2bb9aa300f11c1c5f18d0fe81abdf8148009fe8c8ab0690bd9d4ac90e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An Economist")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33982")[#strong[#text("An Economist")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Hey, I’m an economist, and I got the right answers to 1 and 2 in my head in less than 15 seconds.")

#text("My intuition for both questions: Holding fixed the durations of walking, running, and standing still, you would want to spend as much *time* on the walkways as possible so as to get the most benefit from them. So you should do your standing still on the walkways and your running on the ground.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1021184a6da538d9142ac83d34cba06cabd2a6007c7f07890004fc0cedb579-569fd4c4f70a8d551d019c6ee1379e2f3bd35638af37751bf1a30bc521803a76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasha")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33985")[#strong[#text("Jasha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("The economist commenting before me is of course enirely right, but I have to admit that I first got it wrong and needed actually more than 15 seconds. My (lame) excuse for this is that question 3 kind of implied that in question 1 and 2 it would not matter what way you do it because otherwise question 3 makes no sense. Once you realize that closing your shoes on the walkway respectively avoiding running faster there will allow you to spend more time on the walkway and getting the help of the extra speed you make there for a longer time the question is really trivial. Makes me kind of feeling superior that even very smart Mathematicians make mistakes as soon as they try to get even the simplest applications right. This makes you also wonder if recent financial turmoil might have something to do with investment banks hiring too many PHDs in Physics and Mathematics in recent years.")

#text("Jasha, economist")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/comment-page-1/#comment-33993")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I generally dislike when mathematicians claim that they are, as a whole, intellectually superior to other types of scientists, and I usually have a healthy respect for economists… but I can’t help but say that the article linked by Noah above")

#link("http://www.slate.com/id/2070182/")[#text("http://www.slate.com/id/2070182/")]

#text("is a serious embarrassment for economics as a science. The reason that it’s embarrassing is that if respected professional economists have trouble seeing the logical flaw in the “paradox,” then it frightens me to think about what logical errors are being ignored in their papers.")

#text("And yes, I realize that the problem in the Slate article was phrased differently than it was in this blog.")

#text("@Jasha: You said, “Makes me kind of feeling superior that even very smart Mathematicians make mistakes as soon as they try to get even the simplest applications right.” And to which “very smart Mathematicians” are you referring? Please point me to an incorrect answer posted by a mathematician. Your previous post seems to suggest that Professor Tao doesn’t know the correct answer to his own question. That suggestion would be funny if it weren’t so appalling.")
]
