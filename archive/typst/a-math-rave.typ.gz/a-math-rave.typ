// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/11/18/a-math-rave/
// Converted to Typst by tao2typ: "2026-10-14T15:20:41.851047+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A math rave", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A math rave")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 November 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/")[#text("https://terrytao.wordpress.com/2021/11/18/a-math-rave/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As math educators, we often wish out loud that our students were more excited about mathematics. I finally came across a video that indicates what such a world might be like:")

#align(center)[

]

#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bd655ca75a3788d862e6d802bb8f3f0f523b638ac2fd7583e4579ab55f4caaa-d9f778b2e8dd8a07b732791e668f22883684cf312c292d9b8b0c6c2683be8538.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goldston")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637185")[#strong[#text("Daniel Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("That graph looks more like y= cos( Pi x)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Savitha")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637187")[#strong[#text("Savitha")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Funny!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0294d933df36a41ccf093f3aa51c2871c09d90fe74122b89b84100af6572448d-9e1c808e0cec5e9b34094623ef1f509d45b7de0012c99b795703fcb40e417309.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ThiKu")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637188")[#strong[#text("ThiKu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Seems to be in Korea.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff97a7210d23d0081538bae6a39526288b39c340c3f493a8fb1512856e3e7c25-6c4ba205fa41e98e0776bb586d35f8b511c91bb2e4fc4f481cd1a4762c97271a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hhan")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637195")[#strong[#text("Hhan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Yeah it’s Korean event and held in a famous club Octagon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637189")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("There is an extended version here: ")#link("https://www.youtube.com/watch?v=kRFTmJkfeks")[#text("https://www.youtube.com/watch?v=kRFTmJkfeks")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("They desperately need to convert to polar coordinates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cb2df646ac1407976594ffe64fa76c53085d44411147fa38fc74421e146688e-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sang-il Oum")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637191")[#strong[#text("Sang-il Oum")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Funny! Another reason to visit Korea again? ;-)")#linebreak()#text(" After some search, I found a longer version:")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Haha, I like it. Thanks Terry :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9630deb7993790d9468db6f8947b171968c44c301b6076c8949e719f716d1ca-6270b06cc7ef82280cbd9ee019be4465a0b202b5d148f53a1daeacbc8da5fba2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maverick S H Oh")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637193")[#strong[#text("Maverick S H Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Hello! Thank you for your interest!")

#text("This happened at the Club Octagon, South Korea, Dec 22, 2021. It was supported and run by KOFAC (government science foundation) and science communicators in the organization. I was one of the science communicators and I contributed on making the background video. We had many other performances/activities too but this video went viral the most 😄")

#text("Let me know if you have any questions. Thanks again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c25cda3f267aa861474475f3800923df97eda9fa4d5d8aa8f081ea45659ebed0-225e00ff066b56849df393cabe796189ae8f925c7b2ee92866e7e74e2b6fae2b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Huynh")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637196")[#strong[#text("Tony Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("I assume you mean Dec 22, 2018? Or is this a clip from the future?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9630deb7993790d9468db6f8947b171968c44c301b6076c8949e719f716d1ca-6270b06cc7ef82280cbd9ee019be4465a0b202b5d148f53a1daeacbc8da5fba2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maverick S. H. Oh")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637197")[#strong[#text("Maverick S. H. Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("Ah yeah thanks! It was 2018. I made a critical typo XD… Idk if I can edit my comment. Thanks :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2021")])]

#text("can you supply another website which I can open from the mainland of PRC，thanks~")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9630deb7993790d9468db6f8947b171968c44c301b6076c8949e719f716d1ca-6270b06cc7ef82280cbd9ee019be4465a0b202b5d148f53a1daeacbc8da5fba2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maverick Sang-Hyun Oh")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637218")[#strong[#text("Maverick Sang-Hyun Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("I do not know of the Chinese restrictions and availability. I guess VPN would help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2021")])]

#text("yes，I think it will be helpful～")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-685021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Hi Maverick,")

#text("would be any possibility of getting a copy of the background video/music to recreate this with my students?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637213")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("Speaking about math excitement, would you consider am academic publication; the by number theory algorithm of human immortality?")#linebreak()#text(" ")#link("https://sites.math.rutgers.edu/~zeilberg/")[#text("https://sites.math.rutgers.edu/~zeilberg/")]#linebreak()#text(" In the the Links option,")#linebreak()#text(" “another masterpiece by Emmanuel Xagorarakis”")#linebreak()#text(" ")#link("http://sites.math.rutgers.edu/~zeilberg/akherim/Xagorarakis19.doc")[#text("http://sites.math.rutgers.edu/~zeilberg/akherim/Xagorarakis19.doc")]

#text("Thanks,")#linebreak()#text(" Emmanuel Xagorarakis")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637277")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("Please read the academically published paper before you give a downvote. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637314")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2021")])]

#text("Here it is in pdf.")#linebreak()#text(" “The Singularity Algorithm of Human Vs Computer and the Binary Code for the Quantum Computer”")

#link("http://www.sorites.org/room/Xagorarakis_Decimal%20System-Singularity(5).pdf")[#text("Click to access Xagorarakis_Decimal%20System-Singularity(5).pdf")]

#text("From the proud Greece,")#linebreak()#text(" E. Xagorarakis")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637351")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2021")])]

#text("I really don’t think I have many downvotes since I’m the outcast here. Immortality and the algorithm of it; go figure…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637449")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2021")])]

#text("I somehow enjoy getting downvotes here. Thanks!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Jung")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637217")[#strong[#text("Paul Jung")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("I’m glad that the Gaussian distribution made the cut. It’s apparently as important as cos(x) and more important than sin(x). By the way, that part in korean in the middle was saying quadrant 1,2,3,4…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("Stupid. A bunch of jerks jumping up and down. It is not music, it is not math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("Someone is sad and jealous")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("I hope that this post is meant to be only a joke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/780c779ae277cd22e08eb84867ab9424c5b6ae0dbffb60a05ae07e7bb5e22b9f-101d74cb4d7a8c42d89c4b3cf2fee3f67206a6b53f363482529d5c3f97522f30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trivia")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637278")[#strong[#text("Trivia")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("Very mature")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2021")])]

#text("Exitement = maturity")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637353")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2021")])]

#text("This is an outstanding move from professor Terence Tao. But for me personally, it cannot beat this:")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637358")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2021")])]

#text("There is also a music band by the name “Axiom of Choice”. Although I did not hear many songs by them but the ones’ I heard I could not relate to the axiom of choice or anything related to axiomatic set theory, but I think there should be some connection or some musician was just too excited by the axiom of choice and started a music band by this name. ")#link("https://en.wikipedia.org/wiki/Axiom_of_Choice_(band)")[#text("https://en.wikipedia.org/wiki/Axiom_of_Choice_(band)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637388")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2021")])]

#text("Not sure where to post this, but apprently google stole your tab name:")#linebreak()#text(" chrome://whats-new/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637451")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2021")])]

#text("Would you consider a free ebook of mine, on the Foundations of Mathematics:")#linebreak()#text(" ")#link("http://www.saitabooks.eu/2015/01/ebook.134.html?m=1")[#text("http://www.saitabooks.eu/2015/01/ebook.134.html?m=1")]#linebreak()#text(" It is ground-braking.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1a5bbf996e2a3381a8b71b000d807b6bcc259e074542105c98d5c29f372308-f7db822e4330f77d4f80a25fc44b009af95f160863ce28cd9a8b21da908abd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Xagorarakis")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637956")[#strong[#text("Emmanuel Xagorarakis")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2021")])]

#text("Thanks for downvoting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2021")])]

#text("Which kind of excitement is really needed to study mathematics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094a4b0ea10c8a79603bb15dab337bd836189265619e0529f7df2e8f34e73026-a474236d5e2a3ea4357ee49e7361f6e112ec96939d507c923e4b2907a09ea431.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lincui")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637546")[#strong[#text("lincui")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Hey, Terence. Being a mathematics professor at UCLA is so lucrative.")#linebreak()#text(" I dream of having as much knowledge as you do, then I will have plenty of money.")#linebreak()#text(" I grew up in a destitute family which even cannot provided me enough food in my childhood.")#linebreak()#text(" How I wish I could understand advanced mathematics as you do…")#linebreak()#text(" Knowledge is money…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/292093866bb619e92430b1b9ad1690d761716f7a389eaa8d5ffb06ec2f2c7581-40081926ba61117a47c439e071dfdae97c22aa00e70f6eea5c3e9fc35d23f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lincui")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637547")[#strong[#text("lincui")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Hey, Terence. How can I understand as much of mathematics as you do?")#linebreak()#text(" My parents’ yearly income totally is less than 15,000 dollars.")#linebreak()#text(" If I can become a mathematics professor at Yale University, I will earn at least 150,000 dollars per year.")#linebreak()#text(" Which is ten times as much as my parents’ total income…")#linebreak()#text(" I cannot wait having a Ph.D degree in mathematics and to get income from mathematics knowledge…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("keep dreaming!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a5cfb58df244822f5d12e3f3e9d646010ea894a46bbf0729660fcd799702bb8-ad09e718a57ab67ef709dd945d8c87195fc982d894fe8b4256e20cbbb7cbb3fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CUILIN")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637549")[#strong[#text("CUILIN")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Terence, I have an old friend who was born in 1953 and who has a Ph.D degree in philosophy from Harvard. I dream of having a Ph.D degree from schools like Harvard as well. But not in humanities, I want to have a Ph.D degree in mathematics…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebe4d927239975a29ca6ddbad699586e827dc6211f15bc1974592b30891f90cb-1cbc7701c636951d25ac62626b1ff54b66c2f202865c3f13caa69bfc2170a7dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CUI LIN")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637572")[#strong[#text("CUI LIN")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Hey, Terence. My life ambition is to be 3 times more intelligent and more knowledgable than you. I will give up all my life enjoyments and pleasures in order to realize this dream and ambition…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("You will never pass Terry, even if you are a cat with nice lives. Intelligence and knowledge can’t be quantified.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-637748")[#strong[#text("A math rave by Terrence Tao | bredrindeacon's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2021")]

#text("[…] A math rave […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a85e534696ef6a0b6a5de0f1f3f2b205d025b177f4c552a5cde01e8ac58998c-a21243e72d71594e72e6ae5e24a36cb646d0820c1842d239a68e887d4d7403c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A math rave – Mathematics, for all Mankind!")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-638094")[#strong[#text("A math rave – Mathematics, for all Mankind!")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2021")])]

#text("[…] A math rave […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MyMathYourMath")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-638095")[#strong[#text("MyMathYourMath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2021")])]

#text("From one math educator to another could you follow my math education YouTube channel @MyMathYourMath")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-638173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2021")])]

#text("Russia turned off its internet for the months of June/July to test out a new Chinese/Iranian style firewall. Now it’s demanding that all of the major US technology companies relocate an HQ to Russia. It’s not correct to let Russia dictate US behavior by showing a weapon. Game theorists, begin calculating!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7330559041d5327ce92e39736fa1aae730a4381cf4573fc9c09d0d538e822717-944f2a1ffb1ecd8363ce4eb03e4f12a22e30a12d638a2c4b4347653dd0ffa143.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wenhan xie")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-638651")[#strong[#text("wenhan xie")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2021")])]

#text("Dear Professor tao，what do you think of Bourbaki？")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/18/a-math-rave/#comment-688294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2025")])]

#text("Hello, you’ve made a song named Giga Society, is it possible to get it somewhere ?")

#emph[#text("[Contrary to some information on the internet, I have no connection with this song. -T]")]
]
