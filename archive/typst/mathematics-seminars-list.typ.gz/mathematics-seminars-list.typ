// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/
// Converted to Typst by tao2typ: "2026-10-14T10:59:16.725864+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics Seminars List", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics Seminars List")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 April 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/")[#text("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My student, ")#link("https://www.math.ucla.edu/people/grad/jdedios")[#text("Jaume de Dios")]#text(", has set up ")#link("http://jaume.dedios.cat/math-seminars/")[#text("a web site")]#text(" to collect upcoming mathematics seminars from any institution that are open online. (For instance, it has a talk that I will be giving in an hour.) There is a form for adding further talks to the site; please feel free to contribute (or make other suggestions) in order to make the seminar list more useful.")

#text("UPDATE: Here are some other lists of mathematical seminars online:")

#list(
[#link("http://math.mit.edu/~aosun/online_seminars.html")[#text("Online seminars")]#text(" (curated by Ao Sun and Mingchen Xia at MIT)")],
[#link("http://dermenjian.com/seminars/")[#text("Algebraic Combinatorics Online Seminars")]#text(" (maybe using the same data set as the preceding link?)")],
[#link("https://s.wayne.edu/isaksen/online-mathematics-seminars/")[#text("Online mathematics seminars")]#text(" (curated by Dan Isaksen at Wayne State University)")],
[#link("https://mathseminars.org/")[#text("Math seminars")]#text(" (run by Edgar Costa and David Roe at MIT)")]
)

#text("Perhaps further links of this type could be added in the comments. It would perhaps make sense to somehow unify these lists into a single one that can be updated through crowdsourcing.")

#text("EDIT: See also IPAM’s ")#link("https://www.ipam.ucla.edu/news/running-virtual-seminars-a-mathematicians-guide/")[#text("advice page on running virtual seminars")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-550937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("Thanks for today’s talk: ")#link("https://terrytao.files.wordpress.com/2020/04/collatz.pdf")[#text("https://terrytao.files.wordpress.com/2020/04/collatz.pdf")]

#text("I find this set of slides more accessible:")

#link("https://terrytao.files.wordpress.com/2020/02/collatz.pdf")[#text("Click to access collatz.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-550956")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("For a could of weeks already there’s been an excellent page at MIT, maintained by students Ao Sun and Mingchen Xia.")

#link("https://math.mit.edu/~aosun/online_seminars.html")[#text("https://math.mit.edu/~aosun/online_seminars.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c1cf6702093972106d4355d3436ba378ee870e2e6a64ed64addae622cf1efe-722da0096ba8d8c90108df270f0c422e927b95c2aa613a1f88962ed4968409f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asgar")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-550966")[#strong[#text("Asgar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("Here is a link to the One World Probability Seminar (which has also links to other math related One World Seminars) ")#link("https://www.wim.uni-mannheim.de/doering/one-world/")[#text("https://www.wim.uni-mannheim.de/doering/one-world/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288aec238adc0b32df98cab5af571a2dc982a5d0fb6cd488400a0a0187fdaf2e-0328b77df668c75b3b45e609ea18039dc2c8be1cd32cbe278508cceed3ee2b83.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Anil Pedgaonkar")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551010")[#strong[#text("Dr. Anil Pedgaonkar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("but when and where nis your online seminar. we clicked the link it gives website. we wanted your seminar today")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54f31a49f4fe62530815643e5d263d40ce1bb856288d7eab6a30a5a46e88f6d7-a29f3f97212412cd3fd164ea4c06399a86937592ed6ef6669fbd64ffcddd4da4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Becky")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551019")[#strong[#text("Becky")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Thank you for the links!")#linebreak()#text(" All the best from Germany, Becky")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd366d60058a5a463c592880db8bcad746981d9cf730e5e200b2aa3963f3eb6a-8cd11ef2cf4d09d96bc08e5ac907ccc87b4f84cbadc84a240767b5f7fbc22aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551024")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Hi! There is a list of logic seminars at ")#link("http://miguelmath.com/webminars.html")[#text("http://miguelmath.com/webminars.html")]#linebreak()#text(" Best wishes,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f26a2d0289ddde1a4e44394a28e7d9a66f2b65b1eec97dc63a9404b3331dae-e9a8a246cbd2478017fcf1c118a96323fc2115ee572d531e98341d0f700f9eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ndwork")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551025")[#strong[#text("ndwork")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("This is great! Thank you! There seems to be an issue where 3pm eastern becomes 0pm pacific, which is midnight.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb0c29dac5c7c2999792e1a2015aff6d5eaff78014e4324deec42500540084-9db649c739c9a1f9c57cdf4cdd3dc17db5ef7d333d3479dafef3c3704c0f47b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaume")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551051")[#strong[#text("Jaume")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Thanks for catching this! I’ll have a look")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb0c29dac5c7c2999792e1a2015aff6d5eaff78014e4324deec42500540084-9db649c739c9a1f9c57cdf4cdd3dc17db5ef7d333d3479dafef3c3704c0f47b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaume")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551054")[#strong[#text("Jaume")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("I think I solved it, there was a bug on the code I was using to translate the time to the user local time, do you still see the issue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f26a2d0289ddde1a4e44394a28e7d9a66f2b65b1eec97dc63a9404b3331dae-e9a8a246cbd2478017fcf1c118a96323fc2115ee572d531e98341d0f700f9eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ndwork")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551065")[#strong[#text("ndwork")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Looks good now!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ce696ef79e2ba743a9916d4fab3a3ce0b2f3e74d431c9ee0d63f3ae0356622-364c90c675d584f7e6f91e97cc231db2864737b215a2c843bb8b9a385c285d10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonid Petrov")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551039")[#strong[#text("Leonid Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("There is a list of online probability seminars curated by Columbia people")

#link("http://www.math.columbia.edu/department/probability/seminar/prob_sem_global.html")[#text("http://www.math.columbia.edu/department/probability/seminar/prob_sem_global.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0b5a55374c29a09774d628fd0a6ac37c9b6f37204ad232705b29593c10e7bd9-659889994de7e167c6106f048d1829bfe736e34a6d7d9be46c05f9a1752dfab6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551067")[#strong[#text("Manuel")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Yet another list on statistical seminars:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://statisfaction.wordpress.com/remote-seminars/")[#text("Remote seminars")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7cfd468247c68ad5e1ffb1ae0c09428aa99ccb3274ea5baa753e0cd81c9950d-8935be1d94e494961057c049f225aa61ab14ad9706389cab3e768aff388a7f74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bunyamin Sari")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551087")[#strong[#text("Bunyamin Sari")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Banach spaces webinars on Fridays at 9AM CDT")

#link("http://www.math.unt.edu/~bunyamin/banach")[#text("http://www.math.unt.edu/~bunyamin/banach")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b4a1c26001d9306c3dddd8069aa2850e348def74d0fc339be82e6b790e9125a-ada560f8efcf397b4d37dd7fe92e73b223b21e98053be0005dfe0cdbc016fe44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aurel Page")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551359")[#strong[#text("Aurel Page")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")])]

#text("Here is another one: ")#link("https://mathseminars.org/")[#text("https://mathseminars.org/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-551610")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("+1 for ")#link("https://mathseminars.org/")[#text("https://mathseminars.org/")]#text(". This site is based on an open-source project intended to facilitate crowd-sourced seminar listings (both virtual and physical). Anyone can create listings for seminars or conferences, either as an organizer or as a curator. These listings will automatically appear once the individual has been endorsed (similar to arXiv endorsing). The goal is to distribute the task of maintaining up to date listings as broadly as possible.")

#text("When browsing talks and seminars, you can filter by topic or institution, tag your favorite talks or seminars, and export to your calendar (new talks in a seminar you have subscribed to will automatically show up in your calendar).")#linebreak()#text(" Times are automatically translated to your local time zone.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b83a5bcd3cfbd3197517da804244ff1c4efe35c179a7afda416081442e5d2973-3d292328ef8dbf5c4dd00be2dc2cb8138d906bf6a45bac2ee55375992bfe5a70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xi'an")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-552906")[#strong[#text("xi'an")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("We have started the ")#link("https://warwick.ac.uk/fac/sci/statistics/news/upcoming-seminars/abcworldseminar/")[#text("ABC World Seminar")]#text(", every other Friday at 11:30, UK time. (ABC stands for approximate Bayesian computation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13dc002096ff123559d143960e66a35b938fa746049b1663d0dce7aa0740d441-50659db8e33efe894485a6019676f8ceac3e3c40886cc9169b3dc6743ccfe889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Wong")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-555963")[#strong[#text("Alexander Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("The seminar list under Jaume de Dios does not work. Please fix, thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb0c29dac5c7c2999792e1a2015aff6d5eaff78014e4324deec42500540084-9db649c739c9a1f9c57cdf4cdd3dc17db5ef7d333d3479dafef3c3704c0f47b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaume")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-555998")[#strong[#text("Jaume")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("Hi! I’m working on it, it seems there was an issue with the renewal of my domain. In the meantime (and in the future) it’s better to use mathseminars.org anyways, since it currently does have more information. Sorry about it!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7f848ae771f5e3500d55345328411cb7ec49a4999caa2b781c3594802717df1-7f40345c9d16a200fbb4ad0988f17672fdf2eabcfce6186275d68819b4f24582.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rooykard rooykard")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-556468")[#strong[#text("Rooykard rooykard")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Reblogged this on ")#link("https://wwwjonbshkhalgh.wordpress.com/2020/05/01/mathematics-seminars-list/")[#text("http://www.jonbeshkhalgh.com")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a5b5d3495b7cf3fdcf222ed41d4159b151bbb54e4db6707e3942f4028dad9b-da354247deb2a4d904516c4dedccb5b97260d3dff5dcd1b7eeed4f3a07fe1a18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sai Gopal")]], [#link("https://terrytao.wordpress.com/2020/04/07/mathematics-seminars-list/#comment-626099")[#strong[#text("Sai Gopal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")])]

#text("This is certainly a great help! Otherwise, earlier I had to go on to the websites of some of these institutes and then check out if there are any upcoming seminars. This idea of collecting all information at one place is a noble thought.")
]
