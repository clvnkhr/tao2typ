// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/
// Converted to Typst by tao2typ: "2026-10-14T16:35:27.461982+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on “non-classical” polynomials in finite characteristic", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on “non-classical” polynomials in finite characteristic")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("k \\geq 0")#text(" be an integer. The concept of a polynomial ")#mi("P: {\\Bbb R} \\to {\\Bbb R}")#text(" of one variable of degree ")#mi("<k")#text(" (or ")#mi("\\leq k-1")#text(") can be defined in one of two equivalent ways:")

#list(
[#text("(Global definition) ")#mi("P: {\\Bbb R} \\to {\\Bbb R}")#text(" is a polynomial of degree ")#mi("<k")#text(" iff it can be written in the form ")#mi("P(x) = \\sum_{0 \\leq j < k} c_j x^j")#text(" for some coefficients ")#mi("c_j \\in {\\Bbb R}")#text(".")],
[#text("(Local definition) ")#mi("P: {\\Bbb R} \\to {\\Bbb R}")#text(" is a polynomial of degree ")#mi("<k")#text(" if it is k-times continuously differentiable and ")#mi("\\frac{d^k}{dx^k} P \\equiv 0")#text(".")]
)

#text("From single variable calculus we know that if P is a polynomial in the global sense, then it is a polynomial in the local sense; conversely, if P is a polynomial in the local sense, then from the Taylor series expansion")

#align(center)[#tao-fit-display[#mitex("P(x) = \\sum_{0 \\leq j < k} \\frac{P^{(j)}(0)}{j!} x^j")]]

#text("we see that P is a polynomial in the global sense. We make the trivial remark that we have no difficulty dividing by ")#mi("j!")#text(" here, because the field ")#mi("{\\Bbb R}")#text(" is of characteristic zero.")

#text("The above equivalence carries over to higher dimensions:")

#list(
[#text("(Global definition) ")#mi("P: {\\Bbb R}^n \\to {\\Bbb R}")#text(" is a polynomial of degree ")#mi("<k")#text(" iff it can be written in the form ")#mi("P(x_1,\\ldots,x_n) = \\sum_{0 \\leq j_1,\\ldots,j_n; j_1+\\ldots+j_n < k} c_{j_1,\\ldots,j_n} x_1^{j_1} \\ldots x_n^{j_n}")#text(" for some coefficients ")#mi("c_{j_1,\\ldots,j_n} \\in {\\Bbb R}")#text(".")],
[#text("(Local definition) ")#mi("P: {\\Bbb R}^n \\to {\\Bbb R}")#text(" is a polynomial of degree ")#mi("<k")#text(" if it is k-times continuously differentiable and ")#mi("(h_1 \\cdot \\nabla) \\ldots (h_k \\cdot \\nabla) P \\equiv 0")#text(" for all ")#mi("h_1,\\ldots,h_k \\in {\\Bbb R}^n")#text(".")]
)

#text("Again, it is not difficult to use several variable calculus to show that these two definitions of a polynomial are equivalent.")

#text("The purpose of this (somewhat technical) post here is to record some basic analogues of the above facts in finite characteristic, in which the underlying domain of the polynomial P is F or ")#mi("F^n")#text(" for some finite field F. In the “classical” case when the range of P is also the field F, it is a well-known fact (which we reproduce here) that the local and global definitions of polynomial are equivalent. But in the “non-classical” case, when P ranges in a more general group (and in particular in the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text("), the global definition needs to be corrected somewhat by adding some new monomials to the classical ones ")#mi("x_1^{j_1} \\ldots x_n^{j_n}")#text(". Once one does this, one can recover the equivalence between the local and global definitions.")

#text("(The results here are derived from forthcoming work with Vitaly Bergelson and Tamar Ziegler.)")

#metadata(none) <tao-ef28ddaa301fc0332a7f>

#heading(level: 1)[#text("— General theory —")]

#text("One can extend the local definition of a polynomial to cover maps ")#mi("P: G \\to H")#text(" for any additive groups G, H. (There is also an important generalisation of this concept to the case of nilpotent groups; we will not concern ourselves with this generalisation here, but see ")#link("http://www.ams.org/mathscinet-getitem?mr=1608723")[#text("this paper of Leibman")]#text(" [as well as this ")#link("http://www.ams.org/mathscinet-getitem?mr=1910931")[#text("followup paper")]#text("].) Given any such map, and any ")#mi("h \\in G")#text(", define the shift ")#mi("T^h P: G \\to H")#text(" and the (discrete) derivative ")#mi("\\Delta_h P: G \\to H")#text(" by the formulae")

#align(center)[#mi("T^h P(x) := P(x+h); \\Delta_h P = T^h P - P")#text(",")]

#text("thus schematically we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Delta_h = T^h - 1.")]]

#text("We say that P is an ")#emph[#text("(additive) polynomial of degree ")#mi("<k")]#text(" (or degree ")#mi("\\leq k-1")#text(") if ")#mi("\\Delta_{h_1} \\ldots \\Delta_{h_k} P = 0")#text(" for all ")#mi("h_1,\\ldots,h_k \\in G")#text(". Note that this corresponds to the definition of a classical polynomial from ")#mi("{\\Bbb R}^n")#text(" to ")#mi("{\\Bbb R}")#text(" once one adds some regularity conditions, such as k-times differentiability (actually, measurability will already suffice).")

#strong[#text("Examples 1.")]#text(" The zero function has degree ")#mi("<0")#text(". A constant function has degree ")#mi("\\leq 0")#text(". A homomorphism has degree ")#mi("\\leq 1")#text(". Composing a polynomial of degree ")#mi("\\leq k")#text(" with a homomorphism (either on the left or right) will give another polynomial of degree ")#mi("\\leq k")#text(". The sum of two polynomials of degree ")#mi("\\leq k")#text(" is again of degree ")#mi("\\leq k")#text(". The derivative ")#mi("\\Delta_h P")#text(" of a polynomial of degree <k is of degree <k-1. Since ")#mi("T^h P = P + \\Delta_h P")#text(", we conclude that the shift of any polynomial of degree <k is also of degree <k. ")#mi("\\diamond")

#text("Now we show that the product and composition of polynomials is again a polynomial.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Product of polynomials is again polynomial) Let ")#mi("P: G \\to H, Q: G \\to K")#text(" be polynomials of degree ")#mi("\\leq h")#text(", ")#mi("\\leq k")#text(" respectively for some ")#mi("h,k \\geq 0")#text(", and let ")#mi("B: H \\times K \\to L")#text(" be a bilinear map. Then ")#mi("B(P,Q)")#text(" is a polynomial of degree ")#mi("\\leq h+k")#text(".")
]

#strong[#text("Proof. ")]#text(" We induct on h+k. The claim is easy when h or k is zero, so suppose that ")#mi("h,k > 0")#text(" and the claim has already been proven for smaller values of h+k. From the discrete product rule")

#align(center)[#tao-fit-display[#mitex("\\Delta_g B(P,Q) = B( \\Delta_g P, Q ) + B( T^g P, \\Delta_g Q )")]]

#text("and induction we see that ")#mi("\\Delta_g B(P,Q)")#text(" is of degree ")#mi("\\leq h+k-1")#text(", and thus ")#mi("B(P,Q)")#text(" has degree ")#mi("\\leq h+k")#text(" as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("If H is a ring, then the product of two polynomials from G to H of degree ")#mi("\\leq h, \\leq k")#text(" respectively is of degree ")#mi("\\leq h+k")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Composition of polynomials is again polynomial) Let ")#mi("P: G \\to H, Q: H \\to K")#text(" be polynomials of degree ")#mi("\\leq h, \\leq k")#text(" respectively for some ")#mi("h,k \\geq 0")#text(". Then ")#mi("Q \\circ P: G \\to K")#text(" is a polynomial of degree ")#mi("\\leq hk")#text(".")
]

#strong[#text("Proof. ")]#text("For inductive reasons it is convenient to prove the following more general statement: if ")#mi("P: G \\to H, Q: H \\to K")#text(" are polynomials of degree ")#mi("\\leq h+m, \\leq k")#text(" respectively for some ")#mi("m,h,k \\geq 0")#text(", and ")#mi("R_1,\\ldots,R_m: G \\to H")#text(" are polynomials of degree ")#mi("\\leq r_1,\\ldots,\\leq r_m")#text(" respectively, where ")#mi("0 \\leq r_j \\leq k")#text(" for all j, then the function ")#mi("S: G \\to K")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("S(x) := [\\Delta_{R_1(x)} \\ldots \\Delta_{R_m(x)} P]( Q(x) )")]]

#text("is a polynomial of degree ")#mi("hk+r_1+\\ldots+r_m")#text(". Clearly Lemma 2 follows from the ")#mi("m \\geq 0")#text(" case of this claim.")

#text("We prove this claim by induction on h, then for fixed h by induction on m, then for fixed h and m by induction on ")#mi("r_1+\\ldots+r_m")#text(". Thus, assume that the claim has already been shown for all smaller values of h, or for the same value of h and all smaller values of m, or for the same values of h,m and all smaller values of ")#mi("r_1+\\ldots+r_m")#text(".")

#text("If ")#mi("r_m=0")#text(" then ")#mi("R_m")#text(" is constant, and by replacing P with ")#mi("\\Delta_{R_m} P")#text(" and decrementing m, we see that the claim follows from the induction hypothesis. Similarly if any other of the ")#mi("r_j")#text(" vanish (since the derivative operators commute with each other). So we may assume that ")#mi("r_j > 0")#text(" for all j.")

#text("Let g in G. By considering the successive differences between the quantities")

#align(center)[#tao-fit-display[#mitex("S(x) = [\\Delta_{R_1(x)} \\Delta_{R_2(x)} \\ldots \\Delta_{R_m(x)}]( Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{R_1(x)} \\Delta_{R_2(x)} \\ldots \\Delta_{R_m(x)}]( T_g Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{T_g R_1(x)} \\Delta_{R_2(x)} \\ldots \\Delta_{R_m(x)}]( T_g Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{T_g R_1(x)} \\Delta_{T_g R_2(x)} \\ldots \\Delta_{R_m(x)}]( T_g Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("\\vdots")]]

#align(center)[#tao-fit-display[#mitex("T_g S(x) = {}[\\Delta_{T_g R_1(x)} \\Delta_{T_g R_2(x)} \\ldots \\Delta_{T_g R_m(x)}]( T_g Q(x) ),")]]

#text("we see that ")#mi("\\Delta_g S(x)")#text(" is the sum of")

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{R_1(x)} \\Delta_{R_2(x)} \\ldots \\Delta_{R_m(x)} \\Delta_{\\Delta g Q(x)} P]( Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{\\Delta_g R_1(x)} \\Delta_{R_2(x)} \\ldots \\Delta_{R_m(x)}]( R_1(x) + T_g Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{T_g R_1(x)} \\Delta_{\\Delta_g R_2(x)} \\ldots \\Delta_{R_m(x)} \\Delta_g]( R_2(x) + T_g Q(x) )")]]

#align(center)[#tao-fit-display[#mitex("\\vdots")]]

#align(center)[#tao-fit-display[#mitex("{}[\\Delta_{T_g R_1(x)} \\Delta_{T_g R_2(x)} \\ldots \\Delta_{\\Delta_g R_m(x)} \\Delta_g]( R_m(x) + T_g Q(x) ).")]]

#text("By the induction hypothesis, each of these terms are polynomials of degree ")#mi("\\leq hk+r_1+\\ldots+r_m-1")#text(". The claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("— The classical case —")]

#text("Now we consider polynomials taking values in a finite field F.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3.")]#text(" (Global description of classical one-dimensional polynomials) Let F be a field of prime order p. For any ")#mi("k \\geq 0")#text(", a function ")#mi("P: F \\to F")#text(" is of degree ")#mi("<k")#text(" if and only if we can expand ")#mi("P(x) = \\sum_{0 \\leq j < k} c_j x^j")#text(" for some coefficients ")#mi("c_j \\in F")#text("; this expansion is unique for ")#mi("k \\leq p")#text(". Also, every function ")#mi("P: F \\to F")#text(" is a polynomial of degree <p.")
]

#strong[#text("Proof. ")]#text(" The “if” portion of the lemma follows from Corollary 1 (since the identity function ")#mi("x \\mapsto x")#text(" is clearly of degree ")#mi("\\leq 1")#text("). For the “only if” part, observe from the binomial identity")

#align(center)[#tao-fit-display[#mitex("T^h = (1 + \\Delta_1)^h = \\sum_{j=0}^h \\binom{h}{j} \\Delta_1^j")]]

#text("for any non-negative integer h, that")

#align(center)[#tao-fit-display[#mitex("f(h) = \\sum_{j=0}^h \\binom{h}{j} \\Delta_1^j f(0).")]]

#text("Since ")#mi("h \\mapsto \\binom{h}{j} = \\frac{h(h-1)\\ldots(h-j+1)}{j!}")#text(" can be meaningfully defined on F for ")#mi("0 \\leq j < p")#text(", we conclude in particular that ")#mi("f(h) = \\sum_{j=0}^{p-1} \\binom{h}{j} \\Delta_1^j f(0).")

#text("Since ")#mi("\\binom{h}{j}")#text(" can be expanded as a linear combination over F of ")#mi("1, h, \\ldots, h^j")#text(", we obtain the remaining claims in Lemma 3. (Note that as the space of functions from F to F is p-dimensional, and generated by ")#mi("1, x, \\ldots, x^{p-1}")#text(", these functions must be linearly independent.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" (Integration lemma) Let ")#mi("f: F \\to F")#text(" be a polynomial of degree ")#mi("\\leq k")#text(" for some ")#mi("0 \\leq k \\leq p-2")#text(", and let ")#mi("h \\in F \\backslash 0")#text(". Then there exists a polynomial ")#mi("P: F \\to F")#text(" of degree ")#mi("\\leq k+1")#text(" such that ")#mi("f = \\Delta_h P")#text(". (In particular, this implies the mean zero condition ")#mi("\\sum_{x \\in F} f(x) = 0")#text(". Conversely, any function ")#mi("f: F \\to F")#text(" with ")#mi("\\sum_{x \\in F} f(x) = 0")#text(" is a polynomial of degree ")#mi("\\leq p-2")#text(".")
]

#strong[#text("Proof. ")]#text("From Lemma 3, the space of polynomials of degree ")#mi("\\leq k")#text(" and ")#mi("\\leq k+1")#text(" is a vector space over F of dimension k+1 and k+2 respectively. The derivative operator ")#mi("\\Delta_h")#text(" is a linear transformation from the latter to the former with a one-dimensional kernel (the space of constants), and must therefore be surjective. The first claim follows. The second claim follows by a similar dimension counting argument. ")#mi("\\Box")

#text("We can iterate Lemma 3 to describe polynomials in higher dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4.")]#text(" (Global description of classical multi-dimensional polynomials) Let F be a field of prime order p, and let ")#mi("n \\geq 1")#text(". For any ")#mi("k \\geq 0")#text(", a function ")#mi("P: F^n \\to F")#text(" is of degree ")#mi("<k")#text(" if and only if we can expand ")#mi("P(x_1,\\ldots,x_n) = \\sum_{0 \\leq j_1,\\ldots,j_n: j_1+\\ldots+j_n < k} c_{j_1,\\ldots,j_n} x_1^{j_1} \\ldots x_n^{j_n}")#text(" for some coefficients ")#mi("c_{j_1,\\ldots,j_n} \\in F")#text(".")
]

#strong[#text("Proof. ")]#text(" As before, the “if” portion follows from Corollary 1, so it suffices to show the “only if” portion. But this follows by a multidimensional version of the analogous argument used to show Lemma 3, starting with the identity")

#align(center)[#tao-fit-display[#mitex("T^{(h_1,\\ldots,h_n)} = (1 + \\Delta_{e_1})^{h_1} \\ldots (1+\\Delta_{e_n})^{h_n}")]]

#text("for non-negative integers ")#mi("h_1,\\ldots,h_n")#text(", where ")#mi("e_1,\\ldots,e_n")#text(" is the standard basis of ")#mi("F^n")#text("; we leave the details to the reader. ")#mi("\\Box")

#strong[#text("Remark 2.")]#text(" The above discussion was for fields ")#mi("F = F_p")#text(" of prime order, but we can use these results to describe classical polynomials for fields ")#mi("F = F_{p^m}")#text(" of prime power order, by viewing any vector space over ")#mi("F_{p^m}")#text(" as a vector space over ")#mi("F_p")#text(". Of course, the resulting polynomials one obtains are merely polynomials over ")#mi("F_p")#text(", rather than over ")#mi("F_p^m")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— The non-classical case —")]

#text("Now we consider polynomials from F or ")#mi("F^n")#text(" into other additive groups, where ")#mi("F=F_p")#text(" is as before a field of prime order p. Thanks to Pontryagin duality, it suffices (in principle, at least) to consider polynomials taking values in the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". The first basic lemma is the following (taken from my forthcoming paper with Bergelson and Ziegler):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5.")]#text(" (Multiplication by p reduces degree) Let ")#mi("f: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" be of degree ")#mi("\\leq k+p-1")#text(" for some ")#mi("k\\geq 0")#text(". Then ")#mi("pf")#text(" is of degree ")#mi("\\leq k")#text(".")
]

#strong[#text("Proof.")]#text(" Since ")#mi("\\Delta_h (pf) = p \\Delta_h f")#text(" for any h, we see by induction that it suffices to show this lemma when k=0.")

#text("Let ")#mi("h \\in F^n")#text(". Raising (1) to the ")#mi("p^{th}")#text(" power we have")

#align(center)[#mi("T^{ph} = 1 + p \\Delta_h + \\frac{p(p-1)}{2} \\Delta_h^2 + \\ldots + p \\Delta_h^{p-1} + \\Delta_h^p")#text(".")]

#text("Of course, ")#mi("T^{ph} = 1")#text(". Applying this identity to f and noting that ")#mi("\\Delta_h^p f = 0")#text(" by hypothesis, we conclude that")

#align(center)[#mi("(1 + \\frac{p-1}{2} \\Delta_h + \\ldots + \\Delta_h^{p-2}) \\Delta_h (pf) = 0")#text(".")]

#text("Inverting ")#mi("(1 + \\frac{p-1}{2} \\Delta_h + \\ldots + \\Delta_h^{p-2})")#text(" using Neumann series (and the finite degree of f) we conclude that ")#mi("\\Delta_h(pf)=0")#text(" for all h, thus ")#mi("pf")#text(" has degree ")#mi("\\leq 0")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3.")]#text(" (Polynomials are discretely valued) If ")#mi("f: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" is of degree ")#mi("\\leq k")#text(", then after subtracting a constant from f, f takes values in the ")#mi("(p^{\\lfloor (k-1)/(p-1)\\rfloor+1})^{th}")#text(" roots of unity.")
]

#text("In one dimension, there is a converse to Lemma 5:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6.")]#text(" Let ")#mi("f: F \\to {\\Bbb R}/{\\Bbb Z}")#text(" be such that pf has degree ")#mi("\\leq k")#text(". Then f has degree ")#mi("\\leq k+p-1")#text(".")
]

#strong[#text("Proof. ")]#text("As in Lemma 5, it suffices to establish the case k=0. But this then follows from the last part of Lemma 3. ")#mi("\\Box")

#text("As a corollary we can classify all non-classical polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Global description of non-classical multi-dimensional polynomials) A function ")#mi("f: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" is a polynomial of degree ")#mi("<k")#text(" if and only if it has the form")

#align(center)[#tao-fit-display[#mitex("f(x) = c_0 + \\sum_{0 \\leq j_1,\\ldots,j_n \\leq p-1; m \\geq 1: j_1+\\ldots+j_n+(p-1)(m-1) < k}")]]

#align(center)[#tao-fit-display[#tao-math("c_{j_1,\\ldots,j_m,m} \\left|x_1\\right|^{j_1} \\ldots \\left|x_n\\right|^{j_n}/p^m", block: true)]]

#text("for some ")#mi("c_0 \\in {\\Bbb R}/{\\Bbb Z}")#text(" and ")#mi("c_{j_1,\\ldots,j_m,m} \\in \\{0,\\ldots,p-1\\}")#text(", where ")#tao-math("x \\mapsto \\left|x\\right|", block: false)#text(" is the obvious map from F to ")#mi("\\{0,\\ldots,p-1\\}")#text(".")
]

#strong[#text("Proof.")]#text(" The “if” part follows easily from Lemma 4 in the case ")#mi("k \\leq p")#text(", and then from Lemma 6 and induction in the general case. The “only if” part follows from Corollary 3 and Lemma 4 in the case ")#mi("k \\leq p")#text(". Now suppose inductively that ")#mi("k > p")#text(" and the claim has already been proven for smaller values of k. By Lemma 5 and the induction hypothesis, pf takes the form")

#align(center)[#tao-fit-display[#mitex("pf(x) = c^{\\prime}_0 + \\sum_{0 \\leq j_1,\\ldots,j_n \\leq p-1; m \\geq 1: j_1+\\ldots+j_n+(p-1)(m-1) < k-p+1}")]]

#align(center)[#tao-fit-display[#tao-math("c^{\\prime}_{j_1,\\ldots,j_n,m} \\left|x_1\\right|^{j_1} \\ldots \\left|x_n\\right|^{j_n}/p^m", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("f(x) = c_0 + \\sum_{0 \\leq j_1,\\ldots,j_n \\leq p-1; m \\geq 1: j_1+\\ldots+j_n+(p-1)(m-1) < k-p+1}")]]

#align(center)[#tao-fit-display[#tao-math("c^{\\prime}_{j_1,\\ldots,j_n,m} \\left|x_1\\right|^{j_1} \\ldots \\left|x_n\\right|^{j_n}/p^{m+1} + g(x)", block: true)]]

#text("where ")#mi("c_0")#text(" is a ")#mi("p^{th}")#text(" root of ")#mi("c^{\\prime}_0")#text(", and g takes values in ")#mi("p^{th}")#text(" roots of unity. Applying Lemma 4 to expand g in monomials, we obtain the claim. ")#mi("\\Box")

#text("As a corollary to this theorem we obtain a converse to Lemma 5:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4.")]#text(" (")#mi("p^{th}")#text(" roots of minimal degree) Let ")#mi("f: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" be of degree ")#mi("\\leq k")#text(" for some ")#mi("k\\geq 0")#text(". Then there exists ")#mi("g: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" of degree ")#mi("\\leq k+p-1")#text(" such that ")#mi("pg=f")#text(".")
]

#text("Interestingly, there does not seem to be a way to establish this theorem without going through a global classification theorem such as Theorem 1.")

#text("Another corollary to Theorem 1 is that any function from a finite dimensional vector space ")#mi("F^n")#text(" to a ")#mi("p^m")#text("-torsion group for some m will be a polynomial of finite degree.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/663a319d112e69e9ebe5a1b81f16f1ca183e5d127ae5c1b2eb1aa87baa96d805-9c2595793d0d8578034c0ba335aafa11d92c659623bbeba487d9b6abfbd10acd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jatkesha")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33516")[#strong[#text("jatkesha")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("Dear Prof. Tao,")

#text("Sorry for digressing here. Unfortunately, the formatting of the post when it is read in Google Reader is haywire. Could you please do something about it?")

#text("Regards,")

#text("Jatkesha")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecd225147c8675ae8d9671b88df7b16d900098d810ea3e8a36fef1ea0bc127da-851dcb3aa2d663cae998245b706541259b054ade4f9710d9c277de34f7ab3bf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Cranch")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33518")[#strong[#text("James Cranch")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("Sorry, I’ve nothing intelligent to say.")

#text("The words “this paper of Leibman” look like they should have a link associated to them, but don’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33521")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("Jatkesha, unfortunately it’s out of Dr. Tao’s hands. Google Reader has recently changed and it now renders every <img> tag as a new paragraph. It’s a Google problem, not a WordPress problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33523")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("Terry: an enjoyable post.")#linebreak()#text(" James: There are two papers of Leibman relevant here: Polynomial sequences in groups, J. Alg 201 (1998), 189-206 and Polynomial mappings in groups, Israel J. Math 129 (2002), 29-60. A digested version of these results for the consumption of additive combinatorialists may be found in Sec. 6 of the paper Quantitative distribution of polynomial sequences on nilmanifolds by Terry and I.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33524")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/433cd16ff39ccd5efcddb727e072f0e1af1747464eaf86d91b95ccf4e943904a-772b7e5255941d417a1e5a178366a712cb7c03e5e93bbad0158284e0bb6753e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ohnym")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33525")[#strong[#text("ohnym")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("dear professor terrence tao")

#text("im send a letter to you that contained way of the proof of the goldbach’s conjecture. ( elementary proof )")

#text("please see that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52bdeb0786c46b76601fd4cc2a591061fad34871ab96e3aee2412d58360178ee-d83a8a7c8b055d734d8d2f07b8454a5c92a1be72445b355ccc01126305fbb31b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mirror2image")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33533")[#strong[#text("mirror2image")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")])]

#text("There was a fun problem, which I’ve encountered while in university, many many years ago. It was form small pamphlet, something like “hard problems in mathematical analysis” for students, printed by Leningrad University. F is infinitely differentiable function. Prove that if for every x exist k such that k derivative of F is zero for x, F is polynomial. Took me a week or two to figure it. May be even three, don’t remember now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of user")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33536")[#strong[#text("user")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2008")])]

#text("@jatkesha: If you are using Firefox you can install the extension Stylish (or edit user.css directly) and add a CSS rule along the lines of:")

#text("@-moz-document url-prefix(“https://www.google.com/reader/”), url-prefix(“http://www.google.com/reader/”) {")#linebreak()#text(" img.content-block-fix { display: inline !important; margin:0px !important; }")#linebreak()#text(" }")

#text("This makes inline math look OK and other images acceptable, as opposed to inline math horrible and other images fine. Sorry for being off topic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-33587")[#strong[#text("Carnival of Mathematics #44 « Maxwell’s Demon")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")]

#text("[…] generate Pythagorean triples at 360. To stretch your mathematical muscles a little more look for Terry Tao, considering polynomials on finite fields ranging over a finite group. Technical but […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-42810")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] monomials each of degree at most , or alternatively as a function whose derivative vanishes; see this previous blog post for some discussion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-44744")[#strong[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("[…] is also of importance (particularly in low characteristic), but the theory is more difficult; see these notes for some further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-49535")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")])]

#text("[…] essentially no distinction between non-classical polynomials and their classical counterparts, as discussed previously on this blog). The need to deal with genuinely non-classical polynomials is the main new difficulty in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-459547")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Dear Prof. Tao,")

#text("I think the statement of Lemma 6 has a rogue exponent “n” in it — the previous sentence (“In dimension one…”) suggests we should be working with n=1, and the statement appears to be very much untrue without this assumption.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-463774")[#strong[#text("Nonclassical polynomials, circles, and groups - Quorai")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")]

#text("[…] this blog post for more background on nonclassical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on inverse theorem entropy | What's new")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-644066")[#strong[#text("Notes on inverse theorem entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("[…] degree polynomial phases from to , which one can normalize to equal at the origin, and then by the classification of such polynomials one can calculate that the entropy is of quasipolynomial size in . By using the recent work of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-675858")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] is a one-bounded function with a lower bound on the Gowers uniformity norm. Then there exists a (non-classical) polynomial of degree at most such that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/#comment-678346")[#strong[#text("A Host–Kra F^omega_2-system of order 5 that isn't Abramov of order 5, and non-measurability of the inverse theorem for the U^6(F^n_2) norm; The construction of completely disconnected Host–Kra–Ziegler components, and the inverse theorem for the")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2023")]

#text("[…] is a one-bounded perform with a decrease sure on the Gowers uniformity norm. Then there exists a (non-classical) polynomial of diploma at most such that […]")
]
