// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:17:18.210946+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/")[#text("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0906.3070")[#text("Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/cover/cover.html")[#text("Analysis & PDE")]#text(". It is a ")#link("http://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_existence_and_smoothness")[#text("famous problem")]#text(" to establish the existence of global smooth solutions to the three-dimensional ")#link("http://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_equations")[#text("Navier-Stokes")]#text(" system of equations")

#align(center)[#mi("\\partial_t u + (u \\cdot \\nabla) u = \\Delta u - \\nabla p")#linebreak()#text(" ")#mi("\\nabla \\cdot u = 0")#linebreak()#text(" ")#mi("u(0,x) = u_0(x)")]

#text("given smooth, compactly supported, divergence-free initial data ")#mi("u_0: {\\Bbb R}^3 \\to {\\Bbb R}^3")#text(".")

#text("I do ")#strong[#text("not")]#text(" claim to have any substantial progress on this problem here. Instead, the paper makes a small observation about the hyper-dissipative version of the Navier-Stokes equations, namely")

#align(center)[#tao-math("\\partial_t u + (u \\cdot \\nabla) u = - \\left|\\nabla\\right|^{2\\alpha} u - \\nabla p", block: false)#linebreak()#text(" ")#mi("\\nabla \\cdot u = 0")#linebreak()#text(" ")#mi("u(0,x) = u_0(x)")]

#text("for some ")#mi("\\alpha > 1")#text(". It is a folklore result that global regularity for this equation holds for ")#mi("\\alpha \\geq 5/4")#text("; the significance of the exponent ")#mi("5/4")#text(" is that it is energy-critical, in the sense that the scaling which preserves this particular hyper-dissipative Navier-Stokes equation, also preserves the energy.")

#text("Values of ")#mi("\\alpha")#text(" below ")#mi("5/4")#text(" (including, unfortunately, the case ")#mi("\\alpha=1")#text(", which is the original Navier-Stokes equation) are supercritical and thus establishing global regularity beyond the reach of most known methods (see ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("my earlier blog post")]#text(" for more discussion).")

#text("A few years ago, ")#link("http://arxiv.org/abs/math.AP/0606145")[#text("I observed")]#text(" (in the case of the spherically symmetric wave equation) that this “criticality barrier” had a very small amount of flexibility to it, in that one could push a critical argument to a slightly supercritical one by exploiting spacetime integral estimates a little bit more. I realised recently that the same principle applied to hyperdissipative Navier-Stokes; here, the relevant spacetime integral estimate is the energy dissipation inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\int_{{\\Bbb R}^d} \\left| \\left|\\nabla\\right|^\\alpha u(t,x)\\right|^2\\ dx dt \\leq \\frac{1}{2} \\int_{{\\Bbb R}^d} \\left|u_0(x)\\right|^2\\ dx", block: true)]]

#text("which ensures that the energy dissipation ")#tao-math("a(t) := \\int_{{\\Bbb R}^d} \\left| \\left|\\nabla\\right|^\\alpha u(t,x)\\right|^2\\ dx", block: false)#text(" is locally integrable (and in fact globally integrable) in time.")

#text("In this paper I push the global regularity results by a fraction of a logarithm from ")#mi("\\alpha=5/4")#text(" towards ")#mi("\\alpha=1")#text(". For instance, the argument shows that the logarithmically supercritical equation")

#align(center)[#tao-math("\\partial_t u + (u \\cdot \\nabla) u = - \\frac{\\left|\\nabla\\right|^{5/2}}{\\log^{1/2}(2-\\Delta)} u - \\nabla p", block: false)#text(" (0)")#linebreak()#text(" ")#mi("\\nabla \\cdot u = 0")#linebreak()#text(" ")#mi("u(0,x) = u_0(x)")]

#text("admits global smooth solutions.")

#text("The argument is in fact quite simple (the paper is seven pages in length), and relies on known technology; one just applies the energy method and a logarithmically modified Sobolev inequality in the spirit of a well-known inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=579997")[#text("of Brezis and Wainger")]#text(". It looks like it will take quite a bit of effort though to improve the logarithmic factor much further.")

#text("One way to explain the tiny bit of wiggle room beyond the critical case is as follows. The standard energy method approach to the critical Navier-Stokes equation relies at one stage on ")#link("http://en.wikipedia.org/wiki/Gronwall%27s_inequality")[#text("Gronwall’s inequality")]#text(", which among other things asserts that if a time-dependent non-negative quantity E(t) obeys the differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t E(t) \\leq a(t) E(t)")]]

#text("and ")#mi("a(t)")#text(" was locally integrable, then E does not blow up in time; in fact, one has the inequality")

#align(center)[#mi("E(t) \\leq E(0) \\exp( \\int_0^t a(s)\\ ds )")#text(".")]

#text("A slight modification of the argument shows that one can replace the linear inequality with a slightly superlinear inequality. For instance, the differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t E(t) \\leq a(t) E(t) \\log E(t)")]]

#text("also does not blow up in time; indeed, a ")#link("http://en.wikipedia.org/wiki/Separation_of_variables")[#text("separation of variables")]#text(" argument gives the explicit double-exponential bound")

#align(center)[#tao-fit-display[#mitex("E(t) \\leq \\exp(\\exp( \\int_0^t a(s)\\ ds + \\log \\log E(0) ))")]]

#text("(let’s take ")#mi("E(0) > 1")#text(" and all functions smooth, to avoid technicalities). It is this ability to go beyond Gronwall’s inequality by a little bit which is really at the heart of the logarithmically supercritical phenomenon. In the paper, I establish an inequality basically of the shape (2), where ")#mi("E(t)")#text(" is a suitably high-regularity Sobolev norm of ")#mi("u(t)")#text(", and ")#mi("a(t)")#text(" is basically the energy dissipation mentioned earlier. The point is that the logarithmic loss of ")#mi("\\log(1 - \\Delta)^{1/4}")#text(" in the dissipation can eventually be converted (by a Brezis-Wainger type argument) to a logarithmic loss in the high-regularity energy, as this energy can serve as a proxy for the frequency ")#tao-math("\\left|\\xi\\right|", block: false)#text(", which in turn serves as a proxy for the Laplacian ")#mi("-\\Delta")#text(".")

#text("To put it another way, with a linear exponential growth model, such as ")#mi("\\partial_t E(t) = C E(t)")#text(", it takes a constant amount of time for E to double, and so E never becomes infinite in finite time. With an equation such as ")#mi("\\partial_t E(t) = C E(t) \\log E(t)")#text(", the time taken for E to double from (say) ")#mi("2^n")#text(" to ")#mi("2^{n+1}")#text(" now shrinks to zero, but only as quickly as the harmonic series ")#mi("1/n")#text(", so it still takes an infinite amount of time for E to blow up. But because the divergence of ")#mi("\\sum_n 1/n")#text(" is logarithmically slow, the growth of E is now a double exponential rather than a single one. So there is a little bit of room to exploit between exponential growth and blowup.")

#text("Interestingly, there is a heuristic argument that suggests that the half-logarithmic loss in (0) can be widened to a full logarithmic loss, which I give below the fold.")

#metadata(none) <tao-e4512f5e0031f5e1734b>

#text("Suppose the solution to (0) (with a full power of the logarithm) blows up at some finite time ")#mi("T_*")#text(". We make the (somewhat improbable) ansatz that all the energy concentrates to a point (e.g. the origin) at this blowup time, thus for each ")#mi("0 < t < T_*")#text(" we assume that u is concentrated in a ball of radius ")#mi("1/N(t)")#text(", where ")#mi("N(t)")#text(" is a frequency scale that goes to infinity as ")#mi("t \\to T_*")#text(". (This type of concentration is, heuristically, the “worst case” for any argument involving Sobolev embedding, which the arguments in my paper certainly rely on.) As the total energy is bounded, and the ball has volume ")#mi("O( 1/N(t)^3)")#text(", this suggests that u(t,x) should have magnitude ")#mi("O(N(t)^{3/2})")#text(" at time t. In particular, from the convection term ")#mi("(u \\cdot \\nabla) u")#text(" in (0) this suggests that u propagates at speed ")#mi("O(N(t)^{3/2})")#text(". In particular, the radius ")#mi("1/N(t)")#text(" should obey the ODE")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\frac{1}{N(t)} = O( N(t)^{3/2} )")]]

#text("which after solving this ODE suggests that N(t) needs to blow up at the rate ")#mi("(T_*-t)^{-2/5}")#text(" or faster: ")#mi("N(t) \\gg (T_*-t)^{-2/5}")#text(". On the other hand, the energy identity for (0) (with a full power of the logarithm) implies that")

#align(center)[#tao-math("\\int_0^{T_*} \\int_{{\\Bbb R}^3} \\frac{\\left|\\nabla\\right|^{5/2}}{\\log(2-\\Delta)} u \\cdot u\\ dx dt < \\infty", block: false)#text(";")]

#text("heuristically substituting in our ansatz, this suggests")

#align(center)[#tao-fit-display[#mitex("\\int_0^{T_*} \\frac{N(t)^{5/2}}{\\log(2 +N(t))} dt < \\infty")]]

#text("but this is incompatible with the blowup rate ")#mi("N(t) \\gg (T_*-t)^{-2/5}")#text(" because ")#mi("\\int_0^\\infty \\frac{ds}{s \\log s}")#text(" is (barely) divergent at infinity. Unfortunately, I do not know how to make this non-rigorous argument precise without taking on some unwanted logarithmic losses, but it may well be feasible to do so; readers are welcome to try, of course :-).")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39616")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("The last paragraph on page 4 starts with “where” and seems to be a continuation of something that is accidentally removed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Oops! Thanks for pointing that out, I think I restored that paragraph now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Dear Prof Tao,")

#text("Excuse me, maybe this is a very simple question but I want to learn it.")

#text("How do we evaluate ")#mi("\\int_{0}^{\\infty}\\frac{ds}{s \\log s}")#text(" ? We have problem at both sides.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39666")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("The integral does not converge")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Dear Tavares,")

#text("thank you, but I want to understand how do we evaluate this type of integrals?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39676")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Dear Anonynous")

#text("You have")

#mi("\\displaystyle\\int_0^{\\infty}\\dfrac{dx}{x\\ln x}=\\displaystyle\\int_0^2\\dfrac{dx}{x\\ln x}+\\displaystyle\\int_2^{\\infty}\\dfrac{dx}{x\\ln x}")

#text("Since")

#mi("\\displaystyle\\int\\dfrac{dx}{x\\ln x}=\\ln \\left( \\ln x\\right)")#text(",")

#mi("\\displaystyle\\int_2^{\\infty}\\dfrac{dx}{x\\ln x}")#text(" does not converge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39677")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Anonymous")

#text("You have to read about the first and second kind improper integrals and its convergence criteria, similar to the series.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39678")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Perhaps this post of mine")

#link("http://problemasteoremas.wordpress.com/2008/02/18/integrais-improprios-a-funcao-gama/")[#text("http://problemasteoremas.wordpress.com/2008/02/18/integrais-improprios-a-funcao-gama/")]

#text("in Portuguese might help a little bit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Thank you for your help Mr. Tavares")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39688")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Professor Tao:")

#text("I am still in the midst of reading it, but")

#text("in your Abstract, you have -D^{2} on the right hand side where it should have the opposite sign.")

#text("Also, around middle of page 5 after “From Plancherel’s theorem and (2) we see that …”, you have an inequality with 3/2 norms on each side. This same inequality also has the power of as -(d+1)/4. Do you mean -(d+2)/4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2009")])]

#text("Dear Prof Tao,")

#text("Do you have your own lecture notes on Besov spaces?")

#text("any help would be appreciated.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2009")])]

#text("Dear anonymous,")

#text("I don’t have notes on Besov spaces ")#emph[#text("per se")]#text(", but I have some notes on Littlewood-Paley theory, which underlies the construction of such spaces, at")

#link("http://www.math.ucla.edu/~tao/254a.1.01w/")[#text("http://www.math.ucla.edu/~tao/254a.1.01w/")]

#text("See also Appendix A of my PDE book (Nonlinear dispersive equations).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39758")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2009")])]

#text("Dear Professor Tao:")

#text("There are two equations (1) in this blog.")

#text("In your paper:")

#text("on pg. 5")#linebreak()#text(" you use Holder and Gagliardo Niremberg inequality to get a certain bound. I am not familiar with the second inequality in particular. Can you explain how you use the second inequality? Is multiplying multiply gradient and gradient inverse and use Holder with 1/2 + (d+2)/4d = (3d+2)/4d?")

#text("on pg. 6")#linebreak()#text(" you state “Putting this all together, we see that the low-frequency contribution to (8) is")

#text("≤ C g (N )^{2} Ek [g (N )^{2} a(t) + (1/N)Ek ].”")

#text("I think a(t) should be (1 + a(t)) here, and (1/N) be (1/N)^{2}?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Thanks for the corrections!")

#text("The Gagliardo-Nirenberg inequality asserts that if f lies in some ")#mi("L^p")#text(" space, and some high derivative ")#mi("\\nabla^m f")#text(" lies in some other ")#mi("L^q")#text(" space, then all intermediate derivatives ")#mi("\\nabla^k f")#text(" will lie in an interpolated ")#mi("L^r")#text(" space, with a bound being the interpolated combination of the ")#mi("L^p")#text(" norm of f and ")#mi("L^q")#text(" norm of ")#mi("\\nabla^m f")#text(". This can be seen for instance by the complex interpolation method, noting from singular integral theory that imaginary powers of ")#tao-math("\\left|\\nabla\\right|", block: false)#text(" are bounded on ")#mi("L^p")#text(" for all ")#mi("1 < p < \\infty")#text(". Applying it here, it allows one to control a certain ")#mi("L^p")#text(" norm of ")#mi("\\nabla^{j_1} u")#text(" by the ")#mi("L^{4d/(d+2)}")#text(" norm of ")#mi("\\nabla u")#text(" and the ")#mi("L^2")#text(" norm of ")#mi("\\nabla^{j_1+j_2-1} u")#text(". (The exponents are guaranteed to work out in the end, thanks to dimensional analysis. More generally, experience (and also para-differential calculus) has shown that the most extreme cases of a Leibniz splitting (in this case, ")#mi("(j_1,j_2) = (1, j), (j,1)")#text(") basically dominate the non-extreme cases, in the sense that if the two extremes can be estimated adequately, then so can all intermediate terms.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39771")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Dear Professor Tao:")

#text("It seems to me that your proof almost verbatim works for not only just NSE but other PDEs. In particular, it works for 2D Quasi-geostrophic Equation (QG); i.e. with d=2 instead of 3, u being dotted changed to the Riesz transform of u. If you agree, I would think it’s worth a mention because there has been significant amount of effort to break the barrier of criticality of QG recently. If not, please inform me where it could go wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-39790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("Dear Student,")

#text("It is likely that these methods would work for other semilinear dissipative equations that are just barely supercritical; I haven’t checked this for QG but can believe it to be the case. (The energy method is remarkably general.) One may need to be careful though if the ")#mi("L^\\infty")#text(" endpoint Sobolev embedding needs to be used; this is not a problem in three and higher dimensions but may possibly become an issue in two dimensions, though I have not worked out the numerology.")

#text("I am not so current on the latest results on this equation, though, so I will leave it for others to pursue these sorts of directions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-40768")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2009")])]

#text("Dear Professor Tao:")

#text("1. By Gagliardo-Niremberg Inequality with which you split the L^{4d/(3d+2)} norm of |\\nabla^{j_{1}}| |\\nabla^{j_{2}}| into the L^{4d/(d+2)} norm of \\nabla u and L^{2} norm of \\nabla^{j_{1} + j_{2} -1}u, you mean something like Theorem 2.1 (Coifman-Meyer multiplier theorem) in your Lecture Notes 3 for 254A, I guess? Otherwise, by outright Googling Gagliardo-Niremberg Inequality, I was not able to find a technique of this Leibniz splitting.")

#text("2. I am not sure where in your proof you must require “for all sufficiently large \\xi.” Please let me know.")

#text("3. I am not too used to your P_{>N} and P_{\\leq N} Fourier projections. I usually think of non-homogeneous Besov space in which we have infinite (bi-infinite if homogeneous) sum onto dyadically decomposed pieces; e.g. I express L^{2} space as B_{2, 2}^{0} space. Is your projection onto the two regions {\\xi : |\\xi| \\leq N} and {\\xi: |\\xi| > N} basically same thing? In other words, are these two projections basically sums, first one finite and second one infinite?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-40809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("1. The estimation of the product proceeds by using Holder’s inequality followed by the Gagliardo-Nirenberg inequality mentioned in my June 27 comment. (It does indeed also follow from the Coifman-Meyer paraproduct theory, though.)")

#text("2. I do not see any reference to “sufficiently large xi” in my paper.")

#text("3. One is of course free to decompose frequency space as one pleases. In particular, one can subdivide ")#mi("P_{>N}")#text(" (say) as a sum of projections ")#mi("P_M")#text(" to frequencies of size M for ")#mi("M > N")#text(" if one wishes. (In the homogeneous setting, one would allow frequency scales to go all the way down to zero, so the sum for ")#mi("P_{\\leq N}")#text(" would be infinite also.) In this particular case, there is not much advantage to be gained by this further decomposition, though it is of course important in other settings.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-40831")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("Dear Professor Tao:")

#text("The “sufficiently large xi” I am referring to is that in your Abstract.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-40834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("By only requiring a lower bound on m for sufficiently large xi, one allows for the possibility that m can vanish for bounded values of xi, thus generalising the result slightly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-40873")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Dear Professor Tao:")

#text("Thank you for your replies.")

#text("The reason why I asked the Question 3 of 07/31 post is the following: (I type LaTeX codes below because last time I I tired to use LaTeX on WordPress, I miserably failed; I apologize in advance if it’s confusing).")

#text("To prove your heuristic correct, I noticed on top of page 6 of your paper, you partition")

#text("$\\lVert \\nabla u \\rVert_{L^{4d/(d + 2)}(R^{d})}$")

#text("into two parts of higher and lower frequencies of Fourier projections. Ultimately you end up making use of the lower frequency part of this inequality to bound")

#text("$\\partial_{t}E_{k}$;")

#text("and prove the global regularity; hence, if you could save g(t) here, you end up saving g^{2}(t) at the end and your heuristic is proven.")

#text("You introduce a(t) which is basically the cumulative energy dissipation of the NSE as a conserved quantity. But, as you of course know, simple maximum kinetic energy,")

#text("$\\lVert u \\rVert_{L^{2}(R^{d})}^{2}$")

#text("is also a conserved quantity for the NSE (and for QG as well; cf. Maximum Principle by Cordoba, Cordoba).")

#text("(If my argument below is wrong, could you explain to me why you chose the conserved quantity a(t) to be the cumulative energy dissipation rather than maximum kinetic energy?)")

#text("Suppose d = 2 for simplicity (this is the case for QG and I would like to ask that you believe all the Sobolev inequality in the process worked out even with d=2). Then the L^{4d/(d + 2)} norm above is just L^{2} norm and L^{2} norm is equivalent to the inhomogeneous Besov space norm, B_{2, 2}^{0} norm (I don’t know of any simple equivalence if d is not 2). To be specific, by B_{2, 2}^{0} norm, I mean")

#text("$\\lVert f \\rVert_{B_{2, 2}^{0}} =")

#text("($\\sum_{s \\geq -1}\\lVert\\triangle_{s}f \\rVert_{L^{2}(R^{2})}^{2})^{1/2}$")

#text("where $\\triangle_{s}$ is a Littlewood-Paley operator, slightly different in the case of s = -1 as you know but should make no difference in this case.")

#text("By this decomposition and splitting the sum to finite part from s = -1 up to N and infinite part from s = N to beyond, and applying Bernstein’s inequality on the finite sum (which is safe because the sum is finite), I wonder if we can get away with not having to rely on a(t) or g(t). In other words, instead of obtaining the bound on the lower frequency part of $\\lVert \\nabla u \\rVert_{L^{2}(R^{2})}$ to be")

#text("$\\lVert \\nabla P_{\\leq N}u\\rVert_{L^{4d/(d+2)}(R^{d})} \\leq Cg(N)(1 + a(t))^{1/2},")

#text("get instead")

#text("C$\\lVert\\theta\\rVert_{L^{2}(R^{2})}$")

#text("which by itself is a conserved quantity and hence no g(t) is needed here as desired.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-42384")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")])]

#text("Dear Professor Tao:")

#text("Perhaps this is not so important, but was there any important reason you gave an example of")

#text("g(\\lvert\\xi\\rvert) = log^{1/4}(2 + \\lvert\\xi\\rvert^{2})")

#text("with")

#text("2 + \\lvert\\xi\\rvert^{2}")

#text("instead of")

#text("1 + \\lvert\\xi\\rvert^{2}?")

#text("As usual, to make the log function strictly non-negative, I would think one naturally starts with (1 + \\lvert\\xi\\rvert^{2}). I did not see any reason to consider 2 + \\lvert\\xi\\rvert^{2} even having read, although briefly, Brezix Wagner’s paper that you cite.")

#text("Please feel free to ignore this question if it is indeed not important and the second case also works.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-42386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")])]

#tao-math("\\log (1 + \\left|\\xi\\right|^2)", block: false)#text(" vanishes when ")#mi("\\xi = 0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-42390")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")])]

#text("Dear Professor Tao:")

#text("I apologize for the silly question, and thank you very much for your reply.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2eed410bf17af67c8cfc20fada76efdbd0a77ece8520d37dbae4b93ba3759a1a-74c3480be27403413ae47eff93ad2daefb4ce1e02ac760793a75c0eaa1ad585c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-42902")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2009")])]

#text("Dear Professor Tao:")

#text("I would like to just make sure that I understand one part correctly. On page 6, you state")

#text("“Meanwhile, from Sobolev embedding we have")

#text("\\lVert \\nabla P_{>N}u \\rVert_{L^{4d/(d+2)}}")

#text("\\leq")

#text("\\frac{1}{N}E_{k}^{1/2}")

#text("(say) if k is large enough”")

#text("and later you optimize by setting N := 1 + E_{k}.")

#text("Then the right hand side of the inequality above is very small. But this is okay because by taking k large, the")

#text("\\lVert \\nabla P_{>N}u \\rVert_{L^{4d/(d+2)}}")

#text("on the left hand side also becomes small, basically because N became significantly larger than 1, the power of the gradient on the left hand side. Then, here at least there seems to be some breathing space; i.e. even if the power of the gradient on the left hand side is more than 1, if it small compared to k, say k/2, you can still take that inequality. Is that correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43811")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("Dear Prof. Tao,")

#text("Nearly at the end of the paper, we are trying to control the high frequency part. I have some problem on")

#text("$")#tao-math("\\left|\\left|\\nabla^{j_1} u\\right|\\right|_{L^\\infty} \\leq C E^{\\frac 12}_k.", block: false)#text("$")

#text("Since we can take ")#mi("j_1=k-1")#text(", in this case, I am a little worried if the Sobolev embedding can be applied.")

#text("Thanks in advance!")

#text("It seems you are travelling now, this problem is not in a hurry. Have a nice trip!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43818")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("j_{1} \\leq j_{2} and j_{1} + j_{2} = k + 1, so j_{1} is at most \\frac{k+1}{2}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43821")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("Dear Student,")

#text("I got it. Thanks a lot for your help!")

#text("By the way, when typing some formula, one can write ")#mi("...")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("I mean at the bottom of the blog there is a very simple instruction on how to write a mathematical formula.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43849")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("Dear Prof. Tao,")

#text("Thanks a lot for the nice paper!")

#text("I think for the critical case, it is not difficult to show the global regularity by using the argument for low frequency part (as in the paper).")

#text("I have a technique problem for the arguments in the third last line of page 5: We applied Holder’s inequality and Gagliardo-Nirenberg inequality to obtain:")

#tao-math("\\left|\\left| \\left|\\nabla^{j_1} u\\right| \\right|\\nabla^{j_2} u\\right| \\left|\\left|_{L^{\\frac{4d}{3d+2}}} \\leq   C \\right|\\right|\\nabla u| \\left|\\left|_{L^{\\frac{4d}{d+2}}}\\right| \\right|\\nabla^{j_1+j_2-1} u ||_{L^2}", block: false)

#text("If $j_1,j_2>1$, by Gagliardo-Nirenberg inequality ")#tao-math("\\left|\\left|f\\right|\\right|_{L^p} \\leq C\\left|\\left|\\nabla f\\right|\\right|^{\\theta}_{L^r} \\left|\\left|f\\right|\\right|^{1-\\theta}_{L^q}", block: false)#text(" (")#mi("p,q,r")#text(" satisfy some relation, I don’t know this inequality before, this one is got from internet), I don’t know how to obtain the norm ")#tao-math("\\left|\\left|\\nabla u\\right|\\right|", block: false)#text(" in the upper bound. It seems we need some interpolation. I only know the interpolations between ")#mi("L^p")#text(" spaces and between ")#mi("H^s")#text(" spaces.")

#text("Thanks a lot in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-43850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("See my previous June 27 and Aug 3 comments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-50661")[#strong[#text("⑥ 纳维-斯托克斯方程组通解的存在性与光滑性：Existence And Smoothness of The Navier-Stokes Equation « Hezhigang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")]

#text("[…] formulation of the global regularity problem for the periodic Navier-Stokes equation ξ Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-50663")[#strong[#text("Existence And Smoothness of The Navier-Stokes Equation « Hezhigang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")]

#text("[…] formulation of the global regularity problem for the periodic Navier-Stokes equation ξ Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4bb092029e9b22e5af2255d8470c35984299104538de2211ca2491f9a7fa449-721f2c58b4d07bdddee46dd3f6b9f9558e9586bd88936718aec053bbc1eaabde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of biruk")]], [#link("https://terrytao.wordpress.com/2009/06/19/global-regularity-for-a-logarithmically-supercritical-hyperdissipative-navier-stokes-equation/#comment-504105")[#strong[#text("biruk")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("Currently there is a published paper on the solutions of navier stokes equations. The solition is derived by transforming intial velocity to fourier like transformation of vector fields. The complete result is submitted to american mathematica society journal and parial result has been published on journal of mathematics research ")#link("https://doi.org/10.5539/jmr.v10n4p128")[#text("https://doi.org/10.5539/jmr.v10n4p128")]
]
