// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/
// Converted to Typst by tao2typ: "2026-10-14T11:13:02.903349+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 January 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/")[#text("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("https://research.unsw.edu.au/people/professor-timothy-trudgian")[#text("Timothy Trudgian")]#text(", ")#link("https://www.unsw.edu.au/hdr/andrew-yang")[#text("Andrew Yang")]#text(" and I have just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/2501.16779")[#text("New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach")]#text("“. This paper launches a project envisioned in ")#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/")[#text("this previous blog post")]#text(", in which the (widely dispersed) literature on various exponents in classical analytic number theory, as well as the relationships between these exponents, are collected in a ")#link("https://github.com/teorth/expdb")[#text("living database")]#text(", together with computer code to optimize the relations between them, with one eventual goal being to automate as much as possible the “routine” components of many analytic number theory papers, in which progress on one type of exponent is converted via standard arguments to progress on other exponents.")

#text("The database we are launching concurrently with this paper is called the ")#link("https://github.com/teorth/expdb")[#text("Analytic Number Theory Exponent Database")]#text(" (ANTEDB). This Github repository aims to collect the latest results and relations on exponents such as the following:")

#list(
[#text("The ")#link("https://teorth.github.io/expdb/blueprint/zeta-growth-chapter.html")[#text("growth exponent")]#text(" ")#mi("{\\mu(\\sigma)}")#text(" of the Riemann zeta function ")#mi("{\\zeta(\\sigma+it)}")#text(" at real part ")#mi("{\\sigma}")#text(" (i.e., the best exponent for which ")#tao-math("{\\zeta(\\sigma+it) \\ll \\left|t\\right|^{\\mu(\\sigma)+o(1)}}", block: false)#text(" as ")#mi("{t \\rightarrow \\infty}")#text(");")],
[#link("https://teorth.github.io/expdb/blueprint/exponent-pairs-chapter.html")[#text("Exponent pairs")]#text(" ")#mi("{(k,\\ell)}")#text(" (used to bound exponential sums ")#mi("{\\sum_{n \\in I} e(T F(n/N))}")#text(" for various phase functions ")#mi("{F}")#text(" and parameters ")#mi("{T,N}")#text(");")],
[#link("https://teorth.github.io/expdb/blueprint/zero-density-chapter.html")[#text("Zero density exponents")]#text(" ")#mi("{A(\\sigma)}")#text(" (used to bound the number of zeros of ")#mi("{\\zeta}")#text(" of real part larger than ")#mi("{\\sigma}")#text(");")]
)

#text("etc.. These sorts of exponents are related to many topics in analytic number theory; for instance, the Lindelof hypothesis is equivalent to the assertion ")#mi("{\\mu(1/2)=0}")#text(".")

#text("Information on these exponents is collected both in a LaTeX “blueprint” that is available as a ")#link("https://teorth.github.io/expdb/blueprint/intro-chapter.html")[#text("human-readable set of web pages")]#text(", and as part of our ")#link("https://github.com/teorth/expdb/tree/main/blueprint/src/python")[#text("Python codebase")]#text(". In the future one could also imagine the data being collected in a Lean formalization, but at present the database only contains a ")#link("https://github.com/teorth/expdb/tree/main/expdb")[#text("placeholder Lean folder")]#text(".")

#text("As a consequence of collecting all the known bounds in the literature on these sorts of exponents, as well as abstracting out various relations between these exponents that were implicit in many papers in this subject, we were then able to run computer-assisted searches to improve some of the state of the art on these exponents in a largely automated fashion (without introducing any substantial new inputs from analytic number theory). In particular, we obtained:")

#list(
[#text("four new exponent pairs;")],
[#text("several new zero density estimates; and")],
[#text("new estimates on the additive energy of zeroes of the Riemann zeta function.")]
)

#text("We are hoping that the ANTEDB will receive more contributions in the future, for instance expanding to other types of exponents, or to update the database as new results are obtained (or old ones added). In the longer term one could also imagine integrating the ANTEDB with other tools, such as Lean or AI systems, but for now we have focused primarily on collecting the data and optimizing the relations between the exponents.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("I don’t know what this means yet, but congrats!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("Great initiative! ANTEDB is an excellent example of how collaboration and gathering knowledge in one place can accelerate progress in science. New results, such as indicator pairs and zero estimates, demonstrate the power of this method. Kudos to the authors and good luck in developing the project!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2025")])]

#text("Summarized by GROK:")

#text("Here’s a summary of the paper “New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach” by Terence Tao, Timothy Trudgian, and Andrew Yang, published on January 28, 2025:")

#text("Overview:")

#list(
[#strong[#text("Authors:")]#text(" Terence Tao, Timothy Trudgian, and Andrew Yang.")],
[#strong[#text("Date:")]#text(" January 28, 2025.")],
[#strong[#text("Category:")]#text(" Analytic Number Theory (math.NT).")],
[#strong[#text("Tags:")]#text(" Analytic number theory, exponent pairs, zero density estimates, Riemann zeta function, exponential sums.")]
)

#strong[#text("Main Points:")]

#enum(start: 1, 
[#strong[#text("Database Initiative – ANTEDB:")]

#list(
[#strong[#text("Purpose:")]#text(" The paper introduces the Analytic Number Theory Exponent Database (ANTEDB), a repository on GitHub aimed at collecting and organizing the literature on various exponents in analytic number theory.")],
[#strong[#text("Content:")]#text(" ANTEDB includes:")

#list(
[#text("Growth exponents of the Riemann zeta function (μ(σ)).")],
[#text("Exponent pairs (k,ℓ) for bounding exponential sums.")],
[#text("Zero density exponents (A(σ)) related to the zeros of the zeta function.")]
)],
[#strong[#text("Format:")]#text(" Information is stored in LaTeX for human readability and in Python for computational purposes. There’s also a placeholder for future formalization in Lean.")]
)],
[#strong[#text("Methodology:")]

#list(
[#text("The project leverages existing knowledge by compiling all known bounds and relations between these exponents.")],
[#text("It uses computer-assisted searches to optimize these relations, leading to new insights without needing new theoretical inputs.")]
)],
[#strong[#text("Achievements:")]

#list(
[#strong[#text("New Exponent Pairs:")]#text(" Four new pairs were discovered, enhancing the bounds on exponential sums.")],
[#strong[#text("Zero Density Estimates:")]#text(" Several new estimates were made, which are crucial for understanding the distribution of the zeros of the Riemann zeta function.")],
[#strong[#text("Additive Energy of Zeros:")]#text(" New estimates on the additive energy of the zeros of the zeta function were calculated, contributing to the study of how these zeros interact.")]
)],
[#strong[#text("Future Directions:")]

#list(
[#strong[#text("Growth of ANTEDB:")]#text(" The authors hope for community contributions to expand the scope of the database, include new research, and possibly integrate with other mathematical tools like Lean or AI systems.")],
[#strong[#text("Automation:")]#text(" The ultimate goal is to automate routine calculations in analytic number theory, making research more efficient and accessible.")]
)],
[#strong[#text("Theoretical and Practical Implications:")]

#list(
[#text("The work supports the automation of mathematical reasoning in number theory, potentially speeding up research by dealing with the “routine” aspects of exponent calculations.")],
[#text("By providing a centralized database, it aids in the verification and progression of results in the field, potentially leading to breakthroughs or simplifications in proofs.")]
)]
)

#text("This paper not only contributes new results but also sets the stage for a transformative approach in how analytic number theory research might be conducted in the future, with a strong emphasis on computational assistance and community engagement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2025")])]

#text("yay for new estimates")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf8826caba1eb9c794ac1fc2344cc00ac1a7fc0bd04151a26a226c6241b0901f-d0f1e51de9d9ed994d07fc2f2707f2e12e6bc414d163826a93f9e5d69a25bdf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raphaelberger4f0aa1a9cc")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687146")[#strong[#text("raphaelberger4f0aa1a9cc")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2025")])]

#text("In ")#link("https://teorth.github.io/expdb/blueprint/debruijn-newman-chapter.html")[#text("https://teorth.github.io/expdb/blueprint/debruijn-newman-chapter.html")]#text(" at “From results of Pólya [ ")#link("https://teorth.github.io/expdb/blueprint/sect0001.html#polya")[#text("131")]#text(" ] it is known that * has purely real zeroes for some * then has purely real zeroes for all *.” Was that supposed to be “… it is known that IF …”?")

#emph[#text("[Correction added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb8ee9d503e8392f2d77cfa96588986c2db619a92d07c2b64590f2ee8362a8fc-b9d213494ef42a25a8ee2716435fd4d650b3b7887f12cc3d387678d0c9ac3239.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sinai Coons")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-687263")[#strong[#text("Sinai Coons")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Howdy! I saw this today, will be printing it tomorrow early morning, thank you for sharing! :)")#linebreak()#text("Wanted to tell you that you make the mathematical visualization easy and pretty, for example…")

#text("“In this framework, we assume there is some ambient index parameter i, which ranges over some ambient sequence of natural numbers going to infinity. All mathematical objects X (numbers, sequences, sets, functions, etc.), will either be fixed — i.e., independent of i — or variable4 – i.e., dependent on i. Of course, fixed objects can be considered as special cases of variable objects, in which the dependency is constant.”")

#text("I visualize the matrices dancing through dimensions. I’m not a math major, but I found it of importance to mention that you have a way in making math visualization pretty. That is all, thank you for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the number of exceptional intervals to the prime number theorem in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/#comment-688229")[#strong[#text("On the number of exceptional intervals to the prime number theorem in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("[…] for the recently launched Analytic Number Theory Exponent Database (ANTEDB) (discussed previously here), and have been uploaded to that […]")
]
