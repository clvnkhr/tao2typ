// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/
// Converted to Typst by tao2typ: "2026-10-14T15:17:09.862406+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The completeness and compactness theorems of first-order logic", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The completeness and compactness theorems of first-order logic")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The famous ")#link("http://en.wikipedia.org/wiki/Godel_completeness_theorem")[#text("Gödel completeness theorem")]#text(" in logic (not to be confused with the even more famous ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems")[#text("Gödel incompleteness theorem")]#text(") roughly states the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Gödel completeness theorem, informal statement)")]#text(" ")#metadata(none) <tao-401ccc1785a6ca3f2af9>#text(" Let ")#mi("{\\Gamma}")#text(" be a ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order")]#text(" ")#link("http://en.wikipedia.org/wiki/Theory_(mathematical_logic)")[#text("theory")]#text(" (a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal language")]#text(" ")#mi("{{\\mathcal L}}")#text(", together with a set of axioms, i.e. ")#link("http://en.wikipedia.org/wiki/Sentence_(mathematical_logic)")[#text("sentences")]#text(" assumed to be true), and let ")#mi("{\\phi}")#text(" be a sentence in the formal language. Assume also that the language ")#mi("{{\\mathcal L}}")#text(" has at most countably many symbols. Then the following are equivalent:")

#list(
[#text("(i) (Syntactic consequence) ")#mi("{\\phi}")#text(" can be deduced from the axioms in ")#mi("{\\Gamma}")#text(" by a finite number of applications of the ")#link("http://en.wikipedia.org/wiki/Natural_deduction")[#text("laws of deduction")]#text(" in first order logic. (This property is abbreviated as ")#mi("{\\Gamma \\vdash \\phi}")#text(".)")],
[#text("(ii) (Semantic consequence) Every ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structure")]#text(" ")#mi("{{\\mathfrak U}}")#text(" which ")#link("http://en.wikipedia.org/wiki/Semantic_theory_of_truth")[#text("satisfies")]#text(" or ")#emph[#text("models")]#text(" ")#mi("{\\Gamma}")#text(", also satisfies ")#mi("{\\phi}")#text(". (This property is abbreviated as ")#mi("{\\Gamma \\models \\phi}")#text(".)")],
[#text("(iii) (Semantic consequence for at most countable models) Every structure ")#mi("{{\\mathfrak U}}")#text(" which is at most countable, and which models ")#mi("{\\Gamma}")#text(", also satisfies ")#mi("{\\phi}")#text(".")]
)
]

#text("One can also formulate versions of the completeness theorem for languages with uncountably many symbols, but I will not do so here. One can also force other cardinalities on the model ")#mi("{{\\mathfrak U}}")#text(" by using the ")#link("http://en.wikipedia.org/wiki/L%C3%B6wenheim%E2%80%93Skolem_theorem")[#text("Löwenheim-Skolem theorem")]#text(".")

#text("To state this theorem even more informally, any (first-order) result which is true in ")#emph[#text("all")]#text(" models of a theory, must be logically deducible from that theory, and vice versa. (For instance, any result which is true for all groups, must be deducible from the group axioms; any result which is true for all systems obeying ")#link("http://en.wikipedia.org/wiki/Peano_arithmetic")[#text("Peano arithmetic")]#text(", must be deducible from the Peano axioms; and so forth.) In fact, it suffices to check countable and finite models only; for instance, any first-order statement which is true for all finite or countable groups, is in fact true for all groups! Informally, a first-order language with only countably many symbols cannot “detect” whether a given structure is countably or uncountably infinite. Thus for instance even the ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("ZFC")]#text(" axioms of set theory must have some at most countable model, even though one can use ZFC to prove the existence of uncountable sets; this is known as ")#link("http://en.wikipedia.org/wiki/Skolem%27s_paradox")[#text("Skolem’s paradox")]#text(". (To resolve the paradox, one needs to carefully distinguish between an object in a set theory being “externally” countable in the structure that models that theory, and being “internally” countable within that theory.)")

#text("Of course, a theory ")#mi("{\\Gamma}")#text(" may contain ")#link("http://en.wikipedia.org/wiki/Independence_(mathematical_logic)")[#text("undecidable")]#text(" statements ")#mi("{\\phi}")#text(" – sentences which are neither provable nor disprovable in the theory. By the completeness theorem, this is equivalent to saying that ")#mi("{\\phi}")#text(" is satisfied by some models of ")#mi("{\\Gamma}")#text(" but not by other models. Thus the completeness theorem is compatible with the incompleteness theorem: ")#link("http://en.wikipedia.org/wiki/Recursively_enumerable_set")[#text("recursively enumerable")]#text(" theories such as Peano arithmetic are modeled by the natural numbers ")#mi("{{\\mathbb N}}")#text(", but are also modeled by other structures also, and there are sentences satisfied by ")#mi("{{\\mathbb N}}")#text(" which are not satisfied by other models of Peano arithmetic, and are thus undecidable within that arithmetic.")

#text("An important corollary of the completeness theorem is the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Compactness theorem, informal statement)")]#text(" ")#metadata(none) <tao-659eee59f002e69bf905>#text(" Let ")#mi("{\\Gamma}")#text(" be a first-order theory whose language has at most countably many symbols. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\Gamma}")#text(" is ")#link("http://en.wikipedia.org/wiki/Consistency")[#text("consistent")]#text(", i.e. it is not possible to logically deduce a contradiction from the axioms in ")#mi("{\\Gamma}")#text(".")],
[#text("(ii) ")#mi("{\\Gamma}")#text(" is ")#emph[#text("satisfiable")]#text(", i.e. there exists a structure ")#mi("{{\\mathfrak U}}")#text(" that models ")#mi("{\\Gamma}")#text(".")],
[#text("(iii) There exists a structure ")#mi("{{\\mathfrak U}}")#text(" which is at most countable, that models ")#mi("{\\Gamma}")#text(".")],
[#text("(iv) Every finite subset ")#mi("{\\Gamma^{\\prime}}")#text(" of ")#mi("{\\Gamma}")#text(" is consistent.")],
[#text("(v) Every finite subset ")#mi("{\\Gamma^{\\prime}}")#text(" of ")#mi("{\\Gamma}")#text(" is satisfiable.")],
[#text("(vi) Every finite subset ")#mi("{\\Gamma^{\\prime}}")#text(" of ")#mi("{\\Gamma}")#text(" is satisfiable with an at most countable model.")]
)
]

#text("Indeed, the equivalence of (i)-(iii), or (iv)-(vi), follows directly from the completeness theorem, while the equivalence of (i) and (iv) follows from the fact that any logical deduction has finite length and so can involve at most finitely many of the axioms in ")#mi("{\\Gamma}")#text(". (Again, the theorem can be generalised to uncountable languages, but the models become uncountable also.)")

#text("There is a consequence of the compactness theorem which more closely resembles the sequential concept of compactness. Given a sequence ")#mi("{{\\mathfrak U}_1, {\\mathfrak U}_2, \\ldots}")#text(" of structures for ")#mi("{{\\mathcal L}}")#text(", and another structure ")#mi("{{\\mathfrak U}}")#text(" for ")#mi("{{\\mathcal L}}")#text(", let us say that ")#mi("{{\\mathfrak U}_n}")#text(" ")#emph[#text("converges elementarily")]#text(" to ")#mi("{{\\mathfrak U}}")#text(" if every sentence ")#mi("{\\phi}")#text(" which is satisfied by ")#mi("{{\\mathfrak U}}")#text(", is also satisfied by ")#mi("{{\\mathfrak U}_n}")#text(" for sufficiently large ")#mi("{n}")#text(". (Replacing ")#mi("{\\phi}")#text(" by its negation ")#mi("{\\neg \\phi}")#text(", we also see that every sentence that is not satisfied by ")#mi("{{\\mathfrak U}}")#text(", is not satisfied by ")#mi("{{\\mathfrak U}_n}")#text(" for sufficiently large ")#mi("{n}")#text(".) Note that the limit ")#mi("{{\\mathfrak U}}")#text(" is only unique up to ")#link("http://en.wikipedia.org/wiki/Elementarily_equivalent")[#text("elementary equivalence")]#text(". Clearly, if each of the ")#mi("{{\\mathfrak U}_n}")#text(" models some theory ")#mi("{\\Gamma}")#text(", then the limit ")#mi("{{\\mathfrak U}}")#text(" will also; thus for instance the elementary limit of a sequence of groups is still a group, the elementary limit of a sequence of rings is still a ring, etc.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Sequential compactness theorem)")]#text(" Let ")#mi("{{\\mathcal L}}")#text(" be a language with at most countably many symbols, and let ")#mi("{{\\mathfrak U}_1, {\\mathfrak U}_2, \\ldots}")#text(" be a sequence of structures for ")#mi("{{\\mathcal L}}")#text(". Then there exists a subsequence ")#mi("{{\\mathfrak U}_{n_j}}")#text(" which converges elementarily to a limit ")#mi("{{\\mathfrak U}}")#text(" which is at most countable.")
]

#emph[#text("Proof:")]#text(" For each structure ")#mi("{{\\mathfrak U}_n}")#text(", let ")#mi("{\\text{Th}({\\mathfrak U}_n)}")#text(" be the theory of that structure, i.e. the set of all sentences that are satisfied by that structure. One can view that theory as a point in ")#mi("{\\{0,1\\}^{{\\mathcal S}}}")#text(", where ")#mi("{{\\mathcal S}}")#text(" is the set of all sentences in the language ")#mi("{{\\mathcal L}}")#text(". Since ")#mi("{{\\mathcal L}}")#text(" has at most countably many symbols, ")#mi("{{\\mathcal S}}")#text(" is at most countable, and so (by the sequential ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff theorem")]#text(") ")#mi("{\\{0,1\\}^{{\\mathcal S}}}")#text(" is sequentially compact in the product topology. (This can also be seen directly by the usual ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli")]#text(" diagonalisation argument.) Thus we can find a subsequence ")#mi("{\\text{Th}({\\mathfrak U}_{n_j})}")#text(" which converges in the product topology to a limit theory ")#mi("{\\Gamma \\in \\{0,1\\}^{{\\mathcal S}}}")#text(", thus every sentence in ")#mi("{\\Gamma}")#text(" is satisfied by ")#mi("{{\\mathfrak U}_{n_j}}")#text(" for sufficiently large ")#mi("{j}")#text(" (and every sentence not in ")#mi("{\\Gamma}")#text(" is not satisfied by ")#mi("{{\\mathfrak U}_{n_j}}")#text(" for sufficiently large ")#mi("{j}")#text("). In particular, any finite subset of ")#mi("{\\Gamma}")#text(" is satisfiable, hence consistent; by the compactness theorem, ")#mi("{\\Gamma}")#text(" itself is therefore consistent, and has an at most countable model ")#mi("{{\\mathfrak U}}")#text(". Also, each of the theories ")#mi("{\\text{Th}({\\mathfrak U}_{n_j})}")#text(" is clearly complete (given any sentence ")#mi("{\\phi}")#text(", either ")#mi("{\\phi}")#text(" or ")#mi("{\\neg \\phi}")#text(" is in the theory), and so ")#mi("{\\Gamma}")#text(" is complete as well. One concludes that ")#mi("{\\Gamma}")#text(" is the theory of ")#mi("{{\\mathfrak U}}")#text(", and hence ")#mi("{{\\mathfrak U}}")#text(" is the elementary limit of the ")#mi("{{\\mathfrak U}_{n_j}}")#text(" as claimed. ")#mi("\\Box")

#text("[It is also possible to state the compactness theorem using the topological notion of compactness, as follows: let ")#mi("{X}")#text(" be the space of all structures of a given language ")#mi("{{\\mathcal L}}")#text(", quotiented by elementary equivalence. One can define a topology on ")#mi("{X}")#text(" by taking the sets ")#mi("{\\{ {\\mathfrak U} \\in X: {\\mathfrak U} \\models \\phi \\}}")#text(" as a sub-base, where ")#mi("{\\phi}")#text(" ranges over all sentences. Then the compactness theorem is equivalent to the assertion that ")#mi("{X}")#text(" is topologically compact.]")

#text("One can use the sequential compactness theorem to build a number of interesting “non-standard” models to various theories. For instance, consider the language ")#mi("{{\\mathcal L}}")#text(" used by Peano arithmetic (which contains the operations ")#mi("{+, \\times}")#text(" and the successor operation ")#mi("{S}")#text(", the relation ")#mi("{=}")#text(", and the constant ")#mi("{0}")#text("), and adjoint a new constant ")#mi("{N}")#text(" to create an expanded language ")#mi("{{\\mathcal L} \\cup \\{N\\}}")#text(". For each natural number ")#mi("{n \\in {\\Bbb N}}")#text(", let ")#mi("{{\\Bbb N}_n}")#text(" be a structure for ")#mi("{{\\mathcal L} \\cup \\{N\\}}")#text(" which consists of the natural numbers ")#mi("{{\\Bbb N}}")#text(" (with the usual interpretations of ")#mi("{+}")#text(", ")#mi("{\\times}")#text(", etc.) and interprets the symbol ")#mi("{N}")#text(" as the natural number ")#mi("{n}")#text(". By the compactness theorem, some subsequence of ")#mi("{{\\Bbb N}_n}")#text(" must converge elementarily to a new structure ")#mi("{*{\\Bbb N}}")#text(" of ")#mi("{{\\mathcal L} \\cup \\{N\\}}")#text(", which still models Peano arithmetic, but now has the additional property that ")#mi("{N>n}")#text(" for every (standard) natural number ")#mi("{n}")#text("; thus we have managed to create a non-standard model of Peano arithmetic which contains a non-standardly large number (one which is larger than every standard natural number).")

#text("The sequential compactness theorem also lets us construct infinitary limits of various sequences of finitary objects; for instance, one can construct infinite pseudo-finite fields as the elementary limits of sequences of finite fields. I recently discovered that other several ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("correspondence principles")]#text(" between finitary and infinitary objects, such as the Furstenberg correspondence principle between sets of integers and dynamical systems, or the more recent correspondence principles concerning graph limits, can be viewed as special cases of the sequential compactness theorem; it also seems possible to encode much of the sum-product theory in finite fields in an infinitary setting using this theorem. I hope to discuss these points in more detail in a later post. In this post, I wish to review (partly for my own benefit) the proof of the completeness (and hence compactness) theorem. The material here is quite standard (I basically follow the usual proof of Henkin, and taking advantage of ")#link("http://en.wikipedia.org/wiki/Skolemization")[#text("Skolemisation")]#text("), but perhaps the concept of an elementary limit is not as well-known outside of logic as it might be. (The closely related concept of an ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" is better known, and can be used to prove most of the compactness theorem already, thanks to ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27_theorem")[#text("Los’s theorem")]#text(", but I do not know how to use ultraproducts to ensure that the limiting model is countable. However, one can think (intuitively, at least), of the limit model ")#mi("{{\\mathfrak U}}")#text(" in the above theorem as being the set of “constructible” elements of an ultraproduct of the ")#mi("{{\\mathfrak U}_n}")#text(".)")

#text("In order to emphasise the main ideas in the proof, I will gloss over some of the more technical details in the proofs, relying instead on informal arguments and examples at various points.")

#metadata(none) <tao-9e7c711ef777db70ca5f>

#heading(level: 1)[#strong[#text(" — 1. Completeness and compactness in propositional logic — ")]]

#text("The completeness and compactness theorems are results in first-order logic. But to motivate some of the ideas in proving these theorems, let us first consider the simpler case of ")#link("http://en.wikipedia.org/wiki/Propositional_calculus")[#text("propositional logic")]#text(". The language ")#mi("{{\\mathcal L}}")#text(" of a propositional logic consists of the following:")

#list(
[#text("A finite or infinite collection ")#mi("{A_1, A_2, A_3, \\ldots}")#text(" of ")#link("http://en.wikipedia.org/wiki/Propositional_variable")[#text("propositional variables")]#text(" – ")#link("http://en.wikipedia.org/wiki/Atomic_formula")[#text("atomic formulae")]#text(" which could be true or false, depending on the interpretation;")],
[#text("A collection of ")#link("http://en.wikipedia.org/wiki/Logical_connective")[#text("logical connectives")]#text(", such as ")#link("http://en.wikipedia.org/wiki/Logical_conjunction")[#text("conjunction")]#text(" ")#mi("{\\wedge}")#text(", ")#link("http://en.wikipedia.org/wiki/Logical_disjunction")[#text("disjunction")]#text(" ")#mi("{\\vee}")#text(", ")#link("http://en.wikipedia.org/wiki/Negation")[#text("negation")]#text(" ")#mi("{\\neg}")#text(", or ")#link("http://en.wikipedia.org/wiki/Material_conditional")[#text("implication")]#text(" ")#mi("{\\implies}")#text(". (The exact choice of which logical connectives to include in the language is to some extent a matter of taste.)")],
[#text("Parentheses (in order to indicate the order of operations).")]
)

#text("Of course, we assume that the symbols used for atomic formulae are distinct from those used for logical connectives, or for parentheses; we will implicitly make similar assumptions of this type in later sections without further comment.")

#text("Using this language, one can form ")#emph[#text("sentences")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Formula_(mathematical_logic)")[#text("formulae")]#text(") by some standard formal rules which I will not write down here. Typical examples of sentences in propositional logic are ")#mi("{A_1 \\implies (A_2 \\vee A_3)}")#text(", ")#mi("{(A_1 \\wedge \\neg A_1) \\implies A_2}")#text(", and ")#mi("{(A_1 \\wedge A_2) \\vee (A_1 \\wedge A_3)}")#text(". Each sentence is of finite length, and thus involves at most finitely many of the propositional variables. Observe that if ")#mi("{{\\mathcal L}}")#text(" is at most countable, then there are at most countably many sentences.")

#text("The analogue of a structure in propositional logic is a ")#emph[#text("truth assignment")]#text(". A truth assignment ")#mi("{{\\mathfrak U}}")#text(" for a propositional language ")#mi("{{\\mathcal L}}")#text(" consists of a truth value ")#mi("{A_n^{\\mathfrak U} \\in \\{ \\text{true}, \\text{false} \\}}")#text(" assigned to each propositional variable ")#mi("{A_n}")#text(". (Thus, for instance, if there are ")#mi("{N}")#text(" propositional variables in the language, then there are ")#mi("{2^N}")#text(" possible truth assignments.) Once a truth assignment ")#mi("{{\\mathfrak U}}")#text(" has assigned a truth value ")#mi("{A_n^{\\mathfrak U}}")#text(" to each propositional variable ")#mi("{A_n}")#text(", it can then assign a truth value ")#mi("{\\phi^{\\mathfrak U}}")#text(" to any other sentence ")#mi("{\\phi}")#text(" in the language ")#mi("{{\\mathcal L}}")#text(" by using the usual truth tables for conjunction, negation, etc.; we write ")#mi("{{\\mathfrak U} \\models \\phi}")#text(" if ")#mi("{{\\mathfrak U}}")#text(" assigns a true value to ")#mi("{\\phi}")#text(" (and say that ")#mi("{\\phi}")#text(" is ")#emph[#text("satisfied")]#text(" by ")#mi("{{\\mathfrak U}}")#text("), and ")#mi("{{\\mathfrak U} \\not \\models \\phi}")#text(" otherwise. Thus, for instance, if ")#mi("{A_1^{\\mathfrak U} = \\text{false}}")#text(" and ")#mi("{A_2^{\\mathfrak U} = \\text{true}}")#text(", then ")#mi("{{\\mathfrak U} \\models A_1 \\vee A_2}")#text(" and ")#mi("{{\\mathfrak U} \\models A_1 \\implies A_2}")#text(", but ")#mi("{{\\mathfrak U} \\not \\models A_2 \\implies A_1}")#text(". Some sentences, e.g. ")#mi("{A_1 \\vee \\neg A_1}")#text(", are true in every truth assignment; these are the (semantic) ")#link("http://en.wikipedia.org/wiki/Tautology_(logic)")[#text("tautologies")]#text(". At the other extreme, the negation of a tautology will of course be false in every truth assignment.")

#text("A ")#emph[#text("theory")]#text(" ")#mi("{\\Gamma}")#text(" is a language ")#mi("{{\\mathcal L}}")#text(", together with a (finite or infinite) collection of sentences (also called ")#mi("{\\Gamma}")#text(") in that language. A truth assignment ")#mi("{{\\mathfrak U}}")#text(" ")#emph[#text("satisfies")]#text(" (or ")#emph[#text("models")]#text(") the theory ")#mi("{\\Gamma}")#text(", and we write ")#mi("{{\\mathfrak U} \\models \\Gamma}")#text(", if we have ")#mi("{{\\mathfrak U} \\models \\phi}")#text(" for all ")#mi("{\\phi \\in \\Gamma}")#text(". Thus, for instance, if ")#mi("{{\\mathfrak U}}")#text(" is as in the preceding example and ")#mi("{\\Gamma := \\{ \\neg A_1, A_1 \\implies A_2 \\}}")#text(", then ")#mi("{{\\mathfrak U} \\models \\Gamma}")#text(".")

#text("The analogue of the Gödel completeness theorem is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Completeness theorem for propositional logic)")]#text(" ")#metadata(none) <tao-6cd08655b271ddd066f1>#text(" Let ")#mi("{\\Gamma}")#text(" be a theory for a propositional language ")#mi("{{\\mathcal L}}")#text(", and let ")#mi("{\\phi}")#text(" be a sentence in ")#mi("{{\\mathcal L}}")#text(". Then the following are equivalent:")

#list(
[#text("(i) (Syntactic consequence) ")#mi("{\\phi}")#text(" can be deduced from the axioms in ")#mi("{\\Gamma}")#text(" by a finite number of applications of the ")#link("http://en.wikipedia.org/wiki/Propositional_logic")[#text("laws of propositional logic")]#text(".")],
[#text("(ii) (Semantic consequence) Every truth assignment ")#mi("{{\\mathfrak U}}")#text(" which satisfies (or models) ")#mi("{\\Gamma}")#text(", also satisfies ")#mi("{\\phi}")#text(".")]
)
]

#text("One can list a complete set of laws of propositional logic used in (i), but we will not do so here.")

#text("To prove the completeness theorem, it suffices to show the following equivalent version.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Completeness theorem for propositional logic, again)")]#text(" ")#metadata(none) <tao-a61df75c3000cfeb7ab5>#text(" Let ")#mi("{\\Gamma}")#text(" be a theory for a propositional language ")#mi("{{\\mathcal L}}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\Gamma}")#text(" is ")#link("http://en.wikipedia.org/wiki/Consistency")[#text("consistent")]#text(", i.e. it is not possible to logically deduce a contradiction from the axioms in ")#mi("{\\Gamma}")#text(".")],
[#text("(ii) ")#mi("{\\Gamma}")#text(" is ")#emph[#text("satisfiable")]#text(", i.e. there exists a truth assignment ")#mi("{{\\mathfrak U}}")#text(" that models ")#mi("{\\Gamma}")#text(".")]
)
]

#text("Indeed, Theorem ")#link(<tao-6cd08655b271ddd066f1>)[#text("4")]#text(" follows from Theorem ")#link(<tao-a61df75c3000cfeb7ab5>)[#text("5")]#text(" by applying Theorem ")#link(<tao-a61df75c3000cfeb7ab5>)[#text("5")]#text(" to the theory ")#mi("{\\Gamma \\cup \\{ \\neg \\phi \\}}")#text(" and taking contrapositives.")

#text("It remains to prove Theorem ")#link(<tao-a61df75c3000cfeb7ab5>)[#text("5")]#text(". It is easy to deduce (i) from (ii), because the laws of propositional logic are ")#link("http://en.wikipedia.org/wiki/Soundness")[#text("sound")]#text(": given any truth assignment, it is easy to verify that these laws can only produce true conclusions given true hypotheses. The more interesting implication is to obtain (ii) from (i) – given a consistent theory ")#mi("{\\Gamma}")#text(", one needs to produce a truth assignment that models that theory.")

#text("Let’s first consider the case when the propositional language ")#mi("{{\\mathcal L}}")#text(" is finite, so that there are only finitely many propositional variables ")#mi("{A_1,\\ldots,A_N}")#text(". Then we can argue using the following “greedy algorithm”.")

#list(
[#text("We begin with a consistent theory ")#mi("{\\Gamma}")#text(".")],
[#text("Observe that at least one of ")#mi("{\\Gamma \\cup \\{ A_1 \\}}")#text(" or ")#mi("{\\Gamma \\cup \\{ \\neg A_1 \\}}")#text(" must be consistent. For if both ")#mi("{\\Gamma \\cup \\{ A_1 \\}}")#text(" and ")#mi("{\\Gamma \\cup \\{ \\neg A_1 \\}}")#text(" led to a logical contradiction, then by the laws of logic one can show that ")#mi("{\\Gamma}")#text(" must also lead to a logical contradiction.")],
[#text("If ")#mi("{\\Gamma \\cup \\{A_1\\}}")#text(" is consistent, we set ")#mi("{A_1^{\\mathfrak U} := \\text{true}}")#text(" and ")#mi("{\\Gamma_1 := \\Gamma \\cup \\{A_1\\}}")#text("; otherwise, we set ")#mi("{A_1^{\\mathfrak U} := \\text{false}}")#text(" and ")#mi("{\\Gamma_1 := \\Gamma \\cup \\{\\neg A_1\\}}")#text(".")],
[#mi("{\\Gamma_1}")#text(" is consistent, so arguing as before we know that at least one of ")#mi("{\\Gamma_1 \\cup \\{A_2\\}}")#text(" or ")#mi("{\\Gamma_1 \\cup \\{\\neg A_2\\}}")#text(" must be consistent. If the former is consistent, we set ")#mi("{A_2^{\\mathfrak U} := \\text{true}}")#text(" and ")#mi("{\\Gamma_2 := \\Gamma_1 \\cup \\{A_2\\}}")#text("; otherwise set ")#mi("{A_2^{\\mathfrak U} := \\text{false}}")#text(" and ")#mi("{\\Gamma_2 := \\Gamma_1 \\cup \\{\\neg A_2\\}}")#text(".")],
[#text("We continue in this fashion, eventually ending up with a consistent theory ")#mi("{\\Gamma_N}")#text(" containing ")#mi("{\\Gamma}")#text(", and a complete truth assignment ")#mi("{{\\mathfrak U}}")#text(" such that ")#mi("{A_n \\in \\Gamma_N}")#text(" whenever ")#mi("{1 \\leq n \\leq N}")#text(" is such that ")#mi("{A_n^{\\mathfrak U} = \\text{true}}")#text(", and such that ")#mi("{\\neg A_n \\in \\Gamma_N}")#text(" whenever ")#mi("{1 \\leq n \\leq N}")#text(" is such that ")#mi("{A_n^{\\mathfrak U} = \\text{false}}")#text(".")],
[#text("From the laws of logic and an induction argument, one then sees that if ")#mi("{\\phi}")#text(" is any sentence with ")#mi("{\\phi^{\\mathfrak U} = \\text{true}}")#text(", then ")#mi("{\\phi}")#text(" is a logical consequence of ")#mi("{\\Gamma_N}")#text(", and hence (since ")#mi("{\\Gamma_N}")#text(" is consistent) ")#mi("{\\neg \\phi}")#text(" is not a consequence of ")#mi("{\\Gamma_N}")#text(". Taking contrapositives, we see that ")#mi("{\\phi^{\\mathfrak U} = \\text{false}}")#text(" whenever ")#mi("{\\neg \\phi}")#text(" is a consequence of ")#mi("{\\Gamma_N}")#text("; replacing ")#mi("{\\phi}")#text(" by ")#mi("{\\neg \\phi}")#text(" we conclude that ")#mi("{{\\mathfrak U}}")#text(" satisfies every sentence in ")#mi("{\\Gamma_N}")#text(", and the claim follows.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument shows in particular that any finite theory either has a model or a proof of a contradictory statement (such as ")#mi("{A \\wedge \\neg A}")#text("). Actually producing a model if it exists, though, is essentially the infamous ")#link("http://en.wikipedia.org/wiki/Satisfiability_problem")[#text("satisfiability problem")]#text(", which is known to be NP-complete, and thus (if ")#mi("{P \\neq NP}")#text(") would require super-polynomial time to execute.")
]

#text("The case of an infinite language can be obtained by combining the above argument with ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(" and the axiom of choice, if the set of propositional variables happens to be well-ordered). Alternatively, one can proceed by establishing")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Compactness theorem for propositional logic)")]#text(" ")#metadata(none) <tao-b508618e7542809e5a29>#text(" Let ")#mi("{\\Gamma}")#text(" be a theory for a propositional language ")#mi("{{\\mathcal L}}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\Gamma}")#text(" is satisfiable.")],
[#text("(ii) Every finite subset ")#mi("{\\Gamma^{\\prime}}")#text(" of ")#mi("{\\Gamma}")#text(" is satisfiable.")]
)
]

#text("It is easy to see that Theorem ")#link(<tao-b508618e7542809e5a29>)[#text("6")]#text(" will allow us to use the finite case of Theorem ")#link(<tao-a61df75c3000cfeb7ab5>)[#text("5")]#text(" to deduce the infinite case, so it remains to prove Theorem ")#link(<tao-b508618e7542809e5a29>)[#text("6")]#text(". The implication of (ii) from (i) is trivial; the interesting implication is the converse.")

#text("Observe that there is a one-to-one correspondence between truth assignments ")#mi("{{\\mathfrak U}}")#text(" and elements of the product space ")#mi("{\\{0,1\\}^{\\mathcal A}}")#text(", where ")#mi("{{\\mathcal A}}")#text(" is the set of propositional variables. For every sentence ")#mi("{\\phi}")#text(", let ")#mi("{F_\\phi \\subset \\{0,1\\}^{\\mathcal A}}")#text(" be the collection of all truth assignments that satisfy ")#mi("{\\phi}")#text("; observe that this is a closed (and open) subset of ")#mi("{\\{0,1\\}^{\\mathcal A}}")#text(" in the product topology (basically because ")#mi("{\\phi}")#text(" only involves finitely many of the propositional variables). If every finite subset ")#mi("{\\Gamma^{\\prime}}")#text(" of ")#mi("{\\Gamma}")#text(" is satisfiable, then ")#mi("{\\bigcap_{\\phi \\in \\Gamma^{\\prime}} F_\\phi}")#text(" is non-empty; thus the family ")#mi("{(F_\\phi)_{\\phi \\in \\Gamma}}")#text(" of closed sets enjoys the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(". On the other hand, from ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(", ")#mi("{\\{0,1\\}^{\\mathcal A}}")#text(" is compact. We conclude that ")#mi("{\\bigcap_{\\phi \\in \\Gamma} F_\\phi}")#text(" is non-empty, and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" While Tychonoff’s theorem in full generality is equivalent to the axiom of choice, it is possible to prove the compactness theorem using a weaker version of this axiom, namely the ")#link("http://en.wikipedia.org/wiki/Ultrafilter_lemma#The_ultrafilter_lemma")[#text("ultrafilter lemma")]#text(". In fact, the compactness theorem is logically equivalent to this lemma.")
]

#heading(level: 1)[#strong[#text(" — 2. Zeroth-order logic — ")]]

#text("Propositional logic is far too limited a language to do much mathematics. Let’s make the language a bit more expressive, by adding constants, operations, relations, and (optionally) the equals sign; however, we refrain at this stage from adding variables or quantifiers, making this a ")#link("http://en.wikipedia.org/wiki/Zeroth-order_logic")[#text("zeroth-order logic")]#text(" rather than a first-order one.")

#text("A zeroth-order language ")#mi("{{\\mathcal L}}")#text(" consists of the following objects:")

#list(
[#text("A (finite or infinite) collection ")#mi("{A_1, A_2, A_3, \\ldots}")#text(" of propositional variables;")],
[#text("A collection ")#mi("{R_1, R_2, R_3, \\ldots}")#text(" of ")#emph[#text("relations")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Predicate")[#text("predicates")]#text("), with each ")#mi("{R_i}")#text(" having an ")#link("http://en.wikipedia.org/wiki/Arity")[#text("arity")]#text(" (or ")#emph[#text("valence")]#text(") ")#mi("{a[R_i]}")#text(" (e.g. unary relation, binary relation, etc.);")],
[#text("A collection ")#mi("{c_1, c_2, c_3, \\ldots}")#text(" of constants;")],
[#text("A collection ")#mi("{f_1, f_2, f_3, \\ldots}")#text(" of ")#emph[#text("operators")]#text(" (or functions), with each operator ")#mi("{f_i}")#text(" having an arity ")#mi("{a[f_i]}")#text(" (e.g. unary operator, binary operator, etc.);")],
[#text("Logical connectives;")],
[#text("Parentheses;")],
[#text("Optionally, the equals sign ")#mi("{=}")#text(".")]
)

#text("For instance, a zeroth-order language for arithmetic on the natural numbers might include the constants ")#mi("{0, 1, 2, \\ldots}")#text(", the binary relations ")#mi("{<, \\leq , >, \\geq}")#text(", the binary operations ")#mi("{+, \\times}")#text(", the unary successor operation ")#mi("{S}")#text(", and the equals sign ")#mi("{=}")#text(". A zeroth-order language for studying all groups generated by six elements might include six generators ")#mi("{a_1,\\ldots,a_6}")#text(" and the identity element ")#mi("{e}")#text(" as constants, as well as the binary operation ")#mi("{\\cdot}")#text(" of group multiplication and the unary operation ")#mi("{()^{-1}}")#text(" of group inversion, together with the equals sign ")#mi("{=}")#text(". And so forth.")

#text("Note that one could shorten the description of such languages by viewing propositional variables as relations of arity zero, and similarly viewing constants as operators of arity zero, but I find it conceptually clearer to leave these two operations separate, at least initially. As we shall see shortly, one can also essentially eliminate the privileged role of the equals sign ")#mi("{=}")#text(" by treating it as just another binary relation, which happens to have ")#link("http://en.wikipedia.org/wiki/First-order_logic#Equality_and_its_axioms")[#text("some standard axioms")]#text(" attached to it.")

#text("By combining constants and operators together in the usual fashion one can create ")#link("http://en.wikipedia.org/wiki/First_order_logic#Terms")[#text("terms")]#text("; for instance, in the zeroth-order language for arithmetic, ")#mi("{3+(4 \\times 5)}")#text(" is a term. By inserting terms into a predicate or relation (or the equals sign ")#mi("{=}")#text("), or using a propositional variable, one obtains an ")#link("http://en.wikipedia.org/wiki/Atomic_formula")[#text("atomic formula")]#text("; thus for instance ")#mi("{3+(4 \\times 5) > 25}")#text(" is an atomic formula. By combining atomic formulae using logical connectives, one obtains a sentence (or ")#link("http://en.wikipedia.org/wiki/Formula_(mathematical_logic)")[#text("formula")]#text("); thus for instance ")#mi("{((4 \\times 5) > 22) \\implies (3 + (4\\times 5) > 25)}")#text(" is a sentence.")

#text("In order to assign meaning to sentences, we need the notion of a ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structure")]#text(" ")#mi("{{\\mathfrak U}}")#text(" for a zeroth-order language ")#mi("{{\\mathcal L}}")#text(". A structure consists of the following objects:")

#list(
[#text("A ")#link("http://en.wikipedia.org/wiki/Domain_of_discourse")[#text("domain of discourse")]#text(" (or ")#emph[#text("universe of discourse")]#text(") ")#mi("{\\text{Dom}({\\mathfrak U})}")#text(";")],
[#text("An assignment of a value ")#mi("{c_n^{\\mathfrak U} \\in \\text{Dom}({\\mathfrak U})}")#text(" to every constant ")#mi("{c_n}")#text(";")],
[#text("An assignment of a function ")#mi("{f_n^{\\mathfrak U}: \\text{Dom}({\\mathfrak U})^{a[f_n]} \\rightarrow \\text{Dom}({\\mathfrak U})}")#text(" to every operation ")#mi("{f_n}")#text(";")],
[#text("An assignment of a truth value ")#mi("{A_n^{\\mathfrak U} \\in \\{ \\text{true}, \\text{false}\\}}")#text(" to every propositional variable ")#mi("{A_n}")#text(";")],
[#text("An assignment of a function ")#mi("{R_n^{\\mathfrak U}: \\text{Dom}({\\mathfrak U})^{a[R_n]} \\{ \\text{true}, \\text{false}\\}}")#text(" to every relation ")#mi("{R_n}")#text(".")]
)

#text("For instance, if ")#mi("{{\\mathcal L}}")#text(" is the language of groups with six generators discussed above, then a structure ")#mi("{\\mathfrak U}")#text(" would consist of a set ")#mi("{G = \\text{Dom}({\\mathfrak U})}")#text(", seven elements ")#mi("{a_1^{\\mathfrak U},\\ldots,a_6^{\\mathfrak U}, e^{\\mathfrak U} \\in G}")#text(" in that set, a binary operation ")#mi("{\\cdot^{\\mathfrak U}: G \\times G \\rightarrow G}")#text(", and a unary operation ")#mi("{(()^{-1})^{\\mathfrak U}: G \\rightarrow G}")#text(". At present, no group-type properties are assumed on these operations; the structure here is little more than a ")#link("http://en.wikipedia.org/wiki/Magma_(algebra)")[#text("magma")]#text(" at this point.")

#text("Every sentence ")#mi("{\\phi}")#text(" in a zeroth-order language ")#mi("{{\\mathcal L}}")#text(" can be interpreted in a structure ")#mi("{{\\mathfrak U}}")#text(" for that language to give a truth value ")#mi("{\\phi^{\\mathfrak U} \\in \\{ \\text{true}, \\text{false}\\}}")#text(", simply by substituting all symbols ")#mi("{\\alpha}")#text(" in the language with their interpreted counterparts ")#mi("{\\alpha^{\\mathfrak U}}")#text(" (note that the equals sign ")#mi("{=}")#text(" does not need any additional data in order to be interpreted). For instance, the sentence ")#mi("{a_1 \\cdot a_2 = a_3}")#text(" is true in ")#mi("{{\\mathfrak U}}")#text(" if ")#mi("{a_1^{\\mathfrak U} \\cdot^{\\mathfrak U} a_2^{\\mathfrak U} = a_3^{\\mathfrak U}}")#text(". Similarly, every term ")#mi("{t}")#text(" in the language can be interpreted to give a value ")#mi("{t^{\\mathfrak U}}")#text(" in the domain of discourse ")#mi("{\\text{Dom}({\\mathfrak U})}")#text(".")

#text("As before, a theory is a collection of sentences; we can define satisfiability ")#mi("{{\\mathfrak U} \\models \\phi}")#text(", ")#mi("{{\\mathfrak U} \\models \\Gamma}")#text(" of a sentence ")#mi("{\\phi}")#text(" or a theory ")#mi("{\\Gamma}")#text(" by a structure ")#mi("{{\\mathfrak U}}")#text(" just as in the previous section. For instance, to describe groups with at most six generators in the language ")#mi("{{\\mathcal L}}")#text(", one might use the theory ")#mi("{\\Gamma}")#text(" which consists of all the group axioms, specialised to terms, e.g. ")#mi("{\\Gamma}")#text(" would contain the associativity axioms ")#mi("{t_1 \\cdot (t_2 \\cdot t_3) = (t_1 \\cdot t_2) \\cdot t_3}")#text(" for all choices of terms ")#mi("{t_1, t_2, t_3}")#text(". (Note that this theory is not quite strong enough to capture the concept of a structure ")#mi("{{\\mathfrak U}}")#text(" being a group generated by six elements, because the domain of ")#mi("{{\\mathfrak U}}")#text(" may contain some “inaccessible” elements which are not the interpretation of any term in ")#mi("{{\\mathcal L}}")#text(", but without the universal quantifier, there is not much we can do in zeroth-order logic to say anything about those elements, and so this is pretty much the best we can do with this limited logic.)")

#text("Now we can state the completeness theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Completeness theorem for zeroth-order logic)")]#text(" ")#metadata(none) <tao-ecfc8b960dcc5ac155ed>#text(" Let ")#mi("{\\Gamma}")#text(" be a theory for a zeroth-order language ")#mi("{{\\mathcal L}}")#text(", and let ")#mi("{\\phi}")#text(" be a sentence in ")#mi("{{\\mathcal L}}")#text(". Then the following are equivalent:")

#list(
[#text("(i) (Syntactic consequence) ")#mi("{\\phi}")#text(" can be deduced from the axioms in ")#mi("{\\Gamma}")#text(" by a finite number of applications of the laws of zeroth-order logic (i.e. all the ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("laws of first-order logic")]#text(" that do not involve variables or quantifiers).")],
[#text("(ii) (Semantic consequence) Every truth assignment ")#mi("{{\\mathfrak U}}")#text(" which satisfies (or models) ")#mi("{\\Gamma}")#text(", also satisfies ")#mi("{\\phi}")#text(".")]
)
]

#text("To prove this theorem, it suffices as before to show that every consistent theory ")#mi("{\\Gamma}")#text(" in a zeroth-order logic is satisfiable, and conversely. The converse implication is again straightforward (the laws of zeroth-order logic are easily seen to be sound); the main task is to show the forward direction, i.e.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-3c6842fd7b85f32e7890>#text(" Let ")#mi("{\\Gamma}")#text(" be a consistent zeroth-order theory. Then ")#mi("{\\Gamma}")#text(" has at least one model.")
]

#emph[#text("Proof:")]#text(" It is convenient to begin by eliminating the equality symbol from the language. Suppose we have already proven Proposition ")#link(<tao-3c6842fd7b85f32e7890>)[#text("8")]#text(" has already been shown for languages without the equality symbol. Then we claim that the proposition also holds for languages with the equality symbol. Indeed, given a consistent theory ")#mi("{\\Gamma}")#text(" in a language ")#mi("{{\\mathcal L}}")#text(" with equality, we can form a companion theory ")#mi("{\\Gamma^{\\prime}}")#text(" in the language ")#mi("{{\\mathcal L}^{\\prime}}")#text(" formed by removing the equality symbol from ")#mi("{{\\mathcal L}}")#text(" and replacing it with a new binary relation ")#mi("{=^{\\prime}}")#text(", by taking all the sentences in ")#mi("{\\Gamma}")#text(" and replacing ")#mi("{=}")#text(" by ")#mi("{=^{\\prime}}")#text(", and then adding in all the axioms of equality (with ")#mi("{=}")#text(" replaced by ")#mi("{=^{\\prime}}")#text(") to ")#mi("{\\Gamma^{\\prime}}")#text(". Thus, for instance, one would add the transitivity axioms ")#mi("{(x =^{\\prime} y) \\wedge (y =^{\\prime} z) \\implies (x =^{\\prime} z)}")#text(" to ")#mi("{\\Gamma}")#text(" for each triple of terms ")#mi("{x,y,z}")#text(", as well as substitution axioms such as ")#mi("{(x =^{\\prime} y) \\implies (B(x,z) =^{\\prime} B(y,z))}")#text(" for any terms ")#mi("{x,y,z}")#text(" and binary functions ")#mi("{B}")#text(". It is straightforward to verify that if ")#mi("{\\Gamma}")#text(" is consistent, then ")#mi("{\\Gamma^{\\prime}}")#text(" is also consistent, because any contradiction derived in ")#mi("{\\Gamma^{\\prime}}")#text(" can be translated to a contradiction derived in ")#mi("{\\Gamma}")#text(" simply by replacing ")#mi("{=^{\\prime}}")#text(" with ")#mi("{=}")#text(" throughout and using the axioms of equality. By hypothesis, we conclude that ")#mi("{\\Gamma^{\\prime}}")#text(" has some model ")#mi("{{\\mathfrak U}^{\\prime}}")#text(". By the axioms of equality, the interpretation ")#mi("{(=^{\\prime})^{{\\mathfrak U}^{\\prime}}}")#text(" of ")#mi("{=^{\\prime}}")#text(" in this model is then an ")#link("http://en.wikipedia.org/wiki/Equivalence_relation")[#text("equivalence relation")]#text(" on the domain ")#mi("{\\text{Dom}({\\mathfrak U}^{\\prime})}")#text(" of ")#mi("{{\\mathfrak U}^{\\prime}}")#text(". One can also remove from the domain of ")#mi("{{\\mathfrak U}^{\\prime}}")#text(" any element which is not of the form ")#mi("{t^{{\\mathfrak U}^{\\prime}}}")#text(" for some term ")#mi("{t}")#text(", as such “inaccessible” elements will not influence the satisfiability of ")#mi("{\\Gamma^{\\prime}}")#text(". We can then define a structure ")#mi("{{\\mathfrak U}}")#text(" for the original language ")#mi("{{\\mathfrak L}}")#text(" by ")#link("http://en.wikipedia.org/wiki/Quotient_set")[#text("quotienting")]#text(" the domain of ")#mi("{{\\mathfrak U}^{\\prime}}")#text(" by the equivalence relation ")#mi("{=^{\\prime}}")#text(", and also quotienting all the interpretations of the relations and operations of ")#mi("{{\\mathcal L}}")#text("; the axioms of equality ensure that this quotienting is possible, and that the quotiented structure ")#mi("{{\\mathfrak U}}")#text(" satisfies ")#mi("{{\\mathcal L}}")#text("; we omit the details.")

#text("Henceforth we assume that ")#mi("{{\\mathcal L}}")#text(" does not contain the equality sign. We will then choose a “tautological” domain of discourse ")#mi("{\\text{Dom}({\\mathfrak U})}")#text(", by setting this domain to be nothing more than the collection of all terms in the language ")#mi("{{\\mathcal L}}")#text(". For instance, in the language of groups on six generators, the domain ")#mi("{\\text{Dom}({\\mathfrak U})}")#text(" is basically the free magma (with “inverse”) on six generators plus an “identity”, consisting of terms such as ")#mi("{(a_1 \\cdot a_2)^{-1} \\cdot a_1}")#text(", ")#mi("{(e \\cdot a_3) \\cdot ((a_4)^{-1})^{-1}}")#text(", etc. With this choice of domain, there is an obvious “tautological” interpretation of constants (")#mi("{c^{\\mathfrak U} := c}")#text(") and operations (e.g. ")#mi("{B^{\\mathfrak U}(t_1, t_2) := B(t_1,t_2)^{\\mathfrak U}}")#text(" for binary operations ")#mi("{B}")#text(" and terms ")#mi("{t_1,t_2}")#text("), which leads to every term ")#mi("{t}")#text(" being interpreted as itself: ")#mi("{t^{\\mathfrak U} = t}")#text(".")

#text("It remains to figure out how to interpret the propositional variables ")#mi("{A_1, A_2, \\ldots}")#text(" and relations ")#mi("{R_1, R_2, \\ldots}")#text(". Actually, one can replace each relation with an equivalent collection of new propositional variables by substituting in all possible terms in the relation. For instance, if one has a binary relation ")#mi("{R(,)}")#text(", one can replace this single relation symbol in the language by a (possibly infinite) collection of propositional variables ")#mi("{R(t_1,t_2)}")#text(", one for each pair of terms ")#mi("{t_1,t_2}")#text(", leading to a new (and probably much larger) language ")#mi("{\\tilde L}")#text(" without any relation symbols. It is not hard to see that if theory ")#mi("{\\Gamma}")#text(" is consistent in ")#mi("{{\\mathcal L}}")#text(", then the theory ")#mi("{\\tilde \\Gamma}")#text(" in ")#mi("{\\tilde L}")#text(" formed by interpreting all atomic formulae such as ")#mi("{R(t_1,t_2)}")#text(" as propositional variables is also consistent. If ")#mi("{\\tilde \\Gamma}")#text(" has a model ")#mi("{\\tilde {\\mathfrak U}}")#text(" with the tautological domain of discourse, it is not hard to see that this can be converted to a model ")#mi("{{\\mathfrak U}}")#text(" of ")#mi("{\\Gamma}")#text(" with the same domain by defining the interpretation ")#mi("{R^{\\mathfrak U}}")#text(" of relations ")#mi("{R}")#text(" in the obvious manner.")

#text("So now we may assume that there are no relation symbols, so that ")#mi("{\\Gamma}")#text(" now consists entirely of propositional sentences involving the propositional variables. But the claim now follows from the completeness theorem in propositional logic. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The above proof can be viewed as a combination of the completeness theorem in propositional logic and the familiar procedure in algebra of constructing an algebraic object (e.g. a group) that obeys various relations, by starting with the free version of that object (e.g. a free group) and then quotienting out by the equivalence relation generated by those relations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Observe that if ")#mi("{{\\mathfrak L}}")#text(" is at most countable, then the structures ")#mi("{{\\mathfrak U}}")#text(" constructed by the above procedure are at most countable (because the set of terms is at most countable, and quotienting by an equivalence relation cannot increase the cardinality). Thus we see (as in Theorem ")#link(<tao-401ccc1785a6ca3f2af9>)[#text("1")]#text(" or Corollary ")#link(<tao-659eee59f002e69bf905>)[#text("2")]#text(") that if a zeroth-order theory in an at most countable language is satisfiable, then it is in fact satisfiable with an at most countable model.")
]

#text("From the completeness theorem for zeroth-order logic and the above remark we obtain the compactness theorem for zeroth-order logic, which is formulated exactly as in Corollary ")#link(<tao-659eee59f002e69bf905>)[#text("2")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. First-order logic — ")]]

#text("We are now ready to study languages which are expressive enough to do some serious mathematics, namely the languages of first-order logic, which are formed from zeroth-order logics by adding variables and quantifiers. (There are ")#link("http://en.wikipedia.org/wiki/Higher-order_logic")[#text("higher-order logics")]#text(" as well, but unfortunately the completeness and compactness theorems typically fail for these, and they will not be discussed here.)")

#text("A language ")#mi("{{\\mathcal L}}")#text(" for a first-order logic consists of the following:")

#list(
[#text("A (finite or infinite) collection ")#mi("{A_1, A_2, A_3, \\ldots}")#text(" of propositional variables;")],
[#text("A collection ")#mi("{R_1, R_2, R_3, \\ldots}")#text(" of relations, with each ")#mi("{R_i}")#text(" having an arity ")#mi("{a[R_i]}")#text(";")],
[#text("A collection ")#mi("{c_1, c_2, c_3, \\ldots}")#text(" of constants;")],
[#text("A collection ")#mi("{f_1, f_2, f_3, \\ldots}")#text(" of operators, with each ")#mi("{f_i}")#text(" having an arity ")#mi("{a[f_i]}")#text(";")],
[#text("A collection ")#mi("{x_1, x_2, x_3, \\ldots}")#text(" of variables;")],
[#text("Logical connectives;")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Quantification")[#text("quantifiers")]#text(" ")#mi("{\\forall, \\exists}")#text(";")],
[#text("Parentheses;")],
[#text("Optionally, the equals sign ")#mi("{=}")#text(".")]
)

#text("For instance, the language for Peano arithmetic includes a constant ")#mi("{0}")#text(", a unary operator ")#mi("{S}")#text(", binary operators ")#mi("{+, \\times}")#text(", the equals sign ")#mi("{=}")#text(", and a countably infinite number of variables ")#mi("{x_1, x_2, \\ldots}")#text(".")

#text("By combining constants, variables and operators together one creates terms; by inserting terms into predicates or relations, or using propositional variables, one obtains atomic formulae. These atomic formulae can contain a number of free variables. Using logical connectives as well as quantifiers to bind any or all of these variables, one obtains ")#link("http://en.wikipedia.org/wiki/Well-formed_formula")[#text("well-formed formulae")]#text("; a formula with no free variables is a ")#emph[#text("sentence")]#text(". Thus, for instance, ")#mi("{\\forall x_2: x_1+x_2=x_2+x_1}")#text(" is a well-formed formula, and ")#mi("{\\forall x_1 \\forall x_2: x_1+x_2=x_2+x_1}")#text(" is a sentence.")

#text("A structure ")#mi("{{\\mathfrak U}}")#text(" for a first-order language ")#mi("{{\\mathfrak L}}")#text(" is exactly the same concept as for a zeroth-order language: a domain of discourse, together with an interpretation of all the constants, operators, propositional variables, and relations in the language. Given a structure ")#mi("{{\\mathfrak U}}")#text(", one can interpret terms ")#mi("{t}")#text(" with no free variables as elements ")#mi("{t^{\\mathfrak U}}")#text(" of ")#mi("{\\text{Dom}({\\mathfrak U})}")#text(", and interpret sentences ")#mi("{\\phi}")#text(" as truth values ")#mi("{\\phi^{\\mathfrak U} \\in \\{ \\text{true}, \\text{false}\\}}")#text(", in the standard fashion.")

#text("A theory is, once again, a collection of sentences in the first-order language ")#mi("{{\\mathcal L}}")#text("; one can define what it means for a structure to satisfy a sentence or a theory just as before.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" In most fields of mathematics, one wishes to discuss several types of objects (e.g. numbers, sets, points, group elements, etc.) at once. For this, one would prefer to use a ")#emph[#text("typed")]#text(" language, in which variables, constants, and functions take values in one type of object, and relations and functions take only certain types of objects as input. However, one can easily model a typed theory using a typeless theory by the trick of adding some additional unary predicates to capture type (e.g. ")#mi("{N(x)}")#text(" to indicate the assertion “")#mi("{x}")#text(" is a natural number”, ")#mi("{S(x)}")#text(" to indicate the assertion “")#mi("{x}")#text(" is a set”, etc.) and modifying the axioms of the theory being considered accordingly. (For instance, in a language involving both natural numbers and other mathematical objects, one might impose a new closure axiom ")#mi("{\\forall x \\forall y: N(x) \\wedge N(y) \\implies N(x+y)}")#text(", and axioms such as the commutativity axiom ")#mi("{\\forall x \\forall y: x+y=y+x}")#text(" would need to be modified to ")#mi("{\\forall x \\forall y: N(x) \\wedge N(y) \\implies x+y=y+x}")#text(".) It is a tedious but routine matter to show that the completeness and compactness theorems for typeless first-order logic imply analogous results for typed first-order logic; we omit the details.")
]

#text("To prove the completeness (and hence compactness) theorem, it suffices as before to show that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" ")#metadata(none) <tao-b8ad1394977c0b1f92bb>#text(" Let ")#mi("{\\Gamma}")#text(" be a consistent first-order theory, with an at most countable language ")#mi("{{\\mathcal L}}")#text(". Then ")#mi("{\\Gamma}")#text(" has at least one model ")#mi("{{\\mathcal U}}")#text(", which is also at most countable.")
]

#text("We shall prove this result using a series of reductions. Firstly, we can mimic the arguments in the zeroth-order case and reduce to the case when ")#mi("{{\\mathcal L}}")#text(" does not contain the equality symbol. (We no longer need to restrict the domain of discourse to those elements which can be interpreted by terms, because the universal quantifier ")#mi("{\\forall}")#text(" is now available for use when stating the axioms of equality.) Henceforth we shall assume that the equality symbol is not present in the language.")

#text("Next, by using the laws of first-order logic to push all quantifiers in the sentences in ")#mi("{\\Gamma}")#text(" to the beginning (e.g. replacing ")#mi("{(\\forall x: P(x)) \\wedge (\\forall y: Q(y))}")#text(" with ")#mi("{\\forall x \\forall y: P(x) \\wedge Q(y)}")#text(") one may assume that all sentences in ")#mi("{\\Gamma}")#text(" are in ")#link("http://en.wikipedia.org/wiki/Prenex_normal_form")[#text("prenex normal form")]#text(", i.e. they consist of a “matrix” of quantifiers, followed by an ")#emph[#text("quantifier-free formula")]#text(" – a well-formed formula with no quantifiers. For instance, ")#mi("{\\forall x \\exists y \\forall z \\exists w: P(x,y,z,w)}")#text(" is in prenex normal form, where ")#mi("{P(x,y,z,w)}")#text(" is an quantifier-free formula with four free variables ")#mi("{x,y,z,w}")#text(".")

#text("Now we will start removing the existential quantifiers ")#mi("{\\exists}")#text(" from the sentences in ")#mi("{\\Gamma}")#text(". Let’s begin with a simple case, when ")#mi("{\\Gamma}")#text(" contains a sentence of the form ")#mi("{\\exists x: P(x)}")#text(" for some quantifier-free formula of one free variable ")#mi("{x}")#text(". Then one can eliminate the existential quantifier by introducing a ")#emph[#text("witness")]#text(", or more precisely adjoining a new constant ")#mi("{c}")#text(" to the language ")#mi("{{\\mathcal L}}")#text(" and replacing the statement ")#mi("{\\exists x: P(x)}")#text(" with the statement ")#mi("{P(c)}")#text(", giving rise to a new theory ")#mi("{\\Gamma^{\\prime}}")#text(" in a new language ")#mi("{\\Lambda^{\\prime}}")#text(". The consistency of ")#mi("{\\Gamma}")#text(" easily implies the consistency of ")#mi("{\\Gamma^{\\prime}}")#text(", while any at most countable model for ")#mi("{\\Gamma^{\\prime}}")#text(" can be easily converted to an at most countable model for ")#mi("{\\Gamma}")#text(" (by “forgetting” the symbol ")#mi("{c}")#text("). (In fact, ")#mi("{\\Gamma^{\\prime}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Conservative_extension")[#text("conservative extension")]#text(" of ")#mi("{\\Gamma}")#text(".) We can apply this reduction simultaneously to all sentences of the form ")#mi("{\\exists x: P(x)}")#text(" in ")#mi("{\\Gamma}")#text(" (thus potentially expanding the collection of constants in the language by a countable amount).")

#text("The same argument works for any sentence in prenex normal form in which all the existential quantifiers are to the left of the universal quantifiers, e.g. ")#mi("{\\exists x \\exists y \\forall z \\forall w: P(x,y,z,w)}")#text("; this statement requires two constants to separately witness ")#mi("{x}")#text(" and ")#mi("{y}")#text(", but otherwise one proceeds much as in the previous paragraph. But what about if one or more of the existential quantifiers is buried behind a universal quantifier? The trick is then to use ")#link("http://en.wikipedia.org/wiki/Skolemization")[#text("Skolemisation")]#text(". We illustrate this with the simplest case of this type, namely that of a sentence ")#mi("{\\forall x \\exists y: P(x,y)}")#text(". Here, one cannot use a constant witness for ")#mi("{y}")#text(". But this is no problem: one simply introduces a witness that depends on ")#mi("{x}")#text(". More precisely, one adjoins a new unary operator ")#mi("{c}")#text(" to the language ")#mi("{{\\mathcal L}}")#text(" and replaces the statement ")#mi("{\\forall x \\exists y: P(x,y)}")#text(" by ")#mi("{\\forall x: P(x,c(x))}")#text(", creating a new theory ")#mi("{\\Gamma^{\\prime}}")#text(" in a new language ")#mi("{\\Lambda^{\\prime}}")#text(". One can again show (though this is not entirely trivial) that the consistency of ")#mi("{\\Gamma}")#text(" implies the consistency of ")#mi("{\\Gamma^{\\prime}}")#text(", and that every countable model for ")#mi("{\\Gamma^{\\prime}}")#text(" can be converted to a countable model for ")#mi("{\\Gamma}")#text(" (again by “forgetting” ")#mi("{c}")#text("). So one can eliminate the existential quantifier from this sentence also. Similar methods work for any other prenex normal form; for instance with the sentence")

#align(center)[#tao-fit-display[#mitex("\\forall x \\exists y \\forall z \\exists w: P(x,y,z,w)")]]

#text("one can obtain a conservative extension of that theory by introducing a unary operator ")#mi("{c}")#text(" and a binary operator ")#mi("{d}")#text(" and replacing the above sentence with")

#align(center)[#tao-fit-display[#mitex("\\forall x \\forall z: P( x, c(x), z, d( x, z) ).")]]

#text("One can show that one can perform Skolemisation on all the sentences in ")#mi("{\\Gamma}")#text(" simultaneously, which has the effect of eliminating all existential quantifiers from ")#mi("{\\Gamma}")#text(" while still keeping the language ")#mi("{{\\mathcal L}}")#text(" at most countable (since ")#mi("{\\Gamma}")#text(" is at most countable). (Intuitively, what is going on here is that we are interpreting all existential axioms in the theory as implicitly defining functions, which we then explicitly formalise as a new symbol in the language. For instance, if we had some theory of sets which contained the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" (every family of non-empty sets ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" admits a ")#link("http://en.wikipedia.org/wiki/Choice_function")[#text("choice function")]#text(" ")#mi("{f: A \\rightarrow \\bigcup_{\\alpha \\in A} X_\\alpha}")#text("), then we can Skolemise this by introducing a “choice function function” ")#mi("{{\\mathcal F}: (X_\\alpha)_{\\alpha \\in A} \\mapsto {\\mathcal F}( (X_\\alpha)_{\\alpha \\in A} )}")#text(" that witnessed this axiom to the language. Note that we do not need uniqueness in the existential claim in order to be able to perform Skolemisation.)")

#text("After performing Skolemisation and adding all the witnesses to the language, we are reduced to the case in which all the sentences in ")#mi("{\\Gamma}")#text(" are in fact universal statements, i.e. of the form ")#mi("{\\forall x_1 \\ldots \\forall x_k: P(x_1,\\ldots,x_k)}")#text(", where ")#mi("{P(x_1,\\ldots,x_k)}")#text(" is an quantifier-free formula of ")#mi("{k}")#text(" free variables. In this case one can repeat the zeroth-order arguments, selecting a structure ")#mi("{{\\mathfrak U}}")#text(" whose domain of discourse is the tautological one, indexed by all the terms with no free variables (in particular, this structure will be countable). One can then replace each first-order statement ")#mi("{\\forall x_1 \\ldots \\forall x_k: P(x_1,\\ldots,x_k)}")#text(" in ")#mi("{\\Gamma}")#text(" by the family of zeroth-order statements ")#mi("{P(t_1,\\ldots,t_k)}")#text(", where ")#mi("{t_1,\\ldots,t_k}")#text(" ranges over all terms with no free variables, thus creating a zeroth-order theory ")#mi("{\\Gamma_0}")#text(". As ")#mi("{\\Gamma}")#text(" is consistent, ")#mi("{\\Gamma_0}")#text(" is also, so by the zeroth-order theory, we can find a model ")#mi("{{\\mathfrak U}}")#text(" for ")#mi("{\\Gamma_0}")#text(" with the tautological domain of discourse, and it is clear that this structure will also be a model for the original theory ")#mi("{\\Gamma}")#text(". The proof of the completeness theorem (and thus the compactness theorem) is now complete.")

#text("In summary: to create a countable model from a consistent first-order theory, one first replaces the equality sign ")#mi("{=}")#text(" (if any) by a binary relation ")#mi("{=^{\\prime}}")#text(", then uses Skolemisation to make all implied functions and operations explicit elements of the language. Next, one makes the zeroth-order terms of the new language the domain of discourse, applies a greedy algorithm to decide the truth assignment of all zeroth-order sentences, and then finally quotients out by the equivalence relation given by ")#mi("{=^{\\prime}}")#text(" to recover the countable model.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" I find the use of Skolemisation to greatly clarify, at a conceptual level, the proof of the completeness theorem. However, at a technical level it does make things more complicated: in particular, showing that the Skolemisation of a consistent theory is still consistent does require some non-trivial effort (one has to take all arguments involving the Skolem function ")#mi("{c()}")#text(", and replace every occurence of ")#mi("{c()}")#text(" by a “virtual” function, defined implicitly using existential quantifiers). On the other hand, this fact is easy to prove once one already ")#emph[#text("has")]#text(" the completeness theorem, though we of course cannot formally take advantage of this while trying to ")#emph[#text("prove")]#text(" that theorem!")

#text("The more traditional Henkin approach is based instead on adding a large number of constant witnesses, one for every existential statement: roughly speaking, for each existential sentence ")#mi("{\\exists x: P(x)}")#text(" in the language, one adds a new constant ")#mi("{c}")#text(" to the language and inserts an axiom ")#mi("{(\\exists x: P(x)) \\implies P(c)}")#text(" to the theory; it is easier to show that this preserves consistency than it is with a more general Skolemisation. Unfortunately, every time one adds a constant to the language, one increases the number of existential sentences for which one needs to perform this type of witnessing, but it turns out that after applying this procedure a countable number of times, one can get to the point where every existential sentence is automatically witnessed by some constant. This has the same ultimate effect as Skolemisation, namely one can convert sentences containing existential quantifiers to ones which are purely universal, and so the rest of the proof is much the same as the proof described above. On the other hand, the Henkin approach avoids the axiom of choice (though one still must use the ultrafilter lemma, of course).")
]

#heading(level: 1)[#text("Comments (51)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38117")[#strong[#text("Gödel, Hilbert and Brouwer « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2009")]

#text("[…] For a technical discussions of Gödel’s completeness and compactness theorem, see this post by Terry Tao. Possibly related posts: (automatically generated)About MathematicsWhy […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38126")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("In the paragraph before Corollary 2, you give the nonstandard natural numbers as an example of how theories of arithmetic are incomplete. However, the nonstandard natural numbers are intentionally constructed to be elementarily equivalent to the natural numbers. Indeed, they witness not the fact that recursively enumerable theories of arithmetic are incomplete but that ")#emph[#text("any")]#text(" first-order theory has “nonstandard”, large models (say, by upward Lowenheim-Skolem).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("Ah, good point. I suppose it is difficult to construct an example of a model of arithmetic that is not elementarily equivalent to N without going through most of the proof of the incompleteness theorem already, so I guess I will have to omit an example altogether in this paragraph…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("I am always curious about the motivation of these expository posts. Any self-motivated mathematician is always interested to learn new material (I have a growing mountain of “to read” papers on my desk). However, there always seems to be more pressing demands. For example, your previous work (and blog posts) suggest that you are currently part way through very promising (landmark?) projects related to the (1) regularity of wave maps, and (2) linear equations in the primes. Undoubtedly, you have other ongoing projects and professional responsibilies as well. So, I’m intrigued by the fact that you wake up one morning and say “I’m going to put major projects X,Y,Z,X’,Y’,Z’,etc on hold, while I learn about first-order logic.” This is, of course, curiosity and not criticism. This method obviously works for you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("That is great,")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("Just a little remark regarding extensions of first order logic:")#linebreak()#text(" You wrote:")#linebreak()#text(" “There are higher-order logics as well, but unfortunately the completeness and compactness theorems fail for these, and they will not be discussed here.”")

#text("In fact, by Lindstrom’s theorem, first order logic is the strongest logic that has the compactness property and the Lowenheim-Skolem property at Aleph_0. But it turns out that you can still work with a logic that is considerably stronger than FOL and yet is pretty much well-behaved, for example, Shelah’s extensions of FOL with cofinality quantifiers has the compactness property and LS property for Aleph_1.")

#text("There is a nice expository paper by Barwise on this subject which can be found here: ")#link("http://www.math.ucla.edu/~asl/bsl/1001/1001-004.ps")[#text("http://www.math.ucla.edu/~asl/bsl/1001/1001-004.ps")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("Dear Anonymous #1,")

#text("Actually, in many ways this post was indirectly motivated by the projects (1) and (2) you mention (I have been working on (1) this week, and was working on (2) a couple weeks ago, as these are indeed my two major projects), even though there is no direct connection in subject matter. A few weeks ago, in discussions with a colleague, I realised that the compactness theorem may have some relevance to yet another question I was interested in; but as I wanted to clear the way to return to my main projects, I decided to at least figure out to my satisfaction once and for all how the compactness theorem worked, so I could return to it later when there is some natural break in my other projects. [I also find that I need to intersperse some relatively basic projects such as these (or such as my class notes) between major research efforts, to avoid getting mentally exhausted or frustrated.] I do plan to write a post later regarding my motivation for looking at the compactness theorem, but this may have to wait for a more opportune time.")

#text("Dear Anonymous #3: thanks for the link! I think I will tone down “fail” to “typically fail’, given that there are indeed some higher-order logics for which some version of completeness or compactness holds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38145")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Thanks for the very interesting blog entry! Very well written for someone who has never attended a lecture in logic.")

#text("I’ve got a question for (ii) => (i) in Corollary 2: I don’t see how it immediately follows from Theorem 1 (ii) => (i) because in Cor. 2 I only have “there exists a structure …”, but in Thm. 1 I need “every structure …”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38146")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Ok, I guess I have to do something similiar to Thm 5 => Thm 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mistar grape")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38161")[#strong[#text("mistar grape")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("What sort of “more recent correspondence principles concerning graph limits” are yah talking about here? Is this the elek&szegedy paper, or something else?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelly Johnson")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38171")[#strong[#text("Kelly Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2009")])]

#text("Thanks, Terence. I appreciated the response to Anonymous #1, as I’ve often wondered that myself. It’s always encouraging to get your thoughts on time management since there never seems to be enough time in the day!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/140f21ff5cd3b8c2a5eaf6379f0dac81c4e88056c10ab125d9b94ba3d7053436-8e066f48f9dc516356d0827bff2a8550eb029828e3ff23d074adc97c28799893.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carson Chow")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38245")[#strong[#text("Carson Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Hi Terry,")

#text("I was wondering if in Theorems 4 and 7, that you meant to write that phi was a sentence in the language L, rather than a sentence in the theory Gamma of the language L.")

#text("Thanks,")#linebreak()#text(" Carson")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3529ef3432f19f545244ebd5f1dcf2e0c12c9d7a202f84575075a8a6a8f28b46-4e0415730b98015d10729ff930abd4ed7e2d3b9eb85d1d109c12918dde1913bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38250")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Hi Terry! Brilliant post! (As always)")

#text("Where could I look up more information about “elementary convergence”?")

#text("Also, do you know if it has been applied to (multi)digraphs?")

#text("I think this concept is what I was looking for in my ph.D. thesis.")

#text("Thanks and kindest regards,")#linebreak()#text(" Jose Brox")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f46902c1ea137a5f5668f80b93236977dda9247ecd0efc68cc31d00aeb64cfde-c15ce8cabde90bb10bf67a885fa374c34e5d214c2c3f8bc4093f66a4eec85691.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Goodrick")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38285")[#strong[#text("John Goodrick")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Thanks for posting this! I’m a model theorist and from what I’ve had time to look at so far it looks like a good explanation of the completeness theorem.")

#text("Couple of quick comments: first, I found it puzzling that your main results (Theorem 1, Corollary 2, etc.) you insisted that the language be countable. Compactness and completeness as they are normally stated (i.e. Theorem 1, parts (i) and (ii)) are true in *any* language, countable or not, and this is very important in model theory. E.g. the proof that consistent theories with infinite models have models of arbitrarily large cardinality goes by expanding to an uncountable language with lots of new constant symbols and applying Compactness.")

#text("Second, I don’t think your notion of “elementary convergence” of a sequence of models well-known even *within* logic. (I think this is the first time I’d heard of it!) I’m not quite sure if they’re good for anything that ultraproducts and reduced products aren’t already good for, but admittedly I haven’t thought about this much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear John,")

#text("Thanks for the comments. I restricted attention to countable languages in order to get a countable model at the end of the day (and also to simplify the notation a little bit in the proof) but of course the theorems extend to higher cardinalities (but now the cardinality of the model will be as large as the cardinality of the language). I had a little remark about this after Theorem 1, but can expand upon this. [Also, I think once one moves to uncountable languages, one loses ")#emph[#text("sequential")]#text(" compactness of theories, though one still has ")#emph[#text("topological")]#text(" compactness by Tychonoff’s theorem.]")

#text("Every ultraproduct of a sequence of structures is an elementary limit of those structures (Los’ theorem), so yes, ultraproducts can already do most of what elementary limits can do. The one thing which is nice about going through the completeness and/or Lowenheim-Skolem theorem, though is that one can get a countable elementary limit (which would correspond to restricting the ultraproduct to “constructible” elements of that ultraproduct, I think.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f46902c1ea137a5f5668f80b93236977dda9247ecd0efc68cc31d00aeb64cfde-c15ce8cabde90bb10bf67a885fa374c34e5d214c2c3f8bc4093f66a4eec85691.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Goodrick")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38346")[#strong[#text("John Goodrick")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("OK, now I see that you’re really proving Compactness plus downward Lowenheim-Skolem simultaneously, which is neat (this isn’t how I normally see it done).")

#text("I stand by an earlier point, though: your argument in Proposition 9 really has nothing at all to do with the countability of the language! Given any consistent theory T, there is always a consistent Skolemization T’ of T of size at most [cardinality of T] plus aleph-0, and the rest of your argument goes through from there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12e9b51b01ecf6b2f5d841204e35ab2d6c03b1522dbe3dde4b5c9d4eb2c376de-6a0191ac642a7488780182f58b190ce4e4c8910313c9c4127d07c8b87220d6e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nhung")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38539")[#strong[#text("nhung")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("i from viet nam.i can’t speak and wrtte english.i like math.but i learn no good.i amide you.sorry becauce i’m to bother you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zk")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38570")[#strong[#text("zk")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("It’s a great blog for learning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szemeredi’s regularity lemma via the correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38654")[#strong[#text("Szemeredi’s regularity lemma via the correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")])]

#text("[…] and Szegedy. It also seems to be related to the concept of an elementary limit that I discussed in this post, though this connection is still rather […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a2b8cfcdb007fc0068aae86e1fa7756c78ed3a869c0ce553b4efe0c33878fe-6d3a5819428ff3fa511ee659415c1505f75e6c398b2ed729ef5d814f497a1fb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ernie Cohen")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38755")[#strong[#text("Ernie Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2009")])]

#text("A few comments. First, while AC (or equivalently, Tychonoff’s theorem) is typically used to prove the compactness theorem, you should note that it follows from (and is in fact equivalent to) the strictly weaker untrafilter lemma.")

#text("Second, in remark 1 you state “The above argument shows in particular that any finite theory either has a model or a proof that the theory implies a contradiction. Actually producing one or the other, though is essentially the infamous satisfiability problem, which is known to be NP-complete, and thus (if P \\neq NP) would require super-polynomial time to execute.”")

#text("There are some technical sloppiness here. While checking for consistency is NP-complete, checking for inconsistency is believed not to be in NP (it is coNP-complete). And checking that the theory is inconsistent is not the same as producing a proof of inconsistency; indeed, every inconsistent theory having a polynomial-size proof would imply NP=coNP.")

#text("Third, an advantage of the Henkin approach is that Skolemization assumes AC, whereas the Henkin approach does not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-38762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2009")])]

#text("Dear Ernie: Thanks for the corrections and comments!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-39220")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("Why is any ultraproduct of a sequence of structures an elementary limit in your sense? I see why Los’ theorem gives unboundedly many ")#mi("\\mathfrak{U}_n\\models\\varphi")#text(" when ")#mi("\\mathfrak{U}\\models\\varphi")#text(", but I don’t see why it gives cofinitely many.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-39225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("Dear anon,")

#text("An ultraproduct of a sequence of structures will be the elementary limit of some subsequence, because there are only countably many sentences one needs to check and one can run the usual Arzela-Ascoli type diagonalisation argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-39462")[#strong[#text("Sequential compactness theorem @ unwanted capture")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")]

#text("[…] and then some are expository bits that he writes up for his own edification. I just noticed a post from April about Gödel’s completeness and compactness theorems. From a logician’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e73d7e7b583e06e2a4f4a5f3decbfb7c358a5725e7090486743d9e9ac7864f49-171b6285da2b7d669a08a4fc2048caaeb4394a625099535300023db830271f67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-40837")[#strong[#text("Danny")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("I was having a debate with someone – in the context of Godel’s proof of the incompleteness theorem – and the questions came up about the countability of statements in a first-order logic. On one hand, I had always – vaguely – understood that the essense of Godel’s proof was that the set of statements was “larger” than the set of provable statements in the same sense that the set of reals was larger than the set of natural numbers. However, given there is a Godel numbering of proofs and a Godel numbering of statements then they must both be countable at most. Is the latter statement correct – that the set of all statements in first-order logic is countable.")

#text("Thx in advance for something that is hopefully not too far off topic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-41725")[#strong[#text("r97124005個人部落格 » Undecidable Sentences")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")]

#text("[…] This is some thought after reading : The completeness and compactness theorems of first-order logic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-41845")[#strong[#text("Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")])]

#text("[…] the completeness theorem, a partial type is nothing more than a set of sentences involving which is logically consistent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-43372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2010")])]

#text("Dear Prof. Tao,")

#text("if we take a countable collection of ”decidable” subsets of natural numbers, is their union again ”decidable”?")

#text("what about arbitrary union?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-47306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Yes – Every singleton is decidable, and every set of natural numbers is a union of countably many singletons.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-43425")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] . This existence of elementary limits is a manifestation of the compactness theorem in logic; see this earlier blog post for more discussion. So we see that compactness methods and ultrafilter methods are closely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-45689")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] Semantic-syntactic duality Much more generally still, a mathematical theory can either be described internally or syntactically via its axioms and theorems, or externally or semantically via its models. The fundamental connection between the two perspectives is given by the Gödel completeness theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-46848")[#strong[#text("Blog cua Tao « Sangtaodaphongcach's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2010")]

#text("[…] The completeness and compactness theorems of first-order logic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6ac75207df45b68f726005648d15df30a65f31def10cf8bbda313159a6112db-7958a10f5849ab0f02c4e5036a86d56ccd4d708d226a2a31e25ba9095b682cab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug Spoonwood")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-51386")[#strong[#text("Doug Spoonwood")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("A language for propositional logic (and first-order logic for that matter) need not contain any parentheses. Lukasiewicz’s notation for propositional logic gives us an example, and the founders of “reverse Polish notation” (e. g. Hamblin) gave us another.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-52870")[#strong[#text("Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2011")])]

#text("[…] this claim is in fact a special case of the Gödel completeness theorem, and is discussed in this previous blog post; we also sketch a proof of completeness […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Struden")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-216128")[#strong[#text("David Struden")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Dear Professor Tao,")

#text("Thanks you for your post.")

#text("I am a student and I had a course on logic from Mendelson’s textbook and it seems to me that what you stated here about completeness theorem is much general than the completeness theorem of Godel that is presented in Mendelson.")

#text("As I understand, a first order theory has two sets of axioms: (1) the core set of axioms contains those common logic axioms such as (A -> (B -> A)); and (2) some extra set of axioms depending on each theory (for example, group has its own group axioms).")

#text("If the second set of axioms is empty then it is called a PREDICATE CALCULUS.")

#text("In Mendelson, Godel’s completeness theorem stated and proved for “predicate calculus” only. This is Godel’s original theorem, is it right?")

#text("What you prove here is a completeness theorem for ALL first order theory. Is my understanding correct?")

#text("So what you show here is much more general than Godel’s original theorem.")

#text("Thank you again for your post. It is very helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/548b0214463baf96958c448c2c53cb9a7d1ce974e713ad879d4afeb980442fa4-16a5188541a747148687484479e8462e6314976b1299bb668d15cab132ba84f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moe Hirsch")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-390496")[#strong[#text("Moe Hirsch")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("A beautiful exposition.")

#text("A small glitch:")

#text("In the paragraph before Corollary 3 (Sequential Compactness Theorem), the second sentence has something missing:")

#text("“Given a sequence U_1, U_2, . . . be a sequence of structures ”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b2b057f9d296967dfbfd5c092a04c78fb1474b0d1a126ef6dbb482525770fc-965994263b210d9eeabf059f613992693973dd84a4480a0e645699950b6e521e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-460948")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2015")])]

#text("If I want to get my feet wet with further interactions between logic and topology, starting here with why the compactness theorem is called such, where would I go?")

#text("One question I am wondering which is not clear to me. Are topological spaces normally associated with languages and first-order theories metrizable? If so what sorts of metrics are out there to describe the “distance” between first-order theories over a fixed language? Or are these topological spaces associated with languages and first-order theories necessarily not metrizable? What implications would that have, if any, on logic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b2b057f9d296967dfbfd5c092a04c78fb1474b0d1a126ef6dbb482525770fc-965994263b210d9eeabf059f613992693973dd84a4480a0e645699950b6e521e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-460950")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2015")])]

#text("I’m trying to bring Brouwer’s fixed point theorem(s) to bear on this situation. If some associated topological spaces are metrizable then there might be contractions and with contractions there are things that can be called “maps” of “territory.” The Brouwer fixed point theorem about contractions implies that if a map is at all within the territory, there is exactly one point of overlap between the map and territory. That point must be really interesting…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8714050c4cc43338ccabc5e3ff72ae04fa405170f512aca7511e4f4b1521757-972b0fb19263fe7a95ebc8b3a7a67d01a3c3d8bc7cad19a96dfeaad4d6e5057d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two old-ish Terry Tao posts about model theory | sylvy's mathsy blog")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-461076")[#strong[#text("Two old-ish Terry Tao posts about model theory | sylvy's mathsy blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2015")])]

#text("[…] this which talks about completeness, compactness, zeroth-order logic, and Skolemisation; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a4cb99b12fce1751ce1b740f166dd16e88d818472f7ec1b2573342ea7b3b8f9-2de7c251cf842d6925e974b6f57330798bacdf7c0b95087b4c483c181e7f0d95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guy Paterson-Jones")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-468531")[#strong[#text("Guy Paterson-Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("In the proof of theorem 6, I think you have used a union symbol where an intersection symbol was intended.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66d3554a7fc49cab70cabf1d9415dc2fc95638dc95698c6b8a918b5ef6fa0ea6-75dd8b63726082791865805104ca3f79dcf4ab3db7232bde28741d8273e1c052.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wael Amay")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-470349")[#strong[#text("Wael Amay")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("here we must be mentioned to important thoery Tarski’s and kurt godel")#linebreak()#text(" have inquiers thats helberts project have been asked …namely if we can said there is independce of tuth and false in amathematic statement")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bba8bf59b5c239e266fcb247fe6ba561708bf870be520374bfaddcd2d222172-82bc23234bc2aeb46377cb20a3360298edbef24213782bb21dcabd2af81b5281.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-470967")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2016")])]

#text("This is one of the best expositions of these topics I have ever read. Brisk and clear.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/548b0214463baf96958c448c2c53cb9a7d1ce974e713ad879d4afeb980442fa4-16a5188541a747148687484479e8462e6314976b1299bb668d15cab132ba84f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Morris W. Hirsch")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-470970")[#strong[#text("Morris W. Hirsch")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2016")])]

#text("Dear Whats new:")

#text("Please remove me from your mailing list. I don’t want to receive any more comments.")

#text("Thank you")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-489599")[#strong[#text("Compactness – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-l&#8230")[#text("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-l&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-489736")[#strong[#text("Consciousness – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-l&#8230")[#text("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-l&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c0dfd1224e44ef2bb95a144314370dd3eb3c85b4f5407f6462ef81312cb0ffe-f454ef44cfdd40fe34ad334fdcb34e7f36f797e4c9d50fa5065f0ca27161bbdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OwenH")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-562182")[#strong[#text("OwenH")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("Regarding the completeness of infinite languages, you say that it can be proved ‘… if the set of propositional variables happens to be well-ordered).’")

#text("In what sense is the collection of propositional variables a set? I am wondering if the axiom of choice can be applied to collections of things in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-562757")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("The axiom of choice is indeed only limited to sets (Zorn’s lemma, for instance, fails for proper classes). The standard trick here is to restrict the available pool of variables to one that is obviously a set, e.g., by only permitting variables ")#mi("x, x^{\\prime}, x^{\\prime\\prime}, x^{\\prime\\prime\\prime}, \\dots")#text(" arising from adjoining a finite number of primes to the base symbol ")#mi("x")#text(" (or if one needs a larger pool of variables, one can only permit variables of the form ")#mi("x_n")#text(" where ")#mi("n")#text(" ranges up to some given ordinal.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-642809")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")])]

#text("How does one define the notion of “countable” in a meta-theory such as Theorem 1? (If ")#mi("\\Gamma")#text(", say, is ZFC, then it cannot be the “countable” in set theory, can it?) Or is such a notion left undefined or primitive?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-642930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2022")])]

#text("When establishing metamathematical results such as the completeness theorem, it is understood that the metatheory is expressive enough to handle standard mathematical concepts such as countability. For instance, one can use ZFC for the metatheory if one desires, even if the internal theory one is studying with this metatheory is also ZFC. (This would be somewhat analogous to the practice of ")#link("https://en.wikipedia.org/wiki/Self-hosting_(compilers)")[#text("self-hosting")]#text(" a compiler in software engineering, i.e., of writing a compiler for a programming language, such as C++, in that very same language.) But to avoid confusion and the perception of infinite regress, one can take the metatheory to be the informal mode of mathematical reasoning that the majority of human mathematicians actually use in practice, rather than any rigid formalization of that reasoning (such as First order Logic + ZFC) that one studies in logic (or which one uses in formal proof verification software).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16b297e2a2fa7318ecedc394dc365a680f44083d76b7965ac4293cd6aecc8cc0-2a0c5fa6e91b4e7d85849ff511ab14a67d277d96f83a48955123c9370cb80892.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gamalf123")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-681807")[#strong[#text("gamalf123")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2023")])]

#text("Shouldn’t the example-theory ")#mi("\\gamma")#text(" given right before theorem 4 actually consist of ")#mi("\\{ \\neg A_1 , A_1 \\rightarrow A_2 \\}")#text(" to be considered ‘satisfied’ by the example-truth assignment ")#mi("A_1 = F , A_2 = T")#text(" ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/#comment-696648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("Just a note: the trick “One can then replace each first-order statement")

#link("https://s0.wp.com/latex.php?latex=%7B%5Cforall+x_1+%5Cldots+%5Cforall+x_k%3A+P%28x_1%2C%5Cldots%2Cx_k%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7B%5Cforall+x_1+%5Cldots+%5Cforall+x_k%3A+P%28x_1%2C%5Cldots%2Cx_k%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("in")

#link("https://s0.wp.com/latex.php?latex=%7B%5CGamma%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7B%5CGamma%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("by the family of zeroth-order statements")

#link("https://s0.wp.com/latex.php?latex=%7BP%28t_1%2C%5Cldots%2Ct_k%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BP%28t_1%2C%5Cldots%2Ct_k%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text(", where")

#link("https://s0.wp.com/latex.php?latex=%7Bt_1%2C%5Cldots%2Ct_k%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bt_1%2C%5Cldots%2Ct_k%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("ranges over all terms with no free variables, thus creating a zeroth-order theory")

#link("https://s0.wp.com/latex.php?latex=%7B%5CGamma_0%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7B%5CGamma_0%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("“ used at the end of the proof above actually has a name: “Herbrandization” (dual to Skolemization of course).")
]
