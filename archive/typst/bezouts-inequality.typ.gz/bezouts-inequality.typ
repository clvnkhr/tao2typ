// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/
// Converted to Typst by tao2typ: "2026-10-14T09:07:09.934286+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bezout’s inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bezout’s inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/")[#text("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Classically, the fundamental object of study in ")#emph[#text("algebraic geometry")]#text(" is the solution set ")#metadata(none) <tao-5844e599ebd454e996cd>

#tao-aligned(keep: true)[


#tao-math("V  & = V_{P_1,\\ldots,P_m} := \\{ (x_1,\\ldots,x_d) \\in k^d: P_1(x_1,\\ldots,x_d) = \\ldots", block: true, numbering: n => [#text("(1)")])



#tao-math(" & = P_m(x_1,\\ldots,x_d) = 0 \\}", block: true)
]

#text("to multiple algebraic equations")

#align(center)[#tao-fit-display[#mitex("P_1(x_1,\\ldots,x_d) = \\ldots = P_m(x_1,\\ldots,x_d) = 0")]]

#text("in multiple unknowns ")#mi("{x_1,\\ldots,x_d}")#text(" in a field ")#mi("{k}")#text(", where the ")#mi("{P_1,\\ldots,P_m: k^d \\rightarrow k}")#text(" are polynomials of various degrees ")#mi("{D_1, \\ldots, D_m}")#text(". We adopt the classical perspective of viewing ")#mi("{V}")#text(" as a set (and specifically, as an ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic set")]#text("), rather than as a scheme. Without loss of generality we may order the degrees in non-increasing order:")

#align(center)[#tao-fit-display[#mitex("D_1 \\geq D_2 \\geq \\ldots \\geq D_m \\geq 1.")]]

#text("We can distinguish between the ")#emph[#text("underdetermined case")]#text(" ")#mi("{m < d}")#text(", when there are more unknowns than equations; the ")#emph[#text("determined case")]#text(" ")#mi("{m=d}")#text(" when there are exactly as many unknowns as equations; and the ")#emph[#text("overdetermined case")]#text(" ")#mi("{m>d}")#text(", when there are more equations than unknowns.")

#text("Experience has shown that the theory of such equations is significantly simpler if one assumes that the underlying field ")#mi("{k}")#text(" is ")#link("http://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed")]#text(" , and so we shall make this assumption throughout the rest of this post. In particular, this covers the important case when ")#mi("{k={\\bf C}}")#text(" is the field of complex numbers (but it does ")#emph[#text("not")]#text(" cover the case ")#mi("{k={\\bf R}}")#text(" of real numbers – see below).")

#text("From the general “soft” theory of algebraic geometry, we know that the algebraic set ")#mi("{V}")#text(" is a union of finitely many algebraic varieties, each of dimension at least ")#mi("{d-m}")#text(", with none of these components contained in any other. In particular, in the underdetermined case ")#mi("{m<d}")#text(", there are no zero-dimensional components of ")#mi("{V}")#text(", and thus ")#mi("{V}")#text(" is either empty or infinite.")

#text("Now we turn to the determined case ")#mi("{d=m}")#text(", where we expect the solution set ")#mi("{V}")#text(" to be zero-dimensional and thus finite. Here, the basic control on the solution set is given by ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(". In our notation, this theorem states the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Bezout’s theorem)")]#text(" ")#metadata(none) <tao-283ada7088c26258bfd6>#text(" Let ")#mi("{d=m=2}")#text(". If ")#mi("{V}")#text(" is finite, then it has cardinality at most ")#mi("{D_1 D_2}")#text(".")
]

#text("This result can be found in any introductory algebraic geometry textbook; it can for instance be proven using the classical tool of ")#link("http://en.wikipedia.org/wiki/Resultant")[#text("resultants")]#text(". The solution set ")#mi("{V}")#text(" will be finite when the two polynomials ")#mi("{P_1,P_2}")#text(" are coprime, but can (and will) be infinite if ")#mi("{P_1,P_2}")#text(" share a non-trivial common factor.")

#text("By defining the right notion of multiplicity on ")#mi("{V}")#text(" (and adopting a suitably “")#link("http://en.wikipedia.org/wiki/Scheme_(mathematics)")[#text("scheme")]#text("-theoretic” viewpoint), and working in ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective space")]#text(" rather than affine space, one can make the inequality ")#tao-math("{\\left|V\\right| \\leq D_1 D_2}", block: false)#text(" an equality. However, for many applications (and in particular, for the applications to combinatorial incidence geometry), the upper bound usually suffices.")

#text("Bezout’s theorem can be generalised in a number of ways. For instance, the restriction on the finiteness of the solution set ")#mi("{V}")#text(" can be dropped by restricting attention to ")#mi("{V^0}")#text(", the union of the zero-dimensional irreducible components of ")#mi("{V}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Bezout’s theorem, again)")]#text(" Let ")#mi("{d=m=2}")#text(". Then ")#mi("{V^0}")#text(" has cardinality at most ")#mi("{D_1 D_2}")#text(".")
]

#emph[#text("Proof:")]#text(" We factor ")#mi("{P_1, P_2}")#text(" into irreducible factors (using unique factorisation of polynomials). By removing repeated factors, we may assume ")#mi("{P_1, P_2}")#text(" are square-free. We then write ")#mi("{P_1 = Q_1 R}")#text(", ")#mi("{P_2 = Q_2 R}")#text(" where ")#mi("{R}")#text(" is the greatest common divisor of ")#mi("{P_1,P_2}")#text(" and ")#mi("{Q_1,Q_2}")#text(" are coprime. Observe that the zero-dimensional component of ")#mi("{\\{ P_1=P_2 = 0\\}}")#text(" is contained in ")#mi("{\\{ Q_1 = Q_2 = 0\\}}")#text(", which is finite from the coprimality of ")#mi("{Q_1,Q_2}")#text(". The claim follows. ")#mi("\\Box")

#text("It is also not difficult to use Bezout’s theorem to handle the overdetermined case ")#mi("{m > d=2}")#text(" in the plane:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Bezout’s theorem, yet again)")]#text(" Let ")#mi("{m \\geq d=2}")#text(". Then ")#mi("{V^0}")#text(" has cardinality at most ")#mi("{D_1 D_2}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume all the ")#mi("{P_i}")#text(" are square-free. We write ")#mi("{P_1 = Q_2 R_2}")#text(", where ")#mi("{Q_2}")#text(" is coprime to ")#mi("{P_2}")#text(" and ")#mi("{R_2}")#text(" divides ")#mi("{P_2}")#text(" (and also ")#mi("{P_1}")#text("). We then write ")#mi("{R_2 = Q_3 R_3}")#text(", where ")#mi("{Q_3}")#text(" is coprime to ")#mi("{P_3}")#text(" and ")#mi("{R_3}")#text(" divides ")#mi("{P_3}")#text(" (and also ")#mi("{P_1,P_2}")#text("). Continuing in this fashion we obtain a factorisation ")#mi("{P_1 = Q_2 Q_3 \\ldots Q_m R_m}")#text(". One then observes that ")#mi("{V^0}")#text(" is contained in the set ")#mi("{\\bigcup_{i=2}^m \\{ Q_i = P_i = 0 \\}}")#text(", which by Theorem ")#link(<tao-283ada7088c26258bfd6>)[#text("1")]#text(" has cardinality at most ")#mi("{\\sum_{i=2}^m \\text{deg}(Q_i) D_i}")#text(". Since ")#mi("{D_i \\leq D_2}")#text(" and ")#mi("{\\sum_{i=2}^m \\text{deg}(Q_i) \\leq \\text{deg}(P_1) = D_1}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Of course, in the overdetermined case ")#mi("{m>d}")#text(" one generically expects the solution set to be empty, but if there is enough degeneracy or numerical coincidence then non-zero solution sets can occur. In particular, by considering the case when ")#mi("{P_2=\\ldots=P_m}")#text(" and ")#mi("{D_2=\\ldots=D_m}")#text(" we see that the bound ")#mi("{D_1 D_2}")#text(" can be sharp in some cases. However, one can do a little better in this situation; by decomposing ")#mi("{P_m}")#text(" into irreducible components, for instance, one can improve the upper bound of ")#mi("{D_1 D_2}")#text(" slightly to ")#mi("{D_1 D_m}")#text(". However, this improvement seems harder to obtain in higher dimensions (see below).")
]

#text("Bezout’s theorem also extends to higher dimensions. Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Higher-dimensional Bezout’s theorem)")]#text(" ")#metadata(none) <tao-a02efcce8efe7cf0703e>#text(" Let ")#mi("{d=m \\geq 0}")#text(". If ")#mi("{V}")#text(" is finite, then it has cardinality at most ")#mi("{D_1 \\ldots D_d}")#text(".")
]

#text("This is a standard fact, and can for instance be proved from the more general and powerful machinery of ")#link("http://en.wikipedia.org/wiki/Intersection_theory_(mathematics)")[#text("intersection theory")]#text(". A typical application of this theorem is to show that, given a degree ")#mi("{D}")#text(" polynomial ")#mi("{P: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" over the reals, the number of connected components of ")#mi("{\\{ x \\in {\\bf R}^d: P(x) \\neq 0 \\}}")#text(" is ")#mi("{O(D^d)}")#text(". The main idea of the proof is to locate a critical point ")#mi("{\\nabla P(x) = 0}")#text(" inside each connected component, and use Bezout’s theorem to count the number of zeroes of the polynomial map ")#mi("{\\nabla P: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(". (This doesn’t quite work directly because some components may be unbounded, and because the fibre of ")#mi("{\\nabla P}")#text(" at the origin may contain positive-dimensional components, but one can use truncation and generic perturbation to deal with these issues; see ")#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/")[#text("my recent paper with Solymosi")]#text(" for further discussion.)")

#text("Bezout’s theorem can be extended to the overdetermined case as before:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Bezout’s inequality)")]#text(" ")#metadata(none) <tao-81b730f094e3d6bb1c86>#text(" Let ")#mi("{m \\geq d \\geq 0}")#text(". Then ")#mi("{V^0}")#text(" has cardinality at most ")#mi("{D_1 \\ldots D_d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(" ostensibly only controls the zero-dimensional components of ")#mi("{V}")#text(", but by throwing in a few generic affine-linear forms to the set of polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" (thus intersecting ")#mi("{V}")#text(" with a bunch of generic hyperplanes) we can also control the total degree of all the ")#mi("{i}")#text("-dimensional components of ")#mi("{V}")#text(" for any fixed ")#mi("{i}")#text(". (Again, by using intersection theory one can get a slightly more precise bound than this, but the proof of that bound is more complicated than the arguments given here.)")
]

#text("This time, though, it is a slightly non-trivial matter to deduce Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(" from Theorem ")#link(<tao-a02efcce8efe7cf0703e>)[#text("4")]#text(", due to the standard difficulty that the intersection of irreducible varieties need not be irreducible (which can be viewed in some ways as the source of many other related difficulties, such as the fact that not every algebraic variety is a ")#link("http://en.wikipedia.org/wiki/Complete_intersection")[#text("complete intersection")]#text("), and so one cannot evade all irreducibility issues merely by assuming that the original polynomials ")#mi("{P_i}")#text(" are irreducible. Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(" first appeared explicitly in the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=716823")[#text("Heintz")]#text(".")

#text("As before, the most systematic way to establish Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(" is via intersection theory. In this post, though, I would like to give a slightly more elementary argument (essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=1354108")[#text("due to Schmid")]#text("), based on generically perturbing the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" in the problem ; this method is less powerful than the intersection-theoretic methods, which can be used for a wider range of algebraic geometry problems, but suffices for the narrow objective of proving Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(". The argument requires some of the “soft” or “qualitative” theory of algebraic geometry (in particular, one needs to understand the semicontinuity properties of preimages of dominant maps), as well as basic linear algebra. As such, the proof is not completely elementary, but it uses only a small amount of algebraic machinery, and as such I found it easier to understand than the intersection theory arguments.")

#text("Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(" is a statement about ")#emph[#text("arbitrary")]#text(" polynomials ")#mi("{P_1,\\ldots,P_m}")#text(". However, it turns out (in the determined case ")#mi("{m=d}")#text(", at least) that upper bounds on ")#tao-math("{\\left|V^0\\right|}", block: false)#text(" are ")#emph[#text("Zariski closed")]#text(" properties, and so it will suffice to establish this claim for ")#emph[#text("generic")]#text(" polynomials ")#mi("{P_1,\\ldots,P_m}")#text(". On the other hand, it is possible to use duality to deduce such upper bounds on ")#tao-math("{\\left|V^0\\right|}", block: false)#text(" from a ")#emph[#text("Zariski open")]#text(" condition, namely that a certain collection of polynomials are linearly independent. As such, to verify the generic case of this open condition, it suffices to establish this condition for a ")#emph[#text("single")]#text(" family of polynomials, such as a family of monomials, in which case the condition can be verified by direct inspection. Thus we see an example of the somewhat strange strategy of establishing the general case from a specific one, using the generic case as an intermediate step.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" There is an important caveat to note here, which is that these theorems only hold for algebraically closed fields, and in particular can fail over the reals ")#mi("{{\\bf R}}")#text(". For instance, in ")#mi("{{\\bf R}^3}")#text(", the polynomials")

#tao-aligned(keep: true)[


#tao-math("P(x,y,z)  & = z", block: true)



#tao-math("Q(x,y,z)  & = z", block: true)



#tao-math("R(x,y,z)  & = (\\prod_{j=1}^N (x-j))^2 + (\\prod_{j=1}^N (y-j))^2", block: true)
]

#text("have degrees ")#mi("{1, 1, 2N}")#text(" respectively, but their common zero locus ")#mi("{\\{ (x,y,0): x,y \\in \\{1,\\ldots,N\\}\\}}")#text(" has cardinality ")#mi("{N^2}")#text(". In some cases one can safely obtain incidence bounds in ")#mi("{{\\bf R}}")#text(" by embedding ")#mi("{{\\bf R}}")#text(" inside ")#mi("{{\\bf C}}")#text(", but as the above example shows, one needs to be careful when doing so.")
]

#metadata(none) <tao-ce1015b7deaab7e0f14b>

#heading(level: 1)[#strong[#text(" — 1. The determined case — ")]]

#text("We begin by establishing Theorem ")#link(<tao-a02efcce8efe7cf0703e>)[#text("4")]#text(". Fix ")#mi("{m=d \\geq 0}")#text(". If one wishes, one can dispose of the trivial case ")#mi("{m=d=0}")#text(" and assume ")#mi("{m=d \\geq 1}")#text(", although this is not strictly necessary for the argument below.")

#text("As mentioned in the introduction, the first idea is to generically perturb the ")#mi("{P_1,\\ldots,P_d}")#text(". To this end, let ")#mi("{W}")#text(" be the vector space ")#mi("{W := W_1 \\times \\ldots \\times W_d}")#text(", where ")#mi("{W_i}")#text(" is the vector space of all polynomials ")#mi("{P_i: k^d \\rightarrow k}")#text(" of degree at most ")#mi("{D_i}")#text("; thus ")#mi("{W}")#text(" is the configuration space of all possible ")#mi("{P_1,\\ldots,P_d}")#text(". This is a finite-dimensional vector space over ")#mi("{k}")#text(" with an explicit dimension ")#mi("{\\text{dim}(W)}")#text(" which we will not need to compute here. The set ")#mi("{V_{P_1,\\ldots,P_d} \\subset k^d}")#text(" in ")#link(<tao-5844e599ebd454e996cd>)[#text("(1)")]#text(" can thus be viewed as the fibre over ")#mi("{(P_1,\\ldots,P_d)}")#text(" of the algebraic set ")#mi("{V_* \\subset W \\times k^d}")#text(", defined as")

#tao-aligned(keep: true)[


#tao-math("V_*  & := \\{ (P_1,\\ldots,P_d,x_1,\\ldots,x_d) \\in W \\times k^d:", block: true)



#tao-math("P_1(x_1,\\ldots,x_d)  & = \\ldots = P_d(x_1,\\ldots,x_d) = 0 \\text{ for all } 1 \\leq i \\leq d \\}.", block: true)
]

#text("This algebraic set is cut out by ")#mi("{d}")#text(" polynomial equations on ")#mi("{W \\times k^d}")#text(" and thus is the union of finitely many algebraic varieties ")#mi("{V_* = V_{*,1} \\cup \\ldots \\cup V_{*,r}}")#text(", each of which has codimension at most ")#mi("{d}")#text(" in ")#mi("{W \\times k^d}")#text(". In particular, ")#mi("{\\text{dim}(V_{*,i}) \\geq \\text{dim}(W)}")#text(".")

#text("Consider one of the components ")#mi("{V_{*,i}}")#text(" of ")#mi("{V_*}")#text(". Its projection ")#mi("{W_{*,i}}")#text(" in ")#mi("{W}")#text(" will be Zariski dense in its closure ")#mi("{\\overline{W_{*,i}}}")#text(", which is necessarily an irreducible variety since ")#mi("{V_{*,i}}")#text(" is, and the projection map from ")#mi("{V_{*,i}}")#text(" to ")#mi("{\\overline{W_{*,i}}}")#text(" will, by definition, be a ")#link("http://en.wikipedia.org/wiki/Rational_mapping#Dominant_and_birational_maps")[#text("dominant map")]#text(". By basic algebraic geometry, the preimages in ")#mi("{V_{*,i}}")#text(" of a point ")#mi("{(P_1,\\ldots,P_d)}")#text(" in ")#mi("{W_{*,i}}")#text(" will generically have dimension ")#mi("{\\text{dim}(V_{*,i}) - \\text{dim}(W_{*,i})}")#text(" (i.e. this dimension will occur outside of a algebraic subset of ")#mi("{W_{*,i}}")#text(" of positive codimension), and even in the non-generic case will have dimension ")#emph[#text("at least")]#text(" ")#mi("{\\text{dim}(V_{*,i}) - \\text{dim}(W_{*,i})}")#text(". Since ")#mi("{\\text{dim}(V_{*,i}) \\geq \\text{dim}(W)}")#text(", we thus see that the only components ")#mi("{V_{*,i}}")#text(" that can contribute to the zero-dimensional set ")#mi("{V^0}")#text(" are those with ")#mi("{\\text{dim}(V_{*,i}) = \\text{dim}(W_{*,i}) = \\text{dim}(W)}")#text(". Now, the projection map is a dominant map between two varieties of the same dimension, and is thus generically finite, with the preimages generically having some constant cardinality ")#mi("{D_{*,i}}")#text(", and non-generically the preimages have a zero-dimensional component of at most ")#mi("{D_{*,i}}")#text(". (Topologically, one can see this claim (at least in the model case ")#mi("{k={\\bf C}}")#text(") as follows. Any isolated point ")#mi("{p}")#text(" in a non-generic preimage must perturb to a zero-dimensional set or to an empty set in nearby preimages, since ")#mi("{V_{*,i}}")#text(" is closed. On a generic preimage, ")#mi("{p}")#text(" must perturb to a zero-dimensional set (for if it generically perturbs to the empty set, the dimension of ")#mi("{V_{*,i}}")#text(" will be too small); since a generic preimage has ")#mi("{D_{*,i}}")#text(" points, we conclude that the non-generic preimage can contain at most ")#mi("{D_{*,i}}")#text(" isolated points. For a more detailed proof of this claim, see Proposition 1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=716823")[#text("Heintz’s paper")]#text(".)")

#text("As a consequence of this analysis, we see that the generic fibre always has at least as many zero-dimensional components as a non-generic fibre, and so to establish Theorem ")#link(<tao-a02efcce8efe7cf0703e>)[#text("4")]#text(", it suffices to do so for generic ")#mi("{P_1,\\ldots,P_m}")#text(".")

#text("Now take ")#mi("{P_1,\\ldots,P_m}")#text(" to be generic. We know that generically, the set ")#mi("{V}")#text(" is finite; we seek to bound its cardinality ")#tao-math("{\\left|V\\right|}", block: false)#text(" by ")#mi("{D_1 \\ldots D_m}")#text(". To do this, we dualise the problem. Let ")#mi("{A}")#text(" be the space of all affine-linear forms ")#mi("{\\lambda: k^d \\rightarrow k}")#text("; this is a ")#mi("{d+1}")#text("-dimensional vector space. We consider the set ")#mi("{\\hat V}")#text(" of all affine-linear forms ")#mi("{\\lambda}")#text(" whose kernel ")#mi("{\\{ \\lambda = 0 \\}}")#text(" intersects ")#mi("{V}")#text(". This is a union of ")#tao-math("{\\left|V\\right|}", block: false)#text(" hyperplanes in ")#mi("{A}")#text(", and is thus a hypersurface of degree ")#tao-math("{\\left|V\\right|}", block: false)#text(". Thus, to upper bound the size of ")#mi("{V}")#text(", it suffices to upper bound the degree of the hypersurface ")#mi("{\\hat V}")#text(", and this can be done by finding a non-zero polynomial of controlled degree that vanishes identically on ")#mi("{\\hat V}")#text(". The point of this observation is that the property of a polynomial being non-zero is a Zariski-open condition, and so we have a chance of establishing the generic case from a special case.")

#text("Now let us look for a (generically non-trivial) polynomial of degree at most ")#mi("{\\prod_{i=1}^d D_i}")#text(" that vanishes on ")#mi("{\\hat V}")#text(". The idea is to try to dualise the assertion that the monomials ")#mi("{x_1^{a_1} \\ldots x_d^{a_d}}")#text(" with ")#mi("{a_j < D_j}")#text(" for all ")#mi("{1 \\leq j \\leq d}")#text(" generically span the function ring of ")#mi("{V}")#text(", to become a statement about ")#mi("{\\hat V}")#text(".")

#text("Let ")#mi("{D}")#text(" be a sufficiently large integer (any integer larger than ")#mi("{\\sum_{i=1}^d (D_i-1)}")#text(" will do, actually), and let ")#mi("{X}")#text(" be the space of all polynomials ")#mi("{P: k^d \\rightarrow k}")#text(" of degree at most ")#mi("{D}")#text(". This is a finite-dimensional vector space over ")#mi("{k}")#text(", generated by the monomials ")#mi("{x_1^{a_1} \\ldots x_d^{a_d}}")#text(" with ")#mi("{a_1,\\ldots,a_d}")#text(" non-negative integers adding up to at most ")#mi("{D}")#text(". We can split ")#mi("{X}")#text(" as a direct sum ")#metadata(none) <tao-792525db00993809e3a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("X = (\\sum_{i=1}^d x_i^{D_i} \\cdot X_i) + X_0")]]

#text("where for ")#mi("{i,\\ldots,d}")#text(", ")#mi("{X_i}")#text(" is generated by those monomials ")#mi("{x_1^{a_1} \\ldots x_d^{a_d}}")#text(" of degree at most ")#mi("{D-D_i}")#text(" with ")#mi("{a_j < D_j}")#text(" for all ")#mi("{j < i}")#text(" and with ")#mi("{a_i \\geq 0}")#text(", and ")#mi("{X_0}")#text(" is generated by those monomials ")#mi("{x_1^{a_1} \\ldots x_d^{a_d}}")#text(" with ")#mi("{a_j < D_j}")#text(" for all ")#mi("{1 \\leq j \\leq d}")#text(". In particular, ")#metadata(none) <tao-9905604af1cb14f45cd9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{dim}(X) = \\sum_{i=1}^d \\text{dim}(X_i) + \\text{dim}(X_0).")]]

#text("Also observe that ")#metadata(none) <tao-3f68e0f8394bc97ba3a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{dim}(X_0) = \\prod_{i=1}^d D_i.")]]

#text("Now let ")#mi("{\\lambda \\in A}")#text(" be an affine-linear form, and consider the sum ")#metadata(none) <tao-0c541a8f97b4c2cf4951>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(\\sum_{i=1}^d P_i \\cdot X_i) + \\lambda \\cdot X_0.")]]

#text("This is a subspace of ")#mi("{X}")#text(" for ")#mi("{D}")#text(" large enough. In view of ")#link(<tao-792525db00993809e3a3>)[#text("(2)")]#text(", we see that this sum can equal all of ")#mi("{X}")#text(" in the case when ")#mi("{P_i = x_i^{D_i}}")#text(" and ")#mi("{\\lambda = 1}")#text(". From ")#link(<tao-9905604af1cb14f45cd9>)[#text("(3)")]#text(", the property of ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" spanning all of ")#mi("{X}")#text(" is a Zariski-open condition, and thus we see that ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" spans ")#mi("{X}")#text(" for generic choices of ")#mi("{P_1,\\ldots,P_d}")#text(" and ")#mi("{\\lambda}")#text(".")

#text("On the other hand, suppose that ")#mi("{\\lambda \\in \\hat V}")#text(", thus ")#mi("{\\lambda(a) = P_1(a) = \\ldots = P_d(a) = 0}")#text(" for some ")#mi("{a \\in k^d}")#text(". Then observe that each factor of ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" lies in the hyperplane ")#mi("{\\{ P \\in X: P(a) = 0 \\}}")#text(" of ")#mi("{X}")#text(", and so ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" does not span ")#mi("{X}")#text(" in this case. Thus, for generic ")#mi("{P_1,\\ldots,P_d}")#text(", we see that ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" spans ")#mi("{X}")#text(" for generic ")#mi("{\\lambda}")#text(" but not for any ")#mi("{\\lambda}")#text(" in ")#mi("{\\hat V}")#text(".")

#text("The property of ")#link(<tao-0c541a8f97b4c2cf4951>)[#text("(5)")]#text(" spanning ")#mi("{X}")#text(" is equivalent to a certain resultant-like determinant of a ")#mi("{\\text{dim}(X) \\times \\text{dim}(X)}")#text(" matrix being non-zero, where the rows are given by the generators of ")#mi("{P_i \\cdot X_i}")#text(" and ")#mi("{\\lambda \\cdot X_0}")#text(". For generic ")#mi("{P_1,\\ldots,P_d}")#text(", this determinant is a non-trivial polynomial in ")#mi("{\\lambda \\cdot X_0}")#text(" which vanishes on ")#mi("{\\hat V}")#text("; an inspection of the matrix reveals that this determinant has degree ")#mi("{\\text{dim}(X_0) = \\prod_{i=1}^d D_i}")#text(" in ")#mi("{\\lambda}")#text(". Thus we have found a non-trivial polynomial of degree ")#mi("{\\prod_{i=1}^d D_i}")#text(" that vanishes on ")#mi("{\\hat V}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. The overdetermined case — ")]]

#text("Now we establish Theorem ")#link(<tao-81b730f094e3d6bb1c86>)[#text("5")]#text(". Fix ")#mi("{P_1,\\ldots,P_m}")#text(", and let ")#mi("{V^{\\prime}}")#text(" be the union of all the positive-dimensional components of ")#mi("{V}")#text(", thus ")#mi("{V_0 = V \\backslash V^{\\prime}}")#text(".")

#text("The main idea here is to perturb ")#mi("{P_1,\\ldots,P_m}")#text(" to be a ")#link("http://en.wikipedia.org/wiki/Regular_sequence_(algebra)")[#text("regular sequence")]#text(" of polynomials outside of ")#mi("{V^{\\prime}}")#text(". More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Regular sequence)")]#text(" For any ")#mi("{1 \\leq r \\leq d}")#text(", one can find polynomials ")#mi("{Q_1,\\ldots,Q_r}")#text(", such that for each ")#mi("{i=1,\\ldots,r}")#text(", ")#mi("{Q_i}")#text(" is a linear combination of ")#mi("{P_i,\\ldots,P_m}")#text(" (and thus has degree at most ")#mi("{D_i}")#text("), with the ")#mi("{P_i}")#text(" coefficient being non-zero, and the set ")#mi("{\\{ x \\in k^d \\backslash V^{\\prime}: Q_1 = \\ldots = Q_r = 0 \\}}")#text(" in ")#mi("{k^d}")#text(" has dimension at most ")#mi("{d-r}")#text(" (in the sense that it is covered by finitely many varieties of dimension at most ")#mi("{d-r}")#text(").")
]

#emph[#text("Proof:")]#text(" We establish this claim by induction on ")#mi("{r}")#text(". For ")#mi("{r=1}")#text(" the claim follows by setting ")#mi("{Q_1 := P_1}")#text(". Now suppose inductively that ")#mi("{1 < r \\leq d}")#text(", and that ")#mi("{Q_1,\\ldots,Q_{r-1}}")#text(" have already been found with the stated properties for ")#mi("{r-1}")#text(".")

#text("By construction, the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" are linear combinations of ")#mi("{Q_1,\\ldots,Q_{r-1}, P_{r},\\ldots,P_m}")#text(". Thus, on the set ")#mi("{W := \\{ x \\in k^d \\backslash V^{\\prime}: Q_1 = \\ldots = Q_{r-1} = 0 \\}}")#text(", the polynomials ")#mi("{P_r,\\ldots,P_m}")#text(" can only simultaneously vanish on the zero-dimensional set ")#mi("{V \\backslash V^{\\prime} = V_0}")#text(". On the other hand, each irreducible component of ")#mi("{W}")#text(" has dimension ")#mi("{d-r+1}")#text(", which is positive. Thus it is not possible for ")#mi("{P_r,\\ldots,P_m}")#text(" to simultaneously vanish on any of these components. If one then sets ")#mi("{Q_r}")#text(" to be a generic linear combination of ")#mi("{P_r,\\ldots,P_m}")#text(", then we thus see that ")#mi("{Q_r}")#text(" will also not vanish on any of these components, and so ")#mi("{\\{ x \\in k^d \\backslash V^{\\prime}: Q_1 = \\ldots = Q_r = 0 \\}}")#text(" has dimension at most ")#mi("{d-r}")#text(". Also, generically the ")#mi("{P_r}")#text(" coefficient of ")#mi("{Q_r}")#text(" is non-zero, and the claim follows. ")#mi("\\Box")

#text("From the above lemma (with ")#mi("{r := d}")#text(") we see that ")#mi("{V_0}")#text(" is contained in the set ")#mi("{\\{ Q_1 = \\ldots = Q_d = 0\\}}")#text(". By Theorem ")#link(<tao-a02efcce8efe7cf0703e>)[#text("4")]#text(", the latter set has cardinality at most ")#mi("{D_1 \\ldots D_d}")#text(", and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-50956")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2011")])]

#emph[#text(" the intersection of irreducible varieties need not be irreducible (which is closely related to the fact that not every algebraic variety is a complete intersection)")]

#text("I’m having trouble guessing what you’re thinking of here. Complete intersections are already often reducible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a6d7bfaab15d364e5b49865f28111b03bffa68435b4bdfcda74c51b42070a12-acae0d9c2b0ceb8fc191ea449781973da58d9d8338a5b301c554d0aca602f46e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-50960")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2011")])]

#text("I think what Terry is thinking is the following: Here is a flawed proof that every variety is a complete intersection. For concreteness, I will “prove” that every curve ")#mi("X")#text(" in 3-space is a complete intersection. For large enough degree, there is a polynomial ")#mi("F")#text(" vanishing on ")#mi("X")#text(" such that ")#mi("\\{F=0 \\}")#text(" is irreducible. Let ")#mi("y")#text(" be a point of ")#mi("\\{ F=0 \\}")#text(" not on ")#mi("X")#text(". For large enough degree, there is a polynomial ")#mi("G")#text(" vanishing on ")#mi("X")#text(" and not at ")#mi("y")#text(", and we can take ")#mi("\\{ G=0 \\}")#text(" irreducible. So ")#mi("F=G=0")#text(" is a proper subvariety of ")#mi("\\{F=0\\}")#text(", containing ")#mi("X")#text(". If the intersection of irreducible varieties was always irreducible, it would have to be ")#mi("X")#text(".")

#text("I’ve seen several students find this proof. There is usually a lot more detail in the parts where you check that ")#mi("F")#text(" and ")#mi("G")#text(" can be found with the required properties, which makes the error less conspicuous.")

#emph[#text("[Yes, this is the type of thing I had in mind; in the counterfactual world where intersections of irreducibles were irreducible, many other things in algebraic geometry would oversimplify, in particular all varieties would be complete intersections. I’ve reworded the text a little bit. – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-50962")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2011")])]

#text("It seems that there is a compiling error right after ")#strong[#text("2. The overdetermined case. Now we establish Theorem […]")]

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab9c0d2168e28a427bdba3d0657b806f00157e002ce84b08ae564e1c72ef1798-2dfbe13171a99185555fc0922e00789adb312caf00917b85c595396002ca3801.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fay")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51379")[#strong[#text("Fay")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2011")])]

#text("Hi,")#linebreak()#text(" Can I say that the infinite union of isolated point is not algebraic? That seems true but I can’t prove it .While in the affine A^1 , and A^2 space , this is true . But I don’t know if it still holds for higher dimension? Thanks !")

#text("Fay")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evgeniy")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51779")[#strong[#text("Evgeniy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("Hi,")

#text("Every algebraic variety has a degree, which is a strictly positive integer (and it is finite). This degree is just a coefficient with dominant term of Hilbert-Samuel polynomial. For 0-dimensional cycle C the degree coincides with number of points (counting the multiplicity). You can see the last affirmation, for example, coincidering the interpolation at the points of C. So infinite union of points can not be algebraic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab9c0d2168e28a427bdba3d0657b806f00157e002ce84b08ae564e1c72ef1798-2dfbe13171a99185555fc0922e00789adb312caf00917b85c595396002ca3801.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fay")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51787")[#strong[#text("Fay")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2011")])]

#text("What do you mean by “last affirmation”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evgeniy")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51806")[#strong[#text("Evgeniy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2011")])]

#text("I am sorry, english is not my native language. I mean this: “For 0-dimensional cycle C the degree coincides with number of points (counting the multiplicity).”")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab9c0d2168e28a427bdba3d0657b806f00157e002ce84b08ae564e1c72ef1798-2dfbe13171a99185555fc0922e00789adb312caf00917b85c595396002ca3801.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fay")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51813")[#strong[#text("Fay")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2011")])]

#text("Thanks ! I am guessing you may assume that the infinite union of isolated points must be a 0 dimensional cycle , therefore a contradiction with a finite degree ,right? But i am confused that why it must be 0 dimensional ? Thanks!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51737")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Is there a special form of Bezout’s theorem for ‘sparse’ polynomials?")

#text("For example, suppose that ")#mi("D_{j}=2")#text(" for each ")#mi("P_{j}")#text(", and ")#mi("d=m")#text(" with ")#mi("m")#text(" large, while each ")#mi("P_{j}")#text(" contains products like ")#mi("x_{i}^{2}")#text(", ")#mi("x_{i}x_{i+1}")#text(", and ")#mi("x_{i}x_{i-1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("I don’t believe there are substantial gains to the Bezout bound from sparsity alone; for instance, in the plane, Bezout’s inequality is basically an equality (if one counts intersection points with multiplicity, assuming no common factors between polynomials, and working in an algebraically closed field of course).")

#text("This isn’t quite the same thing, but there is a variant of the Bezout bound known as the ")#text("combinatorial nullstellensatz")#text(" that prevents the zero set of a polynomial from containing a large Cartesian product if a certain coefficient of that polynomial is non-zero. This does give some sort of link between the combinatorial structure of algebraic sets and their sparsity, though the connection is not really of Bezout type.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-51763")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("Thanks Terrence.")

#text("Just after I wrote this I came accross a review")#linebreak()#text(" article that describes a very simple example, similar to the one I gave above (called a deficient system).")

#text("In the example, the polynomials ")#mi("P_{i}")#text(" contain all terms of the form ")#mi("a_{ij} x_{1}x_{j}")#text(", ")#mi("b_{ij} x_{j}")#text(" and ")#mi("c_{i}")#text(" where the constants, ")#mi("a_{i,j}")#text(", etc. are arbitrary. The Bezout bound is ")#mi("\\leq 2^{n}")#text(" but the number of isolated solutions is ")#mi("\\leq m+1")#text(".")

#text("I’d have to read a bit more on this, but it seems, as you suggest, that as things get more complicated the large gain over the Bezout bound may be lost very quickly.")

#text("Thanks again for your response and for this excellent blog.")

#text("The example is described on p. 212 of :")

#text("T. Y. Li,")#linebreak()#text(" Numerical solution of polynomial systems by homotopy continuation,")#linebreak()#text(" Handbook of Numerical Analysis, Volume 11, 2003, Pages 209-304.")

#text("Here’s the link,")

#link("http://www.sciencedirect.com/science/book/9780444512475")[#text("http://www.sciencedirect.com/science/book/9780444512475")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/412cef1e9051d2e681b6846d20c38f4a90299adf84096d74b5e06ae5aee1cfba-8c777028c96d77aa00d982266735d19b7b19765da6dfca8a17948b139ff73096.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alperen ergur")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-470220")[#strong[#text("Alperen ergur")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("Hi,")

#text("I am not sure if I understand the comment right but isn’t the mixed volume bounds of Bersntein’s theorem a big gain over Bezout?")

#text("It depends the Newton polytope which is some what sparsity.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pappus’s theorem and elliptic curves « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-57396")[#strong[#text("Pappus’s theorem and elliptic curves « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2011")])]

#text("[…] One of the fundamental theorems about algebraic plane curves is Bézout’s theorem, which asserts that if a degree curve and a degree curve have no common component, then they intersect in at most points (and if the underlying field is algebraically closed, one works projectively, and one counts intersections with multiplicity, they intersect in exactly points). Thus, for instance, two distinct lines intersect in at most one point; a line and a conic section intersect in at most two points; two distinct conic sections intersect in at most four points; a line and an elliptic curve intersect in at most three points; two distinct elliptic curves intersect in at most nine points; and so forth. Bézout’s theorem is discussed in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Srivatsan Narayanan")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-57596")[#strong[#text("Srivatsan Narayanan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2011")])]

#text("In Theorem 5, shouldn’t the condition ")#mi("d \\geq m")#text(" be the other way round?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Srivatsan Narayanan")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-57808")[#strong[#text("Srivatsan Narayanan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2011")])]

#text("Sorry to bother you much, but it seems that the post doesn’t reflect the correction :-)")

#emph[#text("[Oops; should be visible now. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A partial converse to Bezout’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-175111")[#strong[#text("A partial converse to Bezout’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")])]

#text("[…] has many strengthenings, generalisations, and variants; see for instance this previous blog post on Bézout’s inequality. Bézout’s theorem asserts a fundamental algebraic dichotomy, of importance in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d86eab25623dd4c1f519b3eac00b3ff3d8a0038cd9582b756334eda3850c95-0d53b14ded35bc4a2de8f195583e2dd93c56bccd7266adf2cee3812e026d9626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-471466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("I wonder what can be said about the real case.")#linebreak()#text(" Is there a version of Theorem 5 that says that for some function f,")#linebreak()#text(" either V < f(D,k), where D is the max degree of the m polynomials,")#linebreak()#text(" or V_0 is infinite? Is there a polynomial bound for f?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/412cef1e9051d2e681b6846d20c38f4a90299adf84096d74b5e06ae5aee1cfba-8c777028c96d77aa00d982266735d19b7b19765da6dfca8a17948b139ff73096.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alperen ergur")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-471467")[#strong[#text("Alperen ergur")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("I guess you would like to see Descartes Rule of Signs or Fewnomial Theory")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gipi")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-471468")[#strong[#text("gipi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("Is there an equivalent of Bézout theorem for systems of trigonometric polynomials?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d86eab25623dd4c1f519b3eac00b3ff3d8a0038cd9582b756334eda3850c95-0d53b14ded35bc4a2de8f195583e2dd93c56bccd7266adf2cee3812e026d9626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/#comment-471469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("Hi Alperen, Could you be more specific?")#linebreak()#text(" Do you know any bound on f(D,k)?")#linebreak()#text(" As Terry mentioned, one cannot get the same bound as in the complex case, but I just wonder if one can get something in that neighborhood.")
]
