// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/
// Converted to Typst by tao2typ: "2026-10-14T15:18:00.613281+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lines in the Euclidean group SE(2)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lines in the Euclidean group SE(2)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/")[#text("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("previous blog post")]#text(", I discussed the recent ")#link("http://arxiv.org/abs/1011.4105")[#text("result of Guth and Katz")]#text(" obtaining a near-optimal bound on the ")#link("http://www.cs.umd.edu/~gasarch/erdos_dist/erdos_dist.html")[#text("Erdos distance problem")]#text(". One of the tools used in the proof (building upon the ")#link("http://arxiv.org/abs/1005.0982")[#text("earlier work of Elekes and Sharir")]#text(") was the observation that the incidence geometry of the Euclidean group ")#mi("{SE(2)}")#text(" of rigid motions of the plane was almost identical to that of lines in the Euclidean space ")#mi("{{\\bf R}^3}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-e835d0bf51a4ea9360cc>#text(" One can identify a (Zariski-)dense portion of ")#mi("{SE(2)}")#text(" with ")#mi("{{\\bf R}^3}")#text(", in such a way that for any two points ")#mi("{A, B}")#text(" in the plane ")#mi("{{\\bf R}^2}")#text(", the set ")#mi("{l_{AB} := \\{ R \\in SE(2): RA = B \\}}")#text(" of rigid motions mapping ")#mi("{A}")#text(" to ")#mi("{B}")#text(" forms a line in ")#mi("{{\\bf R}^3}")#text(".")
]

#emph[#text("Proof:")]#text(" A rigid motion is either a translation or a rotation, with the latter forming a Zariski-dense subset of ")#mi("{SE(2)}")#text(". Identify a rotation ")#mi("{R}")#text(" in ")#mi("{SE(2)}")#text(" by an angle ")#mi("{\\theta}")#text(" with ")#tao-math("{\\left|\\theta\\right| < \\pi}", block: false)#text(" around a point ")#mi("{P}")#text(" with the element ")#mi("{(P, \\cot \\frac{\\theta}{2})}")#text(" in ")#mi("{{\\bf R}^3}")#text(". (Note that such rotations also form a Zariski-dense subset of ")#mi("{SE(2)}")#text(".) Elementary trigonometry then reveals that if ")#mi("{R}")#text(" maps ")#mi("{A}")#text(" to ")#mi("{B}")#text(", then ")#mi("{P}")#text(" lies on the perpendicular bisector of ")#mi("{AB}")#text(", and depends in a linear fashion on ")#mi("{\\cot \\frac{\\theta}{2}}")#text(" (for fixed ")#mi("{A,B}")#text("). The claim follows. ")#mi("\\Box")

#text("As seen from the proof, this proposition is an easy (though ")#emph[#text("ad hoc")]#text(") application of elementary trigonometry, but it was still puzzling to me why such a simple parameterisation of the incidence structure of ")#mi("{SE(2)}")#text(" was possible. Certainly it was clear from general algebraic geometry considerations that ")#emph[#text("some")]#text(" bounded-degree algebraic description was available, but why would the ")#mi("{l_{AB}}")#text(" be expressible as lines and not as, say, quadratic or cubic curves?")

#text("In this post I would like to record some observations arising from discussions with Jordan Ellenberg, Jozsef Solymosi, and Josh Zahl which give a more conceptual (but less elementary) derivation of the above proposition that avoids the use of ")#emph[#text("ad hoc")]#text(" coordinate transformations such as ")#mi("{R \\mapsto (P, \\cot\\frac{\\theta}{2})}")#text(". The starting point is to view the Euclidean plane ")#mi("{{\\bf R}^2}")#text(" as the scaling limit of the sphere ")#mi("{S^2}")#text(" (a fact which is familiar to all of us through the geometry of the Earth), which makes the Euclidean group ")#mi("{SE(2)}")#text(" a scaling limit of the rotation group ")#mi("{SO(3)}")#text(". The latter can then be lifted to a double cover, namely the ")#link("http://en.wikipedia.org/wiki/Spin_group")[#text("spin group")]#text(" ")#mi("{Spin(3)}")#text(". This group has a natural interpretation as the unit ")#link("http://en.wikipedia.org/wiki/Quaternion")[#text("quaternions")]#text(", which is isometric to the unit sphere ")#mi("{S^3}")#text(". The analogue of the lines ")#mi("{l_{AB}}")#text(" in this setting become ")#link("http://en.wikipedia.org/wiki/Great_circle")[#text("great circles")]#text(" on this sphere; applying a ")#link("http://en.wikipedia.org/wiki/Projective_transformation")[#text("projective transformation")]#text(", one can map ")#mi("{S^3}")#text(" to ")#mi("{{\\bf R}^3}")#text(" (or more precisely to the ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective space")]#text(" ")#mi("{{\\bf P}^3}")#text("), at whichi point the great circles become lines. This gives a proof of Proposition ")#link(<tao-e835d0bf51a4ea9360cc>)[#text("1")]#text(".")

#text("Details of the correspondence are provided below the fold. One by-product of this analysis, incidentally, is the observation that the Guth-Katz bound ")#mi("{g(N) \\gg N / \\log N}")#text(" for the Erdos distance problem in the plane ")#mi("{{\\bf R}^2}")#text(", immediately extends with almost no modification to the sphere ")#mi("{S^2}")#text(" as well (i.e. any ")#mi("{N}")#text(" points in ")#mi("{S^2}")#text(" determine ")#mi("{\\gg N/\\log N}")#text(" distances), as well as to the hyperbolic plane ")#mi("{H^2}")#text(".")

#metadata(none) <tao-84b1828451b5194e506a>

#heading(level: 1)[#strong[#text(" — 1. Euclidean geometry as the scaling limit of spherical geometry — ")]]

#link("http://en.wikipedia.org/wiki/Euclidean_geometry")[#text("Euclidean geometry")]#text(" and ")#link("http://en.wikipedia.org/wiki/Spherical_geometry")[#text("spherical geometry")]#text(" are examples of ")#link("http://en.wikipedia.org/wiki/Kleinian_geometry")[#text("Kleinian geometries")]#text(": the geometry of a space ")#mi("{X}")#text(" with a group of symmetries ")#mi("{G}")#text(" acting transitively on it. In the case of Euclidean plane geometry, the space ")#mi("{X}")#text(" is the plane ")#mi("{{\\bf R}^2}")#text(" and the symmetry group is the special Euclidean group ")#mi("{SE(2) = SO(2) \\ltimes {\\bf R}^2}")#text("; in the case of spherical geometry, the space ")#mi("{X}")#text(" is the unit sphere ")#mi("{S^2}")#text(" and the symmetry group is the special orthogonal group ")#mi("{SO(3)}")#text(". According to the Kleinian way of thinking (as formalised by the ")#link("http://en.wikipedia.org/wiki/Erlangen_program")[#text("Erlangen program")]#text("), explicit coordinates on ")#mi("{X}")#text(" should be avoided if possible, with a preference instead for only using concepts (e.g. congruence, distance, angle) that are invariant with respect to the group of symmetries ")#mi("{G}")#text(".")

#text("As we all know from the geometry of the Earth (and the Greek root ")#emph[#text("geometria")]#text(" literally means “Earth measurement”), the geometry of the sphere ")#mi("{S^2}")#text(" resembles the geometry of the plane ")#mi("{{\\bf R}^2}")#text(" at scales that are small compared to the radius of the sphere. There are at least two ways to make this intuitive fact more precise. One is to make the radius ")#mi("{R}")#text(" of the sphere go to infinity, and perform a suitable limit (e.g. a ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("Gromov-Hausdorff limit")]#text("). A dual approach is to keep the radius of the sphere fixed (e.g. considering only the unit sphere), but making the scale ")#mi("{\\epsilon}")#text(" being considered on the sphere shrink to zero. The two approaches are of course equivalent, but we will consider the latter.")

#text("Thus, we view ")#mi("{S^2}")#text(" as the unit sphere in ")#mi("{{\\bf R}^3}")#text(". With an eye to using the quaternionic number system later on, we will denote the standard basis of ")#mi("{{\\bf R}^3}")#text(" as ")#mi("{i,j,k}")#text(", thus in particular ")#mi("{i}")#text(" is a point on the sphere ")#mi("{S^2}")#text(" which we will view as an “origin” for this sphere. The tangent plane to ")#mi("{S^2}")#text(" at this point is then")

#align(center)[#tao-fit-display[#mitex("\\{ i + y j + z k: y,z \\in {\\bf R}^2 \\}.")]]

#text("This plane is tangent to the sphere to second order. In particular, if ")#mi("{(y, z) \\in {\\bf R}^2}")#text(", and ")#mi("{\\epsilon > 0}")#text(" is a small parameter (which we think of as going to zero eventually), then we can find a point on ")#mi("{S^2}")#text(" of the form ")#mi("{i + \\epsilon y j + \\epsilon z k + O(\\epsilon^2)}")#text(". (If one wishes, one can enforce the ")#mi("{O(\\epsilon^2)}")#text(" error to lie in the ")#mi("{i}")#text(" direction, in order to make the identification uniquely well-defined, although this is not strictly necessary for the discussion below.) Thus, we can view the ")#mi("{\\epsilon}")#text("-neighbourhood of the origin ")#mi("{i}")#text(" as being approximately identifiable with a bounded neighbourhood of the origin ")#mi("{0}")#text(" in the plane ")#mi("{{\\bf R}^2}")#text(" via the identification")

#align(center)[#tao-fit-display[#mitex("(y,z) \\mapsto i + \\epsilon y j + \\epsilon z k + O(\\epsilon^2).")]]

#text("With this identification, one can see various structures in spherical geometry correspond (up to errors of ")#mi("{O(\\epsilon)}")#text(") to analogous structures in planar geometry. For instance, a great circle in ")#mi("{S^2}")#text(" is of the form")

#align(center)[#tao-fit-display[#mitex("\\{ p \\in S^2: p \\cdot \\omega = 0 \\}")]]

#text("for some ")#mi("{\\omega \\in S^2}")#text(", where ")#mi("{\\cdot}")#text(" is the usual dot product. In order for this great circle to intersect the ")#mi("{O(\\epsilon)}")#text(" neighbourhood of the origin ")#mi("{i}")#text(", one must have ")#mi("{i \\cdot \\omega = O(\\epsilon)}")#text(", and so we have")

#align(center)[#tao-fit-display[#mitex("\\omega = \\epsilon a i + (\\cos \\theta) j + (\\sin \\theta) k + O(\\epsilon^2)")]]

#text("for some bounded quantity ")#mi("{a}")#text(" and some angle ")#mi("{\\theta}")#text(". If one then restricts the great circle to points ")#mi("{p = i + \\epsilon y j + \\epsilon z k + O(\\epsilon^2)}")#text(", the constraint ")#mi("{p \\cdot \\omega = 0}")#text(" then becomes")

#align(center)[#tao-fit-display[#mitex("a + (\\cos \\theta) y + (\\sin \\theta) z = O(\\epsilon),")]]

#text("which is within ")#mi("{O(\\epsilon)}")#text(" of the equation of a typical line in ")#mi("{{\\bf R}^2}")#text(",")

#align(center)[#tao-fit-display[#mitex("a + (\\cos \\theta) y + (\\sin \\theta) z = 0.")]]

#text("This formalises the geometrically intuitive fact that great circles resemble lines at small scales.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also adopt a more “intrinsic” Riemannian geometry viewpoint to see ")#mi("{{\\bf R}^2}")#text(" as the limit of rescaled versions of ")#mi("{S^2}")#text(". Indeed, for each real number ")#mi("{\\kappa}")#text(", there is a unique (up to isometry) simply connected Riemannian surface ")#mi("{S_\\kappa}")#text(" of constant ")#link("http://en.wikipedia.org/wiki/Scalar_curvature")[#text("scalar curvature")]#text(" ")#mi("{\\kappa}")#text(". For ")#mi("{\\kappa > 0}")#text(", this is the unit sphere ")#mi("{S^2}")#text(" (rescaled by ")#mi("{\\sqrt{\\kappa/2}}")#text("); for ")#mi("{\\kappa=0}")#text(", this is the Euclidean plane ")#mi("{{\\bf R}^2}")#text("; and for ")#mi("{\\kappa < 0}")#text(", it is the ")#link("http://en.wikipedia.org/wiki/Hyperbolic_geometry")[#text("hyperbolic plane")]#text(" ")#mi("{H^2}")#text(" (rescaled by ")#tao-math("{\\sqrt{\\left|\\kappa\\right|/2}}", block: false)#text("). Sending ")#mi("{\\kappa}")#text(" to zero, we thus see the sphere (or hyperbolic plane) converging to the Euclidean plane.")
]

#text("We now apply a similar analysis to a rotation matrix ")#mi("{R \\in SO(3)}")#text(" acting on the unit sphere ")#mi("{S^2}")#text(". In order for this rotation matrix to map an ")#mi("{O(\\epsilon)}")#text(" neighbourhood of the origin ")#mi("{i}")#text(" to another such neighbourhood, the rotation matrix ")#mi("{R}")#text(" must be of the form ")#mi("{R = (1 + \\epsilon T + O(\\epsilon^2)) S}")#text(", where ")#mi("{S}")#text(" is a rotation that fixes ")#mi("{i}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("S (x i + y j + z k) = xi + (y \\cos \\theta - z \\sin \\theta) j + (y \\sin \\theta + z \\cos \\theta) k")]]

#text("for some angle ")#mi("{\\theta}")#text(", and ")#mi("{T}")#text(" is an infinitesimal rotation (i.e. an element of the Lie algebra ")#mi("{\\mathfrak{so}(3)}")#text("), thus ")#mi("{Ti = aj + bk}")#text(" for some reals ")#mi("{a,b}")#text(". We then have")

#tao-aligned(keep: true)[


#tao-math("R ( i + \\epsilon yj + \\epsilon zk + O(\\epsilon^2) )  & = i + \\epsilon (y \\cos \\theta - z \\sin \\theta + a)j", block: true)



#tao-math(" & + \\epsilon (y \\sin \\theta + z \\cos \\theta+b) + O(\\epsilon^2),", block: true)
]

#text("so in ")#mi("{(y,z)}")#text(" coordinates, ")#mi("{R}")#text(" becomes the map")

#align(center)[#tao-fit-display[#mitex("(y,z) \\mapsto (y \\cos \\theta - z \\sin \\theta + a, y \\sin \\theta + z \\cos \\theta+b) + O(\\epsilon),")]]

#text("which is within ")#mi("{\\epsilon}")#text(" of the Euclidean rigid motion")

#align(center)[#tao-fit-display[#mitex("(y,z) \\mapsto (y \\cos \\theta - z \\sin \\theta + a, y \\sin \\theta + z \\cos \\theta+b).")]]

#text("Thus we see the Euclidean rigid motion group ")#mi("{SE(2)}")#text(" emerging as a scaling limit of the orthogonal rotation group ")#mi("{SO(3)}")#text(" (or alternatively, as the normal bundle of the stabiliser of the origin, which is a copy of ")#mi("{SO(2)}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can also analyse the situation from a Lie algebra perspective. As is well known, one can equip the three-dimensional Lie algebra ")#mi("{\\mathfrak{so}(3)}")#text(" with a basis ")#mi("{X,Y,Z}")#text(" obeying the commutation relations")

#align(center)[#tao-fit-display[#mitex("[X,Y] = Z; [Y,Z] = X; [Z,X] = Y,")]]

#text("corresponding to infinitesimal rotations around the ")#mi("{x,y,z}")#text(" axes respectively. If we then rescale ")#mi("{X_\\epsilon := X, Y_\\epsilon := \\epsilon Y, Z_\\epsilon := \\epsilon Z}")#text(" (which morally corresponds to looking at rotation matrices that almost fix ")#mi("{i}")#text(", as above), the commutation relations rescale to")

#align(center)[#tao-fit-display[#mitex("[X_\\epsilon,Y_\\epsilon] = Z_\\epsilon; [Y_\\epsilon,Z_\\epsilon] = \\epsilon^2 X_\\epsilon; [Z_\\epsilon,X_\\epsilon] = Y_\\epsilon.")]]

#text("Sending ")#mi("{\\epsilon \\rightarrow 0}")#text(", the Lie algebra degenerates to the solvable Lie algebra")

#align(center)[#tao-fit-display[#mitex("[X_0,Y_0] = Z_0; [Y_0,Z_0] = 0; [Z_0,X_0] = Y_0,")]]

#text("which is the Lie algebra ")#mi("{\\mathfrak{se}(2)}")#text(" of the Euclidean group ")#mi("{SE(2)}")#text(".")

#text("There is an exact analogue of this phenomenon for the isometry group ")#mi("{SO(2,1) \\equiv SL_2({\\bf R})}")#text(" of the hyperbolic plane ")#mi("{H^2}")#text(" (which one can think of as one sheet of the unit sphere in Minkowski space ")#mi("{{\\bf R}^{2+1}}")#text(", just as ")#mi("{S^2}")#text(" is the unit sphere in ")#mi("{{\\bf R}^3}")#text("). The Lie algebra here can be equipped with a basis ")#mi("{X,Y,Z}")#text(" (which one can interpret as infinitesimal rotations and Lorentz boosts in Minkowski space) with the relations")

#align(center)[#tao-fit-display[#mitex("[X,Y] = Z; [Y,Z] = -X; [Z,X] = Y,")]]

#text("and the same scaling argument as before gives ")#mi("{SE(2)}")#text(" as a scaling limit of ")#mi("{SO(2,1)}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Lifting to the quaternions — ")]]

#text("The ")#link("http://en.wikipedia.org/wiki/Quaternion")[#text("quaternions")]#text(" are a number system, defined formally as the set ")#mi("{{\\bf H}}")#text(" of numbers of the form")

#align(center)[#tao-fit-display[#mitex("t + xi + yj + zk")]]

#text("with ")#mi("{t,x,y,z \\in {\\bf R}}")#text(". This a four-dimensional vector space; it can be turned into an algebra (and into a ")#link("http://en.wikipedia.org/wiki/Division_ring")[#text("division ring")]#text(") by enforcing Hamilton’s relations")

#align(center)[#tao-fit-display[#mitex("i^2=j^2=k^2=ijk=-1.")]]

#text("The quaternions also come equipped with a conjugation operation")

#align(center)[#tao-fit-display[#mitex("(t+xi + yj + zk)^* := t - xi - yj - zk")]]

#text("and a norm")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha\\right| := (\\alpha \\alpha^*)^{1/2} = (\\alpha^* \\alpha)^{1/2},", block: true)]]

#text("thus")

#align(center)[#tao-fit-display[#tao-math("\\left|(t+xi+yj+zk)\\right| = \\sqrt{t^2+x^2+y^2+z^2}.", block: true)]]

#text("The conjugation operation is an ")#link("http://en.wikipedia.org/wiki/Anti-automorphism")[#text("anti-automorphism")]#text(", and the norm is multiplicative: ")#tao-math("{\\left|\\alpha \\beta\\right| = \\left|\\alpha\\right| \\left|\\beta\\right|}", block: false)#text(". The quaternions also have a trace")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(t+xi+yj+zk) = t")]]

#text("(in particular, ")#mi("{\\text{tr}(\\alpha^*) = \\text{tr}(\\alpha)}")#text(" and ")#mi("{\\text{tr}(\\alpha \\beta) = \\text{tr}(\\beta \\alpha)}")#text("), giving rise to a dot product")

#align(center)[#tao-fit-display[#mitex("\\alpha \\cdot \\beta := \\text{tr}( \\alpha \\beta^* )")]]

#text("which (together with the norm) gives a Hilbert space structure on the quaternions.")

#text("The unit sphere ")#mi("{S^3 = \\{ \\alpha \\in {\\bf H}: \\alpha \\alpha^* = 1 \\}}")#text(" of the quaternions forms a group, which is a model for the ")#link("http://en.wikipedia.org/wiki/Spin_group")[#text("spin group")]#text(" ")#mi("{Spin(3)}")#text(" (thus giving rise to an interpretation of the quaternions ")#mi("{{\\bf H}}")#text(", which are of course acted upon by ")#mi("{S^3}")#text(" by left-multiplication, as ")#link("http://en.wikipedia.org/wiki/Spinor")[#text("spinors")]#text(" for this group). This group acts on itself isometrically by conjugation, with an element ")#mi("{\\alpha \\in S^3 \\equiv Spin(3)}")#text(" mapping ")#mi("{\\beta \\in S^3}")#text(" to ")#mi("{\\alpha \\beta \\alpha^*}")#text(". As ")#mi("{\\alpha \\alpha^*=1}")#text(", this action preserves the quaternionic identity ")#mi("{1}")#text(", and thus preserves the orthogonal complement ")#mi("{\\{ xi+yj+zk: x^2+y^2+z^2=1\\}}")#text(" of that identity in ")#mi("{S^3}")#text(", which we can of course identify with ")#mi("{S^2}")#text(". Thus ")#mi("{S^3 \\equiv Spin(3)}")#text(" acts on ")#mi("{S^2}")#text(" isometrically by conjugation, thus providing a map from ")#mi("{Spin(3)}")#text(" to ")#mi("{SO(3)}")#text(". One can verify that this map is surjective (indeed, conjugation by the quaternion ")#mi("{e^{i\\theta}}")#text(" corresponds to a rotation around the ")#mi("{i}")#text("-axis by ")#mi("{2\\theta}")#text(", and similarly for rotations around other axes) and is a double cover (since the center of ")#mi("{S^3}")#text(" is ")#mi("{\\{-1,+1\\}}")#text("), with the pre-image of any rotation in ")#mi("{SO(3)}")#text(" being a pair ")#mi("{\\{\\alpha,-\\alpha\\}}")#text(" of diametrically opposed points in ")#mi("{S^3}")#text(". Thus we see that ")#mi("{SO(3)}")#text(" can be identified (in either the topological or Riemannian geometrical senses) with the projective sphere ")#mi("{S^3/\\pm \\equiv {\\bf P}^3}")#text(". As ")#mi("{SO(3)}")#text(" acts transitively on ")#mi("{S^2}")#text(", we see that ")#mi("{S^3 \\equiv Spin(3)}")#text(" does also.")

#text("The stabiliser ")#mi("{l_{AA} := \\{ \\alpha \\in S^3: \\alpha A \\alpha^* = A \\}}")#text(" of a point ")#mi("{A \\in S^2}")#text(" is easily seen to be a great circle in ")#mi("{S^3}")#text(" (being the intersection of ")#mi("{S^3}")#text(" with the center of ")#mi("{\\alpha}")#text(", which is a plane). For instance, the stabiliser ")#mi("{l_{ii}}")#text(" of the origin ")#mi("{i}")#text(" is the circle ")#mi("{\\{ e^{i\\theta}: \\theta \\in {\\bf R} \\}}")#text(". (This, incidentally, gives an explicit geometric manifestation of the ")#link("http://en.wikipedia.org/wiki/Hopf_fibration")[#text("Hopf fibration")]#text(".) By transitivity (and the isometric nature of the ")#mi("{S^3}")#text(" action), we conclude that the sets ")#mi("{l_{AB} := \\{ \\alpha \\in S^3: \\alpha A \\alpha^* = B \\}}")#text(" are also great circles in ")#mi("{S^3}")#text(" for any pair of points ")#mi("{A, B}")#text(". Conversely, as all great circles are isometric to each other, we see that all great circles are of the form ")#mi("{l_{AB}}")#text(". One also sees that two great circles ")#mi("{l_{AB}, l_{CD}}")#text(" coincide only when ")#mi("{A, C}")#text(" have the same stabiliser, and when ")#mi("{B, D}")#text(" have the same stabiliser, which forces ")#mi("{C, D}")#text(" to either equal ")#mi("{A, B}")#text(", or ")#mi("{-A, -B}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Using a projective transformation, one can identify (a hemisphere of) ")#mi("{S^3}")#text(" with ")#mi("{{\\bf R}^3}")#text(", with (most) great circles becoming lines in ")#mi("{{\\bf R}^3}")#text(". Thus, we see that the incidence geometry of the ")#mi("{l_{AB}}")#text(" in ")#mi("{S^3}")#text(" is essentially equivalent to the incidence geometry of lines in ")#mi("{{\\bf R}^3}")#text(". Because of this, the Guth-Katz argument to establish the bound ")#mi("{g(N) \\gg N / \\log N}")#text(" for the number of distances determined by ")#mi("{N}")#text(" points in the plane ")#mi("{{\\bf R}^2}")#text(", also extends to ")#mi("{N}")#text(" points in the sphere ")#mi("{S^2}")#text(". Indeed, as in the Guth-Katz paper, it suffices to show that the number of congruent line segments ")#mi("{AB, CD}")#text(" in these ")#mi("{N}")#text(" points is ")#mi("{O( N^3 \\log N )}")#text(". For each such pair of line segments, there is a unique element of ")#mi("{SO(3)}")#text(" (and thus two antipodal elements of ")#mi("{S^3 \\equiv Spin(3)}")#text(") that maps ")#mi("{AB}")#text(" to ")#mi("{CD}")#text("; these two antipodal points are also the intersection of ")#mi("{l_{AC}}")#text(" with ")#mi("{l_{BD}}")#text(". Applying the projective transformation, one arrives at exactly the same incidence problem between points and lines considered by Guth-Katz (and in particular, one can apply Theorems 2.4, 2.5 from ")#link("http://arxiv.org/PS_cache/arxiv/pdf/1011/1011.4105v1.pdf")[#text("their paper")]#text(" as a black box, after verifying that at most ")#mi("{O(N)}")#text(" lines of the form ")#mi("{l_{AB}}")#text(" project into a plane or regulus, which is proven in the ")#mi("{S^2}")#text(" case in much the same way as it is in the ")#mi("{{\\bf R}^2}")#text(" case). We omit the details.")

#text("A similar argument (changing the signatures in various metrics, and in the Clifford algebra underlying the quaternions) also allows one to establish the same results in the hyperbolic plane ")#mi("{H^2}")#text("; again, we omit the details.")
]

#text("If we restrict attention to an ")#mi("{\\epsilon}")#text("-neighbourhood of the origin ")#mi("{i}")#text(" in the sphere ")#mi("{S^2}")#text(", and similarly restrict to an ")#mi("{\\epsilon}")#text("-neighbourhood of the stabiliser of ")#mi("{i}")#text(" in the spin group ")#mi("{S^3 \\equiv Spin(3)}")#text(", we can use the correspondences from the previous section to convert ")#mi("{S^2}")#text(" into ")#mi("{{\\bf R}^2}")#text(" in the limit, and ")#mi("{Spin(3)}")#text(" in the limit into a double cover of the rotation group ")#mi("{SE(2)}")#text(" (which ends up just being isomorphic to ")#mi("{SE(2)}")#text(" again). The great circles ")#mi("{l_{AB}}")#text(" in ")#mi("{Spin(3)}")#text(" then, in the limit, become the analogous sets ")#mi("{l_{AB} = \\{ R \\in SE(2): RA = B \\}}")#text(" in ")#mi("{SE(2)}")#text(", and the above correspondences can then be used to map (most of) ")#mi("{SE(2)}")#text(" to ")#mi("{{\\bf R}^3}")#text(", and (most) ")#mi("{l_{AB}}")#text(" to lines, giving Proposition ")#link(<tao-e835d0bf51a4ea9360cc>)[#text("1")]#text(".")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50601")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("What is the set of points in 7 dimensions that corresponds to rotations in 3 space that send one point to another? Has anyone looked at this before? It looks to me that 7 coordinates are needed. 3 for the center of rotation, 3 for the axis of rotation and one for the magnitude of rotation. If the result in 2 dimensions could be generalized perhaps this set of points would be something relatively simple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("Actually, the space SE(3) of rigid motions in R^3 is six-dimensional rather than seven (one only needs two coordinates, rather than three, to describe the axis of rotation). As in the above post, one can view SE(3) as a scaling limit of SO(4), which has a double cover of Spin(4), but the topology of these spaces is more complicated (there is no analogue of the quaternions to help out in this case). The set of rotations $l_{A \\to B}$ then becomes a double coset of the stabiliser of a single point, which is the three-dimensional space SO(3), which is essentially a 3-sphere (or more precisely, it has a 3-sphere as a double cover, as discussed above).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50602")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("I have been looking at this and if the center of rotation is restricted to a plane in space then I think the two dimensional result goes through and the result is a line with some other fixed coordinates maybe this idea can be used to get at the set of points in 7 dimensional space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50604")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("Terry: in the last paragraph you say that the correspondence can be used to map “most of” SE(2) to R^3, can you say a few words about what are the elements that are left out?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50605")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("It’s the translations which are left out. (One can think of a translation in R^2 as an infinitesimal rotation around an origin on the (projective) line at infinity.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50606")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("Actually, I was hoping you could say a few words about upstairs. Each translation corresponds to an unique element in l_{AB}: is there an easy way to see that this element should necessarily be discarded in the construction you gave?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52f15c1660212362a169e7e97fda2c214d5efcb90cf267db5303ac4d0d84d0b2-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50617")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2011")])]

#text("Ah, nevermind. I think I see. Originally I was under the mis-impression that the elements of SE(2) corresponds to only elements of l_{AB} that lies in the epsilon-ball around i. But in fact it corresponds to any element of an l_{AB} with the property that l_{AB} has one intersection with S^2 that is O(epsilon) of i. (In other words, I didn’t understand what you meant by “epsilon neighborhood of stabiliser of i”.) So in effect you are blowing up two dimensions (corresponding to S^2) using the rescaling and maping the remaining direction (a S^1) to R using projection. Neat.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50611")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2011")])]

#text("This is all completely obvious in the appropriate Geometric Algebra setting")#linebreak()#text(" — for 2-space Euclidean geometry, the spinors of Cl(2,0,1).")

#text("Denoting generators by x, y, o, each rotation thru angle t is represented by")#linebreak()#text(" an even grade-2 versor of the form")#linebreak()#text(" 1 + tan(t/2) (a ox + b oy + p yx)")#linebreak()#text(" mapping immediately to a point on the line joining the origin (0,0,0) to the")#linebreak()#text(" point (a,b,1) in 3-space, setting p = 1. Notice that this mapping sends a")#linebreak()#text(" half-turn to the plane at infinity. Translation thru distance tan(t/2) can")#linebreak()#text(" also be accommodated, simply by setting p = 0.")

#text("For rotation in 3-space, the algebra is Cl(3,0,1), the spinor")#linebreak()#text(" 1 + tan(t/2) (a ox + b oy + c oz + p yx + q xz + r zy)")#linebreak()#text(" mapping to a point on a line thru the origin in 6-space.")#linebreak()#text(" Here p yx + q xz + r zy is constrained by p^2 + q^2 + r^2 = 1 ,")#linebreak()#text(" representing a unit imaginary quaternion; the entire vector represents a")#linebreak()#text(" classical screw. For translation the quaternion part is zero.")

#text("An analogous result holds for rotation / translation with coline axis in")#linebreak()#text(" Euclidean n-space, mapping (rotor) to point on line in dimension (n+1)n/2.")#linebreak()#text(" Once outside 2-space however, a general kinematic isometry is a nontrivial")#linebreak()#text(" composition of rotations and translation, requiring a higher-grade spinor")#linebreak()#text(" (motor) for its representation.")

#text("Another way to look at all this is that it’s about the Lie algebra of the")#linebreak()#text(" Euclidean isometry group E(n).")

#text("Fred Lunnon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50621")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2011")])]

#text("A little clarification of my rather terse previous post —")

#text("Translations require the normalising constraint")#linebreak()#text(" a^2 + b^2 + c^2 … = 1 ;")#linebreak()#text(" the distance travelled (correction) is then 2 tan(t/2) in direction")#linebreak()#text(" perpendicular to copoint (hyperplane) with Cartesian equation")#linebreak()#text(" a X^2 + b Y^2 + c Z^2 + … = 0 .")

#text("Generators x, y, z, … represent (reflections in) copoints perpendicular")#linebreak()#text(" to Cartesian coordinate axes X, Y, Z, … ; o represents an isotropic")#linebreak()#text(" (non-invertible) “black hole” at infinity.")

#text("3-space rotations & reflections map to a quadric cone in 6-space, defined by")#linebreak()#text(" the Grassmann constraint")#linebreak()#text(" a p + b q + c r = 0 ;")#linebreak()#text(" 3-space kinematic isometries maps bijectively to points in Euclidean")#linebreak()#text(" (strictly, projective) 6-space.")

#text("When n >= 4, the analogous correspondence between n-space isometry and")#linebreak()#text(" (n+1)n/2-space point is also bijective, with the exception of a set of")#linebreak()#text(" measure zero comprising isometries whose factorisation into orthogonal")#linebreak()#text(" rotations incorporates more than one half-turn.")

#text("[In Lie-algebra terminology, their differential vanishes at the identity.]")#linebreak()#text(" These includes pure-grade “blades” representing (reflection in) subspaces of")#linebreak()#text(" (even) codimension > 2.")

#text("There is a brief exposition of the 3-space algebra (DCQ) at")#linebreak()#text(" ")#link("https://docs.google.com/leaf?id=0B6QR93hqu1AhMTFjOWFjMGQtM2YwMy00MGIzLWE4NzAtOGYxZGQ4ZGUwNTU3&hl=en")[#text("https://docs.google.com/leaf?id=0B6QR93hqu1AhMTFjOWFjMGQtM2YwMy00MGIzLWE4NzAtOGYxZGQ4ZGUwNTU3&hl=en")]

#text("also accounts by")#linebreak()#text(" Jon.~M.~Selig")#linebreak()#text(" Geometric Fundamentals of Robotics")#linebreak()#text(" Springer (2005)")

#text("and by")#linebreak()#text(" Charles Gunn")#linebreak()#text(" On the Homogeneous Model Of Euclidean Geometry")#linebreak()#text(" AGCSE (2011)")#linebreak()#text(" ")#link("https://arxiv.org/abs/1101.4542")[#text("https://arxiv.org/abs/1101.4542")]

#text("Fred Lunnon")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353db294574b77d85998015b42185b48eccfc964603d2dc00d32795d9e9e8a0a-a6511a8a49674f21017f17e09816198beff00bef720eb01660b6c7e1ccd82265.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Three Dimensional Algebraic Curves | Gaurav Happy Tiwari")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50653")[#strong[#text("Three Dimensional Algebraic Curves | Gaurav Happy Tiwari")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")])]

#text("[…] Lines in the Euclidean group SE(2) (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Exceptional isogenies between the classical Lie groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50675")[#strong[#text("Exceptional isogenies between the classical Lie groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("[…] A slightly different interpretation of this correspondence, using quaternions, was discussed in this recent blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An incidence theorem in higher dimensions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50823")[#strong[#text("An incidence theorem in higher dimensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] this paper we use the polynomial Ham Sandwich method of Guth and Katz (as discussed previously on this blog) to establish higher-dimensional versions of the Szemerédi-Trotter theorem, albeit at the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8379222a720f3789451c0d319e6fbd68ac094d1ef06c8333cdecfb6a090fa25-01afef086f0651e73ce8083c24dd1f2cf92a2723d7906db9ea2525d5c98ceb60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Jones")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50865")[#strong[#text("Tim Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("Dear Professor Tao,")

#text("In your Remark 3, is it obvious that a log factor is required for the distances problem on the sphere? For example, must the lattice grid example for R^2 carry over to S^2? Or might it be possible to remove the log and obtain N distances?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("Good question! I don’t see how the grid example in R^2 extends easily to the S^2 case, so in principle one might be able to do better. On the other hand, I cannot think of a technique which would give better results in the S^2 setting than the R^2 case; typically in mathematics, the flat case is easier than the curved case, so the results tend to be stronger in the former. If the sharp lower bound for R^2 is ever established rigorously, this may shed more light on what is going on at S^2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50933")[#strong[#text("The First Xamuel.com Irregular Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2011")]

#text("[…] Terence Tao: Lines in the Euclidean group SE(2) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2afead5c1103d7e8ec3d749d3dc5f6577b8bbeaf05a51d4c076518ee760571fa-8260f9b1677752e85834376dbeb62f44c698ba582912c22068ac990fefb30b7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Gunn")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-50973")[#strong[#text("Charles Gunn")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2011")])]

#text("A historical note: as far as I can tell, the discovery of this parametrization of SE(2) is due to Eduard Study described in his 1891 paper “Von den bewegungen und umlegungen”, Mathematische Annalen, 39:441–566, 1891. There he develops the theory first for SE(3) (resulting in the so-called dual quaternions, an 8-dimensional algebra, which has found widespread applications in robotics, computer vision, and other applied fields). He then specializes this group to S0(3) (rotations fixing the origin), and carries out a limiting process similar to that described above, to arrive at the euclidean group of the plane. The resulting 4D algebra is sometimes called the planar quaternions (see J. Michael McCarthy. “An Introduction to Theoretical Kinematics”, MIT Press, Cambridge, MA, 1990.) Another thorough treatment of the same can be found in Wilhelm Blaschke, “Ebene Kinematik”, Tuebner, Leibzig, 1938, which includes some very nice geometric motivations of these results. He also (following Study) shows how the planes of the resulting parameter space give rise to a representation of the indirection isometries of the euclidean plane (reflections and glide reflections). Blaschke called this parameter space quasi-elliptic space since it arises from the limit of S3 (as the unit quaternions) in this fashion, when two of the generators become nilpotent (j^2=k^2=0). The points in the “plane at infinity” of the parameter space represent translations; the planes perpendicular to the embedded R2 represent pure reflections.")

#text("All this can be perhaps best understood in a modern context via the Clifford algebra which I write as P(Cl(2,0,1))*: that is, the Clifford algebra with degenerate metric (2,0,1), projectivized (so it acts on projective space P2 and not vector space R3). The ‘*’ means that 1-vectors represent lines, not points (dual construction). The even subalgebra of this Clifford algebra (when normalized called the Spin group) is then isomorphic to the planar quaternions described above, just like the even subalgebra of the nondegenerate (“elliptic”) Clifford algebra P(Cl(3,0))* gives the ordinary quaternions. The indirect isometries are also present (in both cases, naturally) via the so-called Pin group, generated by “sandwiches” gxg~ with a 1-vector g (lines).")

#text("More about P(Cl(2,0,1))* and similar results for 3D can be found in the above-quoted paper:")#linebreak()#text(" Charles Gunn")#linebreak()#text(" On the Homogeneous Model Of Euclidean Geometry")#linebreak()#text(" AGACSE (2011)")#linebreak()#text(" ")#link("https://arxiv.org/abs/1101.4542")[#text("https://arxiv.org/abs/1101.4542")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3b201f0308437d9f237aa2421c789a8ff84f856f2240209b2ad74a1592accc-e239f0fb4837efa15a46cd87f105e0f109c8ac7df42ba28e6eea88c2d9098976.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iosevich")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-51198")[#strong[#text("iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("I have a possibly naive question about the Erdos exponent on the sphere. The only way I see to construct an example of ")#mi("N")#text(" points on the sphere that determine only ")#mi("N")#text(" distances is by placing ")#mi("N")#text(" points uniformly around a great circle. What if one assumes that not all ")#mi("N")#text(" points lie on the same circle. Is it reasonable to conjecture that the exponent increases? Less ambitiously, suppose that the set of ")#mi("N")#text(" points is well-distributed. The best example I am aware of yields ")#mi("N^{\\frac{3}{2}}")#text(" distinct distances. More generally, I wonder if the sharp Erdos exponent of a manifold depends on the degree to which ${\\Bbb Z}^d$ acts transitively on the space in question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-228973")[#strong[#text("Distinct Distances: Open Problems and Current Bounds #2 | The Plane Truth")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2013")]

#text("[…] number of distinct distances that any set of points on a hypersphere in must always determine. Tao showed that the bound of Guth and Katz remains valid when the point set is on a sphere in (or on a hyperbolic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-235878")[#strong[#text("Subsets with no repeated distances | Some Plane Truths")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")]

#text("[…] an extension of Guth and Katz’s distinct distances result to points on a sphere, as derived by Tao. Let be the set of vertices of a regular -gon in . It can be easily verified that the points of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-476805")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2017")])]

#text("“and thus preserves the orthogonal complement {\\{ xi+yj+zk: x^2+y^2+z^2\\}} of that identity in {S^3}” Should that be “x^2 + y^2 + z^2 = 1?”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa30d6d357599534cbd9f486ff57ead6abda0e6e284821e861bce7cdd90c72dd-0f29b8027f92678c254808159ac62ede6c5057b769c63bb83044bdebc7e2ae16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob Kusner")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-645440")[#strong[#text("Rob Kusner")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2022")])]

#text("Hi Terry, I just stumbled on this post and wonder if it’s updated it elsewhere. My comment: Since Spin(4)=Spin(3)xSpin(3) as groups as well as spaces (a concrete way to see this: left and right actions by quaternion multiplication of commute). it may be worth revisiting your comment of 6 March, 2011 at 1:12 pm…. Best, Rob")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa30d6d357599534cbd9f486ff57ead6abda0e6e284821e861bce7cdd90c72dd-0f29b8027f92678c254808159ac62ede6c5057b769c63bb83044bdebc7e2ae16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob Kusner")]], [#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/#comment-645442")[#strong[#text("Rob Kusner")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2022")])]

#text("P.S. Please forgive the typos; I meant to type:")

#text("…quaternion multiplication commute), it may….")

#text("Charles Gunn’s comment also hints at this \\Hx\\H action on \\H.")
]
