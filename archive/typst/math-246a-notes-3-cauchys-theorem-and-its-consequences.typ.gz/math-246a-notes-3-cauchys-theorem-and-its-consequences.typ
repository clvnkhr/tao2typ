// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/
// Converted to Typst by tao2typ: "2026-10-14T15:19:47.870963+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Math 246A, Notes 3: Cauchy’s theorem and its consequences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Math 246A, Notes 3: Cauchy’s theorem and its consequences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(".")

#text("We now come to perhaps the most central theorem in complex analysis (save possibly for the fundamental theorem of calculus), namely ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy’s theorem")]#text(", which allows one to compute a large number of contour integrals ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" even without knowing any explicit antiderivative of ")#mi("{f}")#text(". There are many forms and variants of Cauchy’s theorem. To give one such version, we need the basic topological notion of a ")#link("https://en.wikipedia.org/wiki/Homotopic")[#text("homotopy")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Homotopy)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(", ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" be two curves in ")#mi("{U}")#text(".")

#list(
[#text("(i) If ")#mi("{\\gamma_0, \\gamma_1}")#text(" have the same initial point ")#mi("{z_0}")#text(" and terminal point ")#mi("{z_1}")#text(", we say that ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(" are ")#emph[#text("homotopic with fixed endpoints")]#text(" in ")#mi("{U}")#text(" if there exists a continuous map ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text(" such that ")#mi("{\\gamma(0,t) = \\gamma_0(t)}")#text(" and ")#mi("{\\gamma(1,t) = \\gamma_1(t)}")#text(" for all ")#mi("{t \\in [a,b]}")#text(", and such that ")#mi("{\\gamma(s,a) = z_0}")#text(" and ")#mi("{\\gamma(s,b) = z_1}")#text(" for all ")#mi("{s \\in [0,1]}")#text(".")],
[#text("(ii) If ")#mi("{\\gamma_0, \\gamma_1}")#text(" are closed (but possibly with different initial points), we say that ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(" are ")#emph[#text("homotopic as closed curves")]#text(" in ")#mi("{U}")#text(" if there exists a continuous map ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text(" such that ")#mi("{\\gamma(0,t) = \\gamma_0(t)}")#text(" and ")#mi("{\\gamma(1,t) = \\gamma_1(t)}")#text(" for all ")#mi("{t \\in [a,b]}")#text(", and such that ")#mi("{\\gamma(s,a) = \\gamma(s,b)}")#text(" for all ")#mi("{s \\in [0,1]}")#text(".")],
[#text("(iii) If ")#mi("{\\gamma_2: [c,d] \\rightarrow U}")#text(" and ")#mi("{\\gamma_3: [e,f] \\rightarrow U}")#text(" are curves with the same initial point and same terminal point, we say that ")#mi("{\\gamma_2}")#text(" and ")#mi("{\\gamma_3}")#text(" are ")#emph[#text("homotopic with fixed endpoints up to reparameterisation")]#text(" in ")#mi("{U}")#text(" if there is a reparameterisation ")#mi("{\\tilde \\gamma_2: [a,b] \\rightarrow U}")#text(" of ")#mi("{\\gamma_2}")#text(" which is homotopic with fixed endpoints in ")#mi("{U}")#text(" to a reparameterisation ")#mi("{\\tilde \\gamma_3: [a,b] \\rightarrow U}")#text(" of ")#mi("{\\gamma_3}")#text(".")],
[#text("(iv) If ")#mi("{\\gamma_2: [c,d] \\rightarrow U}")#text(" and ")#mi("{\\gamma_3: [e,f] \\rightarrow U}")#text(" are closed curves, we say that ")#mi("{\\gamma_2}")#text(" and ")#mi("{\\gamma_3}")#text(" are ")#emph[#text("homotopic as closed curves up to reparameterisation")]#text(" in ")#mi("{U}")#text(" if there is a reparameterisation ")#mi("{\\tilde \\gamma_2: [a,b] \\rightarrow U}")#text(" of ")#mi("{\\gamma_2}")#text(" which is homotopic as closed curves in ")#mi("{U}")#text(" to a reparameterisation ")#mi("{\\tilde \\gamma_3: [a,b] \\rightarrow U}")#text(" of ")#mi("{\\gamma_3}")#text(".")]
)

#text("In the first two cases, the map ")#mi("{\\gamma}")#text(" will be referred to as a ")#emph[#text("homotopy")]#text(" from ")#mi("{\\gamma_0}")#text(" to ")#mi("{\\gamma_1}")#text(", and we will also say that ")#mi("{\\gamma_0}")#text(" can be ")#emph[#text("continuously deformed to")]#text(" ")#mi("{\\gamma_1}")#text(" (either with fixed endpoints, or as closed curves).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-1143da2bc54c495c4be3>#text(" If ")#mi("{U}")#text(" is a convex set, that is to say that ")#mi("{(1-s) z_0 + s z_1 \\in U}")#text(" whenever ")#mi("{z_0,z_1 \\in U}")#text(" and ")#mi("{0 \\leq s \\leq 1}")#text(", then any two curves ")#mi("{\\gamma_0, \\gamma_1: [0,1] \\rightarrow U}")#text(" from one point ")#mi("{z_0}")#text(" to another ")#mi("{z_1}")#text(" are homotopic, by using the homotopy")

#align(center)[#tao-fit-display[#mitex("\\gamma(s,t) := (1-s) \\gamma_0(t) + s \\gamma_1(t).")]]

#text("For a similar reason, in a convex open set ")#mi("{U}")#text(", any two closed curves will be homotopic to each other as closed curves.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-db47b1c1e7b057ffe3d0>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(".")

#list(
[#text("(i) Prove that the property of being homotopic with fixed endpoints in ")#mi("{U}")#text(" is an equivalence relation.")],
[#text("(ii) Prove that the property of being homotopic as closed curves in ")#mi("{U}")#text(" is an equivalence relation.")],
[#text("(iii) If ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(", ")#mi("{\\gamma_1: [c,d] \\rightarrow U}")#text(" are closed curves with the same initial point, show that ")#mi("{\\gamma_0}")#text(" is homotopic to ")#mi("{\\gamma_1}")#text(" as closed curves up to reparameterisation if and only if ")#mi("{\\gamma_0}")#text(" is homotopic to ")#mi("{\\gamma_2 + \\gamma_1 + (-\\gamma_2)}")#text(" with fixed endpoints for some closed curve ")#mi("{\\gamma_2}")#text(" with the same initial point as ")#mi("{\\gamma_0}")#text(" or ")#mi("{\\gamma_1}")#text(" up to reparameterisation. (Hint: it may be conceptually easier to think about the case when ")#mi("{\\gamma_0, \\gamma_1}")#text(" do not necessarily have the same initial point, in which case the same claim is true, except that ")#mi("{\\gamma_2}")#text(" is now not a closed curve, but rather a curve that starts at the initial point of ")#mi("{\\gamma_0}")#text(" and ends at the initial point of ")#mi("{\\gamma_1}")#text(".) For an additional challenge: propose a counterexample that explains why the curve ")#mi("{\\gamma_2}")#text(" is necessary (in the initial context where ")#mi("{\\gamma_0}")#text(", ")#mi("{\\gamma_1}")#text(" have the same initial point).")],
[#text("(iv) Define a ")#emph[#text("point")]#text(" in ")#mi("{U}")#text(" to be a curve ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" of the form ")#mi("{\\gamma_1(t) = z_0}")#text(" for some ")#mi("{z_0 \\in U}")#text(" and all ")#mi("{t \\in [a,b]}")#text(". Let ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(" be a closed curve in ")#mi("{U}")#text(". Show that ")#mi("{\\gamma_0}")#text(" is homotopic with fixed endpoints to a point in ")#mi("{U}")#text(" if and only if ")#mi("{\\gamma_0}")#text(" is homotopic as a closed curve to a point in ")#mi("{U}")#text(". (In either case, we will call ")#mi("{\\gamma_0}")#text(" ")#emph[#text("homotopic to a point")]#text(", ")#emph[#text("null-homotopic")]#text(", or ")#emph[#text("contractible to a point")]#text(" in ")#mi("{U}")#text(".)")],
[#text("(v) If ")#mi("{\\gamma_0, \\gamma_1: [a,b] \\rightarrow U}")#text(" are curves with the same initial point and the same terminal point, show that ")#mi("{\\gamma_0}")#text(" is homotopic to ")#mi("{\\gamma_1}")#text(" with fixed endpoints in ")#mi("{U}")#text(" if and only if ")#mi("{\\gamma_0 + (-\\gamma_1)}")#text(" is homotopic to a point in ")#mi("{U}")#text(".")],
[#text("(vi) If ")#mi("{U}")#text(" is connected, and ")#mi("{\\gamma_0, \\gamma_1: [a,b] \\rightarrow U}")#text(" are any two curves in ")#mi("{U}")#text(", show that there exists a continuous map ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text(" such that ")#mi("{\\gamma(0,t) = \\gamma_0(t)}")#text(" and ")#mi("{\\gamma(1,t) = \\gamma_1(t)}")#text(" for all ")#mi("{t \\in [a,b]}")#text(". Thus the notion of homotopy becomes rather trivial if one does not fix the endpoints or require the curve to be closed.")],
[#text("(vii) Show that if ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" is a reparameterisation of ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(", then ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(" are homotopic with fixed endpoints in U.")],
[#text("(viii) Prove that the property of being homotopic with fixed endpoints in ")#mi("{U}")#text(" up to reparameterisation is an equivalence relation.")],
[#text("(ix) Prove that the property of being homotopic as closed curves in ")#mi("{U}")#text(" up to reparameterisation is an equivalence relation.")]
)
]

#text("We can then phrase Cauchy’s theorem as an assertion that contour integration on holomorphic functions is a homotopy invariant. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Cauchy’s theorem)")]#text(" ")#metadata(none) <tao-27368d421f0ff4d182b6>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic.")

#list(
[#text("(i) If ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(" and ")#mi("{\\gamma_1: [c,d] \\rightarrow U}")#text(" are rectifiable curves that are homotopic in ")#mi("{U}")#text(" with fixed endpoints up to reparameterisation, then")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_0} f(z)\\ dz = \\int_{\\gamma_1} f(z)\\ dz.")]]],
[#text("(ii) If ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(" and ")#mi("{\\gamma_1: [c,d] \\rightarrow U}")#text(" are closed rectifiable curves that are homotopic in ")#mi("{U}")#text(" as closed curves up to reparameterisation, then")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_0} f(z)\\ dz = \\int_{\\gamma_1} f(z)\\ dz.")]]]
)
]

#text("This version of Cauchy’s theorem is particularly useful for applications, as it explicitly brings into play the powerful technique of ")#emph[#text("contour shifting")]#text(", which allows one to compute a contour integral by replacing the contour with a homotopic contour on which the integral is easier to either compute or integrate. This formulation of Cauchy’s theorem also highlights the close relationship between contour integrals and the ")#link("https://en.wikipedia.org/wiki/Algebraic_topology")[#text("algebraic topology")]#text(" of the complex plane (and open subsets ")#mi("{U}")#text(" thereof). Setting ")#mi("{\\gamma_1}")#text(" to be a point, we obtain an important special case of Cauchy’s theorem (which is in fact equivalent to the full theorem):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Cauchy’s theorem, again)")]#text(" ")#metadata(none) <tao-122c597083bd438b7f6d>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic. Then for any closed rectifiable curve ")#mi("{\\gamma}")#text(" in ")#mi("{U}")#text(" that is contractible in ")#mi("{U}")#text(" to a point, one has ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that Theorem ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(" and Corollary ")#link(<tao-122c597083bd438b7f6d>)[#text("5")]#text(" are logically equivalent.")
]

#text("An important feature to note about Cauchy’s theorem is the ")#emph[#text("global")]#text(" nature of its hypothesis on ")#mi("{f}")#text(". The conclusion of Cauchy’s theorem only involves the values of a function ")#mi("{f}")#text(" on the images of the two curves ")#mi("{\\gamma_0, \\gamma_1}")#text(". However, in order for the hypotheses of Cauchy’s theorem to apply, the function ")#mi("{f}")#text(" must be holomorphic not only on the images on ")#mi("{\\gamma_0, \\gamma_1}")#text(", but on an open set ")#mi("{U}")#text(" that is large enough (and sufficiently free of “holes”) to support a homotopy between the two curves. This point can be emphasised through the following fundamental near-counterexample to Cauchy’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7 (Key example)")]#text(" ")#metadata(none) <tao-2c70e12b7a0646f92279>#text(" Let ")#mi("{U := {\\bf C} \\backslash \\{0\\}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be the holomorphic function ")#mi("{f(z) := \\frac{1}{z}}")#text(". Let ")#mi("{\\gamma_{0,1,\\circlearrowleft}: [0,2\\pi] \\rightarrow {\\bf C}}")#text(" be the closed unit circle contour ")#mi("{\\gamma_{0,1,\\circlearrowleft}(t) := e^{it}}")#text(". Direct calculation shows that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{0,1,\\circlearrowleft}} f(z)\\ dz = 2\\pi i \\neq 0.")]]

#text("As a consequence of this and Cauchy’s theorem, we conclude that the contour ")#mi("{\\gamma_{0,1,\\circlearrowleft}}")#text(" is not contractible to a point in ")#mi("{U}")#text("; note that this does not contradict Example ")#link(<tao-1143da2bc54c495c4be3>)[#text("2")]#text(" because ")#mi("{U}")#text(" is not convex. Thus we see that the lack of holomorphicity (or ")#emph[#text("singularity")]#text(") of ")#mi("{f}")#text(" at the origin can be “blamed” for the non-vanishing of the integral of ")#mi("{f}")#text(" on the closed contour ")#mi("{\\gamma_{0,1,\\circlearrowleft}}")#text(", even though this contour does not come anywhere near the origin. Thus we see that the global behaviour of ")#mi("{f}")#text(", not just the behaviour in the local neighbourhood of ")#mi("{\\gamma_{0,1,\\circlearrowleft}}")#text(", has an impact on the contour integral.")#linebreak()#text(" One can of course rewrite this example to involve non-closed contours instead of closed ones. For instance, if we let ")#mi("{\\gamma_0, \\gamma_1: [0,\\pi] \\rightarrow U}")#text(" denote the half-circle contours ")#mi("{\\gamma_0(t) := e^{it}}")#text(" and ")#mi("{\\gamma_1(t) := e^{-it}}")#text(", then ")#mi("{\\gamma_0,\\gamma_1}")#text(" are both contours in ")#mi("{U}")#text(" from ")#mi("{+1}")#text(" to ")#mi("{-1}")#text(", but one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_0} f(z)\\ dz = +\\pi i")]]

#text("whereas")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_1} f(z)\\ dz = -\\pi i.")]]

#text("In order for this to be consistent with Cauchy’s theorem, we conclude that ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(" are not homotopic in ")#mi("{U}")#text(" (even after reparameterisation).")
]

#text("In the specific case of functions of the form ")#mi("{\\frac{1}{z}}")#text(", or more generally ")#mi("{\\frac{f(z)}{z-z_0}}")#text(" for some point ")#mi("{z_0}")#text(" and some ")#mi("{f}")#text(" that is holomorphic in some neighbourhood of ")#mi("{z_0}")#text(", we can quantify the precise failure of Cauchy’s theorem through the ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_formula")[#text("Cauchy integral formula")]#text(", and through the concept of a ")#link("https://en.wikipedia.org/wiki/Winding_number")[#text("winding number")]#text(". These turn out to be extremely powerful tools for understanding both the nature of holomorphic functions and the topology of open subsets of the complex plane, as we shall see in this and later notes.")

#metadata(none) <tao-85288774e7ae82573ef9>

#heading(level: 1)[#strong[#text(" — 1. Proof of Cauchy’s theorem — ")]]

#text("The underlying reason for the truth of Cauchy’s theorem can be explained in one sentence: complex differentiable functions behave locally like complex linear functions, which are conservative thanks to the fundamental theorem of calculus. More precisely, if ")#mi("{f(z) = a + bz}")#text(" is any complex linear function of ")#mi("{z}")#text(", then ")#mi("{f}")#text(" has an antiderivative ")#mi("{az + \\frac{1}{2} bz^2}")#text(", and hence ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_\\gamma (a+bz)\\ dz = 0")]]

#linebreak()#text(" for any rectifiable closed curve ")#mi("{\\gamma}")#text(" in the complex plane.")#linebreak()#text(" Perhaps the slickest way to make this intuition rigorous is through the following special case of Cauchy’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Goursat’s theorem)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and ")#mi("{z_1,z_2,z_3}")#text(" be complex numbers such that the solid (and closed) triangle spanned by ")#mi("{z_1,z_2,z_3}")#text(" (or more precisely, the ")#emph[#text("convex hull")]#text(" of ")#mi("{\\{z_1,z_2,z_3\\}}")#text(") is contained in ")#mi("{U}")#text(". (We allow the triangle to degenerate in that we allow the ")#mi("{z_1,z_2,z_3}")#text(" to be collinear, or even coincident.) Then for any holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow z_3 \\rightarrow z_1}} f(z)\\ dz = 0,")]]

#text("where ")#mi("{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow z_3 \\rightarrow z_1}}")#text(" is the closed polygonal path that traverses the vertices ")#mi("{z_1, z_2, z_3}")#text(" of the solid triangle in order.")
]

#emph[#text("Proof:")]#text(" Let us denote the triangular contour ")#mi("{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow z_3 \\rightarrow z_1}}")#text(" as ")#mi("{T_0}")#text(". It is convenient (though odd-looking at first sight) to prove this theorem by contradiction. That is to say, suppose for contradiction that we had ")#metadata(none) <tao-628b49d96dcde97a430d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\int_{T_0} f(z)\\ dz\\right| \\geq \\varepsilon", block: true)]]

#linebreak()#text(" for some ")#mi("{\\varepsilon > 0}")#text(". We now run the following “divide and conquer” strategy. We let ")#mi("{z_{12} := \\frac{z_1+z_2}{2}}")#text(", ")#mi("{z_{23} := \\frac{z_2+z_3}{2}}")#text(", ")#mi("{z_{31} := \\frac{z_3 + z_1}{2}}")#text(" be the midpoints of ")#mi("{z_1, z_2, z_3}")#text(". Then from the basic properties of contour integration (see Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration")[#text("Notes 2")]#text(") we can split the triangular integral ")#mi("{\\int_{T_1} f(z)\\ dz}")#text(" as the sum of four integrals on smaller triangles, namely")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_1 \\rightarrow z_{12} \\rightarrow z_{31} \\rightarrow z_1}} f(z)\\ dz")]]

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_{12} \\rightarrow z_2 \\rightarrow z_{23} \\rightarrow z_{12}}} f(z)\\ dz")]]

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_{23} \\rightarrow z_3 \\rightarrow z_{31} \\rightarrow z_{23}}} f(z)\\ dz")]]

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_{12} \\rightarrow z_{23} \\rightarrow z_{31} \\rightarrow z_{12}}} f(z)\\ dz.")]]

#text("(The reader is encouraged to draw a picture to visualise this decomposition.) By ")#link(<tao-628b49d96dcde97a430d>)[#text("(2)")]#text(" and the triangle inequality (or, if one prefers, the pigeonhole principle), we must therefore have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{T_1} f(z)\\ dz\\right| \\geq \\frac{\\varepsilon}{4}", block: true)]]

#text("where ")#mi("{T_1}")#text(" is one of the four triangular contours ")#mi("{\\gamma_{z_1 \\rightarrow z_{12} \\rightarrow z_{31} \\rightarrow z_1}}")#text(", ")#mi("{\\gamma_{z_{12} \\rightarrow z_2 \\rightarrow z_{23} \\rightarrow z_{12}}}")#text(", ")#mi("{\\gamma_{z_{23} \\rightarrow z_3 \\rightarrow z_{31} \\rightarrow z_{23}}}")#text(", or ")#mi("{\\gamma_{z_{12} \\rightarrow z_{23} \\rightarrow z_{31} \\rightarrow z_{12}}}")#text(". Regardless of which of the four contours ")#mi("{T_1}")#text(" is, observe that the triangular region enclosed by ")#mi("{T_1}")#text(" is contained in that of ")#mi("{T_0}")#text(". Furthermore, the ")#link("https://en.wikipedia.org/wiki/Diameter")[#text("diameter")]#text(" of ")#mi("{T_1}")#text(" is precisely half that of ")#mi("{T_0}")#text(", where the diameter ")#mi("{\\mathrm{diam}(\\gamma)}")#text(" of a curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{diam}(\\gamma) := \\sup_{t, t^{\\prime} \\in [a,b]} \\left|\\gamma(t) - \\gamma(t^{\\prime})\\right|;", block: true)]]

#text("similarly, the perimeter ")#tao-math("{\\left|T_1\\right|}", block: false)#text(" of ")#mi("{T_1}")#text(" is precisely half that of ")#mi("{T_0}")#text(". If we iterate the above process, we can find a nested sequence ")#mi("{T_0, T_1, T_2, \\dots}")#text(" of triangular contours, each of which is contained in the previous one with half the diameter and perimeter, such that ")#metadata(none) <tao-0570e42d617f3c3ff6f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\int_{T_n} f(z)\\ dz\\right| \\geq \\frac{\\varepsilon}{4^n}", block: true)]]

#text("for all ")#mi("{n=0,1,2,\\dots}")#text(". If we let ")#mi("{z_n}")#text(" be any point enclosed by ")#mi("{T_n}")#text(", then from the decreasing diameters it is clear that the ")#mi("{z_n}")#text(" are a Cauchy sequence and thus converge to some limit ")#mi("{z_*}")#text(", which is then contained in all of the closed triangles enclosed by any of the ")#mi("{T_n}")#text(".")#linebreak()#text(" In particular, ")#mi("{z_*}")#text(" lies in ")#mi("{U}")#text(" and so ")#mi("{f}")#text(" is differentiable at ")#mi("{z_*}")#text(". This implies, for any ")#mi("{\\varepsilon^{\\prime}>0}")#text(", that there exists a ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{f(z) - f(z_*)}{z-z_*} - f^{\\prime}(z_*)\\right| \\leq \\varepsilon^{\\prime}", block: true)]]

#text("whenever ")#mi("{z \\in D(z_*,\\delta) \\backslash \\{z_*\\}}")#text(". We can rearrange this as")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z) - (f(z_*) + (z-z_*) f^{\\prime}(z_*))\\right| \\leq \\varepsilon^{\\prime} \\left|z-z_*\\right|", block: true)]]

#text("on ")#mi("{D(z_*,\\delta)}")#text(". In particular, for ")#mi("{n}")#text(" large enough, this bound holds on the image on ")#mi("{T_n}")#text(". In this case we can bound ")#tao-math("{\\left|z-z_*\\right|}", block: false)#text(" by ")#mi("{\\mathrm{diam}(T_n)}")#text(", and hence by Exercise 18(v) of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration")[#text("Notes 2")]#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{T_n} f(z)\\ dz - \\int_{T_n} (f(z_*) + (z-z_*) f^{\\prime}(z_*))\\ dz\\right| \\leq \\varepsilon^{\\prime} \\text{diam}(T_n) |T_n|.", block: true)]]

#text("From ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(", the second integral vanishes. As each ")#mi("{T_n}")#text(" has half the diameter and perimeter of the previous, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{T_n} f(z)\\ dz\\right| \\leq \\frac{\\varepsilon^{\\prime} \\text{diam}(T_0) \\left|T_0\\right|}{4^n}.", block: true)]]

#text("But if one chooses ")#mi("{\\varepsilon^{\\prime}}")#text(" small enough depending on ")#mi("{\\varepsilon}")#text(" and ")#mi("{T_0}")#text(", we contradict ")#link(<tao-0570e42d617f3c3ff6f9>)[#text("(3)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" This is a rare example of an argument in which a hypothesis of differentiability, rather than ")#emph[#text("continuous")]#text(" differentiability, is used, because one can localise any failure of the conclusion all the way down to a single point. Another instance of such an argument is the standard proof of ")#link("https://en.wikipedia.org/wiki/Rolle%27s_theorem")[#text("Rolle’s theorem")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Find a proof of Goursat’s theorem that avoids explicit use of proof by contradiction. (")#emph[#text("Hint:")]#text(" use the fact that a solid triangle is compact, in the sense that every open cover has a finite subcover. For the purposes of this question, ignore the possibility that the proof of this latter fact might also use proof by contradiction.) UPDATE:This exercise turned out to be significantly harder than expected, in particular the proof I had in mind does not work. This exercise will be removed in later iterations of the course.")
]

#text("Goursat’s theorem only directly handles triangular contours, but as long as one works “locally”, or more precisely in a convex domain, we can quickly generalise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Local Cauchy’s theorem for polygonal paths)")]#text(" ")#metadata(none) <tao-2e68a8e49fe8b9e6e94c>#text(" Let ")#mi("{U}")#text(" be a convex open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function. Then for any closed polygonal path ")#mi("{\\gamma = \\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" in ")#mi("{U}")#text(", we have ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on the number of vertices ")#mi("{n}")#text(". The cases ")#mi("{n=1,2}")#text(" are trivial, and the ")#mi("{n=3}")#text(" case follows directly from Goursat’s theorem (using the convexity of ")#mi("{U}")#text(" to ensure that the interior of the polygon lies in ")#mi("{U}")#text("). If ")#mi("{n > 3}")#text(", we can split")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}} f(z)\\ dz = \\int_{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_{n-1} \\rightarrow z_1}} f(z)\\ dz + \\int_{z_{n-1} \\rightarrow z_n \\rightarrow z_1 \\rightarrow z_{n-1}} f(z)\\ dz.")]]

#text("The second integral on the right-hand side vanishes by Goursat’s theorem. The claim then follows from induction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" By using the (real-variable) fundamental theorem of calculus and ")#link("https://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini’s theorem")]#text(" in place of Goursat’s theorem, give an alternate proof of Corollary ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("11")]#text(" in the case that ")#mi("{\\gamma}")#text(" is a rectangle ")#mi("{\\gamma = \\gamma_{a+bi \\rightarrow c+bi \\rightarrow c+di \\rightarrow a+di \\rightarrow a+bi}}")#text(" and the derivative ")#mi("{f^{\\prime}}")#text(" of ")#mi("{f}")#text(" is continuous. (One can also use ")#link("https://en.wikipedia.org/wiki/Stokes%27_theorem")[#text("Stokes’ theorem")]#text(" in place of the fundamental theorem of calculus and Fubini’s theorem.)")
]

#text("We can amplify Corollary ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("11")]#text(" using the fundamental theorem of calculus again:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Local Cauchy’s theorem)")]#text(" ")#metadata(none) <tao-5cde6db2fef7460cac3c>#text(" Let ")#mi("{U}")#text(" be a convex open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function. Then ")#mi("{f}")#text(" has an antiderivative ")#mi("{F: U \\rightarrow {\\bf C}}")#text(". Also, ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for any closed rectifiable curve ")#mi("{\\gamma}")#text(" in ")#mi("{U}")#text(", and ")#mi("{\\int_{\\gamma_1} f(z)\\ dz = \\int_{\\gamma_2} f(z)\\ dz}")#text(" whenever ")#mi("{\\gamma_1, \\gamma_2}")#text(" are two rectifiable curves in ")#mi("{U}")#text(" with the same initial point and same terminal point. In other words, ")#mi("{f}")#text(" is conservative on ")#mi("{U}")#text(".")
]

#emph[#text("Proof:")]#text(" The first claim follows from Corollary ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("11")]#text(" and the second fundamental theorem of calculus (Theorem 31 from ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text("). The remaining claims then follow from the first fundamental theorem of calculus (Theorem 28 from ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text("). ")#mi("\\Box")

#text("We can now prove Cauchy’s theorem in the form of Theorem ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(".")

#emph[#text("Proof:")]#text(" We will just prove part (i), as part (ii) is similar (and in any event it follows from part (i)). Since reparameterisation does not affect the integral, we may assume without loss of generality that ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(" and ")#mi("{\\gamma_1: [a,b] \\rightarrow U}")#text(" are homotopic with fixed endpoints, and not merely homotopic with fixed endpoints up to reparameterisation.")

#text("Let ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow U}")#text(" be a homotopy from ")#mi("{\\gamma_0}")#text(" to ")#mi("{\\gamma_1}")#text(". Note that for any ")#mi("{s \\in [0,1]}")#text(" and ")#mi("{t \\in [a,b]}")#text(", ")#mi("{\\gamma(s,t)}")#text(" lies in the open set ")#mi("{U}")#text(". From compactness, there must exist a radius ")#mi("{r>0}")#text(" such that ")#mi("{D(\\gamma(s,t),r) \\subset U}")#text(" for all ")#mi("{s \\in [0,1]}")#text(" and ")#mi("{t \\in [a,b]}")#text(". Next, as ")#mi("{\\gamma}")#text(" is continuous on a compact set, it is uniformly continuous. In particular, there exists ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma(s^{\\prime},t^{\\prime}) - \\gamma(s,t)\\right| \\leq \\frac{r}{4}", block: true)]]

#text("whenever ")#mi("{s,s^{\\prime} \\in [0,1]}")#text(" and ")#mi("{t,t^{\\prime} \\in [a,b]}")#text(" are such that ")#tao-math("{\\left|s-s^{\\prime}\\right| \\leq \\delta}", block: false)#text(" and ")#tao-math("{\\left|t-t^{\\prime}\\right| \\leq \\delta}", block: false)#text(".")#linebreak()#text(" Now partition ")#mi("{[0,1]}")#text(" and ")#mi("{[a,b]}")#text(" as ")#mi("{0 = s_0 < \\dots < s_n = 1}")#text(" and ")#mi("{a = t_0 < \\dots < t_m = b}")#text(" in such a way that ")#tao-math("{\\left|s_i - s_{i-1}\\right| \\leq \\delta}", block: false)#text(" and ")#tao-math("{\\left|t_j-t_{j-1}\\right| \\leq \\delta}", block: false)#text(" for all ")#mi("{1 \\leq i \\leq n}")#text(" and ")#mi("{1 \\leq j \\leq m}")#text(". For each such ")#mi("{i}")#text(" and ")#mi("{j}")#text(", let ")#mi("{C_{i,j}}")#text(" denote the closed polygonal contour")

#align(center)[#tao-fit-display[#mitex("C_{i,j} := \\gamma_{\\gamma(s_i,t_{j-1}) \\rightarrow \\gamma(s_i,t_j) \\rightarrow \\gamma(s_{i-1},t_j) \\rightarrow \\gamma(s_{i-1},t_{j-1}) \\rightarrow \\gamma(s_i,t_{j-1})}.")]]

#text("(the reader is encouraged here to draw a picture of the situation; we are using polygonal contours here rather than the homotopy ")#mi("{\\gamma}")#text(" because we did not require any rectifiability properties on the homotopy). By construction, the diameter of this contour is at most ")#mi("{\\frac{r}{4}+\\frac{r}{4}+\\frac{r}{4}+\\frac{r}{4} = r}")#text(", so the contour is contained entirely in the disk ")#mi("{D( \\gamma(s_i,t_i), r)}")#text(". This disk is convex and contained in ")#mi("{U}")#text(". Applying Corollary ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("11")]#text(" or Corollary ")#link(<tao-5cde6db2fef7460cac3c>)[#text("13")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{C_{i,j}} f(z)\\ dz = 0")]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(" and ")#mi("{1 \\leq j \\leq m}")#text(". If we sum this over all ")#mi("{i}")#text(" and ")#mi("{j}")#text(", and noting that the homotopy fixes the endpoints, we conclude after a lot of cancelling that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{\\gamma(0,t_0) \\rightarrow \\gamma(0, t_1) \\rightarrow \\dots \\rightarrow \\gamma(0, t_n)}} f(z)\\ dz = \\int_{\\gamma_{\\gamma(1,t_0) \\rightarrow \\gamma(1, t_1) \\rightarrow \\dots \\rightarrow \\gamma(1, t_n)}} f(z)\\ dz")]]

#text("(again, the reader is encouraged to draw a picture to see this cancellation). However, from a further application of Corollary ")#link(<tao-5cde6db2fef7460cac3c>)[#text("13")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{\\gamma(0,t_{i-1}) \\rightarrow \\gamma(0,t_i)}} f(z)\\ dz = \\int_{\\gamma_{0,[t_{i-1},t_i]}} f(z)\\ dz")]]

#text("for ")#mi("{i=1,\\dots,n}")#text(", where ")#mi("{\\gamma_{0,[t_{i-1},t_i]}: [t_{i-1},t_i] \\rightarrow U}")#text(" is the restriction of ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text(" to ")#mi("{[t_{i-1},t_i]}")#text(", and similarly for ")#mi("{\\gamma_1}")#text(". Putting all this together we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_0} f(z)\\ dz = \\int_{\\gamma_1} f(z)\\ dz")]]

#text("as required. ")#mi("\\Box")#linebreak()#text(" One nice feature of Cauchy’s theorem is that it allows one to integrate holomorphic functions on curves that are not necessarily rectifiable. Indeed, if ")#mi("{\\gamma: [a,b] \\rightarrow U}")#text(" is a curve in ")#mi("{U}")#text(", then for a sufficiently fine partition ")#mi("{a = t_0 < t_1 < \\dots < t_n = b}")#text(", the polygonal (and hence rectifiable) path ")#mi("{\\gamma_{t_0 \\rightarrow t_1 \\rightarrow \\dots \\rightarrow t_n}}")#text(" will be contained in ")#mi("{U}")#text(", and furthermore be homotopic to ")#mi("{\\gamma}")#text(" with fixed endpoints. One can then ")#emph[#text("define")]#text(" ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" when ")#mi("{f}")#text(" is holomorphic in ")#mi("{U}")#text(" and ")#mi("{\\gamma}")#text(" is non-rectifiable by declaring")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz := \\int_{\\tilde \\gamma} f(z)\\ dz")]]

#text("where ")#mi("{\\tilde \\gamma}")#text(" is ")#emph[#text("any")]#text(" rectifiable curve that is homotopic (with fixed endpoints) to ")#mi("{\\gamma}")#text(". This is a well defined definition thanks to the above discussion as well as Cauchy’s theorem; also observe that the exact open set ")#mi("{U}")#text(" in which the homotopy lives is not relevant, since given any two open sets ")#mi("{U,U^{\\prime}}")#text(" containing the image of ")#mi("{\\gamma}")#text(" one can find a rectifiable curve ")#mi("{\\tilde \\gamma}")#text(" which is homotopic to ")#mi("{\\gamma}")#text(" with fixed endpoints in ")#mi("{U \\cap U^{\\prime}}")#text(", and hence in ")#mi("{U}")#text(" and ")#mi("{U^{\\prime}}")#text(" separately. With this extended notion of the contour integral, one can then remove the hypothesis of rectifiability from many theorems involving integration of holomorphic functions. In particular, Cauchy’s theorem itself now holds for non-rectifiable curves. This reflects some duality in the integration concept ")#mi("{\\int_\\gamma f(z)\\ dz}")#text("; if one assumes more regularity on the function ")#mi("{f}")#text(", one can get away with worse regularity on the curve ")#mi("{\\gamma}")#text(", and vice versa.")#linebreak()#text(" A special case of Cauchy’s theorem is worth recording explicitly. We say that an open set ")#mi("{U}")#text(" in the complex plane is ")#link("https://en.wikipedia.org/wiki/Simply_connected_space")[#text("simply connected")]#text(" if it is non-empty, connected, and if every closed curve in ")#mi("{U}")#text(" is contractible in ")#mi("{U}")#text(" to a point. For instance, from Example ")#link(<tao-1143da2bc54c495c4be3>)[#text("2")]#text(" we see that any convex non-empty open set is simply connected. From Theorem ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(" we then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Cauchy’s theorem, simply connected case)")]#text(" ")#metadata(none) <tao-c62471c786fca94e9237>#text(" Let ")#mi("{U}")#text(" be a simply connected subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic. Then ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for any closed curve in ")#mi("{U}")#text(". In particular (by Exercise 32 of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text("), ")#mi("{f}")#text(" is conservative and has an antiderivative.")
]

#text("One can interpret Cauchy’s theorem through the lens of ")#link("https://en.wikipedia.org/wiki/Algebraic_topology")[#text("algebraic topology")]#text(", and particularly through the machinery of ")#link("https://en.wikipedia.org/wiki/Homology_(mathematics)")[#text("homology")]#text(" and ")#link("https://en.wikipedia.org/wiki/Cohomology")[#text("cohomology")]#text(". We will not develop this perspective in depth in these notes, but the following exercise will give a brief glimpse of the connections to homology and cohomology.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(". Define a ")#link("https://en.wikipedia.org/wiki/Chain_(algebraic_topology)")[#mi("{0}")#text("-chain")]#text(" in ")#mi("{U}")#text(" to be a formal linear combination")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i [z_i]")]]

#text("of points ")#mi("{z_i \\in U}")#text(" (which we enclose in brackets to avoid confusion with the arithmetic operations on ")#mi("{{\\bf C}}")#text(", in particular ")#mi("{[z]+[w]}")#text(" is ")#emph[#text("not")]#text(" identified with ")#mi("{[z+w]}")#text("), where ")#mi("{n}")#text(" is a natural number and the ")#mi("{m_i}")#text(" are integers; these form an additive abelian group in the usual fashion. Similarly, define a ")#emph[#mi("{1}")#text("-chain")]#text(" in ")#mi("{U}")#text(" to be a formal linear combination")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i [\\gamma_i]")]]

#text("of curves ")#mi("{\\gamma_i: [0,1] \\rightarrow U}")#text(" in ")#mi("{U}")#text(", which (for very minor notational reasons) we will fix to have domain in the unit interval ")#mi("{[0,1]}")#text(". Finally, define a ")#emph[#mi("{2}")#text("-chain")]#text(" in ")#mi("{U}")#text(" to be a formal linear combination")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n m_i [T_i]")]]

#text("of ")#link("https://en.wikipedia.org/wiki/Simplex")[#mi("{2}")#text("-simplices")]#text(" ")#mi("{T_i: \\Delta_2 \\rightarrow U}")#text(", defined as continuous maps from the solid triangle ")#mi("{\\Delta_2 := \\{ (x,y) \\in {\\bf R}^2: x,y \\geq 0; x+y \\leq 1 \\}}")#text(".")#linebreak()#text(" Given a ")#mi("{1}")#text("-chain ")#mi("{c = \\sum_{i=1}^n m_i [\\gamma_i]}")#text(" in ")#mi("{U}")#text(", we define its ")#emph[#text("boundary")]#text(" ")#mi("{\\partial c}")#text(" to be the ")#mi("{0}")#text("-chain")

#align(center)[#tao-fit-display[#mitex("\\partial c := \\sum_{i=1}^n m_i ( [\\gamma_i(1)] - [\\gamma_i(0)] )")]]

#text("and call ")#mi("{c}")#text(" a ")#emph[#mi("{1}")#text("-cycle")]#text(" if ")#mi("{\\partial c = 0}")#text(". Similarly, given a ")#mi("{2}")#text("-chain ")#mi("{c = \\sum_{i=1}^2 m_i [T_i]}")#text(", we define its ")#emph[#text("boundary")]#text(" ")#mi("{\\partial c}")#text(" to be the ")#mi("{1}")#text("-chain")

#tao-aligned(keep: true)[


#tao-math("\\partial c  & := \\sum_{i=1}^n m_i ( [t \\mapsto T_i(0,t)] + [t \\mapsto T_i(t,1-t)]", block: true)



#tao-math(" & + [t \\mapsto T_i(1-t,0)] )", block: true)
]

#text("where ")#mi("{t \\mapsto T_i(0,t)}")#text(" is the curve on ")#mi("{[0,1]}")#text(" that maps ")#mi("{t}")#text(" to ")#mi("{T_i(0,t)}")#text(", and similarly for ")#mi("{t \\mapsto T_i(t,1-t)}")#text(" and ")#mi("{t \\mapsto T_i(1-t,0)}")#text(". If ")#mi("{c := \\sum_{i=1}^n m_i [\\gamma_i]}")#text(" is a ")#mi("{1}")#text("-cycle, and ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic, define the integral ")#mi("{\\int_c f}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\int_c f := \\sum_{i=1}^n m_i \\int_{\\gamma_i} f(z)\\ dz.")]]

#text("If ")#mi("{z_0}")#text(" lies outside of a ")#mi("{1}")#text("-cycle ")#mi("{c}")#text(", define the ")#emph[#text("winding number")]

#align(center)[#tao-fit-display[#mitex("W_c(z_0) := \\frac{1}{2\\pi i} \\int_c \\frac{1}{z-z_0}.")]]

#list(
[#text("(i) Show that if ")#mi("{c}")#text(" is a ")#mi("{2}")#text("-chain in ")#mi("{U}")#text(", then ")#mi("{\\partial \\partial c = 0}")#text(".")],
[#text("(ii) Show that if ")#mi("{c}")#text(" is a ")#mi("{2}")#text("-chain in ")#mi("{U}")#text(" and ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic, then ")#mi("{\\int_{\\partial c} f = 0}")#text(".")],
[#text("(iii) If ")#mi("{c}")#text(" is a ")#mi("{1}")#text("-cycle in ")#mi("{U}")#text(", and ")#mi("{W_c(z) = 0}")#text(" for all ")#mi("{z \\in {\\bf C} \\backslash U}")#text(", show that ")#mi("{\\int_c f = 0}")#text(". (")#emph[#text("Hint:")]#text(" first perturb ")#mi("{c}")#text(" to be the union of line segments coming from a grid of some small sidelength ")#mi("{\\varepsilon}")#text(". Observe that the winding number ")#mi("{W_c(z)}")#text(" is constant whenever ")#mi("{z}")#text(" ranges in the interior of one of the squares in this grid. Then find another ")#mi("{1}")#text("-cycle ")#mi("{c^{\\prime}}")#text(" coming from summing boundaries of such squares such that ")#mi("{W_c(z) = W_{c^{\\prime}}(z)}")#text(" for all ")#mi("{z}")#text(" in the interior of grid squares. Then show that ")#mi("{\\int_{c-c^{\\prime}} f = 0}")#text(" and ")#mi("{\\int_{c^{\\prime}} f = 0}")#text(".)")],
[#text("(iv) If ")#mi("{c}")#text(" is a ")#mi("{1}")#text("-cycle, and ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" has an antiderivative, show that ")#mi("{\\int_c f = 0}")#text(".")],
[#text("(v) If ")#mi("{c = \\sum_{i=1}^n m_i [\\gamma_i]}")#text(" is a ")#mi("{1}")#text("-cycle, ")#mi("{W_c(z) = 0}")#text(" for all ")#mi("{z \\in {\\bf C} \\backslash U}")#text(", ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic, and ")#mi("{z_0}")#text(" is a point lying outside of any of the ")#mi("{\\gamma_i}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_c \\frac{f(z)}{z-z_0} = W_c( z_0) f(z_0).")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{U}")#text(" be a subset of the complex plane which is ")#link("https://en.wikipedia.org/wiki/Star_domain")[#text("star-shaped")]#text(", which means that there exists ")#mi("{z_0 \\in U}")#text(" such that for any ")#mi("{z \\in U}")#text(", the line segment ")#mi("{\\{ (1-t) z_0 + tz: t \\in [0,1]\\}}")#text(" is also contained in ")#mi("{U}")#text(". Show that every star-shaped set is simply connected.")
]

#heading(level: 1)[#strong[#text(" — 2. Consequences of Cauchy’s theorem — ")]]

#text("Now that we have Cauchy’s theorem, we use it to quickly give a large number of striking consequences. We begin with a special case of the ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_formula")[#text("Cauchy integral formula")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Cauchy integral formula, special case)")]#text(" ")#metadata(none) <tao-0071c9bc28967a5fc35e>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic, and let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(". Let ")#mi("{r>0}")#text(" be such that the closed disk ")#tao-math("{\\overline{D(z_0,r)} := \\{ z \\in {\\bf C}: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" is contained in ")#mi("{U}")#text(". Let ")#mi("{\\gamma}")#text(" be a closed curve in ")#mi("{U \\backslash \\{z_0\\}}")#text(" that is homotopic (as a closed curve, and up to reparameterisation) in ")#mi("{U \\backslash \\{z_0\\}}")#text(" to ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" in ")#mi("{U}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("f(z_0) = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz.")]]
]

#text("Here we are already taking advantage of the ability to integrate holomorphic functions (such as ")#mi("{\\frac{f(z)}{z-z_0}}")#text(", which is holomorphic on ")#mi("{U \\backslash \\{z_0\\}}")#text(") on curves ")#mi("{\\gamma}")#text(" that are not necessarily rectifiable.")

#text("Note the remarkable feature here that the value of ")#mi("{f}")#text(" at some point other than that on ")#mi("{\\gamma}")#text(" is completely determined by the value of ")#mi("{f}")#text(" on the curve ")#mi("{\\gamma}")#text(", which is a strong manifestation of the “rigid” or “global” nature of holomorphic functions. Such a formula is certainly not available in the real case (Cauchy’s theorem is technically true on the real line, but there is no analogue of the circular contours ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" available in that setting).")

#emph[#text("Proof:")]#text(" Observe that for any ")#mi("{0 < \\varepsilon < r}")#text(", the circles ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" and ")#mi("{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}}")#text(" are homotopic (as closed curves) in ")#mi("{\\overline{D(z_0,r)}}")#text(", and hence in ")#mi("{U}")#text(". Since the function ")#mi("{z \\mapsto \\frac{f(z)}{z-z_0}}")#text(" is holomorphic on ")#mi("{U \\backslash \\{z_0\\}}")#text(", we conclude from Cauchy’s theorem that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz = \\int_{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}} \\frac{f(z)}{z-z_0}\\ dz")]]

#text("As ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", there exists a finite ")#mi("{M}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{f(z)-f(z_0)}{z-z_0}\\right| \\leq M", block: true)]]

#text("for all ")#mi("{z}")#text(" in ")#mi("{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}}")#text(", and all sufficiently small ")#mi("{\\varepsilon}")#text(". The length of this circle is of course ")#mi("{2\\pi \\varepsilon}")#text(". Applying Exercise 18(v) of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration")[#text("Notes 2")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\int_{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}} \\frac{f(z)-f(z_0)}{z-z_0}\\ dz\\right| \\leq 2 \\pi \\varepsilon M.", block: true)]]

#text("On the other hand, from explicit computation (cf. Example ")#link(<tao-2c70e12b7a0646f92279>)[#text("7")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}} \\frac{1}{z-z_0}\\ dz = 2\\pi i;")]]

#text("putting all this together, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz - f(z_0)\\right| \\leq \\varepsilon M.", block: true)]]

#text("Sending ")#mi("{\\varepsilon}")#text(" to zero, we obtain the claim. ")#mi("\\Box")#linebreak()#text(" Note the same argument would give")

#align(center)[#tao-fit-display[#mitex("m f(z_0) = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz")]]

#text("if ")#mi("{\\gamma}")#text(" were homotopic to the curve ")#mi("{t \\mapsto z_0 + r e^{i m t}}")#text(": ")#mi("{0 \\leq t \\leq 2\\pi}")#text(" rather than ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(", for some integer ")#mi("{m}")#text(". In particular, if ")#mi("{\\gamma}")#text(" were homotopic to a point in ")#mi("{U \\backslash \\{z_0\\}}")#text(", then the right-hand side would vanish.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" For various explicit examples of closed contours ")#mi("{\\gamma}")#text(", it is also possible to prove the Cauchy integral formula by applying Cauchy’s theorem to various “keyhole contours”. We will not pursue this approach here, but see for instance Chapter 2 of Stein-Shakarchi.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Mean value property and Poisson kernel)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{\\overline{D(z_0,r)}}")#text(" be a closed disk contained in ")#mi("{U}")#text(".")

#list(
[#text("(i) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic, show that")

#align(center)[#tao-fit-display[#mitex("f(z_0) = \\frac{1}{2\\pi} \\int_0^{2\\pi} f(z_0 + re^{i\\theta})\\ d\\theta.")]]

#text("Use this to give an alternate proof of Exercise 26 from ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation")[#text("Notes 1")]#text(".")],
[#text("(ii) If ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" is harmonic, show that")

#align(center)[#tao-fit-display[#mitex("u(z_0) = \\frac{1}{2\\pi} \\int_0^{2\\pi} u(z_0 + re^{i\\theta})\\ d\\theta.")]]

#text("Use this to give an alternate proof of Theorem 25 from ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation")[#text("Notes 1")]#text(".")],
[#text("(iii) If ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" is harmonic, show that")

#align(center)[#tao-fit-display[#mitex("u(z) = \\frac{1}{2\\pi} \\int_0^{2\\pi} P( \\frac{z - z_0}{re^{i\\theta}} ) u(z_0 + re^{i\\theta})\\ d\\theta")]]

#text("for any ")#mi("{z \\in D(z_0,r)}")#text(", where the ")#emph[#text("Poisson kernel")]#text(" ")#mi("{P: D(0,1) \\rightarrow {\\bf R}}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("P(z) := \\mathrm{Re} \\frac{1 + z}{1-z}.")]]

#text("(")#emph[#text("Hint:")]#text(" it simplifies the calculations somewhat if one reduces to the case ")#mi("{z_0=0}")#text(", ")#mi("{r=1}")#text(", and ")#mi("{z = s}")#text(" for some ")#mi("{0 < s < 1}")#text(". Then compute the integral ")#mi("{\\frac{1}{2\\pi i} \\int_{\\gamma_{0,1,\\circlearrowleft}} f(w) \\frac{1}{2} (\\frac{1+s/w}{1-s/w} + \\frac{1+sw}{1-sw})\\ \\frac{dw}{w}}")#text(" in two different ways, where ")#mi("{f=u+iv}")#text(" is holomorphic with real part ")#mi("{u}")#text(".)")]
)
]

#text("The first important consequence of the Cauchy integral formula is the analyticity of holomorphic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 20 (Holomorphic functions are analytic)")]#text(" ")#metadata(none) <tao-e9c7f0b52df4abec57cd>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic, and let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(". Let ")#mi("{r>0}")#text(" be such that the closed disk ")#tao-math("{\\overline{D(z_0,r)} := \\{ z \\in {\\bf C}: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" is contained in ")#mi("{U}")#text(". For each natural number ")#mi("{n}")#text(", let ")#mi("{a_n}")#text(" denote the complex number ")#metadata(none) <tao-ba5f2440af29ebee271c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("a_n := \\frac{1}{2\\pi i} \\int_{\\gamma_{z_0,r,\\circlearrowleft}} \\frac{f(z)}{(z-z_0)^{n+1}}\\ dz.")]]

#text("Then the power series ")#mi("{\\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" has radius of convergence at least ")#mi("{r}")#text(", and converges to ")#mi("{f(z)}")#text(" inside the disk.")
]

#emph[#text("Proof:")]#text(" By continuity, there exists a finite ")#mi("{M}")#text(" such that ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" for all ")#mi("{z}")#text(" on the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(", which of course has length ")#mi("{2\\pi r}")#text(". From Exercise 17(v) of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration")[#text("Notes 2")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|a_n\\right| \\leq \\frac{1}{2\\pi} 2\\pi r \\frac{M}{r^{n+1}}.", block: true)]]

#text("From this and Proposition 7 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(", we see that the radius of convergence of ")#mi("{a_n}")#text(" is indeed at least ")#mi("{r}")#text(".")#linebreak()#text(" Next, for any ")#mi("{w \\in D(z_0,r)}")#text(", the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" is homotopic (as a closed curve) in ")#mi("{\\overline{D(z_0,r)} \\backslash \\{w\\}}")#text(" (and hence in ")#mi("{U \\backslash \\{w\\})}")#text(" to ")#mi("{\\gamma_{w,\\varepsilon,\\circlearrowleft}}")#text(" to ")#mi("{\\varepsilon}")#text(" small enough that ")#mi("{D(w,\\varepsilon)}")#text(" lies in ")#mi("{D(z_0,r)}")#text(". Applying the Cauchy integral formula, we conclude that")

#align(center)[#tao-fit-display[#mitex("f(w) = \\frac{1}{2\\pi i} \\int_{\\gamma_{z_0,r,\\circlearrowleft}} \\frac{f(z)}{z-w}\\ dz.")]]

#text("On the other hand, from the geometric series formula (Exercise 12 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(") one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{z-w} = \\sum_{n=0}^\\infty \\frac{1}{(z-z_0)^{n+1}} (w-z_0)^n")]]

#text("for all ")#mi("{w \\in D(z_0,r)}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("f(w) = \\frac{1}{2\\pi i} \\int_{\\gamma_{z_0,r,\\circlearrowleft}} (\\sum_{n=0}^\\infty \\frac{f(z)}{(z-z_0)^{n+1}} (w-z_0)^n)\\ dz.")]]

#text("If we could interchange the sum and integral, we would conclude from ")#link(<tao-ba5f2440af29ebee271c>)[#text("(4)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("f(w) = \\sum_{n=0}^\\infty a_n (w-z_0)^n")]]

#text("which would give the claim. To justify the interchange, we will use the ")#link("https://en.wikipedia.org/wiki/Weierstrass_M-test")[#text("Weierstrass ")#mi("{M}")#text("-test")]#text(" (the ")#link("https://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" would also work here). We have the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{f(z)}{(z-z_0)^{n+1}} (w-z_0)^n\\right| \\leq \\frac{M}{r^{n+1}} \\left|w-z_0\\right|^n;", block: true)]]

#text("by the geometric series formula and the hypothesis ")#mi("{w \\in D(z_0,r)}")#text(", the sum ")#tao-math("{\\sum_{n=0}^\\infty \\frac{M}{r^{n+1}} \\left|w-z_0\\right|^n}", block: false)#text(" is finite, and so the ")#mi("{M}")#text("-test applies and we are done. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" A function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" on an open set ")#mi("{U \\subset {\\bf C}}")#text(" is said to be ")#link("https://en.wikipedia.org/wiki/Analytic_function")[#text("complex analytic")]#text(" on ")#mi("{U}")#text(" if, for every ")#mi("{z_0 \\in U}")#text(", there is a power series ")#mi("{\\sum_{n=0}^\\infty a_n(z-z_0)^n}")#text(" with a positive radius of convergence that converges to ")#mi("{f}")#text(" on some neighbourhood of ")#mi("{z_0}")#text(". Combining the above corollary with Theorem 15 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(", we see that ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(" if and only if ")#mi("{f}")#text(" is complex analytic on ")#mi("{U}")#text("; thus the terms “complex differentiable”, “holomorphic”, and “complex analytic” may be used interchangeably. This can be contrasted with real variable case: there is a completely parallel notion of a ")#link("https://en.wikipedia.org/wiki/Analytic_function")[#text("real analytic")]#text(" function ")#mi("{f: (a,b) \\rightarrow {\\bf R}}")#text(" (i.e., a function such that, for every point ")#mi("{x_0}")#text(" in the domain, can be expanded as a convergent power series around that point in some neighbourhood of that point), and real analytic functions are automatically smooth and differentiable, but the converse is quite false.")
]

#text("Recalling (see Remark 21 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(") that power series are infinitely differentiable (in both the real and complex senses) inside their disk of convergence, and working locally in various small disks in ")#mi("{U}")#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 22")]#text(" ")#metadata(none) <tao-d95a12dfb7518ea37ed3>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function. Then ")#mi("{f^{\\prime}: U \\rightarrow {\\bf C}}")#text(" is also holomorphic, and ")#mi("{f}")#text(" is smooth (i.e. infinitely differentiable in the real sense).")
]

#text("In view of this corollary, we may now drop hypotheses of continuous first or second differentiability from several of the theorems in ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(", such as Exercise 26 from that set of notes.")

#text("Combining Corollary ")#link(<tao-d95a12dfb7518ea37ed3>)[#text("22")]#text(" with Proposition 28 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(" (with ")#mi("{{\\bf C}}")#text(" replaced by various rectangles in ")#mi("{U}")#text("), we obtain a form of ")#link("https://en.wikipedia.org/wiki/Elliptic_regularity")[#text("elliptic regularity")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 23 (Elliptic regularity)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" be a harmonic function. Then ")#mi("{u}")#text(" is smooth.")
]

#text("In fact one can even omit the hypothesis of continuous twice differentiability in the definition of harmonicity if one works with the notion of ")#link("https://en.wikipedia.org/wiki/Weakly_harmonic_function")[#text("weak harmonicity")]#text(", but this is a topic for a PDE or distribution theory course and will not be pursued further here.")

#text("Another immediate consequence of Corollary ")#link(<tao-e9c7f0b52df4abec57cd>)[#text("20")]#text(" is a version of the factor theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 24 (Factor theorem for analytic functions)")]#text(" ")#metadata(none) <tao-41a093100bbbb59e31dc>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{z_0}")#text(" be a point in ")#mi("{{\\bf C}}")#text(". Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a complex analytic function that vanishes at ")#mi("{z_0}")#text(". Then there exists a unique complex analytic function ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" such that ")#mi("{f(z) = g(z) (z-z_0)}")#text(" for all ")#mi("{z \\in U}")#text(".")
]

#emph[#text("Proof:")]#text(" For ")#mi("{z \\neq z_0}")#text(", we can simply define ")#mi("{g(z) := f(z)/(z-z_0)}")#text(", and this is clearly the unique choice here. For ")#mi("{z}")#text(" equal to or near ")#mi("{z_0}")#text(", we can expand ")#mi("{f}")#text(" as a Taylor series ")#mi("{f(z) = \\sum_{n=1}^\\infty a_n (z-z_0)^n}")#text(" (noting that the constant term vanishes since ")#mi("{f(z_0)=0}")#text(") and then set ")#mi("{g(z) := \\sum_{n=0}^\\infty a_{n+1} (z-z_0)^n}")#text(". One can check that these two definitions of ")#mi("{g}")#text(" agree on their common domain; on gluing the two definitions together, one obtains a function ")#mi("{g}")#text(" is complex differentiable (and hence analytic) on all of ")#mi("{U}")#text(" with the desired factorisation. Uniqueness at ")#mi("{z_0}")#text(" then follows from uniqueness at ")#mi("{z \\neq z_0}")#text(" and continuity. ")#mi("\\Box")

#text("Yet another consequence is the important property of ")#link("https://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 25 (Analytic continuation)")]#text(" ")#metadata(none) <tao-6710e49eebf184e7a309>#text(" Let ")#mi("{U}")#text(" be a connected non-empty open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(", ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" be complex analytic functions. If ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree on some non-empty open subset of ")#mi("{U}")#text(", then they in fact agree on all of ")#mi("{U}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{V}")#text(" denote the set of all points ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" where ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree to all orders, that is to say that")

#align(center)[#tao-fit-display[#mitex("f^{(n)}(z_0) = g^{(n)}(z_0)")]]

#text("for all ")#mi("{n=0,1,\\dots}")#text(". By hypothesis, ")#mi("{V}")#text(" is non-empty; by the continuity of the ")#mi("{f^{(n)}}")#text(", ")#mi("{V}")#text(" is closed; and from analyticity and Taylor expansion (Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(") ")#mi("{V}")#text(" is open. As ")#mi("{U}")#text(" is connected, ")#mi("{V}")#text(" must therefore be all of ")#mi("{U}")#text(", and the claim follows. (This is an example of the ")#link("http://www.tricki.org/article/Use_the_continuity_method")[#text("continuity method")]#text(" in action.) ")#mi("\\Box")#linebreak()#text(" There is also a variant of the above corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 26 (Non-trivial analytic functions have isolated zeroes)")]#text(" ")#metadata(none) <tao-1d56363ecacbaf24e8da>#text(" Let ")#mi("{U}")#text(" be a connected non-empty open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function which vanishes at some point ")#mi("{z_0 \\in {\\bf C}}")#text(" but is not identically zero. Then there exists a disk ")#mi("{D(z_0,r)}")#text(" in ")#mi("{U}")#text(" on which ")#mi("{f}")#text(" does not vanish except at ")#mi("{z_0}")#text("; in other words, all the zeroes of ")#mi("{f}")#text(" are isolated points.")
]

#emph[#text("Proof:")]#text(" If all the derivatives ")#mi("{f^{(n)}(z_0)}")#text(" of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(" vanish, then by Taylor expansion ")#mi("{f}")#text(" vanishes in some open neighbourhood of ")#mi("{z_0}")#text(", and then by Corollary ")#link(<tao-6710e49eebf184e7a309>)[#text("25")]#text(" ")#mi("{f}")#text(" vanishes everywhere, a contradiction. Thus at least one of the ")#mi("{f^{(n)}(z_0)}")#text(" is non-zero. If ")#mi("{n_0}")#text(" is the first natural number for which ")#mi("{f^{(n_0)}(z_0) \\neq 0}")#text(", then by iterating the factor theorem (Corollary ")#link(<tao-41a093100bbbb59e31dc>)[#text("24")]#text(") we see that ")#mi("{f(z) = (z-z_0)^{n_0} g(z)}")#text(" for some analytic function ")#mi("{g:U \\rightarrow {\\bf C}}")#text(" which is non-vanishing at ")#mi("{z_0}")#text(". By continuity, ")#mi("{g}")#text(" is also non-vanishing in some disk ")#mi("{D(z_0,r)}")#text(" in ")#mi("{U}")#text(", and the claim follows. ")#mi("\\Box")

#text("One particular consequence of the above corollary is that if two entire functions ")#mi("{f,g}")#text(" agree on the real line (or even on an infinite bounded subset of the complex plane), then they must agree everywhere, since otherwise ")#mi("{f-g}")#text(" would have a non-isolated zero, contradicting Corollary ")#link(<tao-1d56363ecacbaf24e8da>)[#text("26")]#text(". This strengthens Corollary ")#link(<tao-6710e49eebf184e7a309>)[#text("25")]#text(", and helps explain why real-variable identities such as ")#mi("{\\sin^2(x)+\\cos^2(x)=1}")#text(" automatically extend to their complex counterparts ")#mi("{\\sin^2(z) + \\cos^2(z) = 1}")#text(". Another consequence is that if an entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is real-valued on the real axis, then one has the identity")

#align(center)[#tao-fit-display[#mitex("f(z) = \\overline{f(\\overline{z})}")]]

#text("for all complex ")#mi("{z}")#text(", because this identity already holds on the real line, and both sides are complex analytic. Thus for instance")

#align(center)[#tao-fit-display[#mitex("\\sin(z) = \\overline{\\sin(\\overline{z})}.")]]

#text("Next, if we combine Corollary ")#link(<tao-e9c7f0b52df4abec57cd>)[#text("20")]#text(" with Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(", as well as Cauchy’s theorem, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Higher order Cauchy integral formula, special case)")]#text(" ")#metadata(none) <tao-eccc46602da5922329e3>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic, and let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(". Let ")#mi("{r>0}")#text(" be such that the closed disk ")#tao-math("{\\overline{D(z_0,r)} := \\{ z \\in {\\bf C}: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" is contained in ")#mi("{U}")#text(". Let ")#mi("{\\gamma}")#text(" be a closed curve in ")#mi("{U \\backslash \\{z_0\\}}")#text(" that is homotopic (as a closed curve, up to reparameterisation) in ")#mi("{U \\backslash \\{z_0\\}}")#text(" to ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" in ")#mi("{U}")#text(". Then for any natural number ")#mi("{n}")#text(", the ")#mi("{n^{\\mathrm{th}}}")#text(" derivative ")#mi("{f^{(n)}(z_0)}")#text(" of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("f^{(n)}(z_0) = \\frac{n!}{2\\pi i} \\int_\\gamma \\frac{f(z)}{(z-z_0)^{n+1}}\\ dz.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Give an alternate proof of Theorem ")#link(<tao-eccc46602da5922329e3>)[#text("27")]#text(" by rigorously differentiating the Cauchy integral formula with respect to the ")#mi("{z_0}")#text(" parameter.")
]

#text("Combining Theorem ")#link(<tao-eccc46602da5922329e3>)[#text("27")]#text(" with Exercise 17(v) of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(", we obtain a more quantitative form of Corollary ")#link(<tao-d95a12dfb7518ea37ed3>)[#text("22")]#text(", which asserts not only that the higher derivatives of a holomorphic function exist, but also places a bound on them:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 29 (Cauchy inequalities)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic, and let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(". Let ")#mi("{r>0}")#text(" be such that the closed disk ")#tao-math("{\\overline{D(z_0,r)} := \\{ z \\in {\\bf C}: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" is contained in ")#mi("{U}")#text(". Suppose that there is an ")#mi("{M}")#text(" such that ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" on the circle ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z-z_0\\right| = r\\}}", block: false)#text(". Then for any natural number ")#mi("{n}")#text(", we have ")#metadata(none) <tao-6620583806083e48f88d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|f^{(n)}(z_0)\\right| \\leq \\frac{n!}{r^n} M.", block: true)]]
]

#text("Note that the ")#mi("{n=0}")#text(" case of this corollary is compatible with the maximum principle (Exercise 26 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(").")

#text("The right-hand side of ")#link(<tao-6620583806083e48f88d>)[#text("(5)")]#text(" has a denominator ")#mi("{r^n}")#text(" that improves when ")#mi("{r}")#text(" gets large. In particular we have the remarkable ")#link("https://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("theorem of Liouville")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 30 (Liouville’s theorem)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be an entire function that is bounded. Then ")#mi("{f}")#text(" is constant.")
]

#emph[#text("Proof:")]#text(" By hypothesis, there is a finite ")#mi("{M}")#text(" such that ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" for all ")#mi("{M}")#text(". Applying the Cauchy inequalities with ")#mi("{n=1}")#text(" and any disk ")#mi("{D(z_0,r)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{\\prime}(z_0)\\right| \\leq \\frac{M}{r}", block: true)]]

#text("for any ")#mi("{z_0 \\in {\\bf C}}")#text(" and ")#mi("{r>0}")#text(". Sending ")#mi("{r}")#text(" to infinity, we conclude that ")#mi("{f^{\\prime}}")#text(" vanishes identically. The claim then follows from the fundamental theorem of calculus. ")#mi("\\Box")#linebreak()#text(" This theorem displays a strong “rigidity” property for entire functions; if such a function is even vaguely close to being constant (by being bounded), then it almost magically “snaps into place” and actually is forced to be a constant! This is in stark contrast to the real case, in which there are functions such as ")#mi("{\\sin(x)}")#text(" that are differentiable (and even smooth and analytic) on the real line and bounded, but definitely not constant. Note that the complex analogue ")#mi("{\\sin(z)}")#text(" of the sine function is not a counterexample to Liouville’s theorem, since ")#mi("{\\sin(z)}")#text(" becomes quite unbounded away from the real axis (Exercise 16 of ")#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("Notes 0")]#text("). This also fits well with the intuition of harmonic functions (and hence also holomorphic functions) being “balanced” in that any convexity in one direction has to be balanced by concavity in the orthogonal direction, and vice versa (as discussed before Theorem 25 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text("): any attempt to create an entire function that is bounded and oscillating in one direction will naturally force that function to become unbounded in the orthogonal direction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be an entire function which is of ")#emph[#text("polynomial growth")]#text(" in the sense that there exists a finite quantity ")#mi("{M>0}")#text(" and some exponent ")#mi("{A \\geq 0}")#text(" such that ")#tao-math("{\\left|f(z)\\right| \\leq M (1+\\left|z\\right|)^A}", block: false)#text(" for all ")#mi("{z \\in {\\bf C}}")#text(". Show that ")#mi("{f}")#text(" is, in fact, a polynomial.")
]

#text("Now we can prove the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(" discussed back in ")#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("Notes 0")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Fundamental theorem of algebra)")]#text(" ")#metadata(none) <tao-3097e26b7f3cbdb92076>#text(" Let")

#align(center)[#tao-fit-display[#mitex("P(z) = a_n z^n + \\dots + a_0")]]

#text("be a polynomial of degree ")#mi("{n \\geq 0}")#text(" for some ")#mi("{a_0,\\dots,a_n \\in {\\bf C}}")#text(" with ")#mi("{a_n}")#text(" non-zero. Then there exist complex numbers ")#mi("{z_1,\\dots,z_n}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("P(z) = a_n (z-z_1) \\dots (z-z_n).")]]
]

#emph[#text("Proof:")]#text(" This is trivial for ")#mi("{n=0,1}")#text(", so suppose inductively that ")#mi("{n \\geq 2}")#text(" and the claim has already been proven for ")#mi("{n-1}")#text(". Suppose first that the equation ")#mi("{P(z)=0}")#text(" has no roots in the complex plane, then the function ")#mi("{1/P(z)}")#text(" is entire. Also, this function goes to zero as ")#tao-math("{\\left|z\\right| \\rightarrow \\infty}", block: false)#text(", and so is bounded on the exterior of any sufficiently large disk; as it is also continuous, it is bounded on any disk and is thus bounded everywhere. By Liouville’s theorem, ")#mi("{1/P(z)}")#text(" is constant, which implies that ")#mi("{P(z)}")#text(" is constant, which is absurd (for instance, the ")#mi("{n^{\\mathrm{th}}}")#text(" derivative of ")#mi("{P}")#text(" is the non-zero function ")#mi("{n! a_n}")#text("). Hence ")#mi("{P(z)}")#text(" has at least one root ")#mi("{z_n}")#text(". By the ")#link("https://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" (which works in any field, including the complex numbers) we can then write ")#mi("{P(z) = Q(z) (z-z_n)}")#text(" for some polynomial ")#mi("{Q(z)}")#text(", which by the long division algorithm (or by comparing coefficients) must take the form")

#align(center)[#tao-fit-display[#mitex("Q(z) = a_n z^{n-1} + b_{n-2} z^{n-2} + \\dots + b_0")]]

#text("for some complex numbers ")#mi("{b_0,\\dots,b_{n-2}}")#text(". The claim then follows from the induction hypothesis. ")#mi("\\Box")#linebreak()#text(" The following exercises show that ")#mi("{{\\bf C}}")#text(" can be alternatively defined as an algebraic closure of the reals ")#mi("{{\\bf R}}")#text(" (together with a designated square root ")#mi("{i}")#text(" of ")#mi("{-1}")#text("), and that extending ")#mi("{{\\bf R}}")#text(" using a different irreducible polynomial than ")#mi("{x^2+1}")#text(" would still give a field isomorphic to the complex numbers, thus supporting the notion that the complex numbers are not an arbitrary extension of the reals, but rather a quite natural and canonical one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{k}")#text(" be a field containing ")#mi("{{\\bf R}}")#text(" which is a ")#link("https://en.wikipedia.org/wiki/Field_extension")[#text("finite extension")]#text(" of ")#mi("{{\\bf R}}")#text(", in the sense that ")#mi("{k}")#text(" is a finite-dimensional vector space over ")#mi("{{\\bf R}}")#text(". Show that ")#mi("{k}")#text(" is isomorphic (as a field) to either ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{\\alpha}")#text(" is some element of ")#mi("{k}")#text(" not in ")#mi("{{\\bf R}}")#text(", show that ")#mi("{P(\\alpha)=0}")#text(" for some irreducible polynomial ")#mi("{P}")#text(" with real coefficients but no real roots. Use this to set up an isomorphism between the field ")#mi("{\\tilde k}")#text(" generated by ")#mi("{{\\bf R}}")#text(" and ")#mi("{\\alpha}")#text(" with ")#mi("{{\\bf C}}")#text(". If there is an element ")#mi("{\\beta}")#text(" of ")#mi("{k}")#text(" not in this field ")#mi("{\\tilde k}")#text(", show that there ")#mi("{Q(\\beta)=0}")#text(" for some irreducible polynomial ")#mi("{Q}")#text(" with coefficients in ")#mi("{\\tilde k}")#text(" and no roots in ")#mi("{\\tilde k}")#text(", and contradict the fundamental theorem of algebra.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" A field ")#mi("{k}")#text(" is said to be ")#link("https://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed")]#text(" if the conclusion of Theorem ")#link(<tao-3097e26b7f3cbdb92076>)[#text("32")]#text(" with ")#mi("{{\\bf C}}")#text(" replaced by ")#mi("{k}")#text(". Show that any algebraically closed field ")#mi("{k}")#text(" containing ")#mi("{{\\bf R}}")#text(", contains a subfield that is isomorphic to ")#mi("{{\\bf C}}")#text(" (and which contains ")#mi("{{\\bf R}}")#text(" as a subfield, isomorphic to the copy of ")#mi("{{\\bf R}}")#text(" inside ")#mi("{{\\bf C}}")#text("). Thus, up to isomorphism, ")#mi("{{\\bf C}}")#text(" is the unique ")#link("https://en.wikipedia.org/wiki/Algebraic_closure")[#text("algebraic closure")]#text(" of ")#mi("{{\\bf R}}")#text(", that is to say a minimal algebraically closed field containing ")#mi("{{\\bf R}}")#text(".")
]

#text("Another nice consequence of the Cauchy integral formula is a converse to Cauchy’s theorem known as ")#link("https://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 35 (Morera’s theorem)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a continuous function. Suppose that ")#mi("{f}")#text(" is conservative in the sense that ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for any closed triangular path in ")#mi("{U}")#text(". Then ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(".")
]

#emph[#text("Proof:")]#text(" By working locally with small disks in ")#mi("{U}")#text(" we may assume that ")#mi("{U}")#text(" is a disk (and in particular connected). Using the argument in the proof of Corollary 11, we may replace triangles with polygonal paths. By Exercise 33 of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(", ")#mi("{f}")#text(" has an antiderivative ")#mi("{F: U \\rightarrow {\\bf R}}")#text(". By definition, ")#mi("{F}")#text(" is complex differentiable at every point of ")#mi("{U}")#text(" (with derivative ")#mi("{f}")#text("), so by Corollary ")#link(<tao-d95a12dfb7518ea37ed3>)[#text("22")]#text(", ")#mi("{F}")#text(" is smooth, which implies in particular that ")#mi("{F^{\\prime} = f}")#text(" is holomorphic on ")#mi("{U}")#text(" as claimed. ")#mi("\\Box")

#text("The power of Morera’s theorem comes from the fact that there are no differentiability requirements in the hypotheses on ")#mi("{f}")#text(", and yet the conclusion is that ")#mi("{f}")#text(" is differentiable (and hence smooth, by Corollary ")#link(<tao-d95a12dfb7518ea37ed3>)[#text("22")]#text("); it can be viewed as another manifestation of “elliptic regularity”. Here is one basic application of Morera’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 36 (Uniform limit of holomorphic functions is holomorphic)")]#text(" ")#metadata(none) <tao-4b5a3684173ae7931c18>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f_n: U \\rightarrow {\\bf C}}")#text(" be a sequence of holomorphic functions that converge ")#link("https://en.wikipedia.org/wiki/Compact_convergence")[#text("uniformly on compact sets")]#text(" to a limit ")#mi("{f: U \\rightarrow {\\bf C}}")#text(". Then ")#mi("{f}")#text(" is also holomorphic. Furthermore, for any natural number ")#mi("{k}")#text(", the derivatives ")#mi("{f_n^{(k)}: U \\rightarrow {\\bf C}}")#text(" also converge uniformly on compact sets to ")#mi("{f^{(k)}: U \\rightarrow {\\bf C}}")#text(". (In particular, ")#mi("{f_n^{(k)}}")#text(" converges pointwise to ")#mi("{f^{(k)}}")#text(" on ")#mi("{U}")#text(".)")
]

#emph[#text("Proof:")]#text(" Again we may work locally and assume that ")#mi("{U}")#text(" is a disk (and in partiular is convex and simply connected). The ")#mi("{f_n}")#text(" are continuous, hence their locally uniform limit ")#mi("{f}")#text(" is also continuous. From Corollary ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("11")]#text(" (or Corollary ")#link(<tao-c62471c786fca94e9237>)[#text("14")]#text("), we have ")#mi("{\\int_\\gamma f_n(z)\\ dz = 0}")#text(" on any closed polygonal path in ")#mi("{U}")#text(", hence on taking locally uniform limits we also have ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for such paths. The holomorphicity of ")#mi("{f}")#text(" then follows from Morera’s theorem. The uniform convergence of ")#mi("{f_n^{(k)}}")#text(" to ")#mi("{f^{(k)}}")#text(" on compact sets ")#mi("{K}")#text(" follows from applying Theorem ")#link(<tao-eccc46602da5922329e3>)[#text("27")]#text(" to circular contours ")#mi("{\\gamma_{z_0,\\varepsilon,\\circlearrowleft}}")#text(" for ")#mi("{z_0 \\in K}")#text(" and ")#mi("{\\varepsilon>0}")#text(" small enough that these contours lie in ")#mi("{U}")#text(" (note from compactness that one can take ")#mi("{\\varepsilon}")#text(" independent of ")#mi("{z_0}")#text("). ")#mi("\\Box")

#text("Actually, one can weaken the uniform nature of the convergence in Theorem ")#link(<tao-4b5a3684173ae7931c18>)[#text("36")]#text(" substantially; even the ")#link("https://en.wikipedia.org/wiki/Weak_topology")[#text("weak limit")]#text(" of holomorphic functions in the space of locally integrable functions on ")#mi("{U}")#text(" will remain harmonic. However, we will not need these weaker versions of this theorem here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Riemann’s theorem on removable singularities)")]#text(" ")#metadata(none) <tao-e65e0af34a185a0d0c82>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(", and let ")#mi("{f: U \\backslash \\{z_0\\} \\rightarrow {\\bf C}}")#text(" be a holomorphic function on ")#mi("{U \\backslash \\{z_0\\}}")#text(" which is bounded near ")#mi("{z_0}")#text(", in the sense that it is bounded on some punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(" contained in ")#mi("{U}")#text(". Show that ")#mi("{f}")#text(" has a ")#link("https://en.wikipedia.org/wiki/Removable_singularity")[#text("removable singularity")]#text(" at ")#mi("{z_0}")#text(", in the sense that ")#mi("{f}")#text(" is the restriction to ")#mi("{U \\backslash \\{z_0\\}}")#text(" of a holomorphic function ")#mi("{\\tilde f: U \\rightarrow {\\bf C}}")#text(" on ")#mi("{U}")#text(". (")#emph[#text("Hint:")]#text(" show that ")#mi("{f}")#text(" is conservative near ")#mi("{z_0}")#text(", find an antiderivative, extend it to ")#mi("{U}")#text(", and use Morera’s theorem to show that this extension is holomorphic. Alternatively, one can also proceed by some version of the Cauchy integral formula.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38 (Integrals of holomorphic functions)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: [0,1] \\times U \\rightarrow {\\bf C}}")#text(" be a continuous function such that, for each ")#mi("{t \\in [0,1]}")#text(", the function ")#mi("{z \\mapsto f(t,z)}")#text(" is holomorphic on ")#mi("{U}")#text(". Show that the function ")#mi("{z \\mapsto \\int_0^1 f(t,z)\\ dt}")#text(" is also holomorphic on ")#mi("{U}")#text(". (")#emph[#text("Hint:")]#text(" work locally and use Cauchy’s theorem, Morera’s theorem, and Fubini’s theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39 (Schwarz reflection principle)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(" that is symmetric around the real axis, that is to say ")#mi("{\\overline{z} \\in U}")#text(" whenever ")#mi("{z \\in U}")#text(". Let ")#mi("{f_+: \\overline{U_+} \\rightarrow {\\bf C}}")#text(" be a continuous function on the set ")#mi("{\\overline{U_+} := \\{ z \\in U: \\mathrm{Im}(z) \\geq 0\\}}")#text(" that is holomorphic in the open subset ")#mi("{U_+ := \\{ z \\in U: \\mathrm{Im}(z) > 0 \\}}")#text(".")

#list(
[#text("(i) Suppose that ")#mi("{f_-: \\overline{U_-} \\rightarrow {\\bf C}}")#text(" be continuous on ")#mi("{\\overline{U_-} := \\{ z \\in U: \\mathrm{Im}(z) \\leq 0\\}}")#text(" that is holomorphic in the open subset ")#mi("{U_- := \\{ z \\in U: \\mathrm{Im}(z) < 0 \\}}")#text(". Suppose further that ")#mi("{f_+}")#text(" and ")#mi("{f_-}")#text(" agree on ")#mi("{U \\cap {\\bf R}}")#text(". Show that ")#mi("{f_+}")#text(" and ")#mi("{f_-}")#text(" are both restrictions of a single holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(".")],
[#text("(ii) Suppose instead that ")#mi("{f_+}")#text(" is real-valued on ")#mi("{U \\cap {\\bf R}}")#text(" (i.e., ")#mi("{f_+(x) \\in {\\bf R}}")#text(" whenever ")#mi("{x \\in U \\cap {\\bf R}}")#text(". Show that ")#mi("{f_+}")#text(" is the restriction of a holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(", which obeys the additional property ")#mi("{f(\\overline{z}) = \\overline{f(z)}}")#text(" for all ")#mi("{z \\in U}")#text(".")]
)

#text("Informally, part (ii) of this theorem asserts that one can always reflect the domain of holomorphicity of a function across a line segment on the boundary of that domain, so long as the function is continuous up to that boundary and becomes real-valued in the limit. This is the most common form of the ")#link("https://en.wikipedia.org/wiki/Schwarz_reflection_principle")[#text("Schwarz reflection principle")]#text(".")
]

#text("The following two Venn diagrams (or more precisely, ")#link("https://en.wikipedia.org/wiki/Euler_diagram")[#text("Euler diagrams")]#text(") summarise the relationships between different types of regularity amongst continuous functions over both the reals and the complexes. The first diagram")

#align(center)[#image("../assets/3cb41fad250f1e59b0fbe69a8edafe452f1112ff451c603b0ad2bec700f9770c-ce46a83837e24c5560dc6033cd4ebf0d05e8edd52b40bac0c031e389daeae9b8.png", width: 90%, alt: "realreg")]

#text("describes the class of continuous functions on some interval ")#mi("{(a,b)}")#text(" in the real line; such functions are automatically conservative, but not necessarily differentiable, while differentiable functions are not necessarily smooth, and smooth functions are not necessarily analytic. On the other hand, when considering the class of continuous functions on an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(", the picture is different:")

#align(center)[#image("../assets/db6976df5b8a12833f0fba6ffa93057bdda8fc965ff7c5f8f2a9b3c7be99b554-abeab4c3227e0ba5fce24f3c2e92189ada0b1d471ca09443f7f9fd62c5039245.png", width: 90%, alt: "complexreg")]

#text("Now, very few continuous functions are conservative, and only slightly more functions are complex differentiable (and for simply connected domains ")#mi("{U}")#text(", these two classes in fact coincide). Whereas in the real case, differentiable functions were considerably less regular than analytic functions, in the complex case the two classes in fact coincide.")

#heading(level: 1)[#strong[#text(" — 3. Winding number — ")]]

#text("One defect of the current formulation of the Cauchy integral formula (see Theorem ")#link(<tao-0071c9bc28967a5fc35e>)[#text("17")]#text(" and the ensuing discussion) is that the curve ")#mi("{\\gamma}")#text(" involved has to be homotopic (as a closed curve, up to reparameterisation) to a circular arc ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(", or at least to a curve of the form ")#mi("{t \\mapsto z_0 + re^{imt}}")#text(", ")#mi("{t \\in [0,2\\pi]}")#text(" for some integer ")#mi("{m}")#text(". We now investigate what happens when this hypothesis is removed. A key notion is that of a ")#emph[#text("winding number")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 40 (Winding number)")]#text(" Let ")#mi("{\\gamma}")#text(" be a closed curve, and let ")#mi("{z_0}")#text(" be a complex number that is not in the image of ")#mi("{\\gamma}")#text(". The ")#link("https://en.wikipedia.org/wiki/Winding_number")[#text("winding number")]#text(" ")#mi("{W_\\gamma(z_0)}")#text(" of ")#mi("{\\gamma}")#text(" around ")#mi("{z_0}")#text(" is defined by the integral ")#metadata(none) <tao-6e75f2b67fc2de6283a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("W_\\gamma(z_0) := \\frac{1}{2\\pi i} \\int_\\gamma \\frac{dz}{z-z_0}.")]]
]

#text("Here we again take advantage of the ability to integrate holomorphic functions on curves that are not necessarily rectifiable. Clearly the winding number is unchanged if we replace ")#mi("{\\gamma}")#text(" by any equivalent curve, and if one replaces the curve ")#mi("{\\gamma}")#text(" with its reversal ")#mi("{-\\gamma}")#text(", then the winding number is similarly negated. In some texts, the winding number is also referred to as the ")#emph[#text("index")]#text(" or ")#emph[#text("degree")]#text(".")

#text("From the Cauchy integral formula we see that")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma}(z_0) = 1")]]

#text("when ")#mi("{\\gamma}")#text(" is homotopic in ")#mi("{{\\bf C} \\backslash \\{z_0\\}}")#text(" (as a closed curve, up to reparameterisation) to a circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(", and more generally that")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma}(z_0) = m")]]

#text("if ")#mi("{\\gamma}")#text(" is homotopic in ")#mi("{{\\bf C} \\backslash \\{z_0\\}}")#text(" (as a closed curve, up to reparameterisation) to a curve of the form ")#mi("{t \\mapsto z_0 + r e^{imt}}")#text(", ")#mi("{t \\in [0,2\\pi]}")#text(". Thus we see, intuitively at least, that ")#mi("{W_\\gamma(z_0)}")#text(" measures the number of times ")#mi("{\\gamma}")#text(" winds counterclockwise about ")#mi("{z_0}")#text(", which explains the term “winding number”.")#linebreak()#text(" We can now state a more general form of the Cauchy integral formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 41 (General Cauchy integral formula)")]#text(" ")#metadata(none) <tao-d13560794489b151e3f3>#text(" Let ")#mi("{U}")#text(" be a simply connected subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{\\gamma}")#text(" be a closed curve in ")#mi("{U}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be holomorphic. Then for any ")#mi("{z_0}")#text(" that lies in ")#mi("{U}")#text(" but not in the image of ")#mi("{\\gamma}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz = W_\\gamma(z_0) f(z_0).")]]
]

#emph[#text("Proof:")]#text(" By Corollary ")#link(<tao-41a093100bbbb59e31dc>)[#text("24")]#text(" (or Exercise ")#link(<tao-e65e0af34a185a0d0c82>)[#text("37")]#text("), we have ")#mi("{f(z) - f(z_0) = (z-z_0) g(z)}")#text(" for some holomorphic function ")#mi("{g: U \\rightarrow {\\bf C}}")#text(". Hence by Theorem ")#link(<tao-c62471c786fca94e9237>)[#text("14")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{f(z)-f(z_0)}{z-z_0}\\ dz = \\int_\\gamma g(z)\\ dz = 0.")]]

#text("The claim then follows from ")#link(<tao-6e75f2b67fc2de6283a3>)[#text("(6)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Higher order general Cauchy integral formula)")]#text(" With ")#mi("{U, \\gamma, f, z_0}")#text(" as in the above theorem, show that")

#align(center)[#tao-fit-display[#mitex("W_\\gamma(z_0) f^{(n)}(z_0) = \\frac{n!}{2\\pi i} \\int_\\gamma \\frac{f(z)}{(z-z_0)^{n+1}}\\ dz")]]

#text("for every natural number ")#mi("{n}")#text(". (")#emph[#text("Hint:")]#text(" instead of approximating ")#mi("{f(z)}")#text(" by ")#mi("{f(z_0)}")#text(", use a partial Taylor expansion of ")#mi("{f}")#text(". Many of the terms that arise can be handled using the fundamental theorem of calculus. Alternatively, one can use differentiation under the integral sign and Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" below.)")
]

#text("To use Theorem ")#link(<tao-d13560794489b151e3f3>)[#text("41")]#text(", it becomes of interest to obtain more properties on the winding number. From Cauchy’s theorem we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 43 (Homotopy invariance)")]#text(" ")#metadata(none) <tao-6781926820c2f76cf25d>#text(" Let ")#mi("{z_0 \\in {\\bf C}}")#text(", and let ")#mi("{\\gamma_0, \\gamma_1}")#text(" be two closed curves in ")#mi("{{\\bf C} \\backslash \\{z_0\\}}")#text(" that are homotopic as closed curves up to reparameterisation in ")#mi("{{\\bf C} \\backslash \\{z_0\\}}")#text(". Then ")#mi("{W_{\\gamma_0}(z_0) = W_{\\gamma_1}(z_0)}")#text(".")
]

#text("The following specific corollary of this lemma will be useful for us.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 44 (Rouche’s theorem for winding number)")]#text(" ")#metadata(none) <tao-e6080ed95475051054b6>#text(" Let ")#mi("{\\gamma_0: [a,b] \\rightarrow {\\bf C}}")#text(" be a closed curve, and let ")#mi("{z_0}")#text(" lie outside of the image of ")#mi("{\\gamma_0}")#text(". Let ")#mi("{\\gamma_1: [a,b] \\rightarrow {\\bf C}}")#text(" be a closed curve such that ")#metadata(none) <tao-7817bb812e82168bd48f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\gamma_1(t) -\\gamma_0(t)\\right| < \\left|\\gamma_0(t) - z_0\\right|", block: true)]]

#text("for all ")#mi("{t \\in [a,b]}")#text(". Then ")#mi("{W_{\\gamma_0}(z_0) = W_{\\gamma}(z_0)}")#text(".")
]

#emph[#text("Proof:")]#text(" The map ")#mi("{\\gamma: [0,1] \\times [a,b] \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{\\gamma(s,t) := (1-s) \\gamma_0(t) + s \\gamma_1(t)}")#text(" is a homotopy from ")#mi("{\\gamma_0}")#text(" to ")#mi("{\\gamma_1}")#text("; by ")#link(<tao-7817bb812e82168bd48f>)[#text("(7)")]#text(" and the triangle inequality, it avoids ")#mi("{z_0}")#text(". The claim then follows from Lemma ")#link(<tao-6781926820c2f76cf25d>)[#text("43")]#text(". ")#mi("\\Box")

#text("Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" can be used to compute the winding number near infinity as follows. Given a curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" and a point ")#mi("{z_0}")#text(", define the ")#emph[#text("distance")]

#align(center)[#tao-fit-display[#tao-math("\\mathrm{dist}(z_0,\\gamma) := \\inf_{t \\in [a,b]} \\left|z_0-\\gamma(t)\\right|", block: true)]]

#text("and the ")#emph[#text("diameter")]

#align(center)[#tao-fit-display[#tao-math("\\mathrm{diam}(\\gamma) := \\sup \\left|\\gamma(t) - \\gamma(t^{\\prime})\\right|.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 45 (Vanishing near infinity)")]#text(" ")#metadata(none) <tao-970b1897af0abab6127d>#text(" Let ")#mi("{\\gamma}")#text(" be a closed curve. Then ")#mi("{W_\\gamma(z_0) = 0}")#text(" whenever ")#mi("{z_0 \\in {\\bf C}}")#text(" is such that ")#mi("{\\mathrm{dist}(z_0,\\gamma) > \\mathrm{diam}(\\gamma)}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" with ")#mi("{\\gamma_0}")#text(" equal to ")#mi("{\\gamma}")#text(" and ")#mi("{\\gamma_1}")#text(" equal to any point in the image of ")#mi("{\\gamma_0}")#text(". ")#mi("\\Box")

#text("Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" also gives local constancy of the winding number:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 46 (Local constancy in ")#mi("{z_0}")#text(")")]#text(" ")#metadata(none) <tao-1dd5da5ec5d973decd53>#text(" Let ")#mi("{\\gamma}")#text(" be a closed curve. Then ")#mi("{W_\\gamma}")#text(" is locally constant. That is to say, if ")#mi("{z_0}")#text(" does not lie in the image of ")#mi("{\\gamma}")#text(", then there exists a disk ")#mi("{D(z_0,r)}")#text(" outside of the image of ")#mi("{\\gamma}")#text(" such that ")#mi("{W_\\gamma(z) = W_\\gamma(z_0)}")#text(" for all ")#mi("{z \\in D(z_0,r)}")#text(".")
]

#emph[#text("Proof:")]#text(" From Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(", we see that if ")#mi("{r}")#text(" is small enough and ")#mi("{h \\in D(0,r)}")#text(", then")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma-h}(z_0) = W_\\gamma(z_0),")]]

#text("where ")#mi("{\\gamma-h: t \\mapsto \\gamma(t)-h}")#text(" is the translation of ")#mi("{\\gamma}")#text(" by ")#mi("{h}")#text(". But by a translation change of variables we see that")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma-h}(z_0) = W_\\gamma(z_0+h)")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" Give an alternate proof of Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" based on differentiation under the integral sign and using the fact that ")#mi("{\\frac{1}{(z-z_0)^2}}")#text(" has an antiderivative away from ")#mi("{z_0}")#text(".")
]

#text("As confirmation of the interpretation of ")#mi("{W_\\gamma(z_0)}")#text(" as a winding number, we can now establish integrality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 48 (Integrality)")]#text(" ")#metadata(none) <tao-b38222d243e636f95235>#text(" Let ")#mi("{\\gamma}")#text(" be a closed curve, and let ")#mi("{z_0}")#text(" lie outside of the image of ")#mi("{\\gamma}")#text(". Then ")#mi("{W_\\gamma(z_0)}")#text(" is an integer.")
]

#emph[#text("Proof:")]#text(" By Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" we may assume without loss of generality that ")#mi("{\\gamma}")#text(" is a closed polygonal path. By partitioning a polygon into triangles (and using Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" to move ")#mi("{z_0}")#text(" slightly out of the way of any new edges formed by this partition) it suffices to verify this for triangular ")#mi("{\\gamma}")#text(". But this follows from the Cauchy integral formula (if ")#mi("{z_0}")#text(" is in the interior of the triangle) or Cauchy’s theorem (if ")#mi("{z_0}")#text(" is in the exterior). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" Give another proof of Lemma ")#link(<tao-b38222d243e636f95235>)[#text("48")]#text(" by restricting again to closed polygonal paths ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(", and showing that the function ")#mi("{t \\mapsto \\exp( \\int_a^t \\frac{\\gamma^{\\prime}(s)}{\\gamma(s)-z_0}\\ ds ) / (\\gamma(t) - z_0)}")#text(" is constant on ")#mi("{[a,b]}")#text(" by establishing that it is continuous and has vanishing derivative at all but finitely many points. (Note that ")#mi("{\\gamma^{\\prime}(s)}")#text(" exists for all but finitely many ")#mi("{s}")#text(", so the integral here can be well defined.)")
]

#text("We now come to a fundamental and well known theorem about simple closed curves, namely the ")#link("https://en.wikipedia.org/wiki/Jordan_curve_theorem")[#text("Jordan curve theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 50 (Jordan curve theorem)")]#text(" ")#metadata(none) <tao-136c67657614311f3223>#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a non-trivial simple closed curve. Then there is an ")#emph[#text("orientation")]#text(" ")#mi("{\\sigma \\in \\{-1,+1\\}}")#text(" such that the complex plane ")#mi("{{\\bf C}}")#text(" is partitioned into the ")#emph[#text("boundary region")]#text(" ")#mi("{\\gamma([a,b])}")#text(", the ")#emph[#text("exterior region")]#text(" ")#metadata(none) <tao-a123a777ca1a5b437abf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\{ z_0 \\not \\in \\gamma([a,b]): W_\\gamma(z_0) = 0 \\},")]]

#text("and the ")#emph[#text("interior region")]#text(" ")#metadata(none) <tao-6b6b85aed8adda90f7a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\{ z_0 \\not \\in \\gamma([a,b]): W_\\gamma(z_0) = \\sigma \\}.")]]

#text("Furthermore:")

#list(
[#text("(i) The exterior region is connected and unbounded.")],
[#text("(ii) The interior region is connected, non-empty and bounded.")],
[#text("(iii) If ")#mi("{U}")#text(" is any open set that contains ")#mi("{\\gamma}")#text(" and its interior, then ")#mi("{\\gamma}")#text(" is contractible to a point in ")#mi("{U}")#text(".")],
[#text("(iv) The boundary of both the interior region and the exterior region is equal to the image of ")#mi("{\\gamma}")#text(".")]
)
]

#text("This theorem is relatively easy to prove for “nice” curves, such as polygons, but is surprisingly delicate to prove in general. Some idea of the subtlety involved can be seen by considering pathological examples such as the ")#link("https://en.wikipedia.org/wiki/Lakes_of_Wada")[#text("lakes of Wada")]#text(", which are three disjoint open connected subsets of ")#mi("{{\\bf C}}")#text(" which all happen to have exactly the same boundary! This does not contradict the Jordan curve theorem, because the boundary set in this example is not given by a simple closed curve. However it does indicate that one has to carefully use the hypothesis of being a simple closed curve in order to prove Theorem ")#link(<tao-136c67657614311f3223>)[#text("50")]#text(". Another indication of the difficulty of the theorem is its global nature; the claim does not hold if one replaces the complex plane ")#mi("{{\\bf C}}")#text(" by other surfaces such as the torus, the ")#link("https://en.wikipedia.org/wiki/Projective_plane")[#text("projective plane")]#text(", or the ")#link("https://en.wikipedia.org/wiki/Klein_bottle")[#text("Klein bottle")]#text(", so the global topological structure of the complex plane must come into play at some point. For the sake of completeness, we give a proof of this theorem in an appendix to these notes.")

#text("If the quantity ")#mi("{\\sigma}")#text(" in the above theorem is equal to ")#mi("{+1}")#text(", we say that the simple closed curve ")#mi("{\\gamma}")#text(" has an ")#emph[#text("anticlockwise orientation")]#text("; if instead ")#mi("{\\sigma=-1}")#text(" we say that ")#mi("{\\gamma}")#text(" has a ")#emph[#text("clockwise")]#text(" orientation. Thus for instance, ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" has an anticlockwise orientation, while its reversal ")#mi("{-\\gamma_{z_0,r,\\circlearrowleft}}")#text(" has the clockwise orientation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51")]#text(" ")#metadata(none) <tao-e96e02d8e47f2a7c03be>#text(" Let ")#mi("{\\gamma_1}")#text(", ")#mi("{\\gamma_2}")#text(" be non-trivial simple closed curves.")

#list(
[#text("(i) If ")#mi("{\\gamma_1,\\gamma_2}")#text(" have disjoint image, show that ")#mi("{\\gamma_2}")#text(" either lies entirely in the interior of ")#mi("{\\gamma_1}")#text(", or in the exterior.")],
[#text("(ii) If ")#mi("{\\gamma_2}")#text(" avoids the exterior of ")#mi("{\\gamma_1}")#text(", show that the interior of ")#mi("{\\gamma_2}")#text(" is contained in the interior of ")#mi("{\\gamma_1}")#text(", and the exterior of ")#mi("{\\gamma_2}")#text(" contains the exterior of ")#mi("{\\gamma_1}")#text(".")],
[#text("(iii) If ")#mi("{\\gamma_2}")#text(" avoids the interior of ")#mi("{\\gamma_1}")#text(", and ")#mi("{\\gamma_1}")#text(" avoids the interior of ")#mi("{\\gamma_2}")#text(", and the two curves have disjoint images, show that the interior of ")#mi("{\\gamma_2}")#text(" is contained in the exterior of ")#mi("{\\gamma_1}")#text(", and the exterior of ")#mi("{\\gamma_2}")#text(" contains the interior of ")#mi("{\\gamma_1}")#text(".")]
)

#text("(This is all visually “obvious” as soon as one draws a picture, but the challenge is to provide a rigorous proof. One should of course use the Jordan curve theorem extensively to do so.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52")]#text(" Let ")#mi("{\\gamma}")#text(" be a non-trivial simple closed curve. Show that the interior of ")#mi("{\\gamma}")#text(" is simply connected. (")#emph[#text("Hint:")]#text(" first show that any simple closed polygonal path in ")#mi("{\\gamma}")#text(" is contractible to a point in the interior; then extend this to closed polygonal paths that are not necessarily simple by an induction on the number of edges in the path; then handle general closed curves.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 53")]#text(" There is a refinement of the Jordan curve theorem known as the ")#link("https://en.wikipedia.org/wiki/Schoenflies_problem")[#text("Jordan-Schoenflies theorem")]#text(", that asserts that for non-trivial simple closed curve ")#mi("{\\gamma}")#text(" there is a ")#link("https://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]#text(" ")#mi("{\\phi: {\\bf C} \\rightarrow {\\bf C}}")#text(" that maps ")#mi("{\\gamma}")#text(" to the unit circle ")#mi("{S^1}")#text(", the interior of ")#mi("{\\gamma}")#text(" to the unit disk ")#mi("{D(0,1)}")#text(", and the exterior to the exterior region ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right| > 1 \\}}", block: false)#text(". The proof of this improved version of the Jordan curve theorem will have to wait until we have the ")#link("https://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(" (as well as a refinement of this ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem_(conformal_mapping)")[#text("theorem due to Carathéodory")]#text("). The Jordan-Schoenflies theorem may seem self-evident, but it is worth pointing out that the analogous result in three dimensions fails without additional regularity assumptions on the boundary surface, thanks to the counterexample of the ")#link("https://en.wikipedia.org/wiki/Alexander_horned_sphere")[#text("Alexander horned sphere")]#text(".")
]

#text("From the Jordan curve theorem we have yet another form of the Cauchy theorem and Cauchy integral formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 54 (Cauchy’s theorem and Cauchy integral formula for simple curves)")]#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed curve, and let ")#mi("{U}")#text(" be an open set containing ")#mi("{\\gamma}")#text(" and its interior. Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function.")

#list(
[#text("(i) (Cauchy’s theorem) One has ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(".")],
[#text("(ii) (Cauchy integral formula) If ")#mi("{z_0 \\in U}")#text(" lies outside of the image of ")#mi("{\\gamma}")#text(", then the expression ")#mi("{\\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz}")#text(" vanishes if ")#mi("{z_0}")#text(" lies in the exterior of ")#mi("{\\gamma}")#text(", equals ")#mi("{f(z_0)}")#text(" if ")#mi("{z_0}")#text(" lies in the interior of ")#mi("{\\gamma}")#text(" and ")#mi("{\\gamma}")#text(" is oriented anti-clockwise, and equals ")#mi("{-f(z_0)}")#text(" if ")#mi("{z_0}")#text(" lies in the interior of ")#mi("{\\gamma}")#text(" and ")#mi("{\\gamma}")#text(" is oriented clockwise.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55")]#text(" Let ")#mi("{P(z) = a_n z^n + \\dots + a_0}")#text(" be a polynomial with complex coefficients ")#mi("{a_0,\\dots,a_n}")#text(" and ")#mi("{a_n \\neq 0}")#text(". For any ")#mi("{R>0}")#text(", let ")#mi("{\\gamma_R: [0,2\\pi] \\rightarrow {\\bf C}}")#text(" denote the closed contour ")#mi("{\\gamma_R(t) := P(R e^{it})}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{R}")#text(" is sufficiently large, then ")#mi("{W_{\\gamma_R}(0) = n}")#text(".")],
[#text("(ii) Show that if ")#mi("{P}")#text(" does not vanish on the closed disk ")#mi("{\\overline{D(0,R)}}")#text(", then ")#mi("{W_{\\gamma_R}(0)=0}")#text(".")],
[#text("(iii) Use these facts to give an alternate proof of the fundamental theorem of algebra that does not invoke Liouville’s theorem.")]
)
]

#text("In the case when the closed curve ")#mi("{\\gamma}")#text(" is a contour (which includes of course the case of closed polygonal paths), one can describe the interior and exterior regions, as well as the winding number, more explicitly.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 56 (Local structure of interior and exterior)")]#text(" Let ")#mi("{\\gamma = \\gamma_1 + \\dots + \\gamma_n: [a,b] \\rightarrow {\\bf C}}")#text(" be a simple closed contour formed by concatenating smooth curves ")#mi("{\\gamma_1,\\dots,\\gamma_n}")#text(" together. Let ")#mi("{z_0}")#text(" be an interior point of one of these curves ")#mi("{\\gamma_i: [a_i,b_i] \\rightarrow {\\bf C}}")#text(", thus ")#mi("{z_0 = \\gamma_i(t_i)}")#text(" for some ")#mi("{a_i < t_i < b_i}")#text(". Set ")#mi("{\\gamma^{\\prime}(t_i) = re^{i\\theta}}")#text(" for some ")#mi("{r>0}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(". Recall from Exercise 25 of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(" that for sufficiently small ")#mi("{\\varepsilon}")#text(", the set ")#mi("{\\gamma([a,b]) \\cap D(z_0,\\varepsilon)}")#text(" can be expressed as a graph of the form")

#align(center)[#tao-fit-display[#mitex("\\gamma([a,b]) \\cap D(z_0,\\varepsilon) = \\{ z_0 + e^{i\\theta} (s + i f(s)): s \\in I_\\varepsilon \\}")]]

#text("for some interval ")#mi("{I_\\varepsilon}")#text(" and some continuously differentiable function ")#mi("{f: I_\\varepsilon \\rightarrow {\\bf R}}")#text(" with ")#mi("{f(0) =f^{\\prime}(0) = \\varepsilon}")#text(". Show that if ")#mi("{\\gamma}")#text(" is oriented anticlockwise, and ")#mi("{\\varepsilon}")#text(" is sufficiently small then the interior of ")#mi("{\\gamma}")#text(" contains all points in ")#mi("{D(z_0,\\varepsilon)}")#text(" of the form ")#mi("{z_0 + e^{i\\theta} (s + i (f(s)+u))}")#text(" for some ")#mi("{s \\in I_\\varepsilon}")#text(" and ")#mi("{u>0}")#text(", and the exterior of ")#mi("{\\gamma}")#text(" contains all points in ")#mi("{D(z_0,\\varepsilon)}")#text(" of the form ")#mi("{z_0 + e^{i\\theta} (s + i (f(s)+u))}")#text(" for some ")#mi("{s \\in I_\\varepsilon}")#text(" and ")#mi("{u<0}")#text(". Similarly if ")#mi("{\\gamma}")#text(" oriented clockwise, with the conditions ")#mi("{u>0}")#text(" and ")#mi("{u<0}")#text(" swapped.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57 (Alexander numbering rule)")]#text(" Let ")#mi("{\\gamma = \\gamma_1 + \\dots + \\gamma_n: [a,b] \\rightarrow {\\bf C}}")#text(" be a closed contour formed by concatenating smooth curves ")#mi("{\\gamma_1,\\dots,\\gamma_n}")#text(" together. Let ")#mi("{\\sigma = \\sigma_1 + \\dots + \\sigma_m: [c,d] \\rightarrow {\\bf C}}")#text(" be a contour formed by concatenating smooth curves ")#mi("{\\sigma_1,\\dots,\\sigma_m}")#text(", with initial point ")#mi("{z_0}")#text(" and terminal point ")#mi("{z_1}")#text(". Assume that there are only finitely many points ")#mi("{w_1,\\dots,w_k}")#text(" where the images of ")#mi("{\\gamma}")#text(" and of ")#mi("{\\sigma}")#text(" intersect. Furthermore, assume at each of the points ")#mi("{w_l}")#text(", ")#mi("{l=1,\\dots,k}")#text(", that one has a “smooth simple transverse intersection” in the sense that the following axioms are obeyed:")

#list(
[#text("(i) ")#mi("{w_l}")#text(" lies in the interior of one of the smooth curves ")#mi("{\\gamma_i: [a_i,b_i] \\rightarrow {\\bf C}}")#text(" that make up ")#mi("{\\gamma}")#text(", thus ")#mi("{w_l = \\gamma_i(t_i)}")#text(" for some ")#mi("{a_i < t_i < b_i}")#text(".")],
[#text("(ii) ")#mi("{w_l}")#text(" lies in the interior of one of the smooth curves ")#mi("{\\sigma_j: [c_j,d_j] \\rightarrow {\\bf C}}")#text(" that make up ")#mi("{\\sigma}")#text(", thus ")#mi("{w_l = \\sigma_j(s_j)}")#text(" for some ")#mi("{c_j < t_j < b_j}")#text(".")],
[#text("(iii) ")#mi("{w_l}")#text(" is only traversed once by ")#mi("{\\sigma}")#text(", thus there do not exist ")#mi("{t \\neq t^{\\prime}}")#text(" in ")#mi("{[c,d]}")#text(" such that ")#mi("{\\sigma(t)=\\sigma(t^{\\prime})=w_l}")#text(". Similarly, ")#mi("{w_l}")#text(" is only traversed once by ")#mi("{\\gamma}")#text(".")],
[#text("(iv) The derivatives ")#mi("{\\gamma^{\\prime}_i(t_i)}")#text(" and ")#mi("{\\gamma^{\\prime}_j(s_j)}")#text(" are linearly independent over ")#mi("{{\\bf R}}")#text(". In other words, we either have a ")#emph[#text("crossing from the right")]#text(" in which ")#mi("{\\gamma^{\\prime}_j(s_j) = \\lambda e^{i\\theta} \\gamma^{\\prime}_i(t_i)}")#text(" for some ")#mi("{\\lambda > 0}")#text(" and ")#mi("{0 < \\theta < \\pi}")#text(", or else we have a ")#emph[#text("crossing from the left")]#text(" in which ")#mi("{\\gamma^{\\prime}_j(s_j) = \\lambda e^{i\\theta} \\gamma^{\\prime}_i(t_i)}")#text(" for some ")#mi("{\\lambda > 0}")#text(" and ")#mi("{-\\pi < \\theta < 0}")#text(".")]
)

#text("Show that ")#mi("{W_\\gamma(z_0) - W_\\gamma(z_1)}")#text(" is equal to the total number of crossings from the left, minus the total number of crossings from the right.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" Let ")#mi("{U}")#text(" be a non-empty connected open subset of ")#mi("{{\\bf C}}")#text(". Show that ")#mi("{U}")#text(" is simply connected if and only if every holomorphic function on ")#mi("{U}")#text(" is conservative.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 59")]#text(" Let ")#mi("{U}")#text(" be a simply connected subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" be a harmonic function. Show that ")#mi("{u}")#text(" has a harmonic conjugate ")#mi("{v: U \\rightarrow {\\bf R}}")#text(", which is unique up to additive constants.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60")]#text(" Let ")#mi("{u: {\\bf C} \\rightarrow {\\bf R}}")#text(" be a harmonic function that is everywhere non-negative. Show that ")#mi("{u}")#text(" is constant. (")#emph[#text("Hint:")]#text(" combine ")#mi("{u}")#text(" with its harmonic conjugate and the complex exponential to create a bounded entire function.)")
]

#heading(level: 1)[#strong[#text(" — 4. Appendix: proof of the Jordan curve theorem (optional) — ")]]

#text("We now prove the Jordan curve theorem.")

#text("We first verify the claim in the easy (and visually intuitive) case that ")#mi("{\\gamma}")#text(" is a non-trivial simple closed polygonal curve. Removing the polygon ")#mi("{\\gamma([a,b])}")#text(" from ")#mi("{{\\bf C}}")#text(" leaves an open set, which we may decompose into connected components as per Exercise 35 of ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(". On each of these components, the winding number ")#mi("{W_\\gamma}")#text(" is constant. Since each component has a non-empty boundary that is contained in ")#mi("{\\gamma([a,b])}")#text(", this constant value of ")#mi("{W_\\gamma}")#text(" must also be attained arbitrarily close to ")#mi("{\\gamma([a,b])}")#text(".")

#text("Now, a routine application of the Cauchy integral formula (see Exercise ")#link(<tao-bcfef39edb05a1f7faf8>)[#text("64")]#text(") shows that as ")#mi("{z_0}")#text(" crosses one of the edges of the polygon ")#mi("{\\gamma([a,b])}")#text(", the winding number ")#mi("{W_\\gamma(z_0)}")#text(" is shifted by either ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(". Hence at each point ")#mi("{z}")#text(" on ")#mi("{\\gamma([a,b])}")#text(", the winding number will take two values ")#mi("{\\{ k, k+1\\}}")#text(" in a sufficiently small neighbourhood of ")#mi("{z}")#text(" (excluding ")#mi("{\\gamma([a,b])}")#text("). By a continuity argument, the integer ")#mi("{k}")#text(" is independent of ")#mi("{z}")#text(". On the other hand, from Corollary ")#link(<tao-970b1897af0abab6127d>)[#text("45")]#text(" the winding number must be able to attain the value of zero. Thus we have ")#mi("{\\{k,k+1\\} = \\{0,\\sigma\\}}")#text(" for some ")#mi("{\\sigma = \\pm 1}")#text(". Dividing a small neighbourhood of ")#mi("{\\gamma([a,b])}")#text(" (excluding ")#mi("{\\gamma([a,b])}")#text(" itself) into the regions where the winding numbers are ")#mi("{0}")#text(" or ")#mi("{\\sigma}")#text(", a further continuity argument shows that each of these regions lie in a single connected component. Thus there are only two connected components, one where the winding number is zero and one where the winding number is ")#mi("{\\sigma}")#text(". From ")#link(<tao-970b1897af0abab6127d>)[#text("(45)")]#text(" the latter component is bounded, hence the former is unbounded. This gives claims (i), (ii) of the Jordan curve theorem. Also, from construction we see that every point ")#mi("{z}")#text(" in ")#mi("{\\gamma([a,b])}")#text(" is adherent to both the interior and exterior, giving (iv).")

#text("Now we establish claim (iii). We induct on the number ")#mi("{n}")#text(" of edges in ")#mi("{\\gamma}")#text(". The cases ")#mi("{n \\leq 3}")#text(" can be handled by direct calculation, so suppose that ")#mi("{n>3}")#text(" and the claim has been proven for all smaller values of ")#mi("{n}")#text(". We may remove any edges of zero length from the polygon. If the interior of the polygon is convex, then the claim follows from Example ")#link(<tao-1143da2bc54c495c4be3>)[#text("2")]#text(", so we may assume that the interior is non-convex. We now invoke the following geometric fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 61")]#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed polygonal path with all edges of positive length. Suppose that all interior angles of ")#mi("{\\gamma}")#text(" (that is, the angle that two adjacent edges make in the interior of the polygon) are less than or equal to ")#mi("{\\pi}")#text(". Show that the interior of ")#mi("{\\gamma}")#text(" is convex. (")#emph[#text("Hint:")]#text(" first eliminate all angles that are exactly ")#mi("{\\pi}")#text(". It suffices to show that the interior is star-shaped around every interior point ")#mi("{z_0}")#text(". To show this, first show that the set of interior points connected to ")#mi("{z_0}")#text(" by a line segment in the interior is a connected component of the interior.)")
]

#text("From this exercise we see that there are two adjacent edges ")#mi("{e,f}")#text(" whose interior angle exceeds ")#mi("{\\pi}")#text(". If one extends ")#mi("{e}")#text(" in the interior until it meets the polygon again, we see that this extended edge ")#mi("{e^*}")#text(" will divide the polygon into two subpolygons ")#mi("{\\gamma_1,\\gamma_2}")#text(", each of which can be verified to have fewer than ")#mi("{n}")#text(" edges. Let ")#mi("{\\sigma_1, \\sigma_2 \\in \\{-1,+1\\}}")#text(" be the orientations of ")#mi("{\\gamma_1, \\gamma_2}")#text(". Then For any point ")#mi("{z_0}")#text(" near an interior point of the edge ")#mi("{e^*}")#text(" but not actually on ")#mi("{e_*}")#text(", ")#mi("{W_{\\gamma}(z_0)}")#text(" is equal to ")#mi("{\\sigma}")#text(", ")#mi("{W_{\\gamma_1}(z_0)}")#text(" takes values in ")#mi("{\\{0,\\sigma_1\\}}")#text(", and ")#mi("{W_{\\gamma_2}(z_0)}")#text(" takes values in ")#mi("{\\{0,\\sigma_2\\}}")#text(", with the latter two winding number switching as ")#mi("{z_0}")#text(" crosses ")#mi("{e^*}")#text(". Since ")#mi("{W_\\gamma(z_0) = W_{\\gamma_1}(z_0) + W_{\\gamma_2}(z_0)}")#text(", we conclude that ")#mi("{\\sigma_1=\\sigma_2=\\sigma}")#text(", and this equation then also shows that the interiors of ")#mi("{\\gamma_1,\\gamma_2}")#text(" are contained in ")#mi("{\\gamma}")#text(". By induction hypothesis, ")#mi("{\\gamma_1}")#text(" and ")#mi("{\\gamma_2}")#text(" are contractible to a point in ")#mi("{U}")#text(". Using Exercise ")#link(<tao-db47b1c1e7b057ffe3d0>)[#text("3")]#text(" we conclude that ")#mi("{\\gamma}")#text(" is contractible to a point in ")#mi("{U}")#text(" also.")

#align(center)[#image("../assets/a28be17229e9a80e8e8dd5ecd086a8334e3a0a8f0eae69735949bf820cb9f33d-e54373a801809fdea19a68cd7b4f9d40ed5982809cc9c6190e7a266e39dd389d.png", width: 90%, alt: "polygon")]

#text("Now we handle the significantly more difficult case when ")#mi("{\\gamma}")#text(" is just a non-trivial simple closed curve. As one may expect, the strategy will be to approximate this curve by a polygonal path, but some care has to be taken when performing a limit, in order to prevent the interior region from collapsing into nothingness, or becoming disconnected, in the limit.")

#text("We begin with a variant of Corollary ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" in which the curve ")#mi("{\\gamma_1}")#text(" is only required to have ")#emph[#text("image")]#text(" close to the image of ")#mi("{\\gamma_0}")#text(", rather than be close to ")#mi("{\\gamma_0}")#text(" in a ")#emph[#text("pointwise")]#text(" (and uniform) sense. For any curve ")#mi("{\\gamma}")#text(" and any ")#mi("{r>0}")#text(", let ")#mi("{N_r(\\gamma) := \\{ z \\in {\\bf C}: \\mathrm{dist}(z,\\gamma) < r \\}}")#text(" denote the ")#mi("{r}")#text("-neighbourhood of ")#mi("{\\gamma}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 62")]#text(" ")#metadata(none) <tao-034a2f41d964f6f3ef6e>#text(" Let ")#mi("{\\gamma_0}")#text(" be a non-trivial simple closed curve, and let ")#mi("{\\delta>0}")#text(". Suppose that ")#mi("{\\varepsilon>0}")#text(" is sufficiently small depending on ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\delta}")#text(". Let ")#mi("{\\gamma_1}")#text(" be a closed curve (not necessarily simple) whose image lies in ")#mi("{N_{\\varepsilon}(\\gamma_0)}")#text(". Then ")#mi("{\\gamma_1}")#text(" is homotopic (as a closed curve, up to reparameterisation) to ")#mi("{m\\gamma_0}")#text(" in ")#mi("{N_\\delta(\\gamma_0)}")#text(", where ")#mi("{m\\gamma_0}")#text(" is defined as the concatenation of ")#mi("{m}")#text(" copies of ")#mi("{\\gamma_0}")#text(" if ")#mi("{m}")#text(" is positive, the trivial curve at the initial point of ")#mi("{\\gamma_0}")#text(" if ")#mi("{m}")#text(" is zero, and the concatenation of ")#mi("{-m}")#text(" copies of ")#mi("{-\\gamma_0}")#text(" if ")#mi("{m}")#text(" is negative. In particular, from Lemma ")#link(<tao-6781926820c2f76cf25d>)[#text("43")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma_1}(z_0) = m W_{\\gamma_0}(z_0)")]]

#text("for all ")#mi("{z_0 \\in {\\bf C} \\backslash N_{\\delta}(\\gamma_0)}")#text(".")
]

#align(center)[#image("../assets/d7b08c74316ca22bb122d0e45c2256b6387bf40f5d9d0ed4bc683b967b30bd2a-dd8fbbf775d86b338f3ca661f8f0419d5617a50f56f28860ac8eb90cd1878c1c.png", width: 90%, alt: "twist")]

#emph[#text("Proof:")]#text(" After reparameterisation, we can take ")#mi("{\\gamma_0: [0,1] \\rightarrow {\\bf C}}")#text(" to have domain on the unit interval ")#mi("{[0,1]}")#text(", and then by periodic extension we can view ")#mi("{\\gamma_0: {\\bf R} \\rightarrow {\\bf C}}")#text(" as a continuous ")#mi("{1}")#text("-periodic function on ")#mi("{{\\bf R}}")#text(".")

#text("As ")#mi("{[0,1]}")#text(" is compact, ")#mi("{\\gamma_0}")#text(" is uniformly continuous on ")#mi("{[0,1]}")#text(", and hence also on ")#mi("{{\\bf R}}")#text(". In particular, there exists ")#mi("{0 < \\kappa < \\frac{1}{10}}")#text(" such that ")#metadata(none) <tao-65f15ce8fee25b248445>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|\\gamma_0(t_1) - \\gamma_0(t_2)\\right| \\leq \\frac{\\delta}{2}", block: true)]]

#linebreak()#text(" whenever ")#mi("{t_1,t_2 \\in {\\bf R}}")#text(" are such that ")#tao-math("{\\left|t_1-t_2\\right| \\leq \\kappa}", block: false)#text(".")#linebreak()#text(" Fix this ")#mi("{\\kappa}")#text(". Observe that the function ")#tao-math("{(t_1,t_2) \\mapsto \\left|\\gamma_0(t_1)-\\gamma_0(t_2)\\right|}", block: false)#text(" is continuous and nowhere vanishing on the region ")#tao-math("{\\{ (t_1,t_2) \\in [0,2] \\times [0,2]: \\kappa \\leq \\left|t_1-t_2\\right| \\leq 1-\\kappa \\}}", block: false)#text(". Thus, if ")#mi("{\\varepsilon}")#text(" is small enough depending on ")#mi("{\\gamma_0,\\kappa}")#text(", we have the lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma_0(t_1)-\\gamma_0(t_2)\\right| \\geq 3\\varepsilon", block: true)]]

#text("whenever ")#mi("{t_1,t_2 \\in [0,2]}")#text(" are such that ")#tao-math("{\\kappa \\leq \\left|t_1-t_2\\right| \\leq 1-\\kappa}", block: false)#text(". Using the ")#mi("{1}")#text("-periodicity of ")#mi("{\\gamma_0}")#text(", we conclude that if ")#mi("{t_1,t_2 \\in {\\bf R}}")#text(" are such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma_0(t_1)-\\gamma_0(t_2)\\right| < 3\\varepsilon", block: true)]]

#text("the there must be an integer ")#mi("{m_{t_1,t_2}}")#text(" such that ")#metadata(none) <tao-0a7cb27e52927eacabbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|t_2 - (t_1+m_{t_1,t_2})\\right| < \\kappa.", block: true)]]

#text("Note that this integer ")#mi("{m_{t_1,t_2}}")#text(" is uniquely determined by ")#mi("{t_1}")#text(" and ")#mi("{t_2}")#text(".")#linebreak()#text(" Let ")#mi("{[a,b]}")#text(" be the domain of ")#mi("{\\gamma_1: [a,b] \\rightarrow {\\bf C}}")#text(". By the uniform continuity of ")#mi("{\\gamma_1}")#text(", we can find a partition ")#mi("{a = s_0 < \\dots < s_n = b}")#text(" of ")#mi("{[a,b]}")#text(" such that ")#metadata(none) <tao-1d543f9551c1643dba07>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|\\gamma_1(s) - \\gamma_1(s^{\\prime})\\right| < \\varepsilon", block: true)]]

#linebreak()#text(" for all ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{s_{j-1} \\leq s, s^{\\prime} \\leq s_j}")#text(". Since the image of ")#mi("{\\gamma_1}")#text(" lies in ")#mi("{N_{\\varepsilon}(\\gamma_0)}")#text(", we can find, for each ")#mi("{0 \\leq j \\leq n}")#text(", a real number ")#mi("{t_j}")#text(" such that ")#metadata(none) <tao-cf4fd839f7f9d3d6ae6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\gamma_1(s_j) - \\gamma_0(t_j)\\right| < \\varepsilon.", block: true)]]

#text("Since ")#mi("{\\gamma_1}")#text(" is closed, we may arrange matters so that ")#metadata(none) <tao-d137d43ec26cc59943b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\gamma_0(t_0) = \\gamma_0(t_n).")]]

#text("From the triangle inequality and ")#link(<tao-1d543f9551c1643dba07>)[#text("(12)")]#text(", ")#link(<tao-cf4fd839f7f9d3d6ae6e>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma_0(t_j) - \\gamma_0(t_{j-1})\\right| < 3\\varepsilon.", block: true)]]

#text("Using ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(11)")]#text(", we conclude that for each ")#mi("{1 \\leq j \\leq n}")#text(", there is an integer ")#mi("{m_j}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|t_j - (t_{j-1}+m_j)\\right| < \\kappa.", block: true)]]

#text("As ")#mi("{\\gamma_0}")#text(" is ")#mi("{1}")#text("-periodic, we have the freedom to shift each of the ")#mi("{t_j}")#text(" by an arbitrary integer, and by doing this for ")#mi("{t_1, \\dots, t_n}")#text(" in turn, we may assume without loss of generality that all the ")#mi("{m_j}")#text(" vanish, thus ")#metadata(none) <tao-cd6dcf962b702d71ab17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|t_j - t_{j-1}\\right| < \\kappa", block: true)]]

#text("for all ")#mi("{j=1,\\dots,n}")#text(". In particular, from ")#link(<tao-65f15ce8fee25b248445>)[#text("(10)")]#text(" we have ")#metadata(none) <tao-2ddb5465ef8623231607>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\gamma_0(t) - \\gamma_0(t^{\\prime})\\right| < \\frac{\\delta}{2}", block: true)]]

#text("whenever ")#mi("{t_{j-1} \\leq t, t^{\\prime} \\leq t_j}")#text(". Also, as ")#mi("{\\gamma_0}")#text(" is simple, we have from ")#link(<tao-d137d43ec26cc59943b3>)[#text("(14)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("t_n = t_0 + m")]]

#text("for some integer ")#mi("{m}")#text(". (Note that by enforcing ")#link(<tao-cd6dcf962b702d71ab17>)[#text("(15)")]#text(", we no longer have the freedom to individually move ")#mi("{t_0}")#text(" or ")#mi("{t_n}")#text(" by an integer, so we cannot assume without loss of generality that ")#mi("{m}")#text(" vanishes.)")#linebreak()#text(" For ")#mi("{j=1,\\dots,n}")#text(", let ")#mi("{\\gamma_{0,j}: [j-1,j] \\rightarrow {\\bf C}}")#text(" denote the curve")

#align(center)[#tao-fit-display[#mitex("\\gamma_{0,j}(t) := \\gamma_0( t_{j-1} + (t-j+1) (t_j - t_{j-1}) )")]]

#text("from ")#mi("{\\gamma_0(t_{j-1})}")#text(" to ")#mi("{\\gamma_0(t_j)}")#text("; similarly let ")#mi("{\\gamma_{1,j}: [j-1,j] \\rightarrow {\\bf C}}")#text(" denote the curve")

#align(center)[#tao-fit-display[#mitex("\\gamma_{1,j}(t) := \\gamma_1( s_{j-1} + (t-j+1) (s_j - s_{j-1}) )")]]

#text("from ")#mi("{\\gamma_1(s_{j-1})}")#text(" to ")#mi("{\\gamma_1(s_j)}")#text(". Observe from ")#link(<tao-2ddb5465ef8623231607>)[#text("(16)")]#text(", ")#link(<tao-1d543f9551c1643dba07>)[#text("(12)")]#text(", ")#link(<tao-cf4fd839f7f9d3d6ae6e>)[#text("(13)")]#text(" that for each ")#mi("{j=1,\\dots,n}")#text(", the images of ")#mi("{\\gamma_{0,j}}")#text(" and ")#mi("{\\gamma_{1,j}}")#text(" both lie in ")#mi("{D( \\gamma_0(t_j), \\frac{\\delta}{2} + 3\\varepsilon)}")#text(", which will lie in ")#mi("{N_\\delta(\\gamma_0([a,b]))}")#text(" if ")#mi("{\\varepsilon}")#text(" is small enough. We can thus form a homotopy ")#mi("{\\gamma: [0,1] \\times [0,n] \\rightarrow N_\\delta(\\gamma_0([a,b]))}")#text(" from ")#mi("{\\gamma_{0,1} + \\dots + \\gamma_{0,n}}")#text(" to ")#mi("{\\gamma_{1,1} + \\dots + \\gamma_{1,n}}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\gamma( s, t ) = (1-s) \\gamma_{0,j}(t) + s \\gamma_{1,j}(t)")]]

#text("for all ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{j-1 \\leq t \\leq j}")#text(". Thus ")#mi("{\\gamma_{0,1} + \\dots + \\gamma_{0,n}}")#text(" and ")#mi("{\\gamma_{1,1} + \\dots + \\gamma_{1,n}}")#text(" are homotopic as closed curves in ")#mi("{N_\\delta(\\gamma_0([a,b]))}")#text(". But by Exercise ")#link(<tao-db47b1c1e7b057ffe3d0>)[#text("3")]#text(", ")#mi("{\\gamma_{0,1} + \\dots + \\gamma_{0,n}}")#text(" is homotopic up to reparameterisation as closed curves to ")#mi("{m \\gamma_0}")#text(" in ")#mi("{N_\\delta(\\gamma_0([a,b]))}")#text(", and ")#mi("{\\gamma_{1,1} + \\dots + \\gamma_{1,n}}")#text(" is similarly homotopic up to reparameterisation as closed curves to ")#mi("{\\gamma_1}")#text(" in ")#mi("{N_\\delta(\\gamma_0([a,b]))}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Returning to the general case of the Jordan curve theorem, we need to ensure that there is at least one point ")#mi("{z_0}")#text(" outside of ")#mi("{\\gamma([a,b])}")#text(" in which ")#mi("{W_f(z_0)}")#text(" is non-zero. This is actually rather tricky; we will achieve this by a parity argument (loosely inspired by a nonstandard version of this argument from ")#link("http://www.ams.org/mathscinet-getitem?mr=1691743")[#text("this paper of Kanovei and Reeken")]#text("). Clearly, ")#mi("{\\gamma([a,b])}")#text(" contains at least two points; by an appropriate rotation, translation, and dilation we may assume that ")#mi("{\\gamma([a,b])}")#text(" contains the points ")#mi("{+i}")#text(" and ")#mi("{-i}")#text(", with ")#mi("{i}")#text(" being both the initial point and the terminal point. Then we can decompose ")#mi("{\\gamma = \\gamma_1 + \\gamma_2}")#text(", where ")#mi("{\\gamma_1: [a,c] \\rightarrow {\\bf C}}")#text(" is a curve from ")#mi("{i}")#text(" to ")#mi("{-i}")#text(", and ")#mi("{\\gamma_2: [c,b] \\rightarrow {\\bf C}}")#text(" is a curve from ")#mi("{-i}")#text(" to ")#mi("{i}")#text(".")

#align(center)[#image("../assets/f2ba781ffde9c45c074329a22755b353038a65e963bdeae90f21fa2d3d703aed-79cae35f94675edfcf83d9e46282f4086fca8b0dccdab5c6653b526c722bff8e.png", width: 90%, alt: "cut")]

#text("Observe from the simplicity of ")#mi("{\\gamma}")#text(" that ")#tao-math("{\\left|\\gamma_1(t_1) - \\gamma_2(t_2)\\right| > 0}", block: false)#text(" whenever ")#mi("{t_1 \\in [a,c]}")#text(" and ")#mi("{t_2 \\in [c,b]}")#text(" are such that ")#metadata(none) <tao-5643f1a80ea9af2d5f84>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|\\mathrm{Im}(\\gamma_1(t))\\right|, \\left|\\mathrm{Im}(\\gamma_2(t_2))\\right| \\leq \\frac{1}{2}.", block: true)]]

#linebreak()#text(" Thus, by compactness, there exists ")#mi("{0 < \\delta < \\frac{1}{10}}")#text(" such that one has the lower bound ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|\\gamma_1(t_1) - \\gamma_2(t_2)\\right| \\geq \\delta", block: true)]]

#text("separating ")#mi("{\\gamma_1}")#text(" from ")#mi("{\\gamma_2}")#text(" whenever ")#mi("{t_1 \\in [a,c]}")#text(", ")#mi("{t_2 \\in [c,b]}")#text(" are such that ")#link(<tao-5643f1a80ea9af2d5f84>)[#text("(17)")]#text(" holds.")#linebreak()#text(" Next, for any natural number ")#mi("{N}")#text(", we may approximate ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" by a polygonal closed path ")#mi("{\\gamma^{(N)}: [a,b] \\rightarrow {\\bf C}}")#text(" with ")#metadata(none) <tao-9bc6e4fa5d522384082d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left|\\gamma^{(N)}(t) - \\gamma(t)\\right| < \\frac{1}{N}", block: true)]]

#linebreak()#text(" for all ")#mi("{t \\in [a,b]}")#text(". Although it is not particularly necessary, we can ensure that ")#mi("{\\gamma^{(N)}(a) = \\gamma(a) = i}")#text(" and ")#mi("{\\gamma^{(N)}(c) = \\gamma(c) = -i}")#text(". By perturbing the edges of the polygonal path ")#mi("{\\gamma^{(N)}}")#text(" slightly, we may assume that none of the vertices of ")#mi("{\\gamma^{(N)}}")#text(" lie on the real axis, and that none of the self-crossings of ")#mi("{\\gamma^{(N)}}")#text(" (if any exist) lie on the real axis; thus, whenever ")#mi("{\\gamma^{(N)}}")#text(" crosses the real axis, it does so at an interior point of an edge, with no other edge of ")#mi("{\\gamma^{(N)}}")#text(" passing through that point. Note that we do not assert that the curve ")#mi("{\\gamma^{(N)}}")#text(" is simple; with some more effort one could “prune” ")#mi("{\\gamma^{(N)}}")#text(" by deleting short loops to make it simple, but this turns out to be unnecessary for the parity argument we give below.")#linebreak()#text(" Let ")#mi("{x^{(N)}_1 < x^{(N)}_2 < \\dots < x^{(N)}_{n^{(N)}}}")#text(" be the points on the real axis where ")#mi("{\\gamma^{(N)}}")#text(" crosses. By Exercise ")#link(<tao-bcfef39edb05a1f7faf8>)[#text("64")]#text(" below, the winding number ")#mi("{W_{\\gamma^{(N)}}(x)}")#text(" changes by ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(" as ")#mi("{x}")#text(" crosses each of the ")#mi("{x^{(N)}_j}")#text("; by Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(", this winding number is constant otherwise, and by Corollary ")#link(<tao-970b1897af0abab6127d>)[#text("45")]#text(" it vanishes near infinity. Thus ")#mi("{n^{(N)}}")#text(" is even, and the winding number is odd between ")#mi("{x^{(N)}_j}")#text(" and ")#mi("{x^{(N)}_{j+1}}")#text(" for any odd ")#mi("{j}")#text(".")

#text("Next, observe that each point ")#mi("{x^{(N)}_j}")#text(" belongs to exactly one of the polygonal paths ")#mi("{\\gamma^{(N)}([a,c])}")#text(" or ")#mi("{\\gamma^{(N)}([c,b])}")#text(". Since each of these curves starts on one side of the real axis and ends up on the other, they must both cross the real axis an odd number of times. On the other hand, the crossing points ")#mi("{x^{(N)}_1,\\dots,x^{(N)}_n}")#text(" can be grouped into pairs ")#mi("{\\{x^{(N)}_j,x^{(N)}_{j+1}\\}}")#text(" with ")#mi("{j}")#text(" odd. We conclude that there must exist an odd ")#mi("{j}")#text(" such that one of the ")#mi("{x^{(N)}_j,x^{(N)}_{j+1}}")#text(" lies in ")#mi("{\\gamma^{(N)}([a,c])}")#text(" and the other lies in ")#mi("{\\tilde \\gamma([c,b])}")#text(".")

#text("Fix such a ")#mi("{j}")#text(". For sake of discussion let suppose that ")#mi("{x^{(N)}_j}")#text(" lies in ")#mi("{\\gamma^{(N)}([a,c])}")#text(" and ")#mi("{x^{(N)}_{j+1}}")#text(" lies in ")#mi("{\\gamma^{(N)}([c,b])}")#text(". From ")#link(<tao-9bc6e4fa5d522384082d>)[#text("(19)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x^{(N)}_j, \\gamma([a,c]) ) \\leq \\frac{1}{N}; \\quad \\mathrm{dist}( x^{(N)}_{j+1}, \\gamma([c,b]) ) \\leq \\frac{1}{N}")]]

#text("and from ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(18)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x, \\gamma([a,c]) ) + \\mathrm{dist}( x, \\gamma([c,b]) ) \\geq \\delta.")]]

#text("for any ")#mi("{x \\in [x^{(N)}_j, x^{(N)}_{j+1}]}")#text(". By the intermediate value theorem, we can thus (for ")#mi("{N}")#text(" large enough) find ")#mi("{x^{(N)}_j < x^{(N)}_* < x^{(N)}_{j+1}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x^{(N)}_*, \\gamma([a,c]) ) = \\mathrm{dist}( x^{(N)}_*, \\gamma([c,b]) )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x^{(N)}_*, \\gamma([a,c]) ), \\mathrm{dist}( x^{(N)}_*, \\gamma([c,b]) ) \\geq \\frac{\\delta}{2}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x^{(N)}_*, \\gamma([a,b]) ) \\geq \\frac{\\delta}{2}.")]]

#text("We arrive at the same conclusion in the opposite case when ")#mi("{x^{(N)}_j}")#text(" lies in ")#mi("{\\gamma^{(N)}([c,b])}")#text(" and ")#mi("{x^{(N)}_{j+1}}")#text(" lies in ")#mi("{\\gamma^{(N)}([a,c])}")#text(".")#linebreak()#text(" By Corollary ")#link(<tao-970b1897af0abab6127d>)[#text("45")]#text(" (and ")#link(<tao-9bc6e4fa5d522384082d>)[#text("(19)")]#text("), the ")#mi("{x^{(N)}_*}")#text(" are bounded in ")#mi("{N}")#text(". By the Bolzano-Weierstrass theorem, we can thus extract a subsequence of the ")#mi("{x^{(N)}_*}")#text(" that converges to some limit ")#mi("{x_*}")#text(". By continuity we then have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dist}( x_*, \\gamma([a,b]) ) \\geq \\frac{\\delta}{2},")]]

#text("in particular ")#mi("{x_*}")#text(" does not lie in ")#mi("{\\gamma([a,b])}")#text(". By construction of ")#mi("{x^{(N)}_*}")#text(", we know that ")#mi("{W_{\\gamma^{(N)}}( x^{(N)}_* )}")#text(" is odd for all ")#mi("{N}")#text("; using Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" and Lemma ")#link(<tao-e6080ed95475051054b6>)[#text("44")]#text(" we conclude that ")#mi("{W_\\gamma(x_*)}")#text(" is also odd. Thus we have found at least one point where the winding number is non-zero.")#linebreak()#text(" Now we can finish the proof of the Jordan curve theorem. Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a non-trivial simple closed curve. By the preceding discussion, we can find a point ")#mi("{z_*}")#text(" outside of ")#mi("{\\gamma([a,b])}")#text(" where the winding number ")#mi("{W_\\gamma}")#text(" is non-zero. Let ")#mi("{\\delta > 0}")#text(" be a sufficiently small parameter, and let ")#mi("{0 < \\varepsilon = \\varepsilon(\\delta) < \\delta}")#text(" be sufficiently small depending on ")#mi("{\\delta}")#text(". By compactness, one can cover the region ")#mi("{N_{\\varepsilon/10}(\\gamma([a,b]))}")#text(" by a finite number of (solid) squares ")#mi("{S}")#text(" of sidelength ")#mi("{\\varepsilon/10}")#text(" and sides parallel to the real and imaginary axes; by perturbation we may assume that no edge of one square is collinear to an edge of any other square. These squares all lie in ")#mi("{N_\\varepsilon(\\gamma([a,b]))}")#text(", and in particular will not contain ")#mi("{z_*}")#text(" if ")#mi("{\\delta}")#text(" is small enough; their union can easily be seen to be connected. The boundaries of these squares divide the complex plane into a finite number of polygonal regions (one of whom is unbounded). One of these regions, call it ")#mi("{\\Omega_\\delta}")#text(", contains the point ")#mi("{z_*}")#text(". This region cannot contain any interior point of a square ")#mi("{S}")#text(", since otherwise ")#mi("{\\Omega_\\delta}")#text(" would be trapped inside a square of sidelength ")#mi("{\\varepsilon/10}")#text(" and hence not contain ")#mi("{z_*}")#text(". In particular, ")#mi("{\\Omega_\\delta}")#text(" avoids ")#mi("{N_{\\varepsilon/10}(\\gamma([a,b]))}")#text(". The region ")#mi("{\\Omega_\\delta}")#text(" cannot be unbounded, since one could then continuously move ")#mi("{z_*}")#text(" to infinity without ever meeting ")#mi("{\\gamma([a,b])}")#text(", contradicting Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(", Corollary ")#link(<tao-970b1897af0abab6127d>)[#text("45")]#text(", and the non-vanishing nature of ")#mi("{W_\\gamma(z_*)}")#text(". The boundary of ")#mi("{\\Omega_\\delta}")#text(" consists of one or more disjoint closed polygonal paths, whose edges consist of horizontal and vertical line segments. Actually, the boundary must consist of just one closed path, since otherwise the union of the squares ")#mi("{S}")#text(" would be disconnected, a contradiction. Let ")#mi("{\\gamma_\\delta}")#text(" denote the path that bounds ")#mi("{\\Omega_\\delta}")#text(" (traversed in either of the two possible directions). This path must be simple, because a crossing can only be formed by an edge of one square ")#mi("{S}")#text(" crossing an edge of another square ")#mi("{S^{\\prime}}")#text(" at a point that is not on the corner of either of the two squares; as ")#mi("{\\Omega_\\delta}")#text(" avoids both ")#mi("{S}")#text(" and ")#mi("{S^{\\prime}}")#text(", it can thus only occupy one quadrant of a neighbourhood of this crossing and so cannot bound all four edges of the crossing.")

#align(center)[#image("../assets/db5b9a0d95b0bea67c486ce8672477eb2eb24006e4d39ec85f4f7c6054232d4e-363426470442b0744f6dde1b0db073bdecf6023b0fdf51a03ef0d20a58a509d4.png", width: 90%, alt: "square")]

#text("Applying the Jordan curve theorem to the polygonal path ")#mi("{\\gamma_\\delta}")#text(", we conclude that there is ")#mi("{\\sigma_\\delta \\in \\{-1,+1\\}}")#text(" such that ")#mi("{W_{\\gamma_\\delta}(z) = \\sigma_\\delta}")#text(" on ")#mi("{\\Omega_\\delta}")#text(", and ")#mi("{W_{\\gamma_\\delta}(z) = 0}")#text(" for all ")#mi("{z}")#text(" outside of ")#mi("{\\Omega_\\delta}")#text(" and ")#mi("{\\tilde \\gamma([a,b])}")#text(". On the other hand, by Proposition ")#link(<tao-034a2f41d964f6f3ef6e>)[#text("62")]#text(" there is an integer ")#mi("{m_\\delta}")#text(" such that ")#mi("{\\gamma_\\delta}")#text(" is homotopic (as closed curves, up to reparameterisation) in ")#mi("{N_\\delta([a,b])}")#text(" to ")#mi("{m_\\delta \\gamma}")#text(", so in particular")

#align(center)[#tao-fit-display[#mitex("W_{\\gamma_\\delta}(z) = m_\\delta W_\\gamma(z)")]]

#text("for all ")#mi("{z \\not \\in N_\\delta(\\gamma([a,b]))}")#text(". Applying this to ")#mi("{z = z_*}")#text(", we conclude that ")#mi("{m_\\delta}")#text(" is either ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(". If we write ")#mi("{\\sigma_\\delta = m_\\delta \\sigma}")#text(" (where ")#mi("{\\sigma}")#text(", ")#emph[#text("a priori")]#text(", may depend on ")#mi("{\\delta}")#text("), then ")#mi("{\\sigma \\in \\{-1,+1\\}}")#text(", and we have ")#metadata(none) <tao-b84ff8057ee3a7f87dea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("W_\\gamma(z) = \\sigma")]]

#text("for ")#mi("{z \\in \\Omega_\\delta \\backslash N_\\delta(\\gamma([a,b]))}")#text(", and ")#metadata(none) <tao-7c2ecd07f155648431e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("W_\\gamma(z) = 0")]]

#text("for ")#mi("{z \\in ({\\bf C} \\backslash \\Omega) \\backslash N_\\delta(\\gamma([a,b]))}")#text(". Thus ")#mi("{W_\\gamma}")#text(" takes only two values outside of ")#mi("{N_\\delta(\\gamma([a,b]))}")#text(". Sending ")#mi("{\\delta \\rightarrow 0}")#text(", we conclude that ")#mi("{\\sigma}")#text(" is in fact independent of ")#mi("{\\delta}")#text(", and ")#mi("{W_\\gamma}")#text(" takes only the two values ")#mi("{0, \\sigma}")#text(" outside of ")#mi("{\\gamma([a,b])}")#text(".")#linebreak()#text(" We now define the interior and exterior regions by ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("(9)")]#text(", ")#link(<tao-a123a777ca1a5b437abf>)[#text("(8)")]#text(", then we have partitioned ")#mi("{{\\bf C}}")#text(" into the interior, exterior, and ")#mi("{\\gamma([a,b])}")#text(". From Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" the interior and exterior are open, and from Lemma ")#link(<tao-970b1897af0abab6127d>)[#text("45")]#text(" the interior is bounded, and hence the exterior is unbounded. The point ")#mi("{z_*}")#text(" lies in the interior, so the interior is non-empty. The only remaining task to show is that the interior and exterior are connected. Suppose for instance that ")#mi("{z_1, z_2}")#text(" lie in the interior region. Then for ")#mi("{\\delta}")#text(" small enough, ")#mi("{z_1, z_2}")#text(" lie outside of ")#mi("{N_\\delta(\\gamma([a,b]))}")#text(". From ")#link(<tao-b84ff8057ee3a7f87dea>)[#text("(20)")]#text(", ")#link(<tao-7c2ecd07f155648431e0>)[#text("(21)")]#text(" we conclude that ")#mi("{z_1,z_2}")#text(" lie in ")#mi("{\\Omega_\\delta}")#text(". As ")#mi("{\\Omega_\\delta}")#text(" is connected, we can thus join ")#mi("{z_1}")#text(" to ")#mi("{z_2}")#text(" by a path in ")#mi("{\\Omega_\\delta}")#text(". As the region ")#mi("{\\Omega_\\delta}")#text(" avoids ")#mi("{N_{\\varepsilon(\\delta)/10}(\\gamma([a,b]))}")#text(", we see from Lemma ")#link(<tao-1dd5da5ec5d973decd53>)[#text("46")]#text(" that the winding number ")#mi("{W_\\gamma}")#text(" stays constant on this path, and so the path remains in the interior region ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("(9)")]#text(". This establishes the connectedness of the interior region; the connectedness of the exterior is proven similarly. This gives (i), (ii).")

#text("Now we show (iii). Let ")#mi("{\\delta > 0}")#text(" be a small parameter. As before, we can find a simple polygonal path ")#mi("{\\gamma_\\delta}")#text(" whose interior ")#mi("{\\Omega_\\delta}")#text(" lies in the interior of ")#mi("{\\gamma}")#text(", and such that ")#mi("{\\gamma_\\delta}")#text(" is homotopic to ")#mi("{m_\\delta \\gamma}")#text(" in ")#mi("{N_\\delta(\\gamma([a,b]))}")#text(", and hence in ")#mi("{U}")#text(" if ")#mi("{\\delta}")#text(" is small enough, for some ")#mi("{m_\\delta = \\pm 1}")#text(". From the previous discussion we see that ")#mi("{\\gamma_\\delta}")#text(" is contractible to a point in ")#mi("{U}")#text(", and so ")#mi("{m_\\delta \\gamma}")#text(" is also. The claim then follows (after reversing the contour ")#mi("{m_\\delta \\gamma}")#text(" if necessary).")

#text("Finally, we show (iv). We need the following variant of the Jordan curve theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 63 (Jordan arc theorem)")]#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a simple ")#emph[#text("non")]#text("-closed curve. Show that the complement of ")#mi("{\\gamma([a,b])}")#text(" in ")#mi("{{\\bf C}}")#text(" is connected. (")#emph[#text("Hint:")]#text(" first establish a variant of Proposition ")#link(<tao-034a2f41d964f6f3ef6e>)[#text("62")]#text(" for non-closed curves, in which ")#mi("{m}")#text(" is now set to zero. Then adapt the proof of the Jordan curve theorem.)")
]

#text("We now show that every point ")#mi("{z_0}")#text(" in the image of ")#mi("{\\gamma}")#text(" is a boundary point of the interior; the argument for the exterior is similar. If ")#mi("{z_0}")#text(" was not a boundary point of the interior, then one could remove a small neighborhood of ")#mi("{z_0}")#text(" from the image of the curve ")#mi("{\\gamma}")#text(" and still disconnect the interior from the exterior. In particular (after shifting the starting and ending points of ")#mi("{\\gamma}")#text(" if necessary) we could find an arc in ")#mi("{\\gamma}")#text(" which disconnects the interior from the exterior; but this contradicts the Jordan arc theorem. This gives (iv), and completes the proof of the general case of the Jordan curve theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64")]#text(" ")#metadata(none) <tao-bcfef39edb05a1f7faf8>#text(" Let ")#mi("{\\gamma}")#text(" be a non-trivial simple closed polygonal curve, and let ")#mi("{z_0}")#text(" be a point in the interior of an edge ")#mi("{e}")#text(" of ")#mi("{\\gamma}")#text(" (i.e., ")#mi("{z_0}")#text(" is not one of the two vertices of ")#mi("{e}")#text("). Let ")#mi("{z, z^{\\prime}}")#text(" be two points sufficiently close to ")#mi("{z_0}")#text(" that lie on opposite sides of ")#mi("{e}")#text(". Without using the Jordan curve theorem, show that ")#tao-math("{\\left|W_\\gamma(z) - W_\\gamma(z^{\\prime})\\right| = 1}", block: false)#text(". (")#emph[#text("Hint:")]#text(" replace ")#mi("{\\gamma}")#text(" by a “local” closed contour that is quite short, and a “global” closed contour which avoids the line segment connecting ")#mi("{z}")#text(" and ")#mi("{z^{\\prime}}")#text(". Then use the Cauchy integral formula.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 65")]#text(" Let ")#mi("{U}")#text(" be a bounded connected non-empty open subset of ")#mi("{{\\bf C}}")#text(". Show that ")#mi("{U}")#text(" is simply connected if and only if the complement ")#mi("{{\\bf C} \\backslash U}")#text(" is connected. (")#emph[#text("Hint:")]#text(" suppose that there is a point ")#mi("{z_*}")#text(" in ")#mi("{{\\bf C} \\backslash U}")#text(" that is separated from infinity by ")#mi("{U}")#text(". Show that there is some compact subset ")#mi("{K}")#text(" of ")#mi("{U}")#text(" that also separates ")#mi("{z_*}")#text(" from infinity. Then cover ")#mi("{K}")#text(" by small squares as in the proof of the Jordan curve theorem to locate a simple closed polygonal path in ")#mi("{U}")#text(" that separates ")#mi("{z_*}")#text(" from infinity.)")
]

#heading(level: 1)[#text("Comments (124)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of theorem 15")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-600153")[#strong[#text("theorem 15")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("In proof of theorem 15, the last sentence says “if \\gamma” were homotopic to a point in U\\{z_0} the right hand side would vanish”. By being homotopic to a point – does it mean that one of the end points is that point? Secondly,does it vanish because it is not holomorphic in U\\{z_0}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-600170")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("Here ‘homotopic’ refers to homotopies of closed curves, so the endpoints are allowed to shift as well – that point is allowed to be any point in ")#mi("U\\setminus\\{z_0\\}")#text(", whether it is on the initial curve or not. The statement about vanishing is just saying that, when you integrate a continuous function around a small curve, the integral is small, so as the curve shrinks to a point the value of the integral shrinks to 0. By the assumption of holomorphicity, the value of the integral doesn’t change as the curve shrinks, so we conclude that it was 0 all along. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of corollary 23")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-600166")[#strong[#text("corollary 23")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("In Proof of corollary 23, analytic continuation, we have “By hypothesis, {V} is non-empty; by the continuity of the {f^{(n)}}, {V} is closed;”. Why is V closed,if {f^{(n)}} is continuous?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-600172")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#mi("V")#text(" is the intersection of the sets ")#mi("V_n")#text(", where ")#mi("V_n")#text(" is the collection of points ")#mi("z")#text(" such that ")#mi("f^{(n)}(z)=g^{(n)}(z)")#text("; equivalently, ")#mi("V_n")#text(" is the zero set of ")#mi("f^{(n)}-g^{(n)}")#text(". Since the latter function is continuous, each ")#mi("V_n")#text(" is the continuous preimage of a closed set (namely, ")#mi("\\{0\\}")#text("), hence is closed. Since the intersection of closed sets is closed, ")#mi("V")#text(" is closed as well. – Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-600181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("May be an alternative to Ben’s comment:")

#text("Suppose ")#mi("w_m\\in V")#text(" and ")#mi("w_m\\to w")#text(". By the continuity of ")#mi("f^{(n)}")#text(" and ")#mi("g^{(n)}")#text(", (and the definition of ")#mi("V")#text("), one has ")#mi("f^{(n)}(w)=\\lim f^{(n)}(w_m)=\\lim g^{(n)}(w_m)=g^{(n)}(w)")#text(" for all ")#mi("n")#text(". So ")#mi("w\\in V")#text(".")

#text("On the other hand, since ")#mi("\\mathbb{C}")#text(" is first countable, ")#mi("w\\in \\overline{V}")#text(" if and only there exists a sequence ")#mi("(w_m)")#text(" that converges to ")#mi("w")#text(". The above argument shows that the closure ")#mi("\\overline{V}")#text(" is contained in ")#mi("V")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("In Exercise 53(i), one can look at the leading term ")#mi("a_nz^n")#text(" and use the Rouche’s theorem. How does one deal with 53(ii)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603429")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("If one pulls back the defining integral for ")#mi("W_{\\gamma}(0)")#text(" by the map P, we obtain a path integral of a holomorphic function, possibly with singularities in the bounded domain. What sort of singularities appear in this case?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("In the EX:15 on removable singularity how I can go using the given hint: show that {f} is conservative near {z_0}, find an antiderivative, extend it to {U}, and use Morera’s theorem to show that this extension is holomorphic.")

#text("1. Whether f is coneservative near z_0 means that f is conservative in D(z_0, r) \\ z_0 ?")

#text("2. If the above is correct then how can I prove that integral of f over a simple closed polygonal curve winds around z_0 is 0 ?")

#text("3. And how to extended the anti derivative on hole U ?")

#text("To use morera’s theorem at first we have to show that f is continuous on U and then over any triangule in U the integral of f is 0")#linebreak()#text(" So, can you explain something more how to use the hypothesis so that morera’s theorem can be used.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603485")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("1 – Yep!")

#text("2 – The important tools here will be homotopy invariance, the possibility of homotoping a curve to have very small length, and the boundedness of ")#mi("f")

#text("3 – Boundedness of ")#mi("f")#text(" translates to vanishing oscillation of the antiderivative ")#mi("F")#text(" – try and show that two distinct sequences ")#mi("z_n,w_n")#text(" limiting to the puncture ")#mi("z_0")#text(" satisfy ")#mi("\\lim F(z_n)=\\lim F(w_n)")

#text("To apply Morera’s theorem, I might suggest breaking an arbitrary triangle into smaller triangles on which the Cauchy integral theorem applies, at least approximately – remember, ")#mi("F")#text(" is already holomorphic on all of $\\latex U\\setminus\\{z_0\\}$!")

#text("– Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("Hello Ben,")#linebreak()#text(" Boundedness of f makes F lipschitz on D(z_0, r) \\ z_0 ??")#linebreak()#text(" To prove this we can follow the proof of 2nd FT of calculus.")#linebreak()#text(" If we have two curve joining z_1 and z_2 (with respect to a fixed point ) then /F(z_1) – F(z_2)/ bounded by M(a bound of f on punctured disk) times /z_1- z_2/.")#linebreak()#text(" But if the line segment joining z_1 and z_2 contains z_0 then we can’t apply triangle ineq there. So, then we go z_1 to z_2 along the same line but going avoiding z_0 by a small semi circle of radius epsilon. Then applying triangle ineq and taking epsilon as small as possible we prove our claim.(Am I correct ??)")

#text("Now we can defn F(z_0) as limit of F(z_n) as n goes to infinity for the sequence (z_n) approaches to z_0 unambiguously.")#linebreak()#text(" This makes F continuous on D(z_0, r) and by applying morera’s theorem then we have F is holomorphic hence f is also holomorphic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-603782")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("That’s pretty much it! One has to be careful to check that being Lipschitz is sufficient to conclude that we do extend continuously to ")#mi("z_0")#text(", but this fact is true.")

#text("One also has to apply Morera’s theorem correctly to conclude that ")#mi("F")#text(" is holomorphic, since we can’t assume that all integrals over closed contours are ")#mi("0")#text(" (since we don’t yet know that ")#mi("F")#text(" is holomorphic) but a standard exercise in “pushing the problem to ")#mi("0")#text("” will produce the desired result.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-606076")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2020")])]

#text("In the statement of Corollary 24, I think you missed mentioning that ")#mi("f")#text(" is holomorphic on ")#mi("U")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64f3b0fca28c506b4615cf526d7ee775d296fde4f6d95b36db775e086b954716-75e7d2df91f29a7e3c295781845eaa8a68134b9f108abc5606280796bb938a9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of folkertt")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-606081")[#strong[#text("folkertt")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2020")])]

#text("I recommend that that be a standing assumption in such a section. It does not always need to be repeated: it is a waste of space and bits. But if this is intended to be a section that can be used forever and ever as a reference and in particular in the context of automated proofs, then maybe it should stay. However, the past indicates (say the King James Bible or the US constitution) that then maybe there should also be mechanisms to update and modernize the Urtext. I personally can not sleep without Newton’s Principia by my side, in Latin (edition 1 on the iPhone).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-606112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2020")])]

#text("This information is very important !")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Let ")#mi("U")#text(" be a non-empty open subset of ")#mi("{\\bf C}")#text(" and ")#mi("\\gamma:[a,b]\\to{\\bf C}")#text(" a simple closed curve whose image is contained in ")#mi("U")#text(". If ")#mi("f")#text(" is holomorphic in the interior region of ")#mi("\\gamma")#text(" and continuous up to the boundary region ")#mi("\\gamma([a,b])")#text(", does one still have ")#mi("\\int_\\gamma f(z)\\,dz=0")#text("?")

#text("In general, how bad can possibly ")#mi("f")#text(" behave on the boundary region given that it is holomorphic in the interior region of a simple closed curve?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("For a nice enough curve (E.g., a contour) there is no difficulty since ")#mi("f")#text(" is locally uniformly continuous and one can approximate the curve by curves in the interior region in which Cauchy’s theorem already applies. If one has a non-rectifiable curve then it is not even obvious that the integral is even going to exist. There is a middle ground of curves that are rectifiable but not contours for which the answer may depend on some subtle regularity properties of the domain enclosed (one may for instance need the domain to be something like a chord-arc domain). I am not familiar enough with these sorts of low-regularity domains to say for sure though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Typo at the end of the proof of Cauchy theorem?")

#emph[#linebreak()#text(" …where ")#mi("{\\gamma_{0,[t_{i-1},t_i]}: [t_{i-1},t_i] \\rightarrow U}")#text(" is the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow U}")#text(" to ")#mi("{[t_{i-1},t_i]}")#text(",")#linebreak()#text(" ")]

#text("… restriction of ")#mi("{\\gamma_0: [a,b] \\rightarrow U}")#text("…")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("With the same hypotheses in Corollary 21, is it true that ")#mi("u")#text(" is also real analytic?")

#emph[#text("[Yes; this follows for instance from the Poisson kernel representation, or from viewing harmonic functions locally as real parts of holomorphic functions. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607657")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("Yep! This follows by taking the real part of the power series expansions for ")#mi("u+iv")#text(", with ")#mi("v")#text(" a local harmonic conjugates. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("Typo in the proof of Morera’s theorem?")

#emph[#linebreak()#text(" … so by Corollary 20, ")#mi("{F}")#text(" is smooth, which implies in particular that ")#mi("{f^{\\prime} = F}")#text(" is holomorphic on ")#mi("{U}")#text(" as claimed.")#linebreak()#text(" ")]

#text("Seems more accurate to say that")

#text("… so by Corollary 20, ")#mi("{F^{\\prime}}")#text(" is holomorphic , which implies in particular that ")#mi("{F^{\\prime} = f}")#text(" is holomorphic on ")#mi("{U}")#text(" as claimed.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-607812")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("I think there is a small typo in the statement of Lemma 41 (Homotopy invariance).")#linebreak()#text(" The last line should read ")#mi("W_{\\gamma_0} ( z_0) = W_{ \\gamma_1 } (z_0)")#text(".")

#emph[#text("[This seems to be what is actually written in the text – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-608143")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2020")])]

#text("Sorry my bad. I meant Corollary 42 (Rouche’s theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a hardy iota guy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-608892")[#strong[#text("a hardy iota guy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("I think adityaguharoy referred to Corollary 42 which is namely Rouche’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-612416")[#strong[#text("246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("[…] is the real part of . The claim now follows by applying the mean value property (Exercise 17 of 246A Notes 3) to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-621853")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("[…] function on the punctured disk. By the Riemann singularity removal theorem (Exercise 35 of 246A Notes 3) extends to be holomorphic on all of , and thus has a Taylor expansion for some coefficients […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Contour shifting | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-622305")[#strong[#text("Contour shifting | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] on complex analysis; for a broader discussion on Cauchy’s theorem and its consequences refer to this blogpost by prof. Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-622415")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("This post seems to be missing the tag math.CV")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-629802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2021")])]

#text("Correction in Exercise 3 (iv) – I think we need the hypothesis that U is connected because a closed curve cannot be homotopic to a point in another component as we demand the range of the deformation to be connected.")

#emph[#text("[The point is permitted to depend on ")#mi("\\gamma_0")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-634691")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Previous set of notes: Notes 1. Next set of notes: Notes 3. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Kowalski")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-636604")[#strong[#text("Matt Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2021")])]

#text("It seems like there’s an error with the box containing exercise 37. The box does not stop at the end of the exercise and instead continues down to contain the remainder of the post.")

#text("Also, I’m loving these notes.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b33f88ce7a64bf045d6c4a082811fd57c1b12e27a69486699a66e80cbcdbc544-d3c9315889c5b63c0dca829a487d67dcb63b7d473ddbb2a772499911c923906f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddharth M")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-636732")[#strong[#text("Siddharth M")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2021")])]

#text("In Exercise 47 I think the ds term should be inside the bracket on the numerator of the expression")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-639594")[#strong[#text("Teorema de la curva de Jordan, prueba del profesor Tao - TopRespuestas")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2022")]

#text("[…] Math 246A, Notes 3: Cauchy’s theorem and its consequences […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-643327")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2022")])]

#text("How different is a closed curve from a 1-cycle in Exercise 15? Are they essentially the same but defined in two different languages?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-643329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2022")])]

#text("1-cycle is a closed curve. But closed curve doesn’t have to be a 1-cycle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-643370")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2022")])]

#text("A 1-cycle can be decomposed as a (formal) integer linear combination of closed curves (which need not intersect each other). For instance, the sum of two disjoint oriented circles would be a 1-cycle, but not a closed curve.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-685564")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2024")])]

#text("Why is Corollary 25 (analytic continuation) a “Corollary” of Theorem 17 (Cauchy integral formula)? It seems that Theorem 17 is not used in its proof. And Corollary 25 is a direct consequence of Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-685587")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2024")])]

#text("Ah, the above was a dumb one. I missed that analyticity of holomorphic functions (Corollary 20) is used in the proof; in this set of notes, it is not used as a definition for being holomorphic.")

#text("I’m wondering though, if at the beginning one changes the definition of “holormophic” as having the Taylor series expansion, which theorem(s) in this section would be much more troublesome.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-688430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2025")])]

#text("I was wondering whether you could elaborate further in the hint of Exercise 61. In particular, why is the set of interior points connected to $z_0$ by a line segment in the interior a connected component of the interior of the curve? This set is clearly open (even in the non-convex case.) It remains to show that it is relatively closed to the interior.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-689585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2026")])]

#text("Dr. Tao,")

#text("It seems that “continously” should be continuously. ")#emph[#text("[Corrected, thanks – T.]")]

#text("I would like to ask: Why is the fundamental theorem of algebra related to “algebra” rather than “analysis” or something else? Does this theorem convey any core ideas in algebra?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-689586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2026")])]

#text("The fundamental theorem of algebra establishes that the complex numbers are ")#link("https://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed")]#text(" as a field. The name is perhaps a historical artefact from a time when the complex numbers were considered one of the most important fields to study in algebra (and the main example of an algebraically closed field); modern algebra has broadened significantly since then (with complex analytic methods, while still relevant, less central to modern algebraic geometry in particular), and so the theorem is not as fundamental to the modern subject. Still, we retain the traditional name as there is no strong incentive to rename it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-692274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2026")])]

#text("In the proof of Theorem 17, ”Applying Exercise 17(v)..” should be ”Applying Exercise 18(v)..”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-694096")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("Although Liouville’s theorem is not as intuitive as the Fundamental Theorem of Algebra, this derivation is not difficult to understand. However, why do people say that essentially all proofs of the Fundamental Theorem of Algebra make use of topological structure? I feel like I cannot see what connection this approach has with topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-694122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Why are the proofs of the fundamental theorem of algebra related to topology or topological structure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-2/#comment-694125")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Most proofs of Liouville’s theorem require at some point the use of Cauchy’s theorem, whose proof involves the topological structure of the complex numbers.")

#text("Note that if the complex numbers are replaced by, say, the field ")#mi("{\\mathbb Q}[i]")#text(", then the fundamental theorem of algebra now fails, so any proof of that theorem must use some property of ")#mi("{\\mathbb C}")#text(" that does not hold for ")#mi("{\\mathbb Q}[i]")#text(". Metric or topological properties, such as local compactness, connectness, or completeness, are natural candidates for such a distinguishing property.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("In the first line of remark 19, it seems clearer to add “of ")#mi("\\mathbb C")#text("” after “open set ")#mi("U")#text("“.")

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("It seems that corollary 24, implies a stronger version of 23 in which ")#mi("f=g")#text(" on a subset of ")#mi("U")#text(" which has an accumulation point (because the difference ")#mi("f-g")#text(" has an accumulation point of zeros, hence by corollary 24 should vanish identically on ")#mi("U")#text(").")

#emph[#text("[Remark to this effect added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("In theorem 34, it seems that the uniform convergence assumption can be relaxed (using the same proof!) to uniform convergence on compact subsets of ")#mi("U")#text(" (i.e. locally uniform convergence).")

#emph[#text("[Fair enough; I’ve reworded the theorem and proof accordingly -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("In exercise 17, property (i) implies (via its application to an appropriate rotation of ")#mi("f")#text(") a stronger version of the maximum principle (that ")#tao-math("\\left|f\\right|", block: false)#text(" has no local maximum unless ")#mi("f")#text(" is constant). Similarly, property (ii) implies that ")#mi("u")#text(" has no local minimum or maximum unless it is constant.")

#emph[#text("[Extended the exercise to reflect a version of this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("In cases (iii), (iv) of definition 1, it seems clearer to add “of ")#mi("\\gamma_3")#text("” at the end.")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("Definition 1(ii), last line should be {\\gamma(s,0) =z_0, \\gamma(s,1) = z_1}.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a8462a72448fe14b69159dccf4634697b80132d3799acbb7467dddc3a6ec8cf-974182dc6a4ce67ea9f5746954ed2a0b06495030cd8473ef785e7fb4cd8b1643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("In theorem 15 cauchy integral formula( special case)")

#text("As {f} is complex differentiable at {z_0}, there exists a finite {M} such that")

#text("Shouldn’t it be( f(z)-f(zo) /(z-zo)) – f'(z) <=M")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Gubkin")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472827")[#strong[#text("Steven Gubkin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("Since the integral of ")#mi("1/z dz")#text(" about the unit circle is (perhaps) the most important computation in complex analysis, I think it is worthwhile seeing the computation done in a few ways. I think, in addition to the direct computation, it is valuable to see the computation done using branches of the logarithm.")

#text("Namely, ")#mi("1/z dz")#text(" has no global antiderivative, but it does have an antiderivative on ")#mi("\\mathbb{C}")#text(" minus the positive imaginary axis, and on ")#mi("\\mathbb{C}")#text(" minus the negative imaginary axis. We can then break our computation of the integral about the circle into a sum of integrals about the top and bottom hemisphere. On each hemisphere we can use the fundamental theorem of calculus. Use the corresponding branch of the logarithm to see that each contributes a sum of ")#mi("\\pi i")#text(" to the integral. So the total integral is ")#mi("2 \\pi i")#text(".")

#emph[#text("[I plan to return to this point in later notes when discussing branch cuts of multi-valued functions – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Gubkin")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472828")[#strong[#text("Steven Gubkin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("Another approach to the same integral is to realize that ")#mi("1/z = \\bar{z}")#text(" on the unit circle. So")

#mi("\\displaystyle \\begin{array}{ll} \\int_{C(0,1)} \\frac{1}{z} d z &= \\int_{C(0,1)} \\bar{z} d z \\\\ & = \\int_{D(0,1)} d( \\bar{z}) d z \\\\  &= \\int_{D(0,1)} \\frac{\\partial \\bar{z}}{ \\partial z} dz \\wedge dz + \\frac{\\partial \\bar{z}}{\\partial \\bar{z}} d\\bar{z} \\wedge dz \\\\ &= \\int_{D(0,1)} 1 d\\bar{z} \\wedge dz\\\\ &= 2i \\int_{D(0,1)} dx \\wedge dy \\\\&= 2\\pi i \\end{array}")

#text("Here I have used Stoke’s theorem on line 2, and on line 5 I used the fact that ")#mi("d\\bar{z} \\wedge d z = 2i d x \\wedge d y")#text(".")

#text("It is interesting to me that these two computations get the “")#mi("\\pi")#text("” in two different ways: as arising from the circumference and area of the unit circle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("In corollary 22, it may be added that ")#mi("g(z)")#text(" is uniquely determined (even under the requirement of being merely continuous at ")#mi("z_0")#text(").")

#emph[#text("[Fair enough – the corollary has been amended to reflect this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("The links in exercise 17(i),(ii) are not working.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("In the proof of theorem 15, in line 7 it should be “sufficiently small ")#mi("\\epsilon")#text("” (instead of ")#mi("M")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472894")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("For a small enough square ")#mi("f(z) = f(z_0) + f^{\\prime}(z_0)(z - z_0)")#text(" and that’s good enough. And we can do ")#mi("\\oint f(z) \\, dz")#text(" by adding over the sides of all the squares and the squares cancel out.")

#text("$")#mi("\\oint f(z) \\, dz \\approx \\frac{1-i}{\\sqrt{2} }\\big{\\left[ f(z_0 + 1dz)  + i\\,f(z_0 + idz) - f(z_0 - 1dz)  -i\\, f(z_0 - idz) \\right]}")#text("$")

#text("I dunno that looks pretty good to me :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a8462a72448fe14b69159dccf4634697b80132d3799acbb7467dddc3a6ec8cf-974182dc6a4ce67ea9f5746954ed2a0b06495030cd8473ef785e7fb4cd8b1643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("The remark which goes after cauchy’s integral theorem proof")

#text("“One nice feature of Cauchy’s theorem is that it allows one to integrate holomorphic functions on curves that are not necessarily rectifiable”")

#text("And then gamma is given to be a contour in U")#linebreak()#text(" Then cauchy integral for non rectifiable curve gamma is defined")

#text("I am not really sure, but I think gamma should be defined as just a curve in U as any contour is rectifiable")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0106b5b3b4220551d528effb7047e2847ee8eff5796baae2bdb6ef3b9cc1e34d-d8beca2a46c8f693035eb0d053f9445245c8bf0c9766a3ed73f405e701740214.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2016")])]

#text("Something seems to have gone wrong in the latex of exercise 54.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2016")])]

#text("for the definition of homotopy, since the interval for curves are [a,b], so the endpoint should be ")#mi("\\gamma(s,a)=\\gamma(s,b)")#text(", that’s for (ii), for (i), the same.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2016")])]

#text("In the first diagram below exercise 37, the notion of “real analytic” is not defined.")

#emph[#text("[See Remark 19 – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2016")])]

#text("I meant that this notion is mentioned without definition (also in remark 19).")#linebreak()#text(" Perhaps a short definition (e.g. local representation by power series on real intervals) can make it clearer.")

#emph[#text("[Short definition added to Remark 19. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ecf449b2cd500d065caee1d1a5ec3006aa46b9d529b858bd7b4654a49d5b1c9-87e1c647dad8ae3461bd5685912399fe80b92209bc3a3b80d2f8e970a0f04193.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-472959")[#strong[#text("h")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2016")])]

#text("FYI The article “Timothy Gowers – Elsevier — my part in its downfall” that linked to on the left column of your blog seems to have been removed by Gowers.")

#text("Does that mean Elsevier is not so bad now?")

#emph[#text("[The link seems to be working fine for me – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("If ")#mi("\\gamma")#text(" is any curve with image ")#mi("\\Gamma")#text(" in some open set ")#mi("U \\subset \\mathbb C")#text(", is there a complex measure ")#mi("\\mu")#text(" (depended only on ")#mi("\\gamma")#text(") over ")#mi("\\Gamma")#text(" such that ")#mi("\\int_{\\Gamma} f d\\mu = \\int_{\\gamma} f(z) dz")#text(" for all functions ")#mi("f")#text(" which are analytic on ")#mi("U")#text("?")

#text("If such a measure ")#mi("\\mu")#text(" exist, it can be used to extend the integral over ")#mi("\\gamma")#text(" to the larger class of ")#mi("\\mu")#text("-measurable functions.")

#emph[#text("[For rectifiable curves, such a measure can be constructed by the Riesz representation theorem. Perhaps there is a Hahn-Banach type construction to produce such a measure in the non-rectifiable case, but it might not be unique. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math 246A, Notes 4: singularities of holomorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473174")[#strong[#text("Math 246A, Notes 4: singularities of holomorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("[…] the previous set of notes we saw that functions that were holomorphic on an open set enjoyed a large number of useful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("As stated, 49 (iii) seems incorrect. Imagine $\\gamma_2$ being a concentric circle with $\\gamma_1$, having a larger radius.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473179")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("After Theorem 34, I think it’s worth noting that even for notions of “convergence on average” such as ")#mi("L^p")#text(" or ")#mi("L^p_\\textrm{loc}")#text(", the limit of a sequence of holomophic functions is holomorphic because one can average Cauchy’s integral formula over an annulus to obtain a kernel which is absolutely continuous with respect to Lebesgue measure.")

#emph[#text("[Added a remark to this effect – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 5: conformal mapping | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473439")[#strong[#text("246A, Notes 5: conformal mapping | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("[…] then on any ball in , is the real part of some holomorphic function thanks to Exercise 62 of Notes 3. By part (ii), is also holomorphic. Taking real parts we see that is harmonic on each ball in , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43461d2987e1377f3702bd3cf3ed1e4429a43c8567c5b942b9ebd364de8b617c-9343215deec22371721a675baed289303a24ec0437857aa5d67f435476e89cc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of snarfblaat")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473585")[#strong[#text("snarfblaat")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("exercise 17(iii)–what do ")#mi("s")#text(" and ")#mi("\\phi")#text(" refer to?")#linebreak()#text(" the short proof of cor.13–the references to the first and second fundamental theorems perhaps reversed?")#linebreak()#text(" exercise 12–")#mi("\\gamma")#text(" is I think a closed rectangle, but the sequence of vertices in ")#mi("\\gamma_{a+bi}...")#text(" doesn’t loop back")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0996e930df9acf8b66d8994927371037ddf21e9c389162e0409c5d5f83822aa-e52612203ce0231fde120158b7f82ba7275e20e10db477083125e1a2a3ef92e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Grad Lounge")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-473891")[#strong[#text("UCLA Math Grad Lounge")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2016")])]

#text("Exercise 3 iii) seems wrong to me. Taking U = C \\ {0,1}, wouldn’t this exercise show that conjugation on the free group with 2 elements is trivial?")

#emph[#text("[Oops, there is a conjugation missing in this exercise – fixed now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2017")])]

#text("In the second Euler diagram (the complex case), should “smooth” be in the same box as “analytic”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("No; for instance, the function ")#mi("z \\mapsto \\overline{z}")#text(" is smooth (in the real sense), but not (complex) analytic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Fair enough. I thought “smooth” means infinitely complex differentiable in this set of notes. It seems that one would never say “a smooth complex function” though.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")])]

#text("– According to the definition 1, is the figure ")#mi("8")#text(" considered as homotopic to a point?")

#text("– Is there a particular reason we need to consider “fixed-endpoints” homotopy instead of the general one that does not require the endpoints being fixed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478399")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("It depends on what domain ")#mi("U")#text(" one is working in. For instance, in a simply connected domain, all closed curves are homotopic to a point (including a figure ")#mi("8")#text(" in the domain). But if the domain has “holes” in one or both of the regions enclosed by this figure ")#mi("8")#text(", then this figure will not be homotopic to a point in that domain.")

#text("Homotopy without fixing the endpoints or requiring the curve to be closed is a rather trivial relation: see Exercise (vi). Related to this, Cauchy’s theorem (Theorem 4) is highly false if one allows the endpoints to vary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("Should ")#mi("\\gamma")#text(" be a closed curve in ")#mi("U")#text(" instead of ")#mi("{\\bf C}")#text(" in Theorem 39?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-478892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("It shows “Formula does not parse” now.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-479259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Typo in Exercise 36:")

#text("the function ")#mi("{z \\mapsto \\int_0^1 f(t,z)\\ dz}")

#text("dz->dt")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-479329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2017")])]

#text("In the proof of Corollary 22, all the three ")#mi("g")#text(" are with different domains while the third one is defined by “gluing” the first two together. (Might be clearer if one using the notations ")#mi("g_1,g_2")#text(" and ")#mi("g")#text(").")

#text("Would you elaborate what “Uniqueness at {z_0} follows from continuity.” means? (This is a little confusing. I guess it means the uniqueness at ")#mi("z_0")#text(" for the ")#mi("g")#text(" in the statement of the Corollary, not the first ")#mi("g")#text(" in the proof. )")

#emph[#text("[Reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-479330")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2017")])]

#text("In the proof of Corollary 23,")

#text("“by the continuity of the ")#mi("{f^{(n)}} {V}")#text(" is closed”")

#text("might be clearer if a comma is added:")

#text("“by the continuity of the ")#mi("{f^{(n)}}")#text(", ")#mi("{V}")#text(" is closed”")

#text("—")#linebreak()#text(" A remark on the “continuity method” could be added, again;-) ")#link("http://www.tricki.org/article/Use_the_continuity_method")[#text("http://www.tricki.org/article/Use_the_continuity_method")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-479331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2017")])]

#text("Regarding Corollary 24, can one define an analytic function ")#mi("f")#text(" on ")#mi("U")#text(" such that ")#mi("f")#text(" has zeros on a given infinite set of isolated points contained in ")#mi("U")#text(".")

#emph[#text("[If the set of points is closed, then yes: see ")#link("http://mathworld.wolfram.com/WeierstrassProductTheorem.html")[#text("http://mathworld.wolfram.com/WeierstrassProductTheorem.html")]#text(" -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-481927")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] Math 246A, Notes 3: Cauchy’s theorem and its consequences […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-486656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2017")])]

#text("In Exercise 36: Shouldn’t $f(t, z)$ be integrated over $dt$ instead of $dz$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-488179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("I have some dumb questions for Remark 16.")

#text("In Stein-Shakarchi Chapter 2, the keyhole contour is used for proving the Cauchy integral formula. But I’m quite uncomfortable with a hand-waving argument in their proof:")

#text("“use the continuity of F to see that in the limit, the integrals over the two sides of the corridor cancel out.”")

#text("How would you turn this into a rigorous estimate?")

#text("(In general, how often do you allow hand-waving arguments in your notes? )")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-488181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("The above ")#mi("F")#text(" is defined as")#linebreak()#text(" ")#mi("\\displaystyle F(\\zeta)=f(\\zeta)/(\\zeta-z)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-488183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("In this particular case, this is not difficult; one simply parameterises both sides of the corridor to turn the integral into a Riemann (or Lebesgue) integral and then uses one of the standard convergence theorems (dominated convergence will certainly work, though this is overkill here since one in fact has uniform convergence).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-488620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2017")])]

#text("As I understand, this set of notes make the “minimum” assumption (being “rectifiable”) of a curve on which one wants to do complex integration. On the other hand, lots of the complex analysis textbooks (such as Stein-Shakarchi) make the stronger assumption that the curve is piecewise (infinitely) differentiable.")

#text("What could be a big picture in practice that (1) when one needs the full power of full generality; (2) when one would be OK with only the piecewise differentiable curves?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-490953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("Is the real line on the complex plane considered as a “closed” contour? How does one get a version of Cauchy integral formula for this one? For instance")#linebreak()#text(" ")#mi("\\displaystyle \\frac{1}{2\\pi i}\\int_{\\bf R} \\frac{f(y)}{y-(x+i\\epsilon)}\\ dy=f(x+i\\epsilon)\\ ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-490962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("The real line is not a closed contour in the complex plane, though if one can extend the ")#mi("(1,0)")#text("-form ")#mi("f(z)\\ dz")#text(" holomorphically to the Riemann sphere then the extended real line becomes a closed contour that one can integrate the form on. In practice, one can often use the Cauchy integral formula to integrate on the real line by working with a large semicircular contour and sending the radius to infinity, but care must be taken in ensuring that the contribution of the semicircular arc becomes negligible in the limit. To this end, tools such as ")#link("https://en.wikipedia.org/wiki/Jordan%27s_lemma")[#text("Jordan’s lemma")]#text(" are often employed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-490991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2017")])]

#text("What decay bound should ")#mi("f")#text(" obey so that Jordan’s lemma can be applied in the above example? In your lecture notes on Hilbert transform: ")#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.pdf")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.pdf")]#text(", you suggest that ")#mi("O_f(\\langle z\\rangle^{-1})")#text(" would be enough. But it seems that one cannot get")#linebreak()#text(" ")#tao-math("\\displaystyle \\lim_{R\\to\\infty}\\max_{\\theta\\in[0,\\pi]} \\left|\\frac{f(Re^{i\\theta})}{Re^{i\\theta}-(x+i\\epsilon)}\\right|=0", block: false)#linebreak()#text(" here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-490993")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2017")])]

#text("For arbitrary ")#mi("f")#text(" (which does not have a good analytic continuation to the upper half-plane), one does not expect to have this formula. Instead, one has the Plemelj formulae for general (and reasonably smooth and decaying) ")#mi("f")#text(": ")#link("https://en.wikipedia.org/wiki/Sokhotski%E2%80%93Plemelj_theorem")[#text("https://en.wikipedia.org/wiki/Sokhotski%E2%80%93Plemelj_theorem")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4294b54e396dbfa48e112dc1db704efb122a82f89a2f16f08add9851aad67897-84819578779a9b73450e4652596ba6db5907740a56a60b24ff5dc04d7822b5c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuhoL")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-492798")[#strong[#text("JuhoL")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Dear Terence.")

#text("Don’t you find it odd that the Goursat’s theorem takes such an “odd” proof? I mean that the most obvious guess might be to have a triangle (or rectangle) that is null-homotopic curve (t=1 is triangle and t=0 is a point inside the triangle) and show that the derivate of the integral in question with respect to homotopy parameter t is zero and then infer that the value of the integral is independent of t and it must be zero since the case t=0 is clearly zero.")

#text("But apparently this method is a dead-end since no-one has published it. Maybe that assumption of non-continuous derivative requires some deeper tricks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-492827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("One can certainly do this if one assumes enough regularity to be able to differentiate under the integral sign, and similar methods are used to establish conservation laws or monotonicity formulae in PDE or geometry. But as you say, it is the lack of continuity of derivative that forces one to move away from the most natural (but regularity-intensive) techniques and towards the proof by contradiction style of proof given here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4294b54e396dbfa48e112dc1db704efb122a82f89a2f16f08add9851aad67897-84819578779a9b73450e4652596ba6db5907740a56a60b24ff5dc04d7822b5c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuhoL")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-492847")[#strong[#text("JuhoL")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("Thanks for reply!")

#text("I had the following idea for the case of rectangle R. If we simply divide horizontal and vertical sides into n equal pieces we have a nice grid of similar subrectangles. And when we increase the number n, then it’s clear that every subrectangle R_i is inside a small neighbourhood of _some_ point z_i in R and we can estimate the integral over a subrectangle R_i with the error term E_i (z) of that neighbourhood of z_i (same estimate for every index i due to geometric construction of the grid). Since the integral over R is equal to the sum of integrals over all subrectangles we can use triangle inequality and have the same conclusion like with Goursat’s method.")

#text("This would be a student friendly direct geometric method that clearly indicates why we must assume derivative everywhere in R, and also it removes that annoying topological argument.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-496089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Hi, Pro Tao. In exercise 3 (iii), I meet some troubles. How to prove that if two closed curves with same initial point are homotopic as closed curves than they must be homotopic with fixed end points？ I know nothing about algebraic topology，so I just try to construct a continuous function by known homotopic function h in condition, but I find it impossible to construct a continuous function meet those condition just by transform the two parameters of the known homotopic function h. However, I don’t know how to construct it outside the function h because I just know that the image of h is in the set U, if I do some operation on the image of U, I can’t sure that it’s still in set U . So, is it impossible to prove that without any knowledge about algebraic topology? How to do it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("No advanced algebraic topology is required for this exercise, and no transformations on ")#mi("U")#text(" are necessary. One can form both the curve ")#mi("\\gamma_2")#text(" and the required endpoint-fixing homotopy in terms of the original closed curve homotopy ")#mi("\\gamma: [0,1] \\times [a,b] \\to U")#text(". (The new homotopy will be sort of a concatenation of the original homotopy and a map that traverses a portion of ")#mi("\\gamma_2")#text(". Drawing a picture of the various stages of the original homotopy will help suggest how to form ")#mi("\\gamma_2")#text(" and the new homotopy.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Pro Tao, I have a question about your proof of cauchy’s theorem in the form of theorem 4(under the corollary 13).")#linebreak()#text(" “However, from a further application of Corollary 11 we have")

#text("∫_(γ_((0,t_(i-1) ) )→γ_(0,t_i ))^ ▒f(z)dz=∫_(γ_(0,[t_(i-1),t_i]))^ ▒f(z)dz ”")#linebreak()#text(" Here, Corollary 11 is established on polygonal closed curve, but the restriction of γ to [t_(i-1),t_i] is not necessarily polygonal. So this equality requires that for any closed curve the integral should be zero. And for this result, we should have the condition that curve is rectifiable, because we need the length to scaling |∫_γ^ ▒f(z)dz-∫_p^ ▒f(z)dz| where γ is the closed curve and p is the polygonal approximation to γ. So I think the condition that rectifiable curve is necessary in Cauchy’s integral theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("This was a typo; it should have referred to Corollary 13 rather than Corollary 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("If use corollary 13, the condition γ is rectifiable is necessary, but after this proof you say that the condition γ is rectifiable isn’t required, so extend holomorphic function’s integral to unrectifiable curve. I think the condition rectifiable is necessary in the proof, so we can’t extend the notion of integral to unrectifiable curve. am I right? or I miss some key point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("After Corollary 13, the notion of a contour integral is extended, by defining the integral ")#mi("\\int_\\gamma f(z)\\ dz")#text(" for any curve (rectifiable or not) to equal ")#mi("\\int_{\\tilde \\gamma} f(z)\\ dz")#text(", where ")#mi("\\tilde \\gamma")#text(" is a rectifiable curve homotopic to ")#mi("\\gamma")#text(". Cauchy’s theorem for rectifiable curves ensures that this definition is well defined, and once we have this definition, it is then trivially true that Cauchy’s theorem is also true for non-rectifiable curves (because any non-rectifiable curve is homotopic to a rectifiable one).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-497701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("Thanks for your reply. I think I get your meaning. Thanks a lot.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/438134cd99874f00e7cb400db9152ec391db8ffd631ce9fd643628c6bdb95ee1-b35a11a7b0a604e80c68ea4ea68aabf507d9b0dfc5dc47ed281f5eacd5c6cf12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriele Cassese")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-515847")[#strong[#text("Gabriele Cassese")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Professor Tao, thanks to Corollary 13 you coherently extend the definition of contour integral to any continuous curve, if the function integrated is holomorphic. Is it possible to do something similar in real analysis, perhaps with the costraint that the function integrated is analytic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-515853")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("One can integrate any closed 1-form on a continuous curve on a manifold by a similar procedure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-578472")[#strong[#text("Math Genius: Jordan Curve Theorem, Professor Tao's proof - TECHPRPR")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2020")]

#text("[…] ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-597797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2020")])]

#text("At the beginning of Chapter 2 of Stein-Shakarchi, it is mentioned that “A precise and general formulation of Cauchy’s theorem requires defining unambiguously the ‘interior’ of a curve,…”")

#text("In Theorem 4, using homotopic rectifiable curves, it seems that one does not need the notion of the “interior of a curve”. Is it implicitly substituted by something equivalent somewhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-597941")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("One way of viewing this is to ask for, instead of the ‘interior of a curve’ per se, a nullhomotopy of the closed curve inside of the domain of the holomorphic function. On one hand, a nullhomotopy of a simple closed curve is more-or-less equivalent to a disk bounded by the curve (here playing the role of the ‘interior’); on the other hand, by Cauchy’s theorem, the value of the integral stays constant as the curve varies (as long as the intermediate curves are regular enough for the integral to make sense), and since holomorphic functions are in particular continuous the integral over small curves limits to 0. – Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-597994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("The version of Cauchy’s theorem alluded to in Stein-Shakarchi appears as Theorem 52(i) in this current set of notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-603265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("Could you sketch briefly how one can use Theorem 48 to prove Theorem 52?")

#text("(Even for 52(i), how does one relate ")#mi("\\int_\\gamma f(z)dz")#text(" with ")#mi("\\frac{1}{2\\pi i}\\int_\\gamma \\frac{1}{z-z_0} dz")#text(" for some ")#mi("z_0")#text(" in the exterior of ")#mi("\\gamma")#text("? )")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-598054")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("Isn’t this proof of Goursat’s theorem (via contradiction) somewhat in the same league of proofs as that of Heine Borel theorem (the part which proves that a closed and bounded subset of ")#mi("\\mathbf{R}^n")#text(" is compact in the sense of having finite subcovers for every cover). We prove it via contradiction taking a nested set of “bad” sets (in case of Goursat’s we take a nested sequence of “bad” triangles), and then use Cauchy property to get a limit point and obtain a contradiction ?")

#emph[#text("[Yes; Exercise 10 is meant to reinforce this connection – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cauchy's integral theorem")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599031")[#strong[#text("cauchy's integral theorem")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2020")])]

#text("Cauchy’s integral theorem: why is it true that if a function is locally linear, then the integral over the contour goes to zero by the fundamental theorem of calculus? It would be true only if the end points of the contour are the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2020")])]

#text("This remark applies to versions of Cauchy’s theorem that involve closed contours, such as Corollary 5.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2020")])]

#text("In the proof of Corollary 22, is it critical that the intersection of the domains of two different versions ")#mi("g")#text(" is open? If one has, say, two analytic functions ")#mi("g_1")#text(" and ")#mi("g_2")#text(" with domains ")#mi("D_1")#text(" and ")#mi("D_2")#text(" such that ")#mi("D_1\\cap D_2")#text(" only consists of one point, (or more general being a closed set), where ")#mi("g_1")#text(" and ")#mi("g_2")#text(" agree. Can one still “glue” them together to get an analytic function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599110")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2020")])]

#text("The notion of analyticity is not defined for non-open sets. Note though that other notions of regularity do not glue along non-open sets; for instance if one glues together smooth functions along a non-open set one typically only obtains a piecewise smooth function rather than a smooth function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599619")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("Prof. Tao: I have a question about Exercise 10 “Find a proof of Goursat’s theorem that avoids explicit use of proof by contradiction.” The proof of Goursat’s theorem in Stein-Shakarchi (Chapter 2, Theorem 1.1, pp. 34-36) is very similar to your proof but has no apparent use of proof by contradiction. (The only use of proof by contradiction I can detect in that proof is the pigeonhole principle.) Would you consider that proof as an acceptable solution to Exercise 10, or does Exercise 10 require a completely different approach? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("See comment by adityaguharoy earlier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599961")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("Technically this does conceal the use of proof by contradiction; but you are still encouraged to seek other proofs that disguise the use of contradiction further (for instance, hiding it inside the Heine-Borel theorem). (There is the interesting question of whether one can avoid proof by contradiction completely and give an ")#link("https://en.wikipedia.org/wiki/Intuitionistic_logic")[#text("intuitionistic proof")]#text(" of Goursat’s theorem; I suspect the answer is “no”, at least using standard formulations of the hypotheses and definitions in the theorem, but do not know of literature on this.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599624")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("As we can see from the analytic continuation for holomorphic functions every harmonic function in this setting turns out to be holomorphic (since for each harmonic function we can find a harmonic conjugate which makes it the real part of a holomorphic function; and if two functions agree their real parts must also agree).")#linebreak()#text(" But is there something known about those functions which obey analytic continuation?")#linebreak()#text(" For example some weaker criteria which if satisfied by a function implies that the function has the analytic continuation property?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("Unique continuation is a property of ")#emph[#text("classes")]#text(" of functions; it is meaningless to ask whether an individual function “has unique continuation” or not. There are a number of unique continuation theorems regarding the class of functions solving an elliptic and parabolic equations (and, to a lesser extent, functions solving hyperbolic equations, though in the latter case the nature of unique continuation is often limited by causality and/or finite speed of propagation). Things are primarily determined by the geometry of the principal symbol the elliptic or parabolic operator in question, and the main technical tools needed to establish these results in general contexts are Carleman inequalities. The subject is rather complicated though (Hormander’s books have a classic treatment of the topic, I am not sure what more modern references to recommend here).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-600040")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("Thank you sir! Now I am able to get more close to what I was asking for actually.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-600573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("Hello,")

#text("Could I ask what you mean by causality for hyperbolic equations here?")

#text("I can see how finite speed of propagation limits the ability to analytically continue; if any continuation can occur, it can only occur in a bounded region of spacetime if only a bounded amount of time has elapsed.")

#text("Are unique continuation theorems true to a lesser extent for hyperbolic equations essentially just because Carleman estimates are harder to establish for them?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c354172d0692d35b6eebd4a914c6111f91cca0adc5af80f45a5f787514d3da2-feb52201bc36c83a9a2e58ee85de1e4645bf57b022c0b135b33839bb9c542a49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paul miller")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-599906")[#strong[#text("paul miller")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("change of time zone in the UK (and my own stupidity) meant that i missed monday and today’s lecture. i dont suppose anyone could send me a recording of those two could they – ")#link("mailto:twisted.instigator@gmail.com")[#text("twisted.instigator@gmail.com")]#text(". sorry and thank you – paul miller")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-600041")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("If I am not wrong, recordings are not available for non UCLA students (as per UCLA privacy statement). But if you are a UCLA student, I think you will have access to all the recordings and hence in particular these ones (being said that I am not a UCLA student and so I don’t know how the thing actually works).")#linebreak()#text(" You can read about this at ")#link("https://ccle.ucla.edu/mod/page/view.php?id=3173126")[#text("https://ccle.ucla.edu/mod/page/view.php?id=3173126")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-600141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("What is an example of two curves that are NOT homotopic with fixed endpoints in U but are homotopic with fixed endpoints up to reparameterisation in U?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/comment-page-1/#comment-600525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("For instance the curve ")#mi("\\gamma_0: [0,1] \\to {\\bf C}")#text(" defined by ")#mi("\\gamma_0(t) := t")#text(" and the curve ")#mi("\\gamma_1: [0,2] \\to {\\bf C}")#text(" defined by ")#mi("\\gamma_1(t) := t/2")#text(" are homotopic with fixed endpoints in ")#mi("{\\bf C}")#text(" after reparameterisation, but not without reparameterisation (as the time intervals of definition are different). If the time intervals agree then one can check that the two notions are in fact equivalent; this basically follows from Exercise 3(vii).")
]
]
