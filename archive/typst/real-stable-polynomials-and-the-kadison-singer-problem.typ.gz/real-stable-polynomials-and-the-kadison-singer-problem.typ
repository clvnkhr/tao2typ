// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:50.380067+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Real stable polynomials and the Kadison-Singer problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Real stable polynomials and the Kadison-Singer problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 November 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/")[#text("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the basic tools in modern combinatorics is the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(", introduced by Erdos, in which a deterministic solution to a given problem is shown to exist by constructing a ")#emph[#text("random")]#text(" candidate for a solution, and showing that this candidate solves all the requirements of the problem with positive probability. When the problem requires a real-valued statistic ")#mi("{X}")#text(" to be suitably large or suitably small, the following trivial observation is often employed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Comparison with mean)")]#text(" ")#metadata(none) <tao-9ad23e8d5208067d25ea>#text(" Let ")#mi("{X}")#text(" be a random real-valued variable, whose mean (or ")#emph[#text("first moment")]#text(") ")#mi("{\\mathop{\\bf E} X}")#text(" is finite. Then")

#align(center)[#tao-fit-display[#mitex("X \\leq \\mathop{\\bf E} X")]]

#text("with positive probability, and")

#align(center)[#tao-fit-display[#mitex("X \\geq \\mathop{\\bf E} X")]]

#text("with positive probability.")
]

#text("This proposition is usually applied in conjunction with a computation of the first moment ")#mi("{\\mathop{\\bf E} X}")#text(", in which case this version of the probabilistic method becomes an instance of the ")#emph[#text("first moment method")]#text(". (For comparison with other moment methods, such as the second moment method, exponential moment method, and zeroth moment method, see Chapter 1 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(". For a general discussion of the probabilistic method, see ")#link("http://www.ams.org/mathscinet-getitem?mr=2437651")[#text("the book by Alon and Spencer")]#text(" of the same name.)")

#text("As a typical example in random matrix theory, if one wanted to understand how small or how large the operator norm ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" of a random matrix ")#mi("{A}")#text(" could be, one might first try to compute the expected operator norm ")#tao-math("{\\mathop{\\bf E} \\left\\|A\\right\\|_{op}}", block: false)#text(" and then apply Proposition ")#link(<tao-9ad23e8d5208067d25ea>)[#text("1")]#text("; see ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("this previous blog post")]#text(" for examples of this strategy (and related strategies, based on comparing ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" with more tractable expressions such as the moments ")#mi("{\\text{tr} A^k}")#text("). (In this blog post, all matrices are complex-valued.)")

#text("Recently, ")#link("http://arxiv.org/abs/1306.3969")[#text("in their proof")]#text(" of the Kadison-Singer conjecture (and also in ")#link("http://arxiv.org/abs/1304.4132")[#text("their earlier paper")]#text(" on Ramanujan graphs), Marcus, Spielman, and Srivastava introduced an striking new variant of the first moment method, suited in particular for controlling the operator norm ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" of a Hermitian positive semi-definite matrix ")#mi("{A}")#text(". Such matrices have non-negative real eigenvalues, and so ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" in this case is just the largest eigenvalue ")#mi("{\\lambda_1(A)}")#text(" of ")#mi("{A}")#text(". Traditionally, one tries to control the eigenvalues through averaged statistics such as moments ")#mi("{\\text{tr} A^k = \\sum_i \\lambda_i(A)^k}")#text(" or Stieltjes transforms ")#mi("{\\text{tr} (A-z)^{-1} = \\sum_i (\\lambda_i(A)-z)^{-1}}")#text("; again, see ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("this previous blog post")]#text(". Here we use ")#mi("{z}")#text(" as short-hand for ")#mi("{zI_d}")#text(", where ")#mi("{I_d}")#text(" is the ")#mi("{d \\times d}")#text(" identity matrix. Marcus, Spielman, and Srivastava instead rely on the interpretation of the eigenvalues ")#mi("{\\lambda_i(A)}")#text(" of ")#mi("{A}")#text(" as the roots of the characteristic polynomial ")#mi("{p_A(z) := \\text{det}(z-A)}")#text(" of ")#mi("{A}")#text(", thus ")#metadata(none) <tao-057739efcab9a7780939>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|A\\right\\|_{op} = \\text{maxroot}( p_A )", block: true)]]

#text("where ")#mi("{\\text{maxroot}(p)}")#text(" is the largest real root of a non-zero polynomial ")#mi("{p}")#text(". (In our applications, we will only ever apply ")#mi("{\\text{maxroot}}")#text(" to polynomials that have at least one real root, but for sake of completeness let us set ")#mi("{\\text{maxroot}(p)=-\\infty}")#text(" if ")#mi("{p}")#text(" has no real roots.)")

#text("Prior to the work of Marcus, Spielman, and Srivastava, I think it is safe to say that the conventional wisdom in random matrix theory was that the representation ")#link(<tao-057739efcab9a7780939>)[#text("(1)")]#text(" of the operator norm ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" was not particularly useful, due to the highly non-linear nature of both the characteristic polynomial map ")#mi("{A \\mapsto p_A}")#text(" and the maximum root map ")#mi("{p \\mapsto \\text{maxroot}(p)}")#text(". (Although, as pointed out to me by Adam Marcus, some related ideas have occurred in graph theory rather than random matrix theory, for instance in the theory of the ")#link("http://en.wikipedia.org/wiki/Matching_polynomial")[#text("matching polynomial")]#text(" of a graph.) For instance, a fact as basic as the triangle inequality ")#tao-math("{\\left\\|A+B\\right\\|_{op} \\leq \\left\\|A\\right\\|_{op} + \\left\\|B\\right\\|_{op}}", block: false)#text(" is extremely difficult to establish through ")#link(<tao-057739efcab9a7780939>)[#text("(1)")]#text(". Nevertheless, it turns out that for certain special types of random matrices ")#mi("{A}")#text(" (particularly those in which a typical instance ")#mi("{A}")#text(" of this ensemble has a simple relationship to “adjacent” matrices in this ensemble), the polynomials ")#mi("{p_A}")#text(" enjoy an extremely rich structure (in particular, they lie in families of real ")#link("http://en.wikipedia.org/wiki/Stable_polynomial")[#text("stable polynomials")]#text(", and hence enjoy good combinatorial interlacing properties) that can be surprisingly useful. In particular, Marcus, Spielman, and Srivastava established the following nonlinear variant of Proposition ")#link(<tao-9ad23e8d5208067d25ea>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Comparison with mean)")]#text(" ")#metadata(none) <tao-8f10e3460cbb9c694509>#text(" Let ")#mi("{m,d \\geq 1}")#text(". Let ")#mi("{A}")#text(" be a random matrix, which is the sum ")#mi("{A = \\sum_{i=1}^m A_i}")#text(" of independent Hermitian rank one ")#mi("{d \\times d}")#text(" matrices ")#mi("{A_i}")#text(", each taking a finite number of values. Then")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}(p_A) \\leq \\text{maxroot}( \\mathop{\\bf E} p_A )")]]

#text("with positive probability, and")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}(p_A) \\geq \\text{maxroot}( \\mathop{\\bf E} p_A )")]]

#text("with positive probability.")
]

#text("We prove this proposition below the fold. The hypothesis that each ")#mi("{A_i}")#text(" only takes finitely many values is technical and can likely be relaxed substantially, but we will not need to do so here. Despite the superficial similarity with Proposition ")#link(<tao-9ad23e8d5208067d25ea>)[#text("1")]#text(", the proof of Proposition ")#link(<tao-8f10e3460cbb9c694509>)[#text("2")]#text(" is quite nonlinear; in particular, one needs the interlacing properties of real stable polynomials to proceed. Another key ingredient in the proof is the observation that while the determinant ")#mi("{\\text{det}(A)}")#text(" of a matrix ")#mi("{A}")#text(" generally behaves in a nonlinear fashion on the underlying matrix ")#mi("{A}")#text(", it becomes (affine-)linear when one considers rank one perturbations, and so ")#mi("{p_A}")#text(" depends in an affine-multilinear fashion on the ")#mi("{A_1,\\ldots,A_m}")#text(". More precisely, we have the following deterministic formula, also proven below the fold:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Deterministic multilinearisation formula)")]#text(" ")#metadata(none) <tao-cc74039fc0153214a9ca>#text(" Let ")#mi("{A}")#text(" be the sum of deterministic rank one ")#mi("{d \\times d}")#text(" matrices ")#mi("{A_1,\\ldots,A_m}")#text(". Then we have ")#metadata(none) <tao-95220649f7d73b138d2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("p_A(z) = \\mu[A_1,\\ldots,A_m](z)")]]

#text("for all ")#mi("{z \\in C}")#text(", where the ")#emph[#text("mixed characteristic polynomial")]#text(" ")#mi("{\\mu[A_1,\\ldots,A_m](z)}")#text(" of any ")#mi("{d \\times d}")#text(" matrices ")#mi("{A_1,\\ldots,A_m}")#text(" (not necessarily rank one) is given by the formula ")#metadata(none) <tao-2abdfa203fc5a0477cc8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mu[A_1,\\ldots,A_m](z)")]]

#align(center)[#tao-fit-display[#mitex("= (\\prod_{i=1}^m (1 - \\frac{\\partial}{\\partial z_i})) \\text{det}( z + \\sum_{i=1}^m z_i A_i ) |_{z_1=\\ldots=z_m=0}.")]]
]

#text("Among other things, this formula gives a useful representation of the mean characteristic polynomial ")#mi("{\\mathop{\\bf E} p_A}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Random multilinearisation formula)")]#text(" ")#metadata(none) <tao-3f8bf70e12c0c28c6919>#text(" Let ")#mi("{A}")#text(" be the sum of jointly independent rank one ")#mi("{d \\times d}")#text(" matrices ")#mi("{A_1,\\ldots,A_m}")#text(". Then we have ")#metadata(none) <tao-86737d7c14ad24d64327>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathop{\\bf E} p_A(z) = \\mu[ \\mathop{\\bf E} A_1, \\ldots, \\mathop{\\bf E} A_m ](z)")]]

#text("for all ")#mi("{z \\in {\\bf C}}")#text(".")
]

#emph[#text("Proof:")]#text(" For fixed ")#mi("{z}")#text(", the expression ")#mi("{\\text{det}( z + \\sum_{i=1}^m z_i A_i )}")#text(" is a polynomial combination of the ")#mi("{z_i A_i}")#text(", while the differential operator ")#mi("{(\\prod_{i=1}^m (1 - \\frac{\\partial}{\\partial z_i}))}")#text(" is a linear combination of differential operators ")#mi("{\\frac{\\partial^j}{\\partial z_{i_1} \\ldots \\partial z_{i_j}}}")#text(" for ")#mi("{1 \\leq i_1 < \\ldots < i_j \\leq d}")#text(". As a consequence, we may expand ")#link(<tao-2abdfa203fc5a0477cc8>)[#text("(3)")]#text(" as a linear combination of terms, each of which is a multilinear combination of ")#mi("{A_{i_1},\\ldots,A_{i_j}}")#text(" for some ")#mi("{1 \\leq i_1 < \\ldots < i_j \\leq d}")#text(". Taking expectations of both sides of ")#link(<tao-95220649f7d73b138d2d>)[#text("(2)")]#text(" and using the joint independence of the ")#mi("{A_i}")#text(", we obtain the claim. ")#mi("\\Box")

#text("In view of Proposition ")#link(<tao-8f10e3460cbb9c694509>)[#text("2")]#text(", we can now hope to control the operator norm ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" of certain special types of random matrices ")#mi("{A}")#text(" (and specifically, the sum of independent Hermitian positive semi-definite rank one matrices) by first controlling the mean ")#mi("{\\mathop{\\bf E} p_A}")#text(" of the random characteristic polynomial ")#mi("{p_A}")#text(". Pursuing this philosophy, Marcus, Spielman, and Srivastava establish the following result, which they then use to prove the Kadison-Singer conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Marcus-Spielman-Srivastava theorem)")]#text(" ")#metadata(none) <tao-4757cd0485c229575d68>#text(" Let ")#mi("{m,d \\geq 1}")#text(". Let ")#mi("{v_1,\\ldots,v_m \\in {\\bf C}^d}")#text(" be jointly independent random vectors in ")#mi("{{\\bf C}^d}")#text(", with each ")#mi("{v_i}")#text(" taking a finite number of values. Suppose that we have the normalisation")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\sum_{i=1}^m v_i v_i^* = 1")]]

#text("where we are using the convention that ")#mi("{1}")#text(" is the ")#mi("{d \\times d}")#text(" identity matrix ")#mi("{I_d}")#text(" whenever necessary. Suppose also that we have the smallness condition")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} \\left\\|v_i\\right\\|^2 \\leq \\varepsilon", block: true)]]

#text("for some ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{i=1,\\ldots,m}")#text(". Then one has ")#metadata(none) <tao-26d4563f2b6c4a5ec217>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\sum_{i=1}^m v_i v_i^* \\right\\|_{op} \\leq (1+\\sqrt{\\varepsilon})^2", block: true)]]

#text("with positive probability.")
]

#text("Note that the upper bound in ")#link(<tao-26d4563f2b6c4a5ec217>)[#text("(5)")]#text(" must be at least ")#mi("{1}")#text(" (by taking ")#mi("{v_i}")#text(" to be deterministic) and also must be at least ")#mi("{\\varepsilon}")#text(" (by taking the ")#mi("{v_i}")#text(" to always have magnitude at least ")#mi("{\\sqrt{\\varepsilon}}")#text("). Thus the bound in ")#link(<tao-26d4563f2b6c4a5ec217>)[#text("(5)")]#text(" is asymptotically tight both in the regime ")#mi("{\\varepsilon\\rightarrow 0}")#text(" and in the regime ")#mi("{\\varepsilon \\rightarrow \\infty}")#text("; the latter regime will be particularly useful for applications to Kadison-Singer. It should also be noted that if one uses more traditional random matrix theory methods (based on tools such as Proposition ")#link(<tao-9ad23e8d5208067d25ea>)[#text("1")]#text(", as well as more sophisticated variants of these tools, such as the concentration of measure results ")#link("http://www.ams.org/mathscinet-getitem?mr=1694526")[#text("of Rudelson")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1889969")[#text("Ahlswede-Winter")]#text("), one obtains a bound of ")#tao-math("{\\left\\| \\sum_{i=1}^m v_i v_i^* \\right\\|_{op} \\ll_\\varepsilon \\log d}", block: false)#text(" with high probability, which is insufficient for the application to the Kadison-Singer problem; see ")#link("http://arxiv.org/abs/math/0612070")[#text("this article of Tropp")]#text(". Thus, Theorem ")#link(<tao-4757cd0485c229575d68>)[#text("5")]#text(" obtains a sharper bound, at the cost of trading in “high probability” for “positive probability”.")

#text("In the paper of Marcus, Spielman and Srivastava, Theorem ")#link(<tao-4757cd0485c229575d68>)[#text("5")]#text(" is used to deduce a conjecture ")#mi("{KS_2}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2035401")[#text("of Weaver")]#text(", which was already known to imply the Kadison-Singer conjecture; actually, a slight modification of their argument gives the paving conjecture of Kadison and Singer, from which the original Kadison-Singer conjecture may be readily deduced. We give these implications below the fold. (See also this ")#link("http://arxiv.org/abs/math/0510024")[#text("survey article")]#text(" for some background on the Kadison-Singer problem.)")

#text("Let us now summarise how Theorem ")#link(<tao-4757cd0485c229575d68>)[#text("5")]#text(" is proven. In the spirit of ")#link("http://en.wikipedia.org/wiki/Semidefinite_programming")[#text("semi-definite programming")]#text(", we rephrase the above theorem in terms of the rank one Hermitian positive semi-definite matrices ")#mi("{A_i := v_iv_i^*}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Marcus-Spielman-Srivastava theorem again)")]#text(" ")#metadata(none) <tao-7e50b53f5c87a5b7cb04>#text(" Let ")#mi("{A_1,\\ldots,A_m}")#text(" be jointly independent random rank one Hermitian positive semi-definite ")#mi("{d \\times d}")#text(" matrices such that the sum ")#mi("{A :=\\sum_{i=1}^m A_i}")#text(" has mean")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} A = I_d")]]

#text("and such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\text{tr} A_i \\leq \\varepsilon")]]

#text("for some ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{i=1,\\ldots,m}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A \\right\\|_{op} \\leq (1+\\sqrt{\\varepsilon})^2", block: true)]]

#text("with positive probability.")
]

#text("In view of ")#link(<tao-057739efcab9a7780939>)[#text("(1)")]#text(" and Proposition ")#link(<tao-8f10e3460cbb9c694509>)[#text("2")]#text(", this theorem follows from the following control on the mean characteristic polynomial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Control of mean characteristic polynomial)")]#text(" ")#metadata(none) <tao-56365f389e9260ddaab9>#text(" Let ")#mi("{A_1,\\ldots,A_m}")#text(" be jointly independent random rank one Hermitian positive semi-definite ")#mi("{d \\times d}")#text(" matrices such that the sum ")#mi("{A :=\\sum_{i=1}^m A_i}")#text(" has mean")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} A = 1")]]

#text("and such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\text{tr} A_i \\leq \\varepsilon")]]

#text("for some ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{i=1,\\ldots,m}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}(\\mathop{\\bf E} p_A) \\leq (1 +\\sqrt{\\varepsilon})^2.")]]
]

#text("This result is proven using the multilinearisation formula (Corollary ")#link(<tao-3f8bf70e12c0c28c6919>)[#text("4")]#text(") and some convexity properties of real stable polynomials; we give the proof below the fold.")

#text("Thanks to Adam Marcus, Assaf Naor and Sorin Popa for many useful explanations on various aspects of the Kadison-Singer problem.")

#metadata(none) <tao-46cb668ba910626ee9dd>

#heading(level: 1)[#strong[#text(" — 1. Multilinearisation formula — ")]]

#text("In this section we prove Proposition ")#link(<tao-cc74039fc0153214a9ca>)[#text("3")]#text(". The key observation is a standard one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Determinant is linear with respect to rank one perturbations)")]#text(" ")#metadata(none) <tao-3f4146a1d0b5dac26562>#text(" Let ")#mi("{A, B}")#text(" be ")#mi("{d \\times d}")#text(" matrices, with ")#mi("{A}")#text(" rank one. Then the polynomial ")#mi("{t \\mapsto \\text{det}(B+tA)}")#text(" is affine-linear (i.e. it is of the form ")#mi("{t \\mapsto a_0 + a_1 t}")#text(" for some coefficients ")#mi("{a_0,a_1}")#text(").")
]

#emph[#text("Proof:")]#text(" When ")#mi("{B}")#text(" is the identity matrix, this follows from the ")#link("https://en.wikipedia.org/wiki/Weinstein%E2%80%93Aronszajn_identity")[#text("Weinsteinâ€“Aronszajn identity")]#text(" ")#mi("{\\text{det}(1 + XY) = \\text{det}(1+YX)}")#text(", which shows in particular that ")#mi("{\\text{det}(1 + t u v^*) = 1 + t v^* u}")#text(" for any rank one matrix ")#mi("{uv^*}")#text(". As the determinant is multiplicative, the claim then follows when ")#mi("{B}")#text(" is any invertible matrix; as the invertible matrices are dense in the space of all matrices, we conclude the general case of the lemma. (One can also prove this lemma via cofactor expansion, after changing variables to make ")#mi("{u}")#text(" or ")#mi("{v}")#text(" a basis vector.) ")#mi("\\Box")

#text("Iterating this, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9 (Determinant is multilinear with respect to rank one perturbations)")]#text(" ")#metadata(none) <tao-889aa88533454fe3d7b5>#text(" Let ")#mi("{A_1,\\ldots,A_m,B}")#text(" be ")#mi("{d \\times d}")#text(" matrices, with ")#mi("{A_1,\\ldots,A_m}")#text(" rank one. Then the polynomial ")#mi("{(t_1,\\ldots,t_m) \\mapsto \\text{det}(B + t_1 A_1 + \\ldots + t_m A_m)}")#text(" is affine-multilinear, that is to say it is of the form")

#align(center)[#tao-fit-display[#mitex("(t_1,\\ldots,t_m) \\mapsto \\sum_{1 \\leq i_1 < \\ldots < i_j \\leq m} a_{i_1,\\ldots,i_j} t_{i_1} \\ldots t_{i_j}")]]

#text("for some coefficients ")#mi("{a_{i_1,\\ldots,i_j}}")#text(".")
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-3f4146a1d0b5dac26562>)[#text("8")]#text(", the polynomial ")#mi("{(t_1,\\ldots,t_m) \\mapsto \\text{det}(B + t_1 A_1 + \\ldots + t_m A_m)}")#text(" is affine-linear in each of the variables ")#mi("{t_i}")#text(" separately (if one freezes the other ")#mi("{m-1}")#text(" variables ")#mi("{t_j}")#text("). The claim follows. ")#mi("\\Box")

#text("Now observe that if a one-variable polynomial ")#mi("{t \\mapsto P(t)}")#text(" is affine-linear, then it can be recovered from its order ")#mi("{1}")#text(" Taylor expansion at the origin:")

#tao-aligned(keep: true)[


#tao-math("P(t)  & = P(0) + t P^{\\prime}(0)", block: true)



#tao-math(" & = (1 + t \\frac{\\partial}{\\partial z}) P(z)|_{z=0}.", block: true)
]

#text("More generally, if a polynomial ")#mi("{(t_1,\\ldots,t_m) \\mapsto P(t_1,\\ldots,t_m)}")#text(" is affine-multilinear in the sense of Corollary ")#link(<tao-889aa88533454fe3d7b5>)[#text("9")]#text(", then it can be recovered from an “order ")#mi("{(1,\\ldots,1)}")#text(" Taylor expansion” at the origin by the formula")

#align(center)[#tao-fit-display[#mitex("P(t_1,\\ldots,t_m) = (\\prod_{i=1}^m (1 + t_i \\frac{\\partial}{\\partial z_i})) P(z_1,\\ldots,z_m) |_{z_1=\\ldots=z_m=0}.")]]

#text("Applying this to the polynomial in Corollary ")#link(<tao-889aa88533454fe3d7b5>)[#text("9")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{det}(B + t_1 A_1 + \\ldots + t_m A_m)")]]

#align(center)[#tao-fit-display[#mitex("= (\\prod_{i=1}^m (1 + t_i \\frac{\\partial}{\\partial z_i})) P(z_1,\\ldots,z_m) |_{z_1=\\ldots=z_m=0}.")]]

#text("Setting ")#mi("{B = x}")#text(" and ")#mi("{t_1=\\ldots=t_m=-1}")#text(", we obtain Proposition ")#link(<tao-cc74039fc0153214a9ca>)[#text("3")]#text(" as required.")

#heading(level: 1)[#strong[#text(" — 2. Real stable polynomials and interlacing — ")]]

#text("Now we prove Proposition ")#link(<tao-8f10e3460cbb9c694509>)[#text("2")]#text(". The key observation is that almost all of the polynomials one needs to work with here are of a special class, namely the ")#emph[#text("real stable polynomials")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10")]#text(" A polynomial ")#mi("{p: {\\bf C}^m \\rightarrow {\\bf C}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Stable_polynomial")[#text("stable")]#text(" if it has no zeroes in the region ")#mi("{\\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: \\text{Im}(z_1),\\ldots,\\text{Im}(z_m) > 0 \\}}")#text(" (in particular, ")#mi("{p}")#text(" is non-zero). A polynomial ")#mi("{p: {\\bf C}^m \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("real stable")]#text(" if it is stable and all of its coefficients are real.")
]

#text("Observe from conjugation symmetry that a real stable polynomial has no zeroes in either of the two regions ")#mi("{\\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: \\text{Im}(z_1),\\ldots,\\text{Im}(z_m) > 0 \\}}")#text(" and ")#mi("{\\{ (z_1,\\ldots,z_m) \\in {\\bf C}^m: \\text{Im}(z_1),\\ldots,\\text{Im}(z_m) < 0 \\}}")#text(". In particular, a one-variable real polynomial is stable if and only if it only has real zeroes. The notion of stability is however more complicated in higher dimensions. See ")#link("http://www.ams.org/mathscinet-getitem?mr=2738906")[#text("this survey of Wagner")]#text(" for a more thorough discussion of the property of real stability.")

#text("To me, the property of being real stable is somewhat similar to properties such as ")#link("http://en.wikipedia.org/wiki/Logarithmically_convex_function")[#text("log-convexity")]#text(" or ")#link("http://en.wikipedia.org/wiki/Total_positivity")[#text("total positivity")]#text("; these are properties that are only obeyed by a minority of objects being studied, but in many key cases, these properties are available and can be very profitable to exploit. In practice, real stable polynomials get to enjoy the combined benefit of real analysis methods (e.g. the intermediate value theorem) with complex analysis methods (e.g. Rouche’s theorem), because of the guarantee that zeroes will be real.")

#text("A basic example of a real stable polynomial is the characteristic polynomial of a Hermitian matrix; this is a rephrasing of the fundamental fact that the eigenvalues of a Hermitian matrix are all real. There is a multidimensional version of this example, which will be the primary source of real stability for us:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" If ")#mi("{A_1,\\ldots,A_m}")#text(" are positive semi-definite Hermitian matrices, then the polynomial ")#mi("{p( z, z_1,\\ldots,z_m) := \\text{det}(z + z_1 A_1 + \\ldots+ z_m A_m)}")#text(" is real stable.")
]

#emph[#text("Proof:")]#text(" It is clear that this polynomial is real (note that it takes real values for real inputs). To show that it is stable, observe that if ")#mi("{z, z_1,\\ldots,z_m}")#text(" have positive imaginary part, then the skew-adjoint part of ")#mi("{z + z_1 A_1 + \\ldots+ z_m A_m}")#text(" is strictly positive definite, and so ")#mi("{z + z_1 A_1 + \\ldots+ z_m A_m}")#text(" is non-singular (since the quadratic form ")#mi("{\\text{Im} \\langle (z+z_1 A_1+\\ldots+z_m A_m)v, v \\rangle}")#text(" is non-degenerate). ")#mi("\\Box")

#text("Stable polynomials are also closed under restriction and under differential operators such as ")#mi("{(1 - \\frac{\\partial}{\\partial z_j})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" Let ")#mi("{p( z_1,\\ldots,z_m )}")#text(" be a real stable polynomial of ")#mi("{m}")#text(" variables.")

#list(
[#text("(Restriction) If ")#mi("{m > 1}")#text(" and ")#mi("{t}")#text(" is real, then the polynomial ")#mi("{p( z_1,\\ldots,z_{m-1},t)}")#text(" is a real stable polynomial of ")#mi("{m-1}")#text(" variables, unless it is identically zero.")],
[#text("(Differentiation) For any real ")#mi("{t}")#text(", the polynomial ")#mi("{(1 + t \\frac{\\partial}{\\partial z_m}) p(z_1,\\ldots,z_m)}")#text(" is a real stable polynomial of ")#mi("{m}")#text(" variables.")]
)

#text("Similarly for permutations of the ")#mi("{m}")#text(" variables.")
]

#emph[#text("Proof:")]#text(" The final claim is clear, as the property of real stability is unchanged under permutation of the variables.")

#text("We first prove the restriction claim. The polynomial ")#mi("{p( z_1,\\ldots,z_{m-1},t)}")#text(" is clearly real. If we have a zero ")#mi("{p( z_1,\\ldots,z_{m-1},t)=0}")#text(" with ")#mi("{z_1,\\ldots,z_{m-1}}")#text(" having positive imaginary part, but ")#mi("{p(\\cdot,\\ldots,\\cdot,t)}")#text(" does not vanish identically, then by the stable nature of zeroes (see, e.g., ")#link("http://en.wikipedia.org/wiki/Rouch%C3%A9%27s_theorem")[#text("Rouche’s theorem")]#text(") we will also have a nearby zero ")#mi("{p(z^{\\prime}_1,\\ldots,z^{\\prime}_{m-2}, z^{\\prime}_{m-1}, z_m)=0}")#text(" for any ")#mi("{z_m}")#text(" sufficiently close to ")#mi("{t}")#text(", with ")#mi("{z^{\\prime}_i}")#text(" arbitrarily close to ")#mi("{z_i}")#text(". In particular, by setting ")#mi("{z_m}")#text(" have positive imaginary part, we contradict the stability of ")#mi("{p(z_1,\\ldots,z_m)}")#text(".")

#text("Now we turn to the differentiation claim. Again the real nature of ")#mi("{(1 + t \\frac{\\partial}{\\partial z_m}) p(z_1,\\ldots,z_m)}")#text(" is clear. To prove stability, it suffices after freezing the first ")#mi("{m-1}")#text(" variables to show that ")#mi("{p(z) +t p^{\\prime}(z)}")#text(" is stable whenever ")#mi("{p(z)}")#text(" is stable. We may of course take ")#mi("{t}")#text(" non-zero. But a stable polynomial of one variable may be factored as ")#mi("{p(z) = c \\prod_{i=1}^d (z-w_i)}")#text(" for some roots ")#mi("{w_1,\\ldots,w_d}")#text(" with non-positive imaginary part. Since")

#align(center)[#tao-fit-display[#mitex("p(z) + t p^{\\prime}(z) = p(z) ( 1 + \\sum_{i=1}^d \\frac{t}{z-w_i} )")]]

#text("we see that if ")#mi("{z}")#text(" has positive imaginary part, then the imaginary part of ")#mi("{1 + \\sum_{i=1}^d \\frac{t}{z-w_i}}")#text(" has the opposite sign to ")#mi("{t}")#text(", and is in particular non-zero; since ")#mi("{p(z)}")#text(" has no zeroes in the upper half-plane, neither does ")#mi("{p(z) +t p^{\\prime}(z)}")#text(". ")#mi("\\Box")

#text("Combining these facts with ")#link(<tao-2abdfa203fc5a0477cc8>)[#text("(3)")]#text(", we immediately obtain:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Mixed characteristic polynomials are real stable)")]#text(" ")#metadata(none) <tao-30ca76a5fb6851f0074a>#text(" If ")#mi("{A_1,\\ldots,A_m}")#text(" are positive semi-definite matrices, then ")#mi("{\\mu[A_1,\\ldots,A_m]}")#text(" is real stable. In other words, all the zeroes of ")#mi("{\\mu[A_1,\\ldots,A_m]}")#text(" are real.")
]

#text("Now, we relate stability with “convexity” properties of the largest root. Note in general that if ")#mi("{(1-\\lambda)p +\\lambda q}")#text(" is a convex combination of two polynomials ")#mi("{p,q}")#text(", that there is no requirement that ")#mi("{\\text{maxroot}((1-\\lambda)p +\\lambda q)}")#text(" lie between ")#mi("{\\text{maxroot}(p)}")#text(" and ")#mi("{\\text{maxroot}(q)}")#text(". For instance, if ")#mi("{p(z) = (z-1)^2 (z+2)}")#text(" and ")#mi("{q(z) = (z+1)^2 (z+2)}")#text(", then ")#mi("{\\text{maxroot}(p)=1}")#text(" and ")#mi("{\\text{maxroot}(q)=-1}")#text(", but ")#mi("{\\text{maxroot}(\\frac{1}{2}p+\\frac{1}{2}q) = -2}")#text(". Note also that ")#mi("{p,q}")#text(" are stable in this case. However the situation improves when one also assumes that all convex combinations of ")#mi("{p,q}")#text(" are stable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Comparison with mean)")]#text(" ")#metadata(none) <tao-e291964da9c5c5928e5b>#text(" Let ")#mi("{p(z), q(z)}")#text(" be real stable polynomials of one variable that are ")#link("http://en.wikipedia.org/wiki/Monic_polynomial")[#text("monic")]#text(" of the same degree. Suppose that ")#mi("{(1-t)p +tq}")#text(" is also real stable for every ")#mi("{0 \\leq t \\leq 1}")#text(". Then for every ")#mi("{0 \\leq \\lambda \\leq 1}")#text(", ")#mi("{\\text{maxroot}((1-\\lambda)p + \\lambda q)}")#text(" lies between ")#mi("{\\text{maxroot}(p)}")#text(" and ")#mi("{\\text{maxroot}(q)}")#text(".")
]

#emph[#text("Proof:")]#text(" We may of course assume ")#mi("{0 <\\lambda <1}")#text(". Without loss of generality let us assume ")#mi("{\\text{maxroot}(p) \\leq \\text{maxroot}(q)}")#text(", so our task is to show that")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}(p) \\leq \\text{maxroot}( (1-\\lambda)p + \\lambda q) \\leq \\text{maxroot}(q).")]]

#text("The second inequality is easy: as ")#mi("{p,q}")#text(" are monic, ")#mi("{p(x)}")#text(" is positive for ")#mi("{x >\\text{maxroot}(p)}")#text(" and ")#mi("{q(x)}")#text(" is positive for ")#mi("{x > \\text{maxroot}(q)}")#text(", and so ")#mi("{(1-\\lambda)p(x) + \\lambda q(x)}")#text(" is positive for ")#mi("{x> \\text{maxroot}(q)}")#text(", giving the claim.")

#text("The first inequality is trickier. Suppose it fails; then ")#mi("{(1-\\lambda)p + \\lambda q}")#text(" has no zero in ")#mi("{[\\text{maxroot}(p), \\text{maxroot}(q)]}")#text(". We have already seen that this polynomial is positive at ")#mi("{\\text{maxroot}(q)}")#text(", thus it must also be positive at ")#mi("{\\text{maxroot}(p)}")#text(". In other words, ")#mi("{q}")#text(" is positive at ")#mi("{\\text{maxroot}(p)}")#text(". Since ")#mi("{q}")#text(" already had a zero at ")#mi("{\\text{maxroot}(q)}")#text(" and was positive to the right of this zero, we conclude that ")#mi("{q}")#text(" has at least two zeroes (counting multiplicity) to right of ")#mi("{\\text{maxroot}(p)}")#text(". On the other hand, for ")#mi("{t}")#text(" sufficiently close to ")#mi("{0}")#text(", ")#mi("{(1-t)p+tq}")#text(" has no zeroes to the right of ")#mi("{\\text{maxroot}(p)}")#text(", and all intermediate convex combinations ")#mi("{(1-t) p + t q}")#text(" cannot vanish at ")#mi("{\\text{maxroot}(p)}")#text(". Thus, at some intermediate value of ")#mi("{t}")#text(", the number of real zeroes of ")#mi("{(1-t) p + t q}")#text(" to the right of ")#mi("{\\text{maxroot}(p)}")#text(" must acquire a jump discontinuity (e.g. two real zeroes colliding and then disappearing, or vice versa), but this contradicts Rouche’s theorem and real stability. ")#mi("\\Box")

#text("One can control other roots than the maximal roots of ")#mi("{p,q,(1-t)p+tq}")#text(" by these arguments, and show that these polynomials have a common interlacing polynomial of one lower degree, but we will not need these stronger results here.")

#text("Specialising this to mixed characteristic polynomials ")#mi("{\\mu[A_1,\\ldots,A_m]}")#text(" (which are always monic of degree ")#mi("{d}")#text("), we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15 (Comparison with mean)")]#text(" Let ")#mi("{A_1,\\ldots,A_m}")#text(" be jointly independent random rank one positive semi-definite Hermitian matrices, with each ")#mi("{A_i}")#text(" taking finitely many values. For any ")#mi("{1 \\leq j < m}")#text(" and any fixed choice of ")#mi("{A_1,\\ldots,A_{j-1}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}( \\mu[ A_1,\\ldots,A_{j-1},A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m] )")]]

#align(center)[#tao-fit-display[#mitex("\\leq \\text{maxroot}( \\mu[ A_1,\\ldots,A_{j-1}, \\mathop{\\bf E} A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m] )")]]

#text("with positive probability, and")

#align(center)[#tao-fit-display[#mitex("\\text{maxroot}( \\mu[ A_1,\\ldots,A_{j-1},A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m] )")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\text{maxroot}( \\mu[ A_1,\\ldots,A_{j-1}, \\mathop{\\bf E} A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m] )")]]

#text("with positive probability.")
]

#emph[#text("Proof:")]#text(" For fixed ")#mi("{A_1,\\ldots,A_{j-1}}")#text(", ")#mi("{\\mathop{\\bf E} A_j}")#text(" is a convex combination of all the values of ")#mi("{A_j}")#text(" that occur with positive probability, and hence (by the affine-multilinear nature of ")#mi("{\\mu}")#text(") ")#mi("{\\mu[ A_1,\\ldots,A_{j-1}, \\mathop{\\bf E} A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m]}")#text(" is a convex combination of the ")#mi("{\\mu[ A_1,\\ldots,A_{j-1}, A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m]}")#text(" over the same range of ")#mi("{A_j}")#text(". On the other hand, by Corollary ")#link(<tao-30ca76a5fb6851f0074a>)[#text("13")]#text(", all such convex combinations are real stable. Iterating Lemma ")#link(<tao-e291964da9c5c5928e5b>)[#text("14")]#text(", we see that ")#mi("{\\text{maxroot}(\\mu[ A_1,\\ldots,A_{j-1}, \\mathop{\\bf E} A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m])}")#text(" must lie in the convex hull of the ")#mi("{\\text{maxroot}(\\mu[ A_1,\\ldots,A_{j-1}, A_j,\\mathop{\\bf E} A_{j+1},\\ldots,\\mathop{\\bf E} A_m])}")#text(", and the claim follows. ")#mi("\\Box")

#text("Iterating the above corollary for ")#mi("{j=1,\\ldots,m}")#text(" and using Proposition ")#link(<tao-cc74039fc0153214a9ca>)[#text("3")]#text(", we obtain Proposition ")#link(<tao-8f10e3460cbb9c694509>)[#text("2")]#text(" as desired.")

#heading(level: 1)[#strong[#text(" — 3. Convexity — ")]]

#text("In order to establish Theorem ")#link(<tao-56365f389e9260ddaab9>)[#text("7")]#text(", we will need some convexity properties of real stable polynomials ")#mi("{p}")#text(", or more precisely of the log-derivatives ")#mi("{\\Phi_p^j := \\frac{\\frac{\\partial}{\\partial z_j} p}{p}}")#text(" of such polynomials, when one is “above” all the zeroes. We begin with the one-dimensional case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (One-dimensional convexity)")]#text(" ")#metadata(none) <tao-a558030fcb3879647678>#text(" Let ")#mi("{p(z)}")#text(" be a real stable polynomial of one variable, and let ")#mi("{\\Phi_p:= \\frac{p^{\\prime}}{p}}")#text(" be the logarithmic derivative (which is defined away from the zeroes of ")#mi("{p}")#text("). Then ")#mi("{(-1)^k \\Phi_p^{(k)}(x) > 0}")#text(" whenever ")#mi("{k=0,1,2\\ldots}")#text(" and ")#mi("{x > \\text{maxroot}(p)}")#text(". In particular, ")#mi("{\\Phi_p}")#text(" is positive, decreasing, and strictly convex to the right of ")#mi("{\\text{maxroot}(p)}")#text(".")
]

#emph[#text("Proof:")]#text(" If we factor ")#mi("{p(z) = c \\prod_{i=1}^d (z-y_i)}")#text(", where ")#mi("{y_1,\\ldots,y_d}")#text(" are the real roots, then ")#mi("{\\Phi_p(z) = \\sum_{i=1}^d \\frac{1}{z-y_i}}")#text(". From direct computation we have")

#align(center)[#tao-fit-display[#mitex("(-1)^k \\Phi_p^{(k)}(x) = k! \\sum_{i=1}^d \\frac{1}{(x-y_i)^{k+1}}.")]]

#text("Since ")#mi("{x-y_i}")#text(" is positive when ")#mi("{x > \\text{maxroot}(p)}")#text(", the claim follows. ")#mi("\\Box")

#text("Now we obtain a higher dimensional version of this lemma. If ")#mi("{p(z_1,\\ldots,z_m)}")#text(" is a real stable polynomial, we say that a point ")#mi("{x = (x_1,\\ldots,x_m) \\in {\\bf R}^m}")#text(" lies ")#emph[#text("above")]#text(" the roots of ")#mi("{p}")#text(" if ")#mi("{p}")#text(" has no zeroes on the orthant ")#mi("{\\{ (y_1,\\ldots,y_m): y_i \\geq x_i \\text{ for all } i=1,\\ldots,m\\}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17 (Multi-dimensional convexity)")]#text(" ")#metadata(none) <tao-19b02cedffa0c876d53d>#text(" Let ")#mi("{p(z_1,\\ldots,z_m)}")#text(" be a real stable polynomial of ")#mi("{m}")#text(" variables, let ")#mi("{1 \\leq i,j \\leq m}")#text(", and let ")#mi("{\\Phi^i_p := \\frac{\\partial_{z_i} p}{p}}")#text(" be the logarithmic derivative in the ")#mi("{e_i}")#text(" direction. Then ")#mi("{(-1)^k \\frac{\\partial^k}{\\partial z_j^k} \\Phi_p^i(x) \\geq 0}")#text(" whenever ")#mi("{k=0,1,2,\\ldots}")#text(" and ")#mi("{x}")#text(" lies above the roots of ")#mi("{p}")#text(". In particular, the function ")#mi("{t \\mapsto \\Phi_p(x+te_j)}")#text(" is non-negative, non-increasing, and convex for non-negative ")#mi("{t}")#text(".")
]

#emph[#text("Proof:")]#text(" For ")#mi("{i=j}")#text(" or ")#mi("{k=0}")#text(", the claim follows from Lemma ")#link(<tao-a558030fcb3879647678>)[#text("16")]#text(" after freezing all the other variables, so we may assume that ")#mi("{i \\neq j}")#text(" and ")#mi("{k \\geq 1}")#text(". By freezing all the other variables and relabeling, we may assume that ")#mi("{m=2}")#text(", ")#mi("{i=1}")#text(", and ")#mi("{j=2}")#text(", thus ")#mi("{p(z_1,z_2)}")#text(" is a real stable polynomial, ")#mi("{x = (x_1,x_2)}")#text(" lies above the roots of ")#mi("{p}")#text(", and the task is to show that")

#align(center)[#tao-fit-display[#mitex("(-1)^k \\frac{\\partial^k}{\\partial z_2^k} \\Phi_p^1(x) \\geq 0")]]

#text("for all ")#mi("{k=1,2,\\ldots}")#text(". Using the variables ")#mi("{x_1,x_2}")#text(" to denote differentiation instead of ")#mi("{z_1,z_2}")#text(", the left-hand side is equal to")

#align(center)[#tao-fit-display[#mitex("(-1)^k \\frac{\\partial^k}{\\partial x_2^k} \\frac{\\partial}{\\partial x_1} \\log p(x)")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{\\partial}{\\partial x_1}( (-1)^k \\frac{\\partial^k}{\\partial x_2^k} \\log p(x) )")]]

#text("so it suffices to show that ")#mi("{(-1)^k \\frac{\\partial^k}{\\partial x_2^k} \\log p(x)}")#text(" is non-decreasing in the ")#mi("{x_1}")#text(" direction. By continuity, it suffices to do this for generic ")#mi("{x_1}")#text(" (thus, we may exclude a finite number of exceptional ")#mi("{x_1}")#text(" if we wish).")

#text("For fixed ")#mi("{x_1}")#text(", the polynomial ")#mi("{p_{x_1}: x_2 \\mapsto p(x_1,x_2)}")#text(" is real stable, and thus has real roots, which we denote as ")#mi("{y_1(x_1),\\ldots,y_d(x_1)}")#text(" (counting multiplicity). For generic ")#mi("{x_1}")#text(", the number ")#mi("{d}")#text(" of roots does not depend on ")#mi("{x_1}")#text(", the ")#mi("{y_i(x_1)}")#text(" can be chosen to vary smoothly in ")#mi("{x_1}")#text(", and the multiplicity of each root ")#mi("{y_i(x_1)}")#text(" is locally constant in ")#mi("{x_1}")#text(" (the latter claim can be seen by noting that the roots of ")#mi("{p_{x_1}}")#text(" of multiplicity at least ")#mi("{k}")#text(" are the same as the roots of the ")#link("https://en.wikipedia.org/wiki/Resultant")[#text("resultant")]#text(" of polynomial ")#mi("{p_{x_1}}")#text(" and its first ")#mi("{k-1}")#text(" derivatives ")#mi("{p_{x_1}^{\\prime}, p_{x_1}^{\\prime},\\dots,p_{x_1}^{(k-1)}}")#text(", and the set of the latter roots are generically smoothly varying in ")#mi("{x_1}")#text("). We then have")

#align(center)[#tao-fit-display[#mitex("(-1)^k \\frac{\\partial^k}{\\partial x_2^k} \\log p(x) = -(k-1)! \\sum_{i=1}^d \\frac{1}{(x_2-y_i(x_1))^k}")]]

#text("so it suffices to show that each of the ")#mi("{\\frac{1}{(x_2-y_i(x_1))^k}}")#text(" is a non-increasing function of ")#mi("{x_1}")#text(". But if ")#mi("{(x_1,x_2)}")#text(" lies above the roots of ")#mi("{p}")#text(", then the ")#mi("{y_i(x_1)}")#text(" all lie below ")#mi("{x_2}")#text("; so it suffices to show that the ")#mi("{y_i(x_1)}")#text(" are all generically non-increasing. But if this were not the case, then (as ")#mi("{y_i(x_1)}")#text(" is generically smooth), ")#mi("{y_i(x_1)}")#text(" would have a positive derivative for all ")#mi("{x_1}")#text(" in an open interval. In particular, there is an ")#mi("{x^0}")#text(" such that the root ")#mi("{y_i(x_1)}")#text(" has positive derivative and a constant multiplicity ")#mi("{m}")#text(" for all ")#mi("{x_1}")#text(" sufficiently close to ")#mi("{x^0}")#text(". This root ")#mi("{y_i(x_1)}")#text(" depends analytically on ")#mi("{x_1}")#text(" near ")#mi("{x^0}")#text(" (this can be seen by noting that ")#mi("{y_i(x_1)}")#text(" is the unique and simple root near ")#mi("{y_i(x^0)}")#text(" of the ")#mi("{(m-1)^{th}}")#text(" derivative of ")#mi("{p_{x_1}}")#text(" and using the inverse function theorem), so by analytic continuation we conclude that for ")#emph[#text("complex")]#text(" ")#mi("{z_1}")#text(" near ")#mi("{x^0}")#text(", the polynomial ")#mi("{z_2 \\mapsto p(z_1,z_2)}")#text(" has a complex root ")#mi("{y_i(z_1)}")#text(" near ")#mi("{y_i(x^0)}")#text(" that depends complex analytically on ")#mi("{z_1}")#text(". Since the derivative of ")#mi("{y_i}")#text(" at ")#mi("{x^0}")#text(" is a positive real, we conclude that there are zeroes ")#mi("{(z_1,z_2)}")#text(" of ")#mi("{p}")#text(" near ")#mi("{(x^0,y^0)}")#text(" with ")#mi("{\\text{Im}(z_1), \\text{Im}(z_2)}")#text(" both strictly positive, contradicting stability, and the claim follows. ")#mi("\\Box")

#text("Now we begin the proof of Theorem ")#link(<tao-56365f389e9260ddaab9>)[#text("7")]#text(". We abbreviate ")#mi("{\\frac{\\partial}{\\partial z_i}}")#text(" as ")#mi("{\\partial_i}")#text(". We start with Proposition ")#link(<tao-cc74039fc0153214a9ca>)[#text("3")]#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} p_A(z) = (\\prod_{i=1}^m (1 - \\partial_i)) \\text{det}( z + \\sum_{i=1}^m z_i \\mathop{\\bf E} A_i ) |_{z_1=\\ldots=z_m=0}.")]]

#text("From the hypothesis ")#mi("{\\mathop{\\bf E} A = 1}")#text(", we may rewrite")

#align(center)[#tao-fit-display[#mitex("z + \\sum_{i=1}^m z_i \\mathop{\\bf E} A_i = \\sum_{i=1}^m (z_i+z) \\mathop{\\bf E} A_i")]]

#text("and so after translating the ")#mi("{z_i}")#text(" by ")#mi("{z}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} p_A(z) = (\\prod_{i=1}^m (1 - \\partial_i)) \\text{det}( \\sum_{i=1}^m z_i \\mathop{\\bf E} A_i ) |_{z_1=\\ldots=z_m=z}.")]]

#text("Replacing each ")#mi("{A_i}")#text(" by their mean, we reduce to showing the following deterministic estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18")]#text(" ")#metadata(none) <tao-428507df4de12f6c5066>#text(" Let ")#mi("{A_1,\\ldots,A_m}")#text(" be Hermitian positive semi-definite ")#mi("{d \\times d}")#text(" matrices such that ")#metadata(none) <tao-d5a3cc08c3d9647ef0e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{i=1}^m A_i = I_d")]]

#text("and such that ")#metadata(none) <tao-1c385247204461b564a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\text{tr} A_i \\leq \\varepsilon")]]

#text("for some ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{i=1,\\ldots,m}")#text(". Let ")#mi("{p(z_1,\\ldots,z_m)}")#text(" be the polynomial")

#align(center)[#tao-fit-display[#mitex("p(z_1,\\ldots,z_m) :=\\text{det}( \\sum_{i=1}^m z_i A_i ).")]]

#text("Then ")#mi("{((1+\\sqrt{\\varepsilon})^2, \\ldots, (1+\\sqrt{\\varepsilon})^2)}")#text(" lies above the roots of ")#mi("{(\\prod_{i=1}^m (1 - \\partial_i)) p}")#text(".")
]

#text("We will prove this theorem as follows. First observe that ")#mi("{(t,\\ldots,t)}")#text(" lies above the roots of ")#mi("{p}")#text(" for any ")#mi("{t>0}")#text(", since ")#mi("{\\sum_{i=1}^m x_i A_i - t}")#text(" is positive semi-definite whenever ")#mi("{x_i \\geq t}")#text(", and so ")#mi("{\\sum_{i=1}^m x_i A_i}")#text(" is non-singular in this region. We now wish to pass from ")#mi("{p}")#text(" to ")#mi("{(\\prod_{i=1}^m (1 - \\partial_i)) p}")#text(" by successive application of the derivative operators ")#mi("{1 - \\partial_i}")#text(". An initial step in this direction is the following elementary consequence of the monotonicity properties from Lemma ")#link(<tao-19b02cedffa0c876d53d>)[#text("17")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19")]#text(" ")#metadata(none) <tao-78675cc176081372c43a>#text(" Let ")#mi("{q(z_1,\\ldots,z_m)}")#text(" be a real stable polynomial, and suppose that ")#mi("{x = (x_1,\\ldots,x_m)}")#text(" lies above the roots of ")#mi("{q}")#text(". Suppose that ")#mi("{1 \\leq j \\leq m}")#text(", with the stability bound")

#align(center)[#tao-fit-display[#mitex("\\Phi_q^j(x) < 1.")]]

#text("Then ")#mi("{x}")#text(" also lies above the roots of ")#mi("{q-\\partial_j q}")#text(".")
]

#emph[#text("Proof:")]#text(" By the monotonicity properties in Lemma ")#link(<tao-19b02cedffa0c876d53d>)[#text("17")]#text(", ")#mi("{\\Phi_q^j(y) < 1}")#text(" for all ")#mi("{y}")#text(" above ")#mi("{x}")#text(" (by which we mean that ")#mi("{y_k \\geq x_k}")#text(" for all ")#mi("{k}")#text("). On the other hand, as ")#mi("{q(y)}")#text(" is non-zero in this region, ")#mi("{q(y) - \\partial_j q(y)}")#text(" can only vanish when ")#mi("{\\Phi_q^j = \\frac{\\partial_j q}{q}}")#text(" is equal to ")#mi("{1}")#text(", and so ")#mi("{x}")#text(" lies above the roots of ")#mi("{q-\\partial_j q}")#text(" as claimed. ")#mi("\\Box")

#text("Unfortunately, this lemma does not directly lend itself to iteration, because the lemma provides no control on ")#mi("{\\Phi_{q -\\partial_j q}}")#text(". To fix this problem, we need the following more complicated variant of Lemma ")#link(<tao-78675cc176081372c43a>)[#text("19")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20")]#text(" ")#metadata(none) <tao-ccb711f092ac8ef1805b>#text(" Let ")#mi("{q(z_1,\\ldots,z_m)}")#text(" be a real stable polynomial, and suppose that ")#mi("{x = (x_1,\\ldots,x_m)}")#text(" lies above the roots of ")#mi("{q}")#text(". Suppose that ")#mi("{1 \\leq j \\leq m}")#text(", with the stability bound ")#metadata(none) <tao-5d19115b2691291d3735>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\Phi_q^j(x) + \\frac{1}{\\delta}\\leq 1")]]

#text("for some ")#mi("{\\delta> 0}")#text(". Then ")#mi("{x+\\delta e_j}")#text(" lies above the roots of ")#mi("{q - \\partial_j q}")#text(", and furthermore one has the monotonicity ")#metadata(none) <tao-d503a88894286f1642a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\Phi_{q-\\partial_j q}^i( x + \\delta e_j) \\leq \\Phi_q^i(x)")]]

#text("for all ")#mi("{1 \\leq i \\leq m}")#text(".")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-78675cc176081372c43a>)[#text("19")]#text(" we already know that ")#mi("{x}")#text(" lies above the roots of ")#mi("{q-\\partial_j q}")#text(", and so ")#mi("{x+\\delta e_j}")#text(" does also. Now we prove ")#link(<tao-d503a88894286f1642a2>)[#text("(9)")]#text(". Above the roots of ")#mi("{q}")#text(", we factorise")

#align(center)[#tao-fit-display[#mitex("q - \\partial_j q = q (1 - \\Phi_q^j)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\log(q - \\partial_j q) = \\log q + \\log(1 - \\Phi_q^j).")]]

#text("Applying ")#mi("{\\partial_i}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Phi_{q-\\delta_j q}^i = \\Phi_q^i - \\frac{\\partial_i \\Phi_q^j}{1 - \\Phi_q^j}.")]]

#text("The claim ")#link(<tao-d503a88894286f1642a2>)[#text("(9)")]#text(" is then equivalent to")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\partial_i \\Phi_q^j(x+\\delta e_j)}{1 - \\Phi_q^j(x+\\delta e_j)} \\leq \\Phi_q^i(x) - \\Phi_q^i(x+\\delta e_j).")]]

#text("On the other hand, by Lemma ")#link(<tao-19b02cedffa0c876d53d>)[#text("17")]#text(", ")#mi("{t \\mapsto \\Phi_q^i(x+te_i)}")#text(" is convex for ")#mi("{t \\geq 0}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\Phi_q^i(x) - \\Phi_q^i(x+\\delta e_j) \\geq - \\delta \\partial_j \\Phi_q^i(x + \\delta e_j)")]]

#text("But")

#align(center)[#tao-fit-display[#mitex("\\partial_j \\Phi_q^i = \\partial_j \\partial_i \\log q = \\partial_i \\partial_j \\log q = \\partial_i \\Phi_q^j")]]

#text("and this quantity is non-positive at ")#mi("{x+\\delta e_j}")#text(" thanks to Lemma ")#link(<tao-19b02cedffa0c876d53d>)[#text("17")]#text(". Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1 - \\Phi_q^j(x+\\delta e_j)} \\leq \\delta.")]]

#text("But by Lemma ")#link(<tao-19b02cedffa0c876d53d>)[#text("17")]#text(" and ")#link(<tao-5d19115b2691291d3735>)[#text("(8)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\Phi_q^j(x+\\delta e_j) \\leq \\Phi_q^j(x) \\leq 1- \\frac{1}{\\delta}")]]

#text("and the claim follows. ")#mi("\\Box")

#text("We can iterate this to obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 21")]#text(" ")#metadata(none) <tao-76878f1d2b881ee5cf98>#text(" Let ")#mi("{q(z_1,\\ldots,z_m)}")#text(" be a real stable polynomial, and suppose that ")#mi("{x = (x_1,\\ldots,x_m)}")#text(" lies above the roots of ")#mi("{q}")#text(". Suppose that ")#metadata(none) <tao-32a015d9cb7b06639455>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\Phi_q^j(x) + \\frac{1}{\\delta}\\leq 1")]]

#text("for some ")#mi("{\\delta> 0}")#text(" and all ")#mi("{1 \\leq j \\leq m}")#text(". Then ")#mi("{x+(\\delta,\\ldots,\\delta)}")#text(" lies above the roots of ")#mi("{(\\prod_{i=1}^m (1-\\partial_i)) q}")#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{0 \\leq k \\leq m}")#text(", set ")#mi("{x_k := x+\\delta(e_1+\\ldots+e_k)}")#text(" and ")#mi("{q_k := (\\prod_{i=1}^k (1-\\partial_i)) q}")#text(". By Lemma ")#link(<tao-ccb711f092ac8ef1805b>)[#text("20")]#text(" induction we see that for each ")#mi("{0 \\leq k \\leq m}")#text(", ")#mi("{x_k}")#text(" lies above the roots of ")#mi("{q_k}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\Phi_{q_k}^j(x_k) + \\frac{1}{\\delta}\\leq 1")]]

#text("for all ")#mi("{j=1,\\ldots,m}")#text(". Setting ")#mi("{k=m}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Finally, we prove Theorem ")#link(<tao-428507df4de12f6c5066>)[#text("18")]#text(". By definition, we have")

#align(center)[#tao-fit-display[#mitex("\\log p( x_1,\\ldots,x_m ) = \\log \\text{det} ( \\sum_{i=1}^m x_i A_i )")]]

#text("and hence on taking ")#mi("{\\partial_j}")#text(" and using the ")#link("http://en.wikipedia.org/wiki/Jacobi%27s_formula")[#text("Jacobi formula")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Phi_p^j( x_1,\\ldots,x_m) = \\text{tr}( A_j (\\sum_{i=1}^m x_i A_i)^{-1} ).")]]

#text("In particular, for any ")#mi("{t>0}")#text(", we may use ")#link(<tao-d5a3cc08c3d9647ef0e8>)[#text("(6)")]#text(", ")#link(<tao-1c385247204461b564a6>)[#text("(7)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\Phi_p^j(t,\\ldots,t) \\leq \\varepsilon/t.")]]

#text("As remarked before, ")#mi("{(t,\\ldots,t)}")#text(" lies above the zeroes of ")#mi("{p}")#text(". Thus, if we choose ")#mi("{t,\\delta>0}")#text(" such that ")#metadata(none) <tao-9b4306d86161fee36ba5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{\\varepsilon}{t} + \\frac{1}{\\delta} \\leq 1")]]

#text("then by Corollary ")#link(<tao-76878f1d2b881ee5cf98>)[#text("21")]#text(", we conclude that ")#mi("{(t+\\delta,\\ldots,t+\\delta)}")#text(" lies above the zeroes of ")#mi("{(\\prod_{i=1}^m (1 - \\partial_i)) p}")#text(". To optimise ")#mi("{t+\\delta}")#text(" subject to the constraint ")#link(<tao-9b4306d86161fee36ba5>)[#text("(11)")]#text(", we set ")#mi("{t := \\sqrt{\\varepsilon}+\\varepsilon}")#text(" and ")#mi("{\\delta := 1+\\sqrt{\\varepsilon}}")#text(", and Theorem ")#link(<tao-428507df4de12f6c5066>)[#text("18")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 4. Weaver, Akemann-Anderson, and paving — ")]]

#text("Theorem ")#link(<tao-4757cd0485c229575d68>)[#text("5")]#text(" is probabilistic in nature, but by specialising to a specific type of random vector (and by taking advantage of the freedom to enlarge the vector space ")#mi("{{\\bf C}^m}")#text(", since the bounds are independent of the dimension ")#mi("{m}")#text("), we obtain the following deterministic consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Weaver-type bound)")]#text(" ")#metadata(none) <tao-bd880856a31609e9867e>#text(" Let ")#mi("{m,r,d \\geq 1}")#text(" be integers and ")#mi("{A,B>0}")#text(" be real numbers. Suppose that ")#mi("{w_1,\\ldots,w_m \\in {\\bf C}^d}")#text(" are such that ")#tao-math("{\\left\\|w_i\\right\\|^2 \\leq A}", block: false)#text(" for all ")#mi("{i}")#text(" and ")#metadata(none) <tao-8e4af3b22bfc58325bd9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{i=1}^m \\left|\\langle u, w_i \\rangle\\right|^2 = B", block: true)]]

#text("for every unit vector ")#mi("{u \\in{\\bf C}^d}")#text(" (i.e., ")#mi("{w_1,\\ldots,w_n}")#text(" is a ")#mi("{B}")#text("–")#link("http://en.wikipedia.org/wiki/Frame_of_a_vector_space#Tight_frames")[#text("tight frame")]#text("), then there exists a partition ")#mi("{\\{1,\\ldots,m\\} = S_1 \\cup \\ldots \\cup S_r}")#text(" into ")#mi("{r}")#text(" components such that ")#metadata(none) <tao-d9d92193adfbe5c885db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{i \\in S_j} \\left|\\langle u, w_i \\rangle\\right|^2 \\leq A + 2 r^{-1/2} A^{1/2} B^{1/2} + r^{-1} B", block: true)]]

#text("for ")#mi("{j=1,\\ldots,r}")#text(" and every unit vector ")#mi("{u \\in {\\bf C}^d}")#text(".")
]

#emph[#text("Proof:")]#text(" Let notation and the hypotheses be as in the theorem. Define the independent random vectors ")#mi("{v_1,\\ldots,v_m \\in {\\bf C}^{d} \\otimes {\\bf C}^r}")#text(" in the ")#mi("{dr}")#text("-dimensional ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{{\\bf C}^d \\otimes {\\bf C}^r}")#text(" of ")#mi("{{\\bf C}^d}")#text(" and ")#mi("{{\\bf C}^r}")#text(" by setting ")#metadata(none) <tao-5536cb516a92ceb12a0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("v_i := \\frac{\\sqrt{r}}{\\sqrt{B}} w_i \\otimes e_{j_i}")]]

#text("for each ")#mi("{i=1,\\ldots,m}")#text(", where ")#mi("{j_1,\\ldots,j_m}")#text(" are sampled uniformly and independently from ")#mi("{\\{1,\\ldots,r\\}}")#text(". From ")#link(<tao-8e4af3b22bfc58325bd9>)[#text("(12)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^m w_i w_i^* = B")]]

#text("so a brief calculation shows that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\sum_{i=1}^m v_i v_i^* = 1.")]]

#text("(Here ")#mi("{1}")#text(" is the identity transformation on ")#mi("{{\\bf C}^d \\otimes {\\bf C}^r}")#text(".) Also, we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} \\left\\|v_i\\right\\|^2 \\leq \\frac{rA}{B}", block: true)]]

#text("for all ")#mi("{i}")#text(". Applying Theorem ")#link(<tao-4757cd0485c229575d68>)[#text("5")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^m v_i v_i^* \\right\\|_{op} \\leq (1 + \\sqrt{\\frac{rA}{B}})^2", block: true)]]

#text("with positive probability. In particular, this occurs for at least one realisation of the ")#mi("{v_i}")#text(". Setting ")#mi("{S_j}")#text(" to be those ")#mi("{i}")#text(" for which ")#mi("{j_i=j}")#text(" for each ")#mi("{j=1,\\ldots,r}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in S_j} \\frac{r}{B} w_i w_i^* \\right\\|_{op} \\leq (1 + \\sqrt{\\frac{rA}{B}})^2", block: true)]]

#text("for ")#mi("{j=1,\\dots,r}")#text("; testing this against a unit vector ")#mi("{u}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i \\in S_j} \\left|\\langle w_i,u\\rangle\\right|^2 \\leq \\frac{B}{r} (1 + \\sqrt{\\frac{rA}{B}})^2,", block: true)]]

#text("and the claim follows after a little arithmetic. ")#mi("\\Box")

#text("For a given ")#mi("{r \\geq 2}")#text(", the Weaver conjecture ")#mi("{KS_r}")#text(" asserts for ")#mi("{A=1}")#text(" the existence of a ")#mi("{B}")#text(" such that the above theorem holds with the upper bound in ")#link(<tao-d9d92193adfbe5c885db>)[#text("(13)")]#text(" replaced by ")#mi("{B-\\delta}")#text(" for some absolute constant ")#mi("{\\delta>0}")#text(". This is easily seen to follow from ")#link(<tao-d9d92193adfbe5c885db>)[#text("(13)")]#text(" by taking ")#mi("{B}")#text(" large enough. For instance (as noted by Marcus, Spielman, and Srivastava), if one takes ")#mi("{r=2, A=1, B=18}")#text(" then the upper bound in ")#link(<tao-d9d92193adfbe5c885db>)[#text("(13)")]#text(" is ")#mi("{16}")#text(", giving the case ")#mi("{KS_2}")#text(" of Weaver’s conjecture, which was already known to imply the Kadison-Singer conjecture (see e.g. ")#link("http://arxiv.org/abs/1109.6077")[#text("this paper of Bice")]#text(" for an ultrafilter-based proof of this fact). Note also that in the large ")#mi("{r}")#text(" limit (keeping ")#mi("{A}")#text(" fixed), the bound in ")#link(<tao-d9d92193adfbe5c885db>)[#text("(13)")]#text(" approaches ")#mi("{A}")#text(", which is the optimal value (as can be seen by considering the case where each ")#mi("{v_i}")#text(" has the maximal magnitude of ")#mi("{A^{1/2}}")#text("); this will be important later.")

#text("We can dualise Theorem ")#link(<tao-bd880856a31609e9867e>)[#text("22")]#text(" as follows, giving a bound of ")#link("http://www.ams.org/mathscinet-getitem?mr=1086563")[#text("Akemann-Anderson")]#text(" type:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 23 (Paving conjecture for projections)")]#text(" ")#metadata(none) <tao-244210e48437b6556980>#text(" Let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{P = (p_{ij})_{1\\leq i,j \\leq m}}")#text(" be an ")#mi("{m \\times m}")#text(" orthogonal projection matrix, that is to say an idempotent Hermitian matrix. Suppose that we have the bound ")#mi("{p_{ii} \\leq \\varepsilon}")#text(" for all ")#mi("{1 \\leq i\\leq m}")#text(" and some ")#mi("{\\varepsilon>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_r}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_r}")#text(" (i.e. the ")#mi("{Q_1,\\ldots,Q_r}")#text(" are diagonal matrices with ")#mi("{0}")#text("s and ")#mi("{1}")#text("s on the diagonal, that sum to the identity matrix) such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q_j PQ_j\\right\\|_{op} \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1}", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{V}")#text(" be the range of ")#mi("{P}")#text(", then ")#mi("{P e_1,\\ldots, P e_m}")#text(" are vectors in ")#mi("{V}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P e_i \\right\\|^2 = \\langle P e_i, e_i \\rangle = p_{ii} \\leq \\varepsilon.", block: true)]]

#text("Also, for any unit vector ")#mi("{u \\in V}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{i=1}^m \\left|\\langle u, Pe_i \\rangle\\right|^2  & = \\sum_{i=1}^m \\left|\\langle Pu, e_i \\rangle\\right|^2", block: true)



#tao-math(" & = \\left\\|Pu \\right\\|^2", block: true)



#tao-math(" & = \\left\\|u\\right\\|^2", block: true)



#tao-math(" & = 1.", block: true)
]

#text("Applying Theorem ")#link(<tao-bd880856a31609e9867e>)[#text("22")]#text(" with ")#mi("{w_i := Pe_i}")#text(", ")#mi("{A := \\varepsilon}")#text(", ")#mi("{B := 1}")#text(", we can find a partition ")#mi("{\\{1,\\ldots,m\\} = S_1 \\cup \\ldots \\cup S_r}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i \\in S_j} \\left|\\langle u, Pe_i \\rangle\\right|^2 \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1}", block: true)]]

#text("for all unit vectors ")#mi("{u \\in V}")#text(" and ")#mi("{j=1,\\ldots,r}")#text(". If we let ")#mi("{Q_j}")#text(" be the diagonal projection ")#mi("{Q = \\sum_{i \\in S_j} e_ie_i^*}")#text(", then")

#tao-aligned(keep: true)[


#tao-math("\\sum_{i \\in S_j} \\left|\\langle u, Pe_i \\rangle\\right|^2  & = \\sum_{i \\in S_j} \\left|\\langle Pu,e_i \\rangle\\right|^2", block: true)



#tao-math(" & = \\sum_{i \\in S_j} \\left|\\langle u, e_i \\rangle\\right|^2", block: true)



#tao-math(" & = \\left\\| Q_ju \\right\\|^2", block: true)
]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_ju \\right\\| \\leq (\\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1})^{1/2} \\left\\|u\\right\\|", block: true)]]

#text("for all ")#mi("{u}")#text(" in ")#mi("{V}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_jP \\right\\|_{op} \\leq (\\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1})^{1/2}", block: true)]]

#text("and thus on squaring")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j P Q_j\\right\\|_{op} \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1}", block: true)]]

#text("as desired. ")#mi("\\Box")

#text("This is a special case of the Kadison-Singer paving conjecture, but we may use a number of standard maneuvers to ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" this to the full paving conjecture, loosely following the papers ")#link("http://arxiv.org/abs/1303.1424")[#text("of Popa")]#text(" and ")#link("http://arxiv.org/abs/1308.5276")[#text("of Akemann-Weaver")]#text(". First, by using the “")#link("http://en.wikipedia.org/wiki/Naimark%27s_dilation_theorem")[#text("dilation trick")]#text("“, we may relax the hypothesis of being a projection:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 24 (Paving conjecture for positive semi-definite matrices)")]#text(" ")#metadata(none) <tao-c492f1f6fc7d06ebdf5a>#text(" Let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{P = (p_{ij})_{1\\leq i,j \\leq m}}")#text(" be a Hermitian positive semi-definite ")#mi("{m \\times m}")#text(" matrix with the bound ")#tao-math("{\\left\\|P\\right\\|_{op} \\leq A}", block: false)#text(" for some ")#mi("{A>0}")#text(". Suppose that we have the bound ")#mi("{p_{ii} \\leq \\varepsilon}")#text(" for all ")#mi("{1 \\leq i\\leq m}")#text(" and some ")#mi("{\\varepsilon>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_r}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_r}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q_j PQ_j\\right\\|_{op} \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon A} + r^{-1} A", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r}")#text(".")
]

#emph[#text("Proof:")]#text(" By scaling we may set ")#mi("{A=1}")#text(". The matrix ")#mi("{P}")#text(" is no longer a projection matrix, but by the spectral theorem and the hypotheses on ")#mi("{P}")#text(", we still have a decomposition of the form")

#align(center)[#tao-fit-display[#mitex("P = \\sum_{i=1}^m \\lambda_i u_i u_i^*")]]

#text("where ")#mi("{u_1,\\ldots,u_m}")#text(" are an orthonormal basis for ")#mi("{{\\bf C}^m}")#text(", and ")#mi("{0 \\leq \\lambda_i \\leq 1}")#text(" for all ")#mi("{i}")#text(".")

#text("Now we embed ")#mi("{{\\bf C}^m}")#text(" in ")#mi("{{\\bf C}^m \\oplus {\\bf C}^M}")#text(" for some large ")#mi("{M}")#text(". If ")#mi("{M}")#text(" is large enough (depending on ")#mi("{m,\\varepsilon}")#text("), we may find orthonormal vectors ")#mi("{v_1,\\ldots,v_m \\in {\\bf C}^M}")#text(" with disjoint supports, such that each of the ")#mi("{v_j}")#text(" have coefficients of magnitude at most ")#mi("{\\varepsilon^{1/2}}")#text(". We may then form the dilated vectors")

#align(center)[#tao-fit-display[#mitex("\\tilde u_i := \\sqrt{\\lambda_i} u_i \\oplus \\sqrt{1-\\lambda_i} v_i")]]

#text("which are an orthonormal system in ")#mi("{{\\bf C}^m \\oplus {\\bf C}^M}")#text(", and the dilated operator")

#align(center)[#tao-fit-display[#mitex("P^{\\prime} := \\sum_{i=1}^m \\tilde u_i \\tilde u_i^*")]]

#text("which is an orthogonal projection on ")#mi("{{\\bf C}^m \\oplus {\\bf C}^M}")#text(". This can be viewed as a ")#mi("{m+M \\times m+M}")#text(" matrix, whose top left ")#mi("{m \\times m}")#text(" minor is ")#mi("{P}")#text(". By construction, all the diagonal entries of this matrix are at most ")#mi("{\\varepsilon}")#text(". Applying Corollary ")#link(<tao-244210e48437b6556980>)[#text("23")]#text(", we may find a partition ")#mi("{1 = Q^{\\prime}_1 + \\ldots + Q^{\\prime}_r}")#text(" of the identity matrix on ")#mi("{{\\bf C}^m \\oplus {\\bf C}^M}")#text(" into diagonal projections ")#mi("{Q^{\\prime}_1,\\ldots,Q^{\\prime}_r}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q^{\\prime}_j P^{\\prime} Q^{\\prime}_j \\right\\|_{op} \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1}", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r}")#text(". If we let ")#mi("{Q_j}")#text(" be the component of ")#mi("{Q^{\\prime}_j}")#text(" that maps ")#mi("{{\\bf C}^m}")#text(" to ")#mi("{{\\bf C}^m}")#text(" (i.e. the top left ")#mi("{m \\times m}")#text(" minor), then the ")#mi("{Q_1,\\ldots,Q_r}")#text(" are diagonal ")#mi("{m \\times m}")#text(" matrices summing to the identity, and we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q_j P Q_j \\right\\|_{op} \\leq \\varepsilon + 2r^{-1/2} \\sqrt{\\varepsilon} + r^{-1}", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r}")#text(", as required. ")#mi("\\Box")

#text("Now we shift by a multiple of the identity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 25 (One-sided paving for Hermitian matrices)")]#text(" ")#metadata(none) <tao-d413f65286221536df21>#text(" Let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{P = (p_{ij})_{1\\leq i,j \\leq m}}")#text(" be a Hermitian ")#mi("{m \\times m}")#text(" matrix with vanishing diagonal, whose eigenvalues lie between ")#mi("{-A}")#text(" and ")#mi("{B}")#text(" for some ")#mi("{A,B>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_r}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_r}")#text(" such that for each ")#mi("{1 \\leq j \\leq r}")#text(", the eigenvalues of ")#mi("{Q_j P Q_j}")#text(" lie between ")#mi("{-A}")#text(" and ")#mi("{2 r^{-1/2} \\sqrt{A(A+B)} + r^{-1} (A+B)}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Corollary ")#link(<tao-c492f1f6fc7d06ebdf5a>)[#text("24")]#text(" with ")#mi("{P}")#text(" replaced by ")#mi("{P+A}")#text(", ")#mi("{A}")#text(" replaced by ")#mi("{A+B}")#text(", and ")#mi("{\\varepsilon}")#text(" set equal to ")#mi("{A}")#text(". ")#mi("\\Box")

#text("We combine this result with its reflection:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 26 (Paving conjecture for Hermitian matrices)")]#text(" Let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{P = (p_{ij})_{1\\leq i,j \\leq m}}")#text(" be a Hermitian ")#mi("{m \\times m}")#text(" matrix with vanishing diagonal, with ")#tao-math("{\\left\\|P\\right\\|_{op} \\leq A}", block: false)#text(" for some ")#mi("{A>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_{r^2}}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_{r^2}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j P Q_j \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r^2}")#text(".")
]

#emph[#text("Proof:")]#text(" The eigenvalues of ")#mi("{P}")#text(" lie between ")#mi("{-A}")#text(" and ")#mi("{A}")#text(". By Corollary ")#link(<tao-d413f65286221536df21>)[#text("25")]#text(", we may find a partition ")#mi("{1 = Q_1 + \\ldots + Q_r}")#text(" into diagonal projections such that each ")#mi("{Q_j P Q_j}")#text(" have eigenvalues between ")#mi("{-A}")#text(" and ")#mi("{2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A}")#text("; of course these matrices also have eigenvalues between ")#mi("{-A}")#text(" and ")#mi("{A}")#text(" and have zero diagonal. Thus, for each ")#mi("{j}")#text(", we may apply Corollary ")#link(<tao-d413f65286221536df21>)[#text("25")]#text(" to ")#mi("{-Q_jPQ_j}")#text(" to find a further splitting ")#mi("{1 = Q_{j,1} + \\ldots + Q_{j,r}}")#text(" into diagonal projections such that ")#mi("{-Q_{j,j^{\\prime}} Q_j P Q_j Q_{j,j^{\\prime}}}")#text(" lie between ")#mi("{-A}")#text(" and ")#mi("{2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A}")#text(". The eigenvalues of ")#mi("{Q_{j,j^{\\prime}} Q_j P Q_j Q_{j,j^{\\prime}}}")#text(" are then bounded in magnitude by ")#mi("{2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A}")#text(", and the claim follows by using the partition ")#mi("{1 = \\sum_{j=1}^r \\sum_{j^{\\prime}=1}^r Q_{j,j^{\\prime}} Q_j}")#text(". ")#mi("\\Box")

#text("Finally, we remove the Hermitian condition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 27 (Paving conjecture for finite matrices)")]#text(" ")#metadata(none) <tao-6350eac584f6733f5648>#text(" Let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{P = (p_{ij})_{1\\leq i,j \\leq m}}")#text(" be a matrix with vanishing diagonal, with ")#tao-math("{\\left\\|P\\right\\|_{op} \\leq A}", block: false)#text(" for some ")#mi("{A>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_{r^4}}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_{r^4}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j P Q_j \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r^4}")#text(".")
]

#emph[#text("Proof:")]#text(" By applying the preceding corollary to the Hermitian matrices ")#mi("{P+P^*}")#text(" and ")#mi("{i(P-P^*)}")#text(", which both have operator norm at most ")#mi("{2A}")#text(", we may find partitions ")#mi("{1 = Q_1 + \\ldots + Q_{r^2}}")#text(" and ")#mi("{1= Q^{\\prime}_1 + \\ldots + Q^{\\prime}_{r^2}}")#text(" into diagonal projections such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j (P+P^*) Q_j \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q^{\\prime}_{j^{\\prime}} i(P-P^*) Q^{\\prime}_{j^{\\prime}} \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{1 \\leq j,j^{\\prime} \\leq r^2}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q^{\\prime}_{j^{\\prime}} Q_j (P \\pm P^*) Q_j Q^{\\prime}_{j^{\\prime}} \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("(note that ")#mi("{Q_j, Q^{\\prime}_{j^{\\prime}}}")#text(" commute). The claim then follows from the triangle inequality. ")#mi("\\Box")

#text("Because the bound here is independent of the dimension ")#mi("{m}")#text(", we may use a standard compactness argument to handle infinite matrices:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 28 (Paving conjecture for infinite matrices)")]#text(" ")#metadata(none) <tao-0364c8c5e2b4b8035433>#text(" Let ")#mi("{P = (p_{ij})_{i,j > 0}}")#text(" be an infinite matrix with vanishing diagonal, with ")#tao-math("{\\left\\|P\\right\\|_{op} \\leq A}", block: false)#text(" for some ")#mi("{A>0}")#text(". Then, for any ")#mi("{r \\geq 1}")#text(", there exists a partition ")#mi("{1 = Q_1 + \\ldots + Q_{r^4}}")#text(" of the identity into diagonal projections ")#mi("{Q_1,\\ldots,Q_{r^4}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j P Q_j \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r^4}")#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{m\\geq 1}")#text(", let ")#mi("{P^{(m)} := (p_{ij} 1_{i \\leq m} 1_{j \\leq m})_{i,j>0}}")#text(" be the top ")#mi("{m \\times m}")#text(" minor of ")#mi("{P}")#text(", extended by zero to an infinite matrix. This matrix has zeroes on the diagonal and has operator norm at most ")#mi("{A}")#text(". Applying Corollary ")#link(<tao-6350eac584f6733f5648>)[#text("27")]#text(" to the ")#mi("{m\\times m}")#text(" minor of ")#mi("{P}")#text(" and then extending, we may find a partition ")#mi("{1 = \\sum_{j=1}^{r^4} Q^{(m)}_j}")#text(" into diagonal projections ")#mi("{Q^{(m)}_1,\\ldots,Q^{(m)}_{r^4}}")#text(" such that ")#metadata(none) <tao-329f0733b2bfdc69f4b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\|Q_j^{(m)} P^{(m)} Q_j^{(m)} \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,r^4}")#text(".")

#text("By the Arzela-Ascoli theorem (or the sequential Banach-Alaoglu theorem), we may pass to a subsequence ")#mi("{m_l}")#text(" such that each of the ")#mi("{Q^{(m_l)}_j}")#text(" converges pointwise to a limit ")#mi("{Q_j}")#text(" (i.e. each coefficient of the matrix ")#mi("{Q^{(m_l)}_j}")#text(" converges as ")#mi("{l \\rightarrow \\infty}")#text(" to the corresponding coefficient of ")#mi("{Q_j}")#text(". As the ")#mi("{Q^{(m_l)}_j}")#text(" are diagonal projections, the ")#mi("{Q_j}")#text(" are as well; since ")#mi("{1 = \\sum_{j=1}^{r^4} Q^{(m_l)}_j}")#text(", we see on taking pointwise limits that ")#mi("{1 = \\sum_{j=1}^{r^4} Q_j}")#text(".")

#text("Now let ")#mi("{u, v}")#text(" be unit vectors in ")#mi("{\\ell^2({\\bf N})}")#text(" with finite support. Then ")#mi("{Q_j^{(m_l)} u = Q_j u}")#text(" for sufficiently large ")#mi("{l}")#text(", and similarly ")#mi("{Q_j^{(m_l)} v = Q_j v}")#text(". As ")#mi("{Q_j u}")#text(" and ")#mi("{Q_j v}")#text(" have finite support, we also have ")#mi("{P^{(m_l)} Q_j u = P Q_j u}")#text(" on the support of ")#mi("{Q_j v}")#text(" for sufficiently large ")#mi("{l}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\langle P^{(m_l)} Q_j^{(m_l)} u, Q_j^{(m_l)} v \\rangle = \\langle P Q_j u, Q_j v \\rangle = \\langle Q_j P Q_j u, v \\rangle")]]

#text("for sufficiently large ")#mi("{m}")#text(". By ")#link(<tao-329f0733b2bfdc69f4b8>)[#text("(15)")]#text(" and the Cauchy-Schwarz inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle Q_j P Q_j u, v \\rangle\\right| \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A;", block: true)]]

#text("taking suprema over all unit vectors ")#mi("{u,v}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Q_j P Q_j \\right\\|_{op} \\leq 2 \\sqrt{2} r^{-1/2} A + 2 r^{-1} A", block: true)]]

#text("for all ")#mi("{1 \\leq j \\leq r^4}")#text(" as required. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 5. The Kadison-Singer problem — ")]]

#text("To turn to the original formulation of the Kadison-Singer problem, we need some terminology from ")#mi("{C^*}")#text("-algebras. We will work with two specific ")#mi("{C^*}")#text(" algebras: the space ")#mi("{B( \\ell^2( {\\bf N} ) )}")#text(" of bounded linear operators on ")#mi("{\\ell^2({\\bf N})}")#text(" (or equivalently, infinite matrices with bounded operator norm); and the subspace ")#mi("{A \\subset B( \\ell^2( {\\bf N} ) )}")#text(" of diagonal matrices in ")#mi("{B(\\ell^2({\\bf N}))}")#text(". These are both examples of ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebras")]#text(", but we will not need the specific definition of a ")#mi("{C^*}")#text("-algebra in what follows.")

#text("A ")#emph[#text("state")]#text(" ")#mi("{\\phi: B(\\ell^2({\\bf N})) \\rightarrow {\\bf C}}")#text(" on ")#mi("{B(\\ell^2({\\bf N}))}")#text(" is a bounded linear functional on ")#mi("{B(\\ell^2({\\bf N}))}")#text(" with ")#mi("{\\phi(1)=1}")#text(", such that ")#mi("{\\phi(Q) \\geq 0}")#text(" for all positive semi-definite ")#mi("{Q \\in B(\\ell^2({\\bf N}))}")#text(". A state ")#mi("{\\phi: B(\\ell^2({\\bf N})) \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("pure")]#text(" if it cannot be represented as a convex combination of two other states. Define a state ")#mi("{\\phi: A \\rightarrow {\\bf C}}")#text(" (and a pure state ")#mi("{\\phi: A \\rightarrow {\\bf C}}")#text(") similarly.")

#text("The Kadison-Singer problem, now solved in the affirmative by Marcus, Spielman, and Srivastava, states the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 29 (Kadison-Singer problem)")]#text(" Let ")#mi("{\\phi: A \\rightarrow {\\bf C}}")#text(" be a pure state. Then there is a unique state ")#mi("{\\psi: B(\\ell^2({\\bf N})) \\rightarrow {\\bf C}}")#text(" that extends ")#mi("{\\phi}")#text(". (In particular, this state is automatically pure).")
]

#text("Existence of ")#mi("{\\psi}")#text(" is easy: set ")#mi("{\\psi(Q):= \\phi(\\text{diag}(Q))}")#text(", where ")#mi("{\\text{diag}(Q)}")#text(" is the matrix ")#mi("{Q}")#text(" with all off-diagonal entries set to zero. The hard part is uniqueness. To solve this problem, let us first understand the structure of pure states on ")#mi("{A}")#text(".")

#text("Let ")#mi("{\\phi: A \\rightarrow {\\bf C}}")#text(", and let ")#mi("{P \\in A}")#text(" be a diagonal projection matrix. Since ")#mi("{P}")#text(" and ")#mi("{1-P}")#text(" are both positive semi-definite, we have ")#mi("{\\phi(P), \\phi(1-P) \\geq 0}")#text(", and hence ")#mi("{0 \\leq \\phi(P) \\leq 1}")#text(". We in fact claim that either ")#mi("{\\phi(P)=0}")#text(" or ")#mi("{\\phi(P)=1}")#text(". Indeed, suppose that ")#mi("{\\phi(P) = \\theta}")#text(" for some ")#mi("{0< \\theta < 1}")#text(". Then we can write ")#mi("{\\phi = (1-\\theta) \\phi_0 + \\theta \\phi_1}")#text(", where ")#mi("{\\phi_1(Q) := \\frac{1}{\\theta} \\phi(PQ)}")#text(" and ")#mi("{\\phi_0(Q) := \\frac{1}{1-\\theta} \\phi((1-P)Q)}")#text(". It is easy to see that ")#mi("{\\phi_0,\\phi_1}")#text(" are both states on ")#mi("{A}")#text(", contradicting the hypothesis that ")#mi("{\\phi}")#text(" is pure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 30")]#text(" With only a little more effort, this argument shows that the pure states of ")#mi("{A}")#text(" are in one-to-one correspondence with the ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" of ")#mi("{{\\bf N}}")#text(", but we will not need to use the finer properties of ultrafilters here.")
]

#text("Now we show uniqueness. Let ")#mi("{\\psi: B(\\ell^2({\\bf N})) \\rightarrow {\\bf C}}")#text(" be a state extending ")#mi("{\\phi}")#text(". Let ")#mi("{Q \\in B(\\ell^2({\\bf N}))}")#text("; our task is to show that ")#mi("{\\psi(Q) = \\phi( \\text{diag}(Q))}")#text(". By subtracting off ")#mi("{\\text{diag}(Q)}")#text(", we may assume that ")#mi("{Q}")#text(" has zero diagonal. Our task is now to show that ")#mi("{\\psi(Q)=0}")#text(".")

#text("Let ")#mi("{\\varepsilon > 0}")#text(". By Corollary ")#link(<tao-0364c8c5e2b4b8035433>)[#text("28")]#text(" (with ")#mi("{r}")#text(" sufficiently large), we may find a partition ")#mi("{1 = P_1 +\\ldots + P_s}")#text(" into diagonal projections ")#mi("{P_1,\\ldots,P_s}")#text(" such that ")#metadata(none) <tao-0b9c74d3c83d68ae32be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\|P_j Q P_j \\right\\|_{op} \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,s}")#text(".")

#text("Recall that ")#mi("{\\psi(P_j) = \\phi(P_j)}")#text(" is either ")#mi("{0}")#text(" or ")#mi("{1}")#text("; since ")#mi("{1 = \\phi(1) = \\sum_j \\phi(P_j)}")#text(", we have ")#mi("{\\phi(P_j)=1}")#text(" for exactly one ")#mi("{j}")#text(", say ")#mi("{j=j_0}")#text(", and ")#mi("{\\phi(P_j)=0}")#text(" for all other ")#mi("{j}")#text(".")

#text("Suppose that ")#mi("{1 \\leq j \\leq s}")#text(" is such that ")#mi("{j \\neq j_0}")#text(". Since ")#mi("{\\langle A, B \\rangle:= \\psi(AB^*)}")#text(" is a Hermitian semi-definite inner product on ")#mi("{B(\\ell^2({\\bf N}))}")#text(", we have the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi(P_j^* R)\\right| \\leq \\psi(P_j^* P_j)^{1/2} \\psi(R^* R_j);", block: true)]]

#text("since ")#mi("{\\psi(P_j^* P_j)=\\psi(P_j) = 0}")#text(", we conclude that ")#mi("{\\psi(P_j R)=0}")#text(" for all ")#mi("{j \\neq j_0}")#text(" and ")#mi("{R \\in B(\\ell^2({\\bf N}))}")#text("; similarly ")#mi("{\\psi(R P_j)=0}")#text(". We conclude that ")#mi("{\\psi(Q) = \\psi(P_{j_0} Q P_{j_0})}")#text(", and hence by ")#link(<tao-0b9c74d3c83d68ae32be>)[#text("(16)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi(Q)\\right| \\leq \\left\\|\\psi\\right\\| \\varepsilon", block: true)]]

#text("where ")#tao-math("{\\left\\|\\psi\\right\\|}", block: false)#text(" is the operator norm of ")#mi("{\\psi}")#text(". Since ")#mi("{\\varepsilon}")#text(" may be arbitrarily small, we conclude that ")#mi("{\\psi(Q)=0}")#text(" as required.")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f4fb0ca9948db4503afa5f12ef6d55a7f447f71052cb3744ed9ee40dde5085-6965c062de31ed516730580e9eca7789aea877f931dbac1a169099ebb5eeee59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-249997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("Your first few references to the authors misspell Nikhil Srivastava’s last name as Srinivasta.")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250003")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("In Theorems 6 and 7 the expected value is missing for the trace, and in Theorem 7, the last statement does not agree with the one in Theorem 6. Also, above Theorem 7, the reference is to Proposition 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CO")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250071")[#strong[#text("CO")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("A few small corrections: Parentheses before 1-\\lambda are missing on lines 4, 7 and 8 in the proof of Lemma 14. In Corollary 15, matrices are independent and the inequalities are not strict. In the proof of Corollary 15 – iterating Lemma 14. In the proof of Lemma 17 (first line), the claim follows from Lemma 16.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eecd66a337c2a4e86e826a83728d9e8eafa931528e06c8e39a12720fd9c72ab9-a2f288599044367771d0e441dea02b25f62c0a5c58b10e26624a15bcdd990a33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250213")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Thanks for the beautiful post.")#linebreak()#text(" A pure state is one that cannot be written as a *convex* combination of other states; one may write some pure states as linear combinations of other states (second paragraph of last section).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250291")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("Dear Prof. Tao,")

#text("thanks for the beautiful post.")

#text("I have a question regarding Lemma 12: It seems to me that real stable polynomials are NOT invariant under restriction. Consider the polynomial p(z_1, z_2) = z_2^2. According to the definition, p is real stable (for every zero, we have z_2 = 0, i.e. (z_1, z_2) is no member of the “upper half plane”).")

#text("But if we substitute z_2 = t := 0, then we get p(z_1, t) = 0, which is NOT real stable.")

#text("(The application of Rouches Theorem in the proof fails if the polynomial p(z_1, \\dots, z_{m-2}, z, t) vanishes identical as a function of z.)")

#text("I am sorry if I am making some silly mistake.")

#text("Best regards,")

#text("Felix V.")

#emph[#text("[Clarified that the restriction property only holds when the restricted polynomial is not identically zero. (In the applications, all the polynomials are monic in at least one of the variables and so are not identically zero.) -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250372")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("z_2^2 is not real stable, for example, it has a root (i, 0).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250393")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("Dear Terry,")

#text("I think your clarification is a bit confusing and unnecessary. The polynomial can not become identically zero, because the same argument by Rouche’s theorem would imply that the original polynomial was not stable, wouldn’t it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250395")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("Sorry, you are right, I was confused.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251054")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("Thank you very much for the clarification.")

#text("So an alternative argument (avoiding Rouches’ theorem) would be that p(\\cdot, …, \\cdot, t + i/n) converges locally uniformly to p(\\cdot, …, \\cdot, t) and has no zeros on the upper half plane, so that (a multidimensional form of) Hurwitz’ theorem (")#link("http://en.wikipedia.org/wiki/Hurwitz%27s_theorem_%28complex_analysis%29#Applications")[#text("http://en.wikipedia.org/wiki/Hurwitz%27s_theorem_%28complex_analysis%29#Applications")]#text(" ) implies that p(\\cdot, …, \\cdot, t) vanishes identically or has no zeros on the upper half plane.")

#text("I have another question regarding the proof of lemma 17. You state that by excluding finitely many points, the zeros can be smoothly parameterized. Can you give me a hint on where to look that up or how to show it?")

#text("It is clear that the claim follows by the implicit function theorem as long as \\frac{\\partial}{\\partial z_1} p(z_1, z_2) \\neq 0 for all zeros z_2 of p(z_1, \\cdot), but I don’t see why this should be true for all but finitely many points.")

#text("Am I missing something?")

#text("Best regards,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251091")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("In my last comment I meant \\frac{\\partial}{\\partial x_2} instead of x_1. This is then of course the same as to say that all zeros have multiplicity one.")

#text("As you explicitly state that you do NOT exclude this case (after all, this could happen for ALL x1), I am even more at a loss.")

#text("Any help would be appreciated.")

#text("Best regards,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("Here I am using the fact that an irreducible algebraic curve is smooth at all but finitely many points. (Indeed, if the curve is given by ")#mi("\\{P(x,y) = 0\\}")#text(" for some irreducible P, then the partial derivatives of P are coprime to P, so by Bezout’s theorem there are only finitely many points where P and ")#mi("\\nabla P")#text(" both vanish.) For similar reasons, there are only finitely many points where the gradient is horizontal, unless the curve is a vertical line (which can be excluded here).")

#text("In this setting, P need not be irreducible, but it can be broken up into irreducible components, which again by Bezout only meet each other in finitely many places. (It is possible for components to appear with multiplicity, but then one can just take a single instance of each component, which will still be smooth away from finitely many points.)")

#text("p.s. one can certainly use Hurwitz’s theorem here in place of Rouche’s theorem, but the former theorem is often presented as a corollary of the latter, so the arguments are not terribly different from each other.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251399")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("Thank you very much. That helped a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-255164")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("Dear Prof. Tao,")

#text("here are a few minor (supposed) mistakes that I found:")

#text("In Lemma 12 “the same sign as t” should be “the opposite sign of t”.")

#text("In Corollary 15 in the expression “we see that X must lie in the convex hull of the Y” (for appropiate values of X,Y) X and Y should have been interchanged.")

#text("In Lemma 16 you mean k! instead of (k-1)! and (x-y_i)^(k+1) instead of (x – y_i)^k.")

#text("In Lemma 20 the “convexity estimate” is incorrect. On the right hand side you have to write \\partial_j \\Phi_q^i (x + \\delta e_j) instead of \\partial_j Phi_q^i (x). (This replacement has also to be made in the next formula).")

#text("In the proof of Theorem 22, the very beginning of the last formula (\\Vert) can be removed. In the line before that: “j=1, \\dots, r” instead of “j=1,2”.")

#text("In the statement of corollary 23: “0s and 1s on the identity” should have been “0s and 1s on the diagonal”.")

#text("Minor improvement: In the statement of Corollary 27 it should be possible to replace both 4s by 2s, as you are using the triangle inequality on P = (P + P*)/2 + (P – P*)/2. This can consequently also be done in Corollary 28.")

#text("Thanks again for the nice post.")

#text("Best regards,")

#text("Felix V.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250401")[#strong[#text("The Kadison-Singer Conjecture has beed Proved by Adam Marcus, Dan Spielman, and Nikhil Srivastava | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")]

#text("[…] Updates: A very nice post on the relation of the Kadison-Singer Conjecture to foundation of quantum mechanics is in this post in Bryan Roberts‘ blog Soul Physics. Here is a very nice post on the mathematics of the conjecture with ten interesting comments on the proof by Orr Shalit, and another nice post on Yemon Choi’s blog. Nov 4, 2013: A new post appeared on Terry tao’s blog, Real stable polynomials and the Kadison Singer Problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250417")[#strong[#text("Mustafa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("There is a typo in Corollary 26: you repeat the “then for r \\geq 1.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0518350fc88d45bfacf0e67fbb3f8bdffb1527585fb5588e4acb381885de9aba-44f1664a705601fdfdd4c982a1e8c9cd2bb18e5fc656f53a83dabbb63ec7a668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TRINH Tuan Phong")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250910")[#strong[#text("TRINH Tuan Phong")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2013")])]

#text("Dear Prof. Tao,")#linebreak()#text(" May I have a question? I wonder whether “x=(x_1,…,x_m) lies above a root z=(z_1,…,z_m) of the polynomial p” in your note means x_j\\geq z_j for some j?")#linebreak()#text(" Best regards,")#linebreak()#text(" TRINH Tuan Phong")

#emph[#text("[For all j, not some j; see text before Lemma 17, and also the proof of Lemma 19. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0518350fc88d45bfacf0e67fbb3f8bdffb1527585fb5588e4acb381885de9aba-44f1664a705601fdfdd4c982a1e8c9cd2bb18e5fc656f53a83dabbb63ec7a668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TRINH Tuan Phong")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251037")[#strong[#text("TRINH Tuan Phong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("Thank you so much for your answer.")#linebreak()#text(" Best regards,")#linebreak()#text(" T.T.Phong")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a470b106d56ae65049580b2fe585d1a0a46b3588cad1a0b70b5073edb1da804d-35e0da9b9a81adb6f8fed9b23a8bb5301dff924fdb892048ce3dcfaed015c612.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Tobler")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-250987")[#strong[#text("Peter Tobler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2013")])]

#text("Hi – hope you don’t mind me raising this minor point – the guy’s name is Srivastava")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd7b6a621acc062b4f11407be479b44ec089dab61db8cc102b53c732f525a5ea-291ba5852cce847aacc4d82a3142dd0ec1277550aaea725f3fa326c7f00f9c51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Casazza")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251443")[#strong[#text("Pete Casazza")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("There is a trivial way to see that paving is equivalent to paving projections with small diagonal. As Teri noted, we may assume T is self-adjoint. Also, we clearly may assume \\|T\\| \\le 1. Now form the square matrix")

#mi("R = \\begin{pmatrix} T & \\sqrt{1-T} \\\\ \\sqrt{1-T} & -T \\end{pmatrix}")

#text("Since R^2=I, P= 1/2(I+R) is a projection with diagonal 1/2 and we can pave")#linebreak()#text(" T if and only if we can pave P. Iterating this, we can reduce to diagonal to")#linebreak()#text(" 1/2^n with the same conclusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/752df130a5897b0c135f0fb1e6ab6b5cb533aa11a41808a67204301d57120295-b49566b97ce359feac7efc5899b426ca959a31d9af43eaa37b209e79fbc99110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-251584")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("In theorem 7: $ maxroot E p $ should be $ maxroot (E p) $.")#linebreak()#text(" In “…are all geerically non-increasing”, geerically should be generically.")#linebreak()#text(" At the end of the proof of Corollary 27, “…commute” should be “…commute)”.")#linebreak()#text(" In Corollary 27 and Corollary 28, “for any $r\\geq 1$, for any $r\\geq 1$” should be “for any $r\\geq 1$”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-302471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#link("http://www.siam.org/prizes/sponsored/polya.php")[#text("http://www.siam.org/prizes/sponsored/polya.php")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-343605")[#strong[#text("Daniel Spielman talks at HUJI – thoughts | Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2014")]

#text("[…] KS2 conjecture, which implies a positive solution to Kadison-Singer (the full story been worked out to expository perfection on Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-417020")[#strong[#text("Fall 2014: Roots of polynomials and probabilistic applications | Stochastic Analysis Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2014")]

#text("[…] Notes by T. Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f183f12d337c6d5888570ec2b8d6d47d7b09a09437135640c03bc23a43fc884e-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Schemaitat")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-429791")[#strong[#text("André Schemaitat")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("In Corollary 28 it is stated that P Q_j u = P^{(m_l)} Q_j u for large l since Q_j u has finite support. Why should this be true ? I.e. if P has many non-zero elements in its rows than P Q_j u won’t even be a vector of finite support.")

#emph[#text("[Oops, this equality should be restricted to the support of ")#mi("Q_j v")#text(". I’ve updated the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-435100")[#strong[#text("Lecture 5. Proof of Kadison-Singer (3) | Stochastic Analysis Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2014")]

#text("[…] of the proof of the Kadison-Singer theorem has largely followed the approach from the blog post by T. Tao, which simplifies some of the arguments in the original paper by A. W. Marcus, D. A. Spielman, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-448985")[#strong[#text("Another one bites the dust (actually many of them) | Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2015")]

#text("[…] there is Terry Tao’s post on this subject that I read and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f75b3f798488279efabce20d8eedca74e66cfec659cfc123a998e57fa589207-ba1dab9236dab3bc10c144d0fd8cc62101a453899aea385147dfe9bcf1469235.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jacobcarruth")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-453946")[#strong[#text("jacobcarruth")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2015")])]

#text("Reblogged this on ")#link("https://jacobcarruth.wordpress.com/2015/04/08/real-stable-polynomials-and-the-kadison-singer-problem/")[#text("jacobcarruth")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2974779f533889fb76725c17cf1336a8617164e207b1a801c673d9d309ae7a3-693dbb6eafdebd52a338e8e1177cfb49cb8cbe46296a6f4c9db502c0d48d2219.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-474423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("In the proof of the second part of Lemma 12, why is it sufficient to freeze all but one variable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-474428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("A polynomial ")#mi("p(z_1,\\dots,z_m)")#text(" is stable iff, whenever ")#mi("w_1,\\dots,w_{m-1}")#text(" have positive imaginary part, the one-variable polynomial ")#mi("z \\mapsto p( w_1,\\dots,w_{m-1},z)")#text(" is stable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous (Sheepish)")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-474439")[#strong[#text("Anonymous (Sheepish)")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2016")])]

#text("Oh duh. I think I was confusing “stable” and “real stable.” Anyways thanks, and I think it’s really cool that you replied :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac2b62556289a7f901ed7de353ab6921dec5d0e8cb58fff79fc31fdf1fa75a-2f1922c5c913a7e392c348c56e074b018ccfda7c468bb3171c9e153e85e835d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bsquare")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-474436")[#strong[#text("bsquare")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2016")])]

#text("Hi M.Tao,")#linebreak()#text(" TO fix Riemann Zeta function, could we use neural networks to predict")#linebreak()#text(" that all solutions are included on a vertical straight line, with good accuracy indeed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0de84f993f4c707f9c52c346952e29ca7474cff81afdeac2cab1ae36d9b5abc9-af498857bf060051de8943b93033771e94b23db767b297b8704f2e12980d3eca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nassoro mtandani")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-474487")[#strong[#text("nassoro mtandani")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("Hi prof. Tao am so interested in mathematics,please help me where do i start and what should i do?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-477268")[#strong[#text("Aleman, Hartz, McCarthy and Richter characterize interpolating sequences in complete Pick spaces | Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2017")]

#text("[…] A reader familiar with Hilbert function spaces, who takes the paving theorem on faith, can understand the proof immediately after reading Chapter 9 in Agler and McCarthy’s monograph. For a very readable exposition of Kadison-Singer including a proof of the paving theorem (following the work of Marcus-Spielman-Srivastava) see Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-514146")[#strong[#text("Un lemme de Tao concernant la stabilité réelle | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2019")]

#text("[…] This Lemma 14 in Tao’s post here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-514157")[#strong[#text("From MSS to Paving | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2019")]

#text("[…] From Tao’s post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d01189e21e2741ce48f48265ba16b69bd0717a67f5117dede2cfb55184804fab-507aa48b02d146c821211ab2d3dff5d9f6ebda1d405aca4d5002bcbf43cb7a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tmukblog")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-569410")[#strong[#text("tmukblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")])]

#text("Just wondering how does one prove that the expression ${\\hbox{det}( z + \\sum_{i=1}^m z_i A_i )}$ is a polynomial combination of the ${z_i A_i}$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-569418")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")])]

#text("The determinant function is a polynomial, thus ")#mi("\\text{det}(z + \\sum_{i=1}^m z_i A_i)")#text(" is a polynomial in the (coefficients of the) ")#mi("z_i A_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-569436")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-573682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2020")])]

#text("Hello Professor Tao, I actually don’t think I follow Corollary 4 of Proposition 3. In Proposition 3, you show that ")#mi("\\mu[A_{1}, \\ldots, A_{m}](z)=p_{A}(z)")#text(" and in corollary 4, you consider the case where the ")#mi("A_{i}")#text(" are random rank one matrices and then assert that ")#mi("\\mu[E[A_{1}, \\ldots, E[A_{m}]]=E[p_{A}]")#text(". I’m trying to follow the case where ")#mi("m=1")#text(", in which case we get that ")#mi("\\mu[E[A]](z) = p_{E[A]}(z)")#text(" (from Proposition 3) but ")#mi("p_{E[A]}(z)")#text(" doesn’t equal ")#mi("E[p_{A}(z)]")#text("? I thought about the case where ")#mi("A")#text(" is random with probability 1/2 of being either the projection ")#mi("[[1,0];[0,0]]")#text(" to the basis vector ")#mi("e_{1}")#text(" in the plane or the projection ")#mi("[[0,0];[0,1]]")#text(" to the basis vector ")#mi("e_{2}")#text(" in the plane, in this silly example ")#mi("E[A]")#text(" is the diagonal matrix with ")#mi("1/2")#text(" on the diagonal entries whose char. polynomial is ")#mi("(z-1/2)^2")#text(" while ")#mi("E[p_{A}]=z(z-1)")#text(". So I must of misunderstood an assumption. As far as the proof given, I think I don’t quite see what happens after you take expectation on both sides. Sorry for the long post and for the latex errors (maybe I should have asked this on MO)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-575161")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2020")])]

#text("In your example you will not in fact have ")#mi("\\mu[E[A]](z)")#text(" equal to ")#mi("p_{E[A]}(z)")#text(" because ")#mi("E[A]")#text(" is not a rank 1 matrix. Instead, ")#mi("\\mu[E[A]](z)")#text(" is equal by definition to")

#mi("\\displaystyle (1 - \\frac{\\partial}{\\partial z_1}) \\mathrm{det}(z + z_1 E[A])|_{z_1=0}")

#mi("\\displaystyle = (1 - \\frac{\\partial}{\\partial z_1}) (z + z_1/2)^2|_{z_1=0}")

#mi("\\displaystyle = (z+z_1/2)^2 - (z+z_1)|_{z_1=0}")

#mi("\\displaystyle = z^2 - z")

#mi("\\displaystyle = {\\bf E}[p_A]")

#text("as claimed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/04/real-stable-polynomials-and-the-kadison-singer-problem/#comment-575343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2020")])]

#text("Oh I see. We need rank one to apply Proposition 3. Thank you for clarifying. I think I understand the proof a little better now.")
]
]
]
