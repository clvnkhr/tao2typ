// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/
// Converted to Typst by tao2typ: "2026-10-14T15:16:36.874411+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 5: Other topological recurrence results", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 5: Other topological recurrence results")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this lecture, we use topological dynamics methods to prove some other ")#link("http://en.wikipedia.org/wiki/Ramsey_theory")[#text("Ramsey-type theorems")]#text(", and more specifically the polynomial van der Waerden theorem, the ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraph")]#text(" ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/IP_set#Hindman.27s_Theorem")[#text("Hindman’s theorem")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Hales-Jewett_theorem")[#text("Hales-Jewett theorem")]#text(". In proving these statements, I have decided to focus on the ultrafilter-based proofs, rather than the combinatorial or topological proofs, though of course these styles of proof are also available for each of the above theorems.")

#metadata(none) <tao-65bacb612dd5b9d19e32>

#heading(level: 1)[#text("— The polynomial van der Waerden theorem —")]

#text("We first prove a significant generalisation of van der Waerden’s theorem (Theorem 2 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Polynomial van der Waerden theorem). Let ")#mi("(P_1,\\ldots,P_k)")#text(" be a tuple of be integer-valued polynomials ")#mi("P_1,\\ldots,P_k: {\\Bbb Z} \\to {\\Bbb Z}")#text(") (or ")#emph[#text("tuple ")]#text("for short) with ")#mi("P_1(0)=\\ldots=P_k(0)")#text(". Then whenever the integers are finitely coloured, one of the colour classes will contain a pattern of the form ")#mi("n + P_1(r), \\ldots, n+P_k(r)")#text(" for some ")#mi("n \\in {\\Bbb Z}")#text(" and ")#mi("r \\in {\\Bbb N}")#text(".")
]

#text("This result is due ")#link("http://www.ams.org/mathscinet-getitem?mr=1325795")[#text("to Bergelson and Leibman")]#text(", who proved it using “epsilon and delta” topological dynamical methods. A combinatorial proof was only obtained rather recently ")#link("http://www.ams.org/mathscinet-getitem?mr=1745405")[#text("by Walters")]#text(". In these notes, I will translate the Bergelson-Leibman argument to the ultrafilter setting.")

#text("Note that the case ")#mi("P_j(r) := (j-1)r")#text(" recovers the ordinary van der Waerden theorem. But the result is significantly stronger; it implies for instance that one of the colour classes contains arbitrarily many shifted geometric progressions ")#mi("n + r, n+r^2, \\ldots, n+r^k")#text(", which does not obviously follow from the van der Waerden theorem. The result here only claims a single monochromatic pattern ")#mi("n + P_1(r), \\ldots, n+P_k(r)")#text(", but it is not hard to amplify this theorem to show that at least one colour class contains infinitely many such patterns.")

#strong[#text("Remark 1")]#text(". The theorem can fail if the hypothesis ")#mi("P_1(0)=\\ldots=P_k(0)")#text(" is dropped; consider for instance the case ")#mi("k = 2")#text(", ")#mi("P_1(r) = 0")#text(", ")#mi("P_2(r) = 2r+1")#text(", and with the integers partitioned (or coloured) into the odd and even integers. More generally, the theorem fails whenever there exists a modulus N such that the polynomials ")#mi("P_1, \\ldots, P_k")#text(" are never simultaneously equal modulo N. This turns out to be the only obstruction; this is a somewhat difficult recent result ")#link("http://front.math.ucdavis.edu/0710.4862")[#text("of Bergelson, Leibman, and Lesigne")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 1")]#text(". Show that the polynomial ")#mi("P(r) := (r^2-2)(r^2-3)(r^2-6)(r^2-7)(r^3-3)")#text(" has a root modulo N for every positive integer N, but has no root in the integers. Thus we see that the Bergelson-Leibman-Lesigne result is stronger than the polynomial van der Waerden theorem; it does not seem possible to directly use the latter to conclude that in every finite colouring of the integers, one of the classes contains the pattern ")#mi("n, n+P(r)")#text(". ")#mi("\\diamond")

#text("Here are the topological dynamics and ultrafilter versions of the above theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (Polynomial van der Waerden theorem, topological dynamics version). Let ")#mi("(P_1,\\ldots,P_k)")#text(" be a tuple with ")#mi("P_1(0)=\\ldots=P_k(0)")#text(". Let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(". Then there exists a set ")#mi("U_\\alpha")#text(" in this cover such that ")#mi("T^{P_1(r)} U \\cap \\ldots \\cap T^{P_k(r)} U \\neq \\emptyset")#text(" for at least one ")#mi("r > 0")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" (Polynomial van der Waerden theorem, ultrafilter version). Let ")#mi("(P_1,\\ldots,P_k)")#text(" be a tuple with ")#mi("P_1(0)=\\ldots=P_k(0)")#text(", and let ")#mi("p \\in \\beta {\\Bbb Z}")#text(" be a minimal ultrafilter. Then there exists ")#mi("q \\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" such that")

#align(center)[#mi("\\lim_{(n,r) \\to q} n + P_i(r) + p = p")#text(" for all ")#mi("1 \\leq i \\leq k")#text(". (1)")]
]

#strong[#text("Exercise 2")]#text(". Show that Theorem 1 and Theorem 2 are equivalent, and that Theorem 3 implies Theorem 2 (or Theorem 1). [For the converse implication, see Exercise 21.] ")#mi("\\diamond")

#text("As in the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(", we shall prove this proposition by induction. However, the induction will be more complicated than just inducting on the number k of polynomials involved, or on the degree of these polynomials, but will instead involve a more complicated measure of the “complexity” of the polynomials being measured. Let us say that a tuple ")#mi("(P_1,\\ldots,P_k)")#text(" ")#emph[#text("obeys the vdW property")]#text(" if the conclusion of Theorem 3 is true for this tuple. Thus for instance, from Proposition 1 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(" we know that any tuple of ")#emph[#text("linear ")]#text("polynomials which vanish at the origin will obey the vdW property.")

#text("Our goal is to show that every tuple of polynomials which simultaneously vanish at the origin has the vdW property. The strategy will be to reduce from any given tuple to a collection of “simpler” tuples. We first begin with an easy observation, that one can always shift one of the polynomials to be zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(". (Translation invariance) Let Q be any integer-valued polynomial. Then a tuple ")#mi("(P_1,\\ldots,P_k)")#text(" obeys the vdW property if and only if ")#mi("(P_1-Q, \\ldots,P_k-Q)")#text(" has the vdW property.")
]

#strong[#text("Proof")]#text(". Let ")#mi("p\\in \\beta {\\Bbb Z}")#text(" be minimal. If ")#mi("(P_1-Q,\\ldots,P_k-Q)")#text(" has the vdW property, then we can find ")#mi("q\\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" such that")

#align(center)[#mi("\\lim_{(n,r) \\to q} n + P_i(r) - Q(r) + p = p")#text(" for all ")#mi("1 \\leq i \\leq k")#text(". (2)")]

#text("If we then define ")#mi("q^{\\prime} := \\lim_{(n,r) \\to q} (n - Q(r),r) \\in \\beta({\\Bbb Z} \\times {\\Bbb N})")#text(" one easily verifies that (1) holds (with q replaced by q’), and the claim holds. The converse implication is similar. ")#mi("\\Box")

#text("Now we come to the key inductive step.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" (Inductive step). Let ")#mi("(P_0,P_1,\\ldots,P_k)")#text(" be a tuple with ")#mi("P_0=0")#text(", and let Q be another integer-valued polynomial. Suppose that for every finite set of integers ")#mi("h_1,\\ldots,h_m")#text(", the tuple ")#mi("( P_i( \\cdot + h_j ) - P_i( h_j ) - Q(\\cdot) )_{1 \\leq i \\leq k; 1 \\leq j \\leq m}")#text(" has the vdW property. Then ")#mi("(0,P_1,\\ldots,P_k)")#text(" also has the vdW property.")
]

#strong[#text("Proof")]#text(". This will be a reprise of the proof of Proposition 1 from the previous lecture. Given any finite number of pairs ")#mi("(n_1,r_1),\\ldots,(n_{b-1},r_{b-1}) \\in {\\Bbb Z} \\times {\\Bbb N}")#text(" with ")#mi("b \\geq 1")#text(", we see from hypothesis that there exists ")#mi("q_b \\in \\beta({\\Bbb Z} \\times {\\Bbb N})")#text(" (depending on these pairs) such that")

#align(center)[#tao-fit-display[#mitex("\\lim_{(n_b,r_b) \\to q_b} n_b + P_i(r_{a+1}+\\ldots+r_b) - P_i(r_{a+1}+\\ldots+r_{b-1})")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("- Q(r_b) + p = p")]]

#text("for all ")#mi("0 \\leq a < b")#text(" and ")#mi("1 \\leq i \\leq k")#text(".")

#text("Now, for every ")#mi("0 \\leq a \\leq b")#text(" and ")#mi("0 \\leq i \\leq k")#text(", consider the expression ")#mi("p_{a,b,i} \\in \\beta {\\Bbb Z} + p")#text(" defined by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("p_{a,b,i} := \\lim_{(n_1,r_1) \\to q_1} \\ldots \\lim_{(n_b,r_b) \\to q_b} P_i(r_{a+1}+\\ldots+r_b) + m_b + p,")]]

#text("where ")#mi("q_1,\\ldots,q_b")#text(" are defined recursively as above and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5).")])
#mitex("m_b := \\sum_{i=1}^b n_i - Q(r_i)")]]

#text("From (3) we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("p_{a,b,i} = p_{a,b-1,i}")]]

#text("for all ")#mi("0 \\leq a < b")#text(" and ")#mi("1 \\leq i \\leq k")#text(", and thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("p_{a,b,i} = p_{a,a,i} = p_{a,a,0}")]]

#text("in this case. For i=0, we have the slightly different identity")

#align(center)[#mi("p_{a,b,0} = p_{b,b,0}")#text(". (7′)")]

#text("We let ")#mi("p_* \\in \\beta {\\Bbb Z}/{\\Bbb Z}")#text(" be arbitrary, and set ")#mi("p^{\\prime} := \\lim_{a \\to p_*} p_{a,a,0} = \\lim_{b \\to p_*} p_{b,b,0} \\in   \\beta {\\Bbb Z} + p")#text(". By the minimality of p, we can find ")#mi("p^{\\prime\\prime} \\in \\beta{\\Bbb Z}")#text(" such that ")#mi("p^{\\prime\\prime}+p^{\\prime}=p")#text(". We thus have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\lim_{h \\to p^{\\prime\\prime}} \\lim_{a \\to p_*} \\lim_{b \\to p_*} h + p_{a,b,i} = p")]]

#text("for all ")#mi("0 \\leq i \\leq k")#text(". If one then sets")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("q :=  \\lim_{h \\to p^{\\prime\\prime}} \\lim_{a \\to p_*} \\lim_{b \\to p_*} \\lim_{(n_1,r_1) \\to q_1} \\ldots \\lim_{(n_b,r_b) \\to q_b} (n,r)")]]

#text("where ")#mi("n := h+m_b")#text(" and ")#mi("r := r_{a+1}+\\ldots+r_b")#text(", one easily verifies (1) as required. ")#mi("\\Box")

#text("Let’s see how this lemma is used in practice. Suppose we wish to show that the tuple ")#mi("(0, r^2)")#text(" has the vdW property (where we use r to denote the independent variable). Applying Lemma 2 with ")#mi("Q(r) := r^2")#text(", we reduce to showing that the tuples ")#mi("((r+h_1)^2 - h_1^2 - r^2, \\ldots, (r+h_m)^2 - h_m^2 - r^2 )")#text(" have the vdW property for all finite collections ")#mi("h_1,\\ldots,h_m")#text(" of integers. But observe that all the polynomials in these tuples are linear polynomials that vanish at the origin. By the ordinary van der Waerden theorem, these tuples all have the vdW property, and so ")#mi("(0,r^2)")#text(" has the vdW property also.")

#text("A similar argument shows that the tuple ")#mi("(0, r^2 + P_1(r), \\ldots, r^2 + P_k(r))")#text(" has the vdW property whenever ")#mi("P_1,\\ldots,P_k")#text(" are linear polynomials that vanish at the origin. Applying Lemma 1, we see that ")#mi("(Q_1(r), r^2 + P_1(r), \\ldots, r^2 + P_k(r))")#text(" obeys the vdW property when ")#mi("Q_1")#text(" is also linear and vanishing at the origin.")

#text("Now, let us consider a tuple ")#mi("(Q_1(r),  Q_2(r), r^2+P_1(r),\\ldots,r^2+P_k(r))")#text(" where ")#mi("Q_2")#text(" is also a linear polynomial that vanishes at the origin. The vdW property for this tuple follows from the previously established vdW properties by first applying Lemma 1 to reduce to the case ")#mi("Q_1=0")#text(", and then applying Lemma 2 with ")#mi("Q=Q_2")#text(". Continuing in this fashion, we see that a tuple ")#mi("(Q_1(r),\\ldots,Q_l(r), r^2+P_1(r),\\ldots,r^2+P_k(r))")#text(" will also obey the vdW property for any linear ")#mi("Q_1,\\ldots,Q_l,P_1,\\ldots,P_k")#text(" that vanish at the origin, for any k and l.")

#text("Now the vdW property for the tuple ")#mi("(0, r^2, 2r^2)")#text(" follows from the previously established cases and Lemma 2 with ")#mi("Q(r) = r^2")#text(".")

#strong[#text("Remark 2.")]#text(" It is possible to continue this inductive procedure (known as ")#emph[#text("PET induction;")]#text(" the PET stands, variously, for “polynomial ergodic theorem” or “polynomial exhaustion theorem”); this is carried out in Exercise 3 below. ")#mi("\\diamond")

#strong[#text("Exercise 3. ")]#text(" Define the ")#emph[#text("top order monomial")]#text(" of a non-zero polynomial ")#mi("P(r) = a_d r^d + \\ldots + a_0")#text(" with ")#mi("a_d \\neq 0")#text(" to be ")#mi("a_d r^d")#text(". Define the top order monomials of a tuple ")#mi("(0,P_1,\\ldots,P_k)")#text(" to be the set of top order monomials of the ")#mi("P_1,\\ldots,P_k")#text(", not counting multiplicity; for instance, the top order monomials of ")#mi("(0, r^2, r^2+r, 2r^2,  2r^2+r)")#text(" are ")#mi("\\{r^2,2r^2\\}")#text(". Define the ")#emph[#text("weight vector")]#text(" of a tuple ")#mi("(P_1,\\ldots,P_k)")#text(" relative to one of its members ")#mi("P_i")#text(" to be the infinite vector ")#mi("(w_1,w_2,\\ldots) \\in {\\Bbb Z}_{\\geq 0}^{\\Bbb N}")#text(", where each ")#mi("w_d")#text(" denotes the number of monomials of degree d in the top order monomials of ")#mi("(P_1-P_i,\\ldots,P_k-P_i)")#text(". Thus for instance, the tuple ")#mi("(0, r^2, r^2+r, 2r^2,  2r^2+r)")#text(" has weight vector ")#mi("(0,2,0,\\ldots)")#text(" with respect to 0, but weight vector ")#mi("(1,2,0,\\ldots)")#text(" with respect to (say) ")#mi("r^2")#text(". Let us say that one weight vector ")#mi("(w_1,w_2,\\ldots)")#text(" is larger than another ")#mi("(w^{\\prime}_1,w^{\\prime}_2,\\ldots)")#text(" if there exists ")#mi("d \\geq 1")#text(" such that ")#mi("w_d > w^{\\prime}_d")#text(" and ")#mi("w_i = w^{\\prime}_i")#text(" for all ")#mi("i > d")#text(".")

#enum(start: 1, 
[#text("Show that the space of all weight vectors is a well-ordered set.")],
[#text("Show that if ")#mi("(0,P_1,\\ldots,P_k)")#text(" is a tuple with ")#mi("k \\geq 1")#text(", ")#mi("P_1")#text(" has the least degree of all the ")#mi("P_i")#text(", and ")#mi("h_1,\\ldots,h_m")#text(" are integers with ")#mi("m \\geq 1")#text(", then the weight vector of ")#mi("( P_i( \\cdot + h_j ) - P_i( h_j ) )_{1 \\leq i \\leq k; 1 \\leq j \\leq m}")#text(" with respect to ")#mi("P_1")#text(" is strictly smaller than the weight vector of ")#mi("(0,P_1,\\ldots,P_k)")#text(" with respect to ")#mi("P_1")#text(".")],
[#text("Using 1., 2., Lemma 1, and Lemma 2, deduce Theorem 3. ")#mi("\\diamond")]
)

#strong[#text("Exercise 4.")]#text(" Find a direct proof of Theorem 2 analogous to the “epsilon and delta” proof of Theorem 4 from the previous lecture. (You can look up the ")#link("http://www.ams.org/mathscinet-getitem?mr=1325795")[#text("paper of Bergelson and Leibman")]#text(" if you’re stuck.) ")#mi("\\diamond")

#strong[#text("Exercise 5")]#text(". Let ")#mi("P_1,\\ldots,P_k: {\\Bbb Z} \\to {\\Bbb Z}^d")#text(" be vector-valued polynomials (thus each of the d components of each of the ")#mi("P_i")#text(" is a polynomial) which all vanish at the origin. Show that if ")#mi("{\\Bbb Z}^d")#text(" is finitely coloured, then one of the colour classes contains a pattern of the form ")#mi("n + P_1(r),\\ldots,n+P_k(r)")#text(" for some ")#mi("n \\in {\\Bbb Z}^d")#text(" and ")#mi("r \\in {\\Bbb N}")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 6")]#text(". Show that for any polynomial sequence ")#mi("P: {\\Bbb Z} \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" taking values in a torus, there exists integers ")#mi("n_j \\to \\infty")#text(" such that ")#mi("P(n_j)")#text(" converges to ")#mi("P(0)")#text(". (One can also tweak the argument to make the ")#mi("n_j")#text(" converge to positive infinity, by the “doubling up” trick of replacing P(n) with (P(n),P(-n)).) On the other hand, show that this claim can fail with exponential sequences such as ")#mi("P(n) := 10^n \\alpha \\text{ mod } 1 \\in {\\Bbb R}/{\\Bbb Z}")#text(" for certain values of ")#mi("\\alpha")#text(". Thus we see that polynomials have better recurrence properties than exponentials. ")#mi("\\diamond")

#heading(level: 1)[#text("— Ramsey’s theorem —")]

#text("Given any finite palette K of colours, a vertex set V, and an integer ")#mi("k  \\geq 1")#text(", define a ")#emph[#text("K-coloured hypergraph")]#text(" G = (V,E) of order k on V to be a function ")#mi("E: \\binom{V}{k} \\to K")#text(", where ")#tao-math("\\binom{V}{k} := \\{ e \\subset V: \\left|e\\right|=k\\}", block: false)#text(" denotes the k-element subsets of V. Thus for instance a hypergraph of order 1 is a vertex colouring, a hypergraph of order 2 is an edge-coloured complete graph, and so forth. We say that a hypergraph G is ")#emph[#text("monochromatic")]#text(" if the edge colouring function E is constant. If W is a subset of V, we refer to the hypergraph ")#mi("G\\downharpoonright_W := (W, E\\downharpoonright_{\\binom{W}{k}})")#text(" as a ")#emph[#text("subhypergraph")]#text(" of G.")

#text("We will now prove the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" (Hypergraph Ramsey theorem). Let K be a finite set, let ")#mi("k \\geq 1")#text(", and let G = (V,E) be a K-coloured hypergraph of order k on a countably infinite vertex set V. Then G contains arbitrarily large finite monochromatic subhypergraphs.")
]

#strong[#text("Remark 3.")]#text(" There is a stronger statement known, namely that G contains an infinitely large monochromatic subhypergraph, but we will not prove this statement, known as the ")#emph[#text("infinite hypergraph Ramsey theorem")]#text(". In the case k=1, these statements are the pigeonhole principle and infinite pigeonhole principle respectively, and are compared in my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("article on hard and soft analysis")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Show that Theorem 4 implies a finitary analogue: given any finite K and positive integers k, m, there exists N such that every K-coloured hyeprgraph of order k on ")#mi("\\{1,\\ldots,N\\}")#text(" contains a monochromatic subhypergraph on m vertices. (")#emph[#text("Hint")]#text(": as in Exercise 3 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(" [note – exercises have been renumbered recently], one should use a compactness and contradiction argument as in my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("article on hard and soft analysis")]#text(".) ")#mi("\\diamond")

#text("It is not immediately obvious, but Theorem 4 is a statement about a topological dynamical system, albeit one in which the underlying group is not the integers ")#mi("{\\Bbb Z}")#text(", but rather the ")#link("http://en.wikipedia.org/wiki/Symmetric_group")[#text("symmetric group")]#text(" ")#mi("\\text{Sym}_0(V)")#text(", defined as the group of bijections from V to itself which are the identity outside of a finite set. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(". (Hypergraph Ramsey theorem, topological dynamics version) Let V be a countably infinite set, and let W be a finite subset of V, thus ")#mi("\\text{Sym}_0(W) \\times \\text{Sym}_0(V \\backslash W)")#text(" is a subgroup of ")#mi("\\text{Sym}_0(V)")#text(". Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a ")#mi("\\text{Sym}_0(V)")#text("-topological dynamical system, thus ")#mi("(X,{\\mathcal F})")#text(" is compact metrisable and ")#mi("T: \\sigma \\mapsto T^\\sigma")#text(" is an ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" of ")#mi("\\text{Sym}_0(V)")#text(" on X via homeomorphisms. Let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of X, such that each ")#mi("U_\\alpha")#text(" is ")#mi("\\text{Sym}_0(W) \\times \\text{Sym}_0(V \\backslash W)")#text("-invariant. Then there exists an element ")#mi("U_\\alpha")#text(" of this cover such that for every finite set ")#mi("\\Gamma \\subset \\text{Sym}_0(V)")#text(" there exists a group element ")#mi("\\sigma \\in \\text{Sym}_0(V)")#text(" such that ")#mi("\\bigcap_{\\gamma \\in \\Gamma} (T^{\\gamma \\sigma})^{-1}(U_\\alpha) \\neq \\emptyset")#text(" (i.e. there exists ")#mi("x \\in X")#text(" such that ")#mi("T^{\\gamma \\sigma} x \\in U_\\alpha")#text(" for all ")#mi("\\gamma \\in \\Gamma")#text(").")
]

#text("This claim should be compared with Theorem 2 of this lecture, or Theorem 1 of the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(".")

#strong[#text("Exercise 8")]#text(". Show that Theorem 4 and Theorem 5 are equivalent. (")#emph[#text("Hint")]#text(": At some point, you will need the use the fact that the quotient space ")#mi("\\text{Sym}_0(V)/(\\text{Sym}_0(W) \\times \\text{Sym}_0(V \\backslash W))")#text(" is isomorphic to ")#tao-math("\\binom{V}{\\left|W\\right|}", block: false)#text(".) ")#mi("\\diamond")

#text("As before, though, we shall only illustrate the ultrafilter approach to Ramsey’s theorem, leaving the other approaches to exercises. Here, we will not work on the compactified integers ")#mi("\\beta {\\Bbb Z}")#text(", but rather on the compactified permutations ")#mi("\\beta \\text{Sym}_0(V)")#text(". (We will view ")#mi("\\text{Sym}_0(V)")#text(" here as a ")#link("http://en.wikipedia.org/wiki/Discrete_topology")[#text("discrete")]#text(" group; one could also give this group the topology inherited from the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text(" on ")#mi("V^V")#text(", leading to a slightly coarser (and thus less powerful) compactification, though one which is still sufficient for the arguments here.) This is a semigroup with the usual multiplication law")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("pq := \\lim_{\\sigma \\to p} \\lim_{\\rho \\to q} \\sigma \\rho.")]]

#text("Let us say that ")#mi("p \\in \\beta \\text{Sym}_0(V)")#text(" is ")#emph[#text("minimal")]#text(" if ")#mi("\\beta \\text{Sym}_0(V) p")#text(" is a minimal left-ideal of ")#mi("\\beta \\text{Sym}_0(V)")#text(". One can show (by repeating Exercise 10 ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("from Lecture 3")]#text(") that every left ideal ")#mi("\\beta\\text{Sym}_0(V) p")#text(" contains at least one minimal element; in particular, minimal elements exist.")

#text("Note that if W is a k-element subset of V, then there is an image map ")#mi("\\pi_W: \\text{Sym}_0(V) \\to \\binom{V}{k}")#text(" which maps a permutation ")#mi("\\sigma")#text(" to its inverse image ")#mi("\\sigma^{-1}(W)")#text(" of W. We can compactify this to a map ")#mi("\\beta \\pi_W: \\beta \\text{Sym}_0(V) \\to \\beta \\binom{V}{k}")#text(". (Caution: ")#mi("\\beta \\binom{V}{k}")#text(" is ")#emph[#text("not")]#text(" the same thing as ")#mi("\\binom{\\beta V}{k}")#text(", for instance the latter is not even compact.) We can now formulate the ultrafilter version of Ramsey’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(". (Hypergraph Ramsey theorem, ultrafilter version) Let V be countably infinite, and let ")#mi("p \\in \\beta \\text{Sym}_0(V)")#text(" be minimal. Then for every finite set W, ")#mi("\\beta \\pi_W")#text(" is constant on ")#mi("\\beta \\text{Sym}_0(V) p")#text(", thus ")#mi("\\beta \\pi_W( qp ) = \\beta \\pi_W(p)")#text(" for all ")#mi("q \\in \\beta \\text{Sym}_0(V)")#text(".")
]

#text("This result should be compared with Proposition 1 from the previous lecture (or Theorem 3 from this lecture).")

#strong[#text("Exercise 9")]#text(". Show that Theorem 6 implies both Theorem 4 and Theorem 5. ")#mi("\\diamond")

#strong[#text("Proof of Theorem 6.")]#text(" By relabeling we may assume ")#mi("V = \\{1,2,3,\\ldots\\}")#text(" and ")#mi("W = \\{1,\\ldots,k\\}")#text(" for some k.")

#text("Given any integers ")#mi("1 \\leq a < i_1 < i_2 < \\ldots < i_a")#text(", let ")#mi("\\sigma_{i_1,\\ldots,i_a} \\in \\text{Sym}_0(V)")#text(" denote the permutation that swaps j with ")#mi("i_j")#text(" for all ")#mi("1 \\leq j \\leq a")#text(", but leaves all other integers unchanged. We select some non-principal ultrafilter ")#mi("p_* := \\beta V \\backslash V")#text(" and define the sequence ")#mi("p_1, p_2, \\ldots \\in \\beta \\text{Sym}_0(V)")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("p_a := \\lim_{i_1 \\to p_*} \\ldots \\lim_{i_a \\to p_*} \\sigma_{i_1,\\ldots,i_a} p.")]]

#text("(Note that the condition ")#mi("a < i_1 < \\ldots < i_a")#text(" will be asymptotically true thanks to the choice of limits here.)")

#text("Let ")#mi("a \\geq k")#text(", and let ")#mi("\\alpha \\in \\text{Sym}_0(V)")#text(" be the a permutation which is the identity outside of ")#mi("\\{1,\\ldots,a\\}")#text(". Then we have the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\pi_W( \\alpha \\sigma_{i_1,\\ldots,i_a} \\rho ) = \\pi_W( \\sigma_{i_{j_1},\\ldots,i_{j_k}} \\rho )")]]

#text("for every ")#mi("\\rho \\in \\text{Sym}_0(V)")#text(", where ")#mi("j_1 < \\ldots < j_k")#text(" are the elements of ")#mi("\\alpha^{-1}(\\{1,\\ldots,k\\})")#text(" in order. Taking limits as ")#mi("\\rho \\to p")#text(", and then inserting the resulting formula into (11), we conclude (after discarding the trivial limits and relabeling the rest) that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\beta \\pi_W(\\alpha p_a) = \\lim_{i_1 \\to p_*} \\ldots \\lim_{i_k \\to p_*} \\beta \\pi_W(\\sigma_{i_1,\\ldots,i_k} p)")]]

#text("and in particular that ")#mi("\\beta \\pi_W(\\alpha p_a)")#text(" is independent of ")#mi("\\alpha")#text(" (if ")#mi("\\alpha")#text(" is the identity outside of ")#mi("\\{1,\\ldots,j\\}")#text(". Now let ")#mi("p^{\\prime} := \\lim_{a \\to p_*} p_a")#text(", then we have ")#mi("\\beta \\pi_W(\\alpha p^{\\prime})")#text(" independent of p’ for all ")#mi("\\alpha \\in \\text{Sym}_0(V)")#text(". Taking limits we conclude that ")#mi("\\beta \\pi_W")#text(" is constant on ")#mi("(\\beta \\text{Sym}_0(V)) p^{\\prime}")#text(". But from construction we see that p’ lies in the closed minimal ideal ")#mi("(\\beta \\text{Sym}_0(V) )p")#text(", thus ")#mi("(\\beta \\text{Sym}_0(V)) p^{\\prime} = (\\beta \\text{Sym}_0(V)) p")#text(". The claim follows. ")#mi("\\Box")

#strong[#text("Exercise 10")]#text(". Establish Theorem 4 directly by a combinatorial argument without recourse to topological dynamics or ultrafilters. (If you are stuck, I recommend reading the classic ")#link("http://www.ams.org/mathscinet-getitem?mr=591457")[#text("text of Graham, Rothschild, and Spencer")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 11")]#text(". Establish Theorem 5 directly by a topological dynamics argument, using combinatorial arguments for the k=1 case but then proceeding by induction afterwards (as in the proof of Theorem 4 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 4")]#text(". More generally, one can interpret the theory of graphs and hypergraphs on a vertex set V through the lens of dynamics of ")#mi("\\text{Sym}_0(V)")#text(" actions; I learned this perspective from ")#link("http://www.math.toronto.edu/~szegedy/")[#text("Balazs Szegedy")]#text(", and it underlies my ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("paper on the hypergraph correspondence principle")]#text(", as well as my more ")#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")[#text("recent paper with Tim Austin on hypergraph property testing.")]#text(" ")#mi("\\diamond")

#heading(level: 1)[#text("— Idempotent ultrafilters and Hindman’s theorem —")]

#text("Thus far, we have been using ultrafilter technology rather lightly, and indeed all of the arguments so far can be converted relatively easily to the topological dynamics formalism, or even a purely combinatorial formalism, with only a moderate amount of effort. But now we will exploit some deeper properties of ultrafilters, which are more difficult to replicate in other settings. In particular, we introduce the notion of an ")#link("http://en.wikipedia.org/wiki/Idempotent")[#text("idempotent ")]#text("ultrafilter.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(". Let ")#mi("(S,\\cdot)")#text(" be a discrete ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(", and let ")#mi("\\beta S")#text(" be given the usual semigroup operation ")#mi("\\cdot")#text(". An element ")#mi("p \\in \\beta S")#text(" is ")#emph[#text("idempotent ")]#text("if ")#mi("p \\cdot p=p")#text(". (We of course define idempotence analogously if the group operation on S is denoted by + instead of ")#mi("\\cdot")#text(".)")
]

#text("Of course, 0 is idempotent, but the remarkable fact is that many other idempotents exist as well. The key tool for creating this is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" (")#link("http://www.ams.org/mathscinet-getitem?mr=101283")[#text("Ellis-Nakamura lemma")]#text("). Let S be a discrete semigroup, and let K be a compact non-empty sub-semigroup of ")#mi("\\beta S")#text(". Then K contains at least one idempotent.")
]

#strong[#text("Proof")]#text(": A simple application of ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" shows that K contains a compact non-empty sub-semigroup K’ which is minimal with respect to set inclusion. We claim that every element of K’ is idempotent. To see this, let p be an arbitrary element of K’. Then observe that K’p is a compact non-empty sub-semigroup of K’ and must therefore be equal to K’; in particular, ")#mi("p \\in K^{\\prime}p")#text(". (Note that ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroups")]#text(" need not contain an identity.) In particular, the stabiliser ")#mi("K^{\\prime\\prime} := \\{ q \\in K^{\\prime}: qp=p\\}")#text(" is non-empty. But one easily observes that this stabiliser is also a compact sub-semigroup of K’, and so K”=K’. In particular, p must stabilise itself, i.e. it is idempotent. ")#mi("\\Box")

#strong[#text("Remark 5.")]#text(" ")#emph[#text("A posteriori")]#text(", this results shows that the minimal non-empty sub-semigroups K’ are in fact just the singleton sets consisting of idempotents. Of course, one cannot see this without first deriving all of Lemma 3. ")#mi("\\diamond")

#text("Idempotence turns out to be particularly powerful when combined with minimality, and to this end we observe the following corollary of the above lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(". Let S be a discrete semigroup. For every ")#mi("p \\in \\beta S")#text(", there exists ")#mi("q \\in (\\beta S) p")#text(" which is both minimal and idempotent.")
]

#strong[#text("Proof.")]#text(" By Exercise 10 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(", there exists ")#mi("r \\in (\\beta S) p")#text(" which is minimal. It is then easy to see that every element of ")#mi("(\\beta S) r")#text(" is minimal. Since ")#mi("(\\beta S) r  \\subset (\\beta S) p")#text(" is a compact non-empty sub-semigroup of ")#mi("\\beta S")#text(", the claim now follows from Lemma 3. ")#mi("\\diamond")

#strong[#text("Remark 6.")]#text(" Somewhat amusingly, minimal idempotent ultrafilters require ")#emph[#text("three")]#text(" distinct applications of Zorn’s lemma to construct: one to define the compactified space ")#mi("\\beta S")#text(", one to locate a minimal left-ideal, and one to locate an idempotent inside that ideal! It seems particularly challenging therefore to define civilised substitutes for this tool which do not explicitly use the axiom of choice. ")#mi("\\diamond")

#text("What can we do with minimal idempotent ultrafilters? One particularly striking example is ")#emph[#text("Hindman’s theorem")]#text(". Given any set A of positive integers, define FS(A) to be the set of all finite sums ")#mi("\\sum_{n \\in B} n")#text(" from A, where B ranges over all finite non-empty subsets of A. (For instance, if ")#mi("A = \\{1,2,4,\\ldots\\}")#text(" are the powers of 2, then ")#mi("FS(A) = {\\Bbb N}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 ")]#text("(Hindman’s theorem) Suppose that the natural numbers ")#mi("{\\Bbb N}")#text(" are finitely coloured. Then one of the colour classes contains a set of the form FS(A) for some infinite set A.")
]

#strong[#text("Remark 7")]#text(". Theorem 7 implies ")#emph[#text("Folkman’s theorem")]#text(", which has the same hypothesis but concludes that one of the colour classes contains sets of the form FS(A) for arbitrarily large but finite sets A. It does not seem possible to easily deduce Hindman’s theorem from Folkman’s theorem. ")#mi("\\diamond")

#strong[#text("Exercise 12.")]#text(" Folkman’s theorem in turn implies ")#emph[#text("Schur’s theorem")]#text(", which asserts that if the natural numbers are finitely coloured, one of the colour classes contains a set of the form ")#mi("FS(\\{x,y\\}) =\\{x,y,x+y\\}")#text(" for some x, y (compare with the k=3 case of van der Waerden’s theorem). Using the Cayley graph construction, deduce Schur’s theorem from Ramsey’s theorem (the k=2 case of Theorem 4). Thus we see that there are some connections between the various Ramsey-type theorems discussed here. ")#mi("\\diamond")

#strong[#text("Proof of Theorem 7.")]#text(" By Corollary 4, we can find a minimal idempotent element p in ")#mi("\\beta {\\Bbb N}")#text("; note that as no element of ")#mi("{\\Bbb N}")#text(" is minimal (cf. Exercise 7 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text("), we know that ")#mi("p \\not \\in {\\Bbb N}")#text(". Let ")#mi("c: {\\Bbb N} \\to \\{1,\\ldots,m\\}")#text(" denote the given colouring function, then ")#mi("\\beta c(p)")#text(" is a colour in ")#mi("\\{1,\\ldots,m\\}")#text(". Since")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\lim_{n \\to p} \\beta c(n) = \\beta c(p)")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\lim_{n \\to p} \\beta c(n+p) = \\beta c(p+p) = \\beta c(p)")]]

#text("we may find a positive integer ")#mi("n_1")#text(" such that ")#mi("\\beta c(n_1) = \\beta c(n_1+p) = \\beta c(p)")#text(". Now from (14), (15) and the similar calculations")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\lim_{n \\to p} \\beta c(n_1+n) = \\beta c(n_1+p) = \\beta c(p)")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\lim_{n \\to p} \\beta c(n_1+n+p) = \\beta c(n_1+p+p) = \\beta c(n_1+p) = \\beta c(p)")]]

#text("we can find an integer ")#mi("n_2 > n_1")#text(" such that ")#mi("\\beta c(n_2) = \\beta c(n_2+p) = \\beta c(n_2+n_1) = \\beta c(n_2+n_1+p) = \\beta c(p)")#text(", thus ")#mi("\\beta c(m) = \\beta c(m+p)=\\beta c(p)")#text(" for all ")#mi("m \\in FS(\\{ n_1,n_2\\})")#text(". Continuing inductively in this fashion, one can find ")#mi("n_1 < n_2 < n_3 < \\ldots")#text(" such that ")#mi("\\beta c(m) = \\beta c(m+p) = \\beta c(p)")#text(" for all ")#mi("m \\in FS(\\{n_1,\\ldots,n_k\\})")#text(" and all k. If we set ")#mi("A := \\{n_1,n_2,\\ldots\\}")#text(", the claim follows. ")#mi("\\Box")

#strong[#text("Remark 8.")]#text(" Purely combinatorial (and quite succinct) proofs of Hindman’s theorem exist – see for instance the one in the text ")#link("http://www.ams.org/mathscinet-getitem?mr=591457")[#text("by Graham, Rothschild, and Spencer")]#text(" – but they generally rely on some ")#emph[#text("ad hoc")]#text(" trickery. Here, the trickery has been encapsulated into the existence of minimal idempotent ultrafilters, which can be reused in other contexts (for instance, we will use it to prove the Hales-Jewett theorem below). ")#mi("\\diamond")

#strong[#text("Exercise 13")]#text(". Define an ")#link("http://en.wikipedia.org/wiki/IP_set")[#text("IP-set")]#text(" to be a set of positive integers which contains a subset of the form FS(A) for some infinite A. Show that if an IP-set S is finitely coloured, then one of its colour classes is also an IP-set. (")#emph[#text("Hint")]#text(": S contains FS(A) for some infinite ")#mi("A = \\{a_1,a_2,a_3,\\ldots\\}")#text(". Show that the set ")#mi("\\bigcap_{n=1}^\\infty \\beta FS( \\{ a_n,a_{n+1},\\ldots \\})")#text(" is a compact non-empty semigroup and thus contains a minimal idempotent ultrafilter p. Use this p to repeat the proof of Theorem 7.) ")#mi("\\diamond")

#heading(level: 1)[#text("— The Hales-Jewett theorem —")]

#text("Given a finite alphabet A, let ")#mi("A^{<\\omega}")#text(" be the free semigroup generated by A, i.e. the set of all finite non-empty words using the alphabet A, with concatenation as the group operation. (E.g. if ")#mi("A = \\{a,b,c\\}")#text(", then ")#mi("A^{<\\omega}")#text(" contains words such as abc and cbb, with ")#mi("abc \\cdot cbb = abccbb")#text(".) If we add another letter * to A (the “wildcard” letter), we create a larger semigroup ")#mi("(A \\cup \\{*\\})^{<\\omega}")#text(" (e.g. containing words such as ab**c*). We of course assume that * was not already present in A. Given any letter ")#mi("x \\in A")#text(", we have a semigroup homomorphism ")#mi("\\pi_x: (A \\cup \\{*\\})^{<\\omega} \\to A^{<\\omega}")#text(" which substitutes every occurrence of the wildcard * with x and leaves all other letters unchanged. (For instance, ")#mi("\\pi_a(ab**c*) = abaaca")#text(".) Define a ")#emph[#text("combinatorial line")]#text(" in ")#mi("A^{<\\omega}")#text(" to be any set of the form ")#mi("\\{ \\pi_x(v): x \\in A \\}")#text(" for some ")#mi("v \\in (A \\cup \\{*\\})^{<\\omega} \\backslash A^{<\\omega}")#text(". For instance, if ")#mi("A = \\{a,b,c\\}")#text(", then ")#mi("\\{ abaaca, abbbcb, abcccc\\}")#text(" is a combinatorial line, generated by the word ")#mi("v = ab**c*")#text(".")

#text("We shall prove the following fundamental theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8")]#text(" (")#link("http://en.wikipedia.org/wiki/Hales-Jewett_theorem")[#text("Hales-Jewett theorem")]#text("). Let A be a finite alphabet. If ")#mi("A^{<\\omega}")#text(" is finitely coloured, then one of the colour classes contains a combinatorial line.")
]

#strong[#text("Exercise 14")]#text(". Show that the Hales-Jewett theorem has the following equivalent formulation: for every finite alphabet A and any ")#mi("m \\geq 1")#text(" there exists N such that if ")#mi("A^N")#text(" is partitioned into m classes, then one of the classes contains a combinatorial line. ")#mi("\\diamond")

#strong[#text("Exercise 15.")]#text(" Assume the Hales-Jewett theorem. In this exercise we compare the strength of this theorem against other Ramsey-type theorems.")

#enum(start: 1, 
[#text("Deduce van der Waerden’s theorem (Theorem 2 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(".) ")#emph[#text("Hint")]#text(": the base k representation of the non-negative natural numbers provides a map from ")#mi("\\{0,\\ldots,k-1\\}^{<\\omega}")#text(" to ")#mi("{\\Bbb Z}_{\\geq 0}")#text(".")],
[#text("Deduce the multidimensional van der Waerden’s theorem of Gallai (Exercise 7 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(".)")],
[#text("Deduce the ")#emph[#text("syndetic van der Waerden theorem")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("of Furstenberg")]#text(": if the integers are finitely coloured and k is a positive integer, then there are infinitely many monochromatic arithmetic progressions ")#mi("n, n+r, \\ldots, n+(k-1)r")#text(" of length k, and furthermore the set of all the step sizes r which appear in such progressions is ")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetic")]#text(". (Hint: argue by contradiction, assuming that the set of all step sizes has arbitrarily long gaps, and use the Hales-Jewett theorem in a manner adapted to these gaps.) For an additional challenge, show that there exists a ")#emph[#text("single")]#text(" colour class whose progressions of length k have spacings in a syndetic set for every k.")],
[#text("Deduce the ")#emph[#text("IP-van der Waerden theorem")]#text(": If the integers are finitely coloured, k is a positive integer, and S is an IP-set (see Exercise 13), show that there are infinitely many monochromatic arithmetic progressions of length k whose step size lies in S. (For an additional challenge, show that one of the colour classes has the property that for every k, the spacings of the k-term progressions in that class forms an ")#emph[#mi("IP^*")#text("-set")]#text(", i.e. it has non-empty intersection with every IP-set. There is an even stronger topological dynamics version of this statement, ")#link("http://www.ams.org/mathscinet-getitem?mr=531271")[#text("due to Furstenberg and Weiss")]#text(", which I will not describe here.)")],
[#text("For any ")#mi("d \\geq 1")#text(", define a ")#emph[#text("d-dimensional combinatorial subspace")]#text(" of ")#mi("A^{<\\omega}")#text(" to be a set of the form ")#mi("\\{ \\pi_{x_1,\\ldots,x_d}(v): x_1,\\ldots,x_d \\in A \\}")#text(", where ")#mi("v \\in (A \\cup \\{ *_1,\\ldots,*_d\\})^{<\\omega}")#text(" is a word containing at least one copy of each of the d wildcards ")#mi("*_1,\\ldots,*_d")#text(", and ")#mi("\\pi_{x_1,\\ldots,x_d}: (A \\cup \\{ *_1,\\ldots,*_d\\})^{<\\omega} \\to A^{<\\omega}")#text(" is the homomorphism that substitutes each wildcard ")#mi("*_j")#text(" with ")#mi("x_j")#text(". Show that if ")#mi("A^{<\\omega}")#text(" is finitely coloured, then one of the colour classes contains arbitrarily high-dimensional combinatorial subspaces.")],
[#text("Let F be a finite field. If the vector space ")#mi("\\lim_{n \\to \\infty} F^n")#text(" (the ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" of the finite vector spaces ")#mi("F^n")#text(") is finitely coloured, show that one of the colour classes contains arbitrarily high-dimensional ")#link("http://en.wikipedia.org/wiki/Affine_space")[#text("affine subspaces")]#text(" over F. (This ")#emph[#text("geometric Ramsey theorem")]#text(" is due ")#link("http://www.ams.org/mathscinet-getitem?mr=306010")[#text("to Graham, Leeb, and Rothschild")]#text(".)")]
)

#text("We now give an ultrafilter-based proof of the Hales-Jewett theorem due ")#link("http://www.ams.org/mathscinet-getitem?mr=1305122")[#text("to Blass")]#text(". As usual, the first step is to obtain a statement involving ultrafilters rather than colourings:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(". (Hales-Jewett theorem, ultrafilter version) Let A be a finite alphabet, and let p be a minimal idempotent element of the semigroup ")#mi("\\beta( A^{<\\omega})")#text(". Then there exists ")#mi("q \\in \\beta (A \\cup \\{*\\})^{<\\omega} ) \\backslash \\beta( A^{<\\omega})")#text(" such that ")#mi("\\beta \\pi_x(q) = p")#text(" for all ")#mi("x \\in A")#text(".")
]

#strong[#text("Exercise 16")]#text(". Deduce Theorem 8 from Proposition 1. ")#mi("\\diamond")

#text("To prove Proposition 1, we need a variant of Corollary 4. If ")#mi("(S,\\cdot )")#text(" is a discrete semigroup and p and q are two idempotents in ")#mi("\\beta S")#text(", let us write ")#mi("p \\prec q")#text(" if we have ")#mi("pq=qp=p")#text(".")

#strong[#text("Exercise 17")]#text(". Show that ")#mi("\\prec")#text(" is a partial ordering on the idempotents of ")#mi("\\beta S")#text(", and that an idempotent is minimal in ")#mi("\\beta S")#text(" if and only if it is minimal with respect to ")#mi("\\prec")#text(". ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(". Let S be a discrete semigroup, and let p be an idempotent in ")#mi("\\beta S")#text(". Then there exists a minimal idempotent q in ")#mi("\\beta S")#text(" such that ")#mi("q \\prec p")#text(".")
]

#strong[#text("Proof of Lemma 4")]#text(". By Exercise 10 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(" (generalised to arbitrary discrete semigroups S), ")#mi("(\\beta S) p")#text(" contains a minimal left-ideal ")#mi("(\\beta S) r")#text(". By Lemma 3, ")#mi("(\\beta S) r")#text(" contains an idempotent s. Since ")#mi("s \\in (\\beta S) p")#text(" and p is idempotent, we conclude sp=s. If we then set ")#mi("q := ps")#text(", we easily check that q is idempotent, that ")#mi("q \\prec p")#text(", and (since q lies in the minimal left-ideal ")#mi("(\\beta S) r")#text(") it is minimal. The claim follows. ")#mi("\\Box")

#strong[#text("Proof of Proposition 1")]#text(". Since p is an idempotent element of ")#mi("\\beta( A^{<\\omega} )")#text(", it is also an idempotent element of ")#mi("\\beta (A \\cup \\{*\\}^{<\\omega})")#text(". However, it is not minimal in that semigroup; for instance, ")#mi("\\beta(A \\cup \\{*\\})^{<\\omega} * p")#text(" does not contain p, since ")#mi("\\beta(A^{<\\omega})")#text(" and ")#mi("\\beta((A \\cup \\{*\\})^{<\\omega} \\backslash A^{<\\omega})")#text(" are disconnected from each other. However, by Lemma 4, we can find a minimal idempotent q in ")#mi("\\beta (A \\cup \\{*\\})^{<\\omega}")#text(" such that ")#mi("q \\prec p")#text(". By the above discussion, q is not equal to p; since p is minimal in ")#mi("\\beta(A^{<\\omega})")#text(", we see that q must lie outside of ")#mi("\\beta(A^{<\\omega})")#text(".")

#text("Now let ")#mi("x \\in A")#text(". Since ")#mi("\\pi_x:   (A \\cup \\{*\\})^{<\\omega} \\to A^{<\\omega}")#text(" is a homomorphism,")

#mi("\\beta \\pi_x: \\beta  (A \\cup \\{*\\})^{<\\omega} \\to \\beta A^{<\\omega}")#text(" is also a homomorphism (why?). Since q is idempotent and ")#mi("q \\prec p")#text(" (note that these are both purely ")#emph[#text("algebraic")]#text(" statements), we conclude that ")#mi("\\beta \\pi_x(q)")#text(" is idempotent and ")#mi("\\beta \\pi_x(q) \\prec \\beta \\pi_x(p)")#text(". But ")#mi("\\beta \\pi_x(p) = p")#text(" is minimal in ")#mi("\\beta A^{<\\omega}")#text(", hence by Exercise 17, we have ")#mi("\\beta \\pi_x(q) = p")#text(". The claim follows. ")#mi("\\Box")

#strong[#text("Exercise 18")]#text(". Adapt the above proof to give an alternate proof of the ultrafilter version of van der Waerden’s theorem (Proposition 1 from the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("previous lecture")]#text(") which relies on idempotence rather than on induction on k. (If you are stuck, read the proof of Proposition 1.55 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1958753")[#text("Glasner’s book")]#text(".) ")#mi("\\diamond")

#strong[#text("Remark 9.")]#text(" Several of the above Ramsey-type theorems can be unified. For instance, the polynomial van der Waerden theorem and the Hales-Jewett theorem have been unified into the ")#link("http://www.ams.org/mathscinet-getitem?mr=1715320")[#text("polynomial Hales-Jewett theorem of Bergelson and Leibman")]#text(" (see also the more recent ")#link("http://www.ams.org/mathscinet-getitem?mr=1745405")[#text("paper of Walters")]#text(" on this topic). This type of Ramsey theory is still an active subject, and we do not yet have a comprehensive and systematic theory (or a “universal” Ramsey theorem) that encompasses all known examples. ")#mi("\\diamond")

#strong[#text("Exercise 19.")]#text(" Let X be an at most countable set (with the discrete topology), and let ")#mi("{\\mathcal F}")#text(" be a family of subsets of X. Show that the following two statements are equivalent:")

#enum(start: 1, 
[#text("Whenever X is finitely coloured, one of the colour classes contains a subset in ")#mi("{\\mathcal F}")#text(".")],
[#text("There exists ")#mi("p \\in \\beta X")#text(" such that every neighbourhood of p contains a subset in ")#mi("{\\mathcal F}")#text(". ")#mi("\\diamond")]
)

#strong[#text("Exercise 20. ")]#text(" Let X, Y be at most countable sets with the discrete topology, and let ")#mi("f_1,\\ldots,f_k: Y \\to X")#text(" be a finite collection of functions. Show that the following two statements are equivalent:")

#enum(start: 1, 
[#text("Whenever X is finitely coloured, one of the colour classes contains a set ")#mi("\\{f_1(y), \\ldots, f_k(y)\\}")#text(" for some ")#mi("y \\in Y")#text(".")],
[#text("There exists ")#mi("q \\in \\beta Y")#text(" such that ")#mi("\\beta f_1(q) = \\ldots = \\beta f_k(q)")#text(".")]
)

#text("(")#emph[#text("Hint")]#text(": look at the closure of ")#mi("\\{ (f_1(y),\\ldots,f_k(y)): y \\in Y \\}")#text(" in $(\\beta X)^k$.) ")#mi("\\diamond")#strong[#text(" ")]

#strong[#text("Exercise 21.")]#text(" Using the previous exercise, deduce Theorem 3 from Theorem 1, and deduce Theorem 6 from Theorem 4. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 24: extra factors added to the polynomial in Exercise 1 to sidestep issues at 2 and 3.]")

#text("[")#emph[#text("Update")]#text(", Jan 30: remarks added and renumbered.]")

#text("[")#emph[#text("Update")]#text(", Feb 1: More exercises added.]")

#text("[")#emph[#text("Update")]#text(", Mar 21: Various corrections.]")

#text("[")#emph[#text("Update")]#text(", Mar 25: Statement of Theorem 5 repaired.]")

#text("[")#emph[#text("Update")]#text(", Mar 31 2009: Proof of Proposition 1 expanded.]")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yury")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-24852")[#strong[#text("Yury")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2008")])]

#text("Dear Prof. Tao,")

#text("the polynomial from Exercise 1 has no roots in case N=8.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-24856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2008")])]

#text("Ah yes, the joys of low characteristic :-) . Easily fixed, of course, by throwing some non-quadratic polynomial such as ")#mi("r^3 - 3")#text(" into the mix, and I guess ")#mi("r^2-7")#text(" as well to deal with the obstructions at 3 also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-24992")[#strong[#text("254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2008")])]

#text("[…] recurrence theorems we have already encountered (e.g. Corollary 1 from Lecture 4, or Theorem 1 from Lecture 5) do not seem to directly establish this result, instead giving the weaker result that every element […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-25755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Dear Prof;")

#text("Don’t we need some condition of left continuity on our group S, for the proof of lemma 3 and corollary 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 7: Structural theory of topological dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-25876")[#strong[#text("254A, Lecture 7: Structural theory of topological dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("[…] on X forms a group, known as the Ellis group of X. (Hint: use part 3, together with Lemma 3 from Lecture 5.) Show that G is a compact subset of (with the product topology), and that G acts transitively […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-25928")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] is also a polynomial version of these theorems (cf. Theorem 1 from Lecture 5), which we will also state in general […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-26053")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("[…] strength of the results, one needs the syndetic van der Waerden theorem, see Exercise 15.3 from Lecture 5, or else apply the Varnavides averaging trick from the previous lecture). We leave the details to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-26713")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Sir")

#text("In the topological dynamics version of Hypergraph Ramsey theorem can you explain how the transformation function T behaves? I am unable to understand the notation ")#mi("T: \\sigma \\mapsto T^\\sigma")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-26722")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Sir")

#text("I think the notation generates a different transformation ")#mi("T^\\sigma")#text(" for each ")#mi("\\sigma \\in \\text{Sym}_0(V)")#text(". For any ")#mi("x \\in X, T^\\sigma x = \\sigma x")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-26807")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2008")])]

#text("[…] is non-constant. (Hint: you will need the “PET induction” machinery from Exercise 3 of Lecture 5. This result was first established by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27350")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2008")])]

#text("Dear professor：")

#text("Here are several corrections:")

#text("1,I think after (2), the definition of q’ should be")

#mi("q^{\\prime} := \\lim_{(n,r) \\to q} (n - Q ( r ), r) \\in \\beta( \\Bbb Z \\times \\Bbb N)")

#text("2,About (3),")

#mi("\\lim_{(n_b,r_b) \\to q_b} n_b+ P_i(r_{a+1}+\\ldots+r_b) - P_i(r_{a+1} + \\ldots+r_{b-1}) - Q(r_b) + p = p")#text(", where” = p ” fail to show up. But I saw your latex code is right, I don’t know why this happens.")

#text("3,About (4),")

#mi("p_{a,b,i}:= \\lim_{(n_b,r_b) \\to q_1}")#text(" …")#mi("\\lim_{(n_b,r_b) \\to q_b}")#text(" ")#mi("P_i(r_{a+1}+\\ldots+r_b) + m_b + p")#text(", the bth sub should be ")#mi("(n_b, r_b)")#text(". The same problem happens to (9).")

#text("4, before (4) and After (7′), the definition of p’ : ")#mi("p^{\\prime} = \\lim_{a \\to p_*} p_{a,a,0}")#text(" = ")#mi("\\lim_{b \\to p_*}")#text(" ")#mi("p_{b,b,0} \\in p")#text(" +")#mi("\\beta {\\Bbb Z}")#text(", not ")#mi("\\beta {\\Bbb Z} +p")#text("?")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27365")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2008")])]

#text("Dear professor:")#linebreak()#text(" I don’t understand the definition of ")#mi("T^\\sigma")#text(". Could you explain a little more about it? Is ")#mi("T^\\sigma")#text(" still a homeomorphism on X or not? what is the image of, say, ")#mi("T^{(1,2)}x")#text(" for a ")#mi("x \\in X")#text("?")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2008")])]

#text("Dear Liu,")

#text("An action T of a group G on a space X is a collection of maps ")#mi("T^\\sigma: X \\to X")#text(" for each group element ")#mi("\\sigma \\in G")#text(" which preserve the group operations, thus ")#mi("T^{id}")#text(" is the identity, ")#mi("T^{\\sigma^{-1}}")#text(" inverts ")#mi("T^{\\sigma}")#text(", and ")#mi("T^{\\sigma \\rho}")#text(" is the composition of ")#mi("T^\\sigma")#text(" and ")#mi("T^\\rho")#text(". See")

#link("http://en.wikipedia.org/wiki/Group_action")[#text("http://en.wikipedia.org/wiki/Group_action")]

#text("In this case, X is a topological space, and so we would require our actions to preserve this topological structure, i.e. to be homeomorphisms.")

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27516")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2008")])]

#text("Dear Professor:")

#text("In theorem 5, I wonder if you mean that “")#mi("U_\\alpha")#text(" is an open cover of X, such that ")#mi("U_\\alpha")#text(" is ")#mi("\\text{Sym}_0(W) \\times \\text{Sym}_0 (V \\backslash W)")#text("– invariant”. If not, that must be my")#linebreak()#text(" misunderstanding.")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27526")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2008")])]

#text("Dear Liu: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27552")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2008")])]

#text("Dear Professor:")

#text("I am stuck when I try to prove theorem 4 from theorem 5. When I")#linebreak()#text(" consider the subsystem ")#mi("\\overline{T^{ \\text {Sym}_0 (V)} x}")#text(" I can’t")#linebreak()#text(" find the proper open cover ")#mi("U_\\alpha")#text(" which is ")#mi("\\text{Sym}_0(W)\\times \\text{Sym}_0 (V \\backslash W)")#text("-invariant. Please")#linebreak()#text(" help me out.")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Dear Liu:")

#text("Let’s set ")#mi("V = \\{1,2,3,\\ldots\\}")#text(" and ")#mi("W = \\{1,\\ldots,k\\}")#text(" for concreteness. Then the relevant space X should be the space of K-coloured hypergraphs of order k on V (with the obvious action of ")#mi("\\text{Sym}_0(V)")#text("), and each ")#mi("U_\\alpha")#text(" for ")#mi("\\alpha \\in K")#text(" should be the clopen set of hypergraphs in X which assign the colour ")#mi("\\alpha")#text(" to the edge ")#mi("\\{1,\\ldots,k\\} = W")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27641")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2008")])]

#text("Dear professor：")

#text("I think the conclusion of theorem 5 should be ")#mi("\\bigcap_{\\gamma \\in \\Gamma} T^{\\sigma\\gamma }(U_\\alpha) \\neq \\emptyset")#text(", because only in this case, I can finish the exercises.")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-27643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2008")])]

#text("Ah, I see what happened. It should actually be ")#mi("\\bigcap_{\\gamma \\in \\Gamma} (T^{\\gamma \\sigma})^{-1}(U_\\alpha) \\neq 0")#text(" (though the other formulation you propose is of course equivalent).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-37624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("Dear professor：")

#text("I think in the proof of the proposition 1, it is better to point out that \\beta( A^{<\\omega} ) does not have an minimal element of \\beta (A \\cup \\{*\\})^{<\\omega}. So the selected q is not in \\beta( A^{<\\omega} ).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-37650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("Thanks, I’ve added a few sentences to this effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40090")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In exercise 3 part 2, I am wondering whether or not the degree of the top order monomial of ")#mi("P_1")#text(" should be asked to have the lowest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40093")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Ah, there was a typo: ")#mi("P_i(\\cdot + h_j) - P_i(h_j)")#text(" should have been ")#mi("P_i(\\cdot + h_j) - P_i(\\cdot)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40096")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Dear professor Tao:")#linebreak()#text(" I’m even more confused, to use lemma 2 in the third step, isn’t ")#mi("P_i(\\cdot + h_j) - P_i(h_j) sh")#text(" the correct one in part 2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Sorry about that; I’ve reverted it. The exercise as originally stated appears to me to be correct, without modification.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of the “epsilon and delta” proof of polynomial Van Der Waerdon theorem « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40103")[#strong[#text("the “epsilon and delta” proof of polynomial Van Der Waerdon theorem « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2009")])]

#text("[…] lecture notes of ergodic theory. I write it separately because it’s a little lengthy. Here is the lecture notes. It is very interesting to contrast this proof with the proof of Hales-Jewett […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Several Ramsey-type theorems « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40120")[#strong[#text("Several Ramsey-type theorems « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2009")])]

#text("[…] theorem. I wrote a post on the combinatorial proof of this theorem.These are also exercises of Professor Tao’s lecture on ergodic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40121")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2009")])]

#text("Dear Professor Tao:")

#text("In the part 4 of exercise 15, I believe the conclusion should be ‘there are infinitely many monochromatic arithmetic progressions ‘of length k’ whose step size lies in S’, with ‘of length k’ missing.")

#text("Also, I can’t work out the additional challenge, could you give me a hint?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Thanks for the correction! The additional challenge in 15.4 is proven similarly to the additional challenge in 15.3, i.e. by applying the infinite pigeonhole principle to get a single colour class that works for infinitely many k.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40201")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" But I got stuck when trying to prove even one k for a single class. I know from 15.4 that the spacings of arithmetic progressions of length k form a IP*set A. But I can’t figure out why one of the color classes in A should also be an IP*set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("The following model problem might get you started: show that if ")#mi("{\\Bbb Z}^2")#text(" is finitely coloured, then one of the colour classes contains arbitrarily long arithmetic progressions in the vertical direction, and also arbitrarily long arithmetic progressions in the horizontal direction.")

#text("Now, do the same thing for ")#mi("{\\Bbb Z}^{<\\omega}")#text(", with the countably infinite number of directions.")

#text("An IP set is sort of a less structured version of ")#mi("{\\Bbb Z}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40582")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("There are essentially countably many different IP-sets in ")#mi("\\Bbb Z")#text(",right?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40205")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Also, about the exercise 3.2, if ")#mi("P_1=r^2 P_2=r")#text(" then the weight vector of ")#mi("(0,r^2,r)")#text(" with respect to ")#mi("r^2")#text(" should be ")#mi("(0,1,0\\cdots)")#text(" and the weight vector of ")#mi("((r+h)^2-h^2,r+h-h)")#text(" with respect to ")#mi("(r+h)^2")#text(" is also ")#mi("(0,1,0\\cdots)")#text(", not strictly smaller than the former one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40500")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Ah, I see the problem now. Your earlier fix (requiring P_1 to have minimal degree) was the correct one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40740")[#strong[#text("陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于08年年初的一门课程，我尝试将所有习题做出来，这是第五讲的二十一个习题。这里是这门课程的主页，这里是本讲的链接。有一些题目我花费的时间比较多，我将所需要的知识补充在另外的帖子中。关于ultrafilter, 我写过一个帖子.习题一中涉及到一点数论知识，尤其关于二次剩余的知识。我写过一个帖子是关于Hales-Jewett定理的归纳法证明.习题4的解答比较长，我另写了一个帖子。该过程是参考了上一讲中定理四的证明。注意这个证明方法与前述Hales-Jewett定理的归纳证明的异同。仍有几个问题没有完成，我会慢慢补上。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40791")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" I still have trouble understanding exercise 3 and ‘PET’ induction method. Lemma 2 enssures the conclusion based on a previously fixed Q and arbitririly chosed ")#mi("h_i")#text(". But in exercise 3.2, ")#mi("Q(r)=P(\\cdot +h_1)")#text(", which depends on ")#mi("h_1")#text(". I got a little confused here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40805")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("It seems OK if we just take ")#mi("Q(r)")#text(" as ")#mi("P_1(\\cdot)")#text(" in exercise 3.2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("Fair enough (though, in view of Lemma 1, one could also permit Q to vary with the ")#mi("h_i")#text(" if one wished.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-40891")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" I failed when doing exercise 11. Could you give one more hint, besides the fact that it is similar with the proof of Theorem 4 from the previous lecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory: Lecture ten « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-45107")[#strong[#text("Solutions to Ergodic Theory: Lecture ten « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2010")])]

#text("[…] Theorem 9: (IP Szemerédi theorem) Let A be a set of integers of positive upper density, let , and let be infinite. Then A contains an arithmetic progression of length k in which r lies in FS(B), the set of finite sums of B (cf. Hindman’s theorem from Lecture 5). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-45565")[#strong[#text("Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")])]

#text("[…] is non-constant. (Hint: you will need the “PET induction” machinery from Exercise 3 of Lecture 5. This result was first established by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-45599")[#strong[#text("Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2010")])]

#text("[…] see G is a group, we firstly take a minimal subsystem of X, we have from Ellis-Nakamura lemma from lecture 5 the existence of the identity, i.e. we take the whole equivalence class imdepotent elements as the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siming Tu")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-159306")[#strong[#text("Siming Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In Lemma 3, Ellis-Nakamura lemma should be Ellis–Numakura lemma. see")

#link("http://en.wikipedia.org/wiki/Ellis-Numakura_lemma")[#text("http://en.wikipedia.org/wiki/Ellis-Numakura_lemma")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eff7fdf81b9c7b14562a2d3c05ec212cf39bd4d8490507d000c140b683b77e96-3043580e7c8e8c447632ec009143aa81249d2bae11e52af323fbed12cb32fb92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Tsaban")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-416375")[#strong[#text("Boaz Tsaban")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2014")])]

#text("Dear Terry, in Remark 1 you take ")#mi("P_1(r) = 0, P_2(r) = 2r+1")#text(".")#linebreak()#text(" Wouldn’t ")#mi("P_1(r) = 0, P_2(r) = 1")#text(" also work, and look more natural?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-416403")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2014")])]

#text("That would also be a counterexample, but a rather degenerate one; the counterexample I selected was intended to resemble the standard Szemeredi example ")#mi("P_i(r) = (i-1)r")#text(", to illustrate that non-degenerate averaging in r is not sufficient by itself to obtain recurrence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d3753205014558738a019b6d275f8da20cafcb8813e2a281e22589647a1aca2-edef1f4c61e4f4c2cf7449faf638a38c871d9f180061a8c1cb251bfeafb9a2bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-458142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")])]

#text("Dear professor Tao,")

#text("Is there an ultrafilter version of the “polynomial” Hales-Jewett theorem?")#linebreak()#text(" This theorem (as formulated in the paper of Walters you linked) is about (sequences of) multi-dimensional arrays with the same length at each dimension, instead of just one dimensional sequences, so there is no natural semigroup operation analogous to concatenation (that I can see).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1531717f83e547943ce13043f58e171cc61005341458e8cf5656a1859923a217-32510c9b609720ae868c14c6fea3c5ba09413d1507508bdb09198c1c2cd18d84.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Can you paint with all the colors of the integers? – The Indeterminate Blogger")]], [#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/#comment-473387")[#strong[#text("Can you paint with all the colors of the integers? – The Indeterminate Blogger")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("[…] References: 0) ")#link("https://arxiv.org/abs/0906.3885")[#text("https://arxiv.org/abs/0906.3885")]#text(" 1) ")#link("http://math.stackexchange.com/questions/789443/hindmans-theorem-on-coloring-a-set-with-n-colours")[#text("http://math.stackexchange.com/questions/789443/hindmans-theorem-on-coloring-a-set-with-n-colours")]#text(" 2) ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")]#text(" […]")
]
