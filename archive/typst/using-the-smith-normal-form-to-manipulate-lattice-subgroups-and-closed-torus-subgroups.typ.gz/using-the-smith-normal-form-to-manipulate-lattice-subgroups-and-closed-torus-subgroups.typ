// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/
// Converted to Typst by tao2typ: "2026-10-14T07:17:10.195875+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Using the Smith normal form to manipulate lattice subgroups and closed torus subgroups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Using the Smith normal form to manipulate lattice subgroups and closed torus subgroups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/")[#text("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{M_{n \\times m}({\\bf Z})}")#text(" denote the space of ")#mi("{n \\times m}")#text(" matrices with integer entries, and let ")#mi("{GL_n({\\bf Z})}")#text(" be the group of invertible ")#mi("{n \\times n}")#text(" matrices with integer entries. The ")#link("https://en.wikipedia.org/wiki/Smith_normal_form")[#text("Smith normal form")]#text(" takes an arbitrary matrix ")#mi("{A \\in M_{n \\times m}({\\bf Z})}")#text(" and factorises it as ")#mi("{A = UDV}")#text(", where ")#mi("{U \\in GL_n({\\bf Z})}")#text(", ")#mi("{V \\in GL_m({\\bf Z})}")#text(", and ")#mi("{D}")#text(" is a rectangular diagonal matrix, by which we mean that the principal ")#mi("{\\min(n,m) \\times \\min(n,m)}")#text(" minor is diagonal, with all other entries zero. Furthermore the diagonal entries of ")#mi("{D}")#text(" are ")#mi("{\\alpha_1,\\dots,\\alpha_k,0,\\dots,0}")#text(" for some ")#mi("{0 \\leq k \\leq \\min(n,m)}")#text(" (which is also the rank of ")#mi("{A}")#text(") with the numbers ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" (known as the ")#emph[#text("invariant factors")]#text(") principal divisors with ")#mi("{\\alpha_1 | \\dots | \\alpha_k}")#text(". The invariant factors are uniquely determined; but there can be some freedom to modify the invertible matrices ")#mi("{U,V}")#text(". The Smith normal form can be computed easily; for instance, in SAGE, it can be computed calling the ")#mi("{{\\tt smith\\_form()}}")#text(" function from the matrix class. The Smith normal form is also available for other principal ideal domains than the integers, but we will only be focused on the integer case here. For the purposes of this post, we will view the Smith normal form as a primitive operation on matrices that can be invoked as a “black box”.")

#text("In this post I would like to record how to use the Smith normal form to computationally manipulate two closely related classes of objects:")

#list(
[#text("Subgroups ")#mi("{\\Gamma \\leq {\\bf Z}^d}")#text(" of a standard lattice ")#mi("{{\\bf Z}^d}")#text(" (or ")#emph[#text("lattice subgroups")]#text(" for short);")],
[#text("Closed subgroups ")#mi("{H \\leq ({\\bf R}/{\\bf Z})^d}")#text(" of a standard torus ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(" (or ")#emph[#text("closed torus subgroups")]#text(" for short).")]
)

#text("(This arose for me due to the need to actually perform (with a collaborator) some numerical calculations with a number of lattice subgroups and closed torus subgroups.) It’s possible that all of these operations are already encoded in some existing object classes in a computational algebra package; I would be interested to know of such packages and classes for lattice subgroups or closed torus subgroups in the comments.")

#text("The above two classes of objects are isomorphic to each other by Pontryagin duality: if ")#mi("{\\Gamma \\leq {\\bf Z}^d}")#text(" is a lattice subgroup, then the orthogonal complement")

#align(center)[#tao-fit-display[#mitex("\\Gamma^\\perp := \\{ x \\in ({\\bf R}/{\\bf Z})^d: \\langle x, \\xi \\rangle = 0 \\forall \\xi \\in \\Gamma \\}")]]

#text("is a closed torus subgroup (with ")#mi("{\\langle,\\rangle: ({\\bf R}/{\\bf Z})^d \\times {\\bf Z}^d \\rightarrow {\\bf R}/{\\bf Z}}")#text(" the usual Fourier pairing); conversely, if ")#mi("{H \\leq ({\\bf R}/{\\bf Z})^d}")#text(" is a closed torus subgroup, then")

#align(center)[#tao-fit-display[#mitex("H^\\perp := \\{ \\xi \\in {\\bf Z}^d: \\langle x, \\xi \\rangle = 0 \\forall x \\in H \\}")]]

#text("is a lattice subgroup. These two operations invert each other: ")#mi("{(\\Gamma^\\perp)^\\perp = \\Gamma}")#text(" and ")#mi("{(H^\\perp)^\\perp = H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" The orthogonal complement of the lattice subgroup")

#align(center)[#tao-fit-display[#mitex("2{\\bf Z} \\times \\{0\\} = \\{ (2n,0): n \\in {\\bf Z}\\} \\leq {\\bf Z}^2")]]

#text("is the closed torus subgroup")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{2}{\\bf Z}/{\\bf Z}) \\times ({\\bf R}/{\\bf Z}) = \\{ (x,y) \\in ({\\bf R}/{\\bf Z})^2: 2x=0\\} \\leq ({\\bf R}/{\\bf Z})^2")]]

#text("and conversely.")
]

#text("Let us focus first on lattice subgroups ")#mi("{\\Gamma \\leq {\\bf Z}^d}")#text(". As all such subgroups are finitely generated abelian groups, one way to describe a lattice subgroup is to specify a set ")#mi("{v_1,\\dots,v_n \\in \\Gamma}")#text(" of generators of ")#mi("{\\Gamma}")#text(". Equivalently, we have")

#align(center)[#tao-fit-display[#mitex("\\Gamma = A {\\bf Z}^n")]]

#text("where ")#mi("{A \\in M_{d \\times n}({\\bf Z})}")#text(" is the matrix whose columns are ")#mi("{v_1,\\dots,v_n}")#text(". Applying the Smith normal form ")#mi("{A = UDV}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Gamma = UDV{\\bf Z}^n = UD{\\bf Z}^n")]]

#text("so in particular ")#mi("{\\Gamma}")#text(" is isomorphic (with respect to the automorphism group ")#mi("{GL_d({\\bf Z})}")#text(" of ")#mi("{{\\bf Z}^d}")#text(") to ")#mi("{D{\\bf Z}^n}")#text(". In particular, we see that ")#mi("{\\Gamma}")#text(" is a free abelian group of rank ")#mi("{k}")#text(", where ")#mi("{k}")#text(" is the rank of ")#mi("{D}")#text(" (or ")#mi("{A}")#text("). This representation also allows one to trim the representation ")#mi("{A {\\bf Z}^n}")#text(" down to ")#mi("{U D^{\\prime}{\\bf Z}^k}")#text(", where ")#mi("{D^{\\prime} \\in M_{d \\times k}}")#text(" is the matrix formed from the ")#mi("{k}")#text(" left columns of ")#mi("{D}")#text("; the columns of ")#mi("{UD^{\\prime}}")#text(" then give a basis for ")#mi("{\\Gamma}")#text(". Let us call this a ")#emph[#text("trimmed representation")]#text(" of ")#mi("{A{\\bf Z}^n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-981f4e620f014826311b>#text(" Let ")#mi("{\\Gamma \\leq {\\bf Z}^3}")#text(" be the lattice subgroup generated by ")#mi("{(1,3,1)}")#text(", ")#mi("{(2,-2,2)}")#text(", ")#mi("{(3,1,3)}")#text(", thus ")#mi("{\\Gamma = A {\\bf Z}^3}")#text(" with ")#mi("{A = \\begin{pmatrix} 1 & 2 & 3 \\\\ 3 & -2 & 1 \\\\ 1 & 2 & 3 \\end{pmatrix}}")#text(". A Smith normal form for ")#mi("{A}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} 3 & 1 & 1 \\\\ 1 & 0 & 0 \\\\ 3 & 1 & 0 \\end{pmatrix} \\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 8 & 0 \\\\ 0 & 0 & 0 \\end{pmatrix} \\begin{pmatrix} 3 & -2 & 1 \\\\ -1 & 1 & 0 \\\\ 1 & 0 & 0 \\end{pmatrix}")]]

#text("so ")#mi("{A{\\bf Z}^3}")#text(" is a rank two lattice with a basis of ")#mi("{(3,1,3) \\times 1 = (3,1,3)}")#text(" and ")#mi("{(1,0,1) \\times 8 = (8,0,8)}")#text(" (and the invariant factors are ")#mi("{1}")#text(" and ")#mi("{8}")#text("). The trimmed representation is")

#align(center)[#tao-fit-display[#mitex("A {\\bf Z}^3 = \\begin{pmatrix} 3 & 1 & 1 \\\\ 1 & 0 & 0 \\\\ 3 & 1 & 0 \\end{pmatrix} \\begin{pmatrix} 1 & 0 \\\\ 0 & 8 \\\\ 0 & 0 \\end{pmatrix} {\\bf Z}^2 = \\begin{pmatrix} 3 & 8 \\\\ 1 & 0 \\\\ 3 & 8 \\end{pmatrix} {\\bf Z}^2.")]]

#text("There are other Smith normal forms for ")#mi("{A}")#text(", giving slightly different representations here, but the rank and invariant factors will always be the same.")
]

#text("By the above discussion we can represent a lattice subgroup ")#mi("{\\Gamma \\leq {\\bf Z}^d}")#text(" by a matrix ")#mi("{A \\in M_{d \\times n}({\\bf Z})}")#text(" for some ")#mi("{n}")#text("; this representation is not unique, but we will address this issue shortly. For now, we focus on the question of how to use such data representations of subgroups to perform basic operations on lattice subgroups. There are some operations that are very easy to perform using this data representation:")

#list(
[#text("(Applying a linear transformation) if ")#mi("{T \\in M_{d^{\\prime} \\times d}({\\bf Z})}")#text(", so that ")#mi("{T}")#text(" is also a linear transformation from ")#mi("{{\\bf Z}^d}")#text(" to ")#mi("{{\\bf Z}^{d^{\\prime}}}")#text(", then ")#mi("{T}")#text(" maps lattice subgroups to lattice subgroups, and clearly maps the lattice subgroup ")#mi("{A{\\bf Z}^n}")#text(" to ")#mi("{(TA){\\bf Z}^n}")#text(" for any ")#mi("{A \\in M_{d \\times n}({\\bf Z})}")#text(".")],
[#text("(Sum) Given two lattice subgroups ")#mi("{A_1 {\\bf Z}^{n_1}, A_2 {\\bf Z}^{n_2} \\leq {\\bf Z}^d}")#text(" for some ")#mi("{A_1 \\in M_{d \\times n_1}({\\bf Z})}")#text(", ")#mi("{A_2 \\in M_{d \\times n_2}({\\bf Z})}")#text(", the sum ")#mi("{A_1 {\\bf Z}^{n_1} + A_2 {\\bf Z}^{n_2}}")#text(" is equal to the lattice subgroup ")#mi("{A {\\bf Z}^{n_1+n_2}}")#text(", where ")#mi("{A = (A_1 A_2) \\in M_{d \\times n_1 + n_2}({\\bf Z})}")#text(" is the matrix formed by concatenating the columns of ")#mi("{A_1}")#text(" with the columns of ")#mi("{A_2}")#text(".")],
[#text("(Direct sum) Given two lattice subgroups ")#mi("{A_1 {\\bf Z}^{n_1} \\leq {\\bf Z}^{d_1}}")#text(", ")#mi("{A_2 {\\bf Z}^{n_2} \\leq {\\bf Z}^{d_2}}")#text(", the direct sum ")#mi("{A_1 {\\bf Z}^{n_1} \\times A_2 {\\bf Z}^{n_2}}")#text(" is equal to the lattice subgroup ")#mi("{A {\\bf Z}^{n_1+n_2}}")#text(", where ")#mi("{A = \\begin{pmatrix} A_1 & 0 \\\\ 0 & A_2 \\end{pmatrix} \\in M_{d_1+d_2 \\times n_1 + n_2}({\\bf Z})}")#text(" is the block matrix formed by taking the direct sum of ")#mi("{A_1}")#text(" and ")#mi("{A_2}")#text(".")]
)

#text("One can also use Smith normal form to detect when one lattice subgroup ")#mi("{B {\\bf Z}^m \\leq {\\bf Z}^d}")#text(" is a subgroup of another lattice subgroup ")#mi("{A {\\bf Z}^n \\leq {\\bf Z}^d}")#text(". Using Smith normal form factorization ")#mi("{A = U D V}")#text(", with invariant factors ")#mi("{\\alpha_1|\\dots|\\alpha_k}")#text(", the relation ")#mi("{B {\\bf Z}^m \\leq A {\\bf Z}^n}")#text(" is equivalent after some manipulation to")

#align(center)[#tao-fit-display[#mitex("U^{-1} B {\\bf Z}^m \\leq D {\\bf Z}^n.")]]

#text("The group ")#mi("{U^{-1} B {\\bf Z}^m}")#text(" is generated by the columns of ")#mi("{U^{-1} B}")#text(", so this gives a test to determine whether ")#mi("{B {\\bf Z}^{m} \\leq A {\\bf Z}^{n}}")#text(": the ")#mi("{i^{th}}")#text(" row of ")#mi("{U^{-1} B}")#text(" must be divisible by ")#mi("{\\alpha_i}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", and all other rows must vanish.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" To test whether the lattice subgroup ")#mi("{\\Gamma^{\\prime}}")#text(" generated by ")#mi("{(1,1,1)}")#text(" and ")#mi("{(0,2,0)}")#text(" is contained in the lattice subgroup ")#mi("{\\Gamma = A{\\bf Z}^3}")#text(" from Example ")#link(<tao-981f4e620f014826311b>)[#text("2")]#text(", we write ")#mi("{\\Gamma^{\\prime}}")#text(" as ")#mi("{B {\\bf Z}^2}")#text(" with ")#mi("{B = \\begin{pmatrix} 1 & 0 \\\\ 1 & 2 \\\\ 1 & 0\\end{pmatrix}}")#text(", and observe that")

#align(center)[#tao-fit-display[#mitex("U^{-1} B = \\begin{pmatrix} 1 & 2 \\\\ -2 & -6 \\\\ 0 & 0 \\end{pmatrix}.")]]

#text("The first row is of course divisible by ")#mi("{1}")#text(", and the last row vanishes as required, but the second row is not divisible by ")#mi("{8}")#text(", so ")#mi("{\\Gamma^{\\prime}}")#text(" is not contained in ")#mi("{\\Gamma}")#text(" (but ")#mi("{4\\Gamma^{\\prime}}")#text(" is); also a similar computation verifies that ")#mi("{\\Gamma}")#text(" is conversely contained in ")#mi("{\\Gamma^{\\prime}}")#text(".")
]

#text("One can now test whether ")#mi("{B{\\bf Z}^m = A{\\bf Z}^n}")#text(" by testing whether ")#mi("{B{\\bf Z}^m \\leq A{\\bf Z}^n}")#text(" and ")#mi("{A{\\bf Z}^n \\leq B{\\bf Z}^m}")#text(" simultaneously hold (there may be more efficient ways to do this, but this is already computationally manageable in many applications). This in principle addresses the issue of non-uniqueness of representation of a subgroup ")#mi("{\\Gamma}")#text(" in the form ")#mi("{A{\\bf Z}^n}")#text(".")

#text("Next, we consider the question of representing the intersection ")#mi("{A{\\bf Z}^n \\cap B{\\bf Z}^m}")#text(" of two subgroups ")#mi("{A{\\bf Z}^n, B{\\bf Z}^m \\leq {\\bf Z}^d}")#text(" in the form ")#mi("{C{\\bf Z}^p}")#text(" for some ")#mi("{p}")#text(" and ")#mi("{C \\in M_{d \\times p}({\\bf Z})}")#text(". We can write")

#tao-aligned(keep: true)[


#tao-math("A{\\bf Z}^n \\cap B{\\bf Z}^m  & = \\{ Ax: Ax = By \\text{ for some } x \\in {\\bf Z}^n, y \\in {\\bf Z}^m \\}", block: true)



#tao-math(" & = (A 0) \\{ z \\in {\\bf Z}^{n+m}: (A B) z = 0 \\}", block: true)
]

#text("where ")#mi("{(A B) \\in M_{d \\times n+m}({\\bf Z})}")#text(" is the matrix formed by concatenating ")#mi("{A}")#text(" and ")#mi("{B}")#text(", and similarly for ")#mi("{(A 0) \\in M_{d \\times n+m}({\\bf Z})}")#text(" (here we use the change of variable ")#mi("{z = \\begin{pmatrix} x \\\\ -y \\end{pmatrix}}")#text("). We apply the Smith normal form to ")#mi("{(A B)}")#text(" to write")

#align(center)[#tao-fit-display[#mitex("(A B) = U D V")]]

#text("where ")#mi("{U \\in GL_d({\\bf Z})}")#text(", ")#mi("{D \\in M_{d \\times n+m}({\\bf Z})}")#text(", ")#mi("{V \\in GL_{n+m}({\\bf Z})}")#text(" with ")#mi("{D}")#text(" of rank ")#mi("{k}")#text(". We can then write")

#tao-aligned(keep: true)[


#tao-math("\\{ z \\in {\\bf Z}^{n+m}: (A B) z = 0 \\}  & = V^{-1} \\{ w \\in {\\bf Z}^{n+m}: Dw = 0 \\}", block: true)



#tao-math(" & = V^{-1} (\\{0\\}^k \\times {\\bf Z}^{n+m-k})", block: true)
]

#text("(making the change of variables ")#mi("{w = Vz}")#text("). Thus we can write ")#mi("{A{\\bf Z}^n \\cap B{\\bf Z}^m = C {\\bf Z}^{n+m-k}}")#text(" where ")#mi("{C \\in M_{d \\times n+m-k}({\\bf Z})}")#text(" consists of the right ")#mi("{n+m-k}")#text(" columns of ")#mi("{(A 0) V^{-1} \\in M_{d \\times n+m}({\\bf Z})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" ")#metadata(none) <tao-03fdb065d956f3fb9ccd>#text(" With the lattice ")#mi("{A{\\bf Z}^3}")#text(" from Example ")#link(<tao-981f4e620f014826311b>)[#text("2")]#text(", we shall compute the intersection of ")#mi("{A{\\bf Z}^3}")#text(" with the subgroup ")#mi("{{\\bf Z}^2 \\times \\{0\\}}")#text(", which one can also write as ")#mi("{B{\\bf Z}^2}")#text(" with ")#mi("{B = \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\\\ 0 & 0 \\end{pmatrix}}")#text(". We obtain a Smith normal form")

#align(center)[#tao-fit-display[#mitex("(A B) = \\begin{pmatrix} 0 & 1 & 0 \\\\ 1 & 0 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix} \\begin{pmatrix} 1 & 0 & 0 & 0 & 0 \\\\ 0 & 1 & 0 & 0 & 0 \\\\ 0 & 0 & 1 & 0 & 0 \\end{pmatrix} \\begin{pmatrix} 3 & -2 & 1 & 0 & 1 \\\\ 1 & 2 & 3 & 1 & 0 \\\\ 1 & 2 & 3 & 0 & 0 \\\\ 1 & 0 & 0 & 0 & 0 \\\\ 0 & 1 & 1 & 0 & 0 \\end{pmatrix}")]]

#text("so ")#mi("{k=3}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("(A 0) V^{-1} = \\begin{pmatrix} 0 & 0 & 1 & 0 & 0 \\\\ 0 & 0 & 3 & 0 & -8 \\\\ 0 & 0 & 1 & 0 & 0 \\end{pmatrix}")]]

#text("and so we can write ")#mi("{A{\\bf Z}^3 \\cap B{\\bf Z}^2 = C{\\bf Z}^2}")#text(" where")

#align(center)[#tao-fit-display[#mitex("C = \\begin{pmatrix} 0 & 0 \\\\ 0 & -8 \\\\ 0 & 0 \\end{pmatrix}.")]]

#text("One can trim this representation if desired, for instance by deleting the first column of ")#mi("{C}")#text(" (and replacing ")#mi("{{\\bf Z}^2}")#text(" with ")#mi("{{\\bf Z}}")#text("). Thus the intersection of ")#mi("{A{\\bf Z}^3}")#text(" with ")#mi("{{\\bf Z}^2 \\times \\{0\\}}")#text(" is the rank one subgroup generated by ")#mi("{(0,-8,0)}")#text(".")
]

#text("A similar calculation allows one to represent the pullback ")#mi("{T^{-1} (A {\\bf Z}^n) \\leq {\\bf Z}^{d^{\\prime}}}")#text(" of a subgroup ")#mi("{A{\\bf Z}^n \\leq {\\bf Z}^d}")#text(" via a linear transformation ")#mi("{T \\in M_{d \\times d^{\\prime}}({\\bf Z})}")#text(", since")

#tao-aligned(keep: true)[


#tao-math("T^{-1} (A {\\bf Z}^n)  & = \\{ x \\in {\\bf Z}^{d^{\\prime}}: Tx = Ay \\text{ for some } y \\in {\\bf Z}^m \\}", block: true)



#tao-math(" & = (I 0) \\{ z \\in {\\bf Z}^{d^{\\prime}+m}: (T A) z = 0 \\}", block: true)
]

#text("where ")#mi("{(I 0) \\in M_{d^{\\prime} \\times d^{\\prime}+m}({\\bf Z})}")#text(" is the concatenation of the ")#mi("{d^{\\prime} \\times d^{\\prime}}")#text(" identity matrix ")#mi("{I}")#text(" and the ")#mi("{d^{\\prime} \\times m}")#text(" zero matrix. Applying the Smith normal form to write ")#mi("{(T A) = UDV}")#text(" with ")#mi("{D}")#text(" of rank ")#mi("{k}")#text(", the same argument as before allows us to write ")#mi("{T^{-1}(A{\\bf Z}^n) = C {\\bf Z}^{d^{\\prime}+m-k}}")#text(" where ")#mi("{C \\in M_{d^{\\prime} \\times d^{\\prime}+m-k}}")#text(" consists of the right ")#mi("{d^{\\prime}+m-k}")#text(" columns of ")#mi("{(I 0) V^{-1} \\in M_{d^{\\prime} \\times d^{\\prime}+m}({\\bf Z})}")#text(".")

#text("Among other things, this allows one to describe lattices given by systems of linear equations and congruences in the ")#mi("{A{\\bf Z}^n}")#text(" format. Indeed, the set of lattice vectors ")#mi("{x \\in {\\bf Z}^d}")#text(" that solve the system of congruences ")#metadata(none) <tao-5b2c711c178a34ab45cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\alpha_i | x \\cdot v_i")]]

#text(" ")#text(" for ")#mi("{i=1,\\dots,k}")#text(", some natural numbers ")#mi("{\\alpha_i}")#text(", and some lattice vectors ")#mi("{v_i \\in {\\bf Z}^d}")#text(", together with an additional system of equations")

#metadata(none) <tao-d1372818d61d68676e19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("x \\cdot w_j = 0")]]

#text("for ")#mi("{j=1,\\dots,l}")#text(" and some lattice vectors ")#mi("{w_j \\in {\\bf Z}^d}")#text(", can be written as ")#mi("{T^{-1}(A {\\bf Z}^k)}")#text(" where ")#mi("{T \\in M_{k+l \\times d}({\\bf Z})}")#text(" is the matrix with rows ")#mi("{v_1,\\dots,v_k,w_1,\\dots,w_l}")#text(", and ")#mi("{A \\in M_{k+l \\times k}({\\bf Z})}")#text(" is the diagonal matrix with diagonal entries ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(". Conversely, any subgroup ")#mi("{A{\\bf Z}^n}")#text(" can be described in this form by first using the trimmed representation ")#mi("{A{\\bf Z}^n = UD^{\\prime}{\\bf Z}^k}")#text(", at which point membership of a lattice vector ")#mi("{x \\in {\\bf Z}^d}")#text(" in ")#mi("{A{\\bf Z}^n}")#text(" is seen to be equivalent to the congruences")

#align(center)[#tao-fit-display[#mitex("\\alpha_i | U^{-1} x \\cdot e_i")]]

#text("for ")#mi("{i=1,\\dots,k}")#text(" (where ")#mi("{k}")#text(" is the rank, ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" are the invariant factors, and ")#mi("{e_1,\\dots,e_d}")#text(" is the standard basis of ")#mi("{{\\bf Z}^d}")#text(") together with the equations")

#align(center)[#tao-fit-display[#mitex("U^{-1} x \\cdot e_j = 0")]]

#text("for ")#mi("{j=k+1,\\dots,d}")#text(". Thus one can obtain a representation in the form ")#link(<tao-5b2c711c178a34ab45cc>)[#text("(1)")]#text(", ")#link(<tao-d1372818d61d68676e19>)[#text("(2)")]#text(" with ")#mi("{l=d-k}")#text(", and ")#mi("{v_1,\\dots,v_k,w_1,\\dots,w_{d-k}}")#text(" to be the rows of ")#mi("{U^{-1}}")#text(" in order.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" With the lattice subgroup ")#mi("{A{\\bf Z}^3}")#text(" from Example ")#link(<tao-981f4e620f014826311b>)[#text("2")]#text(", we have ")#mi("{U^{-1} = \\begin{pmatrix} 0 & 1 & 0 \\\\ 0 & -3 & 1 \\\\ 1 & 0 & -1 \\end{pmatrix}}")#text(", and so ")#mi("{A{\\bf Z}^3}")#text(" consists of those triples ")#mi("{(x_1,x_2,x_3)}")#text(" which obey the (redundant) congruence")

#align(center)[#tao-fit-display[#mitex("1 | x_2,")]]

#text("the congruence")

#align(center)[#tao-fit-display[#mitex("8 | -3x_2 + x_3")]]

#text("and the identity")

#align(center)[#tao-fit-display[#mitex("x_1 - x_3 = 0.")]]

#text("Conversely, one can use the above procedure to convert the above system of congruences and identities back into a form ")#mi("{A^{\\prime} {\\bf Z}^{n^{\\prime}}}")#text(" (though depending on which Smith normal form one chooses, the end result may be a different representation of the same lattice group ")#mi("{A{\\bf Z}^3}")#text(").")
]

#text("Now we apply Pontryagin duality. We claim the identity")

#align(center)[#tao-fit-display[#mitex("(A{\\bf Z}^n)^\\perp = \\{ x \\in ({\\bf R}/{\\bf Z})^d: A^Tx = 0 \\}")]]

#text("for any ")#mi("{A \\in M_{d \\times n}({\\bf Z})}")#text(" (where ")#mi("{A^T \\in M_{n \\times d}({\\bf Z})}")#text(" induces a homomorphism from ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(" to ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" in the obvious fashion). This can be verified by direct computation when ")#mi("{A}")#text(" is a (rectangular) diagonal matrix, and the general case then easily follows from a Smith normal form computation (one can presumably also derive it from the category-theoretic properties of Pontryagin duality, although I will not do so here). So closed torus subgroups that are defined by a system of linear equations (over ")#mi("{{\\bf R}/{\\bf Z}}")#text(", with integer coefficients) are represented in the form ")#mi("{(A{\\bf Z}^n)^\\perp}")#text(" of an orthogonal complement of a lattice subgroup. Using the trimmed form ")#mi("{A{\\bf Z}^n = U D^{\\prime} {\\bf Z}^k}")#text(", we see that")

#tao-aligned(keep: true)[


#tao-math("(A{\\bf Z}^n)^\\perp  & = \\{ x \\in ({\\bf R}/{\\bf Z})^d: (UD^{\\prime})^T x = 0 \\}", block: true)



#tao-math(" & = (U^{-1})^T \\{ y \\in ({\\bf R}/{\\bf Z})^d: (D^{\\prime})^T x = 0 \\}", block: true)



#tao-math(" & = (U^{-1})^T (\\frac{1}{\\alpha_1} {\\bf Z}/{\\bf Z} \\times \\dots \\times \\frac{1}{\\alpha_k} {\\bf Z}/{\\bf Z} \\times ({\\bf R}/{\\bf Z})^{d-k}),", block: true)
]

#text("giving an explicit representation “in coordinates” of such a closed torus subgroup. In particular we can read off the isomorphism class of a closed torus subgroup as the product of a finite number of cyclic groups and a torus:")

#align(center)[#tao-fit-display[#mitex("(A{\\bf Z}^n)^\\perp \\equiv ({\\bf Z}/\\alpha_1 {\\bf Z}) \\times \\dots \\times ({\\bf Z}/\\alpha_k{\\bf Z}) \\times ({\\bf R}/{\\bf Z})^{d-k}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" ")#metadata(none) <tao-8ccf2f9e9cc41e7ad5bf>#text(" The orthogonal complement of the lattice subgroup ")#mi("{A{\\bf Z}^3}")#text(" from Example ")#link(<tao-981f4e620f014826311b>)[#text("2")]#text(" is the closed torus subgroup")

#tao-aligned(keep: true)[


#tao-math("(A{\\bf Z}^3)^\\perp  & = \\{ (x_1,x_2,x_3) \\in ({\\bf R}/{\\bf Z})^3: x_1 + 3x_2 + x_3", block: true)



#tao-math(" & = 2x_1 - 2x_2 + 2x_3 = 3x_1 + x_2 + 3x_3 = 0 \\};", block: true)
]

#text("using the trimmed representation of ")#mi("{(A{\\bf Z}^3)^\\perp}")#text(", one can simplify this a little to")

#tao-aligned(keep: true)[


#tao-math("(A{\\bf Z}^3)^\\perp  & = \\{ (x_1,x_2,x_3) \\in ({\\bf R}/{\\bf Z})^3: 3x_1 + x_2 + 3x_3", block: true)



#tao-math(" & = 8 x_1 + 8x_3 = 0 \\}", block: true)
]

#text("and one can also write this as the image of the group ")#mi("{\\{ 0\\} \\times (\\frac{1}{8}{\\bf Z}/{\\bf Z}) \\times ({\\bf R}/{\\bf Z})}")#text(" under the torus isomorphism")

#align(center)[#tao-fit-display[#mitex("(y_1,y_2,y_3) \\mapsto (y_3, y_1 - 3y_2, y_2 - y_3).")]]

#text("In other words, one can write")

#align(center)[#tao-fit-display[#mitex("(A{\\bf Z}^3)^\\perp = \\{ (y,0,-y) + (0,-\\frac{3a}{8},\\frac{a}{8}): y \\in {\\bf R}/{\\bf Z}; a \\in {\\bf Z}/8{\\bf Z} \\}")]]

#text("so that ")#mi("{(A{\\bf Z}^3)^\\perp}")#text(" is isomorphic to ")#mi("{{\\bf R}/{\\bf Z} \\times {\\bf Z}/8{\\bf Z}}")#text(".")
]

#text("We can now dualize all of the previous computable operations on subgroups of ")#mi("{{\\bf Z}^d}")#text(" to produce computable operations on closed subgroups of ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(". For instance:")

#list(
[#text("To form the intersection or sum of two closed torus subgroups ")#mi("{(A_1 {\\bf Z}^{n_1})^\\perp, (A_2 {\\bf Z}^{n_2})^\\perp \\leq ({\\bf R}/{\\bf Z})^d}")#text(", use the identities")

#align(center)[#tao-fit-display[#mitex("(A_1 {\\bf Z}^{n_1})^\\perp \\cap (A_2 {\\bf Z}^{n_2})^\\perp = (A_1 {\\bf Z}^{n_1} + A_2 {\\bf Z}^{n_2})^\\perp")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(A_1 {\\bf Z}^{n_1})^\\perp + (A_2 {\\bf Z}^{n_2})^\\perp = (A_1 {\\bf Z}^{n_1} \\cap A_2 {\\bf Z}^{n_2})^\\perp")]]

#text("and then calculate the sum or intersection of the lattice subgroups ")#mi("{A_1 {\\bf Z}^{n_1}, A_2 {\\bf Z}^{n_2}}")#text(" by the previous methods. Similarly, the operation of direct sum of two closed torus subgroups dualises to the operation of direct sum of two lattice subgroups.")],
[#text("To determine whether one closed torus subgroup ")#mi("{(A_1 {\\bf Z}^{n_1})^\\perp \\leq ({\\bf R}/{\\bf Z})^d}")#text(" is contained in (or equal to) another closed torus subgroup ")#mi("{(A_2 {\\bf Z}^{n_2})^\\perp \\leq ({\\bf R}/{\\bf Z})^d}")#text(", simply use the preceding methods to check whether the lattice subgroup ")#mi("{A_2 {\\bf Z}^{n_2}}")#text(" is contained in (or equal to) the lattice subgroup ")#mi("{A_1 {\\bf Z}^{n_1}}")#text(".")],
[#text("To compute the pull back ")#mi("{T^{-1}( (A{\\bf Z}^n)^\\perp )}")#text(" of a closed torus subgroup ")#mi("{(A{\\bf Z}^n)^\\perp \\leq ({\\bf R}/{\\bf Z})^d}")#text(" via a linear transformation ")#mi("{T \\in M_{d^{\\prime} \\times d}({\\bf Z})}")#text(", use the identity")

#align(center)[#tao-fit-display[#mitex("T^{-1}( (A{\\bf Z}^n)^\\perp ) = (T^T A {\\bf Z}^n)^\\perp.")]]

#text("Similarly, to compute the image ")#mi("{T( (B {\\bf Z}^m)^\\perp )}")#text(" of a closed torus subgroup ")#mi("{(B {\\bf Z}^m)^\\perp \\leq ({\\bf R}/{\\bf Z})^{d^{\\prime}}}")#text(", use the identity")

#align(center)[#tao-fit-display[#mitex("T( (B{\\bf Z}^m)^\\perp ) = ((T^T)^{-1} B {\\bf Z}^m)^\\perp.")]]]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" Suppose one wants to compute the sum of the closed torus subgroup ")#mi("{(A{\\bf Z}^3)^\\perp}")#text(" from Example ")#link(<tao-8ccf2f9e9cc41e7ad5bf>)[#text("6")]#text(" with the closed torus subgroup ")#mi("{\\{0\\}^2 \\times {\\bf R}/{\\bf Z}}")#text(". This latter group is the orthogonal complement of the lattice subgroup ")#mi("{{\\bf Z}^2 \\times \\{0\\}}")#text(" considered in Example ")#link(<tao-03fdb065d956f3fb9ccd>)[#text("4")]#text(". Thus we have ")#mi("{(A{\\bf Z}^3)^\\perp + (\\{0\\}^2 \\times {\\bf R}/{\\bf Z}) = (C{\\bf Z}^2)^\\perp}")#text(" where ")#mi("{C}")#text(" is the matrix from Example ")#link(<tao-8ccf2f9e9cc41e7ad5bf>)[#text("6")]#text("; discarding the zero column, we thus have")

#align(center)[#tao-fit-display[#mitex("(A{\\bf Z}^3)^\\perp + (\\{0\\}^2 \\times {\\bf R}/{\\bf Z}) = \\{ (x_1,x_2,x_3): -8x_2 = 0 \\}.")]]
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-649472")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2022")])]

#text("Do you know how this compares to using Hermite normal form, which is the more “normal” way to understand subgroups of ")#mi("\\mathbb{Z}^d")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-649505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("Good question! It’s quite possible that the operations considered here (e.g., computing the intersection of one lattice subgroup with another, pulling back a lattice by a linear transformation, or determining whether one lattice is contained in another) could also be calculated using the Hermite normal form instead of the Smith normal form. I have theoretical reasons for preferring the Smith normal form – roughly speaking, the Smith normal form describes lattices by producing a basis, whereas the Hermite normal form instead describes lattices by producing a filtration – but I could imagine that the Hermite normal form is computationally faster for some of the operations considered here. For instance, if one is simply interested in the rank of the lattice and nothing else, I am sure that there would be much faster ways to compute this than to work out the entire Smith normal form.")

#text("From the perspective of someone who simply wants to calculate with these subgroups numerically, I would prefer an object-oriented interface in which there were classes of lattice subgroup or closed torus subgroup objects with the operations I actually need (sum, intersection, pullback, equality, etc.), with the precise implementation of these operations (using Smith normal form, Hermite normal form, or any other method) hidden to me (or perhaps set as an optional flag in case the choice could be used to optimise computational performance). It would be convenient for me if such classes already exist somewhere, but I have no experience in trying to search for them (some desultory Google searches did not turn up anything promising).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-649507")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("OK, now that I have the tip of using the Hermite normal form as an additional search term, I am now beginning to find some hits (e.g., ")#link("https://cseweb.ucsd.edu/classes/wi16/cse206A-a/lec4.pdf")[#text("this set of notes")]#text(") – thanks! It does seem that the Hermite normal form is somewhat faster to compute than the Smith normal form while still being capable of computing most of the operations I actually need (except perhaps the invariant factors). I guess the situation is similar to that of choosing between the singular value decomposition and the LU factorization in linear algebra; the latter gives less information about a matrix, but it is generally faster and would be numerically preferable for certain tasks (such as inverting the matrix).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-649515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Why do you call the entries of a matrix coefficients? In the first sentence, you said “let ")#mi("M_{m\\times n}(Z)")#text(" denote ")#mi("m\\times n")#text(" matrix with integer coefficients”. Shouldn’t one say “with integer entries”? Coefficients usually mean the number in front of an algebraic expression. Or is there a deeper meaning here?")

#emph[#text("[I am largely viewing these matrices as coefficient matrices for their associated linear transformations, but I have changed the wording to “entries” here to reduce the apparent confusion. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a67e3e093f5f8324623d425191e93845f133202427a07f5cb2748846aa683c0-2b242fda0585eeccae8f56454598d427071d1feceab8a76851e978238e5a3ef4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Baker")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-650015")[#strong[#text("Matt Baker")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2022")])]

#text("There is also a correspondence between lattice subgroups and algebraic subgroups of the linear torus ")#mi("{\\mathbb G}_m^d")#text(", where a lattice subgroup ")#mi("\\Lambda")#text(" corresponds to the algebraic subgroup ")#mi("H_\\lambda = \\{ x \\in {\\mathbb G}_m^d \\; | \\; x^\\lambda = 1 \\; \\forall \\; \\lambda \\in \\Lambda \\}.")#text(" This is discussed in Section 3.2 of the book “Heights in Diophantine Geometry” by Bombieri and Gubler, for example. It might be interesting to extend your algorithmic considerations to this setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/176990da2790ecb44fb70868bad7a5920ed2b2cfa62a4e53bcd6d74a839d1c8a-c418c6b91e345eded7cafe66a9d99165512f5f5d3c415727c771f9ea40205295.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2022/07/20/using-the-smith-normal-form-to-manipulate-lattice-subgroups-and-closed-torus-subgroups/#comment-657766")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2022")])]

#text("It is worth mentioning that these computations are standard in lattice-based cryptography. See these notes of Daniele Micciancio’s (section 4 in particular).")

#link("https://cseweb.ucsd.edu/classes/wi10/cse206a/lec2.pdf")[#text("Click to access lec2.pdf")]
]
