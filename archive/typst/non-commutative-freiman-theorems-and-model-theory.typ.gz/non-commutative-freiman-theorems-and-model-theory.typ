// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/
// Converted to Typst by tao2typ: "2026-10-14T15:17:32.679693+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Non-commutative Freiman theorems, and model theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Non-commutative Freiman theorems, and model theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is an adaptation of ")#link("https://www.ipam.ucla.edu/schedule.aspx?pc=cmaws4")[#text("a talk I gave recently")]#text(" for a ")#link("http://www.ipam.ucla.edu/programs/cmaws4/")[#text("program at IPAM")]#text(". In this talk, I gave a (very informal and non-rigorous) overview of ")#link("http://arxiv.org/abs/0909.2190")[#text("Hrushovski’s use of model-theoretic techniques")]#text(" to establish new Freiman-type theorems in non-commutative groups, and some recent work in progress of ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~tws22/")[#text("Tom Sanders")]#text(" and myself to establish combinatorial proofs of some of Hrushovski’s results.")

#metadata(none) <tao-8800002d37908481c5d0>

#strong[#text(" — 1. Non-commutative Freiman theorems — ")]

#text("To avoid a preponderance of quantifiers, I will be somewhat loose with the ")#mi("{O()}")#text(" notation and with terminology such as “bounded” here. Precise statements can be found in Hrushovski’s paper (and in a forthcoming paper of Ben, Tom, and myself).")

#text("Let ")#mi("{A}")#text(" be a finite non-empty subset of a (possibly non-abelian) group ")#mi("{G}")#text(". We say that ")#mi("{A}")#text(" has ")#emph[#text("bounded doubling")]#text(" if ")#tao-math("{\\left|A \\cdot A\\right| \\leq K\\left|A\\right|}", block: false)#text(" for some ")#mi("{K = O(1)}")#text(", where ")#mi("{A \\cdot A = \\{ab: a,b \\in A \\}}")#text(" and ")#tao-math("{\\left|A\\right|}", block: false)#text(" is the cardinality of ")#mi("{A}")#text(". By a ")#emph[#text("non-commutative Freiman theorem")]#text(", I mean a result that classifies (up to losses in the ")#mi("{K}")#text(" parameter) what sets of bounded doubling look like.")

#text("For instance, if ")#mi("{K=1}")#text(", it is easy to see that ")#tao-math("{\\left|A \\cdot A\\right| \\leq \\left|A\\right|}", block: false)#text(" occurs if and only if ")#mi("{A}")#text(" is a coset ")#mi("{xH=Hx}")#text(" of a finite subgroup ")#mi("{H}")#text(" by an element ")#mi("{x}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Centralizer_and_normalizer")[#text("normaliser")]#text(" ")#mi("{N(H)}")#text(" of ")#mi("{H}")#text(". More generally, as we mentioned earlier ")#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("in this post")]#text(", it can be shown by elementary means that if ")#mi("{K < \\phi}")#text(", where ")#mi("{\\phi := \\frac{1+\\sqrt{5}}{2} = 1.618\\ldots}")#text(" is the golden ratio, then sets of doubling less than ")#mi("{K}")#text(" are ")#emph[#text("controlled")]#text(" by a finite subgroup. Here, we say that one finite set ")#mi("{B}")#text(" ")#emph[#text("controls")]#text(" another ")#mi("{A}")#text(" if they have comparable size (i.e. ")#tao-math("{\\left|B\\right| = O(\\left|A\\right|)}", block: false)#text(" and ")#tao-math("{\\left|A\\right| = O(\\left|B\\right|)}", block: false)#text(") and if ")#mi("{A}")#text(" can be covered by a bounded number of left or right translates of ")#mi("{B}")#text(" (i.e. ")#mi("{A \\subset X \\cdot B, B \\cdot X}")#text(" for some ")#mi("{X}")#text(" of size ")#tao-math("{\\left|X\\right| = O(1)}", block: false)#text("). Note that if ")#mi("{B}")#text(" has bounded doubling, and ")#mi("{B}")#text(" controls ")#mi("{A}")#text(", then ")#mi("{A}")#text(" has bounded doubling also. Thus it is natural for the conclusion of a Freiman-type theorem to be that a set of bounded doubling is controlled by a “structured” set of small doubling.")

#text("What does “structured” mean exactly? There is not yet a full consensus on what the list of structured objects should be (see ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("this earlier post")]#text(" for more discussion), but things are well understood in the abelian case, at least. Examples of structured sets of bounded doubling here include")

#list(
[#text("Finite subgroups;")],
[#text("Arithmetic progressions;")],
[#text("Generalised arithmetic progressions (i.e. sums of arithmetic progressions) of bounded dimension;")],
[#text("Coset progressions (sums of finite subgroups and generalised arithmetic progressions);")],
[#text("Balls in a word metric (or weighted word metric, with some generators allowed to have weight zero if they have finite order). These are closely related to coset progressions, indeed they are essentially the same class of sets (up to mutual control).")]
)

#emph[#text("Freiman’s theorem")]#text(", proven in the torsion-free abelian case by Freiman (with simplified proofs later given by Ruzsa and by Bilu), and in the general abelian case by Green and Ruzsa, asserts (roughly speaking) that all sets of small doubling are controlled by a coset progression (or equivalently, by a ball in a word metric). Except for the issue of quantifying constants, this is a satisfactory description of sets of small doubling. (For more on the question of improving the constants, see ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("this guest blog post")]#text(" of Ben Green.)")

#text("In the non-abelian case, known examples of structured sets of bounded doubling include")

#list(
[#text("Finite subgroups;")],
[#text("Balls in a (weighted) word metric in a nilpotent group (of bounded step);")],
[#text("Extensions of a structured set of bounded doubling by finite groups (i.e. given a short exact sequence ")#mi("{0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0}")#text(" of groups with ")#mi("{K}")#text(" finite, the pullback of any structured set in ")#mi("{H}")#text(" to ")#mi("{G}")#text(" will still qualify as a structed set of small doubling).")]
)

#text("One may optimistically conjecture that this is the full list (up to control), in that ")#emph[#text("every")]#text(" set of small doubling in an arbitrary group is controlled by a structured set of small doubling in the above list. This may be a bit too optimistic, but I do not know of any counterexamples, and in various special groups (e.g. nilpotent groups, free groups, simple or semisimple algebraic groups, and to a lesser extent solvable groups) the claim has been largely (though not completely) verified.")

#text("A small technical note: it is often convenient to work not with sets of small doubling, but rather sets of small tripling (so ")#tao-math("{\\left|A \\cdot A \\cdot A\\right| = O(\\left|A\\right|)}", block: false)#text("). This is a stronger condition in the nonabelian case; for instance, if ")#mi("{A = H \\cup \\{x\\}}")#text(" for a finite subgroup ")#mi("{H}")#text(" and for some ")#mi("{x}")#text(" not in the normaliser of ")#mi("{H}")#text(", then ")#mi("{A}")#text(" has small doubling but usually will have large tripling (due to the presence of ")#mi("{HxH}")#text(" in ")#mi("{A^3}")#text("). On the other hand, small tripling turns out to be sufficient to imply small quadrupling, etc. It is also convenient to assume symmetry ")#mi("{A = A^{-1}}")#text(". The connections between these properties is well understood, for instance it is known that every set of small doubling is controlled by a symmetric set of small tripling.")

#strong[#text(" — 2. Hrushovski’s results — ")]

#text("Using a new (and rather non-trivial) model-theoretic result in stable group theory (of which I will say more later), Hrushovski was able to establish three results of Freiman type in non-abelian settings. The first result is the easiest to prove (following more or less directly from the model-theoretic result), but requires that ")#mi("{A}")#text(" is “")#link("http://en.wikipedia.org/wiki/Simple_group")[#text("simple")]#text("” or “")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text("” in some statistical sense. Recall that if a group ")#mi("{G}")#text(" is simple, then every non-trivial conjugacy class ")#mi("{g^G := \\{ hgh^{-1}: h \\in G \\}}")#text(" (with ")#mi("{g}")#text(" not the identity) will necessarily generate the group ")#mi("{G}")#text(". In a similar vein, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hrushovski Corollary 1.2, slightly modified)")]#text(" ")#metadata(none) <tao-33112ee14ee469c3eb52>#text(" Let ")#mi("{A \\subset G}")#text(" be symmetric and of bounded tripling, and let ")#mi("{m, k \\geq 1}")#text(" be (bounded) integers. Suppose that for at least ")#mi("{(1-\\epsilon)}")#text(" of tuples ")#mi("{a_1,\\ldots,a_k \\in A^2}")#text(", one has")

#tao-math("\\displaystyle  \\left|a_1^A \\ldots a_k^A\\right| \\geq \\left|A\\right|/m,", block: false)

#text("where ")#mi("{a^A := \\{hah^{-1}: h \\in A \\}}")#text(" being a partial conjugacy class. If ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{k, m}")#text(" and the tripling constant, then ")#mi("{A}")#text(" is controlled by a finite subgroup of ")#mi("{G}")#text(".")
]

#text("By combining the model theoretic results with some techniques from algebraic group theory (in particular, some machinery of Larsen and Pink) the following variant was shown:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Hrushovski Theorem 1.3, slightly modified)")]#text(" ")#metadata(none) <tao-f998fe06afa0cfbe73e0>#text(" Let ")#mi("{A \\subset G}")#text(" be symmetric and of bounded tripling in a semisimple algebraic group ")#mi("{G}")#text(" of bounded dimension. Then ")#mi("{A}")#text(" is either controlled by a finite subgroup of ")#mi("{G}")#text(", or is contained in finitely many translates of a proper connected algebraic subgroup of ")#mi("{G}")#text(".")
]

#text("Finally, by combining the model theoretic results with the deep theory of Gleason and Yamabe on Hilbert’s fifth problem, the following general result was obtained in an arbitrary group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Hrushovski Theorem 1.1, slightly modified)")]#text(" ")#metadata(none) <tao-97fb5f8538b89f6c1acc>#text(" Let ")#mi("{A \\subset G}")#text(" be symmetric and of bounded tripling in an arbitrary group ")#mi("{G}")#text(". Then there exists a long sequence")

#mi("\\displaystyle  A^4 \\supset B_1 \\supset B_2 \\supset \\ldots \\supset B_M")

#text("where the ")#mi("{B_i}")#text(" behave like a nested sequence of nilpotent balls in the following sense:")

#list(
[#text("Each of the ")#mi("{B_i}")#text(" is symmetric and contains the origin;")],
[#text("Each of the ")#mi("{B_i}")#text(" control ")#mi("{B_{i-1}}")#text(", with ")#mi("{B_1}")#text(" controlling ")#mi("{A^4}")#text(";")],
[#mi("{B_i \\cdot B_i \\subset B_{i-1}}")#text(";")],
[#mi("{[B_i,B_j] \\subset B_{i+j}}")#text(" (for ")#mi("{i+j \\leq M}")#text("), where ")#mi("{[B_i,B_j] := \\{ghg^{-1}h^{-1}: g \\in B_i, h \\in B_j \\}}")#text(".")]
)

#text("Furthermore one can take ")#mi("{M}")#text(" to be arbitrarily large compared to the constants in the control statements.")
]

#text("The conclusion is similar to, but not quite identical with, a certain “weak Freiman theorem” conjectured by Ben Green (and partially verified by Tom Sanders). It is not yet well understood how to exploit this type of conclusion effectively, but nevertheless this represents one of the deepest facts we know about sets of bounded doubling in a completely arbitrary group.")

#text("Let me briefly (and inaccurately) describe how model theory enters in this picture. In each of these claims, we are trying to prove a combinatorial statement, which is roughly of the form “if ")#mi("{A \\subset G}")#text(" has bounded tripling and obeys some additional properties, then ")#mi("{A}")#text(" is controlled by something structured, with some parameters ")#mi("{K}")#text("“, where the parameter ")#mi("{K}")#text(" determines how strong the control is.")

#text("We use the ")#emph[#text("compactness and contradiction method")]#text(" to establish such claims. Suppose the claim failed, then by negating all the quantifiers (and invoking the axiom of choice if necessary), one can find a sequence ")#mi("{A_n \\subset G_n}")#text(" of “increasingly bad” counterexamples in various groups ")#mi("{G_n}")#text(", such that the ")#mi("{A_n}")#text(" have uniformly bounded tripling (and obey the other hypotheses uniformly in ")#mi("{n}")#text(" also), but for which the conclusion fails for any given ")#mi("{K}")#text(", if ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{K}")#text(". (For instance, ")#mi("{A_n}")#text(" might not be coverable by ")#mi("{K}")#text(" copies of a subgroup of size at least ")#tao-math("{\\left|A_n\\right|/K}", block: false)#text(", if ")#mi("{n}")#text(" is large enough depending on ")#mi("{K}")#text(".)")

#text("Now, one takes an ultraproduct of these finitary examples ")#mi("{A_n \\subset G_n}")#text(" to create an infinitary “limiting example” ")#mi("{A \\subset G}")#text(" in a much larger group ")#mi("{G}")#text(" (the ultraproduct of the ")#mi("{G_n}")#text("). Typically, ")#mi("{A}")#text(" and ")#mi("{G}")#text(" will now both be uncountably infinite, and so notions of cardinality are no longer useful to define “small doubling” or “small tripling”. However, in each finite setting ")#mi("{A_n \\subset G_n}")#text(", one can define a ")#emph[#text("normalised cardinality")]#text(" ")#mi("{\\mu_n(B)}")#text(" of any finite set ")#mi("{B\\subset G_n}")#text(" by ")#tao-math("{\\mu_n(B) := \\left|B\\right|/\\left|A_n\\right|}", block: false)#text(", thus we are using ")#mi("{A_n}")#text(" as the “unit” of cardinality here. We can take an ultralimit of the ")#mi("{\\mu_n}")#text(" also (and restrict to the standard part of this limit), to create a limiting “measure” ")#mi("{\\mu(B)}")#text(" (known as a ")#emph[#text("Kiesler measure")]#text(") which assigns an extended real number in ")#mi("{[0,+\\infty]}")#text(" to any ")#emph[#text("definable")]#text(" subset ")#mi("{B}")#text(" of ")#mi("{G}")#text(". Thus for instance ")#mi("{\\mu(A)=1}")#text(". We will not precisely define what it means for a set to be definable here, but roughly it means any set that can be defined in terms of ")#mi("{A}")#text(", the group operations, the Keisler measure, and a finite number of constant elements of ")#mi("{G}")#text(". (Thus for instance ")#mi("{A \\cdot A}")#text(", or ")#mi("{x_1 \\cdot A \\cap x_2 \\cap A}")#text(", or ")#mi("{Sym_\\alpha(A) := \\{ x \\in A: \\mu(A \\cap xA) > \\alpha \\}}")#text(" would be definable sets for constants ")#mi("{x_1,x_2 \\in G}")#text(" and ")#mi("{\\alpha\\in {\\mathbb R}}")#text(".) The Keisler measure behaves in many ways like a Haar measure (in particular, it is left-invariant and right-invariant), although there are some technical differences, most notably it is only finitely additive rather than countably additive.")

#text("Anyway, with this Kiesler measure in hand, a bounded doubling condition becomes ")#mi("{\\mu(A \\cdot A) = O(1)}")#text(", and similarly for bounded tripling conditions, and similar hypotheses.")

#text("The definable subsets of ")#mi("{G}")#text(" form a boolean algebra, and can be used as a base to define a topology on ")#mi("{G}")#text(" (closely related to the ")#emph[#text("Stone topology")]#text(" of ")#mi("{G}")#text("). In particular, the closed sets of these topology are the intersection of a (possibly infinite) number of definable sets, and are thus known as ")#emph[#mi("{\\bigcap}")#text("-definable sets")]#text(" (or ")#emph[#mi("{\\bigwedge}")#text("-definable sets")]#text(", or ")#emph[#text("type-definable sets")]#text("). Such sets can be non-trivial in this infinitary world but do not rigorously have any non-trivial presence in any finitary setting. For instance, one could imagine continually refining the set ")#mi("{A}")#text(", for instance by writing ")#mi("{A_1 := A \\cap (x_1 \\cdot A)}")#text(", ")#mi("{A_2 := A_1 \\cap (x_2 \\cdot A_1)}")#text(", etc. for some sequence ")#mi("{x_1,x_2,\\ldots}")#text("; this is a typical construction in finitary additive combinatorics. Each of these ")#mi("{A_i}")#text(" is definable, so the intersection ")#mi("{\\bigcap_{i=1}^\\infty A_i}")#text(" is ")#mi("{\\bigcap}")#text("-definable. In a finitary setting, such an infinite intersection would likely be trivial (i.e. empty); but in the infinitary setting the intersection can remain non-trivial. But as it is only ")#mi("{\\bigcap}")#text("-definable rather than definable, it does not directly correspond to anything non-trivial in the finitary world.")

#text("In order to have ")#mi("{\\bigwedge}")#text("-definable sets non-trivial, it is very useful to impose various ")#emph[#text("compactness")]#text(" properties on the topology of definable sets; in particular, if ")#mi("{G}")#text(" was genuinely compact, then any family of definable sets which had non-empty finite intersections, would have non-empty complete intersections. In general, ")#mi("{G}")#text(" will not be compact in this manner, but it is possible to extend ")#mi("{G}")#text(" (and ")#mi("{A}")#text(") to a larger model which is an ")#emph[#text("elementary extension")]#text(" of the existing model (in the sense that every first-order statement true in the original model, is still true then the extension), in such a way that this sort of compactness property is obtained (at least when one does not use an enormous number of constants when building definable sets). This type of property is known as ")#emph[#text("saturation")]#text(", and one can always find a saturated extension after enlarging ")#mi("{G}")#text(" (and ")#mi("{A}")#text(") a sufficiently large number of times. (This “sufficiently large” may be extremely large, depending on how strong a saturation property one wants; for instance, measurable cardinals may be involved.)")

#text("Once one has saturation, the definable sets behave well in various ways, and one can study how numerous these sets are, and how they relate to each other. Part of this study is known as ")#emph[#text("stability theory")]#text(", or ")#emph[#text("stable group theory")]#text(" when applied particularly to group models. By using methods from this theory, one can define various useful notions (such as the “dimension” of a definable set, or the notion of various elements being “in general position” within a definable set). Using this type of machinery, Hrushovski proved a rather technical result in stable group theory, which when specialised to the context of sets of small tripling, gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Hrushovski Theorem 3.4, special case)")]#text(" ")#metadata(none) <tao-c7c01c6c16d7edbb6505>#text(" Let ")#mi("{\\mu}")#text(" be an invariant Kiesler measure, and let ")#mi("{A \\subset G}")#text(" which is symmetric and has small tripling in the sense that ")#mi("{\\mu(A) = 1}")#text(" and ")#mi("{\\mu(A \\cdot A \\cdot A) < \\infty}")#text(". Then ")#mi("{A^4}")#text(" contains a normal ")#mi("{\\bigcap}")#text("-definable subgroup ")#mi("{S}")#text(", which is ")#emph[#text("wide")]#text(" in the sense that every definable set that contains ")#mi("{S}")#text(" has positive measure. (As ")#mi("{S}")#text(" is only ")#mi("{\\bigcap}")#text("-definable rather than definable, ")#mi("{S}")#text(" cannot be measured directly; one can only measure the definable sets that ")#mi("{S}")#text(" is contained in.)")
]

#text("If ")#mi("{S}")#text(" were itself definable, it would have positive measure, and it would not be hard to show that the subgroup ")#mi("{S}")#text(" controls ")#mi("{A}")#text(". But in general ")#mi("{S}")#text(" is smaller than this. If for instance ")#mi("{A_n}")#text(" were a progression such as ")#mi("{\\{-n,\\ldots,n\\}}")#text(" in the integers, then in the ultralimit ")#mi("{A}")#text(" would be something like a non-standard interval ")#mi("{\\{-N,\\ldots,N\\}}")#text(" in the nonstandard integers (where ")#mi("{N}")#text(" is an unbounded nonstandard integer), and ")#mi("{S}")#text(" would be something like the intersection of the definable sets ")#mi("{S_i := \\{ x: ix \\in A \\} = \\{ -\\lfloor N/i\\rfloor, \\ldots, \\lfloor N/i\\rfloor\\}}")#text(" for all standard ")#mi("{i}")#text(". Each of the ")#mi("{S_i}")#text(" would have positive measure (")#mi("{1/i}")#text("), but this measure goes to zero as ")#mi("{i \\rightarrow \\infty}")#text(", so ")#mi("{S}")#text(" does not itself has positive measure; but it remains wide (and is a normal subgroup).")

#text("As mentioned earlier, this theorem is one of the key ingredients used to prove Theorems ")#link(<tao-33112ee14ee469c3eb52>)[#text("1")]#text(", ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("2")]#text(", ")#link(<tao-97fb5f8538b89f6c1acc>)[#text("3")]#text(", though in the case of Theorems ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("2")]#text(", ")#link(<tao-97fb5f8538b89f6c1acc>)[#text("3")]#text(" one also needs methods from algebraic group theory and from topological group theory respectively.")

#strong[#text(" — 3. Combinatorial approach — ")]

#text("Recently, ")#link("http://arxiv.org/abs/0912.0306")[#text("Sanders")]#text(" and ")#link("http://people.math.gatech.edu/~ecroot/prob-almost-periods.pdf")[#text("Croot-Sisask")]#text(" independently provided elementary proofs of the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Locating a core set)")]#text(" Let ")#mi("{A}")#text(" be a symmetric set of small doubling, and let ")#mi("{k \\geq 1}")#text(". Then there exists a set ")#mi("{S \\subset A}")#text(" with ")#tao-math("{\\left|S\\right| \\gg_k \\left|A\\right|}", block: false)#text(" such that ")#mi("{S^k \\subset A^4}")#text(".")
]

#text("(A weaker version of this lemma was also established ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("by myself")]#text(" previously.)")

#emph[#text("Proof:")]#text(" (Sketch of Sanders’ proof) For any ")#mi("{B \\subset A}")#text(", the set ")#mi("{B \\cdot A}")#text(" has cardinality between ")#tao-math("{\\left|A\\right|}", block: false)#text(" and ")#tao-math("{K\\left|A\\right|}", block: false)#text(", where ")#mi("{K}")#text(" is the doubling constant of ")#mi("{A}")#text(". From this observation and a pigeonholing argument, one can find a subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(" which is not too small, with the property that ")#mi("{B^{\\prime} \\cdot A}")#text(" is not much smaller than ")#mi("{B \\cdot A}")#text(" for any dense subset ")#mi("{B^{\\prime}}")#text(" of ")#mi("{B}")#text(", in particular ")#metadata(none) <tao-226a193ae269296d44f3>



#text("(say).")

#text("We now let ")#mi("{S}")#text(" be the set of elements ")#mi("{s}")#text(" such that the set ")#mi("{B^{\\prime} := B \\cap sB}")#text(" is large; this set can be shown to be not too small. From ")#link(<tao-226a193ae269296d44f3>)[#text("(1)")]#text(" we then have")

#tao-math("\\displaystyle  \\left|(B \\cdot A) \\cap s(B \\cdot A)\\right| \\geq \\left|(B \\cap sB) \\cdot A\\right| \\geq (1 - \\frac{1}{10 k}) \\left|B \\cdot A\\right|,", block: false)

#text("thus ")#mi("{s}")#text(" only shifts ")#mi("{B \\cdot A}")#text(" by a relative fraction of at most ")#mi("{1/10k}")#text(". Iterating this, we see that every element in ")#mi("{S^k}")#text(" cannot shift ")#mi("{B \\cdot A}")#text(" completely outside itself, and so must lie in ")#mi("{(B \\cdot A) \\cdot (B \\cdot A)^{-1} \\cdot A^4}")#text(" as claimed.")

#text("(Sketch of the Croot-Sisask proof) This is a random sampling argument. Let ")#mi("{\\Sigma}")#text(" be a bounded size random subset of ")#mi("{A}")#text(". Then with high probability, one can approximate ")#mi("{1_A * 1_A}")#text(" in an ")#mi("{L^2}")#text(" sense by ")#tao-math("{\\frac{\\left|\\Sigma\\right|}{\\left|A\\right|} 1_{\\Sigma} * 1_A}", block: false)#text(". On the other hand, one can find many ")#mi("{s}")#text(" such that ")#mi("{\\Sigma, s\\Sigma}")#text(" both sit inside ")#mi("{A}")#text(" with reasonable probability. Because of this, one can find many ")#mi("{s}")#text(" that do not shift ")#mi("{1_A*1_A}")#text(" very much. Letting ")#mi("{S}")#text(" be the set of such ")#mi("{s}")#text(", one obtains the claim by a similar argument as before (using a function ")#mi("{1_A*1_A}")#text(" instead of a set ")#mi("{B \\cdot A}")#text(", but the argument is much the same). ")#mi("\\Box")

#text("On the model-theoretic side, this lemma is like a weak version of Theorem ")#link(<tao-c7c01c6c16d7edbb6505>)[#text("4")]#text(" in which the subgroup ")#mi("{S}")#text(" is not assumed to be normal. Recall however in group theory that any finite index subgroup ")#mi("{H}")#text(" of a group ")#mi("{G}")#text(" contains a normal subgroup ")#mi("{H^{\\prime}}")#text(", formed by intersecting all the conjugates of ")#mi("{H}")#text(" together. It turns out that one can pull off a similar trick in the bounded tripling regime, and obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6 (Locating a normal core set)")]#text(" ")#metadata(none) <tao-fbed70f7d9d64f1b776c>#text(" Let ")#mi("{A}")#text(" be a symmetric set of small tripling, and let ")#mi("{k \\geq 1}")#text(". Then there exists a set ")#mi("{S \\subset A}")#text(" with ")#tao-math("{\\left|S\\right| \\gg_k \\left|A\\right|}", block: false)#text(" such that ")#mi("{(S^A)^k \\subset A^4}")#text(", where ")#mi("{S^A := \\{ asa^{-1}: a \\in A, s \\in S \\}}")#text(".")
]

#text("This is broadly analogous to Theorem ")#link(<tao-c7c01c6c16d7edbb6505>)[#text("4")]#text("; the ")#mi("{\\bigcap}")#text("-definable set ")#mi("{S}")#text(" in that theorem morally corresponds to the intersection of all the sets ")#mi("{S = S_k}")#text(" arising in Corollary ")#link(<tao-fbed70f7d9d64f1b776c>)[#text("6")]#text(", though I have not attempted to make this correspondence more rigorous than a mere heuristic analogy.")

#text("Ben Green, Tom Sanders and I were able to use Corollary ")#link(<tao-fbed70f7d9d64f1b776c>)[#text("6")]#text(" to provide finitary (and quantitative) proofs of Theorems ")#link(<tao-33112ee14ee469c3eb52>)[#text("1")]#text(", ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("2")]#text(" of Hrushovski, though Theorem ")#link(<tao-97fb5f8538b89f6c1acc>)[#text("3")]#text(" still eludes us. Here is a sketch of the proof of Theorem ")#link(<tao-33112ee14ee469c3eb52>)[#text("1")]#text(". Using Corollary ")#link(<tao-fbed70f7d9d64f1b776c>)[#text("6")]#text(", we can find a tiny (but not too tiny) set ")#mi("{S}")#text(" such that ")#mi("{(S^A)^{kl} \\subset A^4}")#text(" for some large ")#mi("{l}")#text(". Combining this with the hypothesis of Theorem ")#link(<tao-33112ee14ee469c3eb52>)[#text("1")]#text(", we can find (if ")#mi("{\\epsilon}")#text(" is small enough) ")#mi("{a_1,\\ldots,a_k \\in S}")#text(" such that ")#mi("{(a_1^A \\ldots a_k^A)^l \\subset A^4}")#text(", and such that ")#mi("{a_1^A \\ldots a_k^A}")#text(" is quite large (cardinality at least ")#tao-math("{\\left|A\\right|/m}", block: false)#text("). Choosing ")#mi("{l}")#text(" large enough, we thus see from the pigeonhole principle that there is an intermediate power ")#mi("{B = (a_1^A \\ldots a_k^A)^r}")#text(" of ")#mi("{a_1^A \\ldots a_k^A}")#text(" whose doubling constant is small, say less than the golden ratio ")#mi("{\\phi}")#text(". But then by previous results, ")#mi("{B}")#text(" is controlled by a subgroup, and then it is not hard to show that ")#mi("{A}")#text(" is controlled also.")

#text("The proof of Theorem ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("2")]#text(" is similar. In lieu of the hypothesis of Theorem ")#link(<tao-33112ee14ee469c3eb52>)[#text("1")]#text(", one uses the classical fact that in a simple group ")#mi("{G}")#text(", there exists an integer ")#mi("{k}")#text(" (called the ")#emph[#text("covering number")]#text(" of ")#mi("{G}")#text(") such that for every non-trivial conjugacy class ")#mi("{g^G}")#text(", ")#mi("{(g^G)^k = G}")#text(". (Basically, the point is that the dimension of a non-trivial conjugation-invariant subvariety of ")#mi("{G}")#text(" must increase when one doubles it.) The next ingredient is a sharp form of the “escape from subvarieties” phenomenon, namely that for any algebraic variety ")#mi("{V}")#text(" in a simple group ")#mi("{G}")#text(" and any symmetric set ")#mi("{A}")#text(" in ")#mi("{G}")#text(", one has ")#tao-math("{\\left|A \\cap V\\right| \\ll \\left|A^{O(1)}\\right|^{\\dim(V)/\\dim(G)}}", block: false)#text("; in particular, ")#mi("{A}")#text(" cannot concentrate in ")#mi("{V}")#text(" if ")#mi("{V}")#text(" has strictly smaller dimension than ")#mi("{V}")#text(". This estimate is (very) implicit in ")#link("http://www.math.ethz.ch/~pink/ftp/LP5.pdf")[#text("work of Larsen and Pink")]#text(", and later ")#link("http://arxiv.org/abs/0909.2190")[#text("by Hrushovski")]#text("; closely related estimates were also ")#link("http://arxiv.org/abs/0807.2027")[#text("established by Helfgott")]#text(". One can obtain this estimate by inspecting the double counting identity")

#tao-math("\\displaystyle  \\left|A \\cap V\\right| \\left|A \\cap W\\right| = \\sum_{x \\in (A^2 \\cap VW)} \\left|A \\cap (V \\cap x W^{-1}) \\cap x A^{-1}\\right|", block: false)

#text("for various algebraic varieties ")#mi("{V,W}")#text("; the details are slightly technical and will not be presented here.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42734")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("In ")#tao-math("{\\left|A \\cap G\\right| \\ll \\left|A^{O(1)}\\right|^{\\dim(V)/\\dim(G)}}", block: false)#text(", surely you mean ")#mi("A\\cap V")#text(" rather than ")#mi("A\\cap G")#text("? ")#emph[#text("[Yes, thanks – T.]")]

#text("While this is true in a general moral sense, you may need some conditions, at least if the group is not simple; I understand, then, that you are still assuming that G is simple at this point. I was discussing this a little with Breuillard over the weekend – in my paper on SL_3, I proved this in all cases that I needed; it is clear that the hypotheses could be relaxed (in particular: while dim(V) always divided dim(G) in the cases I was studying, one need not make such a requirement, thanks to the fact that one can iterate the procedure) but it was and is not completely clear to me what the most general conditions would be.")

#text("You really mean that this should be true for all simple algebraic groups, with no further conditions? That would be very nice. I take you are getting polynomial growth?")

#text("(For the benefit of other readers: my approach to proving this is to stick V into different directions by conjugation, and to multiply the different copies of A \\cap V that one gets.")#linebreak()#text(" One can always use stick V in “generic” directions, thanks to escape from subvarieties; in many circumstances, this is enough for the different copies of V to have only zero-dimensional pairwise intersections. If they do not, one should still get the result one wants unless an intersection of two copies of V has many elements of A on it –")#linebreak()#text(" but if that is the case, one can pass to that intersection and iterate, since it will have")#linebreak()#text(" lower dimension than V. I can see how this actually ought to work for any simple group, but I have not checked the details.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42743")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Yes, this is all for simple groups; the plan here is to first get Freiman type theorems in the simple group case and then climb up a bunch of short exact sequences to get up to the semisimple case (since small doubling is more or less preserved under homomorphisms and with intersecting with fibres of such homomorphisms).")

#text("The Larsen-Pink argument shows that bounds of the form ")#tao-math("\\left|A \\cap V\\right| \\ll \\left|A^{O(1)}\\right|^{\\alpha(dim(V))}", block: false)#text(" can be iteratively improved until the dependence of the exponent ")#mi("\\alpha(dim(V))")#text(" on the dimension becomes the optimal exponent ")#mi("dim(V)/dim(G)")#text(". It’s not too different from the machinery in your paper: start with V and W being counterexamples to the inequality one is trying to prove, with V of maximal dimension and W of minimal dimension. One can conjugate one of these by an element of A (using escape from subvarieties and simplicity) to ensure that VW has strictly larger dimension than V, and hence the fibres have strictly lesser dimension than W generically. In particular, the estimates one wants are already true in those varieties. At this point one uses the double counting inequality mentioned in the post to get a contradiction.")

#text("This part of the argument is indeed polynomial, but the stuff about getting the normal subgroup has at least one exponential loss in it (perhaps two). We’re still working on trying to clean it all up…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("And I take the implied constants in {|A \\cap V| \\ll |A^{O(1)}|^{\\dim(V)/\\dim(G)}} depend only on the dimension and the degree of V and G?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42735")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("PS. If G were not required to be simple, then, as I am sure you are aware, you could just take G = a Borel subgroup of what have you and U = the unipotent subgroup of B, and the inequality would not be true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42739")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Terry,")

#text("The link to Larsen and Pink’s paper is broken. This one worked for me:")

#link("http://www.math.ethz.ch/~pink/ftp/LP5.pdf")[#text("Click to access LP5.pdf")]

#text("It doesn’t appear that this was ever published.")

#emph[#text("[Thanks! – T.]")]

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42740")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Terry,")

#text("Actually, which bit of Larsen and Pink is this implicit in?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42741")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Harald: Section 4.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("And also Section 5 of Hrushovski (in particular, Proposition 5.5 is the model-theoretic analogue of the dimension inequality mentioned here). It takes a certain amount of liberal translating from one language to another to put Hrushovski’s argument (itself a liberal translation of Larsen-Pink) in combinatorial form, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42759")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("I asked Richard Pink last year why this paper with Larsen had not been published, and he said that it had been accepted modulo modifications quite a while ago, but they never actually came to finalize those changes. He said the (potential) difficulties had been in their definition and use of “sufficiently general” subgroups (section 2), since this is not the standard notion of “generic” objects in algebraic geometry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42763")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("Emmanuel,")

#text("That’s amusing. Though I don’t properly understand the definition of “sufficiently general” since I don’t speak the language of schemes, it’s sort-of clear roughly what it means, and for that reason I personally rather like it. Maybe they were writing for a future audience of non algebraic geometers.")

#text("Best")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622dfa16efb18b20705e905af01df89fb672f9d9e5eec085ee0071b46e16fc48-f8d3e9bd2cd05819752f3d5d8f49ea811f53f0ec1c3658aedc56dd64d4c6dfec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chaos")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42767")[#strong[#text("Chaos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("Hi i want to ask a question but maybe it is absurd:)")#linebreak()#text(" in any finite group can we calculate the number of elements which commute each other of course i mean different pair of elements i.e.")#linebreak()#text(" ab=ba ,where a is not equal to b")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622dfa16efb18b20705e905af01df89fb672f9d9e5eec085ee0071b46e16fc48-f8d3e9bd2cd05819752f3d5d8f49ea811f53f0ec1c3658aedc56dd64d4c6dfec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chaos")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42768")[#strong[#text("Chaos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("in fact i should change my question: of all finite groups with n elements,")#linebreak()#text(" suppose we have calculated commuting elements as above question,is there a maximum number of these elements?that is in all these groups,does one of them have a maximum number with the property that distinct elements commute each other?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622dfa16efb18b20705e905af01df89fb672f9d9e5eec085ee0071b46e16fc48-f8d3e9bd2cd05819752f3d5d8f49ea811f53f0ec1c3658aedc56dd64d4c6dfec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chaos")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42773")[#strong[#text("Chaos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2009")])]

#text("groups mentioned above are of course not abelian")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42779")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2009")])]

#text("Dear Chaos,")

#text("I believe that in a non-abelian group at most 5/8 of the pairs of elements can commute. This is a fun exercise in undergraduate group theory.")

#text("After that there is a jump to the next smallest possible proportion, and then a discrete series which accumulates somewhere; maybe 1/2, though I forget.")

#text("There is a fun article on this in an old edition (circa 1970) of “Eureka”, the magazine of the Cambridge Student maths society. As I’m in Princeton right now, I can’t supply the reference – maybe someone else can?")

#text("Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42781")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("This maximum of 5/8 is attained for both the quaternion group ")#mi("H_8")#text(" and dihedral group ")#mi("D_4")#text(", two groups of order 8.")

#text("The general issue of evaluating the probability ")#mi("Pr(G)")#text(" that two elements of a nonabelian finite group ")#mi("G")#text(" commute is discussed in great detail in a 1979 paper in ")#emph[#text("Pacific J. Math.")]#text(" by Rusin which is freely available ")#link("http://projecteuclid.org/DPubS?verb=Display&version=1.0&service=UI&handle=euclid.pjm/1102785075&page=record")[#text("here")]#text(". (Unfortunately, I couldn’t find a reference online for the “Eureka” magazine you mentionned.)")

#text("It appears that there’s indeed an infinite series starting at 5/8 and accumulating at 1/2. The paper mentions several open problems regarding the possible density of ")#mi("Pr(G)")#text(" in intervals [a,b] with ")#mi("b\\leq 1/4")#text(", which seem still open (at least a quick glance at google scholar suggests so).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("Thomas")

#text("The article is by Nigel Boston and it is in volume 43 of Eureka, published in Cambridge in 1983. The title is “nearly abelian groups”. It may well be an exposition of the paper of Rusin you mention above.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9433218afd2a296d68e0a0ddcdca747fbff8a9486aeb84a5385620ce1bed8aaa-0d07f89db3f93ee85a8ef57476bf078eaac9b6956ea72a7e1c233e98a422219a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laci Pyber")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42795")[#strong[#text("Laci Pyber")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2009")])]

#text("Some time ago in joint work with Endre Szabo´ we obtained a version of the “escape from subvarieties” inequality discussed above for finite subsets A of algebraic groups G. Our result holds under the condition that the symmetric set A generates G(F_q), G(F_q) does not normalise any closed subgroup H < G with 0 < dim(H) < dim(G) and the centraliser of G(F_q) in G is finite.")#linebreak()#text(" For more details see ")#link("http://www.renyi.hu/~endre/growth.pdf")[#linebreak()#text(" ")]#link("http://www.renyi.hu/~endre/growth.pdf")[#text("http://www.renyi.hu/~endre/growth.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chaos")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-42912")[#strong[#text("Chaos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Thanks for your helps dear professor green and thomas sauvaget:) i’m surprising now because you answered my question one day later but i looked at this page in 11.12.2009 and i couldnt see anything about my question..maybe it is concerned with density of this site..anyway again and again thanks…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-43011")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("“in some statistical set” should probably be “in some statistical sense”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Linear approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-43384")[#strong[#text("Linear approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("[…] The expectation is that -approximate groups are -controlled by “structured” objects, such as actual groups and progressions, though the precise formulation of this has not yet been finalised. (We say that one finite set -controls another if is at most times larger than in cardinality, and can be covered by at most left translates or right translates of .) The task of stating and proving this statement is the noncommutative Freiman theorem problem, discussed in these earlier blog posts. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate subgroups of linear subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-44812")[#strong[#text("Approximate subgroups of linear subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2010")])]

#text("[…] groups can concentrate in a (bounded complexity) subvariety; this is discussed at the end of this blog post. Possibly related posts: (automatically generated)Review: Predicting Conversion to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-49610")[#strong[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("[…] of a “noncommutative Freiman” type theorem in linear groups . As discussed in earlier blog posts, a general question in additive (or multiplicative) combinatorics is to understand the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/#comment-49771")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed previously). It is also analogous in many ways to the more well-known Furstenberg correspondence principle […]")
]
