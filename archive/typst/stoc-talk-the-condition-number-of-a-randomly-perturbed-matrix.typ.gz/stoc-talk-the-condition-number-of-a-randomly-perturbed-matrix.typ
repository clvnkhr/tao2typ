// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/12/stoc-talk-the-condition-number-of-a-randomly-perturbed-matrix/
// Converted to Typst by tao2typ: "2026-10-14T16:34:57.515565+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "STOC talk: The condition number of a randomly perturbed matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("STOC talk: The condition number of a randomly perturbed matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/12/stoc-talk-the-condition-number-of-a-randomly-perturbed-matrix/")[#text("https://terrytao.wordpress.com/2007/06/12/stoc-talk-the-condition-number-of-a-randomly-perturbed-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am in San Diego for the ")#link("http://www.research.att.com/%7Edsj/stoc07.html")[#text("39th ACM Symposium for the Theory of Computing")]#text(" (STOC). Today I presented my work with ")#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" on the condition number of randomly perturbed matrices, which was the subject of an ")#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/")[#text("earlier post on this blog")]#text(". For this short talk (20 minutes), Van and I prepared ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/conditionSTOC07-1.pdf")[#text("some slides")]#text("; of course, in such a short time frame one cannot hope to discuss many of the details of the result, but one can at least convey the statement of the result and a brief sketch of the main ideas in the proof.")

#text("One late update (which didn’t make it onto ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/conditionSTOC07-1.pdf")[#text("the slides")]#text("): last week, an alternate proof of some cases of our main result (together with some further generalisations and other results, in particular a circular law for the eigenvalues of discrete random matrices) was obtained ")#link("http://arxiv.org/abs/0705.3773")[#text("by Pan and Zhou")]#text(", using earlier arguments ")#link("http://arxiv.org/abs/math/0703503")[#text("by Rudelson and Vershynin")]#text(".")

#text("[")#emph[#text("Update")]#text(", June 16: It was pointed out to me that the Pan-Zhou result only recovers our result in the case when the unperturbed matrix has a spectral norm of ")#mi("O(n^{1/2})")#text(" (our result assumes that the unperturbed matrix has polynomial size). Slides also updated.]")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lieven")]], [#link("https://terrytao.wordpress.com/2007/06/12/stoc-talk-the-condition-number-of-a-randomly-perturbed-matrix/#comment-2138")[#strong[#text("Lieven")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2007")])]

#text("Shouldn’t it be Kappa(M):=infinity if M is singular instead of non-singular on the first slide?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/12/stoc-talk-the-condition-number-of-a-randomly-perturbed-matrix/#comment-2301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2007")])]

#text("Thanks for the correction!")
]
