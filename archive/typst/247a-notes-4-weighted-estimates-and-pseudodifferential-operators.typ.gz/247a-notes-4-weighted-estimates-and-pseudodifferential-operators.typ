// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/12/247a-notes-4-weighted-estimates-and-pseudodifferential-operators/
// Converted to Typst by tao2typ: "2026-11-13T14:47:43.049082+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247A, Notes 4: Weighted estimates and pseudodifferential operators", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247A, Notes 4: Weighted estimates and pseudodifferential operators")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/12/247a-notes-4-weighted-estimates-and-pseudodifferential-operators/")[#text("https://terrytao.wordpress.com/2026/11/12/247a-notes-4-weighted-estimates-and-pseudodifferential-operators/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#heading(level: 1)[#strong[#text(" — 1. Weighted inequalities — ")]]

#text("In the previous notes we have taken a linear or sublinear operator ")#mi("{T}")#text(" on a measure space ")#mi("{X}")#text(" and established ")#mi("{L^p}")#text(" mapping properties, such as")

#align(center)[#tao-fit-display[#tao-math("\\int_{Y} \\left|Tf(y)\\right|^p\\ d\\mu_Y(y) \\lesssim \\int_{X} \\left|f(x)\\right|^p\\ d\\mu_X(x).", block: true)]]

#text("These estimates reveal information about how the height and width of ")#mi("{Tf}")#text(" is controlled by the height and width of ")#mi("{f}")#text(". However, these estimates do not indicate ")#emph[#text("where")]#text(" the support of ")#mi("{Tf}")#text(" is located, due to the rearrangement-invariant nature of the ")#mi("{L^p}")#text(" norms. One way to establish this type of control is to start establishing ")#emph[#text("weighted")]#text(" ")#mi("{L^p}")#text(" estimates, such as")

#metadata(none) <tao-27301716ef81140f720a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_{Y} \\left|Tf(y)\\right|^p w_2(y)\\ d\\mu(y) \\lesssim \\int_{X} \\left|f(x)\\right|^p w_1(x)\\ d\\mu_X(x).", block: true)]]

#text("for various pairs of ")#emph[#text("weight functions")]#text(" ")#mi("{w_1: X \\rightarrow {\\bf R}^+}")#text(" and ")#mi("{w_2: Y \\rightarrow {\\bf R}^+}")#text(". Roughly speaking, these weighted estimates are a variant of the usual ")#mi("{L^p}")#text(" estimates which assert that if ")#mi("{f}")#text(" avoids the regions where ")#mi("{w_1}")#text(" is large, then ")#mi("{Tf}")#text(" avoids the regions where ")#mi("{w_2}")#text(" is large. If ")#mi("{X=Y}")#text(" and one can establish the above type of estimate for many pairs ")#mi("{w_1, w_2}")#text(", with ")#mi("{w_1}")#text(" “looking similar to” ")#mi("{w_2}")#text(", then these estimates begin to confirm an assertion that ")#mi("{T}")#text(" does not significantly change the support of ")#mi("{f}")#text(".")

#text("One can view the estimate ")#link(<tao-27301716ef81140f720a>)[#text("(1)")]#text(" as an assertion that ")#mi("{w_1}")#text(" is at least as large as some sort of “nonlinear adjoint” of ")#mi("{T}")#text(" applied to ")#mi("{w_2}")#text(". For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{T=T_K}")#text(" be an integral operator with bounded non-negative kernel ")#mi("{K:X \\times Y \\rightarrow {\\bf R}^+}")#text(", and let ")#mi("{w_1, w_2}")#text(" be bounded weights. Show that the inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{Y} |Tf(y)| w_2(y)\\ d\\mu_Y(y) \\lesssim \\int_{X} |f(x)| w_1(x)\\ d\\mu_X(x)")]]

#text("holds for all simple functions ")#mi("{f}")#text(" with finite measure support if and only if one has the pointwise estimate ")#mi("{w_1 \\geq T^* w_2}")#text(".")
]

#text("We know that boundedness properties of an adjoint can be used to establish boundedness properties of the original operator. There is a counterpart for weighted estimates:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Equivalence of weight bounds and vector-valued ")#mi("{L^p}")#text(" estimates)")]#text(" ")#metadata(none) <tao-785fda86872f7ba2ab7c>#text(" Let ")#mi("{1 \\leq p < q < \\infty}")#text(", let ")#mi("{A > 0}")#text(", let ")#mi("{T: L^p(X) \\rightarrow L^p(Y)}")#text(" be an arbitrary operator (possibly nonlinear!), and let ")#mi("{r}")#text(" be such that ")#mi("{r^{\\prime} = q/p}")#text(". Then the following are equivalent:")

#list(
[#text("(i) For any sequence ")#mi("{(f_n)_{n \\in {\\bf Z}}}")#text(" in ")#mi("{L^p(X)}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_n \\left|Tf_n\\right|^p)^{1/p} \\right\\|_{L^q(Y)} \\leq A \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^q(X)}.", block: true)]]

#text("In particular (setting all but one of the ")#mi("{f_n}")#text(" equal to zero),")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^q(Y)} \\leq A \\left\\| f \\right\\|_{L^q(X)}.", block: true)]]],
[#text("(ii) For every non-negative ")#mi("{w_2 \\in L^r(Y)}")#text(" there exists a non-negative ")#mi("{w_1 \\in L^r(X)}")#text(" with ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\leq \\left\\|w_2\\right\\|_{L^r(Y)}}", block: false)#text(" such that")

#metadata(none) <tao-ec6aded56b9556c0fac4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\int_Y \\left|Tf(y)\\right|^p w_2(y)\\ d\\mu_Y(y) \\leq A^p \\int_X \\left|f(x)\\right|^p w_1(x)\\ d\\mu_X(x)", block: true)]]

#text("for all ")#mi("{f \\in L^p(X)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" By dividing ")#mi("{T}")#text(" by ")#mi("{A}")#text(" we may normalise ")#mi("{A=1}")#text(". We first show that (ii) implies (i). From the converse Hölder inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (\\sum_n \\left|Tf_n\\right|^p)^{1/p} \\right\\|_{L^q(Y)}^p  & := \\sup \\{ \\int_Y \\sum_n \\left|Tf_n(y)\\right|^p w_2(y)\\ d\\mu_Y(y):", block: true)



#tao-math("\\left\\| w_2 \\right\\|_{L^r(Y)}  & = 1, w_2 \\geq 0 \\}.", block: true)
]

#text("By monotone convergence we may interchange the sum and integral. From ")#link(<tao-ec6aded56b9556c0fac4>)[#text("(2)")]#text(" and Hölder inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\int_Y \\left|Tf_n(y)\\right|^p w_2(y)\\ d\\mu_Y(y)  & \\leq \\sum_n \\int_Y \\left|f_n(y)\\right|^p w_1(y)\\ d\\mu_Y(y)", block: true)



#tao-math(" & \\leq \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^q(X)}^p \\left\\|w_1\\right\\|_{L^r(X)}", block: true)
]

#text("where ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\leq \\left\\|w_2\\right\\|_{L^r(Y)} = 1}", block: false)#text(". The claim follows.")

#text("Now we establish that (i) implies (ii). Fix ")#mi("{w_2}")#text("; we may normalise ")#tao-math("{\\left\\|w_2\\right\\|_{L^r(Y)} = 1}", block: false)#text(". We need to find a ")#mi("{w_1}")#text(" obeying ")#link(<tao-ec6aded56b9556c0fac4>)[#text("(2)")]#text(". From the above arguments we know that a necessary condition for ")#mi("{w_1}")#text(" is that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\int_Y \\left|Tf_n(y)\\right|^p w_2(y)\\ d\\mu_Y(y) \\leq \\int_Y |F(y)| w_1(y)\\ d\\mu_Y(y)", block: true)]]

#text("for all ")#mi("{f_n}")#text(" and ")#mi("{F}")#text(" such that ")#tao-math("{\\sum_n \\left|f_n\\right|^p \\leq \\left|F\\right|}", block: false)#text(". Motivated by this, given any ")#mi("{F \\in L^{r^{\\prime}}(Y)}")#text(", we consider the “capacity”")

#align(center)[#tao-fit-display[#tao-math("\\lambda(F) := \\sup \\{ \\sum_n \\int_Y \\left|Tf_n(y)\\right|^p w_2(y)\\ d\\mu_Y(y): \\sum_n \\left|f_n\\right|^p \\leq \\left|F\\right| \\},", block: true)]]

#text("where ")#mi("{(f_n)_{n \\in {\\bf Z}}}")#text(" ranges over all sequences ")#mi("{L^p(X)}")#text(" with ")#tao-math("{\\sum_n \\left|f_n\\right|^p}", block: false)#text(" bounded pointwise by ")#mi("{F}")#text(". It will suffice to locate ")#mi("{w_1 \\in L^r(X)}")#text(" with ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\leq 1}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\lambda(F) \\leq \\int_X |F| w_1\\ d\\mu_X")]]

#text("for all ")#mi("{F \\in L^{r^{\\prime}}(X)}")#text(", since we may then substitute ")#tao-math("{F = \\left|f\\right|^p}", block: false)#text(" and observe that ")#tao-math("{\\lambda(\\left|f\\right|^p) \\geq \\int_Y \\left|f\\right|^p w_2\\ d\\mu_Y}", block: false)#text(".")

#text("Observe from Hölder that")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl}  \\sum_n \\int_Y \\left|Tf_n(y)\\right|^p w_2(y)\\ d\\mu_Y(y) &\\leq \\left\\| (\\sum_n \\left|Tf_n\\right|^p)^{1/p} \\right\\|_{L^q(Y)}^p \\left\\|w_2\\right\\|_{L^r(Y)} \\\\ &\\leq \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^q(X)}^p \\\\ &\\leq \\left\\| F \\right\\|_{L^{r^{\\prime}}(X)} \\end{array}", block: true)]]

#text("and so we have the boundedness")

#align(center)[#tao-fit-display[#tao-math("\\lambda(F) \\leq \\left\\| F \\right\\|_{L^{r^{\\prime}}(X)}.", block: true)]]

#text("We also easily verify the superlinearity properties")

#align(center)[#tao-fit-display[#tao-math("\\lambda(cF) = \\left|c\\right| \\lambda(F);\\quad \\lambda(F+G) \\geq \\lambda(F)+\\lambda(G)", block: true)]]

#text("for all non-negative ")#mi("{F,G \\in L^{r^{\\prime}}(X)}")#text(". Observe that the sets")

#align(center)[#tao-fit-display[#tao-math("A := \\{ F \\in L^{r^{\\prime}}(X): \\left\\| F\\right\\|_{L^{r^{\\prime}}(X)} < 1 \\}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B := \\{ F \\in L^{r^{\\prime}}(X): F > 0; \\lambda(F) > 1 \\}")]]

#text("are algebraically open (see appendix), convex, and disjoint. Thus by the geometric Hahn-Banach theorem (see appendix), we can find a linear functional ")#mi("{\\nu: L^{r^{\\prime}}(X) \\rightarrow {\\bf C}}")#text(" such that ")#mi("{\\nu < 1}")#text(" on ")#mi("{A}")#text(" and ")#mi("{\\nu > 1}")#text(" on ")#mi("{B}")#text(". (This is a typical use of the Hahn-Banach theorem: philosophically, this theorem asserts that in linear or convex programming, any possibility which is not obviously excluded by the constraints is in fact permissible. Here, it is the vector-valued inequality in (i) which shows that all the “obvious” obstructions to the estimate (ii) do not exist, and Hahn-Banach tells one that there are no non-obvious obstructions.) The former implies that ")#mi("{\\nu}")#text(" is a continuous linear functional with norm at most ")#mi("{1}")#text(" and thus ")#mi("{\\nu(F) = \\int_X F w_1\\ d\\mu_X}")#text(" for some ")#mi("{w_1 \\in L^r(X)}")#text(" with ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\leq 1}", block: false)#text(". The latter implies that ")#mi("{\\nu(F) \\geq \\lambda(F)}")#text(" for all non-negative ")#mi("{F}")#text(", and in particular (setting ")#tao-math("{F := \\left|f\\right|^p}", block: false)#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\int_Y \\left|Tf\\right|^p w_2\\ d\\mu_Y \\leq \\lambda(\\left|f\\right|^p) \\leq \\nu(\\left|f\\right|^p) = \\int_X \\left|f\\right|^p w_1\\ d\\mu_X", block: true)]]

#text("as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" By combining this with Exercise 51 from ")#link("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/")[#text("last week’s notes")]#text(", we obtain a remarkable fact: if ")#mi("{T: L^2(X) \\rightarrow L^2(Y)}")#text(" is a linear operator, then there is a unique continuous linear extension from ")#mi("{L^q(X)}")#text(" to ")#mi("{L^q(Y)}")#text(" for ")#mi("{q > 2}")#text(" if and only if for every ")#mi("{w_2 \\in L^r(Y)}")#text(" there exists ")#mi("{w_1 \\in L^r(X)}")#text(" with ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\lesssim_T \\left\\| w_2\\right\\|_{L^r(Y)}}", block: false)#text(" for which one has the weighted estimate ")#link(<tao-27301716ef81140f720a>)[#text("(1)")]#text(", where ")#mi("{r := (q/2)^{\\prime}}")#text(". Thus in the case of linear operators there is an equivalence between higher unweighted ")#mi("{L^p}")#text(" estimates and weighted ")#mi("{L^2}")#text(" estimates.")
]

#text("We thus see that weighted estimates can be quite powerful; they not only imply unweighted estimates, but also vector-valued versions of those estimates. Indeed, more is true: if we have a sequence of operators ")#mi("{T_n}")#text(" which obey weighted estimates with the ")#emph[#text("same")]#text(" set of weights, then we automatically obtain vector-valued estimates which involve all the ")#mi("{T_n}")#text(" at once. For instance, if ")#mi("{p,q,r}")#text(" are as in the above proposition, and for each ")#mi("{w_2 \\in L^r(Y)}")#text(" there was a ")#mi("{w_1 \\in L^r(X)}")#text(" (")#emph[#text("independent")]#text(" of ")#mi("{n}")#text(") with ")#tao-math("{\\left\\|w_1\\right\\|_{L^r(X)} \\lesssim \\left\\|w_2\\right\\|_{L^r(Y)}}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\int_Y \\left|T_nf(y)\\right|^p w_2(y)\\ d\\mu_Y(y) \\leq \\int_X \\left|f(x)\\right|^p w_1(x)\\ d\\mu_X(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", then we can conclude the vector-valued estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_n \\left|T_n f_n\\right|^p)^{1/p} \\right\\|_{L^q(Y)} \\leq A \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^q(X)}.", block: true)]]

#text("It is thus of interest to obtain weighted estimates, preferably those in which the final weight ")#mi("{w_2}")#text(" is given explicitly in terms of ")#mi("{w_1}")#text(". A particularly pleasant situation occurs when ")#mi("{X=Y}")#text(" and the weights ")#mi("{w_1, w_2}")#text(" are in fact ")#emph[#text("equal")]#text(", although having estimates with asymmetric weights can still be very useful.")

#text("One particularly common (and useful) class of weights are ")#emph[#text("power weights")]#text(" such as ")#mi("{w(x) = \\langle x \\rangle^\\alpha}")#text(" or ")#tao-math("{w(x) = \\left|x\\right|^\\alpha}", block: false)#text(" for Euclidean spaces ")#mi("{{\\bf R}^d}")#text(", especially in PDE applications where such weights tend to appear quite naturally (for instance, via the introduction of Sobolev spaces). However, we will work here with more abstract weights. Here it turns out that one can often mimic the proof of an unweighted estimate to deduce the weighted counterpart.")

#metadata(none) <tao-e9c71f47feb1315619d5>

#heading(level: 1)[#strong[#text(" — 1.1. Weighted estimates for the Hardy-Littlewood maximal function — ")]]

#text("To illustrate weighted estimates, let us establish a basic estimate for the maximal function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Weighted Hardy-Littlewood maximal inequality)")]#text(" ")#metadata(none) <tao-1b698419083714e355a3>#text(" Let ")#mi("{w: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(". Then we have the weak-type estimate")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} 1_{\\left|Mf(x)\\right| > \\lambda}\\ w(x)\\ dx \\lesssim_d \\frac{1}{\\lambda} \\int_{{\\bf R}^d} |f(x)| Mw(x)\\ dx", block: true)]]

#text("for all locally integrable ")#mi("{f}")#text(" and all ")#mi("{\\lambda > 0}")#text(", and the ")#mi("{L^p}")#text(" estimate")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|Mf(x)\\right|^p\\ w(x)\\ dx \\lesssim_{d,p} \\int_{{\\bf R}^d} \\left|f(x)\\right|^p Mw(x)\\ dx", block: true)]]

#text("for all locally integrable ")#mi("{f}")#text(" and ")#mi("{1 < p < \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" By monotone convergence we may assume that both ")#mi("{w}")#text(" and ")#mi("{f}")#text(" are bounded with compact support. The Stein-Weiss interpolation theorem (and the boundedness of ")#mi("{M}")#text(" on ")#mi("{L^\\infty}")#text(" no matter what the weights are) ensure that it suffices to prove the weak-type ")#mi("{(1,1)}")#text(" estimate. For this we mimic the proof of the unweighted estimate. We normalise ")#mi("{\\lambda = 1}")#text(", and let ")#mi("{K}")#text(" be any compact set inside ")#tao-math("{\\{ \\left|Mf(x)\\right| > 1 \\}}", block: false)#text("; it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_K w(x)\\ dx \\lesssim_d \\int_{{\\bf R}^d} |f(x)| Mw(x)\\ dx.")]]

#text("The usual Vitali covering lemma argument lets us locate a finite number of disjoint open balls ")#mi("{B_1,\\ldots,B_N}")#text(" such that ")#mi("{\\bigcup_{n=1}^N 3B_n}")#text(" covers ")#mi("{K}")#text(", and such that ")#tao-math("{-\\!\\!\\!\\!\\int_{B_n} \\left|f(x)\\right| \\gtrsim_d 1}", block: false)#text(" for each ball ")#mi("{B_n}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\int_K w(x)\\ dx \\leq \\sum_{n=1}^N \\int_{3B_n} w(x)\\ dx")]]

#text("it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{3B_n} w(x)\\ dx \\lesssim_d \\int_{B_n} |f(x)| Mw(x)\\ dx")]]

#text("for each ball ")#mi("{B_n}")#text(". But we observe that")

#align(center)[#tao-fit-display[#tao-math("Mw(x) \\gtrsim_d \\frac{1}{\\left|B_n\\right|} \\int_{3B_n} w(y)\\ dy", block: true)]]

#text("for all ")#mi("{x \\in B_n}")#text(", and the claim follows. ")#mi("\\Box")

#text("As a corollary we obtain the following useful vector-valued generalisation of the Hardy-Littlewood maximal inequality.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Fefferman-Stein vector-valued maximal inequality)")]#text(" If ")#mi("{1 < p,q < \\infty}")#text(" and ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" are any sequence of locally integrable functions then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_n \\left|Mf_n\\right|^p)^{1/p} \\right\\|_{L^q({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^q({\\bf R}^d)}", block: true)]]

#text("and the weak-type estimate")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ (\\sum_n \\left|Mf_n\\right|^p)^{1/p} \\geq \\lambda \\} \\right| \\lesssim_{d,p} \\frac{1}{\\lambda} \\left\\| (\\sum_n \\left|f_n\\right|^p)^{1/p} \\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for all locally integrable ")#mi("{f_n}")#text(".")
]

#emph[#text("Proof:")]#text(" By the usual monotone convergence arguments we may restrict only finitely many of the ")#mi("{f_n}")#text(" to be non-zero, and to have all ")#mi("{f_n}")#text(" bounded and finite measure support. We can then restrict the supremum in the maximal function ")#mi("{M}")#text(" to only be over finitely many radii.")

#text("When ")#mi("{p=q}")#text(" the first claim follows from interchanging the norms and using the usual Hardy-Littlewood maximal inequality. For ")#mi("{q>p}")#text(" the claim follows by combining Proposition ")#link(<tao-1b698419083714e355a3>)[#text("4")]#text(", Proposition ")#link(<tao-785fda86872f7ba2ab7c>)[#text("2")]#text(", and the fact that ")#mi("{M}")#text(" is bounded on ")#mi("{L^r({\\bf R}^d)}")#text(". For ")#mi("{q < p}")#text(", it suffices by vector-valued real interpolation to prove the weak-type ")#mi("{(1,1)}")#text(" estimate. We may take each ")#mi("{f_n}")#text(" to be non-negative. By linearisation we can replace ")#mi("{Mf_n(x)}")#text(" by ")#mi("{-\\!\\!\\!\\!\\int_{B(x,r_n(x))} f_n}")#text(" for some measurable radius function ")#mi("{r_n(x)}")#text(" (note that we must permit ")#mi("{r_n}")#text(" to depend on ")#mi("{n}")#text("), which is one reason why this weak-type estimate does not immediately follow from the Hardy-Littlewood inequality). Actually it is more convenient to replace this “rough” average by a smoother average")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B(x,r_n(x))\\right|} \\int_{{\\bf R}^d} \\psi_{n,x}(y) f_n(y)\\ dy", block: true)]]

#text("where ")#mi("{\\psi_{n,x}}")#text(" is a bump function adapted to ")#mi("{B(x,2r_n(x))}")#text(" which equals one on ")#mi("{B(x,r_n(x))}")#text(". This reduces matters to establishing a vector-valued weak-type ")#mi("{(1,1)}")#text(" operator for the linear operator")

#align(center)[#tao-fit-display[#tao-math("T: (f_n)_{n \\in {\\bf Z}} (x) \\mapsto (\\int_{{\\bf R}^d} \\frac{1}{\\left|B(x,r_n(x))\\right|} \\psi_{n,x}(y) f_n(y) )_{n \\in {\\bf Z}}.", block: true)]]

#text("This is an integral operator whose kernel ")#mi("{K(x,y)}")#text(" is a diagonal matrix whose ")#mi("{n^{th}}")#text(" diagonal entry is ")#tao-math("{\\frac{1}{\\left|B(x,r_n(x))\\right|} \\psi_{n,x}(y)}", block: false)#text(". We observe that this kernel is a ")#emph[#text("one-sided")]#text(" vector-valued singular kernel; it obeys the required regularity in the ")#mi("{y}")#text(" variable but not the ")#mi("{x}")#text(". However, this is still enough to convert the ")#mi("{L^p}")#text(" boundedness of ")#mi("{T}")#text(" (which as observed before, follows from switching norms and using the usual Hardy-Littlewood maximal inequality) and then using the standard Calderón-Zygmund argument. ")#mi("\\Box")

#text("The theory of weighted estimates (and ")#link("https://en.wikipedia.org/wiki/Muckenhoupt_weights")[#text("the ")#mi("{A_p}")#text(" weight class")]#text(") has been further developed intensively, but we will not cover it here; see Stein’s “Harmonic analysis” for a thorough exposition of the topic.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Hardy-Littlewood maximal inequality for ")#mi("{A_p}")#text(" weights)")]#text(" ")#metadata(none) <tao-32d833f348ce377c8cc3>#text(" Let ")#mi("{w: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" be strictly positive, and let ")#mi("{1 < p < \\infty}")#text(". Show that the following three statements are equivalent up to changes in the implied constant:")

#list(
[#text("(i) For every ball ")#mi("{B}")#text(", we have ")#mi("{(-\\!\\!\\!\\!\\int_B w) (-\\!\\!\\!\\!\\int_B w^{-p^{\\prime}/p})^{-p^{\\prime}/p} \\lesssim_{p,d} 1}")#text(".")],
[#text("(ii) For every ball ")#mi("{B}")#text(", we have ")#mi("{(-\\!\\!\\!\\!\\int_B w) (-\\!\\!\\!\\!\\int_B w^{-p^{\\prime}/p})^{-p^{\\prime}/p} \\sim_{p,d} 1}")#text(".")],
[#text("(iii) For every locally integrable function ")#mi("{f}")#text(" and ")#mi("{\\lambda > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} 1_{Mf(x) > \\lambda} w(x)\\ dx \\lesssim_{p,d} \\frac{\\int_{{\\bf R}^d} \\left|f(x)\\right|^p w(x)\\ dx}{\\lambda^p}.", block: true)]]]
)

#text("(Note: Weights ")#mi("{w}")#text(" with the above properties are known as ")#emph[#mi("{A_p}")#text(" weights")]#text(". Somewhat counter-intuitively, the weighted weak-type ")#mi("{(p,p)}")#text(" estimate in (iii) is in fact equivalent to its strong-type counterpart, due to a certain “openness” property of ")#mi("{A_p}")#text(" weights, but this will not be shown here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Calderón-Zygmund theory for power weights)")]#text(" ")#metadata(none) <tao-8845886be6cbcf285d18>#text(" Let ")#mi("{T: L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}")#text(" be a CZO. Show that for any ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{-d < \\alpha < \\frac{dp^{\\prime}}{p}}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|Tf(x)\\right|^p \\langle x \\rangle^\\alpha \\lesssim_{d,p,\\alpha} \\int_{{\\bf R}^d} \\left|f(x)\\right|^p \\langle x \\rangle^\\alpha", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|Tf(x)\\right|^p \\left|x\\right|^\\alpha \\lesssim_{d,p,\\alpha} \\int_{{\\bf R}^d} \\left|f(x)\\right|^p \\left|x\\right|^\\alpha", block: true)]]

#text("for all bounded, compactly supported ")#mi("{f}")#text(". (Note that the former can be obtained from the latter by a scaling argument.) Hint: use duality to reduce matters to establishing a bilinear weighted estimate for ")#mi("{\\int_{{\\bf R}^d} Tf(x) \\overline{g(x)}\\ dx}")#text(", and then decompose ")#mi("{f}")#text(" and ")#mi("{g}")#text(" into dyadic pieces. For the “diagonal” interactions use the fact that ")#mi("{T}")#text(" is bounded on ")#mi("{L^p}")#text(", while for the off-diagonal interactions use some form of Schur’s test.")

#text("(Note: the above theory works when ")#mi("{\\langle x \\rangle^\\alpha}")#text(" or ")#tao-math("{\\left|x\\right|^\\alpha}", block: false)#text(" is replaced with a general ")#mi("{A_p}")#text(" weight, but this is harder to prove.)")
]

#heading(level: 1)[#strong[#text(" — 2. Pseudodifferential operators — ")]]

#text("In the previous set of notes we established constructed a reasonably large class of CZOs, namely the ")#link("https://en.wikipedia.org/wiki/Multiplier_(Fourier_analysis)#Mikhlin_multiplier_theorem")[#text("Hörmander-Mikhlin multipliers")]#text(". These multipliers suffice for the analysis of ")#emph[#text("translation-invariant")]#text(" settings, such as studying operators arising from constant-coefficient differential operators such as the Laplacian. However they are not general enough to handle non-translation-invariant situations. For this, we must turn to the ")#link("https://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(", which generalise the variable-coefficient differential operators ")#mi("{\\sum_\\alpha c_\\alpha(x) \\partial_x^\\alpha}")#text(" when the coefficients ")#mi("{c_\\alpha(x)}")#text(" are smooth.")

#text("To motivate these operators, we begin with the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi} \\hat f(\\xi)\\ d\\xi")]]

#text("(for ")#mi("{f}")#text(" Schwartz, say) and apply a monomial differential operator ")#mi("{\\partial_x^\\alpha = \\partial_{x_1}^{\\alpha_1} \\ldots \\partial_{x_d}^{\\alpha_d}}")#text(" for some multiindex ")#mi("{\\alpha = (\\alpha_1,\\ldots,\\alpha_d)}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_x^\\alpha f(x) = \\int_{{\\bf R}^d} (2\\pi i x)^\\alpha e^{2\\pi i x \\cdot \\xi} \\hat f(\\xi)\\ d\\xi")]]

#text("where ")#mi("{x^\\alpha := x_1^{\\alpha_1} \\ldots x_d^{\\alpha_d}}")#text(". Thus we see that for any (smooth) coefficients ")#mi("{c_\\alpha(x)}")#text(", with only finitely many ")#mi("{c_\\alpha}")#text(" non-zero, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_\\alpha c_\\alpha(x) \\partial_x^\\alpha f(x) = \\int_{{\\bf R}^d} a(x,\\xi) e^{2\\pi i x \\cdot \\xi} \\hat f(\\xi)\\ d\\xi")]]

#text("where the ")#emph[#text("symbol")]#text(" ")#mi("{a(x,\\xi)}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("a(x,\\xi) := \\sum_\\alpha c_\\alpha(x) (2\\pi i \\xi)^\\alpha.")]]

#text("Inspired by this, we define for any smooth symbol ")#mi("{a: {\\bf R}^d \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" of at most polynomial growth, the operator ")#mi("{a(X,D)}")#text(" (sometimes also called ")#mi("{\\mathrm{Op}(a)}")#text(") on Schwartz functions ")#mi("{f \\in \\mathcal{S}({\\bf R}^d)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("a(X,D) f(x) := \\int_{{\\bf R}^d} a(x,\\xi) e^{2\\pi i x \\cdot \\xi} \\hat f(\\xi)\\ d\\xi.")]]

#text("This operator ")#mi("{a(X,D)}")#text(" is sometimes called the ")#emph[#text("Kohn-Nirenberg quantization")]#text(" of the symbol ")#mi("{a(x,\\xi)}")#text(". (In the theory of semiclassical analysis, it is often customary to introduce a small parameter ")#mi("{\\hbar}")#text(", called ")#emph[#text("Planck’s constant")]#text(", and replace ")#mi("{a(x,\\xi)}")#text(" in the above equation by ")#mi("{a(x,\\xi/\\hbar)}")#text(", but we will not do so here.) By expanding out the Fourier transform and interchanging integrals, we (formally) have")

#metadata(none) <tao-6e5cb8ddcabc1df6bc34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("a(X,D) f(x) = \\int_{{\\bf R}^d} [\\int_{{\\bf R}^d} a(x,\\xi) e^{2\\pi i (x-y) \\cdot \\xi}\\ d\\xi] f(y)\\ dy;")]]

#text("this formula is rigorous for instance if ")#mi("{a}")#text(" is not only smooth but also compactly supported. As such we see that there is a slight asymmetry between ")#mi("{x}")#text(" and ")#mi("{y}")#text(" in this formula; because of this one sometimes uses the ")#emph[#text("Weyl quantization")]

#align(center)[#tao-fit-display[#mitex("a^{\\mathrm{w}}(X,D) f(x) := \\int_{{\\bf R}^d} [\\int_{{\\bf R}^d} a(\\frac{x+y}{2},\\xi) e^{2\\pi i (x-y) \\cdot \\xi}\\ d\\xi] f(y)\\ dy")]]

#text("instead, though we will not use this quantization here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Formally, if we apply ")#mi("{a(X,D)}")#text(" to a plane wave ")#mi("{f(x) := e^{2\\pi i x \\cdot \\xi}}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("a(X,D) f(x) = a(x,\\xi) f(x).")]]

#text("Thus we can (in principle) reconstruct the symbol ")#mi("{a}")#text(" from the operator ")#mi("{a(X,D)}")#text(" by testing it against plane waves. This computation also shows that, ")#emph[#text("formally")]#text(", every linear operator is of the form ")#mi("{a(X,D)}")#text(" for some ")#mi("{a}")#text("; but in practice most operators will give horrible symbols ")#mi("{a}")#text(" which obey no useful estimates.")
]

#text("The operators ")#mi("{a(X,D)}")#text(" generalise both spatial multipliers ")#mi("{a(X): f(x) \\mapsto a(x) f(x)}")#text(" and Fourier multipliers ")#mi("{a(D)}")#text(", at least when the symbol is smooth. The map from symbol ")#mi("{a}")#text(" to operator ")#mi("{a(X,D)}")#text(" is linear. However, in contrast to the homomorphism laws")

#align(center)[#tao-fit-display[#mitex("a(X) b(X) = (ab)(X); \\quad a(D) b(D) = (ab)(D)")]]

#text("for smooth multipliers ")#mi("{a,b}")#text(" of space or frequency only, it is not quite true that the quantization operation preserves products:")

#align(center)[#tao-fit-display[#mitex("a(X,D) b(X,D) \\neq (ab)(X,D).")]]

#text("Indeed, this would imply in particular that any two operators ")#mi("{a(X,D)}")#text(" and ")#mi("{b(X,D)}")#text(" commute, which is untrue (indeed, ")#mi("{X}")#text(" and ")#mi("{D}")#text(" themselves do not commute with each other). Roughly speaking, the Kohn-Nirenberg quantization always arranges the ")#mi("{X}")#text(" factors to the “left” of the ")#mi("{D}")#text(" factors, whereas the Weyl quantization spreads them around evenly. One can obtain partial substitutes of the homomorphism law; for instance, it is still true that ")#mi("{a(X,D) b(X,D) = (ab)(X,D)}")#text(" if ")#mi("{a(x,\\xi)}")#text(" does not depend on ")#mi("{\\xi}")#text(", or ")#mi("{b(x,\\xi)}")#text(" does not depend on ")#mi("{x}")#text(". Later on we will see that for suitably smooth ")#mi("{a}")#text(" and ")#mi("{b}")#text(", that ")#mi("{a(X,D) b(X,D)}")#text(" is equal to ")#mi("{(ab)(X,D)}")#text(" modulo “lower order” terms. These types of observations form the foundation for the ")#emph[#text("pseudodifferential symbol calculus")]#text(", which is a very useful tool for analysing variable-coefficient linear differential operators (especially those with smooth elliptic symbols), although we will only touch on the foundations of that vast subject here.")

#text("There are two main aspects to the theory of pseudodifferential operators: the analytic aspects, in which the boundedness properties of operators ")#mi("{a(X,D)}")#text(" are analysed, and the (mainly) algebraic aspects, in which one learns how to compose, commute, or invert operators ")#mi("{a(X,D)}")#text(" (usually modulo lower order terms). We shall begin with the analytic aspects.")

#heading(level: 1)[#strong[#text(" — 2.1. Symbol classes — ")]]

#text("Of course, to get any sort of usable bound on the operators ")#mi("{a(X,D)}")#text(", we shall need some quantitative control on the symbol ")#mi("{a(x,\\xi)}")#text(". This requires placing ")#mi("{a}")#text(" in one of the ")#emph[#text("symbol classes")]#text(". There are quite a variety of symbol classes to use, which determine the growth and regularity of the symbol ")#mi("{a}")#text(" in both the spatial variable ")#mi("{x}")#text(" and the frequency variable ")#mi("{\\xi}")#text(". For simplicitly, we shall stick here with the ")#emph[#text("standard")]#text(" symbol class ")#mi("{S^k = S^k_{0,1}}")#text(", which suffices for the local theory of elliptic variable coefficient operators with smooth coefficients. (These are also called the ")#emph[#text("classical")]#text(" symbol classes, but this is confusing, given that the distinction between classical and quantum mechanics in this subject.) Each symbol class represents a decomposition of phase space into regions respecting the Heisenberg uncertainty principle, with the symbol required to be smoothly adapted to each such region and have a certain upper bound on amplitude. In this case, the relevant regions of phase space are the regions where the spatial variable ")#mi("{x}")#text(" is localised to a ball of radius ")#mi("{O(1)}")#text(", and the frequency variable ")#mi("{\\xi}")#text(" is localised to a dyadic annulus ")#tao-math("{\\left|\\xi\\right| \\sim 2^k}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Standard pseudodifferential operators)")]#text(" A smooth symbol ")#mi("{a: {\\bf R}^d \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a ")#emph[#text("(standard) symbol of order ")#mi("{k}")]#text(" for some ")#mi("{k \\in {\\bf R}}")#text(" if we have the estimates")

#metadata(none) <tao-8906bb0efdf319cfb033>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\partial_x^\\alpha \\partial_\\xi^\\beta a(x,\\xi)\\right| \\lesssim_{\\alpha,\\beta,d,k} \\langle \\xi \\rangle^{k-\\left|\\beta\\right|}", block: true)]]

#text("for all multi-indices ")#mi("{\\alpha,\\beta}")#text(" and ")#mi("{x,\\xi \\in {\\bf R}^d}")#text(" (in particular, ")#mi("{a=O(\\langle \\xi \\rangle^k)}")#text(" has at most polynomial growth), and we write ")#mi("{a \\in S^k = S^k_{0,1}}")#text(" in this case. We refer to the operator ")#mi("{a(X,D)}")#text(" as a ")#emph[#text("(standard) pseudo-differential operator")]#text(" (or ")#mi("{\\Psi}")#text("DO for short) of order ")#mi("{k}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" Again, this is a quasi-definition rather than a precise definition, due to the presence of implicit constants; in any conclusion involving these symbols, the implied constants in the conclusion will almost certainly depend on the constants in this definition. In practice, one does not need ")#link(<tao-8906bb0efdf319cfb033>)[#text("(4)")]#text(" for ")#emph[#text("all")]#text(" multi-indices ")#mi("{\\alpha,\\beta}")#text(", but only for finitely many (e.g. for all ")#mi("{\\alpha, \\beta}")#text(" with ")#tao-math("{\\left|\\alpha\\right|, \\left|\\beta\\right| \\leq 100d}", block: false)#text("), but for notational reasons we shall assume infinite regularity instead of finite. The indices ")#mi("{0,1}")#text(" in ")#mi("{S^k_{0,1}}")#text(" refer to the fact that each derivative in the ")#mi("{x}")#text(" variable reduces the growth in ")#mi("{x}")#text(" by ")#mi("{0}")#text(" orders, whereas each derivative in the ")#mi("{\\xi}")#text(" variable reduces the growth in ")#mi("{\\xi}")#text(" by ")#mi("{1}")#text(" order.")
]

#text("If ")#tao-math("{L := \\sum_{\\left|\\alpha\\right| \\leq k} c_\\alpha(x) \\partial_x^\\alpha}", block: false)#text(" is a variable-coefficient differential operator with the coefficients ")#mi("{c_\\alpha}")#text(" smooth, and obeying the bounds ")#mi("{\\partial_x^\\beta c_\\alpha(x) = O_{\\beta}(1)}")#text(" for all multi-indices ")#mi("{\\beta}")#text(", then ")#mi("{L}")#text(" is a pseudodifferential operator of order ")#mi("{k}")#text(". For any fixed ")#mi("{s \\in {\\bf C}}")#text(", a fractional differentiation operator ")#mi("{\\langle D \\rangle^s}")#text(" is a pseudodifferential operator of order ")#mi("{\\Re(s)}")#text(". A Littlewood-Paley operator ")#mi("{\\psi_j(D)}")#text(" is a pseudodifferential operator of order ")#mi("{0}")#text(" for any ")#mi("{j \\geq 0}")#text(" (but not as ")#mi("{j \\rightarrow -\\infty}")#text(" – why?), and if ")#mi("{j = O(1)}")#text(" then ")#mi("{\\psi_j(D)}")#text(" is a pseudodifferential operator of any fixed order.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" By copious application of Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(" one can show that pseudodifferential operators of any order map Schwartz functions to Schwartz functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12 (Classical multiplication of symbols)")]#text(" ")#metadata(none) <tao-e3c8f89e85ae15ffeb07>#text(" Numerous applications of the Leibnitz rule reveal that if ")#mi("{a, b}")#text(" are symbols of order ")#mi("{k,l}")#text(" respectively, then ")#mi("{ab}")#text(" is a symbol of order ")#mi("{k+l}")#text(". Also, observe that if ")#mi("{a}")#text(" is a symbol of order ")#mi("{k}")#text(", it is automatically a symbol of order ")#mi("{k^{\\prime}}")#text(" for any ")#mi("{k^{\\prime} \\geq k}")#text(". Also, ")#mi("{\\partial_x^\\alpha \\partial_\\xi^\\beta a}")#text(" will be a symbol of order ")#tao-math("{k-\\left|\\beta\\right|}", block: false)#text(".")
]

#text("The basic estimate here is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Calderón-Vaillancourt theorem)")]#text(" Every pseudodifferential operator of order ")#mi("{0}")#text(" is a CZO. In particular, it is bounded on ")#mi("{L^p({\\bf R}^d)}")#text(" with ")#mi("{1 < p < \\infty}")#text(" with norm ")#mi("{O_{p,d}(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" The theorem of Calderón and Vaillancourt is in fact more general, allowing other types of symbol classes than that presented here, but we will not attempt to describe the strongest version of the theorem in these notes.")
]

#emph[#text("Proof:")]#text(" We shall allow all implied constants to depend on ")#mi("{d}")#text(", and henceforth omit this dependence explicitly from our notation.")

#text("Let ")#mi("{a(x,\\xi)}")#text(" be a symbol of order ")#mi("{0}")#text(". We have to check two different things: firstly, that ")#mi("{a(X,D)}")#text(" is bounded on ")#mi("{L^2({\\bf R}^d)}")#text(" with operator norm ")#mi("{O(1)}")#text(", and secondly that ")#mi("{a(X,D)}")#text(" has a singular kernel.")

#text("Observe that if we smoothly truncate ")#mi("{a(x,\\xi)}")#text(" to be compactly supported in ")#mi("{\\xi}")#text(", by multiplying by some cutoff function ")#tao-math("{\\chi(\\left|\\xi\\right|/R)}", block: false)#text(" for some large ")#mi("{R \\gg 1}")#text(", that ")#mi("{a}")#text(" remains a symbol of order ")#mi("{0}")#text(" (this is a special case of Remark ")#link(<tao-e3c8f89e85ae15ffeb07>)[#text("12")]#text("). Because of this, and because of various limiting arguments (restricting all functions to the Schwartz class, of course), we will be able to restrict to the case where ")#mi("{a}")#text(" is compactly supported in ")#mi("{\\xi}")#text(", as long as our bounds do not depend on the size of this support.")

#text("Let us check the singular kernel property first. If ")#mi("{f, g}")#text(" are test functions with disjoint supports, we observe from Fubini’s theorem (and the compact support of ")#mi("{a}")#text(" in ")#mi("{\\xi}")#text(") that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} a(X,D) f(x) \\overline{g(x)}\\ dx = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} K(x,y) \\overline{g(x)} f(y)\\ dx dy")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K(x,y) := \\int_{{\\bf R}^d} a(x,\\xi) e^{2\\pi i (x-y) \\cdot \\xi}\\ d\\xi.")]]

#text("Now notice that for any fixed ")#mi("{x}")#text(", ")#mi("{a(x,\\xi)}")#text(" is a symbol of order ")#mi("{0}")#text(", so by Lemma ")#link(<tao-f35a2929e8cf4b8066ad>)[#text("37")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|K(x,y)\\right| \\lesssim \\left|x-y\\right|^{-d} \\text{ and } \\left|\\nabla_y K(x,y)\\right| \\lesssim_d \\left|x-y\\right|^{-d-1}.", block: true)]]

#text("However we have to do a little bit more work to get the ")#mi("{x}")#text(" derivative, due to the dependence of ")#mi("{a}")#text(" on ")#mi("{x}")#text(". Fortunately, ")#mi("{a}")#text(" is so smooth in ")#mi("{x}")#text(" that this is not an issue. Observe that")

#align(center)[#tao-fit-display[#mitex("(\\nabla_x + \\nabla_y) K(x,y) = \\int_{{\\bf R}^d} (\\nabla_x a)(x,\\xi) e^{2\\pi i (x-y) \\cdot \\xi}\\ d\\xi.")]]

#text("Now observe from the symbol estimates that for fixed ")#mi("{x}")#text(", ")#mi("{\\nabla_x a}")#text(" is still a symbol of order ")#mi("{0}")#text(", and so we have")

#align(center)[#tao-fit-display[#tao-math("\\left|(\\nabla_x + \\nabla_y) K(x,y)\\right| \\lesssim_N \\left|x-y\\right|^{-d} \\langle x-y \\rangle^{-N}", block: true)]]

#text("for any ")#mi("{N \\geq 0}")#text(", and the claim follows. Now we check the ")#mi("{L^2({\\bf R}^d)}")#text(" boundedness property, which is harder. We first take advantage of some additional spatial decay to localise in space. An inspection of Lemma ")#link(<tao-f35a2929e8cf4b8066ad>)[#text("37")]#text(" shows that we have the rapid decay")

#align(center)[#tao-fit-display[#tao-math("\\left|K(x,y)\\right| \\lesssim \\left|x-y\\right|^{-100d}", block: true)]]

#text("(say). To use this, we cover ")#mi("{{\\bf R}^d}")#text(" by finitely overlapping balls ")#mi("{B}")#text(" of unit radius, and write")

#tao-aligned(keep: true)[


#tao-math("\\left\\| a(X,D) f\\right\\|_{L^2({\\bf R}^d)}  & \\lesssim (\\sum_B \\left\\| 1_B a(X,D) f \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2}", block: true)



#tao-math(" & \\lesssim (\\sum_B \\left\\| 1_B a(X,D) (f1_{2B}) \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2} + (\\sum_B \\left\\| 1_B a(X,D) (f1_{2B^c}) \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2}.", block: true)
]

#text("The kernel bound gives the pointwise estimate")

#align(center)[#tao-fit-display[#mitex("1_B a(X,D) (f1_{2B^c}) \\lesssim f * \\langle x \\rangle^{-100d}")]]

#text("and so the second term is controlled by ")#tao-math("{\\left\\| f * \\langle x \\rangle^{-100d} \\right\\|_{L^2({\\bf R}^d)}}", block: false)#text(", which is acceptable by Young’s inequality. Thus it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_B \\left\\| 1_B a(X,D) (f1_{2B}) \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2} \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("But since")

#align(center)[#tao-fit-display[#tao-math("(\\sum_B \\left\\| f1_{2B} \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2} \\sim \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("we see that it will suffice to show that each ")#mi("{1_B a(X,D)}")#text(" is bounded on ")#mi("{L^2({\\bf R}^d)}")#text(" uniformly in ")#mi("{B}")#text(". We may translate ")#mi("{B}")#text(" to be ")#mi("{B(0,1)}")#text("; by applying a smooth cutoff we may then assume that the symbol ")#mi("{a(x,\\xi)}")#text(" is supported on the region ")#tao-math("{\\{ \\left|x\\right| \\leq 2\\}}", block: false)#text(". The ")#mi("{B}")#text(" localisation has served its purpose of localising ")#mi("{a}")#text(", and we now discard it.")

#text("By duality, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle a(X,D) f, g \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R}^d)} \\left\\|g\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("for any Schwartz ")#mi("{f}")#text(". Here we shall use the Littlewood-Paley decomposition ")#mi("{1 = \\sum_j \\psi_j(D)}")#text(". The intuition is that ")#mi("{a(X,D)}")#text(", as it resembles a Fourier multiplier, “almost commutes” with these projections ")#mi("{\\psi_j(D)}")#text(", and in particular ")#mi("{\\psi_j(D) a(X,D) \\psi_k(D)}")#text(" is expected to be very small when ")#mi("{j}")#text(" and ")#mi("{k}")#text(" are very different. This type of Fourier localisation phenomenon can be exploited by Littlewood-Paley decomposition. Specifically, we decompose")

#align(center)[#tao-fit-display[#mitex("a(X,D) = \\sum_{j,k \\ge 0} \\tilde \\psi_j(D) \\psi_j(D) a(X,D) \\psi_k(D) \\tilde \\psi_k(D)")]]

#text("where ")#mi("{\\tilde \\psi_j}")#text(" is a slightly wider variant of ")#mi("{\\psi_j}")#text(" such that ")#mi("{\\tilde \\psi_j \\psi_j = \\psi_j}")#text(", where we redefine ")#mi("{\\psi_0}")#text(" and ")#mi("{\\tilde \\psi_0}")#text(" to be one on the ball ")#tao-math("{\\left|\\xi\\right| \\lesssim 1}", block: false)#text(" rather than the annulus ")#tao-math("{\\left|\\xi\\right| \\sim 1}", block: false)#text(". Thus by the triangle inequality and Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle a(X,D) f, g \\rangle\\right| \\lesssim \\sum_{j,k \\ge 0} \\left\\| \\psi_j(D) a(X,D) \\psi_k(D)\\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde \\psi_k(D) f \\right\\|_{L^2({\\bf R}^d)} \\left\\| \\tilde \\psi_j(D)^* g \\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("But from the Littlewood-Paley inequality (or Plancherel) we have")

#align(center)[#tao-fit-display[#tao-math("(\\sum_k \\left\\| \\tilde \\psi_k(D) f \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2} \\sim \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("(\\sum_j \\left\\| \\tilde \\psi_j(D)^* g \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2} \\sim \\left\\|g\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("and so from Schur’s test it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\psi_j(D) a(X,D) \\psi_k(D)\\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} \\lesssim 2^{-\\varepsilon \\left|j-k\\right|}", block: true)]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(" and all ")#mi("{j,k}")#text(" (in fact the argument below allows us to take any ")#mi("{\\varepsilon > 0}")#text(").")

#text("To establish this, let us first look at the operator norm of ")#mi("{a(X,D) \\psi_k(D)}")#text(". This is an integral operator with kernel")

#align(center)[#tao-fit-display[#mitex("K_k(x,y) := \\int_{{\\bf R}^d} a(x,\\xi) \\psi_k(\\xi) e^{2\\pi i (x-y) \\cdot \\xi}\\ d\\xi.")]]

#text("For any fixed ")#mi("{x}")#text(", ")#mi("{a(x,\\xi) \\psi_k(\\xi)}")#text(" is a bump function adapted to the annulus ")#tao-math("{\\{ \\left|\\xi\\right| \\sim 2^k \\}}", block: false)#text(". Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(" then gives")

#align(center)[#tao-fit-display[#tao-math("\\left|K_k(x,y)\\right| \\lesssim 2^{dk} \\langle 2^k (x-y) \\rangle^{-d-1}", block: true)]]

#text("(say). But then Schur’s test can be applied to conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a(X,D) \\psi_k(D) \\right\\|_{L^2({\\bf R}^d)} \\lesssim 1.", block: true)]]

#text("This gives the claim when ")#mi("{j-k=O(1)}")#text(". It remains to establish the cases when ")#mi("{j > k+10}")#text(" (say) and when ")#mi("{j < k-10}")#text(". The cases are not completely symmetric because our choice of quantization was not symmetric, but it turns out that both cases can be treated in essentially the same manner. Let us first look at the case ")#mi("{j > k+10}")#text(". A little computation shows that ")#mi("{a(X,D) \\psi_k(D)}")#text(" is an integral operator with kernel")

#align(center)[#tao-fit-display[#mitex("K_{j,k}(x,y) = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\psi_j(\\eta) a(z,\\xi) \\psi_k(\\xi) e^{2\\pi i (z-y) \\cdot \\xi} e^{2\\pi i (x-z) \\cdot \\eta}\\ d\\xi dz d\\eta.")]]

#text("One can view this kernel in two ways. Firstly, it is ")#mi("{\\psi_j(D_x)}")#text(" applied to ")#mi("{K_k(x,y)}")#text(" (keeping ")#mi("{y}")#text(" fixed). Using the prior bounds on ")#mi("{K_k(x,y)}")#text(" and the convolution kernel bounds on ")#mi("{\\psi_j(D_x)}")#text(" we establish that")

#align(center)[#tao-fit-display[#tao-math("\\left|K_{j,k}(x,y)\\right| \\lesssim 2^{dk} \\langle 2^k (x-y) \\rangle^{-d-1}.", block: true)]]

#text("But this is not enough by itself (it doesn’t get the ")#tao-math("{2^{-\\varepsilon \\left|j-k\\right|}}", block: false)#text(" decay). We can get a different bound by using one of the basic heuristics of stationary phase, which is to locate the variable in which the phase is oscillating in order to fully exploit integration by parts. In this case, the correct variable to analyse is ")#mi("{z}")#text(". We take absolute values in the ")#mi("{\\xi,\\eta}")#text(" integrations to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|K_{j,k}(x,y)\\right| \\leq \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\left| \\int_{{\\bf R}^d} e^{2\\pi i z \\cdot (\\xi-\\eta)} a(z,\\xi)\\ dz \\right| \\left|\\psi_j(\\eta)\\right| \\left|\\psi_k(\\xi)\\right|\\ d\\xi d\\eta.", block: true)]]

#text("The support of ")#mi("{\\psi_j}")#text(" and ")#mi("{\\psi_k}")#text(" forces ")#tao-math("{\\left|\\xi-\\eta\\right| \\sim 2^j}", block: false)#text(", and then since for fixed ")#mi("{\\xi}")#text(", ")#mi("{a(z,\\xi)}")#text(" is a bump function adapted to ")#mi("{B(0,2)}")#text(", we see from Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} e^{2\\pi i z \\cdot (\\xi-\\eta)} a(z,\\xi)\\ dz = O( 2^{-100dj} )")]]

#text("(say). We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|K_{j,k}(x,y)\\right| \\lesssim 2^{-98dj}.", block: true)]]

#text("Taking a suitable combination of this with the previous kernel bound and then applying Schur’s test one obtains the desired result (in fact one gets a much better decay by this type of argument, namely ")#mi("{O_N(2^{-Nj})}")#text(" for any ")#mi("{N > 0}")#text(".")

#text("The case ")#mi("{j < k-10}")#text(" is very similar and is left to the reader. This proves the theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" It is possible to deduce a weak version of the Hörmander-Mikhlin theorem (in which the ")#mi("{j^{th}}")#text(" derivatives of the symbol ")#mi("{m(\\xi)}")#text(" are assumed to be ")#tao-math("{O_j(\\left|\\xi\\right|^{-j})}", block: false)#text(" for all ")#mi("{j \\geq 0}")#text(", not just ")#mi("{0 \\leq j \\leq d+2}")#text(") as a consequence of the Calderón-Vaillancourt theorem and a rescaling argument. Firstly, observe that if ")#mi("{m(\\xi)}")#text(" was a symbol of order ")#mi("{0}")#text(", then ")#mi("{m(D)}")#text(" is already a pseudodifferential operator of order ")#mi("{0}")#text(" and the claim is immediate. If instead ")#mi("{m(\\xi)}")#text(" is merely a homogeneous symbol of order ")#mi("{0}")#text(", we first truncate ")#mi("{m}")#text(" smoothly in an ")#mi("{\\varepsilon}")#text("-neighbourhood of the origin for some small ")#mi("{\\varepsilon > 0}")#text(" to create a truncated symbol ")#mi("{m_\\varepsilon(\\xi)}")#text(". Then one checks that ")#mi("{m_\\varepsilon(\\varepsilon \\xi)}")#text(" is a symbol of order ")#mi("{0}")#text(" and hence ")#mi("{m_\\varepsilon(\\varepsilon D)}")#text(" is a CZO. Since the class of CZOs is scale-invariant we conclude that ")#mi("{m_\\varepsilon(D)}")#text(" is a CZO uniformly in ")#mi("{\\varepsilon}")#text(". The claim then follows by a limiting argument taking ")#mi("{\\varepsilon \\rightarrow 0}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2.2. The pseudodifferential calculus — ")]]

#text("Now we start performing algebraic manipulations on these pseudodifferential operators, collectively referred to as the ")#emph[#text("pseudodifferential calculus")]#text(". We shall first need a technical lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Oscillatory integral estimate)")]#text(" ")#metadata(none) <tao-0864457e4a31e38ff52d>#text(" Let ")#mi("{a(x,y,\\xi,\\eta)}")#text(" be a compactly supported function obeying the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_x^\\alpha \\partial_y^\\beta \\partial_\\xi^\\gamma \\partial_\\eta^\\delta a(x,y,\\xi,\\eta)\\right| \\lesssim_{\\alpha,\\beta,\\gamma,\\delta,k,k^{\\prime},d} \\langle \\xi \\rangle^{k-\\left|\\gamma\\right|} \\langle \\eta \\rangle^{k^{\\prime}-\\left|\\delta\\right|}", block: true)]]

#text("for some ")#mi("{k,k^{\\prime} \\in{\\bf R}}")#text(", all ")#mi("{x,y,\\xi,\\eta \\in {\\bf R}^d}")#text(", and all multiindices ")#mi("{\\alpha,\\beta,\\gamma,\\delta}")#text(". Then the function")

#align(center)[#tao-fit-display[#mitex("c(x,\\xi) := \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,y,\\xi,\\eta) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\eta")]]

#text("is a symbol of order ")#mi("{k+k^{\\prime}}")#text(" (with implied constants depending on ")#mi("{k,k^{\\prime},d}")#text(").")
]

#emph[#text("Proof:")]#text(" We begin with some reductions. The main task will be to establish the zeroth order bound")

#align(center)[#tao-fit-display[#tao-math("\\left|c(x,\\xi)\\right| \\lesssim_{k,k^{\\prime},d} \\langle \\xi \\rangle^{k+k^{\\prime}}.", block: true)]]

#text("Once one has this, the higher derivatives in ")#mi("{x}")#text(" can be dealt with by moving the derivative inside the integral sign, noting that the ")#mi("{x}")#text(" derivatives of ")#mi("{e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}}")#text(" are negative the ")#mi("{y}")#text(" derivative, and then integrating by parts to move all ")#mi("{x,y}")#text(" derivatives onto the symbol ")#mi("{a}")#text(" where they can be harmlessly absorbed. A similar argument lets one deal with higher derivatives in ")#mi("{\\xi}")#text(".")

#text("By dividing ")#mi("{a}")#text(" by ")#mi("{\\langle \\xi \\rangle^k}")#text(" we may take ")#mi("{k=0}")#text(". By translating ")#mi("{a}")#text(" by ")#mi("{x}")#text(" we may take ")#mi("{x=0}")#text(". Our task is now to show that ")#metadata(none) <tao-372c7de53a63098f2e0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left| \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} b(y,\\eta) e^{2\\pi i y \\cdot (\\eta-\\xi)}\\ dy d\\eta\\right| \\lesssim_{k^{\\prime},d} \\langle \\xi \\rangle^{k^{\\prime}}", block: true)]]

#text(" ")#text(" where ")#mi("{b(y,\\eta) := a(0,y,\\xi,\\eta)}")#text("; note that")

#metadata(none) <tao-720473b9320ceb42c196>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\partial_y^\\beta \\partial_\\eta^\\delta b(y,\\eta)\\right| \\lesssim_{\\beta,\\delta,k^{\\prime},d} \\langle\\eta \\rangle^{k^{\\prime}-\\left|\\delta\\right|}", block: true)]]

#text("for all ")#mi("{y,\\eta \\in {\\bf R}^d}")#text(" and all multiindices ")#mi("{\\beta,\\delta}")#text(". Henceforth we omit the dependence of constants on ")#mi("{k^{\\prime},d}")#text(".")

#text("We shall in fact prove ")#link(<tao-372c7de53a63098f2e0a>)[#text("(5)")]#text(" for ")#emph[#text("all")]#text(" compactly supported functions ")#mi("{b}")#text(" obeying ")#link(<tao-720473b9320ceb42c196>)[#text("(6)")]#text(". Let us first deal with the case when ")#mi("{b}")#text(" is supported on the region ")#tao-math("{\\left|y\\right| \\lesssim 1}", block: false)#text(". For fixed ")#mi("{\\eta}")#text(", we may apply Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(" to estimate the ")#mi("{y}")#text(" integral by ")#mi("{O_N( \\langle \\eta \\rangle^{k^{\\prime}} \\langle \\xi - \\eta \\rangle^{-N} )}")#text(" for any ")#mi("{N}")#text(", which by the triangle inequality is equal to ")#mi("{O_N( \\langle \\xi \\rangle^{k^{\\prime}} \\langle \\xi - \\eta \\rangle^{-N} )}")#text(". Integrating in ")#mi("{\\eta}")#text(" we obtain the claim.")

#text("By a smooth partition of unity it remains to deal with the case when ")#mi("{b}")#text(" is supported on the region ")#tao-math("{\\left|y\\right| \\gg 1}", block: false)#text(". Here what we do is take a large integer ")#mi("{N}")#text(", write")

#align(center)[#tao-fit-display[#tao-math("e^{2\\pi i y \\cdot (\\eta-\\xi)} = (\\frac{y}{2\\pi i \\left|y\\right|^2} \\cdot \\nabla_\\eta)^N e^{2\\pi i y \\cdot (\\eta - \\xi)}", block: true)]]

#text("and integrate by parts ")#mi("{N}")#text(" times to express the left-hand side of ")#link(<tao-372c7de53a63098f2e0a>)[#text("(5)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left| \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} [ (\\nabla_\\eta \\cdot \\frac{y}{2\\pi \\left|y\\right|^2})^N b(y,\\eta) ] e^{2\\pi i y \\cdot (\\eta - \\xi)}\\ dy d\\eta\\right|.", block: true)]]

#text("For fixed ")#mi("{\\eta}")#text(", one can estimate the ")#mi("{y}")#text(" integral using Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(" (and a smooth partition of unity) as ")#mi("{O_N( \\langle \\eta \\rangle^{k^{\\prime}} \\langle \\xi - \\eta \\rangle^{-N} )}")#text(", and by repeating the previous argument we obtain the desired bound. ")#mi("\\Box")

#text("We now use this lemma to establish that the (formal) adjoint of a pseudodifferential operator is also a pseudodifferential operator.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17 (Adjoints of ")#mi("{\\Psi}")#text("DOs)")]#text(" Let ")#mi("{a(X,D)}")#text(" be a pseudodifferential operator of order ")#mi("{k}")#text(" for some ")#mi("{k \\in {\\bf R}}")#text(". Then ")#mi("{a(X,D)}")#text(" has an adjoint ")#mi("{a^*(X,D)}")#text(" which is also a pseudodifferential operator of order ")#mi("{k}")#text(". In fact we have")

#align(center)[#tao-fit-display[#mitex("a^*(x,\\xi) = \\overline{a(x,\\xi)} \\mod S^{k-1}")]]

#text("i.e. ")#mi("{a^*}")#text(" differs from ")#mi("{\\overline{a}}")#text(" by a symbol of order ")#mi("{k-1}")#text(".")
]

#emph[#text("Proof:")]#text(" We assume that ")#mi("{a}")#text(" is compactly supported in frequency; this assumption can be removed by limiting arguments which we leave as an exercise to the reader (the point being that our estimates are uniform in the size of this support). Then the (")#mi("{L^2}")#text(") adjoint of ")#mi("{a(X,D)}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("a(X,D)^* f(x) = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\overline{a(y,\\xi)} e^{2\\pi i (x-y) \\cdot \\xi} f(y)\\ d\\xi dy.")]]

#text("On the other hand, observe that")

#align(center)[#tao-fit-display[#mitex("\\overline{a}(X,D) f(x) = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\overline{a(x,\\xi)} e^{2\\pi i (x-y) \\cdot \\xi} f(y)\\ d\\xi dy.")]]

#text("Writing ")#mi("{\\overline{a(y,\\xi)} = \\overline{a(x,\\xi)} + \\int_0^1 (x-y) \\cdot a_x((1-t)x + ty,\\xi)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("a(X,D)^* f(x) = \\overline{a}(X,D) + \\int_0^1 \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} (x-y) \\overline{a_x((1-t)x+ty,\\xi)}")]]

#align(center)[#tao-fit-display[#mitex("e^{2\\pi i (x-y) \\cdot \\xi} f(y)\\ d\\xi dy.")]]

#text("So it will suffice to show that the operator")

#align(center)[#tao-fit-display[#mitex("T_t f(x) := \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} (x-y) \\cdot \\overline{a_x((1-t)x+ty,\\xi)} e^{2\\pi i (x-y) \\cdot \\xi} f(y)\\ d\\xi dy")]]

#text("is a pseudodifferential operator of order ")#mi("{k-1}")#text(", uniformly for ")#mi("{0 \\leq t \\leq 1}")#text(". We can integrate by parts to eliminate the ")#mi("{x-y}")#text(", writing")

#align(center)[#tao-fit-display[#mitex("T_t f(x) := \\frac{-1}{2\\pi i} \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} b((1-t)x+ty,\\xi) e^{2\\pi i (x-y) \\cdot \\xi} f(y)\\ d\\xi dy")]]

#text("where ")#mi("{b(x,\\xi) := \\nabla_\\xi \\cdot \\overline{a_x(x,\\xi)}}")#text(". Observe that ")#mi("{b}")#text(" is a symbol of order ")#mi("{k-1}")#text(". Some playing around with the Fourier inversion formula reveals that we can write ")#mi("{T_t = c_t(X,D)}")#text(" where")

#align(center)[#tao-fit-display[#mitex("c_t(x,\\eta) := \\frac{-1}{2\\pi i} \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} b((1-t)x+ty,\\xi) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ d\\xi dy.")]]

#text("But from Lemma ")#link(<tao-0864457e4a31e38ff52d>)[#text("16")]#text(" we have that ")#mi("{c_t}")#text(" is a symbol of order ")#mi("{k-1}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" A corollary of this lemma is that if a ")#mi("{\\Psi}")#text("DO of order ")#mi("{k}")#text(" has real symbol, then it is self-adjoint modulo a ")#mi("{\\Psi}")#text("DO of order ")#mi("{k-1}")#text(", and conversely if a ")#mi("{\\Psi}")#text("DO of order ")#mi("{k}")#text(" is self-adjoint, then it has a real symbol modulo a symbol of order ")#mi("{k-1}")#text(". If one switches to the Weyl calculus instead of the Kohn-Nirenberg calculus then one can drop the lower order terms here, and assert simply that a ")#mi("{\\Psi}")#text("DO is self-adjoint if and only if it has real symbol.")
]

#text("Next, we study compositions of pseudo-differential operators.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Composition of ")#mi("{\\Psi}")#text("DOs)")]#text(" Let ")#mi("{a(X,D)}")#text(" and ")#mi("{b(X,D)}")#text(" be pseudodifferential operators of order ")#mi("{k}")#text(", ")#mi("{k^{\\prime}}")#text(" respectively. Then ")#mi("{a(X,D) b(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{k+k^{\\prime}}")#text(", and ")#mi("{a(X,D) b(X,D) - ab(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{k+k^{\\prime}-1}")#text(".")
]

#emph[#text("Proof:")]#text(" We assume ")#mi("{a,b}")#text(" are compactly supported; one can remove these hypotheses by a limiting argument which we omit here. For Schwartz functions ")#mi("{f}")#text(", we expand")

#tao-aligned(keep: true)[


#tao-math("a(X,D) b(X,D) f(x)  & := \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,\\xi) e^{2\\pi i (x-y) \\cdot \\xi} b(X,D) f(y)\\ dy d\\xi", block: true)



#tao-math(" & = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,\\xi) b(y,\\eta) e^{2\\pi i (x-y) \\cdot \\xi} e^{2\\pi i y \\cdot \\eta} \\hat f(\\eta)\\ d\\eta dy d\\xi", block: true)



#tao-math(" & = c(X,D) f(x)", block: true)
]

#text("where")

#align(center)[#tao-fit-display[#mitex("c(x,\\eta) := \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,\\xi) b(y,\\eta) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\xi.")]]

#text("From Lemma ")#link(<tao-0864457e4a31e38ff52d>)[#text("16")]#text(" we obtain the first claim. To obtain the second claim, observe from the Fourier inversion formula that")

#align(center)[#tao-fit-display[#mitex("ab(x,\\eta) := \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,\\xi) b(x,\\eta) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\xi")]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} a(x,\\xi) (b(y,\\eta)-b(x,\\eta)) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\xi")]]

#text("is a symbol of order ")#mi("{k+k^{\\prime}-1}")#text(". As in the previous lemma, we exploit the fundamental theorem of calculus to write")

#align(center)[#tao-fit-display[#mitex("b(y,\\eta)-b(x,\\eta) = \\int_0^1 (y-x) \\cdot b_x((1-t)x + ty, \\eta)\\ dt")]]

#text("and then use integration by parts to deal with the ")#mi("{y-x}")#text(", eventually reducing one to showing that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} \\nabla_\\xi a(x,\\xi) \\cdot b_x((1-t)x+ty,\\eta) e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\xi")]]

#text("is a symbol of order ")#mi("{k+k^{\\prime}-1}")#text(". But this follows from Lemma ")#link(<tao-0864457e4a31e38ff52d>)[#text("16")]#text(". ")#mi("\\Box")

#text("It is instructive to establish the above lemma by hand in the case where ")#mi("{a(X,D)}")#text(" and ")#mi("{b(X,D)}")#text(" are variable-coefficient differential operators of order ")#mi("{k}")#text(" and ")#mi("{k^{\\prime}}")#text(" respectively. The defect between ")#mi("{a(X,D)b(X,D)}")#text(" and ")#mi("{ab(X,D)}")#text(" can be interpreted physically as the difference between quantum and classical mechanics.")

#text("The above lemma implies in particular that the commutator")

#align(center)[#tao-fit-display[#mitex("[a(X,D), b(X,D)] := a(X,D) b(X,D) - b(X,D) a(X,D)")]]

#text("of two pseudodifferential operators of order ")#mi("{k}")#text(" and ")#mi("{k^{\\prime}}")#text(" will be an operator of order ")#mi("{k+k^{\\prime}-1}")#text(". In fact we can pin down this commutator more precisely. Define the ")#emph[#text("Poisson bracket")]#text(" ")#mi("{\\{a,b\\}}")#text(" of ")#mi("{a,b}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("\\{ a,b \\} := \\nabla_\\xi a \\cdot \\nabla_x b - \\nabla_x a \\cdot \\nabla_\\xi b.")]]

#text("Thus for instance ")#mi("{\\{x,\\xi\\} = -1}")#text(". One can easily verify that the Poisson bracket of two symbols of order ")#mi("{k,k^{\\prime}}")#text(" respectively will be a symbol of order ")#mi("{k+k^{\\prime}-1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20 (Commutator of ")#mi("{\\Psi}")#text("DOs)")]#text(" Let ")#mi("{a(X,D)}")#text(" and ")#mi("{b(X,D)}")#text(" be pseudodifferential operators of order ")#mi("{k}")#text(", ")#mi("{k^{\\prime}}")#text(" respectively. Then ")#mi("{[a(X,D), b(X,D)] - \\frac{1}{2\\pi i} \\{a,b\\}(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{k+k^{\\prime}-2}")#text(".")
]

#emph[#text("Proof:")]#text(" From the proof of the previous lemma, we see that ")#mi("{[a(X,D),b(X,D)]}")#text(" is a pseudodifferential operator with symbol")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} [a(x,\\xi) b(y,\\eta) - a(y,\\eta) b(x,\\xi)] e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}\\ dy d\\xi.")]]

#text("We Taylor expand")

#tao-aligned(keep: true)[


#tao-math("b(y,\\eta)  & = b(x,\\xi) + (y-x) \\cdot \\nabla_x b(x,\\xi) + (\\eta-\\xi) \\cdot \\nabla_\\eta b(x,\\xi)", block: true)



#tao-math(" & + \\int_0^1 \\int_0^1 [(y-x) \\cdot \\nabla_x] [(\\eta-\\xi) \\cdot \\nabla_\\eta] b( (1-t) x + ty, (1-s) \\xi + s \\eta )\\ ds dt", block: true)
]

#text("and similarly for ")#mi("{a(y,\\eta)}")#text(". Expanding this we obtain a variety of terms. Any factor of ")#mi("{(y-x)}")#text(" can be converted into ")#mi("{\\frac{-1}{2\\pi i}}")#text(" a ")#mi("{\\xi}")#text(" derivative on ")#mi("{e^{2\\pi i (x-y) \\cdot (\\xi-\\eta)}}")#text(", which can then by integration by parts be converted to ")#mi("{\\frac{1}{2\\pi i}}")#text(" times a ")#mi("{\\xi}")#text(" derivative somewhere else. Similarly, any factor of ")#mi("{(\\eta-\\xi)}")#text(" can be converted to ")#mi("{\\frac{-1}{2\\pi i}}")#text(" times a ")#mi("{y}")#text(" derivative somewhere else. Because of this, any term which contains two or more factors of ")#mi("{(y-x) \\cdot \\nabla_x}")#text(" or ")#mi("{(\\eta-\\xi) \\cdot \\nabla_\\eta}")#text(" can be integrated to an expression which has two or more derivatives in ")#mi("{\\xi}")#text(" or ")#mi("{\\eta}")#text(" on the symbols ")#mi("{a,b}")#text(", and Lemma ")#link(<tao-0864457e4a31e38ff52d>)[#text("16")]#text(" will show that such terms give symbols of order ")#mi("{k+k^{\\prime}-2}")#text(". Thus we only need to consider terms with exactly one factor of ")#mi("{(y-x) \\cdot \\nabla_x}")#text(" or ")#mi("{(\\eta-\\xi) \\cdot \\nabla_\\eta}")#text(" (the terms with zero factors cancel each other out). In other words, we can replace the expression ")#mi("{a(x,\\xi) b(y,\\eta) - a(y,\\eta) b(x,\\xi)}")#text(" with")

#tao-aligned(keep: true)[


#tao-math("a(x,\\xi) (y-x)  & \\cdot \\nabla_x b(x,\\xi) + a(x,\\xi) (\\eta-\\xi) \\cdot \\nabla_\\eta b(x,\\xi)", block: true)



#tao-math(" & - b(x,\\xi) (y-x) \\cdot \\nabla_x a(x,\\xi) + b(x,\\xi) (\\eta-\\xi) \\cdot \\nabla_\\eta a(x,\\xi).", block: true)
]

#text("Converting the ")#mi("{(y-x)}")#text(" and ")#mi("{(\\eta-\\xi)}")#text(" terms to derivatives by integration by parts, as outlined above, we can re-express this as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} a_\\xi(x,\\xi) \\cdot b_x(x,\\xi) - \\frac{1}{2\\pi i} a_x(x,\\xi) \\cdot b_\\xi(x,\\xi) = \\frac{1}{2\\pi i} \\{a,b\\}(x,\\xi)")]]

#text("and the claim follows. ")#mi("\\Box")

#text("We thus see that the algebraic structure of pseudodifferential operators is intimately connected to the Poisson geometry structure of the phase plane ")#mi("{\\{ (x,\\xi): x, \\xi \\in{\\bf R}^d\\}}")#text(", which in turn is induced by the symplectic geometry of that plane. There is a rich theory of how symplectic geometry (which represents Hamiltonian or “classical” mechanics) interacts with pseudodifferential operators (which represents quantum mechanics); this is the subject of semiclassical analysis and geometric quantisation. However, these topics would take us too far afield.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-6866b00707ab48540b44>#text(" Show that if ")#mi("{a}")#text(" is a symbol of order ")#mi("{k}")#text(", then ")#mi("{a^w(X,D) = a(X,D) + b(X,D)}")#text(" and ")#mi("{a(X,D) = a^w(X,D) + c^w(X,D)}")#text(", where ")#mi("{b}")#text(" and ")#mi("{c}")#text(" are symbols of order ")#mi("{k-1}")#text(". Thus the Kohn-Nirenberg and Weyl quantisations are equivalent modulo lower order operators.")
]

#heading(level: 1)[#strong[#text(" — 3. Sobolev spaces — ")]]

#text("With all the various inequalities at our disposal (the Hörmander-Mikhlin multiplier theorem, the Calderón-Vaillancourt theorem, and the Hardy-Littlewood-Sobolev inequality) we can now quickly develop some of the classical theory of homogeneous and inhomogeneous Sobolev spaces on Euclidean spaces ")#mi("{{\\bf R}^d}")#text("; of course we will not attempt an exhaustive survey of this vast subject here. In particular, we omit one important analytical aspect of these spaces, namely their local stability under smooth diffeomorphisms, which allows one to transplant these spaces onto manifolds and thus have application to various problems in differential geometry. We begin with the inhomogeneous spaces which contain fewer technicalities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 22 (Inhomogeneous Sobolev norms)")]#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(". If ")#mi("{f \\in \\mathcal{S}({\\bf R}^d)}")#text(" is a Schwartz function, we define the inhomogeneous Sobolev norm ")#tao-math("{\\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{W^{s,p}({\\bf R}^d)} := \\left\\| \\langle \\nabla \\rangle^s f \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("We let ")#mi("{W^{s,p}({\\bf R}^d)}")#text(" be the closure of the Schwartz functions under this norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" When ")#mi("{p=2}")#text(", the spaces ")#mi("{W^{s,p}({\\bf R}^d)}")#text(" are often denoted ")#mi("{H^s({\\bf R}^d)}")#text(" (but not to be confused with the Hardy spaces ")#mi("{{\\mathcal H}^p({\\bf R}^d)}")#text("). From the Fourier inversion formula we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{H^s({\\bf R}^d)} \\sim_{s,d} \\left\\| \\langle \\xi \\rangle^s \\hat f \\right\\|_{L^2({\\bf R}^d)}.", block: true)]]
]

#text("Clearly ")#mi("{W^{0,p}({\\bf R}^d)}")#text(" is isometric to ")#mi("{L^p({\\bf R}^d)}")#text(", so Sobolev spaces include Lebesgue spaces as special cases.")

#text("One can easily verify that Sobolev spaces are Banach spaces, and that the dual of ")#mi("{W^{s,p}({\\bf R}^d)}")#text(" can be identified with ")#mi("{W^{-s,p^{\\prime}}({\\bf R}^d)}")#text(". We have the following basic embeddings.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24 (Sobolev embeddings)")]#text(" ")#metadata(none) <tao-1f7348da56d5c73c30f4>#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(" and ")#mi("{f \\in W^{s,p}({\\bf R}^d)}")#text(".")

#list(
[#text("(i) (Monotonicity in ")#mi("{s}")#text(") If ")#mi("{s^{\\prime} < s}")#text(" then ")#mi("{f \\in W^{s^{\\prime},p}({\\bf R}^d)}")#text(", and")

#metadata(none) <tao-eb0e53b481b0fb1b9b46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|f\\right\\|_{W^{s^{\\prime},p}({\\bf R}^d)} \\lesssim_{p,s,s^{\\prime},d} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]],
[#text("(ii) (Behaviour with respect to pseudodifferential operators) If ")#mi("{a(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{k}")#text(" for some ")#mi("{k \\in {\\bf R}}")#text(", then ")#mi("{a}")#text(" extends continuously from ")#mi("{W^{s,p}}")#text(" to ")#mi("{W^{s-k,p}}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a(X,D) f \\right\\|_{W^{s-k,p}({\\bf R}^d)} \\lesssim_{p,s,d,k} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]],
[#text("(iii) (Behaviour with respect to Hörmander-Mikhlin multipliers) If ")#mi("{m(D)}")#text(" is a Hörmander-Mikhlin multiplier, then ")#mi("{m(D)}")#text(" extends to a bounded linear operator on ")#mi("{W^{s,p}({\\bf R}^d)}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m(D) f \\right\\|_{W^{s,p}({\\bf R}^d)} \\lesssim_{p,s,d} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]],
[#text("(iv) (Characterisation using derivatives) If ")#mi("{f, \\nabla^k f \\in W^{s,p}({\\bf R}^d)}")#text(" for some integer ")#mi("{k \\geq 0}")#text(" (note from (ii) that ")#mi("{\\nabla^k f}")#text(" is already well-defined as an element of ")#mi("{W^{s-k,p}({\\bf R}^d)}")#text(" at least), then ")#mi("{f \\in W^{s+k,p}({\\bf R}^d)}")#text(" and")

#tao-aligned(keep: true)[


#tao-math("\\left\\|f\\right\\|_{W^{s+k,p}({\\bf R}^d)}  & \\sim_{p,s,d,k} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)} + \\left\\| \\nabla^k f \\right\\|_{W^{s,p}({\\bf R}^d)}", block: true)



#tao-math(" & \\sim_{p,s,d,k} \\sum_{j=0}^k \\left\\| \\nabla^j f \\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)
]

#text("In particular,")

#tao-aligned(keep: true)[


#tao-math("\\left\\|f\\right\\|_{W^{k,p}({\\bf R}^d)}  & \\sim_{p,d,k} \\left\\|f\\right\\|_{L^{p}({\\bf R}^d)} + \\left\\| \\nabla^k f \\right\\|_{L^{p}({\\bf R}^d)}", block: true)



#tao-math(" & \\sim_{p,d,k} \\sum_{j=0}^k \\left\\| \\nabla^j f \\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)
]],
[#text("(v) (Sobolev embedding theorem) If ")#mi("{p < q < \\infty}")#text(" is such that ")#mi("{\\frac{d}{q} \\geq \\frac{d}{p}-s}")#text(", then ")#mi("{f \\in L^q({\\bf R}^d)}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\lesssim_{p,s,q,d} \\left\\| f \\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]

#text("If instead ")#mi("{s > d/p}")#text(", then ")#mi("{f}")#text(" is bounded and continuous with")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)} \\lesssim_{p,s,q,d} \\left\\| f \\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" To prove (i), observe that ")#mi("{\\langle \\nabla \\rangle^{s^{\\prime}-s}}")#text(" is certainly a Hörmander-Mikhlin multiplier (or a pseudodifferential operator of order ")#mi("{s^{\\prime}-s}")#text(" and hence of order ")#mi("{0}")#text("), and hence bounded on ")#mi("{L^p({\\bf R}^d)}")#text(". One can then quickly verify ")#link(<tao-eb0e53b481b0fb1b9b46>)[#text("(7)")]#text(" for Schwartz functions and then extend by density.")

#text("To prove (ii), observe from the pseudodifferential calculus that ")#mi("{\\langle \\nabla \\rangle^{s-k} a(X,D) \\langle \\nabla \\rangle^{-s}}")#text(" is a pseudodifferential operator of order ")#mi("{0}")#text(", and hence bounded on ")#mi("{L^p({\\bf R}^d)}")#text(". The claim then follows as in (i).")

#text("To prove (iii), use the Hörmander multiplier theorem coupled with the observation that ")#mi("{m(D)}")#text(" commutes with ")#mi("{\\langle \\nabla \\rangle^s}")#text(" (working in the Schwartz category to begin with).")

#text("To prove (iv), we can use Fourier multiplier calculus to write ")#mi("{\\langle \\nabla \\rangle^k = m_0(D) + m_1(D) \\cdot \\nabla^k}")#text(" where ")#mi("{m_0, m_1}")#text(" are Hörmander-Mikhlin multipliers, and hence")

#align(center)[#tao-fit-display[#mitex("\\langle \\nabla \\rangle^{s+k} f = m_0(D) \\langle \\nabla \\rangle^s f + m_1(D) \\cdot \\langle \\nabla \\rangle^s \\nabla^k f")]]

#text("Taking ")#mi("{L^p}")#text(" norms (first for Schwartz functions, and then one can take weak limits) we establish that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{s+k,p}({\\bf R}^d)} \\lesssim_{p,s,d,k} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)} + \\left\\| \\nabla^k f \\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]

#text("The remaining inequalities then follow from (ii).")

#text("To prove (v), we may lower ")#mi("{s}")#text(" to assume that ")#mi("{0 < s < d}")#text(". We need to show that ")#mi("{\\langle \\nabla \\rangle^{-s}}")#text(" maps ")#mi("{L^p({\\bf R}^d)}")#text(" to ")#mi("{L^q({\\bf R}^d)}")#text(" in the first case, or ")#mi("{L^p({\\bf R}^d)}")#text(" to ")#mi("{L^\\infty({\\bf R}^d)}")#text(" in the second case. But by Lemma ")#link(<tao-f35a2929e8cf4b8066ad>)[#text("37")]#text(", the convolution kernel ")#mi("{K(x)}")#text(" of this Fourier multiplier is ")#tao-math("{O_{s,d,N}( \\min( \\left|x\\right|^{-d+s}, \\left|x\\right|^{-N} ) )}", block: false)#text(" for any ")#mi("{N > 0}")#text(". In particular it is ")#tao-math("{O_{s,d,q}( \\left|x\\right|^{-d/p^{\\prime} - d/q} )}", block: false)#text(", at which point the first claim follows from the Hardy-Littlewood-Sobolev inequality; if ")#mi("{s > d/p}")#text(" then the kernel lies in ")#mi("{L^{p^{\\prime}}}")#text(", at which point we get the second claim (the continuity follows by starting with Schwartz functions and taking limits). ")#mi("\\Box")

#text("Next, we establish a Littlewood-Paley characterisation of Sobolev spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Littlewood-Paley characterisation)")]#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(". Let ")#mi("{\\phi_0: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a bump function adapted to the ball ")#mi("{B(0,2)}")#text(", and for each ")#mi("{j \\geq 1}")#text(" let ")#mi("{\\psi_j: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a bump function adapted to the annulus ")#mi("{B(0,2^{j+1}) \\backslash B(0,2^{j-1})}")#text(", such that one has the pointwise estimate ")#tao-math("{\\left|\\phi_0\\right|^2 + \\sum_{j=1}^\\infty \\left|\\psi_j\\right|^2 \\sim 1}", block: false)#text(". Then for any ")#mi("{f \\in W^{s,p}({\\bf R}^d)}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)} \\sim_{s,p,d} \\left\\| \\phi_0(D) f \\right\\|_{L^p({\\bf R}^d)} + \\left\\| (\\sum_{j=1}^\\infty 2^{2js} \\left|\\psi_j(D) f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Let us just prove the upper bound. From Proposition ")#link(<tao-1f7348da56d5c73c30f4>)[#text("24")]#text("(ii) we already know that ")#mi("{\\phi_0(D)}")#text(" maps ")#mi("{W^{s,p}}")#text(" to ")#mi("{L^p}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^\\infty 2^{2js} \\left|\\psi_j(D) f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{s,p,d} \\left\\|f\\right\\|_{W^{s,p}({\\bf R}^d)}.", block: true)]]

#text("It suffices to do this for Schwartz functions. Substituting ")#mi("{g := \\langle \\nabla \\rangle^s f}")#text(", our task is to show")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^\\infty \\left|2^{js} \\psi_j(D) \\langle \\nabla \\rangle^{-s} g\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{s,p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("But observe that ")#mi("{2^{js} \\psi_j(D)\\langle \\nabla \\rangle^{-s}}")#text(" is a Fourier multiplier whose symbol is adapted to the annulus ")#tao-math("{\\{ \\left|\\xi\\right| \\sim 2^{js} \\}}", block: false)#text(", so the claim follows from the upper Littlewood-Paley inequality.")

#text("The lower bound can be proven in a similar manner using the full Littlewood-Paley inequality, as well as a further frequency decomposition into low frequencies ")#tao-math("{\\left|\\xi\\right| \\lesssim 1}", block: false)#text(" and high frequencies ")#tao-math("{\\left|\\xi\\right| \\gtrsim 1}", block: false)#text(", and we leave this as an exercise to the reader. ")#mi("\\Box")

#text("Sobolev spaces can be interpolated with each other fairly easily using the complex interpolation method. We present here a sample result to give the flavour.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 26")]#text(" Let ")#mi("{T: \\mathcal{S} \\rightarrow \\mathcal{S}}")#text(" be a linear operator on Schwartz functions which is bounded on both ")#mi("{W^{s_0,p_0}({\\bf R}^d)}")#text(" and ")#mi("{W^{s_1,p_1}({\\bf R}^d)}")#text(" for some ")#mi("{1 < p_0,p_1 < \\infty}")#text(" and ")#mi("{s_0,s_1 \\in {\\bf R}}")#text(". Then ")#mi("{T}")#text(" is also bounded on ")#mi("{W^{s_\\theta,p_\\theta}({\\bf R}^d)}")#text(" for ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where ")#mi("{\\frac{1}{p_\\theta} = \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}}")#text(" and ")#mi("{s_\\theta := (1-\\theta) s_0 + \\theta s_1}")#text(".")
]

#emph[#text("Proof:")]#text(" By hypothesis, the operator ")#mi("{\\langle \\nabla \\rangle^{s_j} T \\langle \\nabla \\rangle^{-s_j}}")#text(" is bounded on ")#mi("{L^{p_j}({\\bf R}^d)}")#text(" for ")#mi("{j=0,1}")#text(". By the Hörmander-Mikhlin multiplier theorem, we also see that ")#mi("{\\langle \\nabla \\rangle^{s_j+it} T \\langle \\nabla \\rangle^{-s_j-it}}")#text(" is bounded on ")#mi("{L^{p_j}({\\bf R}^d)}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(" whose operator norm grows at most polynomially in ")#mi("{t}")#text(". The claim then follows from the Stein interpolation theorem. ")#mi("\\Box")

#text("We now briefly discuss homogeneous Sobolev spaces ")#mi("{\\dot W^{s,p}({\\bf R}^d)}")#text(", defined using ")#tao-math("{\\left|\\nabla\\right|^s}", block: false)#text(" instead of ")#mi("{\\langle \\nabla \\rangle^s}")#text("; these have the advantage of behaving well under dilations ")#mi("{\\mathrm{Dil}^q_\\lambda}")#text(", although they have some other drawbacks to compensate for this. Here one can run into some technicalities for the very low regularities (")#mi("{s \\leq -d}")#text("), because the operator ")#tao-math("{\\left|\\nabla\\right|^s}", block: false)#text(" is not well defined distributionally in that case. This problem can be avoided by restricting the Schwartz functions to avoid the frequency origin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 27 (Homogeneous Sobolev norms)")]#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(". If ")#mi("{f \\in \\mathcal{S}({\\bf R}^d)}")#text(" is a Schwartz function whose Fourier transform vanishes near the origin, we define the homogeneous Sobolev norm ")#tao-math("{\\left\\|f\\right\\|_{\\dot W^{s,p}({\\bf R}^d)}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\dot W^{s,p}({\\bf R}^d)} := \\left\\| \\left|\\nabla\\right|^s f \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("We let ")#mi("{\\dot W^{s,p}({\\bf R}^d)}")#text(" be the closure of all such functions under this norm.")
]

#text("Because ")#mi("{\\dot W^{s,p}}")#text(" does not always contain all Schwartz functions, one has to sometimes take a little care with arguments. Nevertheless, one can still establish a reasonable theory for these spaces. For instance, ")#mi("{\\nabla^k}")#text(" is an isomorphism between ")#mi("{\\dot W^{s,p}}")#text(" and ")#mi("{\\dot W^{s-k,p}}")#text(", and we have the homogeneous Sobolev embedding ")#mi("{\\dot W^{s,p}({\\bf R}^d) \\subset L^q({\\bf R}^d)}")#text(" whenever ")#mi("{1 < p < q < \\infty}")#text(" and ")#mi("{d/q = d/p - s}")#text(". For positive ")#mi("{s}")#text(" we also have the relationship ")#mi("{W^{s,p}({\\bf R}^d) = \\dot W^{s,p}({\\bf R}^d) \\cap L^p({\\bf R}^d)}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{W^{s,p}({\\bf R}^d)} \\sim_{s,p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)} + \\left\\| f \\right\\|_{\\dot W^{s,p}({\\bf R}^d)};", block: true)]]

#text("however we caution that this relationship breaks down for negative ")#mi("{s}")#text(". We leave these facts (which are simple modifications of the arguments given above) to the reader.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Endpoint Sobolev embedding)")]#text(" ")#metadata(none) <tao-a08c925fed8ffd1710d3>#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s = d/p}")#text(". Show that if ")#mi("{f \\in \\dot W^{s,p}({\\bf R}^d)}")#text(", then ")#mi("{f \\in \\mathrm{BMO}({\\bf R}^d)}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim_{d,p} \\left\\|f\\right\\|_{\\dot W^{s,p}({\\bf R}^d)}.", block: true)]]

#text("In fact, slightly more is true: show that ")#mi("{f}")#text(" has ")#emph[#text("vanishing mean oscillation")]#text(" in the sense that for any ")#mi("{x \\in {\\bf R}^d}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("-\\!\\!\\!\\!\\int_{B(x,r)} \\left|f - -\\!\\!\\!\\!\\int_{B(x,r)} f\\right| \\rightarrow 0 \\text{ as } r \\rightarrow 0 \\text{ or } r \\rightarrow \\infty.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Hölder-Sobolev embedding)")]#text(" ")#metadata(none) <tao-f8bdff3fb98849eac918>#text(" Let ")#mi("{1 < p < \\infty}")#text(", ")#mi("{0 < \\delta < 1}")#text(", and ")#mi("{s = d/p + \\delta}")#text(". Show that if ")#mi("{f \\in \\dot W^{s,p}({\\bf R}^d)}")#text(", then we have the Hölder estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)-f(y)\\right| \\lesssim_{d,p,\\delta} \\left\\|f\\right\\|_{\\dot W^{s,p}({\\bf R}^d)} \\left|x-y\\right|^\\delta", block: true)]]

#text("for all ")#mi("{x,y \\in {\\bf R}^d}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Appendix: the geometric Hahn-Banach theorem — ")]]

#text("Here we give a geometric formulation of the Hahn-Banach theorem, sometimes also called the ")#emph[#text("Dieudonné hyperplane separation theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 30 (Algebraic openness)")]#text(" A set ")#mi("{A \\subset V}")#text(" in a (real) vector space is ")#emph[#text("algebraically open")]#text(" if the set ")#mi("{\\{ t \\in {\\bf R}: v+tw \\in A \\}}")#text(" is open for all ")#mi("{v,w \\in V}")#text(" (i.e. the intersection of ")#mi("{A}")#text(" with any line is an open subset of that line).")
]

#text("Algebraic openness is a very mild property; indeed, the topological vector space structure given by weak openness is finer than any other topological vector space structure. For instance, in a normed vector space, any open set will be algebraically open.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 31 (Geometric Hahn-Banach theorem)")]#text(" Let ")#mi("{A, B}")#text(" be disjoint convex subsets of a real vector space ")#mi("{V}")#text(", with ")#mi("{A}")#text(" algebraically open. Then there exists a linear functional ")#mi("{\\lambda: V \\rightarrow {\\bf R}}")#text(" and ")#mi("{c \\in {\\bf R}}")#text(" such that ")#mi("{\\lambda < c}")#text(" on ")#mi("{A}")#text(", and ")#mi("{\\lambda \\geq c}")#text(" on ")#mi("{B}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 32")]#text(" In finite dimensions, it is not difficult to drop the algebraic openness hypothesis on ")#mi("{A}")#text(" as long as one now replaces the condition ")#mi("{\\lambda < c}")#text(" by ")#mi("{\\lambda \\leq c}")#text(". However in infinite dimensions one cannot do this. Consider for instance the space ")#mi("{V = \\bigcup_{n=0}^\\infty {\\bf R}^n}")#text(" of sequences ")#mi("{(x_n)_{n=1}^\\infty}")#text(" with only finitely many ")#mi("{x_n}")#text(" non-zero, let ")#mi("{A}")#text(" consist of those sequences whose last non-zero element is strictly positive, and ")#mi("{B = -A}")#text(" consist of those sequences whose last non-zero element is strictly negative. Then there is no hyperplane separating ")#mi("{A}")#text(" from ")#mi("{B}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" If ")#mi("{B}")#text(" is algebraically open, and ")#mi("{A,B}")#text(" are non-empty, then ")#mi("{\\lambda}")#text(" is non-zero, and it is not hard to see that the condition ")#mi("{\\lambda \\geq c}")#text(" can be upgraded to ")#mi("{\\lambda > c}")#text(". If ")#mi("{A}")#text(" contains the origin, then ")#mi("{c}")#text(" must be positive, and can then be rescaled to be ")#mi("{1}")#text(".")
]

#emph[#text("Proof:")]#text(" We first observe that it suffices to verify the homogeneous case, when ")#mi("{A,B}")#text(" are convex cones and ")#mi("{c=0}")#text(". Indeed, to then establish the general case, one applies the homogeneous case to the convex cones ")#mi("{A^{\\prime}, B^{\\prime} \\in {\\bf R} \\times V}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("A^{\\prime} := \\{ (t, tx): t > 0, x \\in A \\}; \\quad B^{\\prime} := \\{ (t,tx): t > 0, x \\in B \\};")]]

#text("we leave the details to the reader.")

#text("Consider all the pairs ")#mi("{(A,B)}")#text(" of disjoint convex cones, with ")#mi("{A}")#text(" algebraically open. We can order these pairs by set inclusion, so that ")#mi("{(A,B) \\leq (A^{\\prime},B^{\\prime})}")#text(" whenever ")#mi("{A \\subseteq A^{\\prime}}")#text(" and ")#mi("{B \\subseteq B^{\\prime}}")#text(", and observe that every chain has an upper bound. By Zorn’s lemma, we thus see that to prove the claim it suffices to do so under the additional assumption that ")#mi("{(A,B)}")#text(" is ")#emph[#text("maximal")]#text(". (This is the one and only place where we use (crucially) the axiom of choice.)")

#text("We can of course assume that neither ")#mi("{A}")#text(" nor ")#mi("{B}")#text(" is empty. We now claim that ")#mi("{B}")#text(" is the complement of ")#mi("{A}")#text(". For if not, then there exists ")#mi("{v \\in V}")#text(" which does not lie in either ")#mi("{A}")#text(" or ")#mi("{B}")#text(". By the maximality of ")#mi("{(A,B)}")#text(", the convex cone generated by ")#mi("{B \\cup \\{v\\}}")#text(" must intersect ")#mi("{A}")#text(" at some point, say ")#mi("{w}")#text(". By dilating ")#mi("{w}")#text(" if necessary we may assume that ")#mi("{w}")#text(" lies on a line segment between ")#mi("{v}")#text(" and some point ")#mi("{b}")#text(" in ")#mi("{B}")#text(". By using the convexity and disjointness of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" one can then deduce that for any ")#mi("{a \\in A}")#text(", the ray ")#mi("{\\{a + t(w-b): t > 0 \\}}")#text(" is disjoint from ")#mi("{B}")#text(". Thus one can enlarge ")#mi("{A}")#text(" to the convex cone generated by ")#mi("{A}")#text(" and ")#mi("{w-b}")#text(", which is still algebraically open and now strictly larger than ")#mi("{A}")#text(" (because it contains ")#mi("{v}")#text("), a contradiction. Thus ")#mi("{B}")#text(" is the complement of ")#mi("{A}")#text(".")

#text("Let us call a line in ")#mi("{V}")#text(" ")#emph[#text("monochromatic")]#text(" if it is entirely contained in ")#mi("{A}")#text(" or entirely contained in ")#mi("{B}")#text(". Note that if a line is not monochromatic, then (because ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are convex and partition the line, and ")#mi("{A}")#text(" is algebraically open), the line splits into an open ray contained in ")#mi("{A}")#text(", and a closed ray contained in ")#mi("{B}")#text(". From this we can conclude that if a line is monochromatic, then all parallel lines must also be monochromatic, because otherwise we look at the ray in the parallel line which contains ")#mi("{A}")#text(" and use convexity of both ")#mi("{A}")#text(" and ")#mi("{B}")#text(" to show that this ray is adjacent to a halfplane contained in ")#mi("{B}")#text(", contradicting algebraic openness. Now let ")#mi("{W}")#text(" be the space of all vectors ")#mi("{w}")#text(" for which there exists a monochromatic line in the direction ")#mi("{w}")#text(" (including ")#mi("{0}")#text("). Then ")#mi("{W}")#text(" is easily seen to be a vector space; since ")#mi("{A,B}")#text(" are non-empty, ")#mi("{W}")#text(" is a proper subspace of ")#mi("{V}")#text(". On the other hand, if ")#mi("{w}")#text(" and ")#mi("{w^{\\prime}}")#text(" are not in ")#mi("{W}")#text(", some playing around with the property that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are convex sets partitioning ")#mi("{V}")#text(" shows that the plane spanned by ")#mi("{w}")#text(" and ")#mi("{w^{\\prime}}")#text(" contains a monochromatic line, and hence some non-trivial linear combination of ")#mi("{w}")#text(" and ")#mi("{w^{\\prime}}")#text(" lies in ")#mi("{W}")#text(". Thus ")#mi("{V/W}")#text(" is precisely one-dimensional. Since every line with direction in ")#mi("{w}")#text(" is monochromatic, ")#mi("{A}")#text(" and ")#mi("{B}")#text(" also have well-defined quotients ")#mi("{A/W}")#text(" and ")#mi("{B/W}")#text(" on this one-dimensional subspace, which remain convex (with ")#mi("{A/W}")#text(" still algebraically open). But then it is clear that ")#mi("{A/W}")#text(" and ")#mi("{B/W}")#text(" are an open and closed ray from the origin in ")#mi("{V/W}")#text(" respectively. It is then a routine matter to construct a linear functional ")#mi("{\\lambda: V \\rightarrow {\\bf R}}")#text(" (with null space ")#mi("{W}")#text(") such that ")#mi("{A = \\{\\lambda < 0\\}}")#text(" and ")#mi("{B = \\{\\lambda \\ge 0\\}}")#text(", and the claim follows. ")#mi("\\Box")

#text("To illustrate the power of this theorem, let us give a famous consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 34 (Hahn-Banach theorem)")]#text(" Let ")#mi("{V}")#text(" be a normed vector space, and let ")#mi("{W}")#text(" be any subspace of ")#mi("{V}")#text(". Then any bounded linear functional ")#mi("{\\lambda: W \\rightarrow {\\bf R}}")#text(" has an extension ")#mi("{\\tilde \\lambda: V \\rightarrow {\\bf R}}")#text(" with the same norm.")
]

#emph[#text("Proof:")]#text(" We may normalise ")#tao-math("{\\left\\| \\lambda \\right\\|_{W^*} = 1}", block: false)#text(". Then the algebraically open convex sets ")#tao-math("{\\{ v \\in V: \\left\\|v\\right\\|_V < 1 \\}}", block: false)#text(" and ")#mi("{\\{ w \\in W: \\lambda(w) > 1 \\}}")#text(" are disjoint, with the former containing ")#mi("{0}")#text(", and so by the geometric Hahn-Banach theorem we can find ")#mi("{\\tilde \\lambda}")#text(" such that ")#mi("{\\tilde \\lambda < 1}")#text(" on the first set and ")#mi("{\\tilde \\lambda > 1}")#text(" on the second. The former fact establishes that ")#mi("{\\tilde \\lambda}")#text(" is bounded on ")#mi("{V}")#text(" with norm at most ")#mi("{1}")#text(", and the latter implies that the null space of ")#mi("{\\tilde \\lambda}")#text(" contains the null space of ")#mi("{\\lambda}")#text(". Restricting to ")#mi("{W}")#text(" we then quickly conclude that ")#mi("{\\tilde \\lambda}")#text(" when restricted to ")#mi("{W}")#text(" equals ")#mi("{\\lambda}")#text(", and the claim follows. ")#mi("\\Box")

#text("In the converse direction, one can deduce the geometric Hahn-Banach theorem from its more familiar formulations, but this requires some work. The first key observation is that to prove the geometric Hahn-Banach theorem it suffices to do so when ")#mi("{B}")#text(" is the origin ")#mi("{\\{0\\}}")#text(", since the general case will eventuall follow from the trick of replacing the pair ")#mi("{(A,B)}")#text(" by ")#mi("{(A-B,\\{0\\})}")#text(", where ")#mi("{A-B := \\{a-b: a \\in A, b \\in B \\}}")#text(" is the Minkowski difference of ")#mi("{A}")#text(" and ")#mi("{B}")#text(". The remainder of the argument proceeds either by mimicking the usual proof of the Hahn-Banach theorem or by building a norm somehow out of ")#mi("{A-B}")#text(".")

#heading(level: 1)[#strong[#text(" — 5. Appendix: Schwartz functions — ")]]

#text("To facilitate computations we devise some notion regarding bump functions.")

#text("We already have defined a notion of what it means for a function ")#mi("{\\phi}")#text(" to be a bump function adapted to a region such as a ball or an annulus; now we modify the notion to also cover Schwartz functions adapted to similar regions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 35")]#text(" Let ")#mi("{B(x_0,r)}")#text(" be a ball and ")#mi("{H > 0}")#text(". We say that a function ")#mi("{\\psi: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a ")#emph[#text("Schwartz function of height ")#mi("{H}")#text(" adapted to the ball ")#mi("{B(x_0,r)}")]#text(" if we have a representation")

#align(center)[#tao-fit-display[#mitex("\\psi(x) = H \\phi( \\frac{x-x_0}{r} )")]]

#text("for some ")#mi("{\\phi}")#text(" which is boundedly Schwartz in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla_x^k \\phi(x)\\right| \\lesssim_{k,d,N} \\langle x \\rangle^{-N-k}", block: true)]]

#text("for all ")#mi("{k,N \\geq 0}")#text(".")
]

#text("Observe that one may equivalently define a Schwartz function of height ")#mi("{H}")#text(" adapted to ")#mi("{B(x_0,r)}")#text(" to be a function ")#mi("{\\psi}")#text(" which obeys the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla_x^k \\psi(x)\\right| \\lesssim_{k,d,N} H r^{-k} \\langle \\frac{x-x_0}{r} \\rangle^{-N-k}", block: true)]]

#text("for all ")#mi("{k,N \\geq 0}")#text(". Note that any bump function adapted to ")#mi("{B(x_0,r)}")#text(" (or any region similar to ")#mi("{B(x_0,r)}")#text(", such as the annulus ")#tao-math("{\\{ x: \\left|x-x_0\\right| \\sim r \\}}", block: false)#text(" is also a Schwartz function of height ")#mi("{1}")#text(" adapted to ")#mi("{B(x_0,r)}")#text(".")

#text("For Schwartz functions adapted to balls centred at the origin, one can compute their Fourier transform easily:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 36")]#text(" ")#metadata(none) <tao-6314b4304d1d2512df1c>#text(" Let ")#mi("{\\phi}")#text(" be a Schwartz function of height ")#mi("{H}")#text(" adapted to the ball ")#mi("{B(0,r)}")#text(". Then ")#mi("{\\hat \\phi}")#text(" and ")#mi("{\\check \\phi}")#text(" are a Schwartz functions of height ")#mi("{H r^d}")#text(" adapted to the ball ")#mi("{B(0,1/r)}")#text(".")
]

#emph[#text("Proof:")]#text(" We can normalise ")#mi("{H=1}")#text("; by rescaling we can normalise ")#mi("{r=1}")#text(". The claim then follows from the usual proof of the fact that the Fourier transform (or inverse Fourier transform) of a Schwartz function is Schwartz. ")#mi("\\Box")

#text("This allows us to take the Fourier transform of symbols:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 37")]#text(" ")#metadata(none) <tao-f35a2929e8cf4b8066ad>#text(" Let ")#mi("{m: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a Schwartz function which is also a symbol of order ")#mi("{k}")#text(" for some ")#mi("{k > -d}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_\\xi^\\alpha m(\\xi)\\right| \\lesssim_{\\alpha,k,d} \\langle \\xi \\rangle^{k-\\left|\\alpha\\right|}", block: true)]]

#text("for all ")#mi("{\\xi \\in {\\bf R}^d}")#text(" and all multiindices ")#mi("{\\alpha}")#text(". Then ")#mi("{\\check m}")#text(" obeys the dual symbol estimates")

#metadata(none) <tao-d7f890c4f72a3d49b698>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|\\partial_x^\\alpha \\check m(x)\\right| \\lesssim_{\\alpha,k,d,N} \\left|x\\right|^{-d-k-\\left|\\alpha\\right|} \\langle x \\rangle^{-N}", block: true)]]

#text("for all ")#mi("{x \\in {\\bf R}^d}")#text(", all multiindices ")#mi("{\\alpha}")#text(", and all ")#mi("{N \\geq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 38")]#text(" The qualitative hypothesis that ")#mi("{m}")#text(" to be Schwartz is needed to ensure that the inverse Fourier transform of ")#mi("{m}")#text(" makes sense classically. It can be removed, but at the cost of interpreting ")#mi("{\\check m}")#text(" as a distribution rather than as a function (and excluding the origin ")#mi("{x=0}")#text(", which may now be singular).")
]

#emph[#text("Proof:")]#text(" Using smooth dyadic cutoffs we may split")

#align(center)[#tao-fit-display[#mitex("m = m_0 + \\sum_{j=1}^\\infty 2^{jk} m_j")]]

#text("where ")#mi("{m_0}")#text(" is a bump function adapted to the ball ")#tao-math("{\\{ \\left|\\xi\\right| \\leq 1\\}}", block: false)#text(" and each ")#mi("{m_j}")#text(" for ")#mi("{j \\geq 1}")#text(" is a bump function adapted to the annulus ")#tao-math("{\\{ \\left|\\xi\\right| \\sim 2^j \\}}", block: false)#text(". In particular, for each ")#mi("{j \\geq 0}")#text(", ")#mi("{m_j}")#text(" is a Schwartz function of height ")#mi("{1}")#text(" adapted to ")#mi("{B(0,2^j)}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\check m = \\check m_0 + \\sum_{j=1}^\\infty 2^{jk} \\check m_j.")]]

#text("By Lemma ")#link(<tao-6314b4304d1d2512df1c>)[#text("36")]#text(", ")#mi("{\\check m_0}")#text(" is a Schwartz function of height ")#mi("{1}")#text(" adapted to ")#mi("{B(0,1)}")#text(", while ")#mi("{\\check m_j}")#text(" is a Schwartz function of height ")#mi("{2^{dj}}")#text(" adapted to ")#mi("{B(0,2^{-j})}")#text(". On summing we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" ")#metadata(none) <tao-9fc58f1abf0d4f134609>#text(" Establish a partial converse to Lemma ")#link(<tao-f35a2929e8cf4b8066ad>)[#text("37")]#text(": if ")#mi("{m}")#text(" is Schwartz and ")#mi("{\\check m}")#text(" obeys ")#link(<tao-d7f890c4f72a3d49b698>)[#text("(8)")]#text(" with ")#mi("{k < 0}")#text(", then ")#mi("{m}")#text(" is a symbol of order ")#mi("{k}")#text(".")
]
