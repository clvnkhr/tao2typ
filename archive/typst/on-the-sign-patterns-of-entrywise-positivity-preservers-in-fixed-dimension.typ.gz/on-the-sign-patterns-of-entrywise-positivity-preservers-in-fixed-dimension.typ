// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/
// Converted to Typst by tao2typ: "2026-10-14T15:19:55.005565+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the sign patterns of entrywise positivity preservers in fixed dimension", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the sign patterns of entrywise positivity preservers in fixed dimension")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 August 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")[#text("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.iisc.ac.in/~khare/")[#text("Apoorva Khare")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1708.05197")[#text("On the sign patterns of entrywise positivity preservers in fixed dimension")]#text("“. This paper explores the relationship between positive definiteness of Hermitian matrices, and entrywise operations on these matrices. The starting point for this theory is the ")#link("https://en.wikipedia.org/wiki/Schur_product_theorem")[#text("Schur product theorem")]#text(", which asserts that if ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq N}}")#text(" and ")#mi("{B = (b_{ij})_{1 \\leq i,j \\leq N}}")#text(" are two ")#mi("{N \\times N}")#text(" Hermitian matrices that are positive semi-definite, then their ")#link("https://en.wikipedia.org/wiki/Hadamard_product_(matrices)")[#text("Hadamard product")]

#align(center)[#tao-fit-display[#mitex("A \\circ B := (a_{ij} b_{ij})_{1 \\leq i,j \\leq N}")]]

#text("is also positive semi-definite. (One should caution that the Hadamard product is ")#emph[#text("not")]#text(" the same as the usual matrix product.) To prove this theorem, first observe that the claim is easy when ")#mi("{A = {\\bf u} {\\bf u}^*}")#text(" and ")#mi("{B = {\\bf v} {\\bf v}^*}")#text(" are rank one positive semi-definite matrices, since in this case ")#mi("{A \\circ B = ({\\bf u} \\circ {\\bf v}) ({\\bf u} \\circ {\\bf v})^*}")#text(" is also a rank one positive semi-definite matrix. The general case then follows by noting from the spectral theorem that a general positive semi-definite matrix can be expressed as a non-negative linear combination of rank one positive semi-definite matrices, and using the bilinearity of the Hadamard product and the fact that the set of positive semi-definite matrices form a convex cone. A modification of this argument also lets one replace “positive semi-definite” by “positive definite” in the statement of the Schur product theorem.")

#text("One corollary of the Schur product theorem is that any polynomial ")#mi("{P(z) = c_0 + c_1 z + \\dots + c_d z^d}")#text(" with non-negative coefficients ")#mi("{c_n \\geq 0}")#text(" is ")#emph[#text("entrywise positivity preserving")]#text(" on the space ")#mi("{{\\mathbb P}_N({\\bf C})}")#text(" of ")#mi("{N \\times N}")#text(" positive semi-definite Hermitian matrices, in the sense that for any matrix ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq N}}")#text(" in ")#mi("{{\\mathbb P}_N({\\bf C})}")#text(", the entrywise application")

#align(center)[#tao-fit-display[#mitex("P[A] := (P(a_{ij}))_{1 \\leq i,j \\leq N}")]]

#text("of ")#mi("{P}")#text(" to ")#mi("{A}")#text(" is also positive semi-definite. (As before, one should caution that ")#mi("{P[A]}")#text(" is ")#emph[#text("not")]#text(" the application ")#mi("{P(A)}")#text(" of ")#mi("{P}")#text(" to ")#mi("{A}")#text(" by the usual functional calculus.) Indeed, one can expand")

#align(center)[#tao-fit-display[#mitex("P[A] = c_0 A^{\\circ 0} + c_1 A^{\\circ 1} + \\dots + c_d A^{\\circ d},")]]

#text("where ")#mi("{A^{\\circ i}}")#text(" is the Hadamard product of ")#mi("{i}")#text(" copies of ")#mi("{A}")#text(", and the claim now follows from the Schur product theorem and the fact that ")#mi("{{\\mathbb P}_N({\\bf C})}")#text(" is a convex cone.")

#text("A slight variant of this argument, already observed by Pólya and Szegö in 1925, shows that if ")#mi("{I}")#text(" is any subset of ")#mi("{{\\bf C}}")#text(" and ")#metadata(none) <tao-c54bd401aac6d4aea00e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(z) = \\sum_{n=0}^\\infty c_n z^n")]]

#text("is a power series with non-negative coefficients ")#mi("{c_n \\geq 0}")#text(" that is absolutely and uniformly convergent on ")#mi("{I}")#text(", then ")#mi("{f}")#text(" will be entrywise positivity preserving on the set ")#mi("{{\\mathbb P}_N(I)}")#text(" of positive definite matrices with entries in ")#mi("{I}")#text(". (In the case that ")#mi("{I}")#text(" is of the form ")#mi("{I = [0,\\rho]}")#text(", such functions are precisely the ")#link("https://www.encyclopediaofmath.org/index.php/Absolutely_monotonic_function")[#text("absolutely monotonic functions")]#text(" on ")#mi("{I}")#text(".)")

#text("In the work ")#link("http://www.ams.org/mathscinet-getitem?mr=5922")[#text("of Schoenberg")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=109204")[#text("of Rudin")]#text(", we have a converse: if ")#mi("{f: (-1,1) \\rightarrow {\\bf C}}")#text(" is a function that is entrywise positivity preserving on ")#mi("{{\\mathbb P}_N((-1,1))}")#text(" for all ")#mi("{N}")#text(", then it must be of the form ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" with ")#mi("{c_n \\geq 0}")#text(". Variants of this result, with ")#mi("{(-1,1)}")#text(" replaced by other domains, appear in the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=264736")[#text("Horn")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=537245")[#text("Vasudeva")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=3660215")[#text("Guillot-Khare-Rajaratnam")]#text(".")

#text("This gives a satisfactory classification of functions ")#mi("{f}")#text(" that are entrywise positivity preservers in all dimensions ")#mi("{N}")#text(" simultaneously. However, the question remains as to what happens if one fixes the dimension ")#mi("{N}")#text(", in which case one may have a larger class of entrywise positivity preservers. For instance, in the trivial case ")#mi("{N=1}")#text(", a function would be entrywise positivity preserving on ")#mi("{{\\mathbb P}_1((0,\\rho))}")#text(" if and only if ")#mi("{f}")#text(" is non-negative on ")#mi("{I}")#text(". For higher ")#mi("{N}")#text(", there is a necessary condition of ")#link("http://www.ams.org/mathscinet-getitem?mr=264736")[#text("Horn")]#text(" (refined slightly by ")#link("http://www.ams.org/mathscinet-getitem?mr=3660215")[#text("Guillot-Khare-Rajaratnam")]#text(") which asserts (at least in the case of smooth ")#mi("{f}")#text(") that all derivatives of ")#mi("{f}")#text(" at zero up to ")#mi("{(N-1)^{th}}")#text(" order must be non-negative in order for ")#mi("{f}")#text(" to be entrywise positivity preserving on ")#mi("{{\\mathbb P}_N((0,\\rho))}")#text(" for some ")#mi("{0 < \\rho < \\infty}")#text(". In particular, if ")#mi("{f}")#text(" is of the form ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(", then ")#mi("{c_0,\\dots,c_{N-1}}")#text(" must be non-negative. In fact, a stronger assertion can be made, namely that the first ")#mi("{N}")#text(" non-zero coefficients in ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" (if they exist) must be positive, or equivalently any negative term in ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" must be preceded (though not necessarily immediately) by at least ")#mi("{N}")#text(" positive terms. If ")#mi("{f}")#text(" is of the form ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" is entrywise positivity preserving on the larger set ")#mi("{{\\mathbb P}_N((0,+\\infty))}")#text(", one can furthermore show that any negative term in ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" must also be ")#emph[#text("followed")]#text(" (though not necessarily immediately) by at least ")#mi("{N}")#text(" positive terms.")

#text("The main result of this paper is that these sign conditions are the ")#emph[#text("only")]#text(" constraints for entrywise positivity preserving power series. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" For each ")#mi("{n}")#text(", let ")#mi("{\\epsilon_n \\in \\{-1,0,+1\\}}")#text(" be a sign.")

#list(
[#text("Suppose that any negative sign ")#mi("{\\epsilon_M = -1}")#text(" is preceded by at least ")#mi("{N}")#text(" positive signs (thus there exists ")#mi("{0 \\leq n_0 < \\dots < n_{N-1}< M}")#text(" with ")#mi("{\\epsilon_{n_0} = \\dots = \\epsilon_{n_{N-1}} = +1}")#text("). Then, for any ")#mi("{0 < \\rho < \\infty}")#text(", there exists a convergent power series ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" on ")#mi("{(0,\\rho)}")#text(", with each ")#mi("{c_n}")#text(" having the sign of ")#mi("{\\epsilon_n}")#text(", which is entrywise positivity preserving on ")#mi("{{\\bf P}_N((0,\\rho))}")#text(".")],
[#text("Suppose in addition that any negative sign ")#mi("{\\epsilon_M = -1}")#text(" is followed by at least ")#mi("{N}")#text(" positive signs (thus there exists ")#mi("{M < n_N < \\dots < n_{2N-1}}")#text(" with ")#mi("{\\epsilon_{n_N} = \\dots = \\epsilon_{n_{2N-1}} = +1}")#text("). Then there exists a convergent power series ")#link(<tao-c54bd401aac6d4aea00e>)[#text("(1)")]#text(" on ")#mi("{(0,+\\infty)}")#text(", with each ")#mi("{c_n}")#text(" having the sign of ")#mi("{\\epsilon_n}")#text(", which is entrywise positivity preserving on ")#mi("{{\\bf P}_N((0,+\\infty))}")#text(".")]
)
]

#text("One can ask the same question with ")#mi("{(0,\\rho)}")#text(" or ")#mi("{(0,+\\infty)}")#text(" replaced by other domains such as ")#mi("{(-\\rho,\\rho)}")#text(", or the complex disk ")#mi("{D(0,\\rho)}")#text(", but it turns out that there are far fewer entrywise positivity preserving functions in those cases basically because of the non-trivial zeroes of Schur polynomials in these ranges; see the paper for further discussion. We also have some quantitative bounds on how negative some of the coefficients can be compared to the positive coefficients, but they are a bit technical to state here.")

#text("The heart of the proofs of these results is an analysis of the determinants ")#mi("{\\mathrm{det} P[ {\\bf u} {\\bf u}^* ]}")#text(" of polynomials ")#mi("{P}")#text(" applied entrywise to rank one matrices ")#mi("{uu^*}")#text("; the positivity of these determinants can be used (together with a continuity argument) to establish the positive definiteness of ")#mi("{P[uu^*]}")#text(" for various ranges of ")#mi("{P}")#text(" and ")#mi("{u}")#text(". Using the ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Binet_formula")[#text("Cauchy-Binet formula")]#text(", one can rewrite such determinants as linear combinations of squares of magnitudes of generalised Vandermonde determinants")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det}( u_i^{n_j} )_{1 \\leq i,j \\leq N},")]]

#text("where ")#mi("{{\\bf u} = (u_1,\\dots,u_N)}")#text(" and the signs of the coefficients in the linear combination are determined by the signs of the coefficients of ")#mi("{P}")#text(". The task is then to find upper and lower bounds for the magnitudes of such generalised Vandermonde determinants. These determinants oscillate in sign, which makes the problem look difficult; however, an algebraic miracle intervenes, namely the factorisation")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det}( u_i^{n_j} )_{1 \\leq i,j \\leq N} = \\pm V({\\bf u}) s_\\lambda({\\bf u})")]]

#text("of the generalised Vandermonde determinant into the ordinary Vandermonde determinant")

#align(center)[#tao-fit-display[#mitex("V({\\bf u}) = \\prod_{1 \\leq i < j \\leq N} (u_j - u_i)")]]

#text("and a ")#link("https://en.wikipedia.org/wiki/Schur_polynomial")[#text("Schur polynomial")]#text(" ")#mi("{s_\\lambda}")#text(" applied to ")#mi("{{\\bf u}}")#text(", where the weight ")#mi("{\\lambda}")#text(" of the Schur polynomial is determined by ")#mi("{n_1,\\dots,n_N}")#text(" in a simple fashion. The problem then boils down to obtaining upper and lower bounds for these Schur polynomials. Because we are restricting attention to matrices taking values in ")#mi("{(0,\\rho)}")#text(" or ")#mi("{(0,+\\infty)}")#text(", the entries of ")#mi("{{\\bf u}}")#text(" can be taken to be non-negative. One can then take advantage of the ")#emph[#text("total positivity")]#text(" of the Schur polynomials to compare these polynomials with a monomial, at which point one can obtain good criteria for ")#mi("{P[A]}")#text(" to be positive definite when ")#mi("{A}")#text(" is a rank one positive definite matrix ")#mi("{A = {\\bf u} {\\bf u}^*}")#text(".")

#text("If we allow the exponents ")#mi("{n_1,\\dots,n_N}")#text(" to be real numbers rather than integers (thus replacing polynomials or power series by ")#link("https://en.wikipedia.org/wiki/Puiseux_series")[#text("Pusieux series")]#text(" or ")#link("https://en.wikipedia.org/wiki/Hahn_series")[#text("Hahn series")]#text("), then we lose the above algebraic miracle, but we can replace it with a geometric miracle, namely the ")#emph[#text("Harish-Chandra-Itzykson-Zuber identity")]#text(", which I discussed in ")#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/")[#text("this previous blog post")]#text(". This factors the above generalised Vandermonde determinant as the product of the ordinary Vandermonde determinant and an integral of a positive quantity over the orthogonal group, which one can again compare with a monomial after some fairly elementary estimates.")

#text("It remains to understand what happens for more general positive semi-definite matrices ")#mi("{A}")#text(". Here we use a trick of ")#link("http://www.ams.org/mathscinet-getitem?mr=506356")[#text("FitzGerald and Horn")]#text(" to amplify the rank one case to the general case, by expressing a general positive semi-definite matrix ")#mi("{A}")#text(" as a linear combination of a rank one matrix ")#mi("{{\\bf u} {\\bf u}^*}")#text(" and another positive semi-definite matrix ")#mi("{B}")#text(" that vanishes on the last row and column (and is thus effectively a positive definite ")#mi("{N-1 \\times N-1}")#text(" matrix). Using the fundamental theorem of calculus to continuously deform the rank one matrix ")#mi("{{\\bf u} {\\bf u}^*}")#text(" to ")#mi("{A}")#text(" in the direction ")#mi("{B}")#text(", one can then obtain positivity results for ")#mi("{P[A]}")#text(" from positivity results for ")#mi("{P[{\\bf u} {\\bf u}^*]}")#text(" combined with an induction hypothesis on ")#mi("{N}")#text(".")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/474510e798f16b3588270cbb0e65945c1015c28d18fd3b884fd94ceefa52c8e6-3c88ded47a80e0f32936e98535afc2f4ec0fad76b9e13b8d4d0f324a52295e5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larson")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485107")[#strong[#text("Larson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Terry, what do you think of Norbert Blum’s proof that P is not equal to NP? It has recently gained a rather heavy amount of attention and even may be correct. Several people have remarked that it is a far more “sound” attempt than Deolalikar’s. What do you think about it? See ")#link("https://arxiv.org/abs/1708.03486")[#text("https://arxiv.org/abs/1708.03486")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("There are some discussions, including expert commentary, on this paper elsewhere on the internet, for instance over at Luca’s blog ")#link("https://lucatrevisan.wordpress.com/2017/08/15/on-norbert-blums-claimed-proof-that-p-does-not-equal-np/")[#text("https://lucatrevisan.wordpress.com/2017/08/15/on-norbert-blums-claimed-proof-that-p-does-not-equal-np/")]#text(" , or Richard and Ken’s blog ")#link("https://rjlipton.wordpress.com/2017/08/17/on-the-edge-of-eclipses-and-pnp/#comment-83680")[#text("https://rjlipton.wordpress.com/2017/08/17/on-the-edge-of-eclipses-and-pnp/#comment-83680")]#text(" . I myself am happy to wait a few more days for the experts to reach consensus, though I gather from these discussions that there already are some significant concerns with the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("In the paper, is the explicit value given by (3.5) for the threshold ")#mi("\\mathcal K")#text(" in (1.4) the best possible one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485120")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("This is probably not the case in general, because of the presence of Schur polynomials in both the numerator and denominator; but in the special case ")#mi("n_j=j")#text(" then the denominator is trivial and the bounds are indeed sharp, as was observed in the ")#link("https://arxiv.org/abs/1504.07674")[#text("previous paper of Belton et al.")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/256a9db122b972ef8239f4ce5a73b3eda55b4b9080bf7ac4f4e959ec20420924-16ee9033abe91d8ac80db69bdfe6a3f781e4e394ec065d35f390853595973dd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mack")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485138")[#strong[#text("Mack")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Hi Terence,")

#text("maybe this is the wrong blog post to comment this on, but I rushed over to your blog after watching “Terence Tao: Structure and Randomness in the Prime Numbers, UCLA” on youtube. One of the best colloquiums I’ve “attended”.")

#text("After watching it I started thinking about Chen’s theorem.")#linebreak()#text(" Maybe this is a dumb question, but why is Chen’s theorem something that has to be proven? Shouldn’t it be obvious, that there are infinitely many pairs p, p + 2 where p is a prime and p+2 is the product of at most two primes, if there are infinetly many prime numbers? Isn’t Chen’s theorem something that should automatically be included in the infinite amount of primes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a55fa8399e2269a45e253365ac44408318dd04ed5a4d64504443e3b3824a23f0-085a229ea07122a195cbf76167de16cb175aba6c0e2bb968cbd28145c1db93c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thegregmartin")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485144")[#strong[#text("thegregmartin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Mack: Suppose I claim that every prime p larger than 10^1000 has the property that p+2 has at least 14 prime factors. That would contradict Chen’s theorem, right? So if Chen’s theorem is to be true, then my claim would have to be false; and if Chen’s theorem is obvious, then my claim must be obviously false. Do you find my claim obviously false? (not in terms of intuition, but in terms of what can be mathematically justified)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b574cff6a383b5a83eff1a8e0f39e4cda59fefeda2f292fe6c13b558dd1d2ec3-83a16351eb01c4582593cb924d743dc2e5d1d192dda2d1097d126f078eb8f814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rachid Ait-Haddou")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485361")[#strong[#text("Rachid Ait-Haddou")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Dear Terence,")#linebreak()#text(" I very much enjoyed reading the paper. I have the following comments: Using the theory of Chebyshev blossoming in Muntz spaces, one can show that the functions")#linebreak()#text(" ")#mi("\\phi_j({\\bf{u}}) =  \\frac{s_{{\\bf{n_{j}}}}({\\bf{u}})}{s_{{\\bf{n}}}{(\\bf{u})}},\\quad  j=0,1,\\ldots,N-1")#linebreak()#text(" are strictly increasing in each variable ")#mi("u_i")#text(" on ")#mi("(0,\\infty)^{N}")#text(". Using this fact, one ends up with a sharp threshold constant ")#mi("\\mathcal{K}_s")#text(" in Proposition 3.4, i.e.;")#linebreak()#text(" ")#mi("\\mathcal{K}_{s} := \\sum_{j=0}^{N-1} \\frac{V({\\bf{n_{j}}})^2}{c_{j} V({\\bf{n}})^2} \\rho^{M-n_{j}}.")#linebreak()#text(" The constant ")#mi("\\mathcal{K}_{s}")#text(" carries itself well in the inductive arguments with the extension principle. This means that ")#mi("\\mathcal{K}_{s}")#text(" is also a sharp constant in the inequality (1.4). More importantly, blossoming")#linebreak()#text(" in Muntz spaces does not distinguish between integer and real powers. Thus, ")#mi("\\mathcal{K}_{s}")#text(" is also sharp in Theorem 5.12. With this approach, one can avoid the use of the Harish-Chandra-Itzykson-Zuber identity.")#linebreak()#text(" Here are two references on Chebyshebv blossoming in Muntz spaces.")#linebreak()#text(" ")#link("https://link.springer.com/article/10.1007/s10208-016-9334-8")[#text("https://link.springer.com/article/10.1007/s10208-016-9334-8")]#linebreak()#text(" ")#link("http://www.sciencedirect.com/science/article/pii/S0377042713000289")[#text("http://www.sciencedirect.com/science/article/pii/S0377042713000289")]#linebreak()#text(" I hope this help and many thanks for such a great blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485439")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2017")])]

#text("Thank you for pointing out the blossoming approach, Rachid. In fact we have been working on an algebraic approach this past week, to derive the exact constants for tuples of all real powers. Apart from obtaining the sharp bound, it also recovered what you mentioned: the coordinatewise monotonicity of the ratio ")#mi("s_{\\bf m}({\\bf u}) / s_{\\bf n}({\\bf u})")#text(" whenever ")#mi("{\\bf m}")#text(" dominates ")#mi("{\\bf n}")#text(" coordinatewise, and both are tuples of real powers. (By the way, by this I assume you meant the ratio of the generalized Vandermondes.) A third consequence of our new results is an algebraic proof of the Cuttler-Greene-Skandera conjecture, which was shown by Sra (and you Remark a different proof with Mazure), both of these proofs using the Harish-Chandra-Itzykson-Zuber formula. There are also other additions and we will update the preprint shortly. Thanks again, and we’re glad to hear further thoughts from you. Best regards, Apoorva.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Continuous analogues of the Schur and skew Schur polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485923")[#strong[#text("Continuous analogues of the Schur and skew Schur polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")])]

#text("[…] noted that it essentially appears in this paper of Shatashvili; Apoorva Khare and I also used it in this recent paper.) Again we induct on ; the case is trivial, so suppose and the claim has already been proven for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486786")[#strong[#text("An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2017")])]

#text("[…] the sign patterns of entrywise positivity preservers in fixed dimension“, announced at this post from last month. The quantitative results are now sharpened using a new monotonicity property of ratios of Schur […]")
]
