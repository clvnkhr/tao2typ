// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/
// Converted to Typst by tao2typ: "2026-10-14T10:52:15.254099+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Abstracting induction on scales arguments", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Abstracting induction on scales arguments")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 June 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/")[#text("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The following situation is very common in modern harmonic analysis: one has a large scale parameter ")#mi("{N}")#text(" (sometimes written as ")#mi("{N=1/\\delta}")#text(" in the literature for some small scale parameter ")#mi("{\\delta}")#text(", or as ")#mi("{N=R}")#text(" for some large radius ")#mi("{R}")#text("), which ranges over some unbounded subset of ")#mi("{[1,+\\infty)}")#text(" (e.g. all sufficiently large real numbers ")#mi("{N}")#text(", or all powers of two), and one has some positive quantity ")#mi("{D(N)}")#text(" depending on ")#mi("{N}")#text(" that is known to be of ")#emph[#text("polynomial size")]#text(" in the sense that ")#metadata(none) <tao-2e68a8e49fe8b9e6e94c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("C^{-1} N^{-C} \\leq D(N) \\leq C N^C")]]

#text("for all ")#mi("{N}")#text(" in the range and some constant ")#mi("{C>0}")#text(", and one wishes to obtain a ")#emph[#text("subpolynomial upper bound")]#text(" for ")#mi("{D(N)}")#text(", by which we mean an upper bound of the form ")#metadata(none) <tao-d5d7b0f0c4765d2918c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("D(N) \\leq C_\\varepsilon N^\\varepsilon")]]

#text("for all ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{N}")#text(" in the range, where ")#mi("{C_\\varepsilon>0}")#text(" can depend on ")#mi("{\\varepsilon}")#text(" but is independent of ")#mi("{N}")#text(". In many applications, this bound is nearly tight in the sense that one can easily establish a matching lower bound")

#align(center)[#tao-fit-display[#mitex("D(N) \\geq C_\\varepsilon N^{-\\varepsilon}")]]

#text("in which case the property of having a subpolynomial upper bound is equivalent to that of being ")#emph[#text("subpolynomial size")]#text(" in the sense that ")#metadata(none) <tao-778a53154159ac289348>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("C_\\varepsilon N^{-\\varepsilon} \\leq D(N) \\leq C_\\varepsilon N^\\varepsilon")]]

#text("for all ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{N}")#text(" in the range. It would naturally be of interest to tighten these bounds further, for instance to show that ")#mi("{D(N)}")#text(" is polylogarithmic or even bounded in size, but a subpolynomial bound is already sufficient for many applications.")

#text("Let us give some illustrative examples of this type of problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Kakeya conjecture)")]#text(" Here ")#mi("{N}")#text(" ranges over all of ")#mi("{[1,+\\infty)}")#text(". Let ")#mi("{d \\geq 2}")#text(" be a fixed dimension. For each ")#mi("{N \\geq 1}")#text(", we pick a maximal ")#mi("{1/N}")#text("-separated set of directions ")#mi("{\\Omega_N \\subset S^{d-1}}")#text(". We let ")#mi("{D(N)}")#text(" be the smallest constant for which one has the Kakeya inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{\\omega \\in \\Omega_N} 1_{T_\\omega} \\right\\|_{L^{\\frac{d}{d-1}}({\\bf R}^d)} \\leq D(N),", block: true)]]

#text("where ")#mi("{T_\\omega}")#text(" is a ")#mi("{1/N \\times 1}")#text("-tube oriented in the direction ")#mi("{\\omega}")#text(". The ")#link("https://en.wikipedia.org/wiki/Kakeya_set#Kakeya_maximal_function")[#text("Kakeya maximal function conjecture")]#text(" is then equivalent to the assertion that ")#mi("{D(N)}")#text(" has a subpolynomial upper bound (or equivalently, is of subpolynomial size). Currently this is only known in dimension ")#mi("{d=2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Restriction conjecture for the sphere)")]#text(" Here ")#mi("{N}")#text(" ranges over all of ")#mi("{[1,+\\infty)}")#text(". Let ")#mi("{d \\geq 2}")#text(" be a fixed dimension. We let ")#mi("{D(N)}")#text(" be the smallest constant for which one has the restriction inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\widehat{fd\\sigma} \\right\\|_{L^{\\frac{2d}{d-1}}(B(0,N))} \\leq D(N) \\left\\| f \\right\\|_{L^\\infty(S^{d-1})}", block: true)]]

#text("for all bounded measurable functions ")#mi("{f}")#text(" on the unit sphere ")#mi("{S^{d-1}}")#text(" equipped with surface measure ")#mi("{d\\sigma}")#text(", where ")#mi("{B(0,N)}")#text(" is the ball of radius ")#mi("{N}")#text(" centred at the origin. The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=864375")[#text("restriction conjecture")]#text(" of Stein for the sphere is then equivalent to the assertion that ")#mi("{D(N)}")#text(" has a subpolynomial upper bound (or equivalently, is of subpolynomial size). Currently this is only known in dimension ")#mi("{d=2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Multilinear Kakeya inequality)")]#text(" ")#metadata(none) <tao-29a3c59705f35e997400>#text(" Again ")#mi("{N}")#text(" ranges over all of ")#mi("{[1,+\\infty)}")#text(". Let ")#mi("{d \\geq 2}")#text(" be a fixed dimension, and let ")#mi("{S_1,\\dots,S_d}")#text(" be compact subsets of the sphere ")#mi("{S^{d-1}}")#text(" which are ")#emph[#text("transverse")]#text(" in the sense that there is a uniform lower bound ")#tao-math("{\\left|\\omega_1 \\wedge \\dots \\wedge \\omega_d\\right| \\geq c > 0}", block: false)#text(" for the wedge product of directions ")#mi("{\\omega_i \\in S_i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(" (equivalently, there is no hyperplane through the origin that intersects all of the ")#mi("{S_i}")#text("). For each ")#mi("{N \\geq 1}")#text(", we let ")#mi("{D(N)}")#text(" be the smallest constant for which one has the multilinear Kakeya inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathrm{geom} \\sum_{T \\in {\\mathcal T}_i} 1_{T} \\right\\|_{L^{\\frac{d}{d-1}}(B(0,N))} \\leq D(N) \\mathrm{geom} \\# {\\mathcal T}_i,", block: true)]]

#text("where for each ")#mi("{i=1,\\dots,d}")#text(", ")#mi("{{\\mathcal T}_i}")#text(" is a collection of infinite tubes in ")#mi("{{\\bf R}^d}")#text(" of radius ")#mi("{1}")#text(" oriented in a direction in ")#mi("{S_i}")#text(", which are separated in the sense that for any two tubes ")#mi("{T,T^{\\prime}}")#text(" in ")#mi("{{\\mathcal T}_i}")#text(", either the directions of ")#mi("{T,T^{\\prime}}")#text(" differ by an angle of at least ")#mi("{1/N}")#text(", or ")#mi("{T,T^{\\prime}}")#text(" are disjoint; and ")#mi("{\\mathrm{geom} = \\mathrm{geom}_{1 \\leq i \\leq d}}")#text(" is our notation for the geometric mean")

#align(center)[#tao-fit-display[#mitex("\\mathrm{geom} a_i := (a_1 \\dots a_d)^{1/d}.")]]

#text("The multilinear Kakeya inequality of ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("Bennett, Carbery, and myself")]#text(" establishes that ")#mi("{D(N)}")#text(" is of subpolynomial size; a ")#link("http://arxiv.org/abs/0811.2251")[#text("later argument of Guth")]#text(" improves this further by showing that ")#mi("{D(N)}")#text(" is bounded (and in fact comparable to ")#mi("{1}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Multilinear restriction theorem)")]#text(" Once again ")#mi("{N}")#text(" ranges over all of ")#mi("{[1,+\\infty)}")#text(". Let ")#mi("{d \\geq 2}")#text(" be a fixed dimension, and let ")#mi("{S_1,\\dots,S_d}")#text(" be compact subsets of the sphere ")#mi("{S^{d-1}}")#text(" which are ")#emph[#text("transverse")]#text(" as in the previous example. For each ")#mi("{N \\geq 1}")#text(", we let ")#mi("{D(N)}")#text(" be the smallest constant for which one has the multilinear restriction inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathrm{geom} \\widehat{f_id\\sigma} \\right\\|_{L^{\\frac{2d}{d-1}}(B(0,N))} \\leq D(N) \\left\\| f \\right\\|_{L^2(S^{d-1})}", block: true)]]

#text("for all bounded measurable functions ")#mi("{f_i}")#text(" on ")#mi("{S_i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(". Then the multilinear restriction theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("Bennett, Carbery, and myself")]#text(" establishes that ")#mi("{D(N)}")#text(" is of subpolynomial size; it is known to be bounded for ")#mi("{d=2}")#text(" (as can be easily verified from Plancherel’s theorem), but it remains open whether it is bounded for any ")#mi("{d>2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Decoupling for the paraboloid)")]#text(" ")#mi("{N}")#text(" now ranges over the square numbers. Let ")#mi("{d \\geq 2}")#text(", and subdivide the unit cube ")#mi("{[0,1]^{d-1}}")#text(" into ")#mi("{N^{(d-1)/2}}")#text(" cubes ")#mi("{Q}")#text(" of sidelength ")#mi("{1/N^{1/2}}")#text(". For any ")#mi("{g \\in L^1([0,1]^{d-1})}")#text(", define the extension operators")

#align(center)[#tao-fit-display[#tao-math("E_{[0,1]^{d-1}} g( x^{\\prime}, x_d ) := \\int_{[0,1]^{d-1}} e^{2\\pi i (x^{\\prime} \\cdot \\xi + x_d \\left|\\xi\\right|^2)} g(\\xi)\\ d\\xi", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("E_Q g( x^{\\prime}, x_d ) := \\int_{Q} e^{2\\pi i (x^{\\prime} \\cdot \\xi + x_d \\left|\\xi\\right|^2)} g(\\xi)\\ d\\xi", block: true)]]

#text("for ")#mi("{x^{\\prime} \\in {\\bf R}^{d-1}}")#text(" and ")#mi("{x_d \\in {\\bf R}}")#text(". We also introduce the weight function")

#align(center)[#tao-fit-display[#tao-math("w_{B(0,N)}(x) := (1 + \\frac{\\left|x\\right|}{N})^{-100d}.", block: true)]]

#text("For any ")#mi("{p}")#text(", let ")#mi("{D_p(N)}")#text(" be the smallest constant for which one has the decoupling inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| E_{[0,1]^{d-1}} g \\right\\|_{L^p(w_{B(0,N)})} \\leq D_p(N) (\\sum_Q \\left\\| E_Q g \\right\\|_{L^p(w_{B(0,N)})}^2)^{1/2}.", block: true)]]

#text("The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("decoupling theorem of Bourgain and Demeter")]#text(" asserts that ")#mi("{D_p(N)}")#text(" is of subpolynomial size for all ")#mi("{p}")#text(" in the optimal range ")#mi("{2 \\leq p \\leq \\frac{2(d+1)}{d-1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Decoupling for the moment curve)")]#text(" ")#mi("{N}")#text(" now ranges over the natural numbers. Let ")#mi("{d \\geq 2}")#text(", and subdivide ")#mi("{[0,1]}")#text(" into ")#mi("{N}")#text(" intervals ")#mi("{J}")#text(" of length ")#mi("{1/N}")#text(". For any ")#mi("{g \\in L^1([0,1])}")#text(", define the extension operators")

#align(center)[#tao-fit-display[#mitex("E_{[0,1]} g(x_1,\\dots,x_d) = \\int_{[0,1]} e^{2\\pi i ( x_1 \\xi + x_2 \\xi^2 + \\dots + x_d \\xi^d} g(\\xi)\\ d\\xi")]]

#text("and more generally")

#align(center)[#tao-fit-display[#mitex("E_J g(x_1,\\dots,x_d) = \\int_{[0,1]} e^{2\\pi i ( x_1 \\xi + x_2 \\xi^2 + \\dots + x_d \\xi^d} g(\\xi)\\ d\\xi")]]

#text("for ")#mi("{(x_1,\\dots,x_d) \\in {\\bf R}^d}")#text(". For any ")#mi("{p}")#text(", let ")#mi("{D_p(N)}")#text(" be the smallest constant for which one has the decoupling inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| E_{[0,1]} g \\right\\|_{L^p(w_{B(0,N^d)})} \\leq D_p(N) (\\sum_J \\left\\| E_J g \\right\\|_{L^p(w_{B(0,N^d)})}^2)^{1/2}.", block: true)]]

#text("It was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3548534")[#text("by Bourgain, Demeter, and Guth")]#text(" that ")#mi("{D_p(N)}")#text(" is of subpolynomial size for all ")#mi("{p}")#text(" in the optimal range ")#mi("{2 \\leq p \\leq d(d+1)}")#text(", which among other things implies the Vinogradov main conjecture (as discussed in ")#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("this previous post")]#text(").")
]

#text("It is convenient to use asymptotic notation to express these estimates. We write ")#mi("{X \\lesssim Y}")#text(", ")#mi("{X = O(Y)}")#text(", or ")#mi("{Y \\gtrsim X}")#text(" to denote the inequality ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some constant ")#mi("{C}")#text(" independent of the scale parameter ")#mi("{N}")#text(", and write ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\lesssim Y \\lesssim X}")#text(". We write ")#mi("{X = o(Y)}")#text(" to denote a bound of the form ")#tao-math("{\\left|X\\right| \\leq c(N) Y}", block: false)#text(" where ")#mi("{c(N) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" along the given range of ")#mi("{N}")#text(". We then write ")#mi("{X \\lessapprox Y}")#text(" for ")#mi("{X \\lesssim N^{o(1)} Y}")#text(", and ")#mi("{X \\approx Y}")#text(" for ")#mi("{X \\lessapprox Y \\lessapprox X}")#text(". Then the statement that ")#mi("{D(N)}")#text(" is of polynomial size can be written as")

#align(center)[#tao-fit-display[#mitex("D(N) \\sim N^{O(1)},")]]

#text("while the statement that ")#mi("{D(N)}")#text(" has a subpolynomial upper bound can be written as")

#align(center)[#tao-fit-display[#mitex("D(N) \\lessapprox 1")]]

#text("and similarly the statement that ")#mi("{D(N)}")#text(" is of subpolynomial size is simply")

#align(center)[#tao-fit-display[#mitex("D(N) \\approx 1.")]]

#text("Many modern approaches to bounding quantities like ")#mi("{D(N)}")#text(" in harmonic analysis rely on some sort of ")#emph[#text("induction on scales")]#text(" approach in which ")#mi("{D(N)}")#text(" is bounded using quantities such as ")#mi("{D(N^\\theta)}")#text(" for some exponents ")#mi("{0 < \\theta < 1}")#text(". For instance, suppose one is somehow able to establish the inequality ")#metadata(none) <tao-c5654c20d1ef73b81f33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("D(N) \\lessapprox D(\\sqrt{N})")]]

#text("for all ")#mi("{N \\geq 1}")#text(", and suppose that ")#mi("{D}")#text(" is also known to be of polynomial size. Then this implies that ")#mi("{D}")#text(" has a subpolynomial upper bound. Indeed, one can iterate this inequality to show that")

#align(center)[#tao-fit-display[#mitex("D(N) \\lessapprox D(N^{1/2^k})")]]

#text("for any fixed ")#mi("{k}")#text("; using the polynomial size hypothesis one thus has")

#align(center)[#tao-fit-display[#mitex("D(N) \\lessapprox N^{C/2^k}")]]

#text("for some constant ")#mi("{C}")#text(" independent of ")#mi("{k}")#text(". As ")#mi("{k}")#text(" can be arbitrarily large, we conclude that ")#mi("{D(N) \\lesssim N^\\varepsilon}")#text(" for any ")#mi("{\\varepsilon>0}")#text(", and hence ")#mi("{D}")#text(" is of subpolynomial size. (This sort of iteration is used for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("my paper with Bennett and Carbery")]#text(" to derive the multilinear restriction theorem from the multilinear Kakeya theorem.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-571d5b2882b8df135b9f>#text(" If ")#mi("{D}")#text(" is of polynomial size, and obeys the inequality")

#align(center)[#tao-fit-display[#mitex("D(N) \\lessapprox D(N^{1-\\varepsilon}) + N^{O(\\varepsilon)}")]]

#text("for any fixed ")#mi("{\\varepsilon>0}")#text(", where the implied constant in the ")#mi("{O(\\varepsilon)}")#text(" notation is independent of ")#mi("{\\varepsilon}")#text(", show that ")#mi("{D}")#text(" has a subpolynomial upper bound. This type of inequality is used to equate various linear estimates in harmonic analysis with their multilinear counterparts; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1625056")[#text("this paper of myself, Vargas, and Vega")]#text(" for an early example of this method.")
]

#text("In more recent years, more sophisticated induction on scales arguments have emerged in which one or more auxiliary quantities besides ")#mi("{D(N)}")#text(" also come into play. Here is one example, this time being an abstraction of a short proof of the multilinear Kakeya inequality ")#link("https://arxiv.org/abs/1409.4683")[#text("due to Guth")]#text(". Let ")#mi("{D(N)}")#text(" be the quantity in Example ")#link(<tao-29a3c59705f35e997400>)[#text("3")]#text(". We define ")#mi("{D(N,M)}")#text(" similarly to ")#mi("{D(N)}")#text(" for any ")#mi("{M \\geq 1}")#text(", except that we now also require that the diameter of each set ")#mi("{S_i}")#text(" is at most ")#mi("{1/M}")#text(". One can then observe the following estimates:")

#list(
[#text("(Triangle inequality) For any ")#mi("{N,M \\geq 1}")#text(", we have")

#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("D(N,M) = M^{O(1)} D(N).")]]],
[#text("(Multiplicativity) For any ")#mi("{N_1,N_2 = N^{O(1)}}")#text(", one has")

#metadata(none) <tao-c0c75a8e79ad011929e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("D(N_1 N_2, M) \\lessapprox D(N_1, M) D(N_2, M).")]]],
[#text("(Loomis-Whitney inequality) We have")

#metadata(none) <tao-784a2ddf5d4d61b6ae15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("D(N,N) \\lessapprox 1.")]]]
)

#text("These inequalities now imply that ")#mi("{D}")#text(" has a subpolynomial upper bound, as we now demonstrate. Let ")#mi("{k}")#text(" be a large natural number (independent of ")#mi("{N}")#text(") to be chosen later. From many iterations of ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("D(N, N^{1/k}) \\lessapprox D(N^{1/k},N^{1/k})^k")]]

#text("and hence by ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("(7)")]#text(" (with ")#mi("{N}")#text(" replaced by ")#mi("{N^{1/k}}")#text(") and ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]

#align(center)[#tao-fit-display[#mitex("D(N) \\lessapprox N^{O(1/k)}")]]

#text("where the implied constant in the ")#mi("{O(1/k)}")#text(" exponent does not depend on ")#mi("{k}")#text(". As ")#mi("{k}")#text(" can be arbitrarily large, the claim follows. We remark that a nearly identical scheme lets one deduce decoupling estimates for the three-dimensional cone from that of the two-dimensional paraboloid; see the final section of this paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("Bourgain and Demeter")]#text(".")

#text("Now we give a slightly more sophisticated example, abstracted from the proof of ")#mi("{L^p}")#text(" decoupling of the paraboloid by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("Bourgain and Demeter")]#text(", as described in ")#link("https://arxiv.org/abs/1604.06032")[#text("this study guide")]#text(" after specialising the dimension to ")#mi("{2}")#text(" and the exponent ")#mi("{p}")#text(" to the endpoint ")#mi("{p=6}")#text(" (the argument is also more or less summarised in this previous post). (In the cited papers, the argument was phrased only for the non-endpoint case ")#mi("{p<6}")#text(", but it has been observed independently by many experts that the argument extends with only minor modifications to the endpoint ")#mi("{p=6}")#text(".) Here we have a quantity ")#mi("{D_p(N)}")#text(" that we wish to show is of subpolynomial size. For any ")#mi("{0 < \\varepsilon < 1}")#text(" and ")#mi("{0 \\leq u \\leq 1}")#text(", one can define an auxiliary quantity ")#mi("{A_{p,u,\\varepsilon}(N)}")#text(". The precise definitions of ")#mi("{D_p(N)}")#text(" and ")#mi("{A_{p,u,\\varepsilon}(N)}")#text(" are given in the study guide (where they are called ")#mi("{\\mathrm{Dec}_2(1/N,p)}")#text(" and ")#mi("{A_p(u, B(0,N^2), u, g)}")#text(" respectively, setting ")#mi("{\\delta = 1/N}")#text(" and ")#mi("{\\nu = \\delta^\\varepsilon}")#text(") but will not be of importance to us for this discussion. Suffice to say that the following estimates are known:")

#list(
[#text("(Crude upper bound for ")#mi("{D_p}")#text(") ")#mi("{D_p(N)}")#text(" is of polynomial size: ")#mi("{D_p(N) \\sim N^{O(1)}}")#text(".")],
[#text("(Bilinear reduction, using parabolic rescaling) For any ")#mi("{0 \\leq u \\leq 1}")#text(", one has")

#metadata(none) <tao-02250c1f4dcd65f0b9aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("D_p(N) \\lessapprox D_p(N^{1-\\varepsilon}) + N^{O(\\varepsilon)+O(u)} A_{p,u,\\varepsilon}(N).")]]],
[#text("(Crude upper bound for ")#mi("{A_{p,u,\\varepsilon}(N)}")#text(") For any ")#mi("{0 \\leq u \\leq 1}")#text(" one has")

#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)+O(u)} D_p(N)")]]],
[#text("(Application of multilinear Kakeya and ")#mi("{L^2}")#text(" decoupling) If ")#mi("{\\varepsilon, u}")#text(" are sufficiently small (e.g. both less than ")#mi("{1/4}")#text("), then")

#metadata(none) <tao-d8dec8bdfc57587a779f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{p,2u,\\varepsilon}(N)^{1/2} D_p(N^{1-u})^{1/2}.")]]]
)

#text("In all of these bounds the implied constant exponents such as ")#mi("{O(\\varepsilon)}")#text(" or ")#mi("{O(u)}")#text(" are independent of ")#mi("{\\varepsilon}")#text(" and ")#mi("{u}")#text(", although the implied constants in the ")#mi("{\\lessapprox}")#text(" notation can depend on both ")#mi("{\\varepsilon}")#text(" and ")#mi("{u}")#text(". Here we gloss over an annoying technicality in that quantities such as ")#mi("{N^{1-\\varepsilon}}")#text(", ")#mi("{N^{1-u}}")#text(", or ")#mi("{N^u}")#text(" might not be an integer (and might not divide evenly into ")#mi("{N}")#text("), which is needed for the application to decoupling theorems; this can be resolved by restricting the scales involved to powers of two and restricting the values of ")#mi("{\\varepsilon, u}")#text(" to certain rational values, which introduces some complications to the later arguments below which we shall simply ignore as they do not significantly affect the numerology.")

#text("It turns out that these estimates imply that ")#mi("{D_p(N)}")#text(" is of subpolynomial size. We give the argument as follows. As ")#mi("{D_p(N)}")#text(" is known to be of polynomial size, we have some ")#mi("{\\eta>0}")#text(" for which we have the bound ")#metadata(none) <tao-a4c49d5d74f5807deed1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("D_p(N) \\lessapprox N^\\eta")]]

#text("for all ")#mi("{N}")#text(". We can pick ")#mi("{\\eta}")#text(" to be the minimal exponent for which this bound is attained: thus ")#metadata(none) <tao-dd7a946de80abf417970>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\eta = \\limsup_{N \\rightarrow \\infty} \\frac{\\log D_p(N)}{\\log N}.")]]

#text("We will call this the ")#emph[#text("upper exponent")]#text(" of ")#mi("{D_p(N)}")#text(". We need to show that ")#mi("{\\eta \\leq 0}")#text(". We assume for contradiction that ")#mi("{\\eta > 0}")#text(". Let ")#mi("{\\varepsilon>0}")#text(" be a sufficiently small quantity depending on ")#mi("{\\eta}")#text(" to be chosen later. From ")#link(<tao-d8dec8bdfc57587a779f>)[#text("(10)")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{p,2u,\\varepsilon}(N)^{1/2} N^{\\eta (\\frac{1}{2} - \\frac{u}{2})}")]]

#text("for any sufficiently small ")#mi("{u}")#text(". A routine iteration then gives")

#align(center)[#tao-fit-display[#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{p,2^k u,\\varepsilon}(N)^{1/2^k} N^{\\eta (1 - \\frac{1}{2^k} - k\\frac{u}{2})}")]]

#text("for any ")#mi("{k \\geq 1}")#text(" that is independent of ")#mi("{N}")#text(", if ")#mi("{u}")#text(" is sufficiently small depending on ")#mi("{k}")#text(". A key point here is that the implied constant in the exponent ")#mi("{O(\\varepsilon)}")#text(" is uniform in ")#mi("{k}")#text(" (the constant comes from summing a convergent geometric series). We now use the crude bound ")#link(<tao-c3ccedf562d9529001d8>)[#text("(9)")]#text(" followed by ")#link(<tao-a4c49d5d74f5807deed1>)[#text("(11)")]#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{\\eta (1 - k\\frac{u}{2}) + O(\\varepsilon) + O(u)}.")]]

#text("Applying ")#link(<tao-02250c1f4dcd65f0b9aa>)[#text("(8)")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("D_p(N) \\lessapprox N^{\\eta(1-\\varepsilon)} + N^{\\eta (1 - k\\frac{u}{2}) + O(\\varepsilon) + O(u)}.")]]

#text("If we choose ")#mi("{k}")#text(" sufficiently large depending on ")#mi("{\\eta}")#text(" (which was assumed to be positive), then the negative term ")#mi("{-\\eta k \\frac{u}{2}}")#text(" will dominate the ")#mi("{O(u)}")#text(" term. If we then pick ")#mi("{u}")#text(" sufficiently small depending on ")#mi("{k}")#text(", then finally ")#mi("{\\varepsilon}")#text(" sufficiently small depending on all previous quantities, we will obtain ")#mi("{D_p(N) \\lessapprox N^{\\eta^{\\prime}}}")#text(" for some ")#mi("{\\eta^{\\prime}}")#text(" strictly less than ")#mi("{\\eta}")#text(", contradicting the definition of ")#mi("{\\eta}")#text(". Thus ")#mi("{\\eta}")#text(" cannot be positive, and hence ")#mi("{D_p(N)}")#text(" has a subpolynomial upper bound as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-c4d3081467efd2158837>#text(" Show that one still obtains a subpolynomial upper bound if the estimate ")#link(<tao-d8dec8bdfc57587a779f>)[#text("(10)")]#text(" is replaced with")

#align(center)[#tao-fit-display[#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{p,2u,\\varepsilon}(N)^{1-\\theta} D_p(N)^{\\theta}")]]

#text("for some constant ")#mi("{0 \\leq \\theta < 1/2}")#text(", so long as we also improve ")#link(<tao-c3ccedf562d9529001d8>)[#text("(9)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("A_{p,u,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} D_p(N^{1-u}).")]]

#text("(This variant of the argument lets one handle the non-endpoint cases ")#mi("{2 < p < 6}")#text(" of the decoupling theorem for the paraboloid.)")
]

#text("To establish decoupling estimates for the moment curve, restricting to the endpoint case ")#mi("{p = d(d+1)}")#text(" for sake of discussion, an even more sophisticated induction on scales argument was deployed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3548534")[#text("by Bourgain, Demeter, and Guth")]#text(". The proof is discussed in ")#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("this previous blog post")]#text(", but let us just describe an abstract version of the induction on scales argument. To bound the quantity ")#mi("{D_p(N) = D_{d(d+1)}(N)}")#text(", some auxiliary quantities ")#mi("{A_{t,q,s,\\varepsilon}(N)}")#text(" are introduced for various exponents ")#mi("{1 \\leq t \\leq \\infty}")#text(" and ")#mi("{0 \\leq q,s \\leq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(", with the following bounds:")

#list(
[#text("(Crude upper bound for ")#mi("{D}")#text(") ")#mi("{D_p(N)}")#text(" is of polynomial size: ")#mi("{D_p(N) \\sim N^{O(1)}}")#text(".")],
[#text("(Multilinear reduction, using non-isotropic rescaling) For any ")#mi("{0 \\leq q,s \\leq 1}")#text(" and ")#mi("{1 \\leq t \\leq \\infty}")#text(", one has")

#metadata(none) <tao-fc06946d7bdf10af7f32>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("D_p(N) \\lessapprox D_p(N^{1-\\varepsilon}) + N^{O(\\varepsilon)+O(q)+O(s)} A_{t,q,s,\\varepsilon}(N).")]]],
[#text("(Crude upper bound for ")#mi("{A_{t,q,s,\\varepsilon}(N)}")#text(") For any ")#mi("{0 \\leq q,s \\leq 1}")#text(" and ")#mi("{1 \\leq t \\leq \\infty}")#text(" one has")

#metadata(none) <tao-618585debe32f3a5194e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("A_{t,q,s,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)+O(q)+O(s)} D_p(N)")]]],
[#text("(Hölder) For ")#mi("{0 \\leq q, s \\leq 1}")#text(" and ")#mi("{1 \\leq t_0 \\leq t_1 \\leq \\infty}")#text(" one has")

#metadata(none) <tao-eee747155659e77fdd5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("A_{t_0,q,s,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{t_1,q,s,\\varepsilon}(N)")]]

#text("and also")

#metadata(none) <tao-d2e63537d1eb856640d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("A_{t_\\theta,q,s,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{t_0,q,s,\\varepsilon}(N)^{1-\\theta} A_{t_1,q,s,\\varepsilon}(N)^\\theta")]]

#text("whenever ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where ")#mi("{\\frac{1}{t_\\theta} = \\frac{1-\\theta}{t_0} + \\frac{\\theta}{t_1}}")#text(".")],
[#text("(Rescaled decoupling hypothesis) For ")#mi("{0 \\leq q,s \\leq 1}")#text(", one has")

#metadata(none) <tao-bc29a460637eb9f3a6ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("A_{p,q,s,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} D_p(N^{1-q}).")]]],
[#text("(Lower dimensional decoupling) If ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{q \\leq s/k}")#text(", then")

#metadata(none) <tao-8c6fb1e9e37a1aea1d30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("A_{k(k+1),q,s,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{k(k+1),s/k,s,\\varepsilon}(N).")]]],
[#text("(Multilinear Kakeya) If ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{0 \\leq q \\leq 1}")#text(", then")

#metadata(none) <tao-2433e24ae03a1202bfca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("A_{kp/d,q,kq,\\varepsilon}(N) \\lessapprox N^{O(\\varepsilon)} A_{kp/d,q,(k+1)q,\\varepsilon}(N).")]]]
)

#text("It is now substantially less obvious that these estimates can be combined to demonstrate that ")#mi("{D(N)}")#text(" is of subpolynomial size; nevertheless this can be done. A somewhat complicated arrangement of the argument (involving some rather unmotivated choices of expressions to induct over) appears in my ")#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("previous blog post")]#text("; I give an alternate proof later in this post.")

#text("These examples indicate a general strategy to establish that some quantity ")#mi("{D(N)}")#text(" is of subpolynomial size, by")

#list(
[#text("(i) Introducing some family of related auxiliary quantities, often parameterised by several further parameters;")],
[#text("(ii) establishing as many bounds between these quantities and the original quantity ")#mi("{D(N)}")#text(" as possible; and then")],
[#text("(iii) appealing to some sort of “induction on scales” to conclude.")]
)

#text("The first two steps (i), (ii) depend very much on the harmonic analysis nature of the quantities ")#mi("{D(N)}")#text(" and the related auxiliary quantities, and the estimates in (ii) will typically be proven from various harmonic analysis inputs such as Hölder’s inequality, rescaling arguments, decoupling estimates, or Kakeya type estimates. The final step (iii) requires no knowledge of where these quantities come from in harmonic analysis, but the iterations involved can become extremely complicated.")

#text("In this post I would like to observe that one can clean up and made more systematic this final step (iii) by passing to upper exponents ")#link(<tao-dd7a946de80abf417970>)[#text("(12)")]#text(" to eliminate the role of the parameter ")#mi("{N}")#text(" (and also “")#link("https://en.wikipedia.org/wiki/Tropical_geometry")[#text("tropicalising")]#text("” all the estimates), and then taking similar limit superiors to eliminate some other less important parameters, until one is left with a simple linear programming problem (which, among other things, could be amenable to computer-assisted proving techniques). This method is analogous to that of passing to a simpler asymptotic limit object in many other areas of mathematics (for instance using the Furstenberg correspondence principle to pass from a combinatorial problem to an ergodic theory problem, as discussed in ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this previous post")]#text("). We use the limit superior exclusively in this post, but many of the arguments here would also apply with one of the other generalised limit functionals discussed in ")#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")[#text("this previous post")]#text(", such as ultrafilter limits.")

#text("For instance, if ")#mi("{\\eta}")#text(" is the upper exponent of a quantity ")#mi("{D(N)}")#text(" of polynomial size obeying ")#link(<tao-c5654c20d1ef73b81f33>)[#text("(4)")]#text(", then a comparison of the upper exponent of both sides of ")#link(<tao-c5654c20d1ef73b81f33>)[#text("(4)")]#text(" one arrives at the scalar inequality")

#align(center)[#tao-fit-display[#mitex("\\eta \\leq \\frac{1}{2} \\eta")]]

#text("from which it is immediate that ")#mi("{\\eta \\leq 0}")#text(", giving the required subpolynomial upper bound. Notice how the passage to upper exponents converts the ")#mi("{\\lessapprox}")#text(" estimate to a simpler inequality ")#mi("{\\leq}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Repeat Exercise ")#link(<tao-571d5b2882b8df135b9f>)[#text("7")]#text(" using this method.")
]

#text("Similarly, given the quantities ")#mi("{D(N,M)}")#text(" obeying the axioms ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(", ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(6)")]#text(", ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("(7)")]#text(", and assuming that ")#mi("{D(N)}")#text(" is of polynomial size (which is easily verified for the application at hand), we see that for any real numbers ")#mi("{a, u \\geq 0}")#text(", the quantity ")#mi("{D(N^a,N^u)}")#text(" is also of polynomial size and hence has some upper exponent ")#mi("{\\eta(a,u)}")#text("; meanwhile ")#mi("{D(N)}")#text(" itself has some upper exponent ")#mi("{\\eta}")#text(". By reparameterising we have the homogeneity")

#align(center)[#tao-fit-display[#mitex("\\eta(\\lambda a, \\lambda u) = \\lambda \\eta(a,u)")]]

#text("for any ")#mi("{\\lambda \\geq 0}")#text(". Also, comparing the upper exponents of both sides of the axioms ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(5)")]#text(", ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(6)")]#text(", ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("(7)")]#text(" we arrive at the inequalities")

#tao-aligned(keep: true)[


#tao-math("\\eta(1,u)  & = \\eta + O(u)", block: true)



#tao-math("\\eta(a_1+a_2,u)  & \\leq \\eta(a_1,u) + \\eta(a_2,u)", block: true)



#tao-math("\\eta(1,1)  & \\leq 0.", block: true)
]

#text("For any natural number ")#mi("{k}")#text(", the third inequality combined with homogeneity gives ")#mi("{\\eta(1/k,1/k)}")#text(", which when combined with the second inequality gives ")#mi("{\\eta(1,1/k) \\leq k \\eta(1/k,1/k) \\leq 0}")#text(", which on combination with the first estimate gives ")#mi("{\\eta \\leq O(1/k)}")#text(". Sending ")#mi("{k}")#text(" to infinity we obtain ")#mi("{\\eta \\leq 0}")#text(" as required.")

#text("Now suppose that ")#mi("{D_p(N)}")#text(", ")#mi("{A_{p,u,\\varepsilon}(N)}")#text(" obey the axioms ")#link(<tao-02250c1f4dcd65f0b9aa>)[#text("(8)")]#text(", ")#link(<tao-c3ccedf562d9529001d8>)[#text("(9)")]#text(", ")#link(<tao-d8dec8bdfc57587a779f>)[#text("(10)")]#text(". For any fixed ")#mi("{u,\\varepsilon}")#text(", the quantity ")#mi("{A_{p,u,\\varepsilon}(N)}")#text(" is of polynomial size (thanks to ")#link(<tao-c3ccedf562d9529001d8>)[#text("(9)")]#text(" and the polynomial size of ")#mi("{D_6}")#text("), and hence has some upper exponent ")#mi("{\\eta(u,\\varepsilon)}")#text("; similarly ")#mi("{D_p(N)}")#text(" has some upper exponent ")#mi("{\\eta}")#text(". (Actually, strictly speaking our axioms only give an upper bound on ")#mi("{A_{p,u,\\varepsilon}}")#text(" so we have to temporarily admit the possibility that ")#mi("{\\eta(u,\\varepsilon)=-\\infty}")#text(", though this will soon be eliminated anyway.) Taking upper exponents of all the axioms we then conclude that ")#metadata(none) <tao-5c5cb567d5ecc7659992>

#tao-aligned(keep: true)[


#tao-math("\\eta  & \\leq \\max( (1-\\varepsilon) \\eta, \\eta(u,\\varepsilon) + O(\\varepsilon) + O(u) )", block: true, numbering: n => [#text("(20)")])



#tao-math("\\eta(u,\\varepsilon)  & \\leq \\eta + O(\\varepsilon) + O(u)", block: true)



#tao-math("\\eta(u,\\varepsilon)  & \\leq \\frac{1}{2} \\eta(2u,\\varepsilon) + \\frac{1}{2} \\eta (1-u) + O(\\varepsilon)", block: true)
]

#text("for all ")#mi("{0 \\leq u \\leq 1}")#text(" and ")#mi("{0 \\leq \\varepsilon \\leq 1}")#text(".")

#text("Assume for contradiction that ")#mi("{\\eta>0}")#text(", then ")#mi("{(1-\\varepsilon) \\eta < \\eta}")#text(", and so the statement ")#link(<tao-5c5cb567d5ecc7659992>)[#text("(20)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("\\eta \\leq \\eta(u,\\varepsilon) + O(\\varepsilon) + O(u).")]]

#text("At this point we can eliminate the role of ")#mi("{\\varepsilon}")#text(" and simplify the system by taking a second limit superior. If we write")

#align(center)[#tao-fit-display[#mitex("\\eta(u) := \\limsup_{\\varepsilon \\rightarrow 0} \\eta(u,\\varepsilon)")]]

#text("then on taking limit superiors of the previous inequalities we conclude that")

#align(center)[#tao-fit-display[#mitex("\\eta(u) \\leq \\eta + O(u)")]]

#metadata(none) <tao-596bc921dbde5861acff>

#tao-aligned(keep: true)[


#tao-math("\\eta(u)  & \\leq \\frac{1}{2} \\eta(2u) + \\frac{1}{2} \\eta (1-u)", block: true, numbering: n => [#text("(21)")])



#tao-math("\\eta  & \\leq \\eta(u) + O(u)", block: true)
]

#text("for all ")#mi("{u}")#text("; in particular ")#mi("{\\eta(u) = \\eta + O(u)}")#text(". We take advantage of this by taking a further limit superior (or “upper derivative”) in the limit ")#mi("{u \\rightarrow 0}")#text(" to eliminate the role of ")#mi("{u}")#text(" and simplify the system further. If we define")

#align(center)[#tao-fit-display[#mitex("\\alpha := \\limsup_{u \\rightarrow 0^+} \\frac{\\eta(u)-\\eta}{u},")]]

#text("so that ")#mi("{\\alpha}")#text(" is the best constant for which ")#mi("{\\eta(u) \\leq \\eta + \\alpha u + o(u)}")#text(" as ")#mi("{u \\rightarrow 0}")#text(", then ")#mi("{\\alpha}")#text(" is finite, and by inserting this “Taylor expansion” into the right-hand side of ")#link(<tao-596bc921dbde5861acff>)[#text("(21)")]#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\alpha \\leq \\alpha - \\frac{1}{2} \\eta.")]]

#text("This leads to a contradiction when ")#mi("{\\eta>0}")#text(", and hence ")#mi("{\\eta \\leq 0}")#text(" as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-5dfd07da0957be5c120f>#text(" Redo Exercise ")#link(<tao-c4d3081467efd2158837>)[#text("8")]#text(" using this method.")
]

#text("The same strategy now clarifies how to proceed with the more complicated system of quantities ")#mi("{A_{t,q,s,\\varepsilon}(N)}")#text(" obeying the axioms ")#link(<tao-fc06946d7bdf10af7f32>)[#text("(13)")]#text("–")#link(<tao-2433e24ae03a1202bfca>)[#text("(19)")]#text(" with ")#mi("{D_p(N)}")#text(" of polynomial size. Let ")#mi("{\\eta}")#text(" be the exponent of ")#mi("{D_p(N)}")#text(". From ")#link(<tao-618585debe32f3a5194e>)[#text("(14)")]#text(" we see that for fixed ")#mi("{t,q,s,\\varepsilon}")#text(", each ")#mi("{A_{t,q,s,\\varepsilon}(N)}")#text(" is also of polynomial size (at least in upper bound) and so has some exponent ")#mi("{a( t,q,s,\\varepsilon)}")#text(" (which for now we can permit to be ")#mi("{-\\infty}")#text("). Taking upper exponents of all the various axioms we can now eliminate ")#mi("{N}")#text(" and arrive at the simpler axioms")

#tao-aligned(keep: true)[


#tao-math("\\eta  & \\leq \\max( (1-\\varepsilon) \\eta, a(t,q,s,\\varepsilon) + O(\\varepsilon) + O(q) + O(s) )", block: true)



#tao-math("a(t,q,s,\\varepsilon)  & \\leq \\eta + O(\\varepsilon) + O(q) + O(s)", block: true)



#tao-math("a(t_0,q,s,\\varepsilon)  & \\leq a(t_1,q,s,\\varepsilon) + O(\\varepsilon)", block: true)



#tao-math("a(t_\\theta,q,s,\\varepsilon)  & \\leq (1-\\theta) a(t_0,q,s,\\varepsilon) + \\theta a(t_1,q,s,\\varepsilon) + O(\\varepsilon)", block: true)



#tao-math("a(d(d+1),q,s,\\varepsilon)  & \\leq \\eta(1-q) + O(\\varepsilon)", block: true)
]

#text("for all ")#mi("{0 \\leq q,s \\leq 1}")#text(", ")#mi("{1 \\leq t \\leq \\infty}")#text(", ")#mi("{1 \\leq t_0 \\leq t_1 \\leq \\infty}")#text(" and ")#mi("{0 \\leq \\theta \\leq 1}")#text(", with the lower dimensional decoupling inequality")

#align(center)[#tao-fit-display[#mitex("a(k(k+1),q,s,\\varepsilon) \\leq a(k(k+1),s/k,s,\\varepsilon) + O(\\varepsilon)")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{q \\leq s/k}")#text(", and the multilinear Kakeya inequality")

#align(center)[#tao-fit-display[#mitex("a(k(d+1),q,kq,\\varepsilon) \\leq a(k(d+1),q,(k+1)q,\\varepsilon)")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{0 \\leq q \\leq 1}")#text(".")

#text("As before, if we assume for sake of contradiction that ")#mi("{\\eta>0}")#text(" then the first inequality simplifies to")

#align(center)[#tao-fit-display[#mitex("\\eta \\leq a(t,q,s,\\varepsilon) + O(\\varepsilon) + O(q) + O(s).")]]

#text("We can then again eliminate the role of ")#mi("{\\varepsilon}")#text(" by taking a second limit superior as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", introducing")

#align(center)[#tao-fit-display[#mitex("a(t,q,s) := \\limsup_{\\varepsilon \\rightarrow 0} a(t,q,s,\\varepsilon)")]]

#text("and thus getting the simplified axiom system ")#metadata(none) <tao-71848bc79dcd1d5edc80>

#tao-aligned(keep: true)[


#tao-math("a(t,q,s)  & \\leq \\eta + O(q) + O(s)", block: true, numbering: n => [#text("(22)")])



#tao-math("a(t_0,q,s)  & \\leq a(t_1,q,s)", block: true)



#tao-math("a(t_\\theta,q,s)  & \\leq (1-\\theta) a(t_0,q,s) + \\theta a(t_1,q,s)", block: true)



#tao-math("a(d(d+1),q,s)  & \\leq \\eta(1-q)", block: true)
]

#metadata(none) <tao-27949fb9a831ffc90e3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\eta \\leq a(t,q,s) + O(q) + O(s)")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("a(k(k+1),q,s) \\leq a(k(k+1),s/k,s)")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{q \\leq s/k}")#text(", and")

#align(center)[#tao-fit-display[#mitex("a(k(d+1),q,kq) \\leq a(k(d+1),q,(k+1)q)")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{0 \\leq q \\leq 1}")#text(".")

#text("In view of the latter two estimates it is natural to restrict attention to the quantities ")#mi("{a(t,q,kq)}")#text(" for ")#mi("{1 \\leq k \\leq d+1}")#text(". By the axioms ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(22)")]#text(", these quantities are of the form ")#mi("{\\eta + O(q)}")#text(". We can then eliminate the role of ")#mi("{q}")#text(" by taking another limit superior")

#align(center)[#tao-fit-display[#mitex("\\alpha_k(t) := \\limsup_{q \\rightarrow 0} \\frac{a(t,q,kq)-\\eta}{q}.")]]

#text("The axioms now simplify to")

#align(center)[#tao-fit-display[#mitex("\\alpha_k(t) = O(1)")]]

#metadata(none) <tao-3adfd128fcec6f53cb7c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\alpha_k(t_0) \\leq \\alpha_k(t_1)")]]

#metadata(none) <tao-3eaeb2c2d355cbc8d4b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\alpha_k(t_\\theta) \\leq (1-\\theta) \\alpha_k(t_0) + \\theta \\alpha_k(t_1)")]]

#metadata(none) <tao-b1d6b91b67c2afa5e322>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\alpha_k(d(d+1)) \\leq -\\eta")]]

#text("and ")#metadata(none) <tao-31b25869b39f1baa9e7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\alpha_j(k(k+1)) \\leq \\frac{j}{k} \\alpha_k(k(k+1))")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(" and ")#mi("{k \\leq j \\leq d}")#text(", and ")#metadata(none) <tao-7f093592aebbb47767b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\alpha_k(k(d+1)) \\leq \\alpha_{k+1}(k(d+1))")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(".")

#text("It turns out that the inequality ")#link(<tao-31b25869b39f1baa9e7f>)[#text("(27)")]#text(" is strongest when ")#mi("{j=k+1}")#text(", thus ")#metadata(none) <tao-7a7db4726ec27397cbbd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\alpha_{k+1}(k(k+1)) \\leq \\frac{k+1}{k} \\alpha_k(k(k+1))")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(".")

#text("From the last two inequalities ")#link(<tao-7f093592aebbb47767b5>)[#text("(28)")]#text(", ")#link(<tao-7a7db4726ec27397cbbd>)[#text("(29)")]#text(" we see that a special role is likely to be played by the exponents")

#align(center)[#tao-fit-display[#mitex("\\beta_k := \\alpha_k(k(k-1))")]]

#text("for ")#mi("{2 \\leq k \\leq d}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\gamma_k := \\alpha_k(k(d+1))")]]

#text("for ")#mi("{1 \\leq k \\leq d}")#text(". From the convexity ")#link(<tao-3eaeb2c2d355cbc8d4b9>)[#text("(25)")]#text(" and a brief calculation we have")

#tao-aligned(keep: true)[


#tao-math("\\alpha_{k+1}(k(d+1))  & \\leq \\frac{1}{d-k+1} \\alpha_{k+1}(k(k+1))", block: true)



#tao-math(" & + \\frac{d-k}{d-k+1} \\alpha_{k+1}((k+1)(d+1)),", block: true)
]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(", hence from ")#link(<tao-7f093592aebbb47767b5>)[#text("(28)")]#text(" we have ")#metadata(none) <tao-981f4e620f014826311b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\gamma_k \\leq \\frac{1}{d-k+1} \\beta_{k+1} + \\frac{d-k}{d-k+1} \\gamma_{k+1}.")]]

#text("Similarly, from ")#link(<tao-3eaeb2c2d355cbc8d4b9>)[#text("(25)")]#text(" and a brief calculation we have")

#tao-aligned(keep: true)[


#tao-math("\\alpha_k(k(k+1))  & \\leq \\frac{(d-k)(k-1)}{(k+1)(d-k+2)} \\alpha_k( k(k-1))", block: true)



#tao-math(" & + \\frac{2(d+1)}{(k+1)(d-k+2)} \\alpha_k(k(d+1))", block: true)
]

#text("for ")#mi("{2 \\leq k \\leq d-1}")#text("; the same bound holds for ")#mi("{k=1}")#text(" if we drop the term with the ")#mi("{(k-1)}")#text(" factor, thanks to ")#link(<tao-3adfd128fcec6f53cb7c>)[#text("(24)")]#text(". Thus from ")#link(<tao-7a7db4726ec27397cbbd>)[#text("(29)")]#text(" we have ")#metadata(none) <tao-0ae467cc10e077a17e83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\beta_{k+1} \\leq \\frac{(d-k)(k-1)}{k(d-k+2)} \\beta_k + \\frac{2(d+1)}{k(d-k+2)} \\gamma_k,")]]

#text("for ")#mi("{1 \\leq k \\leq d-1}")#text(", again with the understanding that we omit the first term on the right-hand side when ")#mi("{k=1}")#text(". Finally, ")#link(<tao-b1d6b91b67c2afa5e322>)[#text("(26)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\gamma_d \\leq -\\eta.")]]

#text("Let us write out the system of equations we have obtained in full: ")#metadata(none) <tao-d6c7dc5b78cc668137cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\beta_2 \\leq 2 \\gamma_1")]]

#metadata(none) <tao-74cf9225fac68b257f93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\gamma_1 \\leq \\frac{1}{d} \\beta_2 + \\frac{d-1}{d} \\gamma_2")]]

#metadata(none) <tao-aea721c039a808c24a14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\beta_3 \\leq \\frac{d-2}{2d} \\beta_2 + \\frac{2(d+1)}{2d} \\gamma_2")]]

#metadata(none) <tao-ef8bac211815808744c6>

#tao-aligned(keep: true)[


#tao-math("\\gamma_2  & \\leq \\frac{1}{d-1} \\beta_3 + \\frac{d-2}{d-1} \\gamma_3", block: true, numbering: n => [#text("(35)")])



#tao-math("\\beta_4  & \\leq \\frac{2(d-3)}{3(d-1)} \\beta_3 + \\frac{2(d+1)}{3(d-1)} \\gamma_3", block: true)



#tao-math("\\gamma_3  & \\leq \\frac{1}{d-2} \\beta_4 + \\frac{d-3}{d-2} \\gamma_4", block: true)
]

#align(center)[#tao-fit-display[#mitex("...")]]

#align(center)[#tao-fit-display[#mitex("\\beta_d \\leq \\frac{d-2}{(d-1) 3} \\beta_{d-1} + \\frac{2(d+1)}{(d-1) 3} \\gamma_{d-1}")]]

#metadata(none) <tao-29ab268f7aba55d260b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\gamma_{d-1} \\leq \\frac{1}{2} \\beta_d + \\frac{1}{2} \\gamma_d")]]

#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\gamma_d \\leq -\\eta.")]]

#text("We can then eliminate the variables one by one. Inserting ")#link(<tao-74cf9225fac68b257f93>)[#text("(33)")]#text(" into ")#link(<tao-d6c7dc5b78cc668137cf>)[#text("(32)")]#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\beta_2 \\leq \\frac{2}{d} \\beta_2 + \\frac{2(d-1)}{d} \\gamma_2")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\beta_2 \\leq \\frac{2(d-1)}{d-2} \\gamma_2.")]]

#text("Inserting this into ")#link(<tao-aea721c039a808c24a14>)[#text("(34)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\beta_3 \\leq 2 \\gamma_2")]]

#text("which when combined with ")#link(<tao-ef8bac211815808744c6>)[#text("(35)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\beta_3 \\leq \\frac{2}{d-1} \\beta_3 + \\frac{2(d-2)}{d-1} \\gamma_3")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\beta_3 \\leq \\frac{2(d-2)}{d-3} \\gamma_3.")]]

#text("Iterating this we get")

#align(center)[#tao-fit-display[#mitex("\\beta_{k+1} \\leq 2 \\gamma_k")]]

#text("for all ")#mi("{1 \\leq k \\leq d-1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\beta_k \\leq \\frac{2(d-k+1)}{d-k} \\gamma_k")]]

#text("for all ")#mi("{2 \\leq k \\leq d-1}")#text(". In particular")

#align(center)[#tao-fit-display[#mitex("\\beta_d \\leq 2 \\gamma_{d-1}")]]

#text("which on insertion into ")#link(<tao-29ab268f7aba55d260b2>)[#text("(36)")]#text(", ")#link(<tao-e81935fb86434cdaaeee>)[#text("(37)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\beta_d \\leq \\beta_d - \\eta")]]

#text("which is absurd if ")#mi("{\\eta>0}")#text(". Thus ")#mi("{\\eta \\leq 0}")#text(" and so ")#mi("{D_p(N)}")#text(" must be of subpolynomial growth.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" (This observation is essentially ")#link("https://arxiv.org/abs/1512.03272")[#text("due to Heath-Brown")]#text(".) If we let ")#mi("{x}")#text(" denote the column vector with entries ")#mi("{\\beta_2,\\dots,\\beta_d,\\gamma_1,\\dots,\\gamma_{d-1}}")#text(" (arranged in whatever order one pleases), then the above system of inequalities ")#link(<tao-d6c7dc5b78cc668137cf>)[#text("(32)")]#text("–")#link(<tao-29ab268f7aba55d260b2>)[#text("(36)")]#text(" (using ")#link(<tao-e81935fb86434cdaaeee>)[#text("(37)")]#text(" to handle the appearance of ")#mi("{\\gamma_d}")#text(" in ")#link(<tao-29ab268f7aba55d260b2>)[#text("(36)")]#text(") reads ")#metadata(none) <tao-792525db00993809e3a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("x \\leq Px + \\eta v")]]

#text("for some explicit square matrix ")#mi("{P}")#text(" with non-negative coefficients, where the inequality denotes pointwise domination, and ")#mi("{v}")#text(" is an explicit vector with non-positive coefficients that reflects the effect of ")#link(<tao-e81935fb86434cdaaeee>)[#text("(37)")]#text(". It is possible to show (using ")#link(<tao-3adfd128fcec6f53cb7c>)[#text("(24)")]#text(", ")#link(<tao-b1d6b91b67c2afa5e322>)[#text("(26)")]#text(") that all the coefficients of ")#mi("{x}")#text(" are negative (assuming the counterfactual situation ")#mi("{\\eta>0}")#text(" of course). Then we can iterate this to obtain")

#align(center)[#tao-fit-display[#mitex("x \\leq P^k x + \\eta \\sum_{j=0}^{k-1} P^j v")]]

#text("for any natural number ")#mi("{k}")#text(". This would lead to an immediate contradiction if the ")#link("https://en.wikipedia.org/wiki/Perron%E2%80%93Frobenius_theorem")[#text("Perron-Frobenius eigenvalue")]#text(" of ")#mi("{P}")#text(" exceeds ")#mi("{1}")#text(" because ")#mi("{P^k x}")#text(" would now grow exponentially; this is typically the situation for “non-endpoint” applications such as proving decoupling inequalities away from the endpoint. In the endpoint situation discussed above, the Perron-Frobenius eigenvalue is ")#mi("{1}")#text(", with ")#mi("{v}")#text(" having a non-trivial projection to this eigenspace, so the sum ")#mi("{\\sum_{j=0}^{k-1} \\eta P^j v}")#text(" now grows at least linearly, which still gives the required contradiction for any ")#mi("{\\eta>0}")#text(". So it is important to gather “enough” inequalities so that the relevant matrix ")#mi("{P}")#text(" has a Perron-Frobenius eigenvalue greater than or equal to ")#mi("{1}")#text(" (and in the latter case one needs non-trivial injection of an induction hypothesis into an eigenspace corresponding to an eigenvalue ")#mi("{1}")#text("). More specifically, if ")#mi("{\\rho}")#text(" is the spectral radius of ")#mi("{P}")#text(" and ")#mi("{w^T}")#text(" is a left Perron-Frobenius eigenvector, that is to say a non-negative vector, not identically zero, such that ")#mi("{w^T P = \\rho w^T}")#text(", then by taking inner products of ")#link(<tao-792525db00993809e3a3>)[#text("(38)")]#text(" with ")#mi("{w}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("w^T x \\leq \\rho w^T x + \\eta w^T v.")]]

#text("If ")#mi("{\\rho > 1}")#text(" this leads to a contradiction since ")#mi("{w^T x}")#text(" is negative and ")#mi("{w^T v}")#text(" is non-positive. When ")#mi("{\\rho = 1}")#text(" one still gets a contradiction as long as ")#mi("{w^T v}")#text(" is strictly negative.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" (This calculation is essentially ")#link("https://arxiv.org/abs/1811.02207")[#text("due to Guo and Zorin-Kranich")]#text(".) Here is a concrete application of the Perron-Frobenius strategy outlined above to the system of inequalities ")#link(<tao-d6c7dc5b78cc668137cf>)[#text("(32)")]#text("–")#link(<tao-e81935fb86434cdaaeee>)[#text("(37)")]#text(". Consider the weighted sum")

#align(center)[#tao-fit-display[#mitex("W := \\sum_{k=2}^d (k-1) \\beta_k + \\sum_{k=1}^{d-1} 2k \\gamma_k;")]]

#text("I had secretly calculated the weights ")#mi("{k-1}")#text(", ")#mi("{2k}")#text(" as coming from the left Perron-Frobenius eigenvector of the matrix ")#mi("{P}")#text(" described in the previous remark, but for this calculation the precise provenance of the weights is not relevant. Applying the inequalities ")#link(<tao-0ae467cc10e077a17e83>)[#text("(31)")]#text(", ")#link(<tao-981f4e620f014826311b>)[#text("(30)")]#text(" we see that ")#mi("{W}")#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=2}^d (k-1) (\\frac{(d-k+1)(k-2)}{(k-1)(d-k+3)} \\beta_{k-1} + \\frac{2(d+1)}{(k-1)(d-k+3)} \\gamma_{k-1})")]]

#align(center)[#tao-fit-display[#mitex("+ \\sum_{k=1}^{d-1} 2k(\\frac{1}{d-k+1} \\beta_{k+1} + \\frac{d-k}{d-k+1} \\gamma_{k+1})")]]

#text("(with the convention that the ")#mi("{\\beta_1}")#text(" term is absent); this simplifies after some calculation to the bound")

#align(center)[#tao-fit-display[#mitex("W \\leq W + \\frac{1}{2} \\gamma_d")]]

#text("and this and ")#link(<tao-e81935fb86434cdaaeee>)[#text("(37)")]#text(" then leads to the required contradiction.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]

#list(
[#text("(i) Extend the above analysis to also cover the non-endpoint case ")#mi("{d^2 < p < d(d+1)}")#text(". (One will need to establish the claim ")#mi("{\\alpha_k(t) \\leq -\\eta}")#text(" for ")#mi("{t \\leq p}")#text(".)")],
[#text("(ii) Modify the argument to deal with the remaining cases ")#mi("{2 < p \\leq d^2}")#text(" by dropping some of the steps.")]
)
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517395")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("The matching lower bound inequality (2.5) is in the wrong way.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/300777f711cb8913205ffa75e29b7705ee72ffa613c5b30636a3f520c1b54277-aaa5bc3653389049e2a95acafd312d3d56df680b72c5e42691bad8e314556875.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of None")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517397")[#strong[#text("None")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("The inequality in (7) seems a bit confusing to me, is the implicit constant a eps power of M instead of N?")

#emph[#text("[Reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517405")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2019")])]

#text("This reminds me of section 4 of Heath brown’s exposition of Wooley’s proof of the cubic case of efficient congruencing in Vinogradov’s mean value theorem")

#link("https://arxiv.org/pdf/1512.03272.pdf")[#text("Click to access 1512.03272.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2019")])]

#text("Thanks for pointing this out! In particular Heath-Brown’s observation clarifies exactly when the iteration is “strong enough” to get subpolynomial bounds – one needs the coefficient matrix of the bounds to have an eigenvalue that either exceeds one in magnitude (in which case the iteration grows exponentially), or equals one but has a nontrivial additive component coming from the induction hypothesis (in which case the iteration grows polynomially). I’ve added a remark to this effect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fe2c3c23dae4eaabbd6f4b31aec2928ef4463c6f8c94967b1253ca36fcf5d2d-d9ba291ec1db405aad3f7589751e6c814d37bbfa5ce4b936be8599abcae1c9fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pavel Zorin-Kranich")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517420")[#strong[#text("Pavel Zorin-Kranich")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2019")])]

#text("For the Bourgain-Demeter-Guth iteration we computed the (right) Perron-Frobenius eigenvector of the matrix of bounds in a paper with Shaoming Guo, see Theorem 3.22 in")#linebreak()#text(" ")#link("https://arxiv.org/abs/1811.02207v1")[#text("https://arxiv.org/abs/1811.02207v1")]#linebreak()#text(" We also found that making this calculation explicit shortens the argument substantially.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517449")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2019")])]

#text("Thanks for this! I have added a version of your calculation as an additional remark to the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/887c077a1c72a53aa12ae4ab297ba4fda9489c344a6aa86f4cc39f2f03e99f52-e40359e769dbeb31d6f90fb861dd32ba9802d69ff97a043d236e2b3b237669a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trevor Wooley")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517598")[#strong[#text("Trevor Wooley")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2019")])]

#text("This observation that the eigen value should be at least 1 in order to establish the necessary exponential or logarithmic growth required to prove diagonal behaviour in Vinogradov’s mean value theorem also occurs in my own work establishing the cubic case of the main conjecture (arxiv:1401.3150, so January 2014) — this was the paper that Heath-Brown sought to simplify in his own exposition of December 2015. The observation is also critical to my slightly early paper (arxiv:1401.2932) “almost” proving the main conjecture in Vinogradov’s mean value theorem for all degrees, and also in the proof of the main conjecture via nested efficient congruencing. These are all p-adic methods using induction on scales of course, as opposed to real methods (corresponding to p equals infinity).")

#text("Incidentally, the first use of different real scales in this subject is due to Vinogradov himself in 1935 in his early work on his mean value theorem, though I suppose this can be traced even to work a decade earlier of Hardy and Littlewood on Waring’s problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2019")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Within the 100 years, no mathematician in the world has been expected and inspired like you. You are liked a light of the antique oil lighter, if the light is out, the spirit of math community will be down. We hope you have many progress in attacking problems which have not been solved in many decades yet. In sum, we have some words that sent to you:” Time is gold” . You will understand our idea, because you are very smart.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c322411af18dfc4b538d4fa60309cc445e0462c6061fbc43a998950f353a2c8-4ebcba8384665a4b60ea5eb3d2c85fb96120fa276264aafad6006727ae2fcb65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517470")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2019")])]

#text("really enjoy your article and books")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d40e1bf8cbf44df0e0be7cf23579618c0812ea5f79233c0ea0f3864348607c-9e0e71ca8541d33415e99c01837f9e2cb8a0e97d041464280dd2ad72fece7121.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517805")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2019")])]

#text("You are still smart. While I am unemployed for a long long time, and I fell I’m getting more and more stupid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/#comment-517810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2019")])]

#text("C’mon, mate! Cheer up! And please find something to laugh or smile about. And best wishes to you. :-)")
]
]
