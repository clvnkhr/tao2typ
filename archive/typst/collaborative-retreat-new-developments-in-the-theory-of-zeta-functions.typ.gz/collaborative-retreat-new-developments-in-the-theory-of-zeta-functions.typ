// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/30/collaborative-retreat-new-developments-in-the-theory-of-zeta-functions/
// Converted to Typst by tao2typ: "2026-11-02T16:20:30.117050+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Collaborative retreat: New developments in the theory of zeta functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Collaborative retreat: New developments in the theory of zeta functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/30/collaborative-retreat-new-developments-in-the-theory-of-zeta-functions/")[#text("https://terrytao.wordpress.com/2026/10/30/collaborative-retreat-new-developments-in-the-theory-of-zeta-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-02 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://www.math.uni-bonn.de/people/assing/")[#text("Edgar Assing")]#text(", ")#link("https://www.math.uni-bonn.de/people/blomer/")[#text("Valentin Blomer")]#text(", and ")#link("https://webusers.imj-prg.fr/~farrell.brumley/")[#text("Farrell Brumley")]#text(" are ")#link("https://math-events.uni-bonn.de/event/1660/")[#text("organizing an event at the Hausdorff Center in Bonn")]#text(" on Jan 11-15 to discuss recent developments regarding the Riemann zeta function and allied functions. From the announcement: “This includes in particular the recently established proof of the quasi Riemann Hypothesis over the rational numbers as well as over general number fields and its manifold consequences, ranging from Artin’s primitive root conjecture and torsion in class groups to equidistribution of periodic torus orbits of higher degree fields.")

#text("The target group are early career researchers with an excellent background in analytic number theory. The collaborative retreat will feature lectures by the organizers as well as exercise sessions and projects in small workgroups in the stimulating atmosphere of the Hausdorff Institute.”")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/30/collaborative-retreat-new-developments-in-the-theory-of-zeta-functions/comment-page-1/#comment-698993")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("This is a great event. Is it open for any one interest in the subject!")
]
