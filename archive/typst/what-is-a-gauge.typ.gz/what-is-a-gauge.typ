// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/
// Converted to Typst by tao2typ: "2026-10-14T16:35:24.923604+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What is a gauge?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What is a gauge?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 September 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("“")#link("http://en.wikipedia.org/wiki/Gauge_theory")[#text("Gauge theory")]#text("” is a term which has connotations of being a fearsomely complicated part of mathematics – for instance, playing an important role in quantum field theory, general relativity, geometric PDE, and so forth. But the underlying concept is really quite simple: a ")#emph[#text("gauge")]#text(" is nothing more than a “coordinate system” that varies depending on one’s “location” with respect to some “base space” or “parameter space”, a ")#emph[#text("gauge transform")]#text(" is a change of coordinates applied to each such location, and a ")#emph[#text("gauge theory")]#text(" is a model for some physical or mathematical system to which gauge transforms can be applied (and is typically ")#emph[#text("gauge invariant")]#text(", in that all physically meaningful quantities are left unchanged (or transform naturally) under gauge transformations). By ")#link("http://en.wikipedia.org/wiki/Gauge_fixing")[#emph[#text("fixing")]]#text(" a gauge (thus ")#emph[#text("breaking")]#text(" or ")#emph[#text("spending")]#text(" the gauge symmetry), the model becomes something easier to analyse mathematically, such as a system of partial differential equations (in classical gauge theories) or a perturbative quantum field theory (in quantum gauge theories), though the tractability of the resulting problem can be heavily dependent on the choice of gauge that one fixed. Deciding exactly how to fix a gauge (or whether one should spend the gauge symmetry at all) is a key question in the analysis of gauge theories, and one that often requires the input of geometric ideas and intuition into that analysis.")

#text("I was asked recently to explain what a gauge theory was, and so I will try to do so in this post. For simplicity, I will focus exclusively on classical gauge theories; quantum gauge theories are the quantization of classical gauge theories and have their own set of conceptual difficulties (coming from quantum field theory) that I will not discuss here. While gauge theories originated from physics, I will not discuss the physical significance of these theories much here, instead focusing just on their mathematical aspects. My discussion will be informal, as I want to try to convey the geometric intuition rather than the rigorous formalism (which can, of course, be found in any graduate text on differential geometry).")

#metadata(none) <tao-305097454dfea3b449b0>

#heading(level: 1)[#text("— Coordinate systems —")]

#text("Before I discuss gauges, I first review the more familiar concept of a ")#emph[#text("coordinate system")]#text(", which is basically the special case of a gauge when the base space (or parameter space) is trivial.")

#text("Classical mathematics, such as practised by the ancient Greeks, could be loosely divided into two disciplines, ")#emph[#text("geometry")]#text(" and ")#emph[#text("number theory")]#text(", where I use the latter term very broadly, to encompass all sorts of mathematics dealing with any sort of number. The two disciplines are unified by the concept of a ")#emph[#text("coordinate system")]#text(", which allows one to convert geometric objects to numeric ones or vice versa. The most well known example of a coordinate system is the ")#link("http://en.wikipedia.org/wiki/Cartesian_coordinate_system")[#text("Cartesian coordinate system")]#text(" for the plane (or more generally for a Euclidean space), but this is just one example of many such systems. For instance:")

#enum(start: 1, 
[#text("One can convert a length (of, say, an interval) into an (unsigned) real number, or vice versa, once one fixes a unit of length (e.g. the metre or the foot). In this case, the coordinate system is specified by the choice of length unit.")],
[#text("One can convert a ")#link("http://en.wikipedia.org/wiki/Displacement_(vector)")[#text("displacement")]#text(" along a line into a (signed) real number, or vice versa, once one fixes a unit of length ")#emph[#text("and")]#text(" an orientation along that line. In this case, the coordinate system is specified by the length unit together with the choice of orientation. Alternatively, one can replace the unit of length and the orientation by a unit displacement vector ")#mi("e")#text(" along the line.")],
[#text("One can convert a position (i.e. a point) on a line into a real number, or vice versa, once one fixes a unit of length, an orientation along the line, ")#emph[#text("and")]#text(" an origin on that line. Equivalently, one can pick an origin ")#mi("O")#text(" and a unit displacement vector ")#mi("e")#text(". This coordinate system essentially identifies the original line with the standard real line ")#mi("{\\Bbb R}")#text(".")],
[#text("One can generalise these systems to higher dimensions. For instance, one can convert a displacement along a plane into a vector in ")#mi("{\\Bbb R}^2")#text(", or vice versa, once one fixes two linearly independent displacement vectors ")#mi("e_1, e_2")#text(" (i.e. a basis) to span that plane; the Cartesian coordinate system is just one special case of this general scheme. Similarly, one can convert a position on a plane to a vector in ")#mi("{\\Bbb R}^2")#text(" once one picks a basis ")#mi("e_1, e_2")#text(" for that plane as well as an origin ")#mi("O")#text(", thus identifying that plane with the standard Euclidean plane ")#mi("{\\Bbb R}^2")#text(". (To put it another way, units of measurement are nothing more than one-dimensional (i.e. scalar) coordinate systems.)")],
[#text("To convert an angle in a plane to a signed number (modulo multiples of ")#mi("2\\pi")#text("), or vice versa, one needs to pick an orientation on the plane (e.g. to decide that anti-clockwise angles are positive).")],
[#text("To convert a ")#emph[#text("direction")]#text(" in a plane to a signed number (again modulo multiples of ")#mi("2\\pi")#text("), or vice versa, one needs to pick an orientation on the plane, as well as a reference direction (e.g. ")#link("http://en.wikipedia.org/wiki/True_north")[#text("true")]#text(" or ")#link("http://en.wikipedia.org/wiki/Magnetic_north_pole")[#text("magnetic north")]#text(" is often used in the case of ocean navigation).")],
[#text("Similarly, to convert a position on a circle to a number (modulo multiples of ")#mi("2\\pi")#text("), or vice versa, one needs to pick an orientation on that circle, together with an origin on that circle. Such a coordinate system then equates the original circle to the standard unit circle ")#tao-math("S^1 := \\{ z \\in {\\Bbb C}: \\left|z\\right| = 1 \\}", block: false)#text(" (with the standard origin ")#mi("+1")#text(" and the standard anticlockwise orientation ")#mi("\\circlearrowleft")#text(").")],
[#text("To convert a position on a two-dimensional sphere (e.g. the surface of the Earth, as a first approximation) to a point on the standard unit sphere ")#mi("S^2 := \\{ (x,y,z) \\in {\\Bbb R}^3: x^2+y^2+z^2 = 1 \\}")#text(", one can pick an orientation on that sphere, an “origin” (or “north pole”) for that sphere, and a “")#link("http://en.wikipedia.org/wiki/Prime_Meridian")[#text("prime meridian")]#text("” connecting the north pole to its antipode. Alternatively, one can view this coordinate system as determining a pair of ")#link("http://en.wikipedia.org/wiki/Euler_angles")[#text("Euler angles")]#text(" ")#mi("\\phi, \\lambda")#text(" (or a ")#link("http://en.wikipedia.org/wiki/Latitude")[#text("latitude")]#text(" and ")#link("http://en.wikipedia.org/wiki/Longitude")[#text("longitude")]#text(") to be assigned to every point on one’s original sphere.")],
[#text("The above examples were all geometric in nature, but one can also consider “combinatorial” coordinate systems, which allow one to identify combinatorial objects with numerical ones. An extremely familiar example of this is ")#link("http://en.wikipedia.org/wiki/Enumeration")[#emph[#text("enumeration")]]#text(": one can identify a set A of (say) five elements with the numbers 1,2,3,4,5 simply by choosing an enumeration ")#mi("a_1, a_2, \\ldots, a_5")#text(" of the set A. One can similarly enumerate other combinatorial objects (e.g. ")#link("http://en.wikipedia.org/wiki/Graph_(mathematics)")[#text("graphs")]#text(", ")#link("http://en.wikipedia.org/wiki/Relation_(mathematics)")[#text("relations")]#text(", ")#link("http://en.wikipedia.org/wiki/Tree_(graph_theory)")[#text("trees")]#text(", ")#link("http://en.wikipedia.org/wiki/Partially_ordered_set")[#text("partial orders")]#text(", etc.), and indeed this is done all the time in combinatorics. Similarly for algebraic objects, such as ")#link("http://en.wikipedia.org/wiki/Coset")[#text("cosets")]#text(" of a subgroup H (or more generally, ")#link("http://en.wikipedia.org/wiki/Torsor")[#text("torsors")]#text(" of a group G); one can identify such a coset with H itself by designating an element of that coset to be the “identity” or “origin”.")]
)

#text("More generally, a coordinate system ")#mi("\\Phi")#text(" can be viewed as an isomorphism ")#mi("\\Phi: A \\to G")#text(" between a given geometric (or combinatorial) object A in some class (e.g. a circle), and a standard object G in that class (e.g. the standard unit circle). (To be pedantic, this is what a ")#emph[#text("global")]#text(" coordinate system is; a ")#emph[#text("local")]#text(" coordinate system, such as the coordinate charts on a manifold, is an isomorphism between a local piece of a geometric or combinatorial object in a class, and a local piece of a standard object in that class. I will restrict attention to global coordinate systems for this discussion.)")

#text("Coordinate systems identify geometric or combinatorial objects with numerical (or standard) ones, but in many cases, there is no natural (or ")#link("http://en.wikipedia.org/wiki/Canonical")[#text("canonical")]#text(") choice of this identification; instead, one may be faced with a variety of coordinate systems, all equally valid. One can of course just fix one such system once and for all, in which case there is no real harm in thinking of the geometric and numeric objects as being equivalent. If however one plans to change from one system to the next (or to avoid using such systems altogether), then it becomes important to carefully distinguish these two types of objects, to avoid confusion. For instance, if an interval AB is measured to have a length of 3 yards, then it is OK to write ")#tao-math("\\left|AB\\right|=3", block: false)#text(" (identifying the geometric concept of length with the numeric concept of a positive real number) so long as you plan to stick to having the yard as the unit of length for the rest of one’s analysis. But if one was also planning to use, say, feet, as a unit of length also, then to avoid confusing statements such as “")#tao-math("\\left|AB\\right|=3", block: false)#text(" and ")#tao-math("\\left|AB\\right|=9", block: false)#text("“, one should specify the coordinate systems explicitly, e.g. “")#tao-math("\\left|AB\\right| = 3 \\text{ yards}", block: false)#text(" and ")#tao-math("\\left|AB\\right| = 9 \\text{ feet}", block: false)#text("“. Similarly, identifying a point P in a plane with its coordinates (e.g. ")#mi("P = (4,3)")#text(") is safe as long as one intends to only use a single coordinate system throughout; but if one intends to change coordinates at some point (or to switch to a coordinate-free perspective) then one should be more careful, e.g. writing ")#mi("P = 4 e_1 + 3 e_2")#text(", or even ")#mi("P = O + 4 e_1 + 3 e_2")#text(", if the origin O and basis vectors ")#mi("e_1, e_2")#text(" of one’s coordinate systems might be subject to future change.")

#text("As mentioned above, it is possible to in many cases to dispense with coordinates altogether. For instance, one can view the length ")#tao-math("\\left|AB\\right|", block: false)#text(" of a line segment AB not as a number (which requires one to select a unit of length), but more abstractly as the equivalence class of all line segments CD that are ")#link("http://en.wikipedia.org/wiki/Congruence_(geometry)")[#text("congruent")]#text(" to AB. With this perspective, ")#tao-math("\\left|AB\\right|", block: false)#text(" no longer lies in the standard ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(" ")#mi("{\\Bbb R}^+")#text(", but in a more abstract semigroup ")#mi("{\\mathcal L}")#text(" (the space of line segments quotiented by congruence), with addition now defined geometrically (by concatenation of intervals) rather than numerically. A unit of length can now be viewed as just one of many different isomorphisms ")#mi("\\Phi: {\\mathcal L} \\to {\\Bbb R}^+")#text(" between ")#mi("{\\mathcal L}")#text(" and ")#mi("{\\Bbb R}^+")#text(", but one can abandon the use of such units and just work with ")#mi("{\\mathcal L}")#text(" directly. Many statements in Euclidean geometry involving length can be phrased in this manner. For instance, if B lies in AC, then the statement ")#tao-math("\\left|AC\\right|=\\left|AB\\right|+\\left|BC\\right|", block: false)#text(" can be stated in ")#mi("{\\mathcal L}")#text(", and does not require any units to convert ")#mi("{\\mathcal L}")#text(" to ")#mi("{\\mathcal R}^+")#text("; with a bit more work, one can also make sense of such statements as ")#tao-math("\\left|AC\\right|^2 = \\left|AB\\right|^2 + \\left|BC\\right|^2", block: false)#text(" for a right-angled triangle ABC (i.e. ")#link("http://en.wikipedia.org/wiki/Pythagorean_theorem")[#text("Pythagoras’ theorem")]#text(") while avoiding units, by defining a symmetric bilinear product operation ")#mi("\\times: {\\mathcal L} \\times {\\mathcal L} \\to {\\mathcal A}")#text(" from the abstract semigroup ")#mi("{\\mathcal L}")#text(" of lengths to the abstract semigroup ")#mi("{\\mathcal A}")#text(" of areas. (Indeed, this is basically how the ancient Greeks, who did not quite possess the modern ")#link("http://en.wikipedia.org/wiki/Real_number")[#text("real number system")]#text(" ")#mi("{\\Bbb R}")#text(", viewed geometry, though of course without the assistance of such modern terminology as “semigroup” or “bilinear”.)")

#text("The above abstract ")#emph[#text("coordinate-free perspective")]#text(" is equivalent to a more concrete ")#emph[#text("coordinate-invariant perspective")]#text(", in which we do allow the use of coordinates to convert all geometric quantities to numeric ones, but insist that every statement that we write down is invariant under changes of coordinates. For instance, if we shrink our chosen unit of length by a factor ")#mi("\\lambda > 0")#text(", then the numerical length of every interval increases by a factor of ")#mi("\\lambda")#text(", e.g. ")#tao-math("\\left|AB\\right| \\mapsto \\lambda \\left|AB\\right|", block: false)#text(". The coordinate-invariant approach to length measurement then treats lengths such as ")#tao-math("\\left|AB\\right|", block: false)#text(" as numbers, but requires all statements involving such lengths to be invariant under the above scaling symmetry. For instance, a statement such as ")#tao-math("\\left|AC\\right|^2 = \\left|AB\\right|^2 + \\left|BC\\right|^2", block: false)#text(" is legitimate under this perspective, but a statement such as ")#tao-math("\\left|AB\\right| = \\left|BC\\right|^2", block: false)#text(" or ")#tao-math("\\left|AB\\right| = 3", block: false)#text(" is not. [In other words, co-ordinate invariance here is the same thing as being dimensionally consistent. Indeed, ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(" is nothing more than the analysis of the scaling symmetries in one’s coordinate systems.] One can retain this coordinate-invariance symmetry throughout one’s arguments; or one can, at some point, choose to ")#emph[#text("spend")]#text(" (or ")#emph[#text("break")]#text(") this coordinate invariance by selecting (or ")#emph[#text("fixing")]#text(") the coordinate system (which, in this case, means selecting a unit length). The advantage in spending such a symmetry is that one can often normalise one or more quantities to equal a particularly nice value; for instance, if a length ")#tao-math("\\left|AB\\right|", block: false)#text(" is appearing everywhere in one’s arguments, and one has carefully retained coordinate-invariance up until some key point, then it can be convenient to spend this invariance to normalise ")#tao-math("\\left|AB\\right|", block: false)#text(" to equal 1. (In this case, one only has a one-dimensional family of symmetries, and so can only normalise one quantity at a time; but when one’s symmetry group is larger, one can often normalise many more quantities at once; as a rule of thumb, one can normalise one quantity for each degree of freedom in the symmetry group.) Conversely, if one has already spent the coordinate invariance, one can often buy it back by converting all the facts, hypotheses, and desired conclusions one currently possesses in the situation back to a coordinate-invariant formulation. Thus one could imagine performing one normalisation to do one set of calculations, then undoing that normalisation to return to a coordinate-free perspective, doing some coordinate-free manipulations, and then performing a different normalisation to work on another part of the problem, and so forth. (For instance, in Euclidean geometry problems, it is often convenient to temporarily assign one key point to be the origin (thus spending translation invariance symmetry), then another, then switch back to a translation-invariant perspective, and so forth. As long as one is correctly accounting for what symmetries are being spent and bought at any given time, this can be a very powerful way of simplifying one’s calculations.)")

#text("Given a coordinate system ")#mi("\\Phi: A \\to G")#text(" that identifies some geometric object A with a standard object G, and some isomorphism ")#mi("\\Psi: G \\to G")#text(" of that standard object, we can obtain a new coordinate system ")#mi("\\Psi \\circ \\Phi: A \\to G")#text(" of A by composing the two isomorphisms. [I will be vague on what “")#link("http://en.wikipedia.org/wiki/Isomorphism")[#text("isomorphism")]#text("” means; one can formalise the concept using the language of ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theory")]#text(".] Conversely, every other coordinate system ")#mi("\\Phi^{\\prime}: A \\to G")#text(" of ")#mi("A")#text(" arises in this manner. Thus, the space of coordinate systems on A is (non-canonically) identifiable with the isomorphism group ")#mi("\\text{Isom}(G)")#text(" of G. This isomorphism group is called the ")#link("http://en.wikipedia.org/wiki/Structure_group#Structure_groups_and_transition_functions")[#emph[#text("structure group")]]#text(" (or ")#link("http://en.wikipedia.org/wiki/Gauge_group")[#emph[#text("gauge group")]]#text(") of the class of geometric objects. For example, the structure group for lengths is ")#mi("{\\Bbb R}^+")#text("; the structure group for angles is ")#mi("{\\Bbb Z}/2{\\Bbb Z}")#text("; the structure group for lines is the ")#link("http://en.wikipedia.org/wiki/Affine_group")[#text("affine group")]#text(" ")#mi("\\text{Aff}({\\Bbb R})")#text("; the structure group for ")#mi("n")#text("-dimensional Euclidean geometry is the ")#link("http://en.wikipedia.org/wiki/Euclidean_group")[#text("Euclidean group")]#text(" ")#mi("E(n)")#text("; the structure group for (oriented) 2-spheres is the (special) ")#link("http://en.wikipedia.org/wiki/Orthogonal_group")[#text("orthogonal group")]#text(" ")#mi("SO(3)")#text("; and so forth. (Indeed, one can basically describe each of the classical geometries (")#link("http://en.wikipedia.org/wiki/Euclidean_geometry")[#text("Euclidean")]#text(", ")#link("http://en.wikipedia.org/wiki/Affine_geometry")[#text("affine")]#text(", ")#link("http://en.wikipedia.org/wiki/Projective_geometry")[#text("projective")]#text(", ")#link("http://en.wikipedia.org/wiki/Spherical_geometry")[#text("spherical")]#text(", ")#link("http://en.wikipedia.org/wiki/Hyperbolic_geometry")[#text("hyperbolic")]#text(", ")#link("http://en.wikipedia.org/wiki/Minkowski_space")[#text("Minkowski")]#text(", etc.) as a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" for its structure group, as per the ")#link("http://en.wikipedia.org/wiki/Erlangen_program")[#text("Erlangen program")]#text(".)")

#heading(level: 1)[#text("— Gauges —")]

#text("In our discussion of coordinate systems, we focused on a single geometric (or combinatorial) object ")#mi("A")#text(": a single line, a single circle, a single set, etc. We then used a single coordinate system to identify that object with a standard representative of such an object.")

#text("Now let us consider the more general situation in which one has a ")#emph[#text("family")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Fiber_bundle")[#emph[#text("fibre bundle")]]#text(") ")#mi("(A_x)_{x \\in X}")#text(" of geometric (or combinatorial) objects (or ")#emph[#text("fibres")]#text(") ")#mi("A_x")#text(": a family of lines (i.e. a line bundle), a family of circles (i.e. a circle bundle), a family of sets, etc. This family is parameterised by some ")#emph[#text("parameter set")]#text(" or ")#emph[#text("base point")]#text(" x, which ranges in some ")#emph[#text("parameter space")]#text(" or ")#emph[#text("base space")]#text(" X. In many cases one also requires some topological or differentiable compatibility between the various fibres; for instance, continuous (or smooth) variations of the base point should lead to continuous (or smooth) variations in the fibre. For sake of discussion, however, let us gloss over these compatibility conditions.")

#text("In many cases, each individual fibre ")#mi("A_x")#text(" in a bundle ")#mi("(A_x)_{x \\in X}")#text(", being a geometric object of a certain class, can be identified with a standard object ")#mi("G")#text(" in that class, by means of a separate coordinate system ")#mi("\\Phi_x: A_x \\to G")#text(" for each base point x. The entire collection ")#mi("\\Phi = (\\Phi_x)_{x \\in X}")#text(" is then referred to as a (global) ")#emph[#text("gauge")]#text(" or ")#emph[#link("http://en.wikipedia.org/wiki/Trivialization")[#text("trivialisation")]]#text(" for this bundle (provided that it is compatible with whatever topological or differentiable structures one has placed on the bundle, but never mind that for now). Equivalently, a gauge is a ")#link("http://en.wikipedia.org/wiki/Bundle_isomorphism")[#text("bundle isomorphism")]#text(" ")#mi("\\Phi")#text(" from the original bundle ")#mi("(A_x)_{x \\in X}")#text(" to the ")#emph[#text("trivial bundle")]#text(" ")#mi("(G)_{x \\in X}")#text(", in which every fibre is the standard geometric object G. (There are also ")#emph[#text("local")]#text(" gauges, which only trivialise a portion of the bundle, but let’s ignore this distinction for now.)")

#text("Let’s give three concrete examples of bundles and gauges; one from differential geometry, one from dynamical systems, and one from combinatorics.")

#strong[#text("Example 1: the circle bundle of the sphere.")]#text(" Recall from the previous section that the space of directions in a plane (which can be viewed as the circle of unit vectors) can be identified with the standard circle ")#mi("S^1")#text(" after picking an orientation and a reference direction. Now let us work not on the plane, but on a sphere, and specifically, on the surface X of the earth. At each point x on this surface, there is a circle ")#mi("S_x")#text(" of directions that one can travel along the sphere from x; the collection ")#mi("SX := (S_x)_{x \\in X}")#text(" of all such circles is then a circle bundle with base space X (known as ")#emph[#text("the")]#text(" circle bundle; it could also be viewed as the sphere bundle, cosphere bundle, or orthonormal frame bundle of X). The structure group of this bundle is the circle group ")#mi("U(1) \\equiv S^1")#text(" if one preserves orientation, or the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semi-direct product")]#text(" ")#mi("S^1 \\rtimes {\\Bbb Z}/2{\\Bbb Z}")#text(" otherwise.")

#text("Now suppose, at every point x on the earth X, the wind is blowing in some direction ")#mi("w_x \\in S_x")#text(". (This is not actually possible globally, thanks to the ")#link("http://en.wikipedia.org/wiki/Hairy_ball_theorem")[#text("hairy ball theorem")]#text(", but let’s ignore this technicality for now.) Thus wind direction can be thought of as a collection ")#mi("w = (w_x)_{x \\in X}")#text(" of representatives from the fibres of the fibre bundle ")#mi("(S_x)_{x \\in X}")#text("; such a collection is known as a ")#link("http://en.wikipedia.org/wiki/Section_(fiber_bundle)")[#emph[#text("section")]]#text(" of the fibre bundle (it is to bundles as the concept of a ")#link("http://en.wikipedia.org/wiki/Graph_of_a_function")[#text("graph")]#text(" ")#mi("\\{ (x, f(x)): x \\in X \\} \\subset X \\times G")#text(" of a function ")#mi("f: X \\to G")#text(" is to the trivial bundle ")#mi("(G)_{x \\in X}")#text(").")

#text("At present, this section has not been represented in terms of numbers; instead, the wind direction ")#mi("w (w_x)_{x \\in X}")#text(" is a collection of points on various different circles in the circle bundle SX. But one can convert this section w into a collection of numbers (and more specifically, a function ")#mi("u: X \\to S^1")#text(" from X to ")#mi("S^1")#text(") by choosing a gauge for this circle bundle – in other words, by selecting an orientation ")#mi("\\epsilon_x")#text(" and a reference direction ")#mi("N_x")#text(" for each point x on the surface of the Earth X. For instance, one can pick the anticlockwise orientation ")#mi("\\circlearrowleft")#text(" and true north for every point x (ignore for now the problem that this is not defined at the north and south poles, and so is merely a local gauge rather than a global one), and then each wind direction ")#mi("w_x")#text(" can now be identified with a unit complex number ")#mi("u(x) \\in S^1")#text(" (e.g. ")#mi("e^{i\\pi/4}")#text(" if the wind is blowing in the northwest direction at x). Now that one has a numerical function u to play with, rather than a geometric object w, one can now use analytical tools (e.g. differentiation, integration, Fourier transforms, etc.) to analyse the wind direction if one desires. But one should be aware that this function reflects the choice of gauge as well as the original object of study. If one changes the gauge (e.g. by using ")#link("http://en.wikipedia.org/wiki/Magnetic_north_pole")[#text("magnetic north")]#text(" instead of true north), then the function u changes, even though the wind direction w is still the same. If one does not want to spend the U(1) gauge symmetry, one would have to take care that all operations one performs on these functions are gauge-invariant; unfortunately, this restrictive requirement eliminates wide swathes of analytic tools (in particular, integration and the Fourier transform) and so one is often forced to break the gauge symmetry in order to use analysis. The challenge is then to select the gauge that maximises the effectiveness of analytic methods. ")#mi("\\diamond")

#strong[#text("Example 2: circle extensions of a dynamical system.")]#text(" Recall (see e.g. my ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("lecture notes")]#text(") that a dynamical system is a pair X = (X,T), where X is a space and ")#mi("T: X \\to X")#text(" is an invertible map. (One can also place additional topological or measure-theoretic structures on this system, as is done in those notes, but we will ignore these structures for this discussion.) Given such a system, and given a ")#emph[#text("cocycle")]#text(" ")#mi("\\rho: X \\to S^1")#text(" (which, in this context, is simply a function from X to the unit circle), we can define the ")#emph[#text("skew product")]#text(" ")#mi("X \\times_\\rho S^1")#text(" of X and the unit circle ")#mi("S^1")#text(", twisted by the cocycle ")#mi("\\rho")#text(", to be the Cartesian product ")#mi("X \\times S^1 := \\{ (x,u): x \\in X, u \\in S^1 \\}")#text(" with the shift ")#mi("\\tilde T: (x,u) \\mapsto (Tx, \\rho(x) u)")#text("; this is easily seen to be another dynamical system. (If one wishes to have a topological or measure-theoretic dynamical system, then ")#mi("\\rho")#text(" will have to be continuous or measurable here, but let us ignore such issues for this discussion.) Observe that there is a ")#link("http://en.wikipedia.org/wiki/Free_action")[#text("free action")]#text(" ")#mi("(S_v: (x,u) \\mapsto (x,vu))_{v \\in S^1}")#text(" of the circle group ")#mi("S^1")#text(" on the skew product ")#mi("X \\times_\\rho S^1")#text(" that commutes with the shift ")#mi("\\tilde T")#text("; the ")#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("quotient space")]#text(" ")#mi("(X \\times_\\rho S^1)/S^1")#text(" of this action is isomorphic to X, thus leading to a ")#emph[#text("factor map")]#text(" ")#mi("\\pi: X \\times_\\rho S^1 \\to X")#text(", which is of course just the projection map ")#mi("\\pi: (x,u) \\mapsto x")#text(". (An example is provided by the ")#emph[#text("skew shift system")]#text(", described in my ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("lecture notes")]#text(".)")

#text("Conversely, suppose that one had a dynamical system ")#mi("\\tilde X = (\\tilde X, \\tilde T)")#text(" which had a free ")#mi("S^1")#text(" action ")#mi("(S_v: \\tilde X \\to \\tilde X)_{v \\in S^1}")#text(" commuting with the shift ")#mi("\\tilde T")#text(". If we set ")#mi("X := \\tilde X/S^1")#text(" to be the quotient space, we thus have a factor map ")#mi("\\pi: \\tilde X \\to X")#text(", whose level sets ")#mi("\\pi^{-1}(\\{x\\})")#text(" are all isomorphic to the circle ")#mi("S^1")#text("; we call ")#mi("\\tilde X")#text(" a ")#emph[#text("circle extension")]#text(" of the dynamical system X. We can thus view ")#mi("\\tilde X")#text(" as a ")#emph[#text("circle bundle")]#text(" ")#mi("(\\pi^{-1}(\\{x\\}))_{x \\in X}")#text(" with base space X, thus the level sets ")#mi("\\pi^{-1}(\\{x\\})")#text(" are now the fibres of the bundle, and the structure group is ")#mi("S^1")#text(". If one picks a ")#emph[#text("gauge ")]#text("for this bundle, by choosing a reference point ")#mi("p_x \\in \\pi^{-1}(\\{x\\})")#text(" in the fibre for each base point x (thus in this context a gauge is the same thing as a ")#link("http://en.wikipedia.org/wiki/Section_(fiber_bundle)")[#emph[#text("section")]]#text(" ")#mi("p = (p_x)_{x \\in X}")#text("; this is basically because this bundle is a ")#link("http://en.wikipedia.org/wiki/Principal_bundle")[#text("principal bundle")]#text("), then one can identify ")#mi("\\tilde X")#text(" with a skew product ")#mi("X \\times_\\rho S^1")#text(" by identifying the point ")#mi("S_v p_x \\in \\tilde X")#text(" with the point ")#mi("(x,v) \\in X \\times_\\rho S^1")#text(" for all ")#mi("x \\in X, v \\in S^1")#text(", and letting ")#mi("\\rho")#text(" be the cocycle defined by the formula")

#align(center)[#tao-fit-display[#mitex("S_{\\rho(x)} p_{Tx} = \\tilde T p_x.")]]

#text("One can check that this is indeed an isomorphism of dynamical systems; if all the various objects here are continuous (resp. measurable), then one also has an isomorphism of topological dynamical systems (resp. measure-preserving systems). Thus we see that gauges allow us to write circle extensions as skew products. However, more than one gauge is available for any given circle extension; two gauges ")#mi("(p_x)_{x \\in X}")#text(", ")#mi("(p^{\\prime}_x)_{x \\in X}")#text(" will give rise to two skew products ")#mi("X \\times_\\rho S^1")#text(", ")#mi("X \\times_{\\rho^{\\prime}} S^1")#text(" which are isomorphic but not identical. Indeed, if we let ")#mi("v: X \\to S^1")#text(" be a rotation map that sends ")#mi("p_x")#text(" to ")#mi("p^{\\prime}_{x}")#text(", thus ")#mi("p^{\\prime}_{x} = S_{v(x)} p_x")#text(", then we see that the two cocycles ")#mi("\\rho^{\\prime}")#text(" and ")#mi("\\rho")#text(" are related by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(0)")])
#mitex("\\rho^{\\prime}(x) = v(Tx)^{-1} \\rho(x) v(x).")]]

#text("Two cocycles that obey the above relation are called ")#emph[#text("cohomologous")]#text("; their skew products are isomorphic to each other. An important general question in dynamical systems is to understand when two given cocycles are in fact cohomologous, for instance by introducing non-trivial cohomological invariants for such cocycles.")

#text("As an example of a circle extension, consider the sphere ")#mi("X = S^2")#text(" from Example 1, with a rotation shift T given by, say, rotating anti-clockwise by some given angle ")#mi("\\alpha")#text(" around the axis connecting the north and south poles. This rotation also induces a rotation on the circle bundle ")#mi("\\tilde X := SX")#text(", thus giving a circle extension of the original system ")#mi("(X,T)")#text(". One can then use a gauge to write this system as a skew product. For instance, if one selects the gauge that chooses ")#mi("p_x")#text(" to be the true north direction at each point x (ignoring for now the fact that this is not defined at the two poles), then this system becomes the ordinary product ")#mi("X \\times_0 S^1")#text(" of the original system X with the circle ")#mi("S^1")#text(", with the cocycle being the trivial cocycle 0. If we were however to use a different gauge, e.g. magnetic north instead of true north, one would obtain a different skew-product ")#mi("X \\times_{\\rho^{\\prime}} S^1")#text(", where ")#mi("\\rho^{\\prime}")#text(" is some cocycle which is cohomologous to the trivial cocycle (except at the poles). (A cocycle which is globally cohomologous to the trivial cocycle is known as a ")#emph[#text("coboundary")]#text(". Not every cocycle is a coboundary, especially once one imposes topological or measure-theoretic structure, thanks to the presence of various topological or measure-theoretic invariants, such as ")#link("http://en.wikipedia.org/wiki/Degree_(continuous_map)")[#text("degree")]#text(".)")

#text("There was nothing terribly special about circles in this example; one can also define group extensions, or more generally homogeneous space extensions, of dynamical systems, and have a similar theory, although one has to take a little care with the order of operations when the structure group is non-abelian; see e.g. my ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("lecture notes")]#text(" on isometric extensions. ")#mi("\\diamond")

#strong[#text("Example 3: Orienting an undirected graph.")]#text(" The language of gauge theory is not often used in combinatorics, but nevertheless combinatorics does provide some simple discrete examples of bundles and gauges which can be useful in getting an intuitive grasp of the concept. Consider for instance an ")#link("http://en.wikipedia.org/wiki/Undirected_graph")[#text("undirected graph")]#text(" G = (V,E) of vertices and edges. I will let X=E denote the space of edges (not the space of vertices)!. Every edge ")#mi("e \\in X")#text(" can be oriented (or directed) in two different ways; let ")#mi("A_e")#text(" be the pair of directed edges of e arising in this manner. Then ")#mi("(A_e)_{e \\in X}")#text(" is a fibre bundle with base space X and with each fibre isomorphic (in the category of sets) to the standard two-element set ")#mi("\\{-1,+1\\}")#text(", with structure group ")#mi("{\\Bbb Z}/2{\\Bbb Z}")#text(".")

#emph[#text("A priori")]#text(", there is no reason to prefer one orientation of an edge e over another, and so there is no canonical way to identify each fibre ")#mi("A_e")#text(" with the standard set ")#mi("\\{-1,+1\\}")#text(". Nevertheless, we can go ahead and arbitrarily select a gauge for X by ")#emph[#text("orienting")]#text(" the graph G. This orientation assigns an oriented edge ")#mi("\\vec e \\in A_e")#text(" to each edge ")#mi("e \\in X")#text(", thus creating a gauge (or section) ")#mi("(\\vec e)_{e \\in X}")#text(" of the bundle ")#mi("(A_e)_{e \\in X}")#text(". Once one selects such a gauge, we can now identify the fibre bundle ")#mi("(A_e)_{e \\in X}")#text(" with the trivial bundle ")#mi("X \\times \\{-1,+1\\}")#text(" by identifying the preferred oriented edge ")#mi("\\vec e")#text(" of each unoriented edge ")#mi("e \\in X")#text(" with ")#mi("(e,+1)")#text(", and the other oriented edge with ")#mi("(e,-1)")#text(". In particular, any other orientation of the graph G can be expressed relative to this reference orientation as a function ")#mi("f: X \\to \\{-1,+1\\}")#text(", which measures when the two orientations agree or disagree with each other. ")#mi("\\diamond")

#text("Recall that every isomorphism ")#mi("\\Psi \\in \\text{Isom}(G)")#text(" of a standard geometric object G allowed one to transform a coordinate system ")#mi("\\Phi: A \\to G")#text(" on a geometric object A to another coordinate system ")#mi("\\Psi \\circ \\Phi: A \\to G")#text(". We can generalise this observation to gauges: every family ")#mi("\\Psi = (\\Psi_x)_{x \\in X}")#text(" of isomorphisms on G allows one to transform a gauge ")#mi("(\\Phi_x)_{x \\in X}")#text(" to another gauge ")#mi("(\\Psi_x \\circ \\Phi_x)_{x \\in X}")#text(" (again assuming that ")#mi("\\Psi")#text(" respects whatever topological or differentiable structure is present). Such a collection ")#mi("\\Psi")#text(" is known as a ")#emph[#text("gauge transformation")]#text(". For instance, in Example 1, one could rotate the reference direction ")#mi("N_x")#text(" at each point ")#mi("x \\in X")#text(" anti-clockwise by some angle ")#mi("\\theta(x)")#text("; this would cause the function ")#mi("u(x)")#text(" to rotate to ")#mi("u(x) e^{-i\\theta(x)}")#text(". In Example 2, a gauge transformation is just a map ")#mi("v: X \\to S^1")#text(" (which may need to be continuous or measurable, depending on the structures one places on X); it rotates a point ")#mi("(x,u) \\in X \\times_\\rho S^1")#text(" to ")#mi("(x, v^{-1} u)")#text(", and it also transforms the cocycle ")#mi("\\rho")#text(" by the formula (0). In Example 3, a gauge transformation would be a map ")#mi("v: X \\to \\{-1,+1\\}")#text("; it rotates a point ")#mi("(x, \\epsilon) \\in X \\times \\{-1,+1\\}")#text(" to ")#mi("(x, v(x) \\epsilon)")#text(".")

#text("Gauge transformations transform functions on the base X in many ways, but some things remain gauge-invariant. For instance, in Example 1, the ")#link("http://en.wikipedia.org/wiki/Winding_number")[#text("winding number")]#text(" of a function ")#mi("u: X \\to S^1")#text(" along a closed loop ")#mi("\\gamma \\subset X")#text(" would not change under a gauge transformation (as long as no singularities in the gauge are created, moved, or destroyed, and the orientation is not reversed). But such topological gauge-invariants are not the only gauge invariants of interest; there are important ")#emph[#text("differential")]#text(" gauge-invariants which make gauge theory a crucial component of modern differential geometry and geometric PDE. But to describe these, one needs an additional gauge-theoretic concept, namely that of a ")#link("http://en.wikipedia.org/wiki/Connection_(mathematics)")[#emph[#text("connection")]]#text(" on a fibre bundle.")

#heading(level: 1)[#text("— Connections —")]

#text("There are many essentially equivalent ways to introduce the concept of a connection; I will use the formulation based primarily on ")#link("http://en.wikipedia.org/wiki/Parallel_transport")[#text("parallel transport")]#text(", and on differentiation of sections. To avoid some technical details I will work (somewhat non-rigorously) with ")#link("http://en.wikipedia.org/wiki/Infinitesimal")[#text("infinitesimals")]#text(" such as dx. (There are ways to make the use of infinitesimals rigorous, such as ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("non-standard analysis")]#text(", but this is not the focus of my post today.)")

#text("In single variable calculus, we learn that if we want to differentiate a function ")#mi("f: [a,b] \\to {\\Bbb R}")#text(" at some point x, then we need to compare the value f(x) of f at x with its value f(x+dx) at some infinitesimally close point x+dx, take the difference ")#mi("f(x+dx)-f(x)")#text(", and then divide by dx, taking limits as ")#mi("dx \\to 0")#text(", if one does not like to use infinitesimals:")

#align(center)[#tao-fit-display[#mitex("\\nabla f(x) := \\lim_{dx \\to 0} \\frac{f(x+dx) - f(x)}{dx}.")]]

#text("In several variable calculus, we learn several generalisations of this concept in which the domain and range of f is allowed to be multi-dimensional. For instance, if ")#mi("f: X \\to {\\Bbb R}^d")#text(" is now a vector-valued function on some multi-dimensional domain (e.g. a ")#link("http://en.wikipedia.org/wiki/Manifold")[#text("manifold")]#text(") X, and v is a ")#link("http://en.wikipedia.org/wiki/Tangent_space")[#text("tangent vector")]#text(" to X at some point x, we can define the ")#link("http://en.wikipedia.org/wiki/Directional_derivative")[#text("directional derivative")]#text(" ")#mi("\\nabla_v f(x)")#text(" of f at x by comparing ")#mi("f(x+v dt)")#text(" with ")#mi("f(x)")#text(" for some infinitesimal dt, take the difference ")#mi("f(x+vdt) - f(x)")#text(", divide by dt, and then take limits as ")#mi("dt \\to 0")#text(":")

#align(center)[#mi("\\displaystyle \\nabla_v f(x) := \\lim_{dt \\to 0} \\frac{f(x+vdt) - f(x)}{dt}")#text(".")]

#text("[Strictly speaking, if X is not flat, then x+vdt is only defined up to an ambiguity of o(dt), but let us ignore this minor issue here, as it is not important in the limit.] If f is sufficiently smooth (being continuously differentiable will do), the directional derivative is linear in v, thus for instance ")#mi("\\nabla_{v+v^{\\prime}} f(x) = \\nabla_v f(x) + \\nabla_{v^{\\prime}} f(x)")#text(". One can also generalise the range of f to other multi-dimensional domains than ")#mi("{\\Bbb R}^d")#text("; the directional derivative then lives in a tangent space of that domain.")

#text("In all of the above examples, though, we were differentiating functions ")#mi("f:X \\to Y")#text(", thus each element ")#mi("x \\in X")#text(" in the base (or domain) gets mapped to an element ")#mi("f(x)")#text(" in the same range Y. However, in many geometrical situations we would like to differentiate ")#emph[#text("sections")]#text(" ")#mi("f = (f_x)_{x \\in X}")#text(" instead of functions, thus f now maps each point ")#mi("x \\in X")#text(" in the base to an element ")#mi("f_x \\in A_x")#text(" of some fibre in a fibre bundle ")#mi("(A_x)_{x \\in X}")#text(". For instance, one might want to know how the wind direction ")#mi("w = (w_x)_{x \\in X}")#text(" changes as one moves x in some direction v; thus computing a directional derivative ")#mi("\\nabla_v w(x)")#text(" of w at x in direction v. One can try to mimic the previous definitions in order to define this directional derivative. For instance, one can move x along v by some infinitesimal amount dt, creating a nearby point ")#mi("x+v dt")#text(", and then evaluate w at this point to obtain ")#mi("w(x+vdt)")#text(". But here we hit a snag: we cannot directly compare ")#mi("w(x+vdt)")#text(" with ")#mi("w(x)")#text(", because the former lives in the fibre ")#mi("A_{x+vdt}")#text(" while the latter lives in the fibre ")#mi("A_x")#text(".")

#text("With a gauge, of course, we can identify all the fibres (and in particular, ")#mi("A_{x+vdt}")#text(" and ")#mi("A_x")#text(") with a common object G, in which case there is no difficulty comparing ")#mi("w(x+vdt)")#text(" with ")#mi("w(x)")#text(". But this would lead to a notion of derivative which is not gauge-invariant, known as the ")#emph[#text("non-covariant")]#text(" or ")#emph[#text("ordinary")]#text(" derivative in physics.")

#text("But there is another way to take a derivative, which does not require the full strength of a gauge (which identifies ")#emph[#text("all")]#text(" fibres simultaneously together). Indeed, in order to compute a derivative ")#mi("\\nabla_v w(x)")#text(", one only needs to identify (or ")#emph[#text("connect")]#text(") two infinitesimally close fibres together: ")#mi("A_x")#text(" and ")#mi("A_{x+vdt}")#text(". In practice, these two fibres are already “within O(dt) of each other” in some sense, but suppose in fact that we have some means ")#mi("\\Gamma(x \\to x+vdt): A_x \\to A_{x+vdt}")#text(" of identifying these two fibres together. Then, we can pull back ")#mi("w(x+vdt)")#text(" from ")#mi("A_{x+vdt}")#text(" to ")#mi("A_x")#text(" through ")#mi("\\Gamma(x \\to x+vdt)")#text(" to define the ")#link("http://en.wikipedia.org/wiki/Covariant_derivative")[#text("covariant derivative")]#text(":")

#align(center)[#mi("\\displaystyle \\nabla_v w(x) := \\lim_{dt \\to 0} \\frac{\\Gamma(x \\to x+vdt)^{-1}( w(x+vdt) ) - w(x) }{dt}")#text(".")]

#text("In order to retain the basic property that ")#mi("\\nabla_v w")#text(" is linear in v, and to allow one to extend the infinitesimal identifications ")#mi("\\Gamma(x \\to x+dx)")#text(" to non-infinitesimal identifications, we impose the property that the ")#mi("\\Gamma(x \\to x+dx)")#text(" to be approximately transitive in that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(x+dx \\to x+dx+dx^{\\prime}) \\circ \\Gamma(x \\to x + dx )")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\approx \\Gamma(x \\to x+dx+dx^{\\prime})")]]

#text("for all x, dx, dx’, where the ")#mi("\\approx")#text(" symbol indicates that the error between the two sides is o(|dx| + |dx’|). [The precise nature of this error is actually rather important, being essentially the ")#link("http://en.wikipedia.org/wiki/Curvature_form")[#emph[#text("curvature")]]#text(" of the connection ")#mi("\\Gamma")#text(" at x in the directions ")#mi("dx, dx^{\\prime}")#text(", but let us ignore this for now.] To oversimplify a little bit, any collection ")#mi("\\Gamma")#text(" of infinitesimal maps ")#mi("\\Gamma(x \\to x+dx)")#text(" obeying this property (and some technical regularity properties) is a ")#emph[#text("connection")]#text(".")

#text("[There are many other important ways to view connections, for instance the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbols")[#text("Christoffel symbol")]#text(" perspective that we will discuss a bit later. Another approach is to focus on the differentiation operation ")#mi("\\nabla_v")#text(" rather than the identifications ")#mi("\\Gamma(x \\to x+dx)")#text(" or ")#mi("\\Gamma(\\gamma)")#text(", and in particular on the algebraic properties of this operation, such as linearity in v or ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivation")]#text("-type properties (in particular, obeying various variants of the ")#link("http://en.wikipedia.org/wiki/Leibnitz_rule")[#text("Leibnitz rule")]#text("). This approach is particularly important in algebraic geometry, in which the notion of an infinitesimal or of a path may not always be obviously available, but we will not discuss it here.]")

#text("The way we have defined it, a connection is a means of identifying two infinitesimally close fibres ")#mi("A_x, A_{x+dx}")#text(" of a fibre bundle ")#mi("(A_x)_{x \\in X}")#text(". But, thanks to (1), we can also identify two distant fibres ")#mi("A_x, A_y")#text(", provided that we have a path ")#mi("\\gamma: [a,b] \\to X")#text(" from ")#mi("x = \\gamma(a)")#text(" to ")#mi("y = \\gamma(b)")#text(", by concatenating the infinitesimal identifications by a non-commutative variant of a ")#link("http://en.wikipedia.org/wiki/Riemann_sum")[#text("Riemann sum")]#text(":")

#align(center)[#tao-fit-display[#tao-math("\\Gamma(\\gamma) := \\lim_{\\sup \\left|t_{i+1}-t_i\\right| \\to 0}", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Gamma(\\gamma(t_{n-1}) \\to \\gamma(t_n)) \\circ \\ldots \\circ \\Gamma(\\gamma(t_0) \\to \\gamma(t_1)),")]]

#text("where ")#mi("a = t_0 < t_1 < \\ldots < t_n = b")#text(" ranges over partitions. This gives us a ")#link("http://en.wikipedia.org/wiki/Parallel_transport")[#emph[#text("parallel transport")]]#text(" map ")#mi("\\Gamma(\\gamma): A_x \\to A_y")#text(" identifying ")#mi("A_x")#text(" with ")#mi("A_y")#text(", which in view of its Riemann sum definition, can be viewed as the “integral” of the connection ")#mi("\\Gamma")#text(" along the curve ")#mi("\\gamma")#text(". This map does not depend on how one parametrises the path ")#mi("\\gamma")#text(", but it can depend on the choice of path used to travel from x to y.")

#text("We illustrate these concepts using several examples, including the three examples introduced earlier.")

#strong[#text("Example 1 continued.")]#text(" (Circle bundle of the sphere) The geometry of the sphere X in Example 1 provides a natural connection on the circle bundle SX, the ")#link("http://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("Levi-Civita connection")]#text(" ")#mi("\\Gamma")#text(", that lets one transport directions around the sphere in as “parallel” a manner as possible; the precise definition is a little technical (see e.g. my ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("lecture notes")]#text(" for a brief description). Suppose for instance one starts at some location x on the equator of the earth, and moves to the antipodal point y by a ")#link("http://en.wikipedia.org/wiki/Great_circle")[#text("great semi-circle")]#text(" ")#mi("\\gamma")#text(" going through the north pole. The parallel transport ")#mi("\\Gamma(\\gamma): S_x \\to S_y")#text(" along this path will map the north direction at x to the ")#emph[#text("south")]#text(" direction at y. On the other hand, if we went from x to y by a great semi-circle ")#mi("\\gamma^{\\prime}")#text(" going along the equator, then the north direction at x would be transported to the ")#emph[#text("north")]#text(" direction at y. Given a section u of this circle bundle, the quantity ")#mi("\\nabla_v u(x)")#text(" can be interpreted as the rate at which u rotates as one travels from x with velocity v. ")#mi("\\diamond")

#strong[#text("Example 2 continued. ")]#text("(Circle extensions) In Example 2, we change the notion of “infinitesimally close” by declaring x and Tx to be infinitesimally close for any x in the base space X (and more generally, x and ")#mi("T^n x")#text(" are non-infinitesimally close for any positive integer n, being connected by the path ")#mi("x \\to Tx \\to \\ldots \\to T^n x")#text(", and similarly for negative n). A cocycle ")#mi("\\rho: X \\to S^1")#text(" can then be viewed as defining a connection on the skew product ")#mi("X \\times_\\rho S^1")#text(", by setting ")#mi("\\Gamma( x \\mapsto Tx ) = \\rho(x)")#text(" (and also ")#mi("\\Gamma(x \\to x) = 1")#text(" and ")#mi("\\Gamma(Tx \\to x ) = \\rho(x)^{-1}")#text(" to ensure compatibility with (1); to avoid notational ambiguities let us assume for sake of discussion that ")#mi("x, Tx, T^{-1} x")#text(" are always distinct from each other). The non-infinitesimal connections ")#mi("\\rho_n(x) := \\Gamma(x \\to Tx \\to \\ldots \\to T^n x)")#text(" are then given by the formula ")#mi("\\rho_n(x) = \\rho(x) \\rho(Tx) \\ldots \\rho(T^{n-1} x)")#text(" for positive n (with a similar formula for negative n). Note that these iterated cocycles ")#mi("\\rho_n")#text(" also describe the iterations of the shift ")#mi("\\tilde T: (x,u) \\mapsto (Tx,\\rho(x)u)")#text(", indeed ")#mi("\\tilde T^n (x,u) = (T^n x, \\rho_n(x) u)")#text(". ")#mi("\\diamond")

#strong[#text("Example 3 continued.")]#text(" (Oriented graphs) In Example 3, we declare two edges e, e’ in X to be “infinitesimally close” if they are adjacent. Then there is a natural notion of parallel transport on the bundle ")#mi("(A_e)_{e \\in X}")#text("; given two adjacent edges ")#mi("e = \\{u,v\\}")#text(", ")#mi("e^{\\prime}=\\{v,w\\}")#text(", we let ")#mi("\\Gamma(e \\to e^{\\prime})")#text(" be the isomorphism from ")#mi("A_e = \\{ \\vec{uv}, \\vec{vu} \\}")#text(" to ")#mi("A_{e^{\\prime}} = \\{ \\vec{vw}, \\vec{wv} \\}")#text(" that maps ")#mi("\\vec{uv}")#text(" to ")#mi("\\vec{vw}")#text(" and ")#mi("\\vec{vu}")#text(" to ")#mi("\\vec{wv}")#text(". Any path ")#mi("\\gamma = (\\{v_1,v_2\\}, \\{v_2,v_3\\}, \\ldots, \\{v_{n-1},v_n\\})")#text(" of edges then gives rise to a connection ")#mi("\\Gamma(\\gamma)")#text(" identifying ")#mi("A_{\\{v_1,v_2\\}}")#text(" with ")#mi("A_{\\{v_{n-1},v_n\\}}")#text(". For instance, the triangular path ")#mi("(\\{u,v\\}, \\{v,w\\}, \\{w,u\\}, \\{u,v\\})")#text(" induces the identity map on ")#mi("A_{\\{u,v\\}}")#text(", whereas the U-turn path ")#mi("(\\{u,v\\}, \\{v,w\\}, \\{w,x\\}, \\{x,v\\}, \\{v,u\\})")#text(" induces the anti-identity map on ")#mi("A_{\\{u,v\\}}")#text(".")

#text("Given an orientation ")#mi("\\vec G = (\\vec e)_{e \\in X}")#text(" of the graph G, one can “differentiate” ")#mi("\\vec G")#text(" at an edge ")#mi("\\{u,v\\}")#text(" in the direction ")#mi("\\{u,v\\} \\to \\{v,w\\}")#text(" to obtain a number ")#mi("\\nabla_{\\{u,v\\} \\to \\{v,w\\}} \\vec G(\\{u,v\\}) \\in \\{-1,+1\\}")#text(", defined as +1 if the parallel transport from ")#mi("\\{u,v\\}")#text(" and ")#mi("\\{v,w\\}")#text(" preserves the orientations given by ")#mi("\\vec G")#text(", and -1 otherwise. This number of course depends on the choice of orientation. But certain combinations of these numbers are independent of such a choice; for instance, given any closed path ")#mi("\\gamma = \\{e_1,e_2,\\ldots,e_n,e_{n+1}=e_1\\}")#text(" of edges in X, the “integral” ")#mi("\\prod_{i=1}^n \\nabla_{e_i \\to e_{i+1}} \\vec G(e_i) \\in \\{-1,+1\\}")#text(" is independent of the choice of orientation ")#mi("\\vec G")#text(" (indeed, it is equal to +1 if ")#mi("\\Gamma(\\gamma)")#text(" is the identity, and -1 if ")#mi("\\Gamma(\\gamma)")#text(" is the anti-identity. ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" (Monodromy) One can interpret the ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy maps")]#text(" of a ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("covering space")]#text(" in the language of connections. Suppose for instance that we have a covering space ")#mi("\\pi: \\tilde X \\to X")#text(" of a topological space X whose fibres ")#mi("\\pi^{-1}(\\{x\\})")#text(" are discrete; thus ")#mi("\\tilde X")#text(" is a discrete fibre bundle over X. The discreteness induces a natural connection ")#mi("\\Gamma")#text(" on this space, which is given by the lifting map; in particular, if one integrates this connection on a closed loop based at some point x, one obtains the monodromy map of that loop at x. ")#mi("\\diamond")

#strong[#text("Example 5.")]#text(" (Definite integrals) In view of the definition (2), it should not be surprising that the ")#link("http://en.wikipedia.org/wiki/Definite_integral")[#text("definite integral")]#text(" ")#mi("\\int_a^b f(x)\\ dx")#text(" of a scalar function ")#mi("f: [a,b] \\to {\\Bbb R}")#text(" can be interpreted as an integral of a connection. Indeed, set ")#mi("X := [a,b]")#text(", and let ")#mi("({\\Bbb R})_{x \\in X}")#text(" be the trivial line bundle over X. The function f induces a connection ")#mi("\\Gamma_f")#text(" on this bundle by setting")

#align(center)[#tao-fit-display[#mitex("\\Gamma_f(x \\mapsto x+dx): y \\mapsto y + f(x) dx.")]]

#text("The integral ")#mi("\\Gamma_f([a,b])")#text(" of this connection along ")#mi("{}[a,b]")#text(" is then just the operation of translation by ")#mi("\\int_a^b f(x)\\ dx")#text(" in the real line. ")#mi("\\diamond")

#strong[#text("Example 6.")]#text(" (Line integrals) One can generalise Example 5 to encompass ")#link("http://en.wikipedia.org/wiki/Line_integral")[#text("line integrals")]#text(" in several variable calculus. Indeed, if ")#mi("X")#text(" is an n-dimensional domain, then a vector field ")#mi("f = (f_1,\\ldots,f_n): X \\to {\\Bbb R}^n")#text(" induces a connection ")#mi("\\Gamma_f")#text(" on the trivial line bundle ")#mi("({\\Bbb R})_{x \\in X}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\Gamma_f( x \\mapsto x+dx ): y \\mapsto y + f_1(x) dx_1 + \\ldots + f_n(x) dx_n.")]]

#text("The integral ")#mi("\\Gamma_f(\\gamma)")#text(" of this connection along a curve ")#mi("\\gamma")#text(" is then just the operation of translation by the line integral ")#mi("\\int_\\gamma f \\cdot dx")#text(" in the real line.")

#text("Note that a gauge transformation in this context is just a vertical translation ")#mi("(x,y) \\mapsto (x,y+V(x))")#text(" of the bundle ")#mi("({\\Bbb R})_{x \\in X} \\equiv X \\times {\\Bbb R}")#text(" by some potential function ")#mi("V: X \\to {\\Bbb R}")#text(", which we will assume to be smooth for sake of discussion. This transformation conjugates the connection ")#mi("\\Gamma_f")#text(" to the connection ")#mi("\\Gamma_{f - \\nabla V}")#text(". Note that this is a ")#link("http://en.wikipedia.org/wiki/Conservative_force")[#text("conservative")]#text(" transformation: the integral of a connection along a closed loop is unchanged by gauge transformation. ")#mi("\\diamond")

#strong[#text("Example 7.")]#text(" (ODE) A different way to generalise Example 5 can be obtained by using the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus ")]#text("to interpret ")#mi("\\int_{[a,b]} f(x)\\ dx")#text(" as the final value ")#mi("u(b)")#text(" of the solution to the initial value problem")

#align(center)[#tao-fit-display[#mitex("u^{\\prime}(t) = f(t); \\quad u(a) = 0")]]

#text("for the ordinary differential equation ")#mi("u^{\\prime}=f")#text(". More generally, the solution u(b) to the initial value problem")

#align(center)[#tao-fit-display[#mitex("u^{\\prime}(t) = F( t, u(t) ); \\quad u(a) = u_0")]]

#text("for some ")#mi("u: [a,b] \\to {\\Bbb R}^n")#text(" taking values in some manifold Y, where ")#mi("F: [a,b] \\times {\\Bbb R}^n \\to {\\Bbb R}^n")#text(" is a function (let us take it to be Lipschitz, to avoid technical issues), can also be interpreted as the integral of a connection ")#mi("\\Gamma")#text(" on the trivial vector space bundle ")#mi("({\\Bbb R}^n)_{t \\in [a,b]}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\Gamma(t \\mapsto t+dt): y \\mapsto y + F(t,y) dt.")]]

#text("Then ")#mi("\\Gamma[a,b]")#text(" will map ")#mi("u_0")#text(" to ")#mi("u(b)")#text(", this is nothing more than the ")#link("http://en.wikipedia.org/wiki/Euler_method")[#text("Euler method")]#text(" for solving ODE. Note that the method of ")#link("http://en.wikipedia.org/wiki/Integrating_factor")[#text("integrating factors")]#text(" in solving ODE can be interpreted as an attempt to simplify the connection ")#mi("\\Gamma")#text(" via a gauge transformation. Indeed, it can be profitable to view the entire theory of connections as a multidimensional “variable-coefficient” generalisation of the theory of ODE. ")#mi("\\diamond")

#text("Once one selects a gauge, one can express a connection in terms of that gauge. In the case of ")#link("http://en.wikipedia.org/wiki/Vector_bundle")[#text("vector bundles")]#text(" (in which every fibre is a d-dimensional vector space for some fixed d), the covariant derivative ")#mi("\\nabla_v w(x)")#text(" of a section w of that bundle along some vector v emanating from x can be expressed in any given gauge by the formula")

#align(center)[#tao-fit-display[#mitex("\\nabla_v w(x)^i = v^\\alpha \\partial_\\alpha w(x)^i + v^\\alpha \\Gamma_{\\alpha j}^i w(x)^j")]]

#text("where we use the gauge to express w(x) as a vector ")#mi("(w(x)^1,\\ldots,w(x)^d)")#text(", the indices ")#mi("i, j = 1,\\ldots,d")#text(" are summed over the fibre dimensions (and ")#mi("\\alpha")#text(" summed over the base dimensions) as per the ")#link("http://en.wikipedia.org/wiki/Einstein_notation")[#text("usual conventions")]#text(", and the ")#mi("\\Gamma_{\\alpha j}^i := (\\nabla_{e_\\alpha} e_j)^i")#text(" are the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbols")[#text("Christoffel symbols")]#text(" of this connection relative to this gauge.")

#text("One example of this, which models ")#link("http://en.wikipedia.org/wiki/Electromagnetism")[#text("electromagnetism")]#text(", is a connection on a ")#link("http://en.wikipedia.org/wiki/Complex_line_bundle")[#text("complex line bundle")]#text(" ")#mi("V = (V_{t,x})_{(t,x) \\in {\\Bbb R}^{1+3}}")#text(" in ")#link("http://en.wikipedia.org/wiki/Spacetime")[#text("spacetime")]#text(" ")#mi("{\\Bbb R}^{1+3} = \\{ (t,x): t \\in {\\Bbb R}, x \\in {\\Bbb R}^3 \\}")#text(". Such a bundle assigns a complex line ")#mi("V_{t,x}")#text(" (i.e. a one-dimensional complex vector space, and thus isomorphic to ")#mi("{\\Bbb C}")#text(") to every point ")#mi("(t,x)")#text(" in spacetime. The structure group here is U(1) (strictly speaking, this means that we view the fibres as ")#emph[#text("normed")]#text(" one-dimensional complex vector spaces, otherwise the structure group would be ")#mi("{\\Bbb C}^\\times")#text("). A gauge identifies V with the trivial complex line bundle ")#mi("({\\Bbb C})_{(t,x) \\in {\\Bbb R}^{1+3}}")#text(", thus converting sections ")#mi("(w_{t,x})_{(t,x) \\in {\\Bbb R}^{1+3}}")#text(" of this bundle into complex-valued functions ")#mi("\\phi: {\\Bbb R}^{1+3} \\to {\\Bbb C}")#text(". A connection on V, when described in this gauge, can be given in terms of fields ")#mi("A_\\alpha: {\\Bbb R}^{1+3} \\to {\\Bbb R}")#text(" for ")#mi("\\alpha = 0,1,2,3")#text("; the covariant derivative of a section in this gauge is then given by the formula")

#align(center)[#mi("\\nabla_\\alpha \\phi := \\partial_\\alpha \\phi + i A_\\alpha \\phi")#text(".")]

#text("In the theory of electromagnetism, ")#mi("A_0")#text(" and ")#mi("(A_1,A_2,A_3)")#text(" are known (up to some normalising constants) as the ")#link("http://en.wikipedia.org/wiki/Magnetic_vector_potential")[#text("electric potential")]#text(" and ")#link("http://en.wikipedia.org/wiki/Magnetic_vector_potential")[#text("magnetic potential")]#text(" respectively. Sections of V do not show up directly in Maxwell’s equations of electromagnetism, but appear in more complicated variants of these equations, such as the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Maxwell-Klein-Gordon_equations")[#text("Maxwell-Klein-Gordon equation")]#text(".")

#text("A gauge transformation of V is given by a map ")#mi("U: {\\Bbb R}^{1+3} \\to S^1")#text("; it transforms sections by the formula ")#mi("\\phi \\mapsto U^{-1} \\phi")#text(", and connections by the formula ")#mi("\\nabla_\\alpha \\mapsto U^{-1} \\nabla_\\alpha U")#text(", or equivalently")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A_\\alpha \\mapsto A_\\alpha + \\frac{1}{i} U^{-1} \\partial_\\alpha U = A_\\alpha + \\partial_\\alpha \\frac{1}{i} \\log U.")]]

#text("In particular, the electromagnetic potential ")#mi("A_\\alpha")#text(" is not gauge invariant (which broadly corresponds to the concept of being ")#emph[#text("nonphysical")]#text(" or ")#emph[#text("nonmeasurable")]#text(" in physics), as gauge symmetry allows one to add an arbitrary gradient function to this potential. However, the ")#link("http://en.wikipedia.org/wiki/Curvature_form")[#text("curvature tensor")]

#align(center)[#tao-fit-display[#mitex("F_{\\alpha \\beta} := [\\nabla_\\alpha, \\nabla_\\beta] = \\partial_\\alpha A_\\beta - \\partial_\\beta A_\\alpha")]]

#text("of the connection is gauge-invariant, and physically measurable in electromagnetism; the components ")#mi("F_{0i} = -F_{i0}")#text(" for ")#mi("i=1,2,3")#text(" of this field have a physical interpretation as the ")#link("http://en.wikipedia.org/wiki/Electric_field")[#text("electric field")]#text(", and the components ")#mi("F_{ij} = -F_{ji}")#text(" for ")#mi("1 \\leq i < j \\leq 3")#text(" have a physical interpretation as the ")#link("http://en.wikipedia.org/wiki/Magnetic_field")[#text("magnetic field")]#text(". (The curvature tensor ")#mi("F")#text(" can be interpreted as describing the parallel transport of infinitesimal rectangles; it measures how far off the connection is from being ")#emph[#text("flat")]#text(", which means that it can be (locally) “straightened” via some choice of gauge to be the trivial connection. In nonabelian gauge theories, in which the structure group is more complicated than just the abelian group U(1), the curvature tensor is non-scalar, but remains gauge-invariant in a tensor sense (gauge transformations will transform the curvature as they would transform a ")#link("http://en.wikipedia.org/wiki/Tensor")[#text("tensor")]#text(" of the same rank).")

#text("Gauge theories can often be expressed succinctly in terms of a connection and its curvatures. For instance, ")#link("http://en.wikipedia.org/wiki/Maxwell%27s_equations")[#text("Maxwell’s equations")]#text(" in free space, which describes how electromagnetic radiation propagates in the presence of charges and currents (but no media other than vacuum), can be written (after normalising away some physical constants) as")

#align(center)[#tao-fit-display[#mitex("\\partial^\\alpha F_{\\alpha \\beta} = J_\\beta")]]

#text("where ")#mi("J_\\beta")#text(" is the ")#link("http://en.wikipedia.org/wiki/4-current")[#text("4-current")]#text(". (Actually, this is only half of Maxwell’s equations, but the other half are a consequence of the interpretation (*) of the electromagnetic field as a curvature of a U(1) connection. Thus this purely geometric interpretation of electromagnetism has some non-trivial physical implications, for instance ruling out the possibility of (classical) ")#link("http://en.wikipedia.org/wiki/Magnetic_monopole")[#text("magnetic monopoles")]#text(".) If one generalises from complex line bundles to higher-dimensional vector bundles (with a larger structure group), one can then write down the (classical) ")#link("http://en.wikipedia.org/wiki/Yang-Mills_equation")[#text("Yang-Mills equation")]

#align(center)[#tao-fit-display[#mitex("\\nabla^\\alpha F_{\\alpha \\beta} = 0")]]

#text("which is the classical model for three of the four fundamental forces in physics: the electromagnetic, weak, and strong nuclear forces (with structure groups U(1), SU(2), and SU(3) respectively). (The classical model for the fourth force, gravitation, is given by a somewhat different geometric equation, namely the ")#link("http://en.wikipedia.org/wiki/Einstein_equations")[#text("Einstein equations")]#text(" ")#mi("G_{\\alpha \\beta} = 8 \\pi T_{\\alpha \\beta}")#text(", though this equation is also “gauge-invariant” in some sense.)")

#text("The gauge invariance (or gauge freedom) inherent in these equations complicates their analysis. For instance, due to the gauge freedom (2), Maxwell’s equations, when viewed in terms of the electromagnetic potential ")#mi("A_\\alpha")#text(", are ill-posed: specifying the initial value of this potential at time zero does not uniquely specify the future value of this potential (even if one also specifies any number of additional time derivatives of this potential at time zero), since one can use (2) with a gauge function U that is trivial at time zero but non-trivial at some future time to demonstrate the non-uniqueness. Thus, in order to use standard PDE methods to solve these equations, it is necessary to first fix the gauge to a sufficient extent that it eliminates this sort of ambiguity. If one were in a one-dimensional situation (as opposed to the four-dimensional situation of spacetime), with a trivial topology (i.e. the domain is a line rather than a circle), then it is possible to gauge transform the connection to be completely trivial, for reasons generalising both the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("fundamental theorem of ODEs")]#text(". (Indeed, to trivialise a connection ")#mi("\\Gamma")#text(" on a line ")#mi("{\\Bbb R}")#text(", one can pick an arbitrary origin ")#mi("t_0 \\in {\\Bbb R}")#text(" and gauge transform each point ")#mi("t \\in {\\Bbb R}")#text(" by ")#mi("\\Gamma([t_0,t])")#text(".) However, in higher dimensions, one cannot hope to completely trivialise a connection by gauge transforms (mainly because of the possibility of a non-zero curvature form); in general, one cannot hope to do much better than setting a single component of the connection to equal zero. For instance, for Maxwell’s equations (or the Yang-Mills equations), one can trivialise the connection ")#mi("A_\\alpha")#text(" in the time direction, leading to the ")#emph[#text("temporal gauge condition")]

#align(center)[#mi("A_0 = 0")#text(".")]

#text("This gauge is indeed useful for providing an easy proof of local existence for these equations, at least for smooth initial data. But there are many other useful gauges also that one can fix; for instance one has the ")#link("http://en.wikipedia.org/wiki/Lorenz_gauge")[#text("Lorenz gauge")]

#align(center)[#tao-fit-display[#mitex("\\partial^\\alpha A_\\alpha = 0")]]

#text("which has the nice property of being ")#link("http://en.wikipedia.org/wiki/Lorentz_invariance")[#text("Lorentz-invariant")]#text(", and transforms the Maxwell or Yang-Mills equations into linear or nonlinear wave equations respectively. Another important gauge is the ")#link("http://en.wikipedia.org/wiki/Coulomb_gauge#Coulomb_gauge")[#text("Coulomb gauge")]

#align(center)[#tao-fit-display[#mitex("\\partial_i A_i = 0")]]

#text("where i only ranges over spatial indices 1,2,3 rather than over spacetime indices 0,1,2,3. This gauge has an elliptic variational formulation (Coulomb gauges are critical points of the functional ")#tao-math("\\int_{{\\Bbb R}^3} \\sum_{i=1}^3 \\left|A_i\\right|^2", block: false)#text(") and thus are expected to be “smaller” and “smoother” than many other gauges; this intuition can be borne out by standard elliptic theory (or ")#link("http://en.wikipedia.org/wiki/Hodge_theory")[#text("Hodge theory")]#text(", in the case of Maxwell’s equations). In some cases, the correct selection of a gauge is crucial in order to establish basic properties of the underlying equation, such as local existence. For instance, the simplest proof of local existence of the Einstein equations uses a ")#link("http://en.wikipedia.org/wiki/Harmonic_coordinates")[#text("harmonic gauge")]#text(", which is analogous to the Lorenz gauge mentioned earlier; the simplest proof of local existence of Ricci flow uses a gauge of de Turck that is also related to harmonic maps (see e.g. ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("my lecture notes")]#text("); and in my own work on wave maps, a certain “caloric gauge” based on harmonic map heat flow is crucial (see e.g. ")#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/")[#text("this post")]#text(" of mine). But in many situations, it is not yet fully understood whether the use of the correct choice of gauge is a mere technical convenience, or is more innate to the equation. It is definitely conceivable, for instance, that a given gauge field equation is well-posed with one choice of gauge but ill-posed with another. It would also be desirable to have a more gauge-invariant theory of PDEs that did not rely so heavily on gauge theory at all, but this seems to be rather difficult; many of our most powerful tools in PDE (for instance, the Fourier transform) are highly non-gauge-invariant, which makes it very inconvenient to try to analyse these equations in a purely gauge-invariant setting.")

#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-520708")[#strong[#text("Ray 4.0 : reality of the Virtual – Whereof one cannot speak")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2019")]

#text("[…] a connection so you know how the sections on the manifold on TM evolve in time. Please check out Terry Tao’s post, where he talks about the duality of differential geometry and number theory which splits the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-632842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2021")])]

#text("The usual interpretation of Maxwell’s equations is to assume the 4-current as a (given!) “source” and solve the equations for the 4-potential.")

#text("Another possible interpretation is to assume the 4-potential as (given!) “input” which (by Maxwell’s equations) uniquely define(!) the 4-current (as “output”) – thereby interpreting Maxwell’s equations as a mere definition(!) of the 4-current from the 4-potential (without any constraints on the 4-potential).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Puzzled")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-677694")[#strong[#text("Puzzled")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2023")])]

#text("Can you explain in more detail why Z/2Z is the structure group for angles?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Still Puzzled")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-677711")[#strong[#text("Still Puzzled")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2023")])]

#text("To elaborate on my question, I get that there is an orientation choice, but don’t we have freedom also choose what angle is equivalent to 0 for instance 360 degrees instead of 2pi radians? Am I missing a constraint here that prevents that?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-684530")[#strong[#text("Log-Concavity and Conformal Gauges – Gabe Khan's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2024")]

#text("[…] use gauges in ingenious ways to prove results in geometry and mathematical physics. There is a good blog post by Terry Tao on the topic and another on Uhlenbeck’s work when she won the Abel […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1be264da67992fbff0896f15259465e2b9eabc1daed23f0881d030207c45d1b8-cdad6c9bcf24ce638744447b776dc030d5d621705f27a52c47db04223247ed8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vahid")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-684864")[#strong[#text("Vahid")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2024")])]

#text("Dear Prof. Tao")

#text("Thank you for this great lecture.")

#text("Can you also make a comment on difference between gauge transformations (symmetries) of a system versus global symmetries. We know that the gauge symmetries have trivial (0 or boundary charges) Noether charges while the global symmetrie have non-trivial charges (like energy, …).")

#text("It seems that even those boundary charges are also important in gauge theories. For example in general relativity the only acceptable notion of energy is a Noether boundary charge associated to a boundary gauge transformation.")

#text("Now, I am confused when you say ”It would also be desirable to have a more gauge-invariant theory of PDEs that did not rely so heavily on gauge theory at all”.")

#text("How can we get the same gauge effects (like memory effect) if we do not have them in the first place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-684880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("By “not relying so heavily on gauge theory”, I am specifically referring to the technique (which is common in this subject) of requiring that one first place the PDE in a special gauge before applying non-gauge-invariant tools such as Fourier analysis. On the other hand, applying infinitesimal gauge transformations to construct Noether charges is a gauge-invariant operation and so I would consider it part of the “more gauge-invariant theory of PDE” that I had in mind.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-685660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("Dear Prof Tao,")

#text("Can you please tell a bit about large gauge transformations? Are they different from the gauge transformations described in this article?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-685663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("Large gauge transformations are the gauge transformations that cannot be continuously deformed to the trivial (identity) gauge transformation; they show up when there is non-trivial topology in the base and fibers of the bundle. For instance, suppose one wanted to decide when “noon” occurred at every point on the Earth (excluding the poles); this basically amounts to selecting a gauge for a circle bundle over the Earth in which every fiber is a 24-hour cycle. One option is to select noon to be when the sun is overhead (or as close to overhead as it can be, given the latitude). Another option is to select noon to be 12:00pm UTC. The two options are topologically distinct – if one goes once around the equator, the definition of noon will wander off by 24 hours in the former case, but stay fixed in the latter case, and there is no way to continuously deform one to other. So the gauge transformation that links the two gauges will be large instead of small.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-687030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2025")])]

#text("Hi Terry, I’m sure this sounds bananas, but I’m a physicist who is trying to imagine an extended version of (classical) electromagnetism that is not gauge invariant. That is, clearly Maxwell’s equations would have to be a limiting case, and in certain gauges, one can come up with a scalar “gauge wave,” but having a nontrivial coupling between these sectors seems quite challenging. Do you have any sense of what mathematical structures would be involved? I presume we can’t use fiber bundles without the internal symmetry of the gauge group, but is there a well known alternative to, say, working with 4-potentials instead? Is it still a fiber bundle, but the gauge group is now just the identity? Many thanks for any insight you can provide!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-687455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2025")])]

#text("Are equations (1) and (2) somehow incompletely rendered?")

#emph[#text("[I have now broken up these equations into two lines to make them more visible. =T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-688561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2025")])]

#text("“In several variable calculus, we learn several generalisations of this concept in which the domain and range of f to be multi-dimensional.”")

#text("Missing a word before “to be”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-688668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2025")])]

#text("Nevertheless, we can go ahead and arbitrary select a gauge for X by ")#emph[#text("orienting")]#text(" the graph G.")

#text("Should be “arbitrarily”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7085ec3d58478b5d8c1ba2bf9605a54219bbc62dd8f9e6720e741104dc82879-18efb89c4f697f895e62c275d4f773974f535ff8795db51040851d4c01677264.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orwin O'Dowd")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-2/#comment-692152")[#strong[#text("Orwin O'Dowd")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2026")])]

#text("Terence, your representation of the electric field as curvature seems to bear on the old problem of finding mechanical dimensions for electrodynamic variables. Euler’s hypothesis of surface charges fails to boundary layers and skin depts, throwing the question open. Taking charge to be rather mass spinning at the speed of light, hence in dimensions of velocity, I find the electric field in mass and length, here field sources and radius of curvature. Does that make any sense to you? Does any objection come to mind? I don’t consider these dimensions to be constitutive of the phenomena, merely instrumental as a guide to identifying them, and a shorthand for representation, simplifying some calculations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32699")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2008")])]

#text("Oh boy! As first-poster (at the time of writing, anyway), this is my chance to express appreciation of Terence Tao’s wonderful series of lectures.")

#text("This particular (gauge theory) lecture touches upon a topic of great practical interest in engineering, namely what the lecture calls “the challenge [of selecting] the gauge that maximizes the effectiveness of analytic methods.”")

#text("Very often in engineering, one has a global algebraic invariance that one wishes to promote to a local geometry invariance … and then link to conservation laws … would it be too much to hope for a few remarks on this topic?")

#text("Within the context of quantum simulation science, specifically within the (common) problem of dynamically simulating open quantum systems, there is a concrete example of this kind of mathematical challenge.")

#text("Namely, there is a well-known global algebraic symmetry associated with “ambiguity in the operator-product representation”. It is natural to ask—without necessarily having a clear idea of what the answer might be—what mathematical tools are available for promoting this global algebraic symmetry on linear quantum state-spaces, to a local geometric symmetry on nonlinear quantum state-spaces?")

#text("For all us engineers know, this is may be a well-established area of mathematics … or perhaps not … and in either case the necessary ideas are perhaps not all that easy to recognize.")

#text("As pretty much everyone appreciates, weblogs like Terence’s are a wonderful catalyst for helping people get started on these lines of inquiry.")

#text("So please accept my thanks, for a half-hour of pure enjoyment, which left behind (in one reader’s mind) the germ of new perspectives and new lines of inquiry that (hopefully) may grow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32702")[#strong[#text("Terry Tao and gauge theories « The Gauge Connection")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")]

#text("[…] I have found a beatiful post by Terry Tao, a Fields medallist, about gauge theories. See here for a worthwhile reading. This post is truly elucidating and so well written that I thought it was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32713")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("Dear Prof. Tao,")

#text("First of all, as a mathematical physicist, I must (as many others)")#linebreak()#text(" thank you for your clear and precise post on this beautiful topic.")#linebreak()#text(" I have a few comments regarding the last paragraph.")

#text("Indeed, gauge-invariant lines of attack for analytical aspects of")#linebreak()#text(" PDE’s endowed with gauge invariance or, more generally, with")#linebreak()#text(" some sort of constraint with respect to the Cauchy problem (i.e.")#linebreak()#text(" the system is under-determined but the initial data cannot be")#linebreak()#text(" arbitrary – it satisfies some relations given by components of the")#linebreak()#text(" PDE system in such a way that this relations are guaranteed to be")#linebreak()#text(" satisfied for all times due to the remaining (evolution) part of the")#linebreak()#text(" system, once they are satisfied by the initial data. Gauge fixing")#linebreak()#text(" gives a solution to the constraint part of the PDE system) are usually")#linebreak()#text(" based on configuration space techniques. A recent prime example")#linebreak()#text(" is the paper by Klainerman and Rodnianski (J. Hyperbolic Differ.")#linebreak()#text(" Equ. 4 (2007), 401-433) on the construction of a Kirchoff-Sobolev")#linebreak()#text(" parametrix for the wave equation and its use for an alternative, _gauge-invariant_ proof of the global well-posedness of the")#linebreak()#text(" Yang-Mills system established earlier by Eardley and Moncrief. This")#linebreak()#text(" construction also holds in curved spacetimes, and it’s based on")#linebreak()#text(" modifying the original Kirchoff-Sobolev construction by replacing")#linebreak()#text(" the spatial distance by another one, adapted to the geometry of a")#linebreak()#text(" null (i.e. characteristic) foliation of the spacetime. The latter device")#linebreak()#text(" is also remniscent of the landmark (and also configuration")#linebreak()#text(" space-based) proof by Christodoulou and Klainerman of the global")#linebreak()#text(" nonlinear stability of Minkowski spacetime w.r.t. the Einstein equations,")#linebreak()#text(" which also makes use of yet another configuration space method of")#linebreak()#text(" obtaining estimates, namely that of commuting vector fields.")

#text("The question of well-posedness of PDE systems endowed with")#linebreak()#text(" gauge invariance is related to another deep problem, namely:")#linebreak()#text(" What is the definition of hyperbolicity of a PDE system endowed")#linebreak()#text(" with gauge invariance (or, more generally, constraints)? A tentative")#linebreak()#text(" one, which works for many important examples (Einstein, Yang-Mills,")#linebreak()#text(" Maxwell, etc.), would be: “A PDE system with constraints such that")#linebreak()#text(" there is a solution of the latter (i.e., a gauge fixing prescription)")#linebreak()#text(" which renders the ‘reduced’ system hyperbolic in the usual sense”,")#linebreak()#text(" but this is too loose. Another line of attack would be to add extra,")#linebreak()#text(" auxiliary functions (fields) which correspond either to derivatives")#linebreak()#text(" of the fields and/or to “Lagrange multipliers” and demand that the")#linebreak()#text(" enlarged system is hyperbolic, but this enlargement also seems to")#linebreak()#text(" depend on the particular structure of the PDE system at hand.")#linebreak()#text(" It seems to me that a proper, _gauge-invariant_ definition of")#linebreak()#text(" hyperbolicity, which is obviously important from a physical viewpoint,")#linebreak()#text(" is crucial even to devise gauge-invariant analytical tools in a more")#linebreak()#text(" systematic fashion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32716")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("Dear Pedro,")

#text("Thanks for the comments! I agree that the recent progress by Klainerman-Rodnianski and others in establishing gauge-invariant analytic methods in physical (or configuration) space is very encouraging. There has also been some progress in finding gauge-invariant substitutes for some tools that used to rely (weakly) on frequency space, for instance using geometric heat flows as a substitute for Littlewood-Paley theory, or the spectral theory of the Laplacian as a substitute for the Fourier transform. And of course we have microlocal analysis, which is already set up to be invariant under canonical transformations and so has a good chance of having reasonable gauge-invariance properties also. But the one thing we are still missing is to have a gauge-invariant substitute for finer-scale frequency analysis, which is not as coarse as Littlewood-Paley theory or as restricted to high-frequency or semi-classical limits as microlocal analysis. In particular, a key thing one wants to do with waves is to separate them into pieces depending on their direction (or momentum); I don’t know of a way to do this other than by invoking the Fourier transform (or related transforms, such as Hilbert transforms, Riesz transforms, or Radon transforms) to work in frequency space (or momentum space), and this breaks all the gauge invariance. There are a few isolated papers that attempt to perform momentum decompositions by purely physical space means (e.g. by using various spacetime cutoffs) but progress here is still rather tentative.")

#text("At present, I am agnostic on which of these three general approaches (working with an artificial (but analytically convenient) gauge, working with a “geometrically natural” gauge, or working in a gauge-invariant context) is “best” for these sorts of problems; my guess is that we will need all three types of approaches, and be able to switch easily from one to the other when necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7646e6b1d35adbfaa921d634120fcb1eb33282ee29912c6fd34e7ffe580d4376-23f75807c0d2711a674be352bdac5bff038841e313540a7ac4659036feb4f45c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Muhammad Alkarouri")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32719")[#strong[#text("Muhammad Alkarouri")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2008")])]

#text("By a purely lucky coincidence, I was just yesterday looking at the concept of gauge yesterday, and I find this brilliant explanation.")#linebreak()#text(" As an aside, I would like to thank you (Prof. Tao) for the whole blog, and to ask when would you expect to publish the blog book you are preparing?")

#text("Back to the topic, in Wikipedia they are explaining a connection between a gauge and a corresponding psudo-norm. Can you shed a little light on that please?")#linebreak()#text(" And does it make sense to connect the gauge explanation here with your idea in linear geometry of interpreting a linear transformation as a multidimensional generalisation of a ratio?")

#text("Many thanks in advance,")

#text("Muhammad Alkarouri")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41cefa4973882f6cf1313142288f7dc1297efec19e561681cc1352d58209071e-91a4ad869e36f475aa9f416474315e22502dc46e4c002e2bcc563b8319c00990.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland Bacher")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32731")[#strong[#text("Roland Bacher")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2008")])]

#text("I think there is a tiny missprint in Example 1: It should read $\\mathbb Z/2\\mathbb Z\\ltimes S^1$ (In order to remind the notation easily, my thesis")#linebreak()#text(" adviser told me that the acting group opens its mouth and tries to swallow the group it acts upon.) Thanks for your blog and best wishes, Roland Bacher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("Dear Roland: thanks for the correction (and for the mnemonic!).")

#text("Dear Muhammad: The concept of a gauge function as used in convex geometry is only distantly related to the concept of a gauge for a bundle, though perhaps there is some natural way to interpret the former as a special case of the latter.")

#text("Multidimensional linear coordinate systems, which are given by linear transformations, are indeed multidimensional generalisations of one-dimensional coordinate systems, which can be viewed as ratios between some physical quantity (e.g. a unit length) and a numerical quantity (e.g. the number 1). But this is of course a rather special kind of ratio. The more typical ratios in practice connects one physical quantity to another, e.g. a speed 30 m/sec is a ratio between length and time, or equivalently a linear transformation from the one-dimensional vector space of time displacements to the one-dimensional vector space of spatial displacements. Multidimensional transformations, e.g. velocity (a linear transformation from the one-dimensional vector space of time displacements to the three-dimensional space of spatial displacements), or the action of a magnetic field acting on a charge (a linear transformation from the three-dimensional space of velocities to the three-dimensional space of forces) can thus be viewed as a multidimensional ratio, given not by a single number, but as a matrix of numbers, indexed by the various degrees of freedom for the input and output.")

#text("I just sent off the final galley proofs for my book to the AMS, and hopefully it should all be done before the end of the year (at which point I suppose I will start working on the next volume.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dbb388caee534c33f914b537280eb600bbe6bf21d396ce07e221e1b561073b-05efbf875afb17d0655237cf1a1b3f84cfccf6f11ed708175023bd13d505cce8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32776")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2008")])]

#text("Two other related topics:")

#text("1. Quivers. This theory basically concerns connections on vector bundles over (usually finite) directed graphs. One novel feature, over manifolds, is that the dimension of the “bundle” may change over different points. The “connection”, usually called a representation of the quiver, is a choice of linear map for each edge of the graph. If one fixes a gauge, i.e. a basis for each vector space, then the theory is boring — the space of connections is itself a big vector space. The interest is in the gauge transformations, whose group is the product of the general linear groups of the vector spaces.")

#text("In the most basic case, there is one edge. Then the nullity plus rank theorem says that there exists a gauge in which the linear map is especially simple. Gabriel’s theorem says that there are only discretely many gauge-equivalent classes iff the graph is ADE.")

#text("2. Currency trading (e.g. ")#link("http://front.math.ucdavis.edu/9710.3148")[#text("this paper")]#text("). Here the finite graph is a complete digraph on the set of currencies, and the linear maps (between all 1-d spaces; this is electromagnetism) are exchange rates. The curvature (magnetic field) measures the possibility of arbitrage, and abitrageurs are charged particles. This paper is great fun to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32782")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2008")])]

#text("In hopes of keeping this gauge-theory thread (gently) stimulated—because IMHO many more readers of this weblog have good ideas than are posting—perhaps students will be interested to learn that Shannon’s classic 1949 article ")#emph[#text("Communication in the Presence of Noise")]#text(" begins with the sentence “A method is developed for representing any communication system ")#emph[#text("geometrically")]#text("” (and Shannon’s article is still well worth reading today).")

#text("In the subsequent six decades, the geometric point-of-view pioneered by Shannon has flowered … and so has our algebraic, informatic, and combinatoric understanding (to name just a few other mathematical disciplines).")

#text("A nice thing about gauge formalisms is that they provide a natural meeting-ground for these mathematical points of view. The good news for younger mathematicians (and scientists, and engineers, and even economists) is that we still have a long way to go in understanding how these threads are most naturally united.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7646e6b1d35adbfaa921d634120fcb1eb33282ee29912c6fd34e7ffe580d4376-23f75807c0d2711a674be352bdac5bff038841e313540a7ac4659036feb4f45c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Muhammad Alkarouri")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32795")[#strong[#text("Muhammad Alkarouri")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2008")])]

#text("Thank you very much, Prof. Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cohomology for dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-34294")[#strong[#text("Cohomology for dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("[…] (In this context, the first cohomology becomes a quotient space rather than a group; see also my earlier post interpreting these cocycles in the language of gauge theory.) It seems to me that in this case, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Use basic examples to calibrate exponents « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-34465")[#strong[#text("Tricks Wiki: Use basic examples to calibrate exponents « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2008")])]

#text("[…] automatic by working exclusively with gauge-invariant notation (see also my earlier post on gauge theory). Another important test case for Schrödinger equations is the high-frequency limit , closely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-34840")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("[…] structure), isometric (to preserve metric structure), etc. Besides giving us useful symmetries to spend, the presence of such group actions allows one to apply the powerful techniques of representation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-35260")[#strong[#text("Michael Nielsen » Doing science online")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")]

#text("[…] other posts, on topics like Perelman’s proof of the Poincare conjecture, quantum chaos, and gauge theory. Many posts contain remarkable insights, often related to open research problems, and they […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1680af8f0e1a54ad62852e52976079e6485770e6fc6ce2a52013997d3ed7b119-7a27bef7cd621f3ca147a7a7b05913247f53c0107594c40023fd2773cd08f471.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Cargo")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-39398")[#strong[#text("Matt Cargo")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2009")])]

#text("Hi Terence,")#linebreak()#text(" In ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/#comment-32716")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/#comment-32716")]#linebreak()#text(" you said")#linebreak()#text(" “And of course we have microlocal analysis, which is already set up to be invariant under canonical transformations and so has a good chance of having reasonable gauge-invariance properties also. But the one thing we are still missing is to have a gauge-invariant substitute for finer-scale frequency analysis, which is not as coarse as Littlewood-Paley theory or as restricted to high-frequency or semi-classical limits as microlocal analysis.”")

#text("I studied this precisely this subject for my thesis at UC Berkeley. See for example the paper ")#link("http://arxiv.org/abs/math-ph/0506074")[#text("http://arxiv.org/abs/math-ph/0506074")]#text(" , in which I show that, in theory at least, creation and annihilation operators can be constructed out of the Weyl symbols of any quantum integrable system. These lead directly to higher order corrections to the Bohr–Sommerfeld quantization rules. There was a rub, unfortunately, which involves a gauge freedom: A")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1680af8f0e1a54ad62852e52976079e6485770e6fc6ce2a52013997d3ed7b119-7a27bef7cd621f3ca147a7a7b05913247f53c0107594c40023fd2773cd08f471.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Cargo")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-39399")[#strong[#text("Matt Cargo")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2009")])]

#text("[ahem, accidental return. To continue,]")#linebreak()#text(" At lowest order, there is the freedom in choosing the classical angle variables. This is unfortunate because these variables appear in the expression (interestingly, involving a symplectic connection) for the first correction to the symbols of the creation/annihilation operators. The expression is gauge invariant, but I was never able find a way to write it using only gauge-independent quantities, that is, with only the action variables. The problem persists at every order, and is in fact due the overall phase freedom in the quantum wavefunctions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grothendieck’s definition of a group « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-41891")[#strong[#text("Grothendieck’s definition of a group « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("[…] transport”) the fibre at the initial point of to the fibre at the final point; see this previous blog post for more discussion. Note that the identity property is redundant, being implied by the other three […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abd58512f59cce7268ad98b52e74d42da2f444c3ec28e76c750ec08bffabb1a8-7c055e8331130cba1d77b6543772114aceae9f0b7abc193af28283562aa73d09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will M Farr")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-41931")[#strong[#text("Will M Farr")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Dr. Tao,")

#text("I realize that I’m coming to this post late in the game, but I just wanted to give a data point regarding your musing that, “It is definitely conceivable, for instance, that a given gauge field equation is well-posed with one choice of gauge but ill-posed with another.” This is certainly the case for Einstein’s equation in general relativity, and has been a problem that the numerical relativity community has worked on extensively over the last few decades! Depending on the choice of gauge, the character of the equations can change completely—see Paschalidis, Khokhlov, and Novikov, arXiv:gr-qc/0511075 and Paschalidis, arXiv:0704.2861 for some work in classifying common first-order formulations of Einstein’s equation and constructing formulations that are well-posed in any gauge.")

#text("Thanks for the post—I love the clarity of your style in general, and in this post you really hit the ball out of the park.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-43416")[#strong[#text("Episode 005: 12-Gauge Theory – OR – How the Delorean Can Save Economics | Math for Primates")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2010")]

#text("[…] Terrence Tao on Gauge Theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Gaussian ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-43723")[#strong[#text("254A, Notes 6: Gaussian ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("[…] One approach here would be to artificially “fix a gauge” and work on some slice of the parameter space which is “transverse” to all the symmetries. With such an approach, one can use the classical change of variables formula. While this can certainly be done, we shall adopt a more “gauge-invariant” approach and carry the various invariances with us throughout the computation. (For a comparison of the two approaches, see this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-43748")[#strong[#text("Year Twenty Eight « Sarosh Wahla")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2010")]

#text("[…] (b) Learn about gauge theory; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cayley graphs and the geometry of groups « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-45933")[#strong[#text("Cayley graphs and the geometry of groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("[…] fibre subgraph. The notion of a splitting in group theory is analogous to the geometric notion of a global gauge. The existence of such a splitting or gauge, and the relationship between two such splittings or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-46134")[#strong[#text("it begins « 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2010")]

#text("[…] it begins 类归于： Learning,counter — 曾经话说要如何 @ 11:27 上午 0.later gauge […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-46526")[#strong[#text("counters « 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2010")]

#text("[…] .later gauge/integrability-V.E.Zakharov/Lars Onsager/dipole/dimensional analysis/ill-posed problems/Pascal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neurociência e o Projeto Ersätz-Brain… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-48781")[#strong[#text("Neurociência e o Projeto Ersätz-Brain… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2010")])]

#text("[…] de redes neurais via sistemas dinâmicos, modelo de Potts e, por que não, teorias de gauge (cf. What is a gauge?, Gauge theories (scholarpedia), Preparation for Gauge Theory e Gauge Theory (José […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-99881")[#strong[#text("Smolin (2011) | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")]

#text("[…] the remainder of this section, I use notes from Ganguli (1999), Singer (2001) and Tao (2008). Below I give a definition of a fiber bundle: Definition (Fiber Bundle): A fiber bundle consists […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4dc3d6a4cb63528e60034bfe04dc37103ccddc30cb7730bd9fd16b3e93795b3-a9fabdd4c11fd5fa0ad0a747d21da904bf20f8b71d33973ffc08125c5444342e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nlcatter")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-115094")[#strong[#text("nlcatter")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2011")])]

#text("you started out fine and then diverged to uselessness!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9528482a6a988e417e7796610ac432b1fda7c7dd63cffee3866c6e1dd59813cb-f1dac34232dc6725dc643ab999519d2002f24b58f85c7890d800b9196f42ba57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of artojh")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-187832")[#strong[#text("artojh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2012")])]

#text("Well written and explained, does the work of Ruđer Josip Bošković and his writing on relativity in his volumes written in 1785 have a bearing on the understanding of his use of guage co-ordinates well before the modern set of guage theories. Thanks Arto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-211405")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] time. (This is closely related to the concept of spending symmetry, which I discuss for instance in this post (or in Section 2.1 of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-211489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("wow, much love and appreciation. This just made me a smarter physics student. I could not begin to thank you enough. It was clear concise and beautiful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43dc3449f0a51d5323d43238990f27be8923feba147dc3f7426171170baecbb3-14e7174c040a427b5ae680746fd6a88d5553e4afa009b1f969a592e3f6847f93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Dobkin")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-233678")[#strong[#text("Daniel Dobkin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Beautifully clear, with lovely simple examples to clarify what the heck the obscure abstract definitions mean, in contrast to a number of other posts and pages I’ve read on the topic. If I remembered my differential geometry from Misner, Thorne and Wheeler three decades back I would have actually followed the details! But now I know what a fiber bundle is and why you might need to transport it. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b27bc80b9492e61975e55dbc22e31438c86cbbb11088c5314b78d98ad1c11aa3-7ba711a6bbfc2e737373eb5633e20458f5fe61a1c9f3de0669f643d8be9ff64c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? | What about being a physicist")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-249190")[#strong[#text("What is a gauge? | What about being a physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2013")])]

#text("[…] What is a gauge?. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c4b172db15948ae5560db86a84f43283cd4bf9e83d07cafe25547cde76b4ab9-ea817c449f6af1ad1c5529a66419b23636280545fdff5d3fbc5270d9206ae081.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simon Crase")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-254712")[#strong[#text("Simon Crase")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2013")])]

#text("Thank you for a clear exposition. I had been working my way the The Road to Reality until I hit a brick wall with Fibre Bundles & Gauge Theory. Thanks to you I have crashed though. And I’m making sense of some of the scatterd bricks, too…;-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-271333")[#strong[#text("What is the Significance of Lie Groups $SO(3)$ and $SU(2)$ to Particle Physics? | Wet Savanna Animals")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")]

#text("[…] Terrence Tao’s blog “What is a gauge?” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-280011")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")]

#strong[#text("What is Gauge Theory (intuitively)?")]

#text("Here’s a great answer from Terence Tao: ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2d66f61feb96f60bbe3f6cc07ab7815c48e7246a7c3c93464e536eb4f6b3fdc-31286ec124ba33c65b9f497f383dee997876f9a0ce0fe8a4ecbb1e2d5c17e0cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Varun")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-394752")[#strong[#text("Varun")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for such a clear exposition on gauge. I am a bachelor’s student, recently been trying to understand Donaldson and Kronheimer’s exposition The Geometry of Four Manifolds.")

#text("I have a somewhat naive question. I came across the following comment: ” Our ASD equation is non-linear, but more to the point it is not elliptic, i.e, the highest order part ")#mi("d^{+}")#text(" is not elliptic. This is clear from abstract grounds from the invariance of the equation under gauge transformations.”")

#text("How is the gauge group responsible for the ellipticity of the operator?")

#text("Varun")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-395019")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("Elliptic operators should have uniqueness of the Dirichlet problem, but gauge symmetry implies lack of uniqueness. (Or, one can look at how elliptic regularity is incompatible with gauge symmetry.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-410286")[#strong[#text("[转载]What’s a Gauge? | 小小泪")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")]

#text("[…] Terence Tao’s blog: What’s a Gauge. \"Gauge theory\" is a term which has connotations of being a fearsomely complicated part of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-447165")[#strong[#text("Terry Tao’s “what is a gauge?” | The Daily Pochemuchka")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")]

#text("[…] the introduction to the blog post of the same […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nistwo Rai")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-467249")[#strong[#text("Nistwo Rai")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2016")])]

#text("Can anyone help me.")#linebreak()#text(" What do you mean by saying half maximally gauged and maximally gauged????")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2da260a0de0ddaa5faaefc90775518f0baeecd14aa53266d656bb9e0da9faae8-a833d3fc876b6d1eaa963f7f60c3585f29fb7afcd5ed253421c7f7fca4063b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of imran khan")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-469738")[#strong[#text("imran khan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("the displacement vector arises due to gauge transformation is taken a time dependent, any one tell me, can we take")#linebreak()#text(" it as a function of “r” i-e B(r ) instead of B(t).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-471041")[#strong[#text("Omissions in Mathematics Education: Gauge Integration - Comments | Page 2 | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2016")]

#text("[…] concept of a \"gauge\" in physics isn't very intuitive. There are explanations such as ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")]#text(" , but I need someone to explain the explanation!) Stephen Tashi, Jul 25, 2016 at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4384aabf1c0fc5c9c8f2252e578af7edb60aeb02d1a4ede70b8a4ebc9cae1366-1f31c7d434b2640f17a93f67a3121ffe49dfc3a11c79e5583b4642fae0bc1fce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Bollinger")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-475463")[#strong[#text("Terry Bollinger")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2016")])]

#text("Very minor erratum: Coordinate Systems, #8 says ")#mi("x^2+y^2+z^2")#text("; perhaps ")#mi("x^2+y^2+z^2=1")#text(" was intended?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-479573")[#strong[#text("Symmetry → connection field → force of nature – Physics says what?")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")]#text(" [long technical explanation] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df0024a6fb41e61715766188c9c30f0af8ce8ca4728f7b90fb06d0ca08bf5a86-007891ddfbc321af447c3bee6484ecd8b1c858148191e9ac246ba4a9361fd3d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JR")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-480093")[#strong[#text("JR")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2017")])]

#text("I have one objection to this otherwise brilliant article. First, I do not think it is meaningful to say that a gauge transformation is necessarily a coordinate transformation. In fact, all physical theories should be invariant under arbitrary coordinate transformations. This is the reason why the group of diffeomorphisms of spacetime cannot be taken as a gauge group of any physical theory unless of course, you consider active diffeomorphisms. In the physics community, the term “gauge theory” is reserved for a much more restrictive class of physical theories.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-482050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2017")])]

#text("Tao….the most professional young mathematician")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An addendum to “arbitrage, amplification, and the tensor power trick” | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-485252")[#strong[#text("An addendum to “arbitrage, amplification, and the tensor power trick” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2017")])]

#text("[…] to proving inequalities such as (1). There is a complementary approach, discussed for instance in this previous post, which is to spend the symmetry to place the variable “without loss of generality” in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-518336")[#strong[#text("Particle physics – Beyond the standard model | helen the hare")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-518946")[#strong[#text("The Geometry of Wavefunctions – SPK Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")]

#text("[…] I skimmed the chapter “Connections on Fiber Bundles ” and read this wonderful post by Terence Tao describing in general what a Gauge Theory is. What I got from reading these texts […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-519324")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("I have a certain type of more “generalized” gauge transformation where I fail to clearly see how it relates to gauge transformations in the sense it has been described here. Its basically a certain trick which is used for example in the field of molecular magnetic response theory. A baby example would be like that:")

#text("Suppose you have a (measurable real (")#mi("\\Bbb R \\to \\Bbb R")#text(")) function ")#mi("f(x)")#text(" that is the ")#mi("x")#text("-derivative of a function ")#mi("E(x) = x + c")#text(", which is only known up to the constant ")#mi("c")#text(". In this setting ")#mi("f(x)")#text(" is independent of ")#mi("c")#text(" already point-wise, i.e. for each point ")#mi("x\\in\\Bbb R")#text(" “separately”. We can make use of that by instead of looking at specific ")#mi("E(x)")#text(" with certain specific constants ")#mi("c")#text(", we use a family of functions that is indexed by ")#mi("x")#text(": ")#mi("E_x(x) = \\{ x + c_x \\}_{x\\in\\Bbb R}")#text(". In that way one could for example choose for any point ")#mi("x_0")#text(" such a ")#mi("c_{x_0}")#text(" that ")#mi("E_{x_0}(x_0)")#text(" evaluates to ")#mi("=0")#text(" for each point ")#mi("x_0\\in \\Bbb R")#text(", by simply using ")#mi("c_{x_0}=-x_0")#text(".")

#text("Can someone help me to get a clear picture or formulation of this method?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-519339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("The mathematical formalism you are looking for here is not gauge theory, but rather ")#link("https://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaf theory")]#text(", which is related to gauge theory but is a different concept. What you are describing is the sheaf of (local or global) solutions ")#mi("E")#text(" to a differential equation, which in this particular case is ")#mi("\\frac{d}{dx} E(x) = f(x)")#text(". Viewing these solutions as sections of a line bundle on the domain (which in this case is the real line ")#mi("{\\bf R}")#text("), one can use gauge transformations to transform the differential equation (for instance, by subtracting a particular solution ")#mi("E_0")#text(" from this differential equation one can gauge transform to the simpler ODE ")#mi("\\frac{d}{dx} E(x) = 0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-519340")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("Sheaf theory! Many thanks and kind regards!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-519343")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("Sorry, I have one more burning question :-) When applying naively this procedure I have obtained a very interesting result, which keeps on puzzling me. Maybe you have a hint on what I could look at to understand better.")

#text("So when I decided on the condition to “fixed the gauge”, i.e. choose that ")#mi("E")#text(" should evaluate to ")#mi("0")#text(" (just to stay in the picture, the actual thing is a bit more complicated) I found that the transformation I needed (the “function” ")#mi("c_x")#text(") in order to achieve that, is intuitively physically much more meaningful then I expected. I didn’t expect it because ")#mi("c")#text(" in a way should not contain physical information in itself. So how can ")#mi("c_x")#text(" become that meaningful? And what the relation between ")#mi("c_x")#text(" and ")#mi("E=0")#text("?")

#text("I am aware its very vague, but in case you are interested I can send a short as possible but more precise summary through another channel. Its a current research project of mine which could lead to deepened understanding of some aspect of molecular magnetism. And this result is quite exciting for me but a big mystery as well.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-519355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("Can gauge therory be viewed as a particular case of a general simplifying method (for a given mathematical structure) to choose a particular canonical form of the mathematical sructure ?")
]
