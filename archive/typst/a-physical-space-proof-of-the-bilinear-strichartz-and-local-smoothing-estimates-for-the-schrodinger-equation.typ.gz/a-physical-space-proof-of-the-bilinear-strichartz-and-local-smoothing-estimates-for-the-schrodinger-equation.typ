// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/10/a-physical-space-proof-of-the-bilinear-strichartz-and-local-smoothing-estimates-for-the-schrodinger-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:18:43.660201+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A physical space proof of the bilinear Strichartz and local smoothing estimates for the Schrodinger equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A physical space proof of the bilinear Strichartz and local smoothing estimates for the Schrodinger equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/10/a-physical-space-proof-of-the-bilinear-strichartz-and-local-smoothing-estimates-for-the-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2013/07/10/a-physical-space-proof-of-the-bilinear-strichartz-and-local-smoothing-estimates-for-the-schrodinger-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The purpose of this post is to link to a short unpublished note of mine that I wrote back in 2010 but forgot to put on my web page at the time. Entitled “")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/07/bilinear.pdf")[#text("A physical space proof of the bilinear Strichartz and local smoothing estimates for the Schrodinger equation")]#text("“, it gives a proof of two standard estimates for the free (linear) Schrodinger equation in flat Euclidean space, namely the bilinear Strichartz estimate and the local smoothing estimate, using primarily “physical space” methods such as integration by parts, instead of “frequency space” methods based on the Fourier transform, although a small amount of Fourier analysis (basically sectoral projection to make the Schrodinger waves move roughly in a given direction) is still needed. This is somewhat in the spirit of an ")#link("http://www.ams.org/mathscinet-getitem?mr=1945287")[#text("older paper of mine")]#text(" with Klainerman and Rodnianski doing something similar for the wave equation, and is also very similar to a ")#link("http://www.ams.org/mathscinet-getitem?mr=2518079")[#text("paper of Planchon and Vega")]#text(" from 2009. The hope was that by avoiding the finer properties of the Fourier transform, one could obtain a more robust argument which could also extend to nonlinear, non-free, or non-flat situations. These notes were cited once or twice by some people that I had privately circulated them to, so I decided to put them online here for reference.")

#text("UPDATE, July 24: Fabrice Planchon has kindly supplied ")#link("http://math.unice.fr/~fab/bilinear-schrod-blog.html")[#text("another note")]#text(" in which he gives a particularly simple proof of local smoothing in one dimension, and discusses some other variants of the method (related to the paper of Planchon and Vega cited earlier).")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e35251de1b933b058b30942de0a0eb1a3c3e2023d65ea0d115d007e2be782507-ab221df27a73d6f3519ad13ae96c0846e077527e14ed3206c628f1c8b6972f2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aczel@bu.edu")]], [#link("https://terrytao.wordpress.com/2013/07/10/a-physical-space-proof-of-the-bilinear-strichartz-and-local-smoothing-estimates-for-the-schrodinger-equation/#comment-238163")[#strong[#text("aczel@bu.edu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Hi terry, I quoted your recent work on the prime gaps here: ")#link("http://blogs.discovermagazine.com/crux/?p=3178#.Ud202RyVY9k")[#text("http://blogs.discovermagazine.com/crux/?p=3178#.Ud202RyVY9k")]#text(" All best, Amir")
]
