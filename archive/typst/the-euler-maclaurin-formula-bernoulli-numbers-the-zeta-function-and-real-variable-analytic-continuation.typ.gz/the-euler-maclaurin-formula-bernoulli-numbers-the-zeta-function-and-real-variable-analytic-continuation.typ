// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/
// Converted to Typst by tao2typ: "2026-11-05T14:52:55.627500+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic continuation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic continuation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-05 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta(s)}")#text(" is defined in the region ")#mi("{\\text{Re}(s)>1}")#text(" by the absolutely convergent series ")#metadata(none) <tao-cb9d7890ca12537fb514>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s} = 1 + \\frac{1}{2^s} + \\frac{1}{3^s} + \\ldots.")]]

#text(" Thus, for instance, it is known that ")#mi("{\\zeta(2)=\\pi^2/6}")#text(", and thus ")#metadata(none) <tao-ae06b17fef8101a23101>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^2} = 1 + \\frac{1}{4} + \\frac{1}{9} + \\ldots = \\frac{\\pi^2}{6}.")]]



#text("For ")#mi("{\\text{Re}(s) \\leq 1}")#text(", the series on the right-hand side of ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(" is no longer absolutely convergent, or even conditionally convergent. Nevertheless, the ")#mi("{\\zeta}")#text(" function can be extended to this region (with a pole at ")#mi("{s=1}")#text(") by ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(". For instance, it can be shown that after analytic continuation, one has ")#mi("{\\zeta(0) = -1/2}")#text(", ")#mi("{\\zeta(-1) = -1/12}")#text(", and ")#mi("{\\zeta(-2)=0}")#text(", and more generally ")#metadata(none) <tao-1dd02ccb577aca62da04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\zeta(-s) = - \\frac{B_{s+1}}{s+1}")]]

#text(" for ")#mi("{s=1,2,\\ldots}")#text(", where ")#mi("{B_n}")#text(" are the ")#link("http://en.wikipedia.org/wiki/Bernoulli_number")[#text("Bernoulli numbers")]#text(". If one ")#emph[#text("formally")]#text(" applies ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(" at these values of ")#mi("{s}")#text(", one obtains the somewhat bizarre formulae ")#metadata(none) <tao-1cec177917a28d4c4548>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n=1}^\\infty 1 = 1 + 1 + 1 + \\ldots = -1/2")]]

#text(" ")#metadata(none) <tao-0eb1d8cb89614a82f796>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n=1}^\\infty n = 1 + 2 + 3 + \\ldots = -1/12")]]

#text(" ")#metadata(none) <tao-3e19185ce0a8335b26f5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n=1}^\\infty n^2 = 1 + 4 + 9 + \\ldots = 0")]]

#text(" and ")#metadata(none) <tao-c6562921586ee6fa79c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n=1}^\\infty n^s = 1 + 2^s + 3^s + \\ldots = -\\frac{B_{s+1}}{s+1}.")]]



#text("Clearly, these formulae do not make sense if one stays within the traditional way to evaluate infinite series, and so it seems that one is forced to use the somewhat unintuitive analytic continuation interpretation of such sums to make these formulae rigorous. But as it stands, the formulae look “wrong” for several reasons. Most obviously, the summands on the left are all positive, but the right-hand sides can be zero or negative. A little more subtly, the identities do not appear to be consistent with each other. For instance, if one adds ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(" to ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", one obtains ")#metadata(none) <tao-71c49e8438bb5478ae4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{n=1}^\\infty (n+1) = 2 + 3 + 4 + \\ldots = -7/12")]]

#text(" whereas if one subtracts ")#mi("{1}")#text(" from ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(" one obtains instead ")#metadata(none) <tao-a33beaec9c1f9ec63b3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n=2}^\\infty n = 0 + 2 + 3 + 4 + \\ldots = -13/12")]]

#text(" and the two equations seem inconsistent with each other.")

#text("However, it is possible to interpret ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(", ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", ")#link(<tao-3e19185ce0a8335b26f5>)[#text("(6)")]#text(" by purely real-variable methods, without recourse to complex analysis methods such as analytic continuation, thus giving an “elementary” interpretation of these sums that only requires undergraduate calculus; we will later also explain how this interpretation deals with the apparent inconsistencies pointed out above.")

#text("To see this, let us first consider a convergent sum such as ")#link(<tao-ae06b17fef8101a23101>)[#text("(2)")]#text(". The classical interpretation of this formula is the assertion that the partial sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\frac{1}{n^2} = 1 + \\frac{1}{4} + \\frac{1}{9} + \\ldots + \\frac{1}{N^2}")]]

#text("converge to ")#mi("{\\pi^2/6}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", or in other words that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\frac{1}{n^2} = \\frac{\\pi^2}{6} + o(1)")]]

#text("where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". Actually, by using the ")#link("http://en.wikipedia.org/wiki/Integral_test_for_convergence")[#text("integral test")]#text(" estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=N+1}^\\infty \\frac{1}{n^2} \\leq \\int_N^\\infty \\frac{dx}{x^2} = \\frac{1}{N}")]]

#text("we have the sharper result")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\frac{1}{n^2} = \\frac{\\pi^2}{6} + O(\\frac{1}{N}).")]]

#text("Thus we can view ")#mi("{\\frac{\\pi^2}{6}}")#text(" as the leading coefficient of the asymptotic expansion of the partial sums of ")#mi("{\\sum_{n=1}^\\infty 1/n^2}")#text(".")

#text("One can then try to inspect the partial sums of the expressions in ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(", ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", ")#link(<tao-3e19185ce0a8335b26f5>)[#text("(6)")]#text(", but the coefficients bear no obvious relationship to the right-hand sides:")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n=1}^N 1  & = N", block: true)



#tao-math("\\sum_{n=1}^N n  & = \\frac{1}{2} N^2 + \\frac{1}{2} N", block: true)



#tao-math("\\sum_{n=1}^N n^2  & = \\frac{1}{3} N^3 + \\frac{1}{2} N^2 + \\frac{1}{6} N.", block: true)
]

#text("For ")#link(<tao-c6562921586ee6fa79c7>)[#text("(7)")]#text(", the classical ")#link("http://en.wikipedia.org/wiki/Faulhaber%27s_formula")[#text("Faulhaber formula")]#text(" (or ")#emph[#text("Bernoulli formula")]#text(") gives ")#metadata(none) <tao-aaed739afcdf4c06b1b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{n=1}^N n^s = \\frac{1}{s+1} \\sum_{j=0}^s \\binom{s+1}{j} B_j N^{s+1-j}")]]



#align(center)[#tao-fit-display[#mitex("= \\frac{1}{s+1} N^{s+1} + \\frac{1}{2} N^s + \\frac{s}{12} N^{s-1} + \\ldots + B_s N")]]

#text("for ")#mi("{s \\geq 2}")#text(", which has a vague resemblance to ")#link(<tao-c6562921586ee6fa79c7>)[#text("(7)")]#text(", but again the connection is not particularly clear.")

#text("The problem here is the discrete nature of the partial sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N n^s = \\sum_{n \\leq N} n^s,")]]

#text("which (if ")#mi("{N}")#text(" is viewed as a real number) has jump discontinuities at each positive integer value of ")#mi("{N}")#text(". These discontinuities yield various artefacts when trying to approximate this sum by a polynomial in ")#mi("{N}")#text(". (These artefacts also occur in ")#link(<tao-ae06b17fef8101a23101>)[#text("(2)")]#text(", but happen in that case to be obscured in the error term ")#mi("{O(1/N)}")#text("; but for the divergent sums ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(", ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", ")#link(<tao-3e19185ce0a8335b26f5>)[#text("(6)")]#text(", ")#link(<tao-c6562921586ee6fa79c7>)[#text("(7)")]#text(", they are large enough to cause real trouble.)")

#text("However, these issues can be resolved by replacing the abruptly truncated partial sums ")#mi("{\\sum_{n=1}^N n^s}")#text(" with ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoothed sums")]#text(" ")#mi("{\\sum_{n=1}^\\infty \\eta(n/N) n^s}")#text(", where ")#mi("{\\eta: {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" is a ")#emph[#text("cutoff function")]#text(", or more precisely a compactly supported bounded function that is right-continuous at the origin and equals ")#mi("{1}")#text(" at ")#mi("{0}")#text(". The case when ")#mi("{\\eta}")#text(" is the indicator function ")#mi("{1_{[0,1]}}")#text(" then corresponds to the traditional partial sums, with all the attendant discretisation artefacts; but if one chooses a smoother cutoff, then these artefacts begin to disappear (or at least become lower order), and the true asymptotic expansion becomes more manifest.")

#text("Note that smoothing does not affect the asymptotic value of sums that were already absolutely convergent, thanks to the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(". For instance, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\eta(n/N) \\frac{1}{n^2} = \\frac{\\pi^2}{6} + o(1)")]]

#text("whenever ")#mi("{\\eta}")#text(" is a cutoff function (since ")#mi("{\\eta(n/N) \\rightarrow 1}")#text(" pointwise as ")#mi("{N \\rightarrow \\infty}")#text(" and is uniformly bounded). If ")#mi("{\\eta}")#text(" is equal to ")#mi("{1}")#text(" on a neighbourhood of the origin, then the integral test argument then recovers the ")#mi("{O(1/N)}")#text(" decay rate:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\eta(n/N) \\frac{1}{n^2} = \\frac{\\pi^2}{6} + O(\\frac{1}{N}).")]]

#text("However, smoothing can greatly improve the convergence properties of a divergent sum. The simplest example is ")#link("http://en.wikipedia.org/wiki/Grandi%27s_series")[#text("Grandi’s series")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty (-1)^{n-1} = 1 - 1 + 1 - \\ldots.")]]

#text("The partial sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N (-1)^{n-1} = \\frac{1}{2} + \\frac{1}{2} (-1)^{N-1}")]]

#text("oscillate between ")#mi("{1}")#text(" and ")#mi("{0}")#text(", and so this series is not conditionally convergent (and certainly not absolutely convergent). However, if one performs analytic continuation on the series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{(-1)^{n-1}}{n^s} = 1 - \\frac{1}{2^s} + \\frac{1}{3^s} - \\ldots")]]

#text("and sets ")#mi("{s = 0}")#text(", one obtains a formal value of ")#mi("{1/2}")#text(" for this series. This value can also be obtained by smooth summation. Indeed, for any cutoff function ")#mi("{\\eta}")#text(", we can regroup")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty (-1)^{n-1} \\eta(n/N) =")]]

#align(center)[#tao-fit-display[#mitex("\\frac{\\eta(1/N)}{2} + \\sum_{m=1}^\\infty \\frac{\\eta((2m-1)/N) - 2\\eta(2m/N) + \\eta((2m+1)/N)}{2}.")]]

#text("If ")#mi("{\\eta}")#text(" is twice continuously differentiable (i.e. ")#mi("{\\eta \\in C^2}")#text("), then from Taylor expansion we see that the summand has size ")#mi("{O(1/N^2)}")#text(", and also (from the compact support of ")#mi("{\\eta}")#text(") is only non-zero when ")#mi("{m=O(N)}")#text(". This leads to the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty (-1)^{n-1} \\eta(n/N) = \\frac{1}{2} + O( \\frac{1}{N} )")]]

#text("and so we recover the value of ")#mi("{1/2}")#text(" as the leading term of the asymptotic expansion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that if ")#mi("{\\eta}")#text(" is merely once continuously differentiable (i.e. ")#mi("{\\eta \\in C^1}")#text("), then we have a similar asymptotic, but with an error term of ")#mi("{o(1)}")#text(" instead of ")#mi("{O(1/N)}")#text(". This is an instance of a more general principle that smoother cutoffs lead to better error terms, though the improvement sometimes stops after some degree of regularity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The most famous instance of smoothed summation is ")#link("http://en.wikipedia.org/wiki/Ces%C3%A0ro_summation")[#text("Cesáro summation")]#text(", which corresponds to the cutoff function ")#mi("{\\eta(x) := (1-x)_+}")#text(". Unsurprisingly, when Cesáro summation is applied to Grandi’s series, one again recovers the value of ")#mi("{1/2}")#text(".")
]

#text("If we now revisit the divergent series ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(", ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", ")#link(<tao-3e19185ce0a8335b26f5>)[#text("(6)")]#text(", ")#link(<tao-c6562921586ee6fa79c7>)[#text("(7)")]#text(" with smooth summation in mind, we finally begin to see the origin of the right-hand sides. Indeed, for any fixed smooth cutoff function ")#mi("{\\eta}")#text(", we will shortly show that ")#metadata(none) <tao-9de9299028c394c4ecb7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{n=1}^\\infty \\eta(n/N) = -\\frac{1}{2} + C_{\\eta,0} N + O(\\frac{1}{N})")]]

#text(" ")#metadata(none) <tao-a8ec1083734ead420edb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n=1}^\\infty n \\eta(n/N) = -\\frac{1}{12} + C_{\\eta,1} N^2 + O(\\frac{1}{N})")]]

#text(" ")#metadata(none) <tao-4e13d9dc5d89486a8b5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{n=1}^\\infty n^2 \\eta(n/N) = C_{\\eta,2} N^3 + O(\\frac{1}{N})")]]

#text(" and more generally ")#metadata(none) <tao-eb13f9e702918f67677e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{n=1}^\\infty n^s \\eta(n/N) = -\\frac{B_{s+1}}{s+1} + C_{\\eta,s} N^{s+1} + O(\\frac{1}{N})")]]

#text(" for any fixed ")#mi("{s=1,2,3,\\ldots}")#text(" where ")#mi("{C_{\\eta,s}}")#text(" is the Archimedean factor ")#metadata(none) <tao-4f5e06391570409b4541>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("C_{\\eta,s} := \\int_0^\\infty x^s \\eta(x)\\ dx")]]

#text(" (which is also essentially the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text(" of ")#mi("{\\eta}")#text("). Thus we see that the values ")#link(<tao-1cec177917a28d4c4548>)[#text("(4)")]#text(", ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(5)")]#text(", ")#link(<tao-3e19185ce0a8335b26f5>)[#text("(6)")]#text(", ")#link(<tao-c6562921586ee6fa79c7>)[#text("(7)")]#text(" obtained by analytic continuation are nothing more than the constant terms of the asymptotic expansion of the ")#emph[#text("smoothed")]#text(" partial sums. This is not a coincidence; we will explain the equivalence of these two interpretations of such sums (in the model case when the analytic continuation has only finitely many poles and does not grow too fast at infinity) below the fold.")

#text("This interpretation clears up the apparent inconsistencies alluded to earlier. For instance, the sum ")#mi("{\\sum_{n=1}^\\infty n = 1 + 2 + 3 + \\ldots}")#text(" consists only of non-negative terms, as does its smoothed partial sums ")#mi("{\\sum_{n=1}^\\infty n \\eta(n/N)}")#text(" (if ")#mi("{\\eta}")#text(" is non-negative). Comparing this with ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text(", we see that this forces the highest-order term ")#mi("{C_{\\eta,1} N^2}")#text(" to be non-negative (as indeed it is), but does not prohibit the ")#emph[#text("lower-order")]#text(" constant term ")#mi("{-\\frac{1}{12}}")#text(" from being negative (which of course it is).")

#text("Similarly, if we add together ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text(" and ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(" we obtain ")#metadata(none) <tao-43a3f712a9f624724144>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{n=1}^\\infty (n+1) \\eta(n/N) = -\\frac{7}{12} + C_{\\eta,1} N^2 + C_{\\eta,0} N + O(\\frac{1}{N})")]]

#text(" while if we subtract ")#mi("{1}")#text(" from ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text(" we obtain ")#metadata(none) <tao-351718258fee2cf5cc5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{n=2}^\\infty n \\eta(n/N) = -\\frac{13}{12} + C_{\\eta,1} N^2 + O(\\frac{1}{N}).")]]

#text(" These two asymptotics are not inconsistent with each other; indeed, if we shift the index of summation in ")#link(<tao-351718258fee2cf5cc5a>)[#text("(17)")]#text(", we can write ")#metadata(none) <tao-7f13fba62b26d8f61cfc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{n=2}^\\infty n \\eta(n/N) = \\sum_{n=1}^\\infty (n+1) \\eta((n+1)/N)")]]

#text(" and so we now see that the discrepancy between the two sums in ")#link(<tao-71c49e8438bb5478ae4a>)[#text("(8)")]#text(", ")#link(<tao-a33beaec9c1f9ec63b3b>)[#text("(9)")]#text(" come from the shifting of the cutoff ")#mi("{\\eta(n/N)}")#text(", which is invisible in the formal expressions in ")#link(<tao-71c49e8438bb5478ae4a>)[#text("(8)")]#text(", ")#link(<tao-a33beaec9c1f9ec63b3b>)[#text("(9)")]#text(" but become manifestly present in the smoothed sum formulation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" By Taylor expanding ")#mi("{\\eta(n+1/N)}")#text(" and using ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(", ")#link(<tao-7f13fba62b26d8f61cfc>)[#text("(18)")]#text(" show that ")#link(<tao-43a3f712a9f624724144>)[#text("(16)")]#text(" and ")#link(<tao-351718258fee2cf5cc5a>)[#text("(17)")]#text(" are indeed consistent with each other, and in particular one can deduce the latter from the former.")
]

#heading(level: 1)[#strong[#text(" — 1. Smoothed asymptotics — ")]]

#text("We now prove ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(", ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text(", ")#link(<tao-4e13d9dc5d89486a8b5b>)[#text("(13)")]#text(", ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text(". We will prove the first few asymptotics by ")#emph[#text("ad hoc")]#text(" methods, but then switch to the systematic method of the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(" to establish the general case.")

#text("For sake of argument we shall assume that the smooth cutoff ")#mi("{\\eta: {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" is supported in the interval ")#mi("{[0,1]}")#text(" (the general case is similar, and can also be deduced from this case by redefining the ")#mi("{N}")#text(" parameter). Thus the sum ")#mi("{\\sum_{n=1}^\\infty \\eta(n/N) x^s}")#text(" is now only non-trivial in the range ")#mi("{n \\leq N}")#text(".")

#text("To establish ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(", we shall exploit the ")#link("http://en.wikipedia.org/wiki/Trapezoidal_rule")[#text("trapezoidal rule")]#text(". For any smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(", and on an interval ")#mi("{[n,n+1]}")#text(", we see from Taylor expansion that")

#align(center)[#tao-fit-display[#tao-math("f(n+\\theta) = f(n) + \\theta f^{\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^2} )", block: true)]]

#text("for any ")#mi("{0 \\leq \\theta \\leq 1}")#text(", ")#tao-math("{\\left\\|f\\right\\|_{\\dot C^2} := \\sup_{x \\in {\\bf R}} \\left|f^{\\prime\\prime}(x)\\right|}", block: false)#text(". In particular we have")

#align(center)[#tao-fit-display[#tao-math("f(n+1) = f(n) + f^{\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^2} )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_n^{n+1} f(x)\\ dx = f(n) + \\frac{1}{2} f^{\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^2} );", block: true)]]

#text("eliminating ")#mi("{f^{\\prime}(n)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_n^{n+1} f(x)\\ dx = \\frac{1}{2} f(n) + \\frac{1}{2} f(n+1) + O( \\left\\|f\\right\\|_{\\dot C^2} ).", block: true)]]

#text("Summing in ")#mi("{n}")#text(", we conclude the trapezoidal rule")

#tao-aligned(keep: true)[


#tao-math("\\int_0^N f(x)\\ dx  & = \\frac{1}{2} f(0) + f(1) + \\ldots + f(N-1) + \\frac{1}{2} f(N)", block: true)



#tao-math(" & + O( N \\left\\|f\\right\\|_{\\dot C^2} ).", block: true)
]

#text("We apply this with ")#mi("{f(x) := \\eta(x/N)}")#text(", which has a ")#mi("{\\dot C^2}")#text(" norm of ")#mi("{O(1/N^2)}")#text(" from the chain rule, and conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_0^N \\eta(x/N)\\ dx = \\frac{1}{2} + \\sum_{n=1}^\\infty \\eta(n/N) + O( 1/N ).")]]

#text("But from ")#link(<tao-4f5e06391570409b4541>)[#text("(15)")]#text(" and a change of variables, the left-hand side is just ")#mi("{N C_{\\eta,0}}")#text(". This gives ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(".")

#text("The same argument does not quite work with ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text("; one would like to now set ")#mi("{f(x) := x \\eta(x/N)}")#text(", but the ")#mi("{\\dot C^2}")#text(" norm is now too large (")#mi("{O(1/N)}")#text(" instead of ")#mi("{O(1/N^2)}")#text("). To get around this we have to refine the trapezoidal rule by performing the more precise Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f(n+\\theta) = f(n) + \\theta f^{\\prime}(n) + \\frac{1}{2} \\theta^2 f^{\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^3} )", block: true)]]

#text("where ")#tao-math("{\\left\\|f\\right\\|_{\\dot C^3} := \\sup_{x \\in {\\bf R}} \\left|f^{\\prime\\prime\\prime}(x)\\right|}", block: false)#text(". Now we have")

#align(center)[#tao-fit-display[#tao-math("f(n+1) = f(n) + f^{\\prime}(n) + \\frac{1}{2} f^{\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^3} )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_n^{n+1} f(x)\\ dx = f(n) + \\frac{1}{2} f^{\\prime}(n) + \\frac{1}{6} f^{\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^3} ).", block: true)]]

#text("We cannot simultaneously eliminate both ")#mi("{f^{\\prime}(n)}")#text(" and ")#mi("{f^{\\prime\\prime}(n)}")#text(". However, using the additional Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f^{\\prime}(n+1) = f^{\\prime}(n) + f^{\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^3} )", block: true)]]

#text("one obtains")

#tao-aligned(keep: true)[


#tao-math("\\int_n^{n+1} f(x)\\ dx  & = \\frac{1}{2} f(n) + \\frac{1}{2} f(n+1) + \\frac{1}{12} (f^{\\prime}(n) - f^{\\prime}(n+1))", block: true)



#tao-math(" & + O( \\left\\|f\\right\\|_{\\dot C^3} )", block: true)
]

#text("and thus on summing in ")#mi("{n}")#text(", and assuming that ")#mi("{f}")#text(" vanishes to second order at ")#mi("{N}")#text(", one has (by ")#link("http://en.wikipedia.org/wiki/Telescoping_series")[#text("telescoping series")]#text(")")

#align(center)[#tao-fit-display[#tao-math("\\int_0^N f(x)\\ dx = \\frac{1}{2} f(0) + \\frac{1}{12} f^{\\prime}(0) + \\sum_{n=1}^N f(n) + O( N \\left\\|f\\right\\|_{\\dot C^3} ).", block: true)]]

#text("We apply this with ")#mi("{f(x) := x \\eta(x/N)}")#text(". After a few applications of the chain rule and product rule, we see that ")#tao-math("{\\left\\|f\\right\\|_{\\dot C^3} = O(1/N^2)}", block: false)#text("; also, ")#mi("{f(0)=0}")#text(", ")#mi("{f^{\\prime}(0)=1}")#text(", and ")#mi("{\\int_0^N f(x)\\ dx = N^2 C_{\\eta,1}}")#text(". This gives ")#link(<tao-a8ec1083734ead420edb>)[#text("(12)")]#text(".")

#text("The proof of ")#link(<tao-4e13d9dc5d89486a8b5b>)[#text("(13)")]#text(" is similar. With a fourth order Taylor expansion, the above arguments give")

#tao-aligned(keep: true)[


#tao-math("f(n+1)  & = f(n) + f^{\\prime}(n) + \\frac{1}{2} f^{\\prime\\prime}(n) + \\frac{1}{6} f^{\\prime\\prime\\prime}(x) + O( \\left\\|f\\right\\|_{\\dot C^4} ),", block: true)



#tao-math("\\int_n^{n+1} f(x)\\ dx  & = f(n) + \\frac{1}{2} f^{\\prime}(n) + \\frac{1}{6} f^{\\prime\\prime}(n) + \\frac{1}{24} f^{\\prime\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^4} )", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#tao-math("f^{\\prime}(n+1) = f^{\\prime}(n) + f^{\\prime\\prime}(n) + \\frac{1}{2} f^{\\prime\\prime\\prime}(n) + O( \\left\\|f\\right\\|_{\\dot C^4} ).", block: true)]]

#text("Here we have a minor miracle (equivalent to the vanishing of the third Bernoulli number ")#mi("{B_3}")#text(") that the ")#mi("{f^{\\prime\\prime\\prime}}")#text(" term is automatically eliminated when we eliminate the ")#mi("{f^{\\prime\\prime}}")#text(" term, yielding")

#tao-aligned(keep: true)[


#tao-math("\\int_n^{n+1} f(x)\\ dx  & = \\frac{1}{2} f(n) + \\frac{1}{2} f(n+1) + \\frac{1}{12} (f^{\\prime}(n) - f^{\\prime}(n+1))", block: true)



#tao-math(" & + O( \\left\\|f\\right\\|_{\\dot C^4} )", block: true)
]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\int_0^N f(x)\\ dx = \\frac{1}{2} f(0) + \\frac{1}{12} f^{\\prime}(0) + \\sum_{n=1}^N f(n) + O( N \\left\\|f\\right\\|_{\\dot C^4} ).", block: true)]]

#text("With ")#mi("{f(x) := x^2 \\eta(x/N)}")#text(", the left-hand side is ")#mi("{N^3 C_{\\eta,2}}")#text(", the first two terms on the right-hand side vanish, and the ")#mi("{\\dot C^4}")#text(" norm is ")#mi("{O(1/N^2)}")#text(", giving ")#link(<tao-4e13d9dc5d89486a8b5b>)[#text("(13)")]#text(".")

#text("Now we do the general case ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text(". We define the ")#link("http://en.wikipedia.org/wiki/Bernoulli_number")[#text("Bernoulli numbers")]#text(" ")#mi("{B_0, B_1, \\ldots}")#text(" recursively by the formula ")#metadata(none) <tao-c4e476e5608e09eeb760>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{k=0}^{s-1} \\binom{s}{k} B_k = s")]]

#text(" for all ")#mi("{s =1,2,\\ldots}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("B_{s-1} := 1 - \\frac{s-1}{2} B_{s-2} - \\frac{(s-1)(s-2)}{3!} B_{s-3} - \\ldots - \\frac{1}{s} B_0.")]]

#text("The first few values of ")#mi("{B_s}")#text(" can then be computed:")

#align(center)[#tao-fit-display[#mitex("B_0=1; B_1=1/2; B_2=1/6; B_3=0; B_4=-1/30; \\ldots.")]]

#text("From ")#link(<tao-c4e476e5608e09eeb760>)[#text("(19)")]#text(" we see that ")#metadata(none) <tao-09e6ca237d559931cad2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_{k=0}^\\infty \\frac{B_k}{k!} [ P^{(k)}(1) - P^{(k)}(0) ] = P^{\\prime}(1)")]]

#text(" for any polynomial ")#mi("{P}")#text(" (with ")#mi("{P^{(k)}}")#text(" being the ")#mi("{k}")#text("-fold derivative of ")#mi("{P}")#text("); indeed, ")#link(<tao-c4e476e5608e09eeb760>)[#text("(19)")]#text(" is precisely this identity with ")#mi("{P(x) := x^s}")#text(", and the general case then follows by linearity.")

#text("As ")#link(<tao-09e6ca237d559931cad2>)[#text("(20)")]#text(" holds for all polynomials, it also holds for all formal power series (if we ignore convergence issues). If we then replace ")#mi("{P}")#text(" by the formal power series")

#align(center)[#tao-fit-display[#mitex("P(x) = e^{tx} = \\sum_{k=0}^\\infty t^k \\frac{x^k}{k!}")]]

#text("we conclude the formal power series (in ")#mi("{t}")#text(") identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty \\frac{B_k}{k!} t^k (e^t-1) = t e^t")]]

#text("leading to the familiar generating function")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty \\frac{B_k}{k!} t^k = \\frac{t e^t}{e^t-1}")]]

#text("for the Bernoulli numbers.")

#text("If we apply ")#link(<tao-09e6ca237d559931cad2>)[#text("(20)")]#text(" with ")#mi("{P}")#text(" equal to the antiderivative of another polynomial ")#mi("{Q}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 Q(x)\\ dx + \\frac{1}{2} (Q(1)-Q(0)) + \\sum_{k=2}^\\infty \\frac{B_k}{k!} [Q^{(k-1)}(1) - Q^{(k-1)}(0)] = Q(1)")]]

#text("which we rearrange as the identity")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 Q(x)\\ dx = \\frac{1}{2}(Q(0)+Q(1)) - \\sum_{k=2}^\\infty \\frac{B_k}{k!} [Q^{(k-1)}(1) - Q^{(k-1)}(0)]")]]

#text("which can be viewed as a precise version of the trapezoidal rule in the polynomial case. Note that if ")#mi("{Q}")#text(" has degree ")#mi("{d}")#text(", the only the summands with ")#mi("{2 \\leq k \\leq d}")#text(" can be non-vanishing.")

#text("Now let ")#mi("{f}")#text(" be a smooth function. We have a Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f(x) = Q(x) + O( \\left\\|f\\right\\|_{\\dot C^{s+2}} )", block: true)]]

#text("for ")#mi("{0 \\leq x \\leq 1}")#text(" and some polynomial ")#mi("{Q}")#text(" of degree at most ")#mi("{s+1}")#text("; also")

#align(center)[#tao-fit-display[#tao-math("f^{(k-1)}(x) = Q^{(k-1)}(x) + O( \\left\\|f\\right\\|_{\\dot C^{s+2}} )", block: true)]]

#text("for ")#mi("{0 \\leq x \\leq 1}")#text(" and ")#mi("{k \\leq s+2}")#text(". We conclude that")

#tao-aligned(keep: true)[


#tao-math("\\int_0^1 f(x)\\ dx  & = \\frac{1}{2}(f(0)+f(1))", block: true)



#tao-math(" & - \\sum_{k=2}^{s+1} \\frac{B_k}{k!} [f^{(k-1)}(1) - f^{(k-1)}(0)]", block: true)



#tao-math(" & + O( \\left\\|f\\right\\|_{\\dot C^{s+2}} ).", block: true)
]

#text("Translating this by an arbitrary integer ")#mi("{n}")#text(" (which does not affect the ")#mi("{\\dot C^{s+2}}")#text(" norm), we obtain ")#metadata(none) <tao-d6af0b0da416de4d5386>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\int_n^{n+1} f(x)\\ dx = \\frac{1}{2}(f(n)+f(n+1))")]]



#align(center)[#tao-fit-display[#tao-math("- \\sum_{k=2}^{s+1} \\frac{B_k}{k!} [f^{(k-1)}(n+1) - f^{(k-1)}(n)] + O( \\left\\|f\\right\\|_{\\dot C^{s+2}} ).", block: true)]]

#text("Summing the telescoping series, and assuming that ")#mi("{f}")#text(" vanishes to a sufficiently high order at ")#mi("{N}")#text(", we conclude the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(" ")#metadata(none) <tao-c7647006fa89ebe136b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_0^N f(x)\\ dx = \\frac{1}{2} f(0) + \\sum_{n=1}^N f(n) + \\sum_{k=2}^{s+1} \\frac{B_k}{k!} f^{(k-1)}(0)")]]



#align(center)[#tao-fit-display[#tao-math("+ O( N \\left\\|f\\right\\|_{\\dot C^{s+2}} ).", block: true)]]

#text("We apply this with ")#mi("{f(x) := x^s \\eta(x/N)}")#text(". The left-hand side is ")#mi("{C_{\\eta,s} N^{s+1}}")#text(". All the terms in the sum vanish except for the ")#mi("{k=s+1}")#text(" term, which is ")#mi("{\\frac{B_{s+1}}{s+1}}")#text(". Finally, from many applications of the product rule and chain rule (or by viewing ")#mi("{f(x) = N^s g(x/N)}")#text(" where ")#mi("{g}")#text(" is the smooth function ")#mi("{g(x) := x^s \\eta(x)}")#text(") we see that ")#tao-math("{\\left\\|f\\right\\|_{\\dot C^{s+2}} = O(1/N^2)}", block: false)#text(", and the claim ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" ")#metadata(none) <tao-200d6dbc09aebe2fbc6e>#text(" By using a higher regularity norm than the ")#mi("{\\dot C^{s+2}}")#text(" norm, we see that the error term ")#mi("{O(1/N)}")#text(" can in fact be improved to ")#mi("{O(1/N^B)}")#text(" for any fixed ")#mi("{B>0}")#text(", if ")#mi("{\\eta}")#text(" is sufficiently smooth.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Use ")#link(<tao-d6af0b0da416de4d5386>)[#text("(21)")]#text(" to derive Faulhaber’s formula ")#link(<tao-aaed739afcdf4c06b1b4>)[#text("(10)")]#text(". Note how the presence of boundary terms at ")#mi("{N}")#text(" cause the right-hand side of ")#link(<tao-aaed739afcdf4c06b1b4>)[#text("(10)")]#text(" to be quite different from the right-hand side of ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text("; thus we see how non-smooth partial summation creates artefacts that can completely obscure the smoothed asymptotics.")
]

#heading(level: 1)[#strong[#text(" — 2. Connection with analytic continuation — ")]]

#text("Now we connect the interpretation of divergent series as the constant term of smoothed partial sum asymptotics, with the more traditional interpretation via analytic continuation. For sake of concreteness we shall just discuss the situation with the Riemann zeta function series ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(", though the connection extends to far more general series than just this one.")

#text("In the previous section, we have computed asymptotics for the partial sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N)")]]

#text("when ")#mi("{s}")#text(" is a negative integer. A key point (which was somewhat glossed over in the above analysis) was that the function ")#mi("{x^{-s} \\eta(x)}")#text(" was smooth, even at the origin; this was implicitly used to bound various ")#mi("{\\dot C^k}")#text(" norms in the error terms.")

#text("Now suppose that ")#mi("{s}")#text(" is a complex number with ")#mi("{\\text{Re}(s)<1}")#text(", which is not necessarily a negative integer. Then ")#mi("{x^{-s} \\eta(x)}")#text(" becomes singular at the origin, and the above asymptotic analysis is not directly applicable. However, if one instead considers the telescoped partial sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) - \\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(2n/N),")]]

#text("with ")#mi("{\\eta}")#text(" equal to ")#mi("{1}")#text(" near the origin, then by applying ")#link(<tao-c7647006fa89ebe136b7>)[#text("(22)")]#text(" to the function ")#mi("{f(x) := x^{-s} \\eta(x/N) - x^{-s} \\eta(2x/N)}")#text(" (which vanishes near the origin, and is now smooth everywhere), we soon obtain the asymptotic ")#metadata(none) <tao-044322193f3c14de771b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) - \\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(2n/N)")]]



#align(center)[#tao-fit-display[#mitex("= C_{\\eta,-s} (N^{1-s} - (N/2)^{1-s}) + O(1/N).")]]

#text("Applying this with ")#mi("{N}")#text(" equal to a power of two and summing the telescoping series, one concludes that ")#metadata(none) <tao-bef610d68b35d356fe2e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) = \\zeta(s) + C_{\\eta,-s} N^{1-s} + O(1/N)")]]

#text(" for some complex number ")#mi("{\\zeta(s)}")#text(" which is basically the sum of the various ")#mi("{O(1/N)}")#text(" terms appearing in ")#link(<tao-044322193f3c14de771b>)[#text("(23)")]#text(". By modifying the above arguments, it is not difficult to extend this asymptotic to other numbers than powers of two, and to show that ")#mi("{\\zeta(s)}")#text(" is independent of the choice of cutoff ")#mi("{\\eta}")#text(".")

#text("From ")#link(<tao-bef610d68b35d356fe2e>)[#text("(24)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\lim_{N \\rightarrow \\infty} \\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) - C_{\\eta,-s} N^{1-s},")]]

#text("which can be viewed as a definition of ")#mi("{\\zeta}")#text(" in the region ")#mi("{\\text{Re}(s)<1}")#text(". For instance, from ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text(", we have now proven ")#link(<tao-1dd02ccb577aca62da04>)[#text("(3)")]#text(" with this definition of ")#mi("{\\zeta(s)}")#text(". However it is difficult to compute ")#mi("{\\zeta(s)}")#text(" exactly for most other values of ")#mi("{s}")#text(".")

#text("For each fixed ")#mi("{N}")#text(", it is not hard to see that the expression ")#mi("{\\frac{1}{n^s} \\eta(n/N) - C_{\\eta,-s} N^{1-s}}")#text(" is complex analytic in ")#mi("{s}")#text(". Also, by a closer inspection of the error terms in the Euler-Maclaurin formula analysis, it is not difficult to show that for ")#mi("{s}")#text(" in any compact region of ")#mi("{\\{ s \\in {\\bf C}: \\text{Re}(s) < 1\\}}")#text(", these expressions converge uniformly as ")#mi("{N \\rightarrow \\infty}")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(", we conclude that our definition of ")#mi("{\\zeta(s)}")#text(" is complex analytic in the region ")#mi("{\\{ s \\in {\\bf C}: \\text{Re} s < 1 \\}}")#text(".")

#text("We still have to connect this definition with the traditional definition ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(" of the zeta function on the other half of the complex plane. To do this, we observe that")

#align(center)[#tao-fit-display[#mitex("C_{\\eta,-s} N^{1-s} = \\int_0^N x^{-s} \\eta(x/N)\\ dx = \\int_1^N x^{-s} \\eta(x/N)\\ dx - \\frac{1}{s-1}")]]

#text("for ")#mi("{N}")#text(" large enough. Thus we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\frac{1}{s-1} + \\lim_{N \\rightarrow \\infty} \\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) - \\int_1^N x^{-s} \\eta(x/N)\\ dx")]]

#text("for ")#mi("{\\text{Re} s < 1}")#text(". The point of doing this is that this definition also makes sense in the region ")#mi("{\\text{Re}(s) > 1}")#text(" (due to the absolute convergence of the sum ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" and integral ")#mi("{\\int_1^\\infty x^{-s} dx}")#text(". By using the trapezoidal rule, one also sees that this definition makes sense in the region ")#mi("{\\text{Re}(s) > 0}")#text(", with locally uniform convergence there also. So we in fact have a globally complex analytic definition of ")#mi("{\\zeta(s) - \\frac{1}{s-1}}")#text(", and thus a ")#link("http://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic")]#text(" definition of ")#mi("{\\zeta(s)}")#text(" on the complex plane. Note also that this definition gives the asymptotic ")#metadata(none) <tao-d52b78b0b0630151485e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\zeta(s) = \\frac{1}{s-1} + \\gamma + O(\\left|s-1\\right|)", block: true)]]

#text(" near ")#mi("{s=1}")#text(", where ")#mi("{\\gamma}")#text(" is ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler’s constant")]#text(".")

#text("We have thus seen that asymptotics on smoothed partial sums of ")#mi("{\\frac{1}{n^s}}")#text(" gives rise to the familiar meromorphic properties of the Riemann zeta function ")#mi("{\\zeta(s)}")#text(". It turns out that by combining the tools of Fourier analysis and complex analysis, one can reverse this procedure and deduce the asymptotics of ")#mi("{\\frac{1}{n^s}}")#text(" from the meromorphic properties of the zeta function.")

#text("Let’s see how. Fix a complex number ")#mi("{s}")#text(" with ")#mi("{\\text{Re}(s) < 1}")#text(", and a smooth cutoff function ")#mi("{\\eta: {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" which equals one near the origin, and consider the expression ")#metadata(none) <tao-e5bf1f03cacff6adf049>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N)")]]

#text(" where ")#mi("{N}")#text(" is a large number. We let ")#mi("{A > 0}")#text(" be a large number, and rewrite this as")

#align(center)[#tao-fit-display[#mitex("N^{A} \\sum_{n=1}^\\infty \\frac{1}{n^{s+A}} f_A( \\log(n/N) )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_A(x) := e^{Ax} \\eta( e^x ).")]]

#text("The function ")#mi("{f_A}")#text(" is in the Schwartz class. By the Fourier inversion formula, it has a Fourier representation")

#align(center)[#tao-fit-display[#mitex("f_A(x) = \\int_{\\bf R} \\hat f_A(t) e^{-ixt}\\ dt")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\hat f_A(x) := \\frac{1}{2\\pi} \\int_{\\bf R} f_A(x) e^{ixt}\\ dx")]]

#text("and so ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(26)")]#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("N^{A} \\sum_{n=1}^\\infty \\frac{1}{n^{s+A}} \\int_{\\bf R} \\hat f_A(t) (n/N)^{-it}\\ dt.")]]

#text("The function ")#mi("{\\hat f_A}")#text(" is also Schwartz. If ")#mi("{A}")#text(" is large enough, we may then interchange the integral and sum and use ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(" to rewrite ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\hat f_A(t) N^{A+it} \\zeta(s+A+it)\\ dt.")]]

#text("Now we have")

#align(center)[#tao-fit-display[#mitex("\\hat f_A(t) = \\frac{1}{2\\pi} \\int_{\\bf R} e^{(A+it)x} \\eta(e^x)\\ dx;")]]

#text("integrating by parts (which is justified when ")#mi("{A}")#text(" is large enough) we have")

#align(center)[#tao-fit-display[#mitex("\\hat f_A(t) = -\\frac{1}{2\\pi (A+it)} F(A+it)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(A+it) = \\int_{\\bf R} e^{(A+it+1)x} \\eta^{\\prime}(e^x)\\ dx = \\int_0^\\infty y^{A+it} \\eta^{\\prime}(y)\\ dy.")]]

#text("We can thus write ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(26)")]#text(" as a contour integral")

#align(center)[#tao-fit-display[#mitex("\\frac{-1}{2\\pi i} \\int_{s+A-i\\infty}^{s+A+i\\infty} \\zeta(z) \\frac{N^{z-s} F(z-s)}{z-s}\\ dz.")]]

#text("Note that ")#mi("{\\eta^{\\prime}}")#text(" is compactly supported away from zero, which makes ")#mi("{F(A+it)}")#text(" an entire function of ")#mi("{A+it}")#text(", which is uniformly bounded whenever ")#mi("{A}")#text(" is bounded. Furthermore, from repeated integration by parts we see that ")#mi("{F(A+it)}")#text(" is rapidly decreasing as ")#mi("{t \\rightarrow \\infty}")#text(", uniformly for ")#mi("{A}")#text(" in a compact set. Meanwhile, standard estimates show that ")#mi("{\\zeta(\\sigma+it)}")#text(" is of polynomial growth in ")#mi("{t}")#text(" for ")#mi("{\\sigma}")#text(" in a compact set. Finally, the meromorphic function ")#mi("{\\zeta(z) \\frac{N^{z-s} F(z-s)}{z-s}}")#text(" has a simple pole at ")#mi("{z=1}")#text(" (with residue ")#mi("{\\frac{N^{1-s} F(1-s)}{1-s}}")#text(") and at ")#mi("{z-s}")#text(" (with residue ")#mi("{\\zeta(s) F(0)}")#text("). Applying the residue theorem, we can write ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{-1}{2\\pi i} \\int_{s-B-i\\infty}^{s-B+i\\infty} \\zeta(z) \\frac{N^{z-s} F(z-s)}{z-s}\\ dz - \\frac{N^{1-s} F(1-s)}{1-s} - \\zeta(s) F(0)")]]

#text("for any ")#mi("{B>0}")#text(". Using the various bounds on ")#mi("{\\zeta}")#text(" and ")#mi("{F}")#text(", we see that the integral is ")#mi("{O( N^{-B})}")#text(". From integration by parts we have ")#mi("{F(0)=-1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("F(1-s) = - (1-s) \\int_0^\\infty y^{-s} \\eta(y)\\ dy = -(1-s) C_{\\eta,-s}")]]

#text("and thus we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} \\eta(n/N) = \\zeta(s) + C_{\\eta,-s} N^{1-s} + O(N^{-B})")]]

#text("for any ")#mi("{B>0}")#text(", which is ")#link(<tao-eb13f9e702918f67677e>)[#text("(14)")]#text(" (with the refined error term indicated in Remark ")#link(<tao-200d6dbc09aebe2fbc6e>)[#text("4")]#text(").")

#text("The above argument reveals that the simple pole of ")#mi("{\\zeta(s)}")#text(" at ")#mi("{s=1}")#text(" is directly connected to the ")#mi("{C_{\\eta,-s} N^{1-s}}")#text(" term in the asymptotics of the smoothed partial sums. More generally, if a Dirichlet series")

#align(center)[#tao-fit-display[#mitex("D(s) = \\sum_{n=1}^\\infty \\frac{a_n}{n^s}")]]

#text("has a meromorphic continuation to the entire complex plane, and does not grow too fast at infinity, then one (heuristically at least) has the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{a_n}{n^s} \\eta(n/N) = D(s) + \\sum_\\rho C_{\\eta,\\rho-s-1} r_\\rho N^{\\rho-s} + \\ldots")]]

#text("where ")#mi("{\\rho}")#text(" ranges over the poles of ")#mi("{D}")#text(", and ")#mi("{r_\\rho}")#text(" are the residues at those poles. For instance, one has the famous ")#emph[#text("explicit formula")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\Lambda(n) \\eta(n/N) = C_{\\eta,0} N - \\sum_\\rho C_{\\eta,\\rho-1} N^\\rho + \\ldots")]]

#text("where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", ")#mi("{\\rho}")#text(" are the non-trivial zeroes of the Riemann zeta function (counting multiplicity, if any), and ")#mi("{\\ldots}")#text(" is an error term (basically arising from the trivial zeroes of zeta); this ultimately reflects the fact that the Dirichlet series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("has a simple pole at ")#mi("{s=1}")#text(" (with residue ")#mi("{+1}")#text(") and simple poles at every zero of the zeta function with residue ")#mi("{-1}")#text(" (weighted again by multiplicity, though it is not believed that multiple zeroes actually exist).")

#text("The link between poles of the zeta function (and its relatives) and asymptotics of (smoothed) partial sums of arithmetical functions can be used to compare elementary methods in analytic number theory with complex methods. Roughly speaking, elementary methods are based on leading term asymptotics of partial sums of arithmetical functions, and are mostly based on exploiting the simple pole of ")#mi("{\\zeta}")#text(" at ")#mi("{s=1}")#text(" (and the lack of a simple zero of Dirichlet ")#mi("{L}")#text("-functions at ")#mi("{s=1}")#text("); in contrast, complex methods also take full advantage of the zeroes of ")#mi("{\\zeta}")#text(" and Dirichlet ")#mi("{L}")#text("-functions (or the lack thereof) in the entire complex plane, as well as the functional equation (which, in terms of smoothed partial sums, manifests itself through the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text("). Indeed, using the above correspondences it is not hard to see that the prime number theorem (for instance) is equivalent to the lack of zeroes of the Riemann zeta function on the line ")#mi("{\\text{Re}(s)=1}")#text(".")

#text("With this dictionary between elementary methods and complex methods, the Dirichlet hyperbola method in elementary analytic number theory corresponds to analysing the behaviour of poles and residues when multiplying together two Dirichlet series. For instance, by using the formula ")#link(<tao-9de9299028c394c4ecb7>)[#text("(11)")]#text(" and the hyperbola method, together with the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n} \\eta(n/N) = \\int_1^\\infty \\eta(x/N)\\ \\frac{dx}{x} + \\gamma + O(1/N)")]]

#text("which can be obtained from the trapezoidal rule and the definition of ")#mi("{\\gamma}")#text(", one can obtain the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\tau(n) \\eta(n/N) = \\int_1^\\infty \\log x \\eta(x/N)\\ dx + 2\\gamma C_{\\eta,0} N + O(\\sqrt{N})")]]

#text("where ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(" is the divisor function (and in fact one can improve the ")#mi("{O(\\sqrt{N})}")#text(" bound substantially by being more careful); this corresponds to the fact that the Dirichlet series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\tau(n)}{n^s} = \\zeta(s)^2")]]

#text("has a double pole at ")#mi("{s=1}")#text(" with expansion")

#align(center)[#tao-fit-display[#mitex("\\zeta(s)^2 = \\frac{1}{(s-1)^2} + 2 \\gamma \\frac{1}{s-1} + O(1)")]]

#text("and no other poles, which of course follows by multiplying ")#link(<tao-d52b78b0b0630151485e>)[#text("(25)")]#text(" with itself.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" In the literature, elementary methods in analytic number theorem often use sharply truncated sums rather than smoothed sums. However, as indicated earlier, the error terms tend to be slightly better when working with smoothed sums (although not much gain is obtained in this manner when dealing with sums of functions that are sensitive to the primes, such as ")#mi("{\\Lambda}")#text(", as the terms arising from the zeroes of the zeta function tend to dominate any saving in this regard).")
]

#heading(level: 1)[#text("Comments (225)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e81ae5d6ad5e94006a27068dedaaa5f3a18ce0fdcc45827546ddb3b7ba6ac9e8-47700900c2e31552c886635d1e60d0b0066e8e4c71ca3bffbfeec4013633b1e7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44155")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Do you understand how Planck’s black-body radiation formula “should” be related to Euler-Maclaurin? I don’t think I’m even asking the question correctly, but confident you can deal with that part.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Ah, I remember discussing these sorts of questions back in grad school 🙂")

#text("Well, ostensibly most visible connection between the two is that the expression ")#mi("1 / (e^x-1)")#text(" appears in both. OK, let’s try deconstructing this, starting with Euler-Maclaurin. One way to formally derive it (which I didn’t emphasise above, as I wanted to keep things fairly elementary, and also rigorous) is to start with the Taylor expansion, which one can write as")

#mi("f(x+h) = e^{hD} f(x)")

#text("where ")#mi("D = \\frac{d}{dx}")#text(" is the derivative operator. In particular")

#mi("f(1)+\\ldots+f(N) = (e^D+\\ldots+e^{ND}) f(0) = \\frac{e^{(N+1)D} - e^D}{e^D-1} f(0)")#text(".")

#text("Using the power series expansion")

#mi("\\frac{D e^D}{e^D-1} = \\sum_{k=0}^\\infty \\frac{B_k}{k!} D^k")

#text("mentioned in the post and using Taylor expansion and the fundamental theorem of calculus (to invert ")#mi("D")#text(") one can then quickly obtain a formal derivation of the Euler-Maclaurin formula.")

#text("Now for black-body radiation. The key calculation here involves the expected particle number of a boson gas at frequency ")#mi("\\nu")#text(". Ignoring vacuum energy issues, a n-particle state here should have energy ")#tao-math("n h\\left|\\nu\\right|", block: false)#text(". At temperature ")#mi("T")#text(", the proportion of the state with particle number n is thus something like ")#tao-math("e^{-nh\\left|\\nu\\right|/kT}/Z(\\nu)", block: false)#text(", where ")#tao-math("Z(\\nu) = \\sum_n e^{-nh\\left|\\nu\\right|/kT}", block: false)#text(" is the partition function at this frequency (ignoring state multiplicity arising from spin). Summing the geometric-like series, we see that the expected particle number")

#tao-math("\\langle n \\rangle = \\sum_n n e^{-nh\\left|\\nu\\right|/kT} / \\sum_n e^{-nh\\left|\\nu\\right|/kT}", block: false)

#text("is then something like ")#tao-math("(h\\left|\\nu\\right|/kT) / (e^{h\\left|\\nu\\right|/kT}-1)", block: false)#text(", which then appears in the black-body radiation law. (In three dimensions, one then gets two extra powers of ")#tao-math("\\left|\\nu\\right|", block: false)#text(" coming from polar coordinates as ")#mi("\\nu")#text(" ranges over ")#mi("R^3")#text(" or a discretised version thereof.)")

#text("In one dimension, the frequency ")#mi("\\nu")#text(" is associated to the operator ")#mi("\\frac{c}{i} D")#text(" (this is just reflecting the relationship ")#mi("\\nu = c/\\lambda")#text("). So the energy is associated to ")#mi("-\\frac{hc}{i} D")#text(" (this reflects the relation ")#mi("E=pc")#text(") and so the partition function formally resembles something like ")#mi("\\sum_n e^{-n \\frac{hc}{ikT} D}")#text(". So I guess this is a sort of Wick rotation of the summation ")#mi("e^D + \\ldots + e^{ND}")#text(" that appears in Euler-Maclaurin. The expected particle number ")#mi("\\sum_n n e^{-n \\frac{hc}{ikT} D} / \\sum_n e^{-n \\frac{hc}{ikT} D}")#text(" can be viewed as a variant of the partition function. I guess if one is working in the low frequency regime then one can then Taylor expand in D and see a series with Bernoulli number coefficients appear.")

#text("To summarise: the low-frequency expansion of the black body radiation formula can be derived from a variant of a higher-dimensional Wick-rotated version of Euler-Maclaurin. It’s sort of a six-degrees-of-separation thing, but I guess there is some slight connection.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-621780")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("(Belatedly) The Wikipedia article Polylogarithm (")#link("https://en.wikipedia.org/wiki/Polylogarith")[#text("https://en.wikipedia.org/wiki/Polylogarith")]#text(") shows several relationships among the polylogarithms, the Bernoulli numbers, Riemann and Hurwitz zeta functions, and the Fermi-Dirac and Bose-Einstein distributions. In ")#link("https://oeis.org/A131758")[#text("https://oeis.org/A131758")]#text(", I pointed out relations among several special number sequences and associated polynomials, their interpolations, the deformed Todd operator, and the FD and BE distributions. Taking the Mellin transform of the distributions gives the polylogarithm over two different domains. Hyper (cluster) polylogarithms have also popped up in recent papers on scattering amplitudes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44158")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Should there be an expository tag? ")#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d13b52cde8a1b7d414731589e7f3104f563a41a738ea354e4b68064964953073-eba8b5b256a1d7287f43bdadec8c9af65fd59a2e56d6882398a0d2ed4b69c2af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44159")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("Small typo between (2) and (3)")

#mi("\\zeta (-1)=-1/12")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/726f84c354721680e56c0e8d3755d9ef91f2c5d5f1275d3cdf28b9253edd9013-7fa1b46fcc8735edc669a021662970b27e7c1c4cd54227247bf47c99198d5ef9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bryan Jacobs")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44198")[#strong[#text("Bryan Jacobs")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("typo is back!")#linebreak()#text(" ")#emph[#text("[Corrected (again), thanks. – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58cfd9d84fef5af31efe45f5015d0ecd845baca99a0369715f7409c47c6bf951-93d2f6a460075013a3ccf21b61762c00b59c805b23c27c9eb581aca475fedf31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44179")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2010")])]

#text("Typo: after “integral test estimate” the first integral sign should be a summation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f599d805903e52eab35492ba372e4219bb0b855bc5f715ccb7c3a9126facdbd-8eaaaaa0128bb89079cc3cc6c41577a09a0086cd169a1a4346475aa16097a8b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jamal")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44185")[#strong[#text("Jamal")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2010")])]

#text("YOU ARE GREAT! How can I learn mathematics by hard byhard")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c47081ae14a50579af5e1df24afc58f54c592a9550161272267222fef5c04bf-9f8092327deca609d8873380454867c9ff5068ea2bfbc49cf74b98ad1296832f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44187")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("Thanks!")

#text("Shouldn’t formula (8)")#linebreak()#text(" ")#mi("\\sum_{n=1}^\\infty n+1")#linebreak()#text(" read")#linebreak()#text(" ")#mi("\\sum_{n=1}^\\infty (n+1)")#linebreak()#text(" to avoid confusion with")#linebreak()#text(" ")#mi("(\\sum_{n=1}^\\infty n)+1")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]

#text("The expression")#linebreak()#text(" ")#mi("\\sum_{n=1}^\\infty \\eta(n/N) \\frac{1}{n^2}")#linebreak()#text(" should be understood as")#linebreak()#text(" ")#mi("lim_{N->\\infty}\\sum_{n=1}^N \\eta(\\frac n N) \\frac{1}{n^2}")#linebreak()#text(" Otherwise the expression depend on N.")#linebreak()#text(" Likewise the upper summation limit in formulas 11-12-13-14-16-17-18 should be N rather than \\infty.")

#text("The formula")#linebreak()#text(" \\displaystyle \\sum_{n=1}^\\infty (-1)^{n-1} \\eta(n/N) = \\frac{1}{2} + \\sum_{m=1}^\\infty \\frac{\\eta((2m-1)/N) – 2\\eta(2m/N) + \\eta((2m+1)/N)}{2}.")#linebreak()#text(" must be split into two lines in order to display correctly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c47081ae14a50579af5e1df24afc58f54c592a9550161272267222fef5c04bf-9f8092327deca609d8873380454867c9ff5068ea2bfbc49cf74b98ad1296832f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44188")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("I regret my second comment above. Now I got it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d644348f315b4b0ed511acbc112c69b2d5c0e70d5cf33f6b2796fb8c867eeb60-ad22295c7744c9330790bec00ed791ec18d3128823c620f24e2bdf36263054a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Javier")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44226")[#strong[#text("Javier")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2010")])]

#text("Pf. Tao,")

#text("I hope you do not shoot messengers bearing bad news!")

#text("I noticed equation 19 is incorrect. The series in equation (19) is equal to zero (I find it incredible no one has made a comment about this). Therefore, the recursion formula you suggest is incorrect. (I tested the recursion for the first few Bernoulli numbers, and I also checked in wolfram website in ")#link("http://mathworld.wolfram.com/BernoulliNumber.html")[#text("http://mathworld.wolfram.com/BernoulliNumber.html")]#text(" eq. #34). Therefore, the basis of your development in this blog seems suspect to me since equation 20 has no basis for polynomials unless you replace the first derivative evaluated at one to evaluation at zero for P(x;s) = x^s. It seem interesting to me that yet equation 20 is valid for P(x;t) = exp(xt). I think this has to do with the fact that P(0;t) is identical to one.")

#text("Sincerely,")

#text("Javier")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2010")])]

#text("Dear Javier,")

#text("I believe you are using the alternate definition of the Bernoulli numbers, in which ")#mi("B_1")#text(" is set to -1/2 rather than 1/2. There does not appear to be a consensus on which one is the canonical definition; both definitions have their own (minor) advantages. For instance, with the ")#mi("B_1 = 1/2")#text(" convention, the formula (7) can be extended to the case s=0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-621777")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("Looking at the Bernoulli polynomials rather than just the #s seems to collate formulas. Ramanujan’s Master Formula gives the Hurwitz zeta function as essentially an entire function interpolation of the Bernoulli polynomials ")#mi("(B.(x))^n = (b.+x)^n = B_n(x)")#text(" with e.g.f. ")#mi("e^{B.(x)t} = e^{(b.+x)t} = \\frac{t}{e^t-1} e^{xt}")#text(", for which the moments are the Bernoulli numbers with e.g.f. ")#mi("B(t)= \\frac{t}{e^t-1}")#text(" with ")#mi("b_1 = \\frac{-1}{2}")#text(" . This e.g.f. reflects the Bernoulli polynomials’ umbral derivational property ")#mi("D_x \\; x^n = (B.(x+1))^n - (B.(x))^n = B_{n}(x) - B_n(x) = n x^{n-1}")#text(", which extends formally term by term to any Taylor series as ")#mi("f^{\\prime}(x) = f(B.(x+1))-f(B.(x))")#text(". Defining ")#mi("B_1(0) = b_1 = \\frac{1}{2}")#text(" destroys this derivational property and redefines all higher degree Bernoulli polynomials. Rather, ")#mi("B_1(1) = \\frac{1}{2}")#text(", and this is the consistent with the RMT/Mellin interpolation of the Bernoulli polynomials to the Hurwitz zeta function ")#mi("B_{s}(z) = -s \\; \\zeta(1-s,z)")#text(", giving ")#mi("B_n(1) = -n \\; \\zeta(1-n,1) = -n \\; \\zeta(1-n) (Riemann) = (-1)^n B_n(0) = (-1)^n b_n")#text(". In the integrand of the MT interpolator, ")#mi("B(-t)")#text(" is the correct expression, which differs only in the term linear in ")#mi("t")#text(" from ")#mi("B(t)")#text(", i.e., ")#mi("B_n(0) = (-1)^n B_n(1)")#text(" with all odd index values vanishing but for ")#mi("n =1")#text(". Confer ")#link("https://mathoverflow.net/questions/353282/an-analytic-continuation-of-power-series-coefficients/379477#379477")[#text("https://mathoverflow.net/questions/353282/an-analytic-continuation-of-power-series-coefficients/379477#379477")]#text(". Reprising, the Riemann zeta function can be regarded as the Mellin interpolation of the sequence ")#mi("B_n(1) = (-1)^n B_n(0)")#text(". Summation formulas with the ‘Todd’ operator retain a nice form as well (cf. ")#link("https://mathoverflow.net/questions/380142/intuitive-explanation-why-shadow-operator-frac-ded-1-connects-logarithms/380189#380189")[#text("https://mathoverflow.net/questions/380142/intuitive-explanation-why-shadow-operator-frac-ded-1-connects-logarithms/380189#380189")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-621778")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("Cut and paste error: In my derivative formula, obviously one ")#mi("B_n(x)")#text(" should be ")#mi("B_n(x+1)")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d644348f315b4b0ed511acbc112c69b2d5c0e70d5cf33f6b2796fb8c867eeb60-ad22295c7744c9330790bec00ed791ec18d3128823c620f24e2bdf36263054a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Javier")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-44228")[#strong[#text("Javier")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2010")])]

#text("Dear Pf. Tao,")

#text("I must admit do not have a math degree, but I love mathematics because of it’s beauty. I am a test engineer by trade and therefore like to test the mathematical ideas I read. I thought B_1 = -1/2 was the “original” Bernoulli number 😉 Do you have a reference for the “extra crispy” definition of the Bernoulli, B_1 = 1/2?")

#text("I think I understand your article’s motivation: you are trying to create meaning to non-convergent series by applying a smoothing function to give a reasonable values to functions with integral representations (which can be analytically continued in the complex domain), thereby using the “asymptotic series” as a quick way to calculate values of these functions, such as the Riemann Zeta function (RZ). Is this correct? If this is the case, could this “approximation” method give an advantage in calculating the zeros of RZ ? I do not know, but my intuition tells me no.")

#text("Again thanks for the clarification and not shooting the messenger 🙂")

#text("Javier")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/905c2cc36f72519db16d843cd635ec38d798bd531e10d702e9c76a598db82ea8-2ba9ff87485624a744d5b578d1ae0473de8491703aaaf19b5bf81007a27b7ead.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anto.Mudhoka")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-503757")[#strong[#text("Anto.Mudhoka")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("moral:never argue with a fields medalist.hahaha")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-45182")[#strong[#text("Divergent sums and the class number formula « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2010")]

#text("[…] why Orde’s argument works. Specifically, I am going to use an idea which I learned from Terry Tao’s blog: Arguments about divergent sums are often really arguments about the constant term in asymptotic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10e635a4b06888f6e6e0817c5ce23294966bd09bf1e22ea42b3f6629842bc07e-e7c47b5a531b394b51b6911bfade26dc8fc6bf2977b78b137993b13e75d3f446.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Williams")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-45196")[#strong[#text("Jeremy Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("Before learning of Bernoulli Numbers, I myself have derived a closed formula for the summation of consecutive integers raised to the i power. Within this fomula I derived another closed formula for computing Bernoulli Numbers.")

#text("After this, I derived a much more efficient formula for generating the summation of consecutive integers riased to the i power. If you are interest in looking at my work (in pdf format) please reply to this post, and I will email it to you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/707640e2d5f4a924a5139f40c54947fbe6175eace6ba1d0fdf0ba40e2bc15435-47ff2103aff8795f5b9b4d96d961c78ca9ec55cf72250b03ab3cd4a4c64db92b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ketilo")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-504491")[#strong[#text("ketilo")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2018")])]

#text("Actually, *I* would be very interested. If you would be so kind, email me at ")#link("mailto:cherry@cherrytree.at")[#text("cherry@cherrytree.at")]#text(" please. I’m currently trying to get many different angles on this topic because I believe there to be a deeper hidden truth beyond what we understood by now. (But I’m far from understanding enough of it to advance in that direction)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618a6d20467401a8a2432716a979843fc6ead9949c14101bebd29af2e395a857-460c1bc434adeac9b73e4009705fe5c7956db03efa4d2ba7dce6845c5051a5d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Praveen")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-529071")[#strong[#text("Praveen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Jeremy, it’s a long time since you posted that comment. I wonder if you have uploaded your PDF to one of the archive servers. If so, please post a link.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10e635a4b06888f6e6e0817c5ce23294966bd09bf1e22ea42b3f6629842bc07e-e7c47b5a531b394b51b6911bfade26dc8fc6bf2977b78b137993b13e75d3f446.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Williams")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-45197")[#strong[#text("Jeremy Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("by the way, all of my computations and derivations give B(1) = +1/2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c24b01e47a6a3ac9833d8a771992b8243059177df48c568542c0ff37e0394c35-40d72cae43c3b5e394fa2774db5b2e6ff475b6657ba874ae7875c94454d6af94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Christensen")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-46550")[#strong[#text("Dan Christensen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("In the discussion of Grandi’s series, in the displayed equation after")

#text("“Indeed, for any cutoff function ")#mi("\\eta")#text(", we can regroup”")

#text("shouldn’t the leading term ")#mi("1/2")#text(" actually be ")#mi("\\eta(1/N)/2")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01a82a74eb2ec7290aa942be4b93128388d9ff0f93b6152862a97a1dd7abeb04-2e16108885b48c8794b353471a8028c596acdd9cbee30c07df98db29106bfe9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tereta")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-46778")[#strong[#text("tereta")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("I found my question,thanks”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3384b8ae5aef500a2154a87a377debf6ac56f9fdabeccb8ba0085aa350ebd02-3577dc8b0b3a0a1de21d9e3d144322c7f8751ca27c4b4a87a163d362ede8a1c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Atkin")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-47138")[#strong[#text("Max Atkin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I found this article a very interesting and fun read. I was wondering if there exists a more precise statement of the following (which appears just before you mention the “explicit formula” );")

#text("“More generally, if a Dirichlet series")

#mi("D(s) = \\sum_{n=1}^\\infty \\frac{a_n}{n^s}")

#text("has a meromorphic continuation to the entire complex plane, and does not grow too fast at infinity, then one (heuristically at least) has the asymptotic")

#mi("\\sum_{n=1}^\\infty \\frac{a_n}{n^s} \\eta(n/N) = D(s) + \\sum_\\rho c_{\\eta,\\rho-s-1} r_\\rho N^{\\rho-s} + \\ldots")

#text("where ")#mi("{\\rho}")#text(" ranges over the poles of ")#mi("{D}")#text(", and ")#mi("{r_\\rho}")#text(" are the residues at those poles.”")

#text("In particular, I would be interested to know what qualifications are hiding in “heuristically at least” and “does not grow too fast at infinity” – is there a theorem that states this somewhere?")

#text("Thanks,")#linebreak()#text(" Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-47150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("Well, I do not know of a precise reference, but most texts in analytic number theory would have some results along these lines, perhaps specialised to specific Dirichlet series such as the one for 1/zeta(s) or zeta'(s)/zeta(s). But the basic idea is simply to mimic the discussion given previously for the ")#mi("a_n=1")#text(" case to whatever Dirichlet series one is studying.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3384b8ae5aef500a2154a87a377debf6ac56f9fdabeccb8ba0085aa350ebd02-3577dc8b0b3a0a1de21d9e3d144322c7f8751ca27c4b4a87a163d362ede8a1c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Atkin")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-47187")[#strong[#text("Max Atkin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("Thank you for taking the time to reply. It sounds as if this is something that is approached on a case by case basis rather than proving a set of properties that a_n must satisfy in order for an “explicit formula” to exist. Is this because the latter approach is too hard?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-47189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("It’s more an issue of non-uniqueness. There are many different choices for what hypotheses to place here, and various conclusions one could reach (involving different hypotheses on the cutoff ")#mi("\\eta")#text(", different bounds on the error term, etc.). [This is common to many principles in analysis; they are not easily formalised by a “one-size-fits-all” theorem, in contrast to the more algebraic portions of mathematics, but instead need to be tailored to each separate application.]")

#text("Also, in most number-theoretic applications, the Dirichlet series in question obeys a functional equation, which can be used to strengthen the asymptotic to a significantly greater extent than can be done for a generic Dirichlet series. So it isn’t all that worthwhile to write down a specific instantiation of the heuristic formula until it is actually needed, other than as a useful exercise to test if one understands how such formulae would be derived.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-47458")[#strong[#text("Yet Another Article to Read During Break | What's Up")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")]

#text("[…] From Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-59949")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] sharper bounds available by using tools such as the Euler-Maclaurin formula (see this blog post). Exponentiating such asymptotics, incidentally, leads to one of the standard proofs of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb50c111fa3d396c0553e5db218d9a6dc1795bc00f9f6f3cf8c5051a4be6695c-3d9c61c0553ce45002722b358ded530054ba5ca185f65bb19dde84177e9b38e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of march")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-135581")[#strong[#text("march")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2012")])]

#text("Dr.Tao ,at s=0 the value should be -1/2 if i’m not mistaking ,anyway my question is this the only way this value obtainable ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb50c111fa3d396c0553e5db218d9a6dc1795bc00f9f6f3cf8c5051a4be6695c-3d9c61c0553ce45002722b358ded530054ba5ca185f65bb19dde84177e9b38e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of march")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-135961")[#strong[#text("march")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2012")])]

#text("I got it,the series is 1/2 but the value of zeta at s=0 is -1/2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-145701")[#strong[#text("What happens when a physicist does math :) | Room 196, Hilbert's Hotel")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2012")]

#text("[…] good reference to that is here. Wanna share?TwitterFacebookLinkedInEmailPrintLike this:LikeOne blogger likes this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90df7e46e381a0f33c732993f538e1eea560d5d255a836a8f30b1ca5836f29fd-a80aa36b3b26faee720192e5821cf8efdaff8d6ab57a17756378a7d0c2a320e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jose garcia")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-225804")[#strong[#text("jose garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2013")])]

#text("thanks for your lesson Professor Tao 🙂")

#text("my question is instead of smoothed sums could we use regulators ? for exapmle for the series {1+2+3+4+5+6+7+….} we introduce a parameter or regulator ‘s’ so { \\sum_{n=1}^{\\infty}n^{1-s}} so for big ‘s’ the sum conveges ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-236888")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("ZETA REGULARIZATION can also be extended to inlcude the renormalizatio of integrals ")#link("http://vixra.org/pdf/1305.0171v2.pdf")[#text("http://vixra.org/pdf/1305.0171v2.pdf")]#text(" however no one pays me attention since i am not famous..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90df7e46e381a0f33c732993f538e1eea560d5d255a836a8f30b1ca5836f29fd-a80aa36b3b26faee720192e5821cf8efdaff8d6ab57a17756378a7d0c2a320e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Javier Garcia Moreta")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-249092")[#strong[#text("Jose Javier Garcia Moreta")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2013")])]

#text("it should be worth mentioning that ZETA REGULARIZATION can be also be applied to divergent integrals in Quantum Field theory and not only for divergent series look ")#link("http://vixra.org/abs/1305.0171")[#text("http://vixra.org/abs/1305.0171")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d980d344250ef9ac82d6bc48803eec8acaa58927e0f297a490ff8e4de40af1b4-c2b5178843fa49b042ce0b48c83c374c6f4cfae1d522ed08a829ed274e392706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266455")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("it is been my experience information travels faster by word of mouth than first-hand experience.")

#text("a discussion of zeta-regularization – stripped of any physics – can be found on math.StackExchange:")#linebreak()#text(" ")#link("http://math.stackexchange.com/questions/39802/why-does-123-dots-1-over-12")[#text("http://math.stackexchange.com/questions/39802/why-does-123-dots-1-over-12")]

#text("I personally have doubts… you can pick any collection of weights and have them approach 1 and take the constant term. Standard procedure in QFT.")

#text("Nonetheless, -1/12 seems to be agreed as the value of the sum of the positive integers.")

#text("I like Dr. Tao’s explanation which uses numerical analysis rather than complex analysis, which feels contrived here. And he points out some holds I hadn’t observed before.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/670209cbae51b82325588c9e5081bb0b234eebdbbfe2765dbe1f75c87def627c-896f0be32cb5c0836969f585b824a344ce1b60ade7f657b0b0125a5b75c68cb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul Raj")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265672")[#strong[#text("Rahul Raj")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Don’t underestimate the Zeros!")

#text("This has a mix of Good Maths and Bad Maths which muddles the mind of the less-than-mathematically-inclined, including yours truly. However, the equations [4], [5], [6], [7], [8] and [9] (at least) make the same bad deductions as the numberphile video. You can see the fallacy here ")#link("http://rahulraj-says.blogspot.in/2014/01/the-power-of-zero.html﻿")[#text("http://rahulraj-says.blogspot.in/2014/01/the-power-of-zero.html﻿")]#text(".")

#text("If the car runs at a constant speed for an hour, it *seriously* impacts the averages, and it does not actually start running 4 times faster if it does a 4x speed only the other hour.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee8a6f46b45622af10c3f9cbe70b7cf111593ada7394feff903a069c1fc42deb-5242cd05298de9cecf2f6f0093f54167a5a726ac59edf836c65356879fbc9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("But you did not take your example to infinity. When you do the result can be negative. This is a well observed occurrence in several branches of physics starting with thermodynamics through string theory. It has even been experimentally demonstrated (in atomic physics). It is certainly unintuitive that summing positive numbers could result in a negative value, but the piece missing is that infinity is not intuitive — any introductory course on number theory or complex analysis will inform you of this. I recommend you do a bit more exploratory learning rather than claiming fallacies where they do not exist. The mathematics here is sound: Professor Tao even demonstrated several different methods at arriving with the same conclusion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2b1fb63da9c8bd495aabba7e7ca1446abf045811c2d9dd1e97ae064fb195cf-181677e239120b180f7cb7c0deadc41618505261f76327632819f7699fe98065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jj")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266129")[#strong[#text("jj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("only because it’s not intuitive doesn’t mean a nonsense result isn’t a nonsense result. “the result isn’t intuitive, but infinity isn’t, so this must be correct then” is no valid method of proof.")#linebreak()#text(" the classical sum over the natural numbers doesn’t exist (nor is it negative).")#linebreak()#text(" and terence tao says that in this very blog post, look above. and the wikipedia page on it says it right in the beginning. but many people tend to ignore that. because it’d be cooler to sum infinitely many positive numbers to get a negative number. that’s more psychology than mathematics.")

#text("what is being done here is not calculating the classical sum of those divergent series by “some new method”, but a method of assigning a value to a divergent sum, which isn’t really free of inconsistencies.")

#text("we need to be careful and not mix up the theory of sequences and infinite sums with what might be called ramanujan summation.")#linebreak()#text(" similarly we shouldn’t mix up the (cauchy) principal value of some divergent integral with the proper integral. for example")#linebreak()#text(" int 1/x over [-1,1] doesn’t exist, but the cauchy principal value would be 1. they are 2 different things, and a thing like the principal value exists, because it’s useful, but it’s not necessarily the “better concept”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-487580")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2017")])]

#text("I don’t think you actually read the blog post. Terence Tao CLEARLY stated that these inconsistencies are apparent and can be resolved by using smooth function which replace the discrete functions. This is correct, because using a function which is only defined for natural numbers and then evaluating the limit to infinity is not appropriate, because there are infinitely many functions which can satisfy those outputs from the partial sumvalues at natural inputs, so it is not sufficient to determine information about bounded behavior. Plus, it assumes that infinity behaves like an integer number, even though we can prove it does not.")

#text("What Terence Tao provided in this blog post is a numerical, functional analysis of partial sums by utilizing expressions which are differentiable, continuous, and valid for all complex numbers, and then evaluating the limit to infinity. Therefore, this is all consistent with the definition of convergent sums and the definition of a series. In fact, declaring these sums are divergent is itself misnomer and inaccurate.")

#text("Also, Tao did not actually say the sums do not exist, he said the sums appear nonsensical from a traditional point of view, nonsensical coming to mean unintuitive and inexplicable or unjustifiable.")

#text("Yes, Wikipedia does say the sum does not exist classically. No one cares about what Wikipedia says, it is not a scholarly source.")

#text("Lastly, but not least, you complete ignored all of the mathematics Tao presented here in the blog, which do not rely on Ramanujan summation.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dcb8d16e8d84e4357f61aafa0a607160757767a31164d5d765752e767372cf0-88e5e58998ee3d945e0561f6032ef86551d4ea13e3966685d648d35e3ff788dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-511823")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2019")])]

#text(">No one cares about what Wikipedia says, it is not a scholarly source.")

#text("By a natural extension of your statement, since this is a blog and not a scholarly source, no one needs to care about what you or Dr. Tao said.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-511892")[#strong[#text("Ángel")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2019")])]

#text("Dr. Terrence Tao is a scholarly source. Mathematicians who do or have done on the research on the subject and have written on it are by default scholarly sources. You are correct that the blog itself does not mean anything as a source, but that is completely irrekevant, ultimately. That is the difference between Wikipedia and this blog. Now how about you stop trying i be a smartass and try providing a valid counterargument? That would be appreciated very much. I don’t expect one, though, because it is difficult to come up for a counterargument against facts and mathematical truths.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angel Mendez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-494022")[#strong[#text("Angel Mendez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("You have absolutely no respect. Terrence Tao has been studying mathematics for nearly half a century, and he is one of the most respected mathematicians of our time, calling him less-than-mathematically inclined is truly an insult and it does not show anything about the mathematical theory he offers here. This man has probably contributed more to the field than you will ever be able to.You should be ashamed of yourself and be more respectful. Also, the addition of 0 does impact a sum, but I fail to see how this exactly relevant when discussing the identities you mentioned, since the functions over which they sum produce no zeros whatsoever. I think you have to be a serious troll.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0490988bcb012d89ecab4bdec9aae62420e27cfa32d326b7562c7696be41704b-abd2bdda103f6bb145ea8316d37cf18fdfc307ccb68a834ed41f01142f30b6b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tennison")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265698")[#strong[#text("Tennison")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Sum of all the positive numbers is equal to a negative number ???????")#linebreak()#text(" How is it possible ?????????")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angel Mendez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-494023")[#strong[#text("Angel Mendez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Summation over a set the natural numbers is only closed for a finitely many addends, not for infinitely many. This should not be surprising, since summation for finitely many addends is also commutative and associative, but is neither for infinitely many, as was demonstrated with the Riemann Theorem of Rearrangement. It is possible for the same reason that infinitely many rational numbers summed can equal an irrational number.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265792")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("Infinity behaves in misterious ways. Why are you surprised that positive numbers can add up to a negative number in infinity, but not be touched by the counter-intuitive result of equation (2) ? The sum of rational numbers gives an irrational number as a result, in infinity… if you accept this as a well-known result, I think you can accept just as easily that adding up positive integers may lead to a negative fraction in infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2b1fb63da9c8bd495aabba7e7ca1446abf045811c2d9dd1e97ae064fb195cf-181677e239120b180f7cb7c0deadc41618505261f76327632819f7699fe98065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jj")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266130")[#strong[#text("jj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("you should only accept correct results.")#linebreak()#text(" while there are results that might seem counter-intuitive but are correct, there are also counter-intuitive results that are simply wrong. =)")#linebreak()#text(" if you actually calculate partial sums (while doing that you should [in the long run] get closer to the limit of the series, if it exists!) you will realise that if you sum (2) you really get close to 1/6 pi^2. while if you calculate partial sums of the sum of natural numbers you will realise that the number gets bigger, and the series diverges. and you can show that in under 3 lines.")#linebreak()#text(" calculating partial sums is no proof but maybe it will help you to visualize. convergence or divergence of the respective series can be proven without big effort.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angel Mendez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-494024")[#strong[#text("Angel Mendez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("The problem with your argument is that it ignores that any operation which maps from the subspace of functions to a subspace of function sequences is only defined for a parameter N where is in the set of natural numbers. In other words, the operation limit ({n –> Inf}, Sum[m=1,n; f(m) = m]) is actually not well-defined because the expression inside the limit is only defined if n is a natural number, which means that the co-domain of the map is very discontinuous and ill-behaved. As such, the limit to infinity is indeterminate. It is possible to prove that there are infinitely many functions which give an element of the sequence for the corresponding natural number, and it is possible to show that not all such functions have a defined limit to infinity. For example, I can define an oscillatory function f(z) bounded by the curve which continues the map of natural numbers to their respective triangular numbers, such that at every input n where n is a natural number, f(n) = n(n+1)/2, but disagrees with this curve otherwise – which it must, since by definition f(n) is oscillatory, so f(z) = k(z)*cos(z+t), where t is a fixed constant. Even without obtaining an explicit expression in terms of elementary functions, the fact that I can define this function and prove it exists within the vector space is sufficient to show that limit is actually undefined. Mathematicians only assumed the limit is infinite because they naively assumed that if the map from the set of natural numbers to sequence of partials sums exists, then there is a continuation to this map which is equivalent to the polynomial in n which classically agrees with the sum. However, this is an arbitrary, unjustified assumption by Cauchy, since there is no agreed upon consensus or rigorous definition on how to evaluate summations for non-natural inputs.")

#text("Also, Terrence Tao provided a theory which allows these series to be convergent. It seems to me you actually failed to read the article at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-505753")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("To cast my argument with a different mold, let me rephrase my statement. The reason you are wrong is because your method of calculating partial sums is wrong, and the sequence of partial sums is not a simple growing discrete function, but rather a continuous function.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265849")[#strong[#text("The Sum Of All Positive Numbers")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")]

#text("[…] Numberphile and physicists Tony Padilla and Ed Copeland share one of the most mind-blowing concepts we’ve ever heard. Apparently, the sum of all positive numbers is not infinity. It’s not even a positive number. Mathlethes report here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265875")[#strong[#text("Matt's Homepage » Blog Archive")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")]

#text("[…] ")#link("http://periodicvideos.blogspot.co.uk/2014/01/thanks.html")[#text("http://periodicvideos.blogspot.co.uk/2014/01/thanks.html")]#text(" But how does it really work? TerryTao goes into tremendous detail of how the summation works and why the Grandi series can sum […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ebe4609122a7280d57450989c8a2e468b00511c51b93047cf15f1bb4b9c0b76-a503f35910454af72e5872b71671ed662a9b417a1c0a159941a9756bdc7f9270.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eric")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265877")[#strong[#text("eric")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("I know I’m late to this column, but I’ve never seen these connections before. Can someone point me to some references?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-265927")[#strong[#text("More Infinite Series Madness | Of Prime Interest")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")]

#text("[…] The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic contin… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266168")[#strong[#text("The 1+2+3+…=-1/12 bonanza | Moses Supposes")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")]

#text("[…] are two ways to do this: Lamb explains analytic continuation and links to Terry Tao’s great post proving the same result using calculus. Analytic continuation by imperfect analogy: I have a car […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266226")[#strong[#text("Le scandale des séries divergentes ! (ou le retour de 1+2+3+4+5+… = -1/12) | Science étonnante")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")]

#text("[…] Un excellent billet de Terence Tao qui donne des réponses à plusieurs questions qui se posent à la fin de ce billet : pourquoi la méthode zeta n’est pas stable, quelle est la connection avec Euler-McLaurin, etc. Ca picote un peu, mais il est fort le bougre ! (merci Hervé !) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0efe8f9bae679728242b5b09c5fa409d8f5f2a7eb8ad6f16acc553f1c91af97a-e218ecdc7a217dcce018868712c94fb982eef3a9e005897befa0fedf190b682c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Sprung")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266447")[#strong[#text("Benjamin Sprung")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("When you did regroup Grandi’s series together with smooth summation (shortly before exercise 1) it should be ")#mi("\\frac{\\eta (1/N)}{2}")#text(", right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61ec9563ec151ec01d8ea9fe20303605dc063d71f01a0daa3b4475c70f0ade9c-867821381cf1fa07481624c8b0708024e413bc17fce227e71967f58ccda5c30f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Naturalness and Infinity | The Furloff")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266536")[#strong[#text("Naturalness and Infinity | The Furloff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("[…] to our emotional selves to think that stuff can cancel out or that nature abhors infinities, yet mathematicians study these things all the time and have been for nearly three […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-266695")[#strong[#text("Here's what you get if you add up every whole number from 1 to infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2014")]

#text("[…] to -1/12. Watch the video above for an explanation (a technical demonstration is here; there is more than one way of getting to the same […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-267277")[#strong[#text("An infinite series of blog posts which sums to -1/12 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")]

#text("[…] An old post by Terry Tao on the topic: The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic contin… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-267304")[#strong[#text("How (Not) to Sum the Natural Numbers: Zeta Function Regularization | 4 gravitons and a grad student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")]

#text("[…] This discussion is not going to be mathematically rigorous, but it should give an authentic and accurate view of where these results come from. If you’re interested in the full mathematical details, a later discussion by Numberphile should help, and the mathematically confident should read Terence Tao’s treatment from back in 2010. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-267898")[#strong[#text("Yes, 1+2+3+… = -1/12. Sort of. | Michael Lauer's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")]

#text("[…] much more satisfying. One fortuitous consequence of this brouhaha has been a lot of links to a post of Terry Tao’s of a few years ago, which I have found enormously helpful. It’s pretty […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/982d4e588e6994359cfed8d026ff2141d1f99f9fe98cc7bde9bd0c58c721a579-ab33d94e3ea58ede739a2ad904591e19c075cc16c8585d99337e5aa170ad60e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Gross")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-267947")[#strong[#text("Dick Gross")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("Terry,")

#text("This is an excellent post. If you want a historical reference to the evaluation of the zeta function at negative integers, you should look at Euler’s great paper of 1749 “Remarques sur un beau rapport…”. In this paper, he is very clear that the sums he is evaluating are not convergent in the traditional sense. Euler also discovered the functional equation of the zeta function (at positive and negative integers).")

#text("Dick Gross")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a44ebb09f4cebe38121cdcf146739d79b99f4ec2e6a181344be58ca18e321b4-f79a3652474f64140583c6749c60fa5df013fc22e041c82adc408e1006ea3921.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Colquhoun")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268100")[#strong[#text("David Colquhoun")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("I am merely an amateur mathematician, The result 1 + 2 + 3 + . . . = -1/12 appears to me to be ‘obviously’ absurd, if only because of the sign.")#linebreak()#text(" I would have presumed that the result is wrong because it is based on the Grandi series which does not have any well-defined sum. Yet I see that string theorists take it literally. Do you think that they are justified in doing so?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fe9d086cdc579843d52ecf46d10d97b1e1714a68adc1f67b8d96a06ebd2a555-bdad9330df1d10f0ea1f71b82c4a699198300ed46dce5fa7fa0c111196dd9cb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268237")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("No. As “jj” pointed out above, this is more like “pop” math. It’s cool because it’s extremely counter-intuitive. In the numberphile vid on this, when pressed for answers on how unbelievable it was, the guy filmed just cutely smiles and says “infinity” as if now it’s magically believable. Because infinity is *magic*! lols")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f42981a16ed44872d897a7cb5f47f152e1d5664f1738e2a1f2393b7d6d06c76-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin VanOrd")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268995")[#strong[#text("Kevin VanOrd")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("That’s an extreme mischaracterization of the Numberphile video, which did not go into nearly as much mathematical detail as Terry does, but certainly does not throw its figurative hands up in the air and say “infinity is magic lolz.” In fact, those professors go into some detail and provide multiple proofs of this particular summation. Infinity is not magic, but it is also not sensible. Your dismissal is no different from the dismissal you perceived from Drs Padilla and Copeland. Rather than make semantic points and accusations of these useful maths (I would remind you that these equations are used in physics and describe observation to essentially 100% accuracy), I’d rather see your proof showing that the sum cannot equal -1/12.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1862e65982a8081b9fe5a3f0fa84dbd81c377009e7d611709643020730f2bdca-367f9ce093d0daed3e19a3bb8414a51bb4a312eaafba2711517f4b18c997d46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joc")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-271364")[#strong[#text("Joc")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("You dismiss Doug’s comment, but your dismissal is of the exact sort you claim his is. In fact, your asking for a proof showing that the sum cannot be equal to -1/12 merely shows that you do not know what a correct proof is nor how to check whether a proof is correct, otherwise you would know better than to accept the fake proof given in the Numberphile video. Any mathematician will be able to tell you that the “-1/12” is not a rational number, not to say a negative one! Anyone who does not make clear the distinction between convergent series and formal series is just deliberately misleading or misled. See Terry’s comments at ")#link("https://plus.google.com/114134834346472219368/posts/ZuJDv3daT9n")[#text("https://plus.google.com/114134834346472219368/posts/ZuJDv3daT9n")]#text(", which show two things. Firstly, that he also thinks it should not be written as just “-1/12” because it certainly doesn’t mean that. Secondly, that some people choose to ignore the infinities in the asymptotic expansion, for questionable reasons. Remember that for a theory to have explanatory power it must not have unbounded arbitrarily chosen parameters. Discarding infinity is equivalent to saying that the theory works because we have managed to fit it to the data we have now, and if future data doesn’t agree we can easily create new cutoff functions to fit to it. In other words, we can never ever be wrong. Now that is foolish.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-507571")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("First, your characterization of Terry’s comments are themselves wrong, because his statement that it should not be rewritten as -1/12 was made contextually from a post-rigorous perspective, which is not what this discussion is about. As for asymptotic expansions, this article itself clarified this and made the approach rigorous. I fail to understand your point.")

#text("-1/12 is most certainly a rational number. -12 is an integer. So is 1. They are coprime. -1/12 is a ratio of the two. It is hence by definition of a rational number. So I have no idea of what you are talking about.")

#text("It seems to me the only person confusing formal series and convergent series is you here, because no one here talked about convergent series at any point except for you. And there is no need to accept the proof Numberphile gave – which is not a proof, but a heuristic demonstration that served as an introduction to a video-series – because we already have rigorous proofs and explanations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-428753")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("dude, you’re from gamespot!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-507572")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("Did you bother to read the article at all? Because the answer is literally there.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268270")[#strong[#text("Apparently 1+2+3+... = -1/12")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")]

#text("[…] to do this is by something called analytic continuation. Some further reading if you are curious: ")#link("https://terrytao.wordpress.com/2010/0")[#text("https://terrytao.wordpress.com/2010/0")]#text("…-continuation/. Might have to do a bit of wiki hyperlink chasing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a982ae002e7284a1347600e45f15d7d1410235588b7dc2965d46500c75185c8-84965f08b19500e2240280bb7f0446b69b2fad8265e8e9b9cb61d73ab89a5c08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268519")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Is there a formal reason for why the following naive manipulation is not problematic?")

#text("S = 1+1+1+… = 1+(1+1+…) = 1+S => 0=1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c676db319267347b93d018ec79bb459dc78d6c3e28319bd6fbb505d739d70e7-ec9336fb8d9ddde85e6eb105e3d3e863d5c5f2c1ec929dc3b7d966e043c7fea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269635")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Yes, exactly here: …)")#linebreak()#text(" This is where this manipulation fails.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1862e65982a8081b9fe5a3f0fa84dbd81c377009e7d611709643020730f2bdca-367f9ce093d0daed3e19a3bb8414a51bb4a312eaafba2711517f4b18c997d46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joc")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-271366")[#strong[#text("Joc")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("Indeed it is problematic, and it is also problematic that the Numberphile video committed exactly the same mistake when he shifted one series by adding an extra zero term in front and claimed that it had the same value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e12afaa8427390539a063a565b2b890a5b713d43ffac89c510b35f07b685d427-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Lav")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-490737")[#strong[#text("Sam Lav")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Come on guys, this is a serious mathematical blog held by a field medalist. No one comes here to read about f****** numberphile videos and high school math cranks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-507570")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("It was an intentional mistake. The whole point was to do a heuristic demonstration, and then in a later video, introduce the more correct, rigorous and proper way of getting and using this result, and they did indeed follow up with such a video. Perhaps people should look into things before commenting about them, ¿eh?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268769")[#strong[#text("Open Thread « Econstudentlog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")]

#text("[…] I felt pretty much that way after watching the video below and skimming parts of Terence Tao’s related blogpost. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-268807")[#strong[#text("The Sum of Positive Integers | Quantitative Scientific Solutions Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")]

#text("[…] technically misleading as well). For a much more correct (and technical discussion), see this blog post by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269743")[#strong[#text("Din ecosistemul științei: Cum folosesc matematica fizicienii | Isarlâk")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")]

#text("[…] februarie. De asemenea (credit Steven Strogatz, pe Twitter) blogul Scientific American. Vezi și un mesaj mai vechi al lui Terry Tao in care se discută background-ul […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269800")[#strong[#text("One number to rule them all: -1/12 « Why Evolution Is True")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")]

#text("[…] Before you all start chipping in below pointing out basic mistakes in the maths (I don’t think there are any), read this response by Tony Padilla (I got lost when the Greek letters began) or, for the truly mathematically endowed, watch this extra and more elaborate proof which takes you through Euler’s calculation and read this mind-bogglingly difficult piece. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb7f9ca9792a63fbe4a0d6d53e9201b5c381a6a96c3166714b173396d5992f62-3ce6733c6feb3d2ae87ae452f19af71f0b375b31919431d29df96641a87908d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269830")[#strong[#text("Allen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("In regards to the proof of why 1+2+3+4+….=-1/12 simpler proof,")#linebreak()#text(" When they move over the bottom S2 and say it is the same as the top S2. I believe that the bottom number if given the same number of terms as the top number would be equal to S2 plus infinity or S2 minus infinity. The lower moved over version of S2 is S2-1 after 1 term, then S2 +1 after 2 terms then S2-2 then S2 +2 then -3 then +3 then -4 then +4 eventually going to – infinity and +infinity greater to make the result they want by adding the 2 S2’s together. As they did with S1, one could argue that that averages to 0. That may be true mathematically in which case I wholeheartedly accept their result. But if you just go with this idea for a second, the result of what they call 2 * S2 would be S2 + S2 + or (and?) – infinity. Working through the problem that equals S1 so in the end, the series 1+2+3…… =-1/12 + or(and?) – infinity over 6 (which is still + or(and?) – infinity). I find that won’t damage the significance of -1/12 to string theory but I find this result, which I think is correct, much more philosophically rewarding. The principle of + and – which could be thought of as + and – infinity or + or – infinity is a fundamental concept in a number of religions (buddhism, shintoism, taoism) and since mathematically + and – infinity equals 0 it does nothing to the original claim that 1 + 2 + 3 +……=-1/12. ﻿")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85cbe4220e771ddd8435b0693f556afe523fae48c1359823075d7180b918fa85-2abe6e3536510e3fbc319ea04852a906d8878fafcf376286bc59fdeba80d03c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fintan")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269928")[#strong[#text("fintan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("Dear Dr Tao, thank you for your nice presentation. You’ve accounted for the inconsistencies between (4)(5) and (6), but not for the more obvious problem: “Most obviously, the summands on the left are all positive, but the right-hand sides can be zero or negative.” This problem means that either there is a logical flaw in the statement S: “summing numbers that are all positive cannot give zero or a negative result”, or there is a logical flaw in the proofs for (4)(5) and (6). I guess statement S follows from Peano’s axioms. Can you say something about where the logical flaw lies?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-269963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("See the paragraph before equation (16), or my more recent discussion at ")#link("https://plus.google.com/114134834346472219368/posts/ZuJDv3daT9n")[#text("https://plus.google.com/114134834346472219368/posts/ZuJDv3daT9n")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535852805f5511fd5707a2e43b2f4a2112fd47b4f02157fde6efdf12b7d26482-ed1d1bb22fc9b56637492f2c664a89ebca4f18e9982ac6328b979108e9d886e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashok M Dhareshwar")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-524064")[#strong[#text("Ashok M Dhareshwar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2019")])]

#text("Professor Tao,")

#text("This link, as well as other links to your contributions at plus.google.com, are no longer available. Would it be possible to give alternate links and/or references?")

#text("Thanks.")

#emph[#text("[Now uploaded to ")#link("https://terrytao.wordpress.com/about/google-buzz/google-post-on-123-1-12/")[#text("https://terrytao.wordpress.com/about/google-buzz/google-post-on-123-1-12/")]#text(" -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62151c540204c257ec030d9a8611363af77a4d7cc2e29f4ed15e8a54e4c82605-fb91b03af4ae8e2f94cd11f08cccf2524754fee53dba4838e6eb362605d396e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philipp Scholz")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-270163")[#strong[#text("Philipp Scholz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Its a question on the extra footage video:")#linebreak()#text(" So i showed this to my dad who is a physician and he had the problem that you simply set s=-1.")#linebreak()#text(" In the series 1+2x+3x^2+4x^3+…=1/(1-x)^2 my father sad that the |x| has to be <1 |x|<1 because if you set |x|=1/-1 you would get a problem. So how do you justify that you just break that rule/insert s=-1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-270251")[#strong[#text("¿Es cierto que 1+2+3+4+…=-1/12? | Blog del Departamento de Álgebra")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")]

#text("[…] Para leer más sobre el tema, recomiendo los excelentes posts del maestro Terence Tao en Google+ y en su blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-1/#comment-270252")[#strong[#text("Linkage | An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")]

#text("[…] some press now. It’s part of the Numberphile series. Terry Tao (as usual) has a pretty definitive post on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-270543")[#strong[#text("Nature already patched it | The Gauge Connection")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")]

#text("[…] could say. Of course, smarter mathematicians are well aware of this as you can read from Terry Tao’s blog. Indeed, Terry Tao is one of the smartest living mathematicians. One of his latest successes is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf107c3783d7a6ca4e01321852ac52a13bf66490351ef74eb3fb30513dffd1c-8ac4bb51243c74382155f8362324925734c9c1107b8513baf7076451b3a35ec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-270597")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Does (11) just say that the integeral of your cutoff function and the riemann sum of the cutoff function differ by 1/2 in the large N limit?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-270654")[#strong[#text("Series convergentes y métodos de sumación | Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")]

#text("[…] este post, Tao intenta dar una interpretación consistente de estos valores, y lo hace basandose en […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-270704")[#strong[#text("The sum of the natural numbers is -1/12? | Scientific Clearing House")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")]

#text("[…] Terence Tao has a nice blog post on evaluating such sums. In a “smoothed” version of the sum, it can be thought of as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-271605")[#strong[#text("Сумма всех натуральных чисел: 1 + 2 + 3 + 4 +… » CreativLabs")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")]

#text("[…] два раза не ходить, ещё пара интересных примеров с […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-271636")[#strong[#text("Сумма всех натуральных чисел: 1 + 2 + 3 + 4 +… | Вести3.ру — Информационный журнал")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")]

#text("[…] два раза не ходить, ещё пара интересных примеров с […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8129b084b4f483b502c84fd8e23e4338e5263a1fff51cfd6c0f57abef61fcecc-6faacbeaad8cba4c646f9341a8da2f0c81aef3c06ec8aa7f5ae2182ec960b1d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jamilasadek")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-277123")[#strong[#text("Jamilasadek")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("I disagree completely with this proof because it can never work you need to set a point where to stop to make this proof. For example:")#linebreak()#text(" S1= 1-1+1-1+1-1+1…..")#linebreak()#text(" 2S1=0+1-1+1-1+1-1+1…..")#linebreak()#text(" now here is where we go wrong. You need to have the same number of ones written wherever u stop so the above means that 2S1=2 which means S1=1 not 1/2. So it all depends on where you stop and wherever you stop there is a different answer given. So this previous cannot work as you are not supposed to stop. So my whole point is that this proof cannot work as you have to set a limit to it for it to work.")#linebreak()#text(" CASE CLOSED!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-507569")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("“I disagree completely with this proof because it can never work you need to set a point where to stop to make this proof.”")

#text("This is nonsense. The summation has infinitely many terms. Hence, BY DEINITION, you cannot have a “point” at which to stop, because if you do, then you are no longer dealing with an infinite summation.")

#text("“For example:")#linebreak()#text(" S1= 1-1+1-1+1-1+1…..")#linebreak()#text(" 2S1=0+1-1+1-1+1-1+1…..")#linebreak()#text(" now here is where we go wrong. You need to have the same number of ones written wherever u stop…”")

#text("No, you do not. First, the summation is there regardless of whether you write every term or not. The summation, if it has value, then it must have it independent of whether you can write or not. This is a mathematical principle. Second of all, the number of digits in the first line is already the same intrinsically as the second line, because both amounts are infinite AND countable, so by Cantor’s theorem, they are the same number of terms.")

#text("“…so the above means that 2S1=2 which means S1=1 not 1/2.”")

#text("I already disproved this.")

#text("“So it all depends on where you stop and wherever you stop there is a different answer given.”")

#text("You do not stop at all to begin with. You fail to understand the basic definition of infinity.")

#text("“So this previous cannot work as you are not supposed to stop. So my whole point is that this proof cannot work as you have to set a limit to it for it to work.”")

#text("No, you do not. At no point in time did he need to set a limit on where to stop to prove it.")

#text("“CASE CLOSED!”")

#text("Indeed, and you lose.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a27b3021c37a4975aedd32142d78684311afbbe9aa954282a0263a04a59167f2-86fb9f8edc0c9b15ecc2fc0da8e002773f93cac87a0adde3bdc29e8d440d501d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Aldridge")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-277587")[#strong[#text("Robert Aldridge")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2014")])]

#text("Grandi’s Series: In my opinion the answer is indeterminate. It’s either 0 or 1 but we don’t know which.")

#text("Every proof I’ve seen so far proves that the average of 0 and 1 is a half.")#linebreak()#text(" I agree that the average is a half but this isn’t the question – we want the sum.")

#text("1-S = S seems to prove the sum is a half but the S’s are NOT equal.")#linebreak()#text(" Both S’s are indeterminate but one is 0 while the other is 1 so we can’t rearrange to get 2S.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-507568")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("What you state is nonsense. They are the same. The article gave a rigorous proof that the sum is 1/2 without any mention of the average. Did you bother to read?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1c21a67d821a1db60a1940f27ec901454ab657aa68e8533d96167342417f46c-f1a06c833c5820a83365b3fc15c0cdbf8ff20c50ab4ad5f9749b6019353f7677.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabi")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-277716")[#strong[#text("Fabi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2014")])]

#text("@Grandi’s series:")#linebreak()#text(" how do you recover ")#mi("\\frac12 + O(\\frac1N)")#text(" from the term above?")#linebreak()#text(" I only get ")#mi("\\frac{\\eta(\\frac1N)}{2} + O(\\frac1N)")#text(" after Taylor expansion.")#linebreak()#text(" Or do you assume, that ")#mi("\\eta")#text(" equals 1 near the origin?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-277719")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2014")])]

#text("Yes; see the second full paragraph after (10).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1c21a67d821a1db60a1940f27ec901454ab657aa68e8533d96167342417f46c-f1a06c833c5820a83365b3fc15c0cdbf8ff20c50ab4ad5f9749b6019353f7677.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabi")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-277982")[#strong[#text("Fabi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2014")])]

#text("Thanks for the quick answer.")

#text("I intended to do your exercises since it seems fun, but I’m already stuck at exercise 1. I think the proof is similar to the one above the exercise. Maybe I didn’t get it right:")

#text("Let ")#mi("\\eta")#text(" be twice differentiable. From taylor expansion we see:")

#mi("\\eta(\\frac{2m}{N} + \\frac1N) = \\eta(\\frac{2m}{N}) + \\eta^{\\prime}(\\frac{2m}{N})\\frac1N + \\frac{\\eta^{\\prime\\prime}(a)}{2} \\cdot \\frac{1}{N^2}")#text(" with ")#mi("a \\in (\\frac{2m}{N},\\frac{2m}{N}+ \\frac1N)")

#text("And")

#mi("\\eta(\\frac{2m}{N} - \\frac1N) = \\eta(\\frac{2m}{N}) - \\eta^{\\prime}(\\frac{2m}{N})\\frac1N + \\frac{\\eta^{\\prime\\prime}(b)}{2} \\cdot \\frac{1}{N^2}")#text(" with ")#mi("b \\in (\\frac{2m}{N} - \\frac1N,\\frac{2m}{N})")

#text("If we put that in the smoothed Grandi’s series after the regroup we obtain")

#mi("\\frac{\\eta(\\frac1N)}{2} + \\sum_{m=1}^{\\infty} \\frac{\\frac{\\eta^{\\prime\\prime}(a)}{2} \\cdot \\frac{1}{N^2} +  \\frac{\\eta^{\\prime\\prime}(b)}{2} \\cdot \\frac{1}{N^2}}{2}")

#text("Since ")#mi("\\eta")#text(" is compact supported the summand is ")#mi("O(\\frac{1}{N^2})")#text(" Ok.")

#text("But you claimed that 1. the sum is only non-zero if ")#mi("m = O(N)")#text(" and 2. thus the sum is ")#mi("O(1/N)")#text(".")#linebreak()#text(" I don’t get neither 1. and 2. …")#linebreak()#text(" (Yesterday I thought I had it, but I misread again…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-278792")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2014")])]

#text("Dear Prof. Tao,")

#text("Can your approach be used to show")

#mi("\\displaystyle f(s+\\Delta \\sigma)=f(s)+\\sum_{k\\ odd,\\ k \\le K}\\left( g_k(\\Delta \\sigma)f^{(k)}(s)+g_k(\\Delta \\sigma)f^{(k)}(s+\\Delta \\sigma)\\right) +remainder\\ term,")

#text("where the numbers ")#mi("g_k(\\Delta \\sigma)")#text(" are given in terms of the Bernoulli numbers?")

#text("The equations after (20) of this blog post look very similar.")

#text("Can this be used to shift the sum of the Riemann ")#mi("\\xi")#text("-function and its odd derivatives from the critical line in the Levinson-Conrey method as claimed ")#link("http://arxiv.org/abs/1403.5786")[#text("here")]#text("?")#linebreak()#text(" They also claim to construct a Dirichlet series which obeys a functional equation coming from this shift in addition to properties coming from the Riemann functional equation ")#mi("\\xi(s)=\\xi(1-s)")#text(". Can this really be used to show that almost all of the zeros of the zeta function are on the critical line?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00b73d80c46fe2f113cb44418d29e35d7d508d7ac7ab47775184934d7bc3702f-1aaf865cba53258afe0c8eb42f0b9b8ca4c36230bfc7397f1c5df754d9a90854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-279173")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2014")])]

#text("I can’t say I can comprehend everything written here. However, this I know as fact. I believe that Terry would also agree with me (I think).")

#text("The series 4+8+12+16+… is not the same as the series 0+4+0+8+… If we could describe “1+2+3+4+…” as a number, then it is a different number than “0+1+0+2+…” In other words, if you are going to say that c=1+2+3+4+…, then keep it consistent and don’t change the definition of “c” for usage in the same equation. Using it inconsistently is like having c=5 and c=4 in the same equation. In other words, it would be having c equal to two different numbers, which defies laws of mathematical rigor that allow us to only assign one definition to a term.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00b73d80c46fe2f113cb44418d29e35d7d508d7ac7ab47775184934d7bc3702f-1aaf865cba53258afe0c8eb42f0b9b8ca4c36230bfc7397f1c5df754d9a90854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-279239")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2014")])]

#text("While it would take work for me to learn all the stuff needed for me to get all of those integrals, the fact that 0+4+0+8+… is not the same as 4+8+12+16… demonstrates that 1+2+3+4+… is definitely equal to an infinitely large number rather than -1/12. In fact, if you notice, [1-(1+2)/4]*(1-4)=-1/12, explaining how -1/12 is achieved in the first place. 1-4 is from c-4c.")#linebreak()#text(" Pretending as if 0+4+0+8+… is the same as 4+8+12+16+… and then substituting the two series so easily is sure to get an answer that is false. No matter how amazing the math is afterwards, if you screw up in the beginning then you will not find the truth. If anyone considers 0+4+0+8+… to be the same as 4+8+12+16+…, then they are simply deluding themselves (which many smart people are keen on doing). Complicating the math is not going to change the result. The wiki page makes the same error, even with the zeta function. It STILL puts a space (in other words +0) between each number in the series, leading to a number that hides the truth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00b73d80c46fe2f113cb44418d29e35d7d508d7ac7ab47775184934d7bc3702f-1aaf865cba53258afe0c8eb42f0b9b8ca4c36230bfc7397f1c5df754d9a90854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-279558")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("I believe though that you stated that traditional methods of treating infinity do not allow for this. The reason why traditional methods do not allow for this is because 0+4+0+8+… is a different value from 4+8+12+16+…, and thus, having c=1+2+3+4+… and calculating 4c to be 0+4+0+8+… instead of having c=4+8+12+16+… is wrong, ruining all the mathematics done afterwards.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9622f3a32c6c108a21d1cb3da6d8608b06ecde48a8ba829be20ddd281b7f2971-12e7bd97b2276c53f8a0f8a886265f482436e6c2fde8da0413bf1354726d0247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ghmath")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-279801")[#strong[#text("ghmath")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("Hello Professor Tao,")#linebreak()#text(" An interesting article, thanks. This article “whispered” other idea about polylogarithms and divisors sum series estimation. This method can be extended for them also.")#linebreak()#text(" Thanks,")#linebreak()#text(" Gevorg.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-283332")[#strong[#text("The Sum of Positive Integers | Quantitative Scientific Solutions | QS-2")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")]

#text("[…] technically misleading as well). For a much more correct (and technical discussion), see this blog post by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5641966ef07adb3d5e66698d712aef23990096af964e0817ed168242e6e0149-b3e40460670d16c7cbda416be3c8504b15b0e2eafc60bbdb99c66e09cb0781ac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aake Roffo")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-322787")[#strong[#text("Aake Roffo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("[…] From ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-func&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-func&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1c21a67d821a1db60a1940f27ec901454ab657aa68e8533d96167342417f46c-f1a06c833c5820a83365b3fc15c0cdbf8ff20c50ab4ad5f9749b6019353f7677.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kim")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-329366")[#strong[#text("Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2014")])]

#text("Hello Prof. Tao,")#linebreak()#text(" in paragraph 1 (smoothed asymptotics) you didn’t define")#linebreak()#text(" ")#tao-math("\\left|\\left|f\\right|\\right|_{C^{s+2}}", block: false)

#text("I assumed it is")#linebreak()#text(" ")#tao-math("\\left|\\left|f\\right|\\right|_{C^{s+2}} := sup_{x \\in \\mathbb{R}} \\left|f^{(s+2)}(x) \\right|", block: false)

#text("In paragraph 1, there are no problems with that definition.")

#text("However, in paragraph 2 (at the beginning) you use the Euler-Maclaurin formula in paragraph 1 with ")#mi("s \\in \\mathbb(C)")#text(" where ")#mi("Re(s)<1")#text(".")

#text("What is ")#tao-math("\\left|\\left|f\\right|\\right|_{C^{s+2}}", block: false)#text(" for ")#mi("s \\in \\mathbb(C)")#text(" where ")#mi("Re(s)<1")#text("?")

#text("Confused,")#linebreak()#text(" Kim")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-329583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2014")])]

#text("The complex parameter ")#mi("s")#text(" in Section 2 is unrelated to the regularity parameter ")#mi("s")#text(" in Section 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-374032")[#strong[#text("Grandi’s series and taking sums of infinite series by averaging | Scorkle's Media")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2014")]

#text("[…] was also made to Terry Tao’s blog post explaining some different ways to overcome non-converging series with alternative outcomes (i.e. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3291c755a5e2baf8a6b00d114f7796748242b75c5e3c3036389acb4aabe8400f-ad044814ff76ec86a8745d9c27a0671a3e4d0e37b242fd1ac10afaa8ec0a6526.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark D. Normand")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-407021")[#strong[#text("Mark D. Normand")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")])]

#text("This posting contains references to equations (21), (22) and (23) but contains no equations labeled with those numbers and it is not immediately obvious which equations should be so labeled.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-407088")[#strong[#text("More on 1+2+3+…=-1/12 | Technology")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")]

#text("[…] of series that we are most interested in. Compare this to the mathematical proofs given for example here or here. The most elegant proof relies on complex analysis which is a subject typically taught at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-417170")[#strong[#text("Czy 1+2+3+…=-1/12? Ramanujan, Euler i Tao o szeregach rozbieżnych | Nie od razu naukę zbudowano")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2014")]

#text("[…] ta jest uproszczoną wersją podejścia z bloga Terence’a Tao, znakomitego matematyka, medalisty Fieldsa. W istocie jest ona ogólniejsza, niż się może […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90df7e46e381a0f33c732993f538e1eea560d5d255a836a8f30b1ca5836f29fd-a80aa36b3b26faee720192e5821cf8efdaff8d6ab57a17756378a7d0c2a320e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Javier Garcia Moreta")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-434509")[#strong[#text("Jose Javier Garcia Moreta")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2014")])]

#text("for the generalized harmonic series should we ahve that")

#mi("\\sum_{n=0}^{\\infty} \\frac{\\eta (n/M)}{(n+a)}= -\\Gamma (a)+log(a)+ \\int_{0}^{\\infty}dx\\eta(x)/(x+a)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a73c75600c94857a56d361a72be26295e59849c6edad7c125fc4182411cd4a17-2a45061e21c6553676aa24a168f0a8a68df450f21eb5929148ab388a45899c43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine C")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-437158")[#strong[#text("Antoine C")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2014")])]

#text("Dear Pr Tao, since i’ve watched the numberphile video on the fact that 1+2+3+4+….+-1/12, i’ve spend severals hours looking for a non-debated proof. As you’re a great mathematician, i’m totally ready to accept that result but how to you explain the fact that it’s still fully debated (at least among non-experts mathematicians, as far as i know) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-442237")[#strong[#text("Grandi’s series |")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2014")]

#text("[…] was also made to Terry Tao’s blog post explaining some different ways to overcome non-converging series with alternative outcomes (i.e. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-445246")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("I just wrote out explicitly in “Bernoulli Appells” at my website how the two sets of Bernoulli numbers ")#mi("B_n(0)=(-1)^n B_n(1)")#text(" are related through the Bernoulli polynomials and how they play out in a simple proof of Faulhaber’s formula and your formula 19.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-450248")[#strong[#text("Trivial Zeroes of the Riemann-Zeta Function and 1+2+3+4+ | Ah, Math?")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2015")]

#text("[…] This post is inspired by Terence Tao’s post on summing divergent series: https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun…. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bdedd91eb49bc37c9092bb357515b22ca16b3ba4869cbf6689411387bcae0e6-4babd5f203eb8e3e3b84de8caeeaca73acd0fde9c867f76477e389f530b3122f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Синиша Бубоња")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-451916")[#strong[#text("Синиша Бубоња")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2015")])]

#text("Dear professor Tao,")

#text("first of all, sorry for my bad English. This article is great! I read it several times. I explore divergent series and founded general method which actually works. Inspired divergent series I defined limit of a function at singular point and I was surprised when I discovered that the method can be applied to compute divergent integrals. I think that this interpretation is correct. I method tested for all series and integrals which I found. I’m sorry that my ignorance of language hampers to write what I want… To a lack of understanding of the problem comes because he viewed from the wrong angle.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://m4t3m4t1k4.wordpress.com/2015/02/14/general-method-for-summing-divergent-series-determination-of-limits-of-divergent-sequences-and-functions-in-singular-points-v2/")[#text("General Method for Summing Divergent Series. Determination of Limits of Divergent Sequences and Functions in Singular Points v2")]
]

#text("Sincerely, Sinisa")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4b6ad14fae81f3f6e14bda5ad96b90a3f4faa74a6e48f399103bcd0b9d42622-cd0c1d492d34db253ce94509f11cb5b8d86d8abc881a153a4415b1138257dcad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Hausdorff S. K.")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-453594")[#strong[#text("Peter Hausdorff S. K.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("Reblogged this on ")#link("https://freeopenmath.wordpress.com/2015/03/30/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("Free Open Mathematics Society")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22e083a7374ac3a64484e1f257b8964d3bdd295034bc3049abf1ae4ab9ab588f-e977c369e1700f04f81f8cd1ac200d670eeeec425dd2cad7b7565f7634d191a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of francisrlb")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-454136")[#strong[#text("francisrlb")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("Could you explain how you get from equation 23 to equation 24. This step is completely mysterious to me. Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-454149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("Apply (23) with N replaced by ")#mi("2N, 4N, \\dots, 2^j N")#text(" for some large ")#mi("j")#text(", then sum. Then, take ")#mi("j")#text(" to infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7241773f7bf819f9836af3e73950d097c23b6d7ea113ad7887e4d07dc82e8cd-92fc1125df076dbca7628f213ed39d3c1149f975b969ab874924b25a7ed8803e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo C.Mog.")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-477094")[#strong[#text("Pablo C.Mog.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("Dear Prof Tao,")#linebreak()#text(" Sorry to bother you, but I’m stuck in the same part as Francis (equations 23 and 24)")#linebreak()#text(" I arrived to this:")#linebreak()#text(" ∑n-s η(nN-1) – cη,-sN1-s=∑n-s η(n2-jN-1) – cη,-s N1-s 2j(1-s) + ∑k=1k=j O(2-kN-1)")#linebreak()#text(" (1) (2) (3) (4) (5)")#linebreak()#text(" With Re(1-s)>0")#linebreak()#text(" As j tends to infinity, terms (3) and (4) diverge, and their sum seem not yet to be proven to converge.")#linebreak()#text(" Could this be done?: Term (5)=O(N-1) (1-2-j-1)*2 and as j→∞, Term(5)→O(N-1)")#linebreak()#text(" If this is the case then I could do (1)+(2)-(5)→Value(s, η)")#linebreak()#text(" But I couldn’t either prove the independence of the Value form η.")#linebreak()#text(" Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-477277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("(5) is a convergent sequence in ")#mi("j")#text(", and (1) and (2) do not depend on ")#mi("j")#text(", so the sum of (3) and (4) must converge also. The partial sum in (5) differs from the infinite sum by ")#mi("O( 2^{-k} N)")#text(", and this can be used to establish (24) for ")#mi("2^j N")#text(" by a suitable definition of ")#mi("\\zeta(s)")#text(".")

#text("See also Lemma 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")]#text(" for a similar argument.")

#text("Finally, to typeset TeX on this blog, see ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-457526")[#strong[#text("1+2+3+4+5+6+7+8+…= -1/12 | Knight's Atari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")]#text("; [2] ")#link("http://www.maa.org/sites/default/files/pdf/upload_library/22/Ford/RaymondAyoub.pdf")[#text("http://www.maa.org/sites/default/files/pdf/upload_library/22/Ford/RaymondAyoub.pdf")]#text(" [3] […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-457572")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("This interesting paper on Euler’s life and work gives in particular many details on the history of the “Basel problem” (on the evaluation of ")#mi("\\zeta (2)")#text(") and its solution by Euler in 1734, and also Euler’s discovery of ")#mi("\\zeta (s)")#text(" functional equation in 1749 (almost 110 years before Riemann!).")#linebreak()#text(" Interestingly, this 1974 article (considering also Euler’s work on ")#mi("\\zeta  (3)")#text(" evaluation) states that “the arithmetic nature of ")#mi("\\zeta (3)")#text(" remains an unsolved problem” – appeared only 5 years before Apery’s theorem (on the irrationality of ")#mi("\\zeta (3)")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-457668")[#strong[#text("[Toán] Sum of nature numbers | Mangala")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/343da7ee593f8fe0dabbe2050bf714516d94763484cd9f362503a7fa5e39c11a-c376f792f2bc23c4292cf4323a610d2dee8c025d5b434d013151d0fda24f9b24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-458199")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2015")])]

#text("Apologies if this was already mentioned somewhere and I missed it: Here is a quick way to see that equation (14) gives Bernoulli numbers without going through the Euler-Maclaurin computation. Put ")#mi("\\eta(x) = e^{-x}")#text(". Then (14) gives")

#mi("\\zeta(-s) = \\lim_{N \\to \\infty} \\sum_{n=1}^{\\infty} n^s \\exp(-n/N) - N^{s+1} \\int_0^{\\infty} x^s e^{-x} dx.")

#text("The sum is")#linebreak()#text(" ")#tao-math("(-1)^s \\left(\\frac{d}{dt} \\right)^s\\left|_{t=1/N} \\sum_{n=1}^{\\infty} e^{-nt} = (-1)^s \\left(\\frac{d}{dt} \\right)^s\\right|_{t=1/N} \\frac{1}{e^t-1}.", block: false)

#text("Since ")#mi("1/(e^t-1) = 1/t + \\sum_{m=1}^{\\infty} B_m \\frac{t^{m-1}}{m!}")#text(", the repeated derivative is ")#mi("s!/t^{s+1} + (-1)^s B_{s+1}/(s+1) + O(t)")#text(".")#linebreak()#text(" Plugging in ")#mi("t=1/N")#text(" gives ")#mi("s! N^{s+1} + (-1)^s B_{s+1}/(s+1) + O(1/N)")#text(".")

#text("The integral is a ")#mi("\\Gamma")#text(" function and gives ")#mi("s!")#text(", so")

#mi("\\displaystyle \\zeta(-s) = \\lim_{N \\to \\infty} \\left( s! N^{s+1} + (-1)^s B_{s+1}/(s+1) + O(1/N) \\right) - s! N^{s+1}.")

#text("This matches the desired formula up to the ")#mi("(-1)^s")#text(", but fortunately the odd indexed Bernoulli numbers are zero anyway.")

#text("Thanks very much for this post. For no good reason, I was thinking a bunch last week about understanding ")#mi("L")#text(" functions at ")#mi("0")#text(" without the functional equation, and this was very clarifying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-460557")[#strong[#text("1 + 2 + 3 + … = – 1/12 and Related Results | beorminga")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2015")]

#text("[…] blog by the eminent Australian/American mathematician Terry Tao. In one of his published articles there, entitled The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-461541")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")]

#strong[#text("What’s the intuition behind the equation [math]1+2+3+\\cdots = -\\tfrac{1}{12}[/math]?")]

#text("To the best of my knowledege, there is two ways of giving a finite value to a diverging sum : * Choosing a different method of summation * Analytic continuation of a well choosen function The “standard addition properties” are not conserved when you…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f652385d3ef1ba5f9ee84ccdc5fbabc2cd9df6582f3bc1eee35b2af43fabfe1-9f4aea7ebda090e45f56bce6f92f952466bd7b8ae69a72e3efd39c7204f16c66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Quaeghebeur")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-466054")[#strong[#text("Erik Quaeghebeur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")])]

#text("Can one find a series ")#mi("\\chi(s)")#text(" and complex number ")#mi("q")#text(" such that ")#mi("\\chi(q) = \\sum_{n=1}^\\infty n")#text(" formally, but which after analytic continuation gives a finite value ")#mi("\\chi(q)\\neq\\zeta(-1)=-\\frac{1}{12}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-466058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")])]

#text("Yes, if one is willing to use rather artificial-looking series. For instance, the series")

#mi("\\displaystyle \\chi(s) = \\sum_{n=1}^\\infty \\left( \\frac{n(n+1)}{2} e^{-ns} - \\frac{n(n-1)}{2} e^{-(n-1)s} \\right)")

#text("telescopes to zero for any ")#mi("{\\bf Re}(s) > 0")#text(", but formally is ")#mi("\\sum_{n=1}^\\infty n")#text(" at ")#mi("s=0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f652385d3ef1ba5f9ee84ccdc5fbabc2cd9df6582f3bc1eee35b2af43fabfe1-9f4aea7ebda090e45f56bce6f92f952466bd7b8ae69a72e3efd39c7204f16c66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Quaeghebeur")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-466059")[#strong[#text("Erik Quaeghebeur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")])]

#text("Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3acfe099e672eacdbc7a11abffc4118edd4a643f1fc2e99a1f5d7974d095f7e-2ddc54466ce33189cccd4d1c87a954fa2d98e7c198d7643dbaec46c585a90a3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cre Master")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-466220")[#strong[#text("Cre Master")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2016")])]

#text("Hi Terence,")

#text("I need your help resolving something regarding -1/12. I have been discussing it over on Reddit;")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://www.reddit.com/r/math/comments/45qw5i/trying_to_nail_down_the_112_from_the_numberphile/")[#text("Trying to nail down the -1/12 from the Numberphile video on 1 + 2 + 3….")]#linebreak()#text(" by")#link("https://www.reddit.com/user/Cremasterau/")[#text("u/Cremasterau")]#text(" in")#link("https://www.reddit.com/r/math/")[#text("math")]
]

#text("There I pointed out that graphing 1/2x(x+1) leaves an area under the x axis equal to -1/12 something I found to be really interesting.")

#text("When I went to the Wikipedia page it showed a graphic which stated “The first four partial sums of the series 1 + 2 + 3 + 4 + ⋯. The parabola is their smoothed asymptote; its y-intercept is −1/12” with a link to this article.")

#text("I thought this -1/12 could have been an artifact of the smoothing since when all numbers are included the intercept would seem to be -1/8.")

#text("I have raised this a few times and mathematicians seem more interested in dismissing the Numberphile video than delivering a considered answer so I’m hoping you might give me your thoughts.")

#text("Kind regards,")

#text("Cre")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fa5e7ccc1323b73ca2070871fc8058d0c298e9e6d8febd1d2d6e10ead87caef-52bd23a3df95f73e1dbd17431f7073dadac53cecd3904922a80f3d996e1930d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sam palmer")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-507660")[#strong[#text("sam palmer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2018")])]

#text("Hi Cre,")

#text("I too was wondering this and I found the answer in the talk section of the Wiki article.")

#text("The intercept of what is drawn really would be -1/8")

#text("What apparently is going on is that if you imagine all possible quadratics that fit the function, as in functions of the form (n-x)(n+1-x)/2 for x between 0 and 1, then the average y intercept is indeed -1/12")

#text("Maybe someone should edit the article?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sam palmer")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-507723")[#strong[#text("sam palmer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("Actually sorry, it looks like the wiki article is saying that the parabola that that goes through all those half way points has intercept -1/12, when it really has intercept -1/8. But actually I didn’t read it properly and that is not what’s drawn. So the wikipedia article is fine.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biases between consecutive primes | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-466967")[#strong[#text("Biases between consecutive primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("[…] argue this rigorously when using smoother weights like ). The term can be interpreted as , as per this previous post. Assuming this approximation, we obtain the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6decb10282f21b09d3e0de94234e7f167464d87f06fae65737355c33ea243e1c-8ae8cd4529caed3b8afc2670367358be0f2cfbc5a3d557fcb69827575cfd2a7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Katsikogiannis")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-467181")[#strong[#text("Katsikogiannis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2016")])]

#text("Greetings Pr. Tao,")

#text("After reaching the seemingly inconsistent-with-each-other equations 8 and 9, you eventually conclude that there are certain quantities affecting 8 and 9, that the initial techniques used are objectively not powerful enough to contain and one has to use cut-off functions and smooth sums, to clear things up.")

#text("Though, I have to point out that the techniques initially used are actually powerful and reliable enough and the actual reason 8 and 9 seem inconsistent is a certain misconception you base your thought process on.")

#text("That, is considering the mathematical structures in the middle parts of 8 and 9 to equal each other, based on the fact that they share certain properties (that do not fully define them) while failing to keep in mind certain additional characteristics that were previously constructed to them and that are responsible for the results you associate them with.")

#text("More specifically, keeping in mind the way that 8 and 9’s partial sums are defined (that is the way they are associated to the partial sums of equation 5), we have for each case:")

#text("S_1 = (1+1) S_1= (1-1)")

#text("S_2 = (1+1) + (2+1) S_2= (1-1) + 2")

#text("S_3 = (1+1) + (2+1) + (3+1) S_3= (1-1) + 2 + 3")

#text("… …")

#text("S_n = (1+1) + (2+1) + (3+1) + … S_n= (1-1) + 2 + 3 +…")

#text("As shown above, there is a constant difference in the way the partial sums are defined. A difference that is persistent for the n_th partial sum, as n tends to infinity.")

#text("That means the n_th partial sums perceived as 1+2+3+… and 0+1+2+3+… as n tends to infinity in the middle of 8 and 9, are a couple of endlessly expanding collections of summed terms that are constantly different to each other, banishing the case where 8 and 9 contradict each other, when one includes the necessities above.")

#text("In the meanwhile, notice that if one excludes the originally summed (1-1) from 9 and begins with the term 2, so that the partial sums coincide with those of 8 and thus allowing one to validly consider the middle parts of 8 and 9 equal to each other, then the way 9’s partial sums are associated with those of 5 is affected, essentially causing the new equation 9 to be defined as")

#text("S – 1 + (n+1)")

#text("(Where S is the n_th partial sum of equation 5 as n tends to infininity)")

#text("and not as")#linebreak()#text(" S – 1")

#text("as it was originally defined to be, preventing one from leading themselves to any inconsistencies, yet again.")

#text("That’s all for now.")

#text("G. Katsikogiannis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-489088")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2017")])]

#text("The problem with your approach is that you assume that as N —> infinity, N behaved as a natural number. You cannot evaluate the limit of the expression as N approaches Infinity if N is not generalized to all real numbers, because N is not strictly a natural number. Besides, since there is a discontinuity at every natural number, the polynomial with which we define the Nth term of the sequence of partial sums is not unique, so you cannot find the limit of the sequence as N goes to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-489108")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2017")])]

#text("You’ve also assumed that summation of infinitely many summands is associative, which is not the case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-468651")[#strong[#text("Gold Nugget!!! – The Culture")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")]

#text("[…] can read more here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a30fd5d0be7abfb2d2ec472940b6ea8b130e6024c5aeb77b1137019b54be4ccf-1984c4f931d11f2b824d33f92735217b66b48cded285a7aafdcbab8a4f200042.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-469907")[#strong[#text("Abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("Sir,")

#text("I would like to know why the right hand side of (1) doesn’t converge conditionally for 0 < Re(s) $\\leq$ 1 Img(s) $\\neq$ 0. The infinitely many sign changes due to the imaginary part makes it hard for me to prove the statement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-469914")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("At least, for real ")#mi("s")#text(" (for which the terms are positive) the statement is trivial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-469919")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("Estimate the partial sums on an interval of the form ")#mi("N \\leq n \\leq (1+\\varepsilon) N")#text(" for some small but fixed ")#mi("\\varepsilon>0")#text(" and some very large ")#mi("N")#text(", the point being that there is almost no oscillation in this partial sum if ")#mi("\\varepsilon")#text(" is small enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-469925")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")])]

#text("What is known about the Cesaro summation properties for this series inside the critical strip? Is it possible to use this (or higher order) Cesaro summation for the analytic continuation of ")#mi("\\zeta(s)")#text(" into the critical strip?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-469940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2016")])]

#text("Cesaro summation only smooths out oscillations in the range ")#mi("n \\in [x,2x]")#text(" (say) that occur at wavelength significantly less than ")#mi("x")#text(". The summand ")#mi("\\frac{1}{n^{\\sigma+it}}")#text(" oscillates with wavelength comparable to ")#mi("x")#text(" in this range and so convergence is not significantly improved by Cesaro summation. However gentler summation methods, such as Abel summation or (tautologically) zeta function regularisation, will indeed smooth out these oscillations and allow one to extract out a limiting value ")#mi("\\zeta(s)")#text(" for the sum.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e07097ef8629dc3c5e3bfcf89cd698886e593d37a24624b144c8952b83399af6-897ee1d698228a6521487b6d371f95682f333c2524b0391071e05d9c43e01764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zz")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470028")[#strong[#text("Zz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2016")])]

#text("Hi mr.Tao, i want to share with you and your visitors one result that i´ve found working with prime numbers:")#linebreak()#text(" “For every p prime > 3 exists k natural, where ")#mi("-\\frac{1}{12}=\\frac{k}{1-p^2}")#text(" ”")#linebreak()#text(" or in other words: ")#mi("12 | (p^2-1)")#linebreak()#text(" best regards!")#linebreak()#text(" *correcting latex sintaxis, I apologize this is my first message*")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470031")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2016")])]

#text("It is easy to verify that this property holds (more generally) for any odd integer ")#mi("p")#text(" which is not divisible by ")#mi("3")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e07097ef8629dc3c5e3bfcf89cd698886e593d37a24624b144c8952b83399af6-897ee1d698228a6521487b6d371f95682f333c2524b0391071e05d9c43e01764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zz")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470045")[#strong[#text("Zz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2016")])]

#text("Dear Anonymous, you are right.")#linebreak()#text(" Also I want to add that this property also holds if we say “For all ")#mi("p > 3")#text(" prime and ")#mi("n")#text(" natural, exists ")#mi("k")#text(" natural, where ")#mi("-\\frac{1}{12}=\\frac{k}{1-p^{2n}}")#text("”")#linebreak()#text(" or in other words: ")#mi("12 | (p^{2n}-1)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470069")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2016")])]

#text("Since ")#mi("(p^2 -1)| (p^{2n} -1)")#text(", this property is implied by the (apparently weaker) previous property.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470233")[#strong[#text("254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2016")])]

#text("[…] to extend meromorphically to the entire complex plane by using the Euler-Maclaurin formula; see this previous blog post. However, we will not pursue this approach to the meromorphic continuation of zeta further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-470677")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2016")])]

#text("please, use \\dotsb from amsmath.sty instead of \\dots after a binary operator such as + or -, so the dots are aligned vertically on the math axis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-471009")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2016")])]

#text("Is there any known criterion to decide which any given (classically divergent) series still have a (more or less objective) unique “sum” – determined by the above (or similar) summation methods?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-471067")[#strong[#text("1 + 2 + 3 + 4 + 5 + … = -1/12 | Math Problem")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-func&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-func&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-472260")[#strong[#text("1+2+3+4+5…=-1/12 – Fourierinformationsir")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2016")]

#text("[…] this identity is not literally correct, it is still in some sense meaningful. There are far more complex and insightful proofs and interpretations of this identity, but they are a little hard to follow. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Elementary multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-472493")[#strong[#text("254A, Notes 1: Elementary multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] smoother sums such as (5) with smooth, thanks to tools such as the Poisson summation formula. See this previous blog post for some related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 1: Complex differentiation | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-472502")[#strong[#text("246A, Notes 1: Complex differentiation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] leads to generalised summation methods such as zeta function regularisation, which are discussed in this previous blog post. However, we will not use such generalised interpretations of summation very much in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9096dfde7269816be6863a97608b7e1dbb9076f2e60955c86994ad2ca5e62bfb-7f619dd9bfe6cd8d2bb83e70c0a5321fb698b17b4bd6309771b0707acd7517e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reeshad Arian")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-473437")[#strong[#text("Reeshad Arian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Is there a way to sum factorials? If so, is there a use for it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9c2fa19d769db2a9dc7e90c8d0e0b8a0199d292ad08e321afc0b290a443c0f8-df4858d65acf5e2eca5b40506c4fdc2c100b38ee516d649ad4fbbf855078e32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CodeLabMaster")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-475188")[#strong[#text("CodeLabMaster")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("The reason for using the ")#mi("C^{k+2}")#text(" norm is that ")#tao-math("\\left\\|f\\right\\|_{C^{k+2}} = O(1/N^2)", block: false)#text(" so ")#tao-math("O \\left( N \\left\\|f\\right\\|_{C^{k+2}}  \\right)= O(1/N)", block: false)#text(" goes to ")#mi("0")#text(" as ")#mi("N \\to \\infty")#text(" (where ")#mi("f(x) := x^k\\eta(x/N)")#text("). When we set ")#mi("f(x) := \\Gamma(x+1) \\eta(x/N)")#text(", we see that increasing ")#mi("k")#text(" does nothing to help bound our norm more tightly (whereas before, repeated differentiation of the monomial zeroed it out). I’m not sure how one would go about fixing that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ccf11fb4eefa65d72aa4581c5826416b951ea2473a976ab14fa067534b1d05a0-6afd38ddf05fba05735cf13e96a4d2f0c42a3c7bc49c4326a5bb06d9c1a931f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mango")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-2/#comment-475274")[#strong[#text("John Mango")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("It doesn’t really bother me, but someone pointed out to me that ")#tao-math("\\left|\\left|f\\right|\\right|_{\\dot{C}^2} = \\mathrm{sup}_{x \\in \\mathbb{R}} \\left|f^{\\prime\\prime}(x)\\right|", block: false)#text(" is not really a norm since it vanishes for all ")#mi("f(x) = ax + b")#text(". I thought the jargon was “Sobolev” norm, but that’s wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-477265")[#strong[#text("¿Qué sorpresas esconden las sumas infinitas? I | Una vista circular")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2017")]

#text("[…] 1 + 2 + 3 + 4 + ….. Yo he aprendido este enfoque, que quizás no es aún muy conocido, en un magnífico post en el blog de Terence Tao. Mi objetivo en esta serie de posts es dar los detalles imprescindibles […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b11eef0ab806286449cb2d01b102852d32ae9f437ed84257958e008e407220-d8295139a0f32ddff4de05d84837a1a7f10c648f95b8853a3df88f70e2917561.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kolmogorovscale")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-477319")[#strong[#text("kolmogorovscale")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")])]

#text("Reblogged this on ")#link("https://statphysbiochem.wordpress.com/2017/01/31/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("Stat Phys Bio Chem")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-483139")[#strong[#text("Why -1/12? – Maths and Machine Learning")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2017")]

#text("[…] very thorough (and reasonably accessible) discussion of the above series can be found in Terrence Tao’s blog post. In this post, I will not be attempting to either match the rigor or the comprehensiveness of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2674a8d59874d8483b57ac3fed17c237436e40854fef410a8e3fa5f9801efcfc-24ce3e322919ab7930c7e251e1613d7db32ce66cc3a1fda50bb408d1a5dfa074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Enoch Opeyemi")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-484116")[#strong[#text("Dr. Enoch Opeyemi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2017")])]

#text("Greetings Prof. Tao,")#linebreak()#text(" Over the years,I have been working on the Riemann Hypothesis and I have recently found some results that might be interesting to you sir.")

#text("I would like your comments and contributions on them because I got to a point at which I need to use analytic continuation method on my finding.")

#text("Thank you Sir!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-485932")[#strong[#text("Zeta function regularization – Amplitudes. . .")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")]

#text("[…] you can read about divergent series in the following post by Terence Tao and in the book Divergent Series by Hardy. The Riemann hypothesis is an open problem in math, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abda19d8000a9ce60427e0853b80afe7ffd69361ecd845e4bcd7af18e5eb8a5b-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Javier Garcia Moreta")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-486030")[#strong[#text("Jose Javier Garcia Moreta")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2017")])]

#text("Dear professor tao.. for the case of the general harmonic series")

#text("\\sum_{n=0}^{\\infty} \\frac{1}{(n+a)}? is this \\-Psi(a) or \\|-\\Psi (a)+log(a) ??")

#text("which one is the correct regularized result ??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/346d5fdd22af4affac3353c355c0178a3eed6a9d991f83f58a6895705848dbc9-b4dd9f51cc2a9477568c198bd54b4eb00d1a623715beaaae545526a32588f4d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-486340")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Here is another strange equality, which might be compared to equation (7):")#linebreak()#text(" ")#mi("S=\\sum_{k=0}^{\\infty }10^k=-\\frac{1}{9}")#linebreak()#text(" And here is the proof of this: Clearly 10S = S – 1 (!)")#linebreak()#text(" And since 1/9 = 0.111111… this leads to")#linebreak()#text(" ")#mi("S=\\sum_{-\\infty}^{\\infty }10^k = 0")#linebreak()#text(" You can generalize this to any rational number, like e.g.")#linebreak()#text(" ")#mi("142857 \\sum_{k=0}^{\\infty }10^{6k}=-\\frac{1}{7}")#linebreak()#text(" And with 1/7 = 0.142857142857… it follows that")#linebreak()#text(" ")#mi("142857 \\sum_{-\\infty}^{\\infty }10^{6k} = 0")#linebreak()#text(" Sorry about this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c449abb7a60f7d7ba0191f3304fef64c57508b3d23c9183775b8f96ea0adc3f-fc7a874909eec06b233acee7678cb7c264e7c82f5014881e5ece17f2be65053d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B. Koller")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-488304")[#strong[#text("B. Koller")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")])]

#text("A question of terminology :")

#text("I have a rather naive question. We can prove in a strictly mathematical sense that the sum over all the natural numbers must be positive, for instance by induction. If on the other side we put the sum of all natural numbers equal to -1/12 then we prove the contradiction -1/12 > 0 and one knows that from a contradiction everything follows.")#linebreak()#text(" So should we not write instead of the equal sign =, which stands for an equivalence relation and is therefore transitive, the sign : from logic which is in my understanding not an equivalence relation and is not giving a contradiction. I know this is not done usually in mathematics, but it would have the advantage to create less misunderstandings.")

#text("Thanks")

#text("PS. Prof. Tao approach gave me a much better understanding of infinite series, thanks a lot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-489087")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2017")])]

#text("“We can prove in a strictly mathematical sense that the sum over all the natural numbers must be positive, for instance by induction.”")

#text("This is not true. You can only prove by induction that the sum of finitely many addends, all of which are elements of set of natural numbers, must itself be a natural number. However, this proof cannot be executed with infinitely many addends, since it can be rigorously proven that infinite sums are in general not commutative, nor are they closed under any subset of the real numbers, nor are they associative.")

#text("“If on the other side we put the sum of all natural numbers equal to -1/12 then we prove the contradiction -1/12 > 0”")

#text("You’re assuming the sum is greater than zero, which is not. Terence Tao provided an explanation of why this is the case. Whenever N is finite, the term of the highest order in asymptotic expansion, C(η,1)N^2, is always positive and larger in magnitude than 1/12. However, this can be shown false whenever N is infinite.")

#text("“So should we not write instead of the equal sign =, which stands for an equivalence relation and is therefore transitive, the sign : from logic which is in my understanding not an equivalence relation and is not giving a contradiction.”")

#text("There is no contradiction. Mathematicians have been using = for centuries, and the reason is that the usage of it is not wrong.")

#text("“I know this is not done usually in mathematics, but it would have the advantage to create less misunderstandings.”")

#text("There is no misunderstanding. The = is meant literally here, because there are methods to prove that both expressions in the equation are EQUAL, they do not merely correspond to each other, but are actually equivalent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a560eac5e959a723b6fade4cab7a51cda12f7ba366acf9b7c18445f0a0bccd1-f6501636237669ba80c1fd26d48acdf6dce3ec5ce525973c0656ef47c288db27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Mückenheim")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-679757")[#strong[#text("Wolfgang Mückenheim")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2023")])]

#text("Adding positive values finitely or infinitely often will never result in a decrease.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-505752")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("Also, to add to my response to the comment, your claim that everything follows from a contradiction is not true. The principle of explosion is merely an axiom of classical propositional logic, but arithmetic first-order logic uses a Hilbert-style deduction system, in which the principle of explosion cannot be proven nor disproven.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-489375")[#strong[#text("1+2+3+4+ … = –1/12 | Maths with a Pinch of Salt")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2017")]

#text("[…] Terence Tao (o różnych sposobach „sumowania” nieskończonych sum) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-489891")[#strong[#text("1+2+3+4+ … = –1/12 – Mathematica cum grano salis")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")]

#text("[…] Terence Tao (on the many ways of making sense of „impossible” sums) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ca8e7d414ae286f50d3da5cc192fd58084f8ceeebde4840ca8848009a16f63-50c37071087a27e440bec67d1335ee7fc4aecce8a62a19766a934b1087b10114.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Ghosh")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-493438")[#strong[#text("Aditya Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Reblogged this on ")#link("https://mathsupportweb.wordpress.com/2018/03/03/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("Mathematics Support")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beb6bf2d90df72b60422a387a18aa2654c6fd7903561ecc3e382d5fe950ee5a5-44e5b90a2f220123ac9552a78e511d5b53689b6887e72157034cc4e1dc8ee111.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clément Caubel")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-497671")[#strong[#text("Clément Caubel")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("Just to mention a little mistake/typo: after the proof of the Euler-MacLaurin formula (22), when deducing the claim (14), the left hand side is ")#mi("c_{\\eta,s}N^{s+1}")#text(" (and not ")#mi("c_{\\eta,s}N^s")#text("). Also, the size ")#mi("C_{\\eta,s}")#text(" is used during the introduction, and then replaced by ")#mi("c_{\\eta,s}")#text(".")

#text("This gives me the opportunity to thank you warmly for sharing your notes on this blog!")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-502442")[#strong[#text("Is String Theory Built On Funny Math? | Physics Forums")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2018")]

#text("[…] if you want more heavy math see the blog by Terry Tao the guy that started me thinking about this: ")#link("https://terrytao.wordpress.com/2010")[#text("https://terrytao.wordpress.com/2010")]#text("…tion-and-real-variable-analytic-continuation/ Now the 64 million dollar question is this, Look in video 1 – he opens a string theory text – low […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-503565")[#strong[#text("The Sum Of All Numbers Is -1/12? – This Week I Found Out")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-503674")[#strong[#text("Fake papers #1: L’uomo che scambiò la Zeta di Riemann per un polinomio | Maddmaths!")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2018")]

#text("[…] Per farsi un’idea di come questa procedura sia di difficile comprensione per i non esperti, usando la continuazione analitica si arriva a scrivere [1+2+3+4+dots “=” -frac{1}{12}] dove i puntini a sinistra dell’uguale indicano che vanno sommati tutti i numeri naturali, mentre l’uguale è scritto tra virgolette proprio ad indicare che non si tratta di una vera uguaglianza, ma di un’uguaglianza che ha senso usando la procedura di continuazione analitica. Non ha infatti molto senso pensare che la somma di tutti i numeri naturali, infiniti e tutti positivi, sia uguale a un numero razionale e per di più negativo! In effetti la formula nasce dalla continuazione analitica proprio della funzione zeta di Riemann, e ci dice che (-frac{1}{12}) è il valore della funzione (zeta(s)) per (s=-1). Se volete saperne di più su somme di questo tipo, senza usare la continuazione analitica, potete consultare l’articolo tecnico sul blog di Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f00bd0ab55954d1569041af0471e9f3644b7b76bf23e9bda2b6f736d40b37de-3f155f0d43a8dc86fd990fdf8c59817172efcfbce2f60634922b3acc70b022a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jotvansh")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-505743")[#strong[#text("Jotvansh")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("Hi, Professor Tao")

#text("I am a highschool student, I was really fascinated with with this theorem as it contradicts the basic principles of mathematics, so I chose this my mathematical reasacrch project, however I have to prove this summation in an less rigorous way. I have used Grandi series and Ceasaro convergent in order to use for this equation. Although, I am not really sure it would be correct to use them to manipulate the series.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9311b7dc9694169fcac1111e33ab86fa9553d0e67449c3421c97054785beedfa-098b29038641ef015fba53a9278e8e727465e8a5b368f069841f0db893c58439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ángel Méndez Rivera")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-505751")[#strong[#text("Ángel Méndez Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("First of all, you are wrong. The theorem does not contradict the basic principles of mathematics. In fact, I question whether you can even correctly list all the basic principles of mathematics you are appealing to. My guess is that you cannot. This is not surprising, since such principles are typically never taught until you have reached a graduate level of mathematical education. In any case, the very fact that it is a theorem implies it cannot be in contradiction with the principles, because by definition, theorems are derivable only from principles. If you conclude that mathematical claim contradicts the principles, then either the claim is not a theorem, or else your understanding of the principles is incorrect.")

#text("Second of all, Cèsaro summations are not useable for this series, because this series is outside the domain of the Cèsaro summations. The Grandi series is not linearly nor polynomially related to the Ramanujan series. You must use some other method to prove the theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a560eac5e959a723b6fade4cab7a51cda12f7ba366acf9b7c18445f0a0bccd1-f6501636237669ba80c1fd26d48acdf6dce3ec5ce525973c0656ef47c288db27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Mckenhei8m")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-679774")[#strong[#text("Wolfgang Mckenhei8m")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2023")])]

#text("A theorem can imply a contradiction if the basics are inconsistent. Here: Only geometric series with q less than 1 can be summed in a meaningful way. Further summing infinit sets obeys the same logic as summing finite sets: Adding only positive values cannot reduce the result. Finally we need not look for the reasons if the result is blatantly false like -1/12 > 1.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69534a4ac856bd3a6d458cdde3b9176fbd7c1e8f2ceba76c2bceb08d21a1c7b4-9b5684eb3b58bba5253fed56c56335cad843ed3eafceb0d30383d04ea52f28bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerome")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-511897")[#strong[#text("Jerome")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2019")])]

#text("@RIvera I support your patience.")#linebreak()#text(" A small linguistic remark. In the context of these ‘provocative’ limits (they are not a provocation at all to me.).")#linebreak()#text(" I might be good avoid saying ‘this series has such limit’ and say this series is given such limit.")#linebreak()#text(" In fact what matters before all is that the limit we GIVE commute with finite sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f03b8f30993efb268ac6657a5dd805d9a4721e2ef75a4df837ac10c2f146216b-31e62139ff4dcea15a5f96afe6139a162391fbc2c6d1a7e42a7818f1fe72cf53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl Svozil")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-519024")[#strong[#text("Karl Svozil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("May formula (12) not also be interpreted as a consequence or rather an instance of Ritt’s theorem? And therefore (14) a generalization thereof?")

#text("(Please excuse this naive question of a humble physicist; and thank you for this very nice post!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-520815")[#strong[#text("Terence Tao - Understanding 1+2+3+...=-1/12 without Complex Analysis - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")]

#text("[…] by /u/MysteriousSeaPeoples [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12257ef5f5a8a627a8a085b82825eb939de6895f8ff8ee6c99440d0f9bd2cf47-7986496f91adabceaeaafbb7aaa26aa83240f2ba573d4ad245806463f24c7eec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Nardelli")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-523638")[#strong[#text("Michele Nardelli")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2019")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I deal mainly of the new possible mathematical connections, between various formulas of some sectors of theoretical physics and some formulas of specific areas of Number Theory, especially the mathematics of the Indian genius S. Ramanujan (Rogers-Ramanujan identity, mock theta functions and partition functions) and I have already obtained several interesting results from various connections with some sectors of M-Theory, Particle Physics, and black holes physics. I think it’s important to highlight that the values of any entropies (or masses), from which you can to obtain mass (or entropy), radius and temperature of a black hole, by the develop with a formula which contains two results of mock theta functions, provide ALWAYS solutions that, in my humble opinion, could be interesting and significant, as it very closed (practically almost equals) to the mathematical constant Phi (golden ratio) and the Riemann zeta function, precisely ζ(2) = ℼ2 / 6 = 1.644934… that appears very often in many sectors of string theory and Number Theory.")#linebreak()#text(" Thank You and best regards")

#link("https://www.semanticscholar.org/paper/On-the-Hypothetical-Dark-Matter-Candidate-New-with-Nardelli-Nardelli/4fad57b020b5ffb1c9990fba326a438368d76aab")[#text("https://www.semanticscholar.org/paper/On-the-Hypothetical-Dark-Matter-Candidate-New-with-Nardelli-Nardelli/4fad57b020b5ffb1c9990fba326a438368d76aab")]

#link("https://www.semanticscholar.org/paper/Further-Mathematical-Connections-Between-the-Dark-Nardelli-Nardelli/50c23911e187ed97e207d9bf7e5552d7a900235e")[#text("https://www.semanticscholar.org/paper/Further-Mathematical-Connections-Between-the-Dark-Nardelli-Nardelli/50c23911e187ed97e207d9bf7e5552d7a900235e")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-524060")[#strong[#text("The Sum Of All Numbers Is -1/12? – This Month I Found Out")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-527316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("Very Nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-547003")[#strong[#text("About -1/12 – elkalamaras")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2020")]

#text("[…] [10] Terrence Tao, The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic continuation, ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")[#text("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-fun&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-548712")[#strong[#text("There is a lot of discussion in various online mathematical forums currently about the interpretation, derivation,… – mosqueeto")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")]

#text("[…] https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-func… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b071d54969bf641db898f29ded62eb7af11a6ec5de0b86719c0dc980d4c26771-60999644878f5fbcfe521b41a0be8a66897b9a71c14c3a952c97d6455e1fe5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isaac mor")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-550316")[#strong[#text("isaac mor")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("terry tap please check the png image attached")

#text("1. (-1) factprial is -1")#linebreak()#text(" 2. there is no pole at zeta(1)")

#link("http://myzeta.125mb.com/")[#text("http://myzeta.125mb.com/")]

#link("https://drive.google.com/file/d/1rrX3_Tx1hmbAcq3VzSMLC-uIXC5jDXQ-/view")[#text("https://drive.google.com/file/d/1rrX3_Tx1hmbAcq3VzSMLC-uIXC5jDXQ-/view")]

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-577936")[#strong[#text("Sorpresas en las sumas infinitas (VIII) Revisitando 1+2+3+4+…=-1/12 (?) | Una vista circular")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2020")]

#text("[…] se puede entender el resultado con un planteamiento elemental, que yo he aprendido de un magnifico post en el blog de Terence Tao, y que no he visto en ningún otro lugar. Esto es lo que quiero comentar hoy, para ir cerrando esta […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/901a632f286adfb003fb79434c4024f32e8d380b8f4283ebf76e316936151350-1db1672b48d2299839f9db6a1998f40b6380f6c9dde07393692df49d4af53cf6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francois Oger")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-581404")[#strong[#text("Francois Oger")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("If you are interested to learn more about divergent series and want to understand why and how 1+2+3+4+5+6+… = -1/12, I recommend the following online course:")#linebreak()#text(" Introduction to Divergent Series of Integers")#linebreak()#text(" ")#link("https://divergent.thinkific.com/courses/dsi-101")[#text("https://divergent.thinkific.com/courses/dsi-101")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c938a0a8dada9fd23e24888082775f614f52e2badb857ac7dac7436038fc9bf-1b76d032f6ff4081722679b5b209d92ce56820e1ab1a0be6ded352e79ddd0aa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fpmarin")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-599994")[#strong[#text("fpmarin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("Do you know an analytical continuation of the Euler Number $E_{n}$ ?. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cca994b769eb1f132cfb05228526d82577819eceaf4b68e0dab0e1256cdedbc-bec19867caaac08d4c54b326577eb18b3a47ed9f4d704156b96d41533bf08836.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick D'Anzi")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-604770")[#strong[#text("Patrick D'Anzi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("I have difficulty understanding how to make this statement explicit (I don’t know complex analysis very well), what I did was use the Euler-Maclaurin formula:")

#tao-fit-display[#mitex("\\int^n_m f(z)dz=\\sum_{k=m}^nf(k)-\\frac{f(n)-f(m)}{2}-\\sum_{h=1}^{\\lfloor p/2\\rfloor}\\frac{B_{2h}}{(2h)!}(f^{(2h-1)}(n)-f^{(2h-1)}(m))-R_p")]

#text("where ")#mi("R_p=\\mathcal{O}(\\int_m^n |f^{(p)}(z)|dz)")#text(".")

#text("let ")#mi("\\alpha=\\mathcal{Re}[s-B]$ and $g(z)=\\zeta(z)\\frac{N^{z-s}F(z-s)}{z-s}:")

#tao-fit-display[#mitex("\\int^{\\alpha+i \\infty}_{\\alpha-i \\infty} g(z)dz=\\sum_{k=-\\infty}^{+ \\infty}g(\\alpha+i k)+\\mathcal{O}(\\int_{\\alpha-i \\infty}^{\\alpha+i \\infty} |g^{(p)}(z)|dz)")]#linebreak()#text(" at this point I have doubts, I could change the integration line by choosing a ")#mi("\\alpha")#text(" that ")#mi("\\forall k")#text(" neglects ")#mi("g (\\alpha + ik)")#text(" but anyway I don’t know how to show that ")#mi("\\mathcal {O} (\\int_ {\\alpha-i \\infty} ^ {\\alpha + i \\infty} | g ^ {(p)} (z) | dz) = \\mathcal {O} (N ^ {- B})")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-621769")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("To see the beauty of Ramanujan’s use of divergent series, as first recognized by Hardy, see my MathOverflow answer and the comments attached to it (")#link("https://mathoverflow.net/questions/79868/what-does-mellin-inversion-really-mean/79925#79925")[#text("https://mathoverflow.net/questions/79868/what-does-mellin-inversion-really-mean/79925#79925")]#text("). Hardy was predisposed to see this (took him overnight though) since he basically advocated in one of his early papers what I call the Hardy heuristic “When in doubt, interchange operations” similar to Feynman’s “When in doubt, integrate by parts,” the basis to the theory of distributions. (Hardy later gave rigorous conditions under which Ramanujan’s Master Formula is valid.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12257ef5f5a8a627a8a085b82825eb939de6895f8ff8ee6c99440d0f9bd2cf47-7986496f91adabceaeaafbb7aaa26aa83240f2ba573d4ad245806463f24c7eec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-621773")[#strong[#text("Michele")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("Great Srinivasa Ramanujan! is my source of inspiration and was a genius, as Littlewood said, comparable to a Jacobi or an Euler")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d97e6504a9fc8faacfd87a473f969e4db1ea2b532cef05b4c66136c918e41d-a6198ac0f8b56908d7a4e6c8af43a456a4a29a79df59fda5c1fac85eafb8f898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-621774")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("Hardy rated himself a C mathematician compared to Ramanujan as an A. (That puts me off the alphabet. I don’t use the term genius– in some sense it marginalizes the passion, the diligence and dedication, even obsession, of the masters.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-622256")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] has to be interpreted in a suitable non-classical sense in order for it to be rigorous (see this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-633951")[#strong[#text("Links | Derivative Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2021")]

#text("[…] The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic conti… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17c9923dc9ecdf1344d90e5a5cb39ce00d64a79bb1385281e165a267c065448a-784bc795de959a945bbdeaf400f99c1fe599f9bd2b0919d15f03b6b620baca14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-637652")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2021")])]

#text("I believe that you need to strengthen your initial definition of a “cutoff function” to require that ")#mi("\\eta(x)")#text(" be (right-)continuous at ")#mi("x = 0")#text(". Your current initial definition only requires that ")#mi("\\eta(0) = 1")#text(", but this is not enough to imply your later claim that “")#mi("\\eta(n/N) \\to 1")#text(" pointwise as ")#mi("N \\to \\infty")#text("“. (Beginning with the following sentence, you consistently specify that ")#mi("\\eta")#text(" is (at least) continuous.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24285270fc3f2f49737c61342e6e75f5e1235b0a20f7afb4e179056050d8005d-1c1d1e2a110a2b42fbb79e74d0b3991f0cf59c01581fd2680152b5794e3eae84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amos Kipngetich Korir")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-639574")[#strong[#text("Amos Kipngetich Korir")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2022")])]

#text("Here is interesting result which one can use to come up with Euler -Maclaurin formula.I found out that 1/(1+X) is convergent for X>1 if we change the sign of exponent in the famous infinite series a(its Taylor series)to negative and this can be clearly be proven and we can still use the same coefficients.")#linebreak()#text(" 1/(1+X)=(x^-1) – (x^-2) + (x^-3) -……..")#linebreak()#text(" And this is true for other values like")#linebreak()#text(" 1/(1+X)^2…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-639582")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2022")])]

#text("This is true for any rational function ")#mi("f")#text(" which satisfy the functional equation ")#mi("f(x^{-1}) = f(x)")#text(" – which is satisfied by the above examples.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-644160")[#strong[#text("1+2+3+4+… = ? | Buah Pikir")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2022")]

#text("[…] blog pribadinya, Terry Tao menulis bahwa kita perlu melakukan regularisasi. Makhluk apa itu regularisasi? Saya […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68af75f3adef64d3c0ce2c2c8e586a463daf8aa4b58480a5d3984def76901cd4-6154405dc45d98b63e09d69c55e594d2bf70da79d8e587dd528dfa518d340a65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CK")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-649520")[#strong[#text("CK")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("In formula (23) you state: “Applying this with ")#mi("N")#text(" equal to a power of two and summing the telescoping series, one concludes that (24)”. If we let N -> 2^k and sum from k=N to k=infinity, then the telescoping sum on the RHS contains a term infinity^(1-s) which is undefined for Re(s)<1 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-649526")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("Summing the telescoping series on a finite range $\\sum_{k=k_0}^{k_1} \\dots$ will show that ")#mi("\\sum_{n=1}^{2^k} \\frac{1}{n^s} \\eta(n/2^k) - C_{\\eta,-s} (2^k)^{1-s}")#text(" is a Cauchy sequence converging to some limit ")#mi("\\zeta(s)")#text(", and then one can obtain the claim. (See also Lemma 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this blog post")]#text(" for an abstraction of this argument.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-670299")[#strong[#text("Asymptotics of smoothed sums from zeta regularization – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2022")]

#text("[…] this post, Terry Tao gives exactly what I'm after but for a different notion of zeta-function regularization. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa9dfe93d0bca6b5f75a55e9013f79a103aa47371d28ed172f8d6704f45636bf-86d5e0cdf6f18b225eaaf23e50d9c84e6c21d4053f8f51840df05ff58414957d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Tielman")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-677507")[#strong[#text("Bo Tielman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2023")])]

#text("Like you said, we normally define infinite sums with a limit of the partial sums, and you modified the summands by including this smoothing function eta. In order to define a limit, you need a topology. Is it possible to change (or extend) the usual Euclidian topopoly on \\mathbb{R} such that can still define our infinite sums the normal way (so without the eta), and that also agrees with the values of the analytic continuation, that also doesn’t mess everything we already had for normal converging infinite sums.")

#text("Does such a topology exist and if so, is it metrizable?")

#text("With kind regards,")#linebreak()#text(" Bo Tielman")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-677552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")])]

#text("Most infinite summation methods are not shift invariant, for instance ")#mi("0 + 1 + 2 + \\dots = 5/12")#text(" evaluates to a different sum than ")#mi("1 + 2 + 3 + \\dots = -1/12")#text(", so one cannot interpret these assignments of values to infinite sums as a limit of partial sums in any reasonable (e.g., Hausdorff) topology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682639")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2023")])]

#text("I have a strange sensation that this summation may be related to the renormalization procedure in physics. That one bothers Dirac as a deep flaw in the foundation of quantum field theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682647")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2023")])]

#text("A classic post! I’m amazed that cutoff functions like this don’t seem to be a standard topic in the context of divergent series. As shown here they often seem very mathematically natural, and in physics contexts I think they are the most natural class of summation methods.")

#text("One question I couldn’t immediately see the answer to, though: are they *consistent*, in the usual sense of summation methods? That is, if two functions $\\eta$ and $\\tilde{\\eta}$ can both give a finite answer to the smoothed sum, are those answers necessarily equal? (If no, can some reasonable conditions on $\\eta$ or $a_n$ make them consistent?)")

#text("Asked here too: ")#link("https://mathoverflow.net/questions/460676/consistency-results-for-divergent-series-summed-with-smooth-cutoff-functions")[#text("https://mathoverflow.net/questions/460676/consistency-results-for-divergent-series-summed-with-smooth-cutoff-functions")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2023")])]

#text("For functions of polynomial growth one can usually use the Euler-Maclaurin formula (22) to show that the cutoff ")#mi("\\eta")#text(" only affects higher order terms and not the constant term. However for functions of faster than polynomial growth, the situation is more delicate and one would have to analyze the divergent series on a case-by-case basis. I think in some cases, one cannot work with arbitrary cutoff functions, but instead turn to special cutoffs like the one used in zeta function regularization in order to have a good theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2680b42866db192c719f1b16a9b378f2850a2ff066e58d9d1aeb5f1ed1ce456c-6d4931c91ec5d2b2a98ccbe3783719363ad63b7f67c0e69d35d7d6f807a7ed17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sparsh Srivastava")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682730")[#strong[#text("Sparsh Srivastava")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2024")])]

#text("You made a mistake. Equation 8 is incorrect, you added each term in the series pointwise, which is a different operation than adding 2 infinite series. Also consider pointwise multiplication of series. Gonna test these operations out on ramunajans identities now. I’m considering the sum of the reciprocal powers of odds added with the sum of the reciprocal powers of evens because it gives zeta(s)-1 when re(s)>1. Also looking at the pairwise addition case of ramunajans first theorem on summations of series and its generalization now. Very interesting results. Also you’ve read his handwritten notes right? He uses +&c instead of ellipses. I wonder what the significance of that is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2680b42866db192c719f1b16a9b378f2850a2ff066e58d9d1aeb5f1ed1ce456c-6d4931c91ec5d2b2a98ccbe3783719363ad63b7f67c0e69d35d7d6f807a7ed17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sparsh Srivastava")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682731")[#strong[#text("Sparsh Srivastava")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2024")])]

#text("Also sometimes he gives 3 terms and in other cases 4. I’m sure there’s some significance to how many terms he gives. I think he’s giving the minimum number of terms needed to continue the pattern to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2680b42866db192c719f1b16a9b378f2850a2ff066e58d9d1aeb5f1ed1ce456c-6d4931c91ec5d2b2a98ccbe3783719363ad63b7f67c0e69d35d7d6f807a7ed17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sparsh Srivastava")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-682732")[#strong[#text("Sparsh Srivastava")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2024")])]

#text("Also x2 have you read the Aryabhatiyam by Aryabhata? I’m learning Sanskrit now using ai and I had it translate a bit and I read it, some parallels between it and ramunajan’s work. I can’t verify if he knew Sanskrit and would have read this text, but since its a classic Indian mathematical text I’m thinking the information flowed to him one way or another.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-684439")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2024")])]

#text("Related:")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-684452")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2024")])]

#text("Is there a way of deriving the sum of a series from the sums of related series. For example is the sum of the natural numbers related in some way to the individual sums of the odd number and even numbers?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-684456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2024")])]

#text("There are some relations, but one needs to proceed with care as there are several pitfalls. Firstly, divergent summation methods tend to be linear in the summands (provided that the sums actually can be interpreted); and hence ")#mi("\\sum_{n=1}^\\infty f(n)")#text(" can be expressed as the sum of ")#mi("\\sum_{n=1}^\\infty f(n) 1_{2|n}")#text(" and ")#mi("\\sum_{n=1}^\\infty f(n) 1_{2|n-1}")#text(" if all series here are interpretable by the same method. Homogeneous change of variables such as ")#mi("n \\mapsto 2n")#text(" also are typically okay, so the sum ")#mi("\\sum_{n=1}^\\infty f(n) 1_{2|n}")#text(" can be interpreted as ")#mi("\\sum_{n=1}^\\infty f(2n)")#text(". However, it is not always the case that inhomogeneous change of variables formulae such as ")#mi("\\sum_{n=1}^\\infty f(n) 1_{2|n-1} =")#text("latex \\sum_{n=1}^\\infty f(2n-1)$ are valid (the shift by ")#mi("-1")#text(" can mess with the cutoff ")#mi("\\eta(n/N)")#text(" in an undesirable fashion). Unless one knows exactly what one is doing, I would avoid blindly manipulating infinite divergent series, and work instead with the rigorous definitions of whatever summation method one is choosing to use, and manipulate those definitions from first principles.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-684459")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2024")])]

#text("Thanks for replying, it’s fascinating. I came to you via your recent Numberphile appearance.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2831338ff177df4150d1cb3c238521ccb8bef35ae102f71a67716b403c2d9d47-39ba18364c5ffb1a8d8be7691097a74977499c912e7f3a4f3402367a180ff668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orgesleka")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-684460")[#strong[#text("orgesleka")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2024")])]

#text("Dear Terence Tao,")

#text("I am not sure where to ask a question relating the Liouville function and an infinite dimensional lattice, so I thought to ask it here:")

#text("Is this infinite dimensional lattice known in literature:")#linebreak()#text(" ")#link("https://mathoverflow.net/questions/465877/infinite-dimensional-lattice-for-integers-and-the-riemann-hypothesis")[#text("https://mathoverflow.net/questions/465877/infinite-dimensional-lattice-for-integers-and-the-riemann-hypothesis")]

#text("Kind regards from Limburg in Germany,")#linebreak()#text(" Orges Leka")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-685201")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2024")])]

#text("The equation after the line “we conclude the trapezoidal rule” seems to have a truncated final O(N) expression in the latex.")

#emph[#text("[I am not able to reproduce this issue either on my phone or my laptop. Can you clarify? -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-685211")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2024")])]

#text("Thanks for your quick reply. This is a screenshot from my company laptop. I tried zooming in/out or scrolling left/right but the closing ) was still missing. No worries if it’s too much work.")

#align(center)[
#image("../assets/019d0eb3d53d8169f73d722b5fd23f5e40907efafa676ecb6e25cf8cd89769b8-76c4d5f2e4cbbcb1e7d9ae4d43307756b78efba2ec19805f864d361747bd810d.png", width: 90%)
]

#emph[#text("Strangely, I don’t get this overflow on my devices, but in any event I have broken up the display. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3b66bd9673e48cf37bc00fce30d09a5f81f5a046eb5d9d4c2c7b082fb98781d-49e78c2c7df34ec91e644834dc4a9339aae4fd7be4e9ab3271f443fb02453a9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur Jain")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-685648")[#strong[#text("Ankur Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2024")])]

#text("Sir,")#linebreak()#text("I want to bring this to your attention that i have been able to sum a divergent series to a finite sum using a Real Life Example of A Casino Game.")

#text("Please find the PDF attached to this email.")

#text("Any Feedback or Leads would be greatly appreciated.")

#link("https://www.dropbox.com/scl/fi/i29gsjk4ku98nszt810g6/Gold-Nugget-2.pdf?rlkey=7j5stv317tgffdaqt36ll5367&st=1evr8vzb&dl=0")[#text("https://www.dropbox.com/scl/fi/i29gsjk4ku98nszt810g6/Gold-Nugget-2.pdf?rlkey=7j5stv317tgffdaqt36ll5367&st=1evr8vzb&dl=0")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-688307")[#strong[#text("-1/12 and the area under the sum function – zmatt.net")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2025")]

#text("[…] I shall not dwell too much on this topic as it is already well discussed elsewhere; for a gentle introduction I would recommend Mathologer’s video, or for a more technical but brilliantly accessible piece I would suggest Terence Tao’s blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-689533")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2025")])]

#text("There is a missing word where you wrote “is right-continuous the origin”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJUCLA")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-693896")[#strong[#text("AJUCLA")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Can we assign H(s)=-\\sum_{s:\\zeta(s)=0\\wedge\\mathcal{Re}(s)\\in(0,1)}\\mathcal{Re}(s)\\log_2(\\mathcal{Re}(s) as the entropy of zeta zeros and ask if it 2 iff RH is true iff Von Neumann entropy of Hibert-Polya operator is 2?")

#text("Maybe the right question is whether the sum of real part of zeta zeros can be regularized? If it cannot be is RH false?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49c4ba5a6a7a00f103bd08213434542f07db7bf147d435f7bd2949866768917e-200690cfd79d1016a378758999c9211b13fe728919191e635c43187fe48005a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eneatambini")]], [#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/comment-page-3/#comment-699190")[#strong[#text("eneatambini")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("There is a “then” too much in this sentence: “If ")#mi("\\eta")#text(" is equal to ")#mi("1")#text(" on a neighbourhood of the origin, then the integral test argument then recovers the ")#mi("O(1/N)")#text(" decay rate:”")
]
