// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/
// Converted to Typst by tao2typ: "2026-10-14T08:51:39.245315+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 0: A review of probability theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 0: A review of probability theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In preparation for my upcoming course on random matrices, I am briefly reviewing some relevant foundational aspects of ")#link("http://en.wikipedia.org/wiki/Probability_theory")[#text("probability theory")]#text(", as well as setting up basic probabilistic notation that we will be using in later posts. This is quite basic material for a graduate course, and somewhat pedantic in nature, but given how heavily we will be relying on probability theory in this course, it seemed appropriate to take some time to go through these issues carefully.")

#text("We will certainly not attempt to cover all aspects of probability theory in this review. Aside from the utter foundations, we will be focusing primarily on those probabilistic concepts and operations that are useful for ")#emph[#text("bounding")]#text(" the distribution of random variables, and on ensuring ")#emph[#text("convergence")]#text(" of such variables as one sends a parameter ")#mi("{n}")#text(" off to infinity.")

#text("We will assume familiarity with the foundations of measure theory; see for instance ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("these earlier lecture notes")]#text(" of mine for a quick review of that topic. This is also ")#emph[#text("not")]#text(" intended to be a first introduction to probability theory, but is instead a revisiting of these topics from a graduate-level perspective (and in particular, after one has understood the foundations of measure theory). Indeed, I suspect it will be almost impossible to follow this course without already having a firm grasp of undergraduate probability theory.")

#metadata(none) <tao-1f0ce0fd98c3e85d43eb>

#heading(level: 1)[#strong[#text(" — 1. Foundations — ")]]

#text("At a purely formal level, one could call probability theory the study of ")#link("http://en.wikipedia.org/wiki/Measure_space")[#text("measure spaces")]#text(" with total measure one, but that would be like calling number theory the study of strings of digits which terminate. At a practical level, the opposite is true: just as number theorists study concepts (e.g. primality) that have the same meaning in every ")#link("http://en.wikipedia.org/wiki/Numeral_system")[#text("numeral system")]#text(" that models the natural numbers, we shall see that probability theorists study concepts (e.g. independence) that have the same meaning in every measure space that models a family of ")#link("http://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("events")]#text(" or ")#link("http://en.wikipedia.org/wiki/Random_variable")[#text("random variables")]#text(". And indeed, just as the natural numbers can be defined abstractly without reference to any numeral system (e.g. by the ")#link("http://en.wikipedia.org/wiki/Peano_axioms")[#text("Peano axioms")]#text("), core concepts of probability theory, such as random variables, can also be defined abstractly, without explicit mention of a measure space; we will return to this point when we discuss ")#link("http://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(" later in this course.")

#text("For now, though, we shall stick to the standard measure-theoretic approach to probability theory. In this approach, we assume the presence of an ambient ")#link("http://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(" ")#mi("{\\Omega}")#text(", which intuitively is supposed to describe all the possible outcomes of all the sources of randomness that one is studying. Mathematically, this sample space is a ")#link("http://en.wikipedia.org/wiki/Probability_Space")[#text("probability space")]#text(" ")#mi("{\\Omega = (\\Omega,{\\mathcal B},{\\bf P})}")#text(" – a set ")#mi("{\\Omega}")#text(", together with a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}}")#text(" of subsets of ")#mi("{\\Omega}")#text(" (the elements of which we will identify with the probabilistic concept of an ")#link("http://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("event")]#text("), and a ")#link("http://en.wikipedia.org/wiki/Probability_measure")[#text("probability measure")]#text(" ")#mi("{{\\bf P}}")#text(" on the space of events, i.e. an assignment ")#mi("{E \\mapsto {\\bf P}(E)}")#text(" of a real number in ")#mi("{[0,1]}")#text(" to every event ")#mi("{E}")#text(" (known as the ")#emph[#text("probability")]#text(" of that event), such that the whole space ")#mi("{\\Omega}")#text(" has probability ")#mi("{1}")#text(", and such that ")#mi("{{\\bf P}}")#text(" is countably additive.")

#text("Elements of the sample space ")#mi("{\\Omega}")#text(" will be denoted ")#mi("{\\omega}")#text(". However, for reasons that will be explained shortly, we will try to avoid actually referring to such elements unless absolutely required to.")

#text("If we were studying just a single random process, e.g. rolling a single die, then one could choose a very simple sample space – in this case, one could choose the finite set ")#mi("{\\{1,\\ldots,6\\}}")#text(", with the discrete ")#mi("{\\sigma}")#text("-algebra ")#mi("{2^{\\{1,\\ldots,6\\}} := \\{ A: A \\subset \\{1,\\ldots,6\\}\\}}")#text(" and the uniform probability measure. But if one later wanted to also study additional random processes (e.g. supposing one later wanted to roll a second die, and then add the two resulting rolls), one would have to change the sample space (e.g. to change it now to the product space ")#mi("{\\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\}}")#text("). If one was particularly well organised, one could in principle work out in advance all of the random variables one would ever want or need, and then specify the sample space accordingly, before doing any actual probability theory. In practice, though, it is far more convenient to add new sources of randomness on the fly, if and when they are needed, and ")#emph[#text("extend")]#text(" the sample space as necessary. This point is often glossed over in introductory probability texts, so let us spend a little time on it. We say that one probability space ")#mi("{(\\Omega^{\\prime},{\\mathcal B}^{\\prime}, {\\mathcal P}^{\\prime})}")#text(" ")#emph[#text("extends")]#text(" another ")#mi("{(\\Omega,{\\mathcal B}, {\\mathcal P})}")#text(" if there is a surjective map ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" which is ")#emph[#text("measurable")]#text(" (i.e. ")#mi("{\\pi^{-1}(E) \\in {\\mathcal B}^{\\prime}}")#text(" for every ")#mi("{E \\in {\\mathcal B}}")#text(") and ")#emph[#text("probability preserving")]#text(" (i.e. ")#mi("{{\\bf P}^{\\prime}(\\pi^{-1}(E)) = {\\bf P}(E)}")#text(" for every ")#mi("{E \\in {\\mathcal B}}")#text("). (Strictly speaking, it is the pair ")#mi("{((\\Omega^{\\prime},{\\mathcal B}^{\\prime}, {\\mathcal P}^{\\prime}), \\pi)}")#text(" which is the extension of ")#mi("{(\\Omega,{\\mathcal B}, {\\mathcal P})}")#text(", not just the space ")#mi("{(\\Omega^{\\prime},{\\mathcal B}^{\\prime}, {\\mathcal P}^{\\prime})}")#text(", but let us abuse notation slightly here.) By definition, every event ")#mi("{E}")#text(" in the original probability space is canonically identified with an event ")#mi("{\\pi^{-1}(E)}")#text(" of the same probability in the extension.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" As mentioned earlier, the sample space ")#mi("{\\{1,\\ldots,6\\}}")#text(", that models the roll of a single die, can be extended to the sample space ")#mi("{\\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\}}")#text(" that models the roll of the original die together with a new die, with the projection map ")#mi("{\\pi: \\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\} \\rightarrow \\{1,\\ldots,6\\}}")#text(" being given by ")#mi("{\\pi(x,y) := x}")#text(".")

#text("Another example of an extension map is that of a permutation – for instance, replacing the sample space ")#mi("{\\{1,\\ldots,6\\}}")#text(" by the isomorphic space ")#mi("{\\{ a,\\ldots,f\\}}")#text(" by mapping ")#mi("{a}")#text(" to ")#mi("{1}")#text(", etc. This extension is not actually adding any new sources of randomness, but is merely reorganising the existing randomness present in the sample space.")
]

#text("In order to have the freedom to perform extensions every time we need to introduce a new source of randomness, we will try to adhere to the following important dogma: ")#strong[#text("probability theory is only “allowed” to study concepts and perform operations which are preserved with respect to extension of the underlying sample space")]#text(". (This is analogous to how differential geometry is only “allowed” to study concepts and perform operations that are preserved with respect to coordinate change, or how graph theory is only “allowed” to study concepts and perform operations that are preserved with respect to relabeling of the vertices, etc..) As long as one is adhering strictly to this dogma, one can insert as many new sources of randomness (or reorganise existing sources of randomness) as one pleases; but if one deviates from this dogma and uses specific properties of a single sample space, then one has left the category of probability theory and must now take care when doing any subsequent operation that could alter that sample space. This dogma is an important aspect of the ")#emph[#text("probabilistic way of thinking")]#text(", much as the insistence on studying concepts and performing operations that are invariant with respect to coordinate changes or other symmetries is an important aspect of the modern geometric way of thinking. With this probabilistic viewpoint, we shall soon see the sample space essentially disappear from view altogether, after a few foundational issues are dispensed with.")

#text("Let’s give some simple examples of what is and what is not a probabilistic concept or operation. The probability ")#mi("{{\\bf P}(E)}")#text(" of an event is a probabilistic concept; it is preserved under extensions. Similarly, boolean operations on events such as union, intersection, and complement are also preserved under extensions and are thus also probabilistic operations. The emptiness or non-emptiness of an event ")#mi("{E}")#text(" is also probabilistic, as is the equality or non-equality of two events ")#mi("{E,F}")#text(" (note how it was important here that we demanded the map ")#mi("{\\pi}")#text(" to be surjective in the definition of an extension). On the other hand, the ")#emph[#text("cardinality")]#text(" of an event is not a probabilistic concept; for instance, the event that the roll of a given die gives ")#mi("{4}")#text(" has cardinality one in the sample space ")#mi("{\\{1,\\ldots,6\\}}")#text(", but has cardinality six in the sample space ")#mi("{\\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\}}")#text(" when the values of an additional die are used to extend the sample space. Thus, in the probabilistic way of thinking, one should avoid thinking about events as having cardinality, except to the extent that they are either empty or non-empty.")

#text("Indeed, once one is no longer working at the foundational level, it is best to try to suppress the fact that events are being modeled as sets altogether. To assist in this, we will choose notation that avoids explicit use of set theoretic notation. For instance, the union of two events ")#mi("{E, F}")#text(" will be denoted ")#mi("{E \\vee F}")#text(" rather than ")#mi("{E \\cup F}")#text(", and will often be referred to by a phrase such as “the event that at least one of ")#mi("{E}")#text(" or ")#mi("{F}")#text(" holds”. Similarly, the intersection ")#mi("{E \\cap F}")#text(" will instead be denoted ")#mi("{E \\wedge F}")#text(", or “the event that ")#mi("{E}")#text(" and ")#mi("{F}")#text(" both hold”, and the complement ")#mi("{\\Omega \\backslash E}")#text(" will instead be denoted ")#mi("{\\overline{E}}")#text(", or “the event that ")#mi("{E}")#text(" does not hold” or “the event that ")#mi("{E}")#text(" fails”. In particular the sure event ")#mi("{\\Omega}")#text(" can now be referred to without any explicit mention of the sample space as ")#mi("{\\overline{\\emptyset}}")#text(". We will continue to use the subset notation ")#mi("{E \\subset F}")#text(" (since the notation ")#mi("{E \\leq F}")#text(" may cause confusion), but refer to this statement as “")#mi("{E}")#text(" is contained in ")#mi("{F}")#text("” or “")#mi("{E}")#text(" implies ")#mi("{F}")#text("” or “")#mi("{E}")#text(" holds only if ")#mi("{F}")#text(" holds” rather than “")#mi("{E}")#text(" is a subset of ")#mi("{F}")#text("“, again to downplay the role of set theory in modeling these events.")

#text("We record the trivial but fundamental ")#emph[#text("union bound")]#text(" ")#metadata(none) <tao-ef3ff703d7565ab5215c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( \\bigvee_i E_i ) \\leq \\sum_i {\\bf P}(E_i)")]]



#text(" for any finite or countably infinite collection of events ")#mi("{E_i}")#text(". Taking complements, we see that if each event ")#mi("{E_i}")#text(" fails with probability at most ")#mi("{\\epsilon_i}")#text(", then the joint event ")#mi("{\\bigwedge_i E_i}")#text(" fails with probability at most ")#mi("{\\sum_i \\epsilon_i}")#text(". Thus, if one wants to ensure that all the events ")#mi("{E_i}")#text(" hold at once with a reasonable probability, one can try to do this by showing that the failure rate of the individual ")#mi("{E_i}")#text(" is small compared to the number of events one is controlling. This is a reasonably efficient strategy so long as one expects the events ")#mi("{E_i}")#text(" to be genuinely “different” from each other; if there are plenty of repetitions, then the union bound is poor (consider for instance the extreme case when ")#mi("{E_i}")#text(" does not even depend on ")#mi("{i}")#text(").")

#text("We will sometimes refer to use of the union bound to bound probabilities as the ")#emph[#text("zeroth moment method")]#text(", to contrast it with the first moment method, second moment method, exponential moment method, and Fourier moment methods for bounding probabilities that we will encounter later in this course.")

#text("Let us formalise some specific cases of the union bound that we will use frequently in the course. In most of this course, there will be an integer parameter ")#mi("{n}")#text(", which will often be going off to infinity, and upon which most other quantities will depend; for instance, we will often be considering the spectral properties of ")#mi("{n \\times n}")#text(" random matrices.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Asymptotic notation)")]#text(" We use ")#mi("{X = O(Y)}")#text(", ")#mi("{Y = \\Omega(X)}")#text(", ")#mi("{X \\ll Y}")#text(", or ")#mi("{Y \\gg X}")#text(" to denote the estimate ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some ")#mi("{C}")#text(" independent of ")#mi("{n}")#text(" and all ")#mi("{n \\geq C}")#text(". If we need ")#mi("{C}")#text(" to depend on a parameter, e.g. ")#mi("{C = C_k}")#text(", we will indicate this by subscripts, e.g. ")#mi("{X = O_k(Y)}")#text(". We write ")#mi("{X=o(Y)}")#text(" if ")#tao-math("{\\left|X\\right| \\leq c(n) Y}", block: false)#text(" for some ")#mi("{c}")#text(" that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". We write ")#mi("{X \\sim Y}")#text(" or ")#mi("{X = \\Theta(Y)}")#text(" if ")#mi("{X \\ll Y \\ll X}")#text(".")
]

#text("Given an event ")#mi("{E = E_n}")#text(" depending on such a parameter ")#mi("{n}")#text(", we have five notions (in decreasing order of confidence) that an event is likely to hold:")

#list(
[#text("An event ")#mi("{E}")#text(" holds ")#emph[#text("surely")]#text(" (or is ")#emph[#text("true")]#text(") if it is equal to the sure event ")#mi("{\\overline{\\emptyset}}")#text(".")],
[#text("An event ")#mi("{E}")#text(" holds ")#emph[#text("almost surely")]#text(" (or ")#emph[#text("with full probability")]#text(") if it occurs with probability ")#mi("{1}")#text(": ")#mi("{{\\bf P}(E) = 1}")#text(".")],
[#text("An event ")#mi("{E}")#text(" holds ")#emph[#text("with overwhelming probability")]#text(" if, for every fixed ")#mi("{A>0}")#text(", it holds with probability ")#mi("{1-O_A(n^{-A})}")#text(" (i.e. one has ")#mi("{{\\bf P}(E) \\geq 1 - C_A n^{-A}}")#text(" for some ")#mi("{C_A}")#text(" independent of ")#mi("{n}")#text(").")],
[#text("An event ")#mi("{E}")#text(" holds ")#emph[#text("with high probability")]#text(" if it holds with probability ")#mi("{1-O(n^{-c})}")#text(" for some ")#mi("{c>0}")#text(" independent of ")#mi("{n}")#text(" (i.e. one has ")#mi("{{\\bf P}(E) \\geq 1 - C n^{-c}}")#text(" for some ")#mi("{C}")#text(" independent of ")#mi("{n}")#text(").")],
[#text("An event ")#mi("{E}")#text(" holds ")#emph[#text("asymptotically almost surely")]#text(" if it holds with probability ")#mi("{1-o(1)}")#text(", thus the probability of success goes to ")#mi("{1}")#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(".")]
)

#text("Of course, all of these notions are probabilistic notions.")

#text("Given a family of events ")#mi("{E_\\alpha}")#text(" depending on some parameter ")#mi("{\\alpha}")#text(", we say that each event in the family holds with overwhelming probability ")#emph[#text("uniformly in")]#text(" ")#mi("{\\alpha}")#text(" if the constant ")#mi("{C_A}")#text(" in the definition of overwhelming probability is independent of ")#mi("{\\alpha}")#text("; one can similarly define uniformity in the concepts of holding with high probability or asymptotic almost sure probability.")

#text("From the union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(1)")]#text(" we immediately have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Union bound)")]#text(" ")#metadata(none) <tao-e6c57cc7714df7b28e4b>

#list(
[#text("If ")#mi("{E_\\alpha}")#text(" is an arbitrary family of events that each hold surely, then ")#mi("{\\bigwedge_\\alpha E_\\alpha}")#text(" holds surely.")],
[#text("If ")#mi("{E_\\alpha}")#text(" is an at most countable family of events that each hold almost surely, then ")#mi("{\\bigwedge_\\alpha E_\\alpha}")#text(" holds almost surely.")],
[#text("If ")#mi("{E_\\alpha}")#text(" is a family of events of polynomial cardinality (i.e. cardinality ")#mi("{O(n^{O(1)})}")#text(") which hold with uniformly overwhelming probability, the ")#mi("{\\bigwedge_\\alpha E_\\alpha}")#text(" holds with overwhelming probability.")],
[#text("If ")#mi("{E_\\alpha}")#text(" is a family of events of sub-polynomial cardinality (i.e. cardinality ")#mi("{O(n^{o(1)})}")#text(") which hold with uniformly high probability, the ")#mi("{\\bigwedge_\\alpha E_\\alpha}")#text(" holds with high probability. (In particular, the cardinality can be polylogarithmic in size, ")#mi("{O(\\log^{O(1)} n)}")#text(".)")],
[#text("If ")#mi("{E_\\alpha}")#text(" is a family of events of uniformly bounded cardinality (i.e. cardinality ")#mi("{O(1)}")#text(") which each hold asymptotically almost surely, then ")#mi("{\\bigwedge_\\alpha E_\\alpha}")#text(" holds asymptotically almost surely. (Note that uniformity of asymptotic almost sureness is automatic when the cardinality is bounded.)")]
)
]

#text("Note how as the certainty of an event gets stronger, the number of times one can apply the union bound increases. In particular, holding with overwhelming probability is practically as good as holding surely or almost surely in many of our applications (except when one has to deal with the entropy of an ")#mi("{n}")#text("-dimensional system, which can be exponentially large, and will thus require a certain amount of caution).")

#heading(level: 1)[#strong[#text(" — 2. Random variables — ")]]

#text("An event ")#mi("{E}")#text(" can be in just one of two states: the event can hold or fail, with some probability assigned to each. But we will usually need to consider the more general class of ")#link("http://en.wikipedia.org/wiki/Random_variable")[#text("random variables")]#text(" which can be in multiple states.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Random variable)")]#text(" Let ")#mi("{R = (R,{\\mathcal R})}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Measurable_space")[#text("measurable space")]#text(" (i.e. a set ")#mi("{R}")#text(", equipped with a ")#mi("{\\sigma}")#text("-algebra of subsets of ")#mi("{{\\mathcal R}}")#text("). A ")#emph[#text("random variable")]#text(" taking values in ")#mi("{R}")#text(" (or an ")#emph[#mi("{R}")#text("-valued random variable")]#text(") is a measurable map ")#mi("{X}")#text(" from the sample space to ")#mi("{R}")#text(", i.e. a function ")#mi("{X: \\Omega \\rightarrow R}")#text(" such that ")#mi("{X^{-1}(S)}")#text(" is an event for every ")#mi("{S \\in {\\mathcal R}}")#text(".")
]

#text("As the notion of a random variable involves the sample space, one has to pause to check that it invariant under extensions before one can assert that it is a probabilistic concept. But this is clear: if ")#mi("{X: \\Omega \\rightarrow R}")#text(" is a random variable, and ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" is an extension of ")#mi("{\\Omega}")#text(", then ")#mi("{X^{\\prime} := X \\circ \\pi}")#text(" is also a random variable, which generates the same events in the sense that ")#mi("{(X^{\\prime})^{-1}(S) = \\pi^{-1}( X^{-1}(S) )}")#text(" for every ")#mi("{S \\in {\\mathcal R}}")#text(".")

#text("At this point let us make the convenient convention (which we have in fact been implicitly using already) that an event is identified with the ")#link("http://en.wikipedia.org/wiki/Predicate_(mathematical_logic)")[#text("predicate")]#text(" which is true on the event set and false outside of the event set. Thus for instance the event ")#mi("{X^{-1}(S)}")#text(" could be identified with the predicate “")#mi("{X \\in S}")#text("“; this is preferable to the set-theoretic notation ")#mi("{\\{ \\omega \\in \\Omega: X(\\omega) \\in S \\}}")#text(", as it does not require explicit reference to the sample space and is thus more obviously a probabilistic notion. We will often omit the quotes when it is safe to do so, for instance ")#mi("{{\\bf P}(X \\in S)}")#text(" is shorthand for ")#mi("{{\\bf P}(``X \\in S^{\\prime\\prime})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-3959b7855f62b6b6f3f2>#text(" On occasion, we will have to deal with ")#emph[#text("almost surely defined")]#text(" random variables, which are only defined on a subset ")#mi("{\\Omega^{\\prime}}")#text(" of ")#mi("{\\Omega}")#text(" of full probability. However, much as measure theory and integration theory is largely unaffected by modification on sets of measure zero, many probabilistic concepts, in particular probability, distribution, and expectation, are similarly unaffected by modification on events of probability zero. Thus, a lack of definedness on an event of probability zero will usually not cause difficulty, so long as there are at most countably many such events in which one of the probabilistic objects being studied is undefined. In such cases, one can usually resolve such issues by setting a random variable to some arbitrary value (e.g. ")#mi("{0}")#text(") whenever it would otherwise be undefined.")
]

#text("We observe a few key subclasses and examples of random variables:")

#list(
[#emph[#text("Discrete random variables")]#text(", in which ")#mi("{{\\mathcal R} = 2^R}")#text(" is the discrete ")#mi("{\\sigma}")#text("-algebra, and ")#mi("{R}")#text(" is at most countable. Typical examples of ")#mi("{R}")#text(" include a countable subset of the reals or complexes, such as the natural numbers or integers. If ")#mi("{R=\\{0,1\\}}")#text(", we say that the random variable is ")#emph[#text("Boolean")]#text(", while if ")#mi("{R}")#text(" is just a singleton set ")#mi("{\\{c\\}}")#text(" we say that the random variable is ")#emph[#text("deterministic")]#text(", and (by abuse of notation) we identify this random variable with ")#mi("{c}")#text(" itself. Note that a Boolean random variable is nothing more than an ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator function")]#text(" ")#mi("{{\\bf I}(E)}")#text(" of an event ")#mi("{E}")#text(", where ")#mi("{E}")#text(" is the event that the boolean function equals ")#mi("{1}")#text(".")],
[#emph[#text("Real-valued random variables")]#text(", in which ")#mi("{R}")#text(" is the real line and ")#mi("{{\\mathcal R}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Borel_set")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(", generated by the open sets of ")#mi("{R}")#text(". Thus for any real-valued random variable ")#mi("{X}")#text(" and any interval ")#mi("{I}")#text(", we have the events “")#mi("{X \\in I}")#text("“. In particular, we have the ")#emph[#text("upper tail event")]#text(" “")#mi("{X \\geq \\lambda}")#text("” and ")#emph[#text("lower tail event")]#text(" “")#mi("{X \\leq \\lambda}")#text("” for any threshold ")#mi("{\\lambda}")#text(". (We also consider the events “")#mi("{X > \\lambda}")#text("” and “")#mi("{X < \\lambda}")#text("” to be tail events; in practice, there is very little distinction between the two.)")],
[#emph[#text("Complex random variables")]#text(", whose range is the complex plane with the Borel ")#mi("{\\sigma}")#text("-algebra. A typical event associated to a complex random variable ")#mi("{X}")#text(" is the ")#emph[#text("small ball event")]#text(" “")#tao-math("{\\left|X-z\\right| < r}", block: false)#text("” for some complex number ")#mi("{z}")#text(" and some (small) radius ")#mi("{r>0}")#text(". We refer to real and complex random variables collectively as ")#emph[#text("scalar random variables")]#text(".")],
[#text("Given a ")#mi("{R}")#text("-valued random variable ")#mi("{X}")#text(", and a measurable map ")#mi("{f: R \\rightarrow R^{\\prime}}")#text(", the ")#mi("{R^{\\prime}}")#text("-valued random variable ")#mi("{f(X)}")#text(" is indeed a random variable, and the operation of converting ")#mi("{X}")#text(" to ")#mi("{f(X)}")#text(" is preserved under extension of the sample space and is thus probabilistic. This variable ")#mi("{f(X)}")#text(" can also be defined without reference to the sample space as the unique random variable for which the identity")

#align(center)[#tao-fit-display[#mitex("``f(X) \\in S^{\\prime\\prime} = ``X \\in f^{-1}(S)^{\\prime\\prime}")]]

#text("holds for all ")#mi("{R^{\\prime}}")#text("-measurable sets ")#mi("{S}")#text(".")],
[#text("Given two random variables ")#mi("{X_1}")#text(" and ")#mi("{X_2}")#text(" taking values in ")#mi("{R_1, R_2}")#text(" respectively, one can form the ")#emph[#text("joint random variable")]#text(" ")#mi("{(X_1,X_2)}")#text(" with range ")#mi("{R_1 \\times R_2}")#text(" with the product ")#mi("{\\sigma}")#text("-algebra, by setting ")#mi("{(X_1,X_2)(\\omega) := (X_1(\\omega),X_2(\\omega))}")#text(" for every ")#mi("{\\omega \\in \\Omega}")#text(". One easily verifies that this is indeed a random variable, and that the operation of taking a joint random variable is a probabilistic operation. This variable can also be defined without reference to the sample space as the unique random variable for which one has ")#mi("{\\pi_1(X_1,X_2)=X_1}")#text(" and ")#mi("{\\pi_2(X_1,X_2)=X_2}")#text(", where ")#mi("{\\pi_1: (x_1,x_2) \\mapsto x_1}")#text(" and ")#mi("{\\pi_2: (x_1,x_2) \\mapsto x_2}")#text(" are the usual projection maps from ")#mi("{R_1 \\times R_2}")#text(" to ")#mi("{R_1, R_2}")#text(" respectively. One can similarly define the joint random variable ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" for any family of random variables ")#mi("{X_\\alpha}")#text(" in various ranges ")#mi("{R_\\alpha}")#text(" (note here that the set ")#mi("{A}")#text(" of labels can be infinite or even uncountable).")],
[#text("Combining the previous two constructions, given any measurable binary operation ")#mi("{f: R_1 \\times R_2 \\rightarrow R^{\\prime}}")#text(" and random variables ")#mi("{X_1, X_2}")#text(" taking values in ")#mi("{R_1, R_2}")#text(" respectively, one can form the ")#mi("{R^{\\prime}}")#text("-valued random variable ")#mi("{f(X_1,X_2) := f((X_1,X_2))}")#text(", and this is a probabilistic operation. Thus for instance one can add or multiply together scalar random variables, and similarly for the matrix-valued random variables that we will consider shortly. Similarly for ternary and higher order operations. A technical issue: if one wants to perform an operation (such as division of two scalar random variables) which is not defined everywhere (e.g. division when the denominator is zero). In such cases, one has to adjoin an additional “undefined” symbol ")#mi("{\\top}")#text(" to the output range ")#mi("{R^{\\prime}}")#text(". In practice, this will not be a problem as long as all random variables concerned are defined (i.e. avoid ")#mi("{\\top}")#text(") almost surely.")],
[#emph[#text("Vector-valued random variables")]#text(", which take values in a finite-dimensional vector space such as ")#mi("{{\\bf R}^n}")#text(" or ")#mi("{{\\bf C}^n}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra. One can view a vector-valued random variable ")#mi("{X = (X_1,\\ldots,X_n)}")#text(" as the joint random variable of its scalar component random variables ")#mi("{X_1,\\ldots,X_n}")#text(".")],
[#emph[#text("Matrix-valued random variables")]#text(" or ")#emph[#text("random matrices")]#text(", which take values in a space ")#mi("{M_{n \\times p}({\\bf R})}")#text(" or ")#mi("{M_{n \\times p}({\\bf C})}")#text(" of ")#mi("{n \\times p}")#text(" real or complex-valued matrices, again with the Borel ")#mi("{\\sigma}")#text("-algebra, where ")#mi("{n, p \\geq 1}")#text(" are integers (usually we will focus on the square case ")#mi("{n=p}")#text("). Note here that the shape ")#mi("{n \\times p}")#text(" of the matrix is deterministic; we will not consider in this course matrices whose shapes are themselves random variables. One can view a matrix-valued random variable ")#mi("{X = (X_{ij})_{1 \\leq i \\leq n; 1 \\leq j \\leq p}}")#text(" as the joint random variable of its scalar components ")#mi("{X_{ij}}")#text(". One can apply all the usual matrix operations (e.g. sum, product, determinant, trace, inverse, etc.) on random matrices to get a random variable with the appropriate range, though in some cases (e.g with inverse) one has to adjoin the undefined symbol ")#mi("{\\top}")#text(" as mentioned earlier.")],
[#link("http://en.wikipedia.org/wiki/Point_process")[#text("Point processes")]#text(", which take values in the space ")#mi("{{\\mathfrak N}(S)}")#text(" of subsets ")#mi("{A}")#text(" of a space ")#mi("{S}")#text(" (or more precisely, on the space of ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multisets")]#text(" of ")#mi("{S}")#text(", or even more precisely still as integer-valued locally finite measures on ")#mi("{S}")#text("), with the ")#mi("{\\sigma}")#text("-algebra being generated by the counting functions ")#tao-math("{\\left|A \\cap B\\right|}", block: false)#text(" for all precompact measurable sets ")#mi("{B}")#text(". Thus, if ")#mi("{X}")#text(" is a point process in ")#mi("{S}")#text(", and ")#mi("{B}")#text(" is a precompact measurable set, then the counting function ")#tao-math("{\\left|X \\cap B\\right|}", block: false)#text(" is a discrete random variable in ")#mi("{\\{0,1,2,\\ldots\\} \\cup \\{+\\infty\\}}")#text(". For us, the key example of a point process comes from taking the ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_matrix")[#text("spectrum")]#text(" ")#mi("{\\{ \\lambda_1,\\ldots,\\lambda_n\\}}")#text(" of eigenvalues (counting multiplicity) of a random ")#mi("{n \\times n}")#text(" matrix ")#mi("{M_n}")#text(". I discuss point processes further in ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("this previous blog post")]#text(". We will return to point processes (and define them more formally) later in this course.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" A pedantic point: strictly speaking, one has to include the range ")#mi("{R = (R,{\\mathcal R})}")#text(" of a random variable ")#mi("{X}")#text(" as part of that variable (thus one should really be referring to the pair ")#mi("{(X,R)}")#text(" rather than ")#mi("{X}")#text("). This leads to the annoying conclusion that, technically, boolean random variables are not integer-valued, integer-valued random variables are not real-valued, and real-valued random variables are not complex-valued. To avoid this issue we shall abuse notation very slightly and identify any random variable ")#mi("{X = (X,R)}")#text(" to any ")#emph[#text("coextension")]#text(" ")#mi("{(X,R^{\\prime})}")#text(" of that random variable to a larger range space ")#mi("{R^{\\prime} \\supset R}")#text(" (assuming of course that the ")#mi("{\\sigma}")#text("-algebras are compatible). Thus, for instance, a real-valued random variable which happens to only take a countable number of values will now be considered a discrete random variable also.")
]

#text("Given a random variable ")#mi("{X}")#text(" taking values in some range ")#mi("{R}")#text(", we define the ")#emph[#text("distribution")]#text(" ")#mi("{\\mu_X}")#text(" of ")#mi("{X}")#text(" to be the probability measure on the measurable space ")#mi("{R = (R,{\\mathcal R})}")#text(" defined by the formula ")#metadata(none) <tao-fbecb5a6981c3f47d968>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu_X(S) := {\\bf P}(X \\in S),")]]



#text(" thus ")#mi("{\\mu_X}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward")]#text(" ")#mi("{X_* {\\bf P}}")#text(" of the sample space probability measure ")#mi("{{\\bf P}}")#text(" by ")#mi("{X}")#text(". This is easily seen to be a probability measure, and is also a probabilistic concept. The probability measure ")#mi("{\\mu_X}")#text(" is also known as the ")#link("http://en.wikipedia.org/wiki/Law_(stochastic_processes)")[#text("law")]#text(" for ")#mi("{X}")#text(".")

#text("We write ")#mi("{X \\equiv Y}")#text(" for ")#mi("{\\mu_X=\\mu_Y}")#text("; we also abuse notation slightly by writing ")#mi("{X \\equiv \\mu_X}")#text(".")

#text("We have seen that every random variable generates a probability distribution ")#mi("{\\mu_X}")#text(". The converse is also true:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Creating a random variable with a specified distribution)")]#text(" ")#metadata(none) <tao-7134d90c9fc306b8f2b7>#text(" Let ")#mi("{\\mu}")#text(" be a probability measure on a measurable space ")#mi("{R = (R,{\\mathcal R})}")#text(". Then (after extending the sample space ")#mi("{\\Omega}")#text(" if necessary) there exists an ")#mi("{R}")#text("-valued random variable ")#mi("{X}")#text(" with distribution ")#mi("{\\mu}")#text(".")
]

#emph[#text("Proof:")]#text(" Extend ")#mi("{\\Omega}")#text(" to ")#mi("{\\Omega \\times R}")#text(" by using the obvious projection map ")#mi("{(\\omega,r) \\mapsto \\omega}")#text(" from ")#mi("{\\Omega \\times R}")#text(" back to ")#mi("{\\Omega}")#text(", and extending the probability measure ")#mi("{{\\bf P}}")#text(" on ")#mi("{\\Omega}")#text(" to the product measure ")#mi("{{\\bf P} \\times \\mu}")#text(" on ")#mi("{\\Omega \\times R}")#text(". The random variable ")#mi("{X(\\omega,r) := r}")#text(" then has distribution ")#mi("{\\mu}")#text(". ")#mi("\\Box")

#text("In the case of discrete random variables, ")#mi("{\\mu_X}")#text(" is the discrete probability measure ")#metadata(none) <tao-a251ce10406456c6446d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mu_X(S) = \\sum_{x \\in S} p_x")]]



#text(" where ")#mi("{p_x := {\\bf P}(X=x)}")#text(" are non-negative real numbers that add up to ")#mi("{1}")#text(". To put it another way, the distribution of a discrete random variable can be expressed as the sum of Dirac masses: ")#metadata(none) <tao-bed2e0e0a32b0a8802c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mu_X = \\sum_{x \\in R} p_x \\delta_x.")]]



#text(" We list some important examples of discrete distributions:")

#list(
[#link("http://en.wikipedia.org/wiki/Dirac_delta_function")[#text("Dirac distributions")]#text(" ")#mi("{\\delta_{x_0}}")#text(", in which ")#mi("{p_x = 1}")#text(" for ")#mi("{x=x_0}")#text(" and ")#mi("{p_x=0}")#text(" otherwise;")],
[#link("http://en.wikipedia.org/wiki/Uniform_distribution_(discrete)")[#text("discrete uniform distributions")]#text(", in which ")#mi("{R}")#text(" is finite and ")#tao-math("{p_x = 1/\\left|R\\right|}", block: false)#text(" for all ")#mi("{x \\in R}")#text(";")],
[#text("(Unsigned) ")#link("http://en.wikipedia.org/wiki/Bernoulli_distribution")[#text("Bernoulli distributions")]#text(", in which ")#mi("{R=\\{0,1\\}}")#text(", ")#mi("{p_1=p}")#text(", and ")#mi("{p_0=1-p}")#text(" for some parameter ")#mi("{0 \\leq p \\leq 1}")#text(";")],
[#text("The ")#emph[#text("signed Bernoulli distribution")]#text(", in which ")#mi("{R = \\{-1,+1\\}}")#text(" and ")#mi("{p_{+1}=p_{-1} = 1/2}")#text(";")],
[#emph[#text("Lazy signed Bernoulli distributions")]#text(", in which ")#mi("{R = \\{-1,0,+1\\}}")#text(", ")#mi("{p_{+1}=p_{-1}=\\mu/2}")#text(", and ")#mi("{p_0 = 1-\\mu}")#text(" for some parameter ")#mi("{0 \\leq \\mu \\leq 1}")#text(";")],
[#link("http://en.wikipedia.org/wiki/Geometric_distribution")[#text("Geometric distributions")]#text(", in which ")#mi("{R = \\{0,1,2,\\ldots\\}}")#text(" and ")#mi("{p_k = (1-p)^k p}")#text(" for all natural numbers ")#mi("{k}")#text(" and some parameter ")#mi("{0 \\leq p \\leq 1}")#text("; and")],
[#link("http://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson distributions")]#text(", in which ")#mi("{R = \\{0,1,2,\\ldots\\}}")#text(" and ")#mi("{p_k = \\frac{\\lambda^k e^{-\\lambda}}{k!}}")#text(" for all natural numbers ")#mi("{k}")#text(" and some parameter ")#mi("{\\lambda}")#text(".")]
)

#text("Now we turn to non-discrete random variables ")#mi("{X}")#text(" taking values in some range ")#mi("{R}")#text(". We say that a random variable is ")#emph[#text("continuous")]#text(" if ")#mi("{{\\bf P}(X=x)=0}")#text(" for all ")#mi("{x \\in R}")#text(" (here we assume that all points are measurable). If ")#mi("{R}")#text(" is already equipped with some reference measure ")#mi("{dm}")#text(" (e.g. Lebesgue measure in the case of scalar, vector, or matrix-valued random variables), we say that the random variable is ")#emph[#text("absolutely continuous")]#text(" if ")#mi("{{\\bf P}(X \\in S)=0}")#text(" for all null sets ")#mi("{S}")#text(" in ")#mi("{R}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Radon%E2%80%93Nikodym_theorem")[#text("Radon-Nikodym theorem")]#text(", we can thus find a non-negative, absolutely integrable function ")#mi("{f \\in L^1(R, dm)}")#text(" with ")#mi("{\\int_R f\\ dm = 1}")#text(" such that ")#metadata(none) <tao-7fab2b5d0539e8dce834>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mu_X(S) = \\int_S f\\ dm")]]



#text(" for all measurable sets ")#mi("{S \\subset R}")#text(". More succinctly, one has ")#metadata(none) <tao-5736fa339cb9a3b1b573>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("d\\mu_X = f\\ dm.")]]



#text(" We call ")#mi("{f}")#text(" the ")#emph[#text("probability density function")]#text(" of the probability distribution ")#mi("{\\mu_X}")#text(" (and thus, of the random variable ")#mi("{X}")#text("). As usual in measure theory, this function is only defined up to almost everywhere equivalence, but this will not cause any difficulties.")

#text("In the case of real-valued random variables ")#mi("{X}")#text(", the distribution ")#mi("{\\mu_X}")#text(" can also be described in terms of the ")#link("http://en.wikipedia.org/wiki/Cumulative_distribution_function")[#text("cumulative distribution function")]#text(" ")#metadata(none) <tao-3b151d348d3d215d211a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("F_X(x) := {\\bf P}(X \\leq x) = \\mu_X( (-\\infty,x] ).")]]



#text(" Indeed, ")#mi("{\\mu_X}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Lebesgue%E2%80%93Stieltjes_integration")[#text("Lebesgue-Stieltjes measure")]#text(" of ")#mi("{F_X}")#text(", and (in the absolutely continuous case) the derivative of ")#mi("{F_X}")#text(" exists and is equal to the probability density function almost everywhere. We will not use the cumulative distribution function much in this course, although we will be very interested in bounding tail events such as ")#mi("{{\\bf P}(X > \\lambda)}")#text(" or ")#mi("{{\\bf P}(X < \\lambda)}")#text(".")

#text("We give some basic examples of absolutely continuous scalar distributions:")

#list(
[#link("http://en.wikipedia.org/wiki/Uniform_distribution_(continuous)")[#text("uniform distributions")]#text(", in which ")#mi("{f := \\frac{1}{m(I)} 1_I}")#text(" for some subset ")#mi("{I}")#text(" of the reals or complexes of finite non-zero measure, e.g. an interval ")#mi("{[a,b]}")#text(" in the real line, or a disk in the complex plane.")],
[#text("The real ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution")]#text(" ")#mi("{N(\\mu,\\sigma^2) = N(\\mu,\\sigma^2)_{\\bf R}}")#text(" of mean ")#mi("{\\mu \\in {\\bf R}}")#text(" and variance ")#mi("{\\sigma^2 > 0}")#text(", given by the density function ")#mi("{f(x) := \\frac{1}{\\sqrt{2\\pi \\sigma^2}} \\exp( - (x-\\mu)^2/2\\sigma^2 )}")#text(" for ")#mi("{x \\in {\\bf R}}")#text(". We isolate in particular the ")#emph[#text("standard (real) normal distribution")]#text(" ")#mi("{N(0,1)}")#text(". Random variables with normal distributions are known as ")#emph[#text("gaussian random variables")]#text(".")],
[#text("The complex ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution")]#text(" ")#mi("{N(\\mu,\\sigma^2)_{\\bf C}}")#text(" of mean ")#mi("{\\mu \\in {\\bf C}}")#text(" and variance ")#mi("{\\sigma^2 > 0}")#text(", given by the density function ")#tao-math("{f(z) := \\frac{1}{\\pi \\sigma^2} \\exp( - \\left|z-\\mu\\right|^2/\\sigma^2 )}", block: false)#text(". Again, we isolate the standard complex normal distribution ")#mi("{N(0,1)_{\\bf C}}")#text(".")]
)

#text("Later on, we will encounter several more scalar distributions of relevance to random matrix theory, such as the semicircular law or Marcenko-Pastur law. We will also of course encounter many matrix distributions (also known as ")#emph[#text("matrix ensembles")]#text(") as well as point processes.")

#text("Given an unsigned random variable ")#mi("{X}")#text(" (i.e. a random variable taking values in ")#mi("{[0,+\\infty]}")#text("), one can define the ")#link("http://en.wikipedia.org/wiki/Expected_value")[#text("expectation")]#text(" or ")#emph[#text("mean")]#text(" ")#mi("{{\\bf E} X}")#text(" as the unsigned integral ")#metadata(none) <tao-6e20a742343bae1f14d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\bf E} X := \\int_0^\\infty x\\ d\\mu_X(x),")]]



#text(" which by the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(" can also be rewritten as ")#metadata(none) <tao-75cff5fbfd6f3fdffc0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\bf E} X = \\int_0^\\infty {\\bf P}(X \\geq \\lambda)\\ d\\lambda.")]]



#text(" The expectation of an unsigned variable lies in also ")#mi("{[0,+\\infty]}")#text(". If ")#mi("{X}")#text(" is a scalar random variable (which is allowed to take the value ")#mi("{\\infty}")#text(") for which ")#tao-math("{{\\bf E}\\left|X\\right| < \\infty}", block: false)#text(", we say that ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Absolutely_integrable")[#text("absolutely integrable")]#text(", in which case we can define its expectation as ")#metadata(none) <tao-0b5b105fd54a39ffbb98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("{\\bf E} X := \\int_{\\bf R} x\\ d\\mu_X(x)")]]



#text(" in the real case, or ")#metadata(none) <tao-3a69ea1ff6bb5ef4aa78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("{\\bf E} X := \\int_{\\bf C} z\\ d\\mu_X(z)")]]



#text(" in the complex case. Similarly for vector-valued random variables (note that in finite dimensions, all norms are equivalent, so the precise choice of norm used to define ")#tao-math("{\\left|X\\right|}", block: false)#text(" is not relevant here). If ")#mi("{X = (X_1,\\ldots,X_n)}")#text(" is a vector-valued random variable, then ")#mi("{X}")#text(" is absolutely integrable if and only if the components ")#mi("{X_i}")#text(" are all absolutely integrable, in which case one has ")#mi("{{\\bf E} X = ({\\bf E} X_1, \\ldots, {\\bf E} X_n)}")#text(".")

#text("A deterministic scalar random variable ")#mi("{c}")#text(" is its own mean. An indicator function ")#mi("{{\\bf I}(E)}")#text(" has mean ")#mi("{\\mathop{\\bf P}(E)}")#text(". An unsigned Bernoulli variable (as defined previously) has mean ")#mi("{p}")#text(", while a signed or lazy signed Bernoulli variable has mean ")#mi("{0}")#text(". A real or complex gaussian variable with distribution ")#mi("{N(\\mu,\\sigma^2)}")#text(" has mean ")#mi("{\\mu}")#text(". A Poisson random variable has mean ")#mi("{\\lambda}")#text("; a geometric random variable has mean ")#mi("{p}")#text(". A uniformly distributed variable on an interval ")#mi("{[a,b] \\subset {\\bf R}}")#text(" has mean ")#mi("{\\frac{a+b}{2}}")#text(".")

#text("A fundamentally important property of expectation is that it is linear: if ")#mi("{X_1,\\ldots,X_k}")#text(" are absolutely integrable scalar random variables and ")#mi("{c_1,\\ldots,c_k}")#text(" are finite scalars, then ")#mi("{c_1 X_1 + \\ldots + c_k X_k}")#text(" is also absolutely integrable and ")#metadata(none) <tao-7f2fe580edb35154041f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("{\\bf E} c_1 X_1 + \\ldots + c_k X_k = c_1 {\\bf E} X_1 + \\ldots + c_k {\\bf E} X_k.")]]



#text(" By the Fubini-Tonelli theorem, the same result also applies to infinite sums ")#mi("{\\sum_{i=1}^\\infty c_i X_i}")#text(" provided that ")#tao-math("{\\sum_{i=1}^\\infty |c_i| {\\bf E}\\left|X_i\\right|}", block: false)#text(" is finite.")

#text("We will use ")#emph[#text("linearity of expectation")]#text(" so frequently in the sequel that we will often omit an explicit reference to it when it is being used. It is important to note that linearity of expectation requires no assumptions of independence or dependence amongst the individual random variables ")#mi("{X_i}")#text("; this is what makes this property of expectation so powerful.")

#text("In the unsigned (or real absolutely integrable) case, expectation is also monotone: if ")#mi("{X \\leq Y}")#text(" is true for some unsigned or real absolutely integrable ")#mi("{X, Y}")#text(", then ")#mi("{{\\bf E} X \\leq {\\bf E} Y}")#text(". Again, we will usually use this basic property without explicit mentioning it in the sequel.")

#text("For an unsigned random variable, we have the obvious but very useful ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov inequality")]#text(" ")#metadata(none) <tao-43cedaa98924112f2f89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("{\\bf P}(X \\geq \\lambda) \\leq \\frac{1}{\\lambda} {\\bf E} X")]]



#text(" for any ")#mi("{\\lambda > 0}")#text(", as can be seen by taking expectations of the inequality ")#mi("{\\lambda {\\bf I}(X \\geq \\lambda) \\leq X}")#text(". For signed random variables, Markov’s inequality becomes ")#metadata(none) <tao-0db95c924f20e0e0b525>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("{\\bf P}(\\left|X\\right| \\geq \\lambda) \\leq \\frac{1}{\\lambda} {\\bf E} \\left|X\\right|", block: true)]]





#text("Another fact related to Markov’s inequality is that if ")#mi("{X}")#text(" is an unsigned or real absolutely integrable random variable, then ")#mi("{X \\geq {\\bf E} X}")#text(" must hold with positive probability, and also ")#mi("{X \\leq {\\bf E} X}")#text(" must also hold with positive probability. Use of these facts or ")#link(<tao-43cedaa98924112f2f89>)[#text("(13)")]#text(", ")#link(<tao-0db95c924f20e0e0b525>)[#text("(14)")]#text(", combined with monotonicity and linearity of expectation, is collectively referred to as the ")#link("http://en.wikipedia.org/wiki/Second_moment_method#First_moment_method")[#text("first moment method")]#text(". This method tends to be particularly easy to use (as one does not need to understand dependence or independence), but by the same token often gives sub-optimal results (as one is not exploiting any independence in the system).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Borel-Cantelli lemma)")]#text(" Let ")#mi("{E_1,E_2,\\ldots}")#text(" be a sequence of events such that ")#mi("{\\sum_i {\\bf P}(E_i) < \\infty}")#text(". Show that almost surely, at most finitely many of the events ")#mi("{E_i}")#text(" occur at once. State and prove a result to the effect that the condition ")#mi("{\\sum_i {\\bf P}(E_i) < \\infty}")#text(" cannot be weakened.")
]

#text("If ")#mi("{X}")#text(" is an absolutely integrable or unsigned scalar random variable, and ")#mi("{F}")#text(" is a measurable function from the scalars to the unsigned extended reals ")#mi("{[0,+\\infty]}")#text(", then one has the change of variables formula ")#metadata(none) <tao-8c0fe4c9870dd85ff494>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\bf E} F(X) = \\int_{\\bf R} F(x)\\ d\\mu_X(x)")]]



#text(" when ")#mi("{X}")#text(" is real-valued and ")#metadata(none) <tao-3340c1931312bc23964c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("{\\bf E} F(X) = \\int_{\\bf C} F(z)\\ d\\mu_X(z)")]]



#text(" when ")#mi("{X}")#text(" is complex-valued. The same formula applies to signed or complex ")#mi("{F}")#text(" if it is known that ")#tao-math("{\\left|F(X)\\right|}", block: false)#text(" is absolutely integrable. Important examples of expressions such as ")#mi("{{\\bf E} F(X)}")#text(" are ")#emph[#text("moments")]#text(" ")#metadata(none) <tao-690a8d18f75dfaa79dd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("{\\bf E} \\left|X\\right|^k", block: true)]]



#text(" for various ")#mi("{k \\geq 1}")#text(" (particularly ")#mi("{k=1,2,4}")#text("), ")#emph[#text("exponential moments")]#text(" ")#metadata(none) <tao-acbd196ae5cb1f3cf478>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("{\\bf E} e^{tX}")]]



#text(" for real ")#mi("{t}")#text(", ")#mi("{X}")#text(", and ")#emph[#text("Fourier moments")]#text(" (or the ")#link("http://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(") ")#metadata(none) <tao-9588bb66985e232246e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("{\\bf E} e^{itX}")]]



#text(" for real ")#mi("{t, X}")#text(", or ")#metadata(none) <tao-6d8a9edcd5bf1e5563b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("{\\bf E} e^{it\\cdot X}")]]



#text(" for complex or vector-valued ")#mi("{t, X}")#text(", where ")#mi("{\\cdot}")#text(" denotes a real inner product. We shall also occasionally encounter the ")#emph[#text("resolvents")]#text(" ")#metadata(none) <tao-1fe74cd1a815bbf81649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("{\\bf E} \\frac{1}{X-z}")]]



#text(" for complex ")#mi("{z}")#text(", though one has to be careful now with the absolute convergence of this random variable. Similarly, we shall also occasionally encounter ")#emph[#text("negative moments")]#text(" ")#tao-math("{{\\bf E} \\left|X\\right|^{-k}}", block: false)#text(" of ")#mi("{X}")#text(", particularly for ")#mi("{k=2}")#text(". We also sometimes use the ")#emph[#text("zeroth moment")]#text(" ")#tao-math("{{\\bf E} \\left|X\\right|^0 = {\\bf P}(X \\neq 0)}", block: false)#text(", where we take the somewhat unusual convention that ")#mi("{x^0 := \\lim_{k \\rightarrow 0^+} x^k}")#text(" for non-negative ")#mi("{x}")#text(", thus ")#mi("{x^0 := 1}")#text(" for ")#mi("{x>0}")#text(" and ")#mi("{0^0 := 0}")#text(". Thus, for instance, the union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(1)")]#text(" can be rewritten (for finitely many ")#mi("{i}")#text(", at least) as ")#metadata(none) <tao-16af8f6d836d4f893368>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("{\\bf E} \\left|\\sum_i c_i X_i\\right|^0 \\leq \\sum_i \\left|c_i\\right|^0 {\\bf E} \\left|X_i\\right|^0", block: true)]]



#text(" for any scalar random variables ")#mi("{X_i}")#text(" and scalars ")#mi("{c_i}")#text(" (compare with ")#link(<tao-7f2fe580edb35154041f>)[#text("(12)")]#text(").")

#text("It will be important to know if a scalar random variable ")#mi("{X}")#text(" is “usually bounded”. We have several ways of quantifying this, in decreasing order of strength:")

#list(
[#mi("{X}")#text(" is ")#emph[#text("surely bounded")]#text(" if there exists an ")#mi("{M>0}")#text(" such that ")#tao-math("{\\left|X\\right| \\leq M}", block: false)#text(" surely.")],
[#mi("{X}")#text(" is ")#emph[#text("almost surely bounded")]#text(" if there exists an ")#mi("{M>0}")#text(" such that ")#tao-math("{\\left|X\\right| \\leq M}", block: false)#text(" almost surely.")],
[#mi("{X}")#text(" is ")#emph[#text("subgaussian")]#text(" if there exist ")#mi("{C, c > 0}")#text(" such that ")#tao-math("{{\\bf P}(\\left|X\\right| \\geq \\lambda) \\leq C \\exp( - c \\lambda^2 )}", block: false)#text(" for all ")#mi("{\\lambda > 0}")#text(".")],
[#mi("{X}")#text(" has ")#emph[#text("sub-exponential tail")]#text(" if there exist ")#mi("{C, c, a > 0}")#text(" such that ")#tao-math("{{\\bf P}(\\left|X\\right| \\geq \\lambda) \\leq C \\exp( - c \\lambda^a )}", block: false)#text(" for all ")#mi("{\\lambda > 0}")#text(".")],
[#mi("{X}")#text(" has ")#emph[#text("finite ")#mi("{k^{th}}")#text(" moment")]#text(" for some ")#mi("{k \\geq 1}")#text(" if there exists ")#mi("{C}")#text(" such that ")#tao-math("{{\\bf E}\\left|X\\right|^k \\leq C}", block: false)#text(".")],
[#mi("{X}")#text(" is ")#emph[#text("absolutely integrable")]#text(" if ")#tao-math("{{\\bf E}\\left|X\\right| < \\infty}", block: false)#text(".")],
[#mi("{X}")#text(" is ")#emph[#text("almost surely finite")]#text(" if ")#tao-math("{\\left|X\\right| < \\infty}", block: false)#text(" almost surely.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that these properties genuinely are in decreasing order of strength, i.e. that each property on the list implies the next.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that each of these properties are closed under vector space operations, thus for instance if ")#mi("{X, Y}")#text(" have sub-exponential tail, show that ")#mi("{X+Y}")#text(" and ")#mi("{cX}")#text(" also have sub-exponential tail for any scalar ")#mi("{c}")#text(".")
]

#text("The various species of Bernoulli random variable are surely bounded, and any random variable which is uniformly distributed in a bounded set is almost surely bounded. Gaussians are of course subgaussian, while the Poisson and geometric distributions merely have sub-exponential tail. ")#link("http://en.wikipedia.org/wiki/Cauchy_distribution")[#text("Cauchy distributions")]#text(" are typical examples of ")#emph[#text("heavy-tailed")]#text(" distributions which are almost surely finite, but do not have all moments finite (indeed, the Cauchy distribution does not even have finite first moment).")

#text("If we have a family of scalar random variables ")#mi("{X_\\alpha}")#text(" depending on a parameter ")#mi("{\\alpha}")#text(", we say that the ")#mi("{X_\\alpha}")#text(" are uniformly surely bounded (resp. uniformly almost surely bounded, uniformly subgaussian, have uniform sub-exponential tails, or uniformly bounded ")#mi("{k^{th}}")#text(" moment) if the relevant parameters ")#mi("{M, C, c, a}")#text(" in the above definitions can be chosen to be independent of ")#mi("{\\alpha}")#text(".")

#text("Fix ")#mi("{k \\geq 1}")#text(". If ")#mi("{X}")#text(" has finite ")#mi("{k^{th}}")#text(" moment, say ")#tao-math("{{\\bf E}\\left|X\\right|^k \\leq C}", block: false)#text(", then from Markov’s inequality ")#link(<tao-0db95c924f20e0e0b525>)[#text("(14)")]#text(" one has ")#metadata(none) <tao-3dfb34e1efa916f1b293>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("{\\bf P}(\\left|X\\right| \\geq \\lambda) \\leq C \\lambda^{-k},", block: true)]]



#text(" thus we see that the higher the moments that we control, the faster the tail decay is. From the dominated convergence theorem we also have the variant ")#metadata(none) <tao-2db681579fbe43e8e0d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\lim_{\\lambda \\rightarrow \\infty} \\lambda^k {\\bf P}(\\left|X\\right| \\geq \\lambda) = 0.", block: true)]]



#text(" However, this result is ")#emph[#text("qualitative")]#text(" or ")#emph[#text("ineffective")]#text(" rather than ")#emph[#text("quantitative")]#text(" because it provides no ")#emph[#text("rate")]#text(" of convergence of ")#tao-math("{\\lambda^k {\\bf P}(\\left|X\\right| \\geq \\lambda)}", block: false)#text(" to zero. Indeed, it is easy to construct a family ")#mi("{X_\\alpha}")#text(" of random variables of uniformly bounded ")#mi("{k^{th}}")#text(" moment, but for which the quantities ")#tao-math("{\\lambda^k {\\bf P}(\\left|X_\\alpha\\right| \\geq \\lambda)}", block: false)#text(" do not converge uniformly to zero (e.g. take ")#mi("{X_m}")#text(" to be ")#mi("{m}")#text(" times the indicator of an event of probability ")#mi("{m^{-k}}")#text(" for ")#mi("{m=1,2,\\ldots}")#text("). Because of this issue, we will often have to strengthen the property of having a uniformly bounded moment, to that of obtaining a uniformly quantitative control on the decay in ")#link(<tao-2db681579fbe43e8e0d7>)[#text("(24)")]#text(" for a family ")#mi("{X_\\alpha}")#text(" of random variables; we will see examples of this in later lectures. However, this technicality does not arise in the important model case of ")#emph[#text("identically distributed")]#text(" random variables, since in this case we trivially have uniformity in the decay rate of ")#link(<tao-2db681579fbe43e8e0d7>)[#text("(24)")]#text(".")

#text("We observe some consequences of ")#link(<tao-3dfb34e1efa916f1b293>)[#text("(23)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" Let ")#mi("{X = X_n}")#text(" be a scalar random variable depending on a parameter ")#mi("{n}")#text(".")

#list(
[#text("If ")#tao-math("{\\left|X_n\\right|}", block: false)#text(" has uniformly bounded expectation, then for any ")#mi("{\\epsilon > 0}")#text(" independent of ")#mi("{n}")#text(", we have ")#tao-math("{\\left|X_n\\right| = O(n^\\epsilon)}", block: false)#text(" with high probability.")],
[#text("If ")#mi("{X_n}")#text(" has uniformly bounded ")#mi("{k^{th}}")#text(" moment, then for any ")#mi("{A > 0}")#text(", we have ")#tao-math("{\\left|X_n\\right| = O(n^{A/k})}", block: false)#text(" with probability ")#mi("{1 - O( n^{-A} )}")#text(".")],
[#text("If ")#mi("{X_n}")#text(" has uniform sub-exponential tails, then we have ")#tao-math("{\\left|X_n\\right| = O(\\log^{O(1)} n)}", block: false)#text(" with overwhelming probability.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that a real-valued random variable ")#mi("{X}")#text(" is subgaussian if and only if there exist ")#mi("{C>0}")#text(" such that ")#mi("{{\\bf E} e^{t X} \\leq C\\exp( C t^2 )}")#text(" for all real ")#mi("{t}")#text(", and if and only if there exists ")#mi("{C > 0}")#text(" such that ")#tao-math("{{\\bf E} \\left|X\\right|^k \\leq (Ck)^{k/2}}", block: false)#text(" for all ")#mi("{k \\geq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that a real-valued random variable ")#mi("{X}")#text(" has subexponential tails if and only if there exist ")#mi("{C>0}")#text(" such that ")#tao-math("{{\\bf E} \\left|X\\right|^k \\leq \\exp( C k^C )}", block: false)#text(" for all positive integers ")#mi("{k}")#text(".")
]

#text("Once the second moment of a scalar random variable is finite, one can define the ")#link("http://en.wikipedia.org/wiki/Variance")[#text("variance")]#text(" ")#metadata(none) <tao-94f7da29dca3eab203ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("{\\bf Var}(X) := {\\bf E} \\left|X-{\\bf E}(X)\\right|^2.", block: true)]]



#text(" From Markov’s inequality we thus have ")#link("http://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]#text(" ")#metadata(none) <tao-4dc5ee0d2ddd582fe968>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("{\\bf P}(\\left|X - {\\bf E}(X)\\right| \\geq \\lambda) \\leq \\frac{{\\bf Var}(X)}{\\lambda^2}.", block: true)]]



#text(" Upper bounds on ")#tao-math("{{\\bf P}(\\left|X - {\\bf E}(X)\\right| \\geq \\lambda)}", block: false)#text(" for ")#mi("{\\lambda}")#text(" large are known as ")#link("http://en.wikipedia.org/wiki/Large_deviations_theory")[#text("large deviation inequality")]#text(". Chebyshev’s inequality gives a simple but still useful large deviation inequality, which becomes useful once ")#mi("{\\lambda}")#text(" exceeds the ")#link("http://en.wikipedia.org/wiki/Standard_deviation")[#text("standard deviation")]#text(" ")#mi("{{\\bf Var}(X)^{1/2}}")#text(" of the random variable. The use of Chebyshev’s inequality, combined with a computation of variances, is known as the ")#link("http://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment method")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Scaling of mean and variance)")]#text(" If ")#mi("{X}")#text(" is a scalar random variable of finite mean and variance, and ")#mi("{a, b}")#text(" are scalars, show that ")#mi("{{\\bf E}(a+bX) = a + b {\\bf E}(X)}")#text(" and ")#tao-math("{{\\bf Var}(a+bX) = \\left|b\\right|^2 {\\bf Var}(X)}", block: false)#text(". In particular, if ")#mi("{X}")#text(" has non-zero variance, then there exist scalars ")#mi("{a,b}")#text(" such that ")#mi("{a+bX}")#text(" has mean zero and variance one.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" We say that a real number ")#mi("{{\\bf M}(X)}")#text(" is a ")#emph[#text("median")]#text(" of a real-valued random variable ")#mi("{X}")#text(" if ")#mi("{{\\bf P}(X > {\\bf M}(X)), {\\bf P}(X < {\\bf M}(X)) \\leq 1/2}")#text(".")

#list(
[#text("Show that a median always exists, and if ")#mi("{X}")#text(" is absolutely continuous with strictly positive density function, then the median is unique.")],
[#text("If ")#mi("{X}")#text(" has finite second moment, show that ")#mi("{{\\bf M}(X) = {\\bf E}(X) + O( {\\bf Var}(X)^{1/2} )}")#text(" for any median ")#mi("{{\\bf M}(X)}")#text(".")]
)
]

#text("If ")#mi("{X}")#text(" is subgaussian (or has sub-exponential tails with exponent ")#mi("{a>1}")#text("), then from dominated convergence we have the Taylor expansion ")#metadata(none) <tao-36ad584e43825c39b4a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("{\\bf E} e^{tX} =1+ \\sum_{k=1}^\\infty \\frac{t^k}{k!} {\\bf E} X^k")]]



#text(" for any real or complex ")#mi("{t}")#text(", thus relating the exponential and Fourier moments with the ")#mi("{k^{th}}")#text(" moments.")

#heading(level: 1)[#strong[#text(" — 3. Independence — ")]]

#text("When studying the behaviour of a single random variable ")#mi("{X}")#text(", the distribution ")#mi("{\\mu_X}")#text(" captures all the probabilistic information one wants to know about ")#mi("{X}")#text(". The following exercise is one way of making this statement rigorous:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{X}")#text(", ")#mi("{X^{\\prime}}")#text(" be random variables (on sample spaces ")#mi("{\\Omega,\\Omega^{\\prime}}")#text(" respectively) taking values in a range ")#mi("{R}")#text(", such that ")#mi("{X \\equiv X^{\\prime}}")#text(". Show that after extending the spaces ")#mi("{\\Omega, \\Omega^{\\prime}}")#text(", the two random variables ")#mi("{X, X^{\\prime}}")#text(" are isomorphic, in the sense that there exists a probability space isomorphism ")#mi("{\\pi: \\Omega \\rightarrow \\Omega^{\\prime}}")#text(" (i.e. an invertible extension map whose inverse is also an extension map) such that ")#mi("{X = X^{\\prime} \\circ \\pi}")#text(".")
]

#text("However, once one studies ")#emph[#text("families")]#text(" ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" of random variables ")#mi("{X_\\alpha}")#text(" taking values in measurable spaces ")#mi("{R_\\alpha}")#text(" (on a single sample space ")#mi("{\\Omega}")#text("), the distribution of the individual variables ")#mi("{X_\\alpha}")#text(" are no longer sufficient to describe all the probabilistic statistics of interest; the ")#emph[#text("joint distribution")]#text(" of the variables (i.e. the distribution of the tuple ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(", which can be viewed as a single random variable taking values in the product measurable space ")#mi("{\\prod_{\\alpha \\in A} R_\\alpha}")#text(") also becomes relevant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Let ")#mi("{(X_1, X_2)}")#text(" be drawn uniformly at random from the set ")#mi("{\\{ (-1,-1), (-1,+1), (+1,-1), (+1,+1) \\}}")#text(". Then the random variables ")#mi("{X_1}")#text(", ")#mi("{X_2}")#text(", and ")#mi("{-X_1}")#text(" all individually have the same distribution, namely the signed Bernoulli distribution. However the pairs ")#mi("{(X_1,X_2)}")#text(", ")#mi("{(X_1,X_1)}")#text(", and ")#mi("{(X_1,-X_1)}")#text(" all have different joint distributions: the first pair, by definition, is uniformly distributed in ")#mi("{\\{ (-1,-1), (-1,+1), (+1,-1), (+1,+1) \\}}")#text(", while the second pair is uniformly distributed in ")#mi("{\\{(-1,-1),(+1,+1)\\}}")#text(", and the third pair is uniformly distributed in ")#mi("{\\{ (-1,+1), (+1,-1)\\}}")#text(". Thus, for instance, if one is told that ")#mi("{X, Y}")#text(" are two random variables with the Bernoulli distribution, and asked to compute the probability that ")#mi("{X=Y}")#text(", there is insufficient information to solve the problem; if ")#mi("{(X,Y)}")#text(" were distributed as ")#mi("{(X_1,X_2)}")#text(", then the probability would be ")#mi("{1/2}")#text(", while if ")#mi("{(X,Y)}")#text(" were distributed as ")#mi("{(X_1,X_1)}")#text(", the probability would be ")#mi("{1}")#text(", and if ")#mi("{(X,Y)}")#text(" were distributed as ")#mi("{(X_1,-X_1)}")#text(", the probability would be ")#mi("{0}")#text(". Thus one sees that one needs the joint distribution, and not just the individual distributions, to obtain a unique answer to the question.")
]

#text("There is however an important special class of families of random variables in which the joint distribution is determined by the individual distributions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Joint independence)")]#text(" A family ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" of random variables (which may be finite, countably infinite, or uncountably infinite) is said to be ")#emph[#text("jointly independent")]#text(" if the distribution of ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" is the product measure of the distribution of the individual ")#mi("{X_\\alpha}")#text(".")

#text("A family ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" is said to be ")#emph[#text("pairwise independent")]#text(" if the pairs ")#mi("{(X_\\alpha,X_\\beta)}")#text(" are jointly independent for all distinct ")#mi("{\\alpha,\\beta \\in A}")#text(". More generally, ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" is said to be ")#emph[#mi("{k}")#text("-wise independent")]#text(" if ")#mi("{(X_{\\alpha_1},\\ldots,X_{\\alpha_{k^{\\prime}}})}")#text(" are jointly independent for all ")#mi("{1 \\leq k^{\\prime} \\leq k}")#text(" and all distinct ")#mi("{\\alpha_1,\\ldots,\\alpha_{k^{\\prime}} \\in A}")#text(".")

#text("We also say that ")#mi("{X}")#text(" is ")#emph[#text("independent")]#text(" of ")#mi("{Y}")#text(" if ")#mi("{(X,Y)}")#text(" are jointly independent.")

#text("A family of events ")#mi("{(E_\\alpha)_{\\alpha \\in A}}")#text(" is said to be jointly independent if their indicators ")#mi("{({\\bf I}(E_\\alpha))_{\\alpha \\in A}}")#text(" are jointly independent. Similarly for pairwise independence and ")#mi("{k}")#text("-wise independence.")
]

#text("From the theory of product measure, we have the following equivalent formulation of joint independence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" be a family of random variables, with each ")#mi("{X_\\alpha}")#text(" taking values in a measurable space ")#mi("{R_\\alpha}")#text(".")

#list(
[#text("Show that the ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" are jointly independent if and only if for every collection of distinct elements ")#mi("{\\alpha_1,\\ldots,\\alpha_{k^{\\prime}}}")#text(" of ")#mi("{A}")#text(", and all measurable subsets ")#mi("{E_i \\subset R_{\\alpha_i}}")#text(" for ")#mi("{1 \\leq i \\leq k^{\\prime}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( X_{\\alpha_i} \\in E_i \\text{ for all } 1 \\leq i \\leq k^{\\prime} ) = \\prod_{i=1}^{k^{\\prime}} \\mathop{\\bf P}( X_{\\alpha_i} \\in E_i ).")]]],
[#text("Show that the necessary and sufficient condition ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" being ")#mi("{k}")#text("-wise independent is the same, except that ")#mi("{k^{\\prime}}")#text(" is constrained to be at most ")#mi("{k}")#text(".")]
)

#text("In particular, a finite family ")#mi("{(X_1,\\ldots,X_k)}")#text(" of random variables ")#mi("{X_i}")#text(", ")#mi("{1 \\leq i \\leq k}")#text(" taking values in measurable spaces ")#mi("{R_i}")#text(" are jointly independent if and only if")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( X_i \\in E_i \\text{ for all } 1 \\leq i \\leq k ) = \\prod_{i=1}^k \\mathop{\\bf P}( X_i \\in E_i )")]]

#text("for all measurable ")#mi("{E_i \\subset R_i}")#text(".")

#text("If the ")#mi("{X_\\alpha}")#text(" are discrete random variables, one can take the ")#mi("{E_i}")#text(" to be singleton sets in the above discussion.")
]

#text("From the above exercise we see that joint independence implies ")#mi("{k}")#text("-wise independence for any ")#mi("{k}")#text(", and that joint independence is preserved under permuting, relabeling, or eliminating some or all of the ")#mi("{X_\\alpha}")#text(". A single random variable is automatically jointly independent, and so ")#mi("{1}")#text("-wise independence is vacuously true; pairwise independence is the first nontrivial notion of independence in this hierarchy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Let ")#mi("{{\\bf F}_2}")#text(" be the field of two elements, let ")#mi("{V \\subset {\\bf F}_2^3}")#text(" be the subspace of triples ")#mi("{(x_1,x_2,x_3) \\in {\\bf F}_2^3}")#text(" with ")#mi("{x_1+x_2+x_3=0}")#text(", and let ")#mi("{(X_1,X_2,X_3)}")#text(" be drawn uniformly at random from ")#mi("{V}")#text(". Then ")#mi("{(X_1,X_2,X_3)}")#text(" are pairwise independent, but not jointly independent. In particular, ")#mi("{X_3}")#text(" is independent of each of ")#mi("{X_1,X_2}")#text(" separately, but is not independent of ")#mi("{(X_1,X_2)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" This exercise generalises the above example. Let ")#mi("{{\\bf F}}")#text(" be a finite field, and let ")#mi("{V}")#text(" be a subspace of ")#mi("{{\\bf F}^n}")#text(" for some finite ")#mi("{n}")#text(". Let ")#mi("{(X_1,\\ldots,X_n)}")#text(" be drawn uniformly at random from ")#mi("{V}")#text(". Suppose that ")#mi("{V}")#text(" is not contained in any coordinate hyperplane in ")#mi("{{\\bf F}^n}")#text(".")

#list(
[#text("Show that each ")#mi("{X_i}")#text(", ")#mi("{1 \\leq i \\leq n}")#text(" is uniformly distributed in ")#mi("{{\\bf F}}")#text(".")],
[#text("Show that for any ")#mi("{k \\geq 2}")#text(", that ")#mi("{(X_1,\\ldots,X_n)}")#text(" is ")#mi("{k}")#text("-wise independent if and only if ")#mi("{V}")#text(" is not contained in any hyperplane which is definable using at most ")#mi("{k}")#text(" of the coordinate variables.")],
[#text("Show that ")#mi("{(X_1,\\ldots,X_n)}")#text(" is jointly independent if and only if ")#mi("{V = {\\bf F}^n}")#text(".")]
)

#text("Informally, we thus see that imposing constraints between ")#mi("{k}")#text(" variables at a time can destroy ")#mi("{k}")#text("-wise independence, while leaving lower-order independence unaffected.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{V \\subset {\\bf F}_2^3}")#text(" be the subspace of triples ")#mi("{(x_1,x_2,x_3) \\in {\\bf F}_2^3}")#text(" with ")#mi("{x_1+x_2=0}")#text(", and let ")#mi("{(X_1,X_2,X_3)}")#text(" be drawn uniformly at random from ")#mi("{V}")#text(". Then ")#mi("{X_3}")#text(" is independent of ")#mi("{(X_1,X_2)}")#text(" (and in particular, is independent of ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(" separately), but ")#mi("{X_1, X_2}")#text(" are not independent of each other.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-bc517786c8d616be859c>#text(" We say that one random variable ")#mi("{Y}")#text(" (with values in ")#mi("{R_Y}")#text(") is ")#emph[#text("determined")]#text(" by another random variable ")#mi("{X}")#text(" (with values in ")#mi("{R_X}")#text(") if there exists a (deterministic) function ")#mi("{f: R_X \\rightarrow R_Y}")#text(" such that ")#mi("{Y=f(X)}")#text(" is surely true (i.e. ")#mi("{Y(\\omega) = f(X(\\omega))}")#text(" for all ")#mi("{\\omega \\in \\Omega}")#text("). Show that if ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" is a family of jointly independent random variables, and ")#mi("{(Y_\\beta)_{\\beta \\in B}}")#text(" is a family such that each ")#mi("{Y_\\beta}")#text(" is determined by some subfamily ")#mi("{(X_\\alpha)_{\\alpha \\in A_\\beta}}")#text(" of the ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(", with the ")#mi("{A_\\beta}")#text(" disjoint as ")#mi("{\\beta}")#text(" varies, then the ")#mi("{(Y_\\beta)_{\\beta \\in B}}")#text(" are jointly independent also.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Determinism vs. independence)")]#text(" Let ")#mi("{X, Y}")#text(" be random variables. Show that ")#mi("{Y}")#text(" is deterministic if and only if it is simultaneously determined by ")#mi("{X}")#text(", and independent of ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that a complex random variable ")#mi("{X}")#text(" is a complex gaussian random variable (i.e. its distribution is a complex normal distribution) if and only if its real and imaginary parts ")#mi("{Re(X), Im(X)}")#text(" are independent real gaussian random variables with the same variance. In particular, the variance of ")#mi("{Re(X)}")#text(" and ")#mi("{Im(X)}")#text(" will be half of variance of ")#mi("{X}")#text(".")
]

#text("One key advantage of working with jointly independent random variables and events is that one can compute various probabilistic quantities quite easily. We give some key examples below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" If ")#mi("{E_1,\\ldots,E_k}")#text(" are jointly independent events, show that ")#metadata(none) <tao-df9d69d826562955b956>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("{\\bf P}( \\bigwedge_{i=1}^k E_i ) = \\prod_{i=1}^k {\\bf P}(E_i)")]]



#text(" and ")#metadata(none) <tao-103168a0af0b07dcc730>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("{\\bf P}( \\bigvee_{i=1}^k E_i ) = 1-\\prod_{i=1}^k (1-{\\bf P}(E_i))")]]



#text(" Show that the converse statement (i.e. that ")#link(<tao-df9d69d826562955b956>)[#text("(28)")]#text(" and ")#link(<tao-103168a0af0b07dcc730>)[#text("(29)")]#text(" imply joint independence) is true for ")#mi("{k=2}")#text(", but fails for higher ")#mi("{k}")#text(". Can one find a correct replacement for this converse for higher ")#mi("{k}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-f325f48ac1d7b4532270>

#list(
[#text("If ")#mi("{X_1,\\ldots,X_k}")#text(" are jointly independent random variables taking values in ")#mi("{[0,+\\infty]}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\prod_{i=1}^k X_i = \\prod_{i=1}^k \\mathop{\\bf E} X_i.")]]],
[#text("If ")#mi("{X_1,\\ldots,X_k}")#text(" are jointly independent absolutely integrable scalar random variables, show that ")#mi("{\\prod_{i=1}^k X_i}")#text(" is absolutely integrable, and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\prod_{i=1}^k X_i = \\prod_{i=1}^k \\mathop{\\bf E} X_i.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The above exercise combines well with Exercise ")#link(<tao-bc517786c8d616be859c>)[#text("12")]#text(". For instance, if ")#mi("{X_1,\\ldots,X_k}")#text(" are jointly independent subgaussian variables, then from Exercises ")#link(<tao-bc517786c8d616be859c>)[#text("12")]#text(", ")#link(<tao-f325f48ac1d7b4532270>)[#text("16")]#text(" we see that ")#metadata(none) <tao-0b1759a5f76eea6cea79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\mathop{\\bf E} \\prod_{i=1}^k e^{tX_i} = \\prod_{i=1}^k \\mathop{\\bf E} e^{tX_i}")]]



#text(" for any complex ")#mi("{t}")#text(". This identity is a key component of the ")#emph[#text("exponential moment method")]#text(", which we will discuss in the next set of notes.")
]

#text("The following result is a key component of the second moment method.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Pairwise independence implies linearity of variance)")]#text(" If ")#mi("{X_1,\\ldots,X_k}")#text(" are pairwise independent scalar random variables of finite mean and variance, show that")

#align(center)[#tao-fit-display[#mitex("{\\bf Var}(\\sum_{i=1}^k X_i) = \\sum_{i=1}^k {\\bf Var}(X_i)")]]

#text("and more generally")

#align(center)[#tao-fit-display[#tao-math("{\\bf Var}(\\sum_{i=1}^k c_i X_i) = \\sum_{i=1}^k \\left|c_i\\right|^2 {\\bf Var}(X_i)", block: true)]]

#text("for any scalars ")#mi("{c_i}")#text(" (compare with ")#link(<tao-7f2fe580edb35154041f>)[#text("(12)")]#text(", ")#link(<tao-16af8f6d836d4f893368>)[#text("(22)")]#text(").")
]

#text("The product measure construction allows us to extend Lemma ")#link(<tao-7134d90c9fc306b8f2b7>)[#text("4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Creation of new, independent random variables)")]#text(" ")#metadata(none) <tao-c3fcb54e3a86b4ebd1b7>#text(" Let ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" be a family of random variables (not necessarily independent or finite), and let ")#mi("{(\\mu_\\beta)_{\\beta \\in B}}")#text(" be a collection (not necessarily finite) of probability measures ")#mi("{\\mu_\\beta}")#text(" on measurable spaces ")#mi("{R_\\beta}")#text(". Then, after extending the sample space if necessary, one can find a family ")#mi("{(Y_\\beta)_{\\beta \\in B}}")#text(" of independent random variables, such that each ")#mi("{Y_\\beta}")#text(" has distribution ")#mi("{\\mu_\\beta}")#text(", and the two families ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" and ")#mi("{(Y_\\beta)_{\\beta \\in B}}")#text(" are independent of each other.")
]

#text("We isolate the important case when ")#mi("{\\mu_\\beta = \\mu}")#text(" is independent of ")#mi("{\\beta}")#text(". We say that a family ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" of random variables is ")#emph[#text("independently and identically distributed")]#text(", or ")#emph[#text("iid")]#text(" for short, if they are jointly independent and all the ")#mi("{X_\\alpha}")#text(" have the same distribution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" Let ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" be a family of random variables (not necessarily independent or finite), let ")#mi("{\\mu}")#text(" be a probability measure on a measurable space ")#mi("{R}")#text(", and let ")#mi("{B}")#text(" be an arbitrary set. Then, after extending the sample space if necessary, one can find an iid family ")#mi("{(Y_\\beta)_{\\beta \\in B}}")#text(" with distribution ")#mi("{\\mu}")#text(" which is independent of ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(".")
]

#text("Thus, for instance, one can create arbitrarily large iid families of Bernoulli random variables, Gaussian random variables, etc., regardless of what other random variables are already in play. We thus see that the freedom to extend the underyling sample space allows us access to an unlimited source of randomness. This is in contrast to a situation studied in complexity theory and computer science, in which one does not assume that the sample space can be extended at will, and the amount of randomness one can use is therefore limited.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Given two probability measures ")#mi("{\\mu_X, \\mu_Y}")#text(" on two measurable spaces ")#mi("{R_X, R_Y}")#text(", a ")#emph[#text("joining")]#text(" or ")#emph[#text("coupling")]#text(" of the these measures is a random variable ")#mi("{(X,Y)}")#text(" taking values in the product space ")#mi("{R_X \\times R_Y}")#text(", whose individual components ")#mi("{X, Y}")#text(" have distribution ")#mi("{\\mu_X, \\mu_Y}")#text(" respectively. Exercise ")#link(<tao-c3fcb54e3a86b4ebd1b7>)[#text("18")]#text(" shows that one can always couple two distributions together in an independent manner; but one can certainly create non-independent couplings as well. The study of couplings (or joinings) is particularly important in ergodic theory, but this will not be the focus of this course.")
]

#heading(level: 1)[#strong[#text(" — 4. Conditioning — ")]]

#text("Random variables are inherently non-deterministic in nature, and as such one has to be careful when applying deterministic laws of reasoning to such variables. For instance, consider the law of the excluded middle: a statement ")#mi("{P}")#text(" is either true or false, but not both. If this statement is a random variable, rather than deterministic, then instead it is true with some probability ")#mi("{p}")#text(" and false with some complementary probability ")#mi("{1-p}")#text(". Also, applying set-theoretic constructions with random inputs can lead to sets, spaces, and other structures which are themselves random variables, which can be quite confusing and require a certain amount of technical care; consider, for instance, the task of rigorously defining a Euclidean space ")#mi("{{\\bf R}^d}")#text(" when the dimension ")#mi("{d}")#text(" is itself a random variable.")

#text("Now, one can always eliminate these difficulties by explicitly working with points ")#mi("{\\omega}")#text(" in the underlying sample space ")#mi("{\\Omega}")#text(", and replacing every random variable ")#mi("{X}")#text(" by its evaluation ")#mi("{X(\\omega)}")#text(" at that point; this removes all the randomness from consideration, making everything deterministic (for fixed ")#mi("{\\omega}")#text("). This approach is rigorous, but goes against the “probabilistic way of thinking”, as one now needs to take some care in extending the sample space.")

#text("However, if instead one only seeks to remove a ")#emph[#text("partial")]#text(" amount of randomness from consideration, then one can do this in a manner consistent with the probabilistic way of thinking, by introducing the machinery of ")#emph[#text("conditioning")]#text(". By conditioning an event to be true or false, or conditioning a random variable to be fixed, one can turn that random event or variable into a deterministic one, while preserving the random nature of other events and variables (particularly those which are independent of the event or variable being conditioned upon).")

#text("We begin by considering the simpler situation of conditioning on an event.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Conditioning on an event)")]#text(" ")#metadata(none) <tao-6151a5d30bdc7fc118e1>#text(" Let ")#mi("{E}")#text(" be an event (or statement) which holds with positive probability ")#mi("{{\\bf P}(E)}")#text(". By ")#emph[#text("conditioning on the event ")#mi("{E}")]#text(", we mean the act of replacing the underlying sample space ")#mi("{\\Omega}")#text(" with the subset of ")#mi("{\\Omega}")#text(" where ")#mi("{E}")#text(" holds, and replacing the underlying probability measure ")#mi("{{\\bf P}}")#text(" by the ")#emph[#text("conditional probability measure")]#text(" ")#mi("{{\\bf P}(|E)}")#text(", defined by the formula ")#metadata(none) <tao-1fe711b30ebaa593cfd2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("{\\bf P}(F|E) := {\\bf P}(F \\wedge E) / {\\bf P}(E).")]]



#text(" All events ")#mi("{F}")#text(" on the original sample space can thus be viewed as events ")#mi("{(F|E)}")#text(" on the conditioned space, which we model set-theoretically as the set of all ")#mi("{\\omega}")#text(" in ")#mi("{E}")#text(" obeying ")#mi("{F}")#text(". Note that this notation is compatible with ")#link(<tao-1fe711b30ebaa593cfd2>)[#text("(31)")]#text(".")

#text("All random variables ")#mi("{X}")#text(" on the original sample space can also be viewed as random variables ")#mi("{X}")#text(" on the conditioned space, by restriction. We will refer to this conditioned random variable as ")#mi("{(X|E)}")#text(", and thus define conditional distribution ")#mi("{\\mu_{(X|E)}}")#text(" and conditional expectation ")#mi("{{\\bf E}(X|E)}")#text(" (if ")#mi("{X}")#text(" is scalar) accordingly.")

#text("One can also condition on the complementary event ")#mi("{\\overline{E}}")#text(", provided that this event holds with positive probility also.")

#text("By ")#emph[#text("undoing this conditioning")]#text(", we revert the underlying sample space and measure back to their original (or ")#emph[#text("unconditional")]#text(") values. Note that any random variable which has been defined both after conditioning on ")#mi("{E}")#text(", and conditioning on ")#mi("{\\overline{E}}")#text(", can still be viewed as a combined random variable after undoing the conditioning.")
]

#text("Conditioning affects the underlying probability space in a manner which is different from extension, and so the act of conditioning is not guaranteed to preserve probabilistic concepts such as distribution, probability, or expectation. Nevertheless, the conditioned version of these concepts are closely related to their unconditional counterparts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-864b2540921b512ce870>#text(" If ")#mi("{E}")#text(" and ")#mi("{\\overline{E}}")#text(" both occur with positive probability, establish the identities ")#metadata(none) <tao-9c16c7ac1c69c3447b59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("{\\bf P}(F) = {\\bf P}(F|E) {\\bf P}(E) + {\\bf P}(F|\\overline{E}) {\\bf P}(\\overline{E})")]]



#text(" for any (unconditional) event ")#mi("{F}")#text(" and ")#metadata(none) <tao-3ca8ea2d11f73bb2789f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\mu_X = \\mu_{(X|E)} {\\bf P}(E) + \\mu_{(X|\\overline{E})} {\\bf P}(\\overline{E})")]]



#text(" for any (unconditional) random variable ")#mi("{X}")#text(" (in the original sample space). In a similar spirit, if ")#mi("{X}")#text(" is a non-negative or absolutely integrable scalar (unconditional) random variable, show that ")#mi("{(X|E)}")#text(", ")#mi("{(X|\\overline{E})}")#text(" are also non-negative and absolutely integrable on their respective conditioned spaces, and that ")#metadata(none) <tao-2dbdd2fde7e57420b014>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("{\\bf E} X = {\\bf E}(X|E) {\\bf P}(E) + {\\bf E}(X|\\overline{E}) {\\bf P}(\\overline{E}).")]]



#text(" In the degenerate case when ")#mi("{E}")#text(" occurs with full probability, conditioning to the complementary event ")#mi("{\\overline{E}}")#text(" is not well defined, but show that in those cases we can still obtain the above formulae if we adopt the convention that any term involving the vanishing factor ")#mi("{{\\bf P}(\\overline{E})}")#text(" should be omitted. Similarly if ")#mi("{E}")#text(" occurs with zero probability.")
]

#text("The above identities allow one to study probabilities, distributions, and expectations on the original sample space by conditioning to the two conditioned spaces.")

#text("From ")#link(<tao-9c16c7ac1c69c3447b59>)[#text("(32)")]#text(" we obtain the inequality ")#metadata(none) <tao-fd236565b58c50a9a68c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("{\\bf P}(F|E) \\leq {\\bf P}(F) / {\\bf P}(E),")]]



#text(" thus conditioning can magnify probabilities by a factor of at most ")#mi("{1/{\\bf P}(E)}")#text(". In particular,")

#list(
[#text("If ")#mi("{F}")#text(" occurs unconditionally surely, it occurs surely conditioning on ")#mi("{E}")#text(" also.")],
[#text("If ")#mi("{F}")#text(" occurs unconditionally almost surely, it occurs almost surely conditioning on ")#mi("{E}")#text(" also.")],
[#text("If ")#mi("{F}")#text(" occurs unconditionally with overwhelming probability, it occurs with overwhelming probability conditioning on ")#mi("{E}")#text(" also, provided that ")#mi("{{\\bf P}(E) \\geq c n^{-C}}")#text(" for some ")#mi("{c, C>0}")#text(" independent of ")#mi("{n}")#text(".")],
[#text("If ")#mi("{F}")#text(" occurs unconditionally with high probability, it occurs with high probability conditioning on ")#mi("{E}")#text(" also, provided that ")#mi("{{\\bf P}(E) \\geq c n^{-a}}")#text(" for some ")#mi("{c >0}")#text(" and some sufficiently small ")#mi("{a>0}")#text(" independent of ")#mi("{n}")#text(".")],
[#text("If ")#mi("{F}")#text(" occurs unconditionally asymptotically almost surely, it occurs asymptotically almost surely conditioning on ")#mi("{E}")#text(" also, provided that ")#mi("{{\\bf P}(E) \\geq c}")#text(" for some ")#mi("{c>0}")#text(" independent of ")#mi("{n}")#text(".")]
)

#text("Conditioning can distort the probability of events and the distribution of random variables. Most obviously, conditioning on ")#mi("{E}")#text(" elevates the probability of ")#mi("{E}")#text(" to ")#mi("{1}")#text(", and sends the probability of the complementary event ")#mi("{\\overline{E}}")#text(" to zero. In a similar spirit, if ")#mi("{X}")#text(" is a random variable uniformly distributed on some finite set ")#mi("{S}")#text(", and ")#mi("{S^{\\prime}}")#text(" is a non-empty subset of ")#mi("{S}")#text(", then conditioning to the event ")#mi("{X \\in S^{\\prime}}")#text(" alters the distribution of ")#mi("{X}")#text(" to now become the uniform distribution on ")#mi("{S^{\\prime}}")#text(" rather than ")#mi("{S}")#text(" (and conditioning to the complementary event produces the uniform distribution on ")#mi("{S \\backslash S^{\\prime}}")#text(").")

#text("However, events and random variables that are ")#emph[#text("independent")]#text(" of the event ")#mi("{E}")#text(" being conditioned upon are essentially unaffected by conditioning. Indeed, if ")#mi("{F}")#text(" is an event independent of ")#mi("{E}")#text(", then ")#mi("{(F|E)}")#text(" occurs with the same probability as ")#mi("{F}")#text("; and if ")#mi("{X}")#text(" is a random variable independent of ")#mi("{E}")#text(" (or equivalently, independently of the indicator ")#mi("{{\\bf I}(E)}")#text("), then ")#mi("{(X|E)}")#text(" has the same distribution as ")#mi("{X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can view conditioning to an event ")#mi("{E}")#text(" and its complement ")#mi("{\\overline{E}}")#text(" as the probabilistic analogue of the law of the excluded middle. In deterministic logic, given a statement ")#mi("{P}")#text(", one can divide into two separate cases, depending on whether ")#mi("{P}")#text(" is true or false; and any other statement ")#mi("{Q}")#text(" is unconditionally true if and only if it is conditionally true in both of these two cases. Similarly, in probability theory, given an event ")#mi("{E}")#text(", one can condition into two separate sample spaces, depending on whether ")#mi("{E}")#text(" is conditioned to be true or false; and the unconditional statistics of any random variable or event are then a weighted average of the conditional statistics on the two sample spaces, where the weights are given by the probability of ")#mi("{E}")#text(" and its complement.")
]

#text("Now we consider conditioning with respect to a discrete random variable ")#mi("{Y}")#text(", taking values in some range ")#mi("{R}")#text(". One can condition on any event ")#mi("{Y=y}")#text(", ")#mi("{y \\in R}")#text(" which occurs with positive probability. It is then not difficult to establish the analogous identities to those in Exercise ")#link(<tao-864b2540921b512ce870>)[#text("19")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{Y}")#text(" be a discrete random variable with range ")#mi("{R}")#text(". Then we have ")#metadata(none) <tao-cdcb3f28e702adabbe35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("{\\bf P}(F) = \\sum_{y \\in R} {\\bf P}(F|Y=y) {\\bf P}(Y=y)")]]



#text(" for any (unconditional) event ")#mi("{F}")#text(", and ")#metadata(none) <tao-899bde37ba6cca9d9867>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\mu_X = \\sum_{y \\in R} \\mu_{(X|Y=y)} {\\bf P}(Y=y)")]]



#text(" for any (unconditional) random variable ")#mi("{X}")#text(" (where the sum of non-negative measures is defined in the obvious manner), and for absolutely integrable or non-negative (unconditional) random variables ")#mi("{X}")#text(", one has ")#metadata(none) <tao-91f7de0c6cd9b89f0569>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("{\\bf E} X = \\sum_{y \\in R} {\\bf E}(X|Y=y) {\\bf P}(Y=y).")]]



#text(" In all of these identities, we adopt the convention that any term involving ")#mi("{{\\bf P}(Y=y)}")#text(" is ignored when ")#mi("{{\\bf P}(Y=y) = 0}")#text(".")
]

#text("With the notation as in the above exercise, we define the ")#emph[#text("conditional probability")]#text(" ")#mi("{{\\bf P}(F|Y)}")#text(" of an (unconditional) event ")#mi("{F}")#text(" conditioning on ")#mi("{Y}")#text(" to be the (unconditional) random variable that is defined to equal ")#mi("{{\\bf P}(F|Y=y)}")#text(" whenever ")#mi("{Y=y}")#text(", and similarly, for any absolutely integrable or non-negative (unconditional) random variable ")#mi("{X}")#text(", we define the ")#emph[#text("conditional expectation")]#text(" ")#mi("{{\\bf E}(X|Y)}")#text(" to be the (unconditional) random variable that is defined to equal ")#mi("{{\\bf E}(X|Y=y)}")#text(" whenever ")#mi("{Y=y}")#text(". (Strictly speaking, since we are not defining conditional expectation when ")#mi("{{\\bf P}(Y=y)=0}")#text(", these random variables are only defined almost surely, rather than surely, but this will not cause difficulties in practice; see Remark ")#link(<tao-3959b7855f62b6b6f3f2>)[#text("1")]#text(".) Thus ")#link(<tao-cdcb3f28e702adabbe35>)[#text("(36)")]#text(", ")#link(<tao-91f7de0c6cd9b89f0569>)[#text("(38)")]#text(" simplify to ")#metadata(none) <tao-81d255f6bd29085a5db1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("{\\bf P}(F) = {\\bf E}( {\\bf P}(F|Y) )")]]



#text(" and ")#metadata(none) <tao-c70d9a2ac01c14bf4f51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("{\\bf E}(X) = {\\bf E}( {\\bf E}(X|Y) ).")]]





#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" One can interpret conditional expectation as a type of orthogonal projection; see for instance ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("these previous lecture notes of mine")]#text(". But we will not use this perspective in this course. Just as conditioning on an event and its complement can be viewed as the probabilistic analogue of the law of the excluded middle, conditioning on a discrete random variable can be viewed as the probabilistic analogue of dividing into finitely or countably many cases. For instance, one could condition on the outcome ")#mi("{Y \\in \\{1,2,3,4,5,6\\}}")#text(" of a six-sided die, thus conditioning the underlying sample space into six separate subspaces. If the die is fair, then the unconditional statistics of a random variable or event would be an unweighted average of the conditional statistics of the six conditioned subspaces; if the die is weighted, one would take a weighted average instead.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Let ")#mi("{X_1, X_2}")#text(" be iid signed Bernoulli random variables, and let ")#mi("{Y := X_1+X_2}")#text(", thus ")#mi("{Y}")#text(" is a discrete random variable taking values in ")#mi("{-2,0,+2}")#text(" (with probability ")#mi("{1/4}")#text(", ")#mi("{1/2}")#text(", ")#mi("{1/4}")#text(" respectively). Then ")#mi("{X_1}")#text(" remains a signed Bernoulli random variable when conditioned to ")#mi("{Y=0}")#text(", but becomes the deterministic variable ")#mi("{+1}")#text(" when conditioned to ")#mi("{Y=+2}")#text(", and similarly becomes the deterministic variable ")#mi("{-1}")#text(" when conditioned to ")#mi("{Y=-2}")#text(". As a consequence, the conditional expectation ")#mi("{{\\bf E}(X_1|Y)}")#text(" is equal to ")#mi("{0}")#text(" when ")#mi("{Y=0}")#text(", ")#mi("{+1}")#text(" when ")#mi("{Y=+2}")#text(", and ")#mi("{-1}")#text(" when ")#mi("{Y=-2}")#text("; thus ")#mi("{{\\bf E}(X_1|Y) = Y/2}")#text(". Similarly ")#mi("{{\\bf E}(X_2|Y)=Y/2}")#text("; summing and using the linearity of (conditional) expectation (which follows automatically from the unconditional version) we obtain the obvious identity ")#mi("{{\\bf E}(Y|Y)=Y}")#text(".")
]

#text("If ")#mi("{X, Y}")#text(" are independent, then ")#mi("{(X|Y=y) \\equiv X}")#text(" for all ")#mi("{y}")#text(" (with the convention that those ")#mi("{y}")#text(" for which ")#mi("{{\\bf P}(Y=y)=0}")#text(" are ignored), which implies in particular (for absolutely integrable ")#mi("{X}")#text(") that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(X|Y) = {\\bf E}(X)")]]

#text("(so in this case the conditional expectation is a deterministic quantity).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" Let ")#mi("{X, Y}")#text(" be bounded scalar random variables (not necessarily independent), with ")#mi("{Y}")#text(" discrete. Then we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(XY) = {\\bf E}( {\\bf E}(XY|Y) ) = {\\bf E}( Y {\\bf E}(X|Y) )")]]

#text("where the latter equality holds since ")#mi("{Y}")#text(" clearly becomes deterministic after conditioning on ")#mi("{Y}")#text(".")
]

#text("We will also need to condition with respect to continuous random variables (this is the probabilistic analogue of dividing into a potentially uncountable number of cases). To do this formally, we need to proceed a little differently from the discrete case, introducing the notion of a ")#emph[#text("disintegration")]#text(" of the underlying sample space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Disintegration)")]#text(" Let ")#mi("{Y}")#text(" be a random variable with range ")#mi("{R}")#text(". A ")#emph[#text("disintegration")]#text(" ")#mi("{(R^{\\prime}, (\\mu_y)_{y \\in R^{\\prime}})}")#text(" of the underlying sample space ")#mi("{\\Omega}")#text(" with respect to ")#mi("{Y}")#text(" is a subset ")#mi("{R^{\\prime}}")#text(" of ")#mi("{R}")#text(" of full measure in ")#mi("{\\mu_Y}")#text(" (thus ")#mi("{Y \\in R^{\\prime}}")#text(" almost surely), together with assignment of a probability measure ")#mi("{{\\bf P}(|Y=y)}")#text(" on the subspace ")#mi("{\\Omega_y := \\{ \\omega \\in \\Omega: Y(\\omega)=y\\}}")#text(" of ")#mi("{\\Omega}")#text(" for each ")#mi("{y \\in R}")#text(", which is ")#emph[#text("measurable")]#text(" in the sense that the map ")#mi("{y \\mapsto {\\bf P}(F|Y=y)}")#text(" is measurable for every event ")#mi("{F}")#text(", and such that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(F) = {\\bf E} {\\bf P}(F|Y)")]]

#text("for all such events, where ")#mi("{{\\bf P}(F|Y)}")#text(" is the (almost surely defined) random variable defined to equal ")#mi("{{\\bf P}(F|Y=y)}")#text(" whenever ")#mi("{Y=y}")#text(".")

#text("Given such a disintegration, we can then ")#emph[#text("condition")]#text(" to the event ")#mi("{Y=y}")#text(" for any ")#mi("{y \\in R^{\\prime}}")#text(" by replacing ")#mi("{\\Omega}")#text(" with the subspace ")#mi("{\\Omega_y}")#text(" (with the induced ")#mi("{\\sigma}")#text("-algebra), but replacing the underlying probability measure ")#mi("{{\\bf P}}")#text(" with ")#mi("{{\\bf P}(|Y=y)}")#text(". We can thus condition (unconditional) events ")#mi("{F}")#text(" and random variables ")#mi("{X}")#text(" to this event to create conditioned events ")#mi("{(F|Y=y)}")#text(" and random variables ")#mi("{(X|Y=y)}")#text(" on the conditioned space, giving rise to conditional probabilities ")#mi("{{\\bf P}(F|Y=y)}")#text(" (which is consistent with the existing notation for this expression) and conditional expectations ")#mi("{{\\bf E}(X|Y=y)}")#text(" (assuming absolute integrability in this conditioned space). We then set ")#mi("{{\\bf E}(X|Y)}")#text(" to be the (almost surely defined) random variable defined to equal ")#mi("{{\\bf E}(X|Y=y)}")#text(" whenever ")#mi("{Y=y}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Discrete case)")]#text(" If ")#mi("{Y}")#text(" is a discrete random variable, one can set ")#mi("{R^{\\prime}}")#text(" to be the ")#emph[#text("essential range")]#text(" of ")#mi("{Y}")#text(", which in the discrete case is the set of all ")#mi("{y \\in R}")#text(" for which ")#mi("{{\\bf P}(Y=y)>0}")#text(". For each ")#mi("{y \\in R^{\\prime}}")#text(", we define ")#mi("{{\\bf P}(|Y=y)}")#text(" to be the conditional probability measure relative to the event ")#mi("{Y=y}")#text(", as defined in Definition ")#link(<tao-6151a5d30bdc7fc118e1>)[#text("8")]#text(". It is easy to verify that this is indeed a disintegration; thus the continuous notion of conditional probability generalises the discrete one.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7 (Independent case)")]#text(" ")#metadata(none) <tao-0275fca08c216c77b2a1>#text(" Starting with an initial sample space ")#mi("{\\Omega}")#text(", and a probability measure ")#mi("{\\mu}")#text(" on a measurable space ")#mi("{R}")#text(", one can adjoin a random variable ")#mi("{Y}")#text(" taking values in ")#mi("{R}")#text(" with distribution ")#mi("{\\mu}")#text(" that is independent of all previously existing random variables, by extending ")#mi("{\\Omega}")#text(" to ")#mi("{\\Omega \\times R}")#text(" as in Lemma ")#link(<tao-7134d90c9fc306b8f2b7>)[#text("4")]#text(". One can then disintegrate ")#mi("{Y}")#text(" by taking ")#mi("{R^{\\prime}:=R}")#text(" and letting ")#mi("{\\mu_y}")#text(" be the probability measure on ")#mi("{\\Omega_y = \\Omega \\times \\{y\\}}")#text(" induced by the obvious isomorphism between ")#mi("{\\Omega \\times \\{y\\}}")#text(" and ")#mi("{\\Omega}")#text("; this is easily seen to be a disintegration. Note that if ")#mi("{X}")#text(" is any random variable from the original space ")#mi("{\\Omega}")#text(", then ")#mi("{(X|Y=y)}")#text(" has the same distribution as ")#mi("{X}")#text(" for any ")#mi("{y \\in R}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" Let ")#mi("{\\Omega = [0,1]^2}")#text(" with Lebesgue measure, and let ")#mi("{(X_1,X_2)}")#text(" be the coordinate random variables of ")#mi("{\\Omega}")#text(", thus ")#mi("{X_1,X_2}")#text(" are iid with the uniform distribution on ")#mi("{[0,1]}")#text(". Let ")#mi("{Y}")#text(" be the random variable ")#mi("{Y := X_1+X_2}")#text(" with range ")#mi("{R = {\\bf R}}")#text(". Then one can disintegrate ")#mi("{Y}")#text(" by taking ")#mi("{R^{\\prime} = [0,2]}")#text(" and letting ")#mi("{\\mu_y}")#text(" be normalised Lebesgue measure on the diagonal line segment ")#mi("{\\{ (x_1,x_2) \\in [0,1]^2: x_1+x_2=y\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Almost uniqueness of disintegrations)")]#text(" ")#metadata(none) <tao-c2720445a45267813688>#text(" Let ")#mi("{(R^{\\prime},(\\mu_y)_{y \\in R^{\\prime}})}")#text(", ")#mi("{(\\tilde R^{\\prime},(\\tilde \\mu_y)_{y \\in \\tilde R^{\\prime}})}")#text(" be two disintegrations of the same random variable ")#mi("{Y}")#text(". Show that for any event ")#mi("{F}")#text(", one has ")#mi("{{\\bf P}(F|Y=y) = \\tilde {\\bf P}(F|Y=y)}")#text(" for ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in R}")#text(", where the conditional probabilities ")#mi("{{\\bf P}(|Y=y)}")#text(" and ")#mi("{\\tilde {\\bf P}(|Y=y)}")#text(" are defined using the disintegrations ")#mi("{(R^{\\prime},(\\mu_y)_{y \\in R^{\\prime}})}")#text(", ")#mi("{(\\tilde R^{\\prime},(\\tilde \\mu_y)_{y \\in \\tilde R^{\\prime}})}")#text(" respectively. (")#emph[#text("Hint:")]#text(" argue by contradiction, and consider the set of ")#mi("{y}")#text(" for which ")#mi("{{\\bf P}(F|Y=y)}")#text(" exceeds ")#mi("{\\tilde {\\bf P}(F|Y=y)}")#text(" (or vice versa) by some fixed ")#mi("{\\epsilon > 0}")#text(".)")

#text("Similarly, for a scalar random variable ")#mi("{X}")#text(", show that for ")#mi("{\\mu_Y}")#text("-almost every ")#mi("{y \\in R}")#text(", that ")#mi("{(X|Y=y)}")#text(" is absolutely integrable with respect to the first disintegration if and only if it is absolutely integrable with respect to the second integration, and one has ")#mi("{{\\bf E}(X|Y=y) = \\tilde {\\bf E}(X|Y=y)}")#text(" in such cases.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Under some mild topological assumptions on the underlying sample space (and on the measurable space ")#mi("{R}")#text("), one can always find at least one disintegration for every random variable ")#mi("{Y}")#text(", by using tools such as the Radon-Nikodym theorem; see Theorem 4 of ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("these previous lecture notes of mine")]#text(". In practice, we will not invoke these general results here (as it is not natural for us to place topological conditions on the sample space), and instead construct disintegrations by hand in specific cases, for instance by using the construction in Example ")#link(<tao-0275fca08c216c77b2a1>)[#text("7")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Strictly speaking, disintegration is not a probabilistic concept; there is no canonical way to extend a disintegration when extending the sample space;. However, due to the (almost) uniqueness and existence results alluded to earlier, this will not be a difficulty in practice. Still, we will try to use conditioning on continuous variables sparingly, in particular containing their use inside the ")#emph[#text("proofs")]#text(" of various lemmas, rather than in their ")#emph[#text("statements")]#text(", due to their slight incompatibility with the “probabilistic way of thinking”.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Fubini-Tonelli theorem)")]#text(" Let ")#mi("{(R^{\\prime}, (\\mu_y)_{y \\in R^{\\prime}})}")#text(" be a disintegration of a random variable ")#mi("{Y}")#text(" taking values in a measurable space ")#mi("{R}")#text(", and let ")#mi("{X}")#text(" be a non-negative (resp. absolutely integrable) scalar random variable. Show that for ")#mi("{\\mu_Y}")#text("-almost all ")#mi("{y \\in R}")#text(", ")#mi("{(X|Y=y)}")#text(" is a non-negative (resp. absolutely integrable) random variable, and one has the identity ")#metadata(none) <tao-7fe944df9070165a2764>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\mathop{\\bf E}( \\mathop{\\bf E}(X|Y) ) = \\mathop{\\bf E}(X),")]]



#text(" where ")#mi("{\\mathop{\\bf E}(X|Y)}")#text(" is the (almost surely defined) random variable that equals ")#mi("{\\mathop{\\bf E}(X|Y=y)}")#text(" whenever ")#mi("{y \\in R^{\\prime}}")#text(". (Note that one first needs to show that ")#mi("{\\mathop{\\bf E}(X|Y)}")#text(" is measurable before one can take the expectation.) More generally, show that ")#metadata(none) <tao-ebfb353d0a4e8fead567>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("\\mathop{\\bf E}( \\mathop{\\bf E}(X|Y) f(Y) ) = \\mathop{\\bf E}(X f(Y)),")]]



#text(" whenever ")#mi("{f: R \\rightarrow {\\bf R}}")#text(" is a non-negative (resp. bounded) measurable function. (One can essentially take ")#link(<tao-ebfb353d0a4e8fead567>)[#text("(42)")]#text(", together with the fact that ")#mi("{\\mathop{\\bf E}(X|Y)}")#text(" is determined by ")#mi("{Y}")#text(", as a ")#emph[#text("definition")]#text(" of the conditional expectation ")#mi("{\\mathop{\\bf E}(X|Y)}")#text(", but we will not adopt this approach here.)")
]

#text("A typical use of conditioning is to deduce a probabilistic statement from a deterministic one. For instance, suppose one has a random variable ")#mi("{X}")#text(", and a parameter ")#mi("{y}")#text(" in some range ")#mi("{R}")#text(", and an event ")#mi("{E(X,y)}")#text(" that depends on both ")#mi("{X}")#text(" and ")#mi("{y}")#text(". Suppose we know that ")#mi("{{\\bf P} E(X,y) \\leq \\epsilon}")#text(" for every ")#mi("{y \\in R}")#text(". Then, we can conclude that whenever ")#mi("{Y}")#text(" is a random variable in ")#mi("{R}")#text(" independent of ")#mi("{X}")#text(", we also have ")#mi("{{\\bf P} E(X,Y) \\leq \\epsilon}")#text(", regardless of what the actual distribution of ")#mi("{Y}")#text(" is. Indeed, if we condition ")#mi("{Y}")#text(" to be a fixed value ")#mi("{y}")#text(" (using the construction in Example ")#link(<tao-0275fca08c216c77b2a1>)[#text("7")]#text(", extending the underlying sample space if necessary), we see that ")#mi("{{\\bf P}(E(X,Y)|Y=y) \\leq \\epsilon}")#text(" for each ")#mi("{y}")#text("; and then one can integrate out the conditioning using ")#link(<tao-7fe944df9070165a2764>)[#text("(41)")]#text(" to obtain the claim.")

#text("The act of conditioning a random variable to be fixed is occasionally also called ")#emph[#text("freezing")]#text(".")

#heading(level: 1)[#strong[#text(" — 5. Convergence — ")]]

#text("In a first course in undergraduate real analysis, we learn what it means for a sequence ")#mi("{x_n}")#text(" of scalars to converge to a limit ")#mi("{x}")#text("; for every ")#mi("{\\epsilon > 0}")#text(", we have ")#tao-math("{\\left|x_n-x\\right| \\leq \\epsilon}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text(". Later on, this notion of convergence is generalised to metric space convergence, and generalised further to topological space convergence; in these generalisations, the sequence ")#mi("{x_n}")#text(" can lie in some other space than the space of scalars (though one usually insists that this space is independent of ")#mi("{n}")#text(").")

#text("Now suppose that we have a sequence ")#mi("{X_n}")#text(" of random variables, all taking values in some space ")#mi("{R}")#text("; we will primarily be interested in the scalar case when ")#mi("{R}")#text(" is equal to ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", but will also need to consider fancier random variables, such as point processes or empirical spectral distributions. In what sense can we say that ")#mi("{X_n}")#text(" “converges” to a random variable ")#mi("{X}")#text(", also taking values in ")#mi("{R}")#text("?")

#text("It turns out that there are several different ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables")[#text("notions of convergence")]#text(" which are of interest. For us, the four most important (in decreasing order of strength) will be almost sure convergence, convergence in probability, convergence in distribution, and tightness of distribution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Modes of convergence)")]#text(" Let ")#mi("{R = (R,d)}")#text(" be a ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("{\\sigma}")#text("-compact")]#text(", locally compact metric space (with the Borel ")#mi("{\\sigma}")#text("-algebra), and let ")#mi("{X_n}")#text(" be a sequence of random variables taking values in ")#mi("{R}")#text(". Let ")#mi("{X}")#text(" be another random variable taking values in ")#mi("{R}")#text(".")

#list(
[#mi("{X_n}")#text(" ")#emph[#text("converges almost surely")]#text(" to ")#mi("{X}")#text(" if, for almost every ")#mi("{\\omega \\in \\Omega}")#text(", ")#mi("{X_n(\\omega)}")#text(" converges to ")#mi("{X(\\omega)}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\limsup_{n \\rightarrow \\infty} d(X_n,X) \\leq \\epsilon ) = 1")]]

#text("for every ")#mi("{\\epsilon > 0}")#text(".")],
[#mi("{X_n}")#text(" ")#emph[#text("converges in probability")]#text(" to ")#mi("{X}")#text(" if, for every ")#mi("{\\epsilon > 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} {\\bf P}( d(X_n,X) \\leq \\epsilon ) = 1,")]]

#text("or equivalently if ")#mi("{d(X_n,X) \\leq \\epsilon}")#text(" holds asymptotically almost surely for every ")#mi("{\\epsilon > 0}")#text(".")],
[#mi("{X_n}")#text(" ")#emph[#text("converges in distribution")]#text(" to ")#mi("{X}")#text(" if, for every bounded continuous function ")#mi("{F: R \\rightarrow {\\bf R}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow\\infty} \\mathop{\\bf E} F(X_n) = \\mathop{\\bf E} F(X).")]]],
[#mi("{X_n}")#text(" has a ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight sequence of distributions")]#text(" if, for every ")#mi("{\\epsilon > 0}")#text(", there exists a compact subset ")#mi("{K}")#text(" of ")#mi("{R}")#text(" such that ")#mi("{\\mathop{\\bf P}( X_n \\in K ) \\geq 1 - \\epsilon}")#text(" for all sufficiently large ")#mi("{n}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" One can relax the requirement that ")#mi("{R}")#text(" be a ")#mi("{\\sigma}")#text("-compact, locally compact metric space in the definitions, but then some of the nice equivalences and other properties of these modes of convergence begin to break down. In our applications, though, we will only need to consider the ")#mi("{\\sigma}")#text("-compact, locally compact metric space case. Note that all of these notions are probabilistic (i.e. they are preserved under extensions of the sample space).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Implications and equivalences)")]#text(" ")#metadata(none) <tao-9e15f2709a233da97172>#text(" Let ")#mi("{X_n, X}")#text(" be random variables taking values in a ")#mi("{\\sigma}")#text("-compact, locally compact metric space ")#mi("{R}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{X_n}")#text(" converges almost surely to ")#mi("{X}")#text(", then ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(". (")#emph[#text("Hint:")]#text(" ")#link("http://en.wikipedia.org/wiki/Fatou's_lemma")[#text("Fatou’s lemma")]#text(".)")],
[#text("(ii) Show that if ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", then ")#mi("{X_n}")#text(" has a tight sequence of distributions.")],
[#text("(iii) Show that if ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(", then ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(". (")#emph[#text("Hint:")]#text(" first show tightness, then use the fact that on compact sets, continuous functions are uniformly continuous.)")],
[#text("(iv) Show that ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" if and only if ")#mi("{\\mu_{X_n}}")#text(" converges to ")#mi("{\\mu_X}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" (i.e. ")#mi("{\\int f\\ d\\mu_{X_n} \\rightarrow \\int f\\ d\\mu_X}")#text(" for all continuous functions ")#mi("{f: R \\rightarrow {\\bf R}}")#text(" of compact support).")],
[#text("(v) Conversely, if ")#mi("{X_n}")#text(" has a tight sequence of distributions, and ")#mi("{\\mu_{X_n}}")#text(" is convergent in the vague topology, show that ")#mi("{X_n}")#text(" is convergent in distribution to another random variable (possibly after extending the sample space). What happens if the tightness hypothesis is dropped?")],
[#text("(vi) If ")#mi("{X}")#text(" is deterministic, show that ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(" if and only if ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")],
[#text("(vii) If ")#mi("{X_n}")#text(" has a tight sequence of distributions, show that there is a subsequence of the ")#mi("{X_n}")#text(" which converges in distribution. (This is known as ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(").")],
[#text("(viii) If ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(", show that there is a subsequence of the ")#mi("{X_n}")#text(" which converges almost surely to ")#mi("{X}")#text(".")],
[#text("(ix) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" if and only if ")#mi("{\\liminf_{n \\rightarrow \\infty} {\\bf P}(X_n \\in U) \\geq {\\bf P}(X \\in U)}")#text(" for every open subset ")#mi("{U}")#text(" of ")#mi("{R}")#text(", or equivalently if ")#mi("{\\limsup_{n \\rightarrow \\infty} {\\bf P}(X_n \\in K) \\leq {\\bf P}(X \\in K)}")#text(" for every closed subset ")#mi("{K}")#text(" of ")#mi("{R}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" The relationship between almost sure convergence and convergence in probability may be clarified by the following observation. If ")#mi("{E_n}")#text(" is a sequence of events, then the indicators ")#mi("{{\\bf I}(E_n)}")#text(" converge in probability to zero iff ")#mi("{{\\bf P}(E_n) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", but converge almost surely to zero iff ")#mi("{{\\bf P}(\\bigcup_{n \\geq N} E_n) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 9")]#text(" Let ")#mi("{Y}")#text(" be a random variable drawn uniformly from ")#mi("{[0,1]}")#text(". For each ")#mi("{n \\geq 1}")#text(", let ")#mi("{E_n}")#text(" be the event that the decimal expansion of ")#mi("{Y}")#text(" begins with the decimal expansion of ")#mi("{n}")#text(", e.g. every real number in ")#mi("{[0.25, 0.26)}")#text(" lies in ")#mi("{E_{25}}")#text(". (Let us ignore the annoying ")#mi("{0.999\\ldots=1.000\\ldots}")#text(" ambiguity in the decimal expansion here, as it will almost surely not be an issue.) Then the indicators ")#mi("{{\\bf I}(E_n)}")#text(" converge in probability and in distribution to zero, but do not converge almost surely.")

#text("If ")#mi("{y_n}")#text(" is the ")#mi("{n^{th}}")#text(" digit of ")#mi("{Y}")#text(", then the ")#mi("{y_n}")#text(" converge in distribution (to the uniform distribution on ")#mi("{\\{0,1,\\ldots,9\\}}")#text(", but do not converge in probability or almost surely. Thus we see that the latter two notions are sensitive not only to the distribution of the random variables, but how they are positioned in the sample space.")
]

#text("The limit of a sequence converging almost surely or in probability is clearly unique up to almost sure equivalence, whereas the limit of a sequence converging in distribution is only unique up to equivalence in distribution. Indeed, convergence in distribution is really a statement about the distributions ")#mi("{\\mu_{X_n}, \\mu_X}")#text(" rather than of the random vaariables ")#mi("{X_n, X}")#text(" themselves. In particular, for convergence in distribution one does not care about how correlated or dependent the ")#mi("{X_n}")#text(" are with respect to each other, or with ")#mi("{X}")#text("; indeed, they could even live on different sample spaces ")#mi("{\\Omega_n, \\Omega}")#text(" and we would still have a well-defined notion of convergence in distribution, even though the other two notions cease to make sense (except when ")#mi("{X}")#text(" is deterministic, in which case we can recover convergence in probability by Exercise ")#link(<tao-9e15f2709a233da97172>)[#text("23")]#text("(vi)).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Borel-Cantelli lemma)")]#text(" Suppose that ")#mi("{X_n, X}")#text(" are random variables such that ")#mi("{\\sum_n {\\bf P}(d(X_n,X) \\geq \\epsilon) < \\infty}")#text(" for every ")#mi("{\\epsilon > 0}")#text(". Show that ")#mi("{X_n}")#text(" converges almost surely to ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Convergence and moments)")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of scalar random variables, and let ")#mi("{X}")#text(" be another scalar random variable. Let ")#mi("{k, \\epsilon > 0}")#text(".")

#list(
[#text("(i) If ")#tao-math("{\\sup_n {\\bf E} \\left|X_n\\right|^k < \\infty}", block: false)#text(", show that ")#mi("{X_n}")#text(" has a tight sequence of distributions.")],
[#text("(ii) If ")#tao-math("{\\sup_n {\\bf E} \\left|X_n\\right|^k < \\infty}", block: false)#text(" and ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", show that ")#tao-math("{{\\bf E} \\left|X\\right|^k \\leq \\liminf_{n \\rightarrow \\infty} {\\bf E} \\left|X_n\\right|^k}", block: false)#text(".")],
[#text("(iii) If ")#tao-math("{\\sup_n {\\bf E} \\left|X_n\\right|^{k+\\epsilon} < \\infty}", block: false)#text(" and ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", show that ")#tao-math("{{\\bf E} \\left|X\\right|^k = \\lim_{n \\rightarrow \\infty} {\\bf E} \\left|X_n\\right|^k}", block: false)#text(".")],
[#text("(iv) Give a counterexample to show that (iii) fails when ")#mi("{\\epsilon=0}")#text(", even if we upgrade convergence in distribution to almost sure convergence.")],
[#text("(v) If the ")#mi("{X_n}")#text(" are uniformly bounded and real-valued, and ")#mi("{{\\bf E} X^k = \\lim_{n \\rightarrow \\infty} {\\bf E} X_n^k}")#text(" for every ")#mi("{k=0,1,2,\\ldots}")#text(", then ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(". (Hint: use the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Weierstrass approximation theorem")]#text(". Alternatively, use the analytic nature of the moment generating function ")#mi("{{\\bf E} e^{tX}}")#text(" and analytic continuation.)")],
[#text("(vi) If the ")#mi("{X_n}")#text(" are uniformly bounded and complex-valued, and ")#mi("{{\\bf E} X^k \\overline{X}^l = \\lim_{n \\rightarrow \\infty} {\\bf E} X_n^k \\overline{X_n}^l}")#text(" for every ")#mi("{k,l=0,1,2,\\ldots}")#text(", then ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(". Give a counterexample to show that the claim fails if one only considers the cases when ")#mi("{l=0}")#text(".")]
)
]

#text("There are other interesting modes of convergence on random variables and on distributions, such as convergence in ")#link("http://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation norm")]#text(", in the ")#link("http://en.wikipedia.org/wiki/L%C3%A9vy-Prokhorov_metric")[#text("Lévy-Prokhorov metric")]#text(", or in ")#link("http://en.wikipedia.org/wiki/Wasserstein_metric")[#text("Wasserstein metric")]#text(", but we will not need these concepts in this course.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (140)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-137747")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("When defining real-valued random variables, does one typically equip the real line with the Borel measure, or its Lebesgue completion? Does this distinction matter much in practice?")

#text("For instance, does one have to do a significant amount of extra work to check that certain random variables are Lebesgue-measurable as opposed to merely Borel-measurable?")

#text("In the definition you refer only to the Borel measure, but later on you mention some issues about pullbacks of (Lebesgue) null sets when discussing absolute continuity of random variables.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-137764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("In general, the Borel sigma algebra is slightly more convenient to use than the Lebesgue sigma algebra for the _range_ of a measurable function, but the Lebesgue can be more a convenient algebra to use for the _domain_ of a measurable function. But the main advantage of Lebesgue measure, namely completeness, is more useful in measure theory than in probability theory; for most probabilistic applications one does not actually need completeness.")

#text("p.s. I don’t know what issue about pullbacks of null sets you are referring to in your comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-137766")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("I did not really mean to say there was any “issue”, but rather just that you switched from Borel measure to Lebesgue measure in the following passage:")

#text("“Now we turn to non-discrete random variables {X} taking values in some range {R}. We say that a random variable is continuous if {{\\bf P}(X=x)=0} f")#linebreak()#text(" or all {x \\in R} (here we assume that all points are measurable). If {R} is already equipped with some reference measure {dm} (e.g. Lebesgue measure in the case of scalar, vector, or matrix-valued random variables), we say that the random variable is absolutely continuous if {{\\bf P}(X \\in S)=0} for all null sets {S} in {R}. ”")

#text("and it was not clear to me whether there was any significance in this switch.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-137770")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Ah. I tend to use Lebesgue measure to denote both the standard measure on the Lebesgue sigma algebra, as well as its restriction to the Borel sigma algebra (which is indeed the slightly more natural sigma algebra to use in this context). (The terminology “the Borel measure on ")#mi("{\\bf R}")#text("” to denote this restriction is also in use, but somewhat less common, perhaps because it can be confused with the more general concept of a Borel measure.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f08746571f83d1b2a8c384ad68e2c30ed78bd1144145ca771874d8961908d48-86f323d736cb323c5a24cbb64bf4da041087f3a4ec78cd7499c2ed9b0a158fb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of frankpmurphyh")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-147471")[#strong[#text("frankpmurphyh")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2012")])]

#text("Reblogged this on ")#link("http://algebrafm.wordpress.com/2012/06/17/311/")[#text("algebrafm")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/733a63cfb49c7ea86a228f6897cf042241a12dc2a01e7c6b3c03ebefb3fc0f00-8fcbc07a4b0a88c337b96ad437ffae703f5a04cde093ab1ad21a7b989ebf58f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gelasio Salazar")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-167587")[#strong[#text("Gelasio Salazar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("Dear Terry,")

#text("One question about the distinction between “with high probability” and")#linebreak()#text(" “asymptotically almost surely”. We just got a referee report in which they")#linebreak()#text(" ask us to change “w.h.p.” to “a.a.s.” — since in a particular lemma, all")#linebreak()#text(" we can prove is that a certain event holds with probability 1 -o(1). I")#linebreak()#text(" would have normally used w.h.p. and a.a.s. interchangeably, but after the")#linebreak()#text(" referee’s remark (s/he gave your Notes as reference) I realized we need to")#linebreak()#text(" be more careful. In the revised version we’ll use “a.a.s.”, and I was")#linebreak()#text(" wondering if you were aware of other sources in which this distinction")#linebreak()#text(" between “overwhelming probability”, “with high probability” and")#linebreak()#text(" “asymptotically almost surely” is used.")

#text("Last but not least, thanks for your comprehensive notes in Probability")#linebreak()#text(" Theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-167604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("“asymptotically almost surely”, when it is used in literature, invariably means 1-o(1), but for “with high probability” there is less consensus; I have seen it used for both 1-o(1) and for 1-O(n^{-c}) (though not in the same paper, of course). But given that a.a.s. is a perfectly useful and accepted notation for 1-o(1), it seems logical to me to exclusively use w.h.p for 1-O(n^{-c}) instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-172647")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")])]

#text("Could you give an example of your saying that “If one was particularly well organised, one could in principle work out in advance all of the random variables one would ever want or need, and then specify the sample space accordingly, before doing any actual probability theory.”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-172658")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")])]

#text("Can one say to some degree that a random variable ")#mi("X")#text(" on ")#mi("(\\Omega,\\mathcal{B},\\mathcal{P})")#text(" can be regarded as an extension ")#mi("\\pi")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-175875")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2012")])]

#text("I’m confused about the concept “pushforward”. Let ")#mi("(\\Omega,{\\mathcal A},P)")#text(" be a probability space and random variable ")#mi("X")#text(" on this space with range ")#mi("(R, {\\mathcal R})")#text(". Then ")#mi("\\mu_X")#text(" is a probability measure on ")#mi("(R, {\\mathcal R})")#text(". However, according to your notes of 245A, ")#mi("(R, {\\mathcal R})")#text(" can be any measurable space, for example ")#mi("({\\mathbb R},2^{\\mathbb R})")#text(". But I also learned that one cannot sign a measure to ")#mi("({\\mathbb R},2^{\\mathbb R})")#text(" that render it a measure space. What do I do wrong here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-176010")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("One can place several measures on ")#mi("({\\mathbb R}, 2^{\\mathbb R})")#text(", e.g. a Dirac measure. (But one cannot have a non-trivial ")#emph[#text("translation-invariant")]#text(" measure on this space, due to Banach-Tarski type paradoxes.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-176066")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("Ah, I see the point. As you said in this note, the underlying sample space of a random variable is often not specified. And the range of the random variable ")#mi("X")#text(", according to Remark 2, can be somehow not mentioned either as I understand. I’m puzzled about this: to what extend should one specify a random variable? What’s left for a function when one does not specify its domain and range?")

#text("I saw lots of times when one says something like “consider a ")#mi("R")#text("-value random variable”. They don’t even specify which ")#mi("\\sigma-")#text(" algebra is used for ")#mi("R")#text(". What’s more, I’ve never read that one specify a measure for the range measurable space ")#mi("(R,{\\mathcal R})")#text(". Is it because we have an immediate one, ")#mi("\\mu_X")#text(", or it doesn’t matter at all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-176201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("We usually don’t specify the sample space of a random variable for much the same reason we don’t specify which base (e.g. base 10, binary, etc.) we use to represent numbers, or which coordinate system we use to represent a manifold. We ")#emph[#text("could")]#text(" specify these representations, if desired, but we wish to focus on those aspects of the mathematical objects being studied that are ")#emph[#text("independent")]#text(" of the choice of representation, and so it is usually counterproductive to devote too much attention to these representations. (This is discussed near the beginning of this blog post.)")

#text("Also, one should make a distinction between a ")#emph[#text("measurable")]#text(" space ")#mi("(R, {\\mathcal R})")#text(" and a ")#emph[#text("measure")]#text(" space ")#mi("(R, {\\mathcal R}, \\mu)")#text(". A measurable space can be turned into a measure space by specifying a measure, but there are multiple measures one could use for this purpose, and in many cases it is better to not specify a measure at all.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1697a645e726fc6f567025ba0a01e118ff8283c9964f214a35e8b900f8d2b0c0-9189522cb445c6b3bb7f9da0ba599bb4f4725b86caf7943df59463dfca534152.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SAADA")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-182404")[#strong[#text("SAADA")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("Professeur Tao, auriez-vous une version française de cette note ?")#linebreak()#text(" Merci par avance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-182421")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("Non, mais outils de traduction automatique, tels que Google Translate, peuvent faire un travail raisonnable: ")#link("http://translate.google.com/translate?sl=en&tl=fr&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&u=http%3A%2F%2Fterrytao.wordpress.com%2F2010%2F01%2F01%2F254a-notes-0-a-review-of-probability-theory&act=url")[#text("http://translate.google.com/translate?sl=en&tl=fr&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&u=http%3A%2F%2Fterrytao.wordpress.com%2F2010%2F01%2F01%2F254a-notes-0-a-review-of-probability-theory&act=url")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1697a645e726fc6f567025ba0a01e118ff8283c9964f214a35e8b900f8d2b0c0-9189522cb445c6b3bb7f9da0ba599bb4f4725b86caf7943df59463dfca534152.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-182425")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("merci beaucoup professeur.")

#link("http://www.daniel-saada.eu")[#text("http://www.daniel-saada.eu")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-182587")[#strong[#text("Hoeffding bound | blayz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")]

#text("[…] first two sections of the book Topics in Random Matrix Theory by Terry Tao, with his draft and relevant notes available online, and the Hoeffding’s original paper along with the paper by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-212090")[#strong[#text("http terrytao wordpress com 2010 01 01 254a… « Kathys LinkBook")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2013")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/254dbc6e5cc13d4774708aff237e2068f6ba7c713518145049723f1ee65eb49e-e1e9a99897693a8367c545ee5eed0332669c5612da3b735bddc575d44a3da81c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tim")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-213856")[#strong[#text("tim")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2013")])]

#text("Hi Prof Tao,")

#text("Thanks for sharing your note!")

#text("I don’t quite understand why the extension is defined to be surjective in Tao’s blog. Is the concept “extension” trying to become morphisms in some category of probability spaces?")

#text("I found two links ")#link("http://theoreticalatlas.wordpress.com/2010/11/11/categorifying-measure-theory/")[#text("http://theoreticalatlas.wordpress.com/2010/11/11/categorifying-measure-theory/")]#text(" and ")#link("http://mathoverflow.net/questions/49426/is-there-a-category-structure-one-can-place-on-measure-spaces-so-that-category-th")[#text("http://mathoverflow.net/questions/49426/is-there-a-category-structure-one-can-place-on-measure-spaces-so-that-category-th")]#text(". Although I can only understand some small part of them, I hope they can be interesting to you!")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b7ffaaaa2a0ec17b9ecdfb271929cef2a7dbd7636bb74a11131b87370fd4efc-2bcdd4102f94c3348646e196166a41ddc06f7e012e87e7d743584f6eb2bb3d1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marek")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-220663")[#strong[#text("Marek")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("Dear Prof. Tao,")

#text("Excellent post, thank you for sharing! I have a related question, and I would be very grateful if you or someone else could provide me an answer.")

#text("As is well-known, the total variation distance between (the laws of) two random variables X and Y defined on R is given by sup|E[g(X)]−E[g(Y)]|, where the supremum is taken over all g:R→[0,1] that are measurable. Here is my question: do we obtain the same definition if one considers the supremum over all g:R→[0,1] that are continuous? Or over all g:R→[0,1] that are differentiable?")

#text("Thanks a lot in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-220676")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("Yes, basically because test functions are dense in ")#mi("L^1(\\mu)")#text(" for any Borel probability measure on the real line (note that all Borel probability measures on R are Radon measures), thanks to basic tools such as the Stone-Weierstrass theorem, Lusin’s theorem, the Tietze extension theorem, and Urysohn’s lemma (as discussed in ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("this previous blog post")]#text("). Applying this general fact to ")#mi("\\mu := (\\mu_X + \\mu_Y)/2")#text(", the Borel probability measure formed by the average of the two laws, and using the Radon-Nikodym theorem to write ")#mi("\\mu_X, \\mu_Y")#text(" as bounded multiples of ")#mi("\\mu")#text(", we obtain the desired equivalence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b7ffaaaa2a0ec17b9ecdfb271929cef2a7dbd7636bb74a11131b87370fd4efc-2bcdd4102f94c3348646e196166a41ddc06f7e012e87e7d743584f6eb2bb3d1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marek")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-220680")[#strong[#text("Marek")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("Thank you very much for the prompt reply! It is very clear in my mind now. Best, Marek")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-238298")[#strong[#text("Probability and Statistics Books Online | Download free ebook")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")]

#text("[…] A review of probability theory by Terence Tao, 2010 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-245336")[#strong[#text("Free Mathematics eBooks Online : Probability and Statistics | Top Free Books")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")]

#text("[…] A review of probability theory by Terence Tao, 2010 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-251373")[#strong[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("[…] classical foundations of probability theory (discussed for instance in this previous blog post) is founded on the notion of a probability space – a space (the sample space) equipped with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-251374")[#strong[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("[…] classical foundations of probability theory (discussed for instance in this previous blog post) is founded on the notion of a probability space – a space (the sample space) equipped with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6d5aa2cafc1e5f09929ece0e67c133155b4dcac09d7023603a282030f961617-23e47697df3bb68fd482ed2a1011eeff09f1fd1554c06b60b912874d45dbccbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehsan")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-369137")[#strong[#text("Ehsan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2014")])]

#text("Dear Prof. Tao,")

#text("Thank you for sharing your notes!")

#text("My question is about the probabilistic way of thinking. I understand that the cardinality of an event is not probabilistic notion because it is not preserved under the extension of the probability space.")

#text("Can rank and eigenvalues be probabilistic notions? If we consider the space of n-by-n matrices and extend it to the space of n+1-by-n+1 matrices, the the rank and eigenvalues may change as well.")

#text("I think I am missing something here.")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-369198")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2014")])]

#text("The space of n by n matrices is not a probability space (and conversely, most probability spaces are not spaces of matrices), so I don’t see how your scenario would connect with probability theory.")

#text("Of course, if one had a matrix-valued random variable ")#mi("A: \\Omega \\to M_n({\\bf C})")#text(" (i.e. a random matrix), one could compute its rank and eigenvalues, giving a random natural number and a random (multi-)set of points (i.e. a point process) respectively. These would all be probabilistic notions, but in all cases one would be extending the probabilistic domain ")#mi("\\Omega")#text(" rather than the matrix space ")#mi("M_n({\\bf C})")#text(" when performing probabilistic extensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6d5aa2cafc1e5f09929ece0e67c133155b4dcac09d7023603a282030f961617-23e47697df3bb68fd482ed2a1011eeff09f1fd1554c06b60b912874d45dbccbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehsan")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-369657")[#strong[#text("Ehsan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2014")])]

#text("Dear Prof. Tao,")

#text("Thank you for the answer. As you mentioned, I missed the fact that the probabilistic domain $\\Omega$ is extended rather than the space of matrices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e066ca2057bed3dd0ec14eeedebd297350b98f0e350e60180f99848b17fc240-e1d3af0c93bb6653187ec72e9a1bd6b61a34d17940ad55167e81cde09152712a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CRQ")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-373108")[#strong[#text("CRQ")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2014")])]

#text("Dear Prof Tao,")

#text("quick notation question: in definition 1, you say ”for some ")#mi("C")#text(" independent of ")#mi("n")#text(" and all ")#mi("n \\geq C")#text("”. Do you mean instead that there exists ")#mi("n_0")#text(" such that this holds ”for some ")#mi("C")#text(" independent of ")#mi("n")#text(" and all ")#mi("n \\geq n_0")#text("? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-373436")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2014")])]

#text("As long as there are no parameters in play besides ")#mi("n")#text(", this is equivalent to the definition presented, since one could always raise either ")#mi("C")#text(" or ")#mi("n_0")#text(" to be equal to each other. Once there are parameters, though, one has to be more careful. For instance if there are two parameters ")#mi("k,l")#text(" and one is asserting that ")#mi("X = O_k(Y)")#text(", then the conventions I use are that this means that ")#tao-math("\\left|X\\right| \\leq C_k Y", block: false)#text(" for all ")#mi("n \\geq C_k")#text(", where ")#mi("C_k")#text(" depends only on ")#mi("k")#text(" but not on ")#mi("l")#text(" or ")#mi("n")#text(". With the definition involving ")#mi("n_0")#text(", it can be ambiguous as to whether ")#mi("n_0")#text(" is allowed to depend on ")#mi("l")#text(" or not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f85a5456cd6a0d5ddbeb3cfa6afed7caec34e0586b012a23cbbc62fb77ea56d-a92d925e9c8814257333d477380d5cdec28aaaad476d9eed9a42e1a6b6bfa8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nomen")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-373954")[#strong[#text("nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2014")])]

#text("I have been trying to define/explore “conditional random variables” for a while. In particular, I find that “sampling notation”, and what appears to be an adjunction in the algebra of random variables, makes them very natural. For example, consider ")#mi("X \\sim \\mathbf{Z}, Y \\sim \\mathbf{U}_X")#text(". It is very natural to treat ")#mi("Y")#text(" as being conditional on ")#mi("X")#text(", since ")#mi("Y")#text(" is uniformly distributed on ")#mi("(0,X)")#text(".")

#text("However, when I have tried to find out about this idea (mostly on math.stackexchange.com and mathoverflow.net), people have been dismissive. Actually, somebody on mathoverflow.net was supportive and suggested that I look into disintegrations.")

#text("Can you comment on the feasibility of defining such objects? Are they compatible with distintegrations, as you have used them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f85a5456cd6a0d5ddbeb3cfa6afed7caec34e0586b012a23cbbc62fb77ea56d-a92d925e9c8814257333d477380d5cdec28aaaad476d9eed9a42e1a6b6bfa8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nomen")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-373956")[#strong[#text("nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2014")])]

#text("Sorry for the self-reply. I just wanted to clarify my motivation.")

#text("I often see that ")#mi("x\\sim (X|Y)")#text(" used as shorthand for")

#mi("y \\sim Y, x \\sim (X|Y=y)")

#text("This “sample and bind” shorthand seems completely straight-forward to me, since we can “always” recover the distribution of Y from the joint distribution of (X,Y) by marginalizing X out. Are marginalizing and conditioning adjoints? It seems that the notation witnesses triple-ability, if they are adjoint at all.")

#text("This is effectively what I asked on mathoverflow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-377623")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Dear Prof. Tao,")

#text("thank you very much for this nice post and your book on Random Matrices.")

#text("as I noted in this (")#link("http://math.stackexchange.com/questions/842989/the-completeness-assumption-in-prokhorovs-theorem/843397#843397")[#text("http://math.stackexchange.com/questions/842989/the-completeness-assumption-in-prokhorovs-theorem/843397#843397")]#text(") stackexchange post, Exercise 23 seems to have mild problems.")

#text("You only assume that ")#mi("R")#text(" is ")#mi("\\sigma")#text("-compact, not necessarily complete.")

#text("In that case, part (iv) of that exercise fails. Take e.g. ")#mi("R = \\mathbb{Q}")#text(". Then there are no nontrivial continuous functions with compact support, so that one of the conditions is vacuous.")

#text("I am also not sure that part (i) is really true in that setting. The proofs that I found all use the completeness of ")#mi("R")#text(" to show that certain sets (namely of the form ")#mi("K = \\bigcap_j \\bigcup_{i=1}^{k_j} \\overline{B}(a_i, 1/j)")#text(" are compact, as they are closed and totally bounded).")

#text("Sadly, I did not manage to produce a counterexample up to now.")

#text("Best regards,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-377686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Oops, you’re right; I had intended to assume that the metric space is both sigma compact and locally compact, but I think I thought that the latter hypotheses was implied by the former one for metric spaces, but as you point out, the example of the rationals shows that this is not the case. I’ve modified the text accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-378949")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("Thanks for the answer.")

#text("In my post above I was actually referring to part (ii) of the exercise, not part (i), sorry about that.")

#text("Do you know if this part (ii) is correct without the completeness assumption? Wikipedia (")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")]#text(" , part 1 of “Statement of the theorem”) also only assumes that the metric space is separable, but they give neither a proof, nor a source.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49d0ea1c65748d828b6af7e8f15fd89190ec82568fe280f6068b7a13aaffc5c6-c9cc8e742a0f644da9e6552da8d1f714d7637f145e8be25c2a6cad4a76adebf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiteng Liu")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-379025")[#strong[#text("Xiteng Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("Congratulations Terry for The Breakthrough Award! You deserve it for your endeavor and enthusiasm in math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f76daaf24ddb80d6c080050146d2f3a317f45cdc9200f9f95a9d65c2a564aabe-de5450c63f548a555ab38efa89f4cb90db94eca76ad13a6b14f183758260dd3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon Gonen")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-380615")[#strong[#text("Alon Gonen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Dear professor Terrence Tao,")#linebreak()#text(" How do you derive equation 1.24 using dominated converge?")#linebreak()#text(" Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-380868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#tao-math("\\lambda^k 1_{\\left|X\\right| \\geq \\lambda}", block: false)#text(" is dominated by ")#tao-math("\\left|X\\right|^k", block: false)#text(", and converges a.s. to zero as ")#mi("\\lambda \\to \\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real analysis relative to a finite measure space | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-394747")[#strong[#text("Real analysis relative to a finite measure space | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("[…] 1 In my previous post on the foundations of probability theory, I emphasised the freedom to extend the sample space to a larger sample space whenever one wished […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-404544")[#strong[#text("254A, Notes 0: A review of probability theory | Mathemania")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2014")]

#text("[…] 254A, Notes 0: A review of probability theory. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f2de6aa9514af890cf2226c874137fb5322023fc83b06ca2703201c9deb6779-dbf670f5df7e0cfe04ec1a026cb9a951ca7f729abb7f7c3bc9e00cfe91f09427.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aryeh")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-452706")[#strong[#text("Aryeh")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("Dear Prof. Tao, I don’t see how Poisson variables are subgaussian. In particular, the Laplace transform of the Poisson distribution is not upper-bounded by $e^{c t^2}$. Best, -Aryeh")

#emph[#text("[Oops, you’re right – corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 0: Foundations of probability theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-459862")[#strong[#text("275A, Notes 0: Foundations of probability theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("[…] the classical measure-theoretic foundations of probability. (I wrote on these foundations also in this previous blog post, but in that post I already assumed that the reader was familiar with measure theory and basic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 1: Integration and expectation | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-460066")[#strong[#text("275A, Notes 1: Integration and expectation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] Remark 2 There is one minor exception to this general rule if we do not impose the additional requirement that the factor map is surjective. Namely, for non-surjective , it can become possible that two events are unequal in the original sample space model, but become equal in the extension (and similarly for random variables), although the converse never happens (events that are equal in the original sample space always remain equal in the extension). For instance, let be the discrete probability space with and , and let be the discrete probability space with , and non-surjective factor map defined by . Then the event modeled by in is distinct from the empty event when viewed in , but becomes equal to that event when viewed in . Thus we see that extending the sample space by a non-surjective factor map can identify previously distinct events together (though of course, being probability preserving, this can only happen if those two events were already almost surely equal anyway). This turns out to be fairly harmless though; while it is nice to know if two given events are equal, or if they differ by a non-null event, it is almost never useful to know that two events are unequal if they are already almost surely equal. Alternatively, one can add the additional requirement of surjectivity in the definition of an extension, which is also a fairly harmless constraint to impose (this is what I chose to do in this previous set of notes). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acb60df38d3f64e49ba0d925a29a0de078644878e593b196fe216dba8a3f3f81-90f18da174327c251ee030f93cbb28f46145e90cf1e5d15d2b2f0e1db5c883d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-460205")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")])]

#text("As a complement to Durrett’s book, I always found Amir Dembo’s notes on probability to be useful for a course of this type… their main virtue is that they are very systematic and (perhaps obsessively!) organized. ")#link("http://statweb.stanford.edu/~adembo/stat-310a/lnotes.pdf")[#text("http://statweb.stanford.edu/~adembo/stat-310a/lnotes.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/871040c82487f03db8a7b00ff22aaff4886ae7e42fb436f9d0733b2b99c76859-f45a2a76efc83a92e8ae36eeadd82add91c46e956d7b39d7d1ddd05845d082a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-468915")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Thanks for the post. In relating to Terry’s definition of random matrices, does anybody know what is the best way to define a random matrix when its shape is also random variable? For instance, if A is random matrix such that A: Omega -> {space of matrices with m rows}. Thus A maps to the space of matrices with m rows, but the number of columns is itself a random variable. Is there a common way to construct of such a random matrix?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-483707")[#strong[#text("Making Probability Mathematical | Infinite Series")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")]

#text("[…] 254A, Notes 0: A review of probability theory Kolmogorov – Foundations of the Theory of Probability Ian Hacking – The Emergence of Probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/def4db8f5e585bbee405aa6461fe7100bda88281f73596124269cdd33244798c-79432b8bf89d0dc5fa6e0d915a511c4020057fef642ec56a1e9db4a77115faa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mateo Wirth")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-489106")[#strong[#text("Mateo Wirth")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2017")])]

#text("I am having trouble with the definition of a disintegration given above. In particular, without the condition that for any measurable subset S of R, letting E be the event that Y is in S, we have")#linebreak()#text(" ")#mi("P(F \\wedge E) = E P(F|Y) I(Y \\in S),")#linebreak()#text(" I can’t seem to conclude that")#linebreak()#text(" ")#mi("P(F| Y = y) = P(F \\wedge E | Y = y) \\quad \\forall y \\in S")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/def4db8f5e585bbee405aa6461fe7100bda88281f73596124269cdd33244798c-79432b8bf89d0dc5fa6e0d915a511c4020057fef642ec56a1e9db4a77115faa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mateo Wirth")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-489107")[#strong[#text("Mateo Wirth")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2017")])]

#text("Nevermind I see how it works now. Sorry!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-512540")[#strong[#text("The probability space as a fiction | Hydrobates")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")]

#text("[…] search starting from this suspicion let me to an enlightening blog post of Terry Tao called ‘Notes 0: A review of probability theory‘. There he reviews ‘foundational aspects of probability theory’. Fairly early in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-513075")[#strong[#text("What's the meaning of \"random\" in Mathematics? | Page 2 | Physics Forums")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")]

#text("[…] measure space; we will return to this point when we discuss free probability later in this course. ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]#text(" so for starting out: why not focus on probabilistic concepts as opposed to representation in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-519286")[#strong[#text("Making Probability Mathematical | Infinite Series - دکتر تیز")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")]

#text("[…] 254A, Notes 0: A review of probability theory Kolmogorov – Foundations of the Theory of Probability Ian Hacking – The Emergence of Probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-528570")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] In these notes we presume familiarity with the basic concepts of probability theory, such as random variables (which could take values in the reals, vectors, or other measurable spaces), probability, and expectation. Much of this theory is in turn based on measure theory, which we will also presume familiarity with. See for instance this previous set of lecture notes for a brief review. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-532491")[#strong[#text("Is there a category consisting of probability spaces as objects and measurable functions as morphisms? – Lofgren's financial decisions")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2019")]

#text("[…] this post, Terance Tao writes ”probability theory is only ‘allowed’ to study concepts and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-572510")[#strong[#text("Server Bug Fix: Categorification of probability theory: what does a “probability sheaf” tell us (if anything) about probability theory? - TECHPRPR")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")]

#text("[…] If you’re interested in this field, I think you will want to read these references (plus the blog post by Tao that Simpson cites), and you may need to give it time before super compelling applications […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-617194")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2021")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I am an undergraduate student majoring in mathematics, and I really enjoyed the way you explained the “probabilistic way of thinking” and ideas of conditioning on events or extending the sample space in a way far better than most introductory texts that I’ve read. (Although most of this article went over my head). I would be really grateful if you could suggest some references/ lecture notes written in a similar style, which are more suited to an undergraduate looking to learn probability theory.")#linebreak()#text(" Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-635694")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] material in this set of notes presumes some prior exposure to probability theory. See for instance this previous post for a quick review of the relevant […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-691854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2026")])]

#text("Dear Prof. Tao,")

#text("In the examples of Definition 3, why would you define most examples (say, real-valued random variables) equipped with Borel σ-algebras instead of other types of σ-algebras?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-691858")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2026")])]

#text("See ")#link("https://gemini.google.com/share/e6e2d21bb8d1")[#text("this previous (AI-generated) answer")]#text(" to a similar question.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-692023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2026")])]

#text("Dr Tao,")

#text("…")#emph[#text("one can define the expectation or mean EX")]#text("…")

#text("According to the definition of the expectation, isn’t EX a weighted mean? Why would you set EX as a (unweighted) mean?")

#emph[#text("[In these notes, means are allowed to be weighted; we do not assign unweighted means any distinguished status. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-692596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2026")])]

#text("Dr Tao, I am not sure what you mean by “Cauchy distributions are typical examples of ")#emph[#text("heavy-tailed")]#text(" distributions”—— It seems that this is the first time you introduce the term “heavy tail” in this note and didn’t define it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-693142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2026")])]

#text("Are there any reasons that you didn’t use the cumulative distribution function to bound tail events in this set of notes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-2/#comment-693149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2026")])]

#text("The cumulative distribution function is only available for real scalar random variables. In many applications (including random matrix theory), one wants to consider tails of complex, vector-valued, or matrix-valued random variables, for which the cdf is an inappropriate tool.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb6305e23eaf822e424962ab8e88eb23f0fd05caacea095efb8678a5b9153d99-f74320c2611d5263f8a08426e6c11e9a43d2aacf9dc73313b6aede7ce1c97431.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louigi")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43046")[#strong[#text("Louigi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("Nice notes! Just after Exercise 20, there is a ")#mi("\\mathbf{P}(Y=y)")#text(" that should probably be a ")#mi("\\mathbf{P}(F|Y=y)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43051")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")]

#text("[…] 254A, Notes 0: A review of probability theory In preparation for my upcoming course on random matrices, I am briefly reviewing some relevant foundational aspects […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a10c163e634cc43e2995fdce39a0040ded2ce9debaa48ee9a1396cabded53d-e2729b491f49bf837a7c4b5153d140d602bd4dd7a2258a0b475deeb0c306e225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43052")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("In Exercise 23 (v), is the condition that ")#mi("{X_n}")#text(" has a tight sequence of distributions superfluous? Because, given that ")#mi("{\\mu_{X_n}}")#text(" is convergent in the weak-* topology, ")#mi("{\\mu_{X_n}}")#text(" is tight automatically. Maybe I missed something here…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("A weak-* convergent sequence of probability measures is tight if and only if its limit is again a probability measure. If there is loss of mass (consider for instance the uniform distributions on [n,n+1] as ")#mi("n \\to \\infty")#text(") then one has weak-* convergence to a non-probability measure (zero, in the above example) and lack of tightness.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a6624e705763925508f46e3d38ec953f2efc604be36fd34b788db30e8e7bffc-c3de01e711f6c8b35607da8453c920eb93a92e89f0b45a450b864b43ca866bb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of man")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43053")[#strong[#text("man")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("Just after eq. 13, should ")#mi("{\\lambda {\\bf I}(X \\leq \\lambda) \\leq X}")#text(" be ")#mi("{\\lambda {\\bf I}(X \\geq \\lambda) \\leq X}")#text(" ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43054")[#strong[#text("links for 2010-01-02 « Blarney Fellow")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")]

#text("[…] 254A, Notes 0: A review of probability theory « What’s new (tags: probability math) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cec63be731542236f25e1cb4a7d42c9e3ecf844a2bc6f14f1d6dda0602dd4f9f-c2fb5af9a52260ed0c42c0258ed193f17f05833511f60dc48be715542e63548d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43062")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("I noticed the RSS feed for this post didn’t show up in Google Reader (for me anyway). I’m not sure if other people using Google Reader have the same problem. I also wonder if there are other posts I’ve missed because Google Reader skipped them. I know you don’t have any control over this, but I thought I’d let you know.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feb593303ec39774672ffcf06af43c4117e3d372358c523332eeff6551e43dba-56854b7a10c2ec220bfd61566bb4a1a8f38a7408aaac97688282048079cbd643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hassan Mohy-ud-Din")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43063")[#strong[#text("Hassan Mohy-ud-Din")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("Greetings Professor Terence Tao")

#text("Thank You for the notes. Are these notes available in pdf format. Thanking you in anticipation.")

#text("With Profound Regards")

#text("Good Bye")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a10c163e634cc43e2995fdce39a0040ded2ce9debaa48ee9a1396cabded53d-e2729b491f49bf837a7c4b5153d140d602bd4dd7a2258a0b475deeb0c306e225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of salazar")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43065")[#strong[#text("salazar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("In the definition of subgaussianness and subexponential tail, it might be more convenient to replace ")#mi("{\\bf P}(X \\geq \\lambda)")#text(" by ")#tao-math("{\\bf P}(\\left|X\\right| \\geq \\lambda)", block: false)#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43066")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("Jason,")

#text("I think this is not Google Reader, but WordPress. This post did not show up on my RSS reader different than Google’s. I noticed it quite a few times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab534a8f210b7cf9df4446d8db37ac4c66c9daafd983558d524c978586bd377-240112ddbb705ed9e4227fe8af6e34f039e5a6a1a89b991de7041335fc3c4c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43067")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("A few typos?–")

#text("“is absolutely continuous of”")#linebreak()#text(" of -> if")#linebreak()#text(" Exercise 18")#linebreak()#text(" want ")#mi("Y_{\\beta}")#text(" with distribution ")#mi("\\mu_{\\beta}")#text(" ?")#linebreak()#text(" Exercise 19, Eq. 33")#linebreak()#text(" ")#mi("\\mu_{X|\\overline{E}}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Concentration of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43071")[#strong[#text("254A, Notes 1: Concentration of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("[…] the Borel-Cantelli lemma (Exercise 1 from Notes 0), we see that we will be done as long as we can choose such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ñie")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43081")[#strong[#text("Ñie")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2010")])]

#text("In the joint random variable example should")

#text("$ (X_1, X_2)(\\omega) = (X_1(x), X_2(\\omega)) $ for every $x \\in \\Omega $")

#text("be")

#text("$ (X_1, X_2)(\\omega) = (X_1(\\omega), X_2(\\omega)) $ for every $\\omega \\in \\Omega $ ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ñie")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43085")[#strong[#text("Ñie")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("there is stiil an error in ")#mi("x \\in \\Omega")#text(" part. It should be ")#mi("\\omega \\in Omega")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43087")[#strong[#text("pavel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Dear Professor Tao,")#linebreak()#text(" thanks in particular for the illuminating exercises! Some remarks:")

#text("Isn’t the identity on [-1 , -0.5] \\cup [0.5 , 1] with Lebesgue measure a counterexample to uniqueness in Exercise 7?")

#text("I also think that in Definition 10 (convergence in probability) lim sup should be a lim inf.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43088")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Dear Prof. Tao,")

#text("It seems the Lemma 5 is not correct.")

#text("The (ix) of Ex 23 seems also true for the convergence in distribution sense, since the underlying sample space is not involved.")

#text("I don’t understand why (27) needs the condition ")#mi("a>1")#text(".")

#text("I also don’t know how to obtain an counterexample for the case when ")#mi("l=0")#text(" in (vi) of Ex 25.")

#text("Thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43095")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Thanks for the corrections!")

#text("The condition a > 1 is needed to ensure that exp(t|X|) is absolutely integrable.")

#text("For exercise 25(vi), consider the uniform distribution on the unit circle. More generally, note that if an (absoutely integrable) complex random variable is invariant under multiplication by ")#mi("e^{2\\pi i \\theta}")#text(" for any ")#mi("\\theta")#text(" not a k^th root of unity, then its k^{th} moment vanishes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43106")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("A minor detail: in the definition of modes of convergence, the link for sigma-compact space actually links to Fatou’s lemma on Wikipedia.")

#text("Thanks for the great notes! –Jason")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43112")[#strong[#text("254A, Notes 2: The central limit theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("[…] (ii) is immediate from (6) and the definition of convergence in distribution (see Definition 10 of Notes 0), since the function is bounded […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079cb57937093f8327931689e37fbb2200cfc232528e21aa0977888321d71bc7-f2117a98624bb427e54718daad39bba5d3b2ff5987d9b7ab60f6a074ea3be262.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43118")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Dear Prof. Tao,")

#text("Thanks very much for these notes,they are as always brilliant.")

#text("Regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43128")[#strong[#text("ANDREWYAKOVLEV")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")]

#text("[…] A review of probability theory In preparation for my upcoming course on random matrices, I am briefly reviewing some relevant foundational aspects of probability theory, as well as setting up basic probabilistic notation that we will be using in later posts. This is quite basic material for a graduate course, and somewhat pedantic in nature, but given how heavily we will be relying on probability theory in this course, it seemed appropriate to take some time to go through these issues carefully. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("in the following sentence")

#text("”the event that the roll of a die gives ")#mi("\\{4\\}")#text(" has cardinality one in the sample space ")#mi("{\\{1,\\ldots,6\\}}")#text(", but has cardinality six in the sample space ")#mi("{\\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\}}")

#text("I think that it should be 12 not 6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Actually, it is 6. I have modified the text to emphasise that we are talking about the event that the roll of a _given_ die is 4, not that at least one of the dice being rolled is equal to 4; the latter event is not preserved under extensions that increase the number of dice being rolled (and in any case, the latter event would have cardinality 11 rather than 12 in the sample space ")#mi("\\{1,\\ldots,6\\} \\times \\{1,\\ldots,6\\}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Dear Prof. Tao,")

#text("in the proof of lemma 4 we need to show the existence of a probability space on which a random variable has the given distribution.")

#text("in the proof, it is not obvious what the ")#mi("{\\Omega }")#text(" is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#mi("\\Omega")#text(" is the ambient sample space, which is always assumed to be present whenever we are doing anything with probability theory, and is extended as necessary whenever we introduce more random variables; see the second paragraph of Section 1. (One could explicitly mention “Let ")#mi("\\Omega")#text(" be a probability space, with respect to which all random variables mentioned here take as a domain, and all events are measurable in” in the statement of every single lemma and theorem in this course, or in any other text using probabilistic methods, but this would be very tedious, not to mention quite counter to the “probabilistic way of thinking” in which one tries to suppress mention of the sample space as much as possible.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-625080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2021")])]

#text("I have two follow-up questions:")#linebreak()#text(" 1. Does a statement like this requires a proof, especially when the collection of random variables at scope is too big? “Let \\Omega be a probability space, with respect to which all random variables mentioned here take as a domain, and all events are measurable”")#linebreak()#text(" 2. Is the following approach a valid proof and a preferred one? Take (R, \\cal{R}) to be the underlying sample space and take the identity function to be the mapping. If it is a valid but less preferred proof, is it because we should always try to avoid using “concrete space” as the probability space? If it is an invalid proof, why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-625207")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("1: Yes, strictly speaking if one wanted to expand out all the details in a probabilistic argument one would actually have to construct a probability space model ")#mi("\\Omega")#text(" at some point, although in practice tools such as Exercise 18 in these notes are more than sufficient to give such constructions.")

#text("2: This would be a valid approach if one was studying just a single random variable ")#mi("X")#text(" taking values in ")#mi("R")#text(", together with functions ")#mi("f(X)")#text(" of that variable. However it runs into difficulty if at any future point one encounters another source of randomness that is not simply a function of one’s original random variable ")#mi("X")#text(" (this situation already occurs in Example 1). It is at this point that the flexibility to work in a (largely unspecified) sample space that one is free to extend whenever necessary becomes very convenient.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The operator norm of a random matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43154")[#strong[#text("254A, Notes 3: The operator norm of a random matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("[…] we sparsified, it is now safe to apply the Borel-Cantelli lemma (Exercise 1 of Notes 0), and it will suffice to show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43158")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Great notes! I second the request of making them available in pdf, although they already print rather neatly from wordpress.")

#text("By the way, for probability and expectation, you use in some places boldface ")#mi("\\bf P")#text(", ")#mi("\\bf E")#text(", and in some places mathbb ")#mi("\\mathbb P")#text(", ")#mi("\\mathbb E")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Luca: thanks for pointing out the notational inconsistency! (I decided to switch to boldface here, as it seems to be a bit more legible in the blog format.)")

#text("I collate the blog files every year into a PDF file; I am working on the 2009 files right now and should have a draft file ready in the near future. Unfortunately, this means that one has to wait for the maximum possible time before this particular post will be converted. (By a strange coincidence, I had almost the exact same question for the ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("Notes 0 article on 1 January 2009")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-625213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("Dear Prof. Tao:")

#text("Where can I find the PDF file? Do you do this every year for all your blog posts?")

#emph[#text("[ See ")#link("https://terrytao.wordpress.com/books/topics-in-random-matrix-theory/")[#text("https://terrytao.wordpress.com/books/topics-in-random-matrix-theory/")]#text(" -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b172191ae1216757d5e6f19f334cf3827e607380bff0384ee8419016e2dba4d-33bc6fdd89980c1ff1f0fc18668cf2888853d2304d8aba987358f696038b7956.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pashupati")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43160")[#strong[#text("Pashupati")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("An article I can somewhat barely understand, at least!")#linebreak()#text(" How do you convert those into PDF files? Could anybody help?")

#text("And, well, thank you for all those great articles!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rnd_idt")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43168")[#strong[#text("rnd_idt")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Simply wait until more or less march 2011 and you will get your PDF. In the meantime, print wordpress, it’s not that bad.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361a04950475a41037ec565251c0e2c3286072d70467ca68caf07545c2a4334-83f82a5769ac964a883555046c8486b4350c09066749cf7b896745022888e9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CY")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43191")[#strong[#text("CY")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("You can download and install free Primo PDF converter from the site")#linebreak()#text(" ")#link("http://www.primopdf.com/index.aspx")[#text("http://www.primopdf.com/index.aspx")]#linebreak()#text(" Then, you just print this page using Primo PDF to get a pdf file.")

#text("It works for me, hope it works for u guys too :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("I have downloaded that programme but could not figure out how it works.")#linebreak()#text(" Dear CY, could you explain it?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361a04950475a41037ec565251c0e2c3286072d70467ca68caf07545c2a4334-83f82a5769ac964a883555046c8486b4350c09066749cf7b896745022888e9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CY")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43208")[#strong[#text("CY")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("Just print this page by selecting Primo PDF as the name of ‘printer’.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43195")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("I am a bit surprised by statement in exercise 15 mentioning that for $k>2$, the converse statement fails. If I recall correctly the definition of the k-fold product measure, once we specify the pre-measure on the boxes which is basically done in formula (28), then we get a measure that agrees with the joint distribution measure on the algebra of finite unions of boxes (which generates the full $\\sigma-$algebra.) Am I missing something, or does the reason lie somewhere else?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")])]

#text("There is a subtle difference between (28), (29) and the construct of product measure, having to do with quantifiers.")

#text("You may like to think about the k=3 case first. If you know that ")#mi("{\\bf P}(E_1 \\wedge E_2 \\wedge E_3) = {\\bf P}(E_1) {\\bf P}(E_2) {\\bf P}(E_3)")#text(" and ")#mi("{\\bf P}(E_1 \\vee E_2 \\vee E_3) = 1-(1-{\\bf P}(E_1)) (1-{\\bf P}(E_2)) (1-{\\bf P}(E_3))")#text(", does this imply that ")#mi("E_1, E_2, E_3")#text(" are jointly independent?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43198")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e101v1")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2010")]

#text("[…] Considering probability. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43270")[#strong[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] existence of such a collection, after extending the sample space, is guaranteed by Exercise 18 of Notes 0.) If we then […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43294")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("I am confused about the existence of random variables. For concreteness fix $\\Omega =[0,1]$. Now a real-valued random variable is merely a real valued function on $\\Omega$. Let us specify that the random variable $f(x)$ has a Gaussian distribution. Now there is a natural choice for $f(x)$. It isn’t hard to see that I can take $f(x)$ to be a monotonically increasing function such that $f(0)=-\\infty$,$f(1)=\\infty$. However, does there exists another random variable $g(x)$, that is independent and identically distributed? It seems the answer is ‘no’, since once I know the value of $f(\\omega)$ at some choice of $\\omega \\in \\Omega$, I know $\\omega$ and hence I know $g(\\omega)$.")

#text("If I understand this correctly, your proof (exercise 18) that independent identically distributed Gaussian random variables exist may require that you change the underlying probability space $\\Omega$. This leads to the following question. Do two independent Gaussian random variables exist on $[0,1]$? If so, is it possible to explicitly describe such a pair?")

#text("Any comments that can clear up these general issues would be appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("Well, one can use a space-filling curve to map [0,1] to ")#mi("[0,1]^2")#text(", and if one does it correctly one can even make the map measure preserving. (e.g. expand [0,1] in base 2 as infinite binary strings, and separate the even and odd binary strings to create a point in ")#mi("[0,1]^2")#text("). So one can create two or even countably many variables on the unit interval if one wishes, provided one had enough foresight to do so before starting whatever argument one is working with.")

#text("I prefer, though, to just keep extending the probability space whenever necessary, since probability theory is designed to be invariant under this extension operation anyway (see the discussion in Section 1). This way, one does not need to know in advance all the random variables are going to be used in one’s arguments. (To put it more informally: I like to reserve the right to roll more dice whenever I want to.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43326")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2010")])]

#text("Out of curiosity, is it really a good idea to require in your definition of an extension that $\\Omega’ \\to \\Omega$ be surjective? Why not permit it to miss a set of points of measure 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43327")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2010")])]

#text("My reason for this is that I want to have both “almost surely true” and “surely true” as probabilistic notions. If an extension misses a set of measure zero, then an event which was almost surely, but not surely, true, could become surely true upon taking an extension.")

#text("This is not a big deal, of course; for most applications in probability theory there is no significant distinction between almost sure and sure, but I like being able to embed classical logic in probabilistic logic :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7b13a1e6b50eb93a9356815c07b23dd956334b0932a76d24260bd445694836-58e61592e4981467e5a9ff9a216982a847918963283b62463a359ecad5880d19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Steinberger")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-466419")[#strong[#text("John Steinberger")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2016")])]

#text("Not to be annoying or anything, but are there any applications where the distinction between almost sure and sure plays a role?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-466427")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")])]

#text("Well, the fact that many results in probability theory (or ergodic theory, or measure theory) are restricted to the almost sure setting, rather than the sure setting, precludes some deterministic applications. For instance, it is a long-standing conjecture that the digits of ")#mi("\\pi")#text(" are uniformly distributed. It is easy to show that a random number drawn uniformly from, say, the interval $[3,4]$ will almost surely have uniformly distributed digits, but this unfortunately does not tell us anything about the specific number ")#mi("\\pi")#text(" because the event that the random number drawn is equal to ")#mi("\\pi")#text(" has probability zero.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7b13a1e6b50eb93a9356815c07b23dd956334b0932a76d24260bd445694836-58e61592e4981467e5a9ff9a216982a847918963283b62463a359ecad5880d19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Steinberger")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-466522")[#strong[#text("John Steinberger")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2016")])]

#text("Thanks! (By the way there appears to be a typo in the mean of a geometric random variable, which is $(1-p)/p$ not $p$. Also, if the range of the geometric r.v. is changed to $\\{1, 2, \\ldots \\}$ the mean is a prettier $1/p$.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Dear Prof. Tao,")

#text("If a random variable is uniform (or has any other distribution) on a bounded set, isn’t it surely bounded (and not just a.s. bounded)? (This of course is not too important probabilistically, I am just curious.)")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("The distribution ")#mi("\\mu_X")#text(" of a random variable X only gives the probability that X lies in various sets, but cannot force X to lie in a set ")#emph[#text("surely")]#text(". For instance, if we took a uniform distribution on [0,1] and modified it on an event of probability zero to equal 2 (say) on that event, then the new random variable Y would still be considered to have the uniform distribution on [0,1], since ")#mi("\\mu_Y(S) := {\\Bbb P}(Y \\in S)")#text(" is still given by Lebesgue measure on [0,1].")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54f789394cdc73117c8bd8606a521c60faf3863b3963d38f364a938f0fc50baf-da9f8172f9c8612790c62ec1c6d4da8e294275d358200a4af26b860c5d79e838.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitry Karpeev")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43380")[#strong[#text("Dmitry Karpeev")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Prof. Tao,")#linebreak()#text(" If I understand it correctly, Exercise 18 is equivalent supplying a proof of the existence of a probability measure on a suitable infinite product space, which reduces to a given probability measure \\mu_\\beta when restricted to the factor with index \\beta. Is this so, or can the result of Exercise 18 be established by more elementary means?")

#text("Thank you!")#linebreak()#text(" Dmitry.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Yes, the ability to construct arbitrarily many independent random variables with specified distribution in probability theory is essentially equivalent to the ability to construct product measures in measure theory.")

#text("In the case when the desired random variables are real-valued, and there are at most countably many of them, one can use more ")#emph[#text("ad hoc")]#text(" but concrete methods (e.g. using a uniform distribution on [0,1] and converting into binary to create an infinite stream of bits, and subdividing them to create as many sources of randomness as necessary) to create the random variables.")

#text("One can also proceed via the Caratheodory extension theorem or Kolmogorov extension theorem in many cases (but this is how product measure is usually constructed anyway; another approach is via the Riesz representation theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43418")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("typo: in the real normal distribution example there’s a 2 missing in the denominator of the exponent, next to ")#mi("\\sigma^2")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43428")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] of the reals as much as possible. Similarly for other rows of the above table. See for instance lecture notes of mine for further discussion of the distinction between measure theory and probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43461")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] we consider the behaviour of the ESD of a sequence of Hermitian matrix ensembles as . Recall from Notes 0 that for any sequence of random variables in a -compact metrisable space, one can define notions of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("Section 1, paragraph 1, line -1: “will will” -> “will”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43562")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] as possible, and with the random variables and expectations being viewed as derived concepts. See Notes 0 for further discussion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43650")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("typo: in Definition 1. first occurrence of ")#mi("Y \\ll X")#text(" should be ")#mi("Y \\gg X")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17a45f600ae1b532fe6ce8f4e892e5c3c7324cbda6ad9ea5fb5e188978840d4c-fb1676a43c46477da21b35b228d04837a18a861ddf1b12314965045266e7811c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Afonso")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43684")[#strong[#text("Afonso")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("Dear Prof. Tao")

#text("I don’t think I fully understand the meaning of ")#tao-math("\\left|X_n\\right|=O(1)", block: false)#text(" with probability greater than p.")

#text("Does it mean that there exists a constant C such that for every n")#linebreak()#text(" ")#tao-math("\\left|X_n\\right|\\leq C", block: false)#text(" with probability larger than p.")

#text("Or does it mean that if we consider the whole sequence as a random variable (a stochastic process) the output sequence is O(1) with probability greater than p?")

#text("It is not clear to me whether the two are equivalent.")

#text("Thank You,")#linebreak()#text(" Afonso")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("I am using “For all ")#mi("n")#text(", ")#tao-math("\\left|X_n\\right| \\leq C", block: false)#text(" with probability at least ")#mi("p")#text("” to denote the statement ")#tao-math("\\forall n {\\bf P}(\\left|X_n\\right| \\leq C) \\geq p", block: false)#text(", with the (much) stronger statement ")#tao-math("{\\bf P}(\\forall n \\left|X_n\\right| \\leq C) \\geq p", block: false)#text(" being denoted instead by “With probability at least ")#mi("p")#text(", one has ")#tao-math("\\left|X_n\\right| \\leq C", block: false)#text(" for all ")#mi("n")#text("“.")

#text("In most cases, the universal quantification over ")#mi("n")#text(" appears very early in a statement or argument (or is implicit in phrases such as “let n be an integer parameter”), and so one usually is referring to the first type of bound. The second type usually only comes up in this course in discussions of almost sure convergence, and is usually derived from estimates of the first type using the union bound or the Borel-Cantelli lemma (perhaps after first sparsifying n to a lacunary sequence).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59f3eac555b05114508945a4f3eefb422a6d3d643794de770bc5e5a57e5d05ed-76c3c97f65c7aabe1ee51c3090728ea5fade1ea590050db1d08df67181ae4bc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Watson")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43729")[#strong[#text("Sam Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2010")])]

#text("In Exercise 4 (the first part), I think that a mean-zero condition on the random variables is required. Consider the random variable which is almost surely equal to 1. It is subgaussian according to the definition given, since the indicator of [0,1] is dominated by a scalar multiple of a gaussian. On the other hand, there is no C for which the inequality in Exercise 4 will be true, since the identity function on the reals is not dominated by any parabola with vertex at the origin.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2010")])]

#text("Ah, right, I was missing an additional factor of C in front of the ")#mi("\\exp(Ct^2)")#text(" factor. I think I’ve fixed the issue now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("In Definition 10, it should be liminf instead of limsup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("If X_n converges in probability to X , show that there is a subsequence of the which converges almost surely to X.")

#text("ANy hint or reference to this result, I could not figure it out…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-43880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("Find a subsequence ")#mi("X_{n_j}")#text(" so that ")#tao-math("\\sum_j {\\bf P}( \\left|X_{n_j} - X\\right| \\geq \\varepsilon ) < \\infty", block: false)#text(" for every ")#mi("\\varepsilon")#text(", then apply the Borel-Cantelli lemma.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-47273")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("[…] objects of study of that theory, namely the behaviour of random events and random variables. (See this post for further discussion of this point.) This course will not be focused on applications to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6da0ce2b0589fe8a35b4fd1ed0383f44d268ff4b98575ec4e732457fc724f6f6-6cbd2318eaeeeabb0ae62eb31c999e148aa2e0bed374690aad4ff228578390cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-48253")[#strong[#text("Guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("Dear Prof. Tao,")

#text("I’m a bit puzzled by Exercise 25 (v) [if a sequence of uniformly sub-exponential r.v. converges in moments, then it converges in distribution], since I have the impression that sub-exponential is not a strong enough property to be determined by the moments ; for example there are counterexamples to the moments problem with density $\\latex \\exp(-|x|^{1/2+o(1)})$. Did I miss something ?")

#emph[#text("[Ah, I had omitted the requirement that the exponent is at least 1. Thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6da0ce2b0589fe8a35b4fd1ed0383f44d268ff4b98575ec4e732457fc724f6f6-6cbd2318eaeeeabb0ae62eb31c999e148aa2e0bed374690aad4ff228578390cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-48264")[#strong[#text("Guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("OK, I see !")

#text("How do you prove this using truncation and the Weierstrass approximation theorem? My impression is that you need some quantitative information, such as the speed of convergence in the Weierstrass approximation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-48268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("Hmm, good point; the argument I had in mind would indeed require a quantitative version of the Weierstrass approximation theorem. I guess for the purposes of this exercise it is probably best to just handle the uniformly bounded case.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6edc5906596ae65ea8c8bb859f6168c37dbbe035beb2e1f3d13e7f09cff7a5b2-b50fccbeee9b177d94951770e2a857a446acbc1052cb53a03ab822702563e86a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noam Zeilberger")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-108931")[#strong[#text("Noam Zeilberger")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("typo in Proof of Lemma 4? “the product measure ")#mi("P\\times\\mu")#text(" on $R$” should be “the product measure ")#mi("P\\times\\mu")#text(" on ")#mi("\\Omega \\times R")#text("”")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-120121")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2012")])]

#text("Dear Prof Tao,")

#text("This introductory to probability theory does a great job of clarifying the distinction of probability theory from the theory of finite measures. Do any other authors that you know of make as explicit the notion of invariance under extensions?")

#text("By the way, like a previous commenter, I too thought that excluding surjectivity from the definition of extension would be a neat way of making “almost surely” a more intrinsic part of the theory. Remark 1 is simplified in this situation, because all random variables would be only almost surely defined. Conditioning is also somewhat unified with extending, because then ")#mi("\\Omega_y")#text(" is an extension of ")#mi("\\Omega")#text(" with respect to the probability measure ")#mi("{\\bf P}(| Y = y)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-130395")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2012")])]

#text("Small typo: Exercise 9 reads")

#text("“Show that the {(X_\\alpha)_{\\alpha \\in A}} are jointly independent if and only for every…”")

#text("Of course, this should say “if and only if”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-130396")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2012")])]

#text("Also, Exercise 10 has the typo “subsapce”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A cheap version of nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-136451")[#strong[#text("A cheap version of nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2012")])]

#text("[…] To set up cheap nonstandard analysis, we will need an asymptotic parameter , which we will take to initially lie in the natural numbers (though it is certainly possible to set up cheap nonstandard analysis on other non-compact spaces than if one wishes). However, we reserve the right in the future to restrict the parameter space from to a smaller infinite subset (which corresponds to the familiar operation of passing from a sequence to a subsequence, except that we do not bother to relabel the subsequence to be indexed by again). The dynamic nature of the parameter space makes it a little tricky to properly formalise cheap nonstandard analysis in the usual static framework of mathematical logic, but it turns out not to make much difference in practice, because in cheap nonstandard analysis one only works with statements which remain valid under the operation of restricting the underlying domain of the asymptotic parameter. (This is analogous to how in probability theory one only works with statements which remain valid under the operation of extending the underlying probability space, as discussed in this blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cea473f6dce32344586cb43a2e5c6b324b4b16796140d2fcffbb09a3f331a854-3c6f8526e5af25760af25f333c2a929ace8dd90569f1e4ede2b6ae6481195530.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Musfir")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-136671")[#strong[#text("Musfir")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("Reblogged this on ")#link("http://geekmusfir.wordpress.com/2012/04/04/171/")[#text("Geekmusfir")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-137744")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Given two (or more) independent random variables ")#mi("X, Y")#text(", can we always lift the sample space ")#mi("\\Omega")#text(" to some ")#mi("\\Omega^{\\prime}")#text(" which can factored as a product ")#mi("\\Omega^{\\prime} = A \\times B")#text(" of measure spaces (with product measure) such that ")#mi("X")#text(" is defined on ")#mi("A")#text(" and ")#mi("Y")#text(" is defined on ")#mi("B")#text("?")

#text("The definition of independence ensures that we can do this for the corresponding distributions, but can we do it directly on the sample space?")

#text("As an informal guideline, if we pretend that the sample space breaks into a product measure space whenever we see independent random variables, will we ever get into trouble while working in probability?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-137767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Yes, this should be true (at least under some mild assumptions on the sigma algebras involved (e.g. if all the underlying spaces are standard Borel), so that tools such as disintegration become available. But one should caution that the product structure may not be canonical or unique. For instance, Example 3 above can be given three different product structures, each of which makes two of the three variables ")#mi("x_1,x_2,x_3")#text(" manifestly independent, but the three structures are not compatible with each other. So it is perhaps best not to rely on this viewpoint too strongly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/comment-page-1/#comment-137771")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Do concerns about lack of canonicity or uniqueness with regards to the sample space ever disturb us as probabilists?")

#text("It seems that we de-emphasize the role of the sample space so much that it is not clear to me how its universal properties could play any role in probability.")

#text("My general aim is to grasp better this “probabilistic” way of thinking, in particular to understand in what ways it allows us to replace or modify the sample space without affecting our tools.")
]
]
]
