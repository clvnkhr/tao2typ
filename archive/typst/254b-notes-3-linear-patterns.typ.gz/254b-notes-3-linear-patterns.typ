// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/
// Converted to Typst by tao2typ: "2026-10-14T15:17:44.737826+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 3: Linear patterns", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 3: Linear patterns")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("previous lecture notes")]#text(", we used (linear) Fourier analysis to control the number of three-term arithmetic progressions ")#mi("{a, a+r, a+2r}")#text(" in a given set ")#mi("{A}")#text(". The power of the Fourier transform for this problem ultimately stemmed from the identity")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n,r \\in {\\bf Z}/N^{\\prime}{\\bf Z}} 1_A(n) 1_A(n+r) 1_A(n+2r)")]]

#metadata(none) <tao-67a333356cdc566e6e34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("= \\sum_{\\alpha \\in \\frac{1}{N^{\\prime}}{\\bf Z} / {\\bf Z}} \\hat 1_A(\\alpha) \\hat 1_A(-2\\alpha) \\hat 1_A(\\alpha)")]]

#text("for any cyclic group ")#mi("{{\\bf Z}/N^{\\prime}{\\bf Z}}")#text(" and any subset ")#mi("{A}")#text(" of that group (analogues of this identity also exist for other finite abelian groups, and to a lesser extent to non-abelian groups also, although that is not the focus of my current discussion). As it turns out, linear Fourier analysis is not able to discern higher order patterns, such as arithmetic progressions of length four; we give some demonstrations of this below the fold, taking advantage of the polynomial recurrence theory from ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(".")

#text("The main objective of this course is to introduce the (still nascent) theory of ")#emph[#text("higher order Fourier analysis")]#text(", which is capable of studying higher order patterns. The full theory is still rather complicated (at least, at our present level of understanding). However, one aspect of the theory is relatively simple, namely that we can largely reduce the study of arbitrary additive patterns to the study of a single type of additive pattern, namely the ")#emph[#text("parallelopipeds")]#text(" ")#metadata(none) <tao-a1453f380fa9f1a08e84>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("( x + \\omega_1 h_1 + \\ldots + \\omega_d h_d )_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}}.")]]

#text("Thus for instance, for ")#mi("{d=1}")#text(" one has the ")#emph[#text("line segments")]#text(" ")#metadata(none) <tao-a4187fd9cf8f7b9e93ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x, x+h_1")]]

#text("for ")#mi("{d=2}")#text(" one has the ")#emph[#text("parallelograms")]#text(" ")#metadata(none) <tao-6c4d9f073fb5b6bbeea0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("x, x+h_1, x+h_2, x+h_1+h_2,")]]

#text("for ")#mi("{d=3}")#text(" one has the ")#emph[#text("parallelopipeds")]#text(" ")#metadata(none) <tao-7799fa2bbf74a430834b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("x, x+h_1, x+h_2, x+h_3, x+h_1+h_2, x+h_1+h_3, x+h_2+h_3, x+h_1+h_2+h_3.")]]

#text("These patterns are particularly pleasant to handle, thanks to the large number of symmetries available on the discrete cube ")#mi("{\\{0,1\\}^d}")#text(". For instance, whereas establishing the presence of arbitrarily long arithmetic progressions in dense sets is quite difficult (Szemerédi’s theorem), establishing arbitrarily high-dimensional parallelopipeds is much easier:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{A \\subset [N]}")#text(" be such that ")#tao-math("{\\left|A\\right| > \\delta N}", block: false)#text(" for some ")#mi("{0 < \\delta \\leq 1}")#text(". If ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", show that there exists an integer ")#mi("{1 \\leq h \\ll 1/\\delta}")#text(" such that ")#tao-math("{\\left|A \\cap (A+h)\\right| \\gg \\delta^2 N}", block: false)#text(". (")#emph[#text("Hint:")]#text(" obtain upper and lower bounds on the set ")#mi("{\\{ (x,y) \\in A \\times A: x < y \\leq x + 10/\\delta \\}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Hilbert cube lemma)")]#text(" Let ")#mi("{A \\subset [N]}")#text(" be such that ")#tao-math("{\\left|A\\right| > \\delta N}", block: false)#text(" for some ")#mi("{0 < \\delta \\leq 1}")#text(", and let ")#mi("{d \\geq 1}")#text(" be an integer. Show that if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta,d}")#text(", then ")#mi("{A}")#text(" contains a parallelopiped of the form ")#link(<tao-a1453f380fa9f1a08e84>)[#text("(2)")]#text(", with ")#mi("{1 \\leq h_1,\\ldots,h_d \\ll_\\delta 1}")#text(" positive integers. (")#emph[#text("Hint:")]#text(" use the previous exercise and induction.) Conclude that if ")#mi("{A \\subset {\\bf Z}}")#text(" has positive upper density, then it contains infinitely many such parallelopipeds for each ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that if ")#mi("{q \\geq 1}")#text(" is an integer, and ")#mi("{d}")#text(" is sufficiently large depending on ")#mi("{q}")#text(", then for any parallelopiped ")#link(<tao-a1453f380fa9f1a08e84>)[#text("(2)")]#text(" in the integers ")#mi("{{\\bf Z}}")#text(", there exists ")#mi("{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}}")#text(", not all zero, such that ")#mi("{x + h_1 \\omega_1 + \\ldots + h_d \\omega_d = x \\text{ mod } q}")#text(". (Hint: pigeonhole the ")#mi("{h_i}")#text(" in the residue classes modulo ")#mi("{q}")#text(".) Use this to conclude that if ")#mi("{A}")#text(" is the set of all integers ")#mi("{n}")#text(" such that ")#tao-math("{\\left|n-km!\\right| \\geq m}", block: false)#text(" for all integers ")#mi("{k, m \\geq 1}")#text(", then ")#mi("{A}")#text(" is a set of positive upper density (and also positive lower density) which does not contain any infinite parallelopipeds (thus one cannot take ")#mi("{d=\\infty}")#text(" in the Hilbert cube lemma).")
]

#text("The standard way to control the parallelogram patterns (and thus, all other (finite complexity) linear patterns) are the ")#emph[#text("Gowers uniformity norms")]#text(" ")#metadata(none) <tao-28f1a05a7a09f2d2bdf6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| f\\right\\|_{U^d(G)} := {\\bf E}_{x,h_1,\\ldots,h_d \\in G} \\prod_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}^d} {\\mathcal C}^{\\omega_1+\\ldots+\\omega_d} f(x+\\omega_1 h_1 + \\ldots + \\omega_d h_d)", block: true)]]

#text("with ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" a function on a finite abelian group ")#mi("{G}")#text(", and ")#mi("{{\\mathcal C}: z \\mapsto \\overline{z}}")#text(" is the complex conjugation operator; analogues of this norm also exist for group-like objects such as the progression ")#mi("{[N]}")#text(", and also for measure-preserving systems (where they are known as the ")#emph[#text("Gowers-Host-Kra uniformity seminorms")]#text(", see ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("this paper of Host-Kra")]#text(" for more discussion). In this set of notes we will focus on the basic properties of these norms; the deepest fact about them, known as the ")#emph[#text("inverse conjecture")]#text(" for these norms, will be discussed in later notes.")

#metadata(none) <tao-9c549f0fcc02d09fa50c>

#heading(level: 1)[#strong[#text(" — 1. Linear Fourier analysis does not control length four progressions — ")]]

#text("Let ")#mi("{A \\subset {\\bf Z}/N{\\bf Z}}")#text(" be a subset of a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" with density ")#tao-math("{\\left|A\\right| = \\delta N}", block: false)#text("; we think of ")#mi("{0 < \\delta \\leq 1}")#text(" as being fixed, and ")#mi("{N}")#text(" as being very large or goingn off to infinity.")

#text("For each ")#mi("{k \\geq 1}")#text(", consider the number ")#metadata(none) <tao-3a141a0789d3dc54cbf6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\{ (n,r) \\in {\\bf Z}/N{\\bf Z} \\times {\\bf Z}/N{\\bf Z}: n, n+r, \\ldots, n+(k-1)r \\in A \\}")]]

#text("of ")#mi("{k}")#text("-term arithmetic progressions in ")#mi("{A}")#text(" (including degenerate progressions). Heuristically, this expression should typically be close to ")#mi("{\\delta^k N^2}")#text(". Since there are ")#mi("{N^2}")#text(" pairs ")#mi("{(n,r)}")#text(" and we would expect each pair to have a ")#mi("{\\delta^k}")#text(" “probability” that ")#mi("{n, n+r, \\ldots, n+(k-1)r}")#text(" simultaneously lie in ")#mi("{A}")#text(". Indeed, using standard probabilistic tools such as Chernoff’s inequality, it is not difficult to justify this heuristic with probability asymptotically close to ")#mi("{1}")#text(" in the case that ")#mi("{A}")#text(" is a randomly chosen set of the given density.")

#text("Let’s see how this heuristic holds up for small values of ")#mi("{k}")#text(". For ")#mi("{k=0,1,2}")#text(", this prediction is exactly accurate (with no error term) for any set ")#mi("{A}")#text(" with cardinality ")#mi("{\\delta N}")#text("; no randomness hypothesis of any sort is required. For ")#mi("{k=3}")#text(", we see from ")#link(<tao-67a333356cdc566e6e34>)[#text("(1)")]#text(" and the observaation that ")#mi("{\\hat 1_A(0)=\\delta}")#text(" that ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("N^2 (\\delta^3 + \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}: \\xi \\neq 0} \\hat 1_A(\\xi)^2 \\hat 1_A(-2\\xi) ).")]]

#text("Let us informally say that ")#mi("{A}")#text(" is ")#emph[#text("Fourier-pseudorandom")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\xi \\in {\\bf Z}/N{\\bf Z}: \\xi \\neq 0} \\left|\\hat 1_A(\\xi)\\right| = o(1)", block: true)]]

#text("where ")#mi("{o(1)}")#text(" is a quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". Then from applying Plancherel’s formula and Cauchy-Schwarz as in the previous lecture notes, we see that the number of three-term arithmetic progressions is")

#align(center)[#tao-fit-display[#mitex("N^2 (\\delta^3+o(1)).")]]

#text("Thus we see that the Fourier-pseudorandomness hypothesis allows us to count three-term arithmetic progressions almost exactly.")

#text("On the other hand, without the Fourier-pseudorandomness hypothesis, the count ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" can be significantly different from ")#mi("{\\delta^3 N^2}")#text(". For instance, if ")#mi("{A}")#text(" is an interval ")#mi("{A = [\\delta N]}")#text(", then it is not hard to see that ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" is comparable to ")#mi("{\\delta^2 N^2}")#text(" rather than ")#mi("{\\delta^3 N^2}")#text("; the point is that with a set as structured as an interval, once ")#mi("{n}")#text(" and ")#mi("{n+r}")#text(" lie in ")#mi("{A}")#text(", there is already a very strong chance that ")#mi("{n+2r}")#text(" lies in ")#mi("{A}")#text(" also. In the other direction, a construction of Behrend (mentioned in the previous notes) shows the quantity ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" can in fact dip below ")#mi("{\\delta^C N^2}")#text(" for any fixed ")#mi("{C}")#text(" (and in fact one can be as small as ")#mi("{\\delta^{c\\log \\frac{1}{\\delta}} N^2}")#text(" for some absolute constant ")#mi("{c>0}")#text(").")

#text("Now we consider the ")#mi("{k=4}")#text(" case of ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(", which counts four-term progressions. Here, it turns out that Fourier-pseudorandomness is insufficient; it is possible for the quantity ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" to be significantly larger or smaller than ")#mi("{\\delta^4 N^2}")#text(" even if ")#mi("{A}")#text(" is pseudorandom, as was observed by Gowers (with a closely related observation in the context of ergodic theory by Furstenberg).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{\\alpha}")#text(" be an irrational real number, let ")#mi("{0 < \\delta < 1}")#text(", and let ")#mi("{A := \\{ n \\in [N]: 0 \\leq \\{ \\alpha n^2 \\} \\leq \\delta \\}}")#text(". Show that ")#mi("{A}")#text(" is Fourier-pseudorandom (keeping ")#mi("{\\alpha}")#text(" and ")#mi("{\\delta}")#text(" fixed and letting ")#mi("{N \\rightarrow \\infty}")#text("). ")#emph[#text("Hint:")]#text(" One can use Exercise 21 from ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(" to show that sums of the form ")#mi("{\\mathop{\\bf E}_{n \\in [N]} e(k \\alpha n^2) e(\\xi n)}")#text(" cannot be large.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Continuing the previous exercise, show that the expression ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" for ")#mi("{k=4}")#text(" is equal to ")#mi("{(c \\delta^3 + o(1)) N^2}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", for some absolute constant ")#mi("{c>0}")#text(", if ")#mi("{\\delta > 0}")#text(" is sufficiently small. (")#emph[#text("Hint:")]#text(" first show, using the machinery in ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(", that the two-dimensional sequence ")#mi("{(n,r) \\mapsto (\\alpha n^2, \\alpha (n+r)^2, \\alpha(n+2r)^2, \\alpha(n+3r)^2) \\text{ mod } {\\bf Z}^4}")#text(" is asymptotically equidistributed in the torus ")#mi("{\\{ (x_1,x_2,x_3,x_4) \\in {\\bf T}^4: x_1-3x_2+3x_3-x_4=0 \\}}")#text(".)")
]

#text("The above exercises show that a Fourier-pseudorandom set can have a four-term progression count ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" significantly larger than ")#mi("{\\delta^4 N}")#text(". One can also make the count significantly smaller than ")#mi("{\\delta^4 N}")#text(" (another observation of Gowers), but this requires more work.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{0 < \\delta < 1}")#text(". Show that there exists a function ")#mi("{f: {\\bf T}^2 \\rightarrow [0,1]}")#text(" with ")#mi("{\\int_{\\bf T} f(x,y)\\ dy = \\delta}")#text(" for all ")#mi("{x \\in {\\bf T}}")#text(", such that the expression ")#metadata(none) <tao-73306f7832acfcca7d24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\int_V f(x_1,y_1) \\ldots f(x_4,y_4)")]]

#text("is strictly less than ")#mi("{\\delta^4}")#text(", where ")#mi("{V \\leq ({\\bf T}^2)^4}")#text(" is the subspace of quadruplets ")#mi("{((x_1,y_1),\\ldots,(x_4,y_4))}")#text(" such that ")#mi("{x_1,\\ldots,x_4}")#text(" is in arithmetic progression (i.e. ")#mi("{x_i = x + i r}")#text(" for some ")#mi("{x,r \\in {\\bf T}}")#text(") and the ")#mi("{y_1,\\ldots,y_4}")#text(" obey the constraint")

#align(center)[#tao-fit-display[#mitex("y_1 - 3y_2 + 3y_3 - y_4 = 0.")]]

#emph[#text("Hint:")]#text(" Take ")#mi("{f}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("f(x,y) := \\delta + \\epsilon ( f_1(x) \\cos(2\\pi y) + f_3(x) \\cos(6\\pi y) )")]]

#text("where ")#mi("{\\epsilon > 0}")#text(" is a small number, and ")#mi("{f_1, f_3}")#text(" are carefully chosen to make the ")#mi("{\\epsilon^2}")#text(" term in ")#link(<tao-73306f7832acfcca7d24>)[#text("(8)")]#text(" negative.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that there exists an absolute constant ")#mi("{c>0}")#text(" such that for all sufficiently small ")#mi("{\\delta > 0}")#text(" and sufficiently large ")#mi("{N}")#text(" (depending on ")#mi("{\\delta}")#text(") and a set ")#mi("{A \\subset [N]}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(", such that ")#link(<tao-3a141a0789d3dc54cbf6>)[#text("(7)")]#text(" with ")#mi("{k=4}")#text(" is less than ")#mi("{\\delta^{4+c} N^2}")#text(". (")#emph[#text("Hint:")]#text(" take ")#mi("{\\delta \\sim 2^{-m}}")#text(" for some ")#mi("{m \\geq 1}")#text(", and let ")#mi("{A}")#text(" be a random subset of ")#mi("{[N]}")#text(" with each element ")#mi("{n}")#text(" of ")#mi("{[N]}")#text(" lying in ")#mi("{A}")#text(" with an independent probability of")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^m f( \\alpha_j n \\text{ mod } 1, \\alpha_j n^2 \\text{ mod } 1 ),")]]

#text("where ")#mi("{f}")#text(" is the function in the previous exercise (with ")#mi("{\\delta=1/2}")#text("), and ")#mi("{\\alpha_1,\\ldots,\\alpha_m}")#text(" are real numbers which are linearly independent over ")#mi("{{\\bf Z}}")#text(" modulo ")#mi("{1}")#text(".)")
]

#text("For further discussion of this topic, see ")#link("http://www.juliawolf.org/research/preprints/talk280509.pdf")[#text("these slides of Wolf")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. The ")#mi("{100\\%}")#text(" case — ")]]

#text("Now we consider the question of counting more general linear (or affine) patterns than arithmetic progressions. A reasonably general setting is to count patterns of the form")

#align(center)[#tao-fit-display[#mitex("\\Psi(\\vec x) := (\\psi_1(\\vec x), \\ldots, \\psi_t(\\vec x))")]]

#text("in a subset ")#mi("{A}")#text(" of a finite abelian group ")#mi("{G}")#text(" (e.g. a cyclic group ")#mi("{G={\\bf Z}/N{\\bf Z}}")#text("), where ")#mi("{\\vec x = (x_1,\\ldots,x_d) \\in G^d}")#text(", and the ")#mi("{\\psi_1,\\ldots,\\psi_t: G^d \\rightarrow G}")#text(" are affine-linear forms")

#align(center)[#tao-fit-display[#mitex("\\psi_i(x_1,\\ldots,x_d) = c_i + \\sum_{j=1}^d c_{i,j} x_j")]]

#text("for some fixed integers ")#mi("{c_{i,j} \\in {\\bf Z}}")#text(" and group elements ")#mi("{c_{i} \\in G}")#text(". To avoid degeneracies, we will assume that all the ")#mi("{\\psi_i}")#text(" are surjective (or equivalently, that the ")#mi("{c_{i,1},\\ldots,c_{i,d}}")#text(" do not have a common factor that divides the order of ")#mi("{G}")#text("). This count would then be given by")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right|^d \\Lambda_\\Psi(1_A,\\ldots,1_A)", block: true)]]

#text("where ")#mi("{\\Lambda_\\Psi}")#text(" is the ")#mi("{d}")#text("-linear form")

#align(center)[#tao-fit-display[#mitex("\\Lambda_\\Psi(f_1,\\ldots,f_d) := \\mathop{\\bf E}_{\\vec x \\in G^d} f_1(\\psi_1(\\vec x)) \\ldots f_t(\\psi_t(\\vec x)).")]]

#text("For instance, the task of counting arithmetic progressions ")#mi("{n,n+r,\\ldots,n+(k-1)r}")#text(" corresponds to the case ")#mi("{d=2, t=k}")#text(", and ")#mi("{\\psi_i(x_1,x_2) := x_1 +(i-1) x_2}")#text(".")

#text("We have the trivial bound ")#metadata(none) <tao-22a5f9acc2d53dcb606e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| \\leq \\left\\| f_1\\right\\|_{L^\\infty(G)} \\ldots \\left\\|f_t\\right\\|_{L^\\infty(G)}", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^\\infty(G)} := \\sup_{x \\in G} \\left|f(x)\\right|.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can replace the ")#mi("{L^\\infty}")#text(" norm on ")#mi("{f_i}")#text(" in ")#link(<tao-22a5f9acc2d53dcb606e>)[#text("(9)")]#text(" with an ")#mi("{L^{p_i}}")#text(" norm for various values of ")#mi("{p_1,\\ldots,p_t}")#text(". The set of all admissible ")#mi("{p_1,\\ldots,p_t}")#text(" is described by the ")#emph[#text("Brascamp-Lieb inequality")]#text(", see ")#link("http://arxiv.org/abs/math.CA/0505691")[#text("this paper")]#text(" for further discussion. We will not need these variants of ")#link(<tao-22a5f9acc2d53dcb606e>)[#text("(9)")]#text(".")
]

#text("Improving this trivial bound turns out to be a key step in the theory of counting general linear patterns. In particular, it turns out that for any ")#mi("{\\epsilon > 0}")#text(", one usually has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| < \\epsilon \\left\\| f_1\\right\\|_{L^\\infty(G)} \\ldots \\left\\|f_t\\right\\|_{L^\\infty(G)}", block: true)]]

#text("except when ")#mi("{f_1,\\ldots,f_t}")#text(" take a very special form (or at least correlate with functions of a very special form, such as linear or higher order characters).")

#text("To reiterate: the key to the subject is to understand the ")#emph[#text("inverse problem")]#text(" of characterising those functions ")#mi("{f_1,\\ldots,f_d}")#text(" for which one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| \\geq \\epsilon \\left\\| f_1\\right\\|_{L^\\infty(G)} \\ldots \\left\\|f_t\\right\\|_{L^\\infty(G)}.", block: true)]]

#text("This problem is of most interest (and the most difficult) in the “")#mi("{1\\%}")#text(" world” when ")#mi("{\\epsilon}")#text(" is small (e.g. ")#mi("{\\epsilon = 0.01}")#text("), but it is also instructive to consider the simpler cases of the “")#mi("{99\\%}")#text(" world” when ")#mi("{\\epsilon}")#text(" is very close to one (e.g. ")#mi("{\\epsilon = 0.99}")#text("), or the “")#mi("{100\\%}")#text(" world” when ")#mi("{\\epsilon}")#text(" is exactly equal to one. In these model cases one can use additional techniques (error-correction and similar techniques (often of a theoretical computer science flavour) in the ")#mi("{99\\%}")#text(" world, or exact algebraic manipulation in the ")#mi("{100\\%}")#text(" world) to understand this expression.")

#text("Let us thus begin with analysing the ")#mi("{100\\%}")#text(" situation. Specifically, we assume that we are given functions ")#mi("{f_1,\\ldots,f_t \\in L^\\infty(G)}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| = \\left\\| f_1\\right\\|_{L^\\infty(G)} \\ldots \\left\\|f_t\\right\\|_{L^\\infty(G)}", block: true)]]

#text("and wish to classify the functions ")#mi("{f_1,\\ldots,f_t}")#text(" as best we can. We will normalise all the norms on the right-hand side to be one, thus ")#tao-math("{\\left|f_i(x)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{x \\in G}")#text(" and ")#mi("{i=1,\\ldots,t}")#text(", and ")#metadata(none) <tao-ec822a5e611eee9629c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| = 1.", block: true)]]

#text("By the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\Lambda_\\Psi(\\left|f_1\\right|,\\ldots,\\left|f_t\\right|) \\geq 1.", block: true)]]

#text("On the other hand, we have the crude bound")

#align(center)[#tao-fit-display[#tao-math("\\Lambda_\\Psi(\\left|f_1\\right|,\\ldots,\\left|f_t\\right|) \\leq 1.", block: true)]]

#text("Thus equality occurs, which (by the surjectivity hypothesis on all the ")#mi("{\\psi_i}")#text(") shows that ")#tao-math("{\\left|f_i(x)\\right|=1}", block: false)#text(" for all ")#mi("{x \\in G}")#text(" and ")#mi("{i=1,\\ldots,t}")#text(". Thus we may write ")#mi("{f_i(x) = e(\\phi_i(x))}")#text(" for some phase functions ")#mi("{\\phi_i: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(". We then have")

#align(center)[#tao-fit-display[#mitex("\\Lambda_\\Psi(f_1,\\ldots,f_t) = \\mathop{\\bf E}_{\\vec x \\in G^d} e( \\sum_{i=1}^t \\phi_i(\\psi_i(\\vec x)) )")]]

#text("and so from ")#link(<tao-ec822a5e611eee9629c2>)[#text("(10)")]#text(" one has the equation ")#metadata(none) <tao-04b84ba1d4f1d361b3c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{i=1}^t \\phi_i(\\psi_i(\\vec x)) = c")]]

#text("for all ")#mi("{\\vec x \\in G^d}")#text(" and some constant ")#mi("{c}")#text(".")

#text("So the problem now reduces to the algebraic problem of solving functional equations such as ")#link(<tao-04b84ba1d4f1d361b3c9>)[#text("(11)")]#text(". To illustrate this type of problem, let us consider a simple case when ")#mi("{d=2, t=3}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\psi_1(x,y) = x; \\psi_2(x,y) = y; \\psi_3(x,y) = x+y")]]

#text("in which case we are trying to understand solutions ")#mi("{\\phi_1, \\phi_2, \\phi_3: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" to the functional equation ")#metadata(none) <tao-a871c9895f46a4c29b91>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\phi_1(x) + \\phi_2(y) + \\phi_3(x+y) = c.")]]

#text("This equation involves three unknown functions ")#mi("{\\phi_1,\\phi_2,\\phi_3}")#text(". But we can eliminate two of the functions by taking ")#emph[#text("discrete derivatives")]#text(". To motivate this idea, let us temporarily assume that ")#mi("{G}")#text(" is the real line ")#mi("{{\\bf R}}")#text(" rather than a finite group, and that the functions ")#mi("{\\phi_1, \\phi_2, \\phi_3}")#text(" are smooth. If we then apply the partial derivative operator ")#mi("{\\partial_x}")#text(" to the above functional equation, one eliminates ")#mi("{\\phi_2}")#text(" and obtains")

#align(center)[#tao-fit-display[#mitex("\\phi^{\\prime}_1(x) + \\phi^{\\prime}_3(x+y) = 0;")]]

#text("applying ")#mi("{\\partial_y}")#text(" then eliminates ")#mi("{\\phi_1}")#text(" and leaves us with")

#align(center)[#tao-fit-display[#mitex("\\phi^{\\prime\\prime}_3(x+y) = 0,")]]

#text("thus ")#mi("{\\phi^{\\prime\\prime}_3}")#text(" vanishes identically; we can integrate this twice to conclude that ")#mi("{\\phi_3}")#text(" is a linear function of its input,")

#align(center)[#tao-fit-display[#mitex("\\phi_3(x) = a_3 x + b_3")]]

#text("for some constants ")#mi("{a_3, b_3 \\in {\\bf R}}")#text(". A similar argument (using the partial derivative operator ")#mi("{\\partial_x - \\partial_y}")#text(" to eliminate ")#mi("{\\phi_3}")#text(", or by applying change of variables such as ")#mi("{(x,z) := (x,x+y)}")#text(") shows that ")#mi("{\\phi_1(x) = a_1 x + b_1}")#text(" and ")#mi("{\\phi_2(x) = a_2 x + b_2}")#text(" for some additional constants ")#mi("{a_1,b_1,a_2,b_2}")#text(". Finally, by returning to ")#link(<tao-a871c9895f46a4c29b91>)[#text("(12)")]#text(" and comparing coefficients we obtain the additional compatibility condition ")#mi("{a_3 = -a_1 = -a_2}")#text(", which one then easily verifies to completely describe all possible solutions to this equation in the case of smooth functions on ")#mi("{{\\bf R}}")#text(".")

#text("Returning now to the discrete world, we mimic the continuous operation of a partial derivative by introducing difference operators")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi(x) := \\phi(x+h) - \\phi(x)")]]

#text("for ")#mi("{h \\in G}")#text(". If we difference ")#link(<tao-a871c9895f46a4c29b91>)[#text("(12)")]#text(" in the ")#mi("{x}")#text(" variable by an arbitrary shift ")#mi("{h \\in G}")#text(" by replacing ")#mi("{x}")#text(" by ")#mi("{x+h}")#text(" and then subtracting, we eliminate ")#mi("{\\phi_2}")#text(" and obtain")

#align(center)[#tao-fit-display[#mitex("(\\partial_h \\phi_1)(x) + (\\partial_h \\phi_3)(x+y) = 0;")]]

#text("if we then difference in the ")#mi("{y}")#text(" variable by a second arbitrary shift ")#mi("{k \\in G}")#text(", one obtains")

#align(center)[#tao-fit-display[#mitex("(\\partial_k \\partial_h \\phi_3)(x+y)=0")]]

#text("for all ")#mi("{x,y,h,k \\in G}")#text("; in particular, ")#mi("{\\partial_k \\partial_h \\phi_3 \\equiv 0}")#text(" for all ")#mi("{k, h \\in G}")#text(". Such functions are affine-linear:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-a457e8f04aa796dc5077>#text(" Let ")#mi("{\\phi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a function. Show that ")#mi("{\\partial_k \\partial_h \\phi = 0}")#text(" if and only if one has ")#mi("{\\phi(x) = a(x) + b}")#text(" for some ")#mi("{b \\in G}")#text(" and some homomorphism ")#mi("{a: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(". Conclude that the solutions to ")#link(<tao-a871c9895f46a4c29b91>)[#text("(12)")]#text(" are given by the form ")#mi("{\\phi_i(x) = a_i(x) + b_i}")#text(", where ")#mi("{b_1,b_2,b_3 \\in G}")#text(" and ")#mi("{a_1,a_2,a_3: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" are homomorphisms with ")#mi("{a_1 = a_2 = - a_3}")#text(".")
]

#text("Having solved the functional equation ")#link(<tao-a871c9895f46a4c29b91>)[#text("(12)")]#text(", let us now look at an equation related to four term arithmetic progressions, namely ")#metadata(none) <tao-7be1a5685de2633c9c98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\phi_1(x) + \\phi_2(x+y) + \\phi_3(x+2y) + \\phi_4(x+3y) = c")]]

#text("for all ")#mi("{x,y \\in G}")#text(", some constant ")#mi("{c \\in {\\bf R}/{\\bf Z}}")#text(", and some functions ")#mi("{\\phi_1,\\phi_2,\\phi_3,\\phi_4: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(". We will try to isolate ")#mi("{\\phi_4}")#text(" by using discrete derivatives as before to eliminate the other functions. Firstly, we differentiate in the ")#mi("{y}")#text(" direction by an arbitrary shift ")#mi("{h \\in G}")#text(", leading to")

#align(center)[#tao-fit-display[#mitex("(\\partial_h \\phi_2)(x+y) + (\\partial_{2h} \\phi_3)(x+2y) + (\\partial_{3h} \\phi_4)(x+3y) = 0.")]]

#text("In preparation for then eliminating ")#mi("{\\phi_2}")#text(", we shift ")#mi("{x}")#text(" backwards by ")#mi("{y}")#text(", obtaining")

#align(center)[#tao-fit-display[#mitex("(\\partial_h \\phi_2)(x) + (\\partial_{2h} \\phi_3)(x+y) + (\\partial_{3h} \\phi_4)(x+2y) = 0.")]]

#text("Differentiating in the ")#mi("{y}")#text(" direction by another arbitrary shift ")#mi("{k \\in G}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("(\\partial_k \\partial_{2h} \\phi_3)(x+y) + (\\partial_{2k} \\partial_{3h} \\phi_4)(x+2y) = 0.")]]

#text("We shift ")#mi("{x}")#text(" backwards by ")#mi("{y}")#text(" again:")

#align(center)[#tao-fit-display[#mitex("(\\partial_k \\partial_{2h} \\phi_3)(x) + (\\partial_{2k} \\partial_{3h} \\phi_4)(x+y) = 0.")]]

#text("One final differentiation in ")#mi("{y}")#text(" by an arbitrary shift ")#mi("{l \\in G}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("(\\partial_l \\partial_{2k} \\partial_{3h} \\phi_4)(x+y) = 0.")]]

#text("For simplicity, we now make the assumption that the order ")#tao-math("{\\left|G\\right|}", block: false)#text(" of ")#mi("{G}")#text(" is not divisible by either ")#mi("{2}")#text(" or ")#mi("{3}")#text(", so that the homomorphisms ")#mi("{k \\mapsto 2k}")#text(" and ")#mi("{h \\mapsto 3h}")#text(" are automorphisms of ")#mi("{G}")#text(". We conclude that ")#metadata(none) <tao-aef77abeda3439aaea01>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_l \\partial_k \\partial_h \\phi_4 \\equiv 0")]]

#text("for all ")#mi("{l,k,h}")#text(". Such functions will be called ")#emph[#text("quadratic")]#text(" functions from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", thus ")#mi("{\\phi_4}")#text(" is quadratic. A similar argument shows that ")#mi("{\\phi_1,\\phi_2,\\phi_3}")#text(" are quadratic.")

#text("Just as (affine-)linear functions can be completely described in terms of homomorphisms, quadratic functions can be described in terms of bilinear forms, as long as one avoids the characteristic ")#mi("{2}")#text(" case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{G}")#text(" be a finite abelian group with ")#tao-math("{\\left|G\\right|}", block: false)#text(" not divisible by ")#mi("{2}")#text(". Show that a map ")#mi("{\\phi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is quadratic if and only one has a representation of the form")

#align(center)[#tao-fit-display[#mitex("\\phi(x) = B(x,x) + L(x) + c")]]

#text("where ")#mi("{c \\in {\\bf R}/{\\bf Z}}")#text(", ")#mi("{L: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a homomorphism, and ")#mi("{B: G \\times G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a symmetric bihomomorphism (i.e. ")#mi("{B(x,y) = B(y,x)}")#text(", and ")#mi("{B}")#text(" is a homomorphism in each of ")#mi("{x,y}")#text(" individually (holding the other variable fixed)). (")#emph[#text("Hint:")]#text(" Heuristically, one should set ")#mi("{B(h,k) := \\frac{1}{2} \\partial_h \\partial_k \\phi(x)}")#text(", but there is a difficulty because the operation of dividing by ")#mi("{\\frac{1}{2}}")#text(" is not well-defined on ")#mi("{{\\bf R}/{\\bf Z}}")#text(". It is, however, well-defined on ")#tao-math("{\\left|G\\right|^{th}}", block: false)#text(" roots of unity, thanks to ")#tao-math("{\\left|G\\right|}", block: false)#text(" not being divisible by two. Once ")#mi("{B}")#text(" has been constructed, subtract it off and use Exercise ")#link(<tao-a457e8f04aa796dc5077>)[#text("8")]#text(".) What goes wrong when ")#tao-math("{\\left|G\\right|}", block: false)#text(" is divisible by ")#mi("{2}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that when ")#tao-math("{\\left|G\\right|}", block: false)#text(" is not divisible by ")#mi("{2, 3}")#text(", that the complete solution to ")#link(<tao-7be1a5685de2633c9c98>)[#text("(13)")]#text(" is given by")

#align(center)[#tao-fit-display[#mitex("\\phi_i(x) = B_i(x,x) + L_i(x) + c_i")]]

#text("for ")#mi("{i=1,2,3,4}")#text(", ")#mi("{c_i \\in {\\bf R}/{\\bf Z}}")#text(", homomorphisms ")#mi("{L_i: G \\rightarrow{\\bf R}/{\\bf Z}}")#text(", and symmetric bihomomorphisms ")#mi("{B_i: G \\times G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" with ")#mi("{B_2 = -3B_1, B_3 = 3B_1, B_4 = - B_1}")#text(" and ")#mi("{L_1 + L_2 + L_3 + L_4 = L_2 + 2L_3 + 3L_4 = 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Obtain a complete solution to the functional equation ")#link(<tao-7be1a5685de2633c9c98>)[#text("(13)")]#text(" in the case when ")#tao-math("{\\left|G\\right|}", block: false)#text(" is allowed to be divisible by ")#mi("{2}")#text(" or ")#mi("{3}")#text(". (This is an open-ended and surprisingly tricky exercise; it of course depends on what one is willing to call a “solution” to the problem. Use your own judgement.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Call a map ")#mi("{\\phi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" ")#emph[#text("a polynomial of degree ")#mi("{\\leq d}")]#text(" if one has ")#mi("{\\partial_{h_1} \\ldots \\partial_{h_{d+1}} \\phi(x) = 0}")#text(" for all ")#mi("{x,h_1,\\ldots,h_{d+1} \\in G}")#text(". Show that if ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\phi_1,\\ldots,\\phi_k}")#text(" obey the functional equation")

#align(center)[#tao-fit-display[#mitex("\\phi_1(x) + \\phi_2(x+y) + \\ldots + \\phi_k(x+(k-1)y) = c")]]

#text("and ")#tao-math("{\\left|G\\right|}", block: false)#text(" is not divisible by any integer between ")#mi("{2}")#text(" and ")#mi("{k-1}")#text(", then ")#mi("{\\phi_1,\\ldots,\\phi_k}")#text(" are polynomials of degree ")#mi("{\\leq k-2}")#text(".")
]

#text("We are now ready to turn to the general case of solving equations of the form ")#link(<tao-04b84ba1d4f1d361b3c9>)[#text("(11)")]#text(". We relied on two main tricks to solve these equations: differentiation, and change of variables. When solving an equation such as ")#link(<tao-7be1a5685de2633c9c98>)[#text("(13)")]#text(", we alternated these two tricks in turn. To handle the general case, it is more convenient to rearrange the argument by doing all the change of variables in advance. For instance, another way to solve ")#link(<tao-7be1a5685de2633c9c98>)[#text("(13)")]#text(" is to first make the (non-injective) change of variables")

#align(center)[#tao-fit-display[#mitex("(x,y) := (b+2c+3d, -a-b-c-d)")]]

#text("for arbitrary ")#mi("{a,b,c,d \\in G}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("(x,x+y,x+2y,x+3y) = (b+2c+3d, -a+c+2d, -2a-b+d, -3a-2b-c)")]]

#text("and ")#link(<tao-7be1a5685de2633c9c98>)[#text("(13)")]#text(" becomes ")#metadata(none) <tao-252e7d16b21cc5df8d60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\phi_1(b+2c+3d) + \\phi_2(-a+c+2d) + \\phi_3(-2a-b+d) + \\phi_4(-3a-2b-c) = const")]]

#text("for all ")#mi("{a,b,c,d \\in G}")#text(". The point of performing this change of variables is that while the ")#mi("{\\phi_4}")#text(" term (for instance) involves all the three variables ")#mi("{a,b,c}")#text(", the remaining terms only depend on two of the ")#mi("{a,b,c}")#text(" at a time. If we now pick ")#mi("{h,k,l \\in G}")#text(" arbitrarily, and then differentiate in the ")#mi("{a,b,c}")#text(" variables by the shifts ")#mi("{h,k,l}")#text(" respectively, then we eliminate the ")#mi("{\\phi_1, \\phi_2, \\phi_3}")#text(" terms and arrive at")

#align(center)[#tao-fit-display[#mitex("(\\partial_{-l} \\partial_{-2k} \\partial_{-3h} \\phi_4)(-3a-2b-c) = 0")]]

#text("which soon places us back at ")#link(<tao-aef77abeda3439aaea01>)[#text("(14)")]#text(" (assuming as before that ")#tao-math("{\\left|G\\right|}", block: false)#text(" is not divisible by ")#mi("{2}")#text(" or ")#mi("{3}")#text(").")

#text("Now we can do the general case, once we put in place a definition (from ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("this paper of mine with Ben Green")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Cauchy-Schwarz complexity)")]#text(" A system ")#mi("{\\psi_1,\\ldots,\\psi_t: G^d \\rightarrow G}")#text(" of affine-linear forms (with linear coefficients in ")#mi("{{\\bf Z}}")#text(") have ")#emph[#text("Cauchy-Schwarz complexity at most ")#mi("{s}")]#text(" if, for every ")#mi("{1 \\leq i \\leq t}")#text(", one can partition ")#mi("{[t] \\backslash \\{i\\}}")#text(" into ")#mi("{s+1}")#text(" classes (some of which may be empty), such that ")#mi("{\\psi_i}")#text(" does not lie in the affine-linear span (over ")#mi("{{\\bf Q}}")#text(") of the forms in any of these classes. The ")#emph[#text("Cauchy-Schwarz complexity")]#text(" of a system is defined to be the least such ")#mi("{s}")#text(" with this property, or ")#mi("{\\infty}")#text(" if no such ")#mi("{s}")#text(" exists.")
]

#text("The adjective “Cauchy-Schwarz” (introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=2578471")[#text("by Gowers and Wolf")]#text(") may be puzzling at present, but will be motivated later.")

#text("This is a somewhat strange definition to come to grips with at first, so we illustrate it with some examples. The system of forms ")#mi("{x,y,x+y}")#text(" is of complexity ")#mi("{1}")#text("; given any form here, such as ")#mi("{y}")#text(", one can partition the remaining forms into two classes, namely ")#mi("{\\{x\\}}")#text(" and ")#mi("{\\{x+y\\}}")#text(", such that ")#mi("{y}")#text(" is not in the affine-linear span of either. On the other hand, as ")#mi("{y}")#text(" is in the affine linear span of ")#mi("{\\{x,x+y\\}}")#text(", the Cauchy-Schwarz complexity is not zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that for any ")#mi("{k \\geq 2}")#text(", the system of forms ")#mi("{x, x+y, \\ldots, x+(k-1)y}")#text(" has complexity ")#mi("{k-2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that a system of non-constant forms has finite Cauchy-Schwarz complexity if and only if no form is an affine-linear combination of another.")
]

#text("There is an equivalent way to formulate the notion of Cauchy-Schwarz complexity, in the spirit of the change of variables mentioned earlier. Define the ")#emph[#text("characteristic")]#text(" of a finite abelian group ")#mi("{G}")#text(" to be the least order of a non-identity element.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Equivalent formulation of Cauchy-Schwarz complexity)")]#text(" Let ")#mi("{\\psi_1,\\ldots,\\psi_t: G^d \\rightarrow G}")#text(" be a system of affine-linear forms. Suppose that the characteristic of ")#mi("{G}")#text(" is sufficiently large depending on the coefficients of ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(". Then ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(" has Cauchy-Schwarz complexity at most ")#mi("{s}")#text(" if and only if, for each ")#mi("{1 \\leq i \\leq t}")#text(", one can find a linear change of variables ")#mi("{\\vec x = L_i( y_1,\\ldots,y_{s+1}, z_1,\\ldots,z_m )}")#text(" over ")#mi("{{\\bf Q}}")#text(" such that the form ")#mi("{\\dot \\psi_i(L_i(y_1,\\ldots,y_{s+1},z_1,\\ldots,z_m))}")#text(" has non-zero ")#mi("{y_1,\\ldots,y_{s+1}}")#text(" coefficients, but all the other forms ")#mi("{\\dot \\psi_j(L_i(y_1,\\ldots,y_{s+1},z_1,\\ldots,z_m))}")#text(" with ")#mi("{j \\neq i}")#text(" have at least one vanishing ")#mi("{y_1,\\ldots,y_{s+1}}")#text(" coefficient, and ")#mi("{\\dot \\psi_i: {\\bf Q}^d \\rightarrow {\\bf Q}}")#text(" is the linear form induced by the integer coefficients of ")#mi("{\\psi_i}")#text(".")
]

#emph[#text("Proof:")]#text(" To show the “only if” part, observe that if ")#mi("{1 \\leq i \\leq t}")#text(" and ")#mi("{L_i}")#text(" is as above, then we can partition the ")#mi("{\\psi_j}")#text(", ")#mi("{j \\neq i}")#text(" into ")#mi("{s+1}")#text(" classes depending on which ")#mi("{y_k}")#text(" coefficient vanishes for ")#mi("{k=1,\\ldots,s+1}")#text(" (breaking ties arbitrarily), and then ")#mi("{\\psi_i}")#text(" is not representable as an affine-linear combination of the forms from any of these classes (here we use the large characteristic hypothesis). Conversely, suppose ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(" has Cauchy-Schwarz complexity at most ")#mi("{s}")#text(", and let ")#mi("{1 \\leq i \\leq s}")#text(". We can then partition the ")#mi("{j \\neq i}")#text(" into ")#mi("{s+1}")#text(" classes ")#mi("{{\\mathcal A}_1,\\ldots,{\\mathcal A}_{s+1}}")#text(", such that ")#mi("{\\psi_i}")#text(" cannot be expressed as an affine-linear combination of the ")#mi("{\\psi_j}")#text(" from ")#mi("{{\\mathcal A}_k}")#text(" for any ")#mi("{1 \\leq k \\leq s+1}")#text(". By duality, one can then find vectors ")#mi("{v_k \\in {\\bf Q}^d}")#text(" for each ")#mi("{1 \\leq k \\leq s+1}")#text(" such that ")#mi("{\\dot \\psi_i}")#text(" does not annihilate ")#mi("{v_k}")#text(", but all the ")#mi("{\\dot \\psi_j}")#text(" from ")#mi("{{\\mathcal A}_k}")#text(" do. If we then set")

#align(center)[#tao-fit-display[#mitex("L_i(y_1,\\ldots,y_{s+1},z_1,\\ldots,z_d) := (z_1,\\ldots,z_d) + y_1 v_1 + \\ldots + y_{s+1} v_{s+1}")]]

#text("then we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-1b2fc9341a16ae4e3008>#text(" Let ")#mi("{\\psi_1,\\ldots,\\psi_t: G^d \\rightarrow G}")#text(" be a system of affine-linear forms with Cauchy-Schwarz complexity at most ")#mi("{s}")#text(", and suppose that the equation ")#link(<tao-04b84ba1d4f1d361b3c9>)[#text("(11)")]#text(" holds for some finite abelian group ")#mi("{G}")#text(" and some ")#mi("{\\phi_1,\\ldots,\\phi_t: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(". Suppose also that the characteristic of ")#mi("{G}")#text(" is sufficiently large depending on the coefficients of ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(". Conclude that all of the ")#mi("{\\phi_1,\\ldots,\\phi_t}")#text(" are polynomials of degree ")#mi("{\\leq t}")#text(".")
]

#text("It turns out that this result is not quite best possible. Define the ")#emph[#text("true complexity")]#text(" of a system of affine-linear forms ")#mi("{\\psi_1,\\ldots,\\psi_t: G^d \\rightarrow G}")#text(" to be the largest ")#mi("{s}")#text(" such that the powers ")#mi("{\\dot \\psi_1^s, \\ldots, \\dot\\psi_t^s:{\\bf Q}^d \\rightarrow {\\bf Q}}")#text(" are linearly independent over ")#mi("{{\\bf Q}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Show that the true complexity is always less than or equal to the Cauchy-Schwarz complexity, and give an example to show that strict inequality can occur. Also, show that the true complexity is finite if and only if the Cauchy-Schwarz complexity is finite.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that Exercise ")#link(<tao-1b2fc9341a16ae4e3008>)[#text("15")]#text(" continues to hold if Cauchy-Schwarz complexity is replaced by true complexity. (")#emph[#text("Hint:")]#text(" first understand the cyclic case ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(", and use Exercise ")#link(<tao-1b2fc9341a16ae4e3008>)[#text("15")]#text(" to reduce to the case when all the ")#mi("{\\phi_i}")#text(" are polynomials of bounded degree. The main point is to use a “Lefschetz principle” to lift statements in ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" to a characteristic zero field such as ")#mi("{{\\bf Q}}")#text(".) Show that the true complexity cannot be replaced by any smaller quantity.")
]

#text("See ")#link("http://www.ams.org/mathscinet-getitem?mr=2578471")[#text("this paper of Gowers and Wolf")]#text(" for further discussion of the relationship between Cauchy-Schwarz complexity and true complexity.")

#heading(level: 1)[#strong[#text(" — 3. The Gowers uniformity norms — ")]]

#text("In the previous section, we saw that equality in the trivial inequality ")#link(<tao-22a5f9acc2d53dcb606e>)[#text("(9)")]#text(" only occurred when the functions ")#mi("{f_1,\\ldots,f_t}")#text(" were of the form ")#mi("{f_i = e(\\phi_i)}")#text(" for some polynomials ")#mi("{\\phi_i}")#text(" of degree at most ")#mi("{s}")#text(", where ")#mi("{s}")#text(" was the true complexity (or Cauchy-Schwarz complexity) of the system ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(". Another way of phrasing this latter fact is that one has the identity")

#align(center)[#tao-fit-display[#mitex("\\Delta_{h_1} \\ldots \\Delta_{h_{s+1}} f_i(x) = 1")]]

#text("for all ")#mi("{h_1,\\ldots,h_{s+1},x\\in G}")#text(", where ")#mi("{\\Delta_h}")#text(" is the multiplicative derivative")

#align(center)[#tao-fit-display[#mitex("\\Delta_h f(x) := f(x+h) \\overline{f(x)}.")]]

#text("This phenomenon extends beyond the “")#mi("{100\\%}")#text(" world” of exact equalities. For any ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" and ")#mi("{d \\geq 1}")#text(", we define the ")#emph[#text("Gowers norm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{U^d(G)}}", block: false)#text(" by the formula ")#metadata(none) <tao-21f4d2ad0cc7f3627fe3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\|f\\right\\|_{U^d(G)} := (\\mathop{\\bf E}_{h_1,\\ldots,h_d,x \\in G} \\Delta_{h_1} \\ldots \\Delta_{h_d} f(x))^{1/2^d};", block: true)]]

#text("note that this is equivalent to ")#link(<tao-28f1a05a7a09f2d2bdf6>)[#text("(6)")]#text(". Using the identity")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h,x \\in G} \\Delta_h f(x) = \\left|\\mathop{\\bf E}_{x \\in G} f(x)\\right|^2", block: true)]]

#text("we easily verify that the expectation in the definition of ")#link(<tao-21f4d2ad0cc7f3627fe3>)[#text("(16)")]#text(" is a non-negative real. We also have the recursive formula ")#metadata(none) <tao-9150716f69fd56b2ffd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\|f\\right\\|_{U^d(G)} := (\\mathop{\\bf E}_{h\\in G} \\left\\|\\Delta_{h} f \\right\\|_{U^{d-1}(G)}^{2^{d-1}})^{1/2^d}", block: true)]]

#text("for all ")#mi("{d \\geq 1}")#text(".")

#text("The ")#mi("{U^1}")#text(" norm essentially just the mean: ")#metadata(none) <tao-30516e01eadfbd930ef2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left\\|f\\right\\|_{U^1(G)} = \\left|\\mathop{\\bf E}_{x \\in G} f(x)\\right|.", block: true)]]

#text("As such, it is actually a ")#link("http://en.wikipedia.org/wiki/Norm_(mathematics)")[#text("seminorm")]#text(" rather than a norm.")

#text("The ")#mi("{U^2}")#text(" norm can be computed in terms of the Fourier transform:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Fourier representation of ")#mi("{U^2}")#text(")")]#text(" Define the ")#emph[#text("Pontryagin dual")]#text(" ")#mi("{\\hat G}")#text(" of a finite abelian group ")#mi("{G}")#text(" to be the space of all homomorphisms ")#mi("{\\xi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(". For each function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(", define the Fourier transform ")#mi("{\\hat f: \\hat G \\rightarrow {\\bf C}}")#text(" by the formula ")#mi("{\\hat f(\\xi) := \\mathop{\\bf E}_{x \\in G} f(x) e(-\\xi(x))}")#text(". Establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2(G)} = \\left\\| \\hat f \\right\\|_{\\ell^4(\\hat G)} := (\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^4)^{1/4}.", block: true)]]
]

#text("In particular, the ")#mi("{U^2}")#text(" norm is a genuine norm (thanks to the norm properties of ")#mi("{\\ell^4(G)}")#text(", and the injectivity of the Fourier transform).")

#text("For the higher Gowers norms, there is not nearly as nice a formula known in terms of things like the Fourier transform, and it is not immediately obvious that these are indeed norms. But this can be established by introducing the more general ")#emph[#text("Gowers inner product")]

#align(center)[#tao-fit-display[#mitex("\\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(G)} := \\mathop{\\bf E}_{x,h_1,\\ldots,h_d \\in G} \\prod_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}^d}")]]

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}^{\\omega_1+\\ldots+\\omega_d} f_{\\omega_1,\\ldots,\\omega_d}(x+\\omega_1 h_1 + \\ldots + \\omega_d h_d)")]]

#text("for any ")#mi("{2^d}")#text("-tuple ")#mi("{(f_\\omega)_{\\omega \\in \\{0,1\\}^d}}")#text(" of functions ")#mi("{f_\\omega: G \\rightarrow {\\bf C}}")#text(", thus in particular")

#align(center)[#tao-fit-display[#tao-math("\\langle (f)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(G)} = \\left\\|f\\right\\|_{U^d(G)}^{2^d}.", block: true)]]

#text("The relationship between the Gowers inner product and the Gowers uniformity norm is analogous to that between a Hilbert space inner product and the Hilbert space norm. In particular, we have the following analogue of the Cauchy-Schwarz inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Cauchy-Schwarz-Gowers inequality)")]#text(" For any tuple ")#mi("{(f_\\omega)_{\\omega \\in \\{0,1\\}^d}}")#text(" of functions ")#mi("{f_\\omega: G \\rightarrow {\\bf C}}")#text(", use the Cauchy-Schwarz inequality to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(G)}\\right| \\leq \\prod_{j=0,1} \\left|\\langle (f_{\\pi_{i,j}(\\omega)})_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(G)}\\right|^{1/2}", block: true)]]

#text("for all ")#mi("{1 \\leq i \\leq d}")#text(", where for ")#mi("{j=0,1}")#text(" and ")#mi("{\\omega \\in \\{0,1\\}^d}")#text(", ")#mi("{\\pi_{i,j}(\\omega) \\in \\{0,1\\}^d}")#text(" is formed from ")#mi("{\\omega}")#text(" by replacing the ")#mi("{i^{th}}")#text(" coordinate with ")#mi("{j}")#text(". Iterate this to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(G)}\\right| \\leq \\prod_{\\omega \\in \\{0,1\\}^d} \\left\\|f_\\omega\\right\\|_{U^d(G)}.", block: true)]]

#text("Then use this to conclude the monotonicity formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^d(G)} \\leq \\left\\|f\\right\\|_{U^{d+1}(G)}", block: true)]]

#text("for all ")#mi("{d \\geq 1}")#text(", and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f+g\\right\\|_{U^d(G)} \\leq \\left\\|f\\right\\|_{U^d(G)} + \\left\\|g\\right\\|_{U^d(G)}", block: true)]]

#text("for all ")#mi("{f, g: G \\rightarrow {\\bf C}}")#text(". (")#emph[#text("Hint:")]#text(" For the latter inequality, raise both sides to the power ")#mi("{2^d}")#text(" and expand the left-hand side.) Conclude in particular that the ")#mi("{U^d(G)}")#text(" norms are indeed norms for all ")#mi("{d \\geq 2}")#text(".")
]

#text("The Gowers uniformity norms can be viewed as a quantitative measure of how well a given function behaves like a polynomial. One piece of evidence in this direction is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Inverse conjecture for the Gowers norm, ")#mi("{100\\%}")#text(" case)")]#text(" Let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(G)}=1}", block: false)#text(", and let ")#mi("{s \\geq 0}")#text(". Show that ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}(G)} \\leq 1}", block: false)#text(", with equality if and only if ")#mi("{f = e(\\phi)}")#text(" for some polynomial ")#mi("{\\phi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{s}")#text(".")
]

#text("The problem of classifying smaller values of ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}(G)}}", block: false)#text(" is significantly more difficult, and will be discussed in later notes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Polynomial phase invariance)")]#text(" If ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" is a function and ")#mi("{\\phi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a polynomial of degree at most ")#mi("{s}")#text(", show that ")#tao-math("{\\left\\| e(\\phi) f \\right\\|_{U^{s+1}(G)} = \\left\\|f\\right\\|_{U^{s+1}(G)}}", block: false)#text(". Conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\phi} \\left|\\mathop{\\bf E}_{x \\in G} e( \\phi(x) ) f(x) \\right| \\leq \\left\\|f\\right\\|_{U^{s+1}(G)}", block: true)]]

#text("where ")#mi("{\\phi}")#text(" ranges over polynomials of degree at most ")#mi("{s}")#text(".")
]

#text("The main utility for the Gowers norms in this subject comes from the fact that they control many other expressions of interest. Here is a basic example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be a function, and for each ")#mi("{1 \\leq i \\leq s+1}")#text(", let ")#mi("{g_i: G^{s+1} \\rightarrow {\\bf C}}")#text(" be a function bounded in magnitude by ")#mi("{1}")#text(" which is independent of the ")#mi("{i^{th}}")#text(" coordinate of ")#mi("{G^{s+1}}")#text(". Let ")#mi("{a_1,\\ldots,a_{s+1}}")#text(" be non-zero integers, and suppose that the characteristic of ")#mi("{G}")#text(" exceeds the magnitude of any of the ")#mi("{a_i}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x_1,\\ldots,x_{s+1} \\in G} f(a_1 x_1 + \\ldots + a_{s+1} x_{s+1}) \\prod_{i=1}^{s+1} g_i(x_1,\\ldots,x_{s+1})\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\left\\|f\\right\\|_{U^{s+1}(G)}.", block: true)]]

#emph[#text("Hint:")]#text(" induct on ")#mi("{s}")#text(" and use ")#link(<tao-9150716f69fd56b2ffd8>)[#text("(17)")]#text(" and the Cauchy-Schwarz inequality.")
]

#text("This gives us an analogue of Exercise ")#link(<tao-1b2fc9341a16ae4e3008>)[#text("15")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Generalised von Neumann inequality)")]#text(" Let ")#mi("{\\Psi = (\\psi_1,\\ldots,\\psi_t)}")#text(" be a collection of affine-linear forms ")#mi("{\\psi_i: G^d \\rightarrow G}")#text(" with Cauchy-Schwarz complexity ")#mi("{s}")#text(". If the characteristic of ")#mi("{G}")#text(" is sufficiently large depending on the linear coefficients of ")#mi("{\\psi_1,\\ldots,\\psi_t}")#text(", show that one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| \\leq \\inf_{1 \\leq i \\leq t} \\left\\|f_i\\right\\|_{U^{s+1}(G)}", block: true)]]

#text("whenever ")#mi("{f_1,\\ldots,f_t: G \\rightarrow {\\bf C}}")#text(" are bounded in magnitude by one.")

#text("Conclude in particular that if ")#mi("{A}")#text(" is a subset of ")#mi("{G}")#text(" with ")#tao-math("{\\left|A\\right|=\\delta\\left|G\\right|}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\Lambda_\\Psi(1_A,\\ldots,1_A) = \\delta^t + O_t( \\left\\|1_A - \\delta \\right\\|_{U^{s+1}(G)} ).", block: true)]]
]

#text("From the above inequality, we see that if ")#mi("{A}")#text(" has some positive density ")#mi("{\\delta > 0}")#text(" but has much fewer than ")#mi("{\\delta^t N^d / 2}")#text(" (say) patterns of the form ")#mi("{\\psi_1(\\vec x), \\ldots, \\psi_t(\\vec x)}")#text(" with ")#mi("{\\vec x \\in G^d}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A - \\delta \\right\\|_{U^{s+1}(G)} \\gg_{t,\\delta} 1.", block: true)]]

#text("This is the initial motivation for studying ")#emph[#text("inverse theorems")]#text(" for the Gowers norms, which give necessary conditions for a (bounded) function to have large ")#mi("{U^{s+1}(G)}")#text(" norm. This will be a focus of subsequent notes.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44449")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2010")])]

#text("Hi Terry,")

#text("There seem to be a lot of “Formula does not parse” messages. Is it just my problem?")

#text("Marco")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44471")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("Dear Prof. Tao")

#text("In Exercise 3, I think something is missing, since q isn’t used (and the hint doesn’t seem to make sense)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("Ah, there was a “mod q” missing in one of the displays. Thanks for the correction!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jc")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44470")[#strong[#text("jc")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("Not sure if this is the right place to post this, but I was browsing arxiv trackbacks and noticed that for your posts that link arxiv articles, in addition to the trackbacks expected, wordpress is also sending trackbacks for Thurston’s article linked in the sidebar.")

#text("See e.g. ")#link("http://arxiv.org/tb/math/9404236")[#text("http://arxiv.org/tb/math/9404236")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44484")[#strong[#text("Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Does anyone else find that these 254B lecture notes posts do not show up in the RSS feed, or is it just me?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-44745")[#strong[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("[…] from the previous notes that a function is a function is a polynomial of degree at most […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-45001")[#strong[#text("Pietro")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("Dear Terry,")

#text("in your definition of the Gowers inner product, I think you want to take the expectation over x,h_1,…,h_d of the expression that you have.")

#text("Thanks for the great notes and blog!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-45018")[#strong[#text("Pietro")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("Also, in exercise 1, I guess we want the intersection of A and A+h to have size >> delta squared times N.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-45022")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-45027")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] regularity lemma, Gowers uniformity norms, polynomials, Szemeredi's theorem | by Terence Tao In Notes 3, we saw that the number of additive patterns in a given set was (in principle, at least) controlled […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-45346")[#strong[#text("254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2010")])]

#text("[…] will rely solely on the Cauchy-Schwarz inequality, using a weighted version of the arguments from Notes 3 that first appeared in this paper of Green and myself. We wish to control the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mixing for progressions in non-abelian groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-203698")[#strong[#text("Mixing for progressions in non-abelian groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("[…] arguments let one conclude that are affine homomorphisms; see e.g. Section 2 of these lecture notes. It turns out that essentially the same argument can be applied in the nonabelian case, but one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-221756")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2013")])]

#text("Dear Terry,")

#text("There seems to be a discrepancy between the definition of the Gowers norm in “The primes contain arbitrarily long arithmetic progressions”:")

#mi("\\displaystyle \\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(\\mathbb{Z}_N)} := \\mathop{\\bf E}_{x,h_1,\\ldots,h_d \\in \\mathbb{Z}_N} \\prod_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}^d}  \\displaystyle f_{\\omega_1,\\ldots,\\omega_d}(x+\\omega_1 h_1 + \\ldots + \\omega_d h_d)")

#text("versus the one used in the later “Linear equations” series:")

#mi("\\displaystyle \\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d(\\mathbb{Z}_N)} := \\mathop{\\bf E}_{x,h_1,\\ldots,h_d \\in \\mathbb{Z}_N} \\prod_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}^d}  \\displaystyle {\\mathcal C}^{\\omega_1+\\ldots+\\omega_d} f_{\\omega_1,\\ldots,\\omega_d}(x+\\omega_1 h_1 + \\ldots + \\omega_d h_d)")

#text("Namely, the alternating conjugation is missing. Is there any particular reason for this change?")

#text("Of course, there is no difference when ")#mi("f(x)")#text(" is real-valued, but “The primes contain…” remarks in the section on anti-uniformity that:")

#text("Given a polynomial ")#mi("P: \\mathbb{Z}_N \\longrightarrow \\mathbb{Z}_N")#text(" of degree ")#mi("\\leq k - 2")#text(", we have ")#mi("\\mathscr{D}F = F")#text(", where ")#mi("F(x) = e^{2 \\pi i P(x)/N}")#text(". This comes from the fact that taking ")#mi("k - 1")#text(" successive differences of ")#mi("P(x)")#text(" gives the zero function.")

#text("For this example to work, it seems that we need the conjugation to be present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-221783")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2013")])]

#text("See Footnote 14 in the most recent version ")#link("http://arxiv.org/abs/math/0404188")[#text("http://arxiv.org/abs/math/0404188")]#text(" of the “The primes contain…” paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-457537")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] in numerous places in the literature (e.g. Lemma 11.4 of my book with Van Vu, or Exercise 23 of this blog post) and will not be repeated here. In particular, from multilinearity we see […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503946")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("Dear professor Tao,")#linebreak()#text(" I am having struggles proving exercise 22. It seems as if I have found a counterexample. I looked at the group ")#mi("\\mathbb{Z}/9\\mathbb{Z}")#text(", which has characteristic 3. For ")#mi("s=0")#text(", take $a=2$ and the statement then is ")#tao-math("\\left|\\mathbb{E}_{g\\in G}f(ag)\\right| \\leq  \\left|\\mathbb{E}_{g\\in G}f(g)\\right|=\\left|\\left|f\\right|\\right|_{U^1(G)}", block: false)#text(". But in this case one can just take a function which is nonzero on ")#mi("2\\cdot \\mathbb{Z}/9\\mathbb{Z}")#text(" but 0 on the rest.")

#text("I am also a little bit confused about your definition of affine linear form ")#mi("\\psi\\colon G^d\\rightarrow G")#text(". You define it to be maps of the form ")#mi("\\psi(x_1,\\dots,x_d) = c+\\sum_{i=1}^dc_ix_i")#text(" for integers ")#mi("c,c_i\\in\\mathbb{Z}")#text(", but in a group, what does ")#mi("c\\in \\mathbb{Z}")#text(" mean? If ")#mi("G")#text(" were a ring with unit, I would understand.")

#text("Thanks a lot in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503947")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("Please ignore my first question (about counterexample as it is not correct what I wrote).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("Abelian groups are canonically ")#link("https://en.wikipedia.org/wiki/Module_(mathematics)#Examples")[#text("modules over the integers")]#text(", e.g., ")#mi("3x = x + x + x")#text(" and ")#mi("-2x = -(x+x)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503950")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("Thanks for the reply. I understand it if you write ")#mi("c_ix_i")#text(" where ")#mi("c_i\\in\\mathbb{Z}")#text(" and ")#mi("x_i\\in\\mathbb{Z}")#text(", but how do I interpret ")#mi("c\\in\\mathbb{Z}")#text(" as an element of ")#mi("G")#text("? Because in the definition of ")#mi("\\psi")#text(" we write ")#mi("c+\\sum_{i}c_ix_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503951")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2018")])]

#text("Sorry for the typo, ")#mi("c_i\\in\\mathbb{Z}")#text(" and ")#mi("x_i\\in G")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-503975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2018")])]

#text("This is a typo: ")#mi("c")#text(" should be an element of ")#mi("G")#text(", not of ")#mi("{\\bf Z}")#text(". I will amend the text accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86cbb0bed535ea836b48b0dca2f8d66b841225e22cfda7d0dcce05c1d0c1ff5a-5fd5bce5b4b880708fc07a82730dc3d53cc5933d99c06ebc979281c49917325c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iPie")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-504268")[#strong[#text("iPie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("Hi prof. Tao, I find the proof of proposition 2 (equivalent formulation of CS-complexity) hard to follow (it could be me of course). I don’t understand how you use the large characteristic hypothesis to proof the “only if” part. Could you please explain it in more detail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-504283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("Fix ")#mi("k=1,\\dots,s+1")#text(". By hypothesis, the rational form ")#mi("\\dot \\psi_i(L_i(y_1, \\dots, z_m))")#text(" has non-vanishing ")#mi("y_k")#text(" coefficient. If the characteristic is large enough that it does not divide the numerator of this coefficient, this implies that the G-form ")#mi("\\psi_i(L_i(y_1,\\dots,z_m))")#text(" also has non-vanishing coefficient. On the other hand, all the forms ")#mi("\\psi_j(L_i(y_1,\\dots,z_m))")#text(" in the class associated to ")#mi("k")#text(" have vanishing ")#mi("y_k")#text(" coefficient. Hence ")#mi("\\psi_i")#text(" cannot be an affine-linear combination of these ")#mi("\\psi_j")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b721339fc294a7ac4d1a9405954f2d0fd8b189815edefcb60eebb67e0fcbfd4e-3ba893100f2ea4ba691c5a788191274986341c09803b6e96b5d464d8fa0fec0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rok H.")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-565388")[#strong[#text("Rok H.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2020")])]

#text("Dear Professor Tao,")

#text("in the Exercise 8, it should be $a_1 = a_2 = – a_3$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-633060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("I have a question about Exercise 5:")

#text("Set")#linebreak()#text(" ")#mi("A := \\{ (y_1,y_2,y_3,y_4) \\in \\mathbb{T}^4 : 0 \\leq \\{ \\alpha y^2 \\} \\leq \\delta \\}")#text(".")

#text("By equidistribution, it looks like")#linebreak()#text(" ")#tao-math("\\left|\\{ (n,r) \\in [N]^2 : (n,n-r,n-2r,n-3r) \\in A \\}\\right| = ( N^2 + o_{N \\to \\infty}(1) ) \\cdot \\int_{y \\cdot k_0= 0} \\mathbf{1}_A(y) \\ dy", block: false)

#text("where ")#mi("k_0 = \\langle 1, -3,3,1 \\rangle \\in \\mathbb{Z}^4")

#text("I’m getting a little confused because it looks to me like")#linebreak()#text(" ")#tao-math("\\int_{y \\cdot k_0= 0} \\mathbf{1}_A(y) \\ dy = \\left|\\{ y : 0 \\leq \\alpha y^2 \\leq \\delta\\}\\right|^3 = (\\delta/\\alpha)^{3/2}", block: false)#text(",")

#text("which differs from the desired ")#mi("\\delta^3")#text(" bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-633065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2021")])]

#text("The set ")#mi("A")#text(" you write is not well defined (if ")#mi("y \\in \\mathbb{T}")#text(", then ")#mi("\\alpha y^2")#text(" is not well-defined). You may be thinking of ")#mi("B := \\{ (n_1,n_2,n_3,n_4) \\in {\\mathbf Z}^4: 0 \\leq \\{ \\alpha n_i^2 \\} \\leq \\delta\\ \\forall i=1,2,3,4\\}")#text(" instead. In this case, the indicator function ")#mi("1_A")#text(" in your expression should be replaced by ")#mi("1_{[0,\\delta]^4}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-633089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2021")])]

#text("Thanks a lot!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6151aa379f338bffdaf264c1c7edff99b085c752ffa28b30d7d6df67fd97e6e8-1baeb4109d375378053065f98f8e5f237b9768612299c333fa2962f305717fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Killua Zoldyck")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-637026")[#strong[#text("Killua Zoldyck")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2021")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the statement below equation labelled ")#mi("(13)")#text(" shouldn’t it be ")#mi("c\\in \\mathbb{R}")#text(" as the ")#mi("\\phi_i^{\\prime}s")#text(" are taking values in ")#mi("\\mathbb{R}\\mathbb{Z}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Killua Zoldyck")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-639130")[#strong[#text("Killua Zoldyck")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2022")])]

#text("@Anonymous and @farlabb can we please connect via email at ")#link("mailto:lucifer3099@gmail.com")[#text("lucifer3099@gmail.com")]#text(" as i wanted to discuss some of the exercises.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/#comment-639790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("Dear Prof Tao,")#linebreak()#text(" Can you please provide me with an hint on how to approach the exercise 4 in this section using the exercise 21 in section 1 (like explain how to work with the given hint) ? It is not very clear to me how to make use of exercise 21 in section 1.")

#emph[#text("[Approximate the cutoff ")#mi("1_{[0,\\delta]}( x \\text{ mod } 1)")#text(" by a trigonometric polynomial, so that the indicator function of ")#mi("A")#text(" can be approximated by a finite linear combination of functions of the forn ")#mi("n \\mapsto e(k \\alpha n^2)")#text(". -T]")]
]
