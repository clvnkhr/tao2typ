// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/
// Converted to Typst by tao2typ: "2026-10-14T07:00:06.322749+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")[#text("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We continue our study of ")#mi("\\kappa")#text("-solutions. In the ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("previous lecture")]#text(" we primarily exploited the non-negative curvature of such solutions; in this lecture and the next, we primarily exploit the ancient nature of these solutions, together with the finer analysis of the two scale-invariant monotone quantities we possess (Perelman entropy and Perelman reduced volume) to obtain a important scaling limit of ")#mi("\\kappa")#text("-solutions, the ")#emph[#text("asymptotic gradient shrinking soliton")]#text(" of such a solution.")

#text("The main idea here is to exploit what I have called the ")#emph[#text("infinite convergence principle")]#text(" in a ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("previous post")]#text(": that every bounded monotone sequence converges. In the context of ")#mi("\\kappa")#text("-solutions, we can apply this principle to either of our monotone quantities: the ")#emph[#text("Perelman entropy")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu(g(t),\\tau) := \\inf \\{ {\\mathcal W}(M,g(t),f,\\tau): \\int_M (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu = 1 \\}")]]

#text("where ")#mi("\\tau := -t")#text(" is the backwards time variable and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\mathcal W}(M,g(t),f,\\tau) := \\int_M (\\tau(\\left|\\nabla f\\right|^2 + R) + f - d) (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu,", block: true)]]

#text("or the")#emph[#text(" Perelman reduced volume")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\tilde V_{(0,x_0)}(-\\tau) := \\tau^{-d/2} \\int_M e^{-l_{(0,x_0)}(-\\tau,x)}\\ d\\mu(x)")]]

#text("where ")#mi("x_0 \\in M")#text(" is a fixed base point. As pointed out in Lecture 11, these quantities are related, and both are non-increasing in ")#mi("\\tau")#text(".")

#text("The reduced volume starts off at ")#mi("(4\\pi)^{d/2}")#text(" when ")#mi("\\tau=0")#text(", and so by the infinite convergence principle it approaches some asymptotic limit ")#mi("0 \\leq \\tilde V_{(0,x_0)}(-\\infty) \\leq (4\\pi)^{d/2}")#text(" as ")#mi("\\tau \\to -\\infty")#text(". (We will later see that this limit is strictly between 0 and ")#mi("(4\\pi)^{d/2}")#text(".) On the other hand, the reduced volume is invariant under the scaling")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("g^{(\\lambda)}(t) := \\frac{1}{\\lambda^2} g( \\lambda^2 t ),")]]

#text("in the sense that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tilde V_{(0,x_0)}^{(\\lambda)}(-\\tau) = \\tilde V_{(0,x_0)}(-\\lambda^2 \\tau).")]]

#text("Thus, as we send ")#mi("\\lambda \\to \\infty")#text(", the reduced volumes of the rescaled flows ")#mi("t \\mapsto (M, g^{(\\lambda)}(t))")#text(" (which are also ")#mi("\\kappa")#text("-solutions) converge pointwise to a constant ")#mi("\\tilde V_{(0,x_0)}(-\\infty)")#text(".")

#text("Suppose that we could somehow “take a limit” of the flows ")#mi("t \\mapsto (M, g^{(\\lambda)}(t))")#text(" (or perhaps a subsequence of such flows) and obtain some limiting flow ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(". ")#emph[#text("Formally")]#text(", such a flow would then have a constant reduced volume of ")#mi("\\tilde V_{(0,x_0)}(-\\infty)")#text(". On the other hand, the reduced volume is monotone. If we could have a criterion as to when the reduced volume became stationary, we could thus classify all possible limiting flows ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(", and thus obtain information about the asymptotic behaviour of ")#mi("\\kappa")#text("-solutions (at least along a subsequence of scales going to infinity).")

#text("We will carry out this program more formally in the next lecture, in which we define the concept of an ")#emph[#text("asymptotic gradient-shrinking soliton")]#text(" of a ")#mi("\\kappa")#text("-solution.")#linebreak()#text(" In this lecture, we content ourselves with a key step in this program, namely to characterise when the Perelman entropy or Perelman reduced volume becomes stationary; this requires us to revisit the theory we have built up in the last few lectures. It turns out that, roughly speaking, this only happens when the solution is a gradient shrinking soliton, thus at any given time ")#mi("-\\tau")#text(" one has an equation of the form ")#mi("\\text{Ric} + \\text{Hess}(f) = \\lambda g")#text(" for some ")#mi("f: M \\to {\\Bbb R}")#text(" and ")#mi("\\lambda > 0")#text(". Our computations here will be somewhat formal in nature; we will make them more rigorous in the next lecture.")

#text("The material here is largely based on ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" and the ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("first paper of Perelman")]#text(". Closely related treatments also appear in the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(" and the ")#link("http://arxiv.org/abs/math/0612069")[#text("paper of Cao-Zhu")]#text(".")

#metadata(none) <tao-c016c2e84c4705f18988>

#heading(level: 1)[#text("— Stationarity of the Perelman entropy —")]

#text("We begin with a discussion of the Perelman entropy, which is simpler than the Perelman reduced volume but which will serve as a model for the latter. To simplify the exposition we shall argue at a formal level, assuming all integrals converge, that all functions are smooth, all infima are actually attained, etc.")

#text("In Exercise 9, we already saw that if ")#mi("f: (-\\infty,0] \\times M \\to {\\Bbb R}")#text(" solves the nonlinear backwards heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("f_\\tau = \\Delta f - \\left|\\nabla f\\right|_g^2 + R - \\frac{d}{2\\tau}", block: true)]]

#text("then the quantity ")#mi("{\\mathcal W}(M,g(t),f,\\tau)")#text(" obeyed the monotonicity formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{d}{d\\tau} {\\mathcal W}(M,g(t),f,\\tau) = -\\int_M H\\ d\\mu")]]

#text("where H is the non-negative quantity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("H := 2\\tau \\left|\\text{Ric} + \\text{Hess}(f)- \\frac{1}{2\\tau} g\\right|^2 (4\\pi \\tau)^{-d/2} e^{-f}.", block: true)]]

#text("In terms of the function ")#mi("u := (4\\pi \\tau)^{-d/2} e^{-f}")#text(", we also recall that (6) can be rewritten as the adjoint heat equation ")#mi("u_\\tau = \\Delta u + Ru")#text(". In particular, we see that if ")#mi("{\\mathcal W}(M,g(t),f,\\tau)")#text(" is ever stationary at some time ")#mi("\\tau")#text(", then the solution must obey the gradient shrinking soliton equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\text{Ric} + \\text{Hess}(f) = \\frac{1}{2\\tau} g")]]

#text("at that time ")#mi("\\tau")#text(". Using the uniqueness properties of Ricci flow (and of the backwards heat equation), one can then show that (9) persists for all subsequent times. Formally at least, this argument also shows that the Perelman reduced entropy ")#mi("\\mu(M,g,\\tau)")#text(" can only be stationary on gradient shrinking solitons.")

#text("Let us analyse the monotonicity formula (7) further. If we write")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("v := (\\tau(\\left|\\nabla f\\right|^2 + R) + f - d) (4\\pi\\tau)^{-d/2} e^{-f} = (\\tau(\\left|\\nabla f\\right|^2 + R) + f - d) u", block: true)]]

#text("then (7) asserts that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{d}{d\\tau} \\int_M v\\ d\\mu = -\\int_M H\\ d\\mu.")]]

#text("Since ")#mi("\\frac{d}{d\\tau} d\\mu = R\\ d\\mu")#text(", we thus see that ")#mi("\\partial_\\tau v")#text(" must equal ")#mi("-H-Rv")#text(" plus a quantity which integrates to zero (i.e. a divergence). Given this, and given the fact that u (which is a close relative to v) obeys the adjoint heat equation), the following fact is then not so surprising:")

#strong[#text("Exercise 1.")]#text(" With the above assumptions, show that v obeys the forced adjoint heat equation")

#align(center)[#mi("v_\\tau = \\Delta v - Rv - H")#text(". ")#mi("\\diamond")#text(" (12)")]

#heading(level: 1)[#text("— Stationarity in the Bishop-Gromov reduced volume —")]

#text("Before we turn to the monotonicity of the Perelman reduced volume, we first consider the simpler model case of the Bishop-Gromov reduced volume (Corollary 1 of ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text("). An inspection of the proof of that result reveals that the key point was to establish the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\Delta r \\leq \\frac{d-1}{r}")]]

#text("on a manifold ")#mi("(M,g)")#text(" of non-negative Ricci curvature ")#mi("\\text{Ric} \\geq 0")#text(", where ")#mi("r := d(x,x_0)")#text(" for some fixed origin ")#mi("x_0")#text(". To simplify the exposition let us assume we are inside the injectivity radius, and away from the origin, to avoid any issues with lack of smoothness.")

#text("We gave a proof of (13) in ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" using the second variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\frac{d^2}{ds^2} E(\\gamma)|_{s=0} = \\int_0^1 \\left|\\nabla_X Y\\right|_g^2 - g(\\text{Riem}(X, Y) Y, X)\\ dt", block: true)]]

#text("whenever ")#mi("\\gamma: (-\\varepsilon,\\varepsilon) \\times [0,1] \\to M")#text(" is a geodesic at ")#mi("s=0")#text(", with ")#mi("X = \\partial_t \\gamma")#text(" and ")#mi("Y := \\partial_s \\gamma")#text("; (see equation (17) of ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text("). From this (and the first variation formula) we obtain the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\text{Hess}(r)(v,v) \\leq \\int_0^1 \\left|\\nabla_X Y\\right|_g^2 - g(\\text{Riem}(X, Y) Y, X)\\ dt", block: true)]]

#text("for any vector field Y along the minimising geodesic from ")#mi("x_0")#text(" to x that equals 0 at ")#mi("t=0")#text(" and equals v at ")#mi("t=1")#text(".")

#text("Of course, the only way that (15) can be an equality is if Y minimises the right-hand side subject to the constraints just mentioned. A standard calculus of variations computation lets one extract the ")#link("http://en.wikipedia.org/wiki/Euler-Lagrange_equation")[#text("Euler-Lagrange equation")]#text(" for this variational problem:")

#strong[#text("Exercise 2.")]#text(" Show that if (15) is obeyed with equality, then Y must obey the ")#link("http://en.wikipedia.org/wiki/Jacobi_equation")[#text("Jacobi equation")]

#align(center)[#mi("\\nabla_X \\nabla_X Y + \\text{Riem}(Y,X) X = 0")#text(". ")#mi("\\diamond")#text(" (16)")]

#text("Vector fields obeying (16) are known as ")#emph[#text("Jacobi fields")]#text(".")

#text("Recall from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" that the inequality (13) was derived by applying (15) for v in an arbitrary orthonormal frame, and with ")#mi("Y(t) := tv")#text(", where v was extended by parallel transport along ")#mi("\\gamma")#text(" (thus ")#mi("\\nabla_X v = 0")#text("). Thus, in order for (13) to be obeyed with equality, the fields ")#mi("Y(t)=tv")#text(" must be a Jacobi field for each v. Applying (16), and noting that ")#mi("X = \\partial_r")#text(", we conclude that we must have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\text{Riem}( \\cdot, \\partial_r ) \\partial_r = 0")]]

#text("along ")#mi("\\gamma")#text(" in order for (13) to be obeyed with equality. The converse is also true:")

#strong[#text("Exercise 3. ")]#text(" Establish the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\nabla_{\\partial r} \\text{Hess}(r)_{\\alpha \\beta} + \\text{Hess}(r)_{\\alpha \\gamma} \\text{Hess}(r)^\\gamma_\\beta = - \\text{Riem}_{\\alpha \\gamma \\delta \\beta} (\\partial_r)^{\\gamma} (\\partial_r)^{\\delta}")]]

#text("in the injectivity region, and conclude (13) is true with equality whenever (17) holds along the minimising geodesic ")#mi("\\gamma")#text(". ")#mi("\\diamond")

#text("As a consequence of the above analysis, we see that the Bishop-Gromov reduced volume can only be stationary on a sphere when (17) holds on the ball within that sphere.")

#text("We can also use the theory of Jacobi fields to get a more precise formula for ")#mi("\\text{Hess}(r)")#text(" (and hence ")#mi("\\Delta r")#text("). The key observation is that the Jacobi equation (16) can be written as the linearisation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\nabla_Y( \\nabla_X X ) = 0")]]

#text("of the geodesic equation ")#mi("\\nabla_X X = 0")#text(". This is ultimately unsurprising, since the geodesic equation and the Jacobi equation come from the Euler-Lagrange equations for the energy functional and a quantity related to a variation of the energy functional. But it allows us (at least inside the injectivity region, which also turns out (again, unsurprisingly) to be the region where the boundary value problem for the Jacobi equation always has unique solutions), to view Jacobi fields as the infinitesimal deformation field of geodesics.")

#text("Now let ")#mi("\\gamma: (-\\varepsilon,\\varepsilon) \\times [0,1] \\to M")#text(" be a family of geodesics ")#mi("\\gamma_s: [0,1] \\to M")#text(" from ")#mi("x_0")#text(" to ")#mi("x(s)")#text(", so that ")#mi("\\nabla_X X = 0")#text(" and so (by (19)) Y is a Jacobi field for each s with Y(s,0)=0 and ")#mi("Y(s,1) = v(s) := x^{\\prime}(s)")#text(". (In general one no longer expects to have Y be geodesic in the s direction, i.e. ")#mi("\\nabla_Y Y")#text(" need not be zero, but this will not concern us.) The first variation formula (i.e. the ")#link("http://en.wikipedia.org/wiki/Gauss%27s_lemma_%28Riemannian_geometry%29")[#text("Gauss lemma")]#text(" ")#mi("\\nabla r = X(1)")#text(") then gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\nabla_{v} r = g(  X(\\cdot,1),  v )")]]

#text("and differentiating this again gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\nabla_{v}  \\nabla_{v} r = g(  \\nabla_v X(\\cdot,1),  v ) + g( X(\\cdot,1), \\nabla_v v ).")]]

#text("Expanding out the left-hand side by the product rule and using (20) and the torsion-free identity ")#mi("\\nabla_Y X = \\nabla_X Y")#text(" we conclude the second variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\text{Hess}(r)(v,v) = g( \\nabla_X Y(1), v )")]]

#text("whenever ")#mi("Y")#text(" is a Jacobi field along the minimal geodesic ")#mi("\\gamma")#text(" from ")#mi("x_0")#text(" to ")#mi("x")#text(" with Y(0)=0 and Y(1)=v, and whenever one is inside the injectivity region.")

#strong[#text("Exercise 4.")]#text(" Let Y be a Jacobi field with Y(0)=0 and Y(1)=v, and suppose one is inside the injectivity region. Use (22) and (16) to show that (15) in fact holds with equality, thus providing a converse to Exercise 2. (Hint: apply the fundamental theorem of calculus to the right-hand side of (22).) ")#mi("\\diamond")

#heading(level: 1)[#text("— Constancy of the Perelman reduced volume —")]

#text("We can obtain parabolic analogues of the above elliptic arguments to conclude when the Perelman reduced volume is stationary. Again, let us argue formally and assume that we are working inside the injectivity domain from a point ")#mi("(0,x_0)")#text(".")

#text("Write ")#mi("l = l_{(0,x_0)}")#text(". Recall from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" that the proof of monotonicity of reduced volume relied on the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\partial_{\\tau} l - \\Delta l + \\left|\\nabla l\\right|^2 - R + \\frac{d}{2\\tau} \\geq 0", block: true)]]

#text("which in turn followed from the three equalities and estimates")

#tao-aligned(keep: true)[


#tao-math("\\nabla l  & = X", block: true, numbering: n => [#text("(24)")])



#tao-math("\\partial_\\tau l  & = \\frac{1}{2} R - \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{2\\tau} l", block: true, numbering: n => [#text("(25)")])



#tao-math("\\Delta l  & \\leq \\frac{d}{2\\tau} + \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{2} R - \\frac{1}{2\\tau} l.", block: true, numbering: n => [#text("(26)")])
]

#text("Thus, in order for the reduced volume to be stationary at some time ")#mi("t = -\\tau_1")#text(", one must have (23) (or equivalently, (26)) holding with equality throughout M at this time.")

#text("It is convenient to normalise ")#mi("\\tau_1=1")#text(". Recall from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(" that the proof of (26) proceeded via the second variation formula")

#tao-aligned(keep: true)[


#tao-math("\\frac{d^2}{ds^2} {\\mathcal L}(\\gamma)  & = \\int_0^{1} \\sqrt{\\tau} ( \\text{Hess}(R)(Y,Y)", block: true)



#tao-math(" & + 2 \\left|\\nabla_X Y\\right|^2 - 2 g(\\text{Riem}(X,Y) Y, X))\\ d\\tau", block: true, numbering: n => [#text("(27)")])
]

#text("applied to the vector field ")#mi("Y := \\sqrt{\\tau} v")#text(", where v obeys the ODE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\nabla_X v = - \\text{Ric}(v,\\cdot)^*; v(s,1) = x^{\\prime}(s).")]]

#text("As in the elliptic case, equality in (26) can only hold if Y obeys the Euler-Lagrange equation for the right-hand side of (23), which can be computed to be")

#align(center)[#tao-fit-display[#mitex("\\nabla_X \\nabla_X Y + \\text{Riem}(Y,X) X - \\frac{1}{2} \\nabla_Y( \\nabla R )")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("+ \\frac{1}{2\\tau} \\nabla_X Y + 2 (\\nabla_Y \\text{Ric})(X,\\cdot)^* + 2\\text{Ric}(\\nabla_X Y, \\cdot)^* = 0.")]]

#text("Solutions of (29) are known as ")#emph[#mi("{\\mathcal L}")#text("-Jacobi fields")]#text(". As in the elliptic case, this equation can be rewritten as the linearisation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\nabla_Y G(X) = 0")]]

#text("of the ")#mi("{\\mathcal L}")#text("-geodesic equation ")#mi("G(X)=0")#text(", where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("G(X) := \\nabla_X X - \\frac{1}{2} \\nabla R + \\frac{1}{2\\tau} X + 2 \\text{Ric}(X,\\cdot)^*")]]

#text("was introduced in ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(".")

#strong[#text("Exercise 5. ")]#text(" Verify (29) and (30). ")#mi("\\diamond")

#text("If ")#mi("\\gamma: (-\\varepsilon,\\varepsilon) \\times [0,\\tau_1] \\to M")#text(" is now a smooth family of minimising ")#mi("{\\mathcal L}")#text("-geodesics from ")#mi("(0,x_0)")#text(" to ")#mi("(-\\tau_1, x_1(s))")#text(", then the variation field ")#mi("Y = \\partial_s X")#text(" is an ")#mi("{\\mathcal L}")#text("-Jacobi field by (30) (and conversely, inside the region of injectivity, any Jacobi field on a minimising geodesic can be extended locally to such a smooth family. The first variation formula (24) gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\nabla_v l = g( X, v )")]]

#text("where ")#mi("v(s) := x^{\\prime}_1(s) = Y(s,1)")#text(", and so on differentiating again and arguing as in the elliptic case we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\text{Hess}(l)(v,v) = g( \\nabla_X Y(1), v )")]]

#text("whenever Y is an ")#mi("{\\mathcal L}")#text("-Jacobi field with Y(0)=0 and Y(1)=v.")

#strong[#text("Exercise 6. ")]#text(" Show (using (31) and the fundamental theorem of calculus, as in Exercise 4) that (33) is equal to (27). ")#mi("\\diamond")

#text("Now we return to our analysis of when the reduced volume is stationary at ")#mi("\\tau=1")#text(". We had found in that case that the vector field ")#mi("Y := \\sqrt{\\tau} v")#text(", where v solved (28), must be a Jacobi field. Combining this with (33) we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\text{Hess}(l)(v,v) = \\frac{1}{2} \\left|v\\right|^2 - \\text{Ric}(v,v)", block: true)]]

#text("for any v, or in other words that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\text{Ric} + \\text{Hess}(l) = \\frac{1}{2} g.")]]

#text("This is for time ")#mi("\\tau=1")#text("; rescaling the above analysis gives more generally that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\text{Ric} + \\text{Hess}(l) = \\frac{1}{2\\tau} g.")]]

#text("We thus conclude (formally, at least) that whenever the reduced volume is stationary, then the manifold is a gradient shrinking soliton (at that instant in time, at least) with potential function given by the reduced length. (The computation is only formal at present, because we have not addressed the issue of what to do on the ")#mi("{\\mathcal L}")#text("-cut locus.)")

#strong[#text("Exercise 7.")]#text(" If (26) is obeyed with equality, show that the function ")#mi("f := l")#text(" obeys (6) and that ")#mi("{\\mathcal W}(M,g(t),f,\\tau) = 0")#text(" (cf. the computations at the end of ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text("). From this and (7), deduce another (formal) proof of (36) whenever the reduced volume is stationary on an open time interval. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" We have just seen that in the case of stationary reduced volume, the function f that appears in the entropy functional can be taken to be equal to the reduced length l. In general, one can take f to be a function bounded from above by the reduced length; see Corollary 9.5 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Ricci flows of maximal reduced volume —")]

#text("Recall that the reduced volume ")#mi("\\tilde V_{(0,x_0)}(-\\tau)")#text(" is equal to ")#mi("(4\\pi)^{d/2}")#text(" in the case of Euclidean space, and converges to this value in the limit ")#mi("\\tau \\to 0")#text(" in the case of complete Ricci flows of bounded curvature")#linebreak()#text(" (this can be shown by an analysis of the ")#mi("{\\mathcal L}")#text("-exponential map for small values of ")#mi("\\tau")#text(", as discussed in ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text("). From this and the monotonicity of reduced volume we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\tilde V_{(0,x_0)}(-\\tau) \\leq (4\\pi)^{d/2}")]]

#text("for all such flows. We now characterise when equality occurs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("Suppose that ")#mi("t \\mapsto (M,g(t))")#text(" is a connected Ricci flow of bounded curvature on ")#mi("{}[-\\tau_1,0]")#text(" for some ")#mi("\\tau_1 > 0")#text(", such that (37) is obeyed with equality at the initial time ")#mi("-\\tau_1")#text(" for some point ")#mi("x_0 \\in M")#text(". Then M is Euclidean.")
]

#strong[#text("Proof.")]#text(" We give a sketch here only; full details can be found in Proposition 7.27 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(".")

#text("An inspection of the proof of monotonicity of reduced volume (especially as viewed through the ")#mi("{\\mathcal L}")#text("-exponential map, as in ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text(") reveals that the domain of injectivity ")#mi("\\Omega \\subset T_{x_0} M")#text(" of the exponential map must have full measure, otherwise there will be a loss of reduced volume. The previous analysis then reveals that the equation (32) must hold outside of the cut locus; as l is Lipschitz and the manifold is smooth, one can then take limits and conclude that (32) holds globally (and so l is in fact smooth).")

#text("Combining (32) with the Ricci flow equation we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\frac{d}{dt} g = {\\mathcal L}_{\\nabla l} g - \\frac{1}{\\tau} g,")]]

#text("thus the metric is shrinking and also deforming by a vector field. In particular this gives an analogous equation for the magnitude ")#tao-math("\\left|\\text{Riem}\\right|_g^2", block: false)#text(" of curvature (see equations (22), (26)):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\frac{d}{dt}  \\left|\\text{Riem}\\right|_g^2 = \\nabla_{\\nabla l} \\left|\\text{Riem}\\right|_g^2 + \\frac{1}{\\tau} \\left|\\text{Riem}\\right|_g^2.", block: true)]]

#text("A maximum principle argument (which of course works in the absence of the dissipation term) then shows that if ")#tao-math("\\sup_x \\left|\\text{Riem}\\right|_g^2", block: false)#text(" is strictly positive at one time, then it blows up as ")#mi("\\tau \\to 0")#text(" (like ")#mi("1/\\tau")#text(", in fact), which is absurd; and so this supremum must always be zero. In other words, the manifold is flat, and is therefore the quotient of ")#mi("{\\Bbb R}^d")#text(" by some discrete subgroup. But as the exponential map is almost always in the injectivity domain, this subgroup must be trivial, and the claim follows. ")#mi("\\Box")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/#comment-30083")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] nature of such solutions) we extract a limit. Formally, the reduced volume is now constant and so Lecture 14 suggests that this limit is a gradient soliton; however, some care is required to make this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/#comment-31967")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2008")])]

#text("I am having trouble following how the Jacobi equation (16) can be written as (19) and as a consequence how we can view Jacobi fields as as the infinitestimal deformation field of geodesics. Please elaborate.")

#text("Somewhat related, and hopefully not off the topic question: I know the conjugate point of a point in a sphere is antipodal point. Is the conjugate point of a point in a RP^n itself?")

#text("A lot of the derivations above are under the setting of minimizing geodesic inside the injectivity radius for simplification. What’s the strategy otherwise? If this is to be covered in the succeeding lectures, please ignore this question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/#comment-31978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")])]

#text("Dear ky,")

#text("If X and Y are the vector fields corresponding to the t and s directions, then [X,Y] = 0, and so ")#mi("\\nabla_X Y = \\nabla_Y X")#text(" and ")#mi("{}[\\nabla_Y, \\nabla_X] = \\text{Riem}(Y,X)")#text(". From this one can easily deduce (19) from (16).")

#text("In projective space, a point p is indeed conjugate to itself, and there are no other pairs of conjugate points; this follows from knowledge of conjugate points of the sphere, since projective space is a quotient of the sphere.")

#text("Outside the cut locus, the non-uniqueness of minimising geodesics leads to non-smoothness of the distance function, which causes a number of technical difficulties. One can largely resolve this by using the method of barrier functions, estimating the distance function above and below by smoother functions (for instance, by varying the base point a little bit to move the cut locus), as well as the theory of distributions (exploiting the fact that the cut locus has measure zero). This is somewhat technical and I do not cover it in detail in my notes, but you can see Morgan-Tian’s book for details (in the parabolic case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/#comment-31991")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2008")])]

#text("Dear Professor Tao:")

#text("Both your answers to my questions have been very appreciated. Thank you very much.")
]
