// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/
// Converted to Typst by tao2typ: "2026-10-14T10:29:17.627987+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for an Euler-type equation in vorticity stream form", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for an Euler-type equation in vorticity stream form")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/")[#text("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve been meaning to return to fluids for some time now, in order to build upon ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("my construction two years ago")]#text(" of a solution to an averaged Navier-Stokes equation that exhibited finite time blowup. (I recently spoke on this work in the ")#link("http://web.math.princeton.edu/conference/Klainerman2016/")[#text("recent conference in Princeton in honour of Sergiu Klainerman")]#text("; my slides for that talk ")#link("https://terrytao.wordpress.com/wp-content/uploads/2016/02/navier-klainerman.pdf")[#text("are here")]#text(".)")

#text("One of the biggest deficiencies with my previous result is the fact that the averaged Navier-Stokes equation does not enjoy any good equation for the vorticity ")#mi("{\\omega = \\nabla \\times u}")#text(", in contrast to the true Navier-Stokes equations which, when written in vorticity-stream formulation, become")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\omega + (u \\cdot \\nabla) \\omega  & = (\\omega \\cdot \\nabla) u + \\nu \\Delta \\omega", block: true)



#tao-math("u  & = (-\\Delta)^{-1} (\\nabla \\times \\omega).", block: true)
]

#text("(Throughout this post we will be working in three spatial dimensions ")#mi("{{\\bf R}^3}")#text(".) So one of my main near-term goals in this area is to exhibit an equation resembling Navier-Stokes as much as possible which enjoys a vorticity equation, and for which there is finite time blowup.")

#text("Heuristically, this task should be easier for the Euler equations (i.e. the zero viscosity case ")#mi("{\\nu=0}")#text(" of Navier-Stokes) than the viscous Navier-Stokes equation, as one expects the viscosity to only make it easier for the solution to stay regular. Indeed, morally speaking, the assertion that finite time blowup solutions of Navier-Stokes exist should be roughly equivalent to the assertion that finite time blowup solutions of Euler exist which are “Type I” in the sense that all Navier-Stokes-critical and Navier-Stokes-subcritical norms of this solution go to infinity (which, as explained in ")#link("https://terrytao.wordpress.com/wp-content/uploads/2016/02/navier-klainerman.pdf")[#text("the above slides")]#text(", heuristically means that the effects of viscosity are negligible when compared against the nonlinear components of the equation). In vorticity-stream formulation, the Euler equations can be written as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\omega + (u \\cdot \\nabla) \\omega  & = (\\omega \\cdot \\nabla) u", block: true)



#tao-math("u  & = (-\\Delta)^{-1} (\\nabla \\times \\omega).", block: true)
]

#text("As discussed in ")#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("this previous blog post")]#text(", a natural generalisation of this system of equations is the system ")#metadata(none) <tao-ff74fbaa8a3eb72f4ee1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u")]]





#align(center)[#tao-fit-display[#mitex("u = T (-\\Delta)^{-1} (\\nabla \\times \\omega).")]]

#text("where ")#mi("{T}")#text(" is a linear operator on divergence-free vector fields that is “zeroth order” in some sense; ideally it should also be invertible, self-adjoint, and positive definite (in order to have a Hamiltonian that is comparable to the kinetic energy ")#tao-math("{\\frac{1}{2} \\int_{{\\bf R}^3} \\left|u\\right|^2}", block: false)#text("). (In the ")#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("previous blog post")]#text(", it was observed that the surface quasi-geostrophic (SQG) equation could be embedded in a system of the form ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(".) The system ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(" has many features in common with the Euler equations; for instance vortex lines are transported by the velocity field ")#mi("{u}")#text(", and ")#link("https://en.wikipedia.org/wiki/Kelvin%27s_circulation_theorem")[#text("Kelvin’s circulation theorem")]#text(" is still valid.")

#text("So far, I have not been able to fully achieve this goal. However, I have the following partial result, stated somewhat informally:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" There is a “zeroth order” linear operator ")#mi("{T}")#text(" (which, unfortunately, is not invertible, self-adjoint, or positive definite) for which the system ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(" exhibits smooth solutions that blowup in finite time.")
]

#text("The operator ")#mi("{T}")#text(" constructed is not quite a zeroth-order pseudodifferential operator; it is instead merely in the “forbidden” symbol class ")#mi("{S^0_{1,1}}")#text(", and more precisely it takes the form ")#metadata(none) <tao-a46e5d2bbe2d3b05b2d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("T v = \\sum_{j \\in {\\bf Z}} 2^{3j} \\langle v, \\phi_j \\rangle \\psi_j")]]



#text(" for some compactly supported divergence-free ")#mi("{\\phi,\\psi}")#text(" of mean zero with")

#align(center)[#tao-fit-display[#mitex("\\phi_j(x) := \\phi(2^j x); \\quad \\psi_j(x) := \\psi(2^j x)")]]

#text("being ")#mi("{L^2}")#text(" rescalings of ")#mi("{\\phi,\\psi}")#text(". This operator is still bounded on all ")#mi("{L^p({\\bf R}^3)}")#text(" spaces ")#mi("{1 < p < \\infty}")#text(", and so is arguably still a zeroth order operator, though not as convincingly as I would like. Another, less significant, issue with the result is that the solution constructed does not have good spatial decay properties, but this is mostly for convenience and it is likely that the construction can be localised to give solutions that have reasonable decay in space. But the biggest drawback of this theorem is the fact that ")#mi("{T}")#text(" is not invertible, self-adjoint, or positive definite, so in particular there is no non-negative Hamiltonian for this equation. It may be that some modification of the arguments below can fix these issues, but I have so far been unable to do so. Still, the construction does show that the circulation theorem is insufficient by itself to prevent blowup.")

#text("We sketch the proof of the above theorem as follows. We use the barrier method, introducing the time-varying hyperboloid domains")

#align(center)[#tao-fit-display[#mitex("\\Omega(t) := \\{ (r,\\theta,z): r^2 \\leq 1-t + z^2 \\}")]]

#text("for ")#mi("{t>0}")#text(" (expressed in cylindrical coordinates ")#mi("{(r,\\theta,z)}")#text("). We will select initial data ")#mi("{\\omega(0)}")#text(" to be ")#mi("{\\omega(0,r,\\theta,z) = (0,0,\\eta(r))}")#text(" for some non-negative even bump function ")#mi("{\\eta}")#text(" supported on ")#mi("{[-1,1]}")#text(", normalised so that")

#align(center)[#tao-fit-display[#mitex("\\int\\int \\eta(r)\\ r dr d\\theta = 1;")]]

#text("in particular ")#mi("{\\omega(0)}")#text(" is divergence-free supported in ")#mi("{\\Omega(0)}")#text(", with vortex lines connecting ")#mi("{z=-\\infty}")#text(" to ")#mi("{z=+\\infty}")#text(". Suppose for contradiction that we have a smooth solution ")#mi("{\\omega}")#text(" to ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(" with this initial data; to simplify the discussion we assume that the solution behaves well at spatial infinity (this can be justified with the choice ")#link(<tao-a46e5d2bbe2d3b05b2d2>)[#text("(2)")]#text(" of vorticity-stream operator, but we will not do so here). Since the domains ")#mi("{\\Omega(t)}")#text(" disconnect ")#mi("{z=-\\infty}")#text(" from ")#mi("{z=+\\infty}")#text(" at time ")#mi("{t=1}")#text(", there must exist a time ")#mi("{0 < T_* < 1}")#text(" which is the first time where the support of ")#mi("{\\omega(T_*)}")#text(" touches the boundary of ")#mi("{\\Omega(T_*)}")#text(", with ")#mi("{\\omega(t)}")#text(" supported in ")#mi("{\\Omega(t)}")#text(".")

#text("From ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(" we see that the support of ")#mi("{\\omega(t)}")#text(" is transported by the velocity field ")#mi("{u(t)}")#text(". Thus, at the point of contact of the support of ")#mi("{\\omega(T_*)}")#text(" with the boundary of ")#mi("{\\Omega(T_*)}")#text(", the inward component of the velocity field ")#mi("{u(T_*)}")#text(" cannot exceed the inward velocity of ")#mi("{\\Omega(T_*)}")#text(". We will construct the functions ")#mi("{\\phi,\\psi}")#text(" so that this is not the case, leading to the desired contradiction. (Geometrically, what is going on here is that the operator ")#mi("{T}")#text(" is pinching the flow to pass through the narrow cylinder ")#mi("{\\{ z, r = O( \\sqrt{1-t} )\\}}")#text(", leading to a singularity by time ")#mi("{t=1}")#text(" at the latest.)")

#text("First we observe from conservation of circulation, and from the fact that ")#mi("{\\omega(t)}")#text(" is supported in ")#mi("{\\Omega(t)}")#text(", that the integrals")

#align(center)[#tao-fit-display[#mitex("\\int\\int \\omega_z(t,r,\\theta,z) \\ r dr d\\theta")]]

#text("are constant in both space and time for ")#mi("{0 \\leq t \\leq T_*}")#text(". From the choice of initial data we thus have")

#align(center)[#tao-fit-display[#mitex("\\int\\int \\omega_z(t,r,\\theta,z) \\ r dr d\\theta = 1")]]

#text("for all ")#mi("{t \\leq T_*}")#text(" and all ")#mi("{z}")#text(". On the other hand, if ")#mi("{T}")#text(" is of the form ")#link(<tao-a46e5d2bbe2d3b05b2d2>)[#text("(2)")]#text(" with ")#mi("{\\phi = \\nabla \\times \\eta}")#text(" for some bump function ")#mi("{\\eta = (0,0,\\eta_z)}")#text(" that only has ")#mi("{z}")#text("-components, then ")#mi("{\\phi}")#text(" is divergence-free with mean zero, and")

#tao-aligned(keep: true)[


#tao-math("\\langle (-\\Delta) (\\nabla \\times \\omega), \\phi_j \\rangle  & = 2^{-j} \\langle (-\\Delta) (\\nabla \\times \\omega), \\nabla \\times \\eta_j \\rangle", block: true)



#tao-math(" & = 2^{-j} \\langle \\omega, \\eta_j \\rangle", block: true)



#tao-math(" & = 2^{-j} \\int\\int\\int \\omega_z(t,r,\\theta,z) \\eta_z(2^j r, \\theta, 2^j z)\\ r dr d\\theta dz,", block: true)
]

#text("where ")#mi("{\\eta_j(x) := \\eta(2^j x)}")#text(". We choose ")#mi("{\\eta_z}")#text(" to be supported in the slab ")#mi("{\\{ C \\leq z \\leq 2C\\}}")#text(" for some large constant ")#mi("{C}")#text(", and to equal a function ")#mi("{f(z)}")#text(" depending only on ")#mi("{z}")#text(" on the cylinder ")#mi("{\\{ C \\leq z \\leq 2C; r \\leq 10C \\}}")#text(", normalised so that ")#mi("{\\int f(z)\\ dz = 1}")#text(". If ")#mi("{C/2^j \\geq (1-t)^{1/2}}")#text(", then ")#mi("{\\Omega(t)}")#text(" passes through this cylinder, and we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\langle (-\\Delta) (\\nabla \\times \\omega), \\phi_j \\rangle  & = -2^{-j} \\int f(2^j z)\\ dz", block: true)



#tao-math(" & = 2^{-2j}.", block: true)
]

#text("Inserting ths into ")#link(<tao-a46e5d2bbe2d3b05b2d2>)[#text("(2)")]#text(", ")#link(<tao-ff74fbaa8a3eb72f4ee1>)[#text("(1)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("u = \\sum_{j: C/2^j \\geq (1-t)^{1/2}} 2^j \\psi_j + \\sum_{j: C/2^j < (1-t)^{1/2}} c_j(t) \\psi_j")]]

#text("for some coefficients ")#mi("{c_j(t)}")#text(". We will not be able to control these coefficients ")#mi("{c_j(t)}")#text(", but fortunately we only need to understand ")#mi("{u}")#text(" on the boundary ")#mi("{\\partial \\Omega(t)}")#text(", for which ")#tao-math("{r+\\left|z\\right| \\gg (1-t)^{1/2}}", block: false)#text(". So, if ")#mi("{\\psi}")#text(" happens to be supported on an annulus ")#tao-math("{1 \\ll r+\\left|z\\right| \\ll 1}", block: false)#text(", then ")#mi("{\\psi_j}")#text(" vanishes on ")#mi("{\\partial \\Omega(t)}")#text(" if ")#mi("{C}")#text(" is large enough. We then have")

#align(center)[#tao-fit-display[#mitex("u = \\sum_j 2^j \\psi_j")]]

#text("on the boundary of ")#mi("{\\partial \\Omega(t)}")#text(".")

#text("Let ")#mi("{\\Phi(r,\\theta,z)}")#text(" be a function of the form")

#align(center)[#tao-fit-display[#mitex("\\Phi(r,\\theta,z) = C z \\varphi(z/r)")]]

#text("where ")#mi("{\\varphi}")#text(" is a bump function supported on ")#mi("{[-2,2]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-1,1]}")#text(". We can perform a dyadic decomposition ")#mi("{\\Phi = \\sum_j \\Psi_j}")#text(" where")

#align(center)[#tao-fit-display[#mitex("\\Psi_j(r,\\theta,z) = \\Phi(r,\\theta,z) a(2^j r)")]]

#text("where ")#mi("{a}")#text(" is a bump function supported on ")#mi("{[1/2,2]}")#text(" with ")#mi("{\\sum_j a(2^j r) = 1}")#text(". If we then set")

#align(center)[#tao-fit-display[#mitex("\\psi_j = \\frac{2^{-j}}{r} (-\\partial_z \\Psi_j, 0, \\partial_r \\Psi_j)")]]

#text("then one can check that ")#mi("{\\psi_j(x) = \\psi(2^j x)}")#text(" for a function ")#mi("{\\psi}")#text(" that is divergence-free and mean zero, and supported on the annulus ")#tao-math("{1 \\ll r+\\left|z\\right| \\ll 1}", block: false)#text(", and")

#align(center)[#tao-fit-display[#mitex("\\sum_j 2^j \\psi_j = \\frac{1}{r} (-\\partial_z \\Phi, 0, \\partial_r \\Phi)")]]

#text("so on ")#mi("{\\partial \\Omega(t)}")#text(" (where ")#tao-math("{\\left|z\\right| \\leq r}", block: false)#text(") we have")

#align(center)[#tao-fit-display[#mitex("u = (-\\frac{C}{r}, 0, 0 ).")]]

#text("One can manually check that the inward velocity of this vector on ")#mi("{\\partial \\Omega(t)}")#text(" exceeds the inward velocity of ")#mi("{\\Omega(t)}")#text(" if ")#mi("{C}")#text(" is large enough, and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The type of blowup suggested by this construction, where a unit amount of circulation is squeezed into a narrow cylinder, is of “Type II” with respect to the Navier-Stokes scaling, because Navier-Stokes-critical norms such ")#mi("{L^3({\\bf R}^3)}")#text(" (or at least ")#mi("{L^{3,\\infty}({\\bf R}^3)}")#text(") look like they stay bounded during this squeezing procedure (the velocity field is of size about ")#mi("{2^j}")#text(" in cylinders of radius and length about ")#mi("{2^j}")#text("). So even if the various issues with ")#mi("{T}")#text(" are repaired, it does not seem likely that this construction can be directly adapted to obtain a corresponding blowup for a Navier-Stokes type equation. To get a “Type I” blowup that is consistent with Kelvin’s circulation theorem, it seems that one needs to coil the vortex lines around a loop multiple times in order to get increased circulation in a small space. This seems possible to pull off to me – there don’t appear to be any unavoidable obstructions coming from topology, scaling, or conservation laws – but would require a more complicated construction than the one given above.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("Is it possible that there is some (still unknown) obstruction for the existence of a “good” operator ")#mi("T")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("In principle yes, but I feel this is more a limitation of my methods than the presence of an inherent obstruction. The issue is that I do not have any usable control on the solution ")#mi("\\omega")#text(" other than the conservation of circulation, which is a fairly powerful conservation law but is not fully coercive. As a consequence, I can only control a small fraction of the degrees of freedom of the dynamics – enough to control the carefully designed operator ")#mi("T")#text(" when applied to ")#mi("(-\\Delta)^{-1} (\\nabla \\times \\omega)")#text(" on the boundary of ")#mi("\\Omega(t)")#text(", but little else (for instance, I do not have any good control on the coefficients ")#mi("c_j(t)")#text(" which briefly appear in the analysis). But morally one expects the solution to blowup in a specific fashion, basically like a laminar flow through ")#mi("\\Omega(t)")#text(" at time ")#mi("t")#text(". If one writes down some plausible looking estimates suggested by such a flow model, then the contributions to the dynamics formed by adding terms to ")#mi("T")#text(" to make it invertible, positive definite, and self-adjoint (e.g. a copy of ")#mi("T^*")#text(", and also a small multiple of the identity) should be negligible; similar heuristics suggest that a viscosity term could also be added. But it could be that the fluid departs radically from the laminar flow model, in particular it might prematurely develop some sort of near-singularity in which a large amount of very turbulent behaviour appears, at which point the solution inside ")#mi("\\Omega(t)")#text(" could reach an essentially arbitrary state (subject only to the energy conservation law, which is supercritical with respect to the blowup ansatz and thus increasingly useless as one approaches the putative blowup time) and so I was not able to get any usable control on the degrees of freedom not already controlled by circulation.")

#text("This all comes down to a basic problem when trying to rigorously establish a blowup result in PDE; paradoxically, in order to show that a solution behaves so badly as to create a singularity in finite time, one often needs to first show the solution is ")#emph[#text("good")]#text(" in the sense that it obeys a number of nontrivial estimates, as one often needs to demonstrate that certain “error terms” in the dynamics are negligible compared to the “main terms” that one is trying to use to induce blowup. For instance, one may need to keep the solution uniformly bounded in some rescaled or renormalised coordinates in order to show that it blows up in unrescaled coordinates. There are rare cases (like the one here, or in various “virial identity” based blowup arguments) where there are no error terms in the key estimates and one can then get blowup without needing good control on all aspects of the solution; but the price one pays for this is that one does not get a good understanding of the nature of the blowup, and in particular how stable it is with respect to perturbations of the equation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465960")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("Blowups in fluids are never manifested in reality, regardless of time. Unforutunatelly, asumption and mathematical formulation that fluid can be incompressible, does not have a match in Reality of Nature and as such is core cause of all difficulties and blowups in mathematics relying on such formulation.")#linebreak()#text(" Until that simple fact is recognized, I am afraid that lots of effort and")#linebreak()#text(" time might be wasted.")

#emph[#text("[See page 13 of my slides. The regularity question for Navier-Stokes is an idealised mathematical version of the physically relevant question of whether the Navier-Stokes equations are truly a good model for physical, almost incompressible fluids such as water. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466027")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Thanks for the reference to slide 13, however, I believe that it is not so much question of Navier-Stokes as a model, but of incompressible fluid condition used in NS context.")#linebreak()#text(" Idealized mathematical model goes beyond limits of physical reasonability as it includes expression of pure abstraction of ‘incompressible fluid’ (emphasising here that there is significant difference from ‘incompressible flow’), which is far from a ‘good enough approximation’ as almost incompressible water is unlimited number of times more compressible than non-compressible fluid. In this case, idealized model embodied in incompressible fluid is not achievable in reality and must result with non-realistic abstract results such as singularities, blowups and similar.")#linebreak()#text(" In any real fluid there is fluid constituting physical particle which interacts with directly neighbouring particles. Therefore, by nature of such interaction, density of fluid is not constant as fluid particle tends to ‘flow’ towards area of lower fluid density or oscillates in an limited volume of space in which density is not constant either, depending where particular fluid particle is at any point in time.")#linebreak()#text(" My point- we should look into source of problems, which in my opinion is incompressible fluid condition, not NS equation itself. Everybody is trying to prove or disprove NS problem statement , which includes incompressible fluid condition. However, not all questions are right questions as some questions are simply wrong, so regardless of what one tries to prove or disprove, there is no correct answer to the wrong question.")#linebreak()#text(" We should question question itself which I believe is wrong and which is embodied in ‘incompressible fluid’ condition.")#linebreak()#text(" Thanks!")#linebreak()#text(" Dejan")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466307")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2016")])]

#text("I really think Dejan is making an important and quite valid points. NS is a good model, incompressibility may not be. In other words no real fluid under turbulent motion is actually divergence free. As such we may find that solving the incompressible NS equations yields no progress on the very important problem of turbulence. For example any discussion of the Hamiltonian character of the Euler equations is clearly meaningless for real flows, which have an intrinsically dissipative character. Indeed dissipation is the essence of turbulence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466473")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2016")])]

#text("Bill Rider, a couple of naive questions come to mind: 1) does turbulence appear in numerical solutions to NSE? I thought that it did. 2) Does turbulence appear in experiments with superfluids? I’m not sure. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466518")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2016")])]

#text("I’ll respond to anonymous’ questions two questions.")

#text("Turbulence only occurs the NSE equations when the viscous aspects of the equations are resolved ala DNS. It does not appear a priori in the inviscid Euler, in other words the viscous effects are essential to get the turbulent effects. Treating the Euler equations as anything akin to Hamiltonian produces nothing like turbulence. I really think this line of investigation is a complete dead end. The fact is that our knowledge of turbulence has been quite static since Kolmogorov who probably made the largest advances in the past Century through what are largely dimensional scaling arguments (-5/3 spectrum, the 2/3 and 4/5 laws).")

#text("If we are not progressing in a field its reasonable to ask whether or not our physical model is correct. The entire critique hinges on this question, does incompressible flow contain the right equations for turbulence? Incompressibility is intrinsically unphysical in several regards: thermodynamics are removed, the sound speeds are infinite and true fluid flows of any dynamic significance are not identically divergence-free, they are divergence-free asymptotically. Turbulence is a dissipative phenomena where one of the key aspects of Kolmogorov’s theory, perhaps the most profound result is the amount of dissipation in a turbulent flow asymptotically being independent of Reynolds number. The unphysical nature of incompressibility is never fully articulated in the literature, but it probably should be. Incompressibility is certainly useful in many cases especially engineering, but its derivation from compressible flow is in the adiabatic limit to second order, turbulence is a third oder effect and decisively non-adiabatic in its character.")

#text("The key to any argument here is that compressible flows produce singularities without any difficulty under any circumstance dominated inertially. We only think of shocks in the high Mach number version of fluids. If we look at the formation criteria for shocks, the mechanisms are completely independent of Mach number. The singularities will always form if the viscous forces are small compared to the inertial. Always.")

#text("Superfluids are real fluids and those experiments, real fluids are thermodynamic fluids with real sound speeds albeit with quantum effects. The trick with superfluids turbulence is getting the very small viscosity (almost vanishing we never get to absolute zero, just close) and the very large Reynolds numbers. Its just a way of achieving an idealized turbulent state experimentally.")

#text("If I look at Frisch’s book the statement that turbulence is contained in the incompressible equations is stated axiomatically, not proven. Lack of progress in turbulence theory ought to bring this axiomatic assumption in to question. Until it does I fear progress will be dismal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("K41 (an absolute non-compressible theory) says that the dissipation rate in turbulence is independent of Re. Why is this significant? Assuming it is true, should we find turbulence in the Euler? But this contradicts what you advocated. Incompressibility holds consistently for both NS and Euler?!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466539")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("In my humble opinion, and as per my previous posting, I fully agree with Bill that line of investigation is a complete dead end, however, I would not limit such conclusion just to turbulent flows. Non-physical nature of incompressible fluid and continuity hypothesis in that context I believe represent major barrier in modeling fluid dynamics corresponding to what is happening in nature.")#linebreak()#text(" Let’s take an example of sound propagating through fluid, or waves in general. In the essence of sound (wave) propagation is gradient of fluid density, which for incompressible fluids has to be zero, therefore model based on such strict limitation cannot really represent such important aspect of fluid reality.")#linebreak()#text(" Take a look at this nicely captured sound waves (within a barrel):")

#link("https://www.flickr.com/photos/13084997@N03")[#image("../assets/cb14189af1a21f4ef56876fc38cd172bd8139d0d8b1ace263aef8902422bfb81-bced43a2e33b2ad88d2e2e9f39330a7e53c6e12154809a2d3e2db921eecd39d3.jpg", width: 90%, alt: "Ichneumon wasp")]

#text("In the essence of those images are gradients of fluid density distribution. Using incompressible fluid model would result with perfectly pitch-black images, and could not represent that significant aspect of fluid dynamics.")

#text("I believe that continuum mechanics which does not capture aspects of physical reality embodied in characteristics of molecules and their mutual interactions, cannot represent accurately fluid dynamics which in reality has some important aspects of behavior not captured so far. However, I believe that it is possible to, in mathematically smooth fashion capture all that is important.")#linebreak()#text(" In my humble opinion, I would think that instead of single “Continuum Hypothesis”, principles of “Local Causality”, “Remote Causality” (ie. Gravity) and related mathematical “Continuum Model” would accurately represent fluid dynamics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("Why shocks in high-Ma-number flows are singularities?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466536")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("I’ll answer both anonymous questions:")

#text("For K41 the significance is that the dissipation independent of Re implies the presence of singularities. That is profound. We should find these singularities in Euler, but a special sort of Euler equations. There is a big difference between Euler with no viscosity and Euler with vanishing viscosity. Moreover the limit of dissipation for the dynamic Euler equation is not zero dissipation, but a finite amount of dissipation proportional to the magnitude of the large scale inertially dominated flow. This is not what the Math community is studying hence my critique. The way the community is doing this for turbulence is quite frankly baffling.")

#text("The easy one, shocks have the same invariance to the value of viscosity as turbulence modulo a constant and dimensional-temporal effects. They have the same cubic dependence on the large scale flow as K41’s 4/5 law. In other words, the dissipation rate depends only on the large scale inertial flow and not the value of viscosity. They are singular in the sense that the steepness of the gradient only appears on scales where viscous forces are important. One key difference is that the valid solutions to shocks from the inviscid compressible Euler are found in the vanishing viscosity limit. The solutions without viscosity are nonsense. Shocks produce the same nonzero limiting behavior as K41 predicts, the Euler limit is not zero dissipation, but a finite amount.")

#text("Dynamically interesting systems never approach the dynamics described by Hamiltonian descriptions, which effectively remove dissipation (and time’s arrow).")

#text("IMHO this is exactly the sort of singular behavior we should be looking for in turbulence.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466540")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("Dejan,")

#text("I believe the issue with sound waves is whether they are dynamically important. Incompressibility renders them irrelevant by fiat. Sound waves are essential for shock waves, and viewed as immaterial for turbulence. I think they are actually the soul of turbulence, i.e., the “dog” and vorticity is simply the “tail”. We have been almost completely focused on the side-effect of the physics instead of the actual physics itself. Sound waves and thermodynamics are intimately connected, and I think the second law has a dominant role in this discussion. Again incompressibility removes most of this by fiat.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2016")])]

#text("Shocks are addressed in compressible flow theory. There are numerous examples where the flow is really incompressible, such as turbulence in your coffee cup, fume wake left behind your car and wind loading by tornadoes. Incompressibility must be a valid assumption in these practical scenarios as in designs and CFD simulations.")

#text("Do your shock singularities contain infinite energy? Can you explain if the answer is no.")

#text("What is this limit of vanishing viscosity? (Do you mean the Euler (zero viscosity) and the vanishing viscosity in the Navier-Stokes?) Can you quote a numerical value, say, for air/water, as your critique aims at unphysical approaches?")

#text("It is a misinterpretation that K41 predicts singularity. Frisch’s book on this issue is more or less misleading. His discussion on the drag Re-independence in bluff body flows is incomplete.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("Just before the first double integral of omega_z there is “that he integrals”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465911")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("Is the link for the slides correct? I seem to get lost.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465921")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("(The links for the slides still dont work…)")

#emph[#text("[Hopefully fixed for real now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("Thank you for this post and the slides.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("Thanks for the very interesting post! There seems to be a small typo in the introduction: one too many “assertion” in")#linebreak()#text(" “Indeed, morally speaking, the assertion that finite time blowup solutions of Navier-Stokes assertion”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("Can such a blowup be considered as a new type of turbulence (which also has a similar approximate self-replication behavior at many scales, but without blowup)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465948")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("I view this blowup example as closer to a neck pinch (the fine scale behaviour is concentrated in a small cube, as opposed to being dispersed throughout space as is the case with turbulent flow).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("Suppose that there is a solution for this blowup example. Is it possible (if the asymptotic behavior of this solution near the neck pinch blowup is known) to go backward(!) in time and get a good estimate for the required initial data ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("I would imagine the backwards flow near the blowup solution to be so unstable as to rule out being able to derive anything useful from the initial data from the blowup asymptotics, other than what can be deduced directly from the conservation laws. This backwards evolution moves high frequencies back into low frequencies, which is a very rare type of evolution (basically the rare flows that go against the second law of thermodynamics). It would be like taking, say, a bomb exploding into fragments, and then reversing the order of time to have fragments imploding back into a bomb. This is a valid solution of the equations of Newtonian mechanics, but is incredibly unstable – any perturbation of the fragments as initial data will lead to a final state that has no resemblance to an unexploded bomb.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("OK. but at least this argument seems to show that the required initial data is (in some sense) “rare”.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465947")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("“…constant in both space and time or…” – should the “or” be a “for”?")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("Is there any known upper bound for the number of conservation laws (i.e. time-invariant independent functionals of the fluid state)? Is it possible that there are some unknown conservation laws which can be used ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("There is some literature on attempting to classify the conservation laws that are of a certain form (e.g. arising from an infinitesimal symmetry via Noether’s theorem), see e.g. ")#link("http://www.hindawi.com/journals/ijmms/1989/147865/abs/")[#text("http://www.hindawi.com/journals/ijmms/1989/147865/abs/")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=672198")[#text("http://www.ams.org/mathscinet-getitem?mr=672198")]#text(" . But it is difficult to rule out the possibility of a more exotic conservation law. (To give a silly example, any arbitrary function of the orbit of the Euler flow in phase space would be conserved by the flow.) Also, there may be more general a priori bounds on quantities that are not precisely conserved, but are still bounded uniformly in time. (For instance, ")#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/")[#text("I showed some time ago")]#text(" that global regularity for periodic Navier-Stokes was equivalent to the existence of an a priori bound on the H^1 norm of the solution that depended only on the initial H^1 norm.)")

#text("There have been one or two unusual conservation laws found for Euler that are not on the standard list (energy, circulation, helicity, etc.), e.g. in the recent preprint ")#link("http://arxiv.org/abs/1509.05832")[#text("http://arxiv.org/abs/1509.05832")]#text(" , but they do not look easy to exploit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b526dbf887c0fdf9c8f07fab57d86a3b61fad497cd67390d6c2a0f24773a565-be2bcea39e4d7ba3d95a05e3bf839ca4b7f499abed28a3021f5f1b6cf95acbd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Shankar")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-469943")[#strong[#text("Ravi Shankar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2016")])]

#text("Hello,")

#text("In case it is helpful, I wanted to let you know that the preprint you mentioned has been updated with a new result. In addition to an a priori lower bound involving the energy (equation (58)), there is a nonexistence result on periodic solutions that follows from this conservation law.")

#text("Best,")

#text("Ravi Shankar")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-469980")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2016")])]

#text("Thanks for this. I wanted to clarify one point in your claim about nonexistence of periodic solutions to Euler – are you referring to periodic solutions in Lagrangian coordinates only, or can you also rule out periodic solutions in Eulerian coordinates also? It seems to me that one could have a solution to the Euler equations which is periodic in the latter sense but not the former – tafter some finite time T, the velocity field returns (in Eulerian coordinates) to what it was at time zero, but all the labels might have changed in the process (i.e. each particle could be in a different location from its initial position), so that the solution is not periodic in Lagrangian coordinates.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b526dbf887c0fdf9c8f07fab57d86a3b61fad497cd67390d6c2a0f24773a565-be2bcea39e4d7ba3d95a05e3bf839ca4b7f499abed28a3021f5f1b6cf95acbd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Shankar")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-469987")[#strong[#text("Ravi Shankar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2016")])]

#text("I only claim nonexistence in Lagrangian coordinates. I agree that a time-periodic solution in Eulerian coordinates seems conceivable. Examples with finite energy are surprisingly hard to come by though (e.g. it would not be a potential flow, u(x,t) = grad phi(x,t), since there are no nontrivial harmonic distributions phi(x,t) with L2 gradients).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/800683ad8cad117875c073a80bc1e95b9d478198cfec6aed64b23b60cb25f52b-984cf38386ff6be08009e12f7c53818cb9ddc437d422bedc0c1839fa31184865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465952")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("For some critical cases of nonlinear Schrödinger and wave equations, the global existence problem is solved in a probabilistic way: almost surely, w.r.t. an invariant measure, the solution to a given initial datum exists globally in time. So there is blow up, but in reality one never hits one of these solutions.")

#text("Could such or a related scenary be realistic for Navier-Stokes as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("It’s unlikely that Navier-Stokes, being time-irreversible and non-Hamiltonian, has any non-trivial invariant measures; this seems hard to reconcile with the monotone decreasing nature of energy and of the parabolic smoothing, for instance. In fact the parabolic smoothing even makes it challenging to conceive of a quasi-invariant measure, even for the linear heat equation. But perhaps there is some other way to obtain an almost sure global existence result; that would certainly be fantastic.")

#text("The Euler equations are Hamiltonian, and one could conceivably attempt to establish an almost sure global existence result using, say, a Gibbs measure. It may be that the equation is just too nonlinear for the existing techniques for this to work, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("Hi,")

#text("Your initial vorticity omega(0) is divergence-free, so d(eta(r))/dr must be zero for EVERY (r,theta,z). But your normalisation says function eta cannot be a constant. What sort of function eta you have in mind? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2016")])]

#text("The divergence of ")#mi("\\omega(0)")#text(" is ")#mi("\\frac{\\partial}{\\partial z} \\eta(r)")#text(", which vanishes for any choice of ")#mi("\\eta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465963")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("In cylindrical coordinates r is nonnegative, so why do you speak in the proof sketch of an even function eta of r supported on [-1, 1]?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("This is to keep the function ")#mi("\\eta(r) = \\eta(\\sqrt{x^2+y^2})")#text(" smooth at the origin (by making all the odd order Taylor coefficients vanish at ")#mi("r=0")#text("). For instance, a function such as ")#mi("\\eta(r) = 1-r")#text(" for ")#mi("r \\geq 0")#text(" is smooth on ")#mi("[0,+\\infty)")#text(", but does not give a smooth function in cylindrical coordinates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("Why is the function positive? May a negative be specified?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("Yes; the positivity of ")#mi("\\eta")#text(" makes for a nicer picture with vortex lines only going in one direction, but the argument in fact would work with ")#mi("\\eta")#text(" that changed sign (so long as the total circulation was still non-zero).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("Is it possible that the existence of a finite blowup solution for a certain class of such problems is undecidable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("As far as we know, this is a possibility. Certainly there exist PDE or even ODE which can simulate arbitrary Turing machines (see e.g. the discussion on ")#link("http://mathoverflow.net/questions/15309/simulating-turing-machines-with-o-pdes")[#text("this MathOverflow post")]#text(") and from this it is not difficult to extract a PDE or ODE for which the global regularity problem is undecidable. On the other hand, Navier-Stokes global regularity on a torus for data of energy bounded by a fixed threshold E is decidable for each E; see the remarks section of ")#link("http://arxiv.org/pdf/0710.1604.pdf")[#text("this paper of mine")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-465994")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("Link that should point to a MathOverflow post leads to an arxiv preprint about expander graphs. Should it point ")#link("http://mathoverflow.net/questions/15309/simulating-turing-machines-with-o-pdes")[#text("here")]#text(" instead?")

#emph[#text("[Link corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("One of the obvious flaws is: Kelvin’s circulation theorem has been wrongly applied. The integral over r and theta (displayed after ‘From the choice of initial data we thus have’) just states the instantaneous circulation due to (unknown) vorticity component omega_z at time t>0. You have not shown anything on the dynamics of vector omega(r,theta,z,t) for given initial data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2016")])]

#text("Because of the divergence-free nature of the vorticity (allowing one to use Stokes’ theorem), one does not need complete control of the vorticity at later times to be able to use the circulation law, especially since in this situation the vorticity is confined to the region ")#mi("\\Omega(t)")#text(".")

#text("For a given choice ")#mi("t = t_0, z = z_0")#text(" of ")#mi("t")#text(" and ")#mi("z")#text(", the circulation ")#mi("\\int\\int \\omega_z(t_0,r,\\theta,z_0)\\ r dr d\\theta")#text(" is the circulation through a disk of the form ")#mi("\\{ (t_0,r,\\theta,z_0): r \\leq R \\}")#text(" for some large ")#mi("R")#text(" (since the vorticity will vanish when ")#mi("r")#text(" is large enough). As time evolves, say from time ")#mi("t_0")#text(" to time ")#mi("t_1")#text(", this disk will evolve in a largely unknown fashion; but for ")#mi("R")#text(" large enough, the boundary of the disk will stay outside of the support of the vorticity, so from Stokes’ theorem the circulation of the evolved disk at time ")#mi("t_1")#text(" will equal the circulation of a disk of the form ")#mi("\\{ (t_1,r,\\theta,z_1): r \\leq R \\}")#text(" for arbitrary ")#mi("z_1")#text(" (again assuming ")#mi("R")#text(" large enough). Note that the evolved disk and the new disk do not necessarily have the same boundary, but one can glue the two boundaries together by an additional surface that lies outside of ")#mi("\\Omega(t_1)")#text(", which introduces no additional circulation.")

#text("It is also an instructive exercise to derive the vanishing of the derivatives ")#mi("\\partial_t \\int\\int \\omega_z(t_0,r,\\theta,z_0)\\ r dr d\\theta")#text(" and ")#mi("\\partial_z \\int\\int \\omega_z(t_0,r,\\theta,z_0)\\ r dr d\\theta")#text(" directly from the vorticity equation (1), the divergence-free nature of the vorticity, and integration by parts, without appeal to the circulation theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2016")])]

#text("Assuming the existence of a finite time blowup solution (suggested by the above construction) with ")#mi("u_0")#text(" a known(!) asymptotic “main term” of the solution ")#mi("u")#text(" sufficiently near the blowup time ")#mi("t_*")#text("(i.e. ")#mi("u=u_0 +u_1")#text(" with ")#tao-math("u_1 = o(\\left|u_0\\right|)", block: false)#text(" near ")#mi("t_*")#text(").")#linebreak()#text(" Is it possible (e.g. as done in the formal derivation of Puiseux series) to continue this formal(!) asymptotic series to ")#mi("u = u_0 + ... + u_n + u_{n+1}")#text(" with known(!) ")#mi("u_0, ... , u_n")#text(" and ")#tao-math("u_{i+1}=o(\\left|u_i\\right|)", block: false)#text(" for ")#mi("i = 0, ... , n")#text(" near ")#mi("t_*")#text(" ?")#linebreak()#text(" If so, then (for sufficiently large ")#mi("n")#text("), the relative remainder term ")#tao-math("u_{n+1}/\\left|u\\right|", block: false)#text(" is expected to decay near ")#mi("t_*")#text(" sufficiently fast to allow (via backwards evolution) the actual existence of ")#tao-math("u_{n+1}/\\left|u\\right|", block: false)#text(" (and thereby ")#mi("u")#text(" itself!) sufficiently near the blowup time ")#mi("t_*")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2016")])]

#text("This type of construction works well for ODE-type blowup mechanisms in which the solution essentially only depends on one coordinate of spacetime (such as the time coordinate ")#mi("t")#text("), but for more general blowup situations (such as the neck pinch one suggested here, which is broadly like a self-similar blowup solution) one still has to do some PDE in the spatial (or rescaled spatial) directions to ensure that this series is well-behaved. For instance, for many evolution equations one can try to consider self-similar solutions, e.g. for Navier-Stokes one could consider solutions of the form ")#mi("u(t,x) = (t_*-t)^{-1/2} V( \\frac{x}{(t_*-t)^{1/2}} )")#text(" for some divergence-free ")#mi("V: {\\bf R}^3 \\to {\\bf R}^3")#text(" and all times ")#mi("0 \\leq t < t_*")#text(". Here, the behaviour in the time variable ")#mi("t")#text(" as it approaches the blowup time ")#mi("t_*")#text(" is completely explicit, but the difficulty still remains of constructing the spatial function ")#mi("V")#text(", which needs to obey a certain elliptic PDE. For instance, in this specific example it is known that there are no non-trivial bounded, finite energy ")#mi("V")#text(" obeying this particular self-similar ansatz (thanks to the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1397564")[#text("Necas-Ruzicka-Sverak")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1643650")[#text("Tsai")]#text("; this also follows from the celebrated later work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1992563")[#text("Escuriaza, Seregin, and Sverak")]#text(" that essentially rules out any reasonable “Type II blowup” scenario for Navier-Stokes).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466026")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("How is this new blow-up result related to the program of showing blow-up by showing that the system supports computation? (In particular, do the new systems for which blow up is demonstrated support computation?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466033")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("I didn’t need to make the fluid perform any computation for this particular blowup mechanism. The reason why some sort of computation was needed in the averaged Navier-Stokes blowup was that I needed to program a delay between the transfer of energy from one scale to the next, and the transfer from that scale to the scale after that; otherwise the energy dispersed so widely that the viscosity effects dissipated the energy before it could go all the way to infinitely high frequencies to create the blowup. In the current situation there is no viscosity (and also no energy conservation law); the blowup is driven instead by the circulation conservation law and doesn’t really care if the fluid is dispersing its energy into many different frequencies. So it’s not directly advancing the blowup program I proposed from the averaged Navier-Stokes paper, but it does show that the circulation conservation law is not an insurmountable barrier to that program.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466035")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Thanks, Terry. But can you still make the fluid perform computation in this case? While not needed for blowup in this case, it can be of some separate interest (also because in other scenarios computation is a tool toward blowup).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("My guess is that for any natural number ")#mi("N")#text(", one can choose the dynamical operator ")#mi("T")#text(" so that it can behave (for a suitable preparation of inputs at various spatial scales) like a Turing machine that runs for time ")#mi("N")#text(", because it looks plausible that one can design ")#mi("T")#text(" at various spatial locations to simulate logic gates (and the circulation conservation law will come in handy, as it allows one to largely ignore most of the dynamics as long as the support of the vorticity is contained in a set that can be understood, much as in the blog post here). But again one is relying on the fact that one has a wide latitude to select the nonlinearity ")#mi("T")#text(" (in effect “hard-wiring” the desired program into the dynamics), and in particular not requiring the equation to obey an energy or momentum conservation law (a particular convenience of not having such laws is that this allows one to violate Newton’s third law by allowing one portion of the fluid to act on another without causing a backreaction).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2016")])]

#text("On which basis one can choose what fluid can functionally do? What computation by fluid even means? Do we have a freedom of choice what fluid can do for us? If so, why not assume that T can compute and resolve this issue and we are all done.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("In the question session of your talk you mention a work on Navier-Stokes with a stochastic forcing related to Kolmogorov’s law that can be interpreted as an almost sure global well-posedness result. Would you be able to provide an exact reference ? Thanks in advanced.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466049")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("The result I had in mind was that of Cheskidov, Friedlander, and Shvydkoy: ")#link("http://arxiv.org/abs/1112.5376")[#text("http://arxiv.org/abs/1112.5376")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466071")[#strong[#text("Philip")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2016")])]

#text("Are there characteristic fields, which are analogous to characteristic lines (which are ODE) from linear transport? The characteristic field is a PDE, and describes a level of some other equation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2016")])]

#text("Probably the closest such thing is the notion of a bicharacteristic in microlocal analysis, which transports the singularities and other high frequency dynamics in linear Hamiltonian PDE. In the high frequency limit (or, after a rescaling, the semiclassical limit), a linear Hamiltonian PDE converges in a certain sense to a Hamiltonian flow (closely related to how the Schrodinger equation in quantum mechanics converges to Hamilton’s laws of motion as ")#mi("\\hbar \\to 0")#text("), and the bicharacteristics are the characteristics of that latter flow in phase space.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466095")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2016")])]

#text("I know this is not the right place to advertise, but I just heard a talk (")#link("http://www.math.princeton.edu/events/seminars/ergodic-theory-statistical-mechanics/new-interactions-between-analysis-and-number")[#text("http://www.math.princeton.edu/events/seminars/ergodic-theory-statistical-mechanics/new-interactions-between-analysis-and-number")]#text(") that suggests some hidden structure in the Ulam sequence ")#mi("a_n")#text(": Let ")#mi("S_n(x)=\\sum_{n\\le N} e^{2\\pi i a_nx}")#text(". Then numerics suggest that there is an $\\latex x \\approx 2.57$ such that ")#mi("S_n(x)\\simeq -0.79N")#text(". This is very unusual for a random Fourier series, which basically grows like ")#mi("\\sqrt {N}")#text(" when $\\latex x$ is away from 0. Do you know any explanation related to that or can it be a suitable polymath project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466103")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2016")])]

#text("Why does vorticity vanish at large R? Are you saying that the other two components, omega_r and omega_theta, are always zero in the evolved disk? How do you know that the vortex lines linked to omega_z are normal to the disk for all time t>0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466116")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("By the definition of ")#mi("T_*")#text(", the vorticity (which is transported by the velocity field u thanks to (1), and thus propagates at finite speed) is contained inside the hyperboloid ")#mi("\\Omega(t)")#text(" for times ")#mi("t")#text(" up to ")#mi("T_*")#text(", and in particular vanishes for large values of ")#mi("r")#text(".")

#text("The non-normal components ")#mi("\\omega_r, \\omega_\\theta")#text(" of the vorticity need not vanish (or equivalently, the vortex lines need not be orthogonal to the disk), but the ")#link("https://en.wikipedia.org/wiki/Circulation_(fluid_dynamics)")[#text("circulation")]#text(" ")#mi("\\int_S \\omega \\cdot n\\ dS")#text(" only depends on the normal component of the vorticity, which in this case is ")#mi("\\omega_z")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("Near/by your blow-up time, the velocity u cannot be finite and thus vorticity will “propagate” to infinity.")

#text("The components of o_r and o_theta must contribute to the circulation used in Kelvin’s theorem (which is not your definition).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466135")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("If the solution blows up, we are done – this is precisely the conclusion of Theorem 1! The argument actually proceeds by contradiction, assuming that the solution does not blow up (which is basically equivalent to the velocity staying bounded, after dealing with some minor technical issues at spatial infinity).")

#text("There are two equivalent ways to define the circulation through a loop ")#mi("C")#text(": one is as a line integral ")#mi("\\oint_C u \\cdot dl")#text(", and the other is as a surface integral ")#mi("\\int\\int_S \\omega \\cdot n\\ dS")#text(", where ")#mi("S")#text(" is any surface that has ")#mi("C")#text(" as its (oriented) boundary. The two integrals are equal by Stokes’ theorem, and so either can be used in the statement of Kelvin’s circulation theorem. In my post, I am applying Kelvin’s theorem with ")#mi("S")#text(" equal (at some initial time) to a disk of the form ")#mi("\\{ (r, \\theta, z): z = z_0, r \\leq R \\}")#text(", which measures the circulation through the circle ")#mi("\\{ (r,\\theta,z): z = z_0, r = R \\}")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466109")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("What is an annulus 1 << r + |z| << 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("In Euclidean coordinates ")#mi("(x,y,z)")#text(", this would be a region of the form ")#mi("1 \\ll x^2+y^2+z^2 \\ll 1")#text(" (or more precisely, a region that both contains and is contained in annuli of the form ")#mi("\\{ (x,y,z): c_1 \\leq x^2+y^2+z^2 \\leq c_2 \\}")#text(" for various ")#mi("c_2 > c_1 > 0")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2016")])]

#text("Velocity u(x,t) is never indefinite despite undetermined vorticity and the loose function c(t). So the exposition of the blow-up can be rigorously sought in the realm of philosophy where finite-time singularities and the invariance principle of total vorticity must cause no contradiction, as the law of energy conservation has been overthrown by acrobatics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2016")])]

#text("Absolutelly correct. Topic discussed is not in realm of physically possible. It is pure abstraction far from anything that has in common with fluids, although sounds like it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-466718")[#strong[#text("Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("[…] is not covered by our arguments. Nevertheless (as with previous finite-time blowup results discussed on this blog), one can view this result as a barrier to trying to prove regularity for equations such as in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-467833")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2016")])]

#text("I made a comment on my blog:")

#link("http://claesjohnson.blogspot.se/2016/04/turbulent-euler-solutions-and-clay.html")[#text("http://claesjohnson.blogspot.se/2016/04/turbulent-euler-solutions-and-clay.html")]

#text("Regards, Claes Johnson")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-467841")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2016")])]

#text("To be meaningful the Clay Navier-Stokes problem needs to be reformulated to include the crucial aspect of turbulence:")

#link("http://claesjohnson.blogspot.se/2016/04/reformulation-of-clay-navier-stokes.html")[#text("http://claesjohnson.blogspot.se/2016/04/reformulation-of-clay-navier-stokes.html")]

#text("I would appreciate your comment on this aspect: Is it meaningful/possible to exclude turbulence from the Clay problem?")

#text("Regards, Claes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7125367c1a7647c545b538e4391a234fbe2b80593efa6b898a0f523373c5399-f81f417b6259ddc2fab578bba9472d17c815d2c1e2439afe2217f699f62f0004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Skjetne")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-468905")[#strong[#text("Erik Skjetne")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("Great inspiration to read your blog!")

#text("Finite time t→T blow up of the three dimensional incompressible Navier-Stokes flow velocity or vorticity may be attained by an infinite sequence, in finite time, of flow structure (e.g. neighborhood of a vorticity maximum) volume V contractions to a singularity with almost no leakage of kinetic energy in the process. Volume-contractions cannot be material, since the fluid is incompressible.")

#text("However, blow up of vorticity by vortex stretching implies that maximum and minimum eigenvalues of the fluid rate of strain tensor S split into ± ∞ (eigenvalues sum to zero by mass balance); indeed an extreme anisotropic fluid deformation. In the inertia dominated limit of the Navier-Stokes vorticity equation (the first equation above), the vorticity vector deforms as a small material fluid vector, and as a result the fluid deformation carries over to the deformation of the vorticity flow structure.")

#text("In the inertia-dominated limit (Euler eq.), the vorticity flow structure itself may deform exactly as the fluid and become incompressible! If so, the flow structure cannot reach a volume singularity and this would provide a universal kinematic barrier for blowup the Navier-Stokes equation.")

#text("What do you think about the reasoning above, any clear flaws?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-469995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("What is known about the possibility of real analytic blowup solutions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/#comment-470148")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] presented (for three different choices of vector potential operator ). The first is a variant of one discussed previously on this blog, in which a “neck pinch” singularity for a vortex tube is created by using a […]")
]
