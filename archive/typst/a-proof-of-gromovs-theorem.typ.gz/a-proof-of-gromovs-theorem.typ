// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/
// Converted to Typst by tao2typ: "2026-10-14T08:54:48.202690+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A proof of Gromov’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A proof of Gromov’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")[#text("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A celebrated ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("theorem of Gromov")]#text(" reads:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Every finitely generated group of polynomial growth is virtually nilpotent.")
]

#text("The original proof of Gromov’s theorem was quite non-elementary, using an infinitary limit and exploiting the work surrounding the solution to ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(". More recently, ")#link("http://arxiv.org/abs/0710.4593")[#text("Kleiner provided")]#text(" a proof which was more elementary (based in large part on an earlier paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=1491451")[#text("Colding and Minicozzi")]#text("), though still not entirely so, relying in part on (a weak form of the) ")#link("http://www.ams.org/mathscinet-getitem?mr=286898")[#text("Tits alternative")]#text(" and also on an ultrafilter argument of ")#link("http://www.ams.org/mathscinet-getitem?mr=1483983")[#text("Korevaar-Schoen")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1364901")[#text("Mok")]#text(". I discuss Kleiner’s argument more in this ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("previous blog post")]#text(".")

#text("Recently, ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("Yehuda Shalom and I established a quantitative version of Gromov’s theorem")]#text(" by making every component of Kleiner’s argument finitary. Technically, this provides a fully elementary proof of Gromov’s theorem (we do use one infinitary limit to simplify the argument a little bit, but this is not truly necessary); however, because we were trying to quantify as much of the result as possible, the argument became quite lengthy.")

#text("In this note I want to record a short version of the argument of Yehuda and myself which is not quantitative, but gives a self-contained and largely elementary proof of Gromov’s theorem. The argument is not too far from the Kleiner argument, but has a number of simplifications at various places. In a number of places, there was a choice to take between a short argument that was “inefficient” in the sense that it did not lead to a good quantitative bound, and a lengthier argument which led to better quantitative bounds. I have opted for the former in all such cases.")

#text("Yehuda and I plan to write a short paper containing this argument as well as some additional material, but due to some interest in this particular proof, we are detailing it here on this blog in advance of our paper.")

#text("Note: this post will assume familiarity with the basic terminology of group theory, and will move somewhat quickly through the technical details.")

#metadata(none) <tao-ac7e8d97e754772ef4b9>

#heading(level: 1)[#strong[#text(" — 1. Overview of argument — ")]]

#text("The argument requires four separate ingredients. The first is the existence of non-trivial Lipschitz harmonic functions ")#mi("{f: G \\rightarrow {\\bf R}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Existence of non-trivial Lipschitz harmonic functions)")]#text(" ")#metadata(none) <tao-395bff62dab5de60ccf8>#text(" Let ")#mi("{G}")#text(" be an infinite group generated by a finite symmetric set ")#mi("{S}")#text(". Then there exists a non-constant function ")#mi("{f: G \\rightarrow {\\bf R}}")#text(" which is harmonic in the sense that")

#align(center)[#tao-fit-display[#tao-math("f(x) = \\frac{1}{\\left|S\\right|}\\sum_{s \\in S} f(xs)", block: true)]]

#text("for all ")#mi("{x \\in G}")#text(", and Lipschitz in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)-f(xs)\\right| \\leq C", block: true)]]

#text("for all ")#mi("{x \\in G}")#text(" and ")#mi("{s \\in S}")#text(", and some ")#mi("{C < \\infty}")#text(".")
]

#text("The second is that there are not ")#emph[#text("too")]#text(" many such harmonic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Kleiner’s theorem)")]#text(" ")#metadata(none) <tao-e4b6dd2322c5edc0ed85>#text(" Let ")#mi("{G}")#text(" be a group of polynomial growth generated by a finite symmetric set ")#mi("{S}")#text(" of generators. Then the vector space ")#mi("{V}")#text(" of Lipschitz harmonic functions is finite-dimensional.")
]

#text("The third ingredient is that Gromov’s theorem is true in the compact linear Lie group case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Gromov’s theorem in the compact Lie case)")]#text(" ")#metadata(none) <tao-a81741a8946ba3bb3206>#text(" Let ")#mi("{G}")#text(" be a finitely generated subgroup of a compact linear Lie group ")#mi("{H \\subset GL_n({\\bf C})}")#text(" of polynomial growth. Then ")#mi("{G}")#text(" is virtually abelian.")
]

#text("The final ingredient is that Gromov’s theorem is inductively true once one can locate an infinite cyclic quotient:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Gromov’s theorem with an cyclic quotient)")]#text(" ")#metadata(none) <tao-d3e98aeebf105a0bfe18>#text(" Let ")#mi("{G}")#text(" be a finitely generated group which has polynomial growth of exponent at most ")#mi("{d}")#text(" (i.e. the volume of a ball ")#mi("{B_S(r)}")#text(" grows like ")#mi("{O(r^d)}")#text(" for any fixed set of generators ")#mi("{S}")#text("). Suppose inductively that Gromov’s theorem is already known for groups of polynomial growth of exponent at most ")#mi("{d-1}")#text(", and suppose that ")#mi("{G}")#text(" contains a finite index subgroup ")#mi("{G^{\\prime}}")#text(" which can be mapped homomorphically onto an infinite cyclic group. Then ")#mi("{G}")#text(" is virtually nilpotent.")
]

#text("We prove these four facts in later sections. For now, let us see how they combine to establish Gromov’s theorem in full generality.")

#text("We assume that ")#mi("{G}")#text(" has polynomial growth of order ")#mi("{d}")#text(", and assume inductively that Gromov’s theorem has already been established for growth of order ")#mi("{d-1}")#text(" or less. We fix a symmetric set ")#mi("{S}")#text(" of generators.")

#text("We may assume that ")#mi("{G}")#text(" is infinite otherwise we are already done. So by Theorem ")#link(<tao-395bff62dab5de60ccf8>)[#text("2")]#text(", the space ")#mi("{V}")#text(" of (complex) Lipschitz harmonic functions consists of more than just the constants ")#mi("{{\\bf R}}")#text(". In particular, setting ")#mi("{W := V/{\\bf C}}")#text(", we have a non-trivial short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow {\\bf C} \\rightarrow V \\rightarrow W \\rightarrow 0.")]]

#text("The left translation action of ")#mi("{G}")#text(" preserves the space of Lipschitz harmonic functions, and is thus an action of ")#mi("{G}")#text(" on ")#mi("{V}")#text(". Since ")#mi("{G}")#text(" preserves constants, it is also an action of ")#mi("{G}")#text(" on ")#mi("{W}")#text(". Now, on ")#mi("{W}")#text(", the homogeneous Lipschitz norm is a genuine norm, and is preserved by the action of ")#mi("{G}")#text(". Since all norms are equivalent on a finite-dimensional space, we can place an arbitrary Euclidean structure on ")#mi("{W}")#text(" and conclude that this structure is preserved up to constants by ")#mi("{G}")#text(". So, the image of the action of ")#mi("{G}")#text(" on ")#mi("{W}")#text(" is precompact, and thus its closure is a compact Lie group. By Theorem ")#link(<tao-a81741a8946ba3bb3206>)[#text("4")]#text(", this image is virtually abelian. If it is infinite, then we thus see that a finite index subgroup of ")#mi("{G}")#text(" has an infinite abelian image, and thus has a surjective homomorphism onto the integers, and we are done by Theorem ")#link(<tao-d3e98aeebf105a0bfe18>)[#text("5")]#text(". So we may assume that this image is finite; thus there is a finite index subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" that is trivial on ")#mi("{W}")#text(". The action of ")#mi("{G^{\\prime}}")#text(" on ")#mi("{V}")#text(" then collapses to the form ")#mi("{g f = f + \\lambda_g(f)}")#text(" for some linear functional ")#mi("{\\lambda_g \\in V^*}")#text(" (in fact ")#mi("{\\lambda_g}")#text(" annihilates ")#mi("{1}")#text(" and so comes from ")#mi("{W^*}")#text("). Note that ")#mi("{\\lambda}")#text(" is then an additive representation of ")#mi("{G}")#text(". If the image of this representation is infinite, then we are again done by Theorem ")#link(<tao-d3e98aeebf105a0bfe18>)[#text("5")]#text(", so we may assume that it is finite; thus there is a finite index subgroup ")#mi("{G^{\\prime\\prime}}")#text(" of ")#mi("{G^{\\prime}}")#text(" that is trivial on ")#mi("{V}")#text(". In other words, all Lipschitz harmonic functions are ")#mi("{G^{\\prime\\prime}}")#text("-invariant, and thus take only finitely many values. But looking at the maximum such value and using harmonicity (i.e. using the ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(") we conclude that all Lipschitz harmonic functions are constant, a contradiction.")

#heading(level: 1)[#strong[#text(" — 2. Building a Lipschitz harmonic function — ")]]

#text("Now we prove Theorem ")#link(<tao-395bff62dab5de60ccf8>)[#text("2")]#text(". We introduce the function")

#align(center)[#tao-fit-display[#tao-math("\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s", block: true)]]

#text("where ")#mi("{\\delta_s}")#text(" is the Kronecker delta function. The property of a function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" being harmonic is then simply that ")#mi("{f*\\mu = f}")#text(", using the discrete convolution structure on the group.")

#text("To build such a function, we consider the functions")

#align(center)[#tao-fit-display[#mitex("f_n := \\frac{1}{n} \\sum_{m=1}^n \\mu^{(m)}")]]

#text("where ")#mi("{\\mu^{(m)} := \\mu*\\ldots*\\mu}")#text(" is the convolution of ")#mi("{m}")#text(" copies of ")#mi("{\\mu}")#text(". This sequence of functions is “asymptotically harmonic” in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_n \\right\\|_{\\ell^1(G)} = 1", block: true)]]

#text("but")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_n - f_n * \\mu \\right\\|_{\\ell^1(G)} = O(1/n)", block: true)]]

#text("(we allow implied constants to depend on ")#mi("{S}")#text(").")

#text("There are now two cases. The first case is the ")#strong[#text("non-amenable case")]#text(", when we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_n - f_n * \\delta_s \\right\\|_{\\ell^1(G)} > \\epsilon > 0", block: true)]]

#text("for some ")#mi("{s \\in S}")#text(", some ")#mi("{\\epsilon > 0}")#text(", and infinitely many ")#mi("{n}")#text("; informally, this means that the averaged iterated convolutions ")#mi("{f_n}")#text(" are not getting smoother as ")#mi("{n \\rightarrow \\infty}")#text(". By the duality of ")#mi("{\\ell^1(G)}")#text(" and ")#mi("{\\ell^\\infty(G)}")#text(", we see that for each such ")#mi("{n}")#text(" we can find ")#mi("{H_n}")#text(" with ")#tao-math("{\\left\\| H_n\\right\\|_{\\ell^\\infty(G)} = 1}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|H_n*f_n(\\text{id}) - H_n*f_n(s)\\right| > \\epsilon.", block: true)]]

#text("But Young’s inequality, ")#mi("{H_n*f_n}")#text(" has ")#mi("{\\ell^\\infty(G)}")#text(" norm of at most ")#mi("{1}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|H_n*f_n - H_n*f_n*\\mu\\right\\|_{L^\\infty(G)} = O(1/n).", block: true)]]

#text("Using the sequential Banach-Alaoglu theorem we may take a subsequence limit and obtain a non-trivial bounded harmonic function. Since bounded functions are automatically Lipschitz, the claim follows.")

#text("The second case is the ")#strong[#text("amenable case")]#text(", when we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_n - f_n*\\delta_s \\right\\|_{\\ell^1(G)} \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for each ")#mi("{s \\in S}")#text(". Setting ")#mi("{F_n := f_n^{1/2}}")#text(", one soon verifies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_n \\right\\|_{\\ell^2(G)} = 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_n - F_n * \\delta_s \\right\\|_{\\ell^2(G)} = o(1)", block: true)]]

#text("In particular")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_n - F_n * \\mu \\right\\|_{\\ell^2(G)} = o(1).", block: true)]]

#text("From this and the spectral theorem, we see that the positive-definite Laplacian operator ")#mi("{\\Delta: \\ell^2(G) \\rightarrow \\ell^2(G)}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\Delta F := F - F*\\mu")]]

#text("has non-trivial spectrum at the origin. On the other hand, as ")#mi("{G}")#text(" is infinite, there are no non-trivial harmonic functions in ")#mi("{\\ell^2(G)}")#text(" (as can be seen from the maximum principle), and so the spectrum at the origin is not coming from a zero eigenfunction. From this and the spectral theorem (taking spectral projections to ")#mi("{[0,\\epsilon]}")#text(" for small ")#mi("{\\epsilon}")#text("), one can find a sequence ")#mi("{G_n \\in \\ell^2(G)}")#text(" of functions such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{g \\in G} G_n(g) \\Delta G_n(g) = 1")]]

#text("but")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta G_n \\right\\|_{\\ell^2(G)} \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("A summation by parts gives the Dirichlet energy identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{g \\in G} G_n(g) \\Delta G_n(g) = \\frac{1}{2\\left|S\\right|} \\sum_{s \\in S} \\left\\| G_n - G_n * \\delta_s \\right\\|_{\\ell^2(G)}^2", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G_n - G_n * \\delta_s \\right\\|_{\\ell^2(G)} = O(1),", block: true)]]

#text("and also there exists ")#mi("{s_0 \\in S}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G_n - G_n * \\delta_{s_0} \\right\\|_{\\ell^2(G)} \\gg 1", block: true)]]

#text("for infinitely many ")#mi("{n}")#text(". By the self-duality of ")#mi("{\\ell^2(G)}")#text(", we may thus find a sequence ")#mi("{H_n \\in \\ell^2(G)}")#text(" with ")#tao-math("{\\left\\|H_n\\right\\|_{\\ell^2(G)} = 1}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|H_n*G_n(\\text{id}) - H_n*G_n(s_0)\\right| \\gg 1", block: true)]]

#text("for infinitely many ")#mi("{n}")#text(". From Young’s inequality we also see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| H_n*G_n - H_n*G_n * \\delta_s \\right\\|_{\\ell^\\infty(G)} = O(1)", block: true)]]

#text("(so ")#mi("{H_n*G_n}")#text(" is uniformly Lipschitz) and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta(H_n*G_n) \\right\\|_{\\ell^\\infty(G)} \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(", thus ")#mi("{H_n*G_n}")#text(" is asymptotically harmonic. Using the Arzelá-Ascoli theorem to take another subsequence limit (after first subtracting a constant to normalise ")#mi("{H_n*G_n}")#text(" to be zero at the identity, so that ")#mi("{H_n*G_n}")#text(" becomes locally bounded by the uniform Lispchitz property) we obtain the required non-trivial Lipschitz harmonic function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In the case of groups of polynomial growth, one can verify that one is always in the “amenable” case. In the non-amenable case, the theory of Poisson boundaries gives a plentiful supply of ")#emph[#text("bounded")]#text(" Lipschitz harmonic functions (in fact, there is an infinite-dimensional space of such).")
]

#heading(level: 1)[#strong[#text(" — 3. Kleiner’s theorem — ")]]

#text("We now prove Theorem ")#link(<tao-e4b6dd2322c5edc0ed85>)[#text("3")]#text(". Our proof will basically repeat those in ")#link("http://arxiv.org/abs/0710.4593")[#text("Kleiner’s original paper")]#text(". For simplicity, let us assume a stronger condition than polynomial growth, namely ")#emph[#text("bounded doubling")]

#align(center)[#tao-fit-display[#tao-math("\\left|B_S(2R)\\right| \\leq C \\left|B_S(R)\\right|", block: true)]]

#text("for some fixed constant ")#mi("{C}")#text(" and all ")#mi("{R>0}")#text(". In general, polynomial growth does not obviously imply bounded doubling at all scales, but there is a simple pigeonhole argument that gives bounded doubling on ")#emph[#text("most")]#text(" scales, and this turns out to be enough to run the argument below. But in order not to deal with the (minor) technicalities arising from exceptional scales in which bounded doubling fails, I will assume bounded doubling at all scales. The full proof in the general case can, of course, be found in Kleiner’s paper (which in turn was based upon an ")#link("http://www.ams.org/mathscinet-getitem?mr=1491451")[#text("earlier argument of Colding and Minicozzi")]#text(").")

#text("Let ")#mi("{\\epsilon > 0}")#text(" be a small parameter. The key lemma is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Elliptic regularity)")]#text(" ")#metadata(none) <tao-90700b55e48bca19a22b>#text(" Cover ")#mi("{B_S(4R)}")#text(" by balls ")#mi("{B}")#text(" of radius ")#mi("{\\epsilon R}")#text(". Suppose that a harmonic function ")#mi("{f: G \\rightarrow {\\bf R}}")#text(" has mean zero on every such ball. Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\ell^2(B_S(R))} \\ll \\epsilon \\left\\| f \\right\\|_{\\ell^2(B_S(4R))}.", block: true)]]
]

#text("Let’s see how this lemma establishes the theorem. Consider some Lipschitz harmonic functions ")#mi("{u_1,\\ldots,u_D}")#text(", which we normalise to all vanish at the identity. Let ")#mi("{V}")#text(" be the space spanned by ")#mi("{u_1,\\ldots,u_D}")#text(". For each ")#mi("{R}")#text(", the ")#mi("{L^2(B_S(R))}")#text(" inner product gives a quadratic form ")#mi("{Q_R}")#text(" on ")#mi("{V}")#text(". Using this quadratic form, we can build a Gram matrix determinant")

#align(center)[#tao-fit-display[#mitex("\\det( Q_R(u_i,u_j) )_{1 \\leq i,j \\leq D}.")]]

#text("From the Lipschitz nature of the harmonic functions, we have a bound of the form ")#metadata(none) <tao-760176194068f3029466>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\det( Q_R(u_i,u_j) )_{1 \\leq i,j \\leq D} \\ll R^{D}")]]



#text(" as ")#mi("{R \\rightarrow \\infty}")#text(". On the other hand, we also have the monotonicity property")

#align(center)[#tao-fit-display[#mitex("\\det( Q_R(u_i,u_j) )_{1 \\leq i,j \\leq D} \\leq \\det( Q_{4R}(u_i,u_j) )_{1 \\leq i,j \\leq D}.")]]

#text("Now by bounded doubling, we can cover ")#mi("{B_S(4R)}")#text(" by ")#mi("{O_\\epsilon(1)}")#text(" balls of radius ")#mi("{\\epsilon R}")#text(". By Lemma ")#link(<tao-90700b55e48bca19a22b>)[#text("6")]#text(", the space of functions in ")#mi("{V}")#text(" which have mean zero on each such ball is such that ")#mi("{Q_R}")#text(" is bounded (as a quadratic form) by ")#mi("{O(\\epsilon)}")#text(" times ")#mi("{Q_{4R}}")#text(" on this space. Furthermore, by linear algebra, this space has codimension ")#mi("{O_\\epsilon(1)}")#text(" in ")#mi("{V}")#text(". Using this, we obtain the improved bound")

#align(center)[#tao-fit-display[#mitex("\\det( Q_R(u_i,u_j) )_{1 \\leq i,j \\leq D} \\leq O(\\epsilon)^{D - O_\\epsilon(1)} \\det( Q_{4R}(u_i,u_j) )_{1 \\leq i,j \\leq D}.")]]

#text("For ")#mi("{\\epsilon}")#text(" small enough and ")#mi("{D}")#text(" large enough, the rate of growth ")#mi("{O(\\epsilon)^{D - O_\\epsilon(1)}}")#text(" is strictly less than ")#mi("{4^{-D}}")#text(". Iterating this estimate by doubling ")#mi("{R}")#text(" off to infinity, and comparing against ")#link(<tao-760176194068f3029466>)[#text("(1)")]#text(", we conclude in the limit that")

#align(center)[#tao-fit-display[#mitex("\\det( Q_R(u_i,u_j) )_{1 \\leq i,j \\leq D} = 0")]]

#text("for all ")#mi("{R}")#text(", and so ")#mi("{u_1,\\ldots,u_D}")#text(" cannot be linearly independent. This implies that the space of Lipschitz harmonic functions has dimension at most ")#mi("{D+1}")#text(", and the claim follows.")

#text("It remains to prove the lemma. Fix the harmonic function ")#mi("{f}")#text(".")

#text("There are two basic ingredients here. The first is the reverse Poincaré inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B_S(2R)} \\left|\\nabla f(x)\\right|^2 \\ll R^{-2} \\sum_{x \\in B(x_0,4R)} \\left|f(x)\\right|^2", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla f(x)\\right|^2 := \\sum_{s \\in S} \\left|f(x)-f(xs)\\right|^2.", block: true)]]

#text("This claim (which heavily exploits the harmonicity of ")#mi("{f}")#text(") is proven by writing ")#tao-math("{\\left|f\\right|^2}", block: false)#text(" as ")#mi("{f (f*\\mu)}")#text(", multiplying by a suitable cutoff function adapted to ")#mi("{B(x_0,2r)}")#text(" and equalling one on ")#mi("{B(x_0,r)}")#text(", and summing by parts; we omit the standard details. (The above inequality is in the general spirit of the philosophy that functions that are harmonic on a ball, should be smooth that ball.)")

#text("The second claim is the Poincaré inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x,y \\in B(x_0,r)} \\left|f(x)-f(y)\\right|^2 \\ll r^{2} |B_S(r)| \\sum_{x \\in B(x_0,3r)} \\left|\\nabla f(x)\\right|^2,", block: true)]]

#text("which does not require harmonicity. To prove this claim, observe that the left-hand side can be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{g \\in B_S(2r)} \\sum_{x \\in B(x_0,r)} \\left|f(x)-f(xg)\\right|^2.", block: true)]]

#text("But by expanding each ")#mi("{g \\in B_S(2r)}")#text(" as a word of length most ")#mi("{2r}")#text(" and using the triangle inequality in ")#mi("{\\ell^2}")#text(" and Cauchy-Schwarz, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B(x_0,r)} \\left|f(x)-f(xg)\\right|^2 \\ll r^2 \\sum_{x \\in B(x_0,3r)} \\left|\\nabla f(x)\\right|^2", block: true)]]

#text("and the claim follows.")

#text("If ")#mi("{f}")#text(" has mean zero on ")#mi("{B(x_0,r)}")#text(", the Poincaré inequality implies that ")#metadata(none) <tao-4d2d1dfcb8d03bc60bce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{x \\in B(x_0,r)} \\left|f(x)\\right|^2 \\ll r^{2} \\sum_{x \\in B(x_0,3r)} \\left|\\nabla f(x)\\right|^2.", block: true)]]





#text("To prove the lemma, we first use bounded doubling to refine the family of balls ")#mi("{B = B(x_i,\\epsilon R)}")#text(" so that the triples ")#mi("{3B = B(x_i,3\\epsilon R)}")#text(" have bounded overlap. Applying ")#link(<tao-4d2d1dfcb8d03bc60bce>)[#text("(2)")]#text(" for each such ball and summing we obtain the claim.")

#heading(level: 1)[#strong[#text(" — 4. The compact Lie case — ")]]

#text("Now we prove Theorem ")#link(<tao-a81741a8946ba3bb3206>)[#text("4")]#text(". It is a classical fact that all compact linear Lie groups ")#mi("{H}")#text(" are isomorphic to a subgroup of a unitary group ")#mi("{U(n)}")#text("; indeed, if one takes the standard inner product on ")#mi("{{\\bf C}^n}")#text(" and averages it by the Haar measure of ")#mi("{H}")#text(", one obtains an inner product which is ")#mi("{H}")#text("-invariant, and so ")#mi("{H}")#text(" can be embedded inside the unitary group associated to this group. Thus it suffices to prove the claim when ")#mi("{H=U(n)}")#text(".")

#text("A key observation is that if two unitary elements ")#mi("{g, h}")#text(" are close to the identity, then their commutator ")#mi("{[g,h] = ghg^{-1}h^{-1}}")#text(" is even closer to the identity. Indeed, since multiplication on the left or right by unitary elements does not affect the operator norm, we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| [g,h] - 1 \\right\\|_{op}  & = \\left\\| gh - hg \\right\\|_{op}", block: true)



#tao-math(" & = \\left\\| (g-1)(h-1) - (h-1)(g-1) \\right\\|_{op}", block: true)
]

#text("and so by the triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| [g,h] - 1 \\right\\|_{op} \\leq 2 \\left\\|g-1\\right\\|_{op} \\left\\|h-1\\right\\|_{op}.", block: true)]]





#text("We now need to exploit ")#link(<tao-cddd67830982a78cc839>)[#text("(3)")]#text(" to prove Theorem ")#link(<tao-a81741a8946ba3bb3206>)[#text("4")]#text(". As a warm-up, we first prove the following slightly easier classical result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Jordan’s theorem)")]#text(" ")#metadata(none) <tao-136c67657614311f3223>#text(" Let ")#mi("{G}")#text(" be a finite subgroup of ")#mi("{U(n)}")#text(". Then ")#mi("{G}")#text(" contains an abelian subgroup of index ")#mi("{O_n(1)}")#text(" (i.e. at most ")#mi("{C_n}")#text(", where ")#mi("{C_n}")#text(" depends only on ")#mi("{n}")#text(").")
]

#text("And indeed, the proof of the two results are very similar. Let us first prove Jordan’s theorem. We do this by induction on ")#mi("{n}")#text(", the case ")#mi("{n=1}")#text(" being trivial. Suppose first that ")#mi("{G}")#text(" contains a ")#link("http://en.wikipedia.org/wiki/Center_of_a_group")[#text("central element")]#text(" ")#mi("{g}")#text(" which is not a multiple of the identity. Then, by definition, ")#mi("{G}")#text(" is contained in the ")#link("http://en.wikipedia.org/wiki/Centralizer")[#text("centraliser")]#text(" ")#mi("{Z(g)}")#text(" of ")#mi("{g}")#text(", which by the spectral theorem is isomorphic to a product ")#mi("{U(n_1) \\times \\ldots \\times U(n_k)}")#text(" of smaller unitary groups. Projecting ")#mi("{G}")#text(" to each of these factor groups and applying the induction hypothesis, we obtain the claim.")

#text("Thus we may assume that ")#mi("{G}")#text(" contains no central elements other than multiples of the identity. Now pick a small ")#mi("{\\epsilon > 0}")#text(" (one could take ")#mi("{\\epsilon=1/10}")#text(" in fact) and consider the subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" generated by those elements of ")#mi("{G}")#text(" that are within ")#mi("{\\epsilon}")#text(" of the identity (in the operator norm). By considering a maximal ")#mi("{\\epsilon}")#text("-net of ")#mi("{G}")#text(" we see that ")#mi("{G^{\\prime}}")#text(" has index at most ")#mi("{O_{n,\\epsilon}(1)}")#text(" in ")#mi("{G}")#text(". By arguing as before, we may assume that ")#mi("{G^{\\prime}}")#text(" has no central elements other than multiples of the identity.")

#text("If ")#mi("{G^{\\prime}}")#text(" consists only of multiples of the identity, then we are done. If not, take an element ")#mi("{g}")#text(" of ")#mi("{G^{\\prime}}")#text(" that is not a multiple of the identity, and which is as close as possible to the identity (here is where we use that ")#mi("{G}")#text(" is finite). By ")#link(<tao-cddd67830982a78cc839>)[#text("(3)")]#text(", we see that if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{n}")#text(", and if ")#mi("{h}")#text(" is one of the generators of ")#mi("{G^{\\prime}}")#text(", then ")#mi("{[g,h]}")#text(" lies in ")#mi("{G^{\\prime}}")#text(" and is closer to the identity than ")#mi("{g}")#text(", and is thus a multiple of the identity. On the other hand, ")#mi("{[g,h]}")#text(" has determinant ")#mi("{1}")#text(". Given that it is so close to the identity, it must therefore be the identity (if ")#mi("{\\epsilon}")#text(" is small enough). In other words, ")#mi("{g}")#text(" is central in ")#mi("{G^{\\prime}}")#text(", and is thus a multiple of the identity. But this contradicts the hypothesis that there are no central elements other than multiples of the identity, and we are done.")

#text("The proof of Theorem ")#link(<tao-a81741a8946ba3bb3206>)[#text("4")]#text(" is analogous. Again, we pick a small ")#mi("{\\epsilon > 0}")#text(", and define ")#mi("{G^{\\prime}}")#text(" as before. If ")#mi("{G^{\\prime}}")#text(" has a central element that is not a multiple of the identity, then we can again argue via induction, so suppose that there are no such elements.")

#text("Being finitely generated, it is not difficult to show that ")#mi("{G^{\\prime}}")#text(" can be generated by a finite set ")#mi("{S}")#text(" of generators within distance ")#mi("{\\epsilon}")#text(" of the identity. Now pick an element ")#mi("{h_1 \\in S}")#text(" which is not a multiple of the identity, and is at a distance ")#mi("{\\delta_1}")#text(" from the identity for some ")#mi("{0 < \\delta_1 \\leq \\epsilon}")#text(". We look at all the commutators ")#mi("{[g,h_1]}")#text(" where ")#mi("{g \\in S}")#text(". By ")#link(<tao-cddd67830982a78cc839>)[#text("(3)")]#text(", they are all at distance ")#mi("{O(\\epsilon \\delta_1)}")#text(" from the identity, and have determinant ")#mi("{1}")#text(". If they are all constant multiples of the identity, then by arguing as before we see that ")#mi("{h_1}")#text(" is central in ")#mi("{G^{\\prime}}")#text(", a contradiction, so we can find an element ")#mi("{h_2 := [g_1,h_1]}")#text(" for some ")#mi("{g_1 \\in S}")#text(" which is a distance ")#mi("{\\delta_2 = O_n(\\epsilon \\delta_1)}")#text(" from the origin and is not a multiple of the identity. Continuing this, we can construct ")#mi("{h_3 := [g_2,h_2]}")#text(", etc., where each ")#mi("{h_n}")#text(" is a distance ")#mi("{0 < \\delta_n = O( \\epsilon \\delta_{n-1} )}")#text(" from the identity, and is a commutator of ")#mi("{h_{n-1}}")#text(" with a generator.")

#text("Because of the lacunary nature of the distances of ")#mi("{h_1,h_2,h_3,\\ldots}")#text(", we easily see that the words ")#mi("{h_1^{i_1} \\ldots h_m^{i_m}}")#text(" with ")#mi("{0 \\leq i_1,\\ldots,i_m \\leq c \\epsilon^{-1}}")#text(" are distinct for some small ")#mi("{c > 0}")#text(". On the other hand, all of these words lie in the ball of radius ")#mi("{O( m \\epsilon^{-1} 2^m )}")#text(" generated by ")#mi("{S}")#text(". This contradicts the polynomial growth hypothesis for ")#mi("{\\epsilon}")#text(" taken small enough and ")#mi("{m}")#text(" large enough.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Theorem ")#link(<tao-a81741a8946ba3bb3206>)[#text("4")]#text(" can be deduced as a corollary of Gromov’s theorem, though we do not do so here as this would be circular. Indeed, it is not hard to see that the image of a torsion-free nilpotent group in a unitary group must be abelian.")
]

#heading(level: 1)[#strong[#text(" — 5. The case of an infinite abelian quotient — ")]]

#text("Now we prove Theorem ")#link(<tao-d3e98aeebf105a0bfe18>)[#text("5")]#text(" (which was already observed in Gromov’s original paper, and also closely related to earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=232311")[#text("of Milnor")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=248688")[#text("of Wolf")]#text(").")

#text("Since ")#mi("{G}")#text(" is finitely generated and has polynomial growth of order ")#mi("{d}")#text(", the finite index subgroup ")#mi("{G^{\\prime}}")#text(" is also finitely generated of growth ")#mi("{d}")#text(". By hypothesis, there is a non-trivial homomorphism ")#mi("{\\phi: G^{\\prime} \\rightarrow {\\bf Z}}")#text(". Using the Euclidean algorithm, one can move the generators ")#mi("{e_1,\\ldots,e_m}")#text(" of ")#mi("{G^{\\prime}}")#text(" around so that all but one of them, say ")#mi("{e_1,\\ldots,e_{m-1}}")#text(", lie in the kernel ")#mi("{\\text{ker}(\\phi)}")#text(" of ")#mi("{\\phi}")#text("; we thus see that this kernel must then be generated by ")#mi("{e_1,\\ldots,e_{m-1}}")#text(" and their conjugates ")#mi("{e_m^k e_i e_m^{-k}}")#text(" by powers of ")#mi("{e_m}")#text(".")

#text("Let ")#mi("{S_k}")#text(" be the set of ")#mi("{e_m^{k^{\\prime}} e_i e_m^{-k^{\\prime}}}")#text(" for ")#mi("{1 \\leq i \\leq m-1}")#text(" and ")#tao-math("{\\left|k^{\\prime}\\right| \\leq k}", block: false)#text(", and let ")#mi("{B_k}")#text(" be the words of length at most ")#mi("{k}")#text(" generated by elements of ")#mi("{S_k}")#text(". Observe that if at least one of the elements in ")#mi("{S_{k+1}}")#text(" is not contained in ")#mi("{B_k \\cdot B_k^{-1}}")#text(", then ")#mi("{B_{k+1}}")#text(" is at least twice as big as ")#mi("{B_k}")#text(". Because of polynomial growth, this implies that ")#mi("{S_{k+1} \\subset B_k \\cdot B_k^{-1}}")#text(" for some ")#mi("{k \\geq 1}")#text(", which implies that ")#mi("{\\text{ker}(\\phi)}")#text(" is generated by ")#mi("{S_k}")#text(".")

#text("Observe that the ball of radius ")#mi("{R}")#text(" generated by ")#mi("{S_k}")#text(" and ")#mi("{e_m}")#text(" is at least ")#mi("{R/2}")#text(" times as large as the ball of radius ")#mi("{R/2}")#text(" generated by ")#mi("{S_k}")#text(". Since ")#mi("{G^{\\prime}}")#text(" has growth ")#mi("{d}")#text(", we conclude that ")#mi("{\\text{ker}(\\phi)}")#text(" has growth at most ")#mi("{d-1}")#text(", and is thus virtually nilpotent by hypothesis.")

#text("We have just seen that the kernel ")#mi("{\\text{ker}(\\phi)}")#text(" contains a nilpotent subgroup ")#mi("{N}")#text(" of some finite index ")#mi("{M}")#text("; it is thus finitely generated. We can take ")#mi("{N}")#text(" to be a normal subgroup of ")#mi("{\\text{ker}(\\phi)}")#text(". From Lagrange’s theorem, we see that the group ")#mi("{N^{\\prime}}")#text(" generated by the powers ")#mi("{g^M}")#text(" with ")#mi("{g \\in \\text{ker}(\\phi)}")#text(" is then contained in ")#mi("{N}")#text(" and is therefore nilpotent. ")#mi("{N^{\\prime}}")#text(" is clearly a ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic subgroup")]#text(" of ")#mi("{\\text{ker}(\\phi)}")#text(", and is thus normal in ")#mi("{N}")#text(". The group ")#mi("{N/N^{\\prime}}")#text(" is nilpotent and finitely generated with every element being of order ")#mi("{M}")#text(", and is thus finite; thus ")#mi("{N^{\\prime}}")#text(" is finite index in ")#mi("{\\text{ker}(\\phi)}")#text(". Since it is characteristic, it is in particular invariant under conjugation by ")#mi("{e_m}")#text(". If one lets ")#mi("{G^{\\prime\\prime} = {\\bf Z} \\ltimes_{e_m} N^{\\prime}}")#text(" be the group generated by ")#mi("{N^{\\prime}}")#text(" and ")#mi("{e_m}")#text(", we see that ")#mi("{G^{\\prime\\prime}}")#text(" is a finite index subgroup of ")#mi("{G}")#text(". (Note that as ")#mi("{e_m}")#text(" is not annihilated by ")#mi("{\\phi}")#text(", it will have infinite torsion even after quotienting out by ")#mi("{N^{\\prime}}")#text(".) In particular, it has polynomial growth.")

#text("To conclude, we need to show that ")#mi("{G^{\\prime\\prime}}")#text(" is virtually nilpotent. It will suffice to show that the conjugation action of ")#mi("{e_m^a}")#text(" on ")#mi("{N^{\\prime}}")#text(" acts unipotently on ")#mi("{N^{\\prime}}")#text(" for some finite ")#mi("{a>0}")#text(". We can induct on the step of the nilpotent group ")#mi("{N^{\\prime}}")#text(", assuming that the claim has already been proven for the quotient group ")#mi("{N^{\\prime}/Z(N^{\\prime})}")#text(" (where ")#mi("{Z(N^{\\prime})}")#text(" is the centre of ")#mi("{N^{\\prime}}")#text("), which has one lower step on ")#mi("{N^{\\prime}}")#text(". Thus it suffices to prove unipotence on just the center ")#mi("{Z(N^{\\prime})}")#text(", which is a finitely generated abelian group and thus isomorphic to some ")#mi("{{\\bf Z}^d \\times H}")#text(" for some finite group ")#mi("{H}")#text(". By Lagrange’s theorem, the action on ")#mi("{H}")#text(" becomes trivial after raising ")#mi("{e_m}")#text(" to a suitable power, so we only need to consider the action on ")#mi("{{\\bf Z}^d}")#text(". In this case the conjugation action can be viewed as a matrix ")#mi("{A}")#text(" in ")#mi("{SL_d({\\bf Z})}")#text(". Because ")#mi("{G^{\\prime\\prime}}")#text(" has polynomial growth, the powers ")#mi("{A^n}")#text(" of ")#mi("{A}")#text(" for ")#mi("{n \\in {\\bf Z}}")#text(" cannot grow exponentially (as otherwise the number of subsums of ")#mi("{A^n e_i}")#text(" for ")#mi("{i=1,\\ldots,d}")#text(" and ")#mi("{n=1,\\ldots,N}")#text(" would grow exponentially in ")#mi("{N}")#text(", contradicting the polynomial growth hypothesis); in other words, all the eigenvalues of ")#mi("{A}")#text(" have unit magnitude. On the other hand, these eigenvalues consist of Galois conjugacy classes of algebraic integers. But Kronecker’s theorem asserts that the only algebraic integers ")#mi("{\\alpha}")#text(" whose Galois conjugates all have unit magnitude are the roots of unity (Proof: the algebraic integers ")#mi("{\\alpha^n}")#text(" have bounded degree and uniformly bounded Galois conjugates, hence their minimal polynomial has bounded integer coefficients, and thus repeat itself). We conclude that all the eigenvalues of ")#mi("{A}")#text(" are roots of unity, i.e. some power of ")#mi("{A}")#text(" is unipotent, and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ac3c76aa80d152ff714ebde7860c6f7faa34ec75003e82518a3612d564cfe22-1ebff00a84a42d109c55c13c09f479a57e6eaee2aac59060c8356b26585ebe2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DrDolittle")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43673")[#strong[#text("DrDolittle")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("The statement of theorem 5 would be more legible, I think, if you replaced “infinite abelian group” by ")#mi("Z")#text(".")#linebreak()#text(" In the proof of theorem 5, I don’t see why ")#mi("e_1,..e_{m-1}")#text(" should generate the kernel – for example, ")#mi("e_m e_1 e_m^{-1}")#text(" again is in the kernel.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43674")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Terry,")

#text("Thanks for this. I think this proof can definitely be given in a graduate course now, and I intend to do so myself next academic year.")

#text("Best")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43675")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Dear Mr. Tao,")

#text("a couple of comments regarding the proof of the existence of a Lipschitz harmonic function:")

#text("In the non-amenable case: g_n should be H_n and in the last paragraph, there is no need to appeal to the discreteness of G.")

#text("In the amenable case, I don’t quite see how does one arrive at ||F_n-F_n*δ_s||_{ℓ²}=O(n^{-½}): a direct calculation gives a bound in terms of ||f_n-f_n*δ_s||_{ℓ¹}, which has unknown decay (but is sufficient to conclude).")

#text("If I understand it right, at the end of the proof one chooses a convergent subsequence of H_n*G_n. How does one ensure ∞-boundedness of this sequence? The sequence G_n must go to infinity if ≡1.")

#text("regards, pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43676")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("that is, (G_n, ΔG_n)≡1. (always forget that the “less” and “greater” signs are reserved symbols)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43677")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Thanks for the corrections!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43680")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Two more things: in the Dirichlet energy identity, there seems to be a 1/2 missing on the right.")

#text("Then, I don’t see which topology you would choose to apply Arzelà-Ascoli.")

#text("Instead, one could use the uniform Lipschitz condition to get pointwise boundedness and then select a pointwise convergent subsequence. The value of the Laplacian in a point is a continuous function of a finite amount of values of its argument and thus passes to the limit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Thanks again for the correction.")

#text("I’m applying Arzela-Ascoli (for sigma-compact domains, and in the topology of locally uniform convergence) for the discrete group G. Of course, the proof of Arzela-Ascoli in this case is exactly as you describe, plus one application of diagonalisation. (I tend to lump all arguments that involve the Arzela-Ascoli diagonalisation trick under the category of Arzela-Ascoli type arguments, as a convenient shorthand.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c4555db4237a5fd431f9f45c115762304a300c2d8d1ca992f7c3b94db0fb386-394dc1bee3add89e8562624b39ac5dc64fbd9b199c284bc984fb83659400358e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Solomyak")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43689")[#strong[#text("Boris Solomyak")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("Terry,")

#text("This is great timing, since Steffen Rohde and I are just now covering Gromov’s theorem in a graduate course in Seattle. I have a minor question:")#linebreak()#text(" isn’t it the case that the Poincare inequality in this blog should be “reverse Poncare” and vice versa?")

#text("Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43694")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2010")])]

#text("Some dumb questions about the amenable growth case in Theorem 2:")

#text("(1) I don’t understand the statement that, since ")#mi("\\Delta")#text(" has nontrivial spectrum at the origin, there is a sequence ")#mi("G_n")#text(" with ")#mi("\\langle G_n,  \\Delta G_n \\rangle =1")#text(" and ")#tao-math("\\left|\\Delta G_n\\right| \\to 0", block: false)#text(".")

#text("Suppose ")#mi("\\Delta")#text(" was a self-adjoint idempotent, such as ")#mi("\\begin{smallmatrix} 1 & 0 \\\\ 0 & 0 \\end{smallmatrix}")#text(". Then ")#tao-math("\\langle G_n, \\Delta G_n \\rangle = \\langle \\Delta G_n, \\Delta G_n \\rangle = \\left|G_n\\right|^2", block: false)#text(".")

#text("(2) In a possibly related issue, I don’t understand where you use that ")#mi("G")#text(" is infinite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-43695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2010")])]

#text("Ah, thanks! Yes, the two issues are related. I forgot to mention that when G is infinite, there are no non-trivial harmonic functions in ")#mi("\\ell^2(G)")#text(" (from the maximum principle), and so ")#mi("\\Delta")#text(" has no eigenfunction at zero; the spectrum at zero must then be coming from something other than pure point spectrum at the origin (e.g. continuous spectrum, or a sequence of eigenvalues tending to zero but not actually zero). Now what one can do is take the functions ")#mi("F_n")#text(" and spectrally project them to a small interval ")#mi("[0,\\varepsilon]")#text(" near the origin, which upon normalisation will give the desired ")#mi("G_n")#text(" thanks to the spectral theorem. (The absence of a zero eigenfunction is needed to ensure that we do not divide by zero when performing the normalisation.) I’ve changed the text accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8c1203d7f31aafc34322b009621eb45b736076bb0a611be7053943dfafc686-51bcccf5ddb2ff5658e8ce8dc6b1c1fd8cc866c0e0306612367dcd242fb15df0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gábor Pete")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-46090")[#strong[#text("Gábor Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("Dear Terry,")

#text("I seem to see a mistake in the penultimate paragraph. I’m probably wrong, because I see the same issue in Tits’ appendix to Gromov and in the Drutu-Kapovich lecture notes, but could you please help?")

#text("Why would the subgroup of G generated by N’ and e_m be the semidirect product given by conjugation by e_m? For instance, in the short exact sequence {0} –> {0,2} –> {0,1,2,3} –> {0,1} —> {0} of additive cyclic groups, {0,2} and 1 generate {0,1,2,3}, but conjugation by 1 is the trivial action on {0,2}, hence the semidirect product is a direct product \\Z_2\\times\\Z_2, which is not the same as \\Z_4.")

#text("If I were right, then the last paragraph, about the conjugations, would not apply.")

#text("Embarrassingly, I realized I didn’t understand this point during a lecture I was giving…")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-46095")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("Because we are in the infinite quotient case, ")#mi("e_m")#text(" has infinite order even after quotienting by N’ (recall that ")#mi("\\phi: G^{\\prime} \\to {\\bf Z}")#text(" annihilates N’ but not ")#mi("e_m")#text("), so the torsion obstruction indicated by your example does not arise. (To put it in fancier language, the base group here is ")#mi("{\\bf Z}")#text(" (as opposed to {0,1} in your example), which has a trivial first group cohomology.) I’ve modified the text to clarify this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8c1203d7f31aafc34322b009621eb45b736076bb0a611be7053943dfafc686-51bcccf5ddb2ff5658e8ce8dc6b1c1fd8cc866c0e0306612367dcd242fb15df0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gábor Pete")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-46098")[#strong[#text("Gábor Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("Thanks! This was really dumb…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-49612")[#strong[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("[…] result can be compared with Jordan’s theorem (discussed earlier on this blog) that every finite subgroup of is virtually abelian (with a uniform bound on the index of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-49770")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] in Gromov’s proof of his theorem on groups of polynomial growth (discussed previously on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed previously). It is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbffc0c46d8bb18b3221d2cbbdf4ad72348d417c6d32259de5aa2f0770be46b4-0586e688a235d88f3b08071c6950de46c762ab81047d5dc56eb9c28dce67a80a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-54836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2011")])]

#text("I wonder if someone can provide an explicit reference to the")#linebreak()#text(" paper of the above Theorem 7 (Jordan’s theorem) — a theorem number, page number, or something like that. If i am not mistaken, it should be in Jordan’s paper: Mémoire sur les équations différentielles")#linebreak()#text(" linéaires à intégrale algébrique, J. reine angew. Math. 84 (1878), 89–215?")#linebreak()#text(" In any case i enjoyed the above prove!")#linebreak()#text(" Paulo")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbffc0c46d8bb18b3221d2cbbdf4ad72348d417c6d32259de5aa2f0770be46b4-0586e688a235d88f3b08071c6950de46c762ab81047d5dc56eb9c28dce67a80a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-54838")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2011")])]

#text("Embarrassingly, i have found it now: Page 91.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-70866")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] on harmonic functions of polynomial growth. (This latter proof is discussed in these previous blog posts.) The proof we will give in these notes is more recent, based on an . We remark that the strategy […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-191352")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2012")])]

#text("Dear Prof. Tao,")

#text("I have been working my way through your elementary proof of Gromov’s theorem and understood most of it, but I am currently stuck on the last paragraph of your proof of Theorem 5 (the case of an infinite abelian quotient).")

#text("But first a few remarks:")

#text("1) In the fourth paragraph of the proof of theorem 5, you claim that “the ball of radius R generated by ")#mi("S_k")#text(" is at least ")#mi("R/2")#text(" times as large as the ball of radius R/2 generated by ")#mi("e_1, \\dots, e_{m-1}")#text("“.")#linebreak()#text(" I think you have to replace ")#mi("e_1, \\dots, e_{m-1}")#text(" by ")#mi("\\Gamma_k := \\{e_1, \\dots, e_m , e_1^{-1}, \\dots, e_m^{-1}, 1_G\\}^{2k+1}")#text(", as then ")#mi("S_k \\subset \\Gamma_k")#text(" and thus ")#mi("(S_k^l e_m^i)_{i = 1,\\dots, l}")#text(" are pairwise disjoint subsets of ")#mi("\\Gamma_k^{2l}")#text(" each of cardinality ")#tao-math("\\left|S_k\\right|", block: false)#text(", so that your claim follows. At the very least, you will have to replace ")#mi("e_{1}, \\dots, e_{m-1}")#text(" by ")#mi("e_1, \\dots, e_m")#text(".")

#text("2) In the fifth paragraph of that proof you claim that the group generated by the powers ")#mi("g^M")#text(" would be contained in ")#mi("N")#text(" by Lagrange’s theorem.")#linebreak()#text(" This is only true if ")#mi("N")#text(" is a normal subgroup, as can be seen by the example ")#mi("G=S_3")#text(", ")#mi("N=")#text(" and ")#mi("g=(1,2)")#text(", where ")#mi("[G:N] = 3")#text(", but ")#mi("g^3 = (1,2) \\not \\in N")#text(".")#linebreak()#text(" This is no problem, as every subgroup ")#mi("H \\leq G")#text(" of finite index contains a subgroup ")#mi("N \\leq H")#text(" such that ")#mi("N")#text(" is normal in ")#mi("G")#text(" and ")#mi("[G:N] < \\infty")#text(", so that you can assume that ")#mi("N")#text(" is a normal subgroup.")

#text("Now to my question regarding the last paragraph of that proof:")

#text("Why does the polynomial growth of ")#mi("G^{\\prime\\prime}")#text(" imply the (at most) polynomial growth of the entries of ")#mi("A^n")#text("?")#linebreak()#text(" The only thing that I can deduce from the polynomial growth assumption is that since ")#tao-math("A^k x = e_m^k x e_m^{-k} \\in \\left\\{e_1, \\dots, e_m, e_1^{-1}, e_m^{-1}, 1_G\\right\\}^{2k+\\left\\| x\\right\\|_{\\infty}}", block: false)#text(", you can bound the number of elements(!) in ")#mi("A(B_k) \\cup \\dots \\cup A^k(B_k)")#text(" by a polynomial in ")#mi("k")#text(", where ")#mi("B_k")#text(" denotes the (closed) ball of radius ")#mi("k")#text(" with respect to ")#tao-math("\\left\\| \\cdot \\right\\|", block: false)#text(".")#linebreak()#text(" But what I would need to show the polynomial growth of the elements of ")#mi("A^k")#text(" would be a bound on the exponents of the generators ")#mi("e_1, \\dots, e_m-1")#text(" in an expression for ")#mi("e_m^k x e_m^{-k}")#text(" instead of just a bound on the number of elements.")#linebreak()#text(" Could you give me a hint here?")

#text("Best regards, and thanks in advance for your help,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-191694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("Thanks for the corrections, which are now implemented! Regarding your final question, I should have written “cannot grow exponentially” rather than “can only grow polynomially”. If the ")#mi("A^n")#text(" exhibit exponential growth, then the ")#mi("A^n e_i")#text(" for ")#mi("i=1,\\ldots,d")#text(" and ")#mi("n=1,\\ldots,N")#text(" will be lacunary enough that the number of all possible subsums of these vectors will grow exponentially in N. On the other hand, all these subsums are contained in a ball of radius ")#mi("O(N^2)")#text(", contradicting polynomial growth.")

#text("Here we use the fact from the Jordan normal form that powers of a matrix either grow at most polynomially, or grow exponentially; there is no possibility of a intermediate growth rate. (In contrast, there are nontrivial examples of finitely generated groups of intermediate growth, most notably the Grigorchuk groups.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-192574")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Dear Prof. Tao,")

#text("thank you very much for clarifying my problem.")

#text("I have one more question regarding the same paragraph of the proof of Theorem 5. That question may have a very simple solution which I don’t see, as my knowledge of group theory is limited:")

#text("You claim that it is sufficient to show that the conjugation-action of some power ")#mi("e_m^a")#text(" of ")#mi("e_m")#text(" on ")#mi("N^{\\prime}")#text(" is unipotent.")

#text("My interpretation of unipotency in this case (I only knew that term in connection with matrices) is that for some ")#mi("n \\in \\mathbb{N}")#text(" and ")#mi("b := e_m")#text(" the ")#mi("n")#text("-fold iteration of ")#mi("y \\mapsto \\left(b y b^{-1} \\right) \\cdot y^{-1} = \\left[b, y\\right]")#text(" is trivial, i.e. ")#mi("[b, [b, \\dots, [b,y] \\dots ] ] = 1_{G}")#text(" for all ")#mi("y \\in N^{\\prime}")#text(", where the commutator is of length ")#mi("n")#text(". Your proof actually shows (if I am not mistaken) that all(!) powers of ")#mi("b")#text(" act unipotently (with the same ")#mi("n")#text(").")#linebreak()#text(" One furthermore knows that ")#mi("N^{\\prime}")#text(" is nilpotent, i.e., for some ")#mi("k\\in \\mathbb{N}")#text(", all commutators of length ")#mi("\\geq k")#text(" vanish. But I do not see why this already implies the nilpotency of the semidirect product ")#mi("\\mathbb{Z} \\ltimes_{b} N^{\\prime}")#text(" (I guess that this is what you want to show, as this group has finite index in ")#mi("G^{\\prime\\prime}")#text(").")

#text("My idea would be to show that all commutators of a suitable length vanish, but I run into problems, when the commutator “alternates” between ")#mi("b")#text(" and elements ")#mi("x \\in N^{\\prime}")#text(" of ")#mi("N^{\\prime}")#text(" (or also different powers of ")#mi("b")#text("), i.e., something like ")#mi("[b, [x, [b, [y, \\dots ] ] ]")#text(".")#linebreak()#text(" Could you help me with this?")

#text("Furthermore I am not sure that your proof that all algebraic integers whose Galois-conjugacy class is a subset of the unit circle are roots of unity is correct. According to ")#link("http://math.stackexchange.com/questions/4323/are-all-algebraic-integers-with-absolute-value-1-roots-of-unity")[#text("http://math.stackexchange.com/questions/4323/are-all-algebraic-integers-with-absolute-value-1-roots-of-unity")]#text(", the statement does not hold if only ")#tao-math("\\left|\\alpha\\right| = 1", block: false)#text(" (i.e. there are Galois conjugates outside of the unit circle) and your proof seems to work even in that case.")

#text("Best regards and many thanks again,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-192666")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Thanks again for the corrections! I have now put in a correct proof of Kronecker’s theorem instead of the incorrect one sketched previously.")

#text("Regarding how to establish nilpotence of ")#mi("{\\bf Z} \\ltimes_{e_m^a} N^{\\prime}")#text(" when ")#mi("e_m^a")#text(" acts unipotently, observe that the action of ")#mi("e_m^a")#text(" preserves each member of the lower central series of N’ (as these are characteristic subgroups of N’), while conjugation by an element of N’ moves from one element of the lower central series to the next. Thus, no matter how one alternates between commutation by ")#mi("e_m^a")#text(" or commutation by an element of N’, one either marches up the lower central series and eventually becomes trivial, or else one has a long string of commutation by ")#mi("e_m^a")#text(" and so one becomes trivial by unipotence.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-194707")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("Dear Prof. Tao,")

#text("thank You very much, that helped a lot.")

#text("Best regards,")

#text("Felix V.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-235439")[#strong[#text("Three Theorems About Growth | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")]

#text("[…] All three theorems—more precisely, the proofs of these theorems—require one to overcome a technical hurdle. This is indeed the reason I decided to talk about these results. I was reading a chapter of Terence Tao’s beautiful book titled “Compactness and Contradiction” where he gives an outline of the proof of Gromov’s theorem. Tao is brilliant at explaining things, and you can see this also on-line here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-239640")[#strong[#text("Kleiner’s space of harmonic functions | Ehsaan's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2013")]

#text("[…] T. Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96afe3eda5ed3466e140b8e093dcdbdb6ec8fc6400d007f3aa93ed6d5b7f29b9-f583a89de5bdea1d49a8ad091c6a1c4f5a6e52a677176dc561089c9444eafdbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lingnaodai11")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-444144")[#strong[#text("lingnaodai11")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2014")])]

#text("Reblogged this on ")#link("http://lingnaodai.wordpress.com/2014/12/06/a-proof-of-gromovs-theorem/")[#text("lingnaodai")]#text(" and commented:")#linebreak()#text(" I hope to ask Kleiner to be my advisor.. I hope to understand more of his work, and of group theory of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-459126")[#strong[#text("A Polynomial Growth Puzzle | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2015")]

#text("[…] recalled a post by Terence Tao on Mikhail Gromov’s theorem characterizing finitely-generated groups of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-463202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2015")])]

#text("In the definition of Lipschitz, shouldn’t ")#mi("sx")#text(" be ")#mi("xs")#text("? Thank you very much.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-463208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2015")])]

#text("In the proof of Theorem 2, in the non-amenable case, there is “Since bounded functions are automatically Lipschitz, and the claim follows.” which doesn’t seem very good English to me. I would remove the “and”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-483477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Regarding bounded doubling: What do you mean by “bounded doubling on most scales”? What is the pigeonhole argument showing this? (if you tell me what “most scales” means, maybe I can take this as an exercise). Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-483487")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("One can show for instance that in a group of polynomial growth, for any ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("C_\\varepsilon > 0")#text(" such that one has the doubling property ")#tao-math("\\left|B(2r)\\right| \\leq C_\\varepsilon \\left|B(r)\\right|", block: false)#text(" for a set of radii ")#mi("r")#text(" of ")#link("https://en.wikipedia.org/wiki/Natural_density")[#text("logarithmic density")]#text(" at least ")#mi("1-\\varepsilon")#text(". Or, if one restricts to radii ")#mi("r=2^n")#text(" that are powers of two, the same claim is true for a set of exponents ")#mi("n")#text(" of natural density at least ")#mi("1 - \\varepsilon")#text(".")

#text("(Here I am using the pigeonhole principle in the broad sense, to also encompass other basic results (such as Markov’s inequality) on how a function must deviate around its average.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91a47409566c445a6fd7a0c539b6c47bd26a3f8e852642328d11095e0af4e30f-f92e1efd7f14455da97f17ffcd79423aa96d7108cb6812aabad2936e610724e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Woess")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-506271")[#strong[#text("Wolfgang Woess")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2018")])]

#text("Here is a question which bothers me since quite a while, and which I discussed very briefly with Terry Tao at a Conference in Cortona in June:")#linebreak()#text(" For a complete proof of Varopoulos’ classification of the recurrent groups (= finitely generated groups carrying a recurrent random walk), one only needs the following special cases of Gromov’s theorem:")#linebreak()#text(" (1) A group which does not grow at most quadratically must grow at least cubically,")#linebreak()#text(" (2) A group which grows at most quadratically is virtually Z or Z^2.")#linebreak()#text(" “At most quadratically” can be replaced by ” liminf V(n)/n^2 is finite “,")#linebreak()#text(" where V(n) is the growth function.")#linebreak()#text(" Are there simpler proofs for (1) and/or (2) than the general one ?")#linebreak()#text(" As a matter of fact, all the rest of Varopoulos theorem can be presented to 3rd year students.")#linebreak()#text(" Regards, Wolfgang")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-506468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2018")])]

#text("This is basically asking whether there is a shortcut to prove Gromov’s theorem for subcubic growth. This is roughly analogous (though easier than) trying obtain a Freiman type theorem for sets of doubling constant strictly less than ")#mi("2^3 = 8")#text(". While there is a lot of work on Freiman type theorems with very small doubling constant (e.g. strictly less than ")#mi("2^2 = 4")#text("), I unfortunately don’t know of any way to treat sets of doubling less than 8 that don’t generalise to handle the case of arbitrary doubling. This doesn’t directly rule out a corresponding shortcut for subcubic Gromov, since one has more structure in that setting (whereas Freiman’s theorem deals with the doubling constant for arbitrary sets, the sets in Gromov’s theorem are balls, and this structure can be exploited).")

#text("Though, perhaps one way forward would be to somehow show directly that groups of subcubic growth are virtually abelian, at which point one it is easy to see that the rank is at most two. Given that non-virtually-abelian groups have at least quartic growth (as the Heisenberg group example illustrates), there is a little bit of room here to allow for some slightly inefficient arguments to proceed. Still seems tricky though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a0f44a8c511f4932319d17ca650f4e24496c98ef4a95ac5d7d8cc2f65cd369e-26b6ab8f4bae73cce8cbb72917668110f567679a0266f37c85ecf8bb4d5585a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lee Mosher")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-642479")[#strong[#text("Lee Mosher")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2022")])]

#text("I have a question about the interval ")#mi("[0,\\epsilon)")#text(". Why shouldn’t one use ")#mi("(-\\epsilon,\\epsilon)")#text(" instead? Isn’t it possible that for small enough ")#mi("\\epsilon")#text(" the spectrum intersects ")#mi("[0,\\epsilon)")#text(" in just ")#mi("0")#text("? I was thinking on the other hand that ")#mi("\\Delta")#text(" is a positive operator, but I cannot see why.")

#text("By the way I’m presenting the proof of the polynomial growth theorem in my class this semester, drawing from your blog and its sources (papers of Gromov, Kleiner, you and Shalom, and learning some functional analysis). Back in the early mid 80’s sometime, attending Thurston’s class, he gave me the assignment of presenting Gromov’s paper. I must confess, I never did the assignment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-642533")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#mi("\\Delta")#text(" is indeed positive semi-definite, since ")#tao-math("\\langle F * \\mu, F \\rangle = \\int F * \\tilde F\\ d\\mu \\leq \\left\\| F * \\tilde F\\right\\|_\\infty = \\left\\|F\\right\\|_2^2 = \\langle F, F \\rangle", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-644345")[#strong[#text("gr.group theory - Lipschitz harmonic functions on graphs? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")]

#text("[…] I am not familiar with this sort of subject at all but I am aware of Tao and Yahuda’s result that such functions do exist on Cayley graphs of finitely generated (with $S$ empty) with finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2a57a698da55a6d13b6b91c4acf303d17810c1cab289e85de6000b25bb5f979-70b26cf5deff7264c889ceceb3ee2e653fbff1eaa2f195eb7595911744ca3417.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Yitong")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-687519")[#strong[#text("Zhang Yitong")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2025")])]

#text("Dear Professor Tao,")

#text("Thank you for your insightful blog post! I truly appreciate the clarity and depth of your explanations.")

#text("I have a question regarding the argument just above Remark 2. If I understand correctly, you aim to rescale ")#mi("\\epsilon")#text(" so that ")#mi("(c \\epsilon^{-1})^m")#text(", which represents the cardinality of")

#mi("\\displaystyle h_1^{i_1} \\dots h_m^{i_m} \\mid i_1, \\dots, i_m \\in [0, c \\epsilon^{-1}]")

#text("exceeds ")#mi("(m\\epsilon^{-1} 2^m)^k")#text(" for a fixed ")#mi("k")#text(". This would then lead to a contradiction if ")#mi("G^{\\prime}")#text(" exhibits polynomial growth (specifically, ")#mi("O(m^k)")#text(" growth).")

#text("However, I was wondering whether adjusting ")#mi("\\epsilon")#text(" might also alter ")#mi("G^{\\prime}")#text(" by definition, which could potentially affect the argument. Specifically, if there exists a sequence of subgroups ")#mi("G^{\\prime}_\\epsilon")#text(" (generated by ")#mi("B_\\epsilon(I_n) \\cap G")#text("), and if the growth rate of ")#mi("G^{\\prime}_\\epsilon")#text(" with respect to the corresponding generating set ")#mi("S_\\epsilon")#text(" is ")#mi("O(n^{\\epsilon^{-1}})")#text(", then modifying ")#mi("\\epsilon")#text(" might in turn affect the polynomial growth rate, possibly avoiding a contradiction.")

#text("To be more concrete, in order to select ")#mi("h_1, \\dots, h_m")#text(" such that ")#mi("h_1^{i_1} \\dots h_m^{i_m}")#text(" are distinct for ")#mi("i_k \\in [0, M]")#text(", where ")#mi("M")#text(" is sufficiently large relative to ")#mi("k")#text(" (ensuring that ")#mi("G^{\\prime}")#text(" with respect to ")#mi("S")#text(" has ")#mi("O(n^k)")#text(" growth), we need to choose the generating set ")#mi("S")#text(" close enough to ")#mi("I_n")#text(". However, this choice depends on ")#mi("k")#text(", hence, the definition of the word metric, which depends on ")#mi("S")#text(" itself. Which I find a bit unclear.")

#text("I would greatly appreciate your thoughts on this. Thank you for your time and consideration!")

#text("Regards,")#linebreak()#text("Yitong")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-687521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2025")])]

#text("Passing from ")#mi("G")#text(" to ")#mi("G^{\\prime}")#text(" (and from ")#mi("S")#text(" to ")#mi("S_\\varepsilon")#text(") can change the constant in the polynomial growth rate, but does not affect the *exponent* in the growth rate, so one can still get a contradiction by taking ")#mi("m")#text(" large enough (depending on ")#mi("\\varepsilon")#text(") to outrun any changes in the growth constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2a57a698da55a6d13b6b91c4acf303d17810c1cab289e85de6000b25bb5f979-70b26cf5deff7264c889ceceb3ee2e653fbff1eaa2f195eb7595911744ca3417.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Yitong")]], [#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/#comment-687522")[#strong[#text("Zhang Yitong")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2025")])]

#text("I see, thanks a lot!")
]
]
]
