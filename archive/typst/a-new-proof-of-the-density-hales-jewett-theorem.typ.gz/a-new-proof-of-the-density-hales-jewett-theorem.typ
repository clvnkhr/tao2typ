// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/
// Converted to Typst by tao2typ: "2026-10-14T11:29:32.771105+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A new proof of the density Hales-Jewett theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A new proof of the density Hales-Jewett theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/")[#text("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("polymath1 project")]#text(" has just uploaded to the arXiv the paper “")#link("http://arxiv.org/abs/0910.3926")[#text("A new proof of the density Hales-Jewett theorem")]#text("“, to be submitted shortly. Special thanks here go to Ryan O’Donnell for performing the lion’s share of the writing up of the results, and to Tim Gowers for running a highly successful online mathematical experiment.")

#text("I’ll state the main result in the first non-trivial case ")#mi("k=3")#text(" for simplicity, though the methods extend surprisingly easily to higher ")#mi("k")#text(" (but with significantly worse bounds). Let ")#mi("c_{n,3}")#text(" be the size of the largest subset of the cube ")#mi("[3]^n = \\{1,2,3\\}^n")#text(" that does not contain any combinatorial line. The density Hales-Jewett theorem of Furstenberg and Katznelson shows that ")#mi("c_{n,3} = o(3^n)")#text(". In the course of the Polymath1 project, the explicit values")

#align(center)[#tao-fit-display[#mitex("c_{0,3} = 1; c_{1,3} = 2; c_{2,3} = 6; c_{3,3} = 18; c_{4,3} = 52; c_{5,3} =150; c_{6,3} = 450")]]

#text("were established, as well as the asymptotic lower bound")

#align(center)[#tao-fit-display[#mitex("c_{n,3} \\geq 3^n \\exp( - O( \\sqrt{ \\log n } ) )")]]

#text("(actually we have a slightly more precise bound than this). The main result of this paper is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" (")#mi("k=3")#text(" version) ")#mi("c_{n,3} \\ll 3^n / \\log^{1/2}_* n")#text(".")
]

#text("Here ")#mi("\\log_* n")#text(" is the inverse tower exponential function; it is the number of times one has to take (natural) logarithms until one drops below 1. So it does go to infinity, but extremely slowly. Nevertheless, this is the first explicitly quantitative version of the density Hales-Jewett theorem.")

#text("The argument is based on the density increment argument as pioneered by Roth, and also used in later papers of Ajtai-Szemerédi and Shkredov on the corners problem, which was also influential in our current work (though, perhaps paradoxically, the generality of our setting makes our argument ")#emph[#text("simpler")]#text(" than the above arguments, in particular allowing one to avoid use of the Fourier transform, regularity lemma, or Szemerédi’s theorem). I discuss the argument in the first part of ")#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/")[#text("this previous blog post")]#text(".")

#text("I’ll end this post with an open problem. In our paper, we cite the work of P. L. Varnavides, who was the first to observe the elementary averaging argument that showed that Roth’s theorem (which showed that dense sets of integers contained at least one progression of length three) could be amplified (to show that there was in some sense a “dense” set of arithmetic progressions of length three). However, despite much effort, we were not able to expand “P.” into the first name. As one final task of the Polymath1 project, perhaps some readers with skills in detective work could lend a hand in finding out what Varnavides’ first name was? ")#emph[#text("Update, Oct 22:")]#text(" Mystery now solved; see comments.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41966")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("It’s great to see the project worked out so well!")

#text("As for Varnavides, it seems the name is Panaylotis L Varnavides, born in 1912, then B.A. in Athens, then PhD at University College in London in 1948, see ")#link("http://books.google.fr/books?id=Vws5AAAAIAAJ&q=varnavides+student&dq=varnavides+student&lr=")[#text("this excerpt")]#text(" of a British Who’s Who on Google Books (was indeed a bit hard to find).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41967")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Oops, on second reading it’s Panayiotis L Varnavides (i not l), apologies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b7c4aa131da825e9764009116e884e211c7ad7ac8e900e8db59f8a58433fd9-f65738458d08595e2fa6ae7c501d1de7723dbbae59671735eb6c701edecd8b54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41972")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Amazing, nice find!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41968")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("This reminds me that I have a bit of writing to do for the second polymath paper. But it will have to wait until I get back to Sweden.")#linebreak()#text(" What is the general status of the second paper now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41969")[#strong[#text("Polymath paper up on ArXiV « An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")]

#text("[…] Posted by asarwate under Uncategorized | Tags: mathematics, web | Leave a Comment From Terence Tao’s blog, I see that they have finished writing the first polymath project on A new proof of the density […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Thomas: Thanks for the speedy detective work!")

#text("Klas: Well, we have a series of drafts at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Outline_of_second_paper")[#text("http://michaelnielsen.org/polymath1/index.php?title=Outline_of_second_paper")]

#text("the most recent one being dated July 25. We have a deadline of April to submit it for the forthcoming Szemeredi birthday conference proceedings, so there is plenty of time still to refine it. You are of course welcome to make any corrections to the source files that you spot… in a month or two I may try to more actively shepherd this project towards completion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b7c4aa131da825e9764009116e884e211c7ad7ac8e900e8db59f8a58433fd9-f65738458d08595e2fa6ae7c501d1de7723dbbae59671735eb6c701edecd8b54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41973")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("By the way, I noticed today that I botched a trivial calculation, and our main theorem is actually very slightly better: ")#mi("c_{n, 3} \\ll 3^n/\\sqrt{\\log^* n}")#text(". ")#emph[#text("[Updated, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecabd1fa6afb4ba4a3625fa1a3767a50727ed7d05caf41c50ed4f827e2a28f26-1d27056d0e0b78e8f41d00e11307f782870274c4b932a5867d68a38eb8fbcbe6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Varnavides")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-41988")[#strong[#text("Andreas Varnavides")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("Yes his first name was Panayiotis, born in Paphos Cyprus. He was my uncle")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7b6a828adc240251f48ba4eebe9a0ed1d42ed9d745d9ff1e90b11e384823570-2fc9da8ddb148db84c943dc22021a88cc6fd48b6409339f995b4780a469ba866.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alison Playle")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-641184")[#strong[#text("Alison Playle")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2022")])]

#text("Hi Andreas. Just reaching out to you for some information. My partner is Stephen Lambros Varnavides. We were discussing his Uncle (deceased) and he said that he was a Prof in Mathmatics and said his first name was Buniyotis (probably mis pronounced). Steves father, Themis (deceased) was also born in Cyprus. Themis died in the mid 1990 ‘s and was over 90 when he passes, so the ages are similar. It may just be a coincidence, but it sounds like your Uncle and Panaylotis could be the same person? I found a photo of Panaylotis (from 1946) on Google and he looks a lot like Steve. Do you think they could be one and the same person? If so that makes you and Steve cousins?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-42000")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2009")]

#text("[…] in the new proof and the only reference to his first name was the initial P. ) Terry Tao asked it on his blog and in a short time the mystery was resolved when Thomas Sauvaget found the answer. The next […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-120900")[#strong[#text("Réenchanter la science, collectivement | Matières Vivantes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2012")]

#text("[…] la discussion en commentaires sur la meilleure façon de les résoudre collectivement. Le premier projet Polymath résolu a été mis sur l’arXiv en Octobre […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c41787ce02c5f79b11aa14b97418991066231428030b43591abd7034b0150cef-55a6536defea4c93e545fe4969b5f27dfeba490c37819982d295e53e7fac1577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hyunwoo Park")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/#comment-686369")[#strong[#text("Hyunwoo Park")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("did you mean 450 for C_{6,3}? ")#link("https://oeis.org/search?q=1%2C2%2C6%2C18%2C52%2C150&language=english&go=Search")[#text("https://oeis.org/search?q=1%2C2%2C6%2C18%2C52%2C150&language=english&go=Search")]

#emph[#text("[I believe so, yes. -T]")]
]
