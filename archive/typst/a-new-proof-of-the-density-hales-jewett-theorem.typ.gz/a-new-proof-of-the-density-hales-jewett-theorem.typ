// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/
// Converted to Typst by tao2typ: "2026-10-22T12:09:34.598601+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A new proof of the density Hales-Jewett theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A new proof of the density Hales-Jewett theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/")[#text("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-22 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("polymath1 project")]#text(" has just uploaded to the arXiv the paper “")#link("http://arxiv.org/abs/0910.3926")[#text("A new proof of the density Hales-Jewett theorem")]#text("“, to be submitted shortly. Special thanks here go to Ryan O’Donnell for performing the lion’s share of the writing up of the results, and to Tim Gowers for running a highly successful online mathematical experiment.")

#text("I’ll state the main result in the first non-trivial case ")#mi("k=3")#text(" for simplicity, though the methods extend surprisingly easily to higher ")#mi("k")#text(" (but with significantly worse bounds). Let ")#mi("c_{n,3}")#text(" be the size of the largest subset of the cube ")#mi("[3]^n = \\{1,2,3\\}^n")#text(" that does not contain any combinatorial line. The density Hales-Jewett theorem of Furstenberg and Katznelson shows that ")#mi("c_{n,3} = o(3^n)")#text(". In the course of the Polymath1 project, the explicit values")

#align(center)[#tao-fit-display[#mitex("c_{0,3} = 1; c_{1,3} = 2; c_{2,3} = 6; c_{3,3} = 18; c_{4,3} = 52; c_{5,3} =150; c_{6,3} = 450")]]

#text("were established, as well as the asymptotic lower bound")

#align(center)[#tao-fit-display[#mitex("c_{n,3} \\geq 3^n \\exp( - O( \\sqrt{ \\log n } ) )")]]

#text("(actually we have a slightly more precise bound than this). The main result of this paper is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" (")#mi("k=3")#text(" version) ")#mi("c_{n,3} \\ll 3^n / \\log^{1/2}_* n")#text(".")
]

#text("Here ")#mi("\\log_* n")#text(" is the inverse tower exponential function; it is the number of times one has to take (natural) logarithms until one drops below 1. So it does go to infinity, but extremely slowly. Nevertheless, this is the first explicitly quantitative version of the density Hales-Jewett theorem.")

#text("The argument is based on the density increment argument as pioneered by Roth, and also used in later papers of Ajtai-Szemerédi and Shkredov on the corners problem, which was also influential in our current work (though, perhaps paradoxically, the generality of our setting makes our argument ")#emph[#text("simpler")]#text(" than the above arguments, in particular allowing one to avoid use of the Fourier transform, regularity lemma, or Szemerédi’s theorem). I discuss the argument in the first part of ")#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/")[#text("this previous blog post")]#text(".")

#text("I’ll end this post with an open problem. In our paper, we cite the work of P. L. Varnavides, who was the first to observe the elementary averaging argument that showed that Roth’s theorem (which showed that dense sets of integers contained at least one progression of length three) could be amplified (to show that there was in some sense a “dense” set of arithmetic progressions of length three). However, despite much effort, we were not able to expand “P.” into the first name. As one final task of the Polymath1 project, perhaps some readers with skills in detective work could lend a hand in finding out what Varnavides’ first name was? ")#emph[#text("Update, Oct 22:")]#text(" Mystery now solved; see comments.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4159e78b91f3e9a4334c1f0752d7057fec21eafd2a2d2f9dafb2f4f823c6f8d2-cc9e75a5a9e1b48bdd5a2061171274a5a1de2bbcd53de76e341baaa9c9a5a795.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41966")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("It’s great to see the project worked out so well!")

#text("As for Varnavides, it seems the name is Panaylotis L Varnavides, born in 1912, then B.A. in Athens, then PhD at University College in London in 1948, see ")#link("http://books.google.fr/books?id=Vws5AAAAIAAJ&q=varnavides+student&dq=varnavides+student&lr=")[#text("this excerpt")]#text(" of a British Who’s Who on Google Books (was indeed a bit hard to find).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4159e78b91f3e9a4334c1f0752d7057fec21eafd2a2d2f9dafb2f4f823c6f8d2-cc9e75a5a9e1b48bdd5a2061171274a5a1de2bbcd53de76e341baaa9c9a5a795.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41967")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Oops, on second reading it’s Panayiotis L Varnavides (i not l), apologies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/657df7e009774284c7822e0b667a5c0311f56f354d859c5e284b36520ad40e77-3f4edef397443ec34a221b9d840b5ed184d4ab575da730522bf5a0749705acb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41972")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Amazing, nice find!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41968")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("This reminds me that I have a bit of writing to do for the second polymath paper. But it will have to wait until I get back to Sweden.")#linebreak()#text(" What is the general status of the second paper now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41969")[#strong[#text("Polymath paper up on ArXiV « An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")]

#text("[…] Posted by asarwate under Uncategorized | Tags: mathematics, web | Leave a Comment From Terence Tao’s blog, I see that they have finished writing the first polymath project on A new proof of the density […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Thomas: Thanks for the speedy detective work!")

#text("Klas: Well, we have a series of drafts at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Outline_of_second_paper")[#text("http://michaelnielsen.org/polymath1/index.php?title=Outline_of_second_paper")]

#text("the most recent one being dated July 25. We have a deadline of April to submit it for the forthcoming Szemeredi birthday conference proceedings, so there is plenty of time still to refine it. You are of course welcome to make any corrections to the source files that you spot… in a month or two I may try to more actively shepherd this project towards completion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/657df7e009774284c7822e0b667a5c0311f56f354d859c5e284b36520ad40e77-3f4edef397443ec34a221b9d840b5ed184d4ab575da730522bf5a0749705acb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41973")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("By the way, I noticed today that I botched a trivial calculation, and our main theorem is actually very slightly better: ")#mi("c_{n, 3} \\ll 3^n/\\sqrt{\\log^* n}")#text(". ")#emph[#text("[Updated, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3703ac0fc8fe9ae6b0c2401b2787d88f95cb7a2048eb98454a9bad0d4e6802c7-38d79428e21f388610e810624ef259b24641bda15038dd4edb95181a7708179a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Varnavides")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-41988")[#strong[#text("Andreas Varnavides")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("Yes his first name was Panayiotis, born in Paphos Cyprus. He was my uncle")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63d57e125145e1fce5e256b53ad75eb24d6a3200da188ebfe1c87d7c482d4420-c3d70b42c983addbd14ee6140a8b1df1ef0b26f58d62047316adbdf058a0b33a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alison Playle")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-641184")[#strong[#text("Alison Playle")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2022")])]

#text("Hi Andreas. Just reaching out to you for some information. My partner is Stephen Lambros Varnavides. We were discussing his Uncle (deceased) and he said that he was a Prof in Mathmatics and said his first name was Buniyotis (probably mis pronounced). Steves father, Themis (deceased) was also born in Cyprus. Themis died in the mid 1990 ‘s and was over 90 when he passes, so the ages are similar. It may just be a coincidence, but it sounds like your Uncle and Panaylotis could be the same person? I found a photo of Panaylotis (from 1946) on Google and he looks a lot like Steve. Do you think they could be one and the same person? If so that makes you and Steve cousins?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-42000")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2009")]

#text("[…] in the new proof and the only reference to his first name was the initial P. ) Terry Tao asked it on his blog and in a short time the mystery was resolved when Thomas Sauvaget found the answer. The next […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-120900")[#strong[#text("Réenchanter la science, collectivement | Matières Vivantes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2012")]

#text("[…] la discussion en commentaires sur la meilleure façon de les résoudre collectivement. Le premier projet Polymath résolu a été mis sur l’arXiv en Octobre […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e19db5b5f63fad7d1d774a82f8f2b24af2e64fbcc24b90c88ab22516651d7da0-0ab7ac2e025cb32c8ca7b564b5b2fdcf3ea83b9af054b47f24515232032260a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hyunwoo Park")]], [#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/comment-page-1/#comment-686369")[#strong[#text("Hyunwoo Park")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("did you mean 450 for C_{6,3}? ")#link("https://oeis.org/search?q=1%2C2%2C6%2C18%2C52%2C150&language=english&go=Search")[#text("https://oeis.org/search?q=1%2C2%2C6%2C18%2C52%2C150&language=english&go=Search")]

#emph[#text("[I believe so, yes. -T]")]
]
