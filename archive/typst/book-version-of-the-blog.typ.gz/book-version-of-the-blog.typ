// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/
// Converted to Typst by tao2typ: "2026-10-14T06:53:10.087819+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Book version of the blog", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Book version of the blog")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/")[#text("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("It’s now been ")#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/")[#text("almost a year")]#text(" since I moved my ")#link("http://www.math.ucla.edu/~tao/whatsnew2007.html")[#text("“What’s new?” page")]#text(" from my ")#link("http://www.math.ucla.edu/~tao/")[#text("home page")]#text(" to this blog. Since then, I’ve been quite happy with the directions this blog has been headed in (most of which I had not anticipated when I started), and also with the level of feedback, some of which has been extremely informative to me (and, I hope, to other readers as well).")

#text("Anyway, after discussing things with some of my friends and colleagues, I have decided to convert some of the posts here from 2007 into a book format, in order to place some of the mathematical content here in a more formal and traditional context (with accurate citations and references, etc.). After some thought, I decided not to transcribe ")#emph[#text("all")]#text(" of my posts from last year (there are 93 of them!), but instead to restrict attention to those articles which (a) have significant mathematical content, (b) are not announcements of material that will be published elsewhere, and (c) are not primarily based on a talk given by someone else. As it turns out, this still leaves about 33 articles from 2007, leading to a decent-sized book of a couple hundred pages in length. For various reasons (including legal reasons), I have decided not to incorporate the comments to each post directly into the book format, although corrections, mention of relevant references, etc. will be added with acknowledgments in the endnotes to each article.")

#text("I’ve ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/01/whatsnew.pdf")[#text("converted a couple articles into a book format")]#text(", and also created a table of contents, to see what it would look like. (The format comes from the American Mathematical Society, with whom I am planning to publish the book.) It looks like it will be relatively straightforward to convert the rest (at least compared to writing books from scratch, which I know from experience to be quite time-consuming!). I’ll of course post updates here on this blog when the book is closer to completion.")

#text("At present, the structure and content of the book is still rather flexible; like all things related to this blog, it is an experiment. As such, I am open to suggestions on these matters. (For instance, I do not have any particularly imaginative title for the book, other than “What’s new – 2007”. )")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KenF")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24939")[#strong[#text("KenF")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2008")])]

#text("Everyone wants you to release the book under a creative commons license.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e67010639132cd3578d4d9f8615ea08ee844a5acdcb885d3728638165b04bf8-2c870f2026246c69813eee1d4721f755de625663ea00ea21e899fc1d3e926595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek Buchanan")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24942")[#strong[#text("Derek Buchanan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2008")])]

#text("Perhaps a better title would be")

#text("What was new in 2007")

#text("because what was new in 2007 isn’t new in 2008!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24943")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear Prof. Tao,")

#text("that’s a very nice idea, and I would too suggest using a CC licence (or at least have an online copy available for private use, like Allen Hatcher’s topology book).")

#text("Also do you have a way of regularly archiving the whole blog content including comments (just in case the wordpress servers break down, it would be a huge loss!).")

#text("For the title I’d suggest to add an informative subtitle, and to think about it from a long-term perspective. For instance will there be such a book every year? If so will the ")#mi("n+1")#text(" book always systematically report on any significant advances made on the open problems presented in years ")#mi("1")#text(" to ")#mi("n")#text(" even if it is not the subject of a post of yours in year ")#mi("n")#text("? And so forth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1191a271dce8843dec588cbf5c298ec555e12a8e971d11d12bcef8c2fb1576f8-b5c230a6849acd916d5fe9967f74d1496870c9f17a586146a0b263c7f9826d35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24944")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Youpi!")#linebreak()#text(" which is French for")

#text("“What an excellent piece of news. I’m looking forward to buying this book")#linebreak()#text(" and devouring it, comfortably sitting in my best armchair, sipping cup after cup of moka coffee, Brahms gently played in the background ”")

#text("(French is a very concise language.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Przemyslaw Chojecki")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24952")[#strong[#text("Przemyslaw Chojecki")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Superb idea. Would be also wonderful to see in the future an ongoing course in Dynamical Systems of yours in a book format, enriched maybe with solutions of some of exercises. Is it a chance for it?")

#text("Best Regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DeadWolfe")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24959")[#strong[#text("DeadWolfe")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("I second the idea of making the dynamical systems notes into a book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24965")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Hi,")

#text("Will the book be sold in bookstores?")

#text("KM")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Good job!I think the many will appreciate your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear all: thanks for the suggestions so far!")

#text("A subtitle does indeed resolve my concerns about the title being somewhat obscure (and, as one commenter pointed out, somewhat anachronistic).")

#text("I have not planned far ahead enough to see what to do about the (as yet mostly non-existent) 2008 posts, including the 254A lecture series notes, but presumably if the conversion of the 2007 posts proceeds painlessly and successfully then I will be encouraged to repeat the process in the future (though perhaps not exactly on an annual basis, depending on how the blog evolves; the idea of publishing one book a year, on top of all my other duties, does seem slightly excessive).")

#text("The reminder to backup this blog is also a good suggestion, and one which I will now do on a regular basis. [It turns out that it was just a matter of clicking a button from a menu; see")

#link("http://faq.wordpress.com/2005/09/28/backups/")[#text("http://faq.wordpress.com/2005/09/28/backups/")]

#text(". I now have a 981KB XML file which seems to contain all the essential content of the blog as of today.]")

#text("Judging by how my other books have been faring (with the possible exception of my problem solving book), I would doubt that you would see this book physically in a store, but with the magic of on-line retailing I would imagine that availability is unlikely to be a concern (as with other books published by the AMS). In any case, the original blog posts that the book is going to be almost entirely based on will be available at this site.")

#text("I am not an expert in licensing issues, but it seems that the usual academic model (in which the content of one’s publications can be used freely by later authors, with proper citation and attribution of course) would suffice here. (As said above, I am restricting the book to my own content, as opposed to that generated from the comments or from colleagues; the book will be based on the blog, but will not be an exact replica of it.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79111b1ca80e4c40e8844533bc648e03fc4809b3bbd6658c5bd32a892aa35431-d6fb418c95adaaeba8722e4f20e9ba8a8cfdc4bda3b4b78c69e68dc9aead584a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isabel Lugo")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24994")[#strong[#text("Isabel Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2008")])]

#text("I hope that this book will include the “career advice” posts, which I have found very useful in understanding how at least one “real mathematician” perceives mathematics. (I’m not sure if you consider them part of the blog proper, which is why I’m making this comment.)")

#text("Or, at the very least, I hope that more people read those posts. Such writings — by you and by other mathematicians — have made my transition from a student to a researcher (which is still in progress) easier to handle. The book venue may not be the right place for that, since it’s not obvious who exactly the market for the book is, and it may or may not include beginning graduate students, who are the ones who I’d think would benefit from such advice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-24996")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2008")])]

#text("(I do not know whether this belongs here or on the original entry on the non-commutative Freiman theorem, which I did not read at the time; feel free to move it, if necessary.)")

#text("You say that the growth of subsets of G=SL_2(F_p) which do *not* generate A has not been studied. As it happens, any subset of G that does not generate A is either in a dihedral group or in a Borel subgroup. It should take about two seconds to deduce a Freiman theorem for a dihedral group from the Freiman theorem over Z/nZ.")

#text("The case of subsets of a Borel is more interesting. I think I told you (on this blog) some time ago that the “right” formulation of the sum-product theorem is not over fields – or, rather, the sum-product theorem is a “shadow” of a more general result about groups with commuting automorphisms. That same general result has an even more direct application to Borel subgroups. You see, the maximal torus T (the set of diagonal matrices, say) in a Borel subgroup B (the set of upper triangular matrices) acts by conjugation on the nilpotent subgroup U consisting of the unipotent elements of B (the set of upper triangular matrices). The actions commute because T is abelian.")

#text("(I am leaving out an important technical condition that is fulfilled trivially for SL_2 (as opposed to SL_n).)")

#text("The consequence is that, if a subset A of a Borel contains at least M diagonal elements and at least one unipotent element other than the identity, it will grow by a factor of at least M^{epsilon}, unless almost all the unipotents are already in the set. One can get plenty of diagonal elements by the same method I used in my SL_2 paper – unless A lies in a very small number of cosets of the unipotents.")

#text("There are plenty of little corners left over, as you can see. Would you think it worthwhile to write the complete “non-commutative Freiman theorem” for SL_2 down in its entirety? Do you know whether somebody is already doing that? I may be getting a graduate student soon, and this might be a nice warm-up problem; I do not know what you think.")

#text("In general, I’d expect something much like Freiman’s theorem for unipotent groups; I would guess growth is forced for subsets of non-solvable groups that do not lie in a solvable subgroup; and, finally, I’d expect growth in solvable groups to be")#linebreak()#text(" described by a mildly complicated version of Freiman’s theorem when the")#linebreak()#text(" set of eigenvalues of elements of the set A is small, and to be forced otherwise. It seems clear to me that the second task is the hardest (given that we already know Freiman over abelian groups). Even the third task might not be hard.")

#text("Tell me if there is something you know that does not fit in this division.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2008")])]

#text("Dear Harald,")

#text("It would certainly be of interest for someone (such as your student) to write up a complete non-commutative Freiman theorem for ")#mi("SL_2({\\Bbb F}_p)")#text("; I do not know of anyone who is already doing this. Besides the issue of subgroups, there is also the issue of what happens for very dense sets A (of size ")#mi("p^{3-o(1)}")#text("). Presumably what happens here is that iterated products of A soon fill up all of ")#mi("SL_2")#text(", because of the lack of low-dimensional representations (i.e. quasirandomness). In any case, sorting all this out would be an excellent data point with which to test various candidates for the conjectured “non-commutative Freiman theorem”, at least for nice classical groups such as ")#mi("SL_n")#text(".")

#text("Dear Isabel: Thanks for the suggestion. At this point it will depend to some extent on how much space everything else is going to take up. The case for making a print version of the career advice pages is a little less compelling to me than for the mathematically oriented pages, since the the latter is likely to continue to evolve slowly over time and is not really in need of a stable (and citeable) version. So I may save it for a future lean year in the blog if there is not enough other material to make a decent book.")

#text("Incidentally, I doubt that I will keep issuing updates to articles from year n in a book for year n+m; this is the kind of thing which is much better done in the online blog format than in the static book format.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25047")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("Dear Terry,")

#text("Gowers worked out (in effect) what happens for very dense sets A: as pointed out by Nikolov and Pyber, the result in his paper on Quasirandom Groups has the very nice consequence that, when |A|>p^{2.5+epsilon} or so, A*A*A is the entire group SL_2(F_p).")

#text("From a talk by Babai, I know that Babai, Nikolov and Pyber now have a beautiful and completely general result. They work out that A*A*A is in fact equal to G for sufficiently large subsets of G, where G is any group that lacks low-dimensional representations. Here “sufficiently large” is tight. Moreover, they give bounds on the number of copies of A that are needed to cover G for softer senses of “sufficiently large”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25058")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("Dear Terry,")#linebreak()#text(" I would also like to hear your opinion on publishing the book under CC license and why do you have this opinion.")

#text("Thanks. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25059")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("Oops sorry, I didn’t notice that you’ve already answered to this question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25125")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2008")])]

#text("Congratulations!!")

#text("“Why global regularity for Navier-Stokes is hard” and “The parity problem in sieve theory” are my favourite ones.")

#text("But why not “Einstein’s derivation of E=mc^2”? I really like this post. ( (a) restriction? =P)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("Dear Roberta,")

#text("I drafted the contents list before the Einstein post (the last post of 2007!). But thanks for reminding me to put it in. I hope to put an updated version of the book here in a few weeks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dda700453af7576061df557b89e623e1ed9a1a7d3816c02d89acd3cb76dac707-40d2a7e0f8ca5d226e4368bedd5e8646e492bf0092a5f5f20e20b4711680a060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Technoliterati « ,Never Neutral,")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-25216")[#strong[#text("Technoliterati « ,Never Neutral,")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2008")])]

#text("[…] Just recently, my friend Pablo left a comment on this blog with a link to mathematician’s Terence Tao’s blog, where he explains the process of making a book out of his blog posts. A professor of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-26012")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("If it is not secret what efficient method are you thinking of to convert the blog-formatted files to tex format?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-26107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Dear t8m8r,")

#text("I am mostly relying on plain old search-and-replace, which takes care of a lot of the conversion, but of course many finer details (particularly in converting links to references) have to be taken care of by hand (and I want to go through the material carefully in any case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-26117")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Thanks a lot. I am just starting a blog and thought it would be nice to have tex-version of some of the posts. At the same time I was a bit lazy to convert by hand. Your answer “in any case I want to go through the material carefully” kind of settles the issue for me too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-26684")[#strong[#text("Using MathTran in blogs and wikis « Jonathan Fine’s weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2008")]

#text("[…] In fact, let’s start with Terry Tao’s blog, which is on WordPress. In case you didn’t know, Terry Tao is an eminent and talented young mathematician who is extremely web-savvy. He decided to move from a static web-site to a blog for his news and discussion articles about a year ago. Original he moved to blogspot, but then soon moved on to WordPress, because it gave better LaTeX support. Last month he told us that he has decided to publish a book version of his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A draft version of the blog book « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-29167")[#strong[#text("A draft version of the blog book « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2008")])]

#text("[…] April, 2008 in book, non-technical, update A few months ago, I announced that I was going to convert a significant fraction of my 2007 blog posts into book format. For […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-48705")[#strong[#text("Writing & Blogging | neverendingbooks")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2010")]

#text("[…] Tao is reworking some of his better blogposts into a book, to be published by the AMS (here’s a preliminary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/#comment-72559")[#strong[#text("On Blogging and ‘Technoliterati’ | Networked Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2011")]

#text("[…] Just recently, my friend Pablo left a comment on this blog with a link to mathematician’s Terence Tao’s blog, where he explains the process of making a book out of his blog posts. A professor of the […]")
]
