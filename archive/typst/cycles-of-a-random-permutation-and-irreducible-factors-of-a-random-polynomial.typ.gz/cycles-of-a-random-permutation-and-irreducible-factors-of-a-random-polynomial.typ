// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/
// Converted to Typst by tao2typ: "2026-10-14T15:19:30.273622+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cycles of a random permutation, and irreducible factors of a random polynomial", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cycles of a random permutation, and irreducible factors of a random polynomial")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/")[#text("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In analytic number theory, there is a well known analogy between the prime factorisation of a large integer, and the ")#link("https://en.wikipedia.org/wiki/Permutation#Cycle_notation")[#text("cycle decomposition")]#text(" of a large permutation; this analogy is central to the topic of “anatomy of the integers”, as discussed for instance in ")#link("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf")[#text("this survey article of Granville")]#text(". Consider for instance the following two parallel lists of facts (stated somewhat informally). Firstly, some facts about the prime factorisation of large integers:")

#list(
[#text("Every positive integer ")#mi("{m}")#text(" has a prime factorisation")

#align(center)[#tao-fit-display[#mitex("m = p_1 p_2 \\dots p_r")]]

#text("into (not necessarily distinct) primes ")#mi("{p_1,\\dots,p_r}")#text(", which is unique up to rearrangement. Taking logarithms, we obtain a partition")

#align(center)[#tao-fit-display[#mitex("\\log m = \\log p_1 + \\log p_2 + \\dots + \\log p_r")]]

#text("of ")#mi("{\\log m}")#text(".")],
[#text("(")#link("https://en.wikipedia.org/wiki/Prime_number_theorem")[#text("Prime number theorem")]#text(") A randomly selected integer ")#mi("{m}")#text(" of size ")#mi("{m \\sim N}")#text(" will be prime with probability ")#mi("{\\approx \\frac{1}{\\log N}}")#text(" when ")#mi("{N}")#text(" is large.")],
[#text("If ")#mi("{m \\sim N}")#text(" is a randomly selected large integer of size ")#mi("{N}")#text(", and ")#mi("{p = p_i}")#text(" is a randomly selected prime factor of ")#mi("{m = p_1 \\dots p_r}")#text(" (with each index ")#mi("{i}")#text(" being chosen with probability ")#mi("{\\frac{\\log p_i}{\\log m}}")#text("), then ")#mi("{\\log p_i}")#text(" is approximately uniformly distributed between ")#mi("{0}")#text(" and ")#mi("{\\log N}")#text(". (See Proposition 9 of ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous blog post")]#text(".)")],
[#text("The set of real numbers ")#mi("{\\{ \\frac{\\log p_i}{\\log m}: i=1,\\dots,r \\}}")#text(" arising from the prime factorisation ")#mi("{m = p_1 \\dots p_r}")#text(" of a large random number ")#mi("{m \\sim N}")#text(" converges (away from the origin, and in a suitable weak sense) to the Poisson-Dirichlet process in the limit ")#mi("{N \\rightarrow \\infty}")#text(". (See ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("the previously mentioned blog post")]#text(" for a definition of the Poisson-Dirichlet process, and a proof of this claim.)")]
)

#text("Now for the facts about the cycle decomposition of large permutations:")

#list(
[#text("Every permutation ")#mi("{\\sigma \\in S_n}")#text(" has a cycle decomposition")

#align(center)[#tao-fit-display[#mitex("\\sigma = C_1 \\dots C_r")]]

#text("into disjoint cycles ")#mi("{C_1,\\dots,C_r}")#text(", which is unique up to rearrangement, and where we count each fixed point of ")#mi("{\\sigma}")#text(" as a cycle of length ")#mi("{1}")#text(". If ")#tao-math("{\\left|C_i\\right|}", block: false)#text(" is the length of the cycle ")#mi("{C_i}")#text(", we obtain a partition")

#align(center)[#tao-fit-display[#tao-math("n = \\left|C_1\\right| + \\dots + \\left|C_r\\right|", block: true)]]

#text("of ")#mi("{n}")#text(".")],
[#text("(Prime number theorem for permutations) A randomly selected permutation of ")#mi("{S_n}")#text(" will be an ")#mi("{n}")#text("-cycle with probability exactly ")#mi("{1/n}")#text(". (This was noted in ")#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")[#text("this previous blog post")]#text(".)")],
[#text("If ")#mi("{\\sigma}")#text(" is a random permutation in ")#mi("{S_n}")#text(", and ")#mi("{C_i}")#text(" is a randomly selected cycle of ")#mi("{\\sigma}")#text(" (with each ")#mi("{i}")#text(" being selected with probability ")#tao-math("{\\left|C_i\\right|/n}", block: false)#text("), then ")#tao-math("{\\left|C_i\\right|}", block: false)#text(" is exactly uniformly distributed on ")#mi("{\\{1,\\dots,n\\}}")#text(". (See Proposition 8 of ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this blog post")]#text(".)")],
[#text("The set of real numbers ")#tao-math("{\\{ \\frac{\\left|C_i\\right|}{n} \\}}", block: false)#text(" arising from the cycle decomposition ")#mi("{\\sigma = C_1 \\dots C_r}")#text(" of a random permutation ")#mi("{\\sigma \\in S_n}")#text(" converges (in a suitable sense) to the Poisson-Dirichlet process in the limit ")#mi("{n \\rightarrow \\infty}")#text(". (Again, see ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous blog post")]#text(" for details.)")]
)

#text("See ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous blog post")]#text(" (or the ")#link("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf")[#text("aforementioned article of Granville")]#text(", or the ")#link("http://www.ams.org/notices/199708/tavare.pdf")[#text("Notices article of Arratia, Barbour, and Tavaré")]#text(") for further exploration of the analogy between prime factorisation of integers and cycle decomposition of permutations.")

#text("There is however something unsatisfying about the analogy, in that it is not clear ")#emph[#text("why")]#text(" there should be such a kinship between integer prime factorisation and permutation cycle decomposition. It turns out that the situation is clarified if one uses another fundamental analogy in number theory, namely the analogy between integers and polynomials ")#mi("{P \\in {\\mathbf F}_q[T]}")#text(" over a finite field ")#mi("{{\\mathbf F}_q}")#text(", discussed for instance in ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("this previous post")]#text("; this is the simplest case of the more general ")#link("https://en.wikipedia.org/wiki/Glossary_of_arithmetic_and_Diophantine_geometry#F")[#text("function field analogy")]#text(" between ")#link("https://en.wikipedia.org/wiki/Algebraic_number_field")[#text("number fields")]#text(" and ")#link("https://en.wikipedia.org/wiki/Algebraic_function_field")[#text("function fields")]#text(". Just as we restrict attention to positive integers when talking about prime factorisation, it will be reasonable to restrict attention to monic polynomials ")#mi("{P}")#text(". We then have another analogous list of facts, proven very similarly to the corresponding list of facts for the integers:")

#list(
[#text("Every monic polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" has a factorisation")

#align(center)[#tao-fit-display[#mitex("f = P_1 \\dots P_r")]]

#text("into irreducible monic polynomials ")#mi("{P_1,\\dots,P_r \\in {\\mathbf F}_q[T]}")#text(", which is unique up to rearrangement. Taking degrees, we obtain a partition")

#align(center)[#tao-fit-display[#mitex("\\text{deg} f = \\text{deg} P_1 + \\dots + \\text{deg} P_r")]]

#text("of ")#mi("{\\text{deg} f}")#text(".")],
[#text("(Prime number theorem for polynomials) A randomly selected monic polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" will be irreducible with probability ")#mi("{\\approx \\frac{1}{n}}")#text(" when ")#mi("{q}")#text(" is fixed and ")#mi("{n}")#text(" is large.")],
[#text("If ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" is a random monic polynomial of degree ")#mi("{n}")#text(", and ")#mi("{P_i}")#text(" is a random irreducible factor of ")#mi("{f = P_1 \\dots P_r}")#text(" (with each ")#mi("{i}")#text(" selected with probability ")#mi("{\\text{deg} P_i / n}")#text("), then ")#mi("{\\text{deg} P_i}")#text(" is approximately uniformly distributed in ")#mi("{\\{1,\\dots,n\\}}")#text(" when ")#mi("{q}")#text(" is fixed and ")#mi("{n}")#text(" is large.")],
[#text("The set of real numbers ")#mi("{\\{ \\text{deg} P_i / n \\}}")#text(" arising from the factorisation ")#mi("{f = P_1 \\dots P_r}")#text(" of a randomly selected polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" converges (in a suitable sense) to the Poisson-Dirichlet process when ")#mi("{q}")#text(" is fixed and ")#mi("{n}")#text(" is large.")]
)

#text("The above list of facts addressed the ")#emph[#text("large ")#mi("{n}")#text(" limit")]#text(" of the polynomial ring ")#mi("{{\\mathbf F}_q[T]}")#text(", where the order ")#mi("{q}")#text(" of the field is held fixed, but the degrees of the polynomials go to infinity. This is the limit that is most closely analogous to the integers ")#mi("{{\\bf Z}}")#text(". However, there is another interesting asymptotic limit of polynomial rings to consider, namely the ")#emph[#text("large ")#mi("{q}")#text(" limit")]#text(" where it is now the ")#emph[#text("degree")]#text(" ")#mi("{n}")#text(" that is held fixed, but the order ")#mi("{q}")#text(" of the field goes to infinity. Actually to simplify the exposition we will use the slightly more restrictive limit where the ")#emph[#text("characteristic")]#text(" ")#mi("{p}")#text(" of the field goes to infinity (again keeping the degree ")#mi("{n}")#text(" fixed), although all of the results proven below for the large ")#mi("{p}")#text(" limit turn out to be true as well in the large ")#mi("{q}")#text(" limit.")

#text("The large ")#mi("{q}")#text(" (or large ")#mi("{p}")#text(") limit is technically a different limit than the large ")#mi("{n}")#text(" limit, but in practice the asymptotic statistics of the two limits often agree quite closely. For instance, here is the prime number theorem in the large ")#mi("{q}")#text(" limit:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Prime number theorem)")]#text(" ")#metadata(none) <tao-a160524700113ddd3205>#text(" The probability that a random monic polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" is irreducible is ")#mi("{\\frac{1}{n}+o(1)}")#text(" in the limit where ")#mi("{n}")#text(" is fixed and the characteristic ")#mi("{p}")#text(" goes to infinity.")
]

#emph[#text("Proof:")]#text(" There are ")#mi("{q^n}")#text(" monic polynomials ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(". If ")#mi("{f}")#text(" is irreducible, then the ")#mi("{n}")#text(" zeroes of ")#mi("{f}")#text(" are distinct and lie in the finite field ")#mi("{{\\mathbf F}_{q^n}}")#text(", but do not lie in any proper subfield of that field. Conversely, every element ")#mi("{\\alpha}")#text(" of ")#mi("{{\\mathbf F}_{q^n}}")#text(" that does not lie in a proper subfield is the root of a unique monic polynomial in ")#mi("{{\\mathbf F}_q[T]}")#text(" of degree ")#mi("{f}")#text(" (the minimal polynomial of ")#mi("{\\alpha}")#text("). Since the union of all the proper subfields of ")#mi("{{\\mathbf F}_{q^n}}")#text(" has size ")#mi("{o(q^n)}")#text(", the total number of irreducible polynomials of degree ")#mi("{n}")#text(" is thus ")#mi("{\\frac{q^n - o(q^n)}{n}}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above argument and inclusion-exclusion in fact gives the well known exact formula ")#mi("{\\frac{1}{n} \\sum_{d|n} \\mu(\\frac{n}{d}) q^d}")#text(" for the number of irreducible monic polynomials of degree ")#mi("{n}")#text(".")
]

#text("Now we can give a precise connection between the cycle distribution of a random permutation, and (the large ")#mi("{p}")#text(" limit of) the irreducible factorisation of a polynomial, giving a (somewhat indirect, but still connected) link between permutation cycle decomposition and integer factorisation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-5c23cfc0b0d82de95b46>#text(" The partition ")#mi("{\\{ \\text{deg}(P_1), \\dots, \\text{deg}(P_r) \\}}")#text(" of a random monic polynomial ")#mi("{f= P_1 \\dots P_r\\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" converges in distribution to the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right|\\}}", block: false)#text(" of a random permutation ")#mi("{\\sigma = C_1 \\dots C_r \\in S_n}")#text(" of length ")#mi("{n}")#text(", in the limit where ")#mi("{n}")#text(" is fixed and the characteristic ")#mi("{p}")#text(" goes to infinity.")
]

#text("We can quickly prove this theorem as follows. We first need a basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Most polynomials square-free in large ")#mi("{q}")#text(" limit)")]#text(" ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>#text(" A random monic polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" will be square-free with probability ")#mi("{1-o(1)}")#text(" when ")#mi("{n}")#text(" is fixed and ")#mi("{q}")#text(" (or ")#mi("{p}")#text(") goes to infinity. In a similar spirit, two randomly selected monic polynomials ")#mi("{f,g}")#text(" of degree ")#mi("{n,m}")#text(" will be coprime with probability ")#mi("{1-o(1)}")#text(" if ")#mi("{n,m}")#text(" are fixed and ")#mi("{q}")#text(" or ")#mi("{p}")#text(" goes to infinity.")
]

#emph[#text("Proof:")]#text(" For any polynomial ")#mi("{g}")#text(" of degree ")#mi("{m}")#text(", the probability that ")#mi("{f}")#text(" is divisible by ")#mi("{g^2}")#text(" is at most ")#mi("{1/q^{2m}}")#text(". Summing over all polynomials of degree ")#mi("{1 \\leq m \\leq n/2}")#text(", and using the union bound, we see that the probability that ")#mi("{f}")#text(" is ")#emph[#text("not")]#text(" squarefree is at most ")#mi("{\\sum_{1 \\leq m \\leq n/2} \\frac{q^m}{q^{2m}} = o(1)}")#text(", giving the first claim. For the second, observe from the first claim (and the fact that ")#mi("{fg}")#text(" has only a bounded number of factors) that ")#mi("{fg}")#text(" is squarefree with probability ")#mi("{1-o(1)}")#text(", giving the claim. ")#mi("\\Box")

#text("Now we can prove the theorem. Elementary combinatorics tells us that the probability of a random permutation ")#mi("{\\sigma \\in S_n}")#text(" consisting of ")#mi("{c_k}")#text(" cycles of length ")#mi("{k}")#text(" for ")#mi("{k=1,\\dots,r}")#text(", where ")#mi("{c_k}")#text(" are nonnegative integers with ")#mi("{\\sum_{k=1}^r k c_k = n}")#text(", is precisely")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\prod_{k=1}^r c_k! k^{c_k}},")]]

#text("since there are ")#mi("{\\prod_{k=1}^r c_k! k^{c_k}}")#text(" ways to write a given tuple of cycles ")#mi("{C_1,\\dots,C_r}")#text(" in cycle notation in nondecreasing order of length, and ")#mi("{n!}")#text(" ways to select the labels for the cycle notation. On the other hand, by Theorem ")#link(<tao-a160524700113ddd3205>)[#text("1")]#text(" (and using Lemma ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("4")]#text(" to isolate the small number of cases involving repeated factors) the number of monic polynomials of degree ")#mi("{n}")#text(" that are the product of ")#mi("{c_k}")#text(" irreducible polynomials of degree ")#mi("{k}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\prod_{k=1}^r c_k!} \\prod_{k=1}^r ( (\\frac{1}{k}+o(1)) q^k )^{c_k} + o( q^n )")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{1+o(1)}{\\prod_{k=1}^r c_k! k^{c_k}} q^n,")]]

#text("and the claim follows.")

#text("This was a fairly short calculation, but it still doesn’t quite explain ")#emph[#text("why")]#text(" there is such a link between the cycle decomposition ")#mi("{\\sigma = C_1 \\dots C_r}")#text(" of permutations and the factorisation ")#mi("{f = P_1 \\dots P_r}")#text(" of a polynomial. One immediate thought might be to try to link the multiplication structure of permutations in ")#mi("{S_n}")#text(" with the multiplication structure of polynomials; however, these structures are too dissimilar to set up a convincing analogy. For instance, the multiplication law on polynomials is abelian and non-invertible, whilst the multiplication law on ")#mi("{S_n}")#text(" is (extremely) non-abelian but invertible. Also, the multiplication of a degree ")#mi("{n}")#text(" and a degree ")#mi("{m}")#text(" polynomial is a degree ")#mi("{n+m}")#text(" polynomial, whereas the group multiplication law on permutations does not take a permutation in ")#mi("{S_n}")#text(" and a permutation in ")#mi("{S_m}")#text(" and return a permutation in ")#mi("{S_{n+m}}")#text(".")

#text("I recently found (after some discussions with Ben Green) what I feel to be a satisfying conceptual (as opposed to computational) explanation of this link, which I will place below the fold.")

#metadata(none) <tao-c6db53a8ac6c8d5835cd>

#text("To put cycle decomposition of permutations and factorisation of polynomials on an equal footing, we generalise the notion of a permutation ")#mi("{\\sigma \\in S_n}")#text(" to the notion of a ")#emph[#text("partial permutation")]#text(" ")#mi("{\\sigma = (\\sigma,S)}")#text(" on a fixed (but possibly infinite) domain ")#mi("{X}")#text(", which consists of a finite non-empty subset ")#mi("{S}")#text(" of the set ")#mi("{X}")#text(", together with a bijection ")#mi("{\\sigma: S \\rightarrow S}")#text(" on ")#mi("{S}")#text("; I’ll call ")#mi("{S}")#text(" the ")#emph[#text("support")]#text(" of the partial permutation. We say that a partial permutation ")#mi("{\\sigma}")#text(" is of ")#emph[#text("size")]#text(" ")#mi("{n}")#text(" if the support ")#mi("{S}")#text(" is of cardinality ")#mi("{n}")#text(", and denote this size as ")#tao-math("{\\left|\\sigma\\right|}", block: false)#text(". And now we can introduce a multiplication law on partial permutations that is much closer to that of polynomials: if two partial permutations ")#mi("{\\sigma, \\sigma^{\\prime}}")#text(" on the same domain ")#mi("{X}")#text(" have disjoint supports ")#mi("{S, S^{\\prime}}")#text(", then we can form their disjoint union ")#mi("{\\sigma \\uplus \\sigma^{\\prime}}")#text(", supported on ")#mi("{S \\cup S^{\\prime}}")#text(", to be the bijection on ")#mi("{S \\cup S^{\\prime}}")#text(" that agrees with ")#mi("{\\sigma}")#text(" on ")#mi("{S}")#text(" and with ")#mi("{\\sigma^{\\prime}}")#text(" on ")#mi("{S^{\\prime}}")#text(". Note that this is a commutative and associative operation (where it is defined), and is the disjoint union of a partial permutation of size ")#mi("{n}")#text(" and a partial permutation of size ")#mi("{m}")#text(" is a partial permutation of size ")#mi("{n+m}")#text(", so this operation is much closer in behaviour to the multiplication law on polynomials than the group law on ")#mi("{S_n}")#text(". There is the defect that the disjoint union operation is sometimes undefined (when the two partial permutations have overlapping support); but in the asymptotic regime where the size ")#mi("{n}")#text(" is fixed and the set ")#mi("{X}")#text(" is extremely large, this will be very rare (compare with Lemma ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("4")]#text(").")

#text("Note that a partial permutation is irreducible with respect to disjoint union if and only if it is a cycle on its support, and every partial permutation ")#mi("{\\sigma}")#text(" has a decomposition ")#mi("{\\sigma = C_1 \\uplus \\dots \\uplus C_r}")#text(" into such partial cycles, unique up to permutations. If one then selects some set ")#mi("{{\\mathcal P}}")#text(" of partial cycles on the domain ")#mi("{X}")#text(" to serve as “generalised primes”, then one can define (in the spirit of ")#link("https://en.wikipedia.org/wiki/Beurling_zeta_function")[#text("Beurling integers")]#text(") the set ")#mi("{{\\mathcal N}}")#text(" of “generalised integers”, defined as those partial permutations that are the disjoint union ")#mi("{\\sigma = C_1 \\uplus \\dots \\uplus C_r}")#text(" of partial cycles in ")#mi("{{\\mathcal P}}")#text(". If one lets ")#mi("{{\\mathcal N}_n}")#text(" denote the set of generalised integers of size ")#mi("{n}")#text(", one can (assuming that this set is non-empty and finite) select a partial permutation ")#mi("{\\sigma}")#text(" uniformly at random from ")#mi("{{\\mathcal N}_n}")#text(", and consider the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right| \\}}", block: false)#text(" of ")#mi("{n}")#text(" arising from the decomposition into generalised primes.")

#text("We can now embed both the cycle decomposition for (complete) permutations and the factorisation of polynomials into this common framework. We begin with the cycle decomposition for permutations. Let ")#mi("{q}")#text(" be a large natural number, and set the domain ")#mi("{X}")#text(" to be the set ")#mi("{\\{1,\\dots,q\\}}")#text(". We define ")#mi("{{\\mathcal P}_n}")#text(" to be the set of ")#emph[#text("all")]#text(" partial cycles on ")#mi("{X}")#text(" of size ")#mi("{n}")#text(", and let ")#mi("{{\\mathcal P}}")#text(" be the union of the ")#mi("{{\\mathcal P}_n}")#text(", that is to say the set of ")#emph[#text("all")]#text(" partial cycles on ")#mi("{X}")#text(" (of arbitrary size). Then ")#mi("{{\\mathcal N}}")#text(" is of course the set of all partial permutations on ")#mi("{X}")#text(", and ")#mi("{{\\mathcal N}_n}")#text(" is the set of all partial permutations on ")#mi("{X}")#text(" of size ")#mi("{n}")#text(". To generate an element of ")#mi("{{\\mathcal N}_n}")#text(" uniformly at random for ")#mi("{1 \\leq n \\leq q}")#text(", one simply has to randomly select an ")#mi("{n}")#text("-element subset ")#mi("{S}")#text(" of ")#mi("{X}")#text(", and then form a random permutation of the ")#mi("{n}")#text(" elements of ")#mi("{S}")#text(". From this, it is obvious that the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right|\\}}", block: false)#text(" of ")#mi("{n}")#text(" coming from a randomly chosen element of ")#mi("{{\\mathcal N}_n}")#text(" has exactly the same distribution as the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right|\\}}", block: false)#text(" of ")#mi("{n}")#text(" coming from a randomly chosen element of ")#mi("{S_n}")#text(", as long as ")#mi("{q}")#text(" is at least as large as ")#mi("{n}")#text(" of course.")

#text("Now we embed the factorisation of polynomials into the same framework. The domain ")#mi("{X}")#text(" is now taken to be the algebraic closure ")#mi("{\\overline{{\\mathbf F}_q}}")#text(" of ")#mi("{{\\mathbf F}_q}")#text(", or equivalently the direct limit of the finite fields ")#mi("{{\\mathbf F}_{q^n}}")#text(" (with the obvious inclusion maps). This domain has a fundamental bijection on it, the ")#link("https://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius map")]#text(" ")#mi("{\\text{Frob}: x \\mapsto x^q}")#text(", which is a field automorphism that has ")#mi("{{\\mathbf F}_q}")#text(" as its fixed points. We define ")#mi("{{\\mathcal N}}")#text(" to be the set of partial permutations on ")#mi("{X}")#text(" formed by restricting the Frobenius map ")#mi("{\\text{Frob}}")#text(" to a finite Frobenius-invariant set. It is easy to see that the irreducible Frobenius-invariant sets (that is to say, the orbits of ")#mi("{\\text{Frob}}")#text(") arise from taking an element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" together with all of its Galois conjugates, and so if we define ")#mi("{{\\mathcal P}}")#text(" to be the set of restrictions of Frobenius to a single such Galois orbit, then ")#mi("{{\\mathcal N}}")#text(" are the generalised integers to the generalised primes ")#mi("{{\\mathcal P}}")#text(" in the sense above. Next, observe that, when the characteristic ")#mi("{p}")#text(" is sufficiently large, every squarefree monic polynomial ")#mi("{f \\in {\\mathbf F}_q[T]}")#text(" of degree ")#mi("{n}")#text(" generates a generalised integer of size ")#mi("{n}")#text(", namely the restriction of the Frobenius map to the ")#mi("{n}")#text(" roots of ")#mi("{f}")#text(" (which will be necessarily distinct when the characteristic is large and ")#mi("{f}")#text(" is squarefree). This generalised integer will be a generalised prime precisely when ")#mi("{f}")#text(" is irreducible. Conversely, every generalised integer of size ")#mi("{n}")#text(" generates a squarefree monic polynomial in ")#mi("{{\\mathbf F}_q[T]}")#text(", namely the product of ")#mi("{T-x}")#text(" as ")#mi("{x}")#text(" ranges over the support of the integer. This product is clearly monic, squarefree, and Frobenius-invariant, thus it lies in ")#mi("{{\\mathbf F}_q[T]}")#text(". Thus we may identify ")#mi("{{\\mathcal N}_n}")#text(" with the monic squarefree polynomials of ")#mi("{{\\mathbf F}_q}")#text(" of degree ")#mi("{n}")#text(". With this identification, the (now partially defined) multiplication operation on monic squarefree polynomials coincides exactly with the disjoint union operation on partial permutations. As such, we see that the partition ")#mi("{\\{ \\text{deg} P_1, \\dots, \\text{deg} P_r \\}}")#text(" associated to a randomly chosen squarefree monic polynomial ")#mi("{f = P_1\\dots P_r}")#text(" of degree ")#mi("{n}")#text(" has exactly the same distribution as the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right| \\}}", block: false)#text(" associated to a randomly chosen generalised integer ")#mi("{\\sigma = C_1 \\uplus \\dots \\uplus C_r}")#text(" of size ")#mi("{n}")#text(". By Lemma ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("4")]#text(", one can drop the condition of being squarefree while only distorting the distribution by ")#mi("{o(1)}")#text(".")

#text("Now that we have placed cycle decomposition of permutations and factorisation of polynomials into the same framework, we can explain Theorem ")#link(<tao-5c23cfc0b0d82de95b46>)[#text("3")]#text(" as a consequence of the following ")#emph[#text("universality")]#text(" result for generalised prime factorisations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Universality)")]#text(" ")#metadata(none) <tao-8d9315fc224d877fa15d>#text(" Let ")#mi("{{\\mathcal P}, {\\mathcal N}}")#text(" be collections of generalised primes and integers respectively on a domain ")#mi("{X}")#text(", all of which depend on some asymptotic parameter ")#mi("{q}")#text(" that goes to infinity. Suppose that for any fixed ")#mi("{n,m}")#text(" and ")#mi("{q}")#text(" going to infinity, the sets ")#mi("{{\\mathcal N}_n, {\\mathcal N}_m, {\\mathcal N}_{n+m}}")#text(" are non-empty with cardinalities obeying the asymptotic ")#metadata(none) <tao-2ca7289b5248632c8fe5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|{\\mathcal N}_{n+m}\\right| = (1+o(1)) \\left|{\\mathcal N}_n\\right| \\left|{\\mathcal N}_m\\right|.", block: true)]]

#text("Also, suppose that only ")#tao-math("{o( \\left|{\\mathcal N}_n\\right| \\left|{\\mathcal N}_m\\right|)}", block: false)#text(" of the pairs ")#mi("{(\\sigma,\\sigma^{\\prime}) \\in {\\mathcal N}_n \\times {\\mathcal N}_m}")#text(" have overlapping supports (informally, this means that ")#mi("{\\sigma \\uplus \\sigma^{\\prime}}")#text(" is defined with probability ")#mi("{1-o(1)}")#text("). Then, for fixed ")#mi("{n}")#text(" and ")#mi("{q}")#text(" going to infinity, the distribution of the partition ")#tao-math("{\\{ \\left|C_1\\right|, \\dots, \\left|C_r\\right|\\}}", block: false)#text(" of a random generalised integer from ")#mi("{{\\mathcal N}_n}")#text(" is universal in the limit; that is to say, the limiting distribution does not depend on the precise choice of ")#mi("{X, {\\mathcal P}, {\\mathcal N}}")#text(".")
]

#text("Note that when ")#mi("{{\\mathcal N}_n}")#text(" consists of all the partial permutations of size ")#mi("{n}")#text(" on ")#mi("{\\{1,\\dots,q\\}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal N}_n\\right| = \\binom{q}{n} n! = (1+o(1)) q^n", block: true)]]

#text("while when ")#mi("{{\\mathcal N}_n}")#text(" consists of the monic squarefree polynomials of degree ")#mi("{n}")#text(" in ")#mi("{{\\mathbf F}_q[T]}")#text(" then from Lemma ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("4")]#text(" we also have")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal N}_n\\right| = (1+o(1)) q^n", block: true)]]

#text("so in both cases the first hypothesis ")#link(<tao-2ca7289b5248632c8fe5>)[#text("(1)")]#text(" is satisfied. The second hypothesis is easy to verify in the former case and follows from Lemma ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("4")]#text(" in the latter case. Thus, Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(" gives Theorem ")#link(<tao-5c23cfc0b0d82de95b46>)[#text("3")]#text(" as a corollary.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" An alternate way to interpret Theorem ")#link(<tao-5c23cfc0b0d82de95b46>)[#text("3")]#text(" is as an equidistribution theorem: if one randomly labels the ")#mi("{n}")#text(" zeroes of a random degree ")#mi("{n}")#text(" polynomial as ")#mi("{1,\\dots,n}")#text(", then the resulting permutation on ")#mi("{1,\\dots,n}")#text(" induced by the Frobenius map is asymptotically equidistributed in the large ")#mi("{q}")#text(" (or large ")#mi("{p}")#text(") limit. This is the simplest case of a much more general (and deeper) result known as the Deligne equidistribution theorem, discussed for instance in ")#link("https://people.math.ethz.ch/~kowalski/exponential-sums-rism.pdf")[#text("this survey of Kowalski")]#text(". See also ")#link("http://arxiv.org/abs/1309.6038")[#text("this paper of Church, Ellenberg, and Farb")]#text(" concerning more precise asymptotics for the number of squarefree polynomials with a given cycle decomposition of Frobenius.")
]

#text("It remains to prove Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(". The key is to establish an abstract form of the prime number theorem in this setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Prime number theorem)")]#text(" ")#metadata(none) <tao-5b16cb2218be5516b8a0>#text(" Let the hypotheses be as in Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(". Then for fixed ")#mi("{n}")#text(" and ")#mi("{q \\rightarrow \\infty}")#text(", the density of ")#mi("{{\\mathcal P}_n}")#text(" in ")#mi("{{\\mathcal N}_n}")#text(" is ")#mi("{\\frac{1}{n}+o(1)}")#text(". In particular, the asymptotic density ")#mi("{1/n}")#text(" is universal (it does not depend on the choice of ")#mi("{X, {\\mathcal P}_n, {\\mathcal N}_n}")#text(").")
]

#emph[#text("Proof:")]#text(" Let ")#tao-math("{a_n := n \\left|{\\mathcal P}_n\\right| / \\left|{\\mathcal N}_n\\right|}", block: false)#text(" (this may only be defined for ")#mi("{q}")#text(" sufficiently large depending on ")#mi("{n}")#text("); our task is to show that ")#mi("{a_n = 1+o(1)}")#text(" for each fixed ")#mi("{n}")#text(".")

#text("Consider the set of pairs ")#mi("{(\\sigma, x)}")#text(" where ")#mi("{\\sigma}")#text(" is an element of ")#mi("{{\\mathcal N}_n}")#text(" and ")#mi("{x}")#text(" is an element of the support of ")#mi("{\\sigma}")#text(". Clearly, the number of such pairs is ")#tao-math("{n \\left|{\\mathcal N}_n\\right|}", block: false)#text(". On the other hand, given such a pair ")#mi("{(\\sigma,x)}")#text(", there is a unique factorisation ")#mi("{\\sigma = C \\uplus \\sigma^{\\prime}}")#text(", where ")#mi("{C}")#text(" is the generalised prime in the decomposition of ")#mi("{\\sigma}")#text(" that contains ")#mi("{x}")#text(" in its support, and ")#mi("{\\sigma^{\\prime}}")#text(" is formed from the remaining components of ")#mi("{\\sigma}")#text(". ")#mi("{C}")#text(" has some size ")#mi("{1 \\leq m \\leq n}")#text(", ")#mi("{\\sigma^{\\prime}}")#text(" has the complementary size ")#mi("{n-m}")#text(" and has disjoint support from ")#mi("{C}")#text(", and ")#mi("{x}")#text(" has to be one of the ")#mi("{m}")#text(" elements of the support of ")#mi("{C}")#text(". Conversely, if one selects ")#mi("{1 \\leq m \\leq n}")#text(", then selects a generalised prime ")#mi("{C \\in {\\mathcal P}_m}")#text(", and a generalised integer ")#mi("{\\sigma^{\\prime} \\in {\\mathcal C}_{n-m}}")#text(" with disjoint support from ")#mi("{C}")#text(", and an element ")#mi("{x}")#text(" in the support of ")#mi("{C}")#text(", we recover the pair ")#mi("{(\\sigma,x)}")#text(". Using the hypotheses of Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(", we thus obtain the double counting identity")

#tao-aligned(keep: true)[


#tao-math("n \\left|{\\mathcal N}_n\\right|  & = \\sum_{m=1}^n m \\left|{\\mathcal P}_m\\right| \\left|{\\mathcal N}_{n-m}\\right| - o( \\left|{\\mathcal N}_m\\right| \\left|{\\mathcal N}_{n-m}\\right| )", block: true)



#tao-math(" & = (\\sum_{m=1}^n a_m + o(1)) \\left|{\\mathcal N}_n\\right|", block: true)
]

#text("and thus ")#mi("{\\sum_{m=1}^n a_m = n+o(1)}")#text(" for every fixed ")#mi("{n}")#text(", and so ")#mi("{a_n = 1+o(1)}")#text(" for fixed ")#mi("{n}")#text(" as claimed. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" One could cast this argument in a language more reminiscent of analytic number theory by forming generating series of ")#mi("{{\\mathcal N}_n}")#text(" and ")#mi("{{\\mathcal P}_n}")#text(" and treating these series as analogous to a zeta function and its log-derivative (in close analogy to what is done with Beurling primes), but we will not do so here.")
]

#text("We can now finish the proof of Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(". To show asymptotic universality of the partition ")#tao-math("{\\{ \\left|C_1\\right|,\\dots,\\left|C_r\\right|\\}}", block: false)#text(" of a random generalised integer ")#mi("{\\sigma \\in {\\mathcal N}_n}")#text(", we may assume inductively that asymptotic universality has already been shown for all smaller choices of ")#mi("{n}")#text(". To generate a uniformly random generalised integer ")#mi("{\\sigma}")#text(" of size ")#mi("{n}")#text(", we can repeat the process used to prove Theorem ")#link(<tao-5b16cb2218be5516b8a0>)[#text("7")]#text(". It of course suffices to generate a uniformly random pair ")#mi("{(\\sigma,x)}")#text(", where ")#mi("{\\sigma}")#text(" is a generalised integer of size ")#mi("{n}")#text(" and ")#mi("{x}")#text(" is an element of the support of ")#mi("{\\sigma}")#text(", since on dropping ")#mi("{x}")#text(" we would obtain a uniformly drawn ")#mi("{\\sigma}")#text(".")

#text("To obtain the pair ")#mi("{(\\sigma,x)}")#text(", we first select ")#mi("{m \\in \\{1,\\dots,n\\}}")#text(" uniformly at random, then select a generalised prime ")#mi("{C}")#text(" randomly from ")#mi("{{\\mathcal P}_m}")#text(" and a generalised integer ")#mi("{\\sigma^{\\prime}}")#text(" randomly from ")#mi("{{\\mathcal C}_{n-m}}")#text(" (independently of ")#mi("{C}")#text(" once ")#mi("{m}")#text(" is fixed). Finally, we select ")#mi("{x}")#text(" uniformly at random from the support of ")#mi("{C}")#text(", and set ")#mi("{\\sigma := C \\uplus \\sigma^{\\prime}}")#text(". The pair ")#mi("{(\\sigma,x)}")#text(" is certainly a pair of the required form, but this random variable is not quite uniformly distributed amongst all such pairs. However, by repeating the calculations in Theorem ")#link(<tao-8d9315fc224d877fa15d>)[#text("5")]#text(" (and in particular relying on the conclusion ")#mi("{a_m=1+o(1)}")#text("), we see that this distribution is is within ")#mi("{o(1)}")#text(" of the uniform distribution in total variation norm. Thus, the distribution of the cycle partition ")#tao-math("{\\{ \\left|C_1\\right|,\\dots,\\left|C_r\\right|\\}}", block: false)#text(" of a uniformly chosen ")#mi("{\\sigma}")#text(" lies within ")#mi("{o(1)}")#text(" in total variation of the distribution of the cycle partition of a ")#mi("{\\sigma = C \\uplus \\sigma^{\\prime}}")#text(" chosen by the above recipe. However, the cycle partition of ")#mi("{\\sigma = C \\uplus \\sigma^{\\prime}}")#text(" is simply the union (with multiplicity) of ")#mi("{\\{m\\}}")#text(" with the cycle partition of ")#mi("{\\sigma^{\\prime}}")#text(". As the latter was already assumed to be asymptotically universal, we conclude that the former is also, as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The above analysis helps explain why one could not easily link permutation cycle decomposition with integer factorisation – to produce permutations here with the right asymptotics we needed both the large ")#mi("{q}")#text(" limit and the Frobenius map, both of which are available in the function field setting but not in the number field setting.")
]

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457352")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2015")])]

#text("It might be worth pointing out that Deligne’s equidistribution theorem provides another conceptual explanation for why there is a connection between random polynomials and random permutations, which generalizes to cases where the polynomials are constructed by some random process involving the additive structure, like a fixed polynomial plus a random low degree polynomial.")

#text("Well, at least some people think it’s conceptual.")

#emph[#text("[Good point; I added a remark to this effect. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457356")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("I imagine your generalized primes do not include the primes numbers themselves ")#mi("\\mathbb{P} \\subset \\mathbb{Z}")#text(" or your proof of the Prime Number Theorem would not be so short. Are there any objects which interpolate between ")#mi("\\mathbb{Z}")#text(" and ")#mi("\\mathbb{F}_q[T]")#text(" ? Perhaps even ")#mi("\\lim_{q \\to \\infty} \\mathbb{F}_q[T] = \\mathbb{Z}")#text(" which seems ridiculous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457360")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("Unfortunately there is no rigorous direct connection currently known between function fields and number fields, which is a pity for many reasons (for instance, the Riemann hypothesis is known for the former but not the latter). Nevertheless the analogies between the two are remarkably strong. I believe part of the motivation of trying to construct a theory of “")#link("https://en.wikipedia.org/wiki/Field_with_one_element")[#text("the field of one element")]#text("” is to try to create such a connection, but this program has not yet succeeded in this task.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("The partition ")#mi("\\log m = \\sum_p m_p \\log p")#linebreak()#text(" where ")#mi("m_p")#text(" is the multiplicity for each prime ")#mi("p")#text(" in ")#mi("m")#text(", is represented (at least formally) by the generating function")

#mi("\\sum_m x^{\\log m} = \\prod_p (1-x^{\\log p})^{-1}")

#text("Which is equivalent to the fundamental theorem of arithmetic.")

#text("It is interesting to observe that the substitution ")#mi("x=e^{-s}")#text(" in this partition generating function, gives Euler’s product representation for ")#mi("\\zeta(s)")#text(". Is similar connection exists between partition generating functions for permutations and polynomials and corresponding zeta functions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fd0b8989a1d119d35b383f55c3381965d10d8db9ff53c7a735b27433fef99c6-1330a8631aded25f950ccd0f7fe9f5786882696cc2f012389e35718af48f01fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arul")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457359")[#strong[#text("Arul")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("Nice formula, thank’s for sharing")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17091d4a03d31ec4dcf328fd4d4d32db71be5b910e8d970cb06458f485a78ee0-f9203420c8451af72d62b1b2b4d5e95ce44a69b089d67063cdb25ebaac827640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Amiot")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457459")[#strong[#text("Emmanuel Amiot")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2015")])]

#text("I have trouble with the assertion “A randomly selected permutation of {S_n} will be a cycle with probability exactly {1/n}”: in {S_3} I see 5 cycles, barring id; in {S_4} there are 20. Is it a misprint from the average number of {k-}cycles in the decomposition of a random permutation, which is indeed proved to be {1/k} in the cited previous post?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2f2c047e40a8a8367ac7cff0f3c634b6206c5e1acc6a4975139a25d43ff924b-57b771594e8153ef907b1fdbc612d7f596ed745e9effbe18f313315d3221e898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coderodde")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457506")[#strong[#text("coderodde")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("Hello, Terry. Did you consider using … in your text? This will align your text in a funky way, and thus, add more awesomeness to already awesome text of yours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2f2c047e40a8a8367ac7cff0f3c634b6206c5e1acc6a4975139a25d43ff924b-57b771594e8153ef907b1fdbc612d7f596ed745e9effbe18f313315d3221e898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coderodde")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-457507")[#strong[#text("coderodde")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("WP did not allow me to post HTML. I was suggesting using “justify” for “align”-attribute in the “p” HTML element.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-458313")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2015")])]

#text("“to produce permutations here with the right asymptotics we needed both the large {q} limit and the Frobenius map, both of which are available in the function field setting but not in the number field setting.” I’ll bet most of what you say here works without the large q limit, though. Your Theorem 5 is fine, and your Theorem 3 just has to be modified: the distribution on irreducible factor degrees of a random polynomial over F_q (with n -> oo) is in a sense a “deformation” of the independent Poissons you get from permutations. (Maybe what I literally mean is that everything is a power series in q^{-1} with those Poissons as leading term.) Of course I am biased by my habit of thinking of these things cohomologically, in which setting the statistics of polynomials are governed by an H^0 (whose contribution agrees exactly with statistics of random permutations) and then a sum over higher H^i; the latter become negligible as q gets big, which gives Theorem 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e88c7926d9acf39035fcdb3d33ef5c2940f4a00bc7284f30302b5111f1ddb3a4-80cf16a30f288c39529de39aae4b9548b11a77e99b69844b2aea4cfb77fd4807.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of onlyearthleft.")]], [#link("https://terrytao.wordpress.com/2015/07/15/cycles-of-a-random-permutation-and-irreducible-factors-of-a-random-polynomial/#comment-474590")[#strong[#text("onlyearthleft.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("sorry you addressed q->infinity and n->infinity but the case of q/n=c a real constant might turn out to be the closest towards any connection to integers. Would there be any nontrivial analogies here?")
]
