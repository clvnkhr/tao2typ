// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:34.568159+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Fourier-free proof of the Furstenberg-Sarkozy theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Fourier-free proof of the Furstenberg-Sarkozy theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/")[#text("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The following result is due independently ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("to Furstenberg")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=466059")[#text("to Sarkozy")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Furstenberg-Sarkozy theorem)")]#text(" ")#metadata(none) <tao-dce7cce055566bed799f>#text(" Let ")#mi("{\\delta > 0}")#text(", and suppose that ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(". Then every subset ")#mi("{A}")#text(" of ")#mi("{[N] := \\{1,\\ldots,N\\}}")#text(" of density ")#tao-math("{\\left|A\\right|/N}", block: false)#text(" at least ")#mi("{\\delta}")#text(" contains a pair ")#mi("{n, n+r^2}")#text(" for some natural numbers ")#mi("{n, r}")#text(" with ")#mi("{r \\neq 0}")#text(".")
]

#text("This theorem is of course similar in spirit to results such as ")#link("http://en.wikipedia.org/wiki/Roth%27s_theorem")[#text("Roth’s theorem")]#text(" or ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", in which the pattern ")#mi("{n,n+r^2}")#text(" is replaced by ")#mi("{n,n+r,n+2r}")#text(" or ")#mi("{n,n+r,\\ldots,n+(k-1)r}")#text(" for some fixed ")#mi("{k}")#text(" respectively. There are by now many proofs of this theorem (see ")#link("http://arxiv.org/abs/1107.0243")[#text("this recent paper of Lyall")]#text(" for a survey), but most proofs involve some form of Fourier analysis (or spectral theory). This may be compared with the standard proof of Roth’s theorem, which combines some Fourier analysis with what is now known as the density increment argument.")

#text("A few years ago, Ben Green, Tamar Ziegler, and myself observed that it is possible to prove the Furstenberg-Sarkozy theorem by just using the Cauchy-Schwarz inequality (or van der Corput lemma) and the density increment argument, removing all invocations of Fourier analysis, and instead relying on Cauchy-Schwarz to linearise the quadratic shift ")#mi("{r^2}")#text(". As such, this theorem can be considered as even more elementary than Roth’s theorem (and its proof can be viewed as a toy model for the proof of Roth’s theorem). We ended up not doing too much with this observation, so decided to share it here.")

#text("The first step is to use the density increment argument that goes back to Roth. For any ")#mi("{\\delta > 0}")#text(", let ")#mi("{P(\\delta)}")#text(" denote the assertion that for ")#mi("{N}")#text(" sufficiently large, all sets ")#mi("{A \\subset [N]}")#text(" of density at least ")#mi("{\\delta}")#text(" contain a pair ")#mi("{n,n+r^2}")#text(" with ")#mi("{r}")#text(" non-zero. Note that ")#mi("{P(\\delta)}")#text(" is vacuously true for ")#mi("{\\delta > 1}")#text(". We will show that for any ")#mi("{0 < \\delta_0 \\leq 1}")#text(", one has the implication ")#metadata(none) <tao-abecdf3503635c0be9ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(\\delta_0 + c \\delta_0^3) \\implies P(\\delta_0)")]]

#text("for some absolute constant ")#mi("{c>0}")#text(". This implies that ")#mi("{P(\\delta)}")#text(" is true for any ")#mi("{\\delta>0}")#text(" (as can be seen by considering the infimum of all ")#mi("{\\delta>0}")#text(" for which ")#mi("{P(\\delta)}")#text(" holds), which gives Theorem ")#link(<tao-dce7cce055566bed799f>)[#text("1")]#text(".")

#text("It remains to establish the implication ")#link(<tao-abecdf3503635c0be9ec>)[#text("(1)")]#text(". Suppose for sake of contradiction that we can find ")#mi("{0 < \\delta_0 \\leq 1}")#text(" for which ")#mi("{P(\\delta_0+c\\delta^3_0)}")#text(" holds (for some sufficiently small absolute constant ")#mi("{c>0}")#text("), but ")#mi("{P(\\delta_0)}")#text(" fails. Thus, we can find arbitrarily large ")#mi("{N}")#text(", and subsets ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" of density at least ")#mi("{\\delta_0}")#text(", such that ")#mi("{A}")#text(" contains no patterns of the form ")#mi("{n,n+r^2}")#text(" with ")#mi("{r}")#text(" non-zero. In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h \\in [N^{1/100}]} 1_A(n) 1_A(n+(r+h)^2) = 0.")]]

#text("(The exact ranges of ")#mi("{r}")#text(" and ")#mi("{h}")#text(" are not too important here, and could be replaced by various other small powers of ")#mi("{N}")#text(" if desired.)")

#text("Let ")#tao-math("{\\delta := \\left|A\\right|/N}", block: false)#text(" be the density of ")#mi("{A}")#text(", so that ")#mi("{\\delta_0 \\leq \\delta \\leq 1}")#text(". Observe that")

#tao-aligned(keep: true)[


#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h \\in [N^{1/100}]} 1_A(n) \\delta 1_{[N]}(n+(r+h)^2)  & = \\delta^2 + O(N^{-1/3})", block: true)



#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h \\in [N^{1/100}]} \\delta 1_{[N]}(n) \\delta 1_{[N]}(n+(r+h)^2)  & = \\delta^2 + O(N^{-1/3})", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h \\in [N^{1/100}]} \\delta 1_{[N]}(n) 1_A(n+(r+h)^2) = \\delta^2 + O( N^{-1/3} ).")]]

#text("If we thus set ")#mi("{f := 1_A - \\delta 1_{[N]}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h \\in [N^{1/100}]} f(n) f(n+(r+h)^2) = -\\delta^2 + O( N^{-1/3} ).")]]

#text("In particular, for ")#mi("{N}")#text(" large enough,")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} |f(n)| \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\left|\\mathop{\\bf E}_{h \\in [N^{1/100}]} f(n+(r+h)^2)\\right| \\gg \\delta^2.", block: true)]]

#text("On the other hand, one easily sees that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|f(n)\\right|^2 = O(\\delta)", block: true)]]

#text("and hence by the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} \\left|\\mathop{\\bf E}_{h \\in [N^{1/100}]} f(n+(r+h)^2)\\right|^2 \\gg \\delta^3", block: true)]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h,h^{\\prime} \\in [N^{1/100}]} \\mathop{\\bf E}_{n \\in [N]} f(n+(r+h)^2) f(n+(r+h^{\\prime})^2)\\right| \\gg \\delta^3.", block: true)]]

#text("Shifting ")#mi("{n}")#text(" by ")#mi("{(r+h)^2}")#text(" we obtain (again for ")#mi("{N}")#text(" large enough)")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{h,h^{\\prime} \\in [N^{1/100}]} \\mathop{\\bf E}_{n \\in [N]} f(n) f(n+(h^{\\prime}-h)(2r+h^{\\prime}+h))\\right| \\gg \\delta^3.", block: true)]]

#text("In particular, by the pigeonhole principle (and deleting the diagonal case ")#mi("{h=h^{\\prime}}")#text(", which we can do for ")#mi("{N}")#text(" large enough) we can find distinct ")#mi("{h,h^{\\prime} \\in [N^{1/100}]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{r \\in [N^{1/3}]} \\mathop{\\bf E}_{n \\in [N]} f(n) f(n+(h^{\\prime}-h)(2r+h^{\\prime}+h))\\right| \\gg \\delta^3,", block: true)]]

#text("so in particular")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|\\mathop{\\bf E}_{r \\in [N^{1/3}]} f(n+(h^{\\prime}-h)(2r+h^{\\prime}+h))\\right| \\gg \\delta^3.", block: true)]]

#text("If we set ")#mi("{d := 2(h^{\\prime}-h)}")#text(" and shift ")#mi("{n}")#text(" by ")#mi("{(h^{\\prime}-h) (h^{\\prime}+h)}")#text(", we can simplify this (again for ")#mi("{N}")#text(" large enough) as ")#metadata(none) <tao-dd9cabc077fdf29d9ae9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|\\mathop{\\bf E}_{r \\in [N^{1/3}]} f(n+dr)\\right| \\gg \\delta^3.", block: true)]]

#text("On the other hand, since")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} f(n) = 0")]]

#text("we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} f(n+dr) = O( N^{-2/3+1/100})")]]

#text("for any ")#mi("{r \\in [N^{1/3}]}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [N^{1/3}]} f(n+dr) = O( N^{-2/3+1/100}).")]]

#text("Averaging this with ")#link(<tao-dd9cabc077fdf29d9ae9>)[#text("(2)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\max( \\mathop{\\bf E}_{r \\in [N^{1/3}]} f(n+dr), 0 ) \\gg \\delta^3.")]]

#text("In particular, by the pigeonhole principle we can find ")#mi("{n \\in [N]}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{r \\in [N^{1/3}]} f(n+dr) \\gg \\delta^3,")]]

#text("or equivalently ")#mi("{A}")#text(" has density at least ")#mi("{\\delta+c^{\\prime}\\delta^3}")#text(" on the arithmetic progression ")#mi("{\\{ n+dr: r \\in [N^{1/3}]\\}}")#text(", which has length ")#mi("{\\lfloor N^{1/3}\\rfloor }")#text(" and spacing ")#mi("{d}")#text(", for some absolute constant ")#mi("{c^{\\prime}>0}")#text(". By partitioning this progression into subprogressions of spacing ")#mi("{d^2}")#text(" and length ")#mi("{\\lfloor N^{1/4}\\rfloor}")#text(" (plus an error set of size ")#mi("{O(N^{1/4})}")#text(", we see from the pigeonhole principle that we can find a progression ")#mi("{\\{ n^{\\prime} + d^2 r^{\\prime}: r^{\\prime} \\in [N^{1/4}]\\}}")#text(" of length ")#mi("{\\lfloor N^{1/4}\\rfloor}")#text(" and spacing ")#mi("{d^2}")#text(" on which ")#mi("{A}")#text(" has density at least ")#mi("{\\delta + c\\delta^3}")#text(" (and hence at least ")#mi("{\\delta_0+c\\delta_0^3}")#text(") for some absolute constant ")#mi("{c>0}")#text(". If we then apply the induction hypothesis to the set")

#align(center)[#tao-fit-display[#mitex("A^{\\prime} := \\{ r^{\\prime} \\in [N^{1/4}]: n^{\\prime} + d^2 r^{\\prime} \\in A \\}")]]

#text("we conclude (for ")#mi("{N}")#text(" large enough) that ")#mi("{A^{\\prime}}")#text(" contains a pair ")#mi("{m, m+s^2}")#text(" for some natural numbers ")#mi("{m,s}")#text(" with ")#mi("{s}")#text(" non-zero. This implies that ")#tao-math("{(n^{\\prime}+d^2 m), (n^{\\prime}+d^2 m) + (\\left|d\\right|s)^2}", block: false)#text(" lie in ")#mi("{A}")#text(", a contradiction, establishing the implication ")#link(<tao-abecdf3503635c0be9ec>)[#text("(1)")]#text(".")

#text("A more careful analysis of the above argument reveals a more quantitative version of Theorem ")#link(<tao-dce7cce055566bed799f>)[#text("1")]#text(": for ")#mi("{N \\geq 100}")#text(" (say), any subset of ")#mi("{[N]}")#text(" of density at least ")#mi("{C/(\\log\\log N)^{1/2}}")#text(" for some sufficiently large absolute constant ")#mi("{C}")#text(" contains a pair ")#mi("{n,n+r^2}")#text(" with ")#mi("{r}")#text(" non-zero. This is not the best bound known; a (difficult) ")#link("http://www.ams.org/mathscinet-getitem?mr=928519")[#text("result of Pintz, Steiger, and Szemeredi")]#text(" allows the density to be as low as ")#mi("{C / (\\log N)^{\\frac{1}{4} \\log\\log\\log\\log N}}")#text(". On the other hand, this already improves on the (simpler) Fourier-analytic argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1920188")[#text("of Green")]#text(" that works for densities at least ")#mi("{C/(\\log\\log N)^{1/11}}")#text(" (although the ")#link("http://www.ams.org/mathscinet-getitem?mr=466059")[#text("original argument of Sarkozy")]#text(", which is a little more intricate, works up to ")#mi("{C (\\log\\log N)^{2/3}/(\\log N)^{1/3}}")#text("). In the other direction, a ")#link("http://www.ams.org/mathscinet-getitem?mr=756185")[#text("construction of Rusza")]#text(" gives a set of density ")#mi("{\\frac{1}{65} N^{-0.267}}")#text(" without any pairs ")#mi("{n,n+r^2}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A similar argument also applies with ")#mi("{n,n+r^2}")#text(" replaced by ")#mi("{n,n+r^k}")#text(" for fixed ")#mi("{k}")#text(", because this sort of pattern is preserved by affine dilations ")#mi("{r^{\\prime} \\mapsto n^{\\prime}+d^k r^{\\prime}}")#text(" into arithmetic progressions whose spacing ")#mi("{d^k}")#text(" is a ")#mi("{k^{th}}")#text(" power. By re-introducing Fourier analysis, one can also perform an argument of this type for ")#mi("{n,n+d,n+2d}")#text(" where ")#mi("{d}")#text(" is the sum of two squares; see the above-mentioned paper of Green for details. However there seems to be some technical difficulty in extending it to patterns of the form ")#mi("{n,n+P(r)}")#text(" for polynomials ")#mi("{P}")#text(" that consist of more than a single monomial (and with the normalisation ")#mi("{P(0)=0}")#text(", to avoid local obstructions), because one no longer has this preservation property.")
]

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f85a962998f491ac17c14d8c998207be9efc80df4188bb4d211d3e105ffdbcb0-ef0675e4a70302a2a616f595037854b4958ba37d3a3c888c454af82575362102.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218255")[#strong[#text("Hossein")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("WOW!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9521e98d660cc271844f73bbffc279f55fe0a15b317f2088883011d1c7d85724-f20a2ad7fb6a7f4b7b42f2e267f725604eceed14375e89dfea88ac48dafc2029.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218259")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Typo: “Suppose for sake of contradiction that … ")#mi("P(\\delta_0 + c\\delta_0^3)")#text(" holds” – should this be ")#mi("P(\\delta_0 + c\\delta_0^4)")#text("?")

#emph[#text("[Corrected, thanks. Actually I found just now that one could actually get back the ")#mi("\\delta_0^3")#text(" gain in density by being a bit more careful with the Cauchy-Schwarz, and updated the post accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218267")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("In the three equations before equation (2) I think r+h+h’ should be 2r+h+h’")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Thank you for the nice post! Actually, through shifting by (r+h)^2 one obtains 2r instead of r, and later 2rd but this is a minor thing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218290")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Terry, What are the upper and lower bounds on the required density in this case?")

#emph[#text("[Thanks for the question! I just added a link to the best known lower bound, by Ruzsa, at the end of this post. The best known upper bound is due to Pintz, Steiger, and Szemeredi and is also given at the end of the post. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218394")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Terry, I don’t think my arguments from 2002 give ")#mi("n")#text(", ")#mi("n + r^2")#text(", ")#mi("n + 2r^2")#text(" – in the paper you refer to, the common difference has to be a sum of two squares, a much weaker result. Also, the original Fourier -analytic argument of S\\’ark\\”ozy, which is not too complicated, gives a bound of ")#mi("(\\log N)^{-c}")#text(". The idea of this argument is to make sure your large Fourier coefficient is near a low-complexity rational, so you pass to a subprogression with small common difference.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218415")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Thanks for the lower bound, Terry, That’s quite a gap :)")

#text("I have another question: For Roth we have 2 finite alphabet analogs: The first is DHJ(3) (the density Hales Jewett for 3-letters alphabet) and the second is the cupset problem (a set of (0,1,n}^n without an affine line). (Of course, there are intermediate problems, etc.)")

#text("For Furstenberg-Sarkozy we have a DHJ analog (which is the first case of a polynomial DHJ that Tim proposed to study; it is over a 2-letters alphabet, the ground set has the structure of edges of a complete graph, and asks for a Sperner theorem where the difference correspond to a complete graph).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gowers.wordpress.com/2009/11/14/the-first-unknown-case-of-polynomial-dhj/")[#text("The first unknown case of polynomial DHJ")]
]

#text("My question is about an analog analogous to the the cupset analog. Maybe you have to exclude a difference is in a quadric? Do you know?")

#text("(If the forbidden things will includes those of the polynomial DHJ this would be nice but not necessary)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218420")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Well, the most direct capset analogue of the Furstenberg-Sarkozy theorem is that every dense subset of the polynomial ring ")#mi("{\\bf F}_3[t]")#text(" contains a pair of polynomials of the form ")#mi("p(t), p(t)+q(t)^2")#text(" for ")#mi("q(t)")#text(" non-zero. Here density is in the sense that the density in the space of polynomials of degree less than ")#mi("n")#text(" (which is isomorphic as a vector space to ")#mi("{\\bf F}_3^n")#text(") is bounded from below as ")#mi("n \\to \\infty")#text(". Pretty much any of the known proofs of the Furstenberg-Sarkozy theorem will adapt to this finite field setting (and in fact the arguments will usually become a little bit simpler) But this is not a purely alphabetical statement, because the operation of squaring a polynomial becomes quite complicated if one attempts to interpret it purely in terms of combinatorial operations on the coefficients (it is convolution rather than pointwise addition).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218422")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("That’s fine, but why F_3 and not F_2?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218435")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("The squaring function ")#mi("q(t) \\mapsto q(t)^2")#text(" behaves quite differently in characteristic 2 as compared to odd (or zero) characteristic; in particular, in this characteristic the squaring function becomes linear (")#mi("q(t)^2 = q(t^2)")#text("), and the result here collapses to something more analogous to the Ajtai-Szemeredi corners theorem than the Furstenberg-Sarkozy theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219478")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("Regarding ")#mi("Z_p^n")#text(" as representing polynomials in one variable of degree less than n is very natural, but we can have other versions, e.g., polynomials of degree 2 in some m variables (or “bipartite” polynomials of degree 2) , which may make sense over ")#mi("Z_2")#text(" as well. In particular, it will be nice to have cupset versions related to versions of polynomial HJT that Tim Gowers considered here ")#link("http://gowers.wordpress.com/2009/11/14/the-first-unknown-case-of-polynomial-dhj/")[#text("http://gowers.wordpress.com/2009/11/14/the-first-unknown-case-of-polynomial-dhj/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb638539cd058ec6b5f1f417b7635c2e41d50443240f120ae2a102ed56e680f9-ca7b88140f23d58d6b24abffded01500e3165f0e24772cb110f82d30d86613e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neil Lyall")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-218492")[#strong[#text("Neil Lyall")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2013")])]

#text("Terry, thanks for the very nice post!")

#text("Just wanted to point out that I believe the argument you present can be adapted in a standard way, using Lucier’s increment strategy (with the polynomials changing with each iteration), to obtain the analogous result for full class of so-called intersective polynomials. A nice exposition of Lucier’s iterative procedure can be found at the beginning of Chapter 6 (pp 40-42) of Alex Rice’s Ph.D. thesis, see ")#link("http://www.math.uga.edu/~arice/AlexThesis.pdf")[#text("http://www.math.uga.edu/~arice/AlexThesis.pdf")]

#text("A quick calculation seems to give a bound of the order")#linebreak()#text(" ")#mi("C_k/(\\log\\log N)^{1/2^{k-1}}")#text(" for intersective polynomials of degree ")#mi("k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29b5f3b0987495caa715960819014edc6326a0ed3ebf403bb5a1c0a65f256fec-d0045224cf4d828bda73977abdeac2a3e4e1b7cc9113a81dd387d1064a5b19d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219085")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2013")])]

#text("Thank you for one more great post. You work inspire me, Dr. Tao.")

#text("Can anyone help me with a very basic question? How does (1) guarantee that the infimus of the set of all \\delta>0 for which P(\\delta) holds is zero? And how does analyzing this leads to the fact that P holds for all \\delta>0?")

#text("Sorry for the basic question, but I got stuck.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9521e98d660cc271844f73bbffc279f55fe0a15b317f2088883011d1c7d85724-f20a2ad7fb6a7f4b7b42f2e267f725604eceed14375e89dfea88ac48dafc2029.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219092")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2013")])]

#text("Define the set ")#mi("A = \\{\\delta: P(\\delta)\\}")#text(". If ")#mi("\\delta \\in A")#text(" then for any ")#mi("\\epsilon > \\delta")#text(" we have ")#mi("\\epsilon \\in A")#text(", simply because the theorem is stronger for smaller ")#mi("\\delta")#text(". So the set is some interval (closed ")#mi("[\\delta_0, \\infty)")#text(" or open ")#mi("(\\delta_0,\\infty)")#text(") and trivially it contains 1. Let’s call ")#mi("\\delta_0")#text(" infimum of ")#mi("A")#text(". ")#mi("\\delta_0")#text(" may or may not be in ")#mi("A")#text(" but anything greater than it definitely is in ")#mi("A")#text(".")

#text("If ")#mi("\\delta_0 = 0")#text(", then we are done, since this means ")#mi("A")#text(" contains any positive value, which proves the theorem. So let’s assume ")#mi("\\delta_0 > 0")#text(" and derive a contradiction.")

#text("Let ")#mi("f(x) = x + c x^3")#text(". Note that ")#mi("f")#text(" is (strictly) increasing and continuous. From (1) we have ")#mi("f(x) \\in A \\implies x \\in A")#text(". Equivalently, ")#mi("x \\in A \\implies f^{-1}(x) \\in A")#text(".")

#text("Take any number ")#mi("\\epsilon \\in (\\delta_0, f(\\delta_0))")#text(". Since ")#mi("\\epsilon > \\delta_0")#text(" we have ")#mi("\\epsilon \\in A")#text(", therefore ")#mi("f^{-1}(\\epsilon) \\in A")#text(". But since ")#mi("\\epsilon < f(\\delta_0)")#text(" we have ")#mi("f^{-1}(\\epsilon) < \\delta_0")#text(". So we have a number ")#mi("f^{-1}(\\epsilon)")#text(" which is in ")#mi("A")#text(" and smaller than ")#mi("\\delta_0")#text(", contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29b5f3b0987495caa715960819014edc6326a0ed3ebf403bb5a1c0a65f256fec-d0045224cf4d828bda73977abdeac2a3e4e1b7cc9113a81dd387d1064a5b19d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219101")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2013")])]

#text("Dear anon,")

#text("Thank you for your nice explanation!")

#text("I now got the idea.")

#text("Sincerely, Joseph")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29b5f3b0987495caa715960819014edc6326a0ed3ebf403bb5a1c0a65f256fec-d0045224cf4d828bda73977abdeac2a3e4e1b7cc9113a81dd387d1064a5b19d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219157")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2013")])]

#text("Dear anon,")

#text("Thank you again. But just a quick question: as we define f(x) = x+cx^3, can we consider the same value of c for all x? I mean, the beginning of Tao’s proof says that for any 0<delta00. Can we then fix c when defining f(x) (for example, by taking a c that satisfies (1) for any delta, if such one exists)?")

#text("Otherwise, if we state f(x) = x+c(x)x^3, with c now a function, can we still guarantee that f is invertible?")

#text("Sorry if the question is too basic… This is a new field for me.")

#text("Regards,")

#text("Joseph.")

#emph[#text("[It appears that you used some < and > signs in your answer that became interpreted as HTML and thus disappeared. If you use &lt; and &gt; instead then this should avoid the problem. In any case, ")#mi("c")#text(" is indeed the fixed absolute constant from (1). -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29b5f3b0987495caa715960819014edc6326a0ed3ebf403bb5a1c0a65f256fec-d0045224cf4d828bda73977abdeac2a3e4e1b7cc9113a81dd387d1064a5b19d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-219390")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2013")])]

#text("Never mind, I got it… Once you assume that the infimum is delta0 > 0, you define f(x) = x+cx^3, with c the value that satisfies (1) for that particular delta0 value (so, yes, a unique value for c). Than f is of course increasing and continuous, and everything else follows… I was thinking in a different way, but your explanation was perfect. Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86db87dc075c93412bfdc1ea9b7864c2d55ad1a086ae6dc087dffc0521b8629c-e2c517d9b5f8679e4d4582da1253db4a05b0bc7bfa81afc1502def3aa5f8609c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of solver6")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-220679")[#strong[#text("solver6")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("Hello, i don’t understand wy ")#mi("{\\bf E}_{n\\in [N]}{\\bf E}_{r\\in [N^{1/3}]}{\\bf E}_{h\\in[n^{1/100}]}1_A(n)\\delta1_{[N]}(n+(r+h)^2)={\\delta}^2+O(N^{1/3})")#text(" holds. Can someone help me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-220690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2013")])]

#text("For all but about ")#mi("O(N^{2/3})")#text(" of the choices of n (the choices that are closest to the boundary of ")#mi("[N]")#text(", the inner average ")#mi("{\\bf E}_{r \\in [N^{1/3}]} {\\bf E}_{h \\in [n^{1/100}]} \\delta 1_{[N]}(n+(r+h)^2)")#text(" is equal to ")#mi("\\delta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b39e0b59c878402423c3fef50938d56aa8381dd408f7a0ca59cded2a015adac4-9b499ebcc487ff64ed34f82ec3d1125ee8e442f80a8906e35bdc42b413304ba7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-224967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2013")])]

#text("Hi, I don’t understand the move from the inequality depending only on $h,n,r$ to the one depending also on $h’$.")

#text("Any help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-224980")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2013")])]

#tao-math("\\left|{\\bf E}_{h \\in A} c(h)\\right|^2 = {\\bf E}_{h \\in A} {\\bf E}_{h^{\\prime} \\in A} c(h) c(h^{\\prime})", block: false)#text(" whenever ")#mi("c(h)")#text(" is real-valued.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b39e0b59c878402423c3fef50938d56aa8381dd408f7a0ca59cded2a015adac4-9b499ebcc487ff64ed34f82ec3d1125ee8e442f80a8906e35bdc42b413304ba7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-225305")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2013")])]

#text("Maybe the left side should be squared?")

#emph[#text("[Corrected, thanks – T.],")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8f5fa9345cf000352a5771f4229567fceb3fbb59bb7348599b6a3a1c96a60ab-4584590bb17f791abe9126984c82cbaf8b7a374d5420601a7638d3ada529f88a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ned")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-455158")[#strong[#text("Ned")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("Hi, I need some help: I don’t understand how Cauchy-Schwarz is applied.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-455200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("Cauchy-Schwarz bounds ")#tao-math("{\\bf E}_{n \\in [N]} {\\bf E}_{r \\in [N^{1/3}]} \\left|f(n)\\right| \\left| E_{h \\in [N^{1/100}]} f(n+(r+h)^2)\\right|", block: false)#text(" by the geometric mean of ")#tao-math("{\\bf E}_{n \\in [N]} \\left|f(n)\\right|^2", block: false)#text(" and ")#tao-math("{\\bf E}_{n \\in [N]} {\\bf E}_{r \\in [N^{1/3}]} \\left| E_{h \\in [N^{1/100}]} f(n+(r+h)^2)\\right|^2", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ned")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-455291")[#strong[#text("Ned")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2015")])]

#text("thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2013/02/28/a-fourier-free-proof-of-the-furstenberg-sarkozy-theorem/#comment-682664")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2023")])]

#text("Let ")#mi("P")#text(" be the progression ")#mi("\\{n + dr : r\\in [N^{1/3}]")#text(" obtained near the end of the proof. I think strictly speaking, the fact that ")#mi("{\\bf E}_{r\\in [N^{1/3}]} f(n+dr) \\gg \\delta^3")#text(" only gives us ")#tao-math("\\left|A\\cap P\\right| / \\left|P\\right| \\ge c\\delta^3 + \\delta |[N]\\cap P|\\over \\left|P\\right|", block: false)#text(". But to ensure that ")#mi("P\\subseteq [N]")#text(", we can throw away the largest ")#mi("2N^{1/3+1/100}")#text(" elements of ")#mi("[N]")#text(" at the cost of introducing an error term of ")#mi("O(N^{-2/3+1/100})")#text(". (This doesn’t matter because the whole thing will still be ")#mi("\\gg \\delta^3")#text(".) Then we only sum over ")#mi("n\\in [N-2N^{1/3+1/100}]")#text(", and the elements ")#mi("n+dr")#text(" will always be in ")#mi("[N]")#text(".")
]
