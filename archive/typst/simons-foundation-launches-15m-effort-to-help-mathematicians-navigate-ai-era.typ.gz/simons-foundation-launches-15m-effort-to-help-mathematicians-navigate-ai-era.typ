// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/
// Converted to Typst by tao2typ: "2026-11-16T16:08:21.036753+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Simons Foundation Launches $15M Effort To Help Mathematicians Navigate AI Era", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Simons Foundation Launches $15M Effort To Help Mathematicians Navigate AI Era")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/")[#text("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A ")#link("https://www.simonsfoundation.org/news/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/")[#text("new press release from the Simons Foundation")]#text(", calling for workshops and other initiatives centered on mathematics in the era of AI.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698088")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Great news!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86cf8e242b153b318c02a7df981adc73582a9e2f8838908175acf8a2d9ce5c7c-2a59886790e32ce207c27edac5980b6f0076723881ea8f693648cd84dd41474f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698089")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Not exactly a ”Whatever it takes”, Draghi kind of moment… Openai could probably add a zero and arrange partnerships with a bunch of institutes to have workshops on their current and future papers…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c865010fd5ff72fe83b1c9599ceba7dbda03dbe12463c03223875e6874005ac-ca5225a41b7d35a06389d00fefc22d5f990f83ae3c5839a4699a18bbdafa67ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arihant Jain")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698094")[#strong[#text("Arihant Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Couldn’t agree more. I hope the fund will be used in finding smoother transitions to Math 2.0 instead of proving more AI-assisted theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698109")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("It’s true. This is very little money for them. More would be better. But this is a start.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698098")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("More than one idea that would go on to become a contribution awarded a Fields Medal originated with Alexander Grothendieck’s Sketch of a Program, an image I find quite fitting as we struggle with the division between the search for beauty and earning bread. The ivory tower did not find itself in a crisis of morality overnight")

#text("Lean was born out of IAS seminars developing HoTT, there’s a famously strange interview with Vladimir Voevodesky where among many attempts to grasp at the spiritual and seemingly mystical side of science and his expierence he boldly professes a belief the two subjects are fundamentally heading for a collision course with one another. In that interview get a glimpse into a mind that was not only concerned with getting a computer to assist with verifiying his far out there ideas he often struggled to express to others but genetics and we see emerge that the barrier to his imaginative designs was data.")

#text("We have arxiv, but astrophysics data or data about a new superconducting compound is not transparently and freely available at all. In medicine forget it.")

#text("The societal dynamics that industriously farm the youth into “big science” are famously addressed in Eisenhower’s farewell address. Few seem willing or able to have a mature conversation about the structural role of an organization like DARPA here beyond what something like expMath means for their students. Before the AI bubble we had the internet, and before that railroads. We still use that broadband infrastructure and ship containers on those very same tracks. The push for powerful autonomous AI systems is primarily driven by the perceived value such capacities have in great power conflict. When we are discussing solving math problems we are discussing the very same technology being employed to make decisions that universities are strategic targets to be eliminated to achieve domination over the enemy")

#text("I don’t want to be a doomer. I am a beneficiary of how one can learn about gauge theory while gazing at wonderful sights and sounds of nature thanks to mondern technology. We want to move fast and break things. Ironically the radical future promised very well may be tangible, but we need to find the room to take a deep breath and consider how we can transform the way we live, an elephant in the room is the overlap of shareholders in AI firms and people vocally afraid of such democractic processeses inviting the participation of the masses")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("$15 million is not a lot and might support 75 postdoctorates in 2 years. Unfortunately mathematics is not patentable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698103")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("As admitted in the press release, the Simons Foundation has been sponsoring machine learning and AI for a long time. So with OpenAI and Anthropic there are three incumbents who are financing this initiative.")

#text("The initiative is for reviewing the OpenAI results, learning AI tools and shaping collective standards for AI use.")

#text("The first two directly benefit the AI companies. The third assumes inevitability.")

#text("Money is always nice, but I’m not sure if this influence is entirely positive. I’d rather have the EU giving $15M for shaping collective standards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698107")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("So….about half what OpenAI spent on scooping Navier-Stokes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698134")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This isn’t to help mathematicians. It’s to pay mathematicians who are willing to use AI to bring AI to the next level so mathematics as a human effort can be destroyed. And it’s to prevent OpenAI from being accused of destroying math. It’s entirely selfish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/simons-foundation-launches-15m-effort-to-help-mathematicians-navigate-ai-era/#comment-698172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I feel like there is a lack of transparency, both from the title of the article and the title of this post, in disclosing the fact that this is funded by OpenAI and Anthropic.")
]
