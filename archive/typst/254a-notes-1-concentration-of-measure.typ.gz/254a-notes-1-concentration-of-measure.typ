// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/
// Converted to Typst by tao2typ: "2026-10-14T16:36:01.209898+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 1: Concentration of measure", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 1: Concentration of measure")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose we have a large number of scalar random variables ")#mi("{X_1,\\ldots,X_n}")#text(", which each have bounded size on average (e.g. their mean and variance could be ")#mi("{O(1)}")#text("). What can one then say about their sum ")#mi("{S_n := X_1+\\ldots+X_n}")#text("? If each individual summand ")#mi("{X_i}")#text(" varies in an interval of size ")#mi("{O(1)}")#text(", then their sum of course varies in an interval of size ")#mi("{O(n)}")#text(". However, a remarkable phenomenon, known as ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentration of measure")]#text(", asserts that assuming a sufficient amount of independence between the component variables ")#mi("{X_1,\\ldots,X_n}")#text(", this sum sharply concentrates in a much narrower range, typically in an interval of size ")#mi("{O(\\sqrt{n})}")#text(". This phenomenon is quantified by a variety of ")#link("http://en.wikipedia.org/wiki/Large_deviations_theory")[#text("large deviation inequalities")]#text(" that give upper bounds (often exponential in nature) on the probability that such a combined random variable deviates significantly from its mean. The same phenomenon applies not only to linear expressions such as ")#mi("{S_n = X_1+\\ldots+X_n}")#text(", but more generally to nonlinear combinations ")#mi("{F(X_1,\\ldots,X_n)}")#text(" of such variables, provided that the nonlinear function ")#mi("{F}")#text(" is sufficiently regular (in particular, if it is Lipschitz, either separately in each variable, or jointly in all variables).")

#text("The basic intuition here is that it is difficult for a large number of independent variables ")#mi("{X_1,\\ldots,X_n}")#text(" to “work together” to simultaneously pull a sum ")#mi("{X_1+\\ldots+X_n}")#text(" or a more general combination ")#mi("{F(X_1,\\ldots,X_n)}")#text(" too far away from its mean. Independence here is the key; concentration of measure results typically fail if the ")#mi("{X_i}")#text(" are too highly correlated with each other.")

#text("There are many applications of the concentration of measure phenomenon, but we will focus on a specific application which is useful in the random matrix theory topics we will be studying, namely on controlling the behaviour of random ")#mi("{n}")#text("-dimensional vectors with independent components, and in particular on the distance between such random vectors and a given subspace.")

#text("Once one has a sufficient amount of independence, the concentration of measure tends to be sub-gaussian in nature; thus the probability that one is at least ")#mi("{\\lambda}")#text(" standard deviations from the mean tends to drop off like ")#mi("{C \\exp(-c\\lambda^2)}")#text(" for some ")#mi("{C,c > 0}")#text(". In particular, one is ")#mi("{O( \\log^{1/2} n )}")#text(" standard deviations from the mean with high probability, and ")#mi("{O( \\log^{1/2+\\epsilon} n)}")#text(" standard deviations from the mean with overwhelming probability. Indeed, concentration of measure is our primary tool for ensuring that various events hold with overwhelming probability (other moment methods can give high probability, but have difficulty ensuring overwhelming probability).")

#text("This is only a brief introduction to the concentration of measure phenomenon. A systematic study of this topic can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=1849347")[#text("this book by Ledoux")]#text(".")

#metadata(none) <tao-a2f9815969062f38282e>

#heading(level: 1)[#strong[#text(" — 1. Linear combinations, and the moment method — ")]]

#text("We begin with the simple setting of studying a sum ")#mi("{S_n := X_1+\\ldots+X_n}")#text(" of random variables. As we shall see, these linear sums are particularly amenable to the moment method, though to use the more powerful moments, we will require more powerful independence assumptions (and, naturally, we will need more moments to be finite or bounded). As such, we will take the opportunity to use this topic (large deviation inequalities for sums of random variables) to give a tour of the ")#emph[#text("moment method")]#text(", which we will return to when we consider the analogous questions for the bulk spectral distribution of random matrices.")

#text("In this section we shall concern ourselves primarily with bounded random variables; in the next section we describe the basic ")#emph[#text("truncation method")]#text(" that can allow us to extend from the bounded case to the unbounded case (assuming suitable decay hypotheses).")

#text("The zeroth moment method gives a crude upper bound when ")#mi("{S}")#text(" is non-zero, ")#metadata(none) <tao-f9194e73f9e9459e3450>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( S_n \\neq 0 ) \\leq \\sum_{i=1}^n {\\bf P}( X_i \\neq 0 )")]]

#text("but in most cases this bound is worse than the trivial bound ")#mi("{{\\bf P}(S_n \\neq 0) \\leq 1}")#text(". This bound, however, will be useful when performing the ")#emph[#text("truncation trick")]#text(", which we will discuss below.")

#text("The first moment method is somewhat better, giving the bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right| \\leq \\sum_{i=1}^n {\\bf E} \\left|X_i\\right|", block: true)]]

#text("which when combined with Markov’s inequality gives the rather weak large deviation inequality ")#metadata(none) <tao-7c3d546c231b36cd6731>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf P}( \\left|S_n\\right| \\geq \\lambda ) \\leq \\frac{1}{\\lambda} \\sum_{i=1}^n {\\bf E} |X_i|.", block: true)]]

#text("As weak as this bound is, this bound is sometimes sharp. For instance, if the ")#mi("{X_i}")#text(" are all equal to a single signed Bernoulli variable ")#mi("{X \\in \\{-1,+1\\}}")#text(", then ")#mi("{S_n = nX}")#text(", and so ")#tao-math("{\\left|S_n\\right| = n}", block: false)#text(", and so ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(" is sharp when ")#mi("{\\lambda=n}")#text(". The problem here is a complete lack of independence; the ")#mi("{X_i}")#text(" are all simultaneously positive or simultaneously negative, causing huge fluctuations in the value of ")#mi("{S_n}")#text(".")

#text("Informally, one can view ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(" as the assertion that ")#mi("{S_n}")#text(" typically has size ")#tao-math("{S_n = O( \\sum_{i=1}^n \\left|X_i\\right| )}", block: false)#text(".")

#text("The first moment method also shows that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} S_n = \\sum_{i=1}^n {\\bf E} X_i")]]

#text("and so we can normalise out the means using the identity")

#align(center)[#tao-fit-display[#mitex("S_n - {\\bf E} S_n = \\sum_{i=1}^n X_i - {\\bf E} X_i.")]]

#text("Replacing the ")#mi("{X_i}")#text(" by ")#mi("{X_i - {\\bf E} X_i}")#text(" (and ")#mi("{S_n}")#text(" by ")#mi("{S_n - {\\bf E} S_n}")#text(") we may thus assume for simplicity that all the ")#mi("{X_i}")#text(" have mean zero.")

#text("Now we consider what the second moment method gives us. We square ")#mi("{S_n}")#text(" and take expectations to obtain")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^2 = \\sum_{i=1}^n \\sum_{j=1}^n {\\bf E} X_i \\overline{X_j}.", block: true)]]

#text("If we assume that the ")#mi("{X_i}")#text(" are pairwise independent (in addition to having mean zero), then ")#mi("{{\\bf E} X_i \\overline{X_j}}")#text(" vanishes unless ")#mi("{i=j}")#text(", in which case this expectation is equal to ")#mi("{{\\bf Var}(X_i)}")#text(". We thus have ")#metadata(none) <tao-d7813f80bf8cd3626d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf Var}(S_n) = \\sum_{i=1}^n {\\bf Var}(X_i)")]]

#text("which when combined with Chebyshev’s inequality (and the mean zero normalisation) yields the large deviation inequality ")#metadata(none) <tao-910618ecc4d1ec3ce3f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("{\\bf P}( \\left|S_n\\right| \\geq \\lambda ) \\leq \\frac{1}{\\lambda^2} \\sum_{i=1}^n {\\bf Var}(X_i).", block: true)]]

#text("Without the normalisation that the ")#mi("{X_i}")#text(" have mean zero, we obtain ")#metadata(none) <tao-db939c40a9f78e7d5011>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\bf P}( \\left|S_n - {\\bf E} S_n\\right| \\geq \\lambda ) \\leq \\frac{1}{\\lambda^2} \\sum_{i=1}^n {\\bf Var}(X_i).", block: true)]]

#text("Informally, this is the assertion that ")#mi("{S_n}")#text(" typically has size ")#mi("{S_n = {\\bf E} S_n + O( (\\sum_{i=1}^n {\\bf Var}(X_i))^{1/2} )}")#text(", if we have pairwise independence. Note also that we do not need the full strength of the pairwise independence assumption; the slightly weaker hypothesis of being pairwise ")#link("http://en.wikipedia.org/wiki/Pearson_product-moment_correlation_coefficient")[#text("uncorrelated")]#text(" would have sufficed.")

#text("The inequality ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" is sharp in two ways. Firstly, we cannot expect any significant concentration in any range narrower than the standard deviation ")#mi("{O( (\\sum_{i=1}^n {\\bf Var}(X_i))^{1/2} )}")#text(", as this would likely contradict ")#link(<tao-d7813f80bf8cd3626d39>)[#text("(3)")]#text(". Secondly, the quadratic-type decay in ")#mi("{\\lambda}")#text(" in ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" is sharp given the pairwise independence hypothesis. For instance, suppose that ")#mi("{n = 2^m-1}")#text(", and that ")#mi("{X_j := (-1)^{a_j \\cdot Y}}")#text(", where ")#mi("{Y}")#text(" is drawn uniformly at random from the cube ")#mi("{\\{0,1\\}^m}")#text(", and ")#mi("{a_1,\\ldots,a_n}")#text(" are an enumeration of the non-zero elements of ")#mi("{\\{0,1\\}^m}")#text(". Then a little Fourier analysis shows that each ")#mi("{X_j}")#text(" for ")#mi("{1 \\leq j \\leq n}")#text(" has mean zero, variance ")#mi("{1}")#text(", and are pairwise independent in ")#mi("{j}")#text("; but ")#mi("{S}")#text(" is equal to ")#mi("{(n+1) {\\bf I}( Y = 0 ) - 1}")#text(", which is equal to ")#mi("{n}")#text(" with probability ")#mi("{1/(n+1)}")#text("; this is despite the standard deviation of ")#mi("{S}")#text(" being just ")#mi("{\\sqrt{n}}")#text(". This shows that ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" is essentially (i.e. up to constants) sharp here when ")#mi("{\\lambda = n}")#text(".")

#text("Now we turn to higher moments. Let us assume that the ")#mi("{X_i}")#text(" are normalised to have mean zero and variance at most ")#mi("{1}")#text(", and are also almost surely bounded in magnitude by some ")#mi("{K}")#text(": ")#tao-math("{\\left|X_i\\right| \\leq K}", block: false)#text(". (The interesting regime here is when ")#mi("{K \\geq 1}")#text(", otherwise the variance is in fact strictly smaller than ")#mi("{1}")#text(".) To simplify the exposition very slightly we will assume that the ")#mi("{X_i}")#text(" are real-valued; the complex-valued case is very analogous (and can also be deduced from the real-valued case) and is left to the reader.")

#text("Let us also assume that the ")#mi("{X_1,\\ldots,X_n}")#text(" are ")#mi("{k}")#text("-wise independent for some even positive integer ")#mi("{k}")#text(". With this assumption, we can now estimate the ")#mi("{k^{th}}")#text(" moment")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^k = \\sum_{1 \\leq i_1,\\ldots,i_k \\leq n} {\\bf E} X_{i_1} \\ldots X_{i_{k}}.", block: true)]]

#text("To compute the expectation of the product, we can use the ")#mi("{k}")#text("-wise independence, but we need to divide into cases (analogous to the ")#mi("{i \\neq j}")#text(" and ")#mi("{i=j}")#text(" cases in the second moment calculation above) depending on how various indices are repeated. If one of the ")#mi("{X_{i_j}}")#text(" only appear once, then the entire expectation is zero (since ")#mi("{X_{i_j}}")#text(" has mean zero), so we may assume that each of the ")#mi("{X_{i_j}}")#text(" appear at least twice. In particular, there are at most ")#mi("{k/2}")#text(" distinct ")#mi("{X_j}")#text(" which appear. If exactly ")#mi("{k/2}")#text(" such terms appear, then from the unit variance assumption we see that the expectation has magnitude at most ")#mi("{1}")#text("; more generally, if ")#mi("{k/2-r}")#text(" terms appear, then from the unit variance assumption and the upper bound by ")#mi("{K}")#text(" we see that the expectation has magnitude at most ")#mi("{K^{2r}}")#text(". This leads to the upper bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^k \\leq \\sum_{r=0}^{k/2} K^{2r} N_r", block: true)]]

#text("where ")#mi("{N_r}")#text(" is the number of ways one can assign integers ")#mi("{i_1,\\ldots,i_k}")#text(" in ")#mi("{\\{1,\\ldots,n\\}}")#text(" such that each ")#mi("{i_j}")#text(" appears at least twice, and such that exactly ")#mi("{k/2-r}")#text(" integers appear.")

#text("We are now faced with the purely combinatorial problem of estimating ")#mi("{N_r}")#text(". We will use a somewhat crude bound. There are ")#mi("{\\binom{n}{k/2-r} \\leq n^{k/2-r} / (k/2-r)!}")#text(" ways to choose ")#mi("{k/2-r}")#text(" integers from ")#mi("{\\{1,\\ldots,n\\}}")#text(". Each of the integers ")#mi("{i_j}")#text(" has to come from one of these ")#mi("{k/2-r}")#text(" integers, leading to the crude bound")

#align(center)[#tao-fit-display[#mitex("N_r \\leq \\frac{n^{k/2-r}}{(k/2-r)!} (k/2-r)^k")]]

#text("which after using a crude form ")#mi("{n! \\geq n^n e^{-n}}")#text(" of ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Stirling’s formula")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("N_r \\leq (en)^{k/2-r} (k/2)^{k/2+r},")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^k \\leq (enk/2)^{k/2} \\sum_{r=0}^{k/2} (\\frac{K^2 k}{en})^r.", block: true)]]

#text("If we make the mild assumption ")#metadata(none) <tao-d90a7fe434fa7db7abe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("K^2 \\leq n/k")]]

#text("then from the geometric series formula we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^k \\leq 2 (enk/2)^{k/2}", block: true)]]

#text("(say), which leads to the large deviation inequality ")#metadata(none) <tao-bc64a05e6530fc45e1a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("{\\bf P}( \\left|S_n\\right| \\geq \\lambda \\sqrt{n} ) \\leq 2 (\\frac{\\sqrt{ek/2}}{\\lambda})^k.", block: true)]]

#text("This should be compared with ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(", ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(". As ")#mi("{k}")#text(" increases, the rate of decay in the ")#mi("{\\lambda}")#text(" parameter improves, but to compensate for this, the range that ")#mi("{S_n}")#text(" concentrates in grows slowly, to ")#mi("{O(\\sqrt{nk})}")#text(" rather than ")#mi("{O(\\sqrt{n})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note how it was important here that ")#mi("{k}")#text(" was even. Odd moments, such as ")#mi("{{\\bf E} S_n^3}")#text(", can be estimated, but due to the lack of the absolute value sign, these moments do not give much usable control on the distribution of the ")#mi("{S_n}")#text(". One could be more careful in the combinatorial counting than was done here, but the net effect of such care is only to improve the unspecified constant ")#mi("{C}")#text(" (which can easily be made explicit, but we will not do so here).")
]

#text("Now suppose that the ")#mi("{X_1,\\ldots,X_n}")#text(" are not just ")#mi("{k}")#text("-wise independent for any fixed ")#mi("{k}")#text(", but are in fact jointly independent. Then we can apply ")#link(<tao-bc64a05e6530fc45e1a7>)[#text("(7)")]#text(" for any ")#mi("{k}")#text(" obeying ")#link(<tao-d90a7fe434fa7db7abe7>)[#text("(6)")]#text(". We can optimise in ")#mi("{k}")#text(" by setting ")#mi("{\\sqrt{nk}}")#text(" to be a small multiple of ")#mi("{\\lambda}")#text(", and conclude the gaussian-type bound ")#metadata(none) <tao-d04b284153098bab7685>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("{\\bf P}( \\left|S_n\\right| \\geq \\lambda \\sqrt{n} ) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(", provided that ")#tao-math("{\\left|\\lambda\\right| \\leq c \\sqrt{n} / K}", block: false)#text(" for some small ")#mi("{c}")#text(". (Note that the bound ")#link(<tao-d04b284153098bab7685>)[#text("(8)")]#text(" is trivial for ")#tao-math("{\\left|\\lambda\\right| \\gg \\sqrt{n}}", block: false)#text(", so we may assume that ")#mi("{\\lambda}")#text(" is small compared to this quantity.) Thus we see that while control of each individual moment ")#tao-math("{{\\bf E} \\left|S_n\\right|^k}", block: false)#text(" only gives polynomial decay in ")#mi("{\\lambda}")#text(", by using all the moments simultaneously one can obtain square-exponential decay (i.e. subgaussian type decay).")

#text("By using Stirling’s formula (Exercise 2 from ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Notes 0a")]#text(") one can show that the quadratic decay in ")#link(<tao-d04b284153098bab7685>)[#text("(8)")]#text(" cannot be improved; see Exercise ")#link(<tao-a2a23b4264cbe2f88b28>)[#text("2")]#text(" below.")

#text("It was a little complicated to manage such large moments ")#tao-math("{{\\bf E} \\left|S_n\\right|^k}", block: false)#text(". A slicker way to proceed (but one which exploits the joint independence and commutativity more strongly) is to work instead with the ")#emph[#text("exponential moments")]#text(" ")#mi("{{\\bf E} \\exp( t S_n )}")#text(", which can be viewed as a sort of generating function for the power moments. A useful lemma in this regard is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Hoeffding’s lemma)")]#text(" Let ")#mi("{X}")#text(" be a scalar variable taking values in an interval ")#mi("{[a,b]}")#text(". Then for any ")#mi("{t>0}")#text(", ")#metadata(none) <tao-9377b805a4fc064b778f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\bf E} e^{tX} \\leq e^{t {\\bf E} X} (1 + O( t^2 {\\bf Var}(X) \\exp( O( t (b-a) ) ) ).")]]

#text("In particular ")#metadata(none) <tao-11a5eb5bb9f1cc14358a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("{\\bf E} e^{tX} \\leq e^{t {\\bf E} X} \\exp( O( t^2 (b-a)^2 ) ).")]]
]

#emph[#text("Proof:")]#text(" It suffices to prove the first inequality, as the second then follows using the bound ")#mi("{{\\bf Var}(X) \\leq (b-a)^2}")#text(" and from various elementary estimates.")

#text("By subtracting the mean from ")#mi("{X,a,b}")#text(" we may normalise ")#mi("{{\\bf E}(X)=0}")#text(". By dividing ")#mi("{X,a,b}")#text(" (and multiplying ")#mi("{t}")#text(" to balance) we may assume that ")#mi("{b-a=1}")#text(", which implies that ")#mi("{X = O(1)}")#text(". We then have the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("e^{tX} = 1 + tX + O( t^2 X^2 \\exp( O(t) ) )")]]

#text("which on taking expectations gives")

#align(center)[#tao-fit-display[#mitex("{\\bf E} e^{tX} = 1 + O( t^2 {\\bf Var}(X) \\exp(O(t))")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that the ")#mi("{O(t^2(b-a)^2)}")#text(" factor in ")#link(<tao-11a5eb5bb9f1cc14358a>)[#text("(10)")]#text(" can be replaced with ")#mi("{t^2 (b-a)^2/8}")#text(", and that this is sharp. (Hint: use ")#link("http://en.wikipedia.org/wiki/Jensen's_inequality")[#text("Jensen’s inequality")]#text(".)")
]

#text("We now have the fundamental ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff bound")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Chernoff inequality)")]#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent scalar random variables with ")#tao-math("{\\left|X_i\\right| \\leq K}", block: false)#text(" almost surely, with mean ")#mi("{\\mu_i}")#text(" and variance ")#mi("{\\sigma_i^2}")#text(". Then for any ")#mi("{\\lambda > 0}")#text(", one has ")#metadata(none) <tao-76f73c895b3f5ae270a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("{\\bf P}( \\left|S_n - \\mu\\right| \\geq \\lambda \\sigma ) \\leq C \\max( \\exp( - c \\lambda^2 ), \\exp( - c \\lambda \\sigma / K ) )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(", where ")#mi("{\\mu := \\sum_{i=1}^n \\mu_i}")#text(" and ")#mi("{\\sigma^2 := \\sum_{i=1}^n \\sigma_i^2}")#text(".")
]

#emph[#text("Proof:")]#text(" By taking real and imaginary parts we may assume that the ")#mi("{X_i}")#text(" are real. By subtracting off the mean (and adjusting ")#mi("{K}")#text(" appropriately) we may assume that ")#mi("{\\mu_i=0}")#text(" (and so ")#mi("{\\mu=0}")#text("); dividing the ")#mi("{X_i}")#text(" (and ")#mi("{\\sigma_i}")#text(") through by ")#mi("{K}")#text(" we may assume that ")#mi("{K=1}")#text(". By symmetry it then suffices to establish the upper tail estimate")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma ) \\leq C \\max( \\exp( - c \\lambda^2 ), \\exp( - c \\lambda \\sigma ) )")]]

#text("(with slightly different constants ")#mi("{C, c}")#text(").")

#text("To do this, we shall first compute the exponential moments")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n )")]]

#text("where ")#mi("{0 \\leq t \\leq 1}")#text(" is a real parameter ")#link("http://www.tricki.org/article/Keep_parameters_unspecified_until_it_is_clear_how_to_optimize_them")[#text("to be optimised later")]#text(". Expanding out the exponential and using the independence hypothesis, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n ) = \\prod_{i=1}^n {\\bf E} \\exp(t X_i).")]]

#text("To compute ")#mi("{{\\bf E}\\exp(tX)}")#text(", we use the hypothesis that ")#tao-math("{\\left|X\\right| \\leq 1}", block: false)#text(" and ")#link(<tao-9377b805a4fc064b778f>)[#text("(9)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp(tX) \\leq \\exp( O( t^2 \\sigma_i^2 ) ).")]]

#text("Thus we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n ) \\leq \\exp( O( t^2 \\sigma^2 ) )")]]

#text("and thus by Markov’s inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma ) \\leq \\exp( O( t^2 \\sigma^2 ) - t \\lambda \\sigma ).")]]

#text("If we optimise this in ")#mi("{t}")#text(", subject to the constraint ")#mi("{0 \\leq t \\leq 1}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Informally, the Chernoff inequality asserts that ")#mi("{S_n}")#text(" is sharply concentrated in the range ")#mi("{n \\mu + O(\\sigma \\sqrt{n})}")#text(". The bounds here are fairly sharp, at least when ")#mi("{\\lambda}")#text(" is not too large:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-a2a23b4264cbe2f88b28>#text(" Let ")#mi("{0 < p < 1/2}")#text(" be fixed independently of ")#mi("{n}")#text(", and let ")#mi("{X_1,\\ldots,X_n}")#text(" be iid copies of a Bernoulli random variable that equals ")#mi("{1}")#text(" with probability ")#mi("{p}")#text(", thus ")#mi("{\\mu_i=p}")#text(" and ")#mi("{\\sigma_i^2 = p(1-p)}")#text(", and so ")#mi("{\\mu = np}")#text(" and ")#mi("{\\sigma^2 = np(1-p)}")#text(". Using Stirling’s formula (")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Notes 0a")]#text("), show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n - \\mu\\right| \\geq \\lambda \\sigma ) \\geq c \\exp( - C \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(" and all ")#mi("{\\lambda \\leq c\\sigma}")#text(". What happens when ")#mi("{\\lambda}")#text(" is much larger than ")#mi("{\\sigma}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-744283cd8e5f50d895ef>#text(" Show that the term ")#mi("{\\exp( - c \\lambda \\sigma / K )}")#text(" in ")#link(<tao-76f73c895b3f5ae270a5>)[#text("(11)")]#text(" can be replaced with ")#mi("{(\\lambda K/\\sigma)^{-c \\lambda \\sigma / K}}")#text(" (which is superior when ")#mi("{\\lambda K \\gg \\sigma}")#text("). (")#emph[#text("Hint:")]#text(" Allow ")#mi("{t}")#text(" to exceed ")#mi("{1}")#text(".) Compare this with the results of Exercise ")#link(<tao-a2a23b4264cbe2f88b28>)[#text("2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Hoeffding’s inequality)")]#text(" ")#metadata(none) <tao-64da817f607e940546c5>#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent real variables, with ")#mi("{X_i}")#text(" taking values in an interval ")#mi("{[a_i,b_i]}")#text(", and let ")#mi("{S_n := X_1 + \\ldots + X_n}")#text(". Show that one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n - {\\bf E} S_n\\right| \\geq \\lambda \\sigma ) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(", where ")#tao-math("{\\sigma^2 := \\sum_{i=1}^n \\left|b_i-a_i\\right|^2}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" As we can see, the exponential moment method is very slick compared to the power moment method. Unfortunately, due to its reliance on the identity ")#mi("{e^{X+Y} = e^X e^Y}")#text(", this method relies very strongly on commutativity of the underlying variables, and as such will not be as useful when dealing with noncommutative random variables, and in particular with random matrices. Nevertheless, we will still be able to apply the Chernoff bound to good effect to various components of random matrices, such as rows or columns of such matrices.")
]

#text("The full assumption of joint independence is not completely necessary for Chernoff-type bounds to be present. It suffices to have a ")#link("http://en.wikipedia.org/wiki/Martingale_(probability_theory)")[#text("martingale difference sequence")]#text(", in which each ")#mi("{X_i}")#text(" can depend on the preceding variables ")#mi("{X_1,\\ldots,X_{i-1}}")#text(", but which always has mean zero even when the preceding variables are conditioned out. More precisely, we have ")#link("http://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma’s inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Azuma’s inequality)")]#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be a sequence of scalar random variables with ")#tao-math("{\\left|X_i\\right| \\leq 1}", block: false)#text(" almost surely. Assume also that we have the martingale difference property ")#metadata(none) <tao-df087996d45b03e7eb8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("{\\bf E}( X_i | X_1,\\ldots,X_{i-1} ) = 0")]]

#text("almost surely for all ")#mi("{i=1,\\ldots,n}")#text(" (here we assume the existence of a suitable disintegration in order to define the conditional expectation, though in fact it is possible to state and prove Azuma’s inequality without this disintegration). Then for any ")#mi("{\\lambda > 0}")#text(", the sum ")#mi("{S_n := X_1 + \\ldots + X_n}")#text(" obeys the large deviation inequality ")#metadata(none) <tao-9c9e0fc5c3e0303c15a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("{\\bf P}(\\left|S_n\\right| \\geq \\lambda \\sqrt{n} ) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(".")
]

#text("A typical example of ")#mi("{S_n}")#text(" here is a dependent random walk, in which the magnitude and probabilities of the ")#mi("{i^{th}}")#text(" step are allowed to depend on the outcome of the preceding ")#mi("{i-1}")#text(" steps, but where the mean of each step is always fixed to be zero.")

#emph[#text("Proof:")]#text(" Again, we can reduce to the case when the ")#mi("{X_i}")#text(" are real, and it suffices to establish the upper tail estimate")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(S_n \\geq \\lambda \\sqrt{n} ) \\leq C \\exp( - c \\lambda^2 ).")]]

#text("Note that ")#tao-math("{\\left|S_n\\right| \\leq n}", block: false)#text(" almost surely, so we may assume without loss of generality that ")#mi("{\\lambda \\leq \\sqrt{n}}")#text(".")

#text("Once again, we consider the exponential moment ")#mi("{{\\bf E} \\exp( t S_n )}")#text(" for some parameter ")#mi("{t>0}")#text(". We write ")#mi("{S_n = S_{n-1} + X_n}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n ) = {\\bf E} \\exp( t S_{n-1} ) \\exp( t X_n ).")]]

#text("We do not have independence between ")#mi("{S_{n-1}}")#text(" and ")#mi("{X_n}")#text(", so cannot split the expectation as in the proof of Chernoff’s inequality. Nevertheless we can use conditional expectation as a substitute. We can rewrite the above expression as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} {\\bf E}( \\exp( t S_{n-1} ) \\exp( t X_n ) | X_1,\\ldots,X_{n-1} ).")]]

#text("The quantity ")#mi("{S_{n-1}}")#text(" is deterministic once we condition on ")#mi("{X_1,\\ldots,X_{n-1}}")#text(", and so we can pull it out of the conditional expectation:")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_{n-1} ) {\\bf E}( \\exp( t X_n ) | X_1,\\ldots,X_{n-1} ).")]]

#text("Applying ")#link(<tao-11a5eb5bb9f1cc14358a>)[#text("(10)")]#text(" to the conditional expectation, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( \\exp( t X_n ) | X_1,\\ldots,X_{n-1} ) \\leq \\exp(O(t^2))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n ) \\leq \\exp(O(t^2)) {\\bf E} \\exp(t S_{n-1}).")]]

#text("Iterating this argument gives")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t S_n ) \\leq \\exp(O(n t^2))")]]

#text("and thus by Markov’s inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(S_n \\geq \\lambda \\sqrt{n} ) \\leq \\exp( O(n t^2) - t \\lambda \\sqrt{n} ).")]]

#text("Optimising in ")#mi("{t}")#text(" gives the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Suppose we replace the hypothesis ")#tao-math("{\\left|X_i\\right| \\leq 1}", block: false)#text(" in Azuma’s inequality with the more general hypothesis ")#tao-math("{\\left|X_i\\right| \\leq c_i}", block: false)#text(" for some scalars ")#mi("{c_i > 0}")#text(". Show that we still have ")#link(<tao-9c9e0fc5c3e0303c15a4>)[#text("(13)")]#text(", but with ")#mi("{\\sqrt{n}}")#text(" replaced by ")#mi("{(\\sum_{i=1}^n c_i^2)^{1/2}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The exponential moment method is also used frequently in harmonic analysis to deal with lacunary exponential sums, or sums involving Radamacher functions (which are the analogue of lacunary exponential sums for characteristic ")#mi("{2}")#text("). Examples here include ")#link("http://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(" (and the closely related ")#emph[#text("Kahane’s inequality")]#text("). The exponential moment method also combines very well with log-Sobolev inequalities, as we shall see below (basically because the logarithm inverts the exponential), as well as with the closely related ")#emph[#text("hypercontractivity")]#text(" inequalities.")
]

#heading(level: 1)[#strong[#text(" — 2. The truncation method — ")]]

#text("To summarise the discussion so far, we have identified a number of large deviation inequalities to control a sum ")#mi("{S_n = X_1 + \\ldots + X_n}")#text(":")

#list(
[#text("The zeroth moment method bound ")#link(<tao-f9194e73f9e9459e3450>)[#text("(1)")]#text(", which requires no moment assumptions on the ")#mi("{X_i}")#text(" but is only useful when ")#mi("{X_i}")#text(" is usually zero, and has no decay in ")#mi("{\\lambda}")#text(".")],
[#text("The first moment method bound ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(", which only requires absolute integrability on the ")#mi("{X_i}")#text(", but has only a linear decay in ")#mi("{\\lambda}")#text(".")],
[#text("The second moment method bound ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(", which requires second moment and pairwise independence bounds on ")#mi("{X_i}")#text(", and gives a quadratic decay in ")#mi("{\\lambda}")#text(".")],
[#text("Higher moment bounds ")#link(<tao-bc64a05e6530fc45e1a7>)[#text("(7)")]#text(", which require boundedness and ")#mi("{k}")#text("-wise independence, and give a ")#mi("{k^{th}}")#text(" power decay in ")#mi("{\\lambda}")#text(" (or quadratic-exponential decay, after optimising in ")#mi("{k}")#text(").")],
[#text("Exponential moment bounds such as ")#link(<tao-76f73c895b3f5ae270a5>)[#text("(11)")]#text(" or ")#link(<tao-9c9e0fc5c3e0303c15a4>)[#text("(13)")]#text(", which require boundedness and joint independence (or martingale behaviour), and give quadratic-exponential decay in ")#mi("{\\lambda}")#text(".")]
)

#text("We thus see that the bounds with the strongest decay in ")#mi("{\\lambda}")#text(" require strong boundedness and independence hypotheses. However, one can often partially extend these strong results from the case of bounded random variables to that of unbounded random variables (provided one still has sufficient control on the decay of these variables) by a simple but fundamental trick, known as the ")#emph[#text("truncation method")]#text(". The basic idea here is to take each random variable ")#mi("{X_i}")#text(" and split it as ")#mi("{X_i = X_{i,\\leq N} + X_{i,>N}}")#text(", where ")#mi("{N}")#text(" is a truncation parameter ")#link("http://www.tricki.org/article/Keep_parameters_unspecified_until_it_is_clear_how_to_optimize_them")[#text("to be optimised later")]#text(" (possibly in manner depending on ")#mi("{n}")#text("),")

#align(center)[#tao-fit-display[#tao-math("X_{i,\\leq N} := X_i {\\bf I}(\\left|X_i\\right| \\leq N)", block: true)]]

#text("is the restriction of ")#mi("{X_i}")#text(" to the event that ")#tao-math("{\\left|X_i\\right| \\leq N}", block: false)#text(" (thus ")#mi("{X_{i,\\leq N}}")#text(" vanishes when ")#mi("{X_i}")#text(" is too large), and")

#align(center)[#tao-fit-display[#tao-math("X_{i,> N} := X_i {\\bf I}(\\left|X_i\\right| > N)", block: true)]]

#text("is the complementary event. One can similarly split ")#mi("{S_n = S_{n,\\leq N} + S_{n,>N}}")#text(" where")

#align(center)[#tao-fit-display[#mitex("S_{n,\\leq N} = X_{1,\\leq N} + \\ldots + X_{n,\\leq N}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{n,> N} = X_{1,>N} + \\ldots + X_{n,>N}.")]]

#text("The idea is then to estimate the tail of ")#mi("{S_{n,\\leq N}}")#text(" and ")#mi("{S_{n,>N}}")#text(" by two different means. With ")#mi("{S_{n,\\leq N}}")#text(", the point is that the variables ")#mi("{X_{i,\\leq N}}")#text(" have been made bounded by fiat, and so the more powerful large deviation inequalities can now be put into play. With ")#mi("{S_{n,>N}}")#text(", in contrast, the underlying variables ")#mi("{X_{i,>N}}")#text(" are certainly not bounded, but they tend to have small zeroth and first moments, and so the bounds based on those moment methods tend to be powerful here. (Readers who are familiar with harmonic analysis may recognise this type of ")#link("http://www.tricki.org/article/Divide_and_conquer")[#text("divide and conquer argument")]#text(" as an ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("interpolation argument")]#text(".)")

#text("Let us begin with a simple application of this method.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Weak law of large numbers)")]#text(" Let ")#mi("{X_1,X_2,\\ldots}")#text(" be iid scalar random variables with ")#mi("{X_i \\equiv X}")#text(" for all ")#mi("{i}")#text(", where ")#mi("{X}")#text(" is absolutely integrable. Then ")#mi("{S_n/n}")#text(" converges in probability to ")#mi("{{\\bf E} X}")#text(".")
]

#emph[#text("Proof:")]#text(" By subtracting ")#mi("{{\\bf E} X}")#text(" from ")#mi("{X}")#text(" we may assume without loss of generality that ")#mi("{X}")#text(" has mean zero. Our task is then to show that ")#tao-math("{{\\bf P}( \\left|S_n\\right| \\geq \\epsilon n ) = o(1)}", block: false)#text(" for all fixed ")#mi("{\\epsilon > 0}")#text(".")

#text("If ")#mi("{X}")#text(" has finite variance, then the claim follows from ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(". If ")#mi("{X}")#text(" has infinite variance, we cannot apply ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" directly, but we may perform the truncation method as follows. Let ")#mi("{N}")#text(" be a large parameter to be chosen later, and split ")#mi("{X_i = X_{i,\\leq N} + X_{i,> N}}")#text(", ")#mi("{S_n = S_{n,\\leq N} + S_{n,> N}}")#text(" (and ")#mi("{X = X_{\\leq N} + X_{>N}}")#text(") as discussed above. The variable ")#mi("{X_{\\leq N}}")#text(" is bounded and thus has bounded variance; also, from the dominated convergence theorem we see that ")#tao-math("{\\left|{\\bf E} X_{\\leq N}\\right| \\leq \\epsilon/4}", block: false)#text(" (say) if ")#mi("{N}")#text(" is large enough. From ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,\\leq N}\\right| \\geq \\epsilon n / 2 ) = o(1)", block: true)]]

#text("(where the rate of decay here depends on ")#mi("{N}")#text(" and ")#mi("{\\epsilon}")#text("). Meanwhile, to deal with the tail ")#mi("{X_{>N}}")#text(" we use ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,>N}\\right| \\geq \\epsilon n / 2 ) \\leq \\frac{2}{\\epsilon} {\\bf E} |X_{>N}|.", block: true)]]

#text("But by the dominated convergence theorem (or monotone convergence theorem), we may make ")#tao-math("{{\\bf E} \\left|X_{>N}\\right|}", block: false)#text(" as small as we please (say, smaller than ")#mi("{\\delta > 0}")#text(") by taking ")#mi("{N}")#text(" large enough. Summing, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n}\\right| \\geq \\epsilon n ) = \\frac{2}{\\epsilon} \\delta + o(1);", block: true)]]

#text("since ")#mi("{\\delta}")#text(" is arbitrary, we obtain the claim. ")#mi("\\Box")

#text("A more sophisticated variant of this argument (which I gave in this ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("earlier blog post")]#text(", which also has some further discussion and details) gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Strong law of large numbers)")]#text(" Let ")#mi("{X_1,X_2,\\ldots}")#text(" be iid scalar random variables with ")#mi("{X_i \\equiv X}")#text(" for all ")#mi("{i}")#text(", where ")#mi("{X}")#text(" is absolutely integrable. Then ")#mi("{S_n/n}")#text(" converges almost surely to ")#mi("{{\\bf E} X}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume without loss of generality that ")#mi("{X}")#text(" is real, since the complex case then follows by splitting into real and imaginary parts. By splitting ")#mi("{X}")#text(" into positive and negative parts, we may furthermore assume that ")#mi("{X}")#text(" is non-negative. (Of course, by doing so, we can no longer normalise ")#mi("{X}")#text(" to have mean zero, but for us the non-negativity will be more convenient than the zero mean property.) In particular, ")#mi("{S_n}")#text(" is now non-decreasing in ")#mi("{n}")#text(".")

#text("Next, we apply a sparsification trick. Let ")#mi("{0 < \\epsilon < 1}")#text(". Suppose that we knew that, almost surely, ")#mi("{S_{n_m}/{n_m}}")#text(" converged to ")#mi("{{\\bf E} X}")#text(" for ")#mi("{n=n_m}")#text(" of the form ")#mi("{n_m := \\lfloor (1+\\epsilon)^m \\rfloor}")#text(" for some integer ")#mi("{m}")#text(". Then, for all other values of ")#mi("{n}")#text(", we see that asymptotically, ")#mi("{S_n/n}")#text(" can only fluctuate by a multiplicative factor of ")#mi("{1+O(\\epsilon)}")#text(", thanks to the monotone nature of ")#mi("{S_n}")#text(". Because of this and countable additivity, we see that it suffices to show that ")#mi("{S_{n_m}/{n_m}}")#text(" converges to ")#mi("{{\\bf E} X}")#text(". Actually, it will be enough to show that almost surely, one has ")#tao-math("{\\left|S_{n_m}/{n_m} - {\\bf E} X\\right| \\leq \\epsilon}", block: false)#text(" for all but finitely many ")#mi("{m}")#text(".")

#text("Fix ")#mi("{\\epsilon}")#text(". As before, we split ")#mi("{X = X_{>N_m} + X_{\\leq N_m}}")#text(" and ")#mi("{S_{n_m} = S_{n_m,>N_m} + S_{n_m,\\leq N_m}}")#text(", but with the twist that we now allow ")#mi("{N = N_m}")#text(" to depend on ")#mi("{m}")#text(". Then for ")#mi("{N_m}")#text(" large enough we have ")#tao-math("{\\left|{\\bf E} X_{\\leq N_m} - {\\bf E} X\\right| \\leq \\epsilon/2}", block: false)#text(" (say), by dominated convergence. Applying ")#link(<tao-db939c40a9f78e7d5011>)[#text("(5)")]#text(" as before, we see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n_m,\\leq N_m}/{n_m} - {\\bf E} X\\right| > \\epsilon ) \\leq \\frac{C_\\epsilon}{n_m} {\\bf E} \\left|X_{\\leq N_m}\\right|^2", block: true)]]

#text("for some ")#mi("{C_\\epsilon}")#text(" depending only on ")#mi("{\\epsilon}")#text(" (the exact value is not important here). To handle the tail, we will not use the first moment bound ")#link(<tao-7c3d546c231b36cd6731>)[#text("(2)")]#text(" as done previously, but now turn to the zeroth-moment bound ")#link(<tao-f9194e73f9e9459e3450>)[#text("(1)")]#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( S_{n_m, >N_m} \\neq 0 ) \\leq n_m {\\bf P}( \\left|X\\right| > N_m );", block: true)]]

#text("summing, we conclude")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n_m}/{n_m} - {\\bf E} X\\right| > \\epsilon ) \\leq \\frac{C_\\epsilon}{n_m} {\\bf E} \\left|X_{\\leq N_m}\\right|^2 + n_m {\\bf P}( \\left|X\\right| > N_m ).", block: true)]]

#text("Applying the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(" (Exercise 1 from ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory")[#text("Notes 0")]#text("), we see that we will be done as long as we can choose ")#mi("{N_m}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m=1}^\\infty \\frac{1}{n_m} {\\bf E} \\left|X_{\\leq N_m}\\right|^2", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m=1}^\\infty n_m {\\bf P}( \\left|X\\right| > N_m )", block: true)]]

#text("are both finite. But this can be accomplished by setting ")#mi("{N_m := n_m}")#text(" and interchanging the sum and expectations (writing ")#tao-math("{{\\bf P}( \\left|X\\right| > N_m )}", block: false)#text(" as ")#tao-math("{{\\bf E} {\\bf I}(\\left|X\\right| > N_m)}", block: false)#text(") and using the lacunary nature of the ")#mi("{n_m}")#text(". ")#mi("\\Box")

#text("To give another illustration of the truncation method, we extend a version of the Chernoff bound to the subgaussian case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" be iid copies of a subgaussian random variable ")#mi("{X}")#text(", thus ")#mi("{X}")#text(" obeys a bound of the form ")#metadata(none) <tao-00645195b93272275b50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("{\\bf P}(\\left|X\\right| \\geq t) \\leq C \\exp( - c t^2 )", block: true)]]

#text("for all ")#mi("{t>0}")#text(" and some ")#mi("{C,c>0}")#text(". Let ")#mi("{S_n := X_1+\\ldots+X_n}")#text(". Then for any sufficiently large ")#mi("{A}")#text(" (independent of ")#mi("{n}")#text(") we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n - n {\\bf E} X\\right| \\geq A n ) \\leq C_A \\exp( - c_A n )", block: true)]]

#text("for some constants ")#mi("{C_A, c_A}")#text(" depending on ")#mi("{A,p,C,c}")#text(". Furthermore, ")#mi("{c_A}")#text(" grows linearly in ")#mi("{A}")#text(" as ")#mi("{A \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" By subtracting the mean from ")#mi("{X}")#text(" we may normalise ")#mi("{{\\bf E} X = 0}")#text(". We perform a dyadic decomposition")

#align(center)[#tao-fit-display[#mitex("X_i = X_{i,0} + \\sum_{m=1}^\\infty X_{i,m}")]]

#text("where ")#tao-math("{X_{i,0} := X_i {\\bf I}(\\left|X_i\\right| \\leq 1)}", block: false)#text(" and ")#tao-math("{X_{i,m} := X_i {\\bf I}(2^{m-1} < \\left|X_i\\right| \\leq 2^m)}", block: false)#text(". We similarly split")

#align(center)[#tao-fit-display[#mitex("S_n = S_{n,0} + \\sum_{m=1}^\\infty S_{n,m}")]]

#text("where ")#mi("{S_{n,m} = \\sum_{i=1}^n X_{i,m}}")#text(". Then by the union bound and the pigeonhole principle we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n\\right| \\geq A n ) \\leq \\sum_{m=0}^\\infty {\\bf P}( \\left|S_{n,m}\\right| \\geq \\frac{A}{100(m+1)^2} n )", block: true)]]

#text("(say). Each ")#mi("{X_{i,m}}")#text(" is clearly bounded in magnitude by ")#mi("{2^m}")#text("; from the subgaussian hypothesis one can also verify that the mean and variance of ")#mi("{X_{i,m}}")#text(" are at most ")#mi("{C^{\\prime} \\exp( - c^{\\prime} 2^{2m} )}")#text(" for some ")#mi("{C^{\\prime}, c^{\\prime} > 0}")#text(". If ")#mi("{A}")#text(" is large enough, an application of the Chernoff bound ")#link(<tao-76f73c895b3f5ae270a5>)[#text("(11)")]#text(" (or more precisely, the refinement in Exercise ")#link(<tao-744283cd8e5f50d895ef>)[#text("3")]#text(") then gives (after some computation)")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,m}\\right| \\geq \\frac{A}{100(m+1)^2} n ) \\leq C^{\\prime} 2^{-m} \\exp( - c^{\\prime} A n )", block: true)]]

#text("(say) for some ")#mi("{C^{\\prime}, c^{\\prime} > 0}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that the hypothesis that ")#mi("{A}")#text(" is sufficiently large can be replaced by the hypothesis that ")#mi("{A>0}")#text(" is independent of ")#mi("{n}")#text(". ")#emph[#text("Hint:")]#text(" There are several approaches available. One can adapt the above proof; one can modify the proof of the Chernoff inequality directly; or one can figure out a way to deduce the small ")#mi("{A}")#text(" case from the large ")#mi("{A}")#text(" case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that the subgaussian hypothesis can be generalised to a sub-exponential tail hypothesis")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left|X\\right| \\geq t) \\leq C \\exp( - c t^p )", block: true)]]

#text("provided that ")#mi("{p>1}")#text(". Show that the result also extends to the case ")#mi("{0 < p \\leq 1}")#text(", except with the exponent ")#mi("{\\exp( - c_A n )}")#text(" replaced by ")#mi("{\\exp( - c_A n^{p-\\epsilon} )}")#text(" for some ")#mi("{\\epsilon > 0}")#text(". (I do not know if the ")#mi("{\\epsilon}")#text(" loss can be removed, but it is easy to see that one cannot hope to do much better than this, just by considering the probability that ")#mi("{X_1}")#text(" (say) is already as large as ")#mi("{An}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 3. Lipschitz combinations — ")]]

#text("In the preceding discussion, we had only considered the linear combination ")#mi("{X_1,\\ldots,X_n}")#text(" of independent variables ")#mi("{X_1,\\ldots,X_n}")#text(". Now we consider more general combinations ")#mi("{F(X)}")#text(", where we write ")#mi("{X := (X_1,\\ldots,X_n)}")#text(" for short. Of course, to get any non-trivial results we must make some regularity hypotheses on ")#mi("{F}")#text(". It turns out that a particularly useful class of regularity hypothesis here is a Lipschitz hypothesis – that small variations in ")#mi("{X}")#text(" lead to small variations in ")#mi("{F(X)}")#text(". A simple example of this is ")#link("http://en.wikipedia.org/wiki/McDiarmid's_inequality")[#text("McDiarmid’s inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (McDiarmid’s inequality)")]#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent random variables taking values in ranges ")#mi("{R_1,\\ldots,R_n}")#text(", and let ")#mi("{F: R_1 \\times \\ldots \\times R_n \\rightarrow {\\bf C}}")#text(" be a function with the property that if one freezes all but the ")#mi("{i^{th}}")#text(" coordinate of ")#mi("{F(x_1,\\ldots,x_n)}")#text(" for some ")#mi("{1 \\leq i \\leq n}")#text(", then ")#mi("{F}")#text(" only fluctuates by most ")#mi("{c_i > 0}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("|F(x_1,\\ldots,x_{i-1},x_i,x_{i+1},\\ldots,x_n) -")]]

#align(center)[#tao-fit-display[#mitex("F(x_1,\\ldots,x_{i-1},x_i^{\\prime},x_{i+1},\\ldots,x_n)| \\leq c_i")]]

#text("for all ")#mi("{x_j \\in X_j}")#text(", ")#mi("{x^{\\prime}_i \\in X_i}")#text(" for ")#mi("{1 \\leq j \\leq n}")#text(". Then for any ")#mi("{\\lambda > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|F(X) - {\\bf E} F(X)\\right| \\geq \\lambda \\sigma ) \\leq C \\exp(- c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C,c>0}")#text(", where ")#mi("{\\sigma^2 := \\sum_{i=1}^n c_i^2}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{F}")#text(" is real. By symmetry, it suffices to show the one-sided estimate ")#metadata(none) <tao-22e4f6912a6980d6fd59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\bf P}( F(X) - {\\bf E} F(X) \\geq \\lambda \\sigma^2 ) \\leq C \\exp(- c \\lambda^2 ).")]]

#text("To compute this quantity, we again use the exponential moment method. Let ")#mi("{t > 0}")#text(" be a parameter to be chosen later, and consider the exponential moment ")#metadata(none) <tao-0b1759a5f76eea6cea79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("{\\bf E} \\exp( t F(X) ).")]]

#text("To compute this, let us condition ")#mi("{X_1,\\ldots,X_{n-1}}")#text(" to be fixed, and look at the conditional expectation")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(\\exp( t F(X) ) | X_1,\\ldots,X_{n-1} ).")]]

#text("We can simplify this as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( \\exp( t Y) | X_1,\\ldots,X_{n-1} ) \\exp( t {\\bf E}(F(X)|X_1,\\ldots,X_{n-1}) )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("Y := F(X) - {\\bf E}( F(X)|X_1,\\ldots,X_{n-1})")]]

#text("For ")#mi("{X_1,\\ldots,X_{n-1}}")#text(" fixed, ")#mi("{tY}")#text(" only fluctuates by at most ")#mi("{t c_n}")#text(" and has mean zero. Applying ")#link(<tao-11a5eb5bb9f1cc14358a>)[#text("(10)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( \\exp( t Y) | X_1,\\ldots,X_{n-1} ) \\leq \\exp( O( t^2 c_n^2 ) ).")]]

#text("Integrating out the conditioning, we see that we have upper bounded ")#link(<tao-0b1759a5f76eea6cea79>)[#text("(16)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\exp(O(t^2 c_n^2)) {\\bf E} \\exp( t ({\\bf E}(F(X)|X_1,\\ldots,X_{n-1}) ).")]]

#text("We observe that ")#mi("{({\\bf E}(F(X)|X_1,\\ldots,X_{n-1})}")#text(" is a function ")#mi("{F_{n-1}(X_1,\\ldots,X_{n-1})}")#text(" of ")#mi("{X_1,\\ldots,X_{n-1}}")#text(", where ")#mi("{F_{n-1}}")#text(" obeys the same hypotheses as ")#mi("{F}")#text(" (but for ")#mi("{n-1}")#text(" instead of ")#mi("{n}")#text("). We can then iterate the above computation ")#mi("{n}")#text(" times and eventually upper bound ")#link(<tao-0b1759a5f76eea6cea79>)[#text("(16)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\exp(\\sum_{i=1}^n O(t^2 c_i^2) ) \\exp( t {\\bf E} F(X) ),")]]

#text("which we rearrange as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t (F(X) - {\\bf E} F(X)) ) \\leq \\exp( O(t^2 \\sigma^2) ),")]]

#text("and thus by Markov’s inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( F(X) - {\\bf E} F(X) \\geq \\lambda \\sigma ) \\leq \\exp( O( t^2 \\sigma^2 ) - t \\lambda \\sigma ).")]]

#text("Optimising in ")#mi("{t}")#text(" then gives the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that McDiarmid’s inequality implies Hoeffding’s inequality (Exercise ")#link(<tao-64da817f607e940546c5>)[#text("4")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" One can view McDiarmid’s inequality as a ")#emph[#text("tensorisation")]#text(" of Hoeffding’s lemma, as it leverages the latter lemma for a single random variable to establish an analogous result for ")#mi("{n}")#text(" random variables. It is possible to apply this tensorisation trick to random variables taking values in more sophisticated metric spaces than an interval ")#mi("{[a,b]}")#text(", leading to a class of concentration of measure inequalities known as ")#emph[#text("transportation cost-information inequalities")]#text(", which will not be discussed here.")
]

#text("The most powerful concentration of measure results, though, do not just exploit Lipschitz type behaviour in each individual variable, but ")#emph[#text("joint")]#text(" Lipschitz behaviour. Let us first give a classical instance of this, in the special case when the ")#mi("{X_1,\\ldots,X_n}")#text(" are gaussian variables. A key property of gaussian variables is that any linear combination of independent gaussians is again an independent gaussian:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-3b8d14199277153e41ea>#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent real gaussian variables with ")#mi("{X_i = N(\\mu_i,\\sigma_i^2)_{\\bf R}}")#text(", and let ")#mi("{c_1,\\ldots,c_n}")#text(" be real constants. Show that ")#mi("{c_1 X_1 +\\ldots + c_n X_n}")#text(" is a real gaussian with mean ")#mi("{\\sum_{i=1}^n c_i \\mu_i}")#text(" and variance ")#tao-math("{\\sum_{i=1}^n \\left|c_i\\right|^2 \\sigma_i^2}", block: false)#text(".")

#text("Show that the same claims also hold with complex gaussians and complex constants ")#mi("{c_i}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Rotation invariance)")]#text(" ")#metadata(none) <tao-7ec879c8c860699e2314>#text(" Let ")#mi("{X = (X_1,\\ldots,X_n)}")#text(" be an ")#mi("{{\\bf R}^n}")#text("-valued random variable, where ")#mi("{X_1,\\ldots,X_n \\equiv N(0,1)_{\\bf R}}")#text(" are iid real gaussians. Show that for any orthogonal matrix ")#mi("{U \\in O(n)}")#text(", ")#mi("{UX \\equiv X}")#text(".")

#text("Show that the same claim holds for complex gaussians (so ")#mi("{X}")#text(" is now ")#mi("{{\\bf C}^n}")#text("-valued), and with the orthogonal group ")#mi("{O(n)}")#text(" replaced by the unitary group ")#mi("{U(n)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Gaussian concentration inequality for Lipschitz functions)")]#text(" ")#metadata(none) <tao-72fcc7c75a4c404af794>#text(" Let ")#mi("{X_1,\\ldots,X_n \\equiv N(0,1)_{\\bf R}}")#text(" be iid real gaussian variables, and let ")#mi("{F: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" be a ")#mi("{1}")#text("-Lipschitz function (i.e. ")#tao-math("{\\left|F(x)-F(y)\\right| \\leq \\left|x-y\\right|}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}^n}")#text(", where we use the Euclidean metric on ")#mi("{{\\bf R}^n}")#text("). Then for any ")#mi("{\\lambda}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|F(X) - {\\bf E} F(X)\\right| \\geq \\lambda ) \\leq C \\exp(-c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the following elegant argument of Maurey and Pisier. By subtracting a constant from ")#mi("{F}")#text(", we may normalise ")#mi("{{\\bf E} F(X) = 0}")#text(". By symmetry it then suffices to show the upper tail estimate")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( F(X) \\geq \\lambda ) \\leq C \\exp(-c \\lambda^2 ).")]]

#text("By smoothing ")#mi("{F}")#text(" slightly we may assume that ")#mi("{F}")#text(" is smooth, since the general case then follows from a ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("limiting argument")]#text(". In particular, the Lipschitz bound on ")#mi("{F}")#text(" now implies the gradient estimate ")#metadata(none) <tao-042117d225289e91dc14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|\\nabla F(x)\\right| \\leq 1", block: true)]]

#text("for all ")#mi("{x \\in {\\bf R}^n}")#text(".")

#text("Once again, we use the exponential moment method. It will suffice to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t F(X) ) \\leq \\exp( C t^2 )")]]

#text("for some constant ")#mi("{C>0}")#text(" and all ")#mi("{t>0}")#text(", as the claim follows from Markov’s inequality and optimisation in ")#mi("{t}")#text(" as in previous arguments.")

#text("To exploit the Lipschitz nature of ")#mi("{F}")#text(", we will need to introduce a second copy of ")#mi("{F(X)}")#text(". Let ")#mi("{Y}")#text(" be an independent copy of ")#mi("{X}")#text(". Since ")#mi("{{\\bf E} F(Y) = 0}")#text(", we see from Jensen’s inequality that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( - t F(Y) ) \\geq 1")]]

#text("and thus (by independence of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(")")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t F(X) ) \\leq {\\bf E} \\exp( t (F(X) - F(Y)) ).")]]

#text("It is tempting to use the fundamental theorem of calculus along a line segment,")

#align(center)[#tao-fit-display[#mitex("F(X) - F(Y) = \\int_0^1 \\frac{d}{dt} F((1-t) Y + t X)\\ dt,")]]

#text("to estimate ")#mi("{F(X)-F(Y)}")#text(", but it turns out for technical reasons to be better to use a circular arc instead,")

#align(center)[#tao-fit-display[#mitex("F(X) - F(Y) = \\int_0^{\\pi/2} \\frac{d}{d\\theta} F(Y \\cos \\theta + X \\sin \\theta)\\ d\\theta,")]]

#text("The reason for this is that ")#mi("{X_\\theta := Y \\cos \\theta + X \\sin \\theta}")#text(" is another gaussian random variable equivalent to ")#mi("{X}")#text(", as is its derivative ")#mi("{X^{\\prime}_\\theta := -Y \\sin \\theta + X \\cos \\theta}")#text(" (by Exercise ")#link(<tao-3b8d14199277153e41ea>)[#text("9")]#text("); furthermore, and crucially, these two random variables are ")#emph[#text("independent")]#text(" (by Exercise ")#link(<tao-7ec879c8c860699e2314>)[#text("10")]#text(").")

#text("To exploit this, we first use Jensen’s inequality to bound")

#align(center)[#tao-fit-display[#mitex("\\exp( t (F(X) - F(Y))) \\leq \\frac{2}{\\pi} \\int_0^{\\pi/2} \\exp( \\frac{\\pi t}{2} \\frac{d}{d\\theta} F( X_\\theta ) )\\ d\\theta.")]]

#text("Applying the chain rule and taking expectations, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t (F(X) - F(Y))) \\leq \\frac{2}{\\pi} \\int_0^{\\pi/2} {\\bf E} \\exp( \\frac{\\pi t}{2} \\nabla F( X_\\theta ) \\cdot X^{\\prime}_\\theta )\\ d\\theta.")]]

#text("Let us condition ")#mi("{X_\\theta}")#text(" to be fixed, then ")#mi("{X^{\\prime}_\\theta \\equiv X}")#text("; applying Exercise ")#link(<tao-3b8d14199277153e41ea>)[#text("9")]#text(" and ")#link(<tao-042117d225289e91dc14>)[#text("(17)")]#text(", we conclude that ")#mi("{\\frac{\\pi t}{2} \\nabla F( X_\\theta ) \\cdot X^{\\prime}_\\theta}")#text(" is normally distributed with standard deviation at most ")#mi("{\\frac{\\pi t}{2}}")#text(". As such we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( \\frac{\\pi t}{2} \\nabla F( X_\\theta ) \\cdot X^{\\prime}_\\theta ) \\leq \\exp( C t^2 )")]]

#text("for some absolute constant ")#mi("{C}")#text("; integrating out the conditioning on ")#mi("{X_\\theta}")#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Show that Theorem ")#link(<tao-72fcc7c75a4c404af794>)[#text("8")]#text(" is equivalent to the inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X \\in A) {\\bf P}(X \\not \\in A_\\lambda) \\leq C \\exp(-c \\lambda^2)")]]

#text("holding for all ")#mi("{\\lambda > 0}")#text(" and all measurable sets ")#mi("{A}")#text(", where ")#mi("{X = (X_1,\\ldots,X_n)}")#text(" is an ")#mi("{{\\bf R}^n}")#text("-valued random variable with iid gaussian components ")#mi("{X_1,\\ldots,X_n \\equiv N(0,1)_{\\bf R}}")#text(", and ")#mi("{A_\\lambda}")#text(" is the ")#mi("{\\lambda}")#text("-neighbourhood of ")#mi("{A}")#text(".")
]

#text("Now we give a powerful concentration inequality of Talagrand, which we will rely heavily on later in this course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Talagrand concentration inequality)")]#text(" ")#metadata(none) <tao-db3202a38d8d898db285>#text(" Let ")#mi("{K > 0}")#text(", and let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent complex variables with ")#tao-math("{\\left|X_i\\right| \\leq K}", block: false)#text(" for all ")#mi("{1 \\leq i \\leq n}")#text(". Let ")#mi("{F: {\\bf C}^n \\rightarrow {\\bf R}}")#text(" be a ")#mi("{1}")#text("-Lipschitz convex function (where we identify ")#mi("{{\\bf C}^n}")#text(" with ")#mi("{{\\bf R}^{2n}}")#text(" for the purposes of defining “Lipschitz” and “convex”). Then for any ")#mi("{\\lambda}")#text(" one has ")#metadata(none) <tao-9018c6e34545f42a6342>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("{\\bf P}( \\left|F(X) - {\\bf M} F(X)\\right| \\geq \\lambda K ) \\leq C \\exp(-c \\lambda^2 )", block: true)]]

#text("and ")#metadata(none) <tao-4894b8426fe4a062c840>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("{\\bf P}( \\left|F(X) - {\\bf E} F(X)\\right| \\geq \\lambda K ) \\leq C \\exp(-c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(", where ")#mi("{{\\bf M} F(X)}")#text(" is a median of ")#mi("{F(X)}")#text(".")
]

#text("We now prove the theorem, following the ")#link("http://www.ams.org/mathscinet-getitem?mr=1361756")[#text("remarkable argument of Talagrand")]#text(".")

#text("By dividing through by ")#mi("{K}")#text(" we may normalise ")#mi("{K=1}")#text(". ")#mi("{X}")#text(" now takes values in the convex set ")#mi("{\\Omega^n \\subset {\\bf C}^n}")#text(", where ")#mi("{\\Omega}")#text(" is the unit disk in ")#mi("{{\\bf C}}")#text(". It will suffice to establish the inequality ")#metadata(none) <tao-76e34c4548e2a2975f93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("{\\bf E} \\exp( c d(X,A)^2 ) \\leq \\frac{1}{{\\bf P}(X \\in A) }")]]

#text("for any convex set ")#mi("{A}")#text(" in ")#mi("{\\Omega^n}")#text(" and some absolute constant ")#mi("{c>0}")#text(", where ")#mi("{d(X,A)}")#text(" is the Euclidean distance between ")#mi("{X}")#text(" and ")#mi("{A}")#text(". Indeed, if one obtains this estimate, then one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( F(X) \\leq x ) {\\bf P}( F(X) \\geq y ) \\leq \\exp( - c \\left|x-y\\right|^2 )", block: true)]]

#text("for any ")#mi("{y > x}")#text(" (as can be seen by applying ")#link(<tao-76e34c4548e2a2975f93>)[#text("(20)")]#text(" to the convex set ")#mi("{A := \\{ z \\in \\Omega^n: F(z) \\leq x \\}}")#text("). Applying this inequality of one of ")#mi("{x,y}")#text(" equal to the median ")#mi("{{\\bf M} F(X)}")#text(" of ")#mi("{F(X)}")#text(" yields ")#link(<tao-9018c6e34545f42a6342>)[#text("(18)")]#text(", which in turn implies that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} F(X) = {\\bf M} F(X) + O( 1 ),")]]

#text("which then gives ")#link(<tao-4894b8426fe4a062c840>)[#text("(19)")]#text(".")

#text("We would like to establish ")#link(<tao-76e34c4548e2a2975f93>)[#text("(20)")]#text(" by induction on dimension ")#mi("{n}")#text(". In the case when ")#mi("{X_1,\\ldots,X_n}")#text(" are Bernoulli variables, this can be done; see this ")#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/")[#text("previous blog post")]#text(". In the general case, it turns out that in order to close the induction properly, one must strengthen ")#link(<tao-76e34c4548e2a2975f93>)[#text("(20)")]#text(" by replacing the Euclidean distance ")#mi("{d(X,A)}")#text(" by an essentially larger quantity, which I will call the ")#emph[#text("combinatorial distance")]#text(" ")#mi("{d_c(X,A)}")#text(" from ")#mi("{X}")#text(" to ")#mi("{A}")#text(". For each vector ")#mi("{z = (z_1,\\ldots,z_n) \\in {\\bf C}^n}")#text(" and ")#mi("{\\omega = (\\omega_1,\\ldots,\\omega_n) \\in \\{0,1\\}^n}")#text(", we say that ")#mi("{\\omega}")#text(" ")#emph[#text("supports")]#text(" ")#mi("{z}")#text(" if ")#mi("{z_i}")#text(" is non-zero only when ")#mi("{\\omega_i}")#text(" is non-zero. Define the ")#emph[#text("combinatorial support")]#text(" ")#mi("{U_A(X)}")#text(" of ")#mi("{A}")#text(" relative to ")#mi("{X}")#text(" to be all the vectors in ")#mi("{\\{0,1\\}^n}")#text(" that support at least one vector in ")#mi("{A-X}")#text(". Define the ")#emph[#text("combinatorial hull")]#text(" ")#mi("{V_A(X)}")#text(" of ")#mi("{A}")#text(" relative to ")#mi("{X}")#text(" to be the convex hull of ")#mi("{U_A(X)}")#text(", and then define the ")#emph[#text("combinatorial distance")]#text(" ")#mi("{d_c(X,A)}")#text(" to be the distance between ")#mi("{V_A(X)}")#text(" and the origin.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Combinatorial distance controls Euclidean distance)")]#text(" Let ")#mi("{A}")#text(" be a convex subset of ")#mi("{\\Omega^n}")#text(". ")#mi("{d(X,A) \\leq 2 d_c(X,A)}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose ")#mi("{d_c(X,A) \\leq r}")#text(". Then there exists a convex combination ")#mi("{t = (t_1,\\ldots,t_n)}")#text(" of elements ")#mi("{\\omega \\in U_A(X) \\subset \\{0,1\\}^n}")#text(" which has magnitude at most ")#mi("{r}")#text(". For each such ")#mi("{\\omega \\in U_A(X)}")#text(", we can find a vector ")#mi("{z_\\omega \\in A-X}")#text(" supported by ")#mi("{\\omega}")#text(". As ")#mi("{A, X}")#text(" both lie in ")#mi("{\\Omega^n}")#text(", every coefficient of ")#mi("{z_\\omega}")#text(" has magnitude at most ")#mi("{2}")#text(", and is thus bounded in magnitude by twice the corresponding coefficent of ")#mi("{\\omega}")#text(". If we then let ")#mi("{z_t}")#text(" be the convex combination of the ")#mi("{z_\\omega}")#text(" indicated by ")#mi("{t}")#text(", then the magnitude of each coefficient of ")#mi("{z_t}")#text(" is bounded by twice the corresponding coefficient of ")#mi("{t}")#text(", and so ")#tao-math("{\\left|z_t\\right| \\leq 2r}", block: false)#text(". On the other hand, as ")#mi("{A}")#text(" is convex, ")#mi("{z_t}")#text(" lies in ")#mi("{A-X}")#text(", and so ")#mi("{d(X,A) \\leq 2r}")#text(". The claim follows. ")#mi("\\Box")

#text("Thus to show ")#link(<tao-76e34c4548e2a2975f93>)[#text("(20)")]#text(" it suffices (after a modification of the constant ")#mi("{c}")#text(") to show that ")#metadata(none) <tao-936e792556875bc4f61f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("{\\bf E} \\exp( c d_c(X,A)^2 ) \\leq \\frac{1}{{\\bf P}(X \\in A)}.")]]

#text("We first verify the one-dimensional case. In this case, ")#mi("{d_c(X,A)}")#text(" equals ")#mi("{1}")#text(" when ")#mi("{X \\not \\in A}")#text(", and ")#mi("{0}")#text(" otherwise, and the claim follows from elementary calculus (for ")#mi("{c}")#text(" small enough).")

#text("Now suppose that ")#mi("{n > 1}")#text(" and the claim has already been proven for ")#mi("{n-1}")#text(". We write ")#mi("{X=(X^{\\prime},X_n)}")#text(", and let ")#mi("{A_{X_n} := \\{ z^{\\prime} \\in \\Omega^{n-1}: (z^{\\prime},X_n) \\in A \\}}")#text(" be a slice of ")#mi("{A}")#text(". We also let ")#mi("{B := \\{ z^{\\prime} \\in \\Omega^{n-1}: (z^{\\prime},t) \\in A \\text{ for some } t \\in \\Omega \\}}")#text(". We have the following basic inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" For any ")#mi("{0 \\leq \\lambda \\leq 1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("d_c(X,A)^2 \\leq (1-\\lambda)^2 + \\lambda d_c(X^{\\prime},A_{X_n})^2 + (1-\\lambda) d_c(X^{\\prime},B)^2.")]]
]

#emph[#text("Proof:")]#text(" Observe that ")#mi("{U_A(X)}")#text(" contains both ")#mi("{U_{A_{X_n}}(X^{\\prime}) \\times \\{0\\}}")#text(" and ")#mi("{(U_{B}(X^{\\prime}) \\backslash U_{A_{X_n}}(X^{\\prime})) \\times \\{1\\}}")#text(", and so by convexity, ")#mi("{V_A(X)}")#text(" contains one of ")#mi("{(\\lambda t + (1-\\lambda) u, 1-\\lambda)}")#text(" or ")#mi("{(\\lambda t + (1-\\lambda) u, 0)}")#text(" whenever ")#mi("{t \\in V_{A_{X_n}}(X^{\\prime})}")#text(" and ")#mi("{u \\in V_{B}(X^{\\prime})}")#text(". The claim then follows from Pythagoras’ theorem and the Cauchy-Schwarz inequality. ")#mi("\\Box")

#text("Let us now freeze ")#mi("{X_n}")#text(" and consider the conditional expectation")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (\\exp( c d_c(X,A)^2 )|X_n).")]]

#text("Using the above lemma (with some ")#mi("{\\lambda}")#text(" depending on ")#mi("{X_n}")#text(" to be chosen later), we may bound the left-hand side of ")#link(<tao-936e792556875bc4f61f>)[#text("(21)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("e^{c(1-\\lambda)^2} {\\bf E}((e^{c d_c(X^{\\prime},A_{X_n})})^\\lambda (e^{c d_c(X^{\\prime},B)})^{1-\\lambda}|X_n);")]]

#text("applying Hölder’s inequality and the induction hypothesis ")#link(<tao-936e792556875bc4f61f>)[#text("(21)")]#text(", we can bound this by")

#align(center)[#tao-fit-display[#mitex("e^{c(1-\\lambda)^2} \\frac{1}{{\\bf P}(X^{\\prime} \\in A_{X_n}|X_n)^\\lambda {\\bf P}(X^{\\prime} \\in B|X_n)^{1-\\lambda}}")]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{{\\bf P}(X^{\\prime} \\in B)} e^{c(1-\\lambda)^2} r^{-\\lambda}")]]

#text("where ")#mi("{r := {\\bf P}(X^{\\prime} \\in A_{X_n}|X_n) / {\\bf P}(X^{\\prime} \\in B)}")#text(" (here we note that the event ")#mi("{X^{\\prime} \\in B}")#text(" is independent of ")#mi("{X_n}")#text("). Note that ")#mi("{0 \\leq r \\leq 1}")#text(". We then apply the elementary inequality")

#align(center)[#tao-fit-display[#mitex("\\inf_{0 \\leq \\lambda \\leq 1} e^{c(1-\\lambda)^2} r^{-\\lambda} \\leq 2-r,")]]

#text("which can be verified by elementary calculus if ")#mi("{c}")#text(" is small enough (in fact one can take ")#mi("{c=1/4}")#text("). We conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (\\exp( c d_c(X,A)^2 )|X_n) \\leq \\frac{1}{{\\bf P}(X^{\\prime} \\in B)} ( 2 - \\frac{{\\bf P}(X^{\\prime} \\in A_{X_n}|X_n)}{{\\bf P}(X^{\\prime} \\in B)} ).")]]

#text("Taking expectations in ")#mi("{n}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (\\exp( c d_c(X,A)^2 )) \\leq \\frac{1}{{\\bf P}(X^{\\prime} \\in B)} ( 2 - \\frac{{\\bf P}(X \\in A)}{{\\bf P}(X^{\\prime} \\in B)} ).")]]

#text("Using the inequality ")#mi("{x(2-x) \\leq 1}")#text(" with ")#mi("{x := \\frac{{\\bf P}(X \\in A)}{{\\bf P}(X^{\\prime} \\in B)}}")#text(" we conclude ")#link(<tao-936e792556875bc4f61f>)[#text("(21)")]#text(" as desired.")

#text("The above argument was elementary, but rather “magical” in nature. Let us now give a somewhat different ")#link("http://www.ams.org/mathscinet-getitem?mr=1399224")[#text("argument of Ledoux")]#text(", based on log-Sobolev inequalities, which gives the upper tail bound ")#metadata(none) <tao-6956e1dffd6851cfa0b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\bf P}( F(X) - {\\bf E} F(X) \\geq \\lambda K ) \\leq C \\exp(-c \\lambda^2 ),")]]

#text("but curiously does not give the lower tail bound. (The situation is not symmetric, due to the convexity hypothesis on ")#mi("{F}")#text(".)")

#text("Once again we can normalise ")#mi("{K=1}")#text(". By regularising ")#mi("{F}")#text(" we may assume that ")#mi("{F}")#text(" is smooth. The first step is to establish the following log-Sobolev inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Log-Sobolev inequality)")]#text(" Let ")#mi("{F: {\\bf C}^n \\rightarrow {\\bf R}}")#text(" be a smooth convex function. Then")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} F(X) e^{F(X)} \\leq ({\\bf E} e^{F(X)}) (\\log {\\bf E} e^{F(X)}) + C {\\bf E} e^{F(X)} \\left|\\nabla F(X)\\right|^2", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text(" (independent of ")#mi("{n}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" If one sets ")#mi("{f := e^{F/2}}")#text(" and normalises ")#mi("{{\\bf E} f(X)^2=1}")#text(", this inequality becomes")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|f(X)\\right|^2 \\log \\left|f(X)\\right|^2 \\leq 4C {\\bf E} \\left|\\nabla f(X)\\right|^2", block: true)]]

#text("which more closely resembles the classical log-Sobolev inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=420249")[#text("of Gross")]#text(". The constant ")#mi("{C}")#text(" here can in fact be taken to be ")#mi("{2}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1399224")[#text("Ledoux’s paper")]#text(".")
]

#emph[#text("Proof:")]#text(" We first establish the ")#mi("{1}")#text("-dimensional case. If we let ")#mi("{Y}")#text(" be an independent copy of ")#mi("{X}")#text(", observe that the left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} {\\bf E} ((F(X)-F(Y)) (e^{F(X)} - e^{F(Y)})) + ({\\bf E} F(X)) (({\\bf E} e^{F(X)}).")]]

#text("From Jensen’s inequality, ")#mi("{{\\bf E} F(X) \\leq \\log {\\bf E} e^{F(X)}}")#text(", so it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} ((F(X)-F(Y)) (e^{F(X)} - e^{F(Y)})) \\leq 2C {\\bf E} e^{F(X)} \\left|\\nabla F(X)\\right|^2.", block: true)]]

#text("From convexity of ")#mi("{F}")#text(" (and hence of ")#mi("{e^F}")#text(") and the bounded nature of ")#mi("{X,Y}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("F(X)-F(Y) = O( \\left|\\nabla F(X)\\right|)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("e^{F(X)}-e^{F(Y)} = O( \\left|\\nabla F(X)\\right| e^{F(X)})", block: true)]]

#text("when ")#mi("{F(X) \\geq F(Y)}")#text(", which leads to")

#align(center)[#tao-fit-display[#tao-math("((F(X)-F(Y)) (e^{F(X)} - e^{F(Y)})) = O( e^{F(X)} \\left|\\nabla F(X)\\right|^2 )", block: true)]]

#text("in this case. Similarly when ")#mi("{F(X) < F(Y)}")#text(" (swapping ")#mi("{X}")#text(" and ")#mi("{Y}")#text("). The claim follows.")

#text("To show the general case, we induct on ")#mi("{n}")#text(" (keeping care to ensure that the constant ")#mi("{C}")#text(" does not change in this induction process). Write ")#mi("{X = (X^{\\prime},X_n)}")#text(", where ")#mi("{X^{\\prime} := (X_1,\\ldots,X_{n-1})}")#text(". From induction hypothesis, we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}(F(X) e^{F(X)}|X_n) \\leq f(X_n) e^{f(X_n)} + C {\\bf E}(e^{F(X)} \\left|\\nabla^{\\prime} F(X)\\right|^2|X_n)", block: true)]]

#text("where ")#mi("{\\nabla^{\\prime}}")#text(" is the ")#mi("{n-1}")#text("-dimensional gradient and ")#mi("{f(X_n) := \\log {\\bf E}(e^{F(X)}|X_n)}")#text(". Taking expectations, we conclude that ")#metadata(none) <tao-8924c0513d9ed7132936>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("{\\bf E} F(X) e^{F(X)} \\leq {\\bf E} f(X_n) e^{f(X_n)} + C {\\bf E} e^{F(X)} \\left|\\nabla^{\\prime} F(X)\\right|^2.", block: true)]]

#text("From the convexity of ")#mi("{F}")#text(" and Hölder’s inequality we see that ")#mi("{f}")#text(" is also convex, and ")#mi("{{\\bf E} e^{f(X_n)} = {\\bf E} e^{F(X)}}")#text(". By the ")#mi("{n=1}")#text(" case already established, we have ")#metadata(none) <tao-f5409f0e6979f82e87d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("{\\bf E} f(X_n) e^{f(X_n)} \\leq ({\\bf E} e^{F(X)}) (\\log {\\bf E} e^{F(X)}) + C {\\bf E} e^{f(X_n)} \\left|f^{\\prime}(X_n)\\right|^2.", block: true)]]

#text("Now, by the chain rule")

#align(center)[#tao-fit-display[#tao-math("e^{f(X_n)} \\left|f^{\\prime}(X_n)\\right|^2 = e^{-f(X_n)} \\left| {\\bf E}(e^{F(X)} F_{x_n}(X)|X_n)\\right|^2", block: true)]]

#text("where ")#mi("{F_{x_n}}")#text(" is the derivative of ")#mi("{F}")#text(" in the ")#mi("{x_n}")#text(" direction. Applying Cauchy-Schwarz, we conclude")

#align(center)[#tao-fit-display[#tao-math("e^{f(X_n)} \\left|f^{\\prime}(X_n)\\right|^2 \\leq {\\bf E}(e^{F(X)} \\left|F_{x_n}(X)\\right|^2|X_n).", block: true)]]

#text("Inserting this into ")#link(<tao-8924c0513d9ed7132936>)[#text("(23)")]#text(", ")#link(<tao-f5409f0e6979f82e87d3>)[#text("(24)")]#text(" we close the induction. ")#mi("\\Box")

#text("Now let ")#mi("{F}")#text(" be convex and ")#mi("{1}")#text("-Lipschitz. Applying the above lemma to ")#mi("{tF}")#text(" for any ")#mi("{t>0}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} tF(X) e^{tF(X)} \\leq ({\\bf E} e^{tF(X)}) (\\log {\\bf E} e^{tF(X)}) + C t^2 {\\bf E} e^{tF(X)};")]]

#text("setting ")#mi("{H(t) := {\\bf E} e^{tF(X)}}")#text(", we can rewrite this as a differential inequality")

#align(center)[#tao-fit-display[#mitex("t H^{\\prime}(t) \\leq H(t) \\log H(t) + C t^2 H(t)")]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} (\\frac{1}{t} \\log H(t) ) \\leq C.")]]

#text("From Taylor expansion we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{t} \\log H(t) \\rightarrow {\\bf E} F(X)")]]

#text("as ")#mi("{t \\rightarrow 0}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{t} \\log H(t) \\leq {\\bf E} F(X) + Ct")]]

#text("for any ")#mi("{t>0}")#text(". In other words,")

#align(center)[#tao-fit-display[#mitex("{\\bf E} e^{tF(X)} \\leq \\exp( t {\\bf E} F(X) + C t^2 ).")]]

#text("By Markov’s inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( F(X) - {\\bf E} F(X) > \\lambda ) \\leq \\exp( Ct^2 - t \\lambda);")]]

#text("optimising in ")#mi("{t}")#text(" gives ")#link(<tao-6956e1dffd6851cfa0b5>)[#text("(22)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The same argument, starting with Gross’s log-Sobolev inequality for the gaussian measure, gives the upper tail component of Theorem ")#link(<tao-72fcc7c75a4c404af794>)[#text("8")]#text(", with no convexity hypothesis on ")#mi("{F}")#text(". The situation is now symmetric with respect to reflections ")#mi("{F \\mapsto -F}")#text(", and so one obtains the lower tail component as well. The method of obtaining concentration inequalities from log-Sobolev inequalities (or related inequalities, such as Poincaré-type ienqualities) by combining the latter with the exponential moment method is known as ")#emph[#text("Herbst’s argument")]#text(", and can be used to establish a number of other functional inequalities of interest.")
]

#text("We now close with a simple corollary of the Talagrand concentration inequality, which will be extremely useful in the sequel.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Distance between random vector and a subspace)")]#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be independent complex-valued random variables with mean zero and variance ")#mi("{1}")#text(", and bounded almost surely in magnitude by ")#mi("{K}")#text(". Let ")#mi("{V}")#text(" be a subspace of ")#mi("{{\\bf C}^n}")#text(" of dimension ")#mi("{d}")#text(". Then for any ")#mi("{\\lambda > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|d(X,V) - \\sqrt{n-d}\\right| \\geq \\lambda K ) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(".")
]

#text("Informally, this corollary asserts that the distance between a random vector ")#mi("{X}")#text(" and an arbitrary subspace ")#mi("{V}")#text(" is typically equal to ")#mi("{\\sqrt{n - \\text{dim}(V)} + O(1)}")#text(".")

#emph[#text("Proof:")]#text(" The function ")#mi("{z \\mapsto d(z,V)}")#text(" is convex and ")#mi("{1}")#text("-Lipschitz. From Theorem ")#link(<tao-db3202a38d8d898db285>)[#text("9")]#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|d(X,V) - M d(X,V)\\right| \\geq \\lambda K ) \\leq C \\exp(-c \\lambda^2 ).", block: true)]]

#text("To finish the argument, it then suffices to show that")

#align(center)[#tao-fit-display[#mitex("M d(X,V) = \\sqrt{n-d} + O( K ).")]]

#text("We begin with a second moment calculation. Observe that")

#align(center)[#tao-fit-display[#tao-math("d(X,V)^2 = \\left\\| \\pi(X) \\right\\|^2 = \\sum_{1 \\leq i,j \\leq n} p_{ij} X_i \\overline{X_j},", block: true)]]

#text("where ")#mi("{\\pi}")#text(" is the orthogonal projection matrix to the complement ")#mi("{V^\\perp}")#text(" of ")#mi("{V}")#text(", and ")#mi("{p_{ij}}")#text(" are the components of ")#mi("{\\pi}")#text(". Taking expectations, we obtain ")#metadata(none) <tao-3c1467b9647e4120c4d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("{\\bf E} d(X,V)^2 = \\sum_{i=1}^n p_{ii} = \\text{tr}(\\pi) = n-d")]]

#text("where the latter follows by representing ")#mi("{\\pi}")#text(" in terms of an orthonormal basis of ")#mi("{V^\\perp}")#text(". This is close to what we need, but to finish the task we need to obtain some concentration of ")#mi("{d(X,V)^2}")#text(" around its mean. For this, we write")

#align(center)[#tao-fit-display[#mitex("d(X,V)^2 - {\\bf E} d(X,V)^2 = \\sum_{1 \\leq i,j \\leq n} p_{ij} (X_i \\overline{X_j} - \\delta_{ij})")]]

#text("where ")#mi("{\\delta_{ij}}")#text(" is the Kronecker delta. The summands here are pairwise uncorrelated for ")#mi("{1 \\leq i \\leq j \\leq n}")#text(", and the ")#mi("{i>j}")#text(" cases can be combined with the ")#mi("{i<j}")#text(" cases by symmetry. Each summand also has a variance of ")#mi("{O( K^2 )}")#text(". We thus have the variance bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf Var}( d(X,V)^2 ) = O( K^2 \\sum_{1 \\leq i,j \\leq n} \\left|p_{ij}\\right|^2 ) = O( K^2 (n-d) ),", block: true)]]

#text("where the latter bound comes from representing ")#mi("{\\pi}")#text(" in terms of an orthonormal basis of ")#mi("{V^\\perp}")#text(". From this, ")#link(<tao-3c1467b9647e4120c4d9>)[#text("(25)")]#text(", and Chebyshev’s inequality, we see that the median of ")#mi("{d(X,V)^2}")#text(" is equal to ")#mi("{n-d + O( \\sqrt{K^2 (n-d)} )}")#text(", which implies on taking square roots that the median of ")#mi("{d(X,V)}")#text(" is ")#mi("{\\sqrt{n-d} + O(K)}")#text(", as desired. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (138)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-251128")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("Are the summands for last applicational result really independent or merely uncorrelated?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-432954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2014")])]

#text("Do you want the variance to be “at least 1” or “at most 1”. The current formulation seems inconsistent with the note right after this line.")

#emph[#text("[“At most”. Note clarified to remove the confusion. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy and rare events | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-459504")[#strong[#text("Entropy and rare events | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("[…] inequality, but there are of course many other estimates of this type (see e.g. this previous blog post for some others). Roughly speaking, concentration of measure inequalities allow one to make […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b9622c596a28e6b626703089a7f19a456e2d4d2273ce53e6d845a5d47d198a-430be90cff6b1ba89682ed1ad788a868d961c03f9ecc442911b930ac5ec49bb2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiasen Yang")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-459550")[#strong[#text("Jiasen Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Dear Professor Tao,")

#text("Thank you for the detailed post! I’ve been going through the proof of McDiarmid’s inequality, and I don’t see why it is necessary to assume that the ")#mi("X_i")#text("‘s are independent. I wonder if you could point out which step(s) I missed?")

#text("Thanks very much!")

#emph[#text("[One needs the independence to ensure that (say) ")#mi("X_n")#text(" continues to have mean zero even after conditioning on ")#mi("X_1,\\dots,X_{n-1}")#text(". -T. Note also that the theorem fails quite badly if for instance one has the very strong coupling ")#mi("X_1=\\dots=X_n")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b9622c596a28e6b626703089a7f19a456e2d4d2273ce53e6d845a5d47d198a-430be90cff6b1ba89682ed1ad788a868d961c03f9ecc442911b930ac5ec49bb2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiasen Yang")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-459561")[#strong[#text("Jiasen Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Dear Professor Tao,")

#text("Thank you for your timely reply! Your coupling argument certainly makes sense, but I’m still having trouble determining which step of the proof uses independence directly. Following your point, I agree that $E[X_n] \\neq E[X_n|X_1,\\ldots,X_{n-1}]$ in general, but I don’t see where $X_n$ is assumed to have mean zero?")

#text("Actually, my question originally arose as I was reading a paper which claims to use McDiarmid’s inequality for dependent $X_i$’s after replacing the assumption")#linebreak()#text(" ")#tao-fit-display[#tao-math("\\left|F(x_1,\\ldots,x_{i-1},x_i,x_{i+1},\\ldots,x_n) – F(x_1,\\ldots,x_{i-1},x_i’,x_{i+1},\\ldots,x_n)\\right| \\leq c_i", block: true)]#linebreak()#text(" by")#linebreak()#text(" ")#tao-fit-display[#tao-math("\\left|\\bf{E}[f(X)|x_1,\\ldots, x_{i-1},x_i] – \\bf{E}[f(X)|x_1,\\ldots, x_{i-1},x_i’]\\right| \\le c_i", block: true)]#text(", but I don’t see why this new assumption resolves the issue.")

#text("Thank you again, and please forgive me for my stubbornness!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-459562")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Sorry, my previous reply was quite incorrect, I was thinking of a different concentration equality. For McDiarmid, the claim that the conditioned function ")#mi("F_{n-1}")#text(" obeys the same hypotheses as the original function ")#mi("F_n")#text(" requires the independence hypothesis, as one will find if one expands out the proof of this claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b9622c596a28e6b626703089a7f19a456e2d4d2273ce53e6d845a5d47d198a-430be90cff6b1ba89682ed1ad788a868d961c03f9ecc442911b930ac5ec49bb2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiasen Yang")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-459565")[#strong[#text("Jiasen Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Ah! I finally see your point. Thank you Professor!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 3: The weak and strong law of large numbers | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-460850")[#strong[#text("275A, Notes 3: The weak and strong law of large numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("[…] theory and high dimensional geometry. We will not discuss these topics much in this course, but see this previous blog post for some further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46d5bdee0176ada4a46c7e7a692143f3387de631f85f4e63eeb819b176886dd2-7cf3d54f1416e655edc18fb3d2bf9c7b3654de350336c9056fbcc0238d5f6aba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mahmood")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-461557")[#strong[#text("Mahmood")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Dear Professor Tao,")

#text("In the proof of Lemma 11 and the definition of set ")#mi("B:=\\{z^{\\prime}\\in\\Omega^{n-1}: (z^{\\prime},t)\\in A \\text{ for some } t\\in\\Omega\\}")#text(". What happens if such ")#mi("t")#text(" is equal to ")#mi("X_n")#text("? Is it still valid to say that ")#mi("U_A(X) \\text{contains} U_B(X^{\\prime})\\times\\{1\\}")#text(". For example, when the set ")#mi("A")#text(" has the points whose ")#mi("n\\text{th}")#text(" coordinates are all equal to ")#mi("X_n")#text(", then ")#mi("U_A(X)")#text(" does not have any element with the last coordinate 1. Am I missing something?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-461568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Oops, you’re right, the ")#mi("t=X_n")#text(" case has to be handled separately, but the bound is better in that case (one can stay in the ")#mi("{\\bf R}^{n-1} \\times \\{0\\}")#text(" slice). I’ve updated the argument accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46d5bdee0176ada4a46c7e7a692143f3387de631f85f4e63eeb819b176886dd2-7cf3d54f1416e655edc18fb3d2bf9c7b3654de350336c9056fbcc0238d5f6aba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mazrouei")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-461587")[#strong[#text("mazrouei")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("Thanks for your reply.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 5: Variants of the central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-462101")[#strong[#text("275A, Notes 5: Variants of the central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("[…] in which the underlying random variable is not bounded, but enjoys good moment bounds. See this previous blog post for these inequalities and some further discussion. Last, but certainly not least, there is an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-466316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2016")])]

#text("Hello Professor Tao,")

#text("In the proof of SLLN, I am not sure what do you mean by ‘countable additivity’ in building the connections bewteen convergence of two sequences. Does it mean adding O(\\varepsilon)?")

#text("Thanks!")

#text("Jack")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-466318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2016")])]

#text("If ")#mi("S_{n_m}/n_m")#text(" is almost surely convergent to ")#mi("{\\bf E} X")#text(", then almost surely it is the case that ")#mi("S_n/n")#text(" fluctuates by at most ")#mi("O(\\varepsilon)")#text(" around ")#mi("{\\bf E} X")#text(" (in the sense that the limit superior and limit inferior are both almost surely ")#mi("{\\bf X}+O(\\varepsilon)")#text(". Setting ")#mi("\\varepsilon= 1/n")#text(" (say) for ")#mi("n=1,2,3,\\dots")#text(" and using countable additivity (which implies that the countable intersection of almost sure events is still almost sure, we conclude that the limit superior and limit inferior are both almost surely ")#mi("{\\bf E}")#text(", giving the SLLN.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-466319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2016")])]

#text("Ah, I see. Thanks a lot for your reply!")

#text("Best,")#linebreak()#text(" Jack")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc1de4405b75999fef5398090fc53b9d8f2afaa842f69ecbd86b8c9d7a9be3eb-c899832b5fd05672424e3f437bc8392468d4bbc11b04a2ff3ee4afbb940858a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2016")])]

#text("Dear Prof. Tao, I believe your notes are just impressive.")

#text("What can we say on the lower bound on $Pr[|S_n|\\geq \\lambda]\\geq ?$,depending on the moments of the distribution of the jointly independent, zero mean, variables $X_i$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467675")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2016")])]

#text("This is the realm of large deviation theory; these bounds tend to depend in various subtle ways on the precise distribution of the independent variables. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=542129")[#text("this paper of Nagaev")]#text(" for a classical survey of results; probably there are more up to date surveys also.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467720")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2016")])]

#text("I think that the probability of a recursive nature, so this phenomenon is possible. Probability – it’s just part of the recursion. Any probabilistic model is necessary to approximate recursion, which we can control. For example the set of prime numbers is recursive. But how to prove it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb35cc66cb633384c4380ece0a6df2ee9b9b3196c5081e46f6950c4549f39b03-e18571f599fbc3464397778e44ee457860f5fb5679f8a5a6a9e13dd2a8ffbb9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467947")[#strong[#text("Nathan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2016")])]

#text("Dear Prof. Tao,")

#text("First I would like to thank you for your notes, which are quite impressive!")

#text("I do not understand why each summand has a variance of ")#mi("O(K^2)")#text(" in the computation of the variance of ")#mi("d(X,V)^2")#text(" (corollary 13). Since ")#tao-math("\\left|X_i\\right| \\leq K", block: false)#text(" and a term in the computation has the form ")#mi("E[X_i^2X_j^2]")#text(", shouldn’t we have an ")#mi("O(K^4)")#text("?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#mi("{\\bf E}( X_i^2 X_j^2 ) \\leq {\\bf E}( K^2 X_j^2 ) = K^2")#text(", since ")#mi("X_j")#text(" has mean zero and variance one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-467975")[#strong[#text("Nathan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-478587")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("I was also stuck on this point; thanks for clarifying!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95981c77c5ebe6278e33b354d0686ed08b731078bda45ddfe38098447cec37d3-0b23d76ada69c51e8a2875831a08bbad4e1f6689dcb6c246ff42287616a4990e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vaibhav")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-469325")[#strong[#text("Vaibhav")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Hi Prof. Terrence Tao,")

#text("I am a very simple question. In, (McDiarmid’s inequality) it is not clear how does it depend upon N, the number of random variables concerned. Intuitively, and as you mention elsewhere, the inequality should become stronger. That is, as the number of random variables increase, the deviation from the mean of the function should be less likely. Could you kindly clarify.")

#text("Quoting you:")

#text("“The basic intuition here is that it is difficult for a large number of independent variables {X_1,\\ldots,X_n} to “work together” to simultaneously pull a sum {X_1+\\ldots+X_n} or a more general combination {F(X_1,\\ldots,X_n)} too far away from its mean. Independence here is the key; concentration of measure results typically fail if the {X_i} are too highly correlated with each other.”")

#text("I fail to see this effect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-469511")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Let’s say we are working in the normalisation ")#mi("c_i=1")#text(". The hypothesis of Theorem 7 allows ")#mi("F")#text(" to range over an interval of size ")#mi("n")#text("; but McDiarmid’s inequality shows that concentration instead occurs at a shorter interval at the scale of ")#mi("\\sigma =\\sqrt{n}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95981c77c5ebe6278e33b354d0686ed08b731078bda45ddfe38098447cec37d3-0b23d76ada69c51e8a2875831a08bbad4e1f6689dcb6c246ff42287616a4990e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vaibhav")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-469540")[#strong[#text("Vaibhav")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Dear Prof. Tao, Thanks a lot. This helps most certainly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95981c77c5ebe6278e33b354d0686ed08b731078bda45ddfe38098447cec37d3-0b23d76ada69c51e8a2875831a08bbad4e1f6689dcb6c246ff42287616a4990e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vaibhav")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-469542")[#strong[#text("Vaibhav")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Dear Prof. Tao,")

#text("I had a following question about Levy’s Lemma (another celebreated concentration of measure result).")

#text("First the Levy’s Lemma.")

#text("Let $f : S^k \\rightarrow R$")#linebreak()#text(" be a function with Lipschitz constant $\\eta$ (with respect to the Euclidean norm) and $X \\in k$")#linebreak()#text(" and a point $X \\in S^{k}$ be chosen uniformly at random. Then")#linebreak()#text(" \\begin{align}")#linebreak()#text(" \\label{levy}")#linebreak()#text(" Pr\\{|f(X) – \\bar{f}| > \\alpha\\}\\le exp (-C(k+1)\\alpha^{2}/\\eta^2 )")#linebreak()#text(" \\end{align}")#linebreak()#text(" for some constant $C >0$ and $\\bar{f}$ is the mean value of the function over the sphere.")

#text("Now, here is my question: This Lemma seems to hold for a point chosen")#linebreak()#text(" uniformly at random over a sphere.")#linebreak()#text(" My question is….suppose I choose a point on an N dimensional sphere (X_1, X_2,…, X_N) such that (X_1^2, X_2^2, …, X_N^2) is chosen from a uniform distribution.")#linebreak()#text(" Certainly (X_1^2, X_2^2, …, X_N^2) chosen from a uniform distribution does not imply (X_1, X_2,…, X_N) will be a uniformly random point on the sphere.")#linebreak()#text(" But intuitively, I will expect Levy’s Lemma (or say a weaker version) to hold as I expect it to hold")#linebreak()#text(" for almost all points on the sphere.")#linebreak()#text(" My computer simulations also show this to be the case.")#linebreak()#text(" But, I cannot make mathematical arguments to justify my intuition and my simulations.")

#text("Best,")

#text("vaibhav")

#text("Ps: If I can show this, I can show a neat result in evolutionary biology, which I will be happy to show it to you if you would like.")#linebreak()#text(" Many thanks to you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01901599885f643a9707e9fedd90c0126fa3ed4c884d78f12b539d71c776ab8a-a7916bc83fa7ae082c391fb2e1d63cf97ac556259415a1a4a04b1e45cf143fd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahn")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-470129")[#strong[#text("Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")])]

#text("Dear prof. Tao,")

#text("While I read the proof of proposition 6, I could not follow the step at the end where you applied chernoff bound. For example, what did you choose for lambda?")

#text("I would appreciate your help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-470149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("There is a lot of latitude here in what to choose for ")#mi("\\lambda")#text(", for instance one can take ")#mi("\\lambda = c^{\\prime\\prime} A \\exp( c^{\\prime} 2^{2m} / 2 )")#text(" for some small ")#mi("c^{\\prime\\prime} > 0")#text(". Note that the bound on the RHS is not optimal, but suffices for the application at hand.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-474168")[#strong[#text("Fast Randomized SVD – Facebook Research")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2016")]

#text("[…] our approximation by appealing to concentration of measure results for random matrices – see Terry Tao’s lecture notes on the topic for some useful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-477781")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Could anyone please explain why in the proof of Hoeffding’s lemma, the first Taylor expansion is ")#mi("e^(tX) = 1 + tX + O(t^2 X^2 exp(O(t))")#text(" and not just the naive ")#mi("e^(tX) = 1 + tX + O(t^2 X^2)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-477789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("The simpler estimate ")#mi("O(t^2 X^2)")#text(" for the remainder term applies only for bounded ")#mi("t X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-477791")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Of course, thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a6d499217256e2938fd2677a27494d7b216a8e2b90fa14153ae9d546aad1f0a-80b9ccb784fe96a1d2d45dd930cdfd99ad248671021d1ab871db3b636a3762a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zahra")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-480662")[#strong[#text("Zahra")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2017")])]

#text("Hello Prof. Tao,")

#text("Any known results for the extension of theorem 8 to the case when ")#mi("(X_1,\\ldots, X_n)")#text(" be a vector of iid sub-gaussian variables? Many Thanks.")

#emph[#text("[Probably. I don’t have references handy, but I would recommend checking Ledoux’s book on the subject. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative continuity estimates | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-481107")[#strong[#text("Quantitative continuity estimates | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("[…] is the proof by Maurey and Pisier of the gaussian concentration inequality, given in Theorem 8 of this previous blog post. In a similar vein, if one wishes to compare a scalar random variable of mean zero and variance […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4970c8b53271828e540c68475cec68edd88f754fc1463655d7282a311342bc57-ebafc85aa20d7f671bbb3d7dbe9d796428a370fc86c598b3a243cd370c26f51d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AL Ray")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-490724")[#strong[#text("AL Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I don’t understand something in the proof of the Lemma 10 why is ")#mi("z_\\omega \\in X\\setminus A")#text(" and not ")#mi("z_w\\in A\\setminus X")#text("?")

#text("Thanks in advance!")

#emph[#text("[This is a typo, now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/176d35f294e80f7e32b1a9ca1914c7530ffe95d432c46472720375969279d1dc-1532f691c5b6efa1bfb99cb25b804f9f894c58caee717eb771a5390e2ad037bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-490972")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("Dear Prof. Tao,")

#text("Thanks for the insightful notes. I have two questions:")

#text("1. When calculating the variance of d(X, V)^2, a term in the computation will be E[X_i^2 X_j^2], which I think should be 1 instead of O(K^2) since X_i and X_j are independent.")#linebreak()#text(" 2. Are there any more direct ways to calculate / estimate the expectation of d(X, V)?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-490986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2017")])]

#text("It’s true one can improve the bound on the variance of ")#mi("d(X,V)^2")#text(", but unfortunately this does not significantly improve the concentration bound because of the uncertainty of ")#mi("O(K)")#text(" coming from the use of Theorem 9.")

#text("I don’t know of much sharper ways to control the expectation, but there are several routes to the concentration property at least, starting with the classic work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=279864")[#text("Hanson and Wright")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-528572")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] random variable will concentrate around its mean if its variance is not too large. See these previous notes for more discussion of the concentration of measure phenomenon. One can often obtain stronger […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-528573")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] random variable will concentrate around its mean if its variance is not too large. See these previous notes for more discussion of the concentration of measure phenomenon. One can often obtain stronger […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yijia Liu")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-569920")[#strong[#text("Yijia Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2020")])]

#text("I have been trying to work out the computations for the final part of proposition 6 but I couldnt get the 2^-m factor.")

#text("From ")#link("https://math.stackexchange.com/questions/3734229/chernoff-bound-for-sum-of-sub-gaussian-variables-via-truncation-method")[#text("https://math.stackexchange.com/questions/3734229/chernoff-bound-for-sum-of-sub-gaussian-variables-via-truncation-method")]#text(" it seems that we cannot replace $1/100(m+1)^2$ with $2^{-m-1}$. Is this a typo or have I missed something in calculations.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-635696")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] above claim using concentration of measure results such as the Chernoff inequality, as discussed in this previous blog post. The estimate (2) reflects the general heuristic of expected square root cancellation: when summing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-636795")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2021")])]

#text("In the proof of Theorem 8, should (all five instances of) ")#mi("\\frac{2t}{\\pi}")#text(" be ")#mi("\\frac{\\pi t}{2}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b4dce1352df613475b6621efd1742ec560a19ea81f9055fa4cb7b1c110882bd-080fc85da6ed4dab236e29c61da76145b4103df5298c3b171e1ed1731c153acd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matteo Russo")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-642527")[#strong[#text("Matteo Russo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Dear Prof.Tao,")

#text("Upon thanking you for the notes, I would like to ask whether Talagrand’s Inequality held even in the case where 1-Lipschitz is with respect to the l1-norm. If not, what type of concentration guarantees could still be claimed?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-642537")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("The standard concentration inequality that is used in such settings is McDiarmid’s inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-678142")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2023")])]

#text("I suspect there’s a (minor) typo in the proof of the Chernoff inequality (Theorem 2). After “we use the hypothesis that ")#tao-math("\\left|X\\right| \\leq 1", block: false)#text(" and (9) to obtain” there’s an equation, following from the previous display which is an inequality.")

#text("And on the conclusion of the proof of that theorem, I suspect that the ")#mi("\\max")#text(" of the two exponentials comes from an asymmetry in the tails. At least, This is the case in a proof of a special case (sums of arbitrary Bernoulli RVs) I’ve seen in one treatment elsewhere. But I’ve not seen other proofs give an upper bound of this form, in my limit searching.")

#text("One thing which I haven’t been able to justify to myself is why you consider the parameter ")#mi("t")#text(" in that proof to be bounded above by 1. Is it somehow due to implicitly needing to consider something like keeping a factor of ")#mi("1-t")#text(" positive, while at the same time keeping ")#mi("t")#text(" positive, to use in a previous estimate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-678144")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2023")])]

#text("Sorry, one more thought: might the bound on ")#mi("t")#text(" come from needing ")#tao-math("\\left|tX\\right|", block: false)#text(" to still be bounded by 1? Just casting about at this point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-678158")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2023")])]

#text("Typo now corrected. The condition ")#mi("t \\leq 1")#text(" is needed to be able to estimate the ")#mi("\\exp(O(t(b-a)))")#text(" term in (9) by ")#mi("O(1)")#text(", which allows one to bound the entire RHS of (9) by ")#mi("\\exp( O(t^2 \\sigma_i^2) )")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-678163")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2023")])]

#text("Oh, excellent, thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a23baf9ae89c2695feb1fffa0abe2a63f074b661b26d3b5f80dd164e6f29171d-de8378f9efe0e1626ca5ae280935c53e66b049103dd9cc0c19c84baa146a499a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Feite Zheng")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-686418")[#strong[#text("Feite Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("Professor, could you provide a hint for Exercise 11? I really can’t figure out how to relate the upper bound of the product of two probabilities to the upper bound of the probability of a single event, especially since (vert F(X) – E F(X) vert) cannot be split into a union of multiple events.")

#text("I also can’t eliminate the influence of set ( A ) on the constant ( C ), which makes it difficult to relate set ( A ) to function ( F ). As a result, when I try to connect set ( A ) with ( F ), I can’t prove that the coefficient ( C ) in the upper bound of ( P(vert F(X) – E F(X) vert > lambda) ) is independent of ( F ).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-686433")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("It can help to first work with the median instead of the mean, since the set where ")#mi("F(X)")#text(" is less than or equal to the median, or greater than or equal to the median, is guaranteed to be at least 1/2, and is then a good choice for the set ")#mi("A")#text(" in the hypothesis listed in Exercise 11.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a23baf9ae89c2695feb1fffa0abe2a63f074b661b26d3b5f80dd164e6f29171d-de8378f9efe0e1626ca5ae280935c53e66b049103dd9cc0c19c84baa146a499a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Feite Zheng")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-686420")[#strong[#text("Feite Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("Dear Prof.Tao,")

#text("I don’t understand the proof of Theorem 9 (Talagrand’s concentration inequality). After obtaining inequality (20), how does one get the estimate for ( P(F(X) ge y) )? I noticed that B = { z in Omega^n : F(z) ge x } is not a convex set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-686423")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("You apply (20) for the convex set ")#mi("A = \\{ x \\in \\Omega^n: F(X) \\leq x \\}")#text(" and then apply Markov’s inequality to control the size of ")#mi("\\mathbf{P}(F(X) \\geq y)")#text(", noting that ")#tao-math("d(x,A) \\geq \\left|y-x\\right|", block: false)#text(" on this set. The lack of convexity of this latter set is irrelevant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34b431dc1ab70394c92fb5bda81eb69cfa54a5f5214ddbee5a02b51875136960-f9cf02f2c6582738e0c8d959614db05ce837ed7c3286c27c4b340cf91ba55dc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan Lin")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-692175")[#strong[#text("Ethan Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2026")])]

#text("I noticed that in the section about McDiarmid’s inequality the term of sigma ^ 2 = sum of Ci ^2, it seems to aggregate worse case deviations per coordinate similar to how variance decomposes across independent components. Does this connection reflect a deeper relationship within the Lipschitz structure and the actual variance of F(X)? Does the sum term serve as an upper bound of Var(F(X)) and does the tightness of the inequality depend on how close the term is to the true Var(F(X))? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-692899")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2026")])]

#text("In Theorem 5, if we regard n as the pigeon and [n_m, n_{m+1}) as the pigeonhole, where n_m := ⌊(1+m)^ε⌋, can we view the sparsification trick as a special case of the more general pigeonhole principle? (I don’t know if this is accurate) If so, then more generally speaking, in probability theory, when would we expect the pigeonhole principle to appear?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-692901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2026")])]

#text("Sparsification is complementary to pigeonholing; the two tricks can be combined into the “dyadic pigeonholing” trick, which Jean Bourgain in particular was very fond of, but in this particular case (strong law of large numbers) we are using sparsification only.")

#text("The general principle behind sparsification is that it is cheap to discretize to any scale below which nothing much of interest is happening. In the case of the strong law applied to non-negative random variables, the empirical averages ")#mi("\\frac{1}{n} (X_1 + \\dots + X_n)")#text(" don’t fluctuate very much if one only modifies ")#mi("n")#text(" by a multiplicative factor of ")#mi("1 + O(\\varepsilon)")#text(", so one only gets interesting transitions in this behavior when moving from ")#mi("n")#text(" to ")#mi("(1+\\varepsilon) n")#text(", which prompts the use of the indicated sparsification.")

#text("In probability theory, the plain pigeonhole principle can be viewed as a simple application of the “probabilistic method” (look at the expected number of pigeons in a random pigeonhole). But usually one uses more sophisticated concentration of measure inequalities instead of just the vanilla pigeonhole principle, including many of the inequalities mentioned in this blog post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-692902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2026")])]

#text("Dr Tao, I can’t put into words how grateful I am to you. Your insights are truly enlightening and have helped me tremendously!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-694099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("Could you elaborate on what you mean by “nothing much of interest is happening”? What does “interesting transitions” mean?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-694105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("Write ")#mi("S_n := \\frac{1}{n} (X_1 + \\dots + X_n)")#text(". If the ")#mi("X_i")#text(" are non-negative and ")#mi("n_0 \\leq n \\leq (1+\\varepsilon) n_0")#text(", then it is not hard to show that")

#mi("\\frac{1}{1+\\varepsilon} S_{n_0} \\leq S_n \\leq (1+\\varepsilon) S_{(1+\\varepsilon) n_0}.")

#text("So, controlling ")#mi("S_{n_0}")#text(" and ")#mi("S_{(1+\\varepsilon) n_0}")#text(" already tells you almost everything about the intermediate ")#mi("S_n")#text(" that you would want to know for the purposes of obtaining asymptotics.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-2/#comment-693196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2026")])]

#text("The proof of the WLLN is not particularly difficult, but when we move to prove the SLLN, which requires stronger convergence, namely the almost sure convergence, the Borel–Cantelli lemma is used in the proof. So the reason for using Borel-Cantelli lemma (instead of using first principles or other techniques) is that it can strengthen convergence?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab57e9002bec3490bbe57ea4d2aaeb6863d4bd581032243f8621551be2deaeac-8f6f9cd6fbae7084e5f021eb33e2be3ccad5ea5a1f9e4958afa19968608523d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43078")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2010")])]

#text("I’m enjoying these notes. I just want to point out a technical issue. This post, and also the post ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(", did not appear in Google Reader, although ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Notes 0a")]#text(" does appear there, and all three posts (0, 0a, 1) appear if I go directly to ")#link("https://terrytao.wordpress.com/feed/")[#text("https://terrytao.wordpress.com/feed/")]#text(".")

#text("I don’t know what’s causing this (and the problem may be my fault, or Google’s), but I thought I’d mention this here in case other people have the same issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43083")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2010")])]

#text("Google Reader’s doing the same for me. It doesn’t seem like an uncommon bug — for instance, looking at my feed to Tim Gowers’ blog it doesn’t list the post on Littlewood’s conjecture. Two dropped posts in three days does seem high, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cec63be731542236f25e1cb4a7d42c9e3ecf844a2bc6f14f1d6dda0602dd4f9f-c2fb5af9a52260ed0c42c0258ed193f17f05833511f60dc48be715542e63548d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43126")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("The trouble seems to be something in the content item of the feed (the item containing the full HTML of the post). Using ")#link("http://pipes.yahoo.com")[#text("Yahoo Pipes")]#text(", I created a copy of the feed for this blog and removed the content item. It seems to work fine in Google Reader. The RSS feed is here:")

#link("http://pipes.yahoo.com/pipes/pipe.run?_id=ec21ff6b5d982e2f244ca9fd7d10dfac&_render=rss")[#text("http://pipes.yahoo.com/pipes/pipe.run?_id=ec21ff6b5d982e2f244ca9fd7d10dfac&_render=rss")]

#text("and the Yahoo Pipe (which I made public) is here:")

#link("http://pipes.yahoo.com/pipes/pipe.info?_id=ec21ff6b5d982e2f244ca9fd7d10dfac")[#text("http://pipes.yahoo.com/pipes/pipe.info?_id=ec21ff6b5d982e2f244ca9fd7d10dfac")]

#text("Note that you will have to read the article in WordPress rather than in Google Reader.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelly")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43082")[#strong[#text("Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2010")])]

#text("Aloha Terry,")

#text("I am new to this blog and quite blown away by the sheer amount of fascinating math topics here… Just wondering- how long does it normally take to put these notes together? You don’t seem to sleep!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Dear Prof. Tao,")

#text("I enjoyed this yet another excellent post.")

#text("A remark – theorems 4 and 5 seem to be phrased identically – probably a copy-paste typo.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43090")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("The improved bound you want us to establish in Exercise 3,")#linebreak()#text(" (lambda K/sigma)^(-c lambda sigma), is not scale-invariant; if you multiply the X_i by a constant A, then the K, mu_i, sigma_i, mu, and sigma (and therefore the LHS of the desired inequality) remains unchanged.")

#text("However, the term (lambda K/sigma)^(-c lambda sigma) is raised to the power of A (as lambda K/sigma is unchanged but -c lambda sigma is multiplied by A).")

#text("Am I missing something here, and if not, should the bound be changed to something which is invariant under such scaling?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43096")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Ah, the exponent should be ")#mi("c \\lambda \\sigma/ K")#text(" instead. I’ve changed this accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b7bf3d998a045ad4a6acfae2fca1aa80b31a1c737955a092273dc8cd36f6eb4-17b119af25a285ed29a6aefcb9e7dda27f1636d7622033b09e8ff97a470bce72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arnab")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43100")[#strong[#text("Arnab")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Such wonderful notes!")

#text("In Corollary 13, I think when you did the variance bound of d(X, V)^2,")#linebreak()#text(" you mean the summand are ‘pairwise uncorrelated’ instead of ‘pairwise independent’?")

#emph[#text("[Well, either would work here, so I reworded the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7335123c943e21bb6c4b99399f0574798d0bb4ed94d2549951076040bad50b1a-d00c8d74a4d94a6733ac1cde22cd4a6abbbf91939ae682db321352f6fb665283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akito Nagasaki")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43104")[#strong[#text("Akito Nagasaki")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Dear Professor Tao,")

#text("Inequality(1) seems not always true!")#linebreak()#text(" Pick up a r.v. X taking 1 with probability 1/8, -1 with 1/8 and 0 with 3/4")#linebreak()#text(" and Y a copy of X but independent one.")#linebreak()#text(" Then P(X+Y not equal to zero) = 38/64 and P(X not equal to zero) +")#linebreak()#text(" P(Y not equal to zero)=1/2 ??")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("I think you may have double-counted some of the probabilities here; my computations show that X+Y is non-zero with probability 26/64.")

#text("The proof of the inequality is quite simple in this case, because the event that X+Y is nonzero is clearly contained in the union of the events that X is nonzero and Y is nonzero, thus the probability of the former is at most the sum of the probabilities of the latter.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43108")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("For a seminar our UW QSE Group is giving this quarter, ")#emph[#text("So you want to be a quantum system engineer")]#text(", it would be *very* helpful to have a generalized version of Corollary 13, in which ")#mi("V")#text(" is not a linear subspace, but rather a rank-")#mi("r")#text(" join space of spin-")#mi("j")#text(" product states of order-")#mi("m")#text(".")

#text("Physicists would call ")#mi("V")#text(" a restriction of spin-")#mi("j")#text(" order-")#mi("m")#text(" ")#emph[#text("matrix product states")]#text(" (MPS) to states whose matrices are diagonal of Schmidt rank ")#mi("r")#text(" … the physical point being that ")#mi("r")#text(" then bounds the Schmidt rank of ")#emph[#text("all")]#text(" of the ")#mi("2^(m-1)")#text(" state-space bipartitions. MPS’s like ")#mi("V")#text(" are natural in general-purpose quantum simulation precisely because they have (due to their diagonal restriction) no natural ordering among the spins.")

#text("Since we engineers are going to be exploring Corollary 13 in large dimensions numerically, it would be useful for us to know (in advance) whether we might simply replace ")#mi("d \\to f(j,m,r)")#text(" for some specified function ")#mi("f")#text(".")

#text("Might ")#mi("d \\to f(j,n,r) =?= (2jm+1)r")#text(" … as follows if we approximate $V$ as a linear subspace? Here we welcome all the mathematical guidance we can get, from *any* reader(s) of this weblog!")

#text("And please accept also our apology, in advance, should it happen that the function ")#mi("f(j,m,r)")#text(" is well-known, or obvious (or the latex of this post doesn’t render properly).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43109")[#strong[#text("254A, Notes 2: The central limit theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("[…] the previous set of notes, we were able to establish various tail bounds on . For instance, from Chebyshev’s inequality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e942430ff1257ac41f2cb8b03de7d52203ef174c36ddbff15f615d8ab4914902-8ddc25447f5bfeef892b40ed87c269f9cb4ec46df0a94ba282313a4ca3c594ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43117")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("The display after “Applying (10), we conclude that” in the proof of McDiarmids Inequality seems to be missing a less-or-equal sign.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e91b680ff407af54a27ddf743d4264eb25f17261b87c51e79f87e7601578096-be58656b42ba52a14be5d7544b6089df3988e99820fad2dc06ddccad7a8ad9e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arno")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43121")[#strong[#text("arno")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Hi!")#linebreak()#text(" nice entry… some comments:")#linebreak()#text(" – the way to derive concentration from logarithmic Sobolev inequality is called Herbst’s argument as you surely know… and as the same technique may be applied (with technical details) to other functional inequalities… you should perhaps mention it…")#linebreak()#text(" – Mc Diarmid’s method, as well as Hoeffding’s inequality, may be considered in the larger framework of transportation’s inequality as studied initially By Marton and also Talagrand, and a very elegant way to derive concentration property… Mc Diarmid’s being then a way to tensorize these inequalities… however, it perhaps implies to consider other quantities (such as wasserstein’s distance) that you do not want to use here…")

#text("best regards")

#emph[#text("[Good suggestions, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43122")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("The link to “divide and conquer argument” right before Theorem 4 is not working")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The operator norm of a random matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43152")[#strong[#text("254A, Notes 3: The operator norm of a random matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("[…] bounding can be viewed as a non-commutative analogue of upper bounding the quantity studied in Notes 1. (The analogue of the central limit theorem in Notes 2 is the Wigner semi-circular law, which will […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("in equation ")#mi("(3),")#text(" there is an extra ")#mi("{\\bf E}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("in Theorem 2, ")#mi("(11)")#text(" on the right hand side, we are taking maximum but I do not see with respect to which variable the max is taken.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43174")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("max(x,y) is simply the larger of the two quantities x and y.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("in exercise ")#mi("(2)")#text(", is it ")#mi("\\leq")#text(" or ")#mi("\\geq")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("It is ")#mi("\\geq")#text(". The idea here is to show that Stirling’s formula can be used to provide a lower bound to complement the upper bounds proven in the text.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("I see. Thanks Prof. Tao")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab534a8f210b7cf9df4446d8db37ac4c66c9daafd983558d524c978586bd377-240112ddbb705ed9e4227fe8af6e34f039e5a6a1a89b991de7041335fc3c4c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43183")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("some pedantic typos/details:")

#text("1.”gives a crude upper bound on[sic] when”")

#text("2. Hoeffding’s inequality (exercise 4): P not E")

#text("3. I suppose it’s no coincidence that Theorems 2,3 are (essentially) the crux of the proof of Khintchine’s inequality (on the unit interval). Kahane’s inequality even can be dealt with using “exponential-type” estimates of a distribution function, though the argument I know is more combinatorial (and perhaps “more basic”) in nature.")

#text("4(a). [inconsequential detail] proof of theorem 8, first use of Jensen’s,")#linebreak()#text(" some pi/2’s (and 2/pi’s) need to be inverted? e.g.")

#text("\\displaystyle \\exp( t (f(X) – f(Y))) \\leq \\frac{2}{\\pi} \\int_0^{\\pi/2} \\exp( \\frac{\\pi t}{2} \\frac{d}{d\\theta} f( X_\\theta ) )\\ d\\theta.")

#text("etc.")

#text("4(b). f should be F")

#text("4(c). final bound should be exp(Ct^2)?")#linebreak()#text(" (Laplace transform of Gaussian is, essentially, a Gaussian)?")

#text("5. definition of combinatorial support: “to be the[sic] all”")

#text("6. final equation: errant E on the left, errant \\leq in the middle")

#emph[#text("[Thanks for the corrections! Yes, Khintchine’s inequality can be viewed as part of the family of large deviation inequalities proven by the exponential moment method; I’ve added a remark to this effect -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43271")[#strong[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] all , then one easily verifies (using Exercise 9 of Notes 1) that is a Wiener […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0234b91df9e05f47a6e3f584a1aa54103db34b32ab39ed8c0f51e620a3dc9715-c5267ace8714f947c89e9bbba459dfb6fb16610805bf07b76b4c5568ea53bcd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43330")[#strong[#text("Sean")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2010")])]

#text("At the risk of everyone saying “Oh no, not this guy again” are you aware of my idea of combining the Walsh Hadamard transform and randomly selected permutations to transform arbitrary numerical data into data with a Gaussian distribution? Basically it maps one point on a hypersphere to another random point on the hypersphere. The mapping is reversible. If you look up how to pick a point uniformly at random on the surface of a hypersphere you will see that one method involves random numbers with a Gaussian distribution.")#linebreak()#text(" I only do informal hobby research but I hope that is useful.")#linebreak()#text(" ")#link("http://code.google.com/p/lemontree/downloads/list")[#text("http://code.google.com/p/lemontree/downloads/list")]

#text("Sean O’Connor")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("In the comment following equation (8) it seems that that statement “so we may assume that $\\lambda$ is large compared to this quantity”, should read “\\lambda” is small compared to this quantity” (otherwise we have the null statement $|S_n| >>n$)")

#text("Best")

#emph[#text("[Thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2010")])]

#text("Can someone please post the solution to exercise 11.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43462")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] As will hopefully become clearer in the next set of notes, the semi-circular law is the noncommutative (or free probability) analogue of the central limit theorem, with the semi-circular distribution (1) taking on the role of the normal distribution. Of course, there is a striking difference between the two distributions, in that the former is compactly supported while the latter is merely subgaussian. One reason for this is that the concentration of measure phenomenon is more powerful in the case of ESDs of Wigner matrices than it is for averages of iid variables; compare the concentration of measure results in Notes 3 with those in Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43550")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Dear Prof. Tao,")

#text("I finished reading this chapter. I had some problems:")

#text("1. In the proof of the strong LLN, if we choose ")#mi("N_m=n_m")#text(", I didn’t see why ")#tao-math("\\sum \\frac{1}{n_m} E\\left|X_{\\leq N_m}\\right|^2<\\infty", block: false)#text(" since we only assume the first order moment for ")#mi("X")#text(".")

#text("2. In Ex 7, I can get the bounds ")#mi("\\exp\\{-c_A n^{p/2}\\}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("1. This follows from the pointwise bound ")#tao-math("\\sum_m \\frac{1}{n_m} \\left|X_{\\leq n_m}\\right|^2 \\leq C \\left|X\\right|", block: false)#text(" which ultimately comes from the lacunary nature of the ")#mi("n_m")#text(".")

#text("2. Hmm, that’s strange, because one should get exponential bounds when p >= 1. (For instance, when p=1, one can use the fact that E exp(cX) is bounded for small c to get exponential bounds, see e.g. Lemma 1 of Notes 3.) It may be that your choice of parameters is not fully optimal.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43557")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Thanks!")

#text("I understood 2, but still have some problem for 1: the constant ")#mi("C")#text(" should depend on the sample ")#mi("\\omega")#text(", ")#tao-math("E C\\left|X\\right|=\\infty", block: false)#text(" is possible. To apply Borel-Cantelli Lemma, we need the expectation to be strictly less than ")#mi("\\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43558")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("The constant C is uniform. This is because the expression ")#tao-math("\\sum_m \\frac{1}{n_m} \\left|X_{\\leq n_m}\\right| = \\left|X\\right| \\sum_{m: n_m \\geq \\left|X\\right|} \\frac{1}{n_m}", block: false)#text(" is uniformly bounded (e.g. if the ")#mi("n_m")#text(" are powers of 2, then this quantity is always bounded by 2, by the geometric series formula.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43566")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] probability, though if free probability is combined with tools such as concentration of measure (Notes 1) then such rate information can often be recovered. For similar reasons, free probability lets one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("Dear Prof Tao,")

#text("thanks for these very nice lectures.")#linebreak()#text(" Shouldn’t \\sigma^2 be a \\sigma in McDiarmid’s inequality ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: The least singular value « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-43789")[#strong[#text("254A, Notes 7: The least singular value « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")])]

#text("[…] Talagrand’s inequality (Notes 1), we expect each to be of size on the average, which suggests that ; this is consistent with the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("Suppose one weakens the hypotheses of the above concentration of measure results, e.g.,by removing the assumption of finite mean and variance, or by weakening independence assumptions. It seems that such weaker assumptions are needed in certain interesting applications, such as financial modelling. Is there still some sort of universal behavior, such as convergence in distribution to some universal “fat tailed” distribution, that reasonable combinations of such random variables exhibit?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44245")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2010")])]

#text("I believe the theory of ")#link("http://en.wikipedia.org/wiki/Stable_distribution")[#text("stable laws")]#text(" addresses these sorts of issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2010")])]

#text("Thanks for the reference.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("In Exercise 11, I got the proof for one direction, but do not know how to prove that the statement in Exercise 11 implies Theorem 8. Could you give a relatively detailed hint?")

#text("by the way, one of the “dt” in the proof of Theorem 8 should be replaced with “d\\theta”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("Thanks for the correction!")

#text("To get Theorem 8 from Exercise 11, first prove a variant of Theorem 8 in which the expectation is replaced by the median. To prove that variant, argue by contradiction and look at various level sets of F.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("Would it be right to say that Azuma’s inequality is already present in Hoeffding’s 1963 paper (see top of page 18 there), ditto for McDiarmid’s inequality?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44587")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("Yes, the attribution here can become somewhat complicated; for instance, one can make the case that Hoeffding’s inequality, Azuma’s inequality, and McDiarmid’s inequality were all implicitly present in the work of Bernstein several decades earlier (and are not far off from the work of Chernoff either). Certainly I have seen Azuma’s inequality, for instance, referred to instead as the Azuma-Hoeffding inequality.")

#text("Assigning attribution to a result is not a completely precise science; one has to draw the line somewhere between speculating that the result is true, asserting the result without proof, giving a nearly complete sketch, implicitly stating and proving the result en route to some other goal, giving the proof with full details, to giving applications and popularising the result (for instance by explicitly stating it as the main theorem of a paper). At a more practical level, it is also a matter of what name has taken hold in the community (it is unlikely, for instance, that L’Hopital’s rule or Stokes’ theorem will ever be renamed after their original discoverers); currently Azuma’s inequality seems to have a slight edge over Azuma-Hoeffding, though both are acceptable in my view.")

#text("See also “")#link("http://en.wikipedia.org/wiki/Stigler%27s_law_of_eponymy")[#text("Stigler’s law of eponymy")]#text("“.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2010")])]

#text("Dear Professor Tao,")

#text("Is the convex function requirement for the function F necessary? (In the Talagrand concentration inequality and also in the Log-Solobev inequality?)")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-44621")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("The condition for convexity can be relaxed somewhat, but I believe there are counterexamples to show that it cannot be dispensed with entirely. Ledoux’s book will surely have a thorough discussion of this issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-111431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2011")])]

#text("I’m belatedly returning to this question to record a concrete counterexample. On ")#mi("\\{0,1\\}^n")#text(", consider the function ")#tao-math("F(x) := \\max( \\min( \\left|x\\right|, n/2 + \\sqrt{n} ), n/2 - \\sqrt{n} ) / n^{1/4}", block: false)#text(", where ")#tao-math("\\left|x\\right| := \\left|x_1\\right| + \\ldots + \\left|x_n\\right|", block: false)#text(" is the l^1 (or Hamming) norm. This is O(1)-Lipschitz on ")#mi("\\{0,1\\}^n")#text(", and can thus be extended (in a non-convex manner) to a O(1)-Lipschitz function on ")#mi("{\\bf R}^n")#text(", but concentrates at scale ")#mi("O(n^{1/4})")#text(" rather than at scale O(1).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-112032")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2011")])]

#text("Do you want to swap the order of max and min there? I am also not seeing that it is 1-Lipschitz (wrt Euclidean distance). I get ")#tao-math("\\left|F(x)-F(y)\\right|\\le \\left|\\left|x\\right|-\\left|y\\right|\\right|/n^{1/4}\\le \\left|x-y\\right|/n^{1/4}\\le \\sqrt{n}\\left|x-y\\right|_E/n^{1/4}", block: false)#text(", and all of these are sharp, getting a Lipschitz constant of ")#mi("n^{1/4}")#text(", consistent with the scale of concentration.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-112033")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2011")])]

#text("this reply is so nested the last inequality disappeared! ")#tao-math("\\left|x-y\\right|/n^{1/4}\\le \\sqrt{n}\\left|x-y\\right|_E/n^{1/4}", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-112067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2011")])]

#text("Thanks for the correction! To establish the Lipschitz property, note that F only has a range of ")#mi("O(n^{1/4})")#text(", so it suffices to verify the Lipschitz claim when ")#tao-math("\\left|x-y\\right|_E = O(n^{1/4})", block: false)#text(", which on the unit cube then gives ")#tao-math("\\left|x-y\\right|_{\\ell^1} = \\left|x-y\\right|_E^2 \\ll n^{1/4} \\left|x-y\\right|_E", block: false)#text(". F has a Lipschitz constant of ")#mi("n^{-1/4}")#text(" wrt the ")#mi("\\ell^1")#text(" norm, and hence of norm ")#mi("O(1)")#text(" wrt the Euclidean norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-112072")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2011")])]

#text("Ah right, I see now how my inequalities forget the range of ")#mi("F")#text(". Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-121728")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("Ledoux’s example is also on ")#mi("\\{0,1\\}^n")#text(". Let ")#mi("n")#text(" even and let ")#mi("A")#text(" be the “hereditary” set ")#mi("\\{y:\\sum y_i\\le n/2\\}")#text(" (such sets ")#mi("\\{y:\\sum y_i\\le \\epsilon \\}")#text(" are extremal in the sense of isoperimetry for the Hamming metric on the discrete cube). Let ")#mi("F(x)=d(x,A)")#text(" be the Euclidean distance from ")#mi("x\\in {\\bf R}^n")#text(" to ")#mi("A")#text(". ")#mi("F")#text(" is 1-Lipschitz but not convex.")

#text("Now let ")#mi("P")#text(" be the uniform product measure on ")#mi("\\{0,1\\}^n")#text(" and consider the subset ")#mi("B_\\delta = \\{x: \\sum x_i - n/2\\ge \\delta\\sqrt{n} \\}")#text(" with ")#mi("\\delta")#text(" to be chosen later. Then for any ")#mi("x\\in B_\\delta \\subset \\{0,1\\}^n")#text(" and any ")#mi("y\\in A")#text(", ")#tao-math("\\delta\\sqrt{n}\\le \\sum x_i-n/2 \\le \\sum (x_i-y_i) \\le \\sum \\left|x_i-y_i\\right|^2", block: false)#text(", so that ")#mi("B_\\delta\\subset \\{d(x,A)\\ge\\sqrt{\\delta}n^{1/4}\\}")#text(". Hence, ")#mi("P(\\{F(x)\\ge\\sqrt{\\delta}n^{1/4}\\})\\ge P(\\{\\frac{\\sum x_i - n/2}{\\sqrt{n}}\\ge \\delta\\}) \\ge 1/10")#text(" for ")#mi("\\delta")#text(" sufficiently small independent of ")#mi("n")#text(", by the Central Limit theorem (or just Stirling’s formula).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-46692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2010")])]

#text("Dear Prof. Tao")

#text("I have a question about Gaussian Concentration Inequality for Lipschitz Function.")

#text("Let ")#mi("F_i=\\frac{\\sum_{i=1}^{n}z_{ij}^2}{\\sqrt {n}}(i=1,\\ldots,m)")#text(", where ")#mi("z_{ij}\\sim N(0,1)(j=1,\\ldots,n)")#text(" are iid real Gaussian variables. We have already known ")#mi("F_i^2\\sim\\frac{\\chi_n^2}{n}(i=1,\\ldots,m)")#text(" and can prove ")#mi("F_i")#text(" is Lipschitz Function with Lipschitz Constant ")#mi("\\frac{1}{\\sqrt {n}}")#text(".")

#text("According to the proof of Theorem 8, we can get")#linebreak()#text(" ")#mi("E\\exp(\\frac{\\pi t}{2}\\nabla F_i(X_\\theta)\\cdot X^{\\prime}_\\theta)\\leq\\exp(\\frac{\\pi^2 t^2}{8n})")#text(",")#linebreak()#text(" then")#linebreak()#text(" ")#mi("P(F_i-EF_i\\geq\\lambda)\\leq \\exp(\\frac{\\pi^2 t^2}{8n}-t\\lambda)")#text(".")#linebreak()#text(" Optimising in t , we have")#linebreak()#text(" ")#mi("P(F_i-EF_i\\geq\\lambda)\\leq \\exp(-\\frac{2n\\lambda^2}{\\pi^2})")#text(".")#linebreak()#text(" Since")#linebreak()#text(" ")#mi("EF_i=\\frac{\\sqrt{2}\\Gamma(\\frac{n+1}{2})}{\\sqrt {n}\\Gamma(\\frac{n}{2})}")#text(",")#linebreak()#text(" we can get")#linebreak()#text(" ")#mi("P(F_i\\geq\\frac{\\sqrt{2}\\Gamma(\\frac{n+1}{2})}{\\sqrt {n}\\Gamma(\\frac{n}{2})}+\\lambda)\\leq\\exp(-\\frac{2n\\lambda^2}{\\pi^2})")#text(",")#linebreak()#text(" then")#linebreak()#text(" ")#mi("P(\\max_i F_i\\geq\\frac{\\sqrt{2}\\Gamma(\\frac{n+1}{2})}{\\sqrt {n}\\Gamma(\\frac{n}{2})}+\\lambda)\\leq m\\exp(-\\frac{2n\\lambda^2}{\\pi^2})")#text(".")

#text("Above mentioned are what I can get by Theorem 8. But I have saw a result that one can get")#linebreak()#text(" ")#mi("P(\\max_i F_i\\geq1+\\lambda)\\leq \\exp(-\\frac{n\\lambda^2}{2})")#linebreak()#text(" by Gaussian Concentration. Can we get this result in your opinion? If your answer is YES. Can you tell me why? Some hints will be OK.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-46716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("I met this question when read one of Donoho’s papers.")

#link("http://www-stat.stanford.edu/~donoho/Reports/2004/l1l0EquivCorrected.pdf")[#text("Click to access l1l0EquivCorrected.pdf")]

#text("It seems that the question which has haunted me nearly a week has not yet been settled. Is it so difficult?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-46705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" I hope I can have your advice about the question mentioned in above comment. Your experience will be important to a student interested in Concentration of Measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db7469d55ebfc29a4eeb62a0d6204ef39d147d7c27f8ab699acc452237e22522-c3fdfdc2f3e9cd2df54bcf496d99d0cfdf919eb079f90f9ce4d088ae58440fc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camilo Chaparro")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-47579")[#strong[#text("Camilo Chaparro")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2010")])]

#text("Prof. Tao. I’m doing a research about matrices and measure theory. Can you send me directions or websites where I can find information about those topics? Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-49856")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")])]

#text("Dear Prof. Tao,")

#text("I cannot fully understand what a “sharp” inequality EXACTLY mean here. I read your post on Google buzz about sharp estimate. And there is another passage on Wikipedia which mentions the mathematical jargon “sharp”. By I get confused when I try to give examples. Like “")#mi("(a+b)^2\\geq 0")#text(" is sharp” but “")#mi("(a+b)^2\\geq -1")#text(" is not sharp”? What about ")#mi("a^2+b^2\\geq 2ab")#text(" and ")#mi("a^2+b^2\\geq ab (a\\geq 0,b\\geq 0)")#text("? In the finite dimension space, one has ")#tao-math("\\left\\|a\\right\\|_14\\leq\\left\\|a\\right\\|_6", block: false)#text(" where ")#mi("a\\in {\\Bbb R}^n")#text(". But as long as ")#mi("6<p<14")#text(", one has ")#tao-math("\\left\\|a\\right\\|_14\\leq\\left\\|a\\right\\|_p\\leq \\left\\|a\\right\\|_6", block: false)#text(". So ")#tao-math("\\left\\|a\\right\\|_14\\leq\\left\\|a\\right\\|_6", block: false)#text(" is not sharp?")

#text("You mentioned in your Google buzz that \"These are exact inequalities such as X <= Y without any unspecified constants or error terms (or X <= CY with an extremely explicit C, typically involving special constants such as pi or e). \" It seems that this is only a issue about the constant C. (Even when one has X<=Z<=Y, X<=Y can still be sharp?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-49870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2011")])]

#text("There are varying degrees of sharpness. An inequality ")#mi("X \\leq Y")#text(" is usually considered (exactly) sharp if ")#mi("X")#text(" can be equal to ")#mi("Y")#text(" in some non-trivial cases. (The more non-trivial cases for which equality is nearly attained, the sharper the inequality becomes; thus equalities ")#mi("X = Y")#text(" are the sharpest inequalities of all.) A weaker notion of sharpness than exact sharpness is sharpness up to constants: ")#mi("X \\leq CY")#text(" is sharp up to constants if one has ")#mi("X \\geq cY")#text(" in non-trivial cases. One can also have sharpness up to logarithms, sharpness up to epsilon factors in the exponents, etc.")

#text("One can also consider sharpness in various exponent parameters; if an estimate holds for all exponents p in a certain range, and that range is best possible in that the estimate breaks down outside that range, then the endpoints of that range are considered sharp exponents for the inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7dbcc7aab8fbcf7e230ed3c5f9c2fcf6959d1a89727ad02f8e3a99049cd854e-7781e5f2e5c01883ff922c84ec8fda4c488b0c1435e01f7d5e205d4eb371b93a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pan")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-49939")[#strong[#text("Pan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2011")])]

#text("Dear Professor:")

#text("I have a question about Sobolev Spaces. Suppose there exists a sequence of functions u_n is bounded in W^{2,\\infty}. Then we know, by compactness, there exists a subsequence u_k which weakly converges to a function u in W^{2,\\infty}. But is that possible that the 1st derivative of u_k converges weakly to the 1st derivative of u? As well as the 2nd derivative of u_k?")

#text("Thank you very much professor!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/739241df8cfc450bfcf642fd1c60b466cd43bda2255ab10f7dfb94c07a8a39a3-effc2ea31959cb1ceae88fcb9ce0f7591c04dc8b59258e28357d3c591e3820d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Meng")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-50190")[#strong[#text("Meng")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2011")])]

#text("Dear Prof. Tao,")

#text("I have a question about the decay rate of the sum of i.i.d. random variables.")

#text("If x_i are i.i.d. N(0,1), S_n =\\sum_i |x_i|. What is the sharpest bound of")

#text("P(|S_n-nE[|x_i|]|>cn) for ANY c>0?")

#text("Could I apply Proposition 6? It requires |x_i| to be subgaussian, and c sufficiently large though. Can I use it here?")

#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaodong")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-51669")[#strong[#text("Xiaodong")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Dear Prof. Tao,")

#text("I have a question about Theorem 8 and 9. Do we have a similar result for the concentration of the 1-Lipschitz function when the probability space is a sub-Gaussian product measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-97037")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2011")])]

#text("Hi Terry,")

#text("In the introductory section, I guess you mean one is *within* $O(\\log^{\\frac12}n)$ standard deviations with high probability and *within* $O(\\log^{\\frac12+\\epsilon}n)$ standard deviations with overwhelming probability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-97038")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2011")])]

#text("Yes, this is correct. With my conventions for O() notation, a quantity which is ")#mi("O(X)")#text(" has an upper bound by a constant times X, but does not necessarily have a lower bound. (I occasionally use ")#mi("\\Theta(X)")#text(" for a quantity which has both an upper and lower bound, though nowadays I prefer to avoid using such notation as it is not as widely understood as the O() notation.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Scorsese")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-433614")[#strong[#text("Martin Scorsese")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("Concerning your comment from the 26 October, 2011 at 8:10 am: The way you defined asymptotic notation in the first Definition from “Notes 0”, is contradictory to your comment, I believe: Here you define “$Z$ is $O(X)$” if $Z\\leq CX$, but in the first definition a lower bound is also provided: $|Z|\\leq CX$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-433653")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("In my comment, I was referring to a lower bound of the form ")#mi("Z > cX")#text(" (or ")#tao-math("\\left|Z\\right| > cX", block: false)#text(", if Z is signed) for some strictly positive constant c (such a lower bound is assumed in some variants of the O() notation that one occasionally sees in the literature).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb967dd337b4403a9dd36c9b48641d43352bb1797f4bc6907b1c51e6dc0471ee-3ed973f3dd88f0c3c371a4808972391fb81d5765640b1a0a7b91874832e861c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raj")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-119525")[#strong[#text("Raj")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2011")])]

#text("Dear Prof. Tao,")

#text("Consider the function")

#text("$f(z) = 1/( u^{H} (zI – X_n)^{-2} u)")

#text("where u is a n x 1 unit norm vector with uniform distribution on the sphere and X is an independent random diagonal matrix with real eigenvalues \\lambda_{1}, \\lambda_{n}. Assume that the spectral measure on the eigenvalues on X_n converges almost surely as n-> to a non-random measure \\mu_X that is compactly supported on [a,b].")

#text("For arbitrary z \\in [a,b],, it seems that f(z) – a.s. -> 0 because the numerator of u^{H} (zI – X_n)^{-2} u is O(1/n) while the denominator is O(1/n^2).")

#text("What would be the easiest way to make the above argument rigorous? Can one do so without requiring any level repulsion type assumption on the eigenvalues of X_n?")

#text("I’ve enjoyed reading your notes and the elegance of your presentations.")

#text("Thanks,")

#text("Raj")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4813b01709b13063d1f3496aca97f8e2138ab445e8922336da01387bd600cc4-72fc5567c4150dbdb75d37911c5cdb351071374124fae9b4e5bac2ca10a2345d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-127673")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Dear Prof. Tao,")

#text("I enjoyed your excellent post.")#linebreak()#text(" However, I did not find anything about Khinchine-Kahane or Khinchine inequalities I am also interested in. Please, lead me to your posts or give me an advise for a good book.")

#text("Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-141602")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2012")])]

#text("I think the line under equation (24) should have conditioning on ")#mi("X_n")#text(": ")#tao-math("e^{f(X_n)}\\left|f^{\\prime}(X_n)\\right|^2=e^{-f(X_n)}\\left|{\\bf E}(e^{F(X)}F_{x_n}(X)|X_n)\\right|^2", block: false)#text(". It is to this conditional expectation we apply Cauchy-Schwarz. Then we can take expectations and need an ")#mi("{\\bf E}")#text(" on the left hand side of the next line: ")#tao-math("{\\bf E}e^{f(X_n)}\\left|f^{\\prime}(X_n)\\right|^2\\le {\\bf E}e^{F(X)}\\left|F_{x_n}(X)\\right|^2", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0870856c30d6521f80f5d02dfe33beb593564175f804062ada061bcbe2047d6c-251f92423b96916f17553faf5b68d9437d11c19e89530050dd3bf159df5ee60a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahriman")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-149852")[#strong[#text("Ahriman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("Dear Prof. Tao,")

#text("I don’t understand fully your proof of the McDiarmid’s inequality.")#linebreak()#text(" How do you show that ")#mi("tY")#text(" fluctuates by ")#mi("tc_n")#text(" for latex $X_1, …, X_n$ fixed, and then, how do you apply (10), which says nothing about conditionnal expectations ?")

#text("Maybe I’m not familiar enough with conditional expectations …")

#text("Thank you very much,")#linebreak()#text(" Ahriman.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-149929")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("If ")#mi("X_1,\\ldots,X_{n-1}")#text(" are fixed, then ")#mi("{\\bf E}(F(X)|X_1,\\ldots,X_n)")#text(" is deterministic (i.e. it is just a scalar constant, rather than a random variable), and by hypothesis ")#mi("F(X)")#text(" only fluctuates by ")#mi("c_n")#text(", so ")#mi("Y")#text(" does also. One then applies (10) to the random variable Y (which is a random variable in the conditioned probability space arising after fixing ")#mi("X_1,\\ldots,X_{n-1}")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0870856c30d6521f80f5d02dfe33beb593564175f804062ada061bcbe2047d6c-251f92423b96916f17553faf5b68d9437d11c19e89530050dd3bf159df5ee60a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahriman")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-150110")[#strong[#text("Ahriman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("I think the problem comes from the fact that I don’t understand what “")#mi("X_1, ..., X_{n-1}")#text(" are fixed” means.")#linebreak()#text(" I don’t see also why ")#mi("F_{n-1}")#text(" satisfies the same hypotheses as ")#mi("F")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-150113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Conditional expectation is discussed in Section 4 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(". If one is unfamiliar with conditional expectation, it is probably best to begin with the discrete case, when all the X_i are discrete random variables. In this case, fixing the X_i means selecting deterministic elements ")#mi("x_1,...,x_{n-1}")#text(" of ")#mi("R_1,...,R_{n-1}")#text(" and working with conditional expectations such as ")#mi("F_{n-1}(x_1,\\ldots,x_n) := E(F(X)|X_1=x_1,...,X_{n-1}=x_{n-1})")#text(", which (by the independence) is also equal to ")#mi("E( F(x_1,\\ldots,x_{n-1},X_n) )")#text("; the random variable Y then has the distribution of ")#mi("F(x_1,\\ldots,x_{n-1},X_n) - E(F(x_1,\\ldots,x_{n-1},X_n)")#text(" for each fixed choice of values ")#mi("x_1,\\ldots,x_{n-1}")#text(" of ")#mi("X_1,\\ldots,X_{n-1}")#text(". From the triangle inequality for expectations we see that fluctuation properties of F are inherited by the average ")#mi("F_{n-1}(x_1,\\ldots,x_n) = E( F(x_1,\\ldots,x_{n-1},X_n) )")#text("; for instance, if ")#tao-math("\\left|F(x_1,\\ldots,x_{n-2},x_{n-1},x_n)-F(x_1,\\ldots,x_{n-2},x^{\\prime}_{n-1},x_n)\\right| \\leq c_{n-1}", block: false)#text(" for all ")#mi("x_1,\\ldots,x_n, x^{\\prime}_{n-1}")#text(", then by the triangle inequality ")#tao-math("E \\left|F(x_1,\\ldots,x_{n-2},x_{n-1},X_n)-F(x_1,\\ldots,x_{n-2},x^{\\prime}_{n-1},X_n)\\right| \\leq c_{n-1}", block: false)#text(" and thus ")#tao-math("\\left|E F(x_1,\\ldots,x_{n-2},x_{n-1},X_n) - F(x_1,\\ldots,x_{n-2},x^{\\prime}_{n-1},X_n)\\right| \\leq c_{n-1}", block: false)#text(", so that ")#mi("F_{n-1}")#text(" only fluctuates by at most ")#mi("c_{n-1}")#text(" in the ")#mi("x_{n-1}")#text(" variable.")

#text("If you are more familiar with measure theory than with probability theory, it can be an instructive exercise to write out the argument in measure-theoretic terms, say in the simple case when n=2 and the variable X_1, X_2 are just Bernoulli distributions on {0,1} with a probability 1/2 of each, avoiding all use of probabilistic language. While this is ultimately not the most efficient way to think about such arguments, it can serve as a stepping stone towards a more probabilistic way of thinking.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0870856c30d6521f80f5d02dfe33beb593564175f804062ada061bcbe2047d6c-251f92423b96916f17553faf5b68d9437d11c19e89530050dd3bf159df5ee60a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahriman")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-150136")[#strong[#text("Ahriman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Thank you a lot for yours answers, and time you spent writing it. The case of a finite probability space is clear for me.")#linebreak()#text(" Your definition of conditional expectation is not the same as the one I know. I have to rethink about it. In particular, I always tried to keep away those notions of disintegration.")#linebreak()#text(" Thank you again.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-165685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("Dear Professor Tao,")

#text("I see most of the results here are about indepdendent random variables. What is your opinion and knowledge of any literature on concentration for random variables which are not independent? Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-165699")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("I can offer some buzz words! For measures on manifolds other than product spaces, the logarithmic Sobolev inequality machinery can be employed – check out Ledoux’s book. “Dumber” methods like spectral gap / Poincare inequality may be sufficient at times. See also Sourav Chatterjee’s PhD thesis on using exchangeable pairs to get concentration inequalities, with applications to e.g. spin systems. Ledoux’s book also seems to cover transportation cost inequalities.")

#text("Sometimes there is a trick to express the variables in terms of independent variables. For example, the coordinates of a uniform random point on the simplex ")#mi("X=(X_1,\\dots,X_n)")#text(" (with the dependence relation ")#mi("X_1+\\cdots +X_n=1")#text(") can be expressed in terms of independent rate $n$ exponential random variables ")#mi("Y_1,\\dots,Y_n")#text(" via ")#mi("X_i=Y_i/(\\sum_{j=1}^n Y_j)")#text(". (That is, the coordinates ")#mi("X_i")#text(" have beta distribution.)")

#text("It really depends on the flavor of the dependence – dependent random variables seem to be like nonlinear PDE in that there can’t be any general methodology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chowla conjecture and the Sarnak conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-182163")[#strong[#text("The Chowla conjecture and the Sarnak conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("[…] Finally, this exponentially high concentration can be achieved by the moment method, using a slight variant of the moment method proof of the large deviation estimates such as the Chernoff inequality or Hoeffding inequality (as discussed in this blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-182588")[#strong[#text("Hoeffding bound | blayz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")]

#text("[…] sections of the book Topics in Random Matrix Theory by Terry Tao, with his draft and relevant notes available online, and the Hoeffding’s original paper along with the paper by Serfling. I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2df588265e1df6dcfb8c7dc09da2efeae9adbaa16ff667620f159bc909486e0-d34417fd07382aa110675f7f2c6b07ed7a22a1e63a8a0c10e95452b23d1755c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-198349")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2012")])]

#text("Dear Prof. Tao,")

#text("I am a bit unsure of what Exercise 7 is asking – is it asking to prove the result only for sufficiently large A (as in Proposition 6), or for all A > 0 (as in Exercise 6)?")

#text("Thanks.")

#emph[#text("[The former; one could consider combining both generalisations, but this would be a separate problem. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-207750")[#strong[#text("The Rosenblog » Azuma’s Inequality and Concentration")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2012")]

#text("[…] I just posted an essay which gives some applications of Azuma’s inequality to combinatorics and theoretical computer science, which is available here. Azuma’s inequality is an example of the concentration of measure phenomenon, which has rich applications in combinatorics, probability theory and Banach space theory. This book gives a very thorough survey of the phenomenon, although it approaches the subject from a very geometric/measure theoretic standpoint. A more condensed (and perhaps user-friendly) overview is available on Terence Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some notes on Bakry-Emery theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-215890")[#strong[#text("Some notes on Bakry-Emery theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("[…] inequalities can also be used to establish concentration of measure inequalities; see for instance this previous blog post for an instance of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/comment-page-1/#comment-229140")[#strong[#text("חסם צ'רנוף, חסם אנטרופיה ומה שביניהם | One and One")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")]

#text("[…] לקריאה נוספת: פוסט של טרי טאו על ריכוז של מידה. […]")
]
