// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/
// Converted to Typst by tao2typ: "2026-10-14T11:13:01.265976+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quaternions and spherical trigonometry", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quaternions and spherical trigonometry")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 December 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/")[#text("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Hamilton’s ")#link("https://en.wikipedia.org/wiki/Quaternion")[#text("quaternion number")]#text(" system ")#mi("{\\mathbb{H}}")#text(" is a non-commutative extension of the complex numbers, consisting of numbers of the form ")#mi("{t + xi + yj + zk}")#text(" where ")#mi("{t,x,y,z}")#text(" are real numbers, and ")#mi("{i,j,k}")#text(" are anti-commuting square roots of ")#mi("{-1}")#text(" with ")#mi("{ij=k}")#text(", ")#mi("{jk=i}")#text(", ")#mi("{ki=j}")#text(". While they are non-commutative, they do keep many other properties of the complex numbers:")

#list(
[#text("Being non-commutative, the quaternions do not form a field. However, they are still a ")#link("https://en.wikipedia.org/wiki/Division_ring")[#text("skew field")]#text(" (or division ring): multiplication is associative, and every non-zero quaternion has a unique multiplicative inverse.")],
[#text("Like the complex numbers, the quaternions have a conjugation")

#align(center)[#tao-fit-display[#mitex("\\overline{t+xi+yj+zk} := t-xi-yj-zk,")]]

#text("although this is now an ")#link("https://en.wikipedia.org/wiki/Antihomomorphism")[#text("antihomomorphism")]#text(" rather than a homomorphism: ")#mi("{\\overline{qr} = \\overline{r}\\ \\overline{q}}")#text(". One can then split up a quaternion ")#mi("{t + xi + yj + zk}")#text(" into its real part ")#mi("{t}")#text(" and imaginary part ")#mi("{xi+yj+zk}")#text(" by the familiar formulae")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} q := \\frac{q + \\overline{q}}{2}; \\quad \\mathrm{Im} q := \\frac{q - \\overline{q}}{2}")]]

#text("(though we now leave the imaginary part purely imaginary, as opposed to dividing by ")#mi("{i}")#text(" in the complex case).")],
[#text("The inner product")

#align(center)[#tao-fit-display[#mitex("\\langle q, r \\rangle := \\mathrm{Re} q \\overline{r}")]]

#text("is symmetric and positive definite (with ")#mi("{1,i,j,k}")#text(" forming an orthonormal basis). Also, for any ")#mi("{q}")#text(", ")#mi("{q \\overline{q}}")#text(" is real, hence equal to ")#mi("{\\langle q, q \\rangle}")#text(". Thus we have a norm")

#align(center)[#tao-fit-display[#tao-math("\\left|q\\right| = \\sqrt{q\\overline{q}} = \\sqrt{\\langle q,q \\rangle} = \\sqrt{t^2 + x^2 + y^2 + z^2}.", block: true)]]

#text("Since the real numbers commute with all quaternions, we have the multiplicative property ")#tao-math("{\\left|qr\\right| = \\left|q\\right| \\left|r\\right|}", block: false)#text(". In particular, the unit quaternions ")#tao-math("{U(1,\\mathbb{H}) := \\{ q \\in \\mathbb{H}: \\left|q\\right|=1\\}}", block: false)#text(" (also known as ")#mi("{SU(2)}")#text(", ")#mi("{Sp(1)}")#text(", or ")#mi("{Spin(3)}")#text(") form a compact group.")],
[#text("We have the ")#link("https://en.wikipedia.org/wiki/Trace_(linear_algebra)#Cyclic_property")[#text("cyclic trace property")]

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re}(qr) = \\mathrm{Re}(rq)")]]

#text("which allows one to take adjoints of left and right multiplication:")

#align(center)[#tao-fit-display[#mitex("\\langle qr, s \\rangle = \\langle q, s\\overline{r}\\rangle; \\quad \\langle rq, s \\rangle = \\langle q, \\overline{r}s \\rangle")]]],
[#text("As ")#mi("{i,j,k}")#text(" are square roots of ")#mi("{-1}")#text(", we have the usual Euler formulae")

#align(center)[#tao-fit-display[#mitex("e^{i\\theta} = \\cos \\theta + i \\sin \\theta, e^{j\\theta} = \\cos \\theta + j \\sin \\theta, e^{k\\theta} = \\cos \\theta + k \\sin \\theta")]]

#text("for real ")#mi("{\\theta}")#text(", together with other familiar formulae such as ")#mi("{\\overline{e^{i\\theta}} = e^{-i\\theta}}")#text(", ")#mi("{e^{i(\\alpha+\\beta)} = e^{i\\alpha} e^{i\\beta}}")#text(", ")#tao-math("{\\left|e^{i\\theta}\\right| = 1}", block: false)#text(", etc.")]
)

#text("We will use these sorts of algebraic manipulations in the sequel without further comment.")

#text("The unit quaternions ")#tao-math("{U(1,\\mathbb{H}) = \\{ q \\in \\mathbb{H}: \\left|q\\right|=1\\}}", block: false)#text(" act on the imaginary quaternions ")#mi("{\\{ xi + yj + zk: x,y,z \\in {\\bf R}\\} \\equiv {\\bf R}^3}")#text(" by conjugation:")

#align(center)[#tao-fit-display[#mitex("v \\mapsto q v \\overline{q}.")]]

#text("This action is by orientation-preserving isometries, hence by rotations. It is not quite faithful, since conjugation by the unit quaternion ")#mi("{-1}")#text(" is the identity, but one can show that this is the only loss of faithfulness, reflecting the well known fact that ")#mi("{U(1,\\mathbb{H}) \\equiv SU(2)}")#text(" is a double cover of ")#mi("{SO(3)}")#text(".")

#text("For instance, for any real ")#mi("{\\theta}")#text(", conjugation by ")#mi("{e^{i\\theta/2} = \\cos(\\theta/2) + i \\sin(\\theta/2)}")#text(" is a rotation by ")#mi("{\\theta}")#text(" around ")#mi("{i}")#text(": ")#metadata(none) <tao-a5c77cca2bcc94aba60b>#mi("\\displaystyle  e^{i\\theta/2} i e^{-i\\theta/2} = i \\ \\ \\ \\ \\ (1)")#text(" ")#text(" ")#metadata(none) <tao-f3436f50b2f7f1613ad1>#mi("\\displaystyle  e^{i\\theta/2} j e^{-i\\theta/2} = \\cos(\\theta) j + \\sin(\\theta) k \\ \\ \\ \\ \\ (2)")#text(" ")#text(" ")#metadata(none) <tao-b459afddb3a09621ee29>#mi("\\displaystyle  e^{i\\theta/2} k e^{-i\\theta/2} = \\cos(\\theta) k - \\sin(\\theta) j. \\ \\ \\ \\ \\ (3)")#text(" ")#text(" Similarly for cyclic permutations of ")#mi("{i,j,k}")#text(". The doubling of the angle here can be explained from the Lie algebra fact that ")#mi("{[i,j]=ij-ji}")#text(" is ")#mi("{2k}")#text(" rather than ")#mi("{k}")#text("; it also closely related to the aforementioned double cover. We also of course have ")#mi("{U(1,\\mathbb{H})\\equiv Spin(3)}")#text(" acting on ")#mi("{\\mathbb{H}}")#text(" by left multiplication; this is known as the ")#link("https://en.wikipedia.org/wiki/Spinor")[#text("spinor representation")]#text(", but will not be utilized much in this post. (Giving ")#mi("{\\mathbb{H}}")#text(" the right action of ")#mi("{{\\bf C}}")#text(" makes it a copy of ")#mi("{{\\bf C}^2}")#text(", and the spinor representation then also becomes the standard representation of ")#mi("{SU(2)}")#text(" on ")#mi("{{\\bf C}^2}")#text(".)")

#text("Given how quaternions relate to three-dimensional rotations, it is not surprising that one can also be used to recover the basic laws of ")#link("https://en.wikipedia.org/wiki/Spherical_trigonometry")[#text("spherical trigonometry")]#text(" – the study of spherical triangles on the unit sphere. This is fairly well known, but it took a little effort for me to locate the required arguments, so I am recording the calculations here.")

#text("The first observation is that every unit quaternion ")#mi("{q}")#text(" induces a unit tangent vector ")#mi("{qj\\overline{q}}")#text(" on the unit sphere ")#mi("{S^2 \\subset {\\bf R}^3}")#text(", located at ")#mi("{qi\\overline{q} \\in S^2}")#text("; the third unit vector ")#mi("{qk\\overline{q}}")#text(" is then another tangent vector orthogonal to the first two (and oriented to the left of the original tangent vector), and can be viewed as the cross product of ")#mi("{qi\\overline{q} \\in S^2}")#text(" and ")#mi("{qj\\overline{q} \\in S^2}")#text(". Right multplication of this quaternion then corresponds to various natural operations on this unit tangent vector:")

#list(
[#text("Right multiplying ")#mi("{q}")#text(" by ")#mi("{e^{i\\theta/2}}")#text(" does not affect the location ")#mi("{qi\\overline{q}}")#text(" of the tangent vector, but rotates the tangent vector ")#mi("{qj\\overline{q}}")#text(" anticlockwise by ")#mi("{\\theta}")#text(" in the direction of the orthogonal tangent vector ")#mi("{qk\\overline{q}}")#text(", as it replaces ")#mi("{qj\\overline{q}}")#text(" by ")#mi("{\\cos(\\theta) qj\\overline{q} + \\sin(\\theta) qk\\overline{q}}")#text(".")],
[#text("Right multiplying ")#mi("{q}")#text(" by ")#mi("{e^{k\\theta/2}}")#text(" advances the tangent vector by geodesic flow by angle ")#mi("{\\theta}")#text(", as it replaces ")#mi("{qi\\overline{q}}")#text(" by ")#mi("{\\cos(\\theta) qi\\overline{q} + \\sin(\\theta) qj\\overline{q}}")#text(", and replaces ")#mi("{qj\\overline{q}}")#text(" by ")#mi("{\\cos(\\theta) qj\\overline{q} - \\sin(\\theta) qi\\overline{q}}")#text(".")]
)

#text("Now suppose one has a spherical triangle with vertices ")#mi("{A,B,C}")#text(", with the spherical arcs ")#mi("{AB, BC, CA}")#text(" subtending angles ")#mi("{c, a, b}")#text(" respectively, and the vertices ")#mi("{A,B,C}")#text(" subtending angles ")#mi("{\\alpha,\\beta,\\gamma}")#text(" respectively; suppose also that ")#mi("{ABC}")#text(" is oriented in an anti-clockwise direction for sake of discussion. Observe that if one starts at ")#mi("{A}")#text(" with a tangent vector oriented towards ")#mi("{B}")#text(", advances that vector by ")#mi("{c}")#text(", and then rotates by ")#mi("{\\pi - \\beta}")#text(", the tangent vector now at ")#mi("{B}")#text(" and pointing towards ")#mi("{C}")#text(". If one advances by ")#mi("{a}")#text(" and rotates by ")#mi("{\\pi - \\gamma}")#text(", one is now at ")#mi("{C}")#text(" pointing towards ")#mi("{A}")#text("; and if one then advances by ")#mi("{b}")#text(" and rotates by ")#mi("{\\pi - \\alpha}")#text(", one is back at ")#mi("{A}")#text(" pointing towards ")#mi("{B}")#text(". This gives the fundamental relation ")#metadata(none) <tao-e77c4b3f81059b97c4d2>#mi("\\displaystyle  e^{kc/2} e^{i(\\pi-\\beta)/2} e^{ka/2} e^{i(\\pi-\\gamma)/2} e^{kb/2} e^{i(\\pi-\\alpha)/2} = 1 \\ \\ \\ \\ \\ (4)")#text(" ")#text(" relating the three sides and three equations of this triangle. (")#emph[#text("A priori")]#text(", due to the lack of faithfulness of the ")#mi("{U(1,\\mathbb{H})}")#text(" action, the right-hand side could conceivably have been ")#mi("{-1}")#text(" rather than ")#mi("{1}")#text("; but for extremely small triangles the right-hand side is clearly ")#mi("{1}")#text(", and so by continuity it must be ")#mi("{1}")#text(" for all triangles.) Indeed, a moments thought will reveal that the condition ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" is necessary and sufficient for the data ")#mi("{a,b,c,\\alpha,\\beta,\\gamma}")#text(" to be associated with a spherical triangle. Thus one can view ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" as a “master equation” for spherical trigonometry: in principle, it can be used to derive all the other laws of this subject.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The law ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" has an evident symmetry ")#mi("{(a,b,c,\\alpha,\\beta,\\gamma) \\mapsto (\\pi-\\alpha,\\pi-\\beta,\\pi-\\gamma,\\pi-a,\\pi-b,\\pi-c)}")#text(", which corresponds to the operation of replacing a spherical triangle with its dual triangle. Also, there is nothing particularly special about the choice of imaginaries ")#mi("{i,k}")#text(" in ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text("; one can conjugate ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" by various quaternions and replace ")#mi("{i,k}")#text(" here by any other orthogonal pair of unit quaternions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" If we work in the small scale regime, replacing ")#mi("{a,b,c}")#text(" by ")#mi("{\\varepsilon a, \\varepsilon b, \\varepsilon c}")#text(" for some small ")#mi("{\\varepsilon>0}")#text(", then we expect spherical triangles to behave like Euclidean triangles. Indeed, ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" to zeroth order becomes")

#align(center)[#tao-fit-display[#mitex("e^{i(\\pi-\\beta)/2} e^{i(\\pi-\\gamma)/2} e^{i(\\pi-\\alpha)/2} = 1")]]

#text("which reflects the classical fact that the sum of angles of a Euclidean triangle is equal to ")#mi("{\\pi}")#text(". To first order, one obtains")

#align(center)[#tao-fit-display[#mitex("c + a e^{i(\\pi-\\gamma)/2} e^{i(\\pi-\\alpha)/2} + b e^{i(\\pi-\\alpha)/2} = 0")]]

#text("which reflects the evident fact that the vector sum of the sides of a Euclidean triangle sum to zero. (Geometrically, this correspondence reflects the fact that the action of the (projective) quaternion group on the unit sphere converges to the action of the special Euclidean group ")#mi("{SE(2)}")#text(" on the plane, in a suitable asymptotic limit.)")
]

#text("The identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" is an identity of two unit quaternions; as the unit quaternion group ")#mi("{U(1,\\mathbb{H})}")#text(" is three-dimensional, this thus imposes three independent constraints on the six real parameters ")#mi("{a,b,c,\\alpha,\\beta,\\gamma}")#text(" of the spherical triangle. One can manipulate this constraint in various ways to obtain various trigonometric identities involving some subsets of these six parameters. For instance, one can rearrange ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(4)")]#text(" to get ")#metadata(none) <tao-6036ebabccb1c49c31ea>#mi("\\displaystyle  e^{i(\\pi-\\beta)/2} e^{ka/2} e^{i(\\pi-\\gamma)/2} = e^{-kc/2} e^{-i(\\pi-\\alpha)/2} e^{-kb/2}. \\ \\ \\ \\ \\ (5)")#text(" ")#text(" Conjugating by ")#mi("{i}")#text(" to reverse the sign of ")#mi("{k}")#text(", we also have")

#align(center)[#tao-fit-display[#mitex("e^{i(\\pi-\\beta)/2} e^{-ka/2} e^{i(\\pi-\\gamma)/2} = e^{kc/2} e^{-i(\\pi-\\alpha)/2} e^{kb/2}.")]]

#text("Taking the inner product of both sides of these identities, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle e^{i(\\pi-\\beta)/2} e^{ka/2} e^{i(\\pi-\\gamma)/2}, e^{i(\\pi-\\beta)/2} e^{-ka/2} e^{i(\\pi-\\gamma)/2} \\rangle")]]

#text("is equal to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{-kc/2} e^{-i(\\pi-\\alpha)/2} e^{-kb/2}, e^{kc/2} e^{-i(\\pi-\\alpha)/2} e^{kb/2} \\rangle.")]]

#text("Using the various properties of inner product, the former expression simplifies to ")#mi("{\\mathrm{Re} e^{ka} = \\cos a}")#text(", while the latter simplifies to")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} \\langle e^{-i(\\pi-\\alpha)/2} e^{-kb} e^{i(\\pi-\\alpha)/2}, e^{kc} \\rangle.")]]

#text("We can write ")#mi("{e^{kc} = \\cos c + (\\sin c) k}")#text(" and")

#align(center)[#tao-fit-display[#mitex("e^{-i(\\pi-\\alpha)/2} e^{-kb} e^{i(\\pi-\\alpha)/2} = \\cos b - (\\sin b) (\\cos(\\pi-\\alpha) k + \\sin(\\pi-\\alpha) j)")]]

#text("so on substituting and simplifying we obtain")

#align(center)[#tao-fit-display[#mitex("\\cos b \\cos c + \\sin b \\sin c \\cos \\alpha = \\cos a")]]

#text("which is the ")#link("https://en.wikipedia.org/wiki/Spherical_law_of_cosines")[#text("spherical cosine rule")]#text(". Note in the infinitesimal limit (replacing ")#mi("{a,b,c}")#text(" by ")#mi("{\\varepsilon a, \\varepsilon b, \\varepsilon c}")#text(") this rule becomes the familiar Euclidean cosine rule")

#align(center)[#tao-fit-display[#mitex("a^2 = b^2 + c^2 - 2bc \\cos \\alpha.")]]

#text("In a similar fashion, from ")#link(<tao-6036ebabccb1c49c31ea>)[#text("(5)")]#text(" we see that the quantity")

#align(center)[#tao-fit-display[#mitex("\\langle e^{i(\\pi-\\beta)/2} e^{ka/2} e^{i(\\pi-\\gamma)/2} i e^{-i(\\pi-\\gamma)/2} e^{-ka/2} e^{-i(\\pi-\\beta)/2}, k \\rangle")]]

#text("is equal to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{-kc/2} e^{-i(\\pi-\\alpha)/2} e^{-kb/2} i e^{kb/2} e^{i(\\pi-\\alpha)/2} e^{kc/2}, k \\rangle.")]]

#text("The first expression simplifies by ")#link(<tao-a5c77cca2bcc94aba60b>)[#text("(1)")]#text(" and properties of the inner product to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{ka/2} i e^{-ka/2}, e^{-i(\\pi-\\beta)/2} k e^{i(\\pi-\\beta)/2} \\rangle,")]]

#text("which by ")#link(<tao-f3436f50b2f7f1613ad1>)[#text("(2)")]#text(", ")#link(<tao-b459afddb3a09621ee29>)[#text("(3)")]#text(" simplifies further to ")#mi("{\\sin a \\sin \\beta}")#text(". Similarly, the second expression simplifies to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{-kb/2} i e^{kb/2} , e^{i(\\pi-\\alpha)/2} k e^{-i(\\pi-\\alpha)/2}\\rangle,")]]

#text("which by ")#link(<tao-f3436f50b2f7f1613ad1>)[#text("(2)")]#text(", ")#link(<tao-b459afddb3a09621ee29>)[#text("(3)")]#text(" simplifies to ")#mi("{\\sin b \\sin \\alpha}")#text(". Equating the two and rearranging, we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sin \\alpha}{\\sin a} = \\frac{\\sin \\beta}{\\sin b}")]]

#text("which is the ")#link("https://en.wikipedia.org/wiki/Law_of_sines#The_spherical_law_of_sines")[#text("spherical sine rule")]#text(". Again, in the infinitesimal limit we obtain the familiar Euclidean sine rule")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sin \\alpha}{a} = \\frac{\\sin \\beta}{b}.")]]

#text("As a variant of the above analysis, we have from ")#link(<tao-6036ebabccb1c49c31ea>)[#text("(5)")]#text(" again that")

#align(center)[#tao-fit-display[#mitex("\\langle e^{i(\\pi-\\beta)/2} e^{ka/2} e^{i(\\pi-\\gamma)/2} i e^{-i(\\pi-\\gamma)/2} e^{-ka/2} e^{-i(\\pi-\\beta)/2}, j \\rangle")]]

#text("is equal to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{-kc/2} e^{-i(\\pi-\\alpha)/2} e^{-kb/2} i e^{kb/2} e^{i(\\pi-\\alpha)/2} e^{kc/2}, j \\rangle.")]]

#text("As before, the first expression simplifies to")

#align(center)[#tao-fit-display[#mitex("\\langle e^{ka/2} i e^{-ka/2}, e^{-i(\\pi-\\beta)/2} j e^{i(\\pi-\\beta)/2} \\rangle")]]

#text("which equals ")#mi("{\\sin a \\cos \\beta}")#text(". Meanwhile, the second expression can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\langle e^{-i(\\pi-\\alpha)/2} e^{-kb/2} i e^{kb/2} e^{i(\\pi-\\alpha)/2}, e^{kc/2} j e^{-kc/2} \\rangle.")]]

#text("By ")#link(<tao-f3436f50b2f7f1613ad1>)[#text("(2)")]#text(", ")#link(<tao-b459afddb3a09621ee29>)[#text("(3)")]#text(" we can simplify")

#align(center)[#tao-fit-display[#mitex("e^{-i(\\pi-\\alpha)/2} e^{-kb/2} i e^{kb/2} e^{i(\\pi-\\alpha)/2}")]]

#align(center)[#tao-fit-display[#mitex("= (\\cos b) i - (\\sin b) \\cos(\\pi-\\alpha) j + (\\sin b) \\sin(\\pi-\\alpha) k")]]

#text("and so the inner product is ")#mi("{\\cos b \\sin c - \\cos b \\sin c \\cos \\alpha}")#text(", leading to the “")#link("https://en.wikipedia.org/wiki/Spherical_trigonometry#Five-part_rules")[#text("five part rule")]#text("”")

#align(center)[#tao-fit-display[#mitex("\\cos b \\sin c - \\sin b \\cos c \\cos \\alpha = \\sin a \\cos \\beta.")]]

#text("In the case of a right-angled triangle ")#mi("{\\beta=\\pi/2}")#text(", this simplifies to one of ")#link("https://en.wikipedia.org/wiki/Spherical_trigonometry#Napier's_rules_for_right_spherical_triangles")[#text("Napier’s rules")]

#metadata(none) <tao-50d858e0985ecc7f6041>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\cos \\alpha = \\frac{\\tan c}{\\tan b},")]]

#text("which in the infinitesimal limit is the familiar ")#mi("{\\cos \\alpha = \\frac{c}{b}}")#text(". The other rules of Napier can be derived in a similar fashion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" One application of Napier’s rule ")#link(<tao-50d858e0985ecc7f6041>)[#text("(6)")]#text(" is to determine the ")#link("https://en.wikipedia.org/wiki/Sunrise_equation")[#text("sunrise equation")]#text(" for when the sun rises and sets at a given location on the Earth, and a given time of year. For sake of argument let us work in summer, in which the ")#link("https://en.wikipedia.org/wiki/Declination")[#text("declination")]#text(" ")#mi("{\\delta}")#text(" of the Sun is positive (due to ")#link("https://en.wikipedia.org/wiki/Axial_tilt")[#text("axial tilt")]#text(", it reaches a maximum of ")#mi("{23.5^\\circ}")#text(" at the summer solstice). Then the Sun subtends an angle of ")#mi("{\\pi/2-\\delta}")#text(" from the pole star (")#link("https://en.wikipedia.org/wiki/Polaris")[#text("Polaris")]#text(" in the northern hemisphere, ")#link("https://en.wikipedia.org/wiki/Sigma_Octantis")[#text("Sigma Octantis")]#text(" in the southern hemisphere), and appears to rotate around that pole star once every ")#mi("{24}")#text(" hours. On the other hand, if one is at a latitude ")#mi("{\\phi}")#text(", then the pole star an elevation of ")#mi("{\\phi}")#text(" above the horizon. At extremely high latitudes ")#mi("{\\phi > \\pi/2-\\delta}")#text(", the sun will never set (a phenomenon known as “")#link("https://en.wikipedia.org/wiki/Midnight_sun")[#text("midnight sun")]#text("“); but in all other cases, at sunrise or sunset, the sun, pole star, and horizon point below the pole star will form a right-angled spherical triangle, with hypotenuse subtending an angle ")#mi("{\\pi/2-\\delta}")#text(" and vertical side subtending an angle ")#mi("{\\phi}")#text(". The angle subtended by the pole star in this triangle is ")#mi("{\\pi-\\omega}")#text(", where ")#mi("{\\omega}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Hour_angle#Solar")[#text("solar hour angle")]#text(" ")#mi("{\\omega}")#text(" – the angle that the sun deviates from its noon position. Equation ")#link(<tao-50d858e0985ecc7f6041>)[#text("(6)")]#text(" then gives the ")#emph[#text("sunrise equation")]

#align(center)[#tao-fit-display[#mitex("\\cos(\\pi-\\omega) = \\frac{\\tan \\phi}{\\tan(\\pi/2-\\delta)}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\cos \\omega = - \\tan \\phi \\tan \\delta.")]]

#text("A similar rule determines the time of sunset. In particular, the number of daylight hours in summer (assuming one is not in the midnight sun scenario ")#mi("{\\phi > \\pi/2 -\\delta}")#text(") is given by")

#align(center)[#tao-fit-display[#mitex("24 - \\frac{24}{\\pi} \\mathrm{arccos}(\\tan \\phi \\tan \\delta).")]]

#text("The situation in winter is similar, except that ")#mi("{\\delta}")#text(" is now negative, and ")#link("https://en.wikipedia.org/wiki/Polar_night")[#text("polar night")]#text(" (no sunrise) occurs when ")#mi("{\\phi > \\pi/2+\\delta}")#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("The article appears to end in the middle of a sentence.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("‘once every 24 days’, read: ‘once every 24 hours’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ec9ab6f2c2916fde7d466db10fb7dcc609a330c5fceb6670d5c761ef261d32d-a4913dd55644b47bcf16c47f618a905231f6151cc464102a7655b4ba1733310f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quixote5446")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686941")[#strong[#text("quixote5446")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("This makes me think about making the chess equation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("The statement of the antihomorphism looks wrong.")

#emph[#text("[Space added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686943")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2024")])]

#text("“For sake of argument let us work in summer”")

#text("Let the record show that Terry went without summers for four years straight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686945")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2024")])]

#text("As a homework exercise we should similarly recover hyperbolic trigonometry from ")#mi("\\mathrm{SL}_2(\\mathbb{R})")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2024")])]

#text("Ah, that is indeed a great exercise! The adjoint representation of ")#mi("\\mathrm{SL}_2({\\mathbb R})")#text(" on its Lie algebra ")#mi("\\mathfrak{sl}_2({\\mathbb R})")#text(" preserves the (traceless) matrices of unit determinant, which are a model for the hyperbolic plane (after quotienting out by ")#mi("\\pm 1")#text("), and thus also acts on the unit tangent bundle of that plane, so presumably the algebra should all work out (indeed it should all be a Wick rotation of the spherical version).")

#text("Presumably one can do similar analysis involving quaternion algebras over any field (except possibly the characteristic two ones), perhaps after using a more algebraic description of the unit circle/hyperbola than the trigonometric/hyperbolic trigonometric one (e.g., as ")#mi("SO(2)")#text(" or ")#mi("SO(1,1)")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686948")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2024")])]

#text("Yes, ")#mi("\\mathrm{PSL}_2(\\mathbb{R})")#text(" is the unit tangent bundle of the hyperbolic plane, similar to how the hopf fibration realizes the unit tangent bundle of the sphere as ")#mi("\\mathrm{SU(2)}")#text(" (mod ")#mi("\\pm 1")#text(").")

#text("I guess you’re right and this should work over any field as long as we use the matrix entries as the coordinates")

#text("E.g. in the hyperbolic case we would use ")#mi("e^a")#text(" for the side of length ")#mi("a")#text(" which would make ")#mi("\\sinh a,\\cosh a")#text(" algebraic; in terms of the angles and lengths everything is transcendental.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686955")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2024")])]

#text("For consistency with the previous formula, you should write the familiar Euclidian cosine rule")

#mi("b^2 + c^2 -2bc \\cos(\\alpha) = a^2")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2024")])]

#link("https://arxiv.org/abs/1411.4999")[#text("https://arxiv.org/abs/1411.4999")]#text(" ‘This expansion to “second order qubits” would imply either a larger gauge freedom or a natural space of hidden variables.’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686986")[#strong[#text("Double Maths First Thing: Issue 11 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2025")]

#text("[…] Terry Tao on quaternions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb8ee9d503e8392f2d77cfa96588986c2db619a92d07c2b64590f2ee8362a8fc-b9d213494ef42a25a8ee2716435fd4d650b3b7887f12cc3d387678d0c9ac3239.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sinai Coons")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686989")[#strong[#text("Sinai Coons")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2025")])]

#text("I’m submitting this comment prior to finishing due to (4) the master equation, I am curious as to whether the intersections between Heisenberg uncertainty (quantum noise reduction), as demonstrated by the exponents (the half-angle formulas) in the equation, when taken into account with the complex system, could still hold… Wouldn’t that be neat? I logged into my account in case my train of thought makes no sense, I would much appreciate being guided in the right direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2025")])]

#text("There is trigonometry over finite fields (")#link("https://math.stackexchange.com/questions/334754/how-does-trigonometry-in-a-galois-field-work")[#text("https://math.stackexchange.com/questions/334754/how-does-trigonometry-in-a-galois-field-work")]#text(") as well having sin(a+b) and cos(a+b) rules. Do we have such rules for spherical trigonometry over finite fields (whatever it means)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-686996")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2025")])]

#text("Yes (at least in odd characteristic); if one parameterizes the unit circle by ")#mi("\\{ (x,y): x^2+y^2=1\\}")#text(" rather than ")#mi("\\{ (\\cos \\theta, \\sin \\theta): \\theta \\in{\\mathbf R} \\}")#text(", then one can define the unit circle over any field without difficulty, and in the case of algebraically closed fields not of characteristic 2, they will behave quite similarly to the real unit circle as far as algebraic geometry is concerned. In particular, one should retain most of the spherical trigonometric identities (after this reparameterization) over finite fields of odd characteristic, with the caveat that sometimes one may need to pass to a quadratic extension due to the need to take square roots in order to express ")#mi("x")#text(" in terms of ")#mi("y")#text(" or vice versa on the unit circle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/362f362a7117988899ea8bd758ab9920efe815431dd057773dcd4fb87bbb939e-bfa4b6890a06014b339f519fd52ce1c257f5955c150767fe94b385094414da2b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687000")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2025")])]

#text("Can we relate octonions similarly to (any) geometry?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687006")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2025")])]

#text("The octonions are non-associative, so I would not expect them to act in an interesting fashion on any space in the same way that the quaternions act on things like the tangent bundle of the 2-sphere. On the other hand, the symmetry group of the octonions themselves is the exceptional Lie group ")#mi("G_2")#text(". This is a different type of relation – here it is ")#mi("G_2")#text(" acting on the octonions, rather than the octonions acting on something else – but it does connect the octonions with a modern geometrical object.")

#text("The unit octonions can be identified with the 7-sphere, and one can use them to build some operations on that sphere such as the octionic cross product, but I do not know to what extent one can describe such operations as “geometric”. (They do exhibit ")#mi("G_2")#text(" symmetry, though.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1e2f5f1404e8808e5948a97e5e01d0866c11705a1334490e189c22fc32a57a5-5db5edc36840ba3ca0b2c45bf8ec8256486d39f7786cdca2f80234191cc50f74.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687007")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2025")])]

#text("I enjoyed the post tying together into the mathematics behind the sunrise equation at the end.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2025")])]

#text("Thank you for this post! Some reader(s) might be interested in this formalisation of the theory of quaternions in the proof assistant Isabelle/HOL by Lawrence Paulson from 2018: ")#link("https://www.isa-afp.org/entries/Quaternions.html")[#text("https://www.isa-afp.org/entries/Quaternions.html")]#text(" . (I formalised the basics of octonions following his formalisation shortly afterwards: ")#link("https://www.isa-afp.org/entries/Octonions.html")[#text("https://www.isa-afp.org/entries/Octonions.html")]#text(" ). It would be great if someone would be interested in building on these formalisations to formalise more material on quaternions/octonions in Isabelle/HOL inspired by this post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687066")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2025")])]

#text("Besides complex numbers, quaternions and octonions, there’s also sedonions … all using powers of 2 (2, 4, 8 and 16 components).")

#text("So, if you’re playing with the first three, why stop there?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687047")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2025")])]

#text("Hello Sir Tao, Your explanation of how unit quaternions represent rotations in three dimensions and how they can be applied to spherical triangles is well-articulated. ")#linebreak()#text("What are the other areas of physics and engineering where quaternion representations can be used/implemented? ")#linebreak()#text("Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2025")])]

#text("Quaternions are a convenient algebraic tool to describe spinors in three and four dimensions, so I would imagine in particular that the quantum mechanics of fermions could in principle be described via quaternions. But I don’t know to what extent this is actually done in the physics literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2025")])]

#text("Thanks Sir Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b8db10c25d43bab6f0ff190d334d2e8efb9d12933b44bb29c03afb5b042fc44-19019d0882133fb2c830c0d44083b91ac04173f8e6f2a9b12bc1864269f00c5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 3co")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687144")[#strong[#text("3co")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2025")])]

#text("Wow! Just a casual hot tip for quantum physicists.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687060")[#strong[#text("Tao. Quaternions and spherical trigonometry – eryanghsu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2025")]

#text("[…] Quaternions and spherical trigonometry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687074")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2025")])]

#text("The octonions are also interesting, and one of only four spheres with a “homotopy group” structure – a multiplication with inverses but associative only up to homotopy.")

#text("This gives a unit sphere of S⁷ instead of S³, but it is not O(n) for any n.")

#text("My question- what could fill in the question mark in the below:")

#text("S⁰ | logic")

#text("S¹ | trigonometry")

#text("S³ | spherical trigonometry")

#text("S⁷ | ???")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2025")])]

#text("Evidently it doesn’t have one actually. Sorry for this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2025")])]

#text("Can you do the last example in function of minute of the day? to develop a simple calc of globally know the median luminosty of each part by coordinates with year-gap cycle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687157")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2025")])]

#text("Are the signs on the sine terms correct on Eqs.(2) and (3)? Since ")#mi("[i,j]=+2k")#text(" (and cyclic perm.) as stated on the line after Eq.(3), surely the signs should be the opposite, with Eq.(2) having ")#mi("+\\sin(\\theta)k")#text(" and Eq.(3) having ")#mi("- \\sin(\\theta)j")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/19/quaternions-and-spherical-trigonometry/#comment-687200")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2025")])]

#text("Your Remark 2 reminded me of a relation I arrived at last year (see blog linked below). Let x be any of α₁, β₁, or γ₁, and suppose α₁ + β₁ + γ₁ = π. Then:")

#text("e^(i(α₂ + β₂)) + e^(i(α₂ + γ₂)) + e^(i(β₂ + γ₂)) = 1")

#text("(where x ∈ ℝ such that (x + π)/(2π) ∉ ℤ),")

#text("with complex α₂ = arccos(csc(α₁)) and similarly for β₂ and γ₂. I wonder if there might be a connection to your note.")

#text("Blog link: ")#link("https://geometriadominicana.blogspot.com/2024/07/showing-frac1eialpha2-frac1eibeta2.html")[#text("https://geometriadominicana.blogspot.com/2024/07/showing-frac1eialpha2-frac1eibeta2.html")]
]
