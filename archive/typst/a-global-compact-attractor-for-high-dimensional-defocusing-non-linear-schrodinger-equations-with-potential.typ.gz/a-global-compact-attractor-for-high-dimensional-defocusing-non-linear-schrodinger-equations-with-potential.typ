// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/13/a-global-compact-attractor-for-high-dimensional-defocusing-non-linear-schrodinger-equations-with-potential/
// Converted to Typst by tao2typ: "2026-10-14T06:59:37.631575+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/13/a-global-compact-attractor-for-high-dimensional-defocusing-non-linear-schrodinger-equations-with-potential/")[#text("https://terrytao.wordpress.com/2008/05/13/a-global-compact-attractor-for-high-dimensional-defocusing-non-linear-schrodinger-equations-with-potential/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0805.1544")[#text("A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential")]#text("“, submitted to ")#link("http://intlpress.com/PDE/")[#text("Dynamics of PDE")]#text(". This paper continues some ")#link("http://arxiv.org/abs/math.AP/0309428")[#text("earlier work")]#text(" ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("of myself")]#text(" in an attempt to understand the ")#emph[#text("soliton resolution conjecture")]#text(" for various nonlinear dispersive equations, and in particular, ")#link("http://tosio.math.toronto.edu/wiki/index.php/Schrodinger_equations")[#text("nonlinear Schrödinger equations")]#text(" (NLS). This conjecture (which I also discussed in my third ")#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/")[#text("Simons lecture")]#text(") asserts, roughly speaking, that any reasonable (e.g. bounded energy) solution to such equations eventually resolves into a superposition of a radiation component (which behaves like a solution to the linear Schrödinger equation) plus a finite number of “nonlinear bound states” or “solitons”. This conjecture is known in many perturbative cases (when the solution is close to a special solution, such as the vacuum state or a ground state) as well as in defocusing cases (in which no non-trivial bound states or solitons exist), but is still almost completely open in non-perturbative situations (in which the solution is large and not close to a special solution) which contain at least one bound state. In ")#link("http://arxiv.org/abs/math.AP/0309428")[#text("my earlier")]#text(" ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("papers")]#text(", I was able to show that for certain NLS models in sufficiently high dimension, one could at least say that such solutions resolved into a radiation term plus a finite number of “weakly bound” states whose evolution was essentially almost periodic (or almost periodic modulo translation symmetries). These bound states also enjoyed various additional decay and regularity properties. As a consequence of this, in five and higher dimensions (and for reasonable nonlinearities), and assuming spherical symmetry, ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("I showed")]#text(" that there was a (local) ")#emph[#text("compact attractor")]#text(" ")#mi("K_E")#text(" for the flow: any solution with energy bounded by some given level E would eventually decouple into a radiation term, plus a state which converged to this compact attractor ")#mi("K_E")#text(". In that result, I did not rule out the possibility that this attractor depended on the energy E. Indeed, it is conceivable for many models that there exist nonlinear bound states of arbitrarily high energy, which would mean that ")#mi("K_E")#text(" must increase in size as E increases to accommodate these states. (I discuss these results in a ")#link("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/")[#text("recent talk")]#text(" of mine.)")

#text("In my new paper, following a suggestion of ")#link("http://www.columbia.edu/~miw2103/")[#text("Michael Weinstein")]#text(", I consider the NLS equation")

#align(center)[#tao-fit-display[#tao-math("i u_t + \\Delta u = \\left|u\\right|^{p-1} u + Vu", block: true)]]

#text("where ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^d \\to {\\Bbb C}")#text(" is the solution, and ")#mi("V \\in C^\\infty_0({\\Bbb R}^d)")#text(" is a smooth compactly supported real potential. We make the standard assumption ")#mi("1 + \\frac{4}{d} < p < 1 + \\frac{4}{d-2}")#text(" (which is asserting that the nonlinearity is mass-supercritical and energy-subcritical). In the absence of this potential (i.e. when V=0), this is the defocusing nonlinear Schrödinger equation, which is known to have no bound states, and in fact it is known in this case that all finite energy solutions eventually ")#emph[#text("scatter")]#text(" into a radiation state (which asymptotically resembles a solution to the linear Schrödinger equation). However, once one adds a potential (particularly one which is large and negative), both ")#emph[#text("linear ")]#text("bound states (solutions to the linear eigenstate equation ")#mi("(-\\Delta + V) Q = -E Q")#text(") and ")#emph[#text("nonlinear")]#text(" bound states (solutions to the nonlinear eigenstate equation ")#tao-math("(-\\Delta+V)Q = -EQ - \\left|Q\\right|^{p-1} Q", block: false)#text(") can appear. Thus in this case the soliton resolution conjecture predicts that solutions should resolve into a scattering state (that behaves as if the potential was not present), plus a finite number of (nonlinear) bound states. There is a fair amount of work towards this conjecture for this model in perturbative cases (when the energy is small), but the case of large energy solutions is still open.")

#text("In my new paper, I consider the large energy case, assuming spherical symmetry. For technical reasons, I also need to assume very high dimension ")#mi("d \\geq 11")#text(". The main result is the existence of a ")#emph[#text("global")]#text(" compact attractor K: every finite energy solution, no matter how large, eventually resolves into a scattering state and a state which converges to K. In particular, since K is bounded, all but a bounded amount of energy will be radiated off to infinity. Another corollary of this result is that the space of all nonlinear bound states for this model is compact. Intuitively, the point is that when the solution gets very large, the defocusing nonlinearity dominates any attractive aspects of the potential V, and so the solution will disperse in this case; thus one expects the only bound states to be bounded. The spherical symmetry assumption also restricts the bound states to lie near the origin, thus yielding the compactness. (It is also conceivable that the localised nature of V also restricts bound states to lie near the origin, even without the help of spherical symmetry, but I was not able to establish this rigorously.)")

#metadata(none) <tao-813b8ec66083429844c7>

#text("In view of my previous results concerning local compact attractors, the main difficulty is to show that spherically symmetric ")#emph[#text("almost periodic")]#text(" solutions – solutions which range inside a compact subset of the energy space – enjoy a universal upper bound on their energy and mass. (This can be viewed as a “quasi-Liouville theorem”, in analogy with other recent Liouville theorems in the literature which classify various types of almost periodic solutions.)")

#text("This is accomplished in two stages. Firstly, by extensive use of the Duhamel formula and the dispersive properties of the free Schrödinger propagator (as in my previous papers), one shows that spherically symmetric almost periodic solutions exhibit quite strong decay away from the origin (more than is predicted just from the finite energy hypothesis); indeed, they decay like the ")#link("http://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newton potential")]#text(" ")#tao-math("\\left|x\\right|^{2-d}", block: false)#text(" (which makes sense, if one looks at the bound state equation). In high dimension, this gives additional moment bounds on the solution. For instance, in 11 and higher dimensions, it implies that not only do almost periodic solutions have finite mass (which means that ")#tao-math("\\int_{{\\Bbb R}^d} \\left|u(t,x)\\right|^2\\ dx", block: false)#text(" is finite) but that the sixth moment ")#tao-math("\\int_{{\\Bbb R}^d} \\left|u(t,x)\\right|^2 \\left|x\\right|^6\\ dx", block: false)#text(" is also finite.")

#text("These moment conditions allow one to use some exotic virial identities. The basic virial identity for NLS is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\Bbb R}^d} \\nabla a \\cdot \\text{Im}( \\overline{u} \\nabla u )\\ dx")]]

#tao-aligned(keep: true)[


#tao-math(" & = 2 \\int_{{\\Bbb R}^d} \\text{Hess}(a)( \\nabla u, \\overline{\\nabla u} )\\ dx", block: true)



#tao-math(" & + \\frac{p-1}{p+1} \\int_{{\\Bbb R}^d} \\left|u\\right|^{p+1} \\Delta a\\ dx", block: true)



#tao-math(" & - \\frac{1}{2} \\int_{{\\Bbb R}^d} \\left|u\\right|^2 \\Delta \\Delta a\\ dx", block: true)



#tao-math(" & - \\int_{{\\Bbb R}^d} (\\nabla a \\cdot \\nabla V) \\left|u\\right|^2\\ dx", block: true)
]

#text("where ")#mi("a: {\\Bbb R}^d \\to {\\Bbb R}")#text(" is a weight function which has to obey some reasonable regularity and growth hypotheses but is otherwise arbitrary. The more moment conditions one has on u, the more rapid one can take the growth of a to be.")

#text("Different choices of the weight a yield different interesting consequences. For instance, ")#mi("a(x):=1")#text(" gives the momentum conservation law, while ")#tao-math("a(x) := \\left|x\\right|", block: false)#text(" gives the Morawetz inequalities. The choice ")#tao-math("a(x):=\\left|x\\right|^2", block: false)#text(" gives the virial identity of Glassey, which I use to establish a universal bound on the energy. It turns out that the choice ")#tao-math("a(x) := \\left|x\\right|^4", block: false)#text(" gives an identity that can give a universal bound on the mass (coming from the ")#mi("\\Delta \\Delta a")#text(" term in the identity), which yields the main theorem; the dimension hypothesis ")#mi("d \\geq 11")#text(" is needed to get enough decay on the almost periodic solution in order to justify the formal application of the virial identity with this quartic weight. (By working a bit harder I was able to weaken this hypothesis to ")#mi("d \\geq 7")#text(", but the correct hypothesis should be ")#mi("d \\geq 5")#text(", in analogy with the classical theory of resonances for the linear Schrödinger operator with potential.)")

#text("One technical feature that comes up when dealing with superquadratic weights such as ")#tao-math("\\left|x\\right|^4", block: false)#text(" is that the mass term that involves ")#mi("\\Delta \\Delta a")#text(" is negative, which looks unfavourable. Fortunately, it turns out that one can use ")#link("http://en.wikipedia.org/wiki/Hardy's_inequality")[#text("Hardy’s inequality")]#text(" and the term coming from the ")#link("http://en.wikipedia.org/wiki/Hessian_matrix")[#text("Hessian")]#text(" ")#mi("\\text{Hess}(a)")#text(" to convert this negative term into a positive one.")

#text("There is an amusing consequence of these results; once one has a global compact attractor for a PDE, it becomes possible ")#emph[#text("in principle")]#text(" to establish soliton resolution for this PDE by a finite amount of rigorous numerics on that attractor (or on some larger compact set containing that attractor), combined with some quantitative nonlinear stability results on all the soliton states. However such a program would be extremely complicated to execute in practice.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2008/05/13/a-global-compact-attractor-for-high-dimensional-defocusing-non-linear-schrodinger-equations-with-potential/#comment-29737")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2008")])]

#text("This is an excellent idea. I did ")#link("http://brannenworks.com/b_nonl.pdf")[#text("something similar, see section IV")]#text(" with Clifford / Geometric algebra (GA) a few years ago. The result was that a non linear Dirac equation can be rewritten as a set of stuff that moves according to the usual linear Dirac equation and a set of interactions.")

#text("A reason for starting with the Geometric Algebra (sometimes called “spacetime algebra” or “STA” by David Hestenes and followers) is that it makes Lorentz symmetry automatic. At the time I was working on 4+1 spacetime so it is only 5 dimensional. The GA on 3+1 dimensions is known to the physicists as the Dirac algebra and consists of the gamma matrices used to model spin-1/2 particles like the electron, neutrino or proton.")

#text("Another reason for using GA (or Clifford algebra) is that it gives you more dimensions per spacetime dimension, but my motivation at the time was to ")#link("http://brannenworks.com/a_fer.pdf")[#text("get the structure")]#text(" of the weak hypercharge and weak isospin quantum numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele")]], [#link("https://terrytao.wordpress.com/2008/05/13/a-global-compact-attractor-for-high-dimensional-defocusing-non-linear-schrodinger-equations-with-potential/#comment-627819")[#strong[#text("Michele")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2021")])]

#text("Dear Prof. Tao")

#text("I’m an italian studious of mathematics and theoretical physics.")#linebreak()#text(" I’m writing you because I studied your very interesting “A GLOBAL COMPACT ATTRACTOR FOR HIGH-DIMENSIONAL NON-LINEAR SCHRODINGER EQUATIONS”. What other papers of yours can you recommend me to consult in order to delve into these interesting topics? I’m grateful if You can show/suggest me other Your papers regarding this subject. I would need to deepen this argument to prepare my next papers in the best way. Best wishes")
]
