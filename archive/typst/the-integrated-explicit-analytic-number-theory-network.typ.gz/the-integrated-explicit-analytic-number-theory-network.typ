// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/
// Converted to Typst by tao2typ: "2026-10-14T15:21:09.652735+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The integrated explicit analytic number theory network", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The integrated explicit analytic number theory network")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 January 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/")[#text("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Like many other areas of modern analysis, analytic number theory often relies on the convenient device of asymptotic notation to express its results. It is common to use notation such as ")#mi("{X = O(Y)}")#text(" or ")#mi("{X \\ll Y}")#text(", for instance, to indicate a bound of the form ")#tao-math("{\\left|X\\right| \\leq C Y}", block: false)#text(" for some unspecified constant ")#mi("{C}")#text(". Such implied constants ")#mi("{C}")#text(" vary from line to line, and in most papers, one does not bother to compute them explicitly. This makes the papers easier both to write and to read (for instance, one can use asymptotic notation to conceal a large number of lower order terms from view), and also means that minor numerical errors (for instance, forgetting a factor of two in an inequality) typically has no major impact on the final results. However, the price one pays for this is that many results in analytic number theory are only true in asymptotic sense; a typical example is ")#link("https://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s theorem")]#text(" that every sufficiently large odd integer can be expressed as the sum of three primes. In the first few proofs of this theorem, the threshold for “sufficiently large” was not made explicit.")

#text("There is however a small portion of the analytic number theory devoted to ")#emph[#text("explicit")]#text(" analytic number theory estimates, in which all constants are made completely explicit (and many lower order terms are retained). For instance, whereas the prime number theorem asserts that the prime counting function ")#mi("{\\pi(x)}")#text(" is asymptotic to the logarithmic integral ")#mi("{\\mathrm{Li}(x) = \\int_2^x \\frac{dt}{\\log t}}")#text(", in ")#link("https://arxiv.org/abs/2206.12557")[#text("this recent paper of Fiori, Kadiri, and Swidinsky")]#text(" the explicit estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi(x) - \\mathrm{Li}(x)\\right| \\leq 9.2211 x \\sqrt{\\log x} \\exp(- 0.8476 \\sqrt{\\log x} )", block: true)]]

#text("is proven for all ")#mi("{x \\geq 2}")#text(".")

#text("Such explicit results follow broadly similar strategies of proof to their non-explicit counterparts, but require a significant amount of careful book-keeping and numerical optimization; furthermore, any given explicit analytic number theory paper is likely to rely on the numerical results obtained in previous explicit analytic number theory papers. While the authors make their best efforts to avoid errors and build in some redundancy into their work, there have unfortunately been a few cases in which an explicit result stated in the published literature contained numerical errors that placed the numerical constants in several downstream applications of these papers into doubt.")

#text("Because of this propensity for error, updating any given explicit analytic number theory result to take into account computational improvements in other explicit results (such as zero-free regions for the Riemann zeta function) is not done lightly; such updates occur on the timescale of decades, and only by a small number of specialists in such careful computations. This leads to authors needing such explicit results to often be forced to rely on papers that are a decade or more out of date, with constants that they know in principle can be improved by inserting more recent explicit inputs, but do not have the domain expertise to confidently update all the numerical coefficients.")

#text("To me, this situation sounds like an appropriate application of modern AI and formalization tools – not to replace the most enjoyable aspects of human mathematical research, but rather to allow extremely tedious and time-consuming, but still necessary, mathematical tasks to be offloaded to semi-automated or fully automated tools.")

#text("Because of this, I (acting in my capacity as Director of Special Projects at IPAM) have just launched the ")#link("https://www.ipam.ucla.edu/news-research/special-projects/integrated-explicit-analytic-number-theory-network/")[#text("integrated explicit analytic number theory network")]#text(", a project partially hosted within the existing “")#link("https://github.com/AlexKontorovich/PrimeNumberTheoremAnd")[#text("Prime Number Theorem And More")]#text("” (PNT+) formalization project. This project will consist of two components. The first is a crowdsourced formalization project to formalize a number of inter-related explicit analytic number theory results in Lean, such as the explicit prime number theorem of Fiori, Kadiri, and Swidinsky mentioned above; already some smaller results have been largely formalized, and we are making good progress (especially with the aid of modern AI-powered autoformalization tools) on several of the larger papers. The second, which will be run at IPAM with the financial and technical support of ")#link("https://www.math.inc/")[#text("Math Inc.")]#text(", will be to extract from this network of formalized results an interactive “spreadsheet” of a large number of types of such estimates, with the ability to add or remove estimates from the network and have the numerical impact of these changes automatically propagate to other estimates in the network, similar to how changing one cell in a spreadsheet will automatically update other cells that depend on it. For instance, one could increase or decrease the numerical threshold to which the Riemann hypothesis is verified, and see the impact of this change on the explicit error terms in the prime number theorem; or one could “roll back” all the literature to a given date, and see what the best estimates on various analytic number theory expressions could still be derived from the literature available at that date. Initially, this spreadsheet will be drawn from direct adaptations of the various arguments from papers formalized within the network, but in a more ambitious second stage of the project we plan to use AI tools to modify these arguments to find more efficient relationships between the various numerical parameters than were provided in the source literature.")

#text("These more ambitious outcomes will likely take several months before a working proof of concept can be demonstrated; but in the near term I will be grateful for any contributions to the formalization side of the project, which is being coordinated on the ")#link("https://leanprover.zulipchat.com/#narrow/channel/423402-PrimeNumberTheorem.2B/")[#text("PNT+ Zulip channel")]#text(" and on the ")#link("https://github.com/AlexKontorovich/PrimeNumberTheoremAnd")[#text("github repository")]#text(". We are using a github issues based system to coordinate the project, similar to how it was done for the Equational Theories Project. Any volunteer can select one of the outstanding formalization tasks on the ")#link("https://github.com/AlexKontorovich/PrimeNumberTheoremAnd/issues")[#text("Github issues page")]#text(" and “claim” it as a task to work on, eventually submitting a pull request (PR) to the repository when proposing a solution (or to “disclaim” the task if for whatever reason you are unable to complete it). As with other large formalization projects, an informal “blueprint” is ")#link("https://alexkontorovich.github.io/PrimeNumberTheoremAnd/blueprint/")[#text("currently under construction")]#text(" that breaks up the proofs of the main results of several explicit analytic number theory papers into bite-sized lemmas and sublemmas, most of which can be formalized independently without requiring broader knowledge of the arguments from the paper that the lemma was taken from. (A graphical display of the current formalization status of this blueprint can be found ")#link("https://alexkontorovich.github.io/PrimeNumberTheoremAnd/blueprint/dep_graph_document.html")[#text("here")]#text(". At the current time of writing, many portions of the blueprint are disconnected from each other, but as the formalization progresses, more linkages should be created.)")

#text("One minor innovation implemented in this project is to label each task by a “size” (ranging from XS (extra small) to XL (extra large)) that is a subjective assessment of the task difficulty, with the tasks near the XS side of the spectrum particularly suitable for beginners to Lean.")

#text("We are permitting AI use in completing the proof formalization tasks, though we require the AI use to be disclosed, and that the code is edited by humans to remove excessive bloat. (We expect some of the AI-generated code to be rather inelegant; but ")#emph[#text("no")]#text(" proof of these explicit analytic number theory estimates, whether human-generated or AI-generated, is likely to be all that pretty or worth reading for its own sake, so the downsides of using AI-generated proofs here are lower than in other use cases.) We of course require all submissions to typecheck correctly in Lean through Github’s Continuous Integration (CI) system, so that any incorrect AI-generated code will be rejected. We are also cautiously experimenting with ways in which AI can also automatically or semi-automatically generate the formalized ")#emph[#text("statements")]#text(" of lemmas and theorems, though here one has to be significantly more alert to the dangers of misformalizing an informally stated result, as this type of error cannot be automatically detected by a proof assistant.")

#text("We also welcome suggestions for additional papers or results in explicit analytic number theory to add to the network, and will have some blueprinting tasks in addition to the formalization tasks to convert such papers into a blueprinted sequence of small lemmas suitable for individual formalization.")

#text("Update: a personal log documenting the project may be found ")#link("https://github.com/AlexKontorovich/PrimeNumberTheoremAnd/wiki/Terence-Tao's-personal-log")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2026")])]

#text("Terence Tao is a gift to humanity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2026")])]

#text("There’s the initiative of Olivier Ramaré and colleagues which seems relevant: ")#link("https://ramare-olivier.github.io/TME-EMT/accueil.html")[#text("https://ramare-olivier.github.io/TME-EMT/accueil.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2026")])]

#text("Yes, when we have optimized our workflows a bit more we certainly plan to input the results from the TME-EMT network into our own network (initially as “sorries” with no proofs provided, but eventually with their proofs formalized also). Right now we are focusing a relatively small number of papers to see if we can actually accomplish an end-to-end explicit prime number theorem with all the prerequisite results from previous papers also formalized, but once we have that infrastructure set up it should be relatively straightforward to add these results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Pierro de Camargo")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691576")[#strong[#text("André Pierro de Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2026")])]

#text("Allow me to add that we are currently transfering Oliver’s project to a new site (see url below) to make updating and further mantainance easier. We shall create a wikipedia link to it when it is ready (there are still some typeseting and typos introduced during the transfer to be fixed).")

#text("The new webpage is: ")#link("https://tme-emt-wiki-gitlab-io-9d3436.gitlab.io/")[#text("https://tme-emt-wiki-gitlab-io-9d3436.gitlab.io/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-692316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2026")])]

#text("Just an update: the new site is:")

#link("https://archimede.pages.math.cnrs.fr/tme-emt-wiki/index.html")[#text("TME-EMT-Wiki 01 documentation")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/510c66552aeb522f5cb76b75c478fe636cf66825f909bb6c727daf61b2947f20-6dbbb40e17caf4d3068d1767901bd69105f87b499754457556d5c4ae80051e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of secretlyobject05ab30fe9f")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691612")[#strong[#text("secretlyobject05ab30fe9f")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2026")])]

#text("This project effectively moves the field from a ‘static archive’ model to a ‘continuous integration’ model.")

#text("By formalizing these explicit bounds, you are essentially treating a theorem not as a fixed artifact (a PDF), but as a function: $Theorem(Input_Bounds) to Output_Bounds$.")

#text("The ‘spreadsheet’ then acts as the runtime environment. The beauty of this approach is that it resolves the latency between a foundational improvement (e.g., a better zero-free region) and its downstream consequences. Instead of waiting decades for a new survey paper to ‘clear the cache,’ the network can just ‘recompile’ the dependent constants.")

#text("It suggests that eventually, the network itself becomes the canonical, dynamically maintained representation of the state of the art, with traditional papers serving as human-readable snapshots of particular states in the graph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("A major concern is this direction is how to handle the rounding errors introduced during the process. Say an explicit estimate E was obtained in a paper “A” by means of constants E_1, E_2, … E_k published elsewhere. When E_1, E_2 … E_k are updated, the new “E” shall be computed in finite precision and the rounding errors introduced in the computation of E must be taking into account.")

#text("This analysis is usually done by the researcher which is involved in the updating process, and it is not trivial how to automatize this part. In fact, it seems that the unique automatic tool that ensures reliable bounds for the computed “E” is Interval arithmetic. However, in some cases, it leads to non-realistic (although correct) bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/15/the-integrated-explicit-analytic-number-theory-network/#comment-691643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("If the analysis is formalized in Lean, it will have had to deal with these roundoff errors; floating point arithmetic is certainly not recognized as a valid substitute for exact arithmetic in Lean! Therefore in the updating process, one may initially use floating point arithmetic to obtain an initial guess for what values the updated downstream constants should be, but then one has to actually formalize this within Lean, and some small adjustments to the constants may then be needed if the roundoffs do not work in one’s favor. Based on some early AI experiments with my UCLA group we believe that current AI models are (barely) able to perform this type of adjustment, at least for relatively simple functional relationships between constants – and if the constants are not adjusted so drastically that the global shape of the argument has to change as a consequence – but we need to work to see whether it can be scaled up to the complex arguments that will appear in this network.")

#text("However, there will inevitably be some very large computations in this network that will not be feasible to formalize in Lean – numerical verification of the Riemann Hypothesis up to a very large height ")#mi("H")#text(" being the prime example. This will probably have to be represented within Lean as an axiom, and in many cases the only known verification of such axioms will be through nonrigorous arithmetic, such as floating point arithmetic. However, my hope is that it will be relatively easy (particularly with AI tools) to tune down this height parameters ")#mi("H")#text(" and recalculate all of the downstream constants in a short amount of time (and in a Lean-verified fashion), so that one can see just how much numerical verification is actually needed to establish any given result, and in particular whether one can retreat to a numerical RH result which is weaker, but more rigorously verified (e.g., by an interval arithmetic calculation in a conventional software language such as Python).")
]
]
