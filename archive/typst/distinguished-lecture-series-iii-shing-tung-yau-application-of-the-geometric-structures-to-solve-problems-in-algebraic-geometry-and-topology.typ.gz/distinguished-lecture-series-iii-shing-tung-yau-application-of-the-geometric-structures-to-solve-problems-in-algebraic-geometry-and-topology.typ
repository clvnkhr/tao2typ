// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/
// Converted to Typst by tao2typ: "2026-10-14T16:34:56.488586+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Shing-Tung Yau, “Application of the Geometric Structures to Solve Problems in Algebraic Geometry and Topology”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Shing-Tung Yau, “Application of the Geometric Structures to Solve Problems in Algebraic Geometry and Topology”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/")[#text("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("On Friday, Yau concluded his lecture series by discussing the PDE approach to constructing geometric structures, particularly ")#link("http://en.wikipedia.org/wiki/Einstein_metric")[#text("Einstein metrics")]#text(", and their applications to many questions in low-dimensional topology (yes, this includes the ")#link("http://en.wikipedia.org/wiki/Poincare_conjecture")[#text("Poincaré conjecture")]#text("). Yau also discussed the situation in high-dimensional topology, which appears to be completely different (and much less well understood).")

#text("Yau’s slides for this talk are ")#link("http://www.math.ucla.edu/dls/2007/yauucla3.pdf")[#text("available here")]#text(".")

#metadata(none) <tao-a967fd8dc216c978762c>

#text("In Yau’s previous talk, he discussed how one can (sometimes) construct geometric structures on complicated manifolds by gluing together structures on simpler manifolds (with boundary). This can be a powerful approach, but has a number of drawbacks:")

#enum(start: 1, 
[#text("It only works well when there is plenty of control on the topology. In situations such as the Poincaré conjecture, in which the only ")#emph[#text("a priori")]#text(" topological information is that the manifold is simply connected, this technique is not very effective.")],
[#text("Gluing most naturally takes place in the homeomorphic category. If one wants to work in the diffeomorphic category, the method either does not apply or has to be substantially reworked.")]
)

#text("In recent years it has become clear that methods from nonlinear PDE, especially nonlinear parabolic PDE, can be applied to construct geometric structures in the diffeomorphic category, even in the absence of strong topological control on the manifold; the idea is that a carefully chosen PDE can continue deforming an unknown structure until it becomes “recognizable” in some sense (e.g. it minimises or nearly minimises some functional). The difficulty is now moved into one of establishing ")#emph[#text("long-time")]#text(" existence and control of solutions to this nonlinear PDE.")

#emph[#text("Short-time")]#text(" existence for parabolic equations is relatively easy, for instance by energy estimates and Sobolev embedding; however, one cannot simply iterate the short-time argument to get long-time control, because the Sobolev embedding constants depend on the geometry, which could be blowing up. It is thus necessary to seek other estimates and methods which are more independent of the evolution of the geometry; thus it is particularly useful to have bounds which depend only on the ")#emph[#text("initial")]#text(" geometry. There are two main ways to achieve this: maximum principles (which Yau viewed as a kind of “worst case analysis” for solutions) and monotonicity formulae.")

#text("There are many geometric structures that can be constructed in this way (e.g. ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic maps")]#text(" are a good example), but Yau focused primarily on ")#link("http://en.wikipedia.org/wiki/Einstein_metric")[#text("Einstein metrics")]#text(" – Riemannian metrics whose ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci tensor")]#text(" is equal to a constant multiple of the metric itself. This constant has an interpretation in general relativity as the ")#link("http://en.wikipedia.org/wiki/Cosmological_constant")[#text("cosmological constant")]#text(" for the ")#link("http://en.wikipedia.org/wiki/Einstein_field_equations")[#text("vacuum Einstein equations")]#text(", and can be positive, zero, or negative. One should clarify that in general relativity, it is the ")#emph[#text("Lorentzian")]#text(" (")#link("http://en.wikipedia.org/wiki/Signature_%28physics%29")[#text("signature")]#text(" -+++) version of the Einstein equations which is important (and much more difficult to handle analytically), whereas in geometry it is the ")#emph[#text("Euclidean")]#text(" (signature ++++) version which is of most use.")

#text("Einstein metrics can be viewed as the higher-dimensional generalisation of the ")#link("http://en.wikipedia.org/wiki/Poincare_metric")[#text("Poincaré metric")]#text(" for Riemann surfaces of higher genus. They are amazingly useful in low-dimensional topology, and later in this talk Yau discussed several applications of these metrics.")

#text("After choosing a suitable coordinate system (e.g. ")#link("http://en.wikipedia.org/wiki/Harmonic_coordinates")[#text("harmonic coordinates")]#text("), the Einstein equations become an elliptic system (basically because the Ricci operator resembles a Laplacian when viewed in a suitable coordinate system). Thus, on a compact manifold, we expect a relatively small number of solutions (just as there are relatively few eigenfunctions of the Laplacian). But it is not at all clear whether there exists such a metric at all, particularly if one wants to prescribe the sign of the cosmological constant; Yau views this problem as a fundamental one in modern geometry.")

#text("There seem to be three known strategies for constructing Einstein metrics:")

#enum(start: 1, 
[#text("Variational (minimax) methods;")],
[#text("Methods assuming additional symmetry structure on the manifold (especially ")#link("http://en.wikipedia.org/wiki/K%C3%A4hler_manifold")[#text("Kähler structure")]#text("); and")],
[#link("http://en.wikipedia.org/wiki/Ricci_flow")[#text("Ricci flow")]#text(".")]
)

#text("Yau then discussed each of these three strategies in turn.")

#text("First, the variational method. Suppose we normalise all metrics to have volume 1, and then also fix the conformal class of the metric. If we minimise the total scalar curvature ")#mi("\\int_M R\\ dg")#text(" over all representatives in such a class, we (formally) obtain a number R, which should be attained by a constant scalar curvature metric in that class; if one then maximises that number over all conformal classes in a certain topological class, one gets another number – the ")#emph[#text("Yamabe invariant")]#text(" – which should formally be attained by an Einstein metric (note that all Einstein metrics automatically have constant scalar curvature, which is essentially just the cosmological constant).")

#text("Thus, to obtain an Einstein metric, one has to rigorously perform two tasks: firstly, one has to minimise the total scalar curvature in a conformal class to create a constant scalar curvature metric; and then one has to maximise this over all conformal classes to obtain an Einstein metric. The first problem is the famous ")#emph[#text("Yamabe problem")]#text(", and was basically solved by Trudinger, Aubin, and Schoen. (Yamabe’s original argument for this problem contained some gaps.) The hardest case is when the manifold is conformally flat; here, Schoen needed to use the Green’s function of the Laplacian to make the manifold asymptotically flat, in which case the positive mass theorem could be applied – thus providing another link between the Yamabe problem and general relativity.")

#text("Unfortunately, the second problem – maximisation over conformal classes – appears to be much more difficult, although there is some recent progress in this direction by Schoen et al. and Anderson.")

#text("Yau then turned to the second major technique, which assumes additional symmetry on the underlying manifold. In the early work on general relativity, one constructed solutions to Einstein equations (e.g. the ")#link("http://en.wikipedia.org/wiki/Schwarzschild_metric")[#text("Schwarzschild solution")]#text(") by assuming some ")#emph[#text("global ")]#text("symmetry, such as rotational invariance, to effectively reduce matters to a lower dimensional (and thus simpler) problem. Here, though, Yau focused more on ")#emph[#text("internal ")]#text("symmetries, such as holomorphic coordinates (which essentially means ")#link("http://en.wikipedia.org/wiki/K%C3%A4hler_manifold")[#text("Kähler structure")]#text(") or more generally structures with a special holonomy group. Particularly important here are the ")#link("http://en.wikipedia.org/wiki/Kahler-Einstein_manifold")[#text("Kähler-Einstein manifolds")]#text(", which are simply the Kähler manifolds whose metric obeys Einstein’s equations.")

#text("In a Kähler manifold, one can show that the cohomology class of the Ricci tensor is always equal to the first ")#link("http://en.wikipedia.org/wiki/Chern_class")[#text("Chern class")]#text(" (of the canonical line bundle). Thus, a necessary condition for a Kähler manifold to have a Kähler-Einstein metric of the same Chern class is that the Chern class must have a definite sign (which would then be the sign of the cosmological constant). The famous ")#link("http://en.wikipedia.org/wiki/Calabi_conjecture")[#text("Calabi conjecture")]#text(", proven by Yau, asserts that this necessary condition is also sufficient, and furthermore that the Kähler-Einstein metric is essentially unique. As a consequence, one can show that if a Kähler manifold has negative or zero Chern class, then it has a unique Kähler-Einstein metric; the situation in positive Chern class is be significantly more complicated. For instance, for ")#link("http://en.wikipedia.org/wiki/Minimal_model")[#text("minimal models")]#text(" of algebraic manifolds of ")#link("http://en.wikipedia.org/wiki/General_type")[#text("general type")]#text(", the first Chern class is not everywhere negative, and thus has no ")#emph[#text("smooth")]#text(" Kähler-Einstein metric; nevertheless, one can construct (either by the methods used to prove the Calabi conjecture, or by Ricci flow methods) ")#emph[#text("singular")]#text(" Kähler-Einstein metrics, whose singular sets have some interesting structure which is still not fully understood, but does lead to some deep algebraic geometry consequences for these manifolds, as these metrics provide a rich source of invariants for these types of manifolds, which can be used to analyse algebraic or topological problems which ")#emph[#text("a priori")]#text(" have no relationship with this metric. For instance, the spectrum of the Laplace-Beltrami operator for this metric should in principle capture a large part of the geometry of these manifolds, though nobody knows how to reconstruct the manifold from this Laplacian.")

#text("Kähler-Einstein metrics were used (together with a vanishing theorem for holomorphic sections) by Yau to determine which algebraic manifolds were ")#link("http://en.wikipedia.org/wiki/Shimura_variety")[#text("Shimura varieties")]#text("; roughly speaking, the Chern class has to be non-positive and a certain U(n)-irreducible component of a tensor power of the tangent bundle must have a non-trivial holomorphic section. One purely algebraic consequence of this is that any ")#mi("\\text{Gal}({\\Bbb C}/{\\Bbb Q})")#text(" Galois conjugate of a Shimura variety is again a Shimura variety, a fact proven earlier by Kazhdan via representation-theoretic methods.")

#text("Kähler-Einstein metrics were also used in Yau’s proof of the Bogomolov-Miyaoka-Yau inequality ")#mi("c_1(M) \\cdot c_1(M) \\leq 3 c_2(M)")#text(" mentioned in ")#link("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/")[#text("Zhang’s lectures")]#text(". (In fact, Yau recalled that he learnt about this problem from a colloquium of Mumford right here at UCLA, thus illustrating one of the advantages of attending colloquia.) The argument also shows when equality holds, and this fact turns out to be useful for proving the Severi conjecture (that ")#mi("{\\Bbb{CP}}^2")#text(" has only one complex structure, namely the obvious one; this is sort of like a complex analogue of the Poincaré conjecture). Kähler-Einstein metrics with cosmological constant zero (i.e. Ricci-flat Kähler metrics) are also used in algebraic geometry and string theory, for instance in establishing various versions of ")#link("http://en.wikipedia.org/wiki/Torelli_theorem")[#text("Torelli’s theorem")]#text(". For positive cosmological constant, there appears to be some relationship between these metrics and the algebraic geometric stability of the underlying manifold; the Kähler-Einstein metric seems to serve somehow as a concrete “witness” of the fact that a certain bundle is stable in the ")#link("http://en.wikipedia.org/wiki/Geometric_invariant_theory")[#text("GIT")]#text(" sense – which is often hard to verify by purely algebraic means. This phenomenon seems to be particularly strong when the underlying manifold has some moduli space structure.")

#text("From a PDE perspective, a primary reason why Kähler metrics are much easier to work with than the more general Riemannian metrics is that the former are quite rigid; they can essentially be described by a single scalar function, and so one “only” needs to solve a scalar nonlinear PDE to construct things like Kähler-Einstein metrics. In contrast, Riemannian metrics need a tensor to be described properly, and there is a large group of diffeomorphisms that one’s analysis should be invariant under, so there are also some gauge fixing problems which cause significant difficulty.")

#text("Yau then turned to Ricci flow, which is now perhaps the most famous way to try to build (or to approach) Einstein metrics, and was introduced by Hamilton partly inspired by the previous successes of Einstein metrics to understand other geometric problems (such as the Severi conjeture). [As a side note, Yau also noted that Ricci flow had been introduced independently, and for rather different purposes, by people working in quantum gravity, but I wasn’t able to catch the full details of this.]")

#text("Yau then briefly went through the recent history of the Poincaré conjecture. (Regarding the controversies of last year, Yau’s simply remarked that this story is “longer and more complicated than some newspaper reports might have you believe.”) Hamilton’s first paper on Ricci flow established the global convergence of the Ricci flow to a round sphere when the initial metric had positive Ricci curvature, in particular establishing the Poincaré conjecture in this case; besides the local existence theory for this flow, the main tool here was the maximum principle applied to the scalar curvature. Hamilton then went on to make several other major advances on the Ricci flow approach, culminating perhaps in his establishment of the geometrisation conjecture under the additional assumption that the Ricci curvature stays bounded throughout the lifetime of Ricci flow (with surgery). This result introduces many of the tools that Perelman would also use, for instance the Li-Yau-Hamilton inequality coming from a tensor maximum principle which implies a pinching property in regions of high curvature (basically, in those regions the curvature tends to be positive rather than negative), injectivity radius estimates, rescaling arguments to classify singularities, and of course the idea of augmenting the Ricci flow with surgery. (Hamilton also used some other machinery, notably the positive mass theorem and robust (quantitative) versions of the Mostow rigidity theorem, which ended up not being used in Perelman’s final proof.)")

#text("One of the main reasons why Hamilton needed the hypothesis of bounded curvature was that he was unable to eliminate a certain singularity scenario, caused by a cigar soliton (or more precisely, this product of this soliton with a line). This scenario was eliminated by Perelman, by introducing some powerful new monotone quantities (Perelman entropy and Perelman reduced volume). Of course, once the curvature was allowed to become unbounded, the rest of the argument also had to be significantly reworked; in particular, Perelman’s analysis of singularities and construction of surgery is much more delicate, and in the case of the geometrisation conjecture there are even more additional difficulties arising from the fact that Ricci flow with surgery does not necessarily terminate in finite time. [In my opinion, another of Perelman’s great contributions is to elevate the role of scale-invariance in this problem, which had been somewhat masked in earlier work due to reliance on maximum principles. See my ")#link("http://arxiv.org/abs/math.DG/0610903")[#text("exposition of Perelman’s proof")]#text(" for more discussion.]")

#text("Yau made two general comments about the two main tools for obtaining global control for the Ricci flow, namely ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principles")]#text(" and ")#link("http://tosio.math.toronto.edu/wiki/index.php/Monotonicity_formula")[#text("monotonicity formulae")]#text(". Regarding maximum principles, he observed that using them was something of an art; one could work for years on an equation without being able to exploit a maximum principle, but once one found the proper way to do it, it could be worked out and verified within an hour; thus, the applications of such principles only looks simple in retrospect (sort of like the solution to problems in ")#link("http://en.wikipedia.org/wiki/NP_%28complexity%29")[#text("NP")]#text("). Regarding monotonicity formulae, he noted that the steady-state or self-similar solutions, in particular soliton solutions, were crucial in discovering these formulae; after all, if a monotonicity formula has any chance of existing at all, the inequality must become an equality for the soliton solution. Thus, it is of interest to locate non-trivial identities for soliton solutions, as these have a chance of being converted into non-trivial inequalities for general solutions.")

#text("Yau then surveyed other recent work (involving a large number of mathematicians) in which the Ricci flow was applied to various conjectures in geometric topology. For instance, this flow was used to help show that every complete non-compact Kähler manifold with positive bisectional curvature is bi-holomorphic to ")#mi("{\\Bbb C}^n")#text("; to show that every compact simply connected manifold with positive curvature operator is diffeomorphic to the sphere; and to show that compact manifolds with quarter-pinched curvature are diffeomorphic to manifolds with constant positive curvature. In Yau’s words, Ricci flow has “opened up a new era for geometric analysts to build geometric structures”.")

#text("Yau then turned to four-manifolds and higher-dimensional manifolds. For four-manifolds, we have the important tools of Donaldson theory and Seiberg-Witten theory, but many basic questions about four-manifolds remain open. For instance, regarding four-manifolds with complex structure, there are two basic ways to construct such manifolds; either by gluing together simpler manifolds, or by using the log transformation of Kodiara to convert one complex structure to another. Yau seemed to be of the opinion that these operations should somehow “generate” most of the complex structures on four-manifolds, but it seems that we are quite a way from getting such a classification at present. Yau speculated that future progress here may hinge on finding some sort of unified geometric framework which incorporates all of the known invariants of four-manifolds (the obstructions to integrable complex structures found by Kodiara from the Atiyah-Singer index theorem, the Donaldson invariants coming from moduli spaces of holomorphic vector bundles, and the Seiberg-Witten invariants).")

#text("Yau then turned to higher-dimensional manifolds, for which our understanding is less satisfactory (in part because there are fewer connections with physics). Here, structures appear to be much less rigid, with almost none of the obstructions that are present in low dimensions. For instance, there is no example known of an almost complex manifold of complex dimension 3 or higher which does not admit a complex structure, in marked contrast to the case of complex dimensions 1 and 2. (The case of the sphere ")#mi("S^6")#text(" is already a famous unsolved problem.) Yau seemed to tentatively conjecture that in fact no obstructions existed, i.e. all almost complex manifolds in three and higher complex dimensions have at least one complex structure. If this conjecture were true, it would imply that there are a very large number of non-Kähler complex geometries in higher dimensions. In particular, it seems to indicate that while Kähler geometries are rather rigid, and one cannot deform one such geometry to another while remaining in the Kähler category; however in some cases we know that we can “tunnel” from one Kähler manifold to another by deforming through non-Kähler complex geometries. There is a model example of this by Clemens and Friedman which collapses a rational curve inside a Calabi-Yau manifold into a (singular) ")#link("http://en.wikipedia.org/wiki/Conifold")[#text("conifold")]#text("; one can then smooth out this conifold (destroying the Kähler structure, but retaining the complex structure) and then deform to another conifold, which lets one end up at a different Calabi-Yau manifold. (Yau also mentioned a mirror symmetric version of this, in which the rational curves became ")#mi("S^3")#text("s, but I didn’t understand this well.) It has been proposed by Reid that in fact all Calabi-Yau manifolds with three complex dimensions could be connected to each other by such tunneling procedures.")

#text("Because arbitrary complex structures seem to be so non-rigid in higher dimensions, Yau has been looking at various enhancements of such structures which might have a richer theory. One such candidate are ")#emph[#text("balanced")]#text(" Hermitian metrics ")#mi("\\omega")#text(", which obey the codimension one condition ")#mi("d(\\omega^{n-1}) = 0")#text(". These initially arose in twistor theory and then in heterotic string theory. Strominger studied the latter setting, and proposed a package of structures (which Yau calls a “Strominger system”), namely a holomorphic vector bundle with a Hermitian Yang-Mills connection and a balanced Hermitian metric, which are connected to each other by a certain “anomaly equation”. There is some preliminary work on the existence of these systems, but it seems that this theory is still in its very early stages.")

#text("Yau also mentioned that in any dimension, the Donaldson-Uhlenbeck-Yau theory of stable holomorphic bundles for Kähler manifolds can be used to construct connections on the tangent bundle with some specified holonomy group G, but a major difficulty in using this is that these connections are not ")#emph[#text("a priori")]#text(" torsion-free; I got the impression that there was not yet a systematic way to resolve this problem.")

#text("In closing, Yau was optimistic that further inspiration from physics, in particular from mirror symmetry, string theory, and the (future) theory of quantum gravity, would continue to show the way ahead in geometry. For instance, from dynamical considerations in physics he expected the spectral properties of various elliptic operators associated to deformations of geometric structures (e.g. the Lichnerowicz operator for Einstein manifolds) should play more of a role in the subject than they currently do.")

#text("[")#emph[#text("Update")]#text(", May 19: Clarified that the Galois conjugacy of a Shimura variety was over ")#mi("{\\Bbb Q}")#text(", not over the number field used to model the variety.]")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1007")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")])]

#emph[#text("collapses a rational curve inside a Calabi-Yau manifold into a (singular) conifold; one can then smooth out this conifold (destroying the Kähler structure, but retaining the complex structure) and then deform to another conifold, which lets one end up at a different Calabi-Yau manifold. (Yau also mentioned a mirror symmetric version")]

#text("One collapses a complex curve by changing the symplectic structure while the complex structure remains constant. One nice toric picture starts with a 3-d ziggurat, seen from above looking like")#linebreak()#text(" \\ /")#linebreak()#text(" |")#linebreak()#text(" / \\")#linebreak()#text(" where the vertical line corresponds to the curve. That line is shrunk to zero length, in a way that modifies the polytope but not its fan. So algebraic geometers who only watch the complex structure and not the Riemannian structure have a nasty surprise, when without warning the curve suddenly becomes a point.")#linebreak()#text(" The toric picture")#linebreak()#text(" \\ /")#linebreak()#text(" / \\")#linebreak()#text(" is, locally, the conifold of 2×2 determinant zero matrices. That has a deformation of the complex structure to 2×2 determinant 1 matrices. There is a map from {det 1} ->> {det 0} collapsing the (Lagrangian!) SU(2) to the singular point, and elsewhere a symplectomorphism. In that sense one may imagine that it is a variation of the complex structure while the symplectic structure is held fixed, the mirror dual to the previous family.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1008")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")])]

#text("Greedy wordpress, for eating the space I put before that | !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sz")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1010")[#strong[#text("sz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("Dear prof. Tao,")

#text("Yau’s this statement:")

#text("“Kähler-Einstein metrics were used (together with a vanishing theorem for holomorphic sections) by Yau to determine which algebraic manifolds were Shimura varieties; roughly speaking, the Chern class has to be non-positive and a certain U(n)-irreducible component of a tensor power of the tangent bundle must have a non-trivial holomorphic section. One purely algebraic consequence of this is that any Galois conjugate of a Shimura variety is again a Shimura variety, a fact proven earlier by Kazhdan.”")

#text("mystefied me. I know Yau and Siu’s great work on characterizing the locally symmetric varieties or Shimura varieties by some curvature conditions and others, but this is purely over the complex numbers. Shimura varieties, among the other thing, has a rational model, means it can be defined by a set of algebraic equations with coefficients in some number field , and when Galois conjugates brought in to act on this coefficients, we get a new variety, and it is natural to ask if this new variety is also a Shimura variety. But over the complex numbers these two varieties are identical. I don’t see how can we tell a rational structure from some conditions over the complex numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sz")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1011")[#strong[#text("sz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("Dear Prof. Tao,")

#text("I think Yau’s absolutely right to point out the spectrum of Kahler-Einstein metric is a fundamental invariants of the manifold. For example for Calabi-Yau manifold we know for each Kahler class we have an unique Ricci-flat metric. The spectrum of this metric then would provide the fundamental invariants for this Kahler class, and even might be used to construct global coordinate functions for the Kahler moduli space.")

#text("For example for Abelian varieties from the spectrum of the flat metric we can construct the theta functions, and the “theta null” is then a canonical coordinates for the moduli space of Abelian varieties.")

#text("But the big question is, what’s the geometric meaning of these spectrums?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b58c65d149a92464bc601f85ffd91135f257a5b5a4482b59a26d97c816f303d1-c7dbf2229f6f54efc6398fb3ec711b35609f773b8f16b007a93bbdb5bb43c55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bb")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1012")[#strong[#text("bb")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("sz,")

#text("if i’m parsing your question correctly, you’re claiming that “Galois conjugates” of a fixed variety are all isomorphic (and consequently, the Kazhdan-Yau theorem is contentless).")

#text("this is false! the point is that Galois automorphisms of C over Q are extremely discontinuous when it comes to the analytic topology (think of one which restricts to the non-trivial automorphism of Q(sqrt(2)). Serre has constructed examples of varieties defined over number fields whose fundamental groups are different for different embeddings of the number field in to C (c.f: his paper “Exemples de variétés projectives conjuguées non homéomorphes” , C. R. Acad. Sci. Paris 258 1964 4194–4196).")

#text("what is true, however, is that varieties defined over Q have isomorphic Galois conjugates and this is simply because Q has a unique embedding in C. but it’s hard to find Shimura varieties whose canonical model is rational (for ex: the most basic Shimura variety, the modular curve X(N), has a canonical model defined over the ring of integers of the N-th cyclotomic field).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1018")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("RE: Allen Knutson diagram above:")

#text("If o is substituted for | , then")

#text("\\/")#linebreak()#text(" o")#linebreak()#text(" /\\")

#text("This may represent at least two things:")#linebreak()#text(" a – flop transition [top row, figure 11.5, The Elegant Universe, Brian Greene], if rotated 90 degrees >oo representing maximum")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sz")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1019")[#strong[#text("sz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("bb,")

#text("Thank you for pointing this out, I think you are right. My “identical” is only a “set theoretical identical” and this is obviously not I want.")

#text("But in this context to apply the complex analytic criterion like Yau’s, I think")#linebreak()#text(" over the complex numbers this also has to be continous, for otherwise how can we carry over the metric, curvature, and the existence of holomorphic sections from one to another? I am still quite puzzled.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1024")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("Dear sz and bb,")

#text("I found a paper of Milne discussing the Kazhdan-Yau result,")

#link("http://www.jmilne.org/math/Manuscripts/KazTh.pdf")[#text("Click to access KazTh.pdf")]

#text("I would imagine that the continuous structures on the Galois-transformed variety are not obviously related to the continuous structures on the original variety, but that the arguments of Kazhdan and Yau nevertheless enable one to construct such structures on the new variety.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1030")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")]

#text("[…] Distinguished Lecture Series III: Shing-Tung Yau, “Application of the Geometric Structures to … On Friday, Yau concluded his lecture series by discussing the PDE approach to constructing geometric structures, […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b58c65d149a92464bc601f85ffd91135f257a5b5a4482b59a26d97c816f303d1-c7dbf2229f6f54efc6398fb3ec711b35609f773b8f16b007a93bbdb5bb43c55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bb")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1036")[#strong[#text("bb")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")])]

#text("sz and TT,")

#text("i have no idea what Yau’s result is and can claim no familiarity with the techniques that go into it. but, based on what was posted, one guess i can make is the following:")

#text("Say X_C is the shimura variety in question (over the complex numbers) and X_k is the canonical model of X_C defined over a number field k with a specified embedding i:k –> C which realises X_C as the complex variety associated to the scheme X_k. then tangent bundle of X_C is actually the pullback of a bundle defined over k, the formation of the space of global “holomorphic” sections commutes with the base change i:k –> C, the chern class of the tangent bundle of X_k is defined as a class in the l-adic cohomology (or, better, the chow ring) of X_k and, on identifying the l-adic cohomology of X_k with singular cohomology of X_C, is identified with the topologically defined chern class of (the tangent bundle) of X_C i.e: all the gadgets quoted above are defined over k itself. assuming now that the properties in question (non-positivity of the chern class in the sense of intersection theory, and non-emptyness of the space of global sections) can be checked after the base change i: k –> C, yau tells us that the canonical model X_k satisfies the same properties. now further assuming these properties are preserved under a base change j: k –> C, we can conclude that these properties are satisfied for the complex variety Y obtained using the embedding j instead of i (which gives us X_C) and, thereby, establish what was asked. i’ve most definitely belaboured the obvious, but my point is that the properties in question admit algebraic formulations and, therefore, conceivably, might be preserved under Galois conjugations by virtue of “descent”…")

#text("i’ve already taken up too much space here, so i’ll stop now and wait for the experts to correct my mistakes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sz")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1042")[#strong[#text("sz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2007")])]

#text("Dear bb and TT,")

#text("I think perhaps Yau’s talking about the compact Shimura varieties, where topological conditions like c_2=3C_1^2 and holomorphic sections can characterize it, and these conditions can be descent to the number field k. For the general noncompact case I checked Milne’s paper, the thing becomes quite complicated. The criterion of Hermitian symmetric domains involves the positive definiteness of Ricci tensor, this can not be descented to k, so instead some indirect arguments are needed.")

#text("But as Milne remarked, in the case when the Shimura varieties are moduli spaces of some abelian varieties, the question becomes easy. Galois conjugate of the moduli is just the moduli of Galois conjugate abelian varieties, provided everything is defined naturally. This already covers a large part of all Shimura varieties, the remaining cases are E_6, E_7, and certain mixed type. To prove his theorem Kazhdan actually checked these case by case, it’s quite outrageous that Shimura varieties should be treated so differently. Maybe we can hope someday these remaining cases can also be realized as moduli spaces of some objects, that would settle the matter once for all.")

#text("This is of course, only some wishful thinkings…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-1460")[#strong[#text("Not Even Wrong » Blog Archive » Even More Stuff Than Usual")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2007")]

#text("[…] worth reading in Terry Tao’s reporting on a series of lectures by Yau at UCLA here, here and here. At the blog of fellow Fields Medalist Alain Connes, there’s mention of on a recent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jolany hassan")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-147649")[#strong[#text("jolany hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2012")])]

#text("I saw several papers that without proof accept the fact “Short time existence of nonlinear parabolic heat equations ” So really in which paper or lecture note ca I find the proof of this fact?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-147668")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2012")])]

#text("See Remark 2 of my blog post ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow")[#text("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/18/distinguished-lecture-series-iii-shing-tung-yau-application-of-the-geometric-structures-to-solve-problems-in-algebraic-geometry-and-topology/#comment-216112")[#strong[#text("Existence of Kähler-Einstein Metrics | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")]

#text("[…] about the problem by Donaldson and Tian, as well as a series of blog posts (here, here, and here) by Terry Tao based on lectures by […]")
]
