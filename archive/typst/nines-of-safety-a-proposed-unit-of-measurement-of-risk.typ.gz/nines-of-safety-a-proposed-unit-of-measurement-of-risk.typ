// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/
// Converted to Typst by tao2typ: "2026-10-14T16:38:59.238471+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nines of safety: a proposed unit of measurement of risk", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nines of safety: a proposed unit of measurement of risk")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 October 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/")[#text("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In everyday usage, we rely heavily on percentages to quantify probabilities and proportions: we might say that a prediction is ")#mi("{50\\%}")#text(" accurate or ")#mi("{80\\%}")#text(" accurate, that there is a ")#mi("{2\\%}")#text(" chance of dying from some disease, and so forth. However, for those without extensive mathematical training, it can sometimes be difficult to assess whether a given percentage amounts to a “good” or “bad” outcome, because this depends very much on the context of how the percentage is used. For instance:")

#list(
[#text("(i) In a two-party election, an outcome of say ")#mi("{51\\%}")#text(" to ")#mi("{49\\%}")#text(" might be considered close, but ")#mi("{55\\%}")#text(" to ")#mi("{45\\%}")#text(" would probably be viewed as a convincing mandate, and ")#mi("{60\\%}")#text(" to ")#mi("{40\\%}")#text(" would likely be viewed as a landslide.")],
[#text("(ii) Similarly, if one were to poll an upcoming election, a poll of ")#mi("{51\\%}")#text(" to ")#mi("{49\\%}")#text(" would be too close to call, ")#mi("{55\\%}")#text(" to ")#mi("{45\\%}")#text(" would be an extremely favorable result for the candidate, and ")#mi("{60\\%}")#text(" to ")#mi("{40\\%}")#text(" would mean that it would be a major upset if the candidate lost the election.")],
[#text("(iii) On the other hand, a medical operation that only had a ")#mi("{51\\%}")#text(", ")#mi("{55\\%}")#text(", or ")#mi("{60\\%}")#text(" chance of success would be viewed as being incredibly risky, especially if failure meant death or permanent injury to the patient. Even an operation that was ")#mi("{90\\%}")#text(" or ")#mi("{95\\%}")#text(" likely to be non-fatal (i.e., a ")#mi("{10\\%}")#text(" or ")#mi("{5\\%}")#text(" chance of death) would not be conducted lightly.")],
[#text("(iv) A weather prediction of, say, ")#mi("{30\\%}")#text(" chance of rain during a vacation trip might be sufficient cause to pack an umbrella, even though it is more likely than not that rain would not occur. On the other hand, if the prediction was for an ")#mi("{80\\%}")#text(" chance of rain, and it ended up that the skies remained clear, this does not seriously damage the accuracy of the prediction – indeed, such an outcome would be expected in one out of every five such predictions.")],
[#text("(v) Even extremely tiny percentages of toxic chemicals in everyday products can be considered unacceptable. For instance, ")#link("https://www.epa.gov/ground-water-and-drinking-water/basic-information-about-lead-drinking-water")[#text("EPA rules")]#text(" require action to be taken when the percentage of lead in drinking water exceeds ")#mi("{0.0000015\\%}")#text(" (15 parts per billion). At the opposite extreme, recycling contamination rates as high as ")#mi("{10\\%}")#text(" are often considered acceptable.")]
)

#text("Because of all the very different ways in which percentages could be used, I think it may make sense to propose an alternate system of units to measure one class of probabilities, namely the probabilities of avoiding some highly undesirable outcome, such as death, accident or illness. The units I propose are that of “")#link("https://en.wikipedia.org/wiki/Nines_(notation)")[#text("nines")]#text("“, which are already ")#link("https://en.wikipedia.org/wiki/High_availability#Percentage_calculation")[#text("commonly used")]#text(" to measure ")#emph[#text("availability")]#text(" of some service or ")#emph[#text("purity")]#text(" of a material, but can be equally used to measure the ")#emph[#text("safety")]#text(" (i.e., lack of risk) of some activity. Informally, nines measure how many consecutive appearances of the digit ")#mi("{9}")#text(" are in the probability of successfully avoiding the negative outcome, thus")

#list(
[#mi("{90\\%}")#text(" success = one nine of safety")],
[#mi("{99\\%}")#text(" success = two nines of safety")],
[#mi("{99.9\\%}")#text(" success = three nines of safety")]
)

#text("and so forth. Using the mathematical device of ")#link("https://en.wikipedia.org/wiki/Logarithm")[#text("logarithms")]#text(", one can also assign a fractional number of nines of safety to a general probability:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Nines of safety)")]#text(" ")#metadata(none) <tao-61e0df21ba81aa309db6>#text(" An activity (affecting one or more persons, over some given period of time) that has a probability ")#mi("{p}")#text(" of the “safe” outcome and probability ")#mi("{1-p}")#text(" of the “unsafe” outcome will have ")#mi("{k}")#text(" nines of safety against the unsafe outcome, where ")#mi("{k}")#text(" is defined by the formula")

#metadata(none) <tao-a88977576bee99012c29>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("k = -\\log_{10}(1-p)")]]

#text("(where ")#mi("{\\log_{10}}")#text(" is the logarithm to base ten), or equivalently")

#metadata(none) <tao-e684459b6993f6c93b02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("p = 1 - 10^{-k}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Because of the various uncertainties in measuring probabilities, as well as the inaccuracies in some of the assumptions and approximations we will be making later, we will not attempt to measure the number of nines of safety beyond the first decimal point; thus we will round to the nearest tenth of a nine of safety throughout this post.")
]

#text("Here is a conversion table between percentage rates of success (the safe outcome), failure (the unsafe outcome), and the number of nines of safety one has:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Success rate ")#mi("{p}")],
table.cell(colspan: 1, rowspan: 1)[#text("Failure rate ")#mi("{1-p}")],
table.cell(colspan: 1, rowspan: 1)[#text("Number of nines ")#mi("{k}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{75\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{25\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{80\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{20\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{90\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{95\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{97.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{98\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.75\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.25\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.8\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.9\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.95\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.05\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.975\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.025\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.98\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.02\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.99\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.01\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("infinite")]
)

#text("Thus, if one has no nines of safety whatsoever, one is guaranteed to fail; but each nine of safety one has reduces the failure rate by a factor of ")#mi("{10}")#text(". In an ideal world, one would have infinitely many nines of safety against any risk, but in practice there are no ")#mi("{100\\%}")#text(" guarantees against failure, and so one can only expect a finite amount of nines of safety in any given situation. Realistically, one should thus aim to have as many nines of safety as one can reasonably expect to have, but not to demand an infinite amount.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The number of nines of safety against a certain risk is not absolute; it will depend not only on the risk itself, but (a) the number of people exposed to the risk, and (b) the length of time one is exposed to the risk. Exposing more people or increasing the duration of exposure will reduce the number of nines, and conversely exposing fewer people or reducing the duration will increase the number of nines; see Proposition ")#link(<tao-25e2b6b106523880e277>)[#text("7")]#text(" below for a rough rule of thumb in this regard.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Nines of safety are a ")#link("https://en.wikipedia.org/wiki/Logarithmic_scale")[#text("logarithmic scale")]#text(" of measurement, rather than a linear scale. Other familiar examples of logarithmic scales of measurement include the ")#link("https://en.wikipedia.org/wiki/Richter_magnitude_scale")[#text("Richter scale of earthquake magnitude")]#text(", the ")#link("https://en.wikipedia.org/wiki/PH")[#text("pH scale of acidity")]#text(", the ")#link("https://en.wikipedia.org/wiki/Decibel")[#text("decibel scale of sound level")]#text(", ")#link("https://en.wikipedia.org/wiki/Octave")[#text("octaves")]#text(" in music, and the ")#link("https://en.wikipedia.org/wiki/Apparent_magnitude")[#text("magnitude scale for stars")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" ")#metadata(none) <tao-898fa2c627354c20bf3c>#text(" One way to think about nines of safety is via the ")#link("https://www.nytimes.com/2020/12/05/health/coronavirus-swiss-cheese-infection-mackay.html")[#text("Swiss cheese model")]#text(" that was created recently to describe pandemic risk management. In this model, each nine of safety can be thought of as a slice of Swiss cheese, with holes occupying ")#mi("{10\\%}")#text(" of that slice. Having ")#mi("{k}")#text(" nines of safety is then analogous to standing behind ")#mi("{k}")#text(" such slices of Swiss cheese. In order for a risk to actually impact you, it must pass through each of these ")#mi("{k}")#text(" slices. A fractional nine of safety corresponds to a fractional slice of Swiss cheese that covers the amount of space given by the above table. For instance, ")#mi("{0.6}")#text(" nines of safety corresponds to a fractional slice that covers about ")#mi("{75\\%}")#text(" of the given area (leaving ")#mi("{25\\%}")#text(" uncovered).")
]

#text("Now to give some real-world examples of nines of safety. Using data for deaths in the US in 2019 (without attempting to account for factors such as age and gender), a random US citizen will have had the following amount of safety from dying from some selected causes in that year:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Cause of death")],
table.cell(colspan: 1, rowspan: 1)[#text("Mortality rate per ")#mi("{100,\\! 000}")#text(" (approx.)")],
table.cell(colspan: 1, rowspan: 1)[#text("Nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("All causes")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{870}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.0}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("Heart disease")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{200}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.7}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("Cancer")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{180}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.7}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("Accidents")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{52}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.3}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/injury.htm")[#text("Drug overdose")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{22}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.7}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("Influenza/Pneumonia")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{15}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.8}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/deaths.htm")[#text("Suicide")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{14}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.8}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.cdc.gov/nchs/fastats/injury.htm")[#text("Gun violence")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{12}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.9}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.iihs.org/topics/fatality-statistics/detail/state-by-state")[#text("Car accident")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{11}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.0}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://ucr.fbi.gov/crime-in-the-u.s/2019/crime-in-the-u.s.-2019/topic-pages/murder")[#text("Murder")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.3}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://injuryfacts.nsc.org/home-and-community/safety-topics/airplane-crashes/")[#text("Airplane crash")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.14}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5.9}")],
table.cell(colspan: 1, rowspan: 1)[#link("https://www.statista.com/statistics/203715/injuries-and-fatalities-caused-by-lightning-in-the-us/")[#text("Lightning strike")]],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.006}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{7.2}")]
)

#text("The safety of air travel is particularly remarkable: a given hour of flying in general aviation has a ")#link("https://injuryfacts.nsc.org/home-and-community/safety-topics/airplane-crashes/")[#text("fatality rate")]#text(" of ")#mi("{0.00001}")#text(", or about ")#mi("{5}")#text(" nines of safety, while for the major carriers the fatality rate drops down to ")#mi("{0.0000005}")#text(", or about ")#mi("{7.3}")#text(" nines of safety.")

#text("Of course, in 2020, COVID-19 deaths became significant. In this year in the US, ")#link("https://www.cdc.gov/mmwr/volumes/70/wr/mm7014e1.htm")[#text("the mortality rate for COVID-19 (as the underlying or contributing cause of death) was")]#text(" ")#mi("{91.5}")#text(" per ")#mi("{100,\\! 000}")#text(", corresponding to ")#mi("{3.0}")#text(" nines of safety, which was less safe than all other causes of death except for heart disease and cancer. At this time of writing, data for all of 2021 is of course not yet available, but it seems likely that the safety level would be even lower for this year.")

#text("Some further illustrations of the concept of nines of safety:")

#list(
[#text("Each round of ")#link("https://en.wikipedia.org/wiki/Russian_roulette")[#text("Russian roulette")]#text(" has a success rate of ")#mi("{5/6}")#text(", providing only ")#mi("{0.8}")#text(" nines of safety. Of course, the safety will decrease with each additional round: one has only ")#mi("{0.5}")#text(" nines of safety after two rounds, ")#mi("{0.4}")#text(" nines after three rounds, and so forth. (See also Proposition ")#link(<tao-25e2b6b106523880e277>)[#text("7")]#text(" below.)")],
[#text("The ancient Roman punishment of ")#link("https://en.wikipedia.org/wiki/Decimation_(punishment)")[#text("decimation")]#text(", by definition, provided exactly one nine of safety to each soldier being punished.")],
[#text("Rolling a ")#mi("{1}")#text(" on a ")#mi("{20}")#text("-sided die is a risk that carries about ")#mi("{1.3}")#text(" nines of safety.")],
[#text("Rolling a double one (“")#link("https://en.wikipedia.org/wiki/Craps#Names_of_rolls")[#text("snake eyes")]#text("“) from two six-sided dice carries about ")#mi("{1.6}")#text(" nines of safety.")],
[#text("One has about ")#mi("{2.6}")#text(" nines of safety against the risk of someone randomly guessing your birthday on the first attempt.")],
[#text("A ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("null hypothesis")]#text(" has ")#mi("{1.3}")#text(" nines of safety against producing a ")#mi("{p = 0.05}")#text(" ")#link("https://en.wikipedia.org/wiki/Statistical_significance")[#text("statistically significant result")]#text(", and ")#mi("{2.0}")#text(" nines against producing a ")#mi("{p=0.01}")#text(" statistically significant result. (However, one has to be careful when reversing the conditional; a ")#mi("{p=0.01}")#text(" statistically significant result does not necessarily have ")#mi("{2.0}")#text(" nines of safety against the null hypothesis. In ")#link("https://en.wikipedia.org/wiki/Bayesian_statistics")[#text("Bayesian statistics")]#text(", the precise relationship between the two risks is given by ")#link("https://en.wikipedia.org/wiki/Bayes%27_theorem")[#text("Bayes’ theorem")]#text(".)")],
[#text("If a poker opponent is dealt a five-card hand, one has ")#mi("{5.8}")#text(" nines of safety against that opponent being dealt a royal flush, ")#mi("{4.8}")#text(" against a straight flush or higher, ")#mi("{3.6}")#text(" against four-of-a-kind or higher, ")#mi("{2.8}")#text(" against a full house or higher, ")#mi("{2.4}")#text(" against a flush or higher, ")#mi("{2.1}")#text(" against a straight or higher, ")#mi("{1.5}")#text(" against three-of-a-kind or higher, ")#mi("{1.1}")#text(" against two pairs or higher, and just ")#mi("{0.3}")#text(" against one pair or higher. (This data was converted from ")#link("https://en.wikipedia.org/wiki/Poker_probability#Frequency_of_5-card_poker_hands")[#text("this Wikipedia table")]#text(".)")],
[#text("A ")#mi("{k}")#text("-digit PIN number (or a ")#mi("{k}")#text("-digit combination lock) carries ")#mi("{k}")#text(" nines of safety against each attempt to randomly guess the PIN. A length ")#mi("{k}")#text(" password that allows for numbers, upper and lower case letters, and punctuation carries about ")#mi("{2k}")#text(" nines of safety against a single guess. (For the reduction in safety caused by multiple guesses, see Proposition ")#link(<tao-25e2b6b106523880e277>)[#text("7")]#text(" below.)")]
)

#text("Here is another way to think about nines of safety:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Nines of safety extend expected onset of risk)")]#text(" Suppose a certain risky activity has ")#mi("{k}")#text(" nines of safety. If one repeatedly indulges in this activity until the risk occurs, then the expected number of trials before the risk occurs is ")#mi("{10^k}")#text(".")
]

#emph[#text("Proof:")]#text(" The probability that the risk is activated after exactly ")#mi("{n}")#text(" trials is ")#mi("{(1-10^{-k})^{n-1} 10^{-k}}")#text(", which is a ")#link("https://en.wikipedia.org/wiki/Geometric_distribution")[#text("geometric distribution")]#text(" of parameter ")#mi("{10^{-k}}")#text(". The claim then follows from the standard properties of that distribution. ")#mi("\\Box")

#text("Thus, for instance, if one performs some risky activity daily, then the expected length of time before the risk occurs is given by the following table:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Daily nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#text("Expected onset of risk")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#text("One day")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.8}")],
table.cell(colspan: 1, rowspan: 1)[#text("One week")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.5}")],
table.cell(colspan: 1, rowspan: 1)[#text("One month")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.6}")],
table.cell(colspan: 1, rowspan: 1)[#text("One year")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.9}")],
table.cell(colspan: 1, rowspan: 1)[#text("Two years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("Five years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.6}")],
table.cell(colspan: 1, rowspan: 1)[#text("Ten years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.9}")],
table.cell(colspan: 1, rowspan: 1)[#text("Twenty years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("Fifty years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.6}")],
table.cell(colspan: 1, rowspan: 1)[#text("A century")]
)

#text("Or, if one wants to convert the yearly risks of dying from a specific cause into expected years before that cause of death would occur (assuming for sake of discussion that no other cause of death exists):")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Yearly nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#text("Expected onset of risk")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#text("One year")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("Two years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.7}")],
table.cell(colspan: 1, rowspan: 1)[#text("Five years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#text("Ten years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("Twenty years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.7}")],
table.cell(colspan: 1, rowspan: 1)[#text("Fifty years")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A century")]
)

#text("These tables suggest a relationship between the amount of safety one would have in a short timeframe, such as a day, and a longer time frame, such as a year. Here is an approximate formalisation of that relationship:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Repeated exposure reduces nines of safety)")]#text(" ")#metadata(none) <tao-25e2b6b106523880e277>#text(" If a risky activity with ")#mi("{k}")#text(" nines of safety is (independently) repeated ")#mi("{m}")#text(" times, then (assuming ")#mi("{k}")#text(" is large enough depending on ")#mi("{m}")#text("), the repeated activity will have approximately ")#mi("{k - \\log_{10} m}")#text(" nines of safety. Conversely: if the repeated activity has ")#mi("{k^{\\prime}}")#text(" nines of safety, the individual activity will have approximately ")#mi("{k^{\\prime} + \\log_{10} m}")#text(" nines of safety.")
]

#emph[#text("Proof:")]#text(" An activity with ")#mi("{k}")#text(" nines of safety will be safe with probability ")#mi("{1-10^{-k}}")#text(", hence safe with probability ")#mi("{(1-10^{-k})^m}")#text(" if repeated independently ")#mi("{m}")#text(" times. For ")#mi("{k}")#text(" large, we can approximate")

#align(center)[#tao-fit-display[#mitex("(1 - 10^{-k})^m \\approx 1 - m 10^{-k} = 1 - 10^{-(k - \\log_{10} m)}")]]

#text("giving the former claim. The latter claim follows from inverting the former. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The hypothesis of independence here is key. If there is a lot of correlation between the risks between different repetitions of the activity, then there can be much less reduction in safety caused by that repetition. As a simple example, suppose that ")#mi("{90\\%}")#text(" of a workforce are trained to perform some task flawlessly no matter how many times they repeat the task, but the remaining ")#mi("{10\\%}")#text(" are untrained and will always fail at that task. If one selects a random worker and asks them to perform the task, one has ")#mi("{1.0}")#text(" nines of safety against the task failing. If one took that same random worker and asked them to perform the task ")#mi("{m}")#text(" times, the above proposition might suggest that the number of nines of safety would drop to approximately ")#mi("{1.0 - \\log_{10} m}")#text("; but in this case there is perfect correlation, and in fact the number of nines of safety remains steady at ")#mi("{1.0}")#text(" since it is the same ")#mi("{10\\%}")#text(" of the workforce that would fail each time.")

#text("Because of this caveat, one should view the above proposition as only a crude first approximation that can be used as a simple rule of thumb, but should not be relied upon for more precise calculations.")
]

#text("One can repeat a risk either in time (extending the time of exposure to the risk, say from a day to a year), or in space (by exposing the risk to more people). The above proposition then gives an additive conversion law for nines of safety in either case. Here are some conversion tables for time:")

#table(columns: 5, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("From/to")],
table.cell(colspan: 1, rowspan: 1)[#text("Daily")],
table.cell(colspan: 1, rowspan: 1)[#text("Weekly")],
table.cell(colspan: 1, rowspan: 1)[#text("Monthly")],
table.cell(colspan: 1, rowspan: 1)[#text("Yearly")],
table.cell(colspan: 1, rowspan: 1)[#text("Daily")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-0.8")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.5")],
table.cell(colspan: 1, rowspan: 1)[#text("-2.6")],
table.cell(colspan: 1, rowspan: 1)[#text("Weekly")],
table.cell(colspan: 1, rowspan: 1)[#text("+0.8")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-0.6")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.7")],
table.cell(colspan: 1, rowspan: 1)[#text("Monthly")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.5")],
table.cell(colspan: 1, rowspan: 1)[#text("+0.6")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.1")],
table.cell(colspan: 1, rowspan: 1)[#text("Yearly")],
table.cell(colspan: 1, rowspan: 1)[#text("+2.6")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.7")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.1")],
table.cell(colspan: 1, rowspan: 1)[#text("0")]
)

#table(columns: 5, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("From/to")],
table.cell(colspan: 1, rowspan: 1)[#text("Yearly")],
table.cell(colspan: 1, rowspan: 1)[#text("Per 5 yr")],
table.cell(colspan: 1, rowspan: 1)[#text("Per decade")],
table.cell(colspan: 1, rowspan: 1)[#text("Per century")],
table.cell(colspan: 1, rowspan: 1)[#text("Yearly")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-0.7")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.0")],
table.cell(colspan: 1, rowspan: 1)[#text("-2.0")],
table.cell(colspan: 1, rowspan: 1)[#text("Per 5 yr")],
table.cell(colspan: 1, rowspan: 1)[#text("+0.7")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-0.3")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.3")],
table.cell(colspan: 1, rowspan: 1)[#text("Per decade")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.0")],
table.cell(colspan: 1, rowspan: 1)[#text("+ -0.3")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("-1.0")],
table.cell(colspan: 1, rowspan: 1)[#text("Per century")],
table.cell(colspan: 1, rowspan: 1)[#text("+2.0")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.3")],
table.cell(colspan: 1, rowspan: 1)[#text("+1.0")],
table.cell(colspan: 1, rowspan: 1)[#text("0")]
)

#text("For instance, as mentioned before, the yearly amount of safety against cancer is about ")#mi("{2.7}")#text(". Using the above table (and making the somewhat unrealistic hypothesis of independence), we then predict the daily amount of safety against cancer to be about ")#mi("{2.7 + 2.6 = 5.3}")#text(" nines, the weekly amount to be about ")#mi("{2.7 + 1.7 = 4.4}")#text(" nines, and the amount of safety over five years to drop to about ")#mi("{2.7 - 0.7 = 2.0}")#text(" nines.")

#text("Now we turn to conversions in space. If one knows the level of safety against a certain risk for an individual, and then one (independently) exposes a group of such individuals to that risk, then the reduction in nines of safety when considering the possibility that at least one group member experiences this risk is given by the following table:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Group")],
table.cell(colspan: 1, rowspan: 1)[#text("Reduction in safety")],
table.cell(colspan: 1, rowspan: 1)[#text("You (")#mi("{1}")#text(" person)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#text("You and your partner (")#mi("{2}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("You and your parents (")#mi("{3}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.5}")],
table.cell(colspan: 1, rowspan: 1)[#text("You, your partner, and three children (")#mi("{5}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.7}")],
table.cell(colspan: 1, rowspan: 1)[#text("An extended family of ")#mi("{10}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A class of ")#mi("{30}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.5}")],
table.cell(colspan: 1, rowspan: 1)[#text("A workplace of ")#mi("{100}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A school of ")#mi("{1,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-3.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A university of ")#mi("{10,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-4.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A town of ")#mi("{100,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-5.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A city of ")#mi("{1}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-6.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A state of ")#mi("{10}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-7.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A country of ")#mi("{100}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-8.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("A continent of ")#mi("{1}")#text(" billion people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-9.0}")],
table.cell(colspan: 1, rowspan: 1)[#text("The entire planet")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-9.8}")]
)

#text("For instance, in a given year (and making the somewhat implausible assumption of independence), you might have ")#mi("{2.7}")#text(" nines of safety against cancer, but you and your partner collectively only have about ")#mi("{2.7 - 0.3 = 2.4}")#text(" nines of safety against this risk, your family of five might only have about ")#mi("{2.7 - 0.7 = 2}")#text(" nines of safety, and so forth. By the time one gets to a group of ")#mi("{1,\\! 000}")#text(" people, it actually becomes very likely that at least one member of the group will die of cancer in that year. (Here the precise conversion table breaks down, because a negative number of nines such as ")#mi("{2.7 - 3.0 = -0.3}")#text(" is not possible, but one should interpret a prediction of a negative number of nines as an assertion that failure is very likely to happen. Also, in practice the reduction in safety is less than this rule predicts, due to correlations such as risk factors that are common to the group being considered that are incompatible with the assumption of independence.)")

#text("In the opposite direction, any reduction in exposure (either in time or space) to a risk will increase one’s safety level, as per the following table:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Reduction in exposure")],
table.cell(colspan: 1, rowspan: 1)[#text("Additional nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 10}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\div 100}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.0}")]
)

#text("For instance, a five-fold reduction in exposure will reclaim about ")#mi("{0.7}")#text(" additional nines of safety.")

#text("Here is a slightly different way to view nines of safety:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Suppose that a group of ")#mi("{m}")#text(" people are independently exposed to a given risk. If there are at most")

#align(center)[#tao-fit-display[#mitex("\\log_{10} \\frac{1}{1-2^{-1/m}}")]]

#text("nines of individual safety against that risk, then there is at least a ")#mi("{50\\%}")#text(" chance that one member of the group is affected by the risk.")
]

#emph[#text("Proof:")]#text(" If individually there are ")#mi("{k}")#text(" nines of safety, then the probability that all the members of the group avoid the risk is ")#mi("{(1-10^{-k})^m}")#text(". Since the inequality")

#align(center)[#tao-fit-display[#mitex("(1-10^{-k})^m \\leq \\frac{1}{2}")]]

#text("is equivalent to")

#align(center)[#tao-fit-display[#mitex("k \\leq \\log_{10} \\frac{1}{1-2^{-1/m}},")]]

#text("the claim follows. ")#mi("\\Box")

#text("Thus, for a group to collectively avoid a risk with at least a ")#mi("{50\\%}")#text(" chance, one needs the following level of individual safety:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Group")],
table.cell(colspan: 1, rowspan: 1)[#text("Individual safety level required")],
table.cell(colspan: 1, rowspan: 1)[#text("You (")#mi("{1}")#text(" person)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3}")],
table.cell(colspan: 1, rowspan: 1)[#text("You and your partner (")#mi("{2}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.5}")],
table.cell(colspan: 1, rowspan: 1)[#text("You and your parents (")#mi("{3}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.7}")],
table.cell(colspan: 1, rowspan: 1)[#text("You, your partner, and three children (")#mi("{5}")#text(" people)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9}")],
table.cell(colspan: 1, rowspan: 1)[#text("An extended family of ")#mi("{10}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A class of ")#mi("{30}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.6}")],
table.cell(colspan: 1, rowspan: 1)[#text("A workplace of ")#mi("{100}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A school of ")#mi("{1,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A university of ")#mi("{10,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A town of ")#mi("{100,\\! 000}")#text(" people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A city of ")#mi("{1}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{6.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A state of ")#mi("{10}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{7.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A country of ")#mi("{100}")#text(" million people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{8.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("A continent of ")#mi("{1}")#text(" billion people")],
table.cell(colspan: 1, rowspan: 1)[#mi("{9.2}")],
table.cell(colspan: 1, rowspan: 1)[#text("The entire planet")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10.0}")]
)

#text("For large ")#mi("{m}")#text(", the level ")#mi("{k}")#text(" of nines of individual safety required to protect a group of size ")#mi("{m}")#text(" with probability at least ")#mi("{50\\%}")#text(" is approximately ")#mi("{\\log_{10} \\frac{m}{\\ln 2} \\approx (\\log_{10} m) + 0.2}")#text(".")

#text("Precautions that can work to prevent a certain risk from occurring will add additional nines of safety against that risk, even if the precaution is not ")#mi("{100\\%}")#text(" effective. Here is the precise rule:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Precautions add nines of safety)")]#text(" Suppose an activity carries ")#mi("{k}")#text(" nines of safety against a certain risk, and a separate precaution can independently protect against that risk with ")#mi("{l}")#text(" nines of safety (that is to say, the probability that the protection is effective is ")#mi("{1 - 10^{-l}}")#text("). Then applying that precaution increases the number of nines in the activity from ")#mi("{k}")#text(" to ")#mi("{k+l}")#text(".")
]

#emph[#text("Proof:")]#text(" The probability that the precaution fails ")#emph[#text("and")]#text(" the risk then occurs is ")#mi("{10^{-l} \\times 10^{-k} = 10^{-(k+l)}}")#text(". The claim now follows from Definition ")#link(<tao-61e0df21ba81aa309db6>)[#text("1")]#text(". ")#mi("\\Box")

#text("In particular, we can repurpose the table at the start of this post as a conversion chart for effectiveness of a precaution:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Effectiveness")],
table.cell(colspan: 1, rowspan: 1)[#text("Failure rate")],
table.cell(colspan: 1, rowspan: 1)[#text("Additional nines provided")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{75\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{25\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{80\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{20\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{90\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{95\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{97.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{98\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.75\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.25\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.8\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.9\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+3.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.95\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.05\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+3.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.975\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.025\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+3.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.98\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.02\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+3.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99.99\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.01\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+4.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("infinite")]
)

#text("Thus for instance a precaution that is ")#mi("{80\\%}")#text(" effective will add ")#mi("{0.7}")#text(" nines of safety, a precaution that is ")#mi("{99.8\\%}")#text(" effective will add ")#mi("{2.7}")#text(" nines of safety, and so forth. The mRNA COVID vaccines by Pfizer and Moderna ")#link("https://www.yalemedicine.org/news/covid-19-vaccine-comparison")[#text("have somewhere between")]#text(" ")#mi("{88\\% - 96\\%}")#text(" effectiveness against symptomatic COVID illness, providing about ")#mi("{0.9-1.4}")#text(" nines of safety against that risk, and over ")#mi("{95\\%}")#text(" effectiveness against severe illness, thus adding at least ")#mi("{1.3}")#text(" nines of safety in this regard.")

#text("A slight variant of the above rule can be stated using the concept of ")#link("https://en.wikipedia.org/wiki/Relative_risk")[#text("relative risk")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Relative risk and nines of safety)")]#text(" Suppose an activity carries ")#mi("{k}")#text(" nines of safety against a certain risk, and an action multiplies the chance of failure by some ")#link("https://en.wikipedia.org/wiki/Relative_risk")[#text("relative risk")]#text(" ")#mi("{R}")#text(". Then the action removes ")#mi("{\\log_{10} R}")#text(" nines of safety (if ")#mi("{R > 1}")#text(") or adds ")#mi("{-\\log_{10} R}")#text(" nines of safety (if ")#mi("{R<1}")#text(") to the original activity.")
]

#emph[#text("Proof:")]#text(" The additional action adjusts the probability of failure from ")#mi("{10^{-k}}")#text(" to ")#mi("{R \\times 10^{-k} = 10^{-(k - \\log_{10} R)}}")#text(". The claim now follows from Definition ")#link(<tao-61e0df21ba81aa309db6>)[#text("1")]#text(". ")#mi("\\Box")

#text("Here is a conversion chart between relative risk and change in nines of safety:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Relative risk")],
table.cell(colspan: 1, rowspan: 1)[#text("Change in nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.01}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.02}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.05}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{20}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.0}")]
)

#text("Some examples:")

#list(
[#text("Smoking increases the fatality rate of lung cancer by ")#link("https://pubmed.ncbi.nlm.nih.gov/16172220/")[#text("a factor of about")]#text(" ")#mi("{20}")#text(", thus removing about ")#mi("{1.3}")#text(" nines of safety from this particular risk; it also increases the fatality rates of several other diseases, though not quite as dramatically an extent.")],
[#text("Seatbelts reduce the fatality rate in car accidents by ")#link("https://www.sciencedirect.com/topics/nursing-and-health-professions/seatbelt")[#text("a factor of about two")]#text(", adding about ")#mi("{0.3}")#text(" nines of safety. Airbags achieve a ")#link("https://www.iihs.org/topics/airbags")[#text("reduction of about")]#text(" ")#mi("{30-50\\%}")#text(", adding about ")#mi("{0.2-0.3}")#text(" additional nines of safety.")],
[#text("As far as transmission of COVID is concerned, it ")#link("https://reader.elsevier.com/reader/sd/pii/S0140673620311429?token=7F86C0FB761D18174F76DC37E6115DAE19B67B4AA24A21BAB5B90E6DF0515445178C310314106039F1490990A92A6924&originRegion=us-east-1&originCreation=20211004031511")[#text("seems that")]#text(" constant use of face masks reduces transmission by a factor of about five (thus adding about ")#mi("{0.7}")#text(" nines of safety), and similarly for constant adherence to social distancing; whereas for instance a ")#mi("{30\\%}")#text(" compliance with mask usage ")#link("https://www.poverty-action.org/publication/impact-community-masking-covid-19-cluster-randomized-trial-bangladesh")[#text("reduced transmission by about")]#text(" ")#mi("{10\\%}")#text(" (adding only ")#mi("{0.05}")#text(" or so nines of safety).")]
)

#text("The effect of combining multiple (independent) precautions together is cumulative; one can achieve quite a high level of safety by stacking together several precautions that individually have relatively low levels of effectiveness. Again, see the “swiss cheese model” referred to in Remark ")#link(<tao-898fa2c627354c20bf3c>)[#text("5")]#text(". For instance, if face masks add ")#mi("{0.7}")#text(" nines of safety against contracting COVID, social distancing adds another ")#mi("{0.7}")#text(" nines, and the vaccine provide another ")#mi("{1.0}")#text(" nine of safety, implementing all three mitigation methods would (assuming independence) add a net of ")#mi("{2.4}")#text(" nines of safety against contracting COVID.")

#text("In summary, when debating the value of a given risk mitigation measure, the correct question to ask is not quite “Is it certain to work” or “Can it fail?”, but rather “How many extra nines of safety does it add?”.")

#text("As one final comparison between nines of safety and other standard risk measures, we give the following proposition regarding large deviations from the mean.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" Let ")#mi("{X}")#text(" be a ")#link("https://en.wikipedia.org/wiki/Normal_distribution")[#text("normally distributed")]#text(" random variable of standard deviation ")#mi("{\\sigma}")#text(", and let ")#mi("{\\lambda > 0}")#text(". Then the “one-sided risk” of ")#mi("{X}")#text(" exceeding its mean ")#mi("{{\\bf E} X}")#text(" by at least ")#mi("{\\lambda \\sigma}")#text(" (i.e., ")#mi("{X \\geq {\\bf E} X + \\lambda \\sigma}")#text(") carries")

#align(center)[#tao-fit-display[#mitex("-\\log_{10} \\frac{1 - \\mathrm{erf}(\\lambda/\\sqrt{2})}{2}")]]

#text("nines of safety, the “two-sided risk” of ")#mi("{X}")#text(" deviating (in either direction) from its mean by at least ")#mi("{\\lambda \\sigma}")#text(" (i.e., ")#tao-math("{\\left|X-{\\bf E} X\\right| \\geq \\lambda \\sigma}", block: false)#text(") carries")

#align(center)[#tao-fit-display[#mitex("-\\log_{10} (1 - \\mathrm{erf}(\\lambda/\\sqrt{2}))")]]

#text("nines of safety, where ")#mi("{\\mathrm{erf}}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Error_function")[#text("error function")]#text(".")
]

#emph[#text("Proof:")]#text(" This is a routine calculation using the cumulative distribution function of the normal distribution. ")#mi("\\Box")

#text("Here is a short table illustrating this proposition:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Number ")#mi("{\\lambda}")#text(" of deviations from the mean")],
table.cell(colspan: 1, rowspan: 1)[#text("One-sided nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#text("Two-sided nines of safety")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.8}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.9}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2.6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{4.2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{6.5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{6.2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{9.0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{8.7}")]
)

#text("Thus, for instance, the risk of a five sigma event (deviating by more than five standard deviations from the mean in either direction) should carry ")#mi("{6.2}")#text(" nines of safety assuming a normal distribution, and so one would ordinarily feel extremely safe against the possibility of such an event, unless one started doing hundreds of thousands of trials. (However, we caution that this conclusion relies ")#emph[#text("heavily")]#text(" on the assumption that one has a normal distribution!)")

#text("See also ")#link("https://terrytao.wordpress.com/anonymity-and-the-internet/")[#text("this older essay I wrote on anonymity on the internet")]#text(", using bits as a measure of anonymity in much the same way that nines are used here as a measure of safety.")

#heading(level: 1)[#text("Comments (61)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70afc46b147ddae94a359ef8ca49e5e291fca7800e9e09958219b6e07ac83b3b-8950154077a083003948994086a0a074c530e570da0a67867157bead4e84208e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamed")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635229")[#strong[#text("Hamed")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2021")])]

#text("Interesting concept but I’m not clear how it addresses the cases you raised in the beginning about weather prediction and voting. What’s the real advantage of this system rather than elegancy?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3f2e143df231eb23887a4c074d3486e45ecac6b66a0676151e3e012b1280de1-36c93d88e6e96d32d599795b8e561791dc6c629fa889eace91fbc53c356885d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635251")[#strong[#text("-")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("The utility of log probabilities is that they can be added and subtracted, instead of multiplied. Hence, they lend themselves to easier mental calculations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("It allows for a more apples-to-apples comparison between probabilities and risk. We are willing to use weather predictions that may be unreliable say 25% of the time (0.6 nines) because our risk tolerance for rain when we expect sun (or vice versa) is extremely high. On the other hand most of us would refuse to fly on an aircraft that is expected to crash 0.1% of the time (three nines) because our risk tolerance for death is extremely low. The problem with percentages is that their interpretation is context dependent in a mathematically complicated fashion: an assertion like “98% survival rate” would be very good in some contexts, and terrible in others. A logarithmic scale such as nines allows for easier comparisons, as it spaces out distinct values of risk more properly (e.g., 98% and 99% success rates seem very similar, but actually they differ by 0.3 nines, whereas 50% and 51% success rates, differing by only 0.01 nines, are essentially the same rate), and as mentioned in another comment allow one to use the simpler mental arithmetic of addition and subtraction (of numbers with one digit after the decimal point) to do calculations, rather than multiplication or division of percentages.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b733651f00c7faa673ce9cf862bf3e49391b1bd2ab20ddb87cd2dc8a548fa86-e7019884a55bbac7ddea11fd24cff27fadedcf608a7e0eeb4b36835af84b7aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred the Cat")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635243")[#strong[#text("Fred the Cat")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("seems overly complex for what should be a simple “hunch” test and individual risk management approach. e.g. a paranoid person with a 10% chance of rain, will take an overcoat, umbrella, gumboots; whereas someone else with the same chance of rain will pack their Hawaiian shirt. So do you need to layer different risk profiles on top of this to capture individual risk appetite?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("One feature of this system is that it allows for easier conversion from individual risk, which as you say people already have reasonable intuition for, to risk on groups. For weather this is not an issue, since in a group outing if it rains on one person it will almost certainly rain on everybody (the risk of rain is almost completely correlated amongst the group). But for say pandemic risk the situation is different and one’s intuition can lead one awry. An individual might take their chances with a 2% case fatality rate (1.7 nines) when contracting COVID (though this is still rather risky and unwise in my view), but may not realise that under a scenario in which say their extended family of ten people all contract COVID then the probability of at least one fatality in the group increases (assuming independence) to 18% (0.7 nines) which is much less acceptable. (This is an oversimplified model, since comorbidities will make the fatalities in this group correlated, but still hopefully illustrates the point that a nines-based perspective can help gauge risk more accurately.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4867e412df4a1eb67beffcdaf857c0de24c359b094289d3b5a226bfa9e18d9f8-7006aa26df85553fb6cfb52645335fce0915bd3c6bf1a93aa064da66e5bc847e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("IFR for Covid is 2% only in the 70+ age category")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4867e412df4a1eb67beffcdaf857c0de24c359b094289d3b5a226bfa9e18d9f8-7006aa26df85553fb6cfb52645335fce0915bd3c6bf1a93aa064da66e5bc847e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("Table 1 is the official IFR for Covid from the CDC")#linebreak()#text(" ")#link("https://www.cdc.gov/coronavirus/2019-ncov/hcp/planning-scenarios.html")[#text("https://www.cdc.gov/coronavirus/2019-ncov/hcp/planning-scenarios.html")]#linebreak()#text(" As you can see it is way lower than 2%.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("The caption of the table you cite literally says “These are *not* predictions or estimates of the expected impact of COVID-19.”")

#text("Plus, it is written just above that in this table, scenario 5 “represents the best estimate, based on the latest surveillance data and scientific knowledge.” Scenario 5 gives an IFR of 9% for 65+ years old, not 2% for 70+.")

#text("Also, this page was last updated on March 19 2021, way before the delta variant became dominant.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bed3d471d12dca5a78585e4624d7b694b8b19da7984f301c9cc5771f1975190-8ad62e11e2b778996f02bae5d65fabaf9ab60de7093e0b0da67bcc1c9da282c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("The caption of the table you cite literally says:")

#text("“The scenarios are intended to advance public health preparedness and planning.”")

#text("Cool you are right it’s 9% for 65+ and 0.05% for < 49 years. It is a pity that CDC does not update its information. One would have thought it's important in light of delta, but apparently it's not anymore.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("Sorry if my comment sounded too harsh or nitpicky, just wanted to nuance the data given at the link you shared. I agree with you, it is a pity the CDC page has not been updated (though they do explicitly caution that their table is not meant to give estimates). In general, I don’t think that this specific CDC page is a very good reference for a realistic estimate of the COVID-19’s current IFR in the general population.")

#text("This meta-analysis from the European Journal of Epidemiology (2020, before the alpha and delta variants) estimated the IFR of COVID-19 in general population to be between 0.5% and 2.5%, depending on the country (see Fig. 6): ")#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7721859/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7721859/")]#text(".")

#text("So the 2% given by Prof. Tao do not seem too far off.")

#text("Note that in hindsight, these estimates do not seem unrealistic. For instance about 0.18% of the whole population of Peru and 0.35% of the whole population of the Brazilian state of Amazonas officially died of COVID-19 as of today (and of course not everyone in these populations got infected).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("This other independent meta-analysis from a few months before estimates the IFR between 2% and 4.4% : ")#link("https://www.sciencedirect.com/science/article/pii/S138665322030113X?casa_token=6bKNuR7AkjsAAAAA:DCtkc7gDAhGhJ-Z7YnQBHfCyidnyNIjFBeWCcH4sJ74eaIEopCWBhVY4pdhKzzpg61gP_4Q_9g")[#text("https://www.sciencedirect.com/science/article/pii/S138665322030113X?casa_token=6bKNuR7AkjsAAAAA:DCtkc7gDAhGhJ-Z7YnQBHfCyidnyNIjFBeWCcH4sJ74eaIEopCWBhVY4pdhKzzpg61gP_4Q_9g")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/699e04b8e9e6d3da853b3f8fa6d7cd2453c6998eb6660e2c18371a24777a2151-5787f7e01aaeacfcb8a84b67c70f1bd43ee308bdc2f7d4949b35a0e8450f369c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("It’s actually kind of crazy that 3/2 year into a pandemic it is not possible to find an authoritative IFR that we can all agree on. This is why I choose to cite the CDC because it seemed to me to be the estimate that people would be the least likely to contest.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea00d905b16eabd038eda81732443236d197bbf3c534abe1dc52739d4f236258-92e2debc2edeb371189ce5ff46b608030263b14f7222bafe86b589cc2ad110fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Hilbert")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635661")[#strong[#text("David Hilbert")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2021")])]

#text("Since covid IFR is exponential with age, unconditional nines of safety are largely irrelevant. But conditional nines are illuminating.")

#text("Roughly, covid IFR(%) ~ 10^(age/20)/2,000 (rounding and rearranging the log(IFR) formula in the linked paper below.)")

#text("So that’s 5.3 nines of safety for newborns, 4.3 for 20 year-olds, 3.3 for 40 year-olds, 2.3 for 60 year-olds, and 1.3 for 80 year-olds.")

#text("40 (or 3.3 nines) is the cutoff around which covid risk is behaviorally relevant.")

#link("https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC7721859/")[#text("https://www.ncbi.nlm.nih.gov/labs/pmc/articles/PMC7721859/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("Given that the mRNA vaccines decrease the risk of death from COVID by a factor of ten or so, perhaps one way we should frame the benefit of the vaccine in view of this data is that it effectively makes you 20 years younger (with respect to the risk of dying from COVID). :-)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2021")])]

#text("20 years younger？60 to 40，or 40 to 20？")

#emph[#text("[As a first approximation, yes to both: a vaccinated person of age ")#mi("x")#text(" has roughly the same risk of dying from a COVID infection as an unvaccinated person of age ")#mi("x-20")#text(", for pretty much any ")#mi("x > 20")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4268e0bdba38547b16227cba11b3874fec35624f5bc4b9091422612d5746ea-7c199a48e8c6e975688055f635976fb26263babd3669bda938f7b6ffdb6bbf96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-638790")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("Hi Terry, be sure not to conflate correlation and causation! Being 20 years younger would also influence other variables that further change the prediction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-639857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("That’s a cool illustration of the usefulness of the concept.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635263")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("Perhaps some automatic translation app will turn “k nines of safety” into “guard dogs”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635278")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("Predrag Cvitanovic wrote down a comparative ‘struck by lightning’ metric on his blog years ago: ")#link("https://chaosbook.blogspot.com/2015/12/how-important-is-this-news-item-to-me.html")[#text("https://chaosbook.blogspot.com/2015/12/how-important-is-this-news-item-to-me.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("Nice! The “struck by lightning” measurement has the advantage that it automatically scales for changes in group size or exposure duration, avoiding the need for the additive or subtractive modifiers used here. The equivalent metric for nines would be the relative number of nines compared to being struck by lightning; for instance, dying in a car crash is about 3.2 nines more likely than being struck by lightning (corresponding to the “1400 SBLs” in that blog post), regardless of how large a group or what time period one is considering.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85ed6fc91926bf32202c91828ef4a5418b90c08e4cc183f997423bae8760070-27d41b2b8ba7f9c1e679535c2bfbc9c4f211f36117e361d7100aa39728ec9f4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris J.")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635303")[#strong[#text("Chris J.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("When I first started reading this post, I thought it was going to be a single unit of risk that lets you compare across choices where the severity may be different. For example, if with action #1 you have a 10% chance of catching a cold, but with action #2 you have a 0.0001% chance of dying, which should you choose? (Comparing different medical operations / procedures or choosing what foods to eat, etc. would be more concrete examples of this.) I think these types of choices come up a lot in life, and it would be helpful to have an easier way to reason about them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("One could take an economic viewpoint here and assign a monetary cost to any given risk. One crude metric here is the size of insurance policies that people generally take out against a risk: for instance if the average size of a life insurance policy is $1 million, then this would suggest that death would be equivalent to a cost of $1 million, or six orders of magnitude more than a dollar. Each nine of safety would then reduce this cost by an order of magnitude, for instance if one had six nines of safety against death as you suggest then the net cost of action #2 would roughly be a dollar. Doing a similar exercise for the cost of action #1 (figuring out the monetary cost of catching a cold and multiplying by 10%) would then allow for a comparison. So the question is how many orders of magnitude of cost one has for any given negative outcome.")

#text("(Of course, one could argue that not all costs can be measured by purely monetary means, but perhaps there are more sophisticated ways to estimate total cost that extend beyond the monetary dimensions. For instance one could use existing life choices of the individual to infer some implied relationships between the relative costs that individual assigns to various risks and thus tease out their implicit risk tolerances, though there may be limitations to such an approach if the individual is not perfectly rational.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636451")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2021")])]

#text("The expected monetary value approach you describe here seems at odds with your earlier observation that the difference between a 98% and a 99% chance of (say) surviving feels much bigger than the difference between 50% and 51%.")

#text("Any thoughts on reconciling these?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2021")])]

#text("This comes down to comparing costs in relative terms rather than absolute terms. If we assign a monetary value to death, then an action with a 98% survival rate has twice the expected cost as an action with a 99% survival rate, whereas an action with a 50% survival rate is only about 2% more “expensive” in cost than an action with a 51% survival rate. But in absolute terms they both cost the same amount of additional mortality.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2021")])]

#text("the ORF is a biological term means opening reading frame，which you cannot simply summarise its shade as arch ：-）")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2021")])]

#text("still miss the sunshine that day，see you in overflow：-）")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("“of a the” in defn 1")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("Sorry if I missed it, but is this proposal for the general public (and everyday language) or for scientists? If it’s the former, I wonder how well people can adapt their intuition to a logarithmic scale..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd355f89eabe8e858afc8ffffdea8eabd57b3c42ab01963ef718ec454d0b333e-ffc26dfc1f80edc741e217bb2245f5a5ddc1a8d9de2d2d79760ef95bbe73fff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B Fortner")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635332")[#strong[#text("B Fortner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("And all this talk about cheese is making me hungry! But seriously, I LIKE IT. If we use logarithms for earthquakes, and most people are familiar with that (and many understand the scaling of logarithms), they could certainly be useful for describing a pandemic, and comparing it to other pandemics, or even other disasters, if the same variables are used (such as deaths).")

#text("Sent from Yahoo Mail on Android")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635358")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2021")])]

#text("Just curious, are you thinking about these things as part of your new role in the White House?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635705")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("This is great news. Congratulations Prof. Tao. It is good to have top researchers in public policy making positions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ed48bee26be9430c4198927d5ceb594a5bed394505866d611c386eadf680ff5-1f1939a966ca0f0050b8b6c9759dbb4a41da1e8aae81322c7ae83e93e6970b89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Matte")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635414")[#strong[#text("Tom Matte")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("Professor Tao,")

#text("I wanted to send you an article I wrote for Medium. I think you’ll find the entire paper fascinating, especially the math. You can skip the intro and scroll down to the math section if you like.")

#link("https://medium.com/@tommatte/the-dark-matter-information-revolution-is-comingand-it-makes-artificial-intelligence-look-like-a-a040d446618e")[#text("View at Medium.com")]

#text("The way my mind sees mathematical objects doesn’t fit into the nice tidy package that we’re all taught as students. This coordinate system is fluid and has multiple origins, none of which are static.")

#text("Feel free to respond if you have any questions or need clarity on some of my work. I’m not a mathematician, but I do my best.")

#text("Thanks,")

#text("Tom")

#text("404-625-4611 tom-matte.com")

#text(">")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("You can’t see gravitational waves, Tom, and your coordinate system is nonsense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a99f5eadd9bced8233b7cac9ac5c59ab4b0799093f0e2feed020a554c86b6-f8207f40433fd572b79fcd511a6138685fa0b09c645093a35a314d87407bcc52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Casual causal")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635423")[#strong[#text("Casual causal")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2021")])]

#text("Causality is the new hype.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa78f1721eb24b4c8c9207612c4900ace136e8f826348889aa402da861c4def9-7a8fb38d3bdf6c72b856555be4d9ddcf13dd51dd74a340234bfb0c3c7959a2fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Natanael")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635451")[#strong[#text("Natanael")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("Thanks for the nice post Terence. Do you know the book by I. J, Good, Probability and the Weighing of Evidence? Working with A. Turing to break the Enigma codes, Good used ideas similar to the ones you proposed,")#linebreak()#text(" Cheers!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7c240b4f20e80cc18304e2cbbd0d27990d37eedd1f53d6580895fd9810753a4-afcc80a975add0aabc439fff2d7dc88666b08df8da2bc81b618e956d09d0be77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635483")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("Another approach to commicating certain kinds of risk is the micromort & the microlife. 1 micromort = 1 in a million chance of death (i.e. 6 nines of risk), and 1 microlife = a half hour reduction in life expectancy.")#linebreak()#text(" However Professor David Spiegelhalter tells me they didn’t gain the widespread use he’d hoped for: ")#link("https://www.facebook.com/econometricsguru/posts/2307447336003065")[#text("https://www.facebook.com/econometricsguru/posts/2307447336003065")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635486")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2021")])]

#text("Extending your approach, could we also use confidence intervals and hypothesis tests (chi-square test, Student t test, Fisher-Snedecor test)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635535")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2021")])]

#text("In the proof of proposition 10, the word “and” is not to be written in italic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2021")])]

#text("yes it is")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dara")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635560")[#strong[#text("Dara")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2021")])]

#text("This could be a great way of managing something I’ve seen as a big issue in Safety Engineering. In Failure Modes and Effect Analysis (FMEA), types of system failure are given a risk score which is calculated by multiplying a Probability score (1-5) by a Severity score (1-5), and sometimes multiplied again by a Detectability score. In the original military standard, MIL-P-1629, the levels of Probability are defined clearly: ‘Frequent’ is >20%, ‘Reasonably Probable’ is 10-20%, ‘Occasional’ is 1-10%, ‘Remote’ is 0.1-1%, ‘Extremely Unlikely’ is <0.01%. In the vulgarised versions of FMEA that crop up in manuals, these definite scores tend not to be included, and the non-linearity of the scale is lost. In my view, this means the tool ends up misrepresenting the nature of risk in these kinds of critical operations (like healthcare or aviation), as it makes the extreme risks under consideration seem more manageable. I really like the idea of the ‘nines’ as a way to make log-scales practicable, and getting an alternative notation to simple probabilities. If anyone knows of anything similar to this concerning risk, I’d love to hear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635586")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/10/09/nines-of-safety-a-proposed-unit-of-measurement-of-risk/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635587")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2021")])]

#text("This reminds me of Shannon entropy which I recently encountered and I am still studying about it, but I cannot figure out a proper connection between these two notions at this moment (must be because I don’t know much about Shannon entropy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2021")])]

#text("The current trend in US governments discourages gun use more, but legalizes drug use. Not a rational response.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2021")])]

#text("Speaking of irrational responses, the US is set to be passed in economic output by China in under 10 years, but the current government’s policy abroad emphasizes it’s not “US or China”. The US also made a State visit to Vietnam. A straightforward win instead is a correct response.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2021")])]

#text("China gained two years on the US in its race to overtake it economically as a result of the COVID-19 pandemic, according to current sources. Does anyone have an estimate of how this affects the probability of a deliberate attack? I had estimated this at high probabilty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2021")])]

#text("It’s fair to use harder science in decision making, which makes choices that are bright line. Hard analysis is also more useful than soft. When soft ergodic type theorems are proved instead with hard analysis, they have more applications.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Optimus subprime")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635843")[#strong[#text("Optimus subprime")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2021")])]

#text("Reminds me a bit of the “march of nines” that Elon has referred to regarding the development of self-driving cars.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3716da77396379308015a594b5975163867da5fe997f24ebbe447f738d16f137-48d06156876ad572f6d80e00ff83216da8722fbebd7307b14e5c209c5303a33e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Donald Richards")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-635930")[#strong[#text("Donald Richards")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2021")])]

#text("A minor typo: In the proof of Proposition 6, I think you need to change “geometric distribution of parameter {10^k}” to “geometric distribution with parameter {10^{-k}}”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636372")[#strong[#text("Nines of safety: a proposed unit of measurement of risk - 3 Quarks Daily")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2021")]

#text("[…] More here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d56553835196127182ecc3bfd4ef45a19b0ddd92a18ee68d62fa463c32b41549-7d46ac51d73baf9313a1d54fe39ded1082b80f1fcd6f75b6e4505ada4aec84ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of simnett")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636384")[#strong[#text("simnett")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2021")])]

#text("Would anything structural (ie aside from the numbers themselves) change if you used natural log, vs log (10)? It feels like 1/e is a nice sort of number, whereas (say) 3 * 1/10 is harder to think about. Related- if I have a 20 sided dice I “expect” (greater than 50%) to get a one after only 14 rolls, but I also have a ~1/e chance to not get a one after 20 rolls (which is much higher than most people expect).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636497")[#strong[#text("Three nines risk, ma’am – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2021")]

#text("[…] In everyday usage, we rely heavily on percentages to quantify probabilities and proportions: we might say that a prediction is accurate or accurate, that there is a chance of dying from some disease, and so forth. However, for those without extensive mathematical training, it can sometimes be difficult to assess whether a given percentage amounts to a “good” or “bad” outcome, because this depends very much on the context of how the percentage is used. For instance: … (What’s new/ Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-636708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2021")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Last night, I dreamed of a respected prince riding a white horse was coming to near the most beautiful forest in the world. More and more, it iwas very clear! The scence was very splendid like paradise! There was always a beautiful bird flying forward on the prince’ head to make a direction to the forest. How strange it is! Maybe,this seems to be the best news for the world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3becf93bdc8ef32c83eb4773da7a397ff7b3071845d80ae4286aaff39d450183-c46f69a6d332b04a6b6f18cee3621787479b5af8bb6e8e6c0a2c2fa9f33dbdc2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Haupt")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637036")[#strong[#text("Christian Haupt")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2021")])]

#text("‘In summary, when debating the value of a given risk mitigation measure, the correct question to ask is not quite “Is it certain to work” or “Can it fail?”, but rather “How many extra nines of safety does it add?”.’")

#text("In reality, we may face the problem, that a given risk mitigation measure carries itself risk that is at present unquantifiable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10d9ccd98894afba63442d6d4f6f392e05445d44e540f5f2edaeb554adf89ec2-3630aa7a62b39da387b8250c853ef88fd3b8f934cf1ef01899c6c3374fd92c85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DrB")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637251")[#strong[#text("DrB")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("If you are in the age range of 30-40. for healthy people, the risk of hospitalization from Covid is 1 in 4500 = 0.00022, source: ")#link("https://www.qcovid.org/Calculation")[#text("https://www.qcovid.org/Calculation")]#text(". Your chance of hospitalization from the covid shot (2 doses) due to myocarditis is 1 in 20000. Given that the vaccine effectiveness is basically zero after 6 months, you will need two boosters to have protection from hospitalization for an entire year. Hence the risk for myocarditis related hospitalization over the course of one year is therefore 0.00015. One additional booster the next year and your risk for hospitalization from the vaccine is greater than your risk of covid related hospitalization (you only get covid once, after which your natural immunity protects you from severe disease, probably a lifetime). This is, I think, an example of a cascade failure of a system. The vaccine effectiveness, over time, turns negative. You further need to consider that the creation of virulent variants, due to selective pressure from the S-specific antibodies in the vaccinated, may reduce the effectiveness of the vaccine even earlier than the 6 month window. Of course, mass vaccination campaigns increase the chances of escape variants of the virus. If, in addition, your waning antibodies from the vaccine lead to antibody dependent enhancement, you get additional increased risk of severe disease due to the vaccine, bringing the effectiveness even more into the negative numbers. Altogether, your risk from the vaccine is, over time, much much greater than your risk from the disease itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("What is the source on your myocarditis risk statistic? In particular, is it for the same (extremely favorable) “age range 30-40, healthy” demographic that the statistic you are trying to compare it with is drawn from?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10d9ccd98894afba63442d6d4f6f392e05445d44e540f5f2edaeb554adf89ec2-3630aa7a62b39da387b8250c853ef88fd3b8f934cf1ef01899c6c3374fd92c85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DrB")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637265")[#strong[#text("DrB")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("“Myocarditis With COVID-19 mRNA Vaccines”, Journal Circulation, page 3. I guess one can nitpick this, because the background rate is probably included in this estimate 1 / 20000. Age range for Myocarditis is 18-30. So I probably should have made my argument for the 20-30 age range to be more accurate and on target. The risk for Myocarditis from the vaccine decreases with age, so in the range 30-40 it is probably lower than 1 / 20000. I still think the overall argument can be made that way. Also, one should definitely include all other risk factors associated with the vaccines for a true thorough analysis, like the rate of Guillian Barre Syndrome, Appendicitis (this one, if caught early, is very treatable, but still almost always results in hospitalization), etc. All side effects are VERY RARE by themselves, but they are cumulative and that is the point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("Your analysis assumes that (a) the probability of an adverse reaction from a vaccine dose is independent for each dose (i.e., ignoring all risk factors that would be common to each dose), and (b) the lifelong COVID reinfection rate is zero. Also (c) you are still underplaying the risk of COVID by restricting to the “healthy” demographic when considering COVID risk, but not when considering vaccine risk.")

#text("In any case, the risk analysis you mention was indeed conducted in the journal paper you cite. To quote from its conclusion: “Given the known potential risk of complications with COVID-19 infection, including hospitalizations and death even in younger adults (mortality remains 0.1–1 per 100 000 for persons 12–29 years of age), the risk-benefit decision remains overwhelmingly favorable for vaccination.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10d9ccd98894afba63442d6d4f6f392e05445d44e540f5f2edaeb554adf89ec2-3630aa7a62b39da387b8250c853ef88fd3b8f934cf1ef01899c6c3374fd92c85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DrB")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637272")[#strong[#text("DrB")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("Thank you for your reply. Some remarks:")#linebreak()#text(" (a) The validity of this assumption requires more data. We don’t know for example the exact etiology of the vaccine induced Myocarditis. But I doubt that an argument of the form “if person x did not get M. from dose n, he will very likely not get M. from dose n+1” is valid. The occurrence of the inflammation could be completely up to the chaotic dynamics of the patients body, in combination with the distribution of the contents of the shot in the system. We do know, the risk is higher after the second dose. This is likely due to the presence of antibodies from the first dose, that can attack heart muscle, when the protein from the second dose is introduced, detected by the immune system and subsequently attacked. This would, I believe, give credence to the idea of assigning similar probabilities to booster shots. But this is for now only conjecture.")#linebreak()#text(" (b) I do not assume the lifelong reinfection rate to be zero. I do assume that the t-cell memory of the previously infected recovered patient recognize the pathogen at a later time, mounting a sufficient reaction to render the patient essentially save from a severe case of covid. He may still experience symptoms, but is essentially save from hospitalization. This assumption is backed by a great number of publications.")#linebreak()#text(" (c) The particular rate of Myocarditis (at least) is highest, in the very healthy and young demographic. In fact, athletes seem to be disproportionately affected.")

#text("The risk analysis of the paper does not take into account my larger point. Namely, that we will need booster shots in very short ranges, over an indefinite amount of time. Covid is very unlikely to disappear. Assuming that a vaccine with better durability does not come along in the near future, the cumulative burden of repeated booster shots should at least be taken into consideration. In particular, we could ask ourselves if potential treatments, using medication, could reduce covid risks more effectively in the long run.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10d9ccd98894afba63442d6d4f6f392e05445d44e540f5f2edaeb554adf89ec2-3630aa7a62b39da387b8250c853ef88fd3b8f934cf1ef01899c6c3374fd92c85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DrB")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637274")[#strong[#text("DrB")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("I should add that point (b) is much more difficult for the vaccinated. If the vaccinated person gets a breakthrough infection with covid, it may not be the case that they have the same broad protection from severe disease upon reinfection as the unvaccinated, due to a phenomenon called antigenic original sin. Data from public health England seems to support this: The previously infected vaccinated have lower levels of N-specific antibodies than the previously infected unvaccinated. This suggests that the S-specific antibodies of the vaccinated suppress their ability to mount a broad immune response upon infection. Hence a booster may be required EVEN after having had and recovered from a breakthrough infection.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-637281")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2021")])]

#text("The protective effect of COVID-19 antibodies is expected to wane after a year or so, which is not incomparable with the similar waning effect of the vaccine. But in any event this effect is only available to patients who were already infected at least once with COVID. If the risk to be measured is that of contracting COVID while unvaccinated at least once, this cumulative risk will still grow essentially linearly with time regardless of antibody protection amongst the previously infected; avoiding infection in one year confers no protection whatsoever against being infected the next. Compared against the conjecturally linear cumulative risk of booster shots, the net effect is largely a wash.")

#text("Also focusing on hospitalisation data alone seems to be the wrong metric, given that the average unvaccinated COVID hospitalization is significantly more severe than the average vaccine adverse reaction hospitalization (in particular the fatality rate from the former is certainly higher).")

#text("Finally, the young and healthy demographic also seems to be the wrong demographic to focus on for this discussion, given that boosters are only recommended at present for high-risk groups such as the aged or those with pre-existing conditions.")

#text("Certainly proper risk assessment should be done for all treatment options, but the proper venue for this is a peer-reviewed publication, not a sequence of blog comments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7490fe651105efea10f98432daa2021f6fa3e8ad83b3fb08e846a1a8ef130e5b-6ecd11c4f4d976be1b7ad5ee73986e8d49f67624434b0540a6f51028354b0011.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robi Rahman")]], [#link("https://terrytao.wordpress.com/2021/10/03/nines-of-safety-a-proposed-unit-of-measurement-of-risk/#comment-638208")[#strong[#text("Robi Rahman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2021")])]

#text("Your idea was cross-posted to the Effective Altruism forum,")#linebreak()#text(" ")#link("https://forum.effectivealtruism.org/posts/L9pB9sWTngF4BcHeL/nines-of-safety-terence-tao-s-proposed-unit-of-measurement")[#text("https://forum.effectivealtruism.org/posts/L9pB9sWTngF4BcHeL/nines-of-safety-terence-tao-s-proposed-unit-of-measurement")]

#text("where someone pointed out that this idea is already in use for electric grid availability:")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/High_availability")[#text("https://en.wikipedia.org/wiki/High_availability")]
]
