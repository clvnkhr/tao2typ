// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/
// Converted to Typst by tao2typ: "2026-10-14T15:20:43.965706+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Resources for displaced mathematicians", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Resources for displaced mathematicians")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/")[#text("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In this post I would like to collect a list of resources that are available to mathematicians displaced by conflict. Here are some general resources:")

#list(
[#text("The ")#link("https://www.scholarrescuefund.org/")[#text("IIE Scholar Rescue Fund")]

#list(
[#link("https://www.scholarrescuefund.org/iie-srf-statement-on-ukraine/")[#text("Statement on the war in Ukraine")]]
)],
[#link("https://www.scholarsatrisk.org/")[#text("Scholars at Risk")]

#list(
[#link("https://www.scholarsatrisk.org/2022/03/solidarity-with-the-people-of-ukraine-and-ukrainian-higher-education/")[#text("Statement of solidarity with the people of Ukraine and Ukrainian higher education")]]
)],
[#link("https://newuniversityinexileconsortium.org/programs/programs/")[#text("The New University in Exile Consortium programs for scholars")]],
[#text("(Europe) ")#link("https://allea.org/european-fund-for-displaced-scientists")[#text("European fund for displaced scientists")]#text(" (a joint ALLEA-Breakthrough Prize Foundation partnership)")],
[#text("(Brazil) The Sao Paulo Research Foundation has ")#link("https://fapesp.br/15402/initiative-researchers-at-risk")[#text("an initiative for Researchers at Risk")]#text(".")],
[#text("(Canada) ")#link("https://crm.umontreal.ca/InitiativeCRM-ISM/en/index.php")[#text("Joint CRM-ISM initiative in support of mathematicians in distress")]],
[#text("(Canada) ")#link("https://www.wes.org/ca/about-the-wes-gateway-program/")[#text("WES gateway program")]#text(" to assess educational credentials for displaced individuals")],
[#text("(France) The French ")#link("https://www.campusfrance.org/en/pause-program-urgent-aid-scientists-exile")[#text("PAUSE")]#text(" program (National program for the urgent aid and reception of scientists and artists in exile)")

#list(
[#text("PAUSE has a ")#link("https://www.college-de-france.fr/site/programme-pause/PAUSE-Solidarite-Ukraine.htm")[#text("special call for Ukrainian researchers at risk")]#text(".")]
)],
[#text("(Germany) The Humboldt Foundation’s ")#link("https://www.humboldt-foundation.de/en/apply/sponsorship-programmes/philipp-schwartz-initiative")[#text("Philipp Schwartz initiative")]

#list(
[#link("https://www.humboldt-foundation.de/entdecken/newsroom/pressemitteilungen/humboldt-stiftung-reagiert-mit-massnahmenpaket-auf-krieg-gegen-die-ukraine")[#text("Special measures for the current crisis")]#text(" include postponing the deadline for applications to March 18 for Ukrainian scholars, and arrangements for current recipients from Russia who are threatened due to their critical attitude to the war to receive fellowship extensions.")]
)],
[#text("(Germany) ")#link("https://www.dfg.de/en/research_funding/proposal_review_decision/refugee_researchers/index.html")[#text("DFG Refugee Researchers program")]

#list(
[#link("https://www.dfg.de/en/research_funding/announcements_proposals/2022/info_wissenschaft_22_65/index.html")[#text("Special programme for Ukraine")]]
)],
[#text("(UK) ")#link("https://www.cara.ngo/")[#text("Cara – a lifeline to academics at risk")]

#list(
[#link("https://www.cara.ngo/what-we-do/a-lifeline-to-academics-at-risk/ukraine-crisis/")[#text("Statement on the Ukraine crisis")]]
)],
[#text("(UK) ")#link("https://universities.cityofsanctuary.org/")[#text("Universities of Sanctuary")]#text(" network")

#list(
[#link("https://universities.cityofsanctuary.org/2022/03/03/how-you-can-support-the-people-of-ukraine")[#text("Statement on Ukraine")]]
)],
[#text("(UK) The Isaac Newton Institute for the Mathematical Sciences has a ")#link("https://www.newton.ac.uk/information/solidarity-list/")[#text("Solidarity list for researchers in the Mathematical Sciences")]#text(", as well as a ")#link("https://www.newton.ac.uk/event/slm/")[#text("Solidarity for Mathematicians programme")]#text(" for displaced mathematicians.")],
[#text("(UK) The University of Oxford Mathematical Institute has ")#link("https://www.maths.ox.ac.uk/node/41480")[#text("outreach sessions for Refugees and Asylum and Sanctuary Seekers")]#text(" to acclimate them to the academic environment in the UK.")],
[#text("(USA) Harvard University’s ")#link("https://harvardscholarsatrisk.harvard.edu/")[#text("Scholars at Risk")]#text(" (distinct from the preceding program of the same name)")]
)

#text("There are also resources specific to the current crisis:")

#list(
[#link("https://scienceforukraine.eu/")[#text("Science for Ukraine")]

#list(
[#text("See ")#link("https://genevasolutions.news/science-tech/meet-the-latvian-scholar-rallying-support-for-ukrainian-researchers?fbclid=IwAR27bUNtdkxbvCsX8DlnULlXIJNveVu8IvsGkdUieJbSdTfkyg-aOWyuujI")[#text("this web page")]#text(" for some background information on this initiative.")]
)],
[#link("https://jobsforukraine.net/")[#text("Jobs for Ukraine")]],
[#link("https://sites.google.com/view/helpuamath/home")[#text("Help for Displaced Ukrainian Mathematicians")]],
[#text("(Europe) The member universities of the ")#link("https://www.the-guild.eu/")[#text("Guild of European Research-Intensive Universities")]#text(" have ")#link("https://www.the-guild.eu/news/2022/time-for-action-universities-supporting-researcher.html")[#text("a number of support measures for researchers, academics, and students")]#text(" affected by the war in Ukraine.")],
[#text("(Europe) The European Research Centres on Mathematics (ERCOM) committee of the EMS has a ")#link("https://ercom.org/help-for-refugees.html")[#text("number of offers of assistance to mathematicians who are refugees of the current war")]#text(".")],
[#text("(Europe) The EU agency EURAXESS has an initiative ")#link("https://euraxess.ec.europa.eu/ukraine")[#text("ERA4Ukraine that collects various support initatives for Ukrainian researchers")]#text(".")],
[#text("(North America) ")#link("https://sites.google.com/view/ukrainian-mathematicians")[#text("Opportunities in North America for Ukrainian Mathematicians")]],
[#text("(Austria) Austrian Academy of Sciences ")#link("https://stipendien.oeaw.ac.at/stipendien/jesh")[#text("JESH academic mobility program")]#text(" – ")#link("https://stipendien.oeaw.ac.at/stipendien/jesh-ukraine")[#text("call for applications from Ukrainian researchers")]],
[#text("(Austria) FWF Austrian Science Fund has the ")#link("https://www.fwf.ac.at/en/news-and-media-relations/news/detail/nid/20220314")[#text("Crisis Support for Researchers from Ukraine program")]#text(".")],
[#text("(Belgium) The KU Leuven program for researchers from the global South has ")#link("https://www.kuleuven.be/onderzoek/gedocumenteerd/index_en.html#details/ecec501c82f32465f38b0a24df778f798a0fbddd")[#text("relaxed its eligibility requirements for Ukrainian refugees")]#text(".")],
[#text("(Belgium) The ")#link("https://www.ulb.be/")[#text("Université libre de Bruxelles")]#text(" has ")#link("https://www.ulb.be/fr/helpukraine/help-ukraine-communaute-universitaire")[#text("implemented emergency procedures")]#text(" to welcome Ukrainian students who have fled or plan to flee Ukraine because of the war. Contact: ")#link("mailto:helpukraine@ulb.be")[#text("helpukraine@ulb.be")]],
[#text("(Canada) ")#link("https://science.gc.ca/eic/site/063.nsf/eng/98369.html")[#text("A statement from the presidents of Canada’s federal research granting agencies to support Ukrainian research trainees")]#text(" (Additional contact: ")#link("https://personal.math.ubc.ca/~lior/")[#text("Lior Silberman")]#text(" ")#link("mailto:lior@math.ubc.ca")[#text("lior@math.ubc.ca")]#text(")")],
[#text("(Canada) PIMS ")#link("https://www.pims.math.ca/news/pims-statement-ukraine-crisis")[#text("Mathematical Scientist Support Fund Program")]],
[#text("(Canada) NSERC ")#link("https://www.nserc-crsng.gc.ca/Media-Media/NewsDetail-DetailNouvelles_eng.asp?ID=1317")[#text("Special Response Fund for Trainees (Ukraine)")]],
[#text("(Czechia) ")#link("https://www.avcr.cz/en/news-archive/The-Czech-Academy-of-Sciences-supports-scientists-in-Ukraine/")[#text("Announcement from the Czech Academy of Sciences")]#text(" (see also their “")#link("https://www.avcr.cz/en/Help-for-Ukraine/")[#text("Help for Ukraine")]#text("” page)")],
[#text("(Czechia) ")#link("https://gacr.cz/en/support-for-ukrainian-scientists-and-students/")[#text("Announcement from the Czech Science Foundation")]],
[#text("(Czechia) ")#link("https://www.nfneuron.cz/en")[#text("NF Neuron grant")]#text(" for Ukrainian scientists to study in the Czech republic")],
[#text("(Finland) ")#link("https://scientiarum.fi/eng/1660-2/")[#text("Call for grants for Ukrainian researchers in Finland")]],
[#text("(Finland) ")#link("https://www.helsinki.fi/en/admissions-and-education/open-university/enrolment-and-fees/open-university-courses-free-charge-citizens-ukraine")[#text("The University of Helsinki offers free courses at its Open University for citizens of Ukraine")]#text(".")],
[#text("(Germany) ")#link("https://www.uni-muenster.de/MathematicsMuenster/careers/ukraine/index.shtml")[#text("Opportunities in Germany for mathematicians from Ukraine")]#text(" (administered by the German Mathematical Society (DMV))")],
[#text("(Germany) ")#link("https://www.daad.de/en/the-daad/hilfsangebote/")[#text("Support and assistance for Ukrainian students and scientists")]#text(" (administered by the German Academic Exchange Service (DAAD))")],
[#text("(Germany) ")#link("https://www.volkswagenstiftung.de/en/funding/our-funding-portfolio-at-a-glance/funding-for-refugee-scholars-and-scientists-from-ukraine")[#text("Funding for Refugee Scholars and Scientists from Ukraine")]#text(" by the Volkswagen Foundation (Additional contact: ")#link("https://www.fernuni-hagen.de/analysis/team/delio.mugnolo.shtml")[#text("Delio Mugnolo")]#text(" ")#link("mailto:delio.mugnolo@fernuni-hagen.de")[#text("delio.mugnolo@fernuni-hagen.de")]#text(")")],
[#text("(Germany) ")#link("https://ukrainet.eu/")[#text("The Deutsch-Ukrainische Akademische Gesellschaft page on support for students and researchers from Ukraine")]],
[#text("(Germany) University of Muenster ")#link("https://www.uni-muenster.de/de/en/ukraine/index.html")[#text("statement on Ukraine")]],
[#text("(Germany) Berlin Mathematics Research Center ")#link("https://mathplus.de/news/math-support-for-mathematicians-from-ukraine/")[#text("MATH+ Support for mathematicians for Ukraine")]],
[#text("(Luxembourg) The Luxembourg National Research Fund offers ")#link("https://www.fnr.lu/temporary-fnr-support-for-researchers-who-have-fled-the-war-in-ukraine/")[#text("Temporary FNR support for Researchers who have fled the war in Ukraine")]#text(".")],
[#text("(Hungary) There are ")#link("https://www.renyi.hu/en/the-institute/vacancies/research-fellowship-for-ukrainian-mathematicians")[#text("some resources available")]#text(" at the ")#link("https://www.renyi.hu/hu")[#text("Renyi Institute")]#text(" in Hungary. Contact: ")#link("https://www.renyi.hu/~stipsicz/")[#text("Andras Stipsicz")]#text(" ")#link("mailto:stipsicz.andras@renyi.hu")[#text("stipsicz.andras@renyi.hu")]],
[#text("(Poland) Science for Ukraine ")#link("https://amu.pan.pl/en/pomoc-ukrainie/")[#text("Action at AMU PAN")]#text(" (Polish Young Academy – Polish Academy of Sciences) ")#link("https://institution.pan.pl/index.php/755-visits-of-ukrainian-scientists-to-pas")[#text("Visits of Ukrainian scientists to the Polish Academy of Sciences")]

#list(
[#text("This effort is also ")#link("https://www.nationalacademies.org/news/2022/03/nas-launches-effort-to-help-support-ukrainian-researchers-as-they-resettle-in-poland")[#text("being supported by the National Academy of Sciences in the US")]#text(" via the ")#link("https://www8.nationalacademies.org/academygiving/nasem/academygiving.aspx?fundname=Safe%20Passage%20Fund")[#text("Safe Passage Fund")]#text("; ")#link("https://institution.pan.pl/index.php/769-support-for-ukrainian-scholars")[#text("more details here")]#text(".")]
)],
[#text("(Poland) ")#link("https://www.ncn.gov.pl/aktualnosci/2022-03-28-program-specjalny-NCN-dla-Ukrainy")[#text("The National Science Center has a special program for researchers from Ukraine")]#text(".")],
[#text("(Sweden) The Swedish Foundation for Strategic Research has ")#link("https://strategiska.se/en/ssf-supports-ukrainian-researchers-with-30-million-sek/")[#text("individual grants for Ukrainian scientists")]#text(".")],
[#text("(Sweden) The Royal Swedish Academy of Sciences announces ")#link("https://www.kva.se/en/utlysningar/stipendier-bidrag/for-ukrainska-forskare-att-verka-i-sverige")[#text("scholarships for Ukrainian scientists to perform research in Sweden")]#text(".")],
[#text("(Taiwan) Taiwan is ")#link("https://institution.pan.pl/index.php/759-academia-sinica-taiwan-scholarships-for-ukrainian-students")[#text("offering scholarships for Ukrainian students and scholars")]#text(".")],
[#text("(USA) The National Academy of Sciences has a ")#link("https://www.nationalacademies.org/supporting-ukraines-scientists-engineers-and-health-care-workers")[#text("page for resources supporting Ukraine’s scientists, engineers, and health care workers")]#text(".")],
[#text("(USA) The American Mathematical Society ")#link("https://www.ams.org/displaced/ukraine-resources")[#text("has a page on resources for displaced mathematicians")]#text(".")]
)

#text("Finally, there are a number of institutes and departments who are willing to extend visiting or adjunct positions to such displaced mathematicians:")

#list(
[#text("(Australia) The Sydney Mathematical Research Institute has launched a ")#link("https://mathematical-research-institute.sydney.edu.au/ukrainian-visitor-program/")[#text("Visitor Program for Displaced Mathematical Scientists from Ukraine")]#text(".")],
[#text("(Austria) The Erwin Schrodinger Institute has a ")#link("https://www.esi.ac.at/news/n23")[#text("Special Research Fellowship for Ukrainian Scientists")]#text(".")],
[#text("(Brazil) ")#link("https://impa.br/en_US/noticias/support-of-mathematicians-affected-by-war/?fbclid=IwAR3T1EcSVTNupSPBi8ew2umhLlmyrhhEvpbByi6jIhgEazXfn-RxFYcFn_I")[#text("IMPA offers a program in support of mathematicians affected by war or persecution")]#text(".")],
[#text("(Canada) ")#link("https://mysite.science.uottawa.ca/agerolin/")[#text("Augusto Gerolin")]#text("‘s research group at the University of Ottawa ")#link("https://mysite.science.uottawa.ca/agerolin/openpositions.html")[#text("has PhD and postdoctoral positions available")]#text("; Ukrainian students are highly encouraged to apply.")],
[#text("(Denmark) ")#link("https://aias.au.dk/opportunities-at-aias/auff-ukraine-fellowships")[#text("AUFF-Ukraine research fellowships")]#text(" at ")#link("https://aias.au.dk/")[#text("AIAS, Aarhus University")]],
[#text("(Germany) ")#link("https://www.mathcore.ovgu.de/index.php?show=home")[#text("MathCoRe")]#text(" at the Otto von Guericke University of Magdeburg ")#link("https://www.mathcore.ovgu.de/index.php?show=joinus")[#text("supports visiting scientists affected by the current conflict")]#text(". (Contact information contained in the link.)")],
[#text("(Germany) Oberwolfach has a statement on ")#link("https://www.mfo.de/about-the-institute/news/solidarity-with-ukraine-support-for-ukrainian-scientists")[#text("Solidarity with Ukraine – support for Ukrainian scientists")]],
[#text("(Germany) Friedrich Alexander University (FAU) at Erlangen-Nuremberg has a page on ")#link("https://www.fau.de/informationen-auf-ukrainisch")[#text("assistance to Ukraine")]#text(".")],
[#text("(Israel) Tel Aviv University has launched an ")#link("https://english.tau.ac.il/news/ukrainian_student_fellowship_fund")[#text("emergency fellowship fund for Ukrainian graduate students")]#text(".")],
[#text("(Israel) The Weizmann Institute of Science has ")#link("https://www.weizmann.ac.il/feinberg/supported-visiting-students-and-postdocs-program-ukrainians")[#text("a program to support visiting students and postdocs")]#text(" and encourages applications from Ukraine.")],
[#text("(Israel) The Technion ")#link("https://twitter.com/TechnionLive/status/1500834929567047681")[#text("opened a specific budget to host undergraduate and graduate students, post-docs, and faculty from Ukraine")]#text(". Contacts: Ms. Ortal Arazi Minyan ")#link("mailto:ortala@int.technion.ac.il")[#text("ortala@int.technion.ac.il")]#text(" (for students) and Ms. Lisa Aisman ")#link("mailto:lisa@technion.ac.il")[#text("lisa@technion.ac.il")]#text(" (for postdocs/faculty)")],
[#text("(Israel) The Hebrew University of Jerusalem ")#link("https://international.huji.ac.il/news/hebrew-university-emergency-aid-researchers-and-students-ukraine")[#text("opened an emergency aid for researchers and students from Ukraine")]#text(". The invitation is for a period of up to four months.")],
[#text("(Israel) Ben Gurion University ")#link("https://in.bgu.ac.il/en/international/Pages/Financial-Aid.aspx")[#text("has a program for students and researchers affected by the war")]#text(". Contact: ")#link("mailto:oiaa@bgu.ac.il")[#text("oiaa@bgu.ac.il")]],
[#text("(Italy) ")#link("https://www.polimi.it/en/landingpages/ukraine/")[#text("Politecnico de Milano welcomes Ukrainian students and researchers")]#text(".")],
[#text("(Luxembourg) The University of Luxembourg offers ")#link("https://wwwfr.uni.lu/ukraine")[#text("support initiatives for displaced researchers and students from Ukraine")]#text(".")],
[#text("(Netherlands) Utrecht University has a page containing ")#link("https://www.uu.nl/en/news/support-from-the-mathematical-institute-for-students-lecturers-and-researchers-from-ukrainian")[#text("Support from the Mathematical Institute for students, lecturers and researchers from Ukrainian universities")]#text(".")],
[#text("(Poland) The Polish Academy of Sciences offers help to Ukrainian mathematicians, including accommodation and employment. Contact: ")#link("mailto:mail.amu.pan@gmail.com")[#text("mail.amu.pan@gmail.com")]],
[#text("(Poland) The Institute of Mathematics of the Polish Academy of Sciences (IMPAN) in particular offers such help to Ukrainian mathematicians. Contact: ")#link("http://achinger.impan.pl/")[#text("Piotr Achinger")]#text(" ")#link("mailto:pachinger@impan.pl")[#text("pachinger@impan.pl")]],
[#text("(Poland) The CS/math department of the University of Warsaw (MIMUW) also offers help. Contact: ")#link("http://achinger.impan.pl/")[#text("Piotr Achinger")]#text(" ")#link("mailto:pachinger@impan.pl")[#text("pachinger@impan.pl")]],
[#text("(Spain) ")#link("https://www.uc3m.es/ss/Satellite/Empleo/es/Detalle/Ficha_C/1371329345337/1371272207002/Contratacion_de_Profesorado_Visitante")[#text("A visiting position at the Universidad Carlos III de Madrid")]#text(", aimed at Ukrainian nationals")],
[#text("(UK) The London Institute for Mathematical Sciences is ")#link("https://lims.ac.uk/careers/arnold-fellowships-in-physics-and-mathematics/")[#text("hiring five Arnold Fellows from Russia, Ukraine and Belarus in theoretical physics and mathematics")]#text(".")],
[#text("(USA) My ")#link("https://ww3.math.ucla.edu/")[#text("home department at UCLA")]#text(", in cooperation with ")#link("http://www.ipam.ucla.edu/")[#text("IPAM")]#text(", is likely to have a position available for such mathematicians. Contact: ")#link("https://www.math.ucla.edu/~shlyakht/")[#text("Dimitri Shylakhtenko")]#text(" ")#link("mailto:shlyakht@math.ucla.edu")[#text("shlyakht@math.ucla.edu")]],
[#text("(USA) An ")#link("https://president.columbia.edu/news/message-regarding-ukraine")[#text("announcement from Columbia University")]],
[#text("(USA) The mathematics department at Indiana University, Bloomington has several positions. Contact: ")#link("https://math.indiana.edu/about/faculty/pilgrim-kevin.html")[#text("Kevin Pilgrim")]#text(" ")#link("mailto:pilgrim@iu.edu")[#text("pilgrim@iu.edu")]],
[#text("(USA) The mathematics department at Michigan State University ")#link("https://www.mathjobs.org/jobs/list/18643")[#text("may have up to two positions for mathematics faculty who are displaced by the Ukrainian crisis")]#text(". Applicants are encouraged to contact a faculty member at MSU who will support their nomination.")],
[#text("(USA) The mathematics department at Johns Hopkins University has 2-3 ")#link("https://www.mathjobs.org/jobs/list/19628")[#text("one-year visiting positions for next year")]#text(", and is willing to waive some of the required documents for such applications for displaced persons. Contacts: ")#link("https://math.jhu.edu/~savitt/")[#text("David Savitt")]#text(" ")#link("mailto:savitt@jhu.edu")[#text("savitt@jhu.edu")]#text(" and ")#link("https://math.jhu.edu/~eriehl/")[#text("Emily Riehl")]#text(" ")#link("mailto:eriehl@jhu.edu")[#text("eriehl@jhu.edu")]#text(".")],
[#text("(USA) MIT could accept a few Ukrainian/Russian mathematicians as visitors. Contact: ")#link("https://math.mit.edu/~etingof/")[#text("Pavel Etingof")]#text(" ")#link("mailto:etingof@math.mit.edu")[#text("etingof@math.mit.edu")]],
[#text("(USA) Georgia Tech has a ")#link("https://www.mathprograms.org/db/programs/1295")[#text("program for displaced students")]#text(".")],
[#text("(USA) ")#link("https://www.gmu.edu/")[#text("George Mason University")]#text(" has a 2-year visiting scholar position in Math available starting Fall 2022, specifically targeting Ukrainian and Russian mathematicians affected by the crisis. Contact: Maria Emelianenko ")#link("mailto:memelian@gmu.edu")[#text("memelian@gmu.edu")]]
)

#text("If readers have other such resources to contribute (or to update the ones already listed), please do so in the comments and I will modify the above lists as appropriate.")

#text("As with the previous post, any purely political comment not focused on such resources will be considered off-topic and thus subject to deletion.")

#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e33d9ea6000eb2a3e67bfbc4297503708233f7efe799f5045bec2cc1f914e61e-e58bd3fae0600a7b3d95b701d1eee764047209091f62df4ac028c0501d23446e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Kosenko")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641028")[#strong[#text("Andrew Kosenko")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("Columbia sent a message on this topic just now; an excerpt is below:")

#text("“As hundreds of thousands of people are being forced from their homes, pouring into neighboring countries and nations across Europe, we, as an institution of learning, will expand the initiative we put in place for students and scholars displaced by the crisis in Afghanistan to include those seeking refuge from the war in Ukraine. We are eager to welcome these students and scholars to our campuses.”")

#text("Important to note – men between 18 and 60 are not currently permitted to leave Ukraine.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gpecc")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641029")[#strong[#text("gpecc")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("Dear Terry,")

#text("Please check this initiative:")

#link("https://scienceforukraine.eu/")[#text("https://scienceforukraine.eu/")]

#text("Some explanation is here:")

#link("https://genevasolutions.news/science-tech/meet-the-latvian-scholar-rallying-support-for-ukrainian-researchers?fbclid=IwAR27bUNtdkxbvCsX8DlnULlXIJNveVu8IvsGkdUieJbSdTfkyg-aOWyuujI")[#text("https://genevasolutions.news/science-tech/meet-the-latvian-scholar-rallying-support-for-ukrainian-researchers?fbclid=IwAR27bUNtdkxbvCsX8DlnULlXIJNveVu8IvsGkdUieJbSdTfkyg-aOWyuujI")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3033cb72452d14b06ade421fcfd3bc2c97fe56a2f07e45b686bee75480fa1a0-72a2dbd92d7f201d4537600723db3f3bb050da89a9d8443cfa1569d0965327a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evangelos Bampas")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641031")[#strong[#text("Evangelos Bampas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("PAUSE, National program for the urgent aid and reception of scientists in exile (France)")

#link("https://www.campusfrance.org/en/pause-program-urgent-aid-scientists-exile")[#text("https://www.campusfrance.org/en/pause-program-urgent-aid-scientists-exile")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d1d0588c13970b08038ef4eb6f465ede3a5e0497b25cfacd83e28c3fc751db1-a122b3c81260779a1d846bca50733746e7a862cfa8be1c215191b1eb0753da6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr Achinger")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641050")[#strong[#text("Piotr Achinger")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("Thank you for this post!")

#text("The Polish Academy of Sciences offers help to Ukrainian mathematicians, including accommodation and employment. Contact ")#link("mailto:mail.amu.pan@gmail.com")[#text("mail.amu.pan@gmail.com")]#text(" .")

#text("The Institute of Mathematics of the Polish Academy of Sciences (IMPAN) in particular offers such help to Ukrainian mathematicians. Please contact me directly: ")#link("mailto:pachinger@impan.pl")[#text("pachinger@impan.pl")]

#text("The CS/math department of the University of Warsaw (MIMUW) also offers help, though I don’t know of an official statement. Again, just contact me at ")#link("mailto:pachinger@impan.pl")[#text("pachinger@impan.pl")]#text(" and I will talk to people there.")

#text("The above are not listed (yet) on the map “Science for Ukraine”.")

#emph[#text("[Added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36355f0eea87194a6011ee392d91efa415c56e362f2875441485dbd5398cd3e7-89b8bd539bc097f745c78ab9180f70a7f2dae06b291cc659956f633e864fdf56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radek Adamczak")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641054")[#strong[#text("Radek Adamczak")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("In addition to Piotr’s answer let me mention two relevant web pages:")

#link("https://amu.pan.pl/en/pomoc-ukrainie/")[#text("https://amu.pan.pl/en/pomoc-ukrainie/")]

#link("https://institution.pan.pl/index.php/755-visits-of-ukrainian-scientists-to-pas")[#text("https://institution.pan.pl/index.php/755-visits-of-ukrainian-scientists-to-pas")]

#emph[#text("[Added, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195148c9512b278af3c5a4736616a6c3c02da531fa3d2162ab53b1cf8dd347b8-d8e7519ada97498c3e23e3536ffc499b8027882d1828d8a0a844f34f8fbd368a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641051")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#link("https://www.humboldt-foundation.de/en/apply/sponsorship-programmes/philipp-schwartz-initiative")[#text("https://www.humboldt-foundation.de/en/apply/sponsorship-programmes/philipp-schwartz-initiative")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfe9f3e93bdc52045a994d49c01cafb20a449c271afcf0b3aa6cd3177535d8fe-12ebb124206127343e19d26465114837008fcaac7bb033189620e73373735cf0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin M. Pilgrim")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641055")[#strong[#text("Kevin M. Pilgrim")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("Indiana University (Bloomington, Indiana) has several open positions. Inquiries may be sent to Chair Kevin Pilgrim at ")#link("mailto:pilgrim@iu.edu")[#text("pilgrim@iu.edu")]#text(" .")

#emph[#text("[Added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("@Terry: I think there are typos in “Indiana Math University” in your post.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82d790f317c439ff7abd23f90d134c956c18055ad49f8c2ba8140ed7e0a37757-3420c303cf1b242eb9ffda3a3b1d8bf60ad9f62962bd2f89bcd674d762fab5be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of praguencgt")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641057")[#strong[#text("praguencgt")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("Opportunities in Czech Republic:")

#text("1. ")#link("https://www.avcr.cz/en/news-archive/The-Czech-Academy-of-Sciences-supports-scientists-in-Ukraine/")[#text("https://www.avcr.cz/en/news-archive/The-Czech-Academy-of-Sciences-supports-scientists-in-Ukraine/")]

#text("2. ")#link("https://www.nfneuron.cz/en")[#text("https://www.nfneuron.cz/en")]

#text("3. ")#link("https://gacr.cz/en/support-for-ukrainian-scientists-and-students/")[#text("https://gacr.cz/en/support-for-ukrainian-scientists-and-students/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0a267a97cf2278ecea4d2a52c424fb7e264bb1dd1a84f9d00045d82e6be061c-444f87f707e8e2547f48923c03184fd042edd6b4dab28714483bfaf2e07ee17c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascal")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641058")[#strong[#text("pascal")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("The ÖAW (Austrian Academy of Sciences) offers a special mobility program targeted at all Ukrainian scientists (including mathematicians) who had/have to leave their country:")#linebreak()#text(" ")#link("https://stipendien.oeaw.ac.at/stipendien/jesh-ukraine")[#text("https://stipendien.oeaw.ac.at/stipendien/jesh-ukraine")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("Will this leads to an influx of academics from Russia and Ukraine such that the new grads will be at a disadvantage on the job market? I heard sometime before (maybe in the 80s?), a lot of established Russian mathematicians came to the US, and left many new grads jobless. There is no way a new grad can compete with established mathematicians in terms of publication record.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eddce67de066fdfcee59fd567961edf5aaecefcf2f18493a01a66dc08772b6e1-ea9b60c1ad5e3556d61db4d3eb8cd47b278f3fbc05df5054a337295642f37722.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yanky Landau")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641064")[#strong[#text("Yanky Landau")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("As a grad student myself (albeit in physics, not math) this does resonate with me. However, my framing for this is that Putin upended global stability; it happened and that’s that. The cost for some people will be their lives, for some their families, for some financial hardships that will cripple their entire lives, and for some a decreased probability in getting their first choice of job. I am very happy that I am only in the final category")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d45fda403bde3d868619a06847db04e140f17c3e16611f55e90f9288c6a3b636-f7efc26bfd697b1aabb34d1820c25980ebdb1dfe7f0a9739d90970b1a25cd9cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Lessig")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641062")[#strong[#text("Christian Lessig")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("See the section Ukrainian scientists on this page: ")#link("https://www.mathcore.ovgu.de/index.php?show=joinus")[#text("https://www.mathcore.ovgu.de/index.php?show=joinus")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab16edac0e5c9cfd1b9b7fe24a39a921fab0961fdeb1339a4d0b004194906774-a97ed6e9a6aec06fbbd8ec5fe1d55a6cfd06a959362356c42320869110f5e406.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Savitt")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641095")[#strong[#text("David Savitt")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("The math department at Johns Hopkins has 2-3 one-year visitor positions for next year : ")#link("https://www.mathjobs.org/jobs/list/19628")[#text("https://www.mathjobs.org/jobs/list/19628")]#linebreak()#text(" Displaced mathematicians wanting to be considered for these could also contact me directly at ")#link("mailto:savitt@jhu.edu")[#text("savitt@jhu.edu")]#text(", or Emily Riehl at ")#link("mailto:eriehl@jhu.edu")[#text("eriehl@jhu.edu")]#text(". The mathjobs application link asks for some materials, but this isn’t necessary if someone might have trouble getting the materials together.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gilles Lancien")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641101")[#strong[#text("Gilles Lancien")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("To complete the message by Evangelos Bampas (2 March 2022). The link to the French program PAUSE dedicated to Ukrainian researchers :")#linebreak()#text(" ")#link("https://www.college-de-france.fr/site/programme-pause/PAUSE-Solidarite-Ukraine.htm")[#text("https://www.college-de-france.fr/site/programme-pause/PAUSE-Solidarite-Ukraine.htm")]

#emph[#text("[Link added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb430903b4c720929edcb7a1ba879625798188b15ffaf304221f3bbb33fc58e0-3fe3db3cac6fc9451658489b037b1976d75f0bedb858c3ae1ff345c123d15abe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuela Zucknick")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641124")[#strong[#text("Manuela Zucknick")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2022")])]

#text("Also see this list of measures for Ukrainian scientists from the Guild, a European network of universities, including my own University of Oslo: ")#link("https://www.the-guild.eu/news/2022/time-for-action-universities-supporting-researcher.html")[#text("https://www.the-guild.eu/news/2022/time-for-action-universities-supporting-researcher.html")]

#emph[#text("[Added, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b79af867da5b26d1e99314d2ada0f8624de4e40523136377a239ec20fec3f4c3-9fc098e083af397379b7a49bc964a02ac1ae358657e24f34aa87342844202003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir G.")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641126")[#strong[#text("Ofir G.")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2022")])]

#text("The Weizmann institute invites Ukranian graduate students and postdocs to apply to their Visiting Students Program. Information can be found at ")#link("https://www.weizmann.ac.il/feinberg/supported-visiting-students-and-postdocs-program-ukrainians")[#text("https://www.weizmann.ac.il/feinberg/supported-visiting-students-and-postdocs-program-ukrainians")]

#text("I quote:")#linebreak()#text(" “The Feinberg Graduate School at the Weizmann Institute of Science invites advanced undergraduate, graduate students, and postdoctoral researchers to apply to our supported Visiting Students Program. The program welcomes students from Life Sciences, Mathematics & Computer Science, Chemistry, Physics, and Science Teaching to apply. Visitors will be hosted at one of our labs and will get monthly support of 5000 NIS for up to six months + accommodations + airfare.”")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36355f0eea87194a6011ee392d91efa415c56e362f2875441485dbd5398cd3e7-89b8bd539bc097f745c78ab9180f70a7f2dae06b291cc659956f633e864fdf56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radek Adamczak")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641232")[#strong[#text("Radek Adamczak")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2022")])]

#text("There is also this initiative, apologies if it’s already listed (I can’t see it):")

#link("https://sites.google.com/view/ukrainian-mathematicians")[#text("https://sites.google.com/view/ukrainian-mathematicians")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641242")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2022")])]

#text("Good gesture. But aren’t men between 18 and 60 not allowed to leave Ukraine? So technically, these only apply to women mathematicians, which are very few.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a7785f400134756c2dbe1db8486afdce54caf243780f0cee03dd937024813c-f7148a7bb35fd24f11799941beb47a03652d219c33131383e1e6b0ef7d067a5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandra Haedrich")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641259")[#strong[#text("Alexandra Haedrich")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("Prompted by the events in Ukraine, the Centre de recherches mathématiques and the Institut des sciences mathématiques (Montreal, Canada) offer a program in support of mathematicians in distress due to war, oppression, and persecution: ")#link("https://crm.umontreal.ca/InitiativeCRM-ISM/en/index.php")[#text("https://crm.umontreal.ca/InitiativeCRM-ISM/en/index.php")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93ea3721bdd8548d14fa4a9b76621a160c698690a6e1b0143f201ba8e6d0684c-7a5d2d1cce7ce5687644d9966f0c0cebe096b721d796fb994311c503718fc5a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jhschenker")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641260")[#strong[#text("jhschenker")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("The Mathematics department at Michigan State University may have up to two positions for mathematics faculty who are displaced by the Ukrainian crisis. Those in need are encouraged to apply to the Michigan State University Research Associate position advertised at ")#link("https://www.mathjobs.org/jobs/list/18643")[#text("https://www.mathjobs.org/jobs/list/18643")]#text(" and contact a faculty member at MSU who will support their nomination.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eaf804923dc189d55008256e789e1e99af0a4735187fc8fb544545c29862c025-d5ab81c0af308157e820cbb797b442207481c4d202cffae38def54a2fd32ed1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Augusto Gerolin")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641267")[#strong[#text("Augusto Gerolin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("PhD and Postdoctoral positions available in my research group at the University of Ottawa")#linebreak()#text(" ")#link("https://mysite.science.uottawa.ca/agerolin/openpositions.html")[#text("https://mysite.science.uottawa.ca/agerolin/openpositions.html")]

#text("Ukrainian students are highly encouraged to apply.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("Sad news. She didn’t make it.")#linebreak()#text(" —————————————-")#linebreak()#text(" Yulia Zdanovska. She was 21. One of Europe’s best young mathematicians, a winner of European Math Olympics in 2017. She died under RU shelling in Kharkiv the other day")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641932")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("I understand she chose to teach math to underprivileged children through Teach For Ukraine in her city and was killed in a missile attack while distributing aid. A pic of her shows her in a t-shirt on which was printed “Education lights a fire” from William Butler Yeats: “Education is not the filling of a pail, but the lighting of a fire.” (History is repeating itself. The Scottish Cafe is in Lviv, which was Lwow, Poland, during and before WW II. Most of the Lwow school of mathematicians who authored The Scottish Book were either killed or emigrated to the U.S. War has no favorites.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-643075")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2022")])]

#text("“Yulia’s Dream is a unique program based on Massachusetts Institute of Technology (MIT) dedicated to the memory of Yulia Zdanovskaya 💛💙")#linebreak()#text(" This is a free math research program for gifted pupils (9-11 grades) from Ukraine based on the world’s best technological university.")

#text("(")#link("https://www.facebook.com/oksana.matiyash.9/posts/5042207402530797")[#text("https://www.facebook.com/oksana.matiyash.9/posts/5042207402530797")]#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-643134")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("Sorry, the deadline for entering this program has already expired,")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641296")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("Thank you Professor Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4931a41030b93f919eebeda0fac55c5eba989f8e7cd56b89e2cce462ef78d0d8-1ed335d0bab18beb37a4af5aa1a388a68ca03e170d0e692ba70d83e67b84fe19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andriy Haydys")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641302")[#strong[#text("Andriy Haydys")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2022")])]

#text("My home institution, ULB (ulb.be), is putting in place an emergency procedure to welcome Ukrainian students who have fled or plan to flee Ukraine because of the war. We offer the possibility to welcome you on our campuses for the upcoming months, free of charge, to attend a specific module we are currently designing for Ukrainian students. The module will include courses of French language for beginners as well as optional English. Enrollment is possible from Autumn 2022. More info via ")#link("mailto:helpukraine@ulb.be")[#text("helpukraine@ulb.be")]

#emph[#text("[Added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c27b611be94eeed4b4d733b1fd74148e80fded9fdbfd81653583e1e4ce04bac-03a6358cfbfeea3b5345f1daf229ec2a337d05e1e9500675a2729fd8bd889102.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Announcement of fellowships at Aarhus University, Denmark: ")#link("https://aias.au.dk/opportunities-at-aias/auff-ukraine-fellowships")[#text("https://aias.au.dk/opportunities-at-aias/auff-ukraine-fellowships")]

#emph[#text("[Added, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c00c973dc29f58f9b8ca0a438616f1d34f3e7169889497dba49dba7f39051c1b-4bbaad75a04e3ac86fc61e546021db29fe0a47ba4834942379f914b5d0298e41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pavel Etingof")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641347")[#strong[#text("Pavel Etingof")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("The mathematics dept at MIT could accept a few Ukrainian/Russian mathematicians as visiting.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saraí Hernández-Torres")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641374")[#strong[#text("Saraí Hernández-Torres")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2022")])]

#text("Thank you for the list. I include two additional resources from Israel.")

#text("(Israel) The Technion opened a specific budget to host undergraduate and graduate students, post-docs, and faculty from Ukraine. The announcement is in their social media accounts. ")#link("https://twitter.com/TechnionLive/status/1500834929567047681")[#text("https://twitter.com/TechnionLive/status/1500834929567047681")]#text(".")

#text("Contact for students: Ms. Ortal Arazi Minyan (ortala@int.technion.ac.il), and for post-docs and faculty: Ms. Lisa Aisman (lisa@technion.ac.il). They are both from the Technion International Office.")

#text("—")

#text("(Israel) The Hebrew University of Jerusalem opened an emergency aid for researchers and students from Ukraine. The invitation is for a period of up to four months. More details here: ")#link("https://international.huji.ac.il/news/hebrew-university-emergency-aid-researchers-and-students-ukraine")[#text("https://international.huji.ac.il/news/hebrew-university-emergency-aid-researchers-and-students-ukraine")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641428")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2022")])]

#text("Hi Terry. Please note this initiative from the three Canadian granting agencies")

#link("https://science.gc.ca/eic/site/063.nsf/eng/98369.html")[#text("https://science.gc.ca/eic/site/063.nsf/eng/98369.html")]

#text("I’ll be personally happy to host graduate students in need.")

#emph[#text("[Added – thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ea9421c20c95a8f3f4077006a4238ca15955a26993086173710c7c2f94f3b0-f3e9d5996f6bf0cc30a9c7c068de2453e9a06dd214895fba9057a5309eb18263.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Gyllenberg")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641429")[#strong[#text("Mats Gyllenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2022")])]

#text("The Finnish Society of Sciences and Letters has a special grant program for Ukrainian researchers who want to carry out research in Finland, see")#linebreak()#text(" ")#link("https://scientiarum.fi/eng/1660-2/")[#text("https://scientiarum.fi/eng/1660-2/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65077676e3de1779742ee5f127a6a5a735e4228b4cbd78bd44c0c6fb40bf73bc-1c01bb7456ca0d8c5e31514ff255da14248569152002dc4b79c38d6a8d6eaee4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Delio Mugnolo")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641432")[#strong[#text("Delio Mugnolo")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2022")])]

#text("Thanks for this post.")

#text("The VW foundation offers a support scheme:")#linebreak()#text(" ")#link("https://www.volkswagenstiftung.de/en/funding/our-funding-portfolio-at-a-glance/funding-for-refugee-scholars-and-scientists-from-ukraine")[#text("https://www.volkswagenstiftung.de/en/funding/our-funding-portfolio-at-a-glance/funding-for-refugee-scholars-and-scientists-from-ukraine")]

#text("Applicants should submit a proposal together with a host at a German university. I’ll be happy to support applicants, if so wished by them.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55ee0320ab362efaf075de2d6acb79f0c8fc203c5617bc483ab3c5474f1188be-1d7b046957f4a3a1431ca84785b8ed4c1cc52ad5be78c08ee74975d3a7075d59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Ward")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641437")[#strong[#text("Tom Ward")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2022")])]

#text("Apologies if this has been mentioned, but there is also CARA: ")#link("https://www.cara.ngo/")[#text("https://www.cara.ngo/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641446")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2022")])]

#text("Spelling – Augusto Gerolin‘s research group at the University of [Ottawa]")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36355f0eea87194a6011ee392d91efa415c56e362f2875441485dbd5398cd3e7-89b8bd539bc097f745c78ab9180f70a7f2dae06b291cc659956f633e864fdf56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radek Adamczak")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641464")[#strong[#text("Radek Adamczak")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")])]

#text("Berlin Mathematics Research Center also provides support:")

#link("https://mathplus.de/news/math-support-for-mathematicians-from-ukraine/")[#text("https://mathplus.de/news/math-support-for-mathematicians-from-ukraine/")]

#text("Btw, in the list above the information about Poland is merged with the one about UCLA (should be a separate bullet)")

#emph[#text("[Added and corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641465")[#strong[#text("Resources for displaced mathematicians￼ | Blog.CarlRobitaille.org")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")]

#text("[…] Resources for displaced mathematicians […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04cb5cc46cbd11becbc6c85e76aaa98f21284f09ba67500a2c0d011f7fe723ec-4a18deec6b52fbdb9ab4aa4fa75365b66167d685d711c95260b9e89599a9b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Berndtsson")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641475")[#strong[#text("Bo Berndtsson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")])]

#text("“As an extraordinary measure, The Royal Swedish Academy of Sciences announces scholarships for Ukrainian scientists to perform research in Sweden”:")

#link("https://www.kva.se/en/utlysningar/stipendier-bidrag/for-ukrainska-forskare-att-verka-i-sverige")[#text("https://www.kva.se/en/utlysningar/stipendier-bidrag/for-ukrainska-forskare-att-verka-i-sverige")]

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sasha Fish")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641585")[#strong[#text("Sasha Fish")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")])]

#text("A new visitor program for displaced mathematicians from Ukraine at Sydney Mathematical Research Institute at the University of Sydney:")

#link("https://mathematical-research-institute.sydney.edu.au/ukrainian-visitor-program/")[#text("https://mathematical-research-institute.sydney.edu.au/ukrainian-visitor-program/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d93f195bf8b1788cd88c6f95e0f5a7be4af4561bd46364849584158a2f14d953-23825fdfea066ab38006b82508b425b9641116088065606eb4249ce205c14c62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bianca Santoro")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641762")[#strong[#text("Bianca Santoro")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("The German Mathematical Society (DMV) aims to support mathematicians from Ukraine at all stages in their career who might consider a visiting position, scholarship or other forms of scientific long-term stays in Germany. In cooperation with Mathematics Münster, applications from mathematicians from Ukraine and offers from German mathematical institutions will be coordinated via this website.")#linebreak()#text(" Please share this with everyone you may think could be interested: ")#link("http://Go.wwu.de/math-for-ukraine")[#text("http://Go.wwu.de/math-for-ukraine")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641778")[#strong[#text("戰爭中的 AI：烏克蘭用臉部辨識俄羅斯士兵，但這只是小兒科 – 頭條新聞")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")]

#text("[…] Resources for displaced mathematicians […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac451c7a488f810e199eeb5cb48ea1e7d8b1846c61036fbfa25769f90e7b6460-559b94149b50518bb879ac46400baa3196c709a6052a1cf62083c9f50a17a013.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maciej Dołęga")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641864")[#strong[#text("Maciej Dołęga")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2022")])]

#text("There is a new program of the Polish Academy of Sciences in cooperation with the American National Academy of Sciences addressed to Ukrainian researchers fleeing the war. Details are here – ")#link("https://institution.pan.pl/index.php/769-support-for-ukrainian-scholars")[#text("https://institution.pan.pl/index.php/769-support-for-ukrainian-scholars")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-641929")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("This might be useful: ")#link("https://www.youtube.com/watch?v=U-SYbiYD3xM&list=PLtN4y3-8OaDELy-z7yAdVdoVjtFpnaLZj&index=458&t=170s")[#text("https://www.youtube.com/watch?v=U-SYbiYD3xM&list=PLtN4y3-8OaDELy-z7yAdVdoVjtFpnaLZj&index=458&t=170s")]

#emph[#text("[Link added, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3779c15698554a4f495e5ba075b3dfabc4beca707c1c232db9d9c87cfcdb056a-45825f085af4c5d291b83874c04ccecab3f3b4def63490d0541f5de834aa24e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inna Entova")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642023")[#strong[#text("Inna Entova")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2022")])]

#text("Ben Gurion University in Beer Sheva, Israel, has a program for students and researchers affected by the war:")#linebreak()#text(" ")#link("https://in.bgu.ac.il/en/international/Pages/Financial-Aid.aspx")[#text("https://in.bgu.ac.il/en/international/Pages/Financial-Aid.aspx")]#text(".")#linebreak()#text(" Contact email: ")#link("mailto:oiaa@bgu.ac.il")[#text("oiaa@bgu.ac.il")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c643161dd9b74ca3399cb108d8561f4bf5fd11c466958966955206fa76ec8aa6-9640695d9c8fb5ab3718bab42a2f69c34a1e5515639c476044e2663003fd2e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G. Peccati")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642223")[#strong[#text("G. Peccati")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2022")])]

#text("Luxembourg University has now implemented a number of initiatives for researchers and students fleeing Ukraine. They are all listed on the following webpage: ")#link("https://wwwfr.uni.lu/ukraine")[#text("https://wwwfr.uni.lu/ukraine")]

#text("Similarly, Luxembourg’s National Research Fund (FNR) is now offering short-term positions for displaced researchers willing to join the research groups of existing grant holders: ")#link("https://www.fnr.lu/temporary-fnr-support-for-researchers-who-have-fled-the-war-in-ukraine/")[#text("https://www.fnr.lu/temporary-fnr-support-for-researchers-who-have-fled-the-war-in-ukraine/")]

#text("Some of the FNR ongoing grants pertain to the Department of Mathematics (the best way to obtain information about existing grants is to directly reach out to the Department of Mathematics: ")#link("https://wwwfr.uni.lu/recherche/fstm/dmath")[#text("https://wwwfr.uni.lu/recherche/fstm/dmath")]#text(")")

#emph[#text("[Added, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642259")[#strong[#text("Resources for displaced mathematicians - 2NYZ.com")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2022")]

#text("[…] resrcs for displaced mathematicians, terence tao’s collection of resrcs on his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a51e7e67b5e0e729e3293b338385182c836afbee5b564c3f9e949a186024d886-c322ece605e6e6ead1bdd549e61d7a1062480da094362223e583fca8d74cda9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dennis Keeler")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642535")[#strong[#text("Dennis Keeler")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("“New University in Exile Consortium programs are meant to instill a sense of belonging to an intellectual community and to decrease the sense of isolation and dislocation which exiled scholars suffer.” ")#link("https://newuniversityinexileconsortium.org/programs/programs/")[#text("https://newuniversityinexileconsortium.org/programs/programs/")]

#text("While these programs don’t connect scholars to jobs (as far as I can tell), they might help them adjust to new surroundings.")

#emph[#text("[Link added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642713")[#strong[#text("Наукова бібліотека ЧНУ імені Петра Могили інформує - Чорноморський національний університет імені Петра Могили - Чорноморський національ�")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2022")]

#text("[…] Можливості для науковців у галузі математики; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-642896")[#strong[#text("AMS :: Resources for displaced mathematicians – beasiswa")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2022")]

#text("[…] Resources for Displaced Mathematicians, Terence Tao’s collection of resources on his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc412a2f8e01dd1568dd495f66ecb06bd43b95d852512d0e148dd6b9e865076b-9aac3a0374264cd6cd447dd466c945a9b363608b4c08437ebbf33a53474169c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Oliveira Terra Cunha")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-643597")[#strong[#text("Marcelo de Oliveira Terra Cunha")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("This is another Brazilian initiative for academics from Mathematical Sciences displaced (or in serious danger) by any war (not only Ukraine).")

#text("The Institute of Mathematics, Statistics and Scientific Computing (IMECC) at the University of Campinas (Unicamp) invites researchers in the Mathematical Sciences from countries involved in the conflict in Ukraine and other war-affected countries to apply for the Researchers at Risk Initiative, by the Sao Paulo Research Foundation (Fapesp):")#linebreak()#text(" ")#link("https://fapesp.br/15402/initiative-researchers-at-risk")[#text("https://fapesp.br/15402/initiative-researchers-at-risk")]

#text("The scheme will cover scientific stays for 12+ months at any university in the state of Sao Paulo, as well as travel costs, under the following modalities:")#linebreak()#text(" — Visiting Researcher Award (PV), granted initially for up to 12 months, which may be reevaluated and extended at Fapesp’s discretion, under exceptional circumstances. Guidelines for the submission and selection of PV proposals are available at: ")#link("https://fapesp.br/index.php/en/visiting")[#text("https://fapesp.br/index.php/en/visiting")]#linebreak()#text(" — Post-Doctoral Fellowship lasting up to 24 months, which may be extended. Guidelines for the submission and selection of Post-Doctoral Fellowships are available at: ")#link("https://fapesp.br/en/postdoc")[#text("https://fapesp.br/en/postdoc")]#linebreak()#text(" Applications must be sponsored by a local supervisor/host researcher; links to our established research groups can be found here:")#linebreak()#text(" ")#link("https://www.ime.unicamp.br/en/research")[#text("https://www.ime.unicamp.br/en/research")]

#text("Tentative applicants may contact our Research Coordinator at IMECC, Professor Marcelo Terra Cunha, at ")#link("mailto:pqimecc@unicamp.br")[#text("pqimecc@unicamp.br")]#text(" for further information, as well as assistance in matching with our research groups.")

#text("Furthermore, if no immediate collaboration can be locally established, we may assist in sharing individual profiles among groups in other Sao Paulo universities.")

#text("The call is currently open and applications will be processed as they are received, for expedited implementation, until the scheme’s closure on August 30th, 2022.")

#text("This is an equal opportunity call, and IMECC particularly welcomes applications from women and underrepresented groups in the Mathematical Sciences, regardless of religion, marital/maternity status, or migratory situation.")

#text("Please forward this message to any relevant persons or forums.")#linebreak()#text(" Yours sincerely,")#linebreak()#text(" Prof. Marcelo Terra Cunha")#linebreak()#text(" Research Coordinator | IMECC-Unicamp")

#text("Thanks for organising the efforts, Terence!")

#emph[#text("[Link added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-643663")[#strong[#text("Інформаційний дайджест від Американських Рад з міжнародної освіти – Відділ аспірантури і докторантури")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2022")]

#text("[…] – Можливості для науковців у галузі математики: ")#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/?fbclid=IwAR2ftspBq&#8230")[#text("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/?fbclid=IwAR2ftspBq&#8230")]#text("; – Конкурс на актуальні програми імені Фулбрайта: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20a525936696eb411c849461e3d9cadb9376de681d47f43dc650e0e43720cd62-b0114fc690fa3b3605170d53a4104d2b03adc7ebae7bb520350f4426d4745d46.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria Emelianenko")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-644685")[#strong[#text("Maria Emelianenko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2022")])]

#text("George Mason University (DC metro area) has a 2-year visiting scholar position in Math available starting Fall 2022, specifically targeting Ukrainian and Russian mathematicians affected by the crisis. Please send inquiries to Maria Emelianenko at ")#link("mailto:memelian@gmu.edu")[#text("memelian@gmu.edu")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-671966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("One might want to add")#linebreak()#text(" (Germany) DFG – German Research Foundation – Special Programme for Ukraine:")#linebreak()#text(" ")#link("https://www.dfg.de/en/research_funding/announcements_proposals/2022/info_wissenschaft_22_65/index.html")[#text("https://www.dfg.de/en/research_funding/announcements_proposals/2022/info_wissenschaft_22_65/index.html")]

#emph[#text("[Added, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/02/resources-for-displaced-mathematicians/#comment-671967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("… or, more generally:")#linebreak()#text(" DFG – Refugee Researchers:")#linebreak()#text(" ")#link("https://www.dfg.de/en/research_funding/proposal_review_decision/refugee_researchers/index.html")[#text("https://www.dfg.de/en/research_funding/proposal_review_decision/refugee_researchers/index.html")]
]
