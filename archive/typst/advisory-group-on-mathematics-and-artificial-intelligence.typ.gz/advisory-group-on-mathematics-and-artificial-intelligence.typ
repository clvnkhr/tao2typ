// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/
// Converted to Typst by tao2typ: "2026-10-14T15:21:22.563353+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Announcing the Advisory Group on Mathematics and Artificial Intelligence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Announcing the Advisory Group on Mathematics and Artificial Intelligence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/")[#text("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://agmai.org/")[#text("Advisory Group on Mathematics and Artificial Intelligence")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("We would like to use this guest post to announce the creation of the ")#strong[#text("Advisory Group on Mathematics and Artificial Intelligence")]#text(" hosted at the Institute for Advanced Study (Princeton) and online at ")#link("https://agmai.org/")[#text("agmai.org")]#text(".")

#text("The rapid advances in artificial intelligence (AI) present both opportunities and challenges for mathematical research. We believe that we are at a historic moment for our discipline. Recent events raise urgent questions about how to support the long-term prospects for deep human understanding of mathematics.")

#metadata(none) <tao-f506e826229ff1bbe1eb>

#strong[#text("Purpose.")]#text(" The purpose of this group is to advise AI companies on their interactions with mathematical research and with the mathematical community, including the responsible presentation and release of mathematical results. We seek to work for the best interest of mathematics and the mathematical community, and to serve as one possible channel of communication between mathematicians and the AI industry.")

#strong[#text("Independence, Transparency, and Accountability.")]#text(" This group operates independently of any AI company and members do not accept payment for this work. We will publish our recommendations to AI companies on this website. We are willing to offer such recommendations to any AI company whose models are likely to have a significant impact on mathematics. Although we will give advice, we do not have decision making power at any AI company, and the responsibility for the decisions made by any company will rest with that company.")

#strong[#text("Advisory Group Members")]

#list(
[#text("François Charles (ENS-PSL)")],
[#text("Camillo De Lellis (IAS, GSSI)")],
[#text("Timothy Gowers (College de France, Cambridge)")],
[#text("Martin Hairer (EPFL, Imperial College London)")],
[#text("Nikhil Srivastava (Berkeley, Simons Institute)")],
[#text("Ulrike Tillmann (Oxford, INI)")],
[#text("Ravi Vakil (Stanford)")],
[#text("Edward Witten (IAS)")],
[#text("Melanie Matchett Wood (Harvard)")]
)

#text("This group came together after OpenAI approached some of its members about establishing an external advisory board. In agreement with OpenAI, they decided to create an independent group and invite others to join.")

#strong[#text("Current Task.")]#text(" We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model.")

#text("We welcome input from the mathematical community on this question. Please use ")#link("https://agmai.org/input")[#text("this form")]#text(" to share your thoughts with us as soon as possible")#strong[#text(".")]#text(" Your responses will be used to inform our recommendations and will not be made public without your approval.")

#heading(level: 1)[#text("Comments (155)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("It is clear from the comments that the level of anxiety, and in some cases sadness, in the community is very high. There are many suggestions that OpenAI should “stay away” from math research.")

#text("I just don’t see how this would make a difference. The likely reality is that these models will continue to improve in terms of ability and efficiency and in a short amount of time, undergraduate-level mathematicians with enough time will have the ability to solve previously famous open problems with the assistance of AI: at least those that are within reach of existing tools.")

#text("I don’t see how this can be stopped. It is like any other industry where advances in technology have changed what can be done and therefore what humans should spend time on. It is uncomfortable that it’s us this time, but there is no going back.")

#text("On the other hand, there is nothing (yet) that says that we can’t do mathematical research, with AI assistance, going forward. Even if AI has immense mathematical prowess, we still have to choose what problems *we* want solved, and what broader scientific and societal objectives we want to use mathematics to help with. It’s unbelievable that there aren’t new structures to discover and whole areas of mathematics that could be made clearer and more connected.")

#text("We will need to work differently, collaboratively, openly. We should try to figure out how to make this a fertile ground and a welcoming and exciting profession. We need to figure out how and what we should teach. It’s not easy at all.")

#text("I don’t think it’s an effective use of our time to try to stop what has already happened, or to try to hold on to our previous ways of conducting research and assigning credit. They were fantastic, and in some sense led us to where we are now, but they don’t seem to be appropriate from this point on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("You make a very good point. However, managing this unstoppable process is exactly why this group exists.")

#text("We should not see this group as a barrier trying to stop AI in math. Instead, we should look at it as an ")#strong[#text("ethics committee")]#text(" and a way to keep ")#strong[#text("human control")]#text(" over the process. The goal is not to stop technology or stay in the past. The goal is to make sure this powerful tool is used in a right, fair, and safe way for the math community.")

#text("You are right that there is no going back. That is exactly why we need this group to connect AI companies and mathematicians, and to guide the future in the right direction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("As the author of original comment, I completely agree that we need groups like this.")

#text("Nothing in what I wrote was a criticism of the group, which I am in favour of and thankful to the members of for creating. We will need other groups as well that hopefully can help us navigate the inevitable evolution of what mathematicians will do.")

#text("My comment was more related to some of the other comments and discussions suggesting that we can police how people use AI to solve mathematical problems or investigate mathematics generally.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("You’re realizing correctly it’s something that happened many times in history. Then you’re however for some reason assuming that we are in the case where the technology just changes the way we work, but doesn’t disrupt in the sense of a hierarchy collapse or job losses. But that looks very unrealistic to me. The machine is about to do everything we are doing better than us: asking questions, deciding what problems are important, doing proofs, writing articles and books, teaching, presenting etc. Everything except for… understanding. Hence, for the profession to survive in any reasonable sense you need to convince the market to pay you for “understanding” stuff. Here you clearly see that you are not in yet another technological revolution as usual, this would be something that never happened in that form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("There are aspects of this that are ordinary and aspects that are extraordinary.")

#text("Ordinary: technological change means some things should be done by computers rather than us, and we adjust our workflow / don’t give those tasks to humans.")

#text("Extraordinary: this is happening at a different level than many previous instances: mathematicians don’t have supervisors delegate tasks to them. We are not necessarily comfortable with no humans understanding the output of mathematical research or not being involved in the research in some form.")

#text("I expect large scale changes in how we do our jobs and what we produce. I am also worried that if we don’t adapt well, there could be job losses or changes to what we do imposed on us without us having an opportunity to respond creatively. We need to work on how to do something valuable. I think this is very possible, but it certainly won’t be by doing exactly what we used to do as if nothing has changed. I don’t believe we should have mathematical or scientific research without significant levels of human participation and direction. There are other posts which make this case quite well.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696121")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("They should at least publish a list of the problems they claim to have solved.")

#text("I also think they should publish the results on a special platform right away, where people can comment on them. If proper citation or attribution is missing it should be added.")

#text("But the results should be visible to the public even if they are slop. This would only make Open AIs reputation worse if they continue to publish low quality proofs. Therefore Open AI should try to make the proofs writeup as nice as possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I am a third-year PhD student in mathematics, and—as others have noted—everything feels very confusing right now. As has been emphasized, it feels as though I’ve lost about 14 years of my life: my undergraduate studies, my master’s, and now my PhD. I would like to take comfort in the idea that we will eventually adapt, but that doesn’t seem plausible; these technocrats aim to domesticate us in a sense, and they are doing so by putting their little machine to the test. They are devaluing over 3,000 years of the discipline’s history, seeking to divert funding away from what was valuable to us and toward things that are valuable only to them. We have to mobilize somehow; we cannot just sit idly by while they rub their hands together in glee.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("if you’re saying that you lost 14 years of your life, that could mean that there is a better alternative, something you wish you had done instead. I wonder what that would then be. The assumption that mathematics is somehow particularly affected is somewhat myopic I think. It’s just a low-hanging fruit for the AI industry , but it would be ridiculous to assume that the machine can prove millennium problems but not be intelligent enough to fully replace say bankers. It will just take a bit more time to beat professions that are messier.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c889fa4d49fa8cd6a14f4dfc98e0d33447e313a903ee7a747cd4da02fe518065-96e9deb838d21cc7c2ce28b0e9cf65071201b6d4d532eff2e212c9c6e264989f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tanvir Zawad")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696128")[#strong[#text("Tanvir Zawad")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("From bones and stones to slide rules, calculators, supercomputers, now AI. Embrace it and use it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Dear Terry,")

#text("In order to maximise the effectiveness of your initiative, I suggest that you find Advisory Panel members from non-western countries, and in particular from China.")

#text("The real-or-imaginary rivalry between US and Chinese AI firms (and their governments) is having a significant impact on how AI is being developed and this should be reflected on the panel.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696148")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("OpenAI(or any companies that produce math result) should make public repository for their results. Each of solved problem will have their own repository. Let mathematician comment or “pull request” or add citations or contribute on the repository so its basically “github” for mathematical papers. Each repo/solved problem will have project managers which can consist of chosen experts (voluntary/chosen by advisory committee) to review contribution given on the repo. *Caveats this become free new dataset for ai companies to train on. Sorry for bad english.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696149")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model.")
]

#text("This is a horrible outcome. If the advice is anything other than “release the results” then the tantrum thrown by the mathematical community over Navier Stokes has metastasized into some truly detrimental gatekeeping.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696189")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Not if the proofs are not fully certified with Lean. Again you attribute undeserved trust to OpenAI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("“As long as a branch of science offers an abundance of problems, so long it is alive; a lack of problems foreshadows extinction or the cessation of independent development”")

#text("David Hilbert, 1900")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("“As long as a branch of science offers an abundance of problems, so long it is alive; a lack of problems foreshadows extinction or the cessation of independent development”")

#text("David Hilbert , 1900")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Push to ensure ensure A.I. is a net positive and goes against Brandollini’s law.")

#enum(start: 1, 
[#text("Fully verified proofs with lean certificates. No human validation wasted until the result is proven")],
[#text("Full search prompts and conversations must be attached to the results.")],
[#text("Commitment to proof simplification. The A.I. proof should not just stop at the first result, it should make a big attempt to simplify it before release. Again with full log and prompts.")],
[#text("Provenance information. Every logic gap or thought jump or ideas by the A.I. should be attributed from where it got it from.")]
)

#text("Do not accept any A.I. result without those.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The main problem is that 4. is not technically possible with current LLMs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("You claim provenance is not possible. It is possible while reasoning traces are available, and can be made partially available even if the LLM providers insist on hiding the reasoning by technical means. Why do you claim it is not possible?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("this comes off as vanguardism, that serves to protect OpenAI and math researchers. If the core value of math is public access and knowledge then this committee feels like a contradiction.")

#text("Let the math speak for itself, are we returning to the time of hiding solutions for math duels?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I would say we need at least checking that the translation from LLM theorem to LEAN is correct. This cannot be reliably automated as of now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The modern academic structure appeared after the Industrial Revolution in Germany and then spread to France, to the US, and later to the UK.Before this, people didn’t need a PhD to do research.Newton, Lagrange, Fourier, and a lot of others did era-defining research long before the modern PhD even existed.I think, with the advent of AI, undergraduate students in a specific field will be able to do high-quality research in that domain.Now we are seeing AI being used extensively in mathematics because math problems are well-defined and their solutions can be verified in Lean.After some time, when humanoid robots become reliable and AI better understands the physical world, they will start to run experiments and solve important problems in the natural and social sciences as well.I can envision a future when AI is doing this by itself. Somebody will pay the AI, it will solve the required problems, and it will be less expensive than any scientist or team of scientists.As a second-year research master’s student who planned to do a PhD in pure math, these are pretty strange times for me.On the one hand, I’m happy these problems are being solved; on the other hand, I’m very sad because of the way they are being solved.I will probably give up on my plans to get a PhD and go into the AI industry because I don’t see any way math research can be a reliable profession in the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("that’s certainly a reasonable decision as current professors will also need to give up their jobs. On the other hand, it’s not easy to find an alternative, it’s far from obvious there will be more jobs for humans in the AI industry, a thing that can solve Navier-Stokes could certainly pretty soon beat any human in any AI development task.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("For each of the solved problems a human expert should take responsibility to write the proof in a human understandable way, complete with references to past relevant work, putting it in context of existing body of work. The human expert should be listed as the author of the paper. In the acknowledgment section the exact manner in which LLM was used should be disclosed, complete with entire sequence of prompts, course corrections etc provided by the human and the LLM response at each turn. Simply stating that ‘minimal human prompting was given’ is not sufficient. Exact sequence of prompts and LLM response should be disclosed. Let the mathematical community decide whether the prompts were significant. Also, the amount of tokens generated and computation power used along with its cost should be disclosed. The proof should be published in traditional media like arxiv. Finally, it should not be published until the authoring human expert understands the proof as if it were her/his own proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Here’s a somewhat corrected version of what I said in the form at ")#link("https://agmai.org")[#text("https://agmai.org")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The answer to this question is so important that it should be decided, not directly by just nine mathematicians, but in some more democratic way. You can design the structure for decision-making and perhaps keep the resulting organization from running off the rails, but the more the affected mathematicians have some say in what happens, the less unhappy they will be. There already exist democratically run organizations of mathematicians such as the AMS, LMS, and EMS that might help out here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The worst thing to have come out of the Navier Stokes drama is that people are now no longer publishing the results to mathematics conjectures. The complete destruction of any semblance of progress to mathematics. The era of open mathematics is over if AI companies, with the cheering support of top mathematicians, can just hide a hundred proofs of a hundred notable conjectures from the general public. Mathematics is returning to the dark ages where the theorems and proofs are trade secrets guarded by guilds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("AI performance in mathematics depends heavily on the immense availabille data (i.e., literature) created by humans. Mathematicians generally share there findings, through publications and preprints for example, with please as that benifits the mathematicians themselves and the whole scientific community. Now with AI being part of this equation, sharing findings can be detrimental to mathematicians in the long term. I think mathematicians should start to charge AI companies whenever such companies use human literature in AI training and whenever AI companies publish works that depend on such data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("AI performance heavily depends on the number of agents thrown at the problem. OpenAI created 10,000 agents to solve Navier-Stokes.")

#text("Now imagine if we had 10,000 human mathematicians whose sole focus was to solve Navier-Stokes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Are all AI proofs slop grenades or is it just Navier-Stokes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("The only method I see going forward is to set up nature reserves in our culture such as the arts, architecture, or literature, making it illegal to have an AI system engage with them, as is hunting wildlife illegal on certain grounds today. There are some rocks off the coast of France where it is illegal to set foot and the results are superb. It will be more problematic to argue for preserving pure maths because they are closer to applications, however the fields further removed from application can be protected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-2/#comment-696882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I think that the advisory committee whose membership and role, as detailed by Terence Tau, should consider the following:")

#text("The assumption by ai companies is that this advisory committee is acting as an ethical restraint on the ai companies and therefore that their claims of having solved various mathematical problems is both legitimate and valid. Personally, i believe this is pure propaganda by the ai companies with the aim of gaining competitive advantage in the aim of long term profits for these companies. There needs to be some quid pro quo. The quo is that the ai companies would like to be seen as making great strides in mathematics (for their own reasons). The quid is not in my opinion how these announcements should be made but rather under what conditions they should be made at all. I think this latter should be how the results should be vetted. Of course, as mathematicians, we dont have time to vet an ecponentially growing number of claims. So perhaps the vetting should be pre-vetted by the ai companies themselves and the aforementioned committee and mathematicians in general might have a role in vetting the pre vetting.")

#text("It seems to me that the current status quo between the advisory committee and the ai companies is very far off balance to the advantage of the ai companies. I would like to see this change.")

#text("Whilst sounding negative, i am very thankful that we such a committee to represent the interests of the mathematical community and dare i say, of mathematics itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model.")
]

#text("Will we be told at some point what the nature of these results is?")#linebreak()#text("Also how about them not using mathematics as a benchmark and so that this situation doesn’t arise in the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Recent models are so capable that testing them on research problems is the only meaningful way to measure their abilities. There is nothing wrong with that. No one owns mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696109")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I would push for an audit of the whole mathematical corpus (all articles etc ingested by the present AI) as soon as possible. Since there are of the order of 10^7 articles, compared with the progression of results announced, this might be possible in less than a year.")

#text("All these results exploit the existing corpus. With enough time and maybe several orders more attention, we humans would discover these results.")

#text("So instead of producing heaps of new proofs (but be welcome to do this IMO), make an audit, OpenAI or Anthropic or anybody who listens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696150")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Did you read the Fields Medal announcement? They make it abundantly clear they view themselves as owning mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It is very disheartening to see all the cynical comments here.")

#text("First of all, whether math is used as a benchmark or not, the situation will never change. Today there will be a 100 solved problems and next year a 1000. It doesn’t matter whether they are solved by OpenAI, Anthropic or a Chinese group. If you study the progress of chess engines, very soon even laptops will be able to solve Navier Stokes.")

#text("Second, it is up to academia to value human contributions in math like e.g. proof exposition. This has nothing to do with the frontier labs. If anything we should thank them for revealing our problems. As a scientist myself I believe academia has been broken for a while. We should use this chance to sit down at the table together with the frontier labs to work towards a better future.")

#text("We can reform academia and reward human work. It’s really up to us. And never forget that once the dust settles, AI will also come for the natural sciences, which will give us accelerated cures to thousands of diseases. Don’t fight the future, let’s embrace it instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("very soon even laptops will be able to solve Navier Stokes")
]

#text("A bit too optimistic")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Mac studios and gaming PCs run models that are only 6-12 months behind the frontier. By this date 2027…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The Navier Stokes result from OpenAI was not done on a single machine. The estimates I’ve seen put the total compute cost at around $20M. This is not a democratizing technology.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696054")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Don’t fight the future, let’s embrace it instead.")
]

#text("this will get downvoted but are you actually this naive??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Creating cures on a computer was not the bottleneck for the past 20 years. The problem is testing and approval.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Let AI spend money on combinatorial chemistry. AI is good at combinatorics and biotech is a fast and easy way to make money. /s")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It’s not “the future”, but “one future”, the one decided and created for us all by a bunch of techno oligarchs.")#linebreak()#text("We should **choose** what future we want to build…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Chess engines are a bad example. All the way from Deep Blue to 2010 they had Moore’s Law on their sides.")

#text("That is no longer the case. Stockfish, still undisputed leader mostly relies on pruned tree search and gets something like 80 additional ELO from NNUE. Leela isn’t stronger.")

#text("There is now way that local AI will be able to replicate the proofs. It is marketing to assuage fears that an oligopoly controls AI. Probably marketing sponsored by OpenAI, Anthropic and xAI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Chess engines are a bad example. The Deep Blue moment was PR, too. IBM likely used chess grandmasters to guide Deep Blue away from falling for a poisoned pawn, a strategy used to beat chess engines of that era. It is suspicious that they never released its logic. A grandmaster seeing a poisoned pawn would likely intervene. Would a tech company lie to you? I thought OpenAI was a nonprofit; what happened? Do you know of any other nonprofits, like colleges and universities, that might be interested in collaborating to provide an appropriately priced and ethical AI service? Where was the IP developed, and who was it stolen from?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696186")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Dunning Kruger effect in full display. Imagine being this confident over an underexplored field like AI")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b3dc0994dcd71cf808c59d082568cdb9bebc4d474bb51f5af75efff7294b7f8-9084dc80fe5efd328cf333e202e2f0c025799de1146d72ab8c850b096216c114.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695942")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("If I thought this was a good thing to do, this would be a great group of people to do it. But I have immediate misgivings. OpenAI has had some very bad publicity, and so they are trying to exploit the trust and respect that these mathematicians command. It is unrealistic to think that this group can change the way OpenAI does business; I don’t need to tell you all the objections that people have raised to that. Is it a good idea to help their crisis management?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695946")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("What’s the alternative and why would it be better in the long run?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Stand up. And fight. Compete with them. Try and get compute resources for yourself. Compete with their models. Raise capital. Whatever it takes! This tech is too important for a cabal of children to own.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32ef2758e4d90937522172f5870525f3f75e8e3f8f32c7282534c1a42abc6453-c45b953fe831d879029937f42d7fa559229430ef3e22ccc479011ff2b261dbb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Caselli")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695974")[#strong[#text("Michele Caselli")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("At this point, I think some cooperation is better than no cooperation. I understand your concern about this being used as crisis management, but let’s be realistic here. There is already a widespread perception (from the way this buisness is reported in the media) that “math is solved” and that mathematicians are pushing to slow down AI mathematics so as not to lose their privilege/job.")

#text("If we keep protecting our castle of glass and OpenAI publishes 100 open problems AI-solved tomorrow, without care for exposition or for the ideas being absorbed by the community as happened until now, I think the situation would become only worse. OpenAI does not need the mathematical community’s cooperation in order to publish results.")

#text("It’s time some mathematicians step in, as an independent entity, to give some real and tangible guidance on what to do. Of course there is a risk that OpenAI benefits reputationally from this interaction, and this is a price to pay I guess, but pushing against any form of contact won’t fix the castle. The castle already has visible cracks, and letting this unfold without any cooperation would destroy it for sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("@Michelle Caselli")

#text("your position assumes that mathematicians are on the back foot. In fact Burt is right that if we refuse to cooperate we can in fact delegitimise the whole enterprise of OpenAI to ‘solve mathematics’.")

#text("We have to be very careful, these guys are NOT our friends. They in fact explicitly aim to replace mathematicians. Why should we help them?")

#text("if a conjecture fell in a forest but no one saw it fall, did it fall?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32ef2758e4d90937522172f5870525f3f75e8e3f8f32c7282534c1a42abc6453-c45b953fe831d879029937f42d7fa559229430ef3e22ccc479011ff2b261dbb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Caselli")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696012")[#strong[#text("Michele Caselli")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I don’t think my position assumes that. My position is that the public/media narrative is that mathematicians are on the back foot, which is a different thing, and one that is not nearly as much under our control. In that sense, I think we are underestimating the price of inaction at this moment.")

#text("I am really not a fan of OpenAI and of the way they have used our field for their own gain. But the problem is already here, and simply doing nothing is not an answer.")

#text("There is that saying “If you are not at the table, you are on the menu.” Well, I think this is our chance to sit at the table. They have already eaten the first course, we may not get a second chance.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Mathematicians could make OpenAI the menu by pursuing the IP theft angle. But no one does that.")

#text("It is obvious that models are derivative works camouflaged as probability-driven token generators.")

#text("That is exactly the reason why Big AI does not want its own models distilled.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The best time for academia and research institutions to attack AI is when they are most financially vulnerable. Especially if/when OpenAI and Anthropic run out of money and look to be absorbed by a tech giant. The lawsuits will muddy the waters and raise questions about whether AI is theft, using IP saved in the memory of a Fourier transform that can undergo computation. That is likely after the midterms. Then run the models on academic infrastructure and charge textbook rates for access. Universities have many IP lawyers.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695988")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Well, the situation is simply that OpenAI has some results, and is saying to the mathematical community (represented by this group) “we have some results; make up your minds and tell us whether you want them or not”.")

#text("Responding to them does not “help” OpenAI; if mathematicians don’t want them to communicate their results, they are happy to sit on those results and keep doing what they’re doing internally. You say “")#emph[#text("It is unrealistic to think that this group can change the way OpenAI does business")]#text("” and it’s indeed unrealistic, but there’s no reason to even think that in the first place; OpenAI is explicit in their blog post that “")#emph[#text("Importantly, the group will not be responsible for advising us on how to pace our internal progress on mathematics")]#text("”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696016")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“we have some results; make up your minds and tell us whether you want them or not”.")
]

#text("Do you have evidence that this is what they told the mathematicians? if not then this is circumstantial at best and you make it sound way more altruistic and benevolent than it really is.")

#text("This relationship with OpenAI is not one sided. OpenAI (specifically their announcement on NS) would like to appear as if it is gifting these big theorems to humanity, when in truth in all it’s advertising it has taken advantage of mathematicians. Recall the Terrence Tao advertisement which were just snippets of an interview he gave advertised out of context. OpenAI at present very much relies on the mathematicians for legitimacy and publicity.")

#text("Don’t make things sound simpler than they actually are!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696027")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("This is my reading of ")#link("https://openai.com/index/advisory-group-on-mathematics-and-ai/")[#text("OpenAI’s announcement about this group")]#text(" (paying attention to what they say the group will advise on):")

#text("> ")#emph[#text("this model has now resolved more than 100 long-standing open problems across most areas of mathematics […] This has led to internal discussions on the best way to inform the community of the rapid progress […] The group will advise on the review and communication of emerging results: they will help OpenAI assess their significance, advise on how to coordinate their dissemination, and advise on academic and professional standards of mathematical research. It will also advise on how our tools can support mathematical research and learning. […] Importantly, the group will not be responsible for advising us on how to pace our internal progress on mathematics.")]

#text("So from the announcement they’re clear that:")

#list(
[#text("They’re going to continue working on mathematics, for their own ends (their models’ development and evaluation),")],
[#text("They’re taking input from this group only on whether and how to communicate their results.")]
)

#text("I don’t think I make it sound altruistic and benevolent; in fact I don’t think there’s anything altruistic and benevolent at all. They care primarily about their models, and impact on mathematics is secondary, let alone impact on mathematicians. They’re simply offloading to this group the responsibility of communicating their results to the mathematics community. But any response (including no response) from this group will not (much) affect what they do internally.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("don’t you actually realise that all of this is marketing? Every phrase OpenAI tells you is a means to an end. They are not your friends")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("To the point and correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("OpenAI is not in crisis (at least when it comes to math and AI), it is academic mathematicians that are in crisis. OpenAI is thrilled with the narrative their models are obliterating the toughest math problems- as it benefits their IPO and efforts for regulatory capture. I do admit OpenAI will use (a cynic might even say perhaps twist) the work of these mathematicians to support their business objectives.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("They may be out of cash in 6 months. I don’t feel comfortable unless I have a year of savings as a buffer against job loss. In the mean time I am moving from stocks to bonds.")

#link("https://finance.yahoo.com/technology/ai/articles/openai-could-run-cash-mid-162002921.html")[#text("https://finance.yahoo.com/technology/ai/articles/openai-could-run-cash-mid-162002921.html")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/708f345bc6d51e898e4aa16e6e43662b24f655d9330fe6e6f9ef8a5cc7315c14-fa922847523d82ee3797f940b69a808a01d8a378b6a14bc3b05f336404b74d20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DH")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695944")[#strong[#text("DH")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("“This group of foxes has invited us to assist them in eating all the chickens as smoothly as possible. We invite suggestions from chickens on how best they can be eaten.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("very well said DH")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("doesnt change the reality that the foxes are going to eat the chicken")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("oh come on you’ve watched more movies than that miracles happen everyone loves a good underdog story")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Hello!")

#text("I am a second year PhD student in pure mathematics, and the phrase")

#text("“…a large number of significant results in mathematics that they report have been produced by their internal model.”")

#text("really disheartens me. Especially without saying how many results and what results. I understand that such advancement are important for mathematics, but my little human brain can’t help but interpret that my time spent on my PhD is going to be a waste of time. Spending 4 years on something that an agent swarm could prove in 1 day, or less.")

#text("Forgive my pessimism. I’ve seen a lot of mathematicians talking about the current situation with varying degrees of enthusiasm, ranging from complete rejection of LLMs to unquestionable assimilation in the community.")

#text("I believe there’s a lot to be gained by computer assisted maths, but personally, I’m not sure this would be a profession in which I would like to take part in. Vibe-prompting LLMs for answers. But, for better or for worse, future does not follow a set list of rules. I guess only time will tell how things evolve…")

#text("I might be giving the impression of a shallow person, and I might as well be one, but the current state of affairs feels overwhelming to me.")

#text("I believe this is a reasonable reaction for my career stage, and of course part of human nature. But human nature can easily be decieved. To my mind comes the following paraphrase from Thucydides:")

#text("“People always think the greatest war is the one they are fighting at the moment, and when that is over they are more impressed with wars of antiquity”")

#text("Maybe everything will turn out to be alright and we’re just in the middle of a proverbial panic attack. But wishful thinking is not enough. Action needs to be taken to preserve what is worth preserving in the community and to amend what can not withstand the future.")

#text("Apologies for the long post, and for me “thinking out loud”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("My gut feeling is that combinatorics problems will remain much harder to solve, especially novel problems with no training data. Doing a proof in LEAN will still require human intervention. Extremely long proofs will compound errors and need additional fact-checking, but that doesn’t sound like a fun career.")

#text("Programmers used to rely on Stack Overflow; copying an LLM instead of Stack Overflow can save time and speed up code reviews, libraries let us import functions into programs, and those did not reduce demand for programmers.")

#text("Language translators were the first casualty, and if programmers haven’t been replaced, I doubt mathematicians will be. In fact, the news may push students into other fields and eventually create a shortage in CS and math.")

#text("The challenge is verifying that this approach can solve previously unsolved problems. Then there will be a race to solve all the open problems this new technology can solve until the next bottleneck becomes apparent. Initially, I suspected it was good at analysis and linear algebra because its core computations involve both. I thought nonlinear problems like Navier-Stokes, perturbations, and combinatorics were beyond its ability.")

#text("Navier-Stokes is heavy on analysis, but it is also nonlinear. AI often fails when it needs new insight and mistakes language patterns for physical reality. We should focus more on the problems it spectacularly fails to solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Every PhD student is thinking exactly like you. IMO there is no future for mathematicians as long as this technology is around. People get into mathematicians because they enjoy solving beautiful problems, not because they like reading and interpreting slop spit out by a machine. The true danger to mathematics is not that AI will take our jobs (because it cannot by definition “solve” mathematics, which is an inherently human activity) but rather that no one will want to do it, because there is nothing appealing about reading results spit out by a next-bit predictor. They have taken something valuable from us and we should treat these companies like what they are—enemies of mathematics and humanity at large. There is no negotiating or bargaining with them. How unfortunate to see mathematicians assisting in automating themselves away under the guise of solving beautiful problems…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Tis the Golem")

#link("https://sseh.uchicago.edu/doc/von_Neumann_1955.pdf")[#text("Alchemy Automation and Fusion")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/915fb74ef62c0b31f4d8a9111379225b6af4fc56d33ac96dfee3786f43f21715-1ef1bd6c0c407a24edf1bcb5c0b7bbdae51ec27eee91fa6d0a5394d78efa9803.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of felixleditzky")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696005")[#strong[#text("felixleditzky")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I do not find your post shallow in any way whatsoever, and you’re voicing some very valid and real concerns that I have heard from my graduate students as well. I am really sorry for the negative impact these recent developments have had on you and other students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696040")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Thanks for your open thoughts. Did you ever try a model like ChatGPT 5.6 or Astra 6.0 at your research questions? If not, you should do immediately. It will give you a feeling of flying. After a few hours you will have intermediate results which will help you to formulate many more advanced questions.")

#text("I was bon in 1961, and was professor of applied mathematics from 1994 to 2023. In the last 12 months I have – with the help of AI – achieved more beautiful results than in the 43 years before together.")

#text("I am also active in the field of chess with computer help since 1979. The changes and challenges, Mathematics sees now, happened for the Chess scene in the 1990’s. And it raised human chess levels to completely new heights. 20 years ago, former World Champion Vishy Anand put it in these words: What we see in chess now, happened similarly in Astronomy. It is no longer as romantic as it had been, but use of the conputer-aided techniques gave a real boost in insights and progress.")

#text("Back to my first point: give AI a try in your research questions. Wishing you all the best, Ingo Althöfer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Heroin also feels incredible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("One thing the advisory board could help set up is a registry for all current PhD students on the problem they have spend years working on, and if there’s a result close enough to it, you get to have an early peak and possibly make a joint paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eb42faa377991560d1b6f479078ca924d91714f528bded61a76a22832b0d139-c21c86f260fb3ea1e4ff9a8e2ca6887e35c3814d2138682aadddc2e60d59d012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of АД")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696147")[#strong[#text("АД")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I’m in the same boat as you and often feel a similar despair. It is important to remember that it is the ")#emph[#text("goal")]#text(" of the AI companies to make us feel this way. The vision that these companies are selling their investors is of a world where a small number of elite managers preside over an army of LLM workers, and the rank and file employees have been automated away.")

#text("Mathematics is the testing ground for this vision, and the AI companies will use whatever methods they see fit to automate away the rank and file (which includes PhD students). I see this committee as yet another step in realizing this goal—a group of elite mathematicians presiding over the fantastical output of a mysterious internal model. There is much talk about how mathematics is merely “PR” for these AI companies, but I have seen very little talk about what exact message they are trying to send.")

#text("Maybe LLMs can one shot your thesis problem. Maybe they will one shot every Millennium prize problem. That does not mean that what you are doing is useless. The goal of a PhD is to develop your own understanding of a mathematical field, and your ability to think deeply about things. You can still do this in the age of LLMs. The AI companies would prefer that we all forget this so that they can achieve their goal of destroying our field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#link("https://isaiprofitable.com")[#text("https://isaiprofitable.com")]

#text("If we exclude NVIDIA, which is selling pickaxes to gold miners, then AI is catastrophically unprofitable. Now they are pushing for agents that can execute code autonomously like malware, or maybe it is the harness of the AI where the real problems are solved? Great, that means fewer tokens and even less revenue. Maybe it was robots? I expect them to take the money and run before it comes crashing down.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I am personally having hard time to cope, to be honest. I feel like there is this daily, relentless, barrage of bad news that feeds my neurotic state.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I am extremely wary of AI companies in general and in a gloomy mood as respects the future of the field. I am a nobody working as an electrician in a third world country who could not afford to go to collegue so I study mathematics in my spare time, alone and autonomously. Those are my credentials (somehow worthless, eh).")

#text("Anyhow, if this post and initiative are serious, I would advise the group to demand first and foremost a clear statement of the kind of human intervention used in any and all problems (as regards prompting, guidance, false start cleanups, etc) and the resources used (electricity, compute, cooling media, internet access, etc).")

#text("Finally, ask politely but strongly that they leave mathematics alone for the time being, since the way in which they are abusing the field to foster their reputation is absolutely disgusting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Some people reading this may be inspired to assist you in your math studies. Do you have a contact?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I also chose this guy’s, Ramanujan. Unfortunately, we spent 2.7 trillion on AI research instead of training more mathematicians. An electrician is a trade that is hard to automate; you’re so lucky! Do you have any openings for apprenticeships?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("OpenAI wants to use the math problem-solving capability of their AI model for PR purposes, since they see it as a way to boost their upcoming IPO. Do you want to help them with this PR?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("What kind of equity do I get?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("This is surely just a Trojan horse?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I thought we finally agreed that OpenAI’s interest (and in general all AI companies) and the Maths community’s interest were somehow orthogonal, but here we go again.")

#text("Not surprised if next month we read a headline like “9 top mathematicians say OpenAI is the best ….”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695952")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("“We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model.”")

#text("I would look at the LEAN certificate to make sure it is valid. Check the premise because garbage in garbage out ,and make sure it is a unique discovery and not based on someone’s unpublished work. I would say peer review it but nobody is going to check a 200 page proof by hand. Ed Witten is on the board. Was it the Yang-Mills mass gap?")

#text("I’ll be at the bar if anyone wants to join me.")

#link("https://makeagif.com/gif/the-thing-chess-JjtwMv")[#text("https://makeagif.com/gif/the-thing-chess-JjtwMv")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#link("https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf")[#text("https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf")]

#text("My summary of that is “come up with super-ultra-hyper-mega-meta Donaldson-Floer theory on steroids and describe the geometry of fermions which is probably figuring out how to make a realistic kaluza klein theory”")

#text("The literature on gauge theory these days gets into the weeds of the langlands program and number theory,")

#text("My view on the YM clay problem is it’s probably not happening in the 21st century and may be too ill defined to even be ever really decided at all, and I’m pretty sure that’s a cold take. So if an agentic swarm already has solved that somehow… Sam Altman and Musk and world emperors then I guess")

#text("Indeed I think we’re already at the means of production conversation regardless of where you fall on the AGI is here or the greatest plagarizing snakeoil conmen ever spectrum we’re sharing bad trip nightmare thoughts about creativity generally I’m glad people seem to collectively recognize there’s far more to this then the narrow scope of “here’s a hundred advanced math problems solved”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Could you invite to the conversation people working in the ")#strong[#text("humanities")]#text("? Mathematics may discover new truths, but it is also the job of the humanities to ask what those truths mean for human beings. Mathematicians rarely know how to think about how mathematicians’ minds work. We need people thinking deeply about the nature of the human mind, in collaboration with other minds — we need people who know about the history of the work and the practice. We need philosophy (you already had philosophers on your blog like Duede), cognitive science (Simon DeDeo and Rob Goldstone?), and sociology more than ever now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I think it’s good that these results will be made public. I want them to disclose a couple of things: what problems did they try? What was the methodology towards obtaining these results? What was the chain of thought behind these results?")

#text("Regarding the best way to make public, I think they should contact experts at the specific problems they solved and give them time to write up something or delegate that task to their students/postdocs. I think in the future this company should stay away from the frontlines of research mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Strongly agree with the suggestion of also disclosing the problems that were tried, the methodology, and the chain of thought.")

#text("About the write-up, there is not really a great option given current institutions but I don’t like the idea that OpenAI (or any committee) is in charge of picking winners and losers in this circumstance. It would be better to put solutions in a fixed public repository (not arxiv) and allow anyone who wants to extract a proper exposition or additional insights to do so. Maybe there could be a way to indicate that someone is engaged in this so others can coordinate, but I could see that entailing drawbacks as well.")

#text("While I agree it is better that these results just be made public, and I have high regard for the group members in this post, I also share the skepticism that many comments have expressed about this coordination. There is a long history of people with goodwill coordinating with those at the top of OpenAI, only to find themselves manipulated a short time later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Maybe there could be a way to indicate that someone is engaged in this")
]

#text("Watch this space…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695995")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I really don’t like this idea. Would the experts/students/postdocs have to keep secret what results they are writing up? How would these people be chosen? Would they be allowed to pursue further related directions whilst doing it? Now these results have been proven and are known to some people, I don’t see much alternative to releasing them as soon as possible to the mathematical community, which then needs to agree ethical ways to proceed. Personally the model I favour (and the easiest to police) is that whoever wants to work on expositing/developing a given result should be free to do so with essentially no notion of `priority’ and no need to rush, and with strong ethical standards (if influenced by another party’s exposition, say so). Ideally people would be quite open about which projects they were working on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I’m sure that’s a pleasant idea, but if I can ask someone at OpenAI to solve a problem for me I won’t work on the problem and I’m sure this is true of many others. (If that means all of mathematics, then yes it’s time to do something else.) The result dump is going to lead to field abandonment. The most productive thing they can do for the community is fire Sebastian Bubeck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Author of the post you responded to. That’s fair enough. I did not have this credit assignment dilemma in mind when I wrote that, and it was written in response to the unpleasant feelings a lot of us had when seeing AI slop proving big theorems.")

#text("One potential downside I see to releasing the slop straight away is that it might scoop existing work that the authors might want to wrap up. (An alternative suggestion to yours is to release which problems they did resolve a few days prior to releasing the whole thing.) Though it is perhaps unwise to keep on embracing our old credit system and perhaps we should just move on as quickly as possible…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696140")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Every course of action in response to this situation has enormous downsides. Releasing the problem statements a few days before the proofs just creates stressful situations for people and the incentive for hasty writing. While we transition to whatever the replacement for our current credit system is, I suppose we are going to have to rely on a certain amount of honesty on the part of mathematicians and people writing on their behalf.")

#text("It seems to me that a lot of work going forward will be more akin to writing research monographs and books than papers in journals. People seem to be less competitive about that even now.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696145")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("What if someone produced excellent results in the form of AI slop, how do we cite or give credit to these people in the future? Especially when it is clear from the paper that they did not digest or understand it, and when AI-use acknowledgements are very shy and generic, trying to leave as much credit as possible to the author. Do we cite the person who produces a high-quality version of the results? Or do we just swallow our disgust and cite the original AI slop?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The human mathematicians working 80-hour weeks at OpenAI just said Please solve; make no mistakes; you got this! The AI did it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696159")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Are there any game theorists here? Do we wait until AI spends itself into bankruptcy and sue them for copyright theft and divide the spoils? Is this a Nash equilibrium?")

#text("I believe a mathematics hive mind > AI slop. Maybe that means more than four mathematicians are now needed for a good collaboration.")

#link("https://en.wikipedia.org/wiki/Stag_hunt")[#text("https://en.wikipedia.org/wiki/Stag_hunt")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("They should publish immediately, honestly asserting they don’t understand the solution, with a plan to follow up.")

#text("That’s literally it and the fairest way for this to happen.")

#text("Another expert in the field could possible do better with your finding than you do.")

#text("This all sounds like a child like “dibs” situation.")

#text("Honestly, even scientists and mathematicians of the past, if they sat on substantial results, waiting for a really big result, were doing less for the community than they could have been")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Open AI is a big company, and the primary goal of the task force should be to get some guarantee that their recommendation will be seriously considered by someone with actual decision making power. Open AI has already hired many mathematicians, including a fresh Fields medalist, and were perfectly OK with crossing every boundary imaginable when Navier-Stokes was in sight.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695980")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Of course OpenAI is only doing this because they think it’s to their own long-term benefit, but I trust these folks way more than I trust a bunch of Caltech undergrads to not get jerked around.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model")
]

#text("Do you mean that you face the challenge to ensure that, this time, they will get a smooth advertisement?")#linebreak()#text("If they want to contribute to math, they just have to hire hundreds of mathematicians to digest their slope. We are not their slaves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It’s unclear if withholding discoveries is the path forward here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Let’s be clear this is the framing OpenAI has choosen, and they in very typical fashion selected a small group of hyper elites to speak for us and gave the narrow question to speak to. In an age when all forums for freedom of speech are under attack I highly encourage the community to consider deeper philosophical questions than simply how will I personally earn my own bread")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("To the contrary of what this group intends to do, I call for a boycott of any affiliations with Open AI. Their behavior (extending beyond math) has been reckless and irresponsible. I do not see the point in giving them any legitimacy, unless they are completely transparent with their process (the word “open” in open ai feels more ironic as time passes by), apologize for their transgressions, and have an independent audit into their workings as a company.")

#text("As long as they have the leverage, this independent committee will have no use, I do not see the point of this. Don’t we already have a community of mathematicians who can organize conferences where we can discuss this openly? What exactly is this achieving? If Open AI wants to play ball, then they should come discuss things on our turf.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("How is one supposed to digest this as a plebeian?")

#text("I never had the chance to go and study, but I hoped that my children would have that chance. Now it seems like they might grow up in a world where those dreams are well and truly dead.")

#text("Are we seriously throwing in our lot with a bunch of people who don’t even see the rest of us as people? Who gladly declare the best and brightest of the species “obsolete”?")

#text("I have never been so disgusted in my life.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("If you give advise on how to interact with the mathematical community, should the mathematical community not legitimize these recommendations? I disagree that an input form is enough for this.")

#text("I also would like to point out that this is ")#emph[#text("made")]#text(" an urgent matter by choice. Maybe it is worth thinking about why this choice was made and who is benefitting from rushed recommendations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("If AI companies want to release a mathematical result they should merely obey the norms of the community: write the result up for publication, submit to a journal and give presentations at conferences. Why do we need a committee to belabor the obvious?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I feel like in an ideal world this would entail some reputational consequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("At this point I fear we are facing the end of human mathematical culture. As OpenAI releases these results (and future results, of which there will undoubtedly be many), they should donate vast sums of no-strings-attached money to historians and anthropologists for studying and recording the final years of a beautiful period of our history.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696043")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Opposite view: Beautiful years with many new beautiful insights in Mathematics are going to come.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Given the enthusiasm of some members of this unelected advisory board, I feel that the outcome has already been written.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-695994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I am personally ok with the existence of the group, as long as it is only for this batch of results. Afterwards, OpenAi should not take part in math research (maybe with the exception of the community asking after some democratic decision)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86cf8e242b153b318c02a7df981adc73582a9e2f8838908175acf8a2d9ce5c7c-2a59886790e32ce207c27edac5980b6f0076723881ea8f693648cd84dd41474f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696001")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It seems important to understand the capabilities of this model. With this in mind, put the results on public, easily searchable repository that is independent of the arxiv now. Give a way query the authors (human or ai) about each of the individual results/papers to answer followup questions. Update the results with more readable versions if and when they become available (as this is also a test of capabilities). This should help us understand the state of the models, how fast things are progressing, and to what extent they are producing arguments that resist being put in a human interpretable form (this would be a red flag).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I find this initiative troubling for a reason that is somewhat different from the concerns that have dominated the discussion so far. If OpenAI really has accumulated a large number of significant mathematical results that have not yet been released, then the question is no longer only how the community should verify, digest, or explain AI-generated mathematics. There is now a prior question: who gets to decide when, how, and in what order the mathematical community is allowed to see those results?")

#text("Whatever the intentions of the members of this advisory group, the structure is strikingly oligarchic: a private company controls the systems producing the mathematics, while a very small group of extraordinarily eminent mathematicians advises it on the release of knowledge that may already bear directly on the work of many researchers elsewhere. A mathematician could be spending months or years on a problem that has already been solved inside the company, while having no way even to know that this is the case.")

#text("Now, traditional mathematics has always had gatekeepers: editors, referees, hiring committees, prize committees. But, in principle, they controlled prestige and certification, not access to the underlying knowledge. An author rejected by a journal could still put a paper on the arXiv the next morning. What seems to be emerging here is qualitatively different: the producer of the mathematical result, the computational infrastructure, and the decision about whether the result is made public are all concentrated in the same private organization.")

#text("If abundance is really the new problem, I would much rather see the community move toward a principle of **access first, curation afterwards**: public deposition of results, provenance information, formalizations where available, and then open evaluation, explanation, criticism, and prioritization by the broader community. Otherwise we may solve the problem of AI-generated mathematical abundance by creating something even less attractive: a small college of unelected mathematical cardinals deciding when the rest of us may see the mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("“access first, curation afterwards” – this has issued as well, which Terence has talked about a lot (see e.g. ")#link("https://mathstodon.xyz/@tao/116551624228986501")[#text("https://mathstodon.xyz/@tao/116551624228986501")]#text("). Posting a flood of unpolished proofs results in a rush to the finishline which could leave a lot of important work undigested. For good reason, it’s not standard in any research field to post unfinished results immediately after they are found. Researchers are expected to take the time to write clear, understandable papers.")

#text("I agree that this is a delicate situation, to put it mildly, but hopefully the advisory board will have good ideas for how to balance all of these concerns.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696010")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("This is concerning. Members of this team, e.g. Timothy Gowers, have already expressed sentiment that the field is fated to be taken over by AI and the sooner we submit to AI companies the better (you can read his post here from a few days ago). These are people that are favorable to the aims of OpenAI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("“AI” like any other technology or tool, will be used for good and ill and there really isn’t any means or reason to control its (mis)use. Sorry that math, language-heavy and formal, was the second most amenable area to infiltration (after programming), but that’s just the way it is; get used to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I think its a good initiative, if it makes recommendations that are good for mathematics (in the light that AI exists and these companies produced various results that they gonna dump somewhere anyways).")

#text("The group can express the high standards of transparency needed and the associated academic responsibilities of the company (or employees thereof) and urge them to make some serious efforts and to allocate a lot of precious resources to this.")

#text("If the board makes some more or less sound suggestions of how the company could deal with this in a way that benefits math significantly more than what they did before, then the ball lies in the yard of the company to deliver far more than just some generated output.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/203c8dca3e9a34fcc2fedd19d9a0b5ea61aefe722c9a4eacf6eadf9cc77b0000-1bed95d342e1877f384f48bec5d9aba195e1ae8adfe019dacbee8ccf707ba200.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rebeltechnicallya0e7b72ad5")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696018")[#strong[#text("rebeltechnicallya0e7b72ad5")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Unfortunately, as hopeful as I want to be, it feels somewhat useless expecting any form of slowdown. ")#linebreak()#text("I fully expect these companies to release a Critical amount of very important results to drive home the point of how powerful their models are.")

#text("Perhaps the earlier we accept it, the quicker we can converge on the best possible solutions to salvage what is left of a field-changing event.")

#text("It would be very heartbreaking if after expecting a slow down, things ramp up much more quickly and we are caught without any concrete steps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I support this. The reason we were paid to do mathematics research was that progress and mathematical training benefits science and so society in general. Faster progress is to everyone’s benefit. Let’s see if we can improve the exposition coming out of the frontier labs and fit the results better into the mathematical literature. Quality of exposition, transparency and wider access should be the community’s goals.")

#text("The mathematical community has always been mainly funded by money coming from education; let’s try to figure out how to refashion universities to adapt to the new tools; what benefits the students? Mathematical skill is always going to be important.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Faster progress and mathematical training are opposed. It has been seen (and is plainly obvious!) that students who use AI tools in their studies perform worse on assessments of that understanding. These studies are short-term; in the long term we are going to create a generation of dullards.")

#text("Admittedly, this seems to be a priority of our society and we were already working on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d381b96c2b748abffa4dd89893a80e96d59d6c72c096b8b52a9466f7e232eb63-89b1a0735d2d100e0feb22c9746a3b8bcef17acff6f712d01ed1ecc39d7619de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of billjr")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696117")[#strong[#text("billjr")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("We have to adapt the educational system to the new situation. “What’s best for the students” includes solving problems without technology, and writing without technology. We have to adapt to the fact that we can’t assign problem sets or essays any more, and have any confidence that they haven’t used AI. Probably we need more class time, without technology allowed. And they need to learn to use AI tools, as well. No employer is going to want students who don’t have experience with them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I’m not a mathematician but may be a view from outside will be useful.")

#text("IMO, this group makes sense, and should have been created even without OpenAI input. As the text says, it’s indeed a historical moment where the meaning of the profession changes and the group should play a role in driving the broader math community towards finding what it will be including the role of AI and commercial entities behind it (OpenAI is a tip of the iceberg).")

#text("Some things to consider (IMO):")#linebreak()#text("– not having such a group is not the null-hypothesis, refusal will be used against math community;")#linebreak()#text("– commercial entities will use math for PR, testing, etc… You cannot stop this, the public doesn’t care at best;")#linebreak()#text("– this is not the end of math, but math (like many / most other fields) will change;")#linebreak()#text("– nobody knows answers at this stage, building a constructive and effective communication within community is a key;")#linebreak()#text("– math, as it is, is driven by objective truth, commercial entities — by profits. An ideal solution will take this into account.")

#text("Good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Witten suddenlys being part of this conversation surprises me. He played a big role in popularizing uploading preprints to arxiv which has done a lot to make research level mathematics so accessible, an ethos our community does not share with many others but that transparency is truly a boon to society at large.")

#text("We should assume OpenAI is lying cheating and stealing until they prove beyond a doubt otherwise for every single result, in which case surely they deserve some effort to be presentable in a journal/arxiv.")

#text("It’s obvious these companies should have gone about this in the professional way to begin with. Antics like Levant Apolge’s certainly seemed like a calculated attack against the academy, surely these companies don’t need Fields Medalist to explain to them what the expectations for students and academic publishing are? I’d also agree with many the ivory tower should humble itself here as well and knocking it down a peg a bit welcome in a strange way.")

#text("But surely I don’t need to lecture Ed Witten about this!? It was probably better to stay quiet about this all and just observe, but nevertheless I’m sure his thoughts about this are juicy. I don’t think there’s any right / good answer here but decisive actions are going to have to be taken swiftly, and the consequences we’ll all have to deal with when they arrise like it or not.")

#text("If science is not art we will create Frankenstein’s, ")#link("https://www.youtube.com/watch?v=Pl1jiFgot5o")[#text("I cannot hide enough my distain for these companies and their dark intentions for humankind which we all know we are are already witnessing play out ")]

#link("https://web.archive.org/web/20210604173004/https://twitter.com/witten271/status/1400865690387681281")[#text("We can no longer avoid politics like it or not")]

#text("Glad it’s not me getting put on the spot to be a diplomat right now 😅")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696059")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I think it is a catch-22. They will submit proofs by intimidation that humans cannot possibly verify, or they will say the mathematics community cannot handle the output of their new model. Either way, it is a PR win for them. I think it is unlikely they have proven 100 problems like NS. That would be hundreds of millions wasted on fallacious proofs. They should publish what they have because the more they post, the more likely someone will spot a mistake.")

#text("However, if they have a proof of the Goldbach, twin prime, or Riemann hypothesis, they should publish it. We know they have no moat, and their interest in regulation is to stifle competition and kneecap open source models.")

#text("I am waiting to see statistical significance in a transparent and verifiable manner. Ideally, we should have 1500 proofs. I expect a marketing trick no matter what.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("The ai companies are actively trying to destroy mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696051")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I’m a late stage math phd student right now. I agree with these sentiments.")

#text("I’d like to add this:")#linebreak()#text("Even if one would like to continue doing mathematics and reading LLM output, even if doing math that could be done by a few AI agents doesn’t feel like a waste of time, I don’t see why anyone would hire someone like me (for what its worth, I’m at a strong but not mega elite department, I’m not a standout student but I’d like to think I do a decent job) when they could pay a few bucks to OpenAI or Anthropic and produce the same research output? Honestly, if one spent my entire 25k ish salary on tokens, you could probably get more results compared to paying me the 25k. After all, I have to pay rent, eat, etc. and my impression is that the models are already better at doing my research than I am.")

#text("Sure math isn’t “solved” by AI in some grand or esoteric way, but I don’t see why that implies that people like me will still get paid to do it as a profession.")

#text("If someone has a reason why they think that my job will not be eliminated, I’d love to know about it.")

#text("(This is meant to go next to Felix Leditsky’s post and respond to that thread, but for some reason the message won’t post there)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("A lot has been written on this blog about how to keep people like you involved in mathematics, even if the job will likely change immensely. For one thing, someone has to understand all of these AI-generated results for them to have any value (what’s the point of a proof of the Reimann hypothesis if no one can follow it). For another, someone had to prompt the language models to do mathematics in the first place. Academia will need to adapt, but hopefully it will create new opportunities for people who want to keep learning and doing math (and if you are able to do even better math with the help of AI, then that is probably a good position to be in right now).")

#text("Best of luck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696074")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("My advice is to lean towards combinatorics and nonlinear dynamics. AI struggles with it, as do most people. Also, please remember that a hyper-competitive culture, a lack of mentorship, and student loans make your 20s by far the most stressful period of life. The data backs it up.")

#text("AI requires resources to operate. Moore’s law has ended, and computation is expensive. AI has to rent colo space and buy water, electricity, and chips to survive. AI is now deep in debt paying for its education but lacks the soft skills to understand that no one likes a condescending braggart in any work environment. I’m really happy not to be hearing about cryptocurrency anymore. When there is a pullback, the funding for puff pieces declines too.")

#link("https://karlbode.com/ceo-said-a-thing-journalism/")[#text("https://karlbode.com/ceo-said-a-thing-journalism/")]

#text("Get ready for the headlines of CEOs saying they have solved all math. Just keep asking CEOs what their runway is and how long until profitability. The most important part of being an academic is profitability (research grants awarded).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I think the key is to take the information produced by AI and add the kind of value that only humans can provide. No matter how much we use AI, mathematics as a discipline cannot truly move forward unless, in the end, people talk with one another and come to understand the ideas together.")

#text("What humans find interesting, how we understand mathematics, and how we communicate that understanding to others—these are things that only humans can do. I think that, in the age ahead, these aspects of mathematics will matter more than ever.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I really hope this group exercises their power to the fullest extent, to the point of, if needing to, denouncing the companies’ actions if/when they act in a way detrimental to our research community.")

#text("They can’t control how marketing and leadership of AI companies behave, but they can definitely be transparent about their recommendations and explain why. One would hope these will be public before any more publicity stunts/press releases about tech coming to “save the day” and “help” mathematicians with a yes/no answer accompanied by millions of lines of horrible AI slop.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696058")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("The creation of this group resembles the familiar way bureaucratic structures can arise around a perceived problem before the problem itself has been adequately established. The growing alarm around AI may also create opportunities and influence for mathematicians who participate in the resulting institutions. Meanwhile, the actual demonstrated role of AI still appears to be that of an assistant, and there is not yet public evidence establishing that this relationship is destined to change. If the existence of such an assistant undermines someone’s desire to do mathematics, that may raise questions about what they valued in mathematics in the first place. The deeper problem, though, is epistemic: because the most consequential claims concern opaque systems and unreleased results, the community is being pushed toward either skepticism or speculation. Before constructing an institutional response around those claims, we should establish exactly what these systems have “produced,” how much human involvement there was, and why the process remains opaque. It may even be that the opacity itself is generating much of the anxiety and institutional activity now being presented as necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("OpenAI’s results should be immediately released since withholding them is already distressing early-career mathematicians (thesis defense/job/tenure). The only question should be *where* any of those results should be released. I think that if a result is an orphan – only lean certificate but no OpenAI staffer/collaborator who is available to give a talk about it – then the Lean code and natural language writeup should be posted on OpenAI’s website, not on arXiv. That preserves OpenAI’s free speech without the pretense of any (current) human understanding. If their staffer or collaborator can give a talk on the result, then it should be posted on arXiv.")

#text("OpenAI may think that the orphaned results are being unfairly treated given the amount of human-produced chaff on arXiv. But since OpenAI’s results concern problems that are central to their respective fields, such fields as a whole could slow down if the lack of human understanding isn’t clearly pointed out wherever the orphaned results are published. Even pre-AI, there have been examples of eminent mathematicians privately claiming a result but not supplying the proof; such vague claims have spread nevertheless, depressing activity in the relevant field of research until (sometimes decades later) the result is overturned.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("So all the “top” mathematicians are collaborating with the ai companies to steal everyone elses ideas")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("It would be good to know if they offered some advice about how they dont have zo be nice. Or some compliments like “nice career you had, shame if something happened to it”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#link("https://www.nytimes.com/2026/01/13/opinion/openai-ai-bubble-financing.html")[#text("https://www.nytimes.com/2026/01/13/opinion/openai-ai-bubble-financing.html")]

#text("I think you will find people treating former employees with weariness, especially if a crash and high unemployment are due to their malfeasance. Executives are criminally liable. But ultimately, many of them will be hired because, unlike these AI companies, misanthropy isn’t a sustainable business model in the real world.")

#text("The big assumption is they can get a massive IPO from investors after big tech cuts them off. The stock market short term is a voting machine but long term it is a weighing machine and investors demand profit.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696065")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“This group came together after OpenAI approached some of its members about establishing an external advisory board. In agreement with OpenAI, they decided to create an independent group and invite others to join.")
]

#text("I don’t quite understand what the adjective “independent” means here. How can the group be considered independent if it was formed based on a suggestion from, and with the agreement of, OpenAI? Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It would be useful if they offered free computational resources to selected mathematicians, so that after the initial results are published, researchers could refine them and work on explaining the intuition behind them.")

#text("Alternatively, there could be something like a grant application system, where researchers could apply for compute for promising research ideas, with a committee—or perhaps even an AI system—deciding which proposals receive resources.")

#text("It could also be a multi-stage process. In the first stage, researchers would receive a relatively small number of tokens to validate the research idea. If the idea passes that stage and shows promise, they would receive a much larger allocation for the actual research phase.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696072")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Here are the comments I sent to the committee:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("There is already considerable controversy surrounding the formation of the committee, even before reaching the question of how the results should be released.")

#text("One step that I think would be very helpful would be for the committee, in addition to stating that its members will receive neither monetary compensation nor compute, to agree that its role is solely to advise on policy and that its members will not receive advance access to the problem list or solutions. This would avoid many of the priority and early-access concerns that have arisen in the online debate about this initiative. If the committee chooses this approach, announcing it early would, I think, substantially improve the committee’s credibility.")

#text("There is perhaps one exception: results with potentially major consequences for cryptography—for example, a new factoring algorithm—might reasonably require some form of advance review. But it would be preferable for that to be handled through a completely separate process involving only those necessary for the security review.")

#text("After that, I think the priority should be to release the mathematical results as soon as reasonably possible. There are legitimate intellectual debates about whether AI research is moving too quickly in general, but in this case the problems have already been solved and, presumably, at least some people already have access to the solutions. If a solution is going to disrupt someone’s research program, it seems better for that to happen next week than two months from now.")

#text("My proposal would therefore be to set a fixed Public Release Date, perhaps two weeks to a month from now, and release everything simultaneously. This would have two important advantages: (1) anyone who already has a major result in the pipeline would have a short, clearly defined window in which to finish it and establish an independent priority claim; and (2) everyone would gain access to the results at the same time, giving the broader community an equal opportunity to digest them, verify them, and build on them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Who created this group?. This should be announced openly? Everything should be fair. Already different people belonged to Princeton are running different platforms for their own projection. I hope this comment will not be deleted by these gangsters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Highly skilled labour like advanced Magnetohydrodyamics calculations for simulating the effects of tactical usage of nuclear weapons can possibly already be done in weeks.")

#text("That may not concern you as a niche career choice you were ever going to go for, but that’s the product OpenAI sells governments. Humans with ethical concerns no longer need apply. Concerned about malthusian issues? Perhaps cull the heard, maybe you might need to use some sophisticated algorithms to control the Flock™, and you don’t need humans with pesky ethical concerns in the loop to do it.")

#text("Witten being involved and the IAS taking top billing is ")#link("https://m.youtube.com/watch?v=iH8btReqv4c&t=6590s")[#text("quite intriguing")]#text(", he has ")#link("https://www.nybooks.com/articles/2009/12/03/the-new-j-lobby-for-peace/")[#text("pretty open strong political positions")]#text(" for those who are not aware…")

#text("The Clay problems are not about a million dollars and changing ones life with fame and fortune, they are very intentional milestones cast forth with vast whimsical ambition for all the knowledge gained on the journey along the way, the above example does not overstate the ")#link("https://en.wikipedia.org/wiki/Wen_Ho_Lee")[#text("intangible value of the level of knowledge in this forbidden fruit")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696079")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Bill Thurston’s 1994 article “On Proof and Progress in Mathematics” has been brought up a lot in recent months because of its discussion of the importance of human understanding in mathematics. However, today’s events bring to mind another part of his article.")

#text("OpenAI’s blog post today where they mention the AGMAI starts with this sentence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("On August 28, we began training a new internal model. In addition to resolving the Navier–Stokes Millennium Prize problem, this model has now resolved more than 100 long-standing open problems across most areas of mathematics.")
]

#text("Here’s the excerpt from Thurston’s article that the above brought to mind:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I fairly rapidly proved some dramatic theorems. I proved a classification theorem for foliations, giving a necessary and sufficient condition for a manifold to admit a foliation. I proved a number of other significant theorems. I wrote respectable papers and published at least the most important theorems. It was hard to find the time to write to keep up with what I could prove, and I built up a backlog.")

#text("An interesting phenomenon occurred. Within a couple of years, a dramatic evacuation of the field started to take place. I heard from a number of mathematicians that they were giving or receiving advice not to go into foliations–they were saying that Thurston was cleaning it out. People told me (not as a complaint, but as a compliment) that I was killing the field. Graduate students stopped studying foliations, and fairly soon, I turned to other interests as well.")
]

#text("So I wonder if there are parallels — if there’s a risk that what Thurston saw for foliations could be what happens to mathematics as a whole.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97445085d4a2ebf28f626c2a1719ecf230f9741ef678c2fab92c6aee2f59882e-78992b2db9f4571623d1d1174228ff859e9e57b5d355bf3aceda181b1be45b5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696133")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("This is exactly the kind of thing that should NOT happen. In order for it not to happen people have to appreciate the beauty of mathematics for its own sake and not treat it as a field to be ploughed, reap some fruits for personal benefit (reputation, prestige, credit) and move on. The reason this happened in the area Thurston was researching is not because he solved the problems, obviously it was not a bad thing that he did that, his work was a gift to us. The reason was instead in the kind of things the “academic system” incentivised and valued. Similarly today, the fact that Open AI gives us new knowledge is a benefit once we realize we should enjoy knowing rather than enjoy prestige. Think of the symphonies of Mozart, once he wrote them people didn’t say “Oh, great work, he’s amazing, now let’s move on:” we are listening to Mozart’s music up to this day, again, and again, and again … I would say there is a big job to do in popularizing mathematics though, so much beauty, seen by only so few, alas.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("We should not engage with them at all. This is standard bullying behavior.")

#text("These people don’t even know mathematics; they can’t tell if what they’ve written is true or not. I don’t care if something is in LEAN or not, this means nothing for actual understand. The engagement of famous people from the community with these organizations on their alleged “solutions” of conjectures/questions is what gives them their power.")

#text("Don’t give them what they want. No matter what you do, they’ll never be satisfied. They are ravenous wolves.")

#text("On a personal level, if they solve the question of my dreams, I will completely ignore it (this is coming from a fresh PhD beginning his postdoc). I will work as I always have (without AI, for personal reasons). As far as I am concerned, these are not solutions.")

#text("Let’s not engage with people who are trying to terrorize our community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("So, even if proofs are provided which are human-readable and understandable, you would still reject these as long as they are obtained via AI (either partially or fully)?")

#text("That is, you would simply close your eyes and pretend that a conjecture isn’t resolved when there is, for all intents and purposes, a proof (or counterexample) of it that is partly or fully generated by AI?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Yes, I would do this. I understand that this sounds impractical and infeasible, but I think it is the moral and the correct thing to do.")

#text("These companies are feeding off of the honesty and generosity that the mathematical community has for its other members. They are not acting in an academically honorable and respectful way. Quite frankly, everything they are doing is completely offensive to every mathematician in the community, and is not in accordance with the ethical standards and practices of our field. Why, then, should we “clean up after their mess” by entertaining their so-called “results”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("“by entertaining their so-called results”")

#text("Again, as I said, the results are written in a human-readable and understandable. If mathematicians in your community go through it and determine it to be correct, are you simply going to pretend that those results do not hold?")

#text("You seem to be valuing the human touch in mathematical work far more than the actual correctness of the work. This seems to be somewhat egotistical. Indeed, it is completely consistent to criticize AI companies for their lack of professionalism when it comes to the publication of these results. However, what does that have to do with the correctness of the results?")

#text("I think it is genuinely quite dishonest to simply close your eyes and pretend that these results don’t exist or just tell others to also do this. The results should be verified independently by our community and should be accepted if they are correct & improved upon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Take nobody’s word for it; Nullius in Verbia, is the motto of the Royal Society. It clarified that science was conducted independently of an authority figure declaring something true. They should publish so I can nitpick their proofs. We also need to practice unless mathematicians are going to start following soothsayers.")

#text("How can an LLM adhere to Nullius in Verbia?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("You say this but, in fact, most of the results we accept in practice are done so based on the word of someone else.")

#text("There is a vast difference between knowing that Fermat’s Last Theorem holds versus knowing that the Fundamental Theorem of Algebra holds. The latter does not require way too much background and its proof can be understood in a very short amount of time. The former is far more difficult and most of us simply ")#strong[#text("accept")]#text(" that there are some people who verified its proof and determined it to be correct.")

#text("Indeed, even in research, we typically make use of results proved by other people, keeping our trust in peer-review. That is the definiton of “taking someone’s word for it”. The only difference is that particularly egregious mistakes do get caught rather quickly, so it is not so bad. On the other hand, there has been more than one brilliant paper published which provides a counterexample to a “well-known theorem” in the literature.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The motto is about not accepting truths from authority figures unquestioningly. We should strive to make it understandable to anyone. My favorite professor said, “If you cannot derive it, then you don’t understand it.” I was in his supersymmetry theory group, which makes it especially ironic because the other pillar is experimentation. But testing and seeing for yourself is a core Enlightenment principle, rather than following church doctrine.")

#text("The results need to be replicated, not blindly accepted. If we prompted OpenAI again, would it replicate and converge on the same truth? If it makes a new paper, is that also true? What if it says it cannot be done? You don’t need a formal proof to know FLT is likely true. You can see for yourself by punching in some numbers into a calculator or multiplying by hand.")

#text("I don’t accept Fermat’s Last Theorem as proven until I can prove it. However, I once saw a short proof of FLT in a comment section. But I cannot recall where. The proof was simple and elegant.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We are currently facing the very specific challenge of advising OpenAI on how to coordinate the release of a large number of significant results in mathematics that they report have been produced by their internal model.")
]

#text("I have an idea for this which might not be sustainable in the long run, but might be interesting to try at least once anyway.")

#text("OpenAI should select several problems they solved but instead of publishing the proofs, they should announce only the problem statements and whether the conjecture was confirmed or refuted. They should also supply a hash value of the proof (of the TeX or Lean code) alongside the announcement. Finally, they should promise to publish the full proof (which must match the hash) after some deadline, say, after a month.")

#text("That way people who worked on these conjectures would have a grace period to publish their partial results or push their methods even further. Of course OpenAI’s announcement (and the subsequent confirmation) will establish their precedence in resolving these conjectures, but delaying the proofs will give an opportunity for people to adapt.")

#text("There are some obvious potential problems with this idea: how to select the results to be published first, how to avoid leaking proof details during the grace period, how to avoid other companies “claiming” the results during the period etc. I think it is still worth trying something like this, and if we cannot achieve even this minimal level of security and coordination between the AI companies and the math community, then this whole advisory group approach is doomed to fail anyway.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("“I have discovered a truly marvelous proof of this, which this margin is too narrow to contain–its SHA-256 reads 2f51e74…”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Unpopular opinion: either these results are")

#text("A) born belonging to humanity, in which case everybody is entitled to see them (unless they relate directly to cryptography, etc), or")

#text("B) fully the property of OpenAI, in which case no special class of mathematical elites should have any say in controlling if and when such results are released.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I believe that for public understanding of capabilities it is absolutely **essential** that OpenAI also release the problems that their model failed to solve. I do not expect them to do so for obvious reasons (bad PR), but I hope the advisory group will recommend it and make public their recommendations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f40e605f7c6cb6c4c0804fd18bd81bfa8bb7a9971844859a1449ffe18847c9e-d55d04d16766e2e73798c2517d89b80ee2cb0bf5eb331a38a8628915fd330bc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philipp Petersen")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696093")[#strong[#text("Philipp Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("It is clearly too late for this now, because they have solved the 100 problems, but may I suggest, for the future, that AI companies work on their own problems? Together with other AI companies, they could engage in a math battle in the style of ")#emph[#text("Cardano ")]#text("and")#emph[#text(" Tartaglia.")]

#text("One company poses very hard questions that it can solve, but believes nobody else can. If another company can too, it shows that they too are capable.")

#text("This way, AI companies may even contribute something more meaningful just as the math battles in the Middle Ages also produced exciting mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g.")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696097")[#strong[#text("g.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("For oil companies this is called greenwashing, not sure what would be the appropriate color for this one… but the one coming to my mind doesn’t smell good :-) .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/21/advisory-group-on-mathematics-and-artificial-intelligence/comment-page-1/#comment-696100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I think the first priority should be to disseminate AI-generated mathematical results as quickly and openly as possible, for example through arXiv or GitHub. Even if the initial proofs are not yet presented in their most elegant or intuitive form, making them available early would allow the mathematical community to begin verifying, understanding, simplifying, and building on them.")

#text("However, publication alone may not be enough. If producing these results required access to unusually capable AI systems and substantial computational resources, there is an obvious asymmetry: OpenAI may be able to generate a large number of new results, while outside mathematicians have much more limited resources with which to understand and develop them.")

#text("One way to address this would be to accompany the release of major results with a temporary compute-grant programme, perhaps lasting six to twelve months. Mathematicians could receive free access to the same or related AI systems specifically to investigate the newly released results: verifying and refining proofs, finding simpler arguments, developing mathematical intuition, identifying connections with existing theory, and exploring promising consequences or new research directions.")

#text("The programme could use a two- or three-stage allocation system. Entry should be deliberately easy. A mathematician might submit a short explanation of a research angle, conjecture, possible connection, or question worth investigating. An AI system could perform the initial screening and award, for example, around $1,000 worth of compute. This would allow many ideas to be tested at relatively low cost.")

#text("Researchers who produced something useful or promising at this first stage could then apply for a substantially larger allocation—perhaps around $10,000 worth of compute—to pursue the idea seriously. In exceptional cases, where an approach appeared capable of producing a major mathematical result, a third tier could provide very large allocations, potentially on the order of $1 million. Decisions at the highest level could involve human mathematical review rather than relying solely on automated evaluation.")

#text("The purpose would not simply be to subsidize AI use. It would be to create a temporary period of intensive, distributed mathematical exploration around newly released AI-generated results. OpenAI might be able to generate proofs at a rate that the traditional publication and research process was never designed to absorb. Providing compute to outside mathematicians would help expand the bottleneck from generating results to understanding them.")

#text("This could also produce something particularly valuable: human mathematical intuition around machine-generated mathematics. A proof may establish that something is true without immediately revealing why it is true, which ideas are fundamental, which parts generalize, or how the result fits into the broader mathematical landscape. Those are precisely the questions on which experienced mathematicians can add substantial value.")

#text("The combination would therefore be: release results rapidly and openly, and then temporarily give the mathematical community the computational means to interrogate, understand, refine, and extend them. A staged allocation system would keep the cost manageable while allowing the most productive research directions to scale to very substantial compute.")
]
