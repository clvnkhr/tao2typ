// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/
// Converted to Typst by tao2typ: "2026-10-14T16:35:00.792973+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: the circular law", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: the circular law")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/%7Evanvu/")[#text("Van Vu")]#text(" and I have recently uploaded our joint paper, “")#link("http://arxiv.org/abs/0708.2895")[#text("Random matrices: the circular law")]#text("“, submitted to ")#link("http://cdm.math.ca/index.php/cdm")[#text("Contributions to Discrete Mathematics")]#link("http://www.actamathematica.org/")[#text("http://www.actamathematica.org/")]#text(". In this paper we come close to fully resolving the ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("circular law conjecture")]#text(" regarding the eigenvalue distribution of random matrices, for arbitrary choices of coefficient distribution.")

#text("More precisely, suppose we have an ")#mi("n \\times n")#text(" matrix ")#mi("N_n")#text(" for some large n, where each coefficient ")#mi("x_{ij}")#text(" of ")#mi("N_n")#text(" is an ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("independent identically distributed copy")]#text(" of a single random variable x (possibly complex-valued). x could be continuous (e.g. a Gaussian) or discrete (e.g. a Bernoulli random variable, taking values +1 and -1 with equal probability). For simplicity, let us normalise x to have mean 0 and variance 1 (in particular, the second moment is finite). This matrix will not be self-adjoint or normal, but we still expect it to be diagonalisable, with n complex eigenvalues. Heuristic arguments suggest that these eigenvalues should mostly have magnitude ")#mi("O(\\sqrt{n})")#text("; for instance, one can see this by observing that the ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_norm")[#text("Hilbert-Schmidt norm")]#text(" (a.k.a. the ")#link("http://en.wikipedia.org/wiki/Matrix_norm#Frobenius_norm")[#text("Frobenius norm")]#text(") ")#mi("\\text{tr} N_n^* N_n")#text(", which can be shown to dominate the sum of squares of the magnitudes of the eigenvalues, is of size comparable to ")#mi("n^2")#text(" on the average. Because of this, it is customary to normalise the matrix by ")#mi("1/\\sqrt{n}")#text("; thus let ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(" be the n complex eigenvalues of ")#mi("\\frac{1}{\\sqrt{n}} N_n")#text(", arranged in any order.")

#text("Numerical evidence (as seen for instance ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("here")]#text(") soon reveals that these n eigenvalues appear to distribute themselves uniformly in the unit circle ")#tao-math("\\{ z \\in {\\Bbb C}: \\left|z\\right| \\leq 1 \\}", block: false)#text(" in the limit ")#mi("n \\to \\infty")#text(". This phenomenon is known as the ")#emph[#text("circular law")]#text(". It can be made more precise; if we define the ")#emph[#text("empirical spectral distribution")]#text(" ")#mi("\\mu_n: {\\Bbb R}^2 \\to [0,1]")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("\\mu_n(s,t) := \\frac{1}{n} \\# \\{ 1 \\leq k \\leq n: \\text{Re}(\\lambda_k) \\leq s; \\text{Im}(\\lambda_k) \\leq t \\}")]]

#text("then with probability 1, ")#mi("\\mu_n")#text(" should converge uniformly to the uniform distribution ")#mi("\\mu_\\infty")#text(" of the unit circle, defined as")

#align(center)[#tao-fit-display[#tao-math("\\mu_\\infty(s,t) := \\frac{1}{\\pi} \\text{mes}(\\{ (x,y): \\left|x\\right|^2 + \\left|y\\right|^2 \\leq 1; x \\leq s; y \\leq t \\}.", block: true)]]

#text("This statement is known as the ")#emph[#text("circular law conjecture")]#text(". In the case when x is a complex Gaussian, this law was verified ")#link("http://www.ams.org/mathscinet-getitem?mr=220494")[#text("by Mehta")]#text(" (using an explicit ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("formula of Ginibre")]#text(" for the joint density function of the eigenvalues in this case). A strategy for attacking the general case was then formulated ")#link("http://www.ams.org/mathscinet-getitem?mr=773436")[#text("by Girko")]#text(", although a fully rigorous execution of that strategy was first achieved ")#link("http://www.ams.org/mathscinet-getitem?mr=1428519")[#text("by Bai")]#text(" (and then improved slightly by Bai and Silverstein). They established the circular law under the assumption that x had slightly better than bounded second moment (i.e. ")#tao-math("{\\Bbb E}\\left|x\\right|^{2+\\delta} < \\infty", block: false)#text(" for some ")#mi("\\delta > 0")#text("), but more importantly that the probability density function of x in the complex plane was bounded (in particular, this ruled out all discrete random variables, such as the Bernoulli random variable). The reason for this latter restriction was in order to control the event that the matrix ")#mi("N_n")#text(" (or more precisely ")#mi("\\frac{1}{\\sqrt{n}} N_n - z I")#text(" for various complex numbers z) becomes too ")#link("http://en.wikipedia.org/wiki/Condition_number")[#text("ill-conditioned")]#text(" by having a very small least ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular value")]#text(".")

#text("In the last few years, work ")#link("http://www.ams.org/mathscinet-getitem?mr=2196007")[#text("of Rudelson")]#text(", ")#link("http://arxiv.org/abs/math.PR/0703307")[#text("of myself with Van Vu")]#text(", and ")#link("http://arxiv.org/abs/math/0703503")[#text("of Rudelson-Vershynin")]#text(" (building upon earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=1260107")[#text("of Kahn, Komlos, and Szemerédi")]#text(", and ")#link("http://front.math.ucdavis.edu/math.CO/0411095")[#text("of Van")]#text(" ")#link("http://arxiv.org/abs/math.PR/0511215")[#text("and myself")]#text("), have opened the way to control the condition number of random matrices even when the matrices are discrete, and so there have been a recent string of results using these techniques to extend the circular law to discrete settings. In particular, ")#link("http://front.math.ucdavis.edu/0702.5386")[#text("Gotze and Tikhomirov established")]#text(" the circular law for discrete random variables which were sub-Gaussian, which was then relaxed ")#link("http://arxiv.org/abs/0705.3773")[#text("by Pan and Zhou")]#text(" to an assumption of bounded fourth moment. In our paper, we get very close to the ideal assumption of bounded second moment; we need ")#tao-math("{\\Bbb E} \\left|x\\right|^2 \\log^C(1+\\left|x\\right|) < \\infty", block: false)#text(" for some ")#mi("C > 16")#text(". (The power of 16 in the logarithm can certainly be improved, though our methods do not allow the logarithm to be removed entirely.)")

#text("The main new difficulty that arises when relaxing the moment condition so close to the optimal one is that one begins to lose control on the ")#emph[#text("largest ")]#text("singular value of ")#mi("\\frac{1}{\\sqrt{n}} N_n")#text(", i.e. on the operator norm of ")#mi("\\frac{1}{\\sqrt{n}} N_n")#text(". Under high moment assumptions (e.g. fourth moment) one can keep this operator norm bounded with reasonable probability (especially after truncating away some exceptionally large elements), but when the moment conditions are loosened, one can only bound this operator norm by a quantity bounded polynomially in n, even after truncation. This in turn causes certain metric entropy computations to become significantly more delicate, as one has to reduce the scale ")#mi("\\epsilon")#text(" of the net below what one would ordinarily like to have.")

#metadata(none) <tao-2d6900c0a234c3d81bc8>#text("The proof of the circular law can be reduced by standard methods to control on the least singular value of the matrices ")#mi("\\frac{1}{\\sqrt{n}} N_n - zI")#text("; the latter is then controlled by some standard counting methods coupled with a new inverse Littlewood-Offord theorem. Let me now briefly discuss these three distinct steps.")

#text("First, the reduction to the least singular value problem. Because the matrix ")#mi("N_n")#text(" is not self-adjoint or normal, approaches which rely on the spectral theorem, such as the moment method (i.e. computing expressions such as ")#mi("\\text{tr}(N_n^k)")#text(" for various k) do not work terribly well (except to get some crude upper bounds). Any approach based on explicit formulae also seem hopeless. Instead, since the work of Girko, all work on the circular law has proceeded through an analysis of the ")#emph[#text("Stieltjes transform")]

#align(center)[#tao-fit-display[#mitex("s_n(z) := \\frac{1}{n} \\sum_{k=1}^n \\frac{1}{\\lambda_k - z}")]]

#text("of the empirical spectral distribution ")#mi("\\mu_n")#text(". On the one hand, this rational function encodes the same information as ")#mi("\\mu_n")#text("; on the other hand, its real part can be expressed as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\text{Re} s_n(z) = -\\frac{1}{2} \\frac{\\partial}{\\partial s} \\log  \\det (\\frac{1}{\\sqrt{n}} N_n - z I) (\\frac{1}{\\sqrt{n}} N_n - z I)^*")]]

#text("where ")#mi("\\frac{\\partial}{\\partial s}")#text(" denotes the derivative with respect to the real part ")#mi("s = \\text{Re}(z)")#text(" of z. Because of this, one can (in principle, at least) deduce the circular law from a study of the spectral distribution of ")#mi("(\\frac{1}{\\sqrt{n}} N_n - z I) (\\frac{1}{\\sqrt{n}} N_n - z I)^*")#text(". The key advantage in doing so is that this latter matrix is self-adjoint (i.e. Hermitian), which makes many additional tools available (not just the moment method, but also various perturbation methods, since the spectrum of a self-adjoint matrix is very stable, whereas the spectrum of an arbitrary matrix is not [due to the influence of the ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text("]). As it turns out, one particularly useful tool is useful is the ")#emph[#text("interspersing property")]#text(": given an ")#mi("n-1 \\times n-1")#text(" minor of a self-adjoint ")#mi("n \\times n")#text(" matrix, the eigenvalues of the former intersperse the eigenvalues of the latter. (This is a nice exercise to derive from the min-max characterisation of eigenvalues of self-adjoint matrices. It also shows up in work on Horn’s conjecture on sums of Hermitian matrices, but that is a whole story in itself.)")

#text("Anyway, using all this machinery one can formally derive the circular law by various (mostly algebraic) manipulations, but there is a significant analytical issue that has to be addressed. In order to exploit (1), one has to handle the two singularities of the logarithm function, one at 0 and the other at infinity. The singularity at infinity is not difficult to deal with, because one has reasonable bounds on the size of ")#mi("N_n")#text("; but the singularity at 0 causes a lot of trouble. Basically, one can only control the effect of this singularity if one has good control on the least singular value of the matrix ")#mi("\\frac{1}{\\sqrt{n}} N_n - z I")#text(" for generic values of z (of course, things are bad when z is an eigenvalue; the problem is if there are also large regions of pseudospectrum in which this matrix has very large inverse even though z is far from any eigenvalue).")

#text("So matters reduce to that of controlling the least singular value of ")#mi("\\frac{1}{\\sqrt{n}} N_n - z I")#text(". To simplify the discussion let us just look at the z=0 case, which already contains most of the main ideas. Here, we have to obtain good upper bounds for probabilities such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\mathbf{P} ( \\left\\| N_n x \\right\\| < \\varepsilon \\text{ for some unit vector } x ),", block: true)]]

#text("for various choices of the parameter ")#mi("\\varepsilon")#text(". If one had only a single unit vector x to deal with, one could easily use a variety of techniques to estimate this probability; the trouble is that we have to consider all possible values of x at once.")

#text("There are two main strategies for dealing with expressions such as (2), which I call the ")#emph[#text("entropy strategy")]#text(" and the ")#emph[#text("swapping strategy")]#text(". The entropy strategy proceeds by using some operator norm bound on ")#mi("N_n")#text(" to discretise the space of all possible x, so that x now only ranges over a finite set. One then gets as good an estimate as one can for each individual x in that set, and sums in x. (There is a slightly more sophisticated multi-scale version of this idea, known as the method of ")#link("http://books.google.com/books?id=dvn4hBt2QEoC")[#text("generic chaining")]#text(", but it turns out we do not need that method here.) This method works well as long as the metric entropy (a.k.a. covering numbers) of the set of x which one has to deal with is small. The swapping method, in contrast, is much more indirect; it uses various manipulations using conditional expectation (and heavy exploitation of independence) to compare probabilities such as (2) in terms of fractions of other probabilities which can be more easily controlled, for instance using the trivial bound that any probability is bounded above by 1. The swapping method was used heavily in some earlier work (for instance in ")#link("http://front.math.ucdavis.edu/math.CO/0501313")[#text("these")]#text(" ")#link("http://arxiv.org/abs/math.PR/0703307")[#text("two")]#text(" papers of Van and myself) but ends up not being very effective here (especially once one reinstates the perturbation ")#mi("-zI")#text(" for arbitrary z); we only use it to handle those vectors x which are “poor” in the sense that x is unlikely to be close to orthogonal to any of the rows of ")#mi("N_n")#text(" (and thus ")#tao-math("\\left\\|N_n x\\right\\|", block: false)#text(" is unlikely to be small).")

#text("To deal with the “rich” vectors, we are thus left with the entropy method, and so we need to control the covering numbers of the space of rich vectors. This problem falls under the purview of ")#emph[#text("inverse Littlewood-Offord theory")]#text(", which seeks to classify those coefficients ")#mi("a_1,\\ldots,a_n")#text(" for which the random walk ")#mi("a_1 x_1 + \\ldots + a_n x_n")#text(" is unusually concentrated (e.g. it hits a small ball with high probability), where ")#mi("x_1,\\ldots,x_n")#text(" are iid copies of x. (In contrast, the more classical forward Littlewood-Offord theory starts with some assumptions on these coefficients ")#mi("a_1,\\ldots,a_n")#text(", and then bounds the “small ball probability”, which measures the extent to which the random walk can concentrate.) This theory is somewhat analogous to the inverse sumset theory developed by Freiman, Ruzsa, and others, and indeed Fourier analysis and the geometry of numbers are used quite heavily in this subject. Here, we need to develop some fairly precise (but technical) inverse Littlewood-Offord theorems in order to obtain an acceptable entropy bound; roughly speaking, we show that most of the coefficients ")#mi("a_1,\\ldots,a_n")#text(" are efficiently contained within a generalised arithmetic progression of bounded rank, with nearly sharp bounds on the size of the progression. One key difficulty is that the variable x is fairly arbitrary; since the information one extracts from Fourier-analytic methods depends heavily on the characteristic function of x, one has to manipulate this information using very general geometry-of-numbers tools, requiring a number of rather technical lemmas (for instance, we need to locate large lacunary sets inside generalised arithmetic progressions).")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7685")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("How important is the assumption that the matrix entries are identically distributed? Is it vital to (some of) the methods used here, or is it really a technical convenience?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Mark,")

#text("One can partially relax the hypothesis of identical distribution; it is enough to assume that the ")#mi("x_{ij}")#text(" are independent, and are “Fourier-dominated” by another random variable y which has bounded ")#mi("2+\\delta")#text(" moment (say) and nonzero variance. By Fourier dominated, I mean that we have ")#tao-math("\\left|{\\Bbb E} e^{2\\pi i {\\rm Re}( x_{ij} \\zeta )}\\right| \\leq \\left|{\\Bbb E} e^{2\\pi i {\\rm Re}( y \\zeta )}\\right|", block: false)#text(" for all i,j and all complex numbers ")#mi("\\zeta")#text(", thus the characteristic functions of the ")#mi("x_{ij}")#text(" are uniformly controlled by the characteristic function of y. This generalisation is more or less automatic from our methods, as the iid hypothesis is primarily exploited via Fourier-analytic techniques.")

#text("As a concrete example, we can handle the case in which all of the ")#mi("x_{ij}")#text(" are supported in a fixed finite set (e.g. ")#mi("\\{ -100,\\ldots,100 \\}")#text("), but have different distributions (but still all have mean zero and variance 1, of course).")

#text("On the other hand, the assumption of independence is absolutely crucial for us (though perhaps we might be able to tolerate a small (")#mi("o(n)")#text(") amount of “bad” entries, e.g. we can “freeze” some entries to be deterministic).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7688")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Terry,")

#text("Of course it’s to be expected that weakening the assumption of independence is a much more complicated manner, since it can be done so many ways. Recent work in the setting of symmetric random matrices with dependent entries includes cases in which one sees the same asymptotic spectral behavior as in the classical case (like ")#link("http://www.ams.org/mathscinet-getitem?mr=2205336")[#text("here")]#text("), or something completely new (like ")#link("http://www.ams.org/mathscinet-getitem?mr=2206341")[#text("here")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Mark,")

#text("Thanks for the links! (Incidentally, Mathscinet has a useful feature called “make link” which creates a civilised and stable URL for any article, in particular it points to the article itself rather than the search query that located that article.)")

#text("In the case of discrete matrices, even the simplest non-independent case, namely that of random symmetric Bernoulli matrices, is already very difficult; I was ")#link("http://arxiv.org/abs/math.PR/0505156")[#text("able to show with Kevin Costello and Van Vu")]#text(" that those matrices are non-singular with probability 1-o(1), but to get condition number bounds (i.e. to control the least singular value) looks much more difficult. (Of course, in this particular case, the matrix is self-adjoint, and one can use moment methods to get a spectral distribution – the semicircular law, I believe – but I have no idea what happens for, say, symmetric ")#emph[#text("complex")]#text(" discrete random matrices.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5130ac4862acfb3b439a25f5c64c6b9f62383822f69f8de01b40a9f1c8f22fe9-14a868d0dff57fdc551a4bc132a8ec5e781ca9d4bfd009e371f351fa79a69ab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Clarage")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7704")[#strong[#text("Jim Clarage")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("What form does the Circle Law take when the eigenvalues are all real?")

#text("I’m asking as a biophysicist. E.g., the dynamics of large protein molecules (large N-body) involves matrices in the atomic motions. It would seem the real-resctricted form of the conjecture would allow me to make some general limiting statements about the dynamics. (instead of running hours of mindless computer grid time as I do now).")

#text("Would they be evenly distributed on real interval? Or would they be weighted at origin since a disk projection on interval would weight in middle?")

#text("-signed biophysicist posting to (my favorite) math blog for first time")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Jim,")

#text("For random self-adjoint matrices with iid entries (which automatically have real eigenvalues), the relevant law is Wigner’s semicircular law:")

#link("http://mathworld.wolfram.com/WignersSemicircleLaw.html")[#text("http://mathworld.wolfram.com/WignersSemicircleLaw.html")]

#text("In particular, there is definitely a concentration near the origin.")

#text("More generally, the theory of random self-adjoint matrices is extremely well developed, in large part due to the effectiveness of the moment method in this setting. See for instance the book by Mehta on random matrices.")

#text("If instead you are asking about the distribution of the real parts of the complex eigenvalues of a random matrix, the distribution will again obey the semicircular law, since if one projects the uniform distribution of the circular law onto the real axis, one obtains the semicircular distribution on an interval. It is a curious coincidence that this distribution comes up in two different ways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5130ac4862acfb3b439a25f5c64c6b9f62383822f69f8de01b40a9f1c8f22fe9-14a868d0dff57fdc551a4bc132a8ec5e781ca9d4bfd009e371f351fa79a69ab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Clarage")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7717")[#strong[#text("Jim Clarage")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")])]

#text("Dear Terry,")

#text("Thanks so much for the answer. I’ll either goto sleep now, or figure out what this implies for the dynamics of very large protein molecules.")

#text("ps., I find it wonderfully coincidental that you mentioned the “curious coincidence” between the strictly Real and the real-parts of the Complex, since of course Wigner himself stressed such")#linebreak()#text(" ")#link("http://www.dartmouth.edu/~matc/MathDrama/reading/Wigner.html")[#text("seemingly unreasonable")]#text(" coincidences in mathematics and natural science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7719")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")]

#text("[…] Random matrices: the circular law Van Vu and I have recently uploaded our joint paper, “Random matrices: the circular law“, submitted to Acta […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7749")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2007")])]

#text("Are there any results concerning the spectrum of (normalized) random unimodular matrices, obtained for instance by random walks on $SL(n,\\mathbf{Z})$, using systems of generators like elementary matrices which seem to give a decent dependency on $n$? Of course there are two parameters involved here, the length (say $k$) of the random walk, and the size $n$ of the matrix, instead of simply the size $n$, and it’s not clear if fixing $k$ and letting $n$ go to infinity will lead to something interesting. For the limit of large $k$, with fixed $n$, one might expect to obtain a limit however (related to Haar measure on $SU(n)$?) And one could imagine “mixed” limits where $k$ is a function")#linebreak()#text(" of $n$, so that the $k$-th step is throughly mixed.")

#text("In another direction, I’m wondering if in the bounds for the probability that a random Bernoulli-type discrete random matrix is singular, one can expect to have similar bounds for the probability that the characteristic polynomial is, say, irreducible, or has big splitting field? This is the type of questions that can be attacked by sieve in the case of random walks, using harmonic analysis (uniform spectral gaps of Cayley graphs), but for Bernoulli-type random matrices, the same approach would need to know quite precisely how the the characteristic polynomial of such a matrix is distributed modulo a prime $p$, which seems interesting but not obvious at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2007")])]

#text("Dear Emmanuel,")

#text("Regarding your first question, I don’t have a direct answer, but there is some work which is in the spirit of your questions. Random walks on ")#mi("SL(2,{\\Bbb R})")#text(" are essentially the same as transfer matrices for discrete one-dimensional Schrodinger (or Dirac) operators with random potentials, and there is an immense literature on these (the buzzword here is “Anderson localization”). Presumably, much of this literature extends to ")#mi("SL(n,{\\Bbb R})")#text(" in the regime where n is fixed and k is going to infinity.")

#text("There is a small amount of literature on how close a random walk in a fixed non-abelian Lie group can get to the origin, see for instance the ")#link("http://arxiv.org/abs/math/0010145")[#text("Kaloshin-Rodnianski paper")]#text(" on a conjecture of Gamburd-Jacobson-Sarnak. More recently, the work of Bourgain and Gamburd establishes rapidly converging uniform distribution properties of random walks on SU(2).")

#text("In the opposite regime in which k is fixed and n is going to infinity, then one presumably wants to use the tools of free probability, free convolution, and so forth.")

#text("As for your second question, there is some literature on what the determinant mod p of a random Bernoulli matrix looks like (in the regime where p is fixed and n goes to infinity) – as one would expect, it becomes uniformly distributed on {1,…,p-1} and has a spike at 0, and of course one can also easily figure out what is going on with the trace and a few moments, but this is nowhere near enough control on the characteristic polynomial to start addressing questions such as irreducibility. It might be possible to make some conjectures though; if the matrix is not actually singular, then one expects the characteristic polynomial modulo p to look rather generic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7761")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2007")])]

#text("Dear Terry,")

#text("I wouldn’t say that the two different occurences of the semicircle law are just a coincidence. Rather they illustrate an interesting phenomenon. In addressing Jim’s question you pointed out that the semicircle law approximately describes the distribution of:")

#text("1) the (necessarily real) eigenvalues of a suitably normalized random self-adjoint matrix; and")#linebreak()#text(" 2) the real parts of the eigenvalues of $\\frac{1}{\\sqrt{n}} N_n$.")

#text("If we, as usual, define the real part of $N_n$ to be the matrix $\\frac{1}{2} (N_n + N_n^*)$, then the real part of $N_n$ is precisely the kind of random self-adjoint matrix covered by Wigner’s theorem. In general, the real parts of the eigenvalues of a matrix $N_n$ are not the same as the eigenvalues of the real part of $N_n$. But the two different occurences of the semicircle law show that when the matrix is large and its entries are i.i.d. random variables, those two sets of numbers are nearly the same with high probability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2007")])]

#text("To Mark and Terry,")

#text("It sounds interesting. Would there be a “soft” way to show that the distributions")#linebreak()#text(" of the real parts of the eigenvalues and the eigenvalues of the real parts are tbe same, without computing these distributions precisely ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-7976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Dear anonymous,")

#text("As far as I know there is no “soft” way to do this, which is a pity as it would probably provide a much simpler proof of the circular law (which, at present, requires a much more intricate argument than the corresponding argument for the semicircular law, since the method of moments works very well for the latter but not the former).")

#text("One reason for caution, though, is that once one leaves the realm of self-adjoint (or at least normal) matrices, and considers arbitrary matrices, then the spectrum becomes a very unstable concept; small perturbations in the matrix can lead to dramatic changes in the spectrum, due to the presence of pseudospectrum. Because of this, it seems hopeless to get any control on the spectrum of such matrices by purely soft arguments, unless one has some control on pseudospectrum (such as the least singular value bounds alluded to in the main post), which almost certainly requires “hard analysis” methods to establish. But perhaps if one assumed that kind of control as a “black box”, then there is scope for softer arguments to get somewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbfec39caa7ed3ccc3bba4fdc35d8b72ec4ae82ffa87fcbc51132e3bfbb06328-d8de1e1202dff87bed093a5b9488fdad2e91da831f9c1c927f25d4e08164e29f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrizio Dabbene")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-8664")[#strong[#text("Fabrizio Dabbene")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("Dear Terence,")

#text("some time ago I wrote a brief paper")#linebreak()#text(" ")#link("http://staff.polito.it/fabrizio.dabbene/Papers/02-blondel.pdf")[#text(" On the Stability of Random Matrice")]#text(" for a book on ")#text("Unsolved Problems in Mathematical Systems and Control Theory")#text(". I was wondering if your recent research could shed a new light on these open problems in the field of control theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-8712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("Dear Fabrizio,")

#text("There is certainly a lot of work on the spectrum of randomly perturbed matrices; for instance, the condition number and least singular value of such matrices was studied by Spielman and Teng, and then by many other authors (including ourelves). I am not so familiar with the literature regarding your specific problem, but I would imagine that one should first look at simple ensembles such as the GUE; our methods here are more complicated and mainly designed to handle discrete random matrices, which are of importance in digital applications but probably not so much in analog control theory situations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-8800")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2007")])]

#text("Dear Terence & Fabrizio")

#text("It seems that the polynomial bound on the smallest singular value allows to handle the non central case: ")#link("http://arxiv.org/abs/0709.0036")[#text("http://arxiv.org/abs/0709.0036")]#linebreak()#text(" I used the logarithmic potential approach. I ignore if the Fourier-Stieltjes approach of Girko & Bai allows to do the same.")#linebreak()#text(" The non-central case gives to Frabrizio an example of a random non-Hermitian perturbation of a rank one matrix…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-24324")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Regarding my last comment, I think I was too sloppy about the normalization. The eigenvalues of the real part of ")#mi("N_n")#text(" are distributed according to the semicircle law with radius ")#mi("\\sqrt{2}")#text(", whereas the real parts of the eigenvalues of ")#mi("N_n")#text(" are distributed according to the semicircle law with radius 1. So maybe the two appearances of the semicircle law are a coincidence after all, although there may be some heuristic explanation for that factor of ")#mi("\\sqrt{2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/450a4af21a4cd7292f2560e9eb08aafa0f9db98d0b681bd668e5c27809829faf-d258b2061bb2b03f38669aee13676d88e8122e5a3a68d5ef4e3fed4463458521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil Chafaï")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-25899")[#strong[#text("Djalil Chafaï")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Dear Terence,")

#text("One of the main result of your paper with Van Vu is the polynomial control of the smallest singular value of generic random matrices with i.i.d. entries of finite variance. Is it also the case for random matrices with i.i.d. exchangeable rows? Think about the uniform law on some l_p ball, or the uniform law on Markov kernels. The circular law theorem is probably true for such random matrices (confirmed by computer simulations).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-25915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Dear Djalil,")

#text("Of course, some non-degeneracy condition on the rows would be required – if the rows were all constant, for instance, then the matrix would always be singular. More generally, if X denotes a random vector with the distribution of the rows, then the arguments used by Van and myself and by others basically require that X does not concentrate too often within a small neighbourhood of a hyperplane, unless the hyperplane is of a specific form (basically, the normal vector of that hyperplane has to obey some arithmetic relations between its coordinates, up to small error, in order for concentration to be allowed). It is conceivable that such properties could be verified for specific row distributions, though we do not yet have a general abstract theorem that would identify these properties precisely and give an efficient means to test for them. (For the l_p ball, though, I would imagine that concentration of measure effects would make this ensemble sufficiently close to the fully iid ensemble that one could probably deduce results on the former from the latter without much difficulty.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/450a4af21a4cd7292f2560e9eb08aafa0f9db98d0b681bd668e5c27809829faf-d258b2061bb2b03f38669aee13676d88e8122e5a3a68d5ef4e3fed4463458521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil Chafaï")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-26175")[#strong[#text("Djalil Chafaï")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Thank you for your answer, Terence. Of course, exchangeability is not enough. I wonder if there is some simple additional assumption on the correlation and marginal law in order to ensure that the law is close enough to the i.i.d. case or to a more subtle “good” case as you explained. Concentration of measure is a good idea for some class of distributions, but quite restrictive maybe. I was thinking about exchangeability as a weak replacement of i.i.d. Well, my idea is probably too naive in view of the “arithmetic hyperplane property”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-26199")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Djalil,")

#text("I haven’t seen anything like what you’re asking about for the circular law, but if you don’t already know them, the following might interest you:")

#text("“")#link("http://www.ams.org/mathscinet-getitem?mr=2280648")[#text("Random points in the unit ball of ")#mi("l_p^n")]#text("“, preprint available ")#link("http://math.univ-lyon1.fr/~aubrun/recherche/index.html")[#text("here")]#text(". This shows that the Marchenko-Pastur and Bai-Yin results hold for random matrices with rows uniform in an $latex l_p” ball.")

#text("“")#link("http://www.ams.org/mathscinet-getitem?mr=2294976")[#text("A generalization of the Lindeberg principle")]#text("“, article available ")#link("http://arxiv.org/abs/math/0508519")[#text("here")]#text(". This shows that the semicircle law holds for random symmetric matrices with exchangeable entries above the main diagonal.")

#text("What is the “arithmetic hyperplane property” you refer to?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/450a4af21a4cd7292f2560e9eb08aafa0f9db98d0b681bd668e5c27809829faf-d258b2061bb2b03f38669aee13676d88e8122e5a3a68d5ef4e3fed4463458521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil Chafaï")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-26214")[#strong[#text("Djalil Chafaï")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Thanks Mark. I’ve already noticed these two interesting papers.")

#text("“arithmetic hyperplane property” is a shortcut that I used for the explanation of Terence given above about the approach used by him and Van Vu for the polynomial control of the smallest singular value.")#linebreak()#text(" See the last message of Terence above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: A general approach for the least singular value problem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-29984")[#strong[#text("Random matrices: A general approach for the least singular value problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2008")])]

#text("[…] size and with no assumptions on x other than zero mean and unit variance. (See also my earlier blog post on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of ESDs and the circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-31871")[#strong[#text("Random matrices: Universality of ESDs and the circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2008")])]

#text("[…] with the weak and strong law of large numbers, and in fact this law is used in the proof.) In a previous paper, we had established the same claim but under the additional assumption that the moment was finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-43882")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] were then slowly removed in a sequence of papers by Gotze-Tikhimirov, Girko, Pan-Zhou, and Tao-Vu, with the last moment condition being removed in a paper of myself, Van Vu, and Manjunath […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-211776")[#strong[#text("Small ball probability and Inverse Littlewood-Offord theorems « Vuhavan's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")]

#text("[…] discuss the connection from here to the Circular Law conjecture, but interested reader can check this link or this link or this link for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3e0e5b589972b7d140a97d9d2dc14522dd38417466f24e82fbb2e441844fddb-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Foxall")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-223692")[#strong[#text("Eric Foxall")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2013")])]

#text("Hi,")

#text("You mention it is possible to show that the sum of squares of singular values dominates the sum of squares of the eigenvalues of a matrix. Is there an easy way to see why this should be true?")

#text("Thanks,")#linebreak()#text(" Eric")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/#comment-223772")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2013")])]

#text("This can be done directly for upper-triangular matrices (in which the eigenvalues are just the diagonal entries, and the sum of squares of singular values is the Frobenius norm), and the general case then follows from the ")#link("http://en.wikipedia.org/wiki/Schur_decomposition")[#text("Schur decomposition")]#text(".")
]
]
