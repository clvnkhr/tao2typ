// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:05.548756+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stein’s spherical maximal theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stein’s spherical maximal theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/")[#text("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("If ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a locally integrable function, we define the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_function")[#text("Hardy-Littlewood maximal function")]#text(" ")#mi("{Mf: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("Mf(x) := \\sup_{r>0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)|\\ dy,", block: true)]]

#text("where ")#mi("{B(x,r)}")#text(" is the ball of radius ")#mi("{r}")#text(" centred at ")#mi("{x}")#text(", and ")#tao-math("{\\left|E\\right|}", block: false)#text(" denotes the measure of a set ")#mi("{E}")#text(". The ")#emph[#text("Hardy-Littlewood maximal inequality")]#text(" asserts that ")#metadata(none) <tao-dbeb44fc8db8f0e1ca88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\{ x \\in {\\bf R}^d: Mf(x) > \\lambda \\}\\right| \\leq \\frac{C_d}{\\lambda} \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f\\in L^1({\\bf R}^d)}")#text(", all ")#mi("{\\lambda > 0}")#text(", and some constant ")#mi("{C_d > 0}")#text(" depending only on ")#mi("{d}")#text(". By a standard density argument, this implies in particular that we have the ")#emph[#text("Lebesgue differentiation theorem")]

#align(center)[#tao-fit-display[#tao-math("\\lim_{r \\rightarrow 0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} f(y)\\ dy = f(x)", block: true)]]

#text("for all ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" and almost every ")#mi("{x \\in {\\bf R}^d}")#text(". See for instance ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("my lecture notes on this topic")]#text(".")

#text("By combining the Hardy-Littlewood maximal inequality with the ")#link("http://en.wikipedia.org/wiki/Marcinkiewicz_interpolation_theorem")[#text("Marcinkiewicz interpolation theorem")]#text(" (and the trivial inequality ")#tao-math("{\\left\\|Mf\\right\\|_{L^\\infty({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)}}", block: false)#text(") we see that ")#metadata(none) <tao-700ab86bfeead33ad064>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|Mf\\right\\|_{L^p({\\bf R}^d)} \\leq C_{d,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{p > 1}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", and some constant ")#mi("{C_{d,p}}")#text(" depending on ")#mi("{d}")#text(" and ")#mi("{p}")#text(".")

#text("The exact dependence of ")#mi("{C_{d,p}}")#text(" on ")#mi("{d}")#text(" and ")#mi("{p}")#text(" is still not completely understood. The standard Vitali-type covering argument used to establish ")#link(<tao-dbeb44fc8db8f0e1ca88>)[#text("(1)")]#text(" has an exponential dependence on dimension, giving a constant of the form ")#mi("{C_d = C^d}")#text(" for some absolute constant ")#mi("{C>1}")#text(". Inserting this into the Marcinkiewicz theorem, one obtains a constant ")#mi("{C_{d,p}}")#text(" of the form ")#mi("{C_{d,p} = \\frac{C^d}{p-1}}")#text(" for some ")#mi("{C>1}")#text(" (and taking ")#mi("{p}")#text(" bounded away from infinity, for simplicity). The dependence on ")#mi("{p}")#text(" is about right, but the dependence on ")#mi("{d}")#text(" should not be exponential.")

#text("In 1982, ")#link("http://www.ams.org/mathscinet-getitem?mr=663787")[#text("Stein gave")]#text(" an elegant argument (with full details appearing in a subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=727348")[#text("paper of Stein and Strömberg")]#text("), based on the Calderón-Zygmund method of rotations, to eliminate the dependence of ")#mi("{d}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-3fddeab481421762653a>#text(" One can take ")#mi("{C_{d,p} = C_p}")#text(" for each ")#mi("{p>1}")#text(", where ")#mi("{C_p}")#text(" depends only on ")#mi("{p}")#text(".")
]

#text("The argument is based on an ")#link("http://www.ams.org/mathscinet-getitem?mr=420116")[#text("earlier bound of Stein")]#text(" from 1976 on the ")#emph[#text("spherical maximal function")]

#align(center)[#tao-fit-display[#mitex("M_S f(x) := \\sup_{r>0} A_r |f|(x)")]]

#text("where ")#mi("{A_r}")#text(" are the spherical averaging operators")

#align(center)[#tao-fit-display[#mitex("A_r f(x) := \\int_{S^{d-1}} f(x+r\\omega) d\\sigma^{d-1}(\\omega)")]]

#text("and ")#mi("{d\\sigma^{d-1}}")#text(" is normalised surface measure on the sphere ")#mi("{S^{d-1}}")#text(". Because this is an uncountable supremum, and the averaging operators ")#mi("{A_r}")#text(" do not have good continuity properties in ")#mi("{r}")#text(", it is not ")#emph[#text("a priori")]#text(" obvious that ")#mi("{M_S f}")#text(" is even a measurable function for, say, locally integrable ")#mi("{f}")#text("; but we can avoid this technical issue, at least initially, by restricting attention to continuous functions ")#mi("{f}")#text(". The Stein maximal theorem for the spherical maximal function then asserts that if ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > \\frac{d}{d-1}}")#text(", then we have ")#metadata(none) <tao-ebe4a1b422624ccc7101>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| M_S f \\right\\|_{L^p({\\bf R}^d)} \\leq C_{d,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all (continuous) ")#mi("{f \\in L^p({\\bf R}^d)}")#text(". We will sketch a proof of this theorem below the fold. (Among other things, one can use this bound to show the pointwise convergence ")#mi("{\\lim_{r \\rightarrow 0} A_r f(x) = f(x)}")#text(" of the spherical averages for any ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > \\frac{d}{d-1}}")#text(", although we will not focus on this application here.)")

#text("The condition ")#mi("{p > \\frac{d}{d-1}}")#text(" can be seen to be necessary as follows. Take ")#mi("{f}")#text(" to be any fixed bump function. A brief calculation then shows that ")#mi("{M_S f(x)}")#text(" decays like ")#tao-math("{\\left|x\\right|^{1-d}}", block: false)#text(" as ")#tao-math("{\\left|x\\right| \\rightarrow \\infty}", block: false)#text(", and hence ")#mi("{M_S f}")#text(" does not lie in ")#mi("{L^p({\\bf R}^d)}")#text(" unless ")#mi("{p > \\frac{d}{d-1}}")#text(". By taking ")#mi("{f}")#text(" to be a rescaled bump function supported on a small ball, one can show that the condition ")#mi("{p > \\frac{d}{d-1}}")#text(" is necessary even if we replace ")#mi("{{\\bf R}^d}")#text(" with a compact region (and similarly restrict the radius parameter ")#mi("{r}")#text(" to be bounded). The condition ")#mi("{d \\geq 3}")#text(" however is not quite necessary; the result is also true when ")#mi("{d=2}")#text(", but this turned out to be a more difficult result, obtained first ")#link("http://www.ams.org/mathscinet-getitem?mr=812567")[#text("by Bourgain")]#text(", with a simplified proof (based on the local smoothing properties of the wave equation) later given ")#link("http://www.ams.org/mathscinet-getitem?mr=1173929")[#text("by Muckenhaupt-Seeger-Sogge")]#text(".")

#text("The Hardy-Littlewood maximal operator ")#mi("{Mf}")#text(", which involves averaging over balls, is clearly related to the spherical maximal operator, which averages over spheres. Indeed, by using polar co-ordinates, one easily verifies the pointwise inequality")

#align(center)[#tao-fit-display[#mitex("Mf(x) \\leq M_S f(x)")]]

#text("for any (continuous) ")#mi("{f}")#text(", which intuitively reflects the fact that one can think of a ball as an average of spheres. Thus, we see that the spherical maximal inequality ")#link(<tao-ebe4a1b422624ccc7101>)[#text("(3)")]#text(" implies the Hardy-Littlewood maximal inequality ")#link(<tao-700ab86bfeead33ad064>)[#text("(2)")]#text(" with the same constant ")#mi("{C_{p,d}}")#text(". (This implication is initially only valid for continuous functions, but one can then extend the inequality ")#link(<tao-700ab86bfeead33ad064>)[#text("(2)")]#text(" to the rest of ")#mi("{L^p({\\bf R}^d)}")#text(" by a standard limiting argument.)")

#text("At first glance, this observation does not immediately establish Theorem ")#link(<tao-3fddeab481421762653a>)[#text("1")]#text(" for two reasons. Firstly, Stein’s spherical maximal theorem is restricted to the case when ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > \\frac{d}{d-1}}")#text("; and secondly, the constant ")#mi("{C_{d,p}}")#text(" in that theorem still depends on dimension ")#mi("{d}")#text(". The first objection can be easily disposed of, for if ")#mi("{p>1}")#text(", then the hypotheses ")#mi("{d \\geq 3}")#text(" and ")#mi("{p > \\frac{d}{d-1}}")#text(" will automatically be satisfied for ")#mi("{d}")#text(" sufficiently large (depending on ")#mi("{p}")#text("); note that the case when ")#mi("{d}")#text(" is bounded (with a bound depending on ")#mi("{p}")#text(") is already handled by the classical maximal inequality ")#link(<tao-700ab86bfeead33ad064>)[#text("(2)")]#text(".")

#text("We still have to deal with the second objection, namely that constant ")#mi("{C_{d,p}}")#text(" in ")#link(<tao-ebe4a1b422624ccc7101>)[#text("(3)")]#text(" depends on ")#mi("{d}")#text(". However, here we can use the method of rotations to show that the constants ")#mi("{C_{p,d}}")#text(" can be taken to be non-increasing (and hence bounded) in ")#mi("{d}")#text(". The idea is to view high-dimensional spheres as an average of rotated low-dimensional spheres. We illustrate this with a demonstration that ")#mi("{C_{d+1,p} \\leq C_{d,p}}")#text(", in the sense that any bound of the form ")#metadata(none) <tao-7b8c8ebdd4a28d34f104>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| M_S f \\right\\|_{L^p({\\bf R}^d)} \\leq A \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for the ")#mi("{d}")#text("-dimensional spherical maximal function, implies the same bound ")#metadata(none) <tao-9edcbdcc41693585973d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| M_S f \\right\\|_{L^p({\\bf R}^{d+1})} \\leq A \\left\\|f\\right\\|_{L^p({\\bf R}^{d+1})}", block: true)]]

#text("for the ")#mi("{d+1}")#text("-dimensional spherical maximal function, with exactly the same constant ")#mi("{A}")#text(". For any direction ")#mi("{\\omega_0 \\in S^d \\subset {\\bf R}^{d+1}}")#text(", consider the averaging operators")

#align(center)[#tao-fit-display[#mitex("M_S^{\\omega_0} f(x) := \\sup_{r>0} A_r^{\\omega_0} |f|(x)")]]

#text("for any continuous ")#mi("{f: {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("A_r^{\\omega_0} f(x) := \\int_{S^{d-1}} f( x + r U_{\\omega_0} \\omega)\\ d\\sigma^{d-1}(\\omega)")]]

#text("where ")#mi("{U_{\\omega_0}}")#text(" is some orthogonal transformation mapping the sphere ")#mi("{S^{d-1}}")#text(" to the sphere ")#mi("{S^{d-1,\\omega_0} := \\{ \\omega \\in S^d: \\omega \\perp \\omega_0\\}}")#text("; the exact choice of orthogonal transformation ")#mi("{U_{\\omega_0}}")#text(" is irrelevant due to the rotation-invariance of surface measure ")#mi("{d\\sigma^{d-1}}")#text(" on the sphere ")#mi("{S^{d-1}}")#text(". A simple application of Fubini’s theorem (after first rotating ")#mi("{\\omega_0}")#text(" to be, say, the standard unit vector ")#mi("{e_d}")#text(") using ")#link(<tao-7b8c8ebdd4a28d34f104>)[#text("(4)")]#text(" then shows that ")#metadata(none) <tao-7da95f622334c1d6622a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| M_S^{\\omega_0} f \\right\\|_{L^p({\\bf R}^{d+1})} \\leq A \\left\\|f\\right\\|_{L^p({\\bf R}^{d+1})}", block: true)]]

#text("uniformly in ")#mi("{\\omega_0}")#text(". On the other hand, by viewing the ")#mi("{d}")#text("-dimensional sphere ")#mi("{S^d}")#text(" as an average of the spheres ")#mi("{S^{d-1,\\omega_0}}")#text(", we have the identity")

#align(center)[#tao-fit-display[#mitex("A_r f(x) = \\int_{S^d} A_r^{\\omega_0} f(x)\\ d\\sigma^d(\\omega_0);")]]

#text("indeed, one can deduce this from the uniqueness of Haar measure by noting that both the left-hand side and right-hand side are invariant means of ")#mi("{f}")#text(" on the sphere ")#tao-math("{\\{ y \\in {\\bf R}^{d+1}: \\left|y-x\\right|=r\\}}", block: false)#text(". This implies that")

#align(center)[#tao-fit-display[#mitex("M_S f(x) \\leq \\int_{S^d} M_S^{\\omega_0} f(x)\\ d\\sigma^d(\\omega_0)")]]

#text("and thus by Minkowski’s inequality for integrals, we may deduce ")#link(<tao-9edcbdcc41693585973d>)[#text("(5)")]#text(" from ")#link(<tao-7da95f622334c1d6622a>)[#text("(6)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Unfortunately, the method of rotations does not work to show that the constant ")#mi("{C_d}")#text(" for the weak ")#mi("{(1,1)}")#text(" inequality ")#link(<tao-dbeb44fc8db8f0e1ca88>)[#text("(1)")]#text(" is independent of dimension, as the weak ")#mi("{L^1}")#text(" quasinorm ")#mi("{\\| \\|_{L^{1,\\infty}}}")#text(" is not a genuine norm and does not obey the Minkowski inequality for integrals. Indeed, the question of whether ")#mi("{C_d}")#text(" in ")#link(<tao-dbeb44fc8db8f0e1ca88>)[#text("(1)")]#text(" can be taken to be independent of dimension remains open. The best known positive result is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=727348")[#text("Stein and Strömberg")]#text(", who showed that one can take ")#mi("{C_d = Cd}")#text(" for some absolute constant ")#mi("{C}")#text(", by comparing the Hardy-Littlewood maximal function with the heat kernel maximal function")

#align(center)[#tao-fit-display[#mitex("\\sup_{t > 0} e^{t\\Delta} |f|(x).")]]

#text("The abstract semigroup maximal inequality of Dunford and Schwartz (discussed for instance in ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("these lecture notes of mine")]#text(") shows that the heat kernel maximal function is of weak-type ")#mi("{(1,1)}")#text(" with a constant of ")#mi("{1}")#text(", and this can be used, together with a comparison argument, to give the Stein-Strömberg bound. In the converse direction, it is a ")#link("http://arxiv.org/abs/0805.1565")[#text("recent result of Aldaz")]#text(" that if one replaces the balls ")#mi("{B(x,r)}")#text(" with cubes, then the weak ")#mi("{(1,1)}")#text(" constant ")#mi("{C_d}")#text(" must go to infinity as ")#mi("{d \\rightarrow \\infty}")#text(".")
]

#metadata(none) <tao-62eaa3ad28431156d924>

#heading(level: 1)[#strong[#text(" — 1. Proof of spherical maximal inequality — ")]]

#text("We now sketch the proof of Stein’s spherical maximal inequality ")#link(<tao-ebe4a1b422624ccc7101>)[#text("(3)")]#text(" for ")#mi("{d \\geq 3}")#text(", ")#mi("{p > \\frac{d}{d-1}}")#text(", and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" continuous. To motivate the argument, let us first establish the simpler estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M_S^1 f \\right\\|_{L^p({\\bf R}^d)} \\leq C_{d,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("where ")#mi("{M_S^1}")#text(" is the spherical maximal function restricted to unit scales:")

#align(center)[#tao-fit-display[#mitex("M_S^1 f(x) := \\sup_{1 \\leq r \\leq 2} A_r |f|(x).")]]

#text("For the rest of these notes, we suppress the dependence of constants on ")#mi("{d}")#text(" and ")#mi("{p}")#text(", using ")#mi("{X \\lesssim Y}")#text(" as short-hand for ")#mi("{X \\leq C_{p,d} Y}")#text(".")

#text("It will of course suffice to establish the estimate ")#metadata(none) <tao-388abdaca940b985361c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\sup_{1 \\leq r \\leq 2} \\left|A_r f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all continuous ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", as the original claim follows by replacing ")#mi("{f}")#text(" with ")#tao-math("{\\left|f\\right|}", block: false)#text(". Also, since the bound is trivially true for ")#mi("{p=\\infty}")#text(", and we crucially have ")#mi("{\\frac{d}{d-1} < 2}")#text(" in three and higher dimensions, we can restrict attention to the regime ")#mi("{p<2}")#text(".")

#text("We establish this bound using a Littlewood-Paley decomposition")

#align(center)[#tao-fit-display[#mitex("f = \\sum_N P_N f")]]

#text("where ")#mi("{N}")#text(" ranges over dyadic numbers ")#mi("{2^k}")#text(", ")#mi("{k \\in {\\bf Z}}")#text(", and ")#mi("{P_N}")#text(" is a smooth Fourier projection to frequencies ")#tao-math("{\\left|\\xi\\right| \\sim N}", block: false)#text("; a bit more formally, we have")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_N f}(\\xi) = \\psi(\\frac{\\xi}{N}) \\hat f(\\xi)")]]

#text("where ")#mi("{\\psi}")#text(" is a bump function supported on the annulus ")#tao-math("{\\{ \\xi \\in {\\bf R}^d: 1/2 \\leq \\left|\\xi\\right| \\leq 2\\}}", block: false)#text(" such that ")#mi("{\\sum_N \\psi(\\frac{\\xi}{N}) = 1}")#text(" for all non-zero ")#mi("{\\xi}")#text(". Actually, for the purposes of proving ")#link(<tao-388abdaca940b985361c>)[#text("(7)")]#text(", it is more convenient to use the decomposition")

#align(center)[#tao-fit-display[#mitex("f = P_{\\leq 1} f + \\sum_{N>1} P_N f")]]

#text("where ")#mi("{P_{\\leq 1} = \\sum_{N \\leq 1} P_N}")#text(" is the projection to frequencies ")#tao-math("{\\left|\\xi\\right| \\lesssim 1}", block: false)#text(". By the triangle inequality, it then suffices to show the bounds ")#metadata(none) <tao-804619a4423d4e263ee6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\sup_{1 \\leq r \\leq 2} \\left|A_r P_{\\leq 1} f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and ")#metadata(none) <tao-c924b0a042df7d8fcbeb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\sup_{1 \\leq r \\leq 2} \\left|A_r P_N f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim N^{-\\epsilon} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{N \\geq 1}")#text(" and some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{p,d}")#text(".")

#text("To prove the low-frequency bound ")#link(<tao-804619a4423d4e263ee6>)[#text("(8)")]#text(", observe that ")#mi("{P_{\\leq 1}}")#text(" is a convolution operator with a Schwartz function, and from this and the radius restriction ")#mi("{1 \\leq r \\leq 2}")#text(" we see that ")#mi("{A_r P_{\\leq 1}}")#text(" is a convolution operator with a Schwartz function of uniformly bounded norms. From this we obtain the pointwise bound ")#metadata(none) <tao-cf835fc094349f22c221>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("A_r P_{\\leq 1} f(x) \\lesssim Mf(x)")]]

#text("and the claim ")#link(<tao-804619a4423d4e263ee6>)[#text("(8)")]#text(" follows from ")#link(<tao-700ab86bfeead33ad064>)[#text("(2)")]#text(".")

#text("Now we turn to the more interesting high-frequency bound ")#link(<tao-c924b0a042df7d8fcbeb>)[#text("(9)")]#text(". Here, ")#mi("{P_N}")#text(" is a convolution operator with an approximation to the identity at scale ")#mi("{\\sim 1/N}")#text(", and so ")#mi("{A_r P_N}")#text(" is a convolution operator with a function of magnitude ")#mi("{O(N)}")#text(" concentrated on an annulus of thickness ")#mi("{O(1/N)}")#text(" around the sphere of radius ")#mi("{r}")#text(". This can be used to give the pointwise bound ")#metadata(none) <tao-7ce9192817991103c3ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("A_r P_N f(x) \\lesssim N Mf(x),")]]

#text("which by ")#link(<tao-700ab86bfeead33ad064>)[#text("(2)")]#text(" gives the bound ")#metadata(none) <tao-3b3ea2db92a67b697ed2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| \\sup_{1 \\leq r \\leq 2} \\left|A_r P_N f(x)\\right| \\right\\|_{L^q({\\bf R}^d)} \\lesssim_q N \\left\\|f\\right\\|_{L^q({\\bf R}^d)}", block: true)]]

#text("for any ")#mi("{q > 1}")#text(". This is not directly strong enough to prove ")#link(<tao-c924b0a042df7d8fcbeb>)[#text("(9)")]#text(", due to the “loss of one derivative” as manifested by the factor ")#mi("{N}")#text(". On the other hand, this bound ")#link(<tao-3b3ea2db92a67b697ed2>)[#text("(12)")]#text(" holds for all ")#mi("{q>1}")#text(", and not just in the range ")#mi("{p > \\frac{d}{d-1}}")#text(".")

#text("To counterbalance this loss of one derivative, we turn to ")#mi("{L^2}")#text(" estimates. A standard stationary phase computation (or Bessel function computation) shows that ")#mi("{A_r}")#text(" is a Fourier multiplier whose symbol decays like ")#tao-math("{\\left|\\xi\\right|^{-(d-1)/2}}", block: false)#text(". As such, Plancherel’s theorem yields the ")#mi("{L^2}")#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_r P_N f \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("uniformly in ")#mi("{1 \\leq r \\leq 2}")#text(". But we still have to take the supremum over ")#mi("{r}")#text(". This is an uncountable supremum, so one cannot just apply a union bound argument. However, from the uncertainty principle, we expect ")#mi("{P_N f}")#text(" to be “blurred out” at spatial scale ")#mi("{1/N}")#text(", which suggests that the averages ")#mi("{A_r P_N f}")#text(" do not vary much when ")#mi("{r}")#text(" is restricted to an interval of size ")#mi("{1/N}")#text(". Heuristically, this then suggests that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq r \\leq 2} \\left|A_r P_N f\\right| \\sim \\sup_{1 \\leq r \\leq 2: r \\in \\frac{1}{N} {\\bf Z}} \\left|A_r P_N f\\right|.", block: true)]]

#text("Estimating the discrete supremum on the right-hand side somewhat crudely by the square-function,")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq r \\leq 2: r \\in \\frac{1}{N} {\\bf Z}} \\left|A_r P_N f\\right| \\leq (\\sum_{1 \\leq r \\leq 2: r \\in \\frac{1}{N} {\\bf Z}} \\left|A_r P_N f\\right|^2)^{1/2},", block: true)]]

#text("and taking ")#mi("{L^2}")#text(" norms, one is then led to the heuristic prediction that ")#metadata(none) <tao-221e4c771b447ce49607>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| \\sup_{1 \\leq r \\leq 2} \\left|A_r P_N f\\right| \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{1/2} N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("One can make this heuristic precise using the one-dimensional Sobolev embedding inequality adapted to scale ")#mi("{1/N}")#text(", namely that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq r \\leq 2} \\left|g(r)\\right| \\lesssim N^{1/2} (\\int_1^2 \\left|g(r)\\right|^2\\ dr)^{1/2} + N^{-1/2} (\\int_1^2 \\left|g^{\\prime}(r)\\right|^2\\ dr)^{1/2}.", block: true)]]

#text("To prove this inequality, one starts with the local one-dimensional Sobolev inequality")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0 \\leq r \\leq 1} \\left|g(r)\\right| \\lesssim \\int_0^{1} |g(r)|\\ dr + \\int_0^{1} |g^{\\prime}(r)|\\ dr,", block: true)]]

#text("rescales this inequality to the scale ")#mi("{1/N}")#text(", and then covers the interval ")#mi("{[1,2]}")#text(" by boundedly overlapping intervals of length ")#mi("{1/N}")#text(".")

#text("A routine computation shows that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{d}{dr} A_r P_N f \\right\\|_{L^2({\\bf R}^d)} \\lesssim N \\times N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("(which formalises the heuristic that ")#mi("{A_r P_N f}")#text(" is roughly constant at ")#mi("{r}")#text("-scales ")#mi("{1/N}")#text("), and this soon leads to a rigorous proof of ")#link(<tao-221e4c771b447ce49607>)[#text("(13)")]#text(".")

#text("An interpolation between ")#link(<tao-3b3ea2db92a67b697ed2>)[#text("(12)")]#text(" and ")#link(<tao-221e4c771b447ce49607>)[#text("(13)")]#text(" (for ")#mi("{q}")#text(" sufficiently close to ")#mi("{1}")#text(") then gives ")#link(<tao-c924b0a042df7d8fcbeb>)[#text("(9)")]#text(" for some ")#mi("{\\epsilon > 0}")#text(" (here we crucially use that ")#mi("{p > \\frac{d}{d-1}}")#text(" and ")#mi("{p<2}")#text(").")

#text("Now we control the full maximal function ")#mi("{M_S f}")#text(". It suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_R \\sup_{R \\leq r \\leq 2R} \\left|A_r f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R}^d)},", block: true)]]

#text("where ")#mi("{R}")#text(" ranges over dyadic numbers.")

#text("For any fixed ")#mi("{R}")#text(", the natural spatial scale is ")#mi("{R}")#text(", and the natural frequency scale is thus ")#mi("{1/R}")#text(". We therefore split")

#align(center)[#tao-fit-display[#mitex("f = P_{\\leq 1/R} f + \\sum_{N > 1} P_{N/R} f,")]]

#text("and aim to establish the bounds ")#metadata(none) <tao-7e914e06150b1f6c9521>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| \\sup_R \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{\\leq 1/R} f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and ")#metadata(none) <tao-8377bf30fdbd011d85fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\| \\sup_R \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{N/R} f(x)\\right| \\right\\|_{L^p({\\bf R}^d)} \\lesssim N^{-\\epsilon} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for each ")#mi("{N > 1}")#text(" and some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{d}")#text(" and ")#mi("{p}")#text(", similarly to before.")

#text("A rescaled version of the derivation of ")#link(<tao-cf835fc094349f22c221>)[#text("(10)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("A_r P_{\\leq 1/R} f(x) \\lesssim Mf(x)")]]

#text("for all ")#mi("{R \\leq r \\leq 2R}")#text(", which already lets us deduce ")#link(<tao-7e914e06150b1f6c9521>)[#text("(14)")]#text(". As for ")#link(<tao-8377bf30fdbd011d85fa>)[#text("(15)")]#text(", a rescaling of ")#link(<tao-7ce9192817991103c3ab>)[#text("(11)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("A_r P_{N/R} f(x) \\lesssim N Mf(x),")]]

#text("for all ")#mi("{R \\leq r \\leq 2R}")#text(", and thus ")#metadata(none) <tao-4a04926224a93c5e8ca3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\| \\sup_R \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{N/R} f(x)\\right| \\right\\|_{L^q({\\bf R}^d)} \\lesssim N \\left\\|f\\right\\|_{L^q({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{q>1}")#text(". Meanwhile, at the ")#mi("{L^2}")#text(" level, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_r P_{N/R} f \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{d}{dr} A_r P_{N/R} f \\right\\|_{L^2({\\bf R}^d)} \\lesssim \\frac{N}{R} N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\frac{1}{R} \\int_R^{2R} \\left|A_r P_{N/R} f\\right|^2\\ dr)^{1/2} + (\\frac{R}{N^2} \\int_R^{2R} \\left|\\frac{d}{dr} A_r P_{N/R} f\\right|^2\\ dr)^{1/2} \\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim N^{1/2} N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("which implies by rescaled Sobolev embedding that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{N/R} f\\right| \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{1/2} N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("In fact, by writing ")#mi("{P_{N/R} f = P_{N/R} \\tilde P_{N/R} f}")#text(", where ")#mi("{\\tilde P_{N/R}}")#text(" is a slight widening of ")#mi("{P_{N/R}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{N/R} f\\right| \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{1/2} N^{-(d-1)/2} \\left\\|\\tilde P_{N/R} f\\right\\|_{L^2({\\bf R}^d)};", block: true)]]

#text("square summing this (and bounding a supremum by a square function) and using Plancherel we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_R \\sup_{R \\leq r \\leq 2R} \\left|A_r P_{N/R} f\\right| \\right\\|_{L^2({\\bf R}^d)} \\lesssim N^{1/2} N^{-(d-1)/2} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("Interpolating this against ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(16)")]#text(" as before we obtain ")#link(<tao-8377bf30fdbd011d85fa>)[#text("(15)")]#text(" as required.")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62ab14f4ecbd76b2f833898cda4c6180b5ca0cafdad003112df9b3e30e06fb34-a40535cd8514079ee123da6be2a12edc287d9f2e7c343f6eb1221dc7f605733a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-52954")[#strong[#text("Yao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2011")])]

#text("Dear Professor Tao, I want to ask you a question that may be ridiculous, I often see many books about harmonic analysis, what does the word “harmonic ” mean? When we call a subject complex analysis or real analysis, may be the most important character of the subject is related to real function or complex function. But when it comes to harmonic analysis, I am not sure why we call this subject harmonic analysis. Does it originated from researching harmonic function ? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-52968")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")])]

#link("http://en.wikipedia.org/wiki/Harmonic")[#text("http://en.wikipedia.org/wiki/Harmonic")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3b201f0308437d9f237aa2421c789a8ff84f856f2240209b2ad74a1592accc-e239f0fb4837efa15a46cd87f105e0f109c8ac7df42ba28e6eea88c2d9098976.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iosevich")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-52974")[#strong[#text("iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")])]

#text("Hi Terry,")

#text("A very nice entry on one of my favorite topics, the spherical averaging operator!")

#text("A quick remark about a connection between your entry and one of your earlier entries on incidence theorems in higher dimensions. One can use the proof of Stein’s result, and also Bourgain/Mockenhaupt, Seeger and Sogge to prove an incidence theorem for spheres of arbitrary radius and homogeneous point sets. This was done in my paper with Hadi Jorati and Izabella Laba that I mentioned in relation to your incidence paper with Jozsef.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48f8ad261b181e1fefc7cce7b76209bb2f14143b9701bb7906efe641a7d7bb37-0e11ad55c45ca5958f7685598f00763a41c5fbd5ae98df0141f9c19707efa1cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Snow")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-52992")[#strong[#text("John Snow")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")])]

#text("I believe my brain did indeed just implode. Thank you for that. ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5920c24b898001d51df9b59e844b4b4675db5210b1b044ca0bc9666cdbaefc2-7d7f2d08c8aec371168a16d8fb2696834fcb287b511d487c334a45cb84a0b827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xifeiautao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-52994")[#strong[#text("xifeiautao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Hi terence,")#linebreak()#text(" The notions of Fourier analysis and harmonic analysis always confused me. In many books they have the same contents. For example, Loukas’s book, Fourier analysis, has similar contents with harmonic analysis written by Stein. So how to make a distinction between Fourier analysis and harmonic in mordern analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-53012")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("There is no fixed definition of any given mathematical field, but Fourier analysis and harmonic analysis do indeed generally refer to overlapping areas of mathematics. Note that harmonic analysis is usually divided into abstract harmonic analysis (over general classes of groups, such as locally compact abelian groups), real-variable harmonic analysis (usually over Euclidean spaces or manifolds), and applied harmonic analysis (e.g. use of wavelets in real-world applications).")

#text("Real-variable harmonic analysis certainly contains Fourier-analytic objects, such as Fourier multipliers, within its purview, but it also studies other objects, such as maximal operators, which do not have any direct connection to the Fourier transform, and in particular can deploy combinatorial or geometric methods (e.g. covering lemmas) that would usually not be termed Fourier analysis. Real-variable harmonic analysis also tends to focus attention on bounding various linear, sublinear, or multilinear operators in spaces such as L^p spaces, whereas Fourier analysis has traditionally been concerned with questions such as convergence or uniqueness of Fourier series. (Of course, the two types of questions are related to each other in many ways.)")

#text("The term Fourier analysis can also be reasonably applied to other applications of the Fourier transform that are not traditionally considered harmonic analysis, such as in additive combinatorics, or additive number theory.")

#text("Ultimately, though, these terms are not rigorously and statically defined, but evolve with the development of the field (and different schools of mathematicians may use these terms in slightly different ways). Much as mathematics can be defined as what mathematicians do, perhaps the most robust definition of “Fourier analysis” and “harmonic analysis” is “what Fourier analysts do” and “what harmonic analysts do”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-53008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Dear Prof. Tao,")

#text("it seems that one or more of the links to your lecture notes at the beginning of the post are broken – they lead back to the post itself.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-53029")[#strong[#text("Análisis y aplicaciones: conferencia en honor de Elias M. Stein | Series divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")]

#text("[…] Recientemente, en conmeración de esta conferencia, Terence Tao publicó en su blog una serie de artículos sobre algunos de los resultados de Stein más importantes, entre los que se encuentran el teorema de interpolación, el principio maximal y el teorema maximal esférico. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-53074")[#strong[#text("Sixth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")]

#text("[…] Tao: Stein’s maximal principle, Stein’s spherical maximal theorem, Locally compact topological vector […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fba2dec28a8e4d1b233936bebc595cd57eed616c23c66e67cdd0a6868dcccd6-04332b5676c7228a89c28b23c08139b9deb4335ef00954c67491155f5e2be8b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-55456")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2011")])]

#text("Dear Dr. Tao,")

#text("I’m not familiar with the union bound argument that mention. What is the argument you would like to make? Do you need a finiteness assumption (on the radii) for it, or could you have a countable supremum?")

#text("K")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-55465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2011")])]

#text("The union bound, in this context, asserts that")#linebreak()#text(" ")#tao-math("\\left| \\{ \\sup_r \\left|F_r(x)\\right| > \\lambda \\} \\right| \\leq \\sum_r \\left|\\{ \\left|F_r(x)\\right| > \\lambda\\}\\right|,", block: false)

#text("or in its ")#mi("L^p")#text(" version,")

#tao-math("\\left\\| \\sup_r \\left|F_r\\right| \\right\\|_{L^p} \\leq (\\sum_r \\left\\|F_r\\right\\|_{L^p}^p)^{1/p}.", block: false)

#text("It is only usable in the case when r is finite or countable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fba2dec28a8e4d1b233936bebc595cd57eed616c23c66e67cdd0a6868dcccd6-04332b5676c7228a89c28b23c08139b9deb4335ef00954c67491155f5e2be8b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-55473")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2011")])]

#text("Got it. Thanks!")

#text("K")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db4bf867018c118a9a0fc9cb9863eb4991cb0030cf0d6c1a3c49e312d31c9b5b-0f23b642c3f7d54a3c4c523ac8205dabef9ce5734ddcb43dce7ad2f57b9e8706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of newsboy")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-55482")[#strong[#text("newsboy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2011")])]

#text("wonderful！")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-140972")[#strong[#text("Bài 1: Hàm cực đại Hardy-Littlewood | Quán cóc Toán")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2012")]

#text("[…] để chỉ ra không phụ thuộc vào số chiều của không gian. Chi tiết xem bài viết trên blog của Terence Tao. Trong chuỗi bài giảng này, tôi sẽ (cố gắng) trở lại vấn đề về ước […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32795fcf55e077e738dee92de5b85111d6f651b911fb69a9e632de2cf7c6e14-82530b3b91b9592b089fb40ffba1b04e0946179bf1e6cf528459cddb5b287e98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hahn")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-172962")[#strong[#text("Hahn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")])]

#text("Hello Terrence Tao,")#linebreak()#text(" Can you explain a little bit more detail about the “blurred out” technique that you used to estimate:")

#tao-math("\\displaystyle \\sup_{1 \\leq r \\leq 2} \\left|A_r P_N f\\right| \\sim \\sup_{1 \\leq r \\leq 2: r \\in \\frac{1}{N} {\\bf Z}} \\left|A_r P_N f\\right|.", block: false)

#text("This is a crucial thing to understand your post thoroughly.")

#text("Thank you,")

#text("Hahn.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-172973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")])]

#text("The rigorous version of this heuristic is given a few paragraphs later in the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32795fcf55e077e738dee92de5b85111d6f651b911fb69a9e632de2cf7c6e14-82530b3b91b9592b089fb40ffba1b04e0946179bf1e6cf528459cddb5b287e98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hahn")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-172997")[#strong[#text("Hahn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")])]

#text("Thank you very much, Terence.")#linebreak()#text(" I got it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guo")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-184506")[#strong[#text("Guo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2012")])]

#text("Hallo, Prof. Tao, do you know if there’s any refinement of this theorem for the endpoint case, say in two dimension, the ")#mi("L^2")#text(" boundedness? Actually I’m thinking if the estimate ")#tao-math("\\left\\| M_S f\\right\\|_{L^{2, \\infty}}\\lesssim \\left\\| f\\right\\|_{L^{2,1}}", block: false)#text(" holds true, one motivation is that the counter-example we use in the 2D case ")#tao-math("\\frac{1}{\\left|x\\right| log(1/\\left|x\\right|)} {1}_{\\left|x\\right|<1}", block: false)#text(" just misses being in ")#mi("L^{2,1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-184529")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2012")])]

#text("I think this remains open. Schlag conjectured an estimate of this form (at least for a dyadically localised version of the maximal operator) in his 1998 Duke paper on the subject, but as far as I know it remains open. (A counterexample could potentially be constructed out of a very carefully designed Besicovitch set, but there might not actually be a set with all the required properties.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-185740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2012")])]

#text("Ah, well, this is embarrassing. A coauthor of mine has tactfully pointed out to me that a counterexample was in fact constructed in Proposition 1.5 of “")#link("http://arxiv.org/abs/math/0205153")[#text("Endpoint mapping properties of spherical maximal operators")]#text(", by A. Seeger, T. Tao, and J. Wright, J. Inst. Math. Jussieu 2 (2003), 109-144. (But I was at least right that a Besicovitch set would be used in the counterexample…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b70b7052ea680b339857afb66d432453c38302a87599ab60bf6eac380c1ef7-b5400083570842e50c66a35fd62568607a885dcf99737010be9f4a7d1c84cfed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guo")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-185927")[#strong[#text("Guo")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("I checked the classical Besicovitch construction, and then believed the estimate to hold true, for 4 days :) Thanks a lot for the reference!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8ee9515a82fe5f5ec38511aa47a5c0037c575a012d3f51fc92e5e234fc43a03-634f6efe5b9a964cae3d38d88793012e59b2d3c01814d692f24908e18c0f4e1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SAAD")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-468602")[#strong[#text("SAAD")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("Good morning,")

#text("how to demonstrate that the maximum according to Hardy-littlewood is integrable?")

#text("Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3f7c0427bc79ce6d6cdde7d08b4554dedfaea47daf6c89fc0bee217679a043c-e76c62a0b00a80babb3f715abb634f506198a4e23c992bb26b7bef3519cce8f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaled")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-469599")[#strong[#text("khaled")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Hello ,")#linebreak()#text(" Please i need your help, how to demonstrate that Hardy-littlewood function maximal is measurable ?")

#text("Best regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-469618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Establish this first for the modification of the Hardy-Littlewood maximal function in which the radii are constrained to be rational numbers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-469601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Is it possible to extend theorem 1 by replacing the balls by an appropriate class of ellipsoids (and the spheres by appropriate spheroids) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-469617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("If one had some sort of hypothesis that every slice of the high-dimensional ball was “uniformly curved” in an appropriate sense, then one might be able to extend Stein’s argument to that case (certainly the spherical maximal function bound used extends to more general settings, see e.g. Chapter XI of Stein’s “Harmonic analysis”). But the argument is not able to deal with balls with flat or nearly flat portions of the boundary. There are other arguments in the literature (by ")#link("http://www.ams.org/mathscinet-getitem?mr=868898")[#text("Bourgain")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=828824")[#text("Carbery")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1042048")[#text("Muller")]#text(") that can deal at least partially with these cases, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-481165")[#strong[#text("Hardy-Littlewood maximal function | 江苏荣华投资公司")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")]

#text("[…] Jump up to:a b Tao, Terence. “Stein’s spherical maximal theorem”.What’s New. Retrieved 22 May […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06930ff57781b7bd3e85155f8709e5148280df5db5238d0efacba768919f9ecb-c7c4cf5cc1eda7825e46c071f9583f9e1011d4e7432c72bafbb80a0e34823919.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Z")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-488168")[#strong[#text("Z")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("Dear prof Tao;")

#text("Is finding the optimal constant for the Hardy-Littlewood inequality considered a “big problem “ in the field of harmonic analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-488184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("Well, it would certainly be a great result if resolved (the one-dimensional case, for instance, was ")#link("http://www.ams.org/mathscinet-getitem?mr=1973058")[#text("published in the Annals")]#text("). But it is considered unlikely to be solved any time soon. There has been a lot of work though on dimension independent bounds, and I personally would be interested in knowing whether the weak-type 1,1 bound for the Hardy-Littlewood maximal function is dimension independent, having worked on this problem myself with Assaf Naor some time back. As is usual with these sorts of analysis problems, often it is not so much the result itself which would have interesting consequences, but the new methods of proof (in particular, one would hope that the techniques used to solve this problem can also give other dimension-independent bounds).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stmadfish (@stmadfish)")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-488859")[#strong[#text("stmadfish (@stmadfish)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Hi Prof Tao,")

#text("I was wondering what is the sharp/optimal space of $f(x)$ for $A_r f(x)$ being continuous with respect to $r$. In your note (")#link("https://pdfs.semanticscholar.org/d001/3f6fdf52e6c6910f8da71d6bd47f2c092206.pdf")[#text("https://pdfs.semanticscholar.org/d001/3f6fdf52e6c6910f8da71d6bd47f2c092206.pdf")]#text("), it seems that you just require $f$ to be non-nagative, bounded function with compact support. In this blog, you wrote “$A_r$ do not have good continuity properties in $r$.”")#linebreak()#text(" Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stmadfish (@stmadfish)")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-488863")[#strong[#text("stmadfish (@stmadfish)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("I am sorry and I find the difference. In this post, ")#tao-fit-display[#mitex("A_r")]#text(" is the spherical averaging operators , in the note, ")#tao-fit-display[#mitex("A_r")]#text(" is the averaging operators. So your comment is no more confusing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc0087dd97d6dd95107914b2f1478cba8fa8d5dc5126796a11aff22a2c05b3c-51efdb7e1e6e2b05dbe987a4d15ee798562ab897def7b673d5a9793b900b8b39.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Basic Littlewood-Paley theory I | Almost Originality")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-514728")[#strong[#text("Basic Littlewood-Paley theory I | Almost Originality")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2019")])]

#text("[…] In developing a framework that allows to prove () we will encounter some variants of the square function above, including ones with smoother frequency projections that are useful in a variety of contexts. We will moreover show some applications of the above fact and its variants. One of these applications will be a proof of the boundedness of the spherical maximal function (almost verbatim the one on Tao’s blog). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc0087dd97d6dd95107914b2f1478cba8fa8d5dc5126796a11aff22a2c05b3c-51efdb7e1e6e2b05dbe987a4d15ee798562ab897def7b673d5a9793b900b8b39.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Basic Littlewood-Paley theory III: applications | Almost Originality")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-515307")[#strong[#text("Basic Littlewood-Paley theory III: applications | Almost Originality")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("[…] for dimension . Let me stress once again that the following is merely a slight re-elaboration of Tao’s excellent post on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-515864")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("What if we replace ")#mi("B(x,r)")#text(" by a convex body?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-515873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("For arbitrary convex bodies, dimension-independent bounds for ")#mi("p > 3/2")#text(" were established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=853451")[#text("by Bourgain")]#text(" and independently ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=828824")[#text("by Carbery")]#text(". It remains open to extend this to ")#mi("p>1")#text(" in general, but this was done for the ")#mi("l^q")#text(" balls, ")#mi("1 < q < \\infty")#text(" by Muller, with the endpoint ")#mi("q=\\infty")#text(" only achieved more recently in a 2014 paper ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3273441")[#text("of Bourgain")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-515885")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("Do you conceive possibility that these results are applicable in the optimization world?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-553456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("In the case when ")#mi("d=3")#text(", the book Functional Analysis by Stein-Shakarchi defines the averaging operator ")#mi("A")#text(" as")

#mi("\\displaystyle A(f)(x) = \\frac{1}{4\\pi}\\int_{S^2}f(x-y)\\;d\\sigma(y),")

#text("which can be also read as the convolution ")#mi("\\frac{1}{4\\pi}f*d\\sigma")#text(". In the definition of ")#mi("A_r")#text(", the plus sign is used on the right instead. How should one understand the discrepancy?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-553483")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("The sphere ")#mi("S^2")#text(" is symmetric under the reflection ")#mi("y \\mapsto -y")#text(", so the choice of sign here does not matter.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/639a90232689947164e956640717e29970ce838ccd119c0fc510500cafa04144-0299fd2cc8299f759e2919190ee97ddad369b7aafd1c2c699521617b00d44928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saurabh")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-554734")[#strong[#text("Saurabh")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I would like to know if there are some positive results for the spherical maximal function (including $n=2$) at the end-point. I could not find any in the literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-554923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Stein’s original paper has an example that shows that the strong-type estimate fails at the endpoint (see also p.472 of Stein’s “Harmonic analysis”). The restricted weak type estimate is also false, this is a special case of Proposition 1.5 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1955209")[#text("this paper of Seeger, Wright and myself")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/639a90232689947164e956640717e29970ce838ccd119c0fc510500cafa04144-0299fd2cc8299f759e2919190ee97ddad369b7aafd1c2c699521617b00d44928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saurabh")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-554959")[#strong[#text("Saurabh")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-599747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("Dear Prof.Tao.")#linebreak()#text(" I would like to know the way to extend a spherical maximal operator estimates on schwartz space to Lp space. Of course, i can extend the domain(Lp) of spherical maximal operator, but I think Proving the Inequality( llM(f)ll_p < C llfll_p) for general f in Lp needs some more setting.(because of nonlinearity)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-599967")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("See Chapter XI.3.5 of Stein’s “Harmonic analysis”. Basically while the maximal operator is not linear, it is still non-negative, monotone, sublinear, and also countably subadditive, and this plus some standard measure theory (e.g., outer and inner regularity of Lebesgue measure) will let one conclude. (It is convenient to work first with Borel-measurable functions rather than Lebesgue-measurable functions in order to guarantee measurability on all spheres (as opposed to almost all spheres), but as explained in Stein’s book, the conclusion ultimately holds for both types of measurability.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-657609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2022")])]

#text("Dr. Tao:")#linebreak()#text(" There are two equivalent definitions of spherical mean from Wikipedia\\\\")#linebreak()#text(" ")#mi("(1)  \\frac{1}{\\omega_{n-1}(r)}\\int_{\\partial B(x,r)}u(y)dS(y)")#text(" \\\\")#linebreak()#text(" ")#tao-math("(2)  \\frac{1}{\\omega_{n-1}}\\int_{\\left|\\left|y\\right|\\right|=1}u(x+ry)dS(y)", block: false)#text(" \\\\")#linebreak()#text(" I don’t see how they are equivalent. (1) is the average over a sphere centred at ")#mi("x")#text(" with radius ")#mi("r")#text(", where (2) is the average over an annulus, i.e. the region of sphere centred at ")#mi("x")#text(" with radius from ")#mi("r-1")#text(" to ")#mi("r+1")#text(". Please explain.")#linebreak()#text(" ")#emph[#text("[The second integral is also on the sphere centred at ")#mi("x")#text(" with radius ")#mi("r")#text("; I am not sure where you are getting the range ")#mi("r-1")#text(" and ")#mi("r+1")#text(" from. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1167863088909057559e89bfdcf4ff1f52dbbb2ef55e442cf215e34d09c0f4a-beae0a36059724d169006da493d59e8f541ef0919be08bd3181a68569d7f8983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-671978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("Dear Professor Tao,")

#text("Is something known on the differentiability of the function ")#mi("x \\mapsto A_r f")#text(" when ")#mi("f")#text(" is positive on a compact set with regular boundary and zero elsewhere? It certainly won’t hold for all ")#mi("r")#text(" but what about almost all of them in a compact interval? Do you by chance have any references? Thanks in advance")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-672006")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2023")])]

#text("I would imagine that differentiability in ")#mi("r")#text(" is too much to hope for; however, one can probably use local smoothing estimates for the wave equation to obtain some Sobolev regularity in ")#mi("r")#text(". Some variational bounds are known: see ")#link("https://arxiv.org/abs/2009.07366")[#text("https://arxiv.org/abs/2009.07366")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1167863088909057559e89bfdcf4ff1f52dbbb2ef55e442cf215e34d09c0f4a-beae0a36059724d169006da493d59e8f541ef0919be08bd3181a68569d7f8983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-672124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2023")])]

#text("Sorry for the lack of clarity, when speaking of differentiability of ")#mi("x \\mapsto A_rf")#text(", the differentiability was to be understood with respect to ")#mi("x")#text(" and not with respect to ")#mi("r")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-685974")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2024")])]

#text("When I view this article on my computer, the displayed equation preceding “which implies by rescaled Sobolev embedding that” is too long, so a large part of it is not visible.")

#emph[#text("[Reformatted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/21/steins-spherical-maximal-theorem/#comment-687556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2025")])]

#text("Dear Professor Tao,")

#text("I would like to know whether there could exist an $L^p$ (discontinuous) function $f$ such that $M_Sf = infty$ almost everywhere (in Lebesgue measure), even when the operator norm inequality holds.")

#emph[#text("[I believe a Fatou lemma type argument can rule this out; this is discussed in Stein’s “Harmonic Analysis”. -T]")]
]
