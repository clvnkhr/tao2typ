// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/
// Converted to Typst by tao2typ: "2026-10-14T16:35:01.692792+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Amplification, arbitrage, and the tensor power trick", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Amplification, arbitrage, and the tensor power trick")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("It occurred to me recently that the mathematical blog medium may be a good venue not just for expository “short stories” on mathematical concepts or results, but also for more technical discussions of individual mathematical “tricks”, which would otherwise not be significant enough to warrant a publication-length (and publication-quality) article. So I thought today that I would discuss the ")#emph[#text("amplification trick")]#text(" in harmonic analysis and combinatorics (and in particular, in the study of estimates); this trick takes an established estimate involving an arbitrary object (such as a function f), and obtains a stronger (or ")#emph[#text("amplified")]#text(") estimate by transforming the object in a well-chosen manner (often involving some new parameters) into a new object, applying the estimate to that new object, and seeing what that estimate says about the original object (after optimising the parameters or taking a limit). The amplification trick works particularly well for estimates which enjoy some sort of symmetry on one side of the estimate that is not represented on the other side; indeed, it can be viewed as a way to “")#link("http://en.wikipedia.org/wiki/Arbitrage")[#text("arbitrage")]#text("” differing amounts of symmetry between the left- and right-hand sides of an estimate. It can also be used in the contrapositive, amplifying a weak counterexample to an estimate into a strong counterexample. This trick also sheds some light as to why ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(" works; an estimate which is not dimensionally consistent can often be amplified into a stronger estimate which is dimensionally consistent; in many cases, this new estimate is so strong that it cannot in fact be true, and thus dimensionally inconsistent inequalities tend to be either false or inefficient, which is why we rarely see them. (More generally, any inequality on which a group acts on either the left or right-hand side can often be “decomposed” into the “isotypic components” of the group action, either by the amplification trick or by other related tools, such as Fourier analysis.)")

#text("The amplification trick is a deceptively simple one, but it can become particularly powerful when one is arbitraging an unintuitive symmetry, such as symmetry under tensor powers. Indeed, the “tensor power trick”, which can eliminate constants and even logarithms in an almost magical manner, can lead to some interesting proofs of sharp inequalities, which are difficult to establish by more direct means.")

#text("The most familiar example of the amplification trick in action is probably the textbook proof of the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\langle v, w \\rangle\\right| \\leq \\left\\|v\\right\\| \\left\\|w\\right\\|", block: true)]]

#text("for vectors v, w in a complex Hilbert space. To prove this inequality, one might start by exploiting the obvious inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|v-w\\right\\|^2 \\geq 0", block: true)]]

#text("but after expanding everything out, one only gets the weaker inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\text{Re} \\langle v, w \\rangle \\leq \\frac{1}{2} \\left\\|v\\right\\|^2 + \\frac{1}{2} \\left\\|w\\right\\|^2.", block: true)]]

#text("Now (3) is weaker than (1) for two reasons; the left-hand side is smaller, and the right-hand side is larger (thanks to the arithmetic mean-geometric mean inequality). However, we can amplify (3) by arbitraging some symmetry imbalances. Firstly, observe that the phase rotation symmetry ")#mi("v \\mapsto e^{i\\theta} v")#text(" preserves the RHS of (3) but not the LHS. We exploit this by replacing v by ")#mi("e^{i\\theta} v")#text(" in (3) for some phase ")#mi("\\theta")#text(" to be chosen later, to obtain")

#align(center)[#tao-math("\\text{Re} e^{i\\theta} \\langle v, w \\rangle \\leq \\frac{1}{2} \\left\\|v\\right\\|^2 + \\frac{1}{2} \\left\\|w\\right\\|^2", block: false)#text(".")]

#text("Now we are free to choose ")#mi("\\theta")#text(" at will (as long as it is real, of course), so it is natural to choose ")#mi("\\theta")#text(" to optimise the inequality, which in this case means to make the left-hand side as large as possible. This is achieved by choosing ")#mi("e^{i\\theta}")#text(" to cancel the phase of ")#mi("\\langle v, w \\rangle")#text(", and we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\langle v, w \\rangle\\right| \\leq \\frac{1}{2} \\left\\|v\\right\\|^2 + \\frac{1}{2} \\left\\|w\\right\\|^2", block: true)]]

#text("This is closer to (1); we have fixed the left-hand side, but the right-hand side is still too weak. But we can amplify further, by exploiting an imbalance in a different symmetry, namely the homogenisation symmetry ")#mi("(v,w) \\mapsto (\\lambda v, \\frac{1}{\\lambda} w)")#text(" for a scalar ")#mi("\\lambda > 0")#text(", which preserves the left-hand side but not the right. Inserting this transform into (4) we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle v, w \\rangle\\right| \\leq \\frac{\\lambda^2}{2} \\left\\|v\\right\\|^2 + \\frac{1}{2\\lambda^2} \\left\\|w\\right\\|^2", block: true)]]

#text("where ")#mi("\\lambda > 0")#text(" is at our disposal to choose. We can optimise in ")#mi("\\lambda")#text(" by minimising the right-hand side, and indeed one easily sees that the minimum (or infimum, if one of v and w vanishes) is ")#tao-math("\\left\\|v\\right\\| \\left\\|w\\right\\|", block: false)#text(" (which is achieved when ")#tao-math("\\lambda = \\sqrt{\\left\\|w\\right\\|/\\left\\|v\\right\\|}", block: false)#text(" when ")#mi("v,w")#text(" are non-zero, or in an asymptotic limit ")#mi("\\lambda \\to 0")#text(" or ")#mi("\\lambda \\to \\infty")#text(" in the degenerate cases), and so we have amplified our way to the Cauchy-Schwarz inequality (1). [See also this ")#link("http://www.dpmms.cam.ac.uk/~wtg10/csineq.html")[#text("discussion by Tim Gowers ")]#text("on the Cauchy-Schwarz inequality.]")

#metadata(none) <tao-55cbc3e87d110a16246b>

#heading(level: 1)[#text("— Amplification via phase, homogeneity, or dilation symmetry —")]

#text("Many similar examples of amplification are used routinely to prove the basic inequalities in harmonic analysis. For instance to deduce the complex-valued triangle inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\int_X f(x)\\ d\\mu(x)\\right| \\leq \\int_X |f(x)|\\ d\\mu(x)", block: true)]]

#text("(where ")#mi("(X,\\mu)")#text(" is a measure space and f is absolutely integrable) from its real-valued counterpart, we first apply the latter inequality to ")#mi("\\text{Re}(f)")#text(" to obtain")

#align(center)[#tao-math("\\left|\\text{Re} \\int_X f(x)\\ d\\mu(x)\\right| \\leq \\int_X |\\text{Re} f(x)|\\ d\\mu(x)", block: false)#text(".")]

#text("To make the right-hand side phase-rotation-invariant, we crudely bound ")#tao-math("\\left|\\text{Re} f(x)\\right|", block: false)#text(" by ")#tao-math("\\left|f(x)\\right|", block: false)#text(", obtaining")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{Re} \\int_X f(x)\\ d\\mu(x)\\right| \\leq \\int_X |f(x)|\\ d\\mu(x)", block: true)]]

#text("and then one can arbitrage the imbalance in phase rotation symmetry to obtain (5). For another well-known example, to prove ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder’s inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\int_X f(x) g(x)\\ d\\mu(x) \\leq \\left\\|f\\right\\|_{L^p(X,d\\mu)} \\left\\|g\\right\\|_{L^q(X,d\\mu)}", block: true)]]

#text("for non-negative measurable ")#mi("f, g")#text(" and dual exponents ")#mi("1 \\leq p,q \\leq \\infty")#text(", one can begin with the elementary (weighted) arithmetic mean-geometric mean inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("ab \\leq \\frac{1}{p} a^p + \\frac{1}{q} b^q")]]

#text("for non-negative a,b (which follows from the convexity of the function ")#mi("\\theta \\mapsto a^\\theta b^{1-\\theta}")#text(", which in turn follows from the convexity of the exponential function) to obtain the inequality")

#align(center)[#tao-math("\\int_X f(x) g(x)\\ d\\mu(x) \\leq \\frac{1}{p} \\left\\|f\\right\\|_{L^p(X,d\\mu)}^p + \\frac{1}{q} \\left\\|g\\right\\|_{L^q(X,d\\mu)}^q", block: false)#text(".")]

#text("This inequality is weaker than (6) (because of (7)); but if one amplifies by arbitraging the imbalance in the homogenisation symmetry ")#mi("(f,g) \\mapsto (\\lambda f, \\frac{1}{\\lambda} g)")#text(" one obtains (6). As a third example, the ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev embedding inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|f\\right\\|_{L^q({\\Bbb R}^d)} \\leq C_{p,q,d} (\\left\\|f\\right\\|_{L^p({\\Bbb R}^d)} + \\left\\| \\nabla f \\right\\|_{L^p({\\Bbb R}^d)}),", block: true)]]

#text("which is valid for ")#mi("1 < p < q \\frac{1}{p} - \\frac{1}{d}")#text(" (and also valid in some endpoint cases) and all test functions (say) f on ")#mi("{\\Bbb R}^d")#text(", can be amplified to obtain the ")#emph[#text("Gagliardo-Nirenberg inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\|f\\right\\|_{L^q({\\Bbb R}^d)} \\leq C_{p,q,d} \\left\\|f\\right\\|_{L^p({\\Bbb R}^d)}^{1-\\theta} \\left\\| \\nabla f \\right\\|_{L^p({\\Bbb R}^d)}^\\theta", block: true)]]

#text("where ")#mi("0 < \\theta < 1")#text(" is the number such that ")#mi("\\frac{1}{q} = \\frac{1}{p} - \\frac{\\theta}{d}")#text(", by arbitraging the action of the dilation group ")#mi("f(x) \\mapsto f(\\lambda x)")#text(". (In this case, the dilation action does not leave either the LHS or RHS of (8) invariant, but it affects the LHS in a well controlled manner, which can be normalised out by dividing by a suitable power of ")#mi("\\lambda")#text(".) The same trick, incidentally, reveals why the Sobolev embedding inequality fails when ")#mi("q < p")#text(" or when ")#mi("\\frac{1}{q} < \\frac{1}{p} - \\frac{1}{d}")#text(", because in these cases it leads to an absurd version of the Gagliardo-Nirenberg inequality. Observe also that the Gagliardo-Nirenberg inequality (9) is dimensionally consistent; the dilation action affects both sides of the inequality in the same way. (The weight of the representation of the dilation action on an expression is the same thing as the exponent of the length unit that one assigns to the dimension of that expression.) More generally, arbitraging a dilation symmetry allows a dimensionally consistent inequality to emerge from a dimensionally inconsistent (or dimensionally inefficient) one.")

#heading(level: 1)[#text("— Amplification using linearity —")]

#text("Another powerful source of amplification is ")#emph[#text("linearity")]#text(" (the principle of superposition). A simple example of this is ")#emph[#text("depolarisation")]#text(". Suppose one has a symmetric bilinear form ")#mi("B(f,g): X \\times X \\to {\\Bbb R}")#text(" from a normed vector space X to the real numbers, and one has already proven the polarised inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|B(f,f)\\right| \\leq A \\left\\|f\\right\\|_X^2", block: true)]]

#text("for all f in X. One can amplify this by replacing f with f+cg for arbitrary f, g in X and a real parameter c, obtaining")

#align(center)[#tao-fit-display[#tao-math("\\left|B(f,f)+2c B(f,g) + c^2 B(g,g)\\right| \\leq A (\\left\\|f\\right\\|_X+\\left|c\\right| \\left\\|g\\right\\|_X)^2.", block: true)]]

#text("Optimising this in c (e.g. taking ")#tao-math("c := \\left\\|f\\right\\|_X/\\left\\|g\\right\\|_X", block: false)#text(") and using the triangle inequality, one eventually obtains the amplified (depolarised) inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|B(f,g)\\right| \\leq C A \\left\\|f\\right\\|_X \\left\\|g\\right\\|_X", block: true)]]

#text("for some absolute constant C.")

#text("For a slightly more sophisticated example, suppose for instance that one has a linear operator ")#mi("T: L^p(X) \\to L^p(Y)")#text(" for some ")#mi("0 < p < \\infty")#text(" and some measure spaces X,Y, and that one has established a scalar estimate of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| Tf \\right\\|_{L^p(Y)} \\leq A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for arbitrary scalar functions f. Then by replacing ")#mi("f")#text(" by a signed sum ")#mi("\\sum_{n=1}^N \\epsilon_n f_n")#text(", where ")#mi("f_1,\\ldots ,f_N")#text(" are arbitrary functions in ")#mi("L^p(X)")#text(" and ")#mi("\\epsilon_n \\in \\{-1,+1\\}")#text(" are signs, and using linearity, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{n=1}^N \\epsilon_n Tf_n \\right\\|_{L^p(Y)} \\leq A \\left\\| \\sum_{n=1}^N \\epsilon_n f_n \\right\\|_{L^p(X)}.", block: true)]]

#text("If we raise this to the ")#mi("p^{th}")#text(" power, take the ")#mi("\\epsilon_n")#text(" to be random (Bernoulli) signs (in order to avoid unexpectedly large cancellations in the series), and then take expectations of both sides, we obtain")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left\\| \\sum_{n=1}^N \\epsilon_n Tf_n \\right\\|_{L^p(Y)}^p \\leq A^p {\\Bbb E}\\left\\| \\sum_{n=1}^N \\epsilon_n f_n \\right\\|_{L^p(X)}^p.", block: true)]]

#text("If one then uses ")#link("http://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(" to compute the expectations, one ends up with the vector valued estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{n=1}^N \\left|Tf_n\\right|^2)^{1/2} \\right\\|_{L^p(Y)} \\leq C_p A \\left\\| (\\sum_{n=1}^N \\left|f_n\\right|^2)^{1/2} \\right\\|_{L^p(X)}", block: true)]]

#text("for some constant ")#mi("C_p")#text(" depending only on p (in particular, it is independent of N). We can then use the monotone convergence theorem to amplify the finite sum to an infinite sum, thus")

#align(center)[#tao-math("\\left\\| (\\sum_{n=1}^\\infty \\left|Tf_n\\right|^2)^{1/2} \\right\\|_{L^p(Y)} \\leq C_p A \\left\\| (\\sum_{n=1}^\\infty \\left|f_n\\right|^2)^{1/2} \\right\\|_{L^p(X)}", block: false)#text(".")]

#text("Comparing this to (10) we see that we have amplified a scalar inequality (in which the unknown function f takes values in the real or complex numbers) to a vector-valued inequality (in which we have a sequence ")#mi("f = (f_n)_{n=1}^\\infty")#text(" taking values in the Hilbert space ")#mi("l^2({\\Bbb N})")#text("). [This particular amplification was first observed by Marcinkiewicz and Zygmund.]")

#text("If the estimate one is studying involves “localised” operators or norms, then one can use linearity to amplify a global estimate into a more localised one. For instance, let us return to the Sobolev inequality (8). We can establish a partition of unity ")#mi("1 = \\sum_{n \\in {\\Bbb Z}^d} \\psi(x-n)")#text(" for some bump function ")#mi("\\psi")#text(", then we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{L^q({\\Bbb R}^d)} \\leq C_{d,q,\\psi} (\\sum_{n \\in {\\Bbb Z}^d} \\left\\| \\psi(\\cdot-n) f \\right\\|_{L^q({\\Bbb R}^d)}^q)^{1/q}.", block: true)]]

#text("Applying the Sobolev inequality (8) to each localised function ")#mi("\\psi(\\cdot-n) f")#text(" and then summing up, one obtains the localised Sobolev inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\Bbb R}^d)} \\leq C^{\\prime}_{p,q,d} (\\sum_{n \\in {\\Bbb Z}^d} (\\left\\|f\\right\\|_{L^p(Q_n)} + \\left\\| \\nabla f \\right\\|_{L^p(Q_n)})^q)^{1/q},", block: true)]]

#text("where ")#mi("Q_n")#text(" is the cube of sidelength 1 centred at n. This estimate is a little stronger than (8), because the ")#mi("l^q")#text(" summation norm is smaller than the ")#mi("l^p")#text(" summation norm.")

#heading(level: 1)[#text("— Amplification via translation invariance —")]

#text("If ")#mi("T")#text(" is a translation-invariant operator on ")#mi("{\\Bbb R}^n")#text(" which is not identically zero, one can automatically rule out a large variety of estimates concerning T due to their incompatibility with translation invariance (they would amplify themselves into an absurd estimate). For instance, it will not be possible to establish any weighted estimate involving power weights such as ")#tao-math("(1+\\left|x\\right|)^\\alpha", block: false)#text(" in which there is a higher exponent on the left. More precisely if ")#mi("\\alpha > \\beta")#text(" are real numbers and ")#mi("0 < p,q < \\infty")#text(", then it is not possible for any estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (1+\\left|x\\right|)^{\\alpha} Tf \\right\\|_{L^q({\\Bbb R}^n)} \\leq C_{p,q,\\alpha,\\beta,n} \\left\\|(1+\\left|x\\right|)^\\beta f\\right\\|_{L^p({\\Bbb R}^n)}", block: true)]]

#text("to be true. Indeed, if such an estimate was true, then by using the translation invariance we can amplify the above estimate to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (1+\\left|x-x_0\\right|)^\\alpha Tf \\right\\|_{L^q({\\Bbb R}^n)} \\leq C_{p,q,\\alpha,\\beta,n} \\left\\|(1+\\left|x-x_0\\right|)^\\beta f\\right\\|_{L^p({\\Bbb R}^n)}", block: true)]]

#text("for any ")#mi("x_0 \\in {\\Bbb R}^n")#text(". But if one fixes f and lets ")#mi("x_0")#text(" go to infinity, we see that the right-hand side grows like ")#tao-math("\\left|x_0\\right|^\\beta", block: false)#text(" while the left-hand side grows like ")#tao-math("\\left|x_0\\right|^\\alpha", block: false)#text(" (unless Tf vanishes entirely), leading to a contradiction.")

#text("[There is a Fourier dual to the above principle, familiar to experts in the analysis of PDEs, which asserts that a function space norm with a low number of derivatives (i.e. a low-regularity norm) cannot control a norm with a high number of derivatives. Here, the underlying symmetry that drives this principle is modulation invariance rather than translation invariance.]")

#text("One can obtain particularly powerful amplifications by combining translation-invariance with linearity, because one can now consider not just translates ")#mi("f(x-x_0)")#text(" of a single function f, but also consider superpositions ")#mi("\\sum_{n=1}^N c_n f(x-x_n)")#text(" of such functions. For instance, we have the principle (which I believe was first articulated by Littlewood) that a non-trivial translation-invariant linear operator T can only map ")#mi("L^p({\\Bbb R}^d)")#text(" to ")#mi("L^q({\\Bbb R}^d)")#text(" when ")#mi("q \\geq p")#text(". (Littlewood summarised this principle as “the higher exponents are always on the left”.) To see this, suppose that we had an estimate of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| Tf \\right\\|_{L^q({\\Bbb R}^d)} \\leq A \\left\\|f\\right\\|_{L^p({\\Bbb R}^d)}.", block: true)]]

#text("We can amplify this estimate by replacing ")#mi("f(x)")#text(" by")#linebreak()#text(" ")#mi("\\sum_{n=1}^N f(x-x_n)")#text(", where N is some integer and ")#mi("x_1,\\ldots,x_N")#text(" are widely separated points. If these points are sufficiently far apart, then the RHS of (11) is comparable to ")#tao-math("A N^{1/p} \\left\\|f\\right\\|_{L^p({\\Bbb R}^d)}", block: false)#text(", whereas the LHS is comparable to")#linebreak()#text(" ")#tao-math("N^{1/q} \\left\\| Tf \\right\\|_{L^q({\\Bbb R}^d)}", block: false)#text(" (note how this uses both the translation-invariance and linearity of T). Thus in the limit we obtain")

#align(center)[#tao-fit-display[#tao-math("N^{1/q} \\left\\| Tf \\right\\|_{L^q({\\Bbb R}^d)} \\leq A N^{1/p} \\left\\|f\\right\\|_{L^p({\\Bbb R}^d)}.", block: true)]]

#text("Letting N go to infinity, we obtain a contradiction unless ")#mi("q \\geq p")#text(" (or unless T is identically zero).")

#text("The combination of translation invariance and linearity is so strong that it can amplify even a very qualitative estimate into a quantitative one. A good example of this is ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("Stein’s maximal principle")]#text(". Suppose we have some maximal operator ")#tao-math("M f := \\sup_n \\left|T_n f\\right|", block: false)#text(" on some compact group G with normalised Haar measure dm, where the ")#mi("T_n")#text(" are a sequence of translation-invariant operators which are uniformly bounded on some ")#mi("L^p(G)")#text(" space for some ")#mi("1 < p \\leq 2")#text(". Suppose we are given the very weak information that ")#mi("Mf")#text(" is finite almost everywhere for every ")#mi("f \\in L^p(G)")#text(". (This is for instance the case if we know that ")#mi("T_n f")#text(" converge pointwise almost everywhere.) Miraculously, this qualitative hypothesis can be amplified into a much stronger quantitative one, namely that ")#mi("M")#text(" is of weak type ")#mi("(p,p)")#text(":")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("m(\\{ x \\in G: Mf(x) \\geq \\lambda \\}) \\leq\\frac{C}{\\lambda^p} \\left\\|f\\right\\|_{L^p(G)}^p.", block: true)]]

#text("To see this, suppose for contradiction that (12) failed for any C; by homogeneity, it would also fail even when restricted to the case ")#mi("\\lambda = 1")#text(". What this means is that for any ")#mi("\\delta > 0")#text(", there exists ")#mi("f_\\delta")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| f_\\delta \\right\\|_{L^p(G)}^p < \\delta m( E_\\delta ),", block: true)]]

#text("where ")#mi("E_\\delta")#text(" is the set where ")#mi("Mf_\\delta > 1")#text(".")

#text("At present, ")#mi("E_\\epsilon")#text(" could be a very small subset of G, although we know that it has positive measure. But we can amplify this set to be very large by the following trick: pick an integer N comparable to ")#mi("1/m(E_\\delta)")#text(", select N random shifts ")#mi("g_1,\\ldots,g_N \\in G")#text(" and random signs ")#mi("\\epsilon_1,\\ldots,\\epsilon_N \\in \\{-1,+1\\}")#text(" and replace ")#mi("f_\\delta")#text(" by the randomised sum ")#mi("F_\\delta := \\sum_{n=1}^N \\epsilon_n f_\\delta(g_n^{-1} \\cdot)")#text(". This sum will tend to be large (greater than or comparable to 1) on most of the union ")#mi("\\bigcup_{n=1}^N g_n \\cdot E_\\epsilon")#text("; this can be made precise using Khintchine’s inequality. On the other hand, another application of Khintchine’s inequality using (13) shows that ")#mi("F_\\delta")#text(" has an ")#mi("L^p")#text(" norm of ")#mi("O(\\delta^{1/p})")#text(" on the average. Thus we have constructed functions f of arbitrarily small ")#mi("L^p")#text(" norm whose maximal function Mf is bounded away from zero on a set of measure bounded away from zero. From this and some minor additional tricks it is not difficult to then construct a function f in ")#mi("L^p")#text(" whose maximal function is infinite on a set of positive measure, leading to the desired contradiction.")

#heading(level: 1)[#text("— The tensor power trick —")]

#text("We now turn to a particularly cute source of amplification, namely the tensor power operation ")#mi("f \\mapsto f^{\\otimes M}")#text(" which takes a complex-valued function ")#mi("f: X \\to {\\Bbb C}")#text(" on some set X and replaces it with a tensor power ")#mi("f^{\\otimes M}: X^M \\to {\\Bbb C}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("f^{\\otimes M}(x_1,\\ldots,x_M) := f(x_1) \\ldots f(x_M).")]]

#text("If one has an estimate for which only one of the sides behaves nicely under tensor powers, then there can be some opportunity for arbitrage. For instance, suppose we wanted to prove the ")#link("http://en.wikipedia.org/wiki/Hausdorff-Young_inequality")[#text("Hausdorff-Young inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| \\hat f \\right\\|_{l^{p^{\\prime}}(\\hat G)} \\leq \\left\\|f\\right\\|_{L^p(G)}", block: true)]]

#text("on arbitrary finite additive groups G and all ")#mi("1 \\leq p \\leq 2")#text(", where ")#mi("p^{\\prime} = p/(p-1)")#text(" is the dual exponent of p, ")#mi("\\hat G")#text(" is the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" of G (i.e. the group of characters on G), we give G normalised counting measure, and ")#tao-math("\\hat f(\\chi) := \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x) \\overline{\\chi(x)}", block: false)#text(" is the Fourier transform on G. If we had the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(", we could quickly deduce (14) from the trivial inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\| \\hat f \\right\\|_{l^\\infty(\\hat G)} \\leq \\left\\|f\\right\\|_{L^1(G)}", block: true)]]

#text("and the ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel identity")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16);")])
#tao-math("\\left\\| \\hat f \\right\\|_{l^2(\\hat G)} \\leq \\left\\|f\\right\\|_{L^2(G)}", block: true)]]

#text("indeed, this is one of the textbook applications of that theorem. But suppose for some reason one did not wish to use the Riesz-Thorin theorem (perhaps in a desire to avoid “non-elementary” methods, such as complex analysis), and instead wished to use the more elementary ")#link("http://en.wikipedia.org/wiki/Marcinkiewicz_interpolation_theorem")[#text("Marcinkiewicz interpolation theorem")]#text(". Then, at first glance, it appears that one can only conclude the weaker estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{l^{p^{\\prime}}(\\hat G)} \\leq C_p \\left\\|f\\right\\|_{L^p(G)}", block: true)]]

#text("for some constant ")#mi("C_p > 1")#text(". However, we can exploit the fact that the Fourier transform commutes with tensor powers. Indeed, by applying the above inequality with f replaced by ")#mi("f^{\\otimes M}")#text(" (and G replaced by ")#mi("G^M")#text(") we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{l^{p^{\\prime}}(\\hat G)}^M \\leq C_p \\left\\|f\\right\\|_{L^p(G)}^M", block: true)]]

#text("for every ")#mi("M \\geq 1")#text("; taking ")#mi("M^{th}")#text(" roots and then letting M go to infinity we obtain (14); the tensor power trick has “magically” deleted the constant ")#mi("C_p")#text(" from the inequality. More generally, one can use the tensor power trick to ")#emph[#text("deduce")]#text(" the Riesz-Thorin interpolation theorem from the Marcinkiewicz interpolation theorem (the key point being that the ")#mi("(L^p,L^q)")#text(" operator norm of a tensor power ")#mi("T^{\\otimes M}")#text(" of a linear operator T is just the ")#mi("M^{th}")#text(" power of the operator norm of the original operator T). This gives a proof of the Riesz-Thorin theorem that does not require complex analysis.")

#text("Actually, the tensor power trick does not just make constants disappear; it can also get rid of logarithms. Because of this, we can make the above argument even more elementary by using a very crude form of the Marcinkiewicz interpolation argument. Indeed, suppose that f is a quasi-step function, or more precisely that it is supported on some set E in G and takes values between A and 2A for some ")#mi("A > 0")#text(". Then from (15) and (16) we see that ")#tao-math("\\left\\|\\hat f\\right\\|_{l^\\infty(\\hat G)} = O( A \\left|E\\right|/\\left|G\\right| )", block: false)#text(" and ")#tao-math("\\left\\|\\hat f\\right\\|_{l^2(\\hat G)} = O( A (\\left|E\\right|/\\left|G\\right|)^{1/2} )", block: false)#text(", and hence ")#tao-math("\\left\\|\\hat f\\right\\|_{l^{p^{\\prime}}(\\hat G)} =O( A (\\left|E\\right|/\\left|G\\right|)^{1/p} )", block: false)#text(". Now if f is not a quasi-step function, one can decompose it into ")#tao-math("O(1+\\log \\left|G\\right|)", block: false)#text(" such functions by the “wedding cake” decomposition (dividing the range of |f| into dyadic intervals from ")#tao-math("\\left\\|f\\right\\|_{L^\\infty}", block: false)#text(" to ")#tao-math("\\left\\|f\\right\\|_{L^\\infty}/\\left|G\\right|^{100}", block: false)#text("; the portion of |f| which is less than ")#tao-math("\\left\\|f\\right\\|_{L^\\infty}/\\left|G\\right|^{100}", block: false)#text(" can be easily dealt with by crude methods). From the triangle inequality we then conclude the weak Hausdorff-Young inequality")

#align(center)[#tao-math("\\left\\| \\hat f \\right\\|_{l^{p^{\\prime}}(\\hat G)} \\leq C_p (1+\\log \\left|G\\right|) \\left\\|f\\right\\|_{L^p(G)}", block: false)#text(".")]

#text("If one runs the tensor power trick again, one can eliminate both the constant factor ")#mi("C_p")#text(" and the logarithmic factor ")#tao-math("1 + \\log \\left|G\\right|", block: false)#text(" and recover (14) (basically because ")#mi("M^{1/M}")#text(" converges to 1 as M goes to infinity). [More generally, the tensor power trick can convert restricted or weak-type estimates into strong-type estimates.]")

#text("The deletion of the constant ")#mi("C_p")#text(" may seem minor, but there are some things one can do with a sharp estimate that one cannot with a non-sharp one. For instance, by differentiating (14) at p=2 (where equality holds) one can obtain the ")#emph[#text("entropy uncertainty principle")]

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\chi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^2 \\log \\frac{1}{\\left|\\hat f(\\xi)\\right|^2} + \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^2 \\log \\frac{1}{\\left|f(x)\\right|^2} \\geq 2 \\log \\left|G\\right|", block: true)]]

#text("whenever we have the normalisation ")#tao-math("\\left\\|f\\right\\|_{L^2(G)}=1", block: false)#text(". (More generally, estimates involving ")#link("http://en.wikipedia.org/wiki/Information_entropy")[#text("Shannon entropy")]#text(" tend to be rather amenable to the tensor power trick.)")

#text("[I should remark that in Euclidean space, the constant in Hausdorff-Young ")#link("http://www.ams.org/mathscinet-getitem?mr=385455")[#text("can be improved to below 1")]#text(", but this requires some particularly Euclidean devices, such as the use of Gaussians, although this is not too dissimilar as there are certainly many connections between Gaussians and tensor products (cf. the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text("). All of the above discussion also has an analogue for ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]#text(".]")

#text("The tensor power trick also allows one to ")#emph[#text("disprove ")]#text("certain estimates. Observe that if two functions f, g on a finite additive group G such that ")#tao-math("\\left|f(x)\\right| \\leq g(x)", block: false)#text(" for all x (i.e. g ")#emph[#text("majorises")]#text(" f), then from Plancherel’s identity we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{l^2(\\hat G)} \\leq \\left\\| \\hat g \\right\\|_{l^2(\\hat G)}", block: true)]]

#text("and more generally (by using the fact that the Fourier transform intertwines convolution and multiplication) that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{l^p(\\hat G)} \\leq \\left\\| \\hat g \\right\\|_{l^p(\\hat G)}", block: true)]]

#text("for all even integers ")#mi("p = 2, 4, 6, \\ldots")#text(". Hardy and Littlewood conjectured that a similar bound held for all ")#mi("2 \\leq p < \\infty")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{l^p(\\hat G)} \\leq C_p \\left\\| \\hat g \\right\\|_{l^p(\\hat G)}.", block: true)]]

#text("But if such a bound held, then by the tensor power trick one could delete the constant ")#mi("C_p")#text(". But then a direct computation (for instance, inspecting what happens when f is infinitesimally close to g) shows that this amplified estimate fails, and so the Hardy-Littlewood majorant conjecture is false. (With a little more work, one can then transfer this failure from finite abelian groups G to other groups, such as the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" or cyclic groups ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", which do not obviously admit tensor product structure; this was first done ")#link("http://www.ams.org/mathscinet-getitem?mr=320636")[#text("by Bachelis")]#text(", and with stronger quantitative estimates ")#link("http://arxiv.org/abs/math/0207226")[#text("by Mockenhaupt-Schlag")]#text(" and ")#link("http://arxiv.org/abs/math/0303244")[#text("by Green-Ruzsa")]#text(".)")

#text("The tensor product trick is also widely used in additive combinatorics (I myself learned this trick from a ")#link("http://www.ams.org/mathscinet-getitem?mr=1420216")[#text("survey paper of Ruzsa")]#text("). Here, one deals with sets A rather than functions f, but the idea is still the same: replace A by the Cartesian power ")#mi("A^M")#text(", see what estimate one gets, and let ")#mi("M \\to \\infty")#text(". There are many instances of this trick in the literature, but I’ll just describe one representative one, ")#link("http://www.ams.org/mathscinet-getitem?mr=1420216")[#text("due to Ruzsa")]#text(". An important inequality of Plünnecke asserts, among other things, that for finite non-empty sets A, B of an additive group G, and any positive integer k, the iterated sumset ")#mi("kB = B + \\ldots + B")#text(" obeys the bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|kB\\right| \\leq \\frac{\\left|A+B\\right|^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("(This inequality, incidentally, is itself proven using a version of the tensor power trick, in conjunction with ")#link("http://en.wikipedia.org/wiki/Marriage_theorem")[#text("Hall’s marriage theorem")]#text(", but never mind that here.) This inequality can be amplified to the more general inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{\\left|A+B_1\\right| \\ldots \\left|A+B_k\\right|}{\\left|A\\right|^{k-1}}", block: true)]]

#text("via the tensor power trick as follows. Applying (17) with ")#mi("B := B_1 \\cup \\ldots \\cup B_k")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{(\\left|A+B_1\\right| + \\ldots + \\left|A+B_k\\right|)^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("The right-hand side looks a bit too big, but this is the same problem we encountered with the Cauchy-Schwarz or Holder inequalities, and we can resolve it in a similar way (i.e. by arbitraging homogeneity). If we replace G with the larger group ")#mi("G \\times {\\Bbb Z}^k")#text(" and replace each set ")#mi("B_i")#text(" with the larger set ")#mi("B_i \\times \\{ e_i, 2e_i, \\ldots, N_i e_i \\}")#text(", where ")#mi("e_1,\\ldots,e_k")#text(" is the standard basis for ")#mi("{\\Bbb Z}^k")#text(" and ")#mi("N_i")#text(" are arbitrary positive integers (and replacing A with ")#mi("A \\times \\{0\\}")#text("), we obtain")

#align(center)[#tao-fit-display[#tao-math("N_1 \\ldots N_k \\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{(N_1 \\left|A+B_1\\right| + \\ldots + N_k \\left|A+B_k\\right|)^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("Optimising this in ")#mi("N_1,\\ldots,N_k")#text(" (basically, by making the ")#tao-math("N_i \\left|A+B_i\\right|", block: false)#text(" close to constant; this is a general rule in optimisation, namely that to optimise X+Y it makes sense to make X and Y comparable in magnitude) we obtain the amplified estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq C_k \\frac{\\left|A+B_1\\right| \\ldots \\left|A+B_k\\right|}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("for some constant ")#mi("C_k")#text("; but then if one replaces ")#mi("A, B_1, \\ldots, B_k")#text(" with their Cartesian powers ")#mi("A^M, B_1^M, \\ldots, B_k^M")#text(", takes ")#mi("M^{th}")#text(" roots, and then sends M to infinity, we can delete the constant ")#mi("C_k")#text(" and recover the inequality.")

#text("[")#emph[#text("Update")]#text(", Sep 5: Optimal value for ")#mi("\\lambda")#text(" in the proof of Cauchy-Schwarz fixed. (Thanks to furia_kucha for the correction.)]")

#text("[")#emph[#text("Update")]#text(", Sep 10: Proof of Ruzsa’s inequality fixed. (Thanks to Van Vu for the correction.)]")

#text("[")#emph[#text("Update")]#text(", Sep 11: Depolarisation example added, and then corrected. (Thanks to Andy Cotton-Clay for the correction.)]")

#heading(level: 1)[#text("Comments (92)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-40943")[#strong[#text("The Role of Amplifiers in Science « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")]

#text("[…] Tensor Power Trick This is a trick that is explained beautifully in Terry Tao’s great blog. See his post for the details, but here let me try to hopefully explain what is up. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The least quadratic nonresidue, and the square root barrier « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-41071")[#strong[#text("The least quadratic nonresidue, and the square root barrier « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2009")])]

#text("[…] of two quadratic residues is again a quadratic residue. One way to use this sort of structure to amplify bad behaviour in a single short interval into bad behaviour across many short intervals. Because of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0afe674e2c853e9e295f7f676f20e24e0bc124693975dbc4932739adac2f362-e9ccd92a4c970b11469571570e1247f1522cb3805d4c3ef75595d819e6f16b5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Gaussian Correlation Conjecture « Almost Sure")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-41606")[#strong[#text("The Gaussian Correlation Conjecture « Almost Sure")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")])]

#text("[…] in the proof of 2 is a tensor power trick along the same lines as those described by Terence Tao in his blog. This will give the following result. Lemma 1 Let be positive constants with as goes to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vorlesung Funktionalanalysis: Erste Etappe « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-42419")[#strong[#text("Vorlesung Funktionalanalysis: Erste Etappe « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2009")])]

#text("[…] die Cauchy-Schwarz Ungleichung. In diesem Zusammenhang möchte ich auf den Interessanten Artikel Amplification, Arbitrage and the Tensor Power Trick von T. Tao hinweisen, in dem die Methodik des Beweises der Cauchy-Schwarz Ungleichung in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-42651")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Are the techniques posted here of any relevance to entropy power inequalities arising in network information theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Montgomery’s uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-119928")[#strong[#text("Montgomery’s uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2012")])]

#text("[…] which one dilates to (and replaces each frequency by their roots), and then sending (cf. the tensor product trick). But we will not need this refinement […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ca9b21ed639971fe0dd8f127397a44d17587342eb081208f5908fdd6567e0-67b88326b3417e4cea1a4c861181ac9944d6b619a7c5e33a6a75bcd67c609bf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tomer Shalev")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-135667")[#strong[#text("Tomer Shalev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2012")])]

#text("Hi Prof Tao,")

#text("regarding amplification of (17).")

#text("can you elaborate on the optimization of ")#mi("N_1,...,N_k")#linebreak()#text(" it seems strange to pick a near global constant when one")#linebreak()#text(" knows that ")#tao-math("\\left|A + B_i\\right|", block: false)#text(" can be big.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-135669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2012")])]

#text("Sorry, by “constant” I meant “constant in i” rather than “absolute constant”. The point is that the arithmetic mean-geometric mean inequality ")#mi("k^k x_1 \\ldots x_k \\leq (x_1 + \\ldots + x_k)^k")#text(" is close to equality when the ")#mi("x_i")#text(" are comparable, no matter how large the ")#mi("x_i")#text(" are. In this particular application, we want to reverse the AM-GM inequality with ")#tao-math("x_i := N_i \\left|A+B_i\\right|", block: false)#text(", so the optimisation proceeds by setting the ")#mi("x_i")#text(" to be comparable, e.g. setting ")#tao-math("N_i := \\lfloor L / \\left|A+B_i\\right| \\rfloor", block: false)#text(" for some large parameter L.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-211409")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] to amplify a hybrid inequality into a dimensionally pure one by optimising over all rescalings; see this previous blog post for a discussion of this trick (which, among other things, amplifies the inhomogeneous Sobolev […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/175329e76631e99c42f00eb217adf1b5c7766b03c233d516176db6b47a83b371-23e0f89fc4eff527bb12841bbfb57b068ed15ada5226b13f1dfb83ed82a68325.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorn")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-213578")[#strong[#text("Jorn")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2013")])]

#text("Another great example of amplification is the proof of Chernoff’s bound from Markov’s inequality in probability theory, which stunned me when I first came across it. Markov’s inequality states that $P(X \\ge a) \\le E(X)/a$ for non-negative random variables $X$. Using that $P(X \\ge a) = P(\\exp(\\theta X) \\ge \\exp(\\theta a))$ for any $\\theta > 0$, we find that $P(X \\ge a) \\le E(\\exp(\\theta X)) \\exp(-\\theta a)$, in which the parameter $\\theta > 0$ can be chosen freely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f387bf4b217b5a474ba5d19eda33906c172561d378bacf84dd05c90b6e45a7c7-cd6c0d024a1357027531e7df800758f186c9958e0e084c33941052ac40e1c388.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Denis Serre")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-218555")[#strong[#text("Denis Serre")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2013")])]

#text("Hi Terry,")

#text("Great post! I like your style and try to follow it closely.")

#text("Here are two examples of amplification, where the amplification trick gets rid of constants.")#linebreak()#text(" 1. The maximum principle for holomorphic functions in a disk ")#mi("D")#text(" (which could be another domain). Let ")#mi("z\\in D")#text(" and ")#mi("f:D\\rightarrow C")#text(" be a holomorphic function. Then Cauchy’s integral formula gives you an inequality ")#tao-math("\\left|f(z)\\right|\\leq C_z\\left\\|f\\right\\|", block: false)#text(", with respect to the sup-norm over the boundary. Apply the inequality to ")#mi("f^k")#text(", then take the ")#mi("k")#text("-th root. The constant is changed into ")#mi("C_z^{1/k}")#text(", which tends to ")#mi("1")#text(" as ")#mi("k")#text(" tends to infinity.")#linebreak()#text(" 2. In matrix analysis, let ")#mi("\\|\\cdot\\|")#text(" be an algebra norm over ")#mi("M_n(R)")#text(", that is ")#tao-math("\\left\\|AB\\right\\|\\leq\\left\\|A\\right\\|\\cdot\\left\\|B\\right\\|", block: false)#text(". Let ")#mi("\\rho(A)")#text(" denote the spectral radius of a matrix ")#mi("A")#text(" (which involves the modulus of complex eigenvalues too). Then ")#tao-math("\\rho(A)\\le\\left\\|A\\right\\|", block: false)#text(". This would be obvious if the norm was subordinated to a complex norm (take an eigenvector associated with an eigenvalue of maximal modulus, bla-bla). If not, take any such subordinated norm ")#mi("N")#text(", we thus have ")#mi("\\rho(A)\\le N(A)")#text(". By equivalence of norms, we obtain ")#tao-math("\\rho(A)\\le C\\left\\|A\\right\\|", block: false)#text(". Apply this to ")#mi("A^k")#text(", use ")#tao-math("\\left\\|A^k\\right\\|\\le\\left\\|A\\right\\|^k", block: false)#text(", then take the ")#mi("k")#text("-th root and let ")#mi("k")#text(" tend to infinity.")

#text("All the best,")

#text("Denis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-228782")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Strengthening inequalities: a mathematical trick (adapted from “Amplification, arbitrage, and the tensor power trick“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-228788")[#strong[#text("Strengthening inequalities: a mathematical trick | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] [1.9] Amplification, arbitrage, and the tensor power trick […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-239342")[#strong[#text("Monday Highlights | Pseudo-Polymath")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")]

#text("[…] A maths trick in narrative form. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-239344")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e266v1")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")]

#text("[…] A maths trick in narrative form. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-239491")[#strong[#text("Cauchy-Schwarz Inequality (and Amplification) | Math ∩ Programming")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")]

#text("[…] the same. What makes this proof stand out is its insightful technique, which I first read about on Terry Tao’s blog. He calls it “textbook,” and maybe it is for an analyst, but it’s still very […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real stable polynomials and the Kadison-Singer problem | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-249985")[#strong[#text("Real stable polynomials and the Kadison-Singer problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("[…] case of the Kadison-Singer paving conjecture, but we may use a number of standard maneuvers to amplify this to the full paving conjecture, loosely following the papers of Popa and of Akemann-Weaver. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-356110")[#strong[#text("Inequalities Using Symmetries | Ah, Math?")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")]

#text("[…] by Terence Tao’s post about amplification of inequalities (")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]#text(") I will give a quick proof of the AM-GM inequality, which says that for any list of nonnegative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-356155")[#strong[#text("Inequalities Using Symmetries | Ah, Math?")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")]

#text("[…] by Terence Tao’s post about amplification of inequalities (")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]#text(") I will give a quick proof of the AM-GM inequality, which says that for any sequence of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-451971")[#strong[#text("254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2015")])]

#text("[…] that the additional term could be deleted by an amplification trick similar to those discussed in this previous post). See this survey of Montgomery for these results and on the (somewhat complicated) evolution of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 1: Integration and expectation | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-460068")[#strong[#text("275A, Notes 1: Integration and expectation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] looks weaker than what we want to prove, but we can “amplify” this inequality to the full strength triangle inequality as follows. Replacing by for any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-472641")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("[…] eliminate this loss we can amplify the above argument by exploiting phase rotation. For any real , we can repeat the above arguments […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-480001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2017")])]

#text("Can this trick be used to show that ")#tao-math("\\left|\\langle v,w\\rangle\\right|=\\left\\|v\\right\\|\\left\\|w\\right\\|", block: false)#text(" (which is usually the second part of the textbook statement of the Cauchy inequality) implies that ")#mi("v,w")#text(" must be linearly dependent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-480003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2017")])]

#text("A typical “textbook” proof (e.g. Folland’s Real Analysis, or ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality#Second_proof")[#text("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality#Second_proof")]#text(") of the Cauchy-Schwarz inequality goes like this:")

#text("In order to show that ")#tao-math("\\left|\\langle x,y\\rangle\\right|\\leq \\left\\|x\\right\\|\\left\\|y\\right\\|", block: false)#text(", one assumes without loss of generality ")#mi("\\langle x,y\\rangle\\neq 0")#text(". By expanding")

#text("$\\displaystyle \\|x-t\\alpha y\\|^2\\geq 0$")

#text("where ")#tao-math("t=\\left\\|y\\right\\|^{-2}\\left|\\langle x,y\\rangle\\right|", block: false)#text(" and ")#tao-math("\\alpha=\\langle x,y\\rangle/\\left|\\langle x,y\\rangle\\right|", block: false)#text(", one can not only conclude that the Cauchy inequality is true ")#emph[#text("but also")]#text(" that the equality is true only when ")#mi("x,y")#text(" are linearly dependent.")

#text("The choice of ")#mi("t")#text(" and ")#mi("\\alpha")#text(" seem rather mysterious; one the other hand, the way one chooses ")#mi("\\lambda")#text(" and ")#mi("\\theta")#text(" in this excellent post is extraordinarily natural. However, maybe I miss something in the post; I don’t see how to conclude the “equality” part from your argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d479079cb9eb251583b10e8b083d251960910c49fdb267c850335c0a414a69f8-6846da9b4648e60130e8d8504e2517cc1608d506634cf7eff7ea832205c2887b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lowerbound")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-480227")[#strong[#text("lowerbound")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2017")])]

#text("Are any of these tricks available for lower bounds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An addendum to “arbitrage, amplification, and the tensor power trick” | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-485251")[#strong[#text("An addendum to “arbitrage, amplification, and the tensor power trick” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2017")])]

#text("[…] one of the earliest posts on this blog, I talked about the ability to “arbitrage” a disparity of symmetry in an inequality, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc714f2c5522d4bf41bc12663cccde217e6cc63f29dc76f424e8844fa4d0e426-95feda0ca4d01454336fb131bd34d94b0217b6fc9650df83be31be257de44bf6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-485330")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Hi, Prof. Tao. I think there is a typo after the step of using ‘Khintchine’s inequality to compute the expectations’ on eq. (10). I think It should become")#linebreak()#text(" ")#tao-math("\\left|\\left|(\\sum^N_{n=1} \\left|T f_n\\right|^2)^{1/2}\\right|\\right|^p_{L^p(Y)} \\leq C_p A \\left|\\left|(\\sum^N_{n=1} \\left|f_n\\right|^2)^{1/2}\\right|\\right|^p_{L^p(X)}", block: false)#text(".")#linebreak()#text(" In the article, it missed raising the RHS to the power of ")#mi("p")#text(".")#linebreak()#text(" Please correct me if I am wrong.")

#text("Thanks.")#linebreak()#text(" Anyway, thanks for this post. This is a really good post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64aa039296f3d7620ededebca302f10fc8e6fa951f4560ca77053c5a80676ef8-297099ea21231eb1547181ee612fae296b60928ac5f503a0a74ec057a84bd53c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-505599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2018")])]

#text("Dear Professor Tao")#linebreak()#text(" I am sorry for being of topic but this post opened my eyes on how to think about estimates. I am deeply grateful to you for the time and effort you put in writing these things. For people like me in 3rd world countries this is the only way to understand how to think about math and how to learn math.")

#text("Thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-509459")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("[…] strengthen it, or to locate interesting asymptotic special cases; I discuss these sorts of tricks in this post. This is particularly powerful with respect to the symmetry of taking tensor products, where it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FUA Kap05-AB01 „Hilberträume und deren Geometrie“ | UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-511034")[#strong[#text("FUA Kap05-AB01 „Hilberträume und deren Geometrie“ | UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2019")])]

#text("[…] Cauchy–Schwarz Ungleichung. In diesem Zusammenhang möchte ich auf den Interessanten Artikel Amplification, Arbitrage and the Tensor Power Trick von T. Tao hinweisen, in dem die Methodik des Beweises der Cauchy–Schwarz Ungleichung im […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Twisted convolution and the sensitivity conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-518973")[#strong[#text("Twisted convolution and the sensitivity conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("[…] amplify this to complex valued polynomials, we take advantage of phase rotation invariance. If is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5dba8f2327dc251ca254d8e0da04e23d821ba9b9d82c55bfe5611048e82ce9d-abd129eaded0c37cd0cfd24e489167557b25bec131fc963a56bc3ad9be81ea2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From Nielsen to Thurston by way of Cummings, ft Terry Tao – Julia Wolffe's Notes")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-520674")[#strong[#text("From Nielsen to Thurston by way of Cummings, ft Terry Tao – Julia Wolffe's Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2019")])]

#text("[…] so forth. A more advanced example: if the problem is invariant under tensor products, as per the tensor product trick, then one’s low dimensional objects should have a tiny bit of shadowing (or perhaps look like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc0087dd97d6dd95107914b2f1478cba8fa8d5dc5126796a11aff22a2c05b3c-51efdb7e1e6e2b05dbe987a4d15ee798562ab897def7b673d5a9793b900b8b39.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hausdorff-Young inequality and interpolation | Almost Originality")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-527196")[#strong[#text("Hausdorff-Young inequality and interpolation | Almost Originality")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2019")])]

#text("[…] one can remove whatever spurious constants obtained by using the tensor power trick (see Tao’s post about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 2: A little bit of complex and Fourier analysis | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-527883")[#strong[#text("254A, Supplement 2: A little bit of complex and Fourier analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2019")])]

#text("[…] weaker bound than what we want, but we can miraculously make the constant disappear by the “tensor power trick“. Namely, observe that if is a holomorphic function bounded in magnitude by on , and is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louis Nirenberg | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-537583")[#strong[#text("Louis Nirenberg | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("[…] inequality of Ladyzhenskaya) can be viewed as an amplification of the usual Sobolev inequality in this post. Another fundamentally useful inequality of Nirenberg is the John-Nirenberg inequality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-537647")[#strong[#text("A nifty proof of the Cauchy-Schwarz inequality – Maths to Share")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")]

#text("[…] blog post is entirely based on the start of this blog post by Terry Tao. I highly recommend reading the post. It gives an interesting insight into how Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-591035")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2020")])]

#text("In the displayed equation following “We can then use the monotone convergence theorem to amplify the finite sum to an infinite sum, thus”, there is an extra power of p on the left-hand side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05bba5db858b8a22975ccfc595ee746764497246245e9155b4c6b88011c0b768-1f8b53bef5d64df4c39fccebd366d71a2c0bb5037d3bc85c9c8f4a0e4b941d11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bart Simpsons")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-592583")[#strong[#text("Bart Simpsons")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("Looks like WordPress doesn’t like the LaTeX here, it’s full of formula doesn’t parse unfortunately.")

#emph[#text("[Sometimes individual wordpress rendering servers have temporary glitches. Right now it seems to be rendering fine. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boosting the van der Corput inequality using the tensor power trick | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-622841")[#strong[#text("Boosting the van der Corput inequality using the tensor power trick | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] While working on an ongoing research project, I recently found that there is a very simple way to get around the latter problem by exploiting the tensor power trick: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-638112")[#strong[#text("Amplification and the tensor power trick in complex analysis – Eureka!")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2021")]

#text("[…] this post we look at the amplification and the tensor power trick popularized by Terence Tao (")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]#text(") and of its application in complex […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-639985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2022")])]

#text("Dear Prof Tao,")

#text("You write in some old lecture notes “The tensor power trick seems like a magical trick at present, but is actually exploiting some basic results in information theory such as the Shannon entropy inequalities and the central limit theorem; it also combines well with vir- tually any inequality which involves Gaussians.” Can you please elaborate or give a reference?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-2/#comment-646177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2022")])]

#text("Dear Prof Tao,")#linebreak()#text(" Can you please give a concrete example for your argument why dimensional analysis works that you mentioned above?")

#emph[#text("[See ")#link("https://terrytao.wordpress.com/2012/12/29/a-mathematical-formalisation-of-dimensional-analysis/")[#text("my subsequent blog post")]#text(" on this topic. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8630")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("For some reason, most of the TeX in the post isn’t parsing. only a few of the early ones aer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8633")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Dear Suresh,")

#text("I could not reproduce this problem; the TeX seems fine to me. Perhaps it was some transient issue, but if others report it then I’ll try to see what I can do to fix it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8641")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Actually it works now: it probably was transient.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R. Eader")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8642")[#strong[#text("R. Eader")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("I wonder when will we start seeing references to blog entries in ‘real’ papers :)")

#text("Really interesting post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5acfe203771387ce155764a9d4668aa7c54a11d97a9d672d77eaaa5a982ec5f-832975b1bd676d449903f4ab62e64f8e8300ca34e0d7158b52ba4ac0f0bf6b9a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of furia_krucha")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8644")[#strong[#text("furia_krucha")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Small misprint: in Cauchy-Schwarz, minimum is achieved at $\\lambda^2 = \\|w\\|/\\|v\\|$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A B")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8651")[#strong[#text("A B")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("I must respectfully disagree with you on the “publication-quality” issue. With some cosmetic changes this can be an excellent expository paper. And if you think (as I do) that this does not look like your typical expository paper — it only shows that it’s important to publish it.")

#text("There are dozens of professors out there who will show this paper to hundreds of students (for their great benefit, I am sure), if it is ever published in a more traditional venue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8725")[#strong[#text("Thursday late night links « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")]

#text("[…] Terry Tao experiments with the medium of blogging–by writing expository posts on math tricks t…; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody asked me, but...")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8729")[#strong[#text("nobody asked me, but...")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("The blog entry is useful as is; why should it be “published” in a “traditional” venue? To give Prof. Tao additional headaches? To make it _less_ accessible (one might have to print it, or go to the library, or worry about some journal’s draconian copyright policies)? To make it expensive? To waste natural resources?")

#text("Welcome to the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8753")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2007")])]

#text("Some others have asked me (by email) regarding conversion of some of the blog posts here to a print form, for instance somehow creating a book version of this blog at some point, roughly in analogy with the conversion of lecture notes into book form. The main advantage I see for this is that it would create a permanent, stable, and citable reference for these articles; with a blog, there is always the risk that the web page goes defunct, and (more subtly) that the page changes over time, with no way to access older versions (unlike wiki-based pages such as Wikipedia or Scholarpedia). By the same token, though, the dynamic nature of the blog format, in particular the cycle of incorporating suggestions from the comments, could not be easily duplicated in that format. (For instance, I do not know what copyright issues would arise if one attempted to insert some of the blog comments here into a book.)")

#text("As the issue does not seem to need any urgent resolution, I have not come to a decision about this, but perhaps will revisit it in a few months when there are more articles here that might be convertible to a publishable format. Though if anyone else has some suggestions on this issue, I would be happy to hear them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8754")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2007")])]

#text("With respect to alternate modes of publication, I definitely think that a PDF version (possibly with the comments included, if feasible) could be a great idea. Although screen reading is doable, and the print-preview trick leads to readable/printable versions of the contents, I think having the posts accessible together in such a format could be very useful.")

#text("If done as an e-book, it wouldn’t necessarily have the disadvantage of being quickly outdated if produced purely electronically, in a way that could easily be kept up to date.")

#text("————————")#linebreak()#text(" More mathematically, here are some other examples of applications of the kinds of tricks described in the post:")

#text("(1) Deligne’s proof(s) of the RH over finite fields uses some kind of tensor power trick: roughly speaking, one needs to show that the eigenvalues ")#mi("\\alpha")#text(" of some operator are of modulus at most ")#mi("\\sqrt{q}")#text(", and the “trivial bound” is ")#mi("q")#text(". Moreover, it is shown that for ")#mi("\\alpha^k")#text(", ")#mi("k\\geq 1")#text(", one can get a bound ")#mi("q^{(k+1)/2}")#text("…")

#text("(2) Recently, Bernstein and Reznikov (“Analytic continuation of representations and estimates of automorphic forms”, Ann. of Math. 150, 1999) proved a very nice result concerning bounds for the coefficients of the spectral expansion of the square of a cusp form (for a subgroup of ")#mi("SL(2,R)")#text("), where the goal is to obtain a precise rate of exponential decay. One of their ideas was to use the fact that a certain function is both bounded by a Sobolev norm and invariant under a group action. The Sobolev norm is not invariant, thus the estimate can be “amplified” to estimate the function by the smallest")#linebreak()#text(" invariant norm, which is then proved to be much smaller than the “trivial” bound.")

#text("It’s also worth mentioning that the terminology “amplification method” has been used in analytic number theory in the last few years to refer to an idea (originally introduced by Iwaniec in “The spectral growth of automorphic ")#mi("L")#text("-functions”, J. reine angew. Math. 428 (1992), 139–159) that leads to a number of important estimates for (typically) special values of automorphic L-functions, especially in the context of the so-called subconvexity problem for estimating L-functions.")

#text("(For a survey of this method, one can see P. Michel’s Park City lectures in “Automorphic Forms and Applications”, edited by P. Sarnak and F. Shahidi, IAS/PCMS vol. 12.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8756")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2007")])]

#text("Hi Terry,")

#text("I agree with AB— with a few minor changes (like replacing links with brief statements of the cited named theorems), this would make for a wonderful Monthly paper. I’d like to see you add the Chauvenet Prize to your list of honors! (Has the Chauvenet Prize been discontinued? If so, it should be resurrected.)")

#text("This is the exactly kind of paper I found really inspiring as an undergraduate. (My analysis teachers at Cornell were Tony Knapp, Robert Strichartz and Eugene Dynkin, and this blog entry reminded me of how much I love analysis when I was an undergraduate— thanks!)")

#text("More tricks, please! This is great stuff, it really is!")

#text("I too would love to see the best of your blog posts collected someday in printed form. Unlike most other blog posts, I think only light editing would be required to enable them to form a fascinating and useful book.")

#text("I’d like to challenge readers who liked this entry as much as I did to add brief descriptions of their own favorite applications of “amplification”, after they’ve had some time to play around with applications! (Perhaps the best of these could be eventually added as additional examples if this entry appears in printed form.)")

#text("Regarding dimensional analysis: I think of this as a special case of Lie’s method of attacking differential equations by analyzing and exploiting their symmetries. Indeed, all the methods taught in undergraduate ODE courses can be regarded as special cases of his approach (which apply to PDEs, although certainly no magic bullet). See for example the readable UG textbook by Cantwell, Introduction to Symmetry Analysis, or various books by Olver or Ibragimov.")

#text("In view of an elementary connection between “entropy” and “asymmetry” known from group actions, and more sophisticated speculations from topos theory and tiling, I’ve long been intrigued by the idea that many mathematical arguments can be reformulated in a manner somewhat analogous to manipulating Rubik’s cube into a desired state, or moving around “tiles” on a table.")

#text("BTW, in a recent article by Brian Hayes, “Sorting out the Genome”, American Scientist 95 (2007), note that he is discusing what I have called the restoration problem for various sets of generators for the symmetric group (unsigned perms) and for its wreath product with C_2 (signed perms), and he illustrates the kind of “regularization” which can result from wreathing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuanglin Shao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8769")[#strong[#text("Shuanglin Shao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2007")])]

#text("Very nice post.")

#text("One more example to use the tensor power trick is in Terry’s own notes on Fourier Analysis[Page 12 on notes 1]")#linebreak()#text(" at")

#link("http://www.math.ucla.edu/~tao/247a.1.06f/")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/")]

#text("It is to prove the log-covexity of L^p norms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8809")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2007")])]

#text("On the copyright issue:")#linebreak()#text(" All original ideas appearing on this blog belong to the owner or renter")#linebreak()#text(" of the server on which this blog is running.")#linebreak()#text(" Scientific copyright customarily lasts 28 years. Theoretically, what")#linebreak()#text(" this means, is that after copyright of an article is ceded to a journal,")#linebreak()#text(" before those 28 years passed, it would be a plagiarism for anybody to:")#linebreak()#text(" 1. write another related paper with only minor changes,")#linebreak()#text(" 2. copy the content of the article into a book.")#linebreak()#text(" Practically, nobody complains that these fine rules for academic")#linebreak()#text(" conduct seem to be violated more and more often, due e.g., to peer")#linebreak()#text(" pressure, seen everywhere.")#linebreak()#text(" In particular, I don’t understand why arxiv is not deleting preprints")#linebreak()#text(" after they are published. I suppose physicists do not care about")#linebreak()#text(" rigour, as e.g., it is customary in their community to rename whole")#linebreak()#text(" theories.")#linebreak()#text(" These bits and pieces I found on the net, and if they are incorrect or")#linebreak()#text(" there is new legislation on these matters, I would like to learn about it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody asked me, but...")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8812")[#strong[#text("nobody asked me, but...")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2007")])]

#text("In this day and age, no one should cede copyright to a journal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8869")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2007")])]

#text("It is easy to see that in my post I expressed no opinion on what")#linebreak()#text(" Terry should do with his blog. However, what is nice about Terry’s blog,")#linebreak()#text(" is that science can be openly discussed here, at least on the issues he")#linebreak()#text(" puts forward. However, I look towards times in which e.g., there would")#linebreak()#text(" be a blog connected to every published paper reviewed on the AMS")#linebreak()#text(" website, with free access to people with math PhD degrees.")#linebreak()#text(" On copyright: it would be interesting to read an opinion from someone who")#linebreak()#text(" experienced her/his work violated in one of the ways I described above.")#linebreak()#text(" And actually, it seems that it is the conduct of arxiv that runs directly counter to the Open Access movement. The following SHERPA website:")#linebreak()#text(" ")#link("http://www.sherpa.ac.uk/romeo.php")[#text("http://www.sherpa.ac.uk/romeo.php")]#linebreak()#text(" gives a complete description of publishers’ various restrictions on archiving")#linebreak()#text(" articles in public domain. E.g., the American Phytopathological Society")#linebreak()#text(" is a so-called yellow publisher, i.e.,")#linebreak()#text(" “author can archive pre-print,")#linebreak()#text(" subject to restrictions below, author can archive post-print")#linebreak()#text(" only publisher PDF may be used,")#linebreak()#text(" published source must be acknowledged")#linebreak()#text(" cover page must be included (provided by publisher).”")#linebreak()#text(" To be more precise, I think it would be a good idea for arxiv to delete all articles which don’t respect these fine rules. Unless spending time working")#linebreak()#text(" hard on ever more papers and books is more important.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2007")])]

#text("Dear Emmanuel,")

#text("Thanks for the examples! I can’t believe I had forgotten about Deligne’s proof of RH for finite fields, which is one of the more spectacular applications of the tensor power trick.")

#text("The amplification method for subconvexity bounds can be viewed as a kind of special case of the amplification trick; here the symmetry one is exploiting is the ability to manipulate the underlying measure or weight in the summation, which is an important symmetry that I didn’t mention in the main post. For instance, if one takes the log-convexity of ")#mi("L^p")#text(" norms,")

#tao-math("\\left\\| f \\right\\|_{L^r(X, d\\mu)} \\leq \\left\\|f\\right\\|_{L^p(X,d\\mu)}^{1-\\theta} \\left\\|f\\right\\|_{L^q(X,d\\mu)}^{\\theta}", block: false)

#text("for ")#mi("0 \\leq \\theta \\leq 1")#text(" and ")#mi("\\frac{1}{r} = \\frac{1-\\theta}{p} + \\frac{\\theta}{q}")#text(" that Shuanglin mentioned, and one uses the symmetry ")#mi("d\\mu \\mapsto wd\\mu")#text(" for arbitrary weight functions w, one can amplify the log-convexity inequality to Holder’s inequality.")

#text("Dear Chris: There are some arguments in analysis (and probably in other areas of mathematics too) which definitely have the feel of a Rubik’s cube-like puzzle, in which there are a relatively small number of “moves” available, and to prove a given result one needs to execute these moves in a well-chosen order. For example, in the analysis of nonlinear PDEs, there are a large variety of multilinear estimates that one needs to prove in order to control any given PDE, but any such estimate can often be proven by the judicious application of a remarkably small number of inequalities (e.g. Holder’s inequality, Sobolev embedding, triangle inequality, the Leibnitz rule, and Bernstein’s inequality). The extreme version of this state of affairs is of course that of a calculus (such as the differential calculus), in which a small set of formal rules allow one to perform any computation of a certain type.")

#text("Dear all: I appreciate the lively discussion here, but please try to keep all comments polite and constructive. Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8934")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2007")])]

#text("Dear Terry,")

#text("I too thought this was a great post, and it set me thinking about the issues raised by some of the comments above. Your initial remark, that it is not conventionally publishable (because it contains no new results) is obviously correct. Here, by “conventionally publishable” I mean “publishable as a research article”. And yet, what I look for in written mathematics is to be taught something. Usually this is an irritatingly indirect process: an author just displays the results and proofs and one has to think very hard before being able to work out which parts of the argument were genuine breakthroughs and which were “tricks” or “semi-standard moves”. If the area is not one’s own, this can be more or less impossible. Your article lays bare a way of thinking, one that I did not know (in particular, I was not aware of that very nice way of thinking about the Cauchy-Schwarz inequality, though I suppose parts of it I had appreciated without thinking about it too consciously) and in that way directly teaches me something.")

#text("I find myself sympathizing with those who would like it to be published in print form, and also with those who object to that on the grounds that the blog medium should be thought of as a perfectly valid medium in itself. I would suggest that the main reason people would like a print version is the convenience of having a number of such “tricks” articles in the same place. But there is nothing in principle against having that convenience online: what is needed is a single (virtual) place where articles of this kind are collected, indexed in many different ways (by author, by subject, and so on). I myself would be very happy to contribute articles of such a kind, as I feel strongly that our present mathematical culture needs changing: we should be more explicit about our thought-processes and thereby more welcoming to new mathematicians. I think that keeping such articles as an online resource would emphasize very nicely that this was intended as a challenge to the more traditional way of doing things.")

#text("I’m left with a question — forgive me if it’s very ignorant. In order to do something along the lines I suggest, would it be necessary to start up a new site, or is there some really convenient way that one can produce a “super-structure” to do the job of indexing the blog posts, keeping the posts where they are? (One could do it crudely by simply setting up a web page, but that relies on a single person to keep it updated, which is not satisfactory.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61a41f9901217a6de1256a8b0d1638ac16eff5dec67bec389f3aa733236aed36-8ecbda28ae40c5f75e88d4d0173384140670cc8b955e99dab9becbec48f125a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8962")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2007")])]

#text("Regarding an online site for mathematical exposition, etc., we’re having a ")#link("http://golem.ph.utexas.edu/category/2007/09/towards_a_higherdimensional_wi.html")[#text("discussion")]#text(" about setting up a wiki over at the Café.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8969")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2007")])]

#text("Dear David,")#linebreak()#text(" I think that such new ideas can rarely be successful. E.g., I find the new")#linebreak()#text(" Scholarpedia quite cynical – the so-called curators can make decisions")#linebreak()#text(" on what is allowed to be changed, and at the same time take credit")#linebreak()#text(" for changes, as an article improves. Besides the editor-in-chief clearly")#linebreak()#text(" has a vested interest in promoting computational neuroscience through")#linebreak()#text(" this outlet. As if indiscriminate government funding was not enough.")#linebreak()#text(" At the same time Wikipedia has a growing positive reputation. Maybe")#linebreak()#text(" they would allow to connect blogs to articles there?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-8974")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2007")])]

#text("Terry, can you delete my comment of September 8th, 2007 at 4:08 pm which was based on a misunderstanding? [")#emph[#text("Done")]#text(" – T.]")

#text("Adam, I am a participant in the discussion David mentioned about setting up a research wiki, and also in ")#link("http://www.eurekajournalwatch.org/index.php/Main_Page")[#text("http://www.eurekajournalwatch.org/index.php/Main_Page")]#text(". I’d like to hear more about your views on the role of the arXiv, Scholarpedia, Wikipedia, etc., but I don’t think this is the place. Can you email me via ")#link("http://www.physicsforums.com/")[#text("http://www.physicsforums.com/")]#text(" (where I am User:Chris Hillman)?")

#text("Terry, one thought I would like to toss out is that while wikis are great for collaboration, I claim the “private wikis” (possibly world readable but editable only by the author) are useful as authorship tools. Here we encounter a technical issue: it is not straightforward to convert a document created under say MediaWiki into a conventional latex formatted paper. But it can be done. (Jacques Distler is working on a wiki which he says can export a latex file with one mouse click, but his wiki software might have drawbacks mitigating this advantage.)")

#text("Tim G, I have also been musing about the potential a collaborative website of mathematical exposition. I’d like to see a wiki which combines the best elements of making mathematical writing more enjoyable by providing a fun authorship environment, while encouraging signed expository articles under the control of the author (an expert both in expository writing and in the subject matter), and providing convenient linking of related articles and more or less public discussion forums. Sites like ")#link("http://eqworld.ipmnet.ru/index.htm")[#text("http://eqworld.ipmnet.ru/index.htm")]#text(" and ")#link("http://mathworld.wolfram.com/")[#text("http://mathworld.wolfram.com/")]#text(" are inspiring; I think with a suitable wiki and institutional sponsorship one could do even better. Unfortunately there may be nontrivial technical obstacles. Maybe we should find a suitable forum in which to extend discussion of “wikis we’d like to see”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Cotton-Clay")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9016")[#strong[#text("Andy Cotton-Clay")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2007")])]

#text("Great post! Just a quick correction: looks like you want ")#tao-math("c = \\left|\\left|f\\right|\\right|_X/\\left|\\left|g\\right|\\right|_X", block: false)#text(" instead of the reciprocal near the top of “Amplification using linearity.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9027")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Chris, speaking about physicsforums.com: the New Scientist has nicer")#linebreak()#text(" graphics.")#linebreak()#text(" To switch from playing with software discussions to Prof. Gowers’")#linebreak()#text(" constructive suggestion that we should be more welcoming to new mathematicians, let me share an experience from my workplace.")#linebreak()#text(" We run programs separately, both maths and physics take about")#linebreak()#text(" 100 new undergrads. While physics gets about 10 excellent students")#linebreak()#text(" each year (e.g., who during the 1st semester by themselves learn about Euler’s proof of the Basel problem), maths gets at most average ones.")#linebreak()#text(" I doubt this is a country-specific problem. Nobody I spoke to can give a sensible reason for this, and it is not the job situation, as mathematicians")#linebreak()#text(" are respected by industry employers here. Maybe our programs are too finance/other superficial fads oriented to attract the brightest?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9032")[#strong[#text("What might an expository mathematical wiki be like? « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")]

#text("[…] as a result of a very interesting post of Terence Tao. Both the post and the discussion can be found here . The post outlines a rather general idea, or trick, that can be used in many mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9033")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Chris, I agree with you that maybe this is not the best place to have a very general discussion about how to organize expository material on the web, so I’ve followed your suggestion and attempted to get a discussion going. See the link just above this comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Terry Tao,")

#text("A random, if not irrelevant question: I find it interesting that you used intuition/terminology from economics. Do you find economics interesting? I was under the impression that many (pure) mathematicians dislike economics, since for instance, it lacks the elegance and beauty of theorem-proof. Did you learn economics as a byproduct of your mathematical activities or was this analogy with “arbitrage” for instance just a coincidental word from economics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Anonymous,")

#text("I find it helpful to draw analogies from any source that can usefully provide them, whether it be physics or economics or Tomb Raider. :-) Indeed, once one has developed the ability to distinguish between rigorous and non-rigorous thinking, there’s really no further reason why the “mathematics” compartment of one’s brain needs to be walled off from the rest of one’s experiences and cognitive abilities (which of course includes various non-rigorous modes of thinking, such as reasoning by analogy).")

#text("On the other hand, one should also be able to recognise when an analogy has reached its natural limits. For instance, it seems unlikely that one could set up an efficient market in estimates that would automatically arbitrage away symmetry imbalances, though I must admit that such a market would be very handy in my own research…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane Yang")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9107")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2007")])]

#text("My collaborators, Erwin Lutwak and Gaoyong Zhang, were struck by the remark by Emmanuel Kowalski about Bernstein and Reznikov’s technique of “amplifying” the Sobolev inequality. We have been doing exactly this with both sharp isoperimetric and Sobolev inequalities on Euclidean space. Except we’ve always called it “optimization”.")

#text("In our PLMS paper on “L_p John ellipsoids”, we show how to amplify the isoperimetric inequality (as well as L_p version of it) for convex bodies over the group SL(n). You get an affine isoperimetric inequality, where the extremal bodies are necessarily not just balls but also ellipsoids. One cool thing about this is that with the “amplified norm”, you can get sharp *reverse* isoperimetric inequalities, where the extremal body is a simplex.")

#text("In our IMRN paper on “Optimal Sobolev inequalities”, we show how to amplify a Sobolev norm over all Banach norms (I guess this is over a rather large infinite dimensional group) and obtain sharp affine-invariant Sobolev inequalities.")

#text("Another theme in our work, which I believe is also pervasive in harmonic analysis, is averaging. Basically, we know two ways to turn Euclidean-invariant inequalities into affine-invariant inequalities: optimization (i.e., amplification) and averaging.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9112")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2007")])]

#text("Tim: A meta site should not be too hard to set up: Most blog programs already provide some sort of feed (atom or rss etc)")

#link("http://en.wikipedia.org/wiki/Rss")[#text("http://en.wikipedia.org/wiki/Rss")]

#text("(I wrote about those here ")#link("http://atdotde.blogspot.com/2005/10/how-to-read-blogs-and-how-not-to-write.html")[#text("http://atdotde.blogspot.com/2005/10/how-to-read-blogs-and-how-not-to-write.html")]#text(" ) These are basically machine readable summaries of blog posts and there are many meta ways of watching many blogs at a time via these feeds. For example, you can list feeds if you use the individualised google home page.")

#text("Maybe authors could include some additional tags in their ‘tricks explained’ posts that would help a computer to categorise them, then it should be quite trivial to write a short program that would serve as a meta engine. I could try some quick hack along these lines if you tell me which ways of accessing it you would like to see.")

#text("Adam: OK I am a physicist and have different standards but the idea of the arxiv removing published papers sounds ridiculous to me: Why would I want to give up the possibility of easy access to papers from my desk (for other than fitness reasons of more frequent visits of the library)? I would think the trend would be rather in the opposite direction: An easily accessible (and that would most likely mean central) repository of all papers and journals only adding the quality control, possibly only virtually. You could imagine that a ‘journal’ only digitally signs a version of a file as “according to standards of journal XYZ” without any paper version etc. Let’s face it, this is the only real value that the journals provide these days (and for which libraries pay enormous sums).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9233")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2007")])]

#text("Robert: I am not taking any sides in the Open Access debate.")#linebreak()#text(" However, it is hard to deny the publishers the right to make")#linebreak()#text(" profit, as it is equivalent to criticizing capitalism. Especially as")#linebreak()#text(" that probably what enabled those price increases was the needless establishment of many new academic journals. The only problem")#linebreak()#text(" with arxiv is that it doesn’t respect the publishers’ requirements,")#linebreak()#text(" which are not that stringent. I think other solutions could be")#linebreak()#text(" discussed. E.g., why doesn’t the government buy out the journals,")#linebreak()#text(" instead of spending public money for the purpose of subsiding")#linebreak()#text(" big business (e.g., math education schemes, equivalent to every")#linebreak()#text(" student buying a graphical calculator).")#linebreak()#text(" To me, the only virtual quality control which seems to have worked so")#linebreak()#text(" far is anonymous contribution, e.g., Wikipedia, or the Linux project.")#linebreak()#text(" In fact, there are still many people who put more value in constructive")#linebreak()#text(" work than in money, politics, coteries, prizes, and other nonsense.")#linebreak()#text(" Let me give you examples of values journals provide.")#linebreak()#text(" Suppose you are asked to referee a paper, which is a blatant copyright")#linebreak()#text(" infringement of one of your works. Then you can at least put up a fight.")#linebreak()#text(" Also, sometimes referees ask questions which are conducive for")#linebreak()#text(" improving a paper.")#linebreak()#text(" I would think that in mathematics it is not too hard to notice good work.")#linebreak()#text(" However, what goes on in physics is another matter, and I don’t")#linebreak()#text(" know what solutions are needed for a science area which might just")#linebreak()#text(" be exhausted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9716")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Of course, publishers can (and have the right to) ask ridiculous things. But if they do we should refuse to cooperate with them (by submitting papers, refereeing or serving on editorial boards). It should be in our interest as scientists to keep our fields healthy. If important results effectively disappear because they are only available in some journal that my (or many other) department’s library cannot afford to subscribe this cannot be in my interest. As in other situations where people decide that have to suffer the consequences at most indirectly (scientists decide where to submit but they don’t have to worry about libraries’ budgets or funding money going into publishing houses pockets) it’s a bit harder to raise awareness.")

#text("I would not go so far that governments should buy out publishers (which are legitimate businesses) but if their service for money is bad we as users should use (or set up which has been proven to be not too hard) better alternatives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9719")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Government agencies could buy out not publishers, but journals.")#linebreak()#text(" Note how well e.g., journals of the AMS are run. They don’t insist")#linebreak()#text(" on ceding copyrights, rogue editors are made to resign, etc.")#linebreak()#text(" I believe before they were bought out by publishers, many journals")#linebreak()#text(" were managed by non-profit organizations. Because many new")#linebreak()#text(" were set up, publishers seized the opportunity to make profit.")#linebreak()#text(" The problem is that there are no known better alternatives.")#linebreak()#text(" If we disseminate our work in electronic repositories, the value")#linebreak()#text(" of such papers would be measured only in the amount of citations.")#linebreak()#text(" However, this doesn’t work for mathematics, as often original")#linebreak()#text(" results take years to be digested by the community. The AMS")#linebreak()#text(" webpage has just posted an article about the so-called Impact")#linebreak()#text(" Factor, which deals with this issue.")#linebreak()#text(" As for journals dissappearing from libraries, welcome to the world.")#linebreak()#text(" In my country, only the library of the Academy of Sciences in the")#linebreak()#text(" capital has a fine collection. Because of this, many talented people")#linebreak()#text(" working in other cities have long had to resign themselves to")#linebreak()#text(" uncompetive backwater projects. However, they are not sharing")#linebreak()#text(" the physicists’ whining about making revolutionary changes.")#linebreak()#text(" Maybe it is because they are not thinking only about “what is in")#linebreak()#text(" my interest.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9723")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Dear all,")

#text("The ethics and future of mathematical publishing are interesting and important topics, but are a little distant from the topic of the original post. I have already received one request to ask that the discussion be moved to a more appropriate forum. Perhaps one of the readers here would like to initiate a new post on their own blog (or point to an existing post on this topic), and then advertise it here. For instance, the following recent post covers similar ground:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://sbseminar.wordpress.com/2007/08/07/more-on-journals/")[#text("More on journals")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9732")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" Apologies for getting off the main topic.")#linebreak()#text(" I have a question, which is somewhat related to amplification and")#linebreak()#text(" the work of your colleague, Perez-Marco. What are your thoughts")#linebreak()#text(" on the power of complex analysis tools in real analysis problems?")#linebreak()#text(" Are there any classical and well researched results for which real")#linebreak()#text(" analysis techniques were not enough? Examples of what I am")#linebreak()#text(" thinking about is the Selberg sieve, the Ablowitz-Ramani-Segur")#linebreak()#text(" conjecture, or some other problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9737")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("Dear Adam,")

#text("Complex methods tend to be particularly powerful in problems in one real variable, or (naturally enough) in the complex plane or other Riemann or conformal surfaces. For instance, complex analysis methods are the only methods known that give good control on the asymptotic behaviour of general solutions to completely integrable equations in one dimension; a corresponding real-variable theory would be highly desirable, but is still in its embryonic stages.")

#text("The type of complex analysis that comes up in analytic number theory (analytic continuation of zeta and L-functions, shifting contours, locating zeroes and poles, etc.) can be partially replaced by Fourier analysis (using changes of variables to convert the Mellin transform to the Fourier-Laplace transform, for instance), but not completely. In particular, the Weierstrass factorisation of a meromorphic function based on its zeroes and poles is very hard to duplicate in a natural fashion using just the Fourier transform. (More generally, real-variable methods are hard-pressed to come up with a usable substitute of the obvious fact from complex analysis that the product of two meromorphic functions is again meromorphic.) But Fourier methods can be used for instance to replicate the Selberg sieve (I have done this in some of my papers with Ben Green and Tamar Ziegler) and to prove the prime number theorem (in one of my unpublished notes on my web page), though the proofs are not as slick as the complex variable ones.")

#text("In higher dimensions, complex methods are generally not as powerful as their real-variable counterparts in solving problems in many real dimensions. Indeed, a reverse phenomenon occurs: several results in several complex variables (notably those involving the ")#mi("\\overline{\\partial}")#text("-problem) require techniques from real-variable harmonic analysis and PDE in their proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The crossing number inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-9770")[#strong[#text("The crossing number inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")])]

#text("[…] of applications, for instance to sum-product estimates. It is also an excellent example of the amplification trick in action; here the main source of amplification is the freedom to pass to subobjects, which is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/add6ac292e2699841111424ecc77a44f097aabdbd9ff1511882839de955ee942-8f57554be21b6c5997ca8c31640c8aeac1d6b636258305cce13037e3bbb9144f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of derek hacon")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-10605")[#strong[#text("derek hacon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("re tensor trick: this also occurs in the proof that not only does the degree of an irreducible rep of a finite group divide the order of G but also divides order of G / order of center of G. Proved by considering large tensor powers of the rep.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fbb168c91cedbf2772b6baa8b2f4763a45cd99c896319eeb5e031e8f7e1040d-ed68e81dd10c20a5f99e944c85917cafa964982708dbfb21a031150c6efd2eb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Steele")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-11844")[#strong[#text("Mike Steele")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("I loved this post and would like to offer another easy example — it’s the proof that Landau gave for the maximum modulus principle for analytic functions (it’s mentioned in a footnote in Polya and Szego).")

#text("What you do is write down the Cauchy integral formula for f(z), then bound |f(z)| by the maximum on the boundary and the length of the boundary. This gives you a “weak” inequality which you amplify by considering f(z)^n. Now you get to make the constants disappear just like they do from the tensorization trick.")

#text("For another financial metaphor, you can also call this process “leveraging the generality” of an inequality. T")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fibela")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-11920")[#strong[#text("Fibela")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("There is another way to look at the Cauchy-Schwarz inequality in the finite-dimensional real case, i.e.")#linebreak()#text(" ")#mi("\\displaystyle v_{1} w_{1}+v_{2}w_{2}+ \\ldots+ v_{n}w_{n} \\leq \\sqrt{v_{1}^{2}+v_{2}^{2}+ \\ldots +v_{n}^{2}} \\sqrt{w_{1}^{2}+w_{2}^{2}+ \\ldots +w_{n}^{2}}")#linebreak()#text(" for real numbers ")#mi("v_{i},w_{i} ,i=1, \\ldots ,n")#text(". Let ")#mi("v=(v_{1},v_{2}, \\ldots ,v_{n})")#text(" and ")#mi("w=(w_{1},w_{2}, \\ldots ,w_{n})")#text(" be the corresponding vectors. We assume that all ")#mi("v_{i},w_{i} ,i=1, \\ldots ,n")#text(" are positive. (All other cases can be deduced from this.)")

#text("You said that the minimum of the function")#linebreak()#text(" ")#mi("\\displaystyle f : \\mathbb{R}^{+} \\rightarrow \\mathbb{R}")#linebreak()#text(" ")#tao-math("\\displaystyle f(\\lambda)=\\frac{\\lambda^{2}}{2}\\left\\|v\\right\\|^{2}+\\frac{1}{2\\lambda^{2}}\\left\\|w\\right\\|^{2}", block: false)#linebreak()#text(" is ")#tao-math("\\left\\|v\\right\\| \\cdot \\left\\|w\\right\\|", block: false)#text(". But the other hand ")#mi("v_{i}w_{i}")#text(" is the minimum of the function")#linebreak()#text(" ")#mi("\\displaystyle f_{i} : \\mathbb{R}^{+} \\rightarrow \\mathbb{R}")#linebreak()#text(" ")#mi("\\displaystyle f_{i}(\\lambda)=\\frac{\\lambda^{2}}{2}v_{i}^{2}+\\frac{1}{2\\lambda^{2}}w_{i}^{2}")#text(".")#linebreak()#text(" Note that ")#mi("f = \\sum_{i=1}^{n} f_{i}")#text(". The Cauchy-Schwarz inequality now follows from the fact the sum of the minima is less than or equal to the minimum of the sum.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1191a271dce8843dec588cbf5c298ec555e12a8e971d11d12bcef8c2fb1576f8-b5c230a6849acd916d5fe9967f74d1496870c9f17a586146a0b263c7f9826d35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-26056")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Dear Terence,")#linebreak()#text(" I think it is a wonderful idea to group tricks together and give them a collective colourful name like “arbitrage”.")#linebreak()#text(" “Amplification” reminds me of the little trick of proving the ” freshman dream” equality (a+b)^q= a^q + b^q in a ring of characteristic p, first for q=p and then for q=power of p. But maybe this should just be called induction…")#linebreak()#text(" Best, A.S.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-27128")[#strong[#text("A Method of E. Landau (in complex analysis) « Vishal Lama’s blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2008")]

#text("[…] version below is an updated and correct one. Also, Andreas pointed out an excellent post on “amplification, arbitrage and tensor power trick” (by Terry Tao) in which the “tricks” discussed are indeed very useful and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-32191")[#strong[#text("Math Journals - to be or not to be? « quantblog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2008")]

#text("[…] August 24, 2008 in Uncategorized | Tags: arxiv, journals, math, peer review, publishing, tao | Found a great entry on Terry Taos blog : a guide to strengthening math inequalities, with examples and tricks, entitled “Amplification, Arbitrage …. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-32214")[#strong[#text("What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("[…] Why global regularity for Navi…Nathan on Career adviceMath Journals – to b… on Amplification, arbitrage, and …PDEbeginner on Why global regularity for Navi…Peter on Weakly turbulent solutions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-32728")[#strong[#text("Cauchy-Schwarz via tensor product « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2008")]

#text("[…] of squares in Timothy Gowers’s first proof. Also the use of tensor products may remind you of Terry Tao’s post about tensor products that includes a proof of Cauchy-Schwarz, but this proof doesn’t actually use the tensor […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-34785")[#strong[#text("245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("[…] First show that the lengths of these intervals cannot differ by more than a factor of two, and then amplify this fact by iteration to conclude the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-35262")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] functional agreeing with on Y. Since has norm at most 1, we have for all . We can amplify this by exploiting phase rotation symmetry, thus for all . Optimising in we see that has norm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 5: Hilbert spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-35265")[#strong[#text("245B, notes 5: Hilbert spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] in a, b (see also my blog post on the amplification trick) we obtain the Cauchy-Schwarz inequality. To verify the norm property, the only non-trivial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f04d3298f84c58fcdd97e8845bc0388cc9cbf4a05a3337f9cc46796bbdd191f2-5a8a0f87598cf6eac1d4221d3260f5750ff2d5bbf1eb90095677f2d0b0ced055.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ali Shahid")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-35386")[#strong[#text("Ali Shahid")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Dear Terry,")#linebreak()#text(" I wanted to express my appreciation for this post. I am an undergraduate student in mathematics, currently enrolled in an analysis course, and although I lack the background to fully comprehend the topics discussed here, I have been able to extract a lot of useful tools that have helped me in my analysis problem sets. I look forward to reading more such expository papers. I would like to ask a slightly unrelated question. I have developed a very keen interest in analysis, and I would like to gain some exposure (even if it is a very rudimentary exposure) to some of the more cutting edge areas in analysis, and I was hoping you could offer some advice regarding where I could/should begin. For instance, if you could suggest some problems I could look into or texts I could read, it would really help a lot. I should also mention that I am also interested in mathematical finance, and so if you have any advice concerning areas in analysis that are related to this, I would really appreciate it. Thank you so much once again. Take care!")

#text("-Ali")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-35418")[#strong[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("[…] rather than norm convergence, known as Stein’s maximal principle (discussed for instance in this previous blog post of mine). For instance, it reduces Carleson’s theorem on the pointwise convergence of Fourier […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/comment-page-1/#comment-37407")[#strong[#text("While I’m linking… « Feed The Bears")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")]

#text("[…] A post on “Amplification, arbitrage, and the tensor power trick”. […]")
]
