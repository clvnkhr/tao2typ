// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/14/first-proof-third-batch-webinar/
// Converted to Typst by tao2typ: "2026-10-15T11:45:55.021746+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "First Proof, Third Batch webinar", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("First Proof, Third Batch webinar")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/14/first-proof-third-batch-webinar/")[#text("https://terrytao.wordpress.com/2026/10/14/first-proof-third-batch-webinar/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-15 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short note that ")#link("https://1stproof.org/")[#text("First Proof")]#text(" is announcing the result of their “third batch” evaluation at a ")#link("https://icarm.io/news/first-proof-third-batch-results-webinar/")[#text("webinar at 3PM ET hosted by ICARM")]#text(" today. (Registration required.)")
