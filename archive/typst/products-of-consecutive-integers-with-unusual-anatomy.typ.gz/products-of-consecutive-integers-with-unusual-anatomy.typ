// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/
// Converted to Typst by tao2typ: "2026-10-14T15:21:11.217771+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Products of consecutive integers with unusual anatomy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Products of consecutive integers with unusual anatomy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 March 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/")[#text("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2603.27990")[#text("Products of consecutive integers with unusual anatomy")]#text("“. This paper answers some ")#link("https://zbmath.org/0434.10001")[#text("questions of Erdős and Graham")]#text(" which were initially motivated by the study of the Diophantine factorial equation")

#align(center)[#tao-fit-display[#mitex("a_1! a_2! a_3! = m^2")]]

#text("where ")#mi("{a_1 < a_2 < a_3}")#text(" and ")#mi("{m}")#text(" are positive integers. Writing ")#mi("{(a,N,N+H) = (a_1,a_2,a_3)}")#text(", one can rewrite this equation as")

#metadata(none) <tao-f723521c75db8ace49d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("s( (N+1) \\dots (N+H) ) = s(a!)")]]

#text("where ")#mi("{s(n)}")#text(" denotes the squarefree part of ")#mi("{n}")#text(" (the smallest factor of ")#mi("{n}")#text(" formed by dividing out a perfect square). For instance, we have")

#align(center)[#tao-fit-display[#mitex("s(8 \\times 9 \\times 10) = 5 = s(6!)")]]

#text("which corresponds to the solution ")#mi("{6! 7! 10! = (6!\\times 7!)^2}")#text(" to the original equation.")

#text("The equation ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(" ties into the general question of what the ")#emph[#text("anatomy")]#text(" (prime factorization) of the product ")#mi("{(N+1) \\dots (N+H)}")#text(" looks like. This is a venerable topic, with the first major result being the Sylvester-Schur theorem from 1892 that the largest prime factor of ")#mi("{(N+1) \\dots (N+H)}")#text(" is greater than ")#mi("{H}")#text(" whenever ")#mi("{N+1>H}")#text(". Another notable result is the Erdős-Selfridge theorem that the product ")#mi("{(N+1) \\dots (N+H)}")#text(" is never a perfect power for ")#mi("{H > 1}")#text(".")

#link("https://zbmath.org/0346.10004")[#text("Erdős and Graham")]#text(" were able to show that solutions to ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(" were somewhat rare, in that the set of possible values of ")#mi("{N+H}")#text(" had density zero. For them, the hardest case to treat was when the interval ")#mi("{\\{N+1,\\dots,N+H\\}}")#text(" was what they called ")#emph[#text("bad")]#text(", in the sense that ")#mi("{(N+1) \\dots (N+H)}")#text(" was divisible by the square of its largest prime factor. They were able, with some effort, to show that the union of all bad intervals also had density zero, which was a key ingredient in to prove the previous result about solutions to ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(". They isolated a subcase of the bad intervals, which they called the ")#emph[#text("very bad")]#text(" intervals, in which the product ")#mi("{(N+1) \\dots (N+H)}")#text(" was a ")#link("https://en.wikipedia.org/wiki/Powerful_number")[#text("powerful number")]#text(" (divisible by the square of every prime factor).")

#text("A ")#link("https://zbmath.org/1373.11029")[#text("later paper of Luca, Saradha, and Shorey")]#text(" made the bounds more quantitative, showing that both the set of values of ")#mi("{N+H}")#text(", as well as the union of bad intervals, had density ")#mi("{O( \\exp(-c \\log^{1/4} x (\\log\\log x)^{3/4})}")#text(" for some absolute constant ")#mi("{c>0}")#text(". In the other direction, just by considering the case ")#mi("{H=1}")#text(", one can show that the number of possible values of ")#mi("{N+H}")#text(" up to ")#mi("{x}")#text(" is ")#mi("{\\gtrsim c_3^1 \\sqrt{x}}")#text(", where ")#mi("{c_3^1}")#text(" is the constant")

#align(center)[#tao-fit-display[#mitex("c_3^1 = 1 + \\sum_{a \\geq 2: a \\neq n^2 \\forall n} \\frac{1}{s(a!)^{1/2}} = 3.70951\\dots.")]]

#text("As for the bad intervals, by again considering the case ")#mi("{H=1}")#text(", it is possible to show that the number of bad points up to ")#mi("{x}")#text(" is")

#align(center)[#tao-fit-display[#mitex("x / \\exp((\\sqrt{2}+o(1)) \\sqrt{\\log x \\log\\log x});")]]

#text("see for instance ")#link("https://zbmath.org/1098.11046")[#text("this paper of Ivic")]#text(". Similarly, the union of the very bad intervals contains as the set of powerful numbers; ")#link("https://zbmath.org/0218.10018")[#text("Golomb worked out")]#text(" that the number of powerful numbers up to ")#mi("{x}")#text(" is ")#mi("{\\sim \\frac{\\zeta(3/2)}{\\zeta(3)} \\sqrt{x}}")#text(".")

#text("It was conjectured by Erdős and Graham that all of these lower bounds are in fact sharp (up to ")#mi("{1+o(1)}")#text(" multiplicative factors); this is ")#link("https://www.erdosproblems.com/380")[#text("Erdos Problem 380")]#text(" (and a portion of ")#link("https://www.erdosproblems.com/374")[#text("Erdos Problem 374")]#text("). The main result of this paper is to confirm this conjecture in two cases and come close in the third:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]

#list(
[#text("The number of numbers up to ")#mi("{x}")#text(" that lie in a bad interval of length ")#mi("{H>1}")#text(" is ")#mi("{O(1/\\log^{1-o(1)} x)}")#text(" of the number of bad points up to ")#mi("{x}")#text(".")],
[#text("The number of numbers up to ")#mi("{x}")#text(" that lie in a very bad interval of length ")#mi("{H>1}")#text(" is ")#mi("{O(x^{2/5+o(1)})}")#text(".")],
[#text("The number of numbers up to ")#mi("{x}")#text(" of the form ")#mi("{N+H}")#text(" for a solution to ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(" is ")#mi("{O(x^{1/2+o(1)})}")#text(".")]
)
]

#text("Not surprisingly, the methods of proof involve many standard tools in analytic number theory, such as the prime number theorem (and its variants in short intervals), zero density estimates, Vinogradov’s bounds on exponential sums, asymptotics for smooth numbers, the large sieve, the fundamental lemma of sieve theory, and the Burgess bound for character sums. There was one point where I needed a small amount of algebraic number theory (the classification of solutions to a generalized Pell equation), which was the one place where I ")#link("https://chatgpt.com/share/69d27d6b-571c-83e8-880a-07c1d56586f2")[#text("turned to AI for assistance")]#text(" (though I ended up rewriting the AI argument myself). One amusing point is that I specifically needed the recent ")#link("https://arxiv.org/abs/2405.20552")[#text("zero density theorem of Guth and Maynard")]#text(" (as converted to a bound on exceptions to the prime number theorem in short intervals ")#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/")[#text("by Gafni and myself")]#text("); previous zero density theorems were barely not strong enough to close the arguments.")

#text("A few more details on the methods of proof. It turns out that very bad intervals, or intervals solving ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(", are both rather short, in that the bound ")#mi("{H \\leq \\exp(\\log^{2/3+o(1)} N)}")#text(" holds. The reason for this is that the primes ")#mi("{p}")#text(" that are larger than ")#mi("{H}")#text(" (in the very bad case) or ")#mi("{C H \\log N}")#text(" for a large constant ")#mi("{C}")#text(" (in the ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(" case) cannot actually divide any of the ")#mi("{N+1,\\dots,N+H}")#text(" unless they divide it at least twice. This creates a constraint on the fractional parts of ")#mi("{N/p}")#text(" and ")#mi("{N/p^2}")#text(" that turns out to be inconsistent with the equidistribution results on those fractional parts coming from Vinogradov’s bounds on exponential sums unless ")#mi("{H}")#text(" is small. In the very bad case, this forces a linear relation between two powerful numbers; expressing powerful numbers as the product of a square and a cube, matters then boil down to counting solutions to an equation such as")

#align(center)[#tao-fit-display[#mitex("n_1^2 n_2^3 + 1 = m_1^2 m_2^3")]]

#text("with say ")#mi("{n_1,n_2,m_1,m_2 \\leq x^{1/5}}")#text(". The number of solutions here turns out to be ")#mi("{O(x^{2/5})}")#text(" by work ")#link("https://zbmath.org/1419.11006")[#text("of Aktas-Murty")]#text(" and ")#link("https://zbmath.org/1290.11011")[#text("of Chan")]#text("; we generalize the arguments in the former to handle a slightly more general equation. A similar argument handles solutions to ")#link(<tao-f723521c75db8ace49d4>)[#text("(1)")]#text(", except in one regime where the parameter ")#mi("{a}")#text(" is somewhat large (comparable to ")#mi("{H \\log N}")#text("), in which case one instead collects some congruence conditions on ")#mi("{N}")#text(" and applies the large sieve.")

#text("The situation with bad intervals is more delicate, because there is no obvious way to make ")#mi("{H}")#text(" small in all cases. However, by the large sieve (as well as the Guth–Maynard theorem), one can show that the contribution of large ")#mi("{H}")#text(" is negligible, and from bounds on smooth numbers one can show that the interval ")#mi("{\\{N+1,\\dots,N+H\\}}")#text(" contains a number with a particularly specific anatomy, of the form ")#mi("{p_0^2 p_1 \\dots p_{1000} m^{\\prime}}")#text(" where ")#mi("{p_0, \\dots, p_{1000}}")#text(" are all primes of roughly the same size, and ")#mi("{m^{\\prime}}")#text(" is a smoother factor involving smaller primes. The rest of the bad interval creates some congruence conditions on the product ")#mi("{p_1 \\dots p_{1000}}")#text(". Using some character sum estimates coming from the Burgess bounds, we find that the residue of ")#mi("{p_1\\dots p_{1000}}")#text(" becomes fairly equidistributed amongst the primitive congruence classes to a given modulus when one perturbs the primes ")#mi("{p_1,\\dots,p_{1000}}")#text(" randomly (there are some complications from exceptional characters of Siegel zero type, but we can use a large values estimate to keep their total contribution under control). This allows us to show that the congruence conditions coming from the bad interval are restrictive enough to make non-trivial bad intervals quite rare compared to bad points. One innovation in this regard is to set up an “anti-sieve”: the elements of a bad interval tend to have an elevated chance of being divisible by small primes, and one can use moment methods to show that an excessive number of small prime divisors is somewhat rare. This can be compared to standard sieve arguments, which often seek to limit the event that a number has an unexpectedly deficient number of small prime divisors.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("the theorem about the product never being a perfect power is by Erdos-Selfridge, not Erdos-Szekeres.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deleforg")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692129")[#strong[#text("deleforg")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#text("Nice work! Unless I misunderstood something, I think you meant to write s(8*9*10) = 5 = s(6!) ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#text("Isn’t the squarefree part of 720 given by s(8x9x10) = 5 (rather than s(8x9x10) = 20) ?")

#text("—Dan Asimov")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2026")])]

#text("I believe there is an errant () in the bound of Luca, Saradha, and Shorey.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51e912c2c7c661d3f4dd157ff51064eee7b203163534ecd505590a16aa0c16bd-8f9c881340b0854f26ce9ef0a10010ce25f02d6879218f859df83d4d527e716a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan José Alba González")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692151")[#strong[#text("Juan José Alba González")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2026")])]

#text("No mention of the identity $n! (n!-1)! (n!)! = (n!)!^2$ which proves the equation have infinitely many solutions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2026")])]

#text("This is a special case of the solutions arising from the sequence ")#mi("{\\mathcal F}_3^1")#text(" discussed in the paper – numbers ")#mi("N")#text(" whose square-free part equals that of a factorial ")#mi("a!")#text(" for some ")#mi("a < N-1")#text(". which makes ")#mi("a! (N-1)! N!")#text(" a square. This sequence contains the factorials ")#mi("n!")#text(", but also contains many other elements (such as the perfect squares greater than 1).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1147b8a2e9fefe16b45980723247e4ac51dc9a8c211b447ccd433b2f0ff45533-990149e2e36c44e854c979cce9f5764d80fee535aec0e9dd072342adc9b3fa60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Audigé")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692172")[#strong[#text("Emmanuel Audigé")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2026")])]

#text("Very nice paper — I found the anti-sieve aspect especially striking. One reformulation I found particularly clean on the F3 side is to encode n! by its parity state ")#mi("\\phi_x(n):=(v_p(n!) \\bmod 2)_{p\\le x}.")#text(" Then ")#mi("a_1!a_2!a_3! \\text{ is a square } \\iff \\phi_x(a_1)+\\phi_x(a_2)+\\phi_x(a_3)=0,")#text(" so the problem becomes an exact 3-collision problem in a finite F_2-space. This yields both ")#mi("T_3^{\\mathrm{ord}}(x)=2^{-\\pi(x)}\\sum_{q\\mid M(x)} S_q(x)^3")#text(" and ")#mi("T_3^{\\mathrm{ord}}(x)=\\sum_{u,v} N_x(u)N_x(v)N_x(u+v).")#text(" I like this viewpoint because it makes the F3 problem look like an additive/self-correlation problem for the parity-state trajectory of n!, which feels very close to the mechanism behind the current x^{1/2+o(1)} scale.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692180")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2026")])]

#text("Even without understanding all the technical details, I find so much peace and clarity in your writing late at night. Thank you for sharing such beautiful mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("What specifically are you using about the Guth-Maynard result? Apparently it is important that 2/15<1/6, but do you need the PNT in short intervals, or just the existence of primes in the short intervals? If you just want lower bounds rather than PNT, then one can use Harman’s sieve to get well below the 1/6 exponent; for instance, Harman (1982) got 1/10+epsilon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("The precise statement is contained in part 3 of Proposition 2.3. The important thing is the power savings in the exceptional set, so that the number of exceptional intervals up to ")#mi("x")#text(" is less than ")#mi("x^{1-c+o(1)}")#text(" for some constant ")#mi("c>0")#text(". From a glance at Section 7 Harman’s paper for instance it seems that he permits an exceptional set as large as ")#mi("x / \\log x")#text(", which is insufficient for our purposes. In contrast, as observed implicitly by Bazzanella and Perelli, and more explicitly by Gafni and myself, zero density theorems give the required ")#mi("x^{1-c+o(1)}")#text(" type control on the error set. I’ll make a note of Harman’s paper in the next revision to the ms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("Interesting! If zero-density methods can get power saving bounds on the size of the exceptional set, then I would have thought the Dirichlet polynomial-based methods of Harman et al on primes in almost all short intervals should also be capable of such feats, since both approaches are ultimately relying on large values estimates for Dirichlet polynomials. Does the zero-density approach give one more “rigidity” than pure Dirichlet polynomial methods, due to the structure of the explicit formula?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2026")])]

#text("It may well be possible to modify Harman’s arguments to extract power type savings, but this would require non-trivial amounts of effort, whereas the power savings from the zero-density approach already exist in the literature and can simply be cited. This could be a good project for a student in the subject. (It might also possibly be within reach of modern AI tools, although the reliability of the arguments produced may be in doubt, as this part of mathematics has not been fully formalized into languages such as Lean.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2026")])]

#text("Regarding your Lemma 2.10, perhaps it may make sense to look at Proposition 1 of ")#link("https://link.springer.com/article/10.1007/s00039-011-0127-6")[#text("https://link.springer.com/article/10.1007/s00039-011-0127-6")]#text(" and the references there to Vaughan and Wooley.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2026")])]

#text("Thanks for the reference! In fact my Lemma 2.10 already essentially follows from Lemma 4 of that paper (which is a key ingredient in the proof of Proposition 1). I will incorporate this into the next revision of the manuscript.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2026")])]

#text("I believe the Sylvester-Schur theorem applied to the product")

#text("(N+1) x … x (N+H)")

#text("requires the condition")

#text("N+1 > H.")

#text("—Dan Asimov")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-692537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2026")])]

#text("Actually, when one has the (classical) Sylvester-Schur theorem [n>=k>0 implies (n+1)…(n+k) has a prime factor > k], then one gets the same result for n+1 >=k when k>2. [ For odd prime k, use S-S on j the largest prime beneath k to get the result for this k. For k = 2 use a combinatorial argument to get the same, while the statement does not hold for k=1.] GRP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-693807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("I think in footnote “The squarefree component s(n) of a natural number is the largest natural number of the form n/m2 for some perfect square m2” it should be the ")#emph[#text("smallest")]#text(" natural number, instead of the ")#emph[#text("largest?")]#text(" Because otherwise every natural number can be written n=n/1^2 and would be its own squarefree component?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/31/products-of-consecutive-integers-with-unusual-anatomy/#comment-696892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Following up on the April 9 discussion of whether Prop. 2.3(iii) can be weakened: I believe Theorem 1.7 only requires Prop. 2.3(iii) for some θ slightly below 1/4, rather than below 1/6, so that Huxley’s classical density estimate (via Bazzanella–Perelli, or your paper with Gafni) already suffices and Guth–Maynard is not needed. The only change is to the first step of Prop. 6.5. Fix 0 < ε < 1/36 and 0 < δ ≤ 0.07, and consider a normalized interval {p₀²m, …, p₀²m + H − 1} (the case (6.3) is symmetric). (a) If H ≥ x^(1/4 − 2ε): apply Prop. 2.3(iii) to intervals of length H/2 exactly as in your argument. This only needs θ = 1/4 − 3ε > 1/6, which is covered by Huxley. (b) If H < x^(1/4 − 2ε) and p₀ > x^(1/4 − ε): the trivial count gives Σ_{p₀ > x^(1/4−ε)} xH/p₀² ≪ x^(1−ε). (c) If x^δ ≤ H and p₀ ≤ x^(1/4 − ε): by Lemma 6.1 every element of the interval is p₀-smooth and p₀ > H. So for every prime p in (p₀, Q], where Q := √(2x)/p₀, the integer m ≤ 2x/p₀² avoids the H distinct residue classes −j·p₀^(−2) mod p, 0 ≤ j < H. Corollary 2.8 with prime moduli only (note Q² = 2x/p₀²) bounds the number of such m by ≪ (x/p₀²) / (H · Σ_{p₀ < p ≤ Q} 1/p) ≪_ε x/(p₀² H), since log Q / log p₀ ≥ (1/4 + ε)/(1/4 − ε). Summing over p₀ > H and dyadic H ≥ x^δ, the union of these intervals has cardinality ≪ x^(1−δ+o(1)). Hence one may assume H < x^δ. The trivial count then removes p₀ > x^(2δ), and since δ ≤ 0.07 the remainder of the proof (in particular the k ≥ 2 requirement in (6.14)) goes through unchanged. The difference from (6.14), which sieves only with primes in (p₀, 2p₀], is that sieving with all primes up to √x/p₀ gains a factor of order H already at k = 1. The exponent 1/4 is the natural limit of this particular argument, since for p₀ > x^(1/4) there are no sieving primes left in (p₀, √x/p₀]. — Jaideep Sai Padhi")
]
