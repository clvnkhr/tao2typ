// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:20:48.034135+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A counterexample to the periodic tiling conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A counterexample to the periodic tiling conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 September 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/")[#text("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.ias.edu/scholars/rachel-greenfeld")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our announcement “")#link("http://arxiv.org/abs/2209.08451")[#text("A counterexample to the periodic tiling conjecture")]#text("“. This is an announcement of a longer paper that we are currently in the process of writing up (and hope to release in a few weeks), in which we disprove the ")#emph[#text("periodic tiling conjecture")]#text(" of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=857454")[#text("Grünbaum-Shephard")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("Lagarias-Wang")]#text(". This conjecture can be formulated in both discrete and continuous settings:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Discrete periodic tiling conjecture)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" Suppose that ")#mi("{F \\subset {\\bf Z}^d}")#text(" is a finite set that tiles ")#mi("{{\\bf Z}^d}")#text(" by translations (i.e., ")#mi("{{\\bf Z}^d}")#text(" can be partitioned into translates of ")#mi("{F}")#text("). Then ")#mi("{F}")#text(" also tiles ")#mi("{{\\bf Z}^d}")#text(" by translations ")#emph[#text("periodically")]#text(" (i.e., the set of translations can be taken to be a periodic subset of ")#mi("{{\\bf Z}^d}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Continuous periodic tiling conjecture)")]#text(" ")#metadata(none) <tao-0cc1c74193b578d2351e>#text(" Suppose that ")#mi("{\\Omega \\subset {\\bf R}^d}")#text(" is a bounded measurable set of positive measure that tiles ")#mi("{{\\bf R}^d}")#text(" by translations up to null sets. Then ")#mi("{\\Omega}")#text(" also tiles ")#mi("{{\\bf R}^d}")#text(" by translations periodically up to null sets.")
]

#text("The discrete periodic tiling conjecture can be easily established for ")#mi("{d=1}")#text(" by the pigeonhole principle (as first observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=429720")[#text("by Newman")]#text("), and was proven for ")#mi("{d=2}")#text(" ")#link("https://arxiv.org/abs/1602.05738")[#text("by Bhattacharya")]#text(" (with a new proof given ")#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/")[#text("by Greenfeld and myself")]#text("). The continuous periodic tiling conjecture was established for ")#mi("{d=1}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("by Lagarias and Wang")]#text(". By an old observation of Hao Wang, one of the consequences of the (discrete) periodic tiling conjecture is that the problem of determining whether a given finite set ")#mi("{F \\subset {\\bf Z}^d}")#text(" tiles by translations is (algorithmically and logically) decidable.")

#text("On the other hand, once one allows tilings by more than one tile, it is well known that ")#link("https://en.wikipedia.org/wiki/Aperiodic_tiling")[#text("aperiodic")]#text(" tile sets exist, even in dimension two – finite collections of discrete or continuous tiles that can tile the given domain by translations, but not periodically. Perhaps the most famous examples of such aperiodic tilings are the ")#link("https://en.wikipedia.org/wiki/Penrose_tiling")[#text("Penrose tilings")]#text(", but there are many other constructions; for instance, there is a construction ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1156132")[#text("of Ammann, Grümbaum, and Shephard")]#text(" of eight tiles in ")#mi("{{\\bf Z}^2}")#text(" which tile aperiodically. Recently, ")#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/")[#text("Rachel and I constructed a pair of tiles")]#text(" in ")#mi("{{\\bf Z}^d}")#text(" that tiled a periodic subset of ")#mi("{{\\bf Z}^d}")#text(" aperiodically (in fact we could even make the tiling question logically undecidable in ZFC).")

#text("Our main result is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Both the discrete and continuous periodic tiling conjectures fail for sufficiently large ")#mi("{d}")#text(". Also, there is a finite abelian group ")#mi("{G_0}")#text(" such that the analogue of the discrete periodic tiling conjecture for ")#mi("{{\\bf Z}^2 \\times G_0}")#text(" is false.")
]

#text("This suggests that the techniques used to prove the discrete periodic conjecture in ")#mi("{{\\bf Z}^2}")#text(" are already close to the limit of their applicability, as they cannot handle even virtually two-dimensional discrete abelian groups such as ")#mi("{{\\bf Z}^2 \\times G_0}")#text(". The main difficulty is in constructing the counterexample in the ")#mi("{{\\bf Z}^2 \\times G_0}")#text(" setting.")

#text("The approach starts by adapting some of the methods of a previous paper of ")#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/")[#text("Rachel and myself")]#text(". The first step is make the problem easier to solve by disproving a “multiple periodic tiling conjecture” instead of the traditional periodic tiling conjecture. At present, Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("3")]#text(" asserts the existence of a “tiling equation” ")#mi("{A \\oplus F = {\\bf Z}^2 \\times G_0}")#text(" (where one should think of ")#mi("{F}")#text(" and ")#mi("{G_0}")#text(" as given, and the tiling set ")#mi("{A}")#text(" is known), which admits solutions, all of which are non-periodic. It turns out that it is enough to instead assert the existence of a ")#emph[#text("system")]

#align(center)[#tao-fit-display[#mitex("A \\oplus F^{(m)} = {\\bf Z}^2 \\times G_0, m=1,\\dots,M")]]

#text("of tiling equations, which admits solutions, all of which are non-periodic. This is basically because one can “stack” together a system of tiling equations into an essentially equivalent single tiling equation in a slightly larger group. The advantage of this reformulation is that it creates a “tiling language”, in which each sentence ")#mi("{A \\oplus F^{(m)} = {\\bf Z}^2 \\times G_0}")#text(" in the language expresses a different type of constraint on the unknown set ")#mi("{A}")#text(". The strategy then is to locate a non-periodic set ")#mi("{A}")#text(" which one can try to “describe” by sentences in the tiling language that are obeyed by this non-periodic set, and which are “structured” enough that one can capture their non-periodic nature through enough of these sentences.")

#text("It is convenient to replace sets by functions, so that this tiling language can be translated to a more familiar language, namely the language of (certain types of) functional equations. The key point here is that the tiling equation")

#align(center)[#tao-fit-display[#mitex("A \\oplus (\\{0\\} \\times H) = G \\times H")]]

#text("for some abelian groups ")#mi("{G, H}")#text(" is precisely asserting that ")#mi("{A}")#text(" is a graph")

#align(center)[#tao-fit-display[#mitex("A = \\{ (x, f(x)): x \\in G \\}")]]

#text("of some function ")#mi("{f: G \\rightarrow H}")#text(" (this sometimes referred to as the “vertical line test” in U.S. undergraduate math classes). Using this translation, it is possible to encode a variety of functional equations relating one or more functions ")#mi("{f_i: G \\rightarrow H}")#text(" taking values in some finite group ")#mi("{H}")#text(" (such as a cyclic group).")

#text("The non-periodic behaviour that we ended up trying to capture was that of a certain “")#mi("{p}")#text("-adically structured function” ")#mi("{f_p: {\\bf Z} \\rightarrow ({\\bf Z}/p{\\bf Z})^\\times}")#text(" associated to some fixed and sufficiently large prime ")#mi("{p}")#text(" (in fact for our arguments any prime larger than ")#mi("{48}")#text(", e.g., ")#mi("{p=53}")#text(", would suffice), defined by the formula")

#align(center)[#tao-fit-display[#mitex("f_p(n) := \\frac{n}{p^{\\nu_p(n)}} \\text{ mod } p")]]

#text("for ")#mi("{n \\neq 0}")#text(" and ")#mi("{f_p(0)=1}")#text(", where ")#mi("{\\nu_p(n)}")#text(" is the number of times ")#mi("{p}")#text(" divides ")#mi("{n}")#text(". In other words, ")#mi("{f_p(n)}")#text(" is the last non-zero digit in the base ")#mi("{p}")#text(" expansion of ")#mi("{n}")#text(" (with the convention that the last non-zero digit of ")#mi("{0}")#text(" is ")#mi("{1}")#text("). This function is not periodic, and yet obeys a lot of functional equations; for instance, one has ")#mi("{f_p(pn) = f_p(n)}")#text(" for all ")#mi("{n}")#text(", and also ")#mi("{f_p(pn+j)=j}")#text(" for ")#mi("{j=1,\\dots,p-1}")#text(" (and in fact these two equations, together with the condition ")#mi("{f_p(0)=1}")#text(", completely determine ")#mi("{f_p}")#text("). Here is what the function ")#mi("{f_p}")#text(" looks like (for ")#mi("{p=5}")#text("):")

#image("../assets/50bfd8219be7bf26455359302075169c64a7ba54f0e797281d1d19d2eb41ca8e-7a1fd7a27a07486ce73123a19b333fbab9862e43df69f5b87f7bcb46d59ed0e3.png", width: 90%)

#text("It turns out that we cannot describe this one-dimensional non-periodic function directly via tiling equations. However, we can describe two-dimensional non-periodic functions such as ")#mi("{(n,m) \\mapsto f_p(An+Bm+C)}")#text(" for some coefficients ")#mi("{A,B,C}")#text(" via a suitable system of tiling equations. A typical such function looks like this:")

#image("../assets/49670d90f7998a68f127d2ace4ad8fbf53e4ceacceffc0a91399afd57d129157-6d2d598d34b7cde2ff4db7f677155382141985b5df3c221228f719183eab4afb.png", width: 90%)

#text("A feature of this function is that when one restricts to a row or diagonal of such a function, the resulting one-dimensional function exhibits “")#mi("{p}")#text("-adic structure” in the sense that it behaves like a rescaled version of ")#mi("{f_p}")#text("; see the announcement for a precise version of this statement. It turns out that the converse is essentially true: after excluding some degenerate solutions in which the function is constant along one or more of the columns, all two-dimensional functions which exhibit ")#mi("{p}")#text("-adic structure along (non-vertical) lines must behave like one of the functions ")#mi("{(n,m) \\mapsto f_p(An+Bm+C)}")#text(" mentioned earlier, and in particular is non-periodic. The proof of this result is strongly reminiscent of the type of reasoning needed to solve a ")#link("https://en.wikipedia.org/wiki/Sudoku")[#text("Sudoku puzzle")]#text(", and so we have adopted some Sudoku-like terminology in our arguments to provide intuition and visuals. One key step is to perform a shear transformation to the puzzle so that many of the rows become constant, as displayed in this example,")

#image("../assets/233f825a4129132e6e6e702f74a37d9b19ccd98e42dac2bea11beefbacc7fa5e-a99f030b0feff3998c876cd8e9e7f4edab1b259bc2ff5b7ee47e7bf0100fb8e9.png", width: 90%)

#text("and then perform a “Tetris” move of eliminating the constant rows to arrive at a secondary Sudoku puzzle which one then analyzes in turn:")

#image("../assets/d223906c7e1ffd38fa9e2a05ac211d7c00bd4dded1e02d0f5bcabe719c119233-85eb21d401e4b1e16538d05726bb4e8a980df87056a7295e41949425f4574f62.png", width: 90%)

#text("It is the iteration of this procedure that ultimately generates the non-periodic ")#mi("{p}")#text("-adic structure.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17091d4a03d31ec4dcf328fd4d4d32db71be5b910e8d970cb06458f485a78ee0-f9203420c8451af72d62b1b2b4d5e95ce44a69b089d67063cdb25ebaac827640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Amiot")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657892")[#strong[#text("Emmanuel Amiot")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("Congrats, this is huge. Very nice original ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657897")[#strong[#text("Announcing a result on the arXiv – SPP 2026")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")]

#text("[…] Today Rachel Greenfeld and Terence Tao announced via the arXiv that they can disprove the periodic tiling conjecture (arXiv:2209.08451). I do not want to discuss here in detail the contents of the conjecture or their approach to disprove it (if you are interested in this, you can read about it on Tao’s blog). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4736a6d8357bfbe59e4514a19e085da96ab8b2641b34f8ae20d40a115bd388c-3cb8131b06f04c156d5551bd61b21bd73058f81b8bf5540139f98441e9a765f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien Labbé")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657902")[#strong[#text("Sébastien Labbé")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("Sounds very interesting. I also needed to use a similar sheer transformation when studying the structure of Jeandel-Rao aperiodic tilings (doi:10.1007/s00454-019-00153-3). Also, the ““Tetris” move of eliminating the constant rows” reminds of the desubstitution steps performed in the same work. Looking forward for the long version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("Thanks for the link! You have helped me realize that this “p-adic structure” that we have in our Sudoku puzzle solutions encoded by tiling are indeed analogous to some type of susbtitution tiling, which in retrospect makes a lot of sense given how substitution tilings are a common device to make aperiodic tilings in other settings. (I don’t think that the tiling our construction ends up producing is literally a substitution tiling, though, but it certainly has some sort of self-similar structure to it…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad7219e5d2b18b5bd21328dbed2ef62677fed49e2e7c7d3808c2c4cc0202a07d-95153fcbfa12d832313fa4454d6a29be664e850a0c764b41682f23381cddcc6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix Johan Schistad Jacobsen")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657912")[#strong[#text("Felix Johan Schistad Jacobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("Tao, you are famous for knowing lots of different maths. Do you know much about q-series on number theory (something I believe to be a promising field)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("Is it possible to find also some explicit upper bounds on the minimal “sufficiently large d” in theorem 3 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("In principle all of our constructions are completely explicit, but we made no attempt to optimize the bounds and so I would imagine that a direct execution of our construction would give extremely large dimension bounds (if I had to guess, I’d say something like ")#mi("d \\sim 10^{10^5}")#text("). For instance, there is one stage in our argument where we need to encode a constraint of the form")

#mi("\\displaystyle (f_1(x),\\dots,f_M(x)) \\in \\Omega")

#text("for all ")#mi("x \\in {\\bf Z}^2")#text(", where ")#mi("M")#text(" is something of the order of ")#mi("10^4")#text(", ")#mi("f_1,\\dots,f_M \\colon {\\bf Z}^2 \\to \\{-1,1\\}")#text(" are boolean functions, and ")#mi("\\Omega \\subset \\{-1,1\\}^M")#text(" is a symmetric set. We proceed here by splitting this constraint into up to ")#mi("2^{M-1}")#text(" smaller constraints of the form")

#tao-math("\\left|\\epsilon_1 f_1(x) + \\dots + \\epsilon_M f_M(x)\\right| \\leq M-1", block: false)

#text("for various coefficients ")#mi("\\epsilon_1,\\dots,\\epsilon_M \\in \\{-1,+1\\}")#text(" (each of which corresponds to shaving one pair of antipodal corners of the cube ")#mi("\\{-1,1\\}^M")#text(" off of the range ")#mi("\\Omega")#text(") and spending a few of of the dimensions ")#mi("d")#text(" to encode each such constraint. This procedure works, but would produce dimensions that are exponential in ")#mi("M")#text(", which is already somewhat large for us. Surely there are more efficient ways to do this, but we decided to use this brute force method as it was relatively simple to implement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Rogers")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657920")[#strong[#text("Jeremy Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2022")])]

#text("If you don’t mind my asking, why an announcement? Why not just release the full paper in a couple of weeks?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("It is a good practice to announce it first, as a full paper takes much more effort, and time delay. Also, nice to have feedback from others before finishing up the paper. If you have a blog, you may want to do it too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("So announce it on the blog?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657969")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("There was some existing interest in this result (which we had announced in some less public channels than this blog), and some of this interest happens to be time-sensitive. On the other hand there is a tradeoff between how hastily we would write the longer paper, and the expositional quality of that paper, so in this case we decided to instead write a shorter announcement first (giving a simplified outline of the argument focusing on the key ideas), and take more time with the full length paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db02d613d815e77ce08800e8d998baabaab07255ff411687a947caa699ef291b-3d6f64eba5eaf012842819ce8fdf73547fbe3e0c16a4662962be585e3181807a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious middle aged man")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657962")[#strong[#text("Curious middle aged man")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("The problem reminds me of the question of whether lattices can have highest packing densities in all dimensions. The analogy being lattices are ‘periodic’ and the fundamental region being a single ’tile’. Can the approach say anything about density of sphere packings in dimensions which are open? In slightly different view point can the concept of multiple ’tiles’ be tied with lattices (multiple lattices) at all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657968")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("Our methods are rather specific to the situation in which one has perfect packing with no wasted space, but perhaps one could interpret this result as a negative result that makes it unlikely that there is any sort of general procedure to take a non-periodic tiling and somehow adjust it into a periodic tiling of equal or greater packing density, since our construction gives a counterexample to this when the sphere is replaced by another (much more complex, and most likely non-convex) body. But there could well be special structure specific to the sphere packing problem (as opposed to other tiling problems) in which lattices play a special role. (Certainly the breakthroughs of Viazovska and co-authors on sphere packing in 8 and 24 dimensions are quite specific to this spherically symmetric situation, and do not seem to apply to more general tiling problems.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-657972")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("I may be seeing a connection that does not exist, but I just now read Bernshteyn’s AMS article on descriptive combinatorics (")#link("https://www.ams.org/notices/202209/rnoti-p1496.pdf")[#text("https://www.ams.org/notices/202209/rnoti-p1496.pdf")]#text("), and it *looks* like your result might be relevant to the open question 2.14 at the end of the paper?")#linebreak()#text(" Your aperiodic tile F can be translated into a locally checkable labeling problem (LCL) by requiring that each region of a given label is in the shape of the tile. I think the existence of a Borel solution might correspond to being able to truncate the p-adic expansion at a finite order, but I’m not certain that I’m even grasping the problem correctly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2022")])]

#text("Yes, there are definitely connections between the discrete or Euclidean tilings consdered here and measurable tiling questions in which one places various descriptive set theory constraints on the sets being tiled. For instance there is a nice ")#link("https://arxiv.org/abs/2012.07567")[#text("paper of Conley, Grebik, and Pikhurko")]#text(" exploring rotational tilings of the sphere in various categories (in the spirit of the Banach-Tarski paradox). In a previous paper of ")#link("https://arxiv.org/abs/2203.01511")[#text("this paper of Grebik, Greenfeld, Rozhon, and myself")]#text(" we were able to demonstrate that there were no non-trivial “factor of iid” tilings of the lattice ")#mi("{\\bf Z}^d")#text(", which is related to the locally checkable condition you mention. It’s a good suggestion to see whether this new construction can help answer some of these questions; we’ll look into it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658001")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2022")])]

#text("The answer to this question might be “read the paper”, but I’m curious how the reduction from ")#mi("\\mathbb{Z}^d")#text(" to ")#mi("\\mathbb{Z}^2 \\times G_0")#text(" goes. I see that, if there is a tiling of ")#mi("\\mathbb{Z}^2 \\times G_0")#text(" then there is a tiling of ")#mi("\\mathbb{Z}^d")#text(", but you also need to know that, if there is a periodic tiling of ")#mi("\\mathbb{Z}^d")#text(" then there is a periodic tiling of ")#mi("\\mathbb{Z}^2 \\times G_0")#text(", and that doesn’t seem obvious to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658026")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2022")])]

#text("The main trick is to introduce a fundamental domain ")#mi("\\Omega")#text(" for ")#mi("{\\bf Z}^2 \\times G_0")#text(" in ")#mi("{\\bf Z}^d")#text(" that is “rigid” in the sense that the only way to tile ")#mi("{\\bf Z}^d")#text(" by translates of ")#mi("\\Omega")#text(" is by a lattice tiling. Such a rigid tile can be created by starting with a standard rectangular box tile and creating some “bumps” on the sides to make it look somewhat like a jigsaw puzzle piece; see Figure 9.1 of ")#link("https://arxiv.org/pdf/2108.07902.pdf")[#text("our previous paper")]#text(" for an illustration. This trick is already sufficient for the case when the tiling set is a graph of a function, which is basically the situation we have in our paper, but there is a more sophisticated version of this trick which in fact works for arbitrary tilings; this was recently shown by Meyerovitch, Sanadhya, and Solomon, in a paper which should also be appearing shortly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/603505b292346ae1305df9c97d9a0e34d768b9030c8ed17c0957e25dff5bea0b-f0cd52799bf419e1dc7f80a0e99e8d15e426066320e28b04bc97e9ada7e183da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658018")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2022")])]

#text("I wonder whether the conjecture holds in Euclidean space when one restricts to closed sets (local finiteness then implies via open-ness of the complement that the covering is seamless). It is probably false, because the set Ω may probably chosen to be closed (can’t we just make it a closed hypercube centered at the lattice point? If there aren’t enough corners in the resulting periodic tiling (from the conjecture) to prove that the hypercubes are all centered, we can probably just linearly move the hypercubes into the right position).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deleforg")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658050")[#strong[#text("deleforg")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2022")])]

#text("Congratulations for this impressive results, which seems to be the culmination of many years of efforts by you and Rachel Greenfeld, considering your previous papers on the topic. Were you aiming at this result since the beginning or did it come as a surprise?")

#text("Do you have any bound on the size of the counter-example tile? Assuming that the constants in your proof could be reduced to non-astronomical values, is there an interpretation of the Z^2 x G_0 tiling that could be “physically realizable”? i.e., does it mean that someone could build a form of 2D tiles with thickness that could translationally pave a thick plane?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658124")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2022")])]

#text("Rachel and I have been working on both the positive and negative directions of this conjecture for the past few years, and we were genuinely uncertain which way our analysis on ${\\bf Z}^2 \\times G_0$ would go. In fact at one point we believed we had positively resolved the periodic tiling conjecture on ${\\bf Z}^2 \\times G_0$ by combining the structural analysis from our first paper (which focused on positive results) with a strong version of the van der Waerden theorem; but then we found that this “strong version” had a counterexample which involved the p-adic function mentioned in this blog post. It was at this point that we decided to try encoding this p-adic function by the methods from our second paper (which focused on negative results) to get a counterexample, though it took a while to find the “Sudoku puzzle” formalism that would achieve this.")

#text("The group ")#mi("G_0")#text(" that we have is quite far from cyclic and so ")#mi("{\\bf Z}^2 \\times G_0")#text(" is not going to be a quotient of ")#mi("{\\bf Z}^3")#text(". As such it is unlikely that it can be used to directly provide a physical tiling of a three-dimensional region, unless one somehow “cheats” by using colors or some other device to simulate the additional finite dimensions of ")#mi("G_0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2022")])]

#text("Is there any “natural” generalization of this conjecture for some smooth Riemannian manifolds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2022")])]

#text("Dr. Tao:")#linebreak()#text(" What class are you teaching this fall? Could one attend it remotely?")

#emph[#text("[My class this quarter is in-person only. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54ccbe1880562cda3072982ac2c7749bf0422d7babad74e672cdd14baf0500b0-b86ef7f20f8f0796d87643aa105a78c2651b51b97828b9693596439e9b0d5e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N.S.")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658191")[#strong[#text("N.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2022")])]

#text("I think that Conjecture 2 is known to fail for $d=3$,a counterexample was constructed in 1993 by Conway and Danzer. Here it is ")#link("https://handwiki.org/wiki/Gyrobifastigium#Schmitt.E2.80.93Conway.E2.80.93Danzer_biprism")[#text("https://handwiki.org/wiki/Gyrobifastigium#Schmitt.E2.80.93Conway.E2.80.93Danzer_biprism")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70cbbd0a47a8f46941d093413fe17a8fa608c57f04e2b6bce46d7bec2b035ea0-0373c19d332f47b9d7a43416359b35f5e040a1e7097f956de7eddd77f03600db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658263")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2022")])]

#text("That tiling is not using only translations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6f1456016a5bf6ec859793e1cd73c3d282ab7a8b3e4394d52287e455e88b304-15fe0a466dcabe71d3848a23323228a275424b895996416e0fdcaa6bc6628de2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chun-Kit Lai")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658231")[#strong[#text("Chun-Kit Lai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2022")])]

#text("I am excited about the results. I know the answer will be known if I read the paper.")

#text("But I would like to know the structure of the counterexamples on $R^d$. Would it be a finite union of hypercubes, like the counterexample of Fuglede’s conjecture? Or it has to make some fractal-type boundaries making it impossible to tile periodically?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2022")])]

#text("The continuous example will be a finite union of translates of a fundamental domain of ")#mi("{\\bf R}^d/{\\bf Z}^d")#text(" which will be a slightly modified version of a unit cube in order to make it rigid; the unit cube itself is not suitable for transferring counterexamples because the standard lattice tiling by unit cubes is non-rigid (individual rows of cubes can “slide”, and in fact in high dimensions quite weird behaviour can occur, as seen by the breakdown of ")#link("https://en.wikipedia.org/wiki/Keller%27s_conjecture")[#text("Keller’s conjecture")]#text("). A picture of a rigid fundamental domain can be found in Figure 9.1 of ")#link("https://arxiv.org/pdf/2108.07902.pdf")[#text("our previous paper")]#text("; it is a finite union of slightly smaller cubes than the unit cube.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("For sufficiently large d,are such counter examples “rare” (in some sense) or not ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658389")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("This is an interesting question. There isn’t much literature on what a “typical” tile looks like – for instance I would expect the tiles which are very “rigid” and have only a few tilings much less numerous than those tiles (such as discrete boxes) which are very “non-rigid” and admit a lot of tilings, but I see no way to prove such assertions rigorously (even if one figures out some reasonable metric by which to count these tiles). Even in one dimension (or in a finite group) these sorts of questions seem hard to tackle with our current technology. But certainly once one can find one tile ")#mi("F")#text(" that tiles aperiodically, one can generate a reasonably large family of others, for instance by taking the Cartesian product ")#mi("F \\times G")#text(" with an arbitrary tile ")#mi("G")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael R.")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-658402")[#strong[#text("Michael R.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Grümbaum = Grünbaum")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-660242")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2022")])]

#text("How’s this goin?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A counterexample to the periodic tiling conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-669449")[#strong[#text("A counterexample to the periodic tiling conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2022")])]

#text("[…] periodic tiling conjecture“. This is the full version of the result I announced on this blog a few months ago, in which we disprove the periodic tiling conjecture of Grünbaum-Shephard and Lagarias-Wang. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/#comment-669451")[#strong[#text("A counterexample to the periodic tiling conjecture - My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2022")]

#text("[…] the periodic tiling conjecture“. This is the full version of the result I announced on this blog a few months ago, in which we disprove the periodic tiling conjecture of Grünbaum-Shephard and Lagarias-Wang. The […]")
]
