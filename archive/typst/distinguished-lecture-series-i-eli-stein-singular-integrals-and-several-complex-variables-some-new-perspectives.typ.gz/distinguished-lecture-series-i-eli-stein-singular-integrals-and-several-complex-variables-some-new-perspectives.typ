// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/
// Converted to Typst by tao2typ: "2026-10-14T16:35:26.149099+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series I: Elias Stein, “Singular Integrals and Several Complex Variables: Some New Perspectives”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series I: Elias Stein, “Singular Integrals and Several Complex Variables: Some New Perspectives”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/")[#text("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://www.math.ucla.edu/dls/2009/stein.shtml")[#text("first Distinguished Lecture Series at UCLA")]#text(" for this academic year is given by ")#link("http://en.wikipedia.org/wiki/Elias_Stein")[#text("Elias Stein")]#text(" (who, incidentally, was my graduate student advisor), who is lecturing on “")#link("http://www.math.ucla.edu/dls/2009/absstein.html")[#text("Singular Integrals and Several Complex Variables: Some New Perspectives")]#text("“. The first lecture was a historical (and non-technical) survey of modern ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(" (which, amazingly, was compressed into half an hour), followed by an introduction as to how this theory is currently in the process of being adapted to handle the basic analytical issues in ")#link("http://en.wikipedia.org/wiki/Several_complex_variables")[#text("several complex variables")]#text(", a topic which in many ways is still only now being developed. The second and third lectures will focus on these issues in greater depth.")

#text("As usual, any errors here are due to my transcription and interpretation of the lecture.")

#text("[")#emph[#text("Update")]#text(", Oct 27: The slides from the talk are now available ")#link("http://www.math.ucla.edu/dls/2009/stein.pdf")[#text("here")]#text(".]")

#metadata(none) <tao-c7b4c690aa01fc886b1a>#text("Harmonic analysis focuses, among other things, on establishing bounds (e.g. in ")#mi("L^p")#text(" spaces) for various linear operators of interest to other parts of analysis (complex analysis, PDE, ergodic theory, number theory, geometric measure theory, etc.). Eli described the modern history of this subject as the interplay between two opposing paradigms: the classical complex-analytic paradigm on one hand (in which one exploits the special properties of holomorphic functions), and the more modern Calderòn-Zygmund paradigm on the other (which relies primarily on real-variable techniques, such as decomposition using various types of cutoff functions). Nowadays, it is the latter paradigm that dominates, even for questions which are ostensibly in the domain of complex analysis (e.g. the ")#mi("\\overline{\\partial}")#text("-Neumann problem, the study of the Cauchy integral on domains, etc.). But Eli first reviewed the pre-Calderòn-Zygmund theory, based on complex methods, illustrating it with the famous 1923 theorem of M. Riesz:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Define the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" Hf of a (sufficiently well-behaved) function ")#mi("f: {\\Bbb R} \\to {\\Bbb C}")#text(" by the formula")

#align(center)[#mi("\\displaystyle Hf(x) := \\frac{1}{\\pi} p.v. \\int_{-\\infty}^\\infty f(x-t) \\frac{dt}{t}")#text(",")]

#text("where p.v. denotes ")#link("http://en.wikipedia.org/wiki/Cauchy_principal_value")[#text("principal value")]#text(". Then H can be extended to be a bounded continuous linear operator on the ")#link("http://en.wikipedia.org/wiki/Lp_space")[#text("Lebesgue space ")]#mi("L^p({\\Bbb R})")#text(" for every ")#mi("1 < p < \\infty")#text(".")
]

#text("Riesz’s original proof used complex analysis, in particular relating the Hilbert transform to the Cauchy integral")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f( z ) := \\frac{1}{2\\pi i} \\int_{-\\infty}^\\infty \\frac{f(t) dt}{t-z},")]]

#text("of a (well-behaved) function f; classical complex analysis tells us that ")#mi("{\\mathcal C} f")#text(" is holomorphic in the upper half-plane, and is equal to ")#mi("f")#text(" if ")#mi("f")#text(" is itself holomorphic in the upper half-plane.")

#text("One has the classical Plemelj-type formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f(x+i0^+) := \\lim_{y \\to 0^+} {\\mathcal C}f(x+iy) = \\frac{1}{2}( f(x) + i H f(x) ),")]]

#text("while from Cauchy’s theorem and the usual contour-shifting arguments, one has")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^\\infty {\\mathcal C}f(x+i0^+)^k\\ dx = 0")]]

#text("for every ")#mi("k \\geq 2")#text(". Using these two facts, Riesz was able to establish the above theorem when p was an even integer, and then concluded the remaining cases by his ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("convexity theorem")]#text(" and a duality argument.")

#text("Variants of the Hilbert transform (such as the ")#link("http://en.wikipedia.org/wiki/Riesz_transform")[#text("Riesz transforms")]#text(") arose naturally in the theory of elliptic PDE in higher dimensions. Unfortunately, complex methods broke down in higher dimensions, and so new techniques were needed in order to generalise theorems such as Riesz’s theorem above to this setting. This was done by Mihlin, ")#link("http://www.ams.org/mathscinet-getitem?mr=52553")[#text("Calderón, and Zygmund")]#text(", establishing ")#mi("L^p")#text(" mapping properties for a wide class of operators (including the Hilbert and Riesz transforms) which we now refer to as ")#emph[#text("singular integral operators")]#text(" or ")#emph[#text("Calderón-Zygmund operators")]#text(" (CZOs). There are actually several overlapping classes of CZOs, but a model example are the convolution operators ")#mi("Tf := f * K")#text(" on a Euclidean space ")#mi("{\\Bbb R}^n")#text(", where the convolution K is a distribution which is equal to a smooth function away from the origin, that obeys the size and smoothness conditions ")#tao-math("\\left|\\partial_x^\\alpha K(x)\\right| \\leq C_\\alpha \\left|x\\right|^{-n-\\alpha}", block: false)#text(" for all multi-indices ")#mi("\\alpha")#text(" and ")#mi("x \\in {\\Bbb R}^d \\backslash 0")#text(", and also obeys a cancellation condition, which can for instance be phrased in the form ")#tao-math("\\left|\\langle K, \\phi_R \\rangle\\right| \\leq C", block: false)#text(" for all ")#mi("R > 0")#text(", where ")#mi("\\phi")#text(" is a fixed bump function with non-zero mean and ")#mi("\\phi_R(x) := \\phi(x/R)")#text(" is a rescaling of that bump function. (These two conditions are obeyed for instance if ")#tao-math("K(x) = p.v. \\Omega(x)/\\left|x\\right|^n", block: false)#text(" for some function ")#mi("\\Omega")#text(" which is smooth and mean zero on the sphere ")#mi("S^{n-1}")#text(", and homogeneous of degree 0. The celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=52553")[#text("theorem of Calderón and Zygmund")]#text(" established the analogue of Riesz’s theorem for this class, i.e. all operators T in this class are bounded on ")#mi("L^p({\\Bbb R}^d)")#text(" for ")#mi("1 < p < \\infty")#text(". The proof introduced the basic Calderón-Zygmund paradigm:")

#enum(start: 1, 
[#text("First, establish boundedness on ")#mi("L^2")#text(". (In the setting of convolution operators, this is equivalent (by ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(") to establishing that ")#mi("K")#text(" has a bounded Fourier transform, which can be established easily from the hypotheses on K.)")],
[#text("Then, leverage the ")#mi("L^2")#text(" boundedness to other types of boundedness, such as weak-type (1,1) boundedness. (CZOs and similar objects are, in general, not of strong-type (1,1), i.e. they are not bounded from ")#mi("L^1")#text(" to itself, but they do often map ")#mi("L^1")#text(" to weak ")#mi("L^1")#text(".)")]
)

#text("In this paradigm it was crucial that the operators involved only had one singularity, at the origin 0 (or more precisely, on the diagonal ")#mi("x=y")#text("). It is also worth noting that the theory is both isotropic (rotation-invariant) and scale-invariant, and so is particularly well suited for problems which enjoy such symmetries (either exactly or approximately). This theory led to some fundamental tools in elliptic PDE, most notably the establishment of ")#emph[#text("elliptic regularity")]#text(", which roughly speaking asserts that when solving an elliptic equation such as ")#link("http://en.wikipedia.org/wiki/Poisson%27s_equation")[#text("Poisson’s equation")]#text(" ")#mi("\\Delta u = f")#text(", that u will have two more degrees of regularity than f in various senses (e.g. in a ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev norm")]#text(" sense).")

#text("The Calderón-Zygmund paradigm has been extended in a number of directions. One of the first directions was to establish a variable coefficient theory, in which one combines the translation-invariant convolution operators ")#mi("f \\mapsto f*K")#text(" arising from constant coefficient elliptic PDE, with such basic variable coefficient operations as pointwise multiplication ")#mi("f \\mapsto af")#text(" by some smooth function a. This leads naturally to various classes of ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudo-differential operators")]#text(" of order 0, which are morally a type of class of CZO. There is a very satisfactory theory for such operators: they are bounded on ")#mi("L^p")#text(" for ")#mi("1 < p < \\infty")#text(" as before, but they also form an algebra (the product or sum of two pseudo-differential operators is again a pseudo-differential operator), which is nearly commutative (any two such operators commute modulo “lower order” operators which are “smoothing” and can thus be neglected in many applications). There is in fact a powerful ")#emph[#text("pseudo-differential calculus")]#text(" that lets one essentially compute all sorts of operations involving pseudo-differential operators just by manipulating the underlying ")#emph[#text("symbol")]#text(" of such operators. This theory is important for many applications, one of which is in making rigorous the ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" in physics between quantum mechanics and classical mechanics.")

#text("For all the power of this generalisation, though, the theory of pseudo-differential operators was still isotropic (rotation-invariant). The next advance, to handle less isotropic situations, grew out of the theory of several complex variables, which exhibits a certain anisotropy that is not visible in the single variable theory. For instance, consider the regularity of a bounded holomorphic function f on a domain ")#mi("\\Omega \\subset {\\Bbb C}^n")#text("; for sake of concreteness let us assume that f is bounded in magnitude by 1, and that the domain has reasonable regularity. In one complex variable, it is easy to obtain a derivative bound ")#tao-math("\\left|f^{\\prime}(z)\\right| \\leq C/\\text{dist}(z,\\partial \\Omega)", block: false)#text(", basically thanks to the Cauchy integral formula and the obvious fact that if z is in the interior of the domain ")#mi("\\Omega")#text(", then the ball of radius ")#mi("\\text{dist}(z,\\partial \\Omega)")#text(" centred at z is also in this domain.")

#text("The same argument works in higher dimensions to give the same bound ")#tao-math("\\left|\\partial_{z_j} f(z)\\right| \\leq C/\\text{dist}(z,\\partial \\Omega)", block: false)#text(" for any complex derivative ")#mi("\\partial_{z_j}")#text(" of f. But a new phenomenon occurs: if one takes a vector X which is complex-tangential to a point p on the boundary ")#mi("\\partial \\Omega")#text(", which means that X and iX are both tangent to p (this never happens in one complex dimension, but is quite frequent in higher dimension), then one can obtain the better bound ")#tao-math("\\left|\\partial_X f(z)\\right| \\leq C/\\text{dist}(z,\\partial \\Omega)^{1/2}", block: false)#text(" when p is the closest point on the boundary to z, because of the geometric fact that z will be the centre of a disk of radius about ")#mi("\\text{dist}(z,\\partial \\Omega)^{1/2}")#text(" contained in ")#mi("\\Omega")#text(" and oriented in the X, iX directions. Thus we see that f has better regularity in the complex-tangential directions ")#mi("T^{\\Bbb C}_p \\partial \\Omega")#text(" (which, in the n-dimensional complex space ")#mi("{\\Bbb C}^n")#text(", are an n-1-dimensional complex hyperplane at any point).")

#text("Just as Euclidean space ")#mi("{\\Bbb R}^n")#text(" is a model geometry for isotropic situations, the ")#link("http://en.wikipedia.org/wiki/Heisenberg_group")[#emph[#text("Heisenberg group")]]#text(" ")#mi("{\\Bbb H}^n")#text(" offers a model geometry for the anisotropic situations arising in several complex variables. It is well known in one complex variable that the unit disk in ")#mi("{\\Bbb C}")#text(" is holomorphically equivalent to the upper half-plane, which has the real line ")#mi("{\\Bbb R}")#text(" as its boundary; similarly, the unit ball in ")#mi("{\\Bbb C}")#text(" is holomorphically equivalent to a domain (the ")#emph[#text("Siegel upper half-space")]#text(") whose boundary is described by the Heisenberg group. There are many ways to define this group, but one standard way is to express ")#mi("{\\Bbb H}^n")#text(" as the space of pairs ")#mi("(z,t)")#text(" with ")#mi("z \\in {\\Bbb C}^{n-1}")#text(" and ")#mi("t \\in {\\Bbb R}")#text(" with group operation ")#mi("(z,t) (z^{\\prime},t^{\\prime}) := (z+z^{\\prime}, t+t^{\\prime}+2 \\text{Im}(z \\overline{z^{\\prime}}))")#text(". The anisotropy in this group is reflected in the natural scaling ")#mi("(z,t) \\mapsto (\\delta z, \\delta^2 t)")#text(" on this space, which gives the t variable twice the homogeneity of the z variables.")

#text("The Lie group structure on the Heisenberg group gives rise to a generating set of left-invariant vector fields")

#align(center)[#tao-fit-display[#mitex("X_j := \\frac{\\partial}{\\partial x_j} + 2y_j \\frac{\\partial}{\\partial t}; \\quad Y_j := \\frac{\\partial}{\\partial y_j} - 2x_j \\frac{\\partial}{\\partial t}, \\quad T = \\frac{\\partial}{\\partial t}")]]

#text("on this group (where ")#mi("j = 1,\\ldots,n-1")#text("), obeying the usual Heisenberg commutation relations ")#mi("{}[Y_j,X_k] = -[X_k,Y_j] = 4 \\delta_{jk} T")#text(" (with all other commutators vanishing). This in turn gives rise to a natural geometry on the Heisenberg group, given by the ")#emph[#text("Carnot-Carathéodory metric")]#text(" (also called the ")#emph[#text("control metric")]#text("). Roughly speaking, the distance between two points p,q on the Heisenberg group in this metric is the length of the shortest path from p to q that one can traverse, where one uses the vector fields ")#mi("X_j, Y_j, T")#text(" as “unit vectors”. The distance between the group identity (0,0) and a typical point ")#mi("(z,t)")#text(" can be shown to be conmparable to ")#tao-math("\\left|z\\right| + \\left|t\\right|^{1/2}", block: false)#text(", thus showing the anisotropy inherent in this metric. (Distances between other pairs of points can then be deduced by using the left-invariance of the metric.)")

#text("The natural analogue of the Cauchy integral for the Heisenberg group is the ")#emph[#text("Cauchy-Szegő projection")]#text(", which can be defined using the sub-Laplacian ")#mi("{\\mathcal L} := - \\sum_{j=1}^{n-1} (X_j^2 + Y_j^2) + in T")#text(" instead of the Euclidean Laplacian. The boundedness theory of this projection follows the Calderón-Zygmund paradigm. In particular, the second step (leveraging ")#mi("L^2")#text(" boundedness to other types of boundedness) is a straightforward extension of the theory to general anisotropic settings (e.g. spaces of homogeneous type). The first step requires some new ideas though; the Fourier transform, which is so powerful in the translation-invariant Euclidean setting, is significantly less effective in the Heisenberg group setting (even with the left translation-invariance). Instead, one generalises the Fourier-analytic approach by replacing it with the more flexible method of exploiting ")#emph[#text("almost orthogonality")]#text(". The basic idea here is as follows. If one wanted to bound a linear operator T from a Hilbert space H to itself, one way to do it would be to break up H into a finite or infinite number of orthogonal pieces ")#mi("H = \\bigoplus_j H_j")#text(". If one was lucky, the operator T would also split as the direct sum ")#mi("T = \\bigoplus_j T_j")#text(" of smaller operators ")#mi("T_j: H_j \\to H_j")#text(", in which case the task of bounding T would reduce to that of bounding the individual operators ")#mi("T_j")#text(" uniformly in j. (The fact that a Fourier multiplier with a bounded symbol is bounded on ")#mi("L^2")#text(" can be viewed as a special case of this observation.) But it turns out that one does not need to decompose T into perfectly orthogonal pieces ")#mi("T_j")#text(" to do this; a decomposition of T into ")#emph[#text("almost")]#text(" orthogonal pieces would have a similar effect, thanks to tools such as the ")#link("http://en.wikipedia.org/wiki/Cotlar%E2%80%93Stein_lemma")[#text("Cotlar-Stein lemma")]#text(".")

#text("The next major development in harmonic analysis that Eli touched upon was the circle of ideas surrounding the Cauchy integral")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}_\\gamma f(z) := \\frac{1}{2\\pi i } \\int_\\gamma \\frac{f(w)}{w-z}\\ dw")]]

#text("on curves ")#mi("\\gamma")#text(" in the complex plane. For smooth curves (or even ")#mi("C^{1+\\varepsilon}")#text(" curves), the theory here is essentially the same as the Cauchy integral on the line; but the situation was much more delicate for curves with the critical regularity of ")#mi("C^1")#text(" (or of ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz")]#text(" curves). [Curves that are less regular than this are likely to be ")#link("http://en.wikipedia.org/wiki/Rectifiable_curve")[#text("unrectifiable")]#text(" and thus have no good theory.] The theory here was worked out in the late 1970s and early 1980s by ")#link("http://www.ams.org/mathscinet-getitem?mr=466568")[#text("Calderòn")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=672839")[#text("Coifman-McIntosh-Meyer")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=744071")[#text("David")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=850408")[#text("David-Semmes")]#text(". Again one followed the Calderòn-Zygmund paradigm, and again the main new difficulty lay in establishing the ")#mi("L^2")#text(" bound. The main tool used to resolve this was the ")#emph[#text("T(1) theorem")]#text(" (and its relative, the ")#emph[#text("T(b) theorem")]#text(") – a theorem that gave a simple criterion for when an operator with a singular kernel was bounded on ")#mi("L^2")#text(". (The name derives from the fact that this criterion can be expressed in terms of the image T(1) of the constant function 1, or more generally T(b) for some suitable weight function b. There is also a dual criterion involving the image ")#mi("T^*(1)")#text(" of 1 under the adjoint ")#mi("T^*")#text(" of T.) The T(1) theorem is proven by combining almost orthogonality methods with the theory of ")#emph[#text("paraproducts")]#text(" – bilinear operators that behave like portions of the pointwise product operator ")#mi("(f,g) \\mapsto fg")#text(".")

#text("Eli now turned to a much more recent development in harmonic analysis (which incorporated all of the previous technology), concerning Cauchy integral operators on domains ")#mi("\\Omega \\subset {\\Bbb C}^n")#text(" in several complex variables. What should the Cauchy integral operator ")#mi("{\\mathcal C}")#text(" be in higher dimensions? There are three desirable properties one would like, in analogy with what happens in one complex variable:")

#enum(start: 1, 
[#text("It should be a reasonably explicit operator, so that one can understand its kernel.")],
[#text("It should recover all (reasonable) holomorphic functions f on ")#mi("\\overline{\\Omega}")#text(" from the restriction ")#mi("f|_{\\partial \\Omega}")#text(", thus ")#mi("f = {\\mathcal C} ( f|_{\\partial \\Omega})")#text(".")],
[#text("It should map arbitrary (reasonable) functions on ")#mi("\\partial \\Omega")#text(" to holomorphic functions.")]
)

#text("A key problem in the subject is that in higher dimensions, there is no canonical choice for the Cauchy integral operator that obeys all of 1-3; instead, one has various families of operators that obey some or all of these properties. Also, the geometry of the domain becomes much more important than in one dimension (note that the ")#link("http://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(", which essentially asserts that there is only one complex geometry for a domain in ")#mi("{\\Bbb C}")#text(", fails utterly in higher dimensions). In particular, it becomes vital that the domain be ")#link("http://en.wikipedia.org/wiki/Pseudoconvex")[#text("pseudoconvex")]#text(" in order to have a good theory. (If a domain is not pseudoconvex at some point, then holomorphic functions on that domain can be automatically extended beyond that point, a fact sometimes colourfully referred to as the “tomato can principle”. Pseudoconvexity can be viewed as the natural generalisation of the concept of convexity that is invariant under holomorphic changes of variable.) To define pseudoconvexity one needs two degrees of regularity on the domain, and so the natural regularity here is ")#mi("C^2")#text(" (or ")#mi("C^{1,1}")#text(").")

#text("One important class of Cauchy integral operators are the ")#emph[#text("Cauchy-Fantappiè operators")]#text(", which first appeared in work of Leray in 1943. These kernels are determined by a complex 1-form ")#mi("G = g_1(z,w) dw_1 + \\ldots g_n(z,w) dw_n")#text(" on the domain ")#mi("\\Omega")#text(" (which we assume to be suitably regular), where ")#mi("z, w")#text(" range over the domain and the ")#mi("g_j")#text(" are arbitrary functions (again assuming suitable regularity). If one lets ")#mi("\\Delta = \\Delta(z,w)")#text(" be the function ")#mi("\\Delta := \\langle G, z-w \\rangle")#text(", and if one makes the non-degeneracy assumption that ")#mi("\\Delta(z,w)")#text(" is non-zero whenever ")#mi("z \\in \\Omega")#text(" and ")#mi("w \\in \\partial \\Omega")#text(", then the Cauchy-Fantappiè operator")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}_g f(z) := \\frac{1}{(2\\pi i)^n} \\int_{\\partial \\Omega} \\frac{G \\wedge \\bigwedge^{n-1} (\\overline{\\partial} G)}{\\Delta^n}\\ f(w)")]]

#text("clearly obeys Property 1, and a Stokes theorem argument can be used to show Property 2. (Note that G is a 1-form and ")#mi("\\overline{\\partial} G")#text(" is a 2-form, and so the numerator here is a (2n-1)-form, matching the real dimension of ")#mi("\\partial \\Omega")#text(".) Property 3 can also be obtained under additional assumptions on the form G, such as holomorphicity. Picking a G that obeys the non-degeneracy condition ")#mi("\\Delta \\neq 0")#text(" requires some work; Leray did this when ")#mi("\\Omega")#text(" was strictly convex, and Henkin and Ramirez extended this to the case when ")#mi("\\Omega")#text(" was strictly pseudoconvex. In the case that ")#mi("\\Omega")#text(" is given as the sublevel set ")#mi("\\Omega = \\{ z \\in {\\Bbb C}^n: \\rho(z) > 0 \\}")#text(" of some defining function ")#mi("\\rho")#text(" (which we assume to be sufficiently smooth and nondegenerate at the boundary), the strict pseudoconvexity condition can be stated as a Hermitian definiteness condition of ")#mi("\\rho")#text(" with respect to tangent complex vector fields, or more precisely that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{i,j} \\eta_i \\overline{\\eta_j} \\frac{\\partial^2 \\rho}{\\partial z_i \\partial z_j}(p) > 0")]]

#text("whenever p lies on the boundary of ")#mi("\\Omega")#text(", and ")#mi("\\sum_i \\eta_i \\frac{\\partial}{\\partial z_i}")#text(" is a complex vector field that is tangent to ")#mi("\\partial \\Omega")#text(" at p.")

#text("The natural analogue of the boundedness of the Cauchy integral operator for Lipschitz domains in several complex variables is then that the Cauchy-Fantappiè operator defined by ")#link("http://www.ams.org/mathscinet-getitem?mr=40:2902")[#text("Henkin")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=42:4767")[#text("Ramirez")]#text(", when restricted back to the boundary ")#mi("\\partial \\Omega")#text(", is bounded on ")#mi("L^p(\\partial \\Omega)")#text(" for ")#mi("1 < p < \\infty")#text(", whenever the domain ")#mi("\\Omega")#text(" is ")#mi("C^{1,1}")#text(" and strongly pseudoconvex. This claim has not quite been proven yet, but a recent result of Lanzani and Stein (to be discussed in later lectures) establishes this under the slightly stronger assumption of ")#mi("\\Omega")#text(" being ")#mi("C^{1,1}")#text(" and strongly ")#mi("{\\Bbb C}")#text("-linear convex. This has a description similar to (1), asserting that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{i,j} \\xi_i \\xi_j \\frac{\\partial^2 \\rho}{\\partial x_i \\partial x_j}(p) > 0")]]

#text("whenever ")#mi("\\sum_i \\xi_i \\frac{\\partial}{\\partial x_i}")#text(" is a ")#emph[#text("real")]#text(" vector field which lies in the complex tangent space ")#mi("T^{\\Bbb C}_p \\partial \\Omega")#text(" of ")#mi("\\partial \\Omega")#text(" at p (i.e. both the vector field, and i times that vector field, are tangent to the boundary). (2) is stronger than (1) (and is implied by strict ")#mi("{\\Bbb R}")#text("-linear convexity, i.e. ordinary strict convexity), but unlike (1), is not invariant under holomorphic changes of variable. An equivalent, and more geometric, formulation of strict ")#mi("{\\Bbb C}")#text("-linear convexity (assuming a suitably smooth domain) is that for any two nearby points p,q on the boundary of ")#mi("\\Omega")#text(", that ")#tao-math("\\text{dist}(q,T_p^{\\Bbb C}\\partial \\Omega) \\geq c \\left|p-q\\right|^2", block: false)#text(" for some positive constant c.")

#text("A second result of Lanzani and Stein shows that a modification of the above Cauchy-Fantappiè operator is bounded for ")#mi("C^2")#text(" strictly pseudoconvex domains. In the other direction, an example of ")#link("http://arxiv.org/abs/0710.0183")[#text("Barrett and Lanzani")]#text(" (using ")#link("http://planetmath.org/encyclopedia/ReinhardtDomain.html")[#text("Reinhart domains")]#text(") shows that ")#mi("C^2")#text(" cannot be replaced by ")#mi("C^{2-\\varepsilon}")#text(", and it is known that things fall apart completely (even in the ")#mi("C^\\infty")#text(" case) once the strong pseudoconvexity hypothesis is dropped. (In the case of non-strict pseudoconvexity it seems that very little is currently understood.)")

#text("Due to lack of time, Eli was not able to fully describe the tools that go into these results – these will be presumably be covered in later lectures – but he mentioned that a variant of the T(1) theorem played a key role, and that one of the main new difficulties was the presence of two independent geometries which both influence the Cauchy-Fantappiè operator – the control geometry, analogous to that of the Heisenberg group, which roughly speaking reflects boundary effects – and the Euclidean geometry induced from that of ")#mi("{\\Bbb C}^n")#text(", which roughly speaking reflects the effect of the interior.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Dear Prof. Tao:")

#text("In the definition of the Hilbert Transform, what does p.v. stand for?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Dear anonymous,")

#text("It stands for “principal value”: ")#link("http://en.wikipedia.org/wiki/Cauchy_principal_value")[#text("http://en.wikipedia.org/wiki/Cauchy_principal_value")]#text(" . I’ve amended the text accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathaaron")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33239")[#strong[#text("mathaaron")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Hi Prof. Tao,")

#text("I was wondering did he provide slides for his talk ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a247114b058708ce737786cf2b02a0eba0ebcda01cb669f6a22706c48f1d925d-a3ee3c99af4287f6c2e5bb36d90c2765059a49c172aa97243ad51fb3f5356cc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33244")[#strong[#text("Brad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("Can you — or anyone reading — recommend for someone familiar with the classical theory a book that motivates the Calderòn-Zygmund paradigm by applications to some of the other areas of analysis you mention?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33248")[#strong[#text("Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("[…] the Distinguished Lecture Series given by Eli Stein here at UCLA, Eli expanded on the themes in the first lecture, in particular providing more details as to the recent results of Lanzani and Stein on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polam")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33251")[#strong[#text("Polam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("Hi Prof. Tao,")

#text("Thank you for your nice post! Just a few small typos:")

#text("1. When you described the Carnot-Caratheodory metric on the Heisenberg group, the group identity should be (0,0) instead of (1,0).")

#text("2. In the formula for the sub-Laplacian on the Heisenberg group, the last term should be ")#mi("\\pm inT")#text(" instead of ")#mi("T^2")#text(".")

#text("3. In the last sentence of the third last paragraph, when you described different notions of convexity, the description that you have given in terms of the distance between a point q on the boundary and the complex tangent space of another nearby point p should be a characterization of strict ")#mi("\\mathbb{C}")#text(" linear convexity rather than strict ")#mi("\\mathbb{R}")#text(" linear convexity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("Dear mathaaron: Eli just gave me his transparencies, I will try to have them scanned tomorrow (though it may not actually get done until Monday).")

#text("Dear Brad: I don’t know of an introductory book like this, but the Princeton Mathematical Series text “Essays on Fourier Analysis in Honor of Elias M. Stein” has a nice collection of applications of harmonic analysis to a wide variety of fields.")

#text("Dear Polam: thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2008")])]

#text("The slides for the DLS are now available at")

#link("http://www.math.ucla.edu/dls/2009/stein.pdf")[#text("Click to access stein.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33699")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("Dear Professor Tao:")

#text("In the course of going through some notes on Navier-Stokes Equation, I came across two problems that I could not understand regarding Calderon-Zygmund operator. In the paper “Remarks on the Breakdown of Smooth Solutions for the 3-D Euler Equations” by Beale, Kato, Majoda (BKM), the velocity field u = u(x, t) was explicitly described as follows:")

#text("u(x) = – \\frac{1}{4\\pi} \\int K(x, y) \\omega(y) dy = T\\omega")

#text("where \\omega = \\nabla x u")

#text("Then using Littlewood-Paley Decomposition,")

#text("T \\omega = \\sum_{k=-\\infty}^{\\infty} P_k T\\omega")

#text("The two questions that I have been banging my head against the wall for some time now are below:")

#text("1. It is said that the P_k T\\omega is no longer singular after the Littlewood-Paley Decomposition. Why? Moreover, in the quest for an answer to this question I tried to derive the Fourier transform of")

#text("u = – \\nabla x (\\nabla^{-1} \\omega); cf (9) in BKM’s paper")

#text("I could not derive this Fourier Transform.")

#text("2. It is said that ||P_k T\\omega||_{L^\\infty} \\leq ||P_k\\omega||_{L^\\infty}. This is not immediately obvious to me.")

#text("If you could kindly inform me of your thoughts and provide a few references, it will be very much appreciated.")

#text("I apologize if this is not exactly relevant and also for not expressing above via LaTeX if it is confusing.")

#text("Best regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/#comment-33702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("Dear ky,")

#text("One can see that ")#mi("P_k T")#text(" has a smooth kernel by first looking at its Fourier multiplier symbol, which is basically a bump function adapted to the annulus of radius and width ")#mi("2^k")#text(" centred at the frequency origin. Standard Fourier transform asymptotics then give that the convolution kernel of ")#mi("P_k T")#text(" is basically an approximation to the identity at spatial scale ")#mi("2^{-k}")#text(". (For these sorts of problems, one should not rely on exact formulae for these kernels, which are often unavailable, but instead use asymptotics and estimates, for instance using such tools as the principle of stationary phase, or repeated integration by parts.)")

#text("As for Q2, one can use the Fourier transform factorise ")#mi("P_k T \\omega")#text(" as ")#mi("\\tilde P_k T P_k \\omega")#text(" where ")#mi("\\tilde P_k")#text(" is a slightly larger version of the Littlewood-Paley projection ")#mi("P_k")#text(" (e.g. one can take ")#mi("\\tilde P_k = \\sum_{j=k-5}^{k+5} P_j")#text("). The operator ")#mi("\\tilde P_k T")#text(" is bounded on ")#mi("L^\\infty")#text(", which gives the claim (there is a multiplicative constant missing in the above bound).")

#text("Good references for this material include Stein’s books on singular integrals and harmonic analysis, and Christ’s monograph on singular integrals; see also my lecture notes at")

#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes5.dvi")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes5.dvi")]

#text("or the first appendix of my book")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("Nonlinear dispersive equations: local and global analysis")]
]
]
