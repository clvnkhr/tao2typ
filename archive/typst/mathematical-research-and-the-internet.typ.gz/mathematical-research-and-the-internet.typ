// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/
// Converted to Typst by tao2typ: "2026-10-14T16:35:51.919176+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematical research and the internet", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematical research and the internet")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/")[#text("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ll be in Australia for the next month or so, giving my share of the ")#link("http://www.austms.org.au/tiki-read_article.php?articleId=61")[#text("Clay-Mahler lectures")]#text(" at various institutions in the country. My first lecture is next Monday at Melbourne University, entitled “")#link("http://wiki.ms.unimelb.edu.au/tiki-download_file.php?fileId=477")[#text("Mathematical research and the internet")]#text("“. This public lecture discusses how various internet technologies (such as blogging) are beginning to transform the way mathematicians do research.")

#text("In the spirit of that article, I have decided to ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/internet2.pdf")[#text("upload an advance copy of the talk here")]#text(", and would welcome any comments or feedback (I still have a little bit of time to revise the article). [NB: the PDF file is about 5MB in size; the original Powerpoint presentation was 10MB!]")

#text("[")#emph[#text("Update")]#text(", August 31: the talk ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/internet2.pdf")[#text("has been updated")]#text(" in view of feedback from this blog and elsewhere. For comparison, the older version of the talk can be ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/internet.pdf")[#text("found here")]#text(".]")

#text("[")#emph[#text("Update")]#text(", Sep 4: Video of the talk and other information is ")#link("http://www.amsi.org.au/index.php/news/87-general-and-outreach-news/332-terry-tao-speaks-at-melbourne-uni")[#text("available here")]#text(".]")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1215ec39572019722252f11e0bba33f52c7197eed2521c24a42ccb3b3bbedf89-3d4bba890dcfc97b6418569acc22eed03e9a15d21aefbb6b4edf29aff5661559.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary Ruben")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41168")[#strong[#text("Gary Ruben")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("I’m looking forward to your talk next week in Melbourne. This might be of relevance and interest: . If they can do this, hopefully the next obvious step for these guys would be to get Sage working within Google wave.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1215ec39572019722252f11e0bba33f52c7197eed2521c24a42ccb3b3bbedf89-3d4bba890dcfc97b6418569acc22eed03e9a15d21aefbb6b4edf29aff5661559.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary Ruben")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41182")[#strong[#text("Gary Ruben")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Looks like the link was removed from my post. Second attempt")#linebreak()#text(" ")#link("http://www.nabble.com/scipy-in-google-wave-(screenshot-attached)-td24884567.html")[#text("http://www.nabble.com/scipy-in-google-wave-(screenshot-attached)-td24884567.html")]#linebreak()#text(" If this fails, Googling “scipy in google wave” will bring up a Nabble archive of a recent post showing a scipy session running inside Google Wave. My point was that, if they can do this, getting Sage going should be a doddle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("Interesting presentation. I wish I could hear you present it.")

#text("I was looking at the graph at page 45. It seems odd that 100% of the world population own an airplane, while only 75% own a car and only 95% own a telephone. Just my 2 cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41173")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Hmm, that is strange. The graph is based on a graph of Nicholas Felton, available for instance at")

#text("but the latter doesn’t mention airplanes at all. (I was actually looking for the latter, but found the former instead, and didn’t look too carefully to check the difference.) I think I will switch to the latter graph in the presentation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uwestroinski")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41171")[#strong[#text("uwestroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("Very interesting talk. Just two observations:")

#text("1) Your remark on mathematics in Wikipedia is cryptic. Intentionally?")

#text("2) When I read the title I expected at least a small remark on the relation of printed media and the internet. What happens to the old technologies? Do journals have the same fate as the typewriter?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41175")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("1) I wasn’t being cryptic. One of wikipedia’s great strengths is its ability to constantly improve its pages over time, which is one reason why I tend to have a preference to link to their pages, all other things being equal. On the other hand, specialist wikis still tend to provide more detailed information, though on a dramatically narrower range of topics.")

#text("2) It is a good question, and I might try to put something about it in the talk, though I think I may already be hitting time constraints as it is.")

#text("While the early 20th century generation of typewriter effectively longer exists, one can make the case that computer keyboards are functionally the 21st century incarnation of the technology, so that the typewriter concept has simply adapted and evolved, rather than “died”. It seems reasonable to conjecture that something analogous will happen (or is already happening) to journals. In my opinion, the next-generation version of the journal’s functions of peer review and editing has not yet emerged, though it is conceivable this could happen in the near future. But I don’t have a clear prediction as to exactly what will happen to the academic journal system, other than that it is likely to change from the status quo, and that the internet will somehow be involved.")

#text("With regards to collaboration, a certain minimum fraction of actual physical interaction still seems essential, so we will definitely still be seeing physical conferences, classes and seminars for quite a while yet (though I expect many of these to acquire a remote viewing option – or better yet, a remote interaction option – also). This minimum fraction, though, can be quite small – I tend to see my collaborators face-to-face about one week of the year on average, and this seems to be enough to sustain the long-distance collaboration over the other 51 weeks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlo")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41176")[#strong[#text("Carlo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Dear Terry,")#linebreak()#text(" on page 28 you write “via Guiseppi Melfi”. I think this should be “Giuseppe Melfi” (or at least the name sounds italian, and Guiseppi is not italian, while Giuseppe is).")#linebreak()#text(" Best,")#linebreak()#text(" Carlo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41177")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Nice presentation, I would just like to mention one small idea – on the slide where you show your own blog, you could show this post about the presentation itself. This might give it a nice metatwist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41181")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Lovely talk, Terry. A few immediate thoughts as I browse through the talk:")

#text("* You write: “Thanks to the internet, the type of insights once reserved for seminars or conference hallways can now be preserved and accumulated.” An interesting additional aspect is that the best insights can also more and more easily be found by future mathematicians, at least when search engines do a good job of ranking. I regularly come across your posts in Google searches. The logs for my blog show a lot of people arrive at my blog that way – three of the most popular search terms are “Jordan-Wigner transformation”, “expander graphs” and “Yang-Mills theories”.")

#text("* Blogs break boundaries in interesting ways. Prior to 2007, I didn’t follow research in mathematics. I’d very occasionally read a mathematical paper as part of my work in theoretical physics, but that was all. RSS makes it so easy to follow blogs that nowadays I read a dozen or so mathematical blogs. It certainly hasn’t turned me into a mathematician, but I do know more about what’s going on in mathematics.")

#text("* Some minor details: Polymath1 took 37 days from Tim’s first research post to “Problem Probably Solved”. There were approximately 800 mathematical comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vidkun")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41183")[#strong[#text("Vidkun")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("What about proof assistants (such as HOL, coq, etc)? Georges Gonthier (who provided a formalized proof of the four colour theorem in 2005) is currently involved in a project aiming for a formalization of the Feit-Thompson theorem; is it conceivable that these tools will one day evolve into a technology used by ordinary mathematicians?")

#text("That is, in the same way that mathematicians nowadays are supposed to provide a Latex manuscript when publishing a paper – not just the ordinary written text – could one in the future be expected to provide a formalized proof of the theorem along with the ordinary article? (This would essentially remove the whole need for a peer review system, at least as far as this is only supposed to guarantee correctness of the claimed results.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41184")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Hi Terry,")#linebreak()#text(" The thing with journals is that they are ranked by impact factor. In some countries, in addition to a salary, an author is paid for publications according to a scale based on the factor. This might be necessary due to extremely corruptive tendencies of some societies. So having only arxiv won’t do. The question is whether refereeing is always on a peer level, like it is supposed to be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41185")[#strong[#text("Mathematical Research and the Internet « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/")[#text("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d529333425a240650df5a9340483eb57cef01492505ede9bc484aef9f9ff3f5c-689c4f22a94fbe8cbebca21c97342337c2f7d8643d731f7cab2293912aab03d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Corneli")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41186")[#strong[#text("Joseph Corneli")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("This quote from the talk sums up a problem we’ve been")#linebreak()#text(" concerned about at PlanetMath since around 2006:")

#text("“There are many promising technologies out there to help")#linebreak()#text(" do research better. In some ways, there are too many such")#linebreak()#text(" technologies. And they don’t always work well with each other.”")

#text("Our idea is to develop a “meta-commons” that will help coordinate")#linebreak()#text(" between disparate projects in math. In fact, soon we may have a")#linebreak()#text(" staff person (me) with a few hours a week to devote to this")#linebreak()#text(" coordination project.")

#text("PlanetMath is still not very well funded, and in any case, we can’t")#linebreak()#text(" do this project alone, so if anyone in another part of the online-math")#linebreak()#text(" market has time or resources to put towards this collaboration, please")#linebreak()#text(" get in touch!")

#text("For some background, see:")#linebreak()#text(" ")#link("http://wiki.planetmath.org/AsteroidMeta/metacommons_manifesto")[#text("http://wiki.planetmath.org/AsteroidMeta/metacommons_manifesto")]

#text("A couple other quick notes: (1) I think the talk is an excellent")#linebreak()#text(" survey of the “stakeholders”; (2) I’d love to have this talk")#linebreak()#text(" be the beginning of a conversation about next steps…")

#text("“these issues should fade with time as later generations of tools")#linebreak()#text(" become easier to use, more integrated, and more mainstream.”")

#text("How can we work together to bring this about?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b84c0c6dee52e806be1ea04072746851f09a4aa9722be65c7743eff99f3c63af-b3e1fae15150784053640bcd4ad6f278e63aae813e191564c48184612d9c597a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of markchicobay")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41190")[#strong[#text("markchicobay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Hey Terry long time since PAC. Looking forward to seeing your talk in Melbourne.")

#text("Can I make a suggestion re your slides. On slides 15,16,17, n+1, :) etc, the comment for discussion is at the bottom of the slide and the image on top.")

#text("This is probably not a good idea. It will be harder for the audience to see your comment and thus understand your slide.")

#text("Put the comment at the top of the slide, where it is clearly visible to everyone. Consider the case of people at the back of the theatre with heads in front of them, the comment at the bottom of the slide will not be visible at all.")

#text("Mark")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b84c0c6dee52e806be1ea04072746851f09a4aa9722be65c7743eff99f3c63af-b3e1fae15150784053640bcd4ad6f278e63aae813e191564c48184612d9c597a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of markchicobay")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41191")[#strong[#text("markchicobay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Another way the internet has changed things for mathematicians is the collaborative processing (computing) power available through principles of distributed processing and more recently cloud computing. eg ")#link("http://www.mersenne.org/")[#text("http://www.mersenne.org/")]#text(" searching for Mersenne primes using desktops all around the world.")

#text("Without the internet researchers would be only able to use local computing power. Might be worth a mention.")

#text("M")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079cb57937093f8327931689e37fbb2200cfc232528e21aa0977888321d71bc7-f2117a98624bb427e54718daad39bba5d3b2ff5987d9b7ab60f6a074ea3be262.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41200")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2009")])]

#text("The talk is exciting, depressed that I won’t be able to be present there. Prof. Tao, do you have any plans of coming to India in the near future.")

#text("Also I thought mention should have been made of specifically math wikis and ")#link("http://www.mersenne.org")[#text("http://www.mersenne.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cffdb6b71884cfab901aa079ab7d41e9b032ef53a48798958aeda575740f1de-41b28b74b34ec45e94511686954f2bfa55030ea004b90394ab26f17125c5a0cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Rotkowitz")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41201")[#strong[#text("Mike Rotkowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2009")])]

#text("Terry, I’m looking forward to it, and especially to Tuesday’s lecture on CS. Will you be able to similarly post slides ahead of time for that as well? Thanks, –Mike")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2009")])]

#text("Thanks for all the suggestions! I’ve incorporated them into the latest version of the talk, which is likely to be the version I will be given this evening; updated links are in the main post.")

#text("I should be able to post a few more of the Mahler lectures in a few days. (An old version of the compressed sensing talk can be found ")#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/")[#text("here")]#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d529333425a240650df5a9340483eb57cef01492505ede9bc484aef9f9ff3f5c-689c4f22a94fbe8cbebca21c97342337c2f7d8643d731f7cab2293912aab03d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Corneli")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41206")[#strong[#text("Joseph Corneli")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2009")])]

#text("FYI and FWIW…")

#text("I’ve put up a wiki page with links to all of the items discussed")#linebreak()#text(" in Terry Tao’s talk (or their best representatives on the web), plus a")#linebreak()#text(" few extras I found in the process:")

#link("http://wiki.planetmath.org/AsteroidMeta/Surveying_the_Math_Metacommons")[#text("http://wiki.planetmath.org/AsteroidMeta/Surveying_the_Math_Metacommons")]

#text("I have further started a “stakeholder analysis”, beginning with")#linebreak()#text(" “use cases” and “some potential problems”. Only in the brainstorming")#linebreak()#text(" phase at present! I’m happy to discuss further: I created a google")#linebreak()#text(" group where we could have an in-depth discussion on “how to move")#linebreak()#text(" forward” — i.e. w/o hijacking this blog.")

#link("http://groups.google.com/group/math-meta?hl=en")[#text("http://groups.google.com/group/math-meta?hl=en")]

#text("And of course you’re welcome to edit the wiki — note, you will have to")#linebreak()#text(" be added to the editors list; posting to the the google group would be")#linebreak()#text(" a good way to introduce yourself to our little enclave & secure")#linebreak()#text(" editing permission. I know there are plenty of items that aren’t on the")#linebreak()#text(" list yet!")

#text("Joe")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41209")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("lol I thought it was the other way round, that “maths is useful for the internet”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b84c0c6dee52e806be1ea04072746851f09a4aa9722be65c7743eff99f3c63af-b3e1fae15150784053640bcd4ad6f278e63aae813e191564c48184612d9c597a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41217")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Hi Terry thanks for your talk on Monday!")

#text("One thing I wanted to raise is that all this collaboration is wonderful, but don’t get complacent about backups.")

#text("Just because the work is “on the internet” doesn’t mean it is safe from hardware failure. We would like to think so but if you check the WordPress Terms of Service for wordpress.com you will see you have nothing to rely on.")

#text("If the site has a hardware failure and months of mathematical posts are lost, it’s gone. Maybe they have a backup and it works, but maybe they don’t. You’re relying on a free service to do real work. In a commercial context it would be flagged as a very big risk.")

#text("Never, ever, rely solely on third parties for backups.")

#text("Always make your own backup. Always!")

#text("Think it can’t happen to a commercial company with millions of users? Think again:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Ma.gnolia")[#text("http://en.wikipedia.org/wiki/Ma.gnolia")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bec2a18033cf3be514197365b628258914d8580aa23c16bc00421c4e769849d-9a82f8f3a7619277699c75fc95d6a071bcd8731a689e48713e51d51636a9a7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Harrigan")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41224")[#strong[#text("Mark Harrigan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Terry – thanks for the talk – I enjoyed it very much and was particularly interested in the example of collaboration leading to a solution of a specific mathematical problem (combinatorial approach to desnity Hales-Jewitt). A fascinating form of meta-cognition. I do a lot of collaborative technical problem solving and am curious at to whether the particular meta-cognitive approach used was guided or emergent (self-organising). By “guided” I mean did one (or more) of the collaborators take it upon themselves to guide the discustion and act as arbiter (where required) as to the best/better options. By emergent I mean did the group “self-organise” and converge toward a solution without guidance. Or was it a mixture? Any elaboration you can provide? :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41242")[#strong[#text("Mathematical research and the internet | Research tips")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")]

#text("[…] On Monday night I attended a lecture by Terry Tao on “Mathematical research and the internet”. Terry is Australia’s most famous mathematician, our only Field’s medalist, and one of the most active mathematical bloggers in the world. He has been described as the “Mozart of mathematics” for his remarkable precocity and prolific output. The slides of his talk are available on his blog site. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41256")[#strong[#text("Clay-Mahler lecture series « Mathematics in Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")]

#text("[…] Here are the slides for the public lecture “Mathematical research and the internet”. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A speech for the American Academy of Arts and Sciences « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41452")[#strong[#text("A speech for the American Academy of Arts and Sciences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("[…] is on the future impact of internet-based technologies on academia (somewhat similar in theme to my recent talk on this topic). I have a draft text below the fold, though it is currently too long and my actual speech is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FUA Lektion 0: Vorbemerkungen « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-41613")[#strong[#text("FUA Lektion 0: Vorbemerkungen « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")])]

#text("[…] Den Inhalt der jeweiligen Themenkreise werden vorab über den Blog zur Verfügung gestellt und können für die Vorbereitung genutzt werden. Die Beweise, ergänzende Beispiele etc. werden dann in der Vorlesung ausführlich besprochen und vorgestellt. Fragen, Kommentare und Ergänzungen hierzu sind erwünscht und sollten mit Hilfe des Kommentar-Feed eingegeben werden. Einen Interessanten Artikel zu Mathematik über das Internet findet man hier. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Das Internet « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-43548")[#strong[#text("Das Internet « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2010")])]

#text("[…] der Mathematik macht die Globalisierung nicht halt. Eine interessante Zusammenstellung findet unter “Mathematical Research and the Internet” auf dem Blog von T. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-44119")[#strong[#text("Maffs and the internets « From Calculus to Columbia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2010")]

#text("[…] ideas, a medium that facilitates the large scale exchange of ideas can only be a good thing. By no leap of the imagination am I the first person to have remarked on this, but it´s still worth […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Analysis 1: Warming-Up « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-73379")[#strong[#text("Analysis 1: Warming-Up « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2011")])]

#text("[…] Wer mehr über Mathematik und Internet wissen möchte, der findet auf dem Blog von Terence Tao einen interessanten Artikel und Vortrag unter Mathematical research and the internet. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-82309")[#strong[#text("365 Tao |")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")]

#text("[…] #split {}#single {}#splitalign {margin-left: auto; margin-right: auto;}#singlealign {margin-left: auto; margin-right: auto;}.linkboxtext {line-height: 1.4em;}.linkboxcontainer {padding: 7px 7px 7px 7px;background-color:#eeeeee;border-color:#000000;border-width:0px; border-style:solid;}.linkboxdisplay {padding: 7px 7px 7px 7px;}.linkboxdisplay td {text-align: center;}.linkboxdisplay a:link {text-decoration: none;}.linkboxdisplay a:hover {text-decoration: underline;} function opensingledropdown() { document.getElementById('singletablelinks').style.display = ''; document.getElementById('singlemouse').style.display = 'none'; } function closesingledropdown() { document.getElementById('singletablelinks').style.display = 'none'; document.getElementById('singlemouse').style.display = ''; } Terence Tao Talks About Things That I Can UnderstandAustria Blogs | Blog | Ji KangThe Mind Manual System365 Tao, 108 Gatesoglcoc.com365 Tao: 316 – RestRegardless of your Background… The destiny is still yoursCreate a destinyHow do you know what your destiny is?Mathematical research and the internet […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/27/mathematical-research-and-the-internet/#comment-409886")[#strong[#text("Hyndsight - Mathematical research and the internet")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2014")]

#text("[…] On Mon­day night I attended a lec­ture by Terry Tao on “Math­e­mat­i­cal research and the inter­net”. Terry is Australia’s most famous math­e­mati­cian, our only Field’s medal­ist, and one of the most active math­e­mat­i­cal blog­gers in the world. He has been described as the “Mozart of math­e­mat­ics” for his remark­able pre­coc­ity and pro­lific out­put. The slides of his talk are avail­able on his blog site. […]")
]
