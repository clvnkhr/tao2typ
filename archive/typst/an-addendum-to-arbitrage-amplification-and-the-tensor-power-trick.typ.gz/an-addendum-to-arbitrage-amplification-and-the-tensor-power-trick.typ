// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/
// Converted to Typst by tao2typ: "2026-10-14T15:19:55.060676+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An addendum to “amplification, arbitrage, and the tensor power trick”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An addendum to “amplification, arbitrage, and the tensor power trick”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 August 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In one of the ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("earliest posts on this blog")]#text(", I talked about the ability to “arbitrage” a disparity of symmetry in an inequality, and in particular to “amplify” such an inequality into a stronger one. (The principle can apply to other mathematical statements than inequalities, with the “hypothesis” and “conclusion” of that statement generally playing the role of the “right-hand side” and “left-hand side” of an inequality, but for sake of discussion I will restrict attention here to inequalities.) One can formalise this principle as follows. Many inequalities in analysis can be expressed in the form ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A(f) \\leq B(f)")]]

#text("for all ")#mi("{f}")#text(" in some space ")#mi("{X}")#text(" (in many cases ")#mi("{X}")#text(" will be a function space, and ")#mi("{f}")#text(" a function in that space), where ")#mi("{A(f)}")#text(" and ")#mi("{B(f)}")#text(" are some functionals of ")#mi("{f}")#text(" (that is to say, real-valued functions of ")#mi("{f}")#text("). For instance, ")#mi("{B(f)}")#text(" might be some function space norm of ")#mi("{f}")#text(" (e.g. an ")#mi("{L^p}")#text(" norm), and ")#mi("{A(f)}")#text(" might be some function space norm of some transform of ")#mi("{f}")#text(". In addition, we assume we have some group ")#mi("{G}")#text(" of symmetries ")#mi("{T: X \\rightarrow X}")#text(" acting on the underlying space. For instance, if ")#mi("{X}")#text(" is a space of functions on some spatial domain, the group might consist of translations (e.g. ")#mi("{Tf(x) = f(x-h)}")#text(" for some shift ")#mi("{h}")#text("), or perhaps dilations with some normalisation (e.g. ")#mi("{Tf(x) = \\frac{1}{\\lambda^\\alpha} f(\\frac{x}{\\lambda})}")#text(" for some dilation factor ")#mi("{\\lambda > 0}")#text(" and some normalisation exponent ")#mi("{\\alpha \\in {\\bf R}}")#text(", which can be thought of as the dimensionality of length one is assigning to ")#mi("{f}")#text("). If we have")

#align(center)[#tao-fit-display[#mitex("A(Tf) = A(f)")]]

#text("for all symmetries ")#mi("{T \\in G}")#text(" and all ")#mi("{f \\in X}")#text(", we say that ")#mi("{A}")#text(" is ")#emph[#text("invariant")]#text(" with respect to the symmetries in ")#mi("{G}")#text("; otherwise, it is not.")

#text("Suppose we know that the inequality ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" holds for all ")#mi("{f \\in X}")#text(", but that there is an imbalance of symmetry: either ")#mi("{A}")#text(" is ")#mi("{G}")#text("-invariant and ")#mi("{B}")#text(" is not, or vice versa. Suppose first that ")#mi("{A}")#text(" is ")#mi("{G}")#text("-invariant and ")#mi("{B}")#text(" is not. Substituting ")#mi("{f}")#text(" by ")#mi("{Tf}")#text(" in ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" and taking infima, we can then amplify ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" to the stronger inequality")

#align(center)[#tao-fit-display[#mitex("A(f) \\leq \\inf_{T \\in G} B(Tf).")]]

#text("In particular, it is often the case that there is a way to send ")#mi("{T}")#text(" off to infinity in such a way that the functional ")#mi("{B(Tf)}")#text(" has a limit ")#mi("{B_\\infty(f)}")#text(", in which case we obtain the amplification ")#metadata(none) <tao-431b36f2b16be7471a7c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A(f) \\leq B_\\infty(f)")]]

#text("of ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(". Note that these amplified inequalities will now be ")#mi("{G}")#text("-invariant on both sides (assuming that the way in which we take limits as ")#mi("{T \\rightarrow \\infty}")#text(" is itself ")#mi("{G}")#text("-invariant, which it often is in practice). Similarly, if ")#mi("{B}")#text(" is ")#mi("{G}")#text("-invariant but ")#mi("{A}")#text(" is not, we may instead amplify ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("\\sup_{T \\in G} A(Tf) \\leq B(f)")]]

#text("and in particular (if ")#mi("{A(Tf)}")#text(" has a limit ")#mi("{A_\\infty(f)}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(") ")#metadata(none) <tao-05418f7af32f3c72947d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("A_\\infty(f) \\leq B(f).")]]

#text("If neither ")#mi("{A(f)}")#text(" nor ")#mi("{B(f)}")#text(" has a ")#mi("{G}")#text("-symmetry, one can still use the ")#mi("{G}")#text("-symmetry by replacing ")#mi("{f}")#text(" by ")#mi("{Tf}")#text(" and taking a limit to conclude that")

#align(center)[#tao-fit-display[#mitex("A_\\infty(f) \\leq B_\\infty(f),")]]

#text("though now this inequality is not obviously stronger than the original inequality ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" (for instance it could well be trivial). In some cases one can also average over ")#mi("{G}")#text(" instead of taking a limit as ")#mi("{T \\rightarrow \\infty}")#text(", thus averaging a non-invariant inequality into an invariant one.")

#text("As discussed in ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("the previous post")]#text(", this use of amplification gives rise to a general principle about inequalities: ")#emph[#text("the most efficient inequalities are those in which the left-hand side and right-hand side enjoy the same symmetries")]#text(". It is certainly possible to have true inequalities that have an imbalance of symmetry, but as shown above, such inequalities can always be amplified to more efficient and more symmetric inequalities. In the case when limits such as ")#mi("{A_\\infty}")#text(" and ")#mi("{B_\\infty}")#text(" exist, the limiting functionals ")#mi("{A_\\infty(f)}")#text(" and ")#mi("{B_\\infty(f)}")#text(" are often simpler in form, or more tractable analytically, than their non-limiting counterparts ")#mi("{A(f)}")#text(" and ")#mi("{B(f)}")#text(" (this is one of the main reasons ")#emph[#text("why")]#text(" we take limits at infinity in the first place!), and so in many applications there is really no reason to use the weaker and more complicated inequality ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(", when stronger, simpler, and more symmetric inequalities such as ")#link(<tao-431b36f2b16be7471a7c>)[#text("(2)")]#text(", ")#link(<tao-05418f7af32f3c72947d>)[#text("(3)")]#text(" are available. Among other things, this explains why many of the most useful and natural inequalities one sees in analysis are ")#link("https://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensionally consistent")]#text(".")

#text("One often tries to prove inequalities ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" by directly chaining together simpler inequalities. For instance, one might attempt to prove ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" by by first bounding ")#mi("{A(f)}")#text(" by some auxiliary quantity ")#mi("{C(f)}")#text(", and then bounding ")#mi("{C(f)}")#text(" by ")#mi("{B(f)}")#text(", thus obtaining ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" by chaining together two inequalities ")#metadata(none) <tao-8e9766083b3bfc2003f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("A(f) \\leq C(f) \\leq B(f).")]]

#text("A variant of the above principle then asserts that ")#emph[#text("when proving inequalities by such direct methods, one should, whenever possible, try to maintain the symmetries that are present in both sides of the inequality")]#text(". Why? Well, suppose that we ignored this principle and tried to prove ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" by establishing ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(" for some ")#mi("{C}")#text(" that is ")#emph[#text("not")]#text(" ")#mi("{G}")#text("-invariant. Assuming for sake of argument that ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(" were actually true, we could amplify the first half ")#mi("{A(f) \\leq C(f)}")#text(" of this inequality to conclude that")

#align(center)[#tao-fit-display[#mitex("A(f) \\leq \\inf_{T \\in G} C(Tf)")]]

#text("and also amplify the second half ")#mi("{C(f) \\leq B(f)}")#text(" of the inequality to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sup_{T \\in G} C(Tf) \\leq B(f)")]]

#text("and hence ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(" amplifies to ")#metadata(none) <tao-035721b44289aef591b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("A(f) \\leq \\inf_{T \\in G} C(Tf) \\leq \\sup_{T \\in G} C(Tf) \\leq B(f).")]]

#text("Let’s say for sake of argument that all the quantities involved here are positive numbers (which is often the case in analysis). Then we see in particular that ")#metadata(none) <tao-446c0c22b6c40d2b0ce9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{\\sup_{T \\in G} C(Tf)}{\\inf_{T \\in G} C(Tf)} \\leq \\frac{B(f)}{A(f)}.")]]

#text("Informally, ")#link(<tao-446c0c22b6c40d2b0ce9>)[#text("(6)")]#text(" asserts that in order for the strategy ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(" used to prove ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" to work, the extent to which ")#mi("{C}")#text(" fails to be ")#mi("{G}")#text("-invariant cannot exceed the amount of “room” present in ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(". In particular, when dealing with those “extremal” ")#mi("{f}")#text(" for which the left and right-hand sides of ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" are comparable to each other, one can only have a bounded amount of non-")#mi("{G}")#text("-invariance in the functional ")#mi("{C}")#text(". If ")#mi("{C}")#text(" fails so badly to be ")#mi("{G}")#text("-invariant that one does not expect the left-hand side of ")#link(<tao-446c0c22b6c40d2b0ce9>)[#text("(6)")]#text(" to be at all bounded in such extremal situations, then the strategy of proving ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" using the intermediate quantity ")#mi("{C}")#text(" is doomed to failure – even if one has already produced some clever proof of one of the two inequalities ")#mi("{A(f) \\leq C(f)}")#text(" or ")#mi("{C(f) \\leq B(f)}")#text(" needed to make this strategy work. And even if it did work, one could amplify ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(" to a simpler inequality ")#metadata(none) <tao-5d5931ee703125ec513c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("A(f) \\leq C_\\infty(f) \\leq B(f)")]]

#text("(assuming that the appropriate limit ")#mi("{C_\\infty(f) = \\lim_{T \\rightarrow \\infty} C(Tf)}")#text(" existed) which would likely also be easier to prove (one can take whatever proofs one had in mind of the inequalities in ")#link(<tao-8e9766083b3bfc2003f7>)[#text("(4)")]#text(", conjugate them by ")#mi("{T}")#text(", and take a limit as ")#mi("{T \\rightarrow \\infty}")#text(" to extract a proof of ")#link(<tao-5d5931ee703125ec513c>)[#text("(7)")]#text(").")

#text("Here are some simple (but somewhat contrived) examples to illustrate these points. Suppose one wishes to prove the inequality ")#metadata(none) <tao-c8aada734719b55cacc9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("xy \\leq x^2 + y^2")]]

#text("for all ")#mi("{x,y>0}")#text(". Both sides of this inequality are invariant with respect to interchanging ")#mi("{x}")#text(" with ")#mi("{y}")#text(", so the principle suggests that when proving this inequality directly, one should only use sub-inequalities that are also invariant with respect to this interchange. However, in this particular case there is enough “room” in the inequality that it is possible (though somewhat unnatural) to violate this principle. For instance, one could decide (for whatever reason) to start with the inequality")

#align(center)[#tao-fit-display[#mitex("0 \\leq (x - y/2)^2 = x^2 - xy + y^2/4")]]

#text("to conclude that")

#align(center)[#tao-fit-display[#mitex("xy \\leq x^2 + y^2/4")]]

#text("and then use the obvious inequality ")#mi("{x^2 + y^2/4 \\leq x^2+y^2}")#text(" to conclude the proof. Here, the intermediate quantity ")#mi("{x^2 + y^2/4}")#text(" is not invariant with respect to interchange of ")#mi("{x}")#text(" and ")#mi("{y}")#text(", but the failure is fairly mild (changing ")#mi("{x}")#text(" and ")#mi("{y}")#text(" only modifies the quantity ")#mi("{x^2 + y^2/4}")#text(" by a multiplicative factor of ")#mi("{4}")#text(" at most), and disappears completely in the most extremal case ")#mi("{x=y}")#text(", which helps explain why one could get away with using this quantity in the proof here. But it would be significantly harder (though still not impossible) to use non-symmetric intermediaries to prove the sharp version")

#align(center)[#tao-fit-display[#mitex("xy \\leq \\frac{x^2 + y^2}{2}")]]

#text("of ")#link(<tao-c8aada734719b55cacc9>)[#text("(8)")]#text(" (that is to say, the arithmetic mean-geometric mean inequality). Try it!")

#text("Similarly, consider the task of proving the triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|z+w\\right| \\leq \\left|z\\right| + \\left|w\\right|", block: true)]]

#text("for complex numbers ")#mi("{z, w}")#text(". One could try to leverage the triangle inequality ")#tao-math("{\\left|x+y\\right| \\leq \\left|x\\right| + \\left|y\\right|}", block: false)#text(" for real numbers by using the crude estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|z+w\\right| \\leq \\left|\\text{Re}(z+w)\\right| + \\left|\\text{Im}(z+w)\\right|", block: true)]]

#text("and then use the real triangle inequality to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{Re}(z+w)\\right| \\leq \\left|\\text{Re}(z)\\right| + \\left|\\text{Re}(w)\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{Im}(z+w)\\right| \\leq \\left|\\text{Im}(z)\\right| + \\left|\\text{Im}(w)\\right|", block: true)]]

#text("and then finally use the inequalities ")#metadata(none) <tao-44ba554e17977b31413d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|\\text{Re}(z)\\right|, \\left|\\text{Im}(z)\\right| \\leq \\left|z\\right|", block: true)]]

#text("and ")#metadata(none) <tao-60c5590f72eef292f954>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\text{Re}(w)\\right|, \\left|\\text{Im}(w)\\right| \\leq \\left|w\\right|", block: true)]]

#text("but when one puts this all together at the end of the day, one loses a factor of two:")

#align(center)[#tao-fit-display[#tao-math("\\left|z+w\\right| \\leq 2(\\left|z\\right| + \\left|w\\right|).", block: true)]]

#text("One can “blame” this loss on the fact that while the original inequality ")#link(<tao-cddd67830982a78cc839>)[#text("(9)")]#text(" was invariant with respect to phase rotation ")#mi("{(z,w) \\mapsto (e^{i\\theta} z, e^{i\\theta} w)}")#text(", the intermediate expressions we tried to use when proving it were not, leading to inefficient estimates. One can try to be smarter than this by using Pythagoras’ theorem ")#tao-math("{\\left|z\\right|^2 = \\left|\\text{Re}(z)\\right|^2 + \\left|\\text{Im}(z)\\right|^2}", block: false)#text("; this reduces the loss from ")#mi("{2}")#text(" to ")#mi("{\\sqrt{2}}")#text(" but does not eliminate it completely, which is to be expected as one is still using non-invariant estimates in the proof. But one can remove the loss completely by using amplification; see ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("the previous blog post")]#text(" for details (we also give a reformulation of this amplification below).")

#text("Here is a slight variant of the above example. Suppose that you had just learned in class to prove the triangle inequality ")#metadata(none) <tao-89eafe87f75cd4ec8dfc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("(\\sum_{n=1}^\\infty \\left|a_n+b_n\\right|^2)^{1/2} \\leq (\\sum_{n=1}^\\infty \\left|a_n\\right|^2)^{1/2} + (\\sum_{n=1}^\\infty \\left|b_n\\right|^2)^{1/2}", block: true)]]

#text("for (say) real square-summable sequences ")#mi("{(a_n)_{n=1}^\\infty}")#text(", ")#mi("{(b_n)_{n=1}^\\infty}")#text(", and was tasked to conclude the corresponding inequality ")#metadata(none) <tao-8b977393d3881617cc95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("(\\sum_{n \\in {\\bf Z}} \\left|a_n+b_n\\right|^2)^{1/2} \\leq (\\sum_{n \\in {\\bf Z}} \\left|a_n\\right|^2)^{1/2} + (\\sum_{n \\in {\\bf Z}} \\left|b_n\\right|^2)^{1/2}", block: true)]]

#text("for doubly infinite square-summable sequences ")#mi("{(a_n)_{n \\in {\\bf Z}}, (b_n)_{n \\in {\\bf Z}}}")#text(". The quickest way to do this is of course to exploit a bijection between the natural numbers ")#mi("{1,2,\\dots}")#text(" and the integers, but let us say for sake of argument that one was unaware of such a bijection. One could then proceed instead by splitting the integers into the positive integers and the non-positive integers, and use ")#link(<tao-89eafe87f75cd4ec8dfc>)[#text("(12)")]#text(" on each component separately; this is very similar to the strategy of proving ")#link(<tao-cddd67830982a78cc839>)[#text("(9)")]#text(" by splitting a complex number into real and imaginary parts, and will similarly lose a factor of ")#mi("{2}")#text(" or ")#mi("{\\sqrt{2}}")#text(". In this case, one can “blame” this loss on the abandonment of translation invariance: both sides of the inequality ")#link(<tao-8b977393d3881617cc95>)[#text("(13)")]#text(" are invariant with respect to shifting the sequences ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(", ")#mi("{(b_n)_{n \\in {\\bf Z}}}")#text(" by some shift ")#mi("{h}")#text(" to arrive at ")#mi("{(a_{n-h})_{n \\in {\\bf Z}}, (b_{n-h})_{n \\in {\\bf Z}}}")#text(", but the intermediate quantities caused by splitting the integers into two subsets are not invariant. Another way of thinking about this is that the splitting of the integers gives a privileged role to the origin ")#mi("{n=0}")#text(", whereas the inequality ")#link(<tao-8b977393d3881617cc95>)[#text("(13)")]#text(" treats all values of ")#mi("{n}")#text(" equally thanks to the translation invariance, and so using such a splitting is unnatural and not likely to lead to optimal estimates. On the other hand, one can deduce ")#link(<tao-8b977393d3881617cc95>)[#text("(13)")]#text(" from ")#link(<tao-89eafe87f75cd4ec8dfc>)[#text("(12)")]#text(" by sending this symmetry to infinity; indeed, after applying a shift to ")#link(<tao-89eafe87f75cd4ec8dfc>)[#text("(12)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{n=-N}^\\infty \\left|a_n+b_n\\right|^2)^{1/2} \\leq (\\sum_{n=-N}^\\infty \\left|a_n\\right|^2)^{1/2} + (\\sum_{n=-N}^\\infty \\left|b_n\\right|^2)^{1/2}", block: true)]]

#text("for any ")#mi("{N}")#text(", and on sending ")#mi("{N \\rightarrow \\infty}")#text(" we obtain ")#link(<tao-8b977393d3881617cc95>)[#text("(13)")]#text(" (one could invoke the monotone convergence theorem here to justify the limit, though in this case it is simple enough that one can just use first principles).")

#text("Note that the principle of preserving symmetry only applies to ")#emph[#text("direct")]#text(" approaches to proving inequalities such as ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(". There is a complementary approach, discussed for instance in ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("this previous post")]#text(", which is to ")#emph[#text("spend")]#text(" the symmetry to place the variable ")#mi("{f}")#text(" “without loss of generality” in a “normal form”, “convenient coordinate system”, or a “good gauge”. Abstractly: suppose that there is some subset ")#mi("{Y}")#text(" of ")#mi("{X}")#text(" with the property that every ")#mi("{f \\in X}")#text(" can be expressed in the form ")#mi("{f = Tg}")#text(" for some ")#mi("{T \\in G}")#text(" and ")#mi("{g \\in Y}")#text(" (that is to say, ")#mi("{X = GY}")#text("). Then, if one wishes to prove an inequality ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" for all ")#mi("{f \\in X}")#text(", and one knows that both sides ")#mi("{A(f), B(f)}")#text(" of this inequality are ")#mi("{G}")#text("-invariant, then it suffices to check ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" just for those ")#mi("{f}")#text(" in ")#mi("{Y}")#text(", as this together with the ")#mi("{G}")#text("-invariance will imply the same inequality ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" for all ")#mi("{f}")#text(" in ")#mi("{GY=X}")#text(". By restricting to those ")#mi("{f}")#text(" in ")#mi("{Y}")#text(", one has given up (or ")#emph[#text("spent")]#text(") the ")#mi("{G}")#text("-invariance, as the set ")#mi("{Y}")#text(" will in typical not be preserved by the group action ")#mi("{G}")#text(". But by the same token, by eliminating the invariance, one also eliminates the prohibition on using non-invariant proof techniques, and one is now free to use a wider range of inequalities in order to try to establish ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(". Of course, such inequalities should make crucial use of the restriction ")#mi("{f \\in Y}")#text(", for if they did not, then the arguments would work in the more general setting ")#mi("{f \\in X}")#text(", and then the previous principle would again kick in and warn us that the use of non-invariant inequalities would be inefficient. Thus one should “spend” the symmetry wisely to “buy” a restriction ")#mi("{f \\in Y}")#text(" that will be of maximal utility in calculations (for instance by setting as many annoying factors and terms in one’s analysis to be ")#mi("{0}")#text(" or ")#mi("{1}")#text(" as possible).")

#text("As a simple example of this, let us revisit the complex triangle inequality ")#link(<tao-cddd67830982a78cc839>)[#text("(9)")]#text(". As already noted, both sides of this inequality are invariant with respect to the phase rotation symmetry ")#mi("{(z,w) \\mapsto (e^{i\\theta} z, e^{i\\theta} w)}")#text(". This seems to limit one to using phase-rotation-invariant techniques to establish the inequality, in particular ruling out the use of real and imaginary parts as discussed previously. However, we can instead ")#emph[#text("spend")]#text(" the phase rotation symmetry to restrict to a special class of ")#mi("{z}")#text(" and ")#mi("{w}")#text(". It turns out that the most efficient way to spend the symmetry is to achieve the normalisation of ")#mi("{z+w}")#text(" being a nonnegative real; this is of course possible since any complex number ")#mi("{z+w}")#text(" can be turned into a nonnegative real by multiplying by an appropriate phase ")#mi("{e^{i\\theta}}")#text(". Once ")#mi("{z+w}")#text(" is a nonnegative real, the imaginary part disappears and we have")

#align(center)[#tao-fit-display[#tao-math("\\left|z+w\\right| = \\text{Re}(z+w) = \\text{Re}(z) + \\text{Re}(w),", block: true)]]

#text("and the triangle inequality ")#link(<tao-cddd67830982a78cc839>)[#text("(9)")]#text(" is now an immediate consequence of ")#link(<tao-44ba554e17977b31413d>)[#text("(10)")]#text(", ")#link(<tao-60c5590f72eef292f954>)[#text("(11)")]#text(". (But note that if one had unwisely spent the symmetry to normalise, say, ")#mi("{z}")#text(" to be a non-negative real, then one is no closer to establishing ")#link(<tao-cddd67830982a78cc839>)[#text("(9)")]#text(" than before one had spent the symmetry.)")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-485253")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2017")])]

#text("” for all {f}&fg=0 00000 in some space {X} ” on line following (1) ??")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-485254")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2017")])]

#text("line after (12) “was” -> “were” !")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d476857d9ea22cecf24fec34d953f4d2ce3d196b948b80e6bd3fbdd5e69720c-8fbc5ad0de5b78a56743a1ebfefe2a9b09e5e61dc67d9a87184b8b96c96f5e60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Missing T")]], [#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-485256")[#strong[#text("Missing T")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2017")])]

#text("The inequality between (2) and (3) is missing a “T” on the LHS.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbe72cf48279b71d6052ad5ac6f43e0ff834d29ec69f5511832267f8eaed5ea0-099b9b77f3a2cc841dbcfac85b8606646ce994535f84fa48d2271c37c3fc01b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-485334")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Very interesting, thank you! Might there be similar principles concerning the averaging of inequalities, like Kahane’s inequality?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-485516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("Dear Terry,")#linebreak()#text(" Every morning,I get up and then I always open your blog.I don´t know why I read your blog avidly.I am very happy if up coming day you succeed of great problems.It appears to release my thirsty.I am expecting you every minute.Good luck to you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-power-trick/#comment-500795")[#strong[#text("What is the most difficult-seeming problem you’ve seen become trivialized after a clever symmetry argument? – Nevin Manimala’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2018")]

#text("[…] gets you out of computing large multi-integrals. Inspired somewhat by Terry Tao’s [article](")#link("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-powe&#8230")[#text("https://terrytao.wordpress.com/2017/08/22/an-addendum-to-arbitrage-amplification-and-the-tensor-powe&#8230")]#text(";) on “amplifying” inequalities through symmetry. What are the best applications of the […]")
]
