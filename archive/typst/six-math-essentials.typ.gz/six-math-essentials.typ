// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/02/16/six-math-essentials/
// Converted to Typst by tao2typ: "2026-10-14T16:39:21.869868+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Six Math Essentials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Six Math Essentials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 February 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/")[#text("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a brief announcement that I have been working with ")#link("https://www.quantabooks.org/")[#text("Quanta Books")]#text(" to publish a short book in popular mathematics entitled “")#link("https://us.macmillan.com/books/9780374621797/sixmathessentials/")[#text("Six Math Essentials")]#text("“, which will cover six of the fundamental concepts in mathematics — numbers, algebra, geometry, probability, analysis, and dynamics — and how they connect with our real-world intuition, the history of math and science, and to modern practice of mathematics, both in theory and in applications. The scheduled publication date is Oct 27, but it is currently available for ")#link("https://us.macmillan.com/books/9780374621797/sixmathessentials/")[#text("preorder")]#text(".")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("This is perhaps too reductive a question, but what ages are you imagining this book to be for?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("This book is for a general audience, without necessarily having a college-level math education. It is aimed more at adults than at children, but some children with an interest in mathematics may be able to get something of it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3529ef3432f19f545244ebd5f1dcf2e0c12c9d7a202f84575075a8a6a8f28b46-4e0415730b98015d10729ff930abd4ed7e2d3b9eb85d1d109c12918dde1913bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoseBrox")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691798")[#strong[#text("JoseBrox")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Its publication in Spain (translated by Editorial Acantilado) was also announced by Quantabooks, but without an specific release date. Do you know whether your book will be published simultaneously worldwide?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("International publication dates are still mostly TBD but it’s like UK and France will be simultaneous.")

#text("Thomas Lin, Quanta Books")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("That is, mostly “likely” simultaneously published in UK and France. I know other countries are considering simultaneous publication too. We’ll know more as it gets closer to release.")

#text("Thomas Lin")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e70606473f4efb3447a7d40452c1c56a278379ce578ac2d49059ef6c98eb4bc9-160ed4e2751d0376670bac5b9c8d382ae9e0bbd2b567c38ae5e8fb03eea782e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oukilwalid")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691799")[#strong[#text("oukilwalid")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Bien que je ne puisse pas commander ce livre sur Amazon pour le moment, j’estime qu’il relève de la philosophie des mathématiques ; une philosophie particulière, à mon sens. L’obstacle que je rencontre actuellement dans ma compréhension des mathématiques, et que je souhaite partager avec vous à l’occasion de la parution de ce livre, est le suivant : Quelle implication en découle ? L’équation 1 + 1 = 2 implique-t-elle une équation très complexe ? Ou bien une équation très complexe implique-t-elle 1 + 1 = 2 ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Could you briefly describe the content of that book?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Thanks for the heads up. Can’t wait to get my hands on it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Is there a sample page? Since it is quanta magazine and do hope also for high quality graphics (for high quality text I have no doubts:))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("I expect that sample pages will be made available after the pages have been proofed and designed. Stay tuned.")

#text("Thomas Lin")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("very interesting, Terence.I hope I could acquire such book. I am crossing fingers for getting inmerse in deep maths.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691807")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Dear Prof. Tao,")

#text("Will there be a sample chapter like that for your cosmic distance ladder book?")

#text("Thanks.")

#emph[#text("[I will check into the possibility of doing so and update when I have a clearer answer. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691808")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2026")])]

#text("Also, another question, Prof. Tao,")

#text("Why isn’t logic considered a fundamental concept of math? Is the reason that whether math presupposes logic is still a philosophical debate?")

#text("What about meta studies of math, like proof theory, then?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("I am ")#link("https://chatgpt.com/share/6994b59e-54fc-800e-8a59-e3c05ea0754c")[#text("outsourcing this question to an AI")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/585260e13957b3b3fb21f67b8f8f524d89249edb84971cb0bc5fb2d5edb963e3-d86b76b3f6cf4554bf505745786995e394bbc1cfac4916f25b13702bc9584e0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thoughtfullyd4c9a86b93")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691824")[#strong[#text("thoughtfullyd4c9a86b93")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("My two cents worth — Logic is fundamental. Most of mathematics does not treat infinities nor singularities as first class citizens. Yet, there are a lot of problem classes in which you can actually reason with a set that includes those limits. My preference is a strict axiomatic hierarchy where you can not blend “levels”. Each level is a gatekeeper for the next tier.")

#text("The idea that mathematics is a language of its own does not work until you completely disambiguate mathematics in your language of choice — and logic is a language that facilitates complete understanding.")

#text("* ⟨T⟩0: ZFC (The Material). The box that contains the idea of a box. If you aren’t starting here, you aren’t even playing the game.")#linebreak()#text("* ⟨T⟩1: Topology (The Stage). This defines “nearness” before you own a ruler. It’s the rubber floor where a donut is a coffee cup—and where singularities (like the zero-point or the absolute) are perfectly admissible inhabitants.")#linebreak()#text("* ⟨T⟩2: Geometry (The Ruler). Adding distance and angles. It’s just Topology after it’s been forced to commit to a specific measurement.")#linebreak()#text("* ⟨T⟩3: Algebra (The Syntax). The ledger for people who trust the ruler more than the stage. It tracks the symmetries the geometry allows.")#linebreak()#text("* ⟨T⟩4: Analysis (The Measure). Measuring the vibration of a string to prove the violin is real. Great for change, but “blind” to the structural admissibility of the stage itself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dthayes83")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691812")[#strong[#text("dthayes83")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("Hi Professor Tao and world,")#linebreak()#text("Happy Chinese New Year.")#linebreak()#text("Kind regards,")#linebreak()#text("Dr Hayes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11e54d593c1a3a62b0562e72bcf8c268df7f1f67dc17aaf10019f975410f5093-cbfe092998f49da41f1e026fa579067df16f392325ccdaff861bd295cdd90f91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uros Colovic")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691838")[#strong[#text("Uros Colovic")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("When I saw 6 Math Essentials I was sure that this was about six functor formalism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("I heard you have been working on textbook about analytic and probabilistic number theory. Do you have any update on it?")

#emph[#text("[I am currently not planning to convert my existing lecture notes into a book. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2026")])]

#text("Any update on when the cosmic distance ladder book is coming out?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/510c66552aeb522f5cb76b75c478fe636cf66825f909bb6c727daf61b2947f20-6dbbb40e17caf4d3068d1767901bd69105f87b499754457556d5c4ae80051e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TheCoherenceCat")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691844")[#strong[#text("TheCoherenceCat")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2026")])]

#text("Waiting for it! It will be a pleasure to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/942eff4986ea20877a73654cefd9fb536fb92443b5f8e7e4bffe6657bae4063a-33858a3c567bbfaa7a1e77d01dfc47391d116c5bf4bde3cade8d7f09f644c8d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ziad Baroudi")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691891")[#strong[#text("Ziad Baroudi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2026")])]

#text("I can’t wait to read this book!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-691942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2026")])]

#text("Are there many examples in the book?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/#comment-694316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("watched your talk on Big Think about the book.Enjoyed very much the stories on the applications and challenges faced in astronomy, navigation and traffic (cars & Internet) and how concepts in mathmatics are used to understand and improve them. Looking forward to acquiring a copy. Thank you for writing it.")
]
