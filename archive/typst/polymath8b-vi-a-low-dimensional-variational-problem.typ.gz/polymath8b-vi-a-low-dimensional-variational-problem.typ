// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:54.619648+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, VI: A low dimensional variational problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, VI: A low dimensional variational problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 January 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/")[#text("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the sixth thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the wiki page")]#text(" (which has recently returned to full functionality, after a partial outage).")

#text("The current focus is on improving the upper bound on ")#mi("{H_1}")#text(" under the assumption of the generalised Elliott-Halberstam conjecture (GEH) from ")#mi("{H_1 \\leq 8}")#text(" to ")#mi("{H_1 \\leq 6}")#text(", which looks to be the limit of the method (see ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265235")[#text("this previous comment")]#text(" for a semi-rigorous reason as to why ")#mi("{H_1 \\leq 4}")#text(" is not possible with this method). With the most general Selberg sieve available, the problem reduces to the following three-dimensional variational one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Does there exist a (not necessarily convex) polytope ")#mi("{R \\subset [0,1]^3}")#text(" with quantities ")#mi("{0 \\leq \\varepsilon_1,\\varepsilon_2,\\varepsilon_3 \\leq 1}")#text(", and a non-trivial square-integrable function ")#mi("{F: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" supported on ")#mi("{R}")#text(" such that")

#list(
[#mi("{R + R \\subset \\{ (x,y,z) \\in [0,2]^3: \\min(x+y,y+z,z+x) \\leq 2 \\},}")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dx = 0}")#text(" when ")#mi("{y+z \\geq 1+\\varepsilon_1}")#text(";")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dy = 0}")#text(" when ")#mi("{x+z \\geq 1+\\varepsilon_2}")#text(";")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dz = 0}")#text(" when ")#mi("{x+y \\geq 1+\\varepsilon_3}")#text(";")]
)

#text("and such that we have the inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{y+z \\leq 1-\\varepsilon_1} (\\int_{\\bf R} F(x,y,z)\\ dx)^2\\ dy dz")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{z+x \\leq 1-\\varepsilon_2} (\\int_{\\bf R} F(x,y,z)\\ dy)^2\\ dz dx")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{x+y \\leq 1-\\varepsilon_3} (\\int_{\\bf R} F(x,y,z)\\ dz)^2\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("> 2 \\int_R F(x,y,z)^2\\ dx dy dz?")]]
]

#text("(Initially it was assumed that ")#mi("{R}")#text(" was convex, but we have now realised that this is not necessary.)")

#text("An affirmative answer to this question will imply ")#mi("{H_1 \\leq 6}")#text(" on GEH. We are “within almost two percent” of this claim; we cannot quite reach ")#mi("{2}")#text(" yet, but have got as far as ")#mi("{1.959633}")#text(". However, we have not yet fully optimised ")#mi("{F}")#text(" in the above problem.")

#text("The most promising route so far is to take the symmetric polytope")

#align(center)[#tao-fit-display[#mitex("R = \\{ (x,y,z) \\in [0,1]^3: x+y+z \\leq 3/2 \\}")]]

#text("with ")#mi("{F}")#text(" symmetric as well, and ")#mi("{\\varepsilon_1=\\varepsilon_2=\\varepsilon_3=\\varepsilon}")#text(" (we suspect that the optimal ")#mi("{\\varepsilon}")#text(" will be roughly ")#mi("{1/6}")#text("). (However, it is certainly worth also taking a look at easier model problems, such as the polytope ")#mi("{{\\cal R}^{\\prime}_3 := \\{ (x,y,z) \\in [0,1]^3: x+y,y+z,z+x \\leq 1\\}}")#text(", which has no vanishing marginal conditions to contend with; more recently we have been looking at the non-convex polytope ")#mi("{R = \\{x+y,x+z \\leq 1 \\} \\cup \\{ x+y,y+z \\leq 1 \\} \\cup \\{ x+z,y+z \\leq 1\\}}")#text(".) Some further details of this particular case are given below the fold.")

#text("There should still be some progress to be made in the other regimes of interest – the unconditional bound on ")#mi("{H_1}")#text(" (currently at ")#mi("{270}")#text("), and on any further progress in asymptotic bounds for ")#mi("{H_m}")#text(" for larger ")#mi("{m}")#text(" – but the current focus is certainly on the bound on ")#mi("{H_1}")#text(" on GEH, as we seem to be tantalisingly close to an optimal result here.")

#metadata(none) <tao-b02349ddd49c7801f335>

#heading(level: 1)[#strong[#text(" — 1. Analysis of the symmetric polytope — ")]]

#text("In the symmetric situation described above, we have a single vanishing marginal condition")

#list(
[#mi("{\\int_0^{3/2-x-y} F(x,y,z)\\ dz = 0}")#text(" when ")#mi("{(x,y) \\in [0,1]^2}")#text(" is such that ")#mi("{1+\\varepsilon_3 \\leq x+y \\leq 3/2}")]
)

#text("and the inequality we wish to prove is that")

#align(center)[#tao-fit-display[#mitex("3\\int_{x+y \\leq 1-\\varepsilon} (\\int_0^{\\min(1,3/2-x-y)} F(x,y,z)\\ dz)^2\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("> 2 \\int_R F(x,y,z)^2\\ dx dy dz.")]]

#text("A routine calculus of variations computation, using Lagrange multipliers, tells us that the extremal ")#mi("{F}")#text(" should take the form ")#metadata(none) <tao-319bd30c7a232e903e34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F(x,y,z) = G(x,y) + G(y,z) + G(z,x)")]]

#text("where ")#mi("{G}")#text(" is symmetric and supported the disconnected set ")#mi("{T_0 \\cup T_1}")#text(", where ")#mi("{T_0}")#text(" is the triangle")

#align(center)[#tao-fit-display[#mitex("T_0 := \\{ (x,y) \\in [0,1]^2: x+y \\leq 1-\\varepsilon\\}")]]

#text("and ")#mi("{T_1}")#text(" is the trapezoid")

#align(center)[#tao-fit-display[#mitex("T_1 := \\{ (x,y) \\in [0,1]^2: 1+\\varepsilon \\leq x+y \\leq 3/2 \\}.")]]

#text("(Strictly speaking, we have not established that an extremiser actually exists, but for the purposes of numerics it seems to be reasonable to proceed as if an extremiser does exist.) One also has the eigenfunction equation")

#align(center)[#tao-fit-display[#mitex("(M^{\\prime\\prime}_{3,\\varepsilon,1})^{-1} \\int_0^{\\min(1,3/2-x-y)} F(x,y,z)\\ dz = G(x,y)")]]

#text("whenever ")#mi("{(x,y) \\in [0,1]^2}")#text(" is such that ")#mi("{x+y \\leq 1-\\varepsilon}")#text(", where ")#mi("{M^{\\prime\\prime}_{3,\\varepsilon,1}}")#text(" is the quantity that we are trying to push above ")#mi("{2}")#text(". It seems that this eigenfunction equation should indicate where exactly we expect the singularities of ")#mi("{F}")#text(" and ")#mi("{G}")#text(" to lie, and how bad they will be (our best guess right now is that the extremiser is continuous but not differentiable at certain points), but this has not yet been fully analysed.")

#text("If we use the ansatz ")#link(<tao-319bd30c7a232e903e34>)[#text("(1)")]#text(", we arrive at a moderately complicated variational problem involving one unknown symmetric function ")#mi("{G(x,y)}")#text(", which is constrained to be supported in ")#mi("{T_0 \\cup T_1}")#text(" and obeys the vanishing marginal condition")

#align(center)[#tao-fit-display[#mitex("\\int_0^{3/2-x-y} (G(x,y) + G(y,z) + G(z,x))\\ dz = 0")]]

#text("whenever ")#mi("{(x,y)}")#text(" lies in ")#mi("{T_1}")#text(". If we let ")#mi("{G_0, G_1}")#text(" be the restrictions of ")#mi("{G}")#text(" to ")#mi("{T_0,T_1}")#text(" respectively (so that ")#mi("{G = G_0 + G_1}")#text("), this constraint becomes")

#align(center)[#tao-fit-display[#mitex("(3/2-x-y) G_1(x,y) + H_0(x,y) + H_1(x,y) + H_0(y,x) + H_1(y,x) = 0")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("H_0(x,y) := \\int_{0 \\leq z \\leq \\min(3/2-x-y,1-\\varepsilon-y)} G_0(y,z)\\ dz")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H_1(x,y) := \\int_{1+\\varepsilon-y \\leq z \\leq 3/2-x-y} G_1(y,z)\\ dz.")]]

#text("This equation can be used to solve for ")#mi("{G_1}")#text(" in terms of ")#mi("{G_0}")#text(", thus reducing to a variational problem for an unconstrained function ")#mi("{G_0}")#text(" on the triangle ")#mi("{T_0}")#text(". In the hexagonal region")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in T_1: x, y \\geq 1/2 - \\varepsilon \\}")]]

#text("the functions ")#mi("{H_1(x,y), H_1(y,x)}")#text(" vanish, and we simply have")

#align(center)[#tao-fit-display[#mitex("G_1(x,y) = -\\frac{H_0(x,y) + H_0(y,x)}{3/2-x-y}")]]

#text("(note that ")#mi("{H_0}")#text(" vanishes at the boundary ")#mi("{x+y=3/2}")#text(", so there is no singularity here). If ")#mi("{\\varepsilon \\geq 1/4}")#text(", this covers all of ")#mi("{T_1}")#text(", and completes the reduction to a variational problem for ")#mi("{G_0}")#text(". We do not believe this range to be the optimal value for ")#mi("{\\varepsilon}")#text(", but might be worth considering as a warmup.")

#text("Now suppose ")#mi("{\\varepsilon < 1/4}")#text(". In the triangular region ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\{ (x,y) \\in T_1: x \\leq 1/2-\\varepsilon\\}")]]

#text("(bounded by the vertices ")#mi("{(\\varepsilon,1)}")#text(", ")#mi("{(1/2-\\varepsilon,1)}")#text(", ")#mi("{(1/2-\\varepsilon,1/2+2\\varepsilon)}")#text(") we have vanishing of ")#mi("{H_1(y,x)}")#text(" but not ")#mi("{H_1(x,y)}")#text(", leading to the equation ")#metadata(none) <tao-05b8b79eea5088487f03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(3/2-x-y) G_1(x,y) + H_0(x,y) + H_0(y,x) + \\int_{1+\\varepsilon-y}^{3/2-x-y} G_1(z,y)\\ dz = 0.")]]

#text("To solve this equation, we first differentiate it in ")#mi("{x}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("(3/2-x-y) \\partial_x G_1(x,y) - G_1(x,y) + \\partial_x H_0(x,y) + \\partial_x H_0(y,x)")]]

#align(center)[#tao-fit-display[#mitex("- G_1(3/2-x-y,y) = 0,")]]

#text("so if we define")

#align(center)[#tao-fit-display[#mitex("K_1(x,y) := G_1(x,y) + G_1(3/2-x-y,y)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("L_0(x,y) := \\partial_x H_0(x,y) + \\partial_x H_0(y,x)")]]

#text("then ")#metadata(none) <tao-9b38d8c13fdaad5c8445>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_x G_1(x,y) = \\frac{K_1(x,y)}{3/2-x-y} - \\frac{L_0(x,y)}{3/2-x-y}")]]

#text("and thus by the substitution ")#mi("{x \\mapsto 3/2-x-y}")#text(" (which preserves the triangle ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(", as well as ")#mi("{K}")#text(")")

#align(center)[#tao-fit-display[#mitex("-\\partial_x G_1(3/2-x-y,y) = \\frac{K_1(x,y)}{x} - \\frac{L_0(3/2-x-y,y)}{x}")]]

#text("and so on subtracting")

#tao-aligned(keep: true)[


#tao-math("\\partial_x K_1(x,y)  & = K_1(x,y) (\\frac{1}{3/2-x-y} - \\frac{1}{x}) - \\frac{L_0(x,y)}{3/2-x-y}", block: true)



#tao-math(" & + \\frac{L_0(3/2-x-y,y)}{x};", block: true)
]

#text("multiplying by ")#mi("{x (x+y-3/2)}")#text(" and rearranging, this becomes")

#tao-aligned(keep: true)[


#tao-math("\\partial_x ( x (x+y-3/2) K_1(x,y) )  & = L_0(x,y) x", block: true)



#tao-math(" & + L_0(3/2-x-y,y) (x+y-3/2),", block: true)
]

#text("so we have")

#align(center)[#tao-fit-display[#mitex("K_1(x,y) = N_0(x,y) + C_1(y) (3/2-y) ( \\frac{1}{x} + \\frac{1}{3/2-x-y} )")]]

#text("for some function ")#mi("{C_1(y)}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("N_0(x,y)  & := \\frac{1}{x(x+y-3/2)} \\int_{(3/2-y)/2}^x L_0(x^{\\prime},y) x^{\\prime}", block: true)



#tao-math(" & + L_0(3/2-x^{\\prime}-y,y) (x^{\\prime}+y-3/2)\\ dx^{\\prime},", block: true)
]

#text("where we are using the signed integral, thus ")#mi("{\\int_b^a = -\\int_a^b}")#text(" when ")#mi("{a>b}")#text(". Note that when ")#mi("{x = (3/2-y)/2}")#text(", ")#mi("{N_0(x,y)}")#text(" vanishes and ")#mi("{K_1(x,y) = 2 G_1(x,y)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("G_1( (3/2-y)/2, y ) = 2 C_1(y).")]]

#text("Meanwhile, from ")#link(<tao-9b38d8c13fdaad5c8445>)[#text("(4)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\partial_x G_1(x,y)  & = \\frac{N_0(x,y)-L_0(x,y)}{3/2-x-y} + C_1(y) \\frac{(3/2-y)}{(3/2-x-y)^2}", block: true)



#tao-math(" & + C_1(y) (\\frac{1}{x} + \\frac{1}{3/2-x-y})", block: true)
]

#text("and so")

#align(center)[#tao-fit-display[#mitex("G_1(x,y) = P_0(x,y) + C_1(y) ( \\frac{3/2-y}{3/2-x-y} + \\log \\frac{x}{3/2-x-y} )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("P_0(x,y) := \\int_{(3/2-y)/2}^x \\frac{N_0(x^{\\prime},y)-L_0(x^{\\prime},y)}{3/2-x^{\\prime}-y}\\ dx^{\\prime}.")]]

#text("On the other hand, from ")#link(<tao-05b8b79eea5088487f03>)[#text("(3)")]#text(" with ")#mi("{x=1/2-\\varepsilon}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("(1+\\varepsilon-y) G_1(1/2-\\varepsilon,y) + H_0(1/2-\\varepsilon,y) + H_0(y,1/2-\\varepsilon) = 0")]]

#text("and so we may solve for ")#mi("{C_1}")#text(" as")

#align(center)[#tao-fit-display[#mitex("C_1(y) = - \\frac{ \\frac{1}{1+\\varepsilon-y} (H_0(1/2-\\varepsilon,y) + H_0(y,1/2-\\varepsilon)) + P_0(1/2-\\varepsilon,y)}{ \\frac{3/2-y}{1+\\varepsilon-y} + \\log \\frac{1/2-\\varepsilon}{1+\\varepsilon-y} }")]]

#text("which gives an explicit (but messy) formula for ")#mi("{G_1}")#text(" in terms of ")#mi("{G_0}")#text(" in the triangle ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text("; by symmetry one also describes ")#mi("{G_1}")#text(" in the triangle")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y) \\in T_1: y \\leq 1/2-\\varepsilon \\},")]]

#text("and this completes the description of ")#mi("{G_1}")#text(" in terms of ")#mi("{G_0}")#text(". (The exact description is, however, rather messy, in particular requiring a certain amount of integration; it is not clear whether we should actually use it for the purposes of efficient numerics.)")

#heading(level: 1)[#text("Comments (104)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265310")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("In problem 1, ")#mi("F")#text(" should be in ")#mi("L^2(R)")#text(" with positive norm, and in the definition of ")#mi("R")#text(" the maximum should be ")#mi("\\leq 2")#text(".")

#emph[#text("[Corrected, thanks – although the constraint ")#mi("R+R \\subset [0,2]^3")#text(" actually already forces ")#mi("R \\subset [0,1]^3")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265315")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("The maximum (in the def. of ")#mi("R")#text(") should be corrected to ")#mi("\\leq 2")#text(" (instead of ")#mi("\\geq 2")#text(").")#linebreak()#text(" And three closing parentheses are missing.")

#emph[#text("[Corrected, although I don’t see where the three missing closing parentheses are. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265336")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I’m sorry (no need for closing parentheses.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265324")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("It seems that condition (4) in the previous thread is that the minimum is ")#mi("<  2")#text(".")

#emph[#text("[Corrected – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("Just before “1. Analysis of the symmetric polytope”: 272 –> 270.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("The very last word: “numericss” –> “numerics”")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265345")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("It seems that in the eigenfunction equation above, ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" should be on the RHS.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265537")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("It seems that the LHS should be without the factor 3.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265350")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("Two quick questions relating to loose ends from the previous thread:")

#text("1) Can I just clarify: is it still believed that H_1 could be reduced from 8 to 6 on GEH if M”_4 could be pushed to a point that allows “n,n+8 both prime” to be excluded (estimated as 2.35), or is there now a variant of the argument for k=3, H_1=4 which precludes that? I ask only because this avenue for progress is strangely unmentioned in the new post.")

#text("2) While the focus remains on k=3 it seems worthwhile to maintain some awareness of the potential for ideas currently in play to translate to the unconditional setting as and when attention returns to it. In particular, the original mention of converting F(x,y,z) to G(x,y) noted the computational efficiency advantage, so it would be valuable to understand whether a corresponding conversion can be performed for larger k. If it can, does it also preserve the ability to avoid partitioning (at the cost of looking at a reduced range of possible F’s) that was mentioned in the thread before last?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I don’t see any strong barrier to the k=4 approach to ")#mi("H_1 \\leq 6")#text(", except for the purely numerical one that we would have to make a much larger improvement in the M_4 statistic to reach this than we would for the M_3 statistic. (Note that 2.35 is only a heuristic computation; in practice, we would probably have to be more efficient still than this.)")

#text("I’m hoping that by playing around with enough variants of the k=3 problem, we will naturally discover efficient ways to do slightly higher values of k (4 or 5, for instance), and can maybe start extrapolating how much gain one could get from various tricks in higher k. I suspect though that most of these gains decay rather fast in k, though if we become better at optimising on the truncated simplex, then we could finally use some of the Polymath8a results, which so far have only been used for m >= 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265524")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Aubrey, as you pointed out in the previous thread, I was being more than a little optimistic that we could reach 2.35. It’s still worthwhile to see what happens (if we can’t make the k=3 case work), but now that I’ve thought about it a bit more, getting to 2.35 seems like a long shot.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265424")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Three lines above (1), the LHS should be multiplied by 3.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265453")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("The exact expression of ")#mi("G_1")#text(" is (at least) useful by providing more detailed information on the possible locations (and types) of its singularities in ")#mi("T_1")#text(" (assuming certain regularity properties of ")#mi("G_0")#text(" in ")#mi("T_0")#text(").")#linebreak()#text(" ")#mi("G_0, G_1")#text(" may be approximated by piecewise polynomials (using polygonal partition adapted to the above information on the possible locations of singularities).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("I cannot see the last part of the inequality just above (1); maybe “")#mi("> 2 \\int_R F(x,y,z)^2 \\,dx\\,dy\\,dz.")#text("” should be put on a new line.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265544")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("I’ve been reviewing Pace’s data from the past week to see whether there is any anomalous pattern.")

#text("First, Pace: I’m uncertain which polytope you were using for the data you reported in ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264511")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264511")]#text(" and ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264615")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264615")]#text(". In each case, was it R’, the prism or the symmetric half-cube? Your description in 264511 looks like the prism, but you referred to it as M’ and then in 264615 as “the symmetric case” so I wanted to check. In particular, it would be good to clarify whether the symmetric half-cube behaves like R’ in gaining 2/3 as much from using epsilon,epsilon,0 as from using eps,eps,eps.")

#text("My main focus is the fact (already pointed out, of course) that the best M value we have for the symmetric half-cube (using three equal epsilons) is only 0.007 greater than for R’ (1.9596 versus 1.9527). This is an order of magnitude less than the difference of 0.06 without epsilons (1.9026 versus 1.8429). I think this suggests that the putative inefficiency of partitioning in the presence of epsilons is hurting much more in the non-R’ polytopes within the symmetric half-cube than it is within R’. Is that a reasonable interpretation? If so, then maybe one idea would be to do Terry’s variable-degree trick in reverse, i.e. to look at high degree for a subset of the non-R’ polytopes (just the A’s, or just the B’s, etc) rather than for R’ itself. Worth a try?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265580")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("The polytope was the one exactly described in comment 264511. It is the prism with cut-offs when ")#mi("y+z\\leq 1+\\epsilon_1")#text(" and ")#mi("x+z\\leq 1+\\epsilon_2")#text(".")

#text("I’m not sure when I’ll have time to get back to these computations. One of my coauthors sent me a draft of our paper, and I’ll be focused on that for the next few days. If you want to give your variable-degree idea a try, you are welcome to the code. Just email me on Tuesday and I’ll send the mathematica notebook to you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265668")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Many thanks Pace – OK, so it’s definitely R’ with two equal epsilons added, so we don’t yet have data on the symmetric half-cube with two equal epsilons added. Please do send me the code (aubrey@sens.org) – thanks! – though I too am overstretched and don’t promise to have the time, especially since I am an extreme Mathematica novice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265846")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("OK, a very brief fiddle with Pace’s code (on the prism, which is the code he had to hand at home) makes this idea look unpromising – increasing the degree to 6 for just one category of component polytopes does not raise M” by more than 0.001 in any case. (I may have done it wrongly, however, because sometimes M” actually fell and because I received some alerts about the matrix inversion being “badly conditioned”.) If this is correct and applies also to the symmetric half-cube, perhaps the takeaway is that the partitioning is just losing a lot in all cases examined so far – which concords with Terry’s suggestion that there are loads of singularities in G_0. As a first data point I checked the prism with epsilon set to 0.25 and found that M” falls by only about 0.017 relative to that for the optimal epsilon of 0.157 found earlier by Pace, so it indeed seems useful to explore the “warmup” option Terry mentioned above (in which, if I understand Terry’s earlier comment about the likely locations of singularities, T_0 will need only a not-very-scary four partitions).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265870")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("A more efficient and numerically stable evaluation of any M-value is to represent it as the largest eigenvalue of a linear matrix pencil ")#mi("(A, B)")#text(" ( see the application section in the wikipedia article on matrix pencil) for which there is an efficient and numerically stable algorithm (without matrix inversion!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266112")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Interesting! When Pace was working on k=54 or so he mentioned that the inversion step was causing RAM issues, so this could be a valuable new tool. (Then again, he did note at the same time that there were also RAM issues when finding the largest eigenvector of similarly sized matrices, so maybe he’s already doing this when needed.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266118")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("This can be implemented in mathematica, see e.g.")

#link("http://reference.wolfram.com/legacy/applications/anm/GeneralizedEigenvalueProblem/9.1.html")[#text("http://reference.wolfram.com/legacy/applications/anm/GeneralizedEigenvalueProblem/9.1.html")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266139")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("I’ve now received Pace’s code for the symmetric half-cube and also (thanks to a suggestion from him) eliminated the alerts I mentioned. As with the prism, it turns out that the benefits to M” from increasing the degree for just one category of partition is much less for any of the non-R’ categories than it is for R’ itself (but it is always positive, so I’m pretty sure I did it correctly this time). A new partitioning that respects singularities seems, therefore, to be an absolute requirement for meaningful further progress.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265582")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2014")])]

#text("Since the explicit (somewhat messy) expression for ")#mi("G_1")#text(" depends linearly on ")#mi("G_0")#text(", another possible approach is to use a basis of symmetrical polynomials to approximate ")#mi("G_0")#text(" on ")#mi("T_0")#text(" with a corresponding basis of functions (derived by the above explicit expression) for ")#mi("G_1")#text(" on ")#mi("T_1")#text(". If the basis of functions for ")#mi("G_1")#text(" is not “too complicated”, the needed two dimensional integrals representing the elements of the matrices for the unconstrained optimization program may be computed sufficiently accurately.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265829")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("In the representation of the vanishing marginal condition using (1), the integrand should be inside parentheses.")

#emph[#text("[Edited, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265895")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")])]

#text("On another topic: just before Christmas (")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258871")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258871")]#text(") Terry improved the asymptotic bounds on H_m in the setting of the MPZ estimates, but I don’t think there was any mention that this was taken through into a modification of the Maple code that xfxie was using to identify minimal k’s. Is any such modification needed? If so, and if it wasn’t done yet, maybe it would give xfxie and Drew something to do while the focus is on k=3 :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-265899")[#strong[#text("Polymath 9 | Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2014")]

#text("[…] is a post discussing this. Meanwhile Polymath 8 has spawned a new project Polymath 8b. ")#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/")[#text("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/")]#text(" is the latest post of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266022")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("In the simple expression for ")#mi("G_1(x, y)")#text(" (six lines above (2)), the RHS should be with a minus sign.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266142")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("The exact value of ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" for ")#mi("\\epsilon \\in (1/2, 1)")#text(":")

#text("In this (simplest) case, the set ")#mi("T_1")#text(" is empty and therefore ")#mi("G=G_0")#text(" is supported on ")#mi("T_0")#text(". Since in this case ")#mi("\\min (1, 3/2 - x - y) = 1")#text(", it follows (assuming the existence of an optimal ")#mi("F")#text(") from the eigenvalue equation and the representation (1) that")

#mi("\\lambda G(x, y) = G(x, y) + H(x) + H(y)")#text(", ")#mi("(x, y) \\in T_0")

#text("where ")#mi("\\lambda := M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" and")

#mi("H(x) := \\int_0^1 G(x, z) dz")#text(" is supported on ")#mi("[0, 1 - \\epsilon]")#text(". Hence")

#mi("(\\lambda - 1)H(x) = \\int_0^{1-\\epsilon} [H(x)+H(z)]dz")#text(". Showing that ")#mi("H")

#text("is a constant supported on ")#mi("[0, 1 - \\epsilon]")#text(". We may normalize it as")

#mi("H(x) := 1_{[0, 1 - \\epsilon]}(x)")#text(". Hence")

#mi("(\\lambda - 1) = 2(1 - \\epsilon)")#text(", implying")

#mi("M^{\\prime\\prime}_{3, \\epsilon, 1} = 3 - 2 \\epsilon")#text(".")

#text("Remark: This expression seems to hold in the limiting case ")#mi("\\epsilon = 1/2")#text(" (since in this case the set ")#mi("T_1")#text(" still has zero area measure).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266148")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Splendid! If this is confirmed, it would be positively cruel if an epsilon slightly less than 1/2 were not a win…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Unfortunately I think the integral ")#mi("\\int_0^{1-\\varepsilon} [H(x)+H(z)]\\ dz")#text(" should in fact be ")#mi("\\int_0^{1-\\varepsilon-x} [H(x)+H(z)]\\ dz")#text(", as G(x,z) is supported on the region ")#mi("z \\leq 1-\\varepsilon-x")#text(". This equation should still be exactly solvable for H, and hence for G and F (by an analysis similar to that providing the exact solution for M_2, or for solving for G_1 in terms of G_0) but it is going to lead to a messier answer than ")#mi("3-2\\varepsilon")#text(", I’m afraid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266154")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("I see the problem: The first formula expressing ")#mi("G(x, y)")#text(" in terms of ")#mi("H(x), H(y)")#text(" is known to hold for ")#mi("(x, y) \\in T_0")#text(" (but not necessarily on ")#mi("[0, 1-\\epsilon]^2")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266166")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Yes. I almost have the solution (H satisfies a very simple second order equation!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266258")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("The corrected derivation of ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" is")

#text("1. The corrected equation for ")#mi("H(x)")#text(" follows by integrating the representation (on ")#mi("T_0")#text(") of ")#mi("G(x, z)")#text(" with respect to ")#mi("z")#text(" over ")#mi("[0, 1-\\epsilon -x]")#text(" (for which the representation holds!). This gives")

#text("(*) ")#mi("(\\lambda - 1)H(x) = (1-\\epsilon -x)H(x) + \\int_0^{1-\\epsilon - x} H(z)  dz")

#text("This is the corrected equation for ")#mi("H")#text(" on ")#mi("[0, 1-\\epsilon]")#text(".")

#text("2. Assuming ")#mi("H")#text(" to be sufficiently smooth, we have")

#text("(1) ")#mi("(\\lambda - 1)H^{\\prime}(x) = -H(x)+(1-\\epsilon-x)H^{\\prime}(x) + H(1-\\epsilon-x)")

#text("By reflection (")#mi("1- \\epsilon -x")#text(" instead of ")#mi("x")#text(") we have")

#text("(1′) ")#mi("(\\lambda-1)H^{\\prime}(1-\\epsilon -x)=-H(1-\\epsilon -x)+x H^{\\prime}(1-\\epsilon -x)+H(x)")

#text("Now we use (1) to express")

#text("(2) ")#mi("H(1- \\epsilon -x) = (\\lambda -2 + \\epsilon +x) H^{\\prime}(x) + H(x)")

#text("So by taking derivatives")

#text("(2′) ")#mi("H^{\\prime}(1-\\epsilon - x) = -2 H^{\\prime}(x) -(\\lambda - 2 +\\epsilon +x)H^{\\prime\\prime}(x)")

#text("Substitution of (2) and (2′) in (1′) gives")

#mi("(x+1-\\lambda)(x+\\lambda +\\epsilon -2) H^{\\prime\\prime}(x)+(3 x +\\epsilon -\\lambda)H^{\\prime}(x) = 0")

#text("Implying that the logarithmic derivative of ")#mi("H^{\\prime}(x)")#text(" is")

#mi("-1/(x+1-\\lambda) - 2/(x+\\lambda +\\epsilon -2)")

#text("Giving (the normalized)")

#text("(3) ")#mi("H^{\\prime}(x) = 1/[(x+1-\\lambda)(x+\\lambda +\\epsilon -2)^2]")

#text("Which gives")

#text("(4) ")#tao-math("H(x) = K^{-2}[\\log \\left|\\frac{x-a}{x+b}\\right| + \\frac{K}{x+b}] + C", block: false)

#text("Where ")#mi("K=2 \\lambda +\\epsilon -3, a=\\lambda -1, b= \\lambda +\\epsilon -2")#text(" and ")#mi("C")#text(" is an integration constant (to be determined with ")#mi("\\lambda")#text(").")

#text("3. In order to determine ")#mi("C")#text(" and ")#mi("\\lambda")#text(" we need two boundary conditions. First, observe that (*) implies")

#text("(i) ")#mi("(\\lambda -1)H(1-\\epsilon) = 0")

#text("Assuming ")#mi("\\lambda \\neq 1")#text(", we have")

#text("(i)’ ")#mi("H(1-\\epsilon) = 0")#text(", implying")

#tao-math("C = - K^{-2}[log \\left|\\frac{2-\\epsilon -\\lambda}{\\lambda -1}\\right| +K/(\\lambda -1)]", block: false)

#text("In order to determine ")#mi("\\lambda")#text(", we need another boundary condition.")

#text("By (2) and (i)’ we have ")#mi("H(0) = (\\lambda -1)H^{\\prime}(1-\\epsilon)")

#text("Therefore by (3)")

#text("(ii)’ ")#mi("H(0) = \\frac{1}{(\\lambda - 1)(2-\\lambda - \\epsilon)}")

#text("Using this in (4), we see that ")#mi("\\lambda")#text(" satisfies")

#text("(5) ")#tao-math("(2 \\lambda +\\epsilon -3)^2 = 2(\\lambda -1)(2-\\lambda -\\epsilon)\\log  \\left|\\frac{\\lambda -1}{2-\\lambda -\\epsilon}\\right| -(1-\\epsilon)(2\\lambda +\\epsilon-3)", block: false)

#text("Therefore ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" should be the largest positive root of (5).")

#text("Remark:")

#text("Note that since the argument of the logarithm in the above expression for ")#mi("C")#text(" should be nonzero and finite, this is equivalent that ")#mi("H(0)")#text(" should not vanish. In particular, the assumption ")#mi("H(0) >0")#text(" implies the simple inequality")

#mi("1 < \\lambda < 2-\\epsilon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266263")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Thanks for this! One could use this exact solution to benchmark the convergence of the numerics (with or without partitioning, using G instead of F, etc.); even in this simple regime ")#mi("\\varepsilon > 1/2")#text(" in which many of the polytopes have disappeared, it appears that G still has a jump discontinuity at ")#mi("x+y=1-\\varepsilon")#text(", leading to corresponding discontinuities for F which require some partitioning in order to be able to efficiently work around. (Conversely, one can use the numerics to confirm the correctness of the exact solution.)")

#text("It also occurs to me that if we work in the two-dimensional G formulation rather than the three-dimensional F formulation, then we can make plots of G that will help strengthen our intuition as to how the singularities are distributed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266267")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("I think there is something wrong here. Graphically, the largest positive root of (5), in the range ")#mi("1< \\lambda < 2-\\varepsilon")#text(", appears to always be ")#mi("\\lambda=3/2-\\varepsilon/2")#text(". Taking ")#mi("\\varepsilon=1/2")#text(", we are then getting ")#mi("M^{\\prime\\prime}_{3,1/2,1}=1.25")#text(" (and in that special case, this is indeed the largest root). But numerically I'm getting ")#mi("M^{\\prime\\prime}_{3,1/2,1}\\geq 1.69296...")#text(". Hopefully I'm not missing something simple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266281")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Interestingly, it is easy to verify that the root is exactly ")#mi("(3-\\epsilon)/2")#text(".")#linebreak()#text(" (In fact all the three terms are zero!) I’ll check again the derivation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266287")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("For this ")#mi("\\lambda")#text(" it follows that ")#mi("H")#text(" vanish identically! (i.e. it is the trivial solution!). If the derivation is correct than something must be wrong with the assumptions (e.g. existence of a smooth optimal solution.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266408")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("You are right! In fact, I just found an easy proof that")

#mi("M^{\\prime\\prime}_{3, \\epsilon, 1} = 1+(1-\\epsilon) M_2")#text(" for ")#mi("\\epsilon \\in [1/2, 1)")

#text("This connection to the constant ")#mi("M_2")#text(" is very interesting!")

#text("Concerning your example, using ")#mi("M_2 = 1.38593...")#text(", we get")

#mi("M_{3, 1/2, 1} = 1 + \\frac{1}{2} M_2 = 1.6929...")

#text("I’ll send the details in my next message.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266423")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("Great work Eytan! Even though 1.69 is a long way from 2, I’m wondering whether this finding could help to indicate which half-cube is really the best. Pace: do you numerically get this same value for both the prism and the symmetric half-cube? (I’m presuming that I can’t check this myself with the code you sent me because a different partitioning is needed for epsilon that large.) If the prism leads to a smaller M” for epsilon=1/2, I think that would constitute a significant strengthening of the evidence that there is no need to consider any half-cube other than the symmetric one from now on.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266453")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("Derivation of ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" for ")#mi("\\epsilon \\in (1/2, 1)")

#text("Observe that ")#mi("G")#text(" is supported on ")#mi("T_0 = (1-\\epsilon) \\mathcal R_2")#text(".")#linebreak()#text(" Therefore it seems reasonable that there is some (scaling) connection to the ")#mi("M_2")#text(" variational problem. Recall (for comparison purpose) that")

#text("1. In the ")#mi("M_2")#text(" problem, the eigenvalue equation was")

#text("(1) ")#mi("M_2 f(x) = (1-x) f(x) + \\int_0^{1-x} f(y) d y")#text(" , ")#mi("x \\in [0, 1]")

#text("with the solution")

#text("(2) ")#mi("f(x) = \\frac{2 M_2 -1}{M_2 -1+x} + \\log \\frac{M_2 -x}{M_2 -1+x}")

#text("2. For the current problem, the eigenvalue equation is (see previous comment)")

#text("(*) ")#mi("(\\lambda -1)H(x) = (1-\\epsilon - x)H(x)+\\int_0^{1-\\epsilon-x}H(y)d y")

#text("where ")#mi("H")#text(" is now supported on ")#mi("[0, 1-\\epsilon]")#text(".")

#text("Let ")#mi("H")#text(" be a solution of (*), than (by a change of variables) we have the equivalent form (with ")#mi("x=(1-\\epsilon)x^{\\prime} , y= (1-\\epsilon)y^{\\prime}")#text(")")

#text("(*)’ ")#mi("(\\lambda -1)\\phi(x^{\\prime}) = (1-\\epsilon)[(1-x^{\\prime})\\phi(x^{\\prime})+\\int_0^{1-x^{\\prime}} \\phi(y^{\\prime})d y^{\\prime}]")

#text("where ")#mi("\\phi(x^{\\prime}) := H((1-\\epsilon)x^{\\prime})")#text(" is supported on ")#mi("[0, 1]")#text(".")

#text("By comparing (*)’ to (1), it follows that")

#mi("(\\lambda -1)/ (1-\\epsilon) = M_2")#text(", hence")

#text("(3) ")#mi("M^{\\prime\\prime}_{3,\\epsilon, 1} = \\lambda = 1+ (1-\\epsilon) M_2")

#text("Remark: From this comparison, it follows that the solution ")#mi("H")#text(" to (*) is given by")

#text("(4) ")#mi("H(x) = f(x/(1-\\epsilon)) , x \\in [0, 1-\\epsilon]")

#text("where ")#mi("f(x)")#text(" is given by (2).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266199")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("I found ")#mi("H(x)")#text(" to be an explicit fourth degree polynomial on ")#mi("[0, 1 - \\epsilon]")#text(" and ")#mi("M^{\\prime\\prime}_{3, \\epsilon, 1}")#text(" was found to be the largest positive root of an explicit fourth order polynomial. I’ll give the details in my next comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266262")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("This (wrong) result was corrected in a later comment (the error originated in a wrong sign of the logarithmic derivative of H’ – affecting the later derivation.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266248")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Is it possible to turn Problem 1 into an optimization problem on a region of some finite-dimensional space, then turn a computer loose on it using a stochastic optimization algorithm or some other global optimization heuristic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266257")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("I took a little break from my other work, and decided to give the extra partitioning a try numerically. So I broke the simplex ")#mi("\\{(x,y,z)\\in [0,1]^3\\ :\\ x+y,y+z,z+x\\leq 1+\\varepsilon;\\ x+y+z\\leq 3/2\\}")#text(" into a finer decomposition than I had used previously. Namely, I used the the following pieces (intersected with the region above) ")#mi("A_{xyz} =\\{x+y\\leq y+z\\leq z+x\\leq 1-\\varepsilon\\}")#text(" ")#mi("B_{xyz}=\\{x+y\\leq y+z\\leq 1-\\varepsilon\\leq z+x\\leq 1+\\varepsilon\\}")#text(" ")#mi("C_{xyz}=\\{x+y\\leq 1-\\varepsilon\\leq y+z\\leq z+x\\leq 1+\\varepsilon\\}")#text(" ")#mi("D_{xyz}=\\{1-\\varepsilon\\leq x+y\\leq y+z\\leq z+x\\leq 1+\\varepsilon\\}")#text(" and their counterparts from permuting x,y,z. I assumed an arbitrary polynomial approximation on each piece, with the obvious symmetries from permuting the variables, and I also assumed that the D-components were irrelevant. [I realize that further restrictions could be made on the other components, but that doesn’t appear necessary.]")

#text("It looks like ")#mi("\\varepsilon\\approx 183/1000")#text(" is quite stable as the optimal choice, and for polynomials of degrees 1-5 we get ")#mi("M_{3,183/1000,1}^{\\prime}")#text(" is bounded below by 1.955982…,1.956463…, 1.956638…, 1.956695…, 1.956713…")

#text("Because of the nice convergence of these values, I think that the simplex has been sufficiently decomposed. Unfortunately, the numbers make me doubt that the M” computation will give much better numerics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("Hmm, that’s only a modest improvement over our previous value of ")#mi("M^{\\prime}_{3,\\varepsilon,1}")#text(" (which was 1.9527), but (a) every little bit helps, I think; (b) it is proof of concept that there was some singularity issue that was helped by improved partitioning; and (c) all the slow convergence issues are coming from the M” problems rather than the M’ problems, suggesting that the singularity problems there are more severe there, and hopefully there is a more serious gain (though we need a tenfold increase in gain over the gain observed here to win, which is a little daunting…). So it’s not yet hopeless (and maybe there’s one last trick to be had in manipulating the Selberg sieve further, though I’m currently out of ideas on that front).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266724")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2014")])]

#text("Motivated by Terry’s optimism,I worked out a similar decomposition as above, over the entire symmetric half-cube. Again I only got modest improvements. The optimal epsilon appears to be around 174/1000, and using that value we get the following lower bounds for ")#mi("M_{3, \\varepsilon, \\varepsilon, \\varepsilon, 1}^{\\prime\\prime}")#text(". As the degree goes from 1 to 4 we have 1.960128, 1.960845, 1.962407, 1.962998.")

#text("When I tried to use additional information about the structure of an optimal solution to speed up the computation, the marginal conditions forced all approximations to be zero (assuming I implemented everything correctly). So it is possible that the marginal conditions are holding the computation back, and don’t work well with polynomial approximation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2014")])]

#text("Well, it’s another 10% or so shaved off of the distance to 2, which is something at least (still feels like Zeno’s paradox, though)… but it does look like we are not using the full power of the extra regions where the vanishing conditions are in effect, so that gives some hope.")

#text("In principle, we don’t have to deal with the vanishing marginals at all, because of the explicit formulae for everything in the extra polytopes given in the blog post above. These are rather messy though, and the probability of an error (either in my calculations, or in a numerical implementation of these calculations) is high, also one has to do some numerical integration of some non-polynomial functions (involving some logarithms). So we can hope to just blast through with polynomials, perhaps working in the G(x,y) formulation where we might be able to use graphs of G to suggest more efficient bases to use.")

#text("How high of a degree do you think you can feasibly compute? We talked earlier about staggering the degree so that R” gets a lot more degree than the other polytopes; one could also arrange matters so that polytopes that have to face two marginal conditions have lower degree than those that face just one marginal condition.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267027")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("It took about 10 hours to compute with degree 6, and the ram requirement was getting large. So probably only another degree or two would be possible.")

#text("I tried playing around with limiting some of the degrees, but that didn’t give good numerics (which it shouldn’t since we expect the G0 and G1 components of G to interact).")

#text("Since the new polytope you gave is so close to the symmetric half-cube, I should be able to get the computations out of that later today (hopefully).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266829")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2014")])]

#text("A possible reason to the enforcement of the approximations to zero on the polytopes for which the marginal constraints apply, is that the number of marginal constraints is larger than the number of degrees of freedom in these approximations (which may happen if the approximating polynomials degrees are “too low”) – leaving no remaining degrees of freedom for improvement.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266966")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("I just realised that there is a bit more flexibility to the region R that the function F needs to be supported on. Namely, it is not actually necessary that R is convex (this is not used anywhere in the Selberg sieve computations), so long as it obeys the inclusion")

#mi("R+R \\subset [0,2]^3 \\cap \\{ \\min(x+y,x+z,y+z) \\leq 2\\}")#text(" (1)")

#text("as stated in the blog post. After playing around with some non-convex examples, I think that in addition to the prism and the symmetric polytope we’ve been playing with, another potentially good choice for R would be the non-convex region")

#mi("R = \\{ x+y,x+z \\leq 1 \\} \\cup \\{ x+y,y+z \\leq 1 \\} \\cup \\{ x+z,y+z \\leq 1\\}")

#text("which obeys (1) (basically because of the pigeonhole principle). Like our other candidates, R has exactly half of the volume of the cube [0,1]^3 (it and its reflection around (1/2,1/2,1/2) cover the cube). The advantage of this R is that each region only deals with at most one vanishing marginal condition, so numerically we shouldn’t be taking as big a hit with the linear constraints on these polytopes. I also suspect that when we reduce to the G-function, the equations are simpler than they are for ")#mi("\\{(x,y,z) \\in [0,1]^3: x+y+z \\leq 3/2 \\}")#text(" as computed in the main blog post, although I haven’t done this yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267036")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("It seems the 1st component of the union is a pyramid whose altitude is the unit segment [0,1] on the x axis and whose base is the unit square [0,1]x[0,1] in the y-z plane. And analogously for the other two components. Is that right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267044")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Yes, that is how a single piece of R looks. The full non-convex polytope R is a bit strange-looking, though. Here’s how it looks from a “top down” view. The unit square ")#mi("\\{ (x,y): 0 \\leq x,y \\leq 1\\}")#text(" can be divided into four right-angled isosceles triangles, ")#mi("S_1 = \\{ 0 \\leq x \\leq 1/2,  x \\leq y \\leq 1-x \\}")#text(", ")#mi("S_2 = \\{ 1/2 \\leq y \\leq 1, y \\leq x \\leq 1-y \\}")#text(", ")#mi("S_3 = \\{ 1/2\\leq x \\leq 1, x \\leq y \\leq 1-x \\}")#text(", and ")#mi("S_4 = \\{ 0 \\leq y \\leq 1/2, y \\leq x \\leq 1-y \\}")#text(". For (x,y) in the two opposing triangles S_1, S_3, z can range from 0 to 1-x; but for (x,y) in the other two triangles S_2, S_4, z can range from 0 to 1-y.")

#text("The calculus of variations analysis as in the main blog post gives us an ansatz")

#mi("F(x,y,z) = G(x,y) +G(y,z) + G(z,x)")

#text("on R, where ")#mi("G")#text(" is supported on the union of the triangles ")#mi("T_0= \\{ (x,y) \\in [0,1]^2: x+y \\leq 1-\\varepsilon \\} \\subset S_1 \\cup S_4")#text(" and ")#mi("T_1 = \\{ (x,y)\\in [0,1]^2: x+y \\geq 1+\\varepsilon \\} \\subset S_2 \\cup S_3")#text(". Letting G_0 and G_1 be the portions of G on these triangles, the vanishing moment conditions become")

#mi("G_1(x,y) (1-\\max(x,y)) + \\int_{0 \\leq z \\leq \\min(1-y-\\varepsilon,1-x)} G_0(y,z)\\ dz")

#mi("+ \\int_{0 \\leq z \\leq \\min(1-x-\\varepsilon,1-y)} G_0(x,z)\\ dz = 0")

#text("on T_1, so ")#mi("G_1")#text(" can be exactly solved in terms of ")#mi("G_0")#text(" by a formula somewhat simpler than in the symmetric polytope case (no logarithms!) In particular, one could set G_0 to be a piecewise polynomial and G_1 would be piecewise rational, so the integrals on R should still be reasonably computable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267060")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("How this ")#mi("G")#text(" is defined (in terms of ")#mi("F")#text(")?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("We have ")#mi("G_0(x,y) = (M^{\\prime\\prime}_{3,\\varepsilon,1})^{-1} \\int_0^{1-\\min(x,y)} F(x,y,z)\\ dz")#text(" for ")#mi("x+y \\leq 1-\\varepsilon")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267087")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Here is data on this new non-convex simplex. The best epsilon is near 147/1000. Using this epsilon and incrementing degrees from 1 to 4, we get the following bounds on ")#mi("M_{3,\\varepsilon,\\varepsilon,\\varepsilon,1}^{\\prime\\prime}")#text(": 1.9359, 1.9386, 1.9397, 1.9400.")

#text("To compare this simplex with the other two, the lower bound for M” using degree 4 polynomials is 1.847. This seems so low as compared with the other two simplexes that I doubled checked my work, but did not find any mistakes. I’m pretty sure that the decomposition I used is valid for any ")#mi("\\varepsilon\\in [0,1/5]")#text(". If someone wants to double-check my formulas, just go to: ")#link("http://www.math.byu.edu/~pace/BddGaps.pdf")[#text("http://www.math.byu.edu/~pace/BddGaps.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("That’s slightly odd, because the data you’re reporting for ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" is worse than the data ")#mi("M^{\\prime}_{3,\\varepsilon,1} \\geq 1.956713")#text(" ")#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266257")[#text("you got")]#text(", admittedly for degree 5 and for partitioning the simplex (but it is also worse than the earlier value of 1.9527 ")#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-266257")[#text("you got")]#text(" with degree 11 and no partitioning). (The values of epsilon are a bit different though.) I’ll take a look at your formulae to see if anything jumps out at me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("OK, my guess for what is going on is that the E,G,H polytopes are not being optimally partitioned; a single G polytope, for instance, is being forced to obey four different vanishing marginal conditions (M1=0, M2=0, M3=0, M4=0) which at low degree will really cut down on the possible options for what one can place on G. If one sliced G up into four pieces, they would each obey a separate vanishing marginal condition and one would have a lot more degrees of freedom, and similarly for E and H. (One nice thing about the non-convex polytope here is that each region faces at most one vanishing marginal condition, so we don’t end up in a nightmarish infinite regress in which every decomposition we use to try to fix up one marginal condition necessitates a further decomposition for another marginal condition.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267095")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("I’ll make that change! Good spotting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267150")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("I started making the changes to the decomposition, but by decomposing those pieces as wanted we end up with around 20 regions in the (x,y)-plane to integrate over to compute J. This is just getting a bit too complicated. I think I’ll hold off working this all out to give people some time to think about the (perhaps easier) 2-dimensional version of the problem.")

#text("By the way, I understand that the epsilon expansion trick doesn’t give us an asymptotic in the numerator (i.e.J-integrals). Are we losing much information here? We only need a smidgen more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267162")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Maybe the ")#mi("\\varepsilon=0")#text(" case could be worked out without too much difficulty to see how much we’re losing on the ")#mi("M^{\\prime\\prime}_3")#text(" computation? Here we only have the A and E polytopes (but then I guess we only have the M_2 moment condition, and so there is no point in partitioning further?).")

#text("We can also work out the formulae for M”_3 in the G(x,y) formulation, it looks like a good test bed to compare the two approaches. As mentioned before, we use the ansatz")

#mi("F(x,y,z) = G(x,y) + G(y,z) + G(z,x)")

#text("on R, where ")#mi("G = G_0 + G_1")#text(", ")#mi("G_0")#text(" is supported on the triangle ")#mi("\\{ x,y \\geq 0: x+y \\leq 1\\}")#text(", and ")#mi("G_1")#text(" is supported on the triangle ")#mi("\\{ x,y \\leq 1: x+y \\geq 1\\}")#text(" and is given in terms of ")#mi("G_0")#text(" by the formula")

#mi("G_1(x,y) = - \\frac{1}{1-\\max(x,y)} (\\int_0^{1-\\max(x,y)} G_0(y,z)\\ dz")#linebreak()#text(" ")#mi("+ \\int_0^{1-\\max(x,y)} G_0(x,z)\\ dz )")

#text("coming from the vanishing marginal condition. (I had a slight typo in my previous formula for ")#mi("G_1")#text(", now corrected.) The I(F) integral is")

#mi("6 \\int_{z \\leq y \\leq x; x+y \\leq 1} (G_0(x,y)+G_0(y,z)+G_0(z,x))^2\\ dx dy dz")#linebreak()#text(" ")#mi("+ 6 \\int_{z \\leq y \\leq x; x+y \\geq 1 \\geq x+z} (G_1(x,y)+G_0(y,z) +G_0(z,x))^2")#linebreak()#text(" ")#mi("dx dy dz")

#text("and the ")#mi("J^{(1)}(F)")#text(" integral is")

#mi("2\\int_{x+y \\leq 1; x \\leq y} (\\int_0^{1-y} G_0(x,y)+G_0(y,z)+G_0(z,x)\\ dz")#linebreak()#text(" ")#mi("+ \\int_{1-y}^{1-x} G_0(x,y)+G_1(y,z) + G_0(z,x)\\ dz)^2\\ dx dy.")

#text("These are messy, but they are all quadratic forms in ")#mi("G_0")#text(" on the triangle ")#mi("\\{x+y \\leq 1; x \\leq y\\}")#text(" which could presumably be computed in terms of a polynomial basis on this triangle (there may be some slight singularity at ")#mi("y=1/2")#text(" and ")#mi("x=1/2")#text(", but we might be able to get good results without further partitioning here).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267169")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("A small observation: if ")#mi("G_0")#text(" is polynomial, then ")#mi("G_1")#text(" is also polynomial for ")#mi("x \\leq y")#text(" (or for ")#mi("x \\geq y")#text("); I had thought it was merely a rational function, but ")#mi("\\int_0^x P(t,y)\\ dt")#text(" is polynomial in x and y when P is a polynomial. This makes all the coefficients in the relevant quadratic form rational numbers, so we can work exactly without having to do any numerical integration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267171")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Regarding the possibility of squeezing more gain out of the numerator – this is a great question, and I have been trying on and off for several weeks now to see if there is anything to get here. The key problem is that for the k=3 problem we are already well beyond the reach of unconditional methods (Bombieri-Vinogradov, Polymath8a, etc.) and so we have to cling to the GEH hypothesis as the only tool available for estimating all the sieve-theoretic sums that we encounter. So there’s not much else to work with, unless we cheat by adding another hypothesis even stronger than GEH and designed specifically to help us out.")

#text("Somehow the enemy is a weird cancellation in which the contributions to a divisor sum ")#mi("\\sum_{d_1|n, d_2|n+2, d_3|n+6} \\dots")#text(" with ")#mi("d_1 \\sim D_1, d_2 \\sim D_2, d_3 \\sim D_3")#text(" are almost canceled out by the contribution to the same sum with ")#mi("d_1 \\sim \\sqrt{x}/D_1, d_2 \\sim \\sqrt{x}/D_2, d_3 \\sim \\sqrt{x}/D_3")#text(". (This is very vague and imprecise, I’m afraid.) This cancellation would be quite bizarre if it really happened, but I don’t see yet how to rule out this sort of thing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267664")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")])]

#text("One thing I’ve noticed in these computations is that different simplexes have different optimal epsilons. I wonder if there is a way to vary the epsilon value as one passes from one region of the simplex to the next.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Actually, this might not be so odd after all: the computation for ")#mi("M^{\\prime}_{3,\\varepsilon,1}")#text(" is on the polytope ")#mi("\\{ x+y,y+z,z+x \\leq 1+\\varepsilon; x+y+z \\leq 3/2\\}")#text(" which is not necessarily contained in ")#mi("\\{ x+y,y+z \\leq 1 \\} \\cup \\{ x+y,x+z \\leq 1 \\} \\cup \\{ x+z,y+z \\leq 1\\}")#text(", so there is no obvious inequality between ")#mi("M^{\\prime}_{3,\\varepsilon,1}")#text(" and ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(". (But there is an inequality ")#mi("M^{\\prime}_3 \\leq M^{\\prime\\prime}_3")#text(", so it was a bit odd that those two were so close together, probably because of the abovementioned problem that the marginal conditions are too restrictive right now.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267105")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("I suggest to remove the convexity requirement of ")#mi("R")#text(" from the formulation of problem 1, and to add this non-convex example to the two given examples.")

#emph[#text("[Done – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267114")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("Thanks Terry. In case it helps others: I think you can visualize this R as the volume between a ‘floor’ [0,1]x[0,1] in the x-y plane and a ‘roof’ z(x,y). z is valley-shaped for x+y less than 1, ridge-shaped for x+y greater than 1, and discontinuous on x+y=1. The valley’s trough is half of the diagonal (0,0,1) to (1,1,0); the ridge’s ridgeline is the other half. Finally z=0 on the base of Terry’s S2 and S3, and z=1 on the base of S1 and S4.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267119")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2014")])]

#text("For those with Mathematica, I discovered that a nice way to visualize these regions is to use the RegionPlot3D command.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267534")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")])]

#text("In trying to gain a better understanding of the epsilon trick (and why it’s not working for the J-integrals) I hit a question: does the epsilon trick when theta=1 actually need divisor sums not covered by von Mangoldt? GEH was introduced in order to extend R to R’ and the various R” polytopes, but the discussion of epsilon didn’t seem to rely on similar considerations. If von Mangoldt is enough for M_k,epsilon,1 then we currently have k down to 4 on EH, with no need to resort to GEH, so this seems worth clarifying.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267579")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")])]

#text("The epsilon trick does not directly require GEH (so in particular it works in the Bombieri-Vinogradov case without any additional assumptions), but in the theta=1 case the epsilon trick does not gain anything numerically unless one is allowed to go outside the original simplex ")#mi("{\\cal R}_k")#text(", and when theta=1 this requires GEH.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267594")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")])]

#text("In the wiki page on the variational problem , there is some (latex ) typo in the line above the last one.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267760")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("Is it possible to generalize the statement of problem 1 by making ")#mi("\\epsilon_1")#text(" dependent on ")#mi("y, z")#text(" (and similarly for ")#mi("\\epsilon_2,  \\epsilon_3")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267815")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("That is exactly the question of my last post. Thank you for putting it more cleanly!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267830")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("My (clarifying) question was indeed stimulated by yours!")

#text("In fact, there may be further generalization in which the marginals are supported on sets ")#mi("D_1, D_2, D_3")#text(" and the outer integrals are over corresponding subsets ")#mi("E_1, E_2, E_3")#text(" (as done in the derivation of the necessary conditions for the optimal ")#mi("F")#text(" in a previous comment).")#linebreak()#text(" It would be interesting to find general sufficient conditions (as in the above conditions on ")#mi("R")#text(") that the sets ")#mi("D_i, E_i")#text(" should satisfy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("Unfortunately I don’t see a way to do this with the Selberg sieve. The first sum ")#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}}")#text(" that shows up in the numerator is determined by the first marginal ")#mi("\\int F(x,y,z)\\ dx")#text(", and if this non-vanishing at some ")#mi("(y_0,z_0)")#text(" with ")#mi("y_0+z_0 \\geq 1+\\varepsilon")#text(" then I can’t see any way to use any of the terms with ")#mi("y+z \\geq 1-\\varepsilon")#text(" for the purposes of getting a lower bound (because I have no control on the inner product of those terms with the contribution at ")#mi("(y_0,z_0)")#text(", and the total contribution of all these terms may well cancel itself out completely.")

#text("Perhaps more fruitful would be to vary R (viewing the variational problem as a free boundary problem). One thing about the symmetric polytope ")#mi("R = \\{ (x,y,z) \\in [0,1]^3: x+y+z \\leq 3/2\\}")#text(" is that the sumset ")#mi("R+R")#text(" meets the constraining region $\\{ (x,y,z) \\in [0,2]^3: \\min(x+y,y+z,z+x) \\leq 2 \\}$ in only one point (1,1,1); this is in contrast to the other polytopes we have tried (the prism and the non-convex polytope). Roughly speaking, this means that we can add a small piece to R somewhere as long as we delete the corresponding reflection of that piece around (1/2,1/2,1/2). So if the extremiser to the symmetric polytope problem is somehow unbalanced with respect to this reflection, one can hope to gain this way. Unfortunately effect of the process of adding and subtracting small pieces to R is a bit tricky to analyse due to all the vanishing marginal conditions. I should get around to doing a perturbative analysis of this though – it looks like a solvable problem, just a messy one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267886")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("Terry: by “viewing the variational problem as a free boundary problem” do you mean that the search for an optimal F could actually “push its envelope”, so to speak? In other words, maybe one could start with an R of the current form, then find F’s that extended slightly beyond R only at some narrowly-circumscribed location, and then see whether that F allowed the reflection of that location to be deleted from R?")

#text("It would be great to have a precise description of which half-cubes are permitted by the sumset constraint, since for sure there are plenty of half-cubes that violate it. Clearly, for any point (x,y,z) that is included within a candidate R, we know the domain of other points (x’,y’,z’) that can also be included: it is simply those such that the midpoint between the two lies within the union-of-prisms (the half-sized version of the permitted R+R). But collapsing this into a general description of which R’s are permitted seems really tricky. I’m working on it :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267934")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2014")])]

#text("Concerning the restriction of ")#mi("R")#text(" to ")#mi("[0, \\infty)^3")#text(", is it really needed? (in particular, do our examples always need to have faces with ")#mi("x=0, y=0, z=0")#text(" ?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268164")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Well, if R doesn’t have faces at x=0,y=0,z=0, one could always replace it with the downset completion ")#mi("R^{\\prime} = \\{(x,y,z): (x^{\\prime},y^{\\prime},z^{\\prime}) \\in R \\text{ for some } x^{\\prime} \\geq x, y^{\\prime} \\geq y, z^{\\prime} \\geq z \\}")#text(", whose sumset ")#mi("R^{\\prime}+R^{\\prime}")#text(" obeys the same containment hypotheses that ")#mi("R+R")#text(".does, so unfortunately there doesn’t seem to be any gain here. (Note also that even if F is supported on a polytope R which does not have faces at x=0,y=0,z=0, the associated sieve weights ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" are essentially supported in the downset completion R’ anyway, due to the construction of the Selberg sieve (which involves a mixed antiderivative f of F, rather than F itself).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268134")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("I’ve been thinking about a variation which I’m optimistic might finally get us down to ")#mi("H_1\\le 6")#text(". Yesterday I was looking through some of the earlier posts about the epsilon-expansion I realized that Terry had already had essentially the same idea, but I hadn’t noticed it before!")

#text("I’ll recap the basic idea:")

#text("Instead of considering just the sieve weights")#linebreak()#text(" ")#mi("(\\sum_{d_i|n+h_i}\\lambda_{d_1,d_2,d_3} )^2")#linebreak()#text(" we can look at the more general weights")#linebreak()#text(" ")#mi("(1-\\sum_{p|n}\\frac{\\log{p}}{\\log{n}})(\\sum_{d_i|n+h_i}\\lambda_{d_1,d_2,d_3})^2")#linebreak()#text(" ")#mi("+\\sum_{p|n}\\frac{\\log{p}}{\\log{n}}(\\sum_{d_i|n+h_i}\\lambda^{(p)}_{d_1,d_2,d_3})^2.")#linebreak()#text(" My original motivation for looking at this was to split the sieve weights to obtain a more flexible epsilon-expansion, but I think simply the flexibility of this more general choice might be enough.")

#text("Let ")#mi("d_i=R^{t_i}")#text(" and ")#mi("p=R^{u}")#text(" with ")#mi("R=x^{1/2-o(1)}")#text(". We assume that ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" are supported on the region ")#mi("\\{t_1+t_2,t_1+t_3,t_2+t_3\\le 1+\\epsilon\\}\\cap [0,1]^3")#text(", which will enable us to evaluate the term not involving the ")#mi("p")#text("‘s using the epsilon expansion trick. To evaluate the terms with the ")#mi("p|n")#text(" conditions we choose ")#mi("\\lambda^{(p)}_{d_1,d_2,d_3}=\\lambda_{d_1,d_2,d_3}")#text(" unless")#linebreak()#text(" ")#mi("(t_1,t_2,t_3,u)\\in\\{t_1+u+t_2,t_1+u+t_3,t_2+t_3\\le 1\\}\\cap[0,1]^4,")#linebreak()#text(" in which case we chose ")#mi("\\lambda^{(p)}_{d_1,d_2,d_3}=0")#text(". This means that under GEH we can obtain asymptotic estimates for each of the ")#mi("p")#text(" terms.")

#text("Doing this, and defining ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" in terms of ")#mi("F")#text(", I find that")#linebreak()#text(" ")#mi("J_1\\ge \\int_{t_2+t_3\\le 1-\\epsilon}(\\int F dt_1)^2dt_2dt_3")#linebreak()#text(" ")#mi("J_2\\ge \\int_{t_1+t_3\\le 1-\\epsilon}(\\int F dt_2)^2dt_1dt_3")#linebreak()#text(" ")#mi("-\\frac{1}{2}\\int\\int\\int(\\int F(t_1,t_2,t_3)-F(t_1+u,t_2,t_3)dt_2)^2dt_1dt_3du")#linebreak()#text(" ")#mi("J_3\\ge \\int_{t_1+t_2\\le 1-\\epsilon}(\\int F dt_3)^2dt_1dt_2")#linebreak()#text(" ")#mi("-\\frac{1}{2}\\int\\int\\int(\\int F(t_1,t_2,t_3) - F(t_1+u,t_2,t_3) dt_3 )^2 dt_1 dt_2 du")#linebreak()#text(" ")#mi("I=\\int\\int\\int F^2 dt_1dt_2dt_3")#linebreak()#text(" ")#mi("-\\frac{1}{2}\\int\\int\\int\\int (F(t_1,t_2,t_3)-F(t_1+u,t_2,t_3))^2dt_1dt_2dt_3du")#linebreak()#text(" where the integration involving the ")#mi("u")#text(" parameter is over")#linebreak()#text(" ")#mi("\\{t_1+u+t_2,t_1+u+t_3,t_2+t_3\\le 1\\}\\cap[0,1]^4.")#linebreak()#text(" Since the optimal functions we’re looking at aren’t constant with respect to the ")#mi("t_1")#text(" variable, I think we should expect a small win.")

#text("I’ve tried implementing this by just taking ")#mi("F")#text(" to be an arbitrary polynomial which is symmetric with respect to ")#mi("t_2")#text(" and ")#mi("t_3")#text(" (so far just given by one polynomial on the whole region). Assuming my code is running correctly, taking ")#mi("F")#text(" to be degree 11, I’m provisionally getting a lower bound of ")#mi("1.9984")#text(". This still should be checked, of course.")

#text("Moreover, we should expect that by splitting ")#mi("F")#text(" up on polytopes should do rather better (as per Pace’s calculations) and one might guess that degree 15 or 16 might be enough on its own.")

#text("There’s also several different variations which don’t just use divisors of ")#mi("n")#text(", or use a different ")#mi("\\epsilon")#text(" for the ")#mi("t_1")#text(" direction since the problem as stated isn’t symmetric with respect to ")#mi("t_1")#text(". This is also not using the extra flexibility from extended the region with vanishing marginal conditions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268144")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("James, if you just need a computer with more RAM, I’m happy to try to run your computation for bigger degrees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268163")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("This is fantastic! I had previously tried to insert the ")#mi("\\frac{\\log p}{\\log n}")#text(" twist to the sieve without the epsilon trick, and found that the eigenfunction equation for F made the original Selberg sieve a stationary point for this process, which made me pessimistic about using this to help us, but somehow the fact that the main term is estimated using the epsilon trick but the secondary terms without the epsilon trick gives a bit of extra gain, which is of course basically all we need at this point.")

#text("One potential problem: to control the main I(F) term, it is not enough that F is supported on ")#mi("\\{ t_1+t_2,t_1+t_3,t_2+t_3 \\leq 1+\\varepsilon\\} \\cap [0,1]^3")#text("; one also has to put F in one of the polytopes R we’ve been using, e.g. ")#mi("\\{ t_1+t_2+t_3 \\leq 3/2 \\} \\cap [0,1]^3")#text(". (In particular, we can’t let F poke past ")#mi("(1/2,1/2,1/2)")#text(", as we don’t have any tools for controlling the I-integral beyond that point, even on GEH.) Hopefully this doesn’t cost us too much though. (And there is also potential to poke outside of ")#mi("\\{t_1+t_2,t_1+t_3,t_2+t_3 \\leq 1+\\varepsilon\\}")#text(" so long as one has vanishing marginal conditions, though we’ve seen that this only gains us a small amount in practice.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268193")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("I was using the restriction ")#mi("\\{t_1+t_2+t_3\\le 3/2\\}")#text(" as well, I forgot to write this down.")

#text("Could you explain what you mean by the eigenfunction equation for ")#mi("F")#text(" made the original optimal weights a stationary point? I think my calculations should be giving an improvement without the ")#mi("\\epsilon")#text(" trick (from 1.84 to 1.87), which maybe means that I’ve made a mistake and this doesn’t really work. I see that this gives no benefit if ")#mi("F")#text(" is constant with respect to ")#mi("t_1")#text(", but the optimal small gaps weights aren’t constant in ")#mi("t_1")#text(", so I would have guessed a win here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Ah, I think I isolated the problem: the term one subtracts off of J_2 is not")

#mi("\\frac{1}{2} \\int\\int\\int_{t_1+u+t_2,t_1+u+t_3,t_2+t_3 \\leq 1} (\\int F(t_1,t_2,t_3)-F(t_1+u,t_2,t_3)\\ dt_2)^2\\ dt_1 dt_3 du")

#text("but rather")

#mi("\\frac{1}{2} ( \\int\\int\\int (\\int F(t_1,t_2,t_3)-F(t_1+u,t_2,t_3)\\ dt_2)^2\\ dt_1 dt_3 du")#linebreak()#text(" ")#mi("- \\int\\int\\int (\\int F_u(t_1,t_2,t_3)-F_u(t_1+u,t_2,t_3)\\ dt_2)^2\\ dt_1 dt_3 du")

#text("where ")#mi("F_u")#text(" is the restriction of F to the complement of ")#mi("\\{t_1+u+t_3,t_1+u+t_2,t_2+t_3 \\leq 1 \\}")#text(", and F is extended by zero outside of its support. Similarly for ")#mi("J_3")#text(".")

#text("Here’s the calculation (without epsilons) which seems to show that the eigenfunction for the M’_3 problem is also the extremiser for this new sieve. Suppose that ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" is given by the eigenfunction F, and ")#mi("\\lambda^{(p)}_{d_1,d_2,d_3}")#text(" is given by ")#mi("F + G_u")#text(" where ")#mi("G_u")#text(" is supported on ")#mi("\\{ t_1+u+t_3,t_1+u+t_2,t_2+t_3 \\leq 1 \\}")#text(" (you chose ")#mi("G_u")#text(" to zero out ")#mi("F")#text(" on this region, but this is not necessarily the optimal choice). The net change to")

#mi("J_1 + J_2 + J_3 - M^{\\prime}_3 I")

#text("coming from this change consists of a term linear in G_u, which I think is")

#mi("\\int\\int\\int (\\int \\partial^{(u)} G_u\\ dy) (\\int \\partial^{(u)} F\\ dy) dx dz du")#linebreak()#text(" ")#mi("+ \\int\\int\\int (\\int \\partial^{(u)} G_u\\ dz) (\\int \\partial^{(u)} F\\ dz)\\ dx dy du")#linebreak()#text(" ")#mi("- M^{\\prime}_3 \\int\\int\\int\\int \\partial^{(u)} G_u \\partial^{(u)} F\\ dx dy dz du")

#text("where ")#mi("\\partial^{(u)} F(x,y,z) := F(x+u,y,z) - F(x,y,z)")#text(", together with a term quadratic in G_u:")

#mi("\\frac{1}{2} \\int\\int\\int (\\int \\partial^{(u)} G_u\\ dy (\\int \\partial^{(u)} G_u\\ dy) dx dz du")#linebreak()#text(" ")#mi("+ \\frac{1}{2} \\int\\int\\int (\\int \\partial^{(u)} G_u\\ dz) (\\int \\partial^{(u)} G_u\\ dz)\\ dx dy du")#linebreak()#text(" ")#mi("- \\frac{1}{2} M^{\\prime}_3 \\int\\int\\int\\int \\partial^{(u)} G_u \\partial^{(u)} G_u\\ dx dy dz du.")

#text("The quadratic term is non-positive due to the definition of ")#mi("M^{\\prime}_3")#text(" (since ")#mi("J_1(G_u)+J_2(G_u)+J_3(G_u)-M^{\\prime}_3 I(G_u)")#text(" is non-positive, and we can throw away the J_1 contribution). As for the linear term, we use Fubini to rewrite this as an inner product of the ")#mi("\\partial^{(u)} G_u")#text(" with ")#mi("\\partial^{(u)} {\\cal L}_2 F + \\partial^{(u)} {\\cal L}_3 F - \\partial^{(u)} M^{\\prime}_3 F")#text(", but this vanishes on the support of ")#mi("\\partial^{(u)} G_u")#text(" by applying ")#mi("\\partial^{(u)}")#text(" to the eigenfunction equation ")#mi("{\\cal L}_1 F + {\\cal L}_2 F + {\\cal L}_3 F - M^{\\prime}_3 F = 0")#text(".")

#text("I think the intuition here is that the Selberg sieve associated to ")#mi("F^{(p)}")#text(", when restricted by ")#mi("1_{p|n}")#text(", behaves very much like the Selberg sieve associated to ")#mi("\\partial^{(u)} F^{(p)}")#text(", times a normalising factor of ")#mi("1/p")#text(". Because the original Selberg sieve F was already optimised against perturbations of the latter type of sieve, it becomes automatically optimised against the former.")

#text("EDIT: I’m not exactly sure what is going on though when one also throws in the epsilons. There may be some flexibility gained here, but I’ll have to think about it a bit more.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268259")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Argh, thanks for this – I should have checked more carefully before posting, it was silly to forget that the shifts would have a smaller support.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("No problem: I myself got really excited by the ")#mi("\\frac{\\log p}{\\log x}")#text(" trick on no less than two previous occasions, before calculating that it didn’t actually offer any gain. But maybe the fourth time will be the charm for this trick, it feels like it should somehow be useful…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268137")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Another comment:")

#text("In my first implementation attempt, I was missing the restriction that ")#mi("(t_1,t_2,t_3)\\in[0,1]^3")#text(" (Pace helpfully pointed this out to me). Without this restriction I was getting a lower bound slightly larger than 2.")

#text("How necessary is this restriction under GEH? I was thinking that we could split the contribution from terms up depending on the number ")#mi("k")#text(" of prime factors. I think that the characteristic function of numbers with exactly ")#mi("k")#text(" prime factors (and each prime factor in a given interval) should have good distribution up to ")#mi("\\theta<1")#text(" under GEH, with complete uniformity in the intervals containing the prime factors. This means that sums weighted by a smooth function of the prime factors should also have good distribution, and I think this means we should be able to handle terms when e.g. ")#mi("d_1,e_1|n")#text(" are very large, provided ")#mi("d_2,e_2,d_3,e_3")#text(" are suitably small. We'd need to be careful about ")#mi("k")#text(" large, but presumably this can be handled by pre-sieving slightly. I haven't thought about this very thoroughly, so maybe I'm missing something obvious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268169")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Hmm. Presieving can certainly restrict us to the range where n,n+2,n+6 have at most ")#mi("10^{10}")#text(" (say) factors, while only costing us something like ")#mi("10^{-8}")#text(" in the final estimates (which we can presumably tolerate). But I don’t see how any further restriction of the number of factors of n, n+2, or n+6 helps us. Note that GEH allows us to insert an arithmetic function of n, n+2, or n+6 into our divisor sums, but not two or more of them at once. So if one starts modulating the divisor sum ")#mi("\\nu")#text(" by the number of prime factors of n, for instance, one loses the ability to sum ")#mi("\\nu(n)")#text(" for prime n+2 or prime n+6, unless the modulating weight is at a very low level like ")#mi("x^{10^{-10}}")#text(". Also I don’t see how knowing something about the number of prime factors helps us get past ")#mi("[0,1]^3")#text(" – we need to understand the divisors of n that are a little bit bigger than ")#mi("x^{1/2}")#text(", which does not seem to correlate with the number of prime factors (unless this number is 1, of course). We could also flip the divisor condition ")#mi("d|n \\iff (n/d)|n")#text(", but this introduces a Mobius function ")#mi("\\mu(n/d)")#text(" into the divisor sum which looks very unpleasant.")

#text("I’m a bit worried that the parity problem blocks us from going beyond ")#mi("[0,1]^3")#text(". In the k=2 case, taking F to be the indicator of ")#mi("[0,1]^2")#text(" already gets us right to the edge of the twin prime conjecture (")#mi("M^{\\prime}_2=2")#text("), and we should not be able to go further without doing something non-sieve-theoretic. This suggests to me that ")#mi("[0,1]^3")#text(" is a real barrier and not just an artificial one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268208")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("I would still be assuming the restriction ")#mi("d_1+d_2,d_1+d_3,d_2+d_3\\le 1")#text(", which would be necessary. I’ll try to be clearer, although I haven’t thought that much about this.")

#text("Imagine for simplicity we’re in the case ")#mi("k=2")#text(" and we’re looking at the weights ")#mi("\\sum_{d_i|n+h_i}\\lambda_{d_1,d_2}")#text(" with the support restricted to ")#mi("d_1<R_1, d_2<R_2")#text(". We know that this is essentially optimal if we take ")#mi("R_1=R_2=x^{1/2+o(1)}")#text(" and ")#mi("\\lambda_{d_1,d_2}=1")#text(" on this region. But imagine we wish to estimate the weights with (say)")#linebreak()#text(" ")#mi("R_1=x^{3/5}, R_2=x^{2/5}")#linebreak()#text(" We can estimate the terms weighted by ")#mi("1_{n+h_1 prime}")#text(" using EH since ")#mi("R_2^2<x")#text(". We can apply the epsilon trick to get a lower bound for the terms weighted by ")#mi("1_{n+h_2 prime}")#text(".")

#text("To estimate the terms weighted by the constant 1, we wish to know that")#linebreak()#text(" ")#mi("\\sum_{n,d_1,e_2:d_1,e_1|n; d_2,e_2|n+2}\\lambda_{d_1,d_2}\\lambda_{e_1,e_2}")#linebreak()#text(" is well distributed in arithmetic progressions modulo ")#mi("[d_2,e_2]")#text(", where the sum is over ")#mi("n,d_1,e_1")#text(" (lets not worry about the dependence on the modulus, since the absolute value is smooth with respect to the modulus). This quantity is")#linebreak()#text(" ")#mi("\\sum_{n}\\alpha*\\beta(n)")#linebreak()#text(" where ")#mi("*")#text(" is Dirichlet convolution, ")#mi("\\beta(r)=1")#text(" and")#linebreak()#text(" ")#mi("\\alpha(r)=\\sum_{[d_1,e_1]=r}\\lambda_{d_1,d_2}\\lambda_{e_1,e_2}")#linebreak()#text(" We’d like to apply GEH to estimate this sum, but in this model case ")#mi("[d_1,e_1]")#text(" can be as large as ")#mi("x")#text(" (since ")#mi("R_1^2\\geq x")#text("), which means we can’t use GEH directly. I believe this is where the restriction ")#mi("(t_1,t_2,t_3)\\in[0,1]^3")#text(" is coming from.")

#text("However, if we split the constant term 1 up into ")#mi("1_{\\omega(n)=k}")#text(" for ")#mi("k<10^{100}")#text(", say, then I think we should be able to estimate each of these terms in arithmetic progressions modulo ")#mi("[d_2,e_2]")#text(". The sum is just a smooth function of the ")#mi("k")#text(" prime divisors of ")#mi("n")#text(" times ")#mi("1_{\\omega(n)=k}")#text(", and (I think) using a similar partitioning argument to that used in the BFI paper, this should be well-distributed modulo ")#mi("[d_2,e_2]<R_2^2<x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Ah, I begin to see what you are doing, nice!")

#text("A model problem here would be to understand the asymptotics of the one-dimensional Selberg sieve")

#mi("\\sum_{n \\sim x} (\\sum_{d|n} \\mu(d) f( \\frac{\\log d}{\\log n} ) )^2.")

#text("When f is supported in ")#mi("[0,1/2]")#text(", the standard Selberg sieve calculation shows that this is asymptotic to ")#mi("\\frac{x}{\\log x} (\\int f^{\\prime}(t)^2\\ dt)")#text(" (possibly up to some ")#mi("\\phi(W)/W")#text(" factors after restricting n to a single residue class modulo W). But by breaking n into prime factors (and supposing that the contribution of huge numbers of prime factors is negligible), it looks like this asymptotic can be extended to f supported in ")#mi("[0,1]")#text(". Note that this is consistent with the reflection identity")

#mi("(\\sum_{d|n} \\mu(d) f( \\frac{\\log d}{\\log n} )^2 = (\\sum_{d|n} \\mu(d) f( 1 - \\frac{\\log d}{\\log n}))^2")

#text("when ")#mi("n")#text(" is square-free (which, after the W-trick, occurs almost all the time), since we get two factors of ")#mi("\\mu(n)")#text(" on reflecting which cancel each other out.")

#text("If this asymptotic holds up for the model problem, then I would tentatively believe that it also works for the multidimensional sums we have to deal with, which would mean that one can replace ")#mi("[0,1]^3")#text(" with ")#mi("[0,2]^3")#text(" in the variational problem on GEH (which, in practice, looks more or less equivalent to working on the entire orthant ")#mi("[0,+\\infty)^3")#text("). This is contingent though on checking that the contribution of numbers that are not almost prime is negligible. There is a calculation of Pintz along these lines at ")#link("http://arxiv.org/abs/1002.2899")[#text("http://arxiv.org/abs/1002.2899")]#text(" , but one can probably also achieve a similar effect through preliminary sieving (the fundamental lemma of sieve theory). I’ll try to work this out in more detail, perhaps in time for the next blog post.")

#text("Looking at the gain from ")#mi("M_{3,\\epsilon,1}")#text(" to ")#mi("M_{3,\\epsilon,1/2}")#text(" in the wiki, it looks like this new room only buys us 0.015 or so, slicing a third off of the gap – but perhaps things are a bit better in the M’ or M” world.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268262")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("A small thought: In the above problem, I think we have to be slightly careful about the precise range of support of ")#mi("f")#text(", since if it is fully supported on the whole interval ")#mi("[0,1]")#text(" then it can correlate with the Moebius function (since ")#mi("\\Lambda")#text(" can be written like this), but if the support is ")#mi("[0,1-\\epsilon]")#text(" then I think it should (conjecturally) have cancellation when summed with the Moebius function, and so we wouldn’t expect it to break the parity barrier (which is reassuring). I think this means that there could be large contributions from numbers with several prime factors if ")#mi("f")#text(" had support ")#mi("[0,1-\\epsilon]")#text(" (where ‘several’ is a range going to infinity as ")#mi("\\epsilon")#text(" goes to 0).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Actually, because we are squaring the sum to play with ")#mi("\\nu(n) = (\\sum_{d|n} \\mu(d) f(\\frac{\\log d}{\\log n}))^2")#text(", the divisor sum can in fact start correlating with Mobius when the support of f stretches past [0,1/2], indeed it more or less has to since the quantity ")#mi("\\int f^{\\prime}(t)^2\\ dt")#text(" that measures the size of ")#mi("\\nu")#text(" relative to the primes has now dipped below the parity barrier of 2. (Note also that multiplying by Mobius is more or less the same as replacing one of the f’s with its reflection ")#mi("f(1-t)")#text(", and that ")#mi("\\int f^{\\prime}(t) f^{\\prime}(1-t)\\ dt")#text(" starts becoming non-zero when the support of f stretches beyond [0,1/2].) But it seems, strangely enough, that we still are able to control the sum ")#mi("\\sum_n \\nu(n)")#text(", not by using the distribution properties of 1, but instead using the distribution properties of the almost primes (and thus fully exploiting the GEH hypothesis). This makes it less clear whether the parity barrier is still in force for the purposes of blocking any progress on H_1 below 6, since Selberg’s argument presumes we are working with sieves that are always orthogonal to Mobius, but I would be surprised if such a notorious obstacle was circumvented so cheaply.")

#text("On a largely unrelated note: Motohashi has just uploaded a survey article on the bounded gaps problem between primes, with the optimistic title of “the twin prime conjecture”, at ")#link("http://arxiv.org/abs/1401.6614")[#text("http://arxiv.org/abs/1401.6614")]#text(" , aimed at a general mathematical audience.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268269")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2014")])]

#text("Yes, I was referring to the non-squared sum when I was talking about correlation with Moebius. I just wanted to use this to demonstrate that if ")#mi("f")#text(" has support ")#mi("[0,1-\\epsilon]")#text(" then numbers with a large number of prime factors (depending on ")#mi("\\epsilon")#text(") will make a noticeable contribution to the squared sum.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268369")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("These are very exciting ideas! This might be a silly question, but what prevents us from applying them to the k=2 case, rather than just the k=3 case?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268356")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("The bound for m=2 without EH can be improved to ")#link("http://math.mit.edu/~drew/admissible_35146_395106.txt")[#text("395,106")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("OK, I think I can justify James’ argument that (on GEH) allows one to relax the requirement that R be contained in ")#mi("[0,1]^k")#text(" (or that ")#mi("R+R")#text(" lie in ")#mi("[0,2]^k")#text(") with the requirement that R be contained instead in ")#mi("[0,2]^k")#text(" (or more precisely ")#mi("[0,2-o(1)]^k")#text("). Thus for instance we gain access to the entire simplex ")#mi("\\{ (x,y,z): x+y+z \\leq 3/2 \\}")#text(" now, bearing in mind though that if we venture too far out into this simplex without vanishing marginal conditions then we will pay for it with the epsilons.")

#text("Details will appear in the next blog post.")#linebreak()#text(" The crux is the following cute identity: if ")#mi("f: [0,a] \\to {\\bf R}")#text(" is a C^1 function (i.e. continuously differentiable), then")

#mi("\\displaystyle \\int_0^1 f^{\\prime}(t)^2\\ dt = \\sum_{k=0}^\\infty \\int_{t_1,\\dots,t_k \\in [0,1]: t_1+\\dots+t_k=1}\\frac{[\\partial^{(t_1)} \\dots \\partial^{(t_k)} f(0)]^2}{t_1 \\dots t_k}")#text(" (*)")

#text("where ")#mi("\\partial^{(t)} f(s) := f(s+t)-f(s)")#text(". A bit more explicitly, the RHS of (*) expands as")

#mi("\\displaystyle (f(1)-f(0))^2")#linebreak()#text(" ")#mi("\\displaystyle + \\int_0^1 (f(1)-f(t)-f(1-t)+f(0))^2\\ \\frac{dt}{t(1-t)}")#linebreak()#text(" ")#mi("\\displaystyle + \\int_0^1 \\int_0^{1-t} (f(1)-f(1-t)-f(1-s)-f(s+t)+f(1-t-s)")#linebreak()#text(" ")#mi("\\displaystyle +f(s)+f(t) -f(0))^2\\ \\frac{ds dt}{st(1-s-t)}")#linebreak()#text(" ")#mi("\\displaystyle + \\dots")

#text("The number-theoretic interpretation is that the LHS of (*) represents the value of ")#mi("\\sum_n (\\sum_{d|n} \\mu(d) f(\\log d/\\log n))^2")#text(", and the k^th term on the RHS of (*) represents the contribution of those n that are the products of exactly k primes. It is relatively easy to establish the inequality ")#mi("LHS \\geq RHS")#text(", after first verifying the preliminary identity")

#mi("\\displaystyle \\int_0^a f^{\\prime}(t)^2\\ dt = a^{-1} (f(a)-f(0))^2+ a^{-1} \\int_0^a \\int_0^{a-t} (\\partial^{(t)} f^{\\prime}(s))^2\\ ds dt;")

#text("getting equality requires a bit more care, and corresponds to the assertion that the sieve is mostly dominated by almost primes.")

#text("Anyway, by using this formula and Maynard’s trick, I think I can get the expected asymptotic for the numerator ")#mi("I_k(F)")#text(" as long as F is supported in the (interior of) a region R with")

#mi("R+R \\subset [0,4]^k \\cap \\bigcup_{i=1}^k \\{ t_1+\\dots+t_{i-1}+t_{i+1}+\\dots+t_k \\leq 2 \\}")

#text("which improves upon the previous requirements by replacing ")#mi("[0,2]^k")#text(" with ")#mi("[0,4]^k")#text(". Details to appear in the next blog post. In particular, when k=3 we can work on the untruncated simplex ")#mi("R = \\{ t_1,t_2,t_3 \\geq 0: t_1+t_2+t_3 \\leq 3/2 \\}")#text(", effectively giving us access to the quantities ")#mi("M_{3,\\epsilon,1/2}")#text(", ")#mi("M^{\\prime}_{3,\\epsilon,1/2}")#text(" and ")#mi("M^{\\prime\\prime}_{3,\\epsilon,1/2}")#text(". I had noted previously that the gain of ")#mi("M_{3,\\epsilon,1/2}")#text(" over ")#mi("M_{3,\\epsilon,1}")#text(" was slight (about 0.013 on current numerical data), but this was because we used a one-dimensional model to compute ")#mi("M_{3,\\epsilon,1/2}")#text(". For ")#mi("M_3")#text(", the one-dimensional model is short by about 0.011, so putting everything together we might expect to advance about 0.024 with this new trick, or more than halfway. (Zeno again!)")

#text("Pace asked what happens when k=2. This is a great question. Technically, the parity barrier is not obviously present any more, although I can’t imagine that it’s this easy to get around that notorious obstacle. We can work in any R with")

#mi("R+R \\subset [0,2] \\times [0,4] \\cup [0,4] \\times [0,2],")

#text("in particular ")#mi("R = \\{ t_1,t_2 \\geq 0: t_1+t_2 \\leq 2 \\}")#text(" is available. But even on this enlarged region, it appears that the previous extremiser ")#mi("F = 1_{[0,1]^2}")#text(" is still a critical point (at least for the ")#mi("\\epsilon=0")#text(" problem), as it solves the Euler-Lagrange equation ")#mi("F(x,y) = G(x) + G(y)")#text(" with ")#mi("\\int F\\ dy = M_2 G")#text(" on ")#mi("x \\in [0,1]")#text(". One could play with the epsilons, and one should probably check this on the 1% chance that we accidentally prove the twin prime conjecture (on GEH) this way, but my guess would be that one loses more than one gains by increasing epsilon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268392")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("I guess its worth noting that in the ")#mi("k=2")#text(" case we also just fail to prove the twin prime conjecture at the other extreme. We’re looking at divisors ")#mi("d_1\\le R_1, d_2\\le R_2")#text(" subject to ")#mi("min(R_1,R_2)\\le x^{1/2}")#text(", so we might as well have ")#mi("R_1=x^{1/2}\\le R_2\\le x")#text(". If ")#mi("R_2=x^{1/2}")#text(" then we’re at our familiar situation, and just fail to prove twin primes. If we take the other extreme ")#mi("R_2=x")#text(", then we effectively have multiplied everything by the characteristic function ")#mi("1_{n prime}")#text(". We have to throw out all of the ")#mi("1_{n+h_2 prime}")#text(" contribution from the epsilon trick, but the constant term 1 and the ")#mi("1_{n prime}")#text(" term contribute the same amount, so we just fail again (and this looks a lot like Bombieri’s sieve). I don’t know what happens in between, but since nothing is correlating with ")#mi("\\mu(n+h_1)\\mu(n+h_2)")#text(" I’d be skeptical the parity barrier isn’t hiding somewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268422")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("With this new, relaxed constraint on R+R, might it be worth revisiting the prism in the k=3 case? I ask because the untruncated simplex with (1/2,1/2,1/2) on its boundary has volume 9/16, but the elongated prism in which x+y (aka t1+t2) does not exceed 1 but z (aka t3) can be as much as 2 has volume 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268443")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Computing on the region ")#mi("\\{(x,y,z)\\in [0,2]^{3}: x+y+z\\leq 3/2;x+y,y+z,z+x\\leq 1+\\varepsilon\\}")#text(" with no marginal conditions, I get ")#mi("M\\geq 1.992")#text(" when epsilon is about 29/100 (and this appears to be close to the optimal epsilon). I’ll next do the computation on the full symmetric half-cube with marginal conditions. This is so tantalizingly close, I think we may just make it! [Aubrey, I tried the same computation on the extended prism, but the numerics didn’t work out as well without incorporating the marginal conditions.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268446")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("By the way, with all the changes I’m getting a little confused by the M notations. To be clear, the previous computation used the epsilon expansion trick and the stated region.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268454")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Right – since current notation covers values of theta other than 1, I guess the question is whether a new notation is needed to represent the fact that the bounding hypercube no longer has edge-length 1/theta, which in turn requires clarity as to whether James’s new trick translates into a bounding hypercube of edge-length 2/theta, or if not, what.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Well, fortunately we can use an older notation here: James’ new trick effectively replaces ")#mi("M^{\\prime}_{3,\\epsilon,1}")#text(" (symmetric polytope) with ")#mi("M^{\\prime}_{3,\\epsilon,1/2}")#text(" (symmetric polytope), and similarly for M and M”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268473")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Ah, sure, the extended prism’s greater volume could certainly only help when marginals are included – it would cut a big swathe off R’_3,epsilon rather than just a tip. Let’s see if you make the goal using the symmetric half-cube with marginals – but if you don’t, I still think it’s worth checking the extended prism with marginals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268458")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("For the relaxed condition on ")#mi("R")#text(", it seems that the above restriction on ")#mi("F")#text(" to be supported on the interior of ")#mi("R")#text(" can be slightly relaxed to the closure of ")#mi("R")#text(" (since the condition on the M-value is open).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268419")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("Another recent paper on the arXiv: Jesse Thorner has used the multidimensional GPY-Selberg sieve to get bounded gaps between primes in residue classes or in Chebotarev classes : ")#link("http://arxiv.org/abs/1401.6677")[#text("http://arxiv.org/abs/1401.6677")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]], [#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-268539")[#strong[#text("Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on can be found at the wiki […]")
]
