// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/
// Converted to Typst by tao2typ: "2026-10-14T15:18:49.120676+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: Writing the paper, IV", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: Writing the paper, IV")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Once again it is time to roll over the ")#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/")[#text("previous discussion thread")]#text(", which has become rather full with comments. The paper is ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("nearly finished")]#text(" (see also ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/wjFF8XoZVG/ek/newgap.pdf")[#text("the working copy")]#text(" at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/8OKNGAmv5n/ek")[#text("this subdirectory")]#text(", as well as the ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("rest of the directory")]#text("), but several people are carefully proofreading various sections of the paper. Once all the people doing so have signed off on it, I think we will be ready to submit (there appears to be no objection to the plan to submit to ")#link("http://msp.org/ant/about/cover/cover.html")[#text("Algebra and Number Theory")]#text(").")

#text("Another thing to discuss is an invitation to Polymath8 to write a ")#link("http://www.ems-ph.org/journals/authorinfo.php?jrn=news")[#text("feature article")]#text(" (up to 8000 words or 15 pages) for the ")#link("http://www.ems-ph.org/journals/journal.php?jrn=news")[#text("Newsletter of the European Mathematical Society")]#text(" on our experiences with this project. It is perhaps premature to actually start writing this article before the main research paper is finalised, but we can at least plan how to write such an article. One suggestion, proposed by Emmanuel, is to have individual participants each contribute a brief account of their interaction with the project, which we would compile together with some additional text summarising the project as a whole (and maybe some speculation for any lessons we can apply here for future polymath projects). Certainly I plan to have a separate blog post collecting feedback on this project once the main writing is done.")

#heading(level: 1)[#text("Comments (166)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249812")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2013")])]

#text("A few more typos:")#linebreak()#text(" 1. Table 1 (p8), ")#mi("{\\cal D}^{(i)}_y")#text(" is now ")#mi("{\\cal D}^i(y)")#text(" according to the new notation in Def 2.14")#linebreak()#text(" 2. p74, immediately after proof of Lemma 5.3, “We will can prove”: “can” can probably be changed to “now”.")#linebreak()#text(" 3. Bottom of p74, definition of ")#mi("\\Theta")#text(" is probably missing “1+”.")#linebreak()#text(" 4. p81, 4th display & 2 lines above it, there are 2 uses of ")#mi("b^{-1}")#text(". Probably better to use ")#mi("\\bar{b}")#text(" to be consistent with later and with other sections.")#linebreak()#text(" 5. p83, 1st paragraph of sec 6.3,”We with a” is missing a verb like “begin”.")#linebreak()#text(" 6. p 170, Ref 22, missing \\”a in Birkhauser.")#linebreak()#text(" 7. p 172, Ref 75, Yildirim may be changed to Y\\i ld\\i r\\i m.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249843")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2013")])]

#text("In the definition of ")#mi("\\kappa_3")#text(" (theorem 2.16), a space is needed between the subscript ")#mi("k_0 - 2")#text(" and ")#mi("\\omega")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b569ab6e7e3d7906c75b26228bb124f88e299a60f22618bcb8846df553ea7ad-f4d6150803cd83679d270d45b0ebd17630784da51d524022a26e5ab5e18ca754.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Goldston")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249886")[#strong[#text("Dan Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2013")])]

#text("I think that footnote 5 on page 13 isn’t correct. Bombieri and Davenport’s proof does not give (1.1) on EH, in fact assuming EH does not help in their proof at all. The problem is that the major arc approximation used there becomes worse for Farey arcs with denominator larger than N^(1/2) because the arcs become so short. Even if one replaces Bombieri and Davenport’s arc widths 1/Q^2 with 1/qQ this does not help. One can generalize their proof as I did in ")#link("http://www.math.sjsu.edu/~goldston/article17.pdf")[#text("http://www.math.sjsu.edu/~goldston/article17.pdf")]#text(" and obtain (1.1) on EH for both Lambda and the sieve weight Lambda_Q (stated on the second page of that paper,) but I’ve never believed that assuming EH for an object like Lambda_Q is worth anything. I tried to get (1.1) from EH for Lambda and for Mu, but never succeeded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249924")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2013")])]

#text("Thanks for the correction! Actually what you write is pretty much what I had read in your paper when writing my Bourbaki report on your work with Pintz and Yildirim (")#link("http://www.math.ethz.ch/~kowalski/goldston-pintz-yildirim.pdf")[#text("http://www.math.ethz.ch/~kowalski/goldston-pintz-yildirim.pdf")]#text(", see Remarque 3.1, which mentions your paper and that “a certain form of EH would imply…”), but when I wrote the footnote in the Polymath8 paper I just vaguely remembered the conclusion (and had forgotten the rest…)")

#text("I think it’s simpler here to delete the footnote (in the earlier account, it was useful as a way of showing a faint historical trail, and emphasizing the link between the original motivation of Bombieri for the B-V theorem and gaps between primes.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249979")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("I am reviewing typei-ii.tex (again, a bit slower than I’d hoped).")

#text("Here’s a question concerning the reduction to exponential sums (with references to the current newgap.pdf in the main folder): it seems to me that when completing the sum, we are doing as if (in (7.22) and later) the modulus of the sum that we complete is q_1q_2r instead of [q_1,q_2]r (see the value of H in (7.23)). Of course this is irrrelevant in terms of the length of the dual sum over h, which can be increased, but it affects the factor 1/H=M/q (roughly) from Lemma 6.9 (ii), which seems to be bigger than what we write by a factor q_0.")

#text("If I understood this right, this means we need a target (7.27) smaller by a factor 1/q_0, i.e., a RHS x^{-\\eps}Q^2NR/q_0^2.")

#text("From a quick read-through of the remainder ot Section 7 and of Section 10, this is actually something we prove, because the exponents of q_0 in all conditions to check are always strong enough (and of course it doesn’t affect the generic case q_0=1). But before making the changes to (7.27), I’d like to make sure that I am not missing something obvious here…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-249981")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("Oops, you are right, this extra factor of ")#mi("q_0")#text(" is indeed missing, but we have enough powers of ")#mi("q_0")#text(" to spare to deal with this. (I checked Andrew Granville’s version of the argument and it looks to be OK because he does the completion of sums a little differently.) I’ll make sure to look out for the powers of q_0 when you’re done with this section (and with Section 10).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250054")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("I am getting confused now with the next step (the Type II estimate) — on the last line of Page 109 of the main folder version, the powers of q_0 are tight (q_0^{-2} on both sides), so if we need a better saving in q_0, it doesn’t work outright (precisely, we need q_0^{-4} after squaring, but we only gain one q_0 from the smaller size of H).")

#text("This doesn’t seem to be problematic for Type I estimates on the other hand.")

#text("The problem comes from the absence of gain in q_0 in the second term of Proposition 7.8, which however seems wasteful. (I haven’t checked yet in Zhang’s treatment or Andrew’s to compare…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("Oh dear, this is a non-trivial issue. For non-zero ")#mi("k")#text(", I think it can be repaired by exploiting more fully the constraint ")#mi("\\frac{b}{n} = \\frac{b^{\\prime}}{n+kr}\\ (q_0)")#text(" in the phase (7.24), which after fixing ")#mi("k,r")#text(" constrains ")#mi("n")#text(" to a single residue class modulo ")#mi("q_0")#text(". This gives an additional factor of ")#mi("q_0")#text(" saving in (7.28) which seems to give enough room to fit in the loss of ")#mi("q_0")#text(" you pointed out.")

#text("The ")#mi("k=0")#text(" case remains a problem. Of course, by restricting to this case, one saves a factor of ")#mi("N/R")#text(", but the way things are set up right now, ")#mi("N/R")#text(" is tiny (as small as ")#mi("x^\\varepsilon")#text(") and so this does not directly help us. Zhang sets ")#mi("N/R")#text(" to be larger than this in the Type II case (something more like ")#mi("x^{2\\varpi+\\varepsilon}")#text(", if I remember correctly), which would solve this problem but worsen the Type II numerology a little bit, which would be annoying.")

#text("The other thing we could do is try to eliminate the ")#mi("q_0>1")#text(" case earlier, before completion of sums. This is actually what Zhang does, but the price one pays for this is that the residue class ")#mi("a")#text(" that one initially works with can no longer be completely arbitrary, but has to obey a “controlled multiplicity” condition, basically for any ")#mi("n \\sim x")#text(", one cannot have more than ")#mi("x^{o(1)}")#text(" moduli ")#mi("q")#text(" for which ")#mi("a = n\\ (q)")#text(".")

#text("I think the issue may also affect Andrew’s version of the argument; he correctly tracked the powers of ")#mi("q_0")#text(" (which he calls ")#mi("g")#text(") all the way through to the third display of page 49, which I have not yet checked carefully. (Also there is a tiny typo in that paper: in the penultimate display of page 47, ")#mi("H_i")#text(" should be ")#mi("2^i G/g")#text(" rather than ")#mi("2^j G/g")#text(".) I have to run for now, but will return to this issue later.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250061")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("I think Andrew mentions something about (the analogue of) Prop. 7.8 not being optimal in terms of q_0 (or is it about another lemma? I have to check).")#linebreak()#text(" I will also continue thinking about this…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("OK, I think I have a fix which is not too bad. It involves treating the ")#mi("k=0")#text(" case separately, and using the additional constraint on ")#mi("n")#text(" in the ")#mi("k \\neq 0")#text(" case. The precise changes are as follows")

#text("1. After the paragraph containing (7.20), declare that we will treat the ")#mi("k=0")#text(" contribution first. Here we do not split off an X term, and simply aim to bound")

#tao-math("\\sum_r \\sum_{q_1r, q_2 r \\in {\\cal D}_I(x^\\delta)} c_{q_1,r} \\overline{c_{q_2,r}} \\sum_{(n,q_1q_2 r)=1} \\left|\\beta(n)\\right|^2", block: false)#linebreak()#text(" ")#mi("\\sum_m \\psi_M(m) 1_{mn = a\\ (r); mn = b\\ (q_1); mn = b^{\\prime}\\ (q_2)}")

#text("in magnitude by ")#mi("O( N^2 M R^{-1} \\log^{-A} x )")#text(".")

#text("We write ")#mi("l = mn")#text(" and the divisor bound to crudely bound this quantity by")

#mi("x^{o(1)} \\sum_r \\sum_{q_1 r, q_2 r \\in {\\mathcal D}_I(x^\\delta)} \\sum_{l \\sim x} 1_{l = a\\ (r); l = b\\ (q_1); l = b^{\\prime}\\ (q_2)} 1.")

#text("By the Chinese remainder theorem, the l summation is ")#mi("O( \\frac{x}{r[q_1,q_2]} )")#text(" (one has to note that ")#mi("x \\gg RQ^2")#text(", which can be deduced from (7.2), (7.12), (7.13) with plenty of room to spare), so we now have")

#mi("x^{1+o(1)} \\sum_r \\sum_{q_1,q_2} \\frac{1}{r[q_1,q_2]}")

#text("which sums to ")#mi("x^{1+o(1)}")#text(", which is acceptable since ")#mi("R \\leq x^{-\\varepsilon} N")#text(".")

#text("For the rest of section 7 we insert the condition ")#tao-math("\\left|k\\right| > 0", block: false)#text(".")

#text("2. Now that k is nonzero, we can insert an additional factor of ")#mi("(k,q_0)")#text(" on the RHS of (7.27), thanks to Lemma 1.6. We’ll need this factor later.")

#text("3. In Section 7.3, we save the constraint ")#mi("1_{b/n = b^{\\prime}/(n+kr)\\ (q_0)}")#text(" from (7.24) and combine it with the ")#mi("\\beta(n) \\overline{\\beta(n+kr)}")#text(" weight. Observe that as ")#mi("r")#text(" is coprime to ")#mi("q_0")#text(", this constraint restricts ")#mi("n")#text(" to at most ")#mi("(k,q_0)")#text(" residue classes modulo ")#mi("q_0")#text(". If we use (1.5) instead of (1.4), we can now insert a factor of ")#mi("\\frac{(k,q_0)}{q_0}")#text(" in (7.28) and the preceding display after inserting the ")#mi("1_{b/n = b^{\\prime}/(n+kr)\\ (q_0)}")#text(" weight (and removing the equality symbol in the display before (7.28)). This gains us an extra factor of ")#mi("q_0")#text(" in the rest of the argument which should compensate for the loss of ")#mi("q_0")#text(" that you noted previously.")

#text("4. Some minor modifications may need to be made to the Type I arguments (either we save the factor of ")#mi("(k,q_0)/q_0")#text(" as in the Type II estimates, or we simply throw this improvement away and take the loss of ")#mi("q_0")#text(").")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250068")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("I’ll check and incorporate this version of the argument tomorrow. At first sight it certainly seems reasonable (and philosophically it would be strange if the numerology with gcd q_0 >1 does not conform to that with q_0=1…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250075")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("Terry’s fix looks good to me. For the new version of (7.28) with the extra factor ")#mi("(k,q_0)/q_0")#text(", we need that ")#mi("Q\\leq N")#text(", but this follows (7.12), (7.13), and the conditions in Theorem 7.7.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250151")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("I’ve put up in the subfolder what I have done so far with typei-ii.tex, which is up to the end of Section 7.4. I will begin the Type I estimates tomorrow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("I looked through it and it seems fine to me. Some minor comments:")

#text("page 97, after the discussion of the off-diagonal contribution: “there can be cancellation between these non-negative terms” should probably be “there cannot be any cancellation between these non-negative terms”. Also, in footnote 18, I was not quite clear as to what “repeating the computation” meant… I guess you are trying to say that we should not be too fixated on the operator norm per se, but rather on the computational techniques used to estimate such norms?")

#text("around (7.4): ironically, with our new fix, the case k=0 that we considered “for simplicity” becomes the case for which we do NOT apply the method indicated! But perhaps this is OK as long as we admit that we are “lying” when giving this oversimplified presentation.")

#text("In (7.29), a factor of ")#mi("(q_0,\\ell)")#text(" is missing on the RHS. The definition of H here is now very slightly different from that in the previous section, but they are equivalent up to constants; actually, for consistency, we may wish to take H equal to ")#mi("x^\\varepsilon Q^2 R M^{-1} q_0^{-1}")#text(" before Remark 7.7, rather than ")#mi("x^\\varepsilon [q_1,q_2] r M^{-1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250208")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("In footnote 18, I wanted to mean that, in some sense, we repeat three or four (or more…) times the same technique, more or less explicitly, instead of having stated an abstract lemma and applying it. (It is not a very important remark so it might be removed.)")

#text("I’ll take care of the other corrections. Actually, it seems the exponential sum estimate is now even better than strictly needed in terms of q_0 when keeping track of the support in n for k non-zero (restricting to few congruence classes modulo q_0) but I haven’t propagated this improvement to the main statement of Theorem 7.8 (of the ek version).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250217")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Actually, what I wrote is absurd, I forgot the squaring-step so the gain we need comes from the n sum in both factors of Cauchy-Schwarz, but I forgot to write it on the second side.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250273")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("The first Type I estimate is now done in the ek folder. I will now work on the last…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250290")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("Bibliography:")

#text("* [6] and [16]: It should be an n-dash instead of a hyphen when indicating a (page) range")#linebreak()#text(" * [25]–[29]: “Ph.Michel” –> “Ph. Michel”")#linebreak()#text(" * [43] and [52]: Remove “pp.”")#linebreak()#text(" * [69]: A comma before the page range")#linebreak()#text(" * [78]: “G.N.” –> “G. N.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250694")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2013")])]

#text("Corrections done in the ek folder.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250706")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2013")])]

#text("Missing: “no. 3-4” –> “no. 3–4” in [6].")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250362")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("I am done reviewing Section 7. The only other remark I had is that I think the middle-condition (which is always the same) in the type I cases seems to involve sigma because one needs a lower-bound for N, namely it should be")

#text("8\\varpi + 3\\delta< 1/2-\\sigma")

#text("instead of")

#text("20\\varpi+6\\delta<1.")

#text("I might have misunderstood, but in any case this condition is always weaker than the first condition, so it doesn't change anything.")

#text("The gain of q_0 was also needed for the second Type I estimate, but not (as far as I could see) for the first.")

#text("I now hope to read Section 8 fairly quickly…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250541")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("A few more, typos and style suggestions:")#linebreak()#text(" 1. p 77, line -7 of Proof of Lemma 5.4, Siegel-Walfisz theorem -> Siegel-Walfisz property.")#linebreak()#text(" 2. p 78, line 9, Type III needs \\sigma in bracket.")#linebreak()#text(" 3. p 78, line 10, direclty -> directly")#linebreak()#text(" 4. p 79, 4th line under (5.19), ")#mi("\\mu_\\geq,\\Lambda_\\geq,1")#text(" -> ")#mi("\\mu_\\geq * \\Lambda_\\geq * 1")#text("?")#linebreak()#text(" 5. p 79, 4 lines under previous, ")#mi("\\mu_< * \\Lambda_<")#text(" -> ")#mi("\\mu_< *\\Lambda_<")#text(" “Lemma 6.9 and Proposition 6.10”.")

#emph[#text("[Unfortunately, I could not fully repair your item 5; it appears that < and > signs have been interpreted as HTML. You will need to use &lt; and &gt; instead. -T.]")]

#emph[#text("[These changes have been made to the main folder files -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250641")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2013")])]

#text("[Thanks for editing, Terry. The <‘s and >’s made quite a mess. The original was quite a bit longer. I cannot fix 5, so I will try to avoid <‘s:]")

#text("5. p 79, 4 lines under previous, another , should be *?")#linebreak()#text(" 6. p 84, statement and proof of Lemma 6.5, (1) and (2) can be changed to (i) and (ii) for consistency.")#linebreak()#text(" 7. p 84, line after (6.6), b should be (b,q)?")#linebreak()#text(" 8. p 85, line after 1st display of proof of Prop 6.6, Z/qZ should be Z/pZ?")#linebreak()#text(" 9. p 86, 3rd line of proof of Lemma 6.8, ")#mi("e_1, e_2")#text(" should be ")#mi("\\delta_1, \\delta_2")#text(".")#linebreak()#text(" 10. pp 89-90, statement of Prop 6.10, (i) and (ii) need to be in roman font to be consistent with other places. (Same for several places in Sec. 7)")#linebreak()#text(" 11. p 90, line -3 of Remark 6.11, “Lemmas 6.9 and 6.10” should be “Lemma 6.9 and Proposition 6.10”.")

#emph[#text("[These changes have been made to the main folder files -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250678")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2013")])]

#text("I incorporated these also in the ek subfolder.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-250623")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2013")])]

#text("I have now put the deligne.tex section in the ek subfolder. The changes there are few:")

#text("(1) I added references to some more surveys (one a slightly older one of mine, and an upcoming one by Fouvry, Philippe and myself (that will appear in the Colloquio di Giorgi series, and which will be ready soon)")

#text("(2) some exponents for conductors were a bit off, I think (this is immaterial for the applications of course)")

#text("(3) I clarified a bit subsection 8.3 which might have been a bit unclear; one or two references might be useful there, which I will take care of.")

#text("(4 I wrote the section on incomplete sums as in exponential.tex, independently of the standard asymptotic convention")

#text("(5) I gave some details in Corollary 8.25 on how to sum with the coprimality condition, since this type of restriction is not directly handled by Section 6.")

#text("Onward to typeiii.tex !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the first paper, V, and a look ahead | What's new")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-251454")[#strong[#text("Polymath8: Writing the first paper, V, and a look ahead | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("[…] time to (somewhat belatedly) roll over the previous thread on writing the first paper from the Polymath8 project, as this thread is overflowing with comments. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-255511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("8\\varpi + 3\\delta< 1/2-\\sigma")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-255512")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("\\mu_")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-2/#comment-255516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("What are you talking about? If you have found an error, tell where it is. No one has any chance of knowing what you are talking about.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248151")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("I’m done with the short Section 4.3. About the only change worth noting is that I replaced the preprint reference for the second Bessel identity with a reference to Watson’s book (according to Watson, the formula is due to Lommel, and goes back to 1879, and a special case is already in Fourier…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248171")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("Regarding Figure 3 in Section 3, I think it would be better to use H rather than H(k) in the label for the vertical axis, since we have defined H(k) as the minimal diameter of an admissible k-tuple and the plot is using upper bounds H on H(k). I would change the captions for both figures 2 and 3 to read “…best known upper bound H for H(k)…”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248240")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("These changes have now been made.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248179")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("Regarding the Newletter for the EMS, I will be happy to share my experiences (after the main paper is submitted).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248184")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("I’ve done some (small) changes to Sections 3.1 and 3.8. The changes in Section 3.1 might be a mere reflection of my own confusion, so feel free to undo them if you want. I was a bit confused about the statement that if ")#mi("p = (1 + o(1))k / \\log k")#text(", then the expected number of missing residue classes is ")#mi("\\gg \\log k")#text(". E.g. if ")#mi("p = k / \\log k")#text(" (which is also ")#mi("(1 + o(1)) k / \\log k")#text(") then this is not true. But conversely I agree that the minimal factor one has to include for the conclusion to become true is ")#mi("1 + o(1)")#text(", so that’s probably what was meant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248187")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("I think the changes you made are fine, but I’ll look at it more carefully when I make my own pass through section 3 (are you still working on it?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248188")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("This was one of the points on which I also didn’t feel I understood the underlying argument, so my write-up was certainly shaky. I won’t touch Section 3 soon, so you can change it as needed, as far as I am concerned.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69739ed99dd3b68ede9bf51b75268e03b562a4909459a13eda7fe8a34528fe13-7a71f7ddc4c734b6572dcef5ff222910af19a7b29e3bef322d45ee8f7160cbdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bevan")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248186")[#strong[#text("David Bevan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("An ‘epsilon’: In the abstract “the q-van der Corput A-process of Heath-Brown and Ringrose” should probably be “the q-van der Corput A-process of Heath-Brown and Graham-Ringrose” as in the rest of the paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248195")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("One left-over comment on Section 2:")

#text("–Near the bottom of page 23, a sentence ends “…concerning $\\varpi$ and $\\delta$.” This phrase can be removed, as those parameters are also mentioned at the beginning of the sentence.")

#text("————————-")

#text("Comments on Section 3–I was a little more lax in reading this section, but found a couple things.")

#text("1. Section 3,1, page 26. Change “using a sieve of Eratosthenes” by replacing “a” with “the”.")

#text("2. Two paragraphs later, change “according as to whether…” by removing “as”.")

#text("3. Section 3.2, page 28. Change “there exists indeed infinitely many choices…” to “there indeed exist infinitely many choices….” [Change the word order, and “exists” to “exist”.]")

#text("4. Section 3.3, page 29. The word “entriers” should be “entries”")

#text("5. Section 3.4, first paragraph (currently page 30). The last sentence is confusing, as “Hensley and Richards” are mentioned both directly before the parenthetical, and directly afterwords.")

#text("6. In the same paragraph, it says this “leads to the asymptotic bound…” but then later better upper bounds are obtained. I recommend changing “asymptotic” to “upper”.")

#text("7. Section 3.5. Change “sieve the the residue” by removing one of the the’s.")

#text("8. Section 3.6. Change “is to check is whether…” by removing the second “is”")

#text("9. Next paragraph, change “which has all one…” to “which has all but one…”")

#text("10. Paragraph before Section 3.6.1: change “sketch three of them” to “sketch four of them”")

#text("11. Section 3.6.1, change “residue class $a_p$ of $a$ modulo $p$…” to “residue class $a_p$ in $\\Z/p\\Z$…”. [It may be confusing to the reader that the notation is being changed here. In sections 1-2, this residue class would be written as “a_p (p)”.]")

#text("12. Last paragraph of 3.6.1. An inequality is spilling off the line. Also, instead of $a_1 \\cup \\cdots \\cup_a n$ it should be $a_1 \\cup \\cdots \\cup a_n$. [The $a$ shouldn’t be in the subscript.]")

#text("13. Section 3.7. A space is missing in “ofnarrow”")

#text("14. Section 3.8. The second paragraph is a parenthetical, with a parenthetical inside. I recommend removing one of the levels of parens.")

#text("15. Four paragraphs later, change “it is better to use directly…” to “it is better to directly use…”")

#text("16. Later in the same paragraph, it says “where the optimal value is roughly…” It may be helpful to write “where the optimal value of $Q$ is roughly…”")

#text("17. Next paragraph, one sentence ends “so that $M(d)\\leq k-1$ if and only if $H(k)\\geq d$.” I recommend making this phrase its own sentence.")

#text("18. Section 3.8.2: change “we already known an…” to “we already know an…” [replace “known” with “know”]")

#text("19. Paragraph above 3.8.3. Change “since partitioning is overtaken by the inclusion-exclusion algorithm below as soon as…” by either removing “below” or changing it to “from below”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248197")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("Thanks for all the edits! I’ll coordinate with Wouter to make sure these get made.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248236")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("Hi, I incorporated Pace’s suggestions, thanks for those. For the moment I’m no longer working on Section 3, so you can go ahead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248239")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("Great. I see that xfxie changed the label on the vertical axis in Figure 3 per my suggestion above (thanks!), and I just changed the captions to match. I won’t have time to work on it today, so feel free to make further edits if anything comes up. I’ll plan to work on narrow.tex on Friday and over the weekend.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248265")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("In remark 2.18, I suggest to replace “the above table” by “table 4” (which is now below remark 2.18).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48fce4eb8ee74132a21b83db48941b7755f7004fe88049fdc6070ff8064e71a0-7401a4eab5f795736c314dbe6614509e8052467db7407c1495e85fb1ade67d64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of foobar")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248267")[#strong[#text("foobar")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("Nothing to do with the math itself, but URL in footnote 7 appears to have “http://” missing – it reads just “math.mit.edu/~primegaps/tuples/admissible_tuples_632_4680.txt”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248289")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("This has been fixed, thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("I’ve been playing around with variants of the GPY sieve")

#mi("\\nu(n) := (\\sum_{d|P(n)} \\mu(d) F( \\frac{\\log d}{\\log R} ) )^2")

#text("and more specifically with sieves of the form")

#mi("\\nu(n) := (\\sum_{d_1|n+h_1; \\ldots; d_{k_0} | n+h_{k_0}} \\mu(d_1) \\ldots \\mu(d_{k_0}) f( \\frac{\\log d_1}{\\log R}, \\ldots, \\frac{\\log d_k}{\\log R} ) )^2")

#text("where ")#mi("f: [0,+\\infty)^{k_0} \\to {\\bf R}")#text(" is a cutoff function. This generalises the GPY sieve (which is basically the case when ")#mi("f(t_1,\\ldots,t_{k_0}) = F(t_1 + \\ldots + t_{k_0})")#text("), but the increased flexibility of the multi-dimensional cutoff function f seems to give better results in the asymptotic regime when ")#mi("k_0")#text(" is very large. (It may be that Maynard has done something very similar at the other end of the spectrum when ")#mi("k_0")#text(" is very small, assuming EH – I haven’t gotten any more details on that yet though.) However it is a bit difficult to compute explicitly with these multidimensional cutoffs, so I’m not sure that these methods can help us for, say, ")#mi("k_0 = 632")#text(", since 632-dimensional integrals are not exactly easy to work with. But this may be another thing to consider for a potential “Polymath 8b” sequel to this current project. (Certainly there is no reason why the current project should be regarded as the definitive last word on prime gaps for all eternity!)")

#text("I’ll try to write up some notes on this in the near future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248296")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("Perhaps the resulting optimization problem for the generalized ")#mi("f")#text(" may lead to a similar (and perhaps analytically solvable) variational problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248382")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("In section 1, in the paragraph immediately prior to subsection 1.1, does the statement about B[16] now need to be modified in light of these developments?")

#text("Incidentally, there is a typo in the previous paragraph: “dependes”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248387")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("Well, one needs to have details and references before making any changes…")

#text("Incidentally, I heard from É. Fouvry that Zhang himself talked in Montréal this week about some other ideas he is working on to improve the GPY method.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248390")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("I was just thinking that the statement as written sounds too definitive (referring to the strongest possible results, rather than for example the strongest known results). Indeed, it seems to be already contradicted by the discussion of possible new sieves in Section 11 paragraph iii. Apologies if I’m misunderstanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248416")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("I’ve been in touch with James Maynard. He has indeed (provisionally) obtained B[12] on EH, basically by performing a computer optimisation on the multidimensional cutoff functions discussed above, and also is provisionally reporting a result B[H] for a small value of H (perhaps as small as H=700) using Bombieri-Vinogradov, and also intervals of that size with three primes (rather than two) assuming EH. But this is all numerical work and is subject to confirmation. The details are not yet written up and probably won’t be for a few more weeks yet. So the Polymath8 results may soon be overtaken by events; but the results in our paper have independent interest beyond the primary goal of getting B[H] for H as small as possible. I’ve invited Maynard to contribute to a future “Polymath8b” project in which H is optimised further, but he requested some time to think about it.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248453")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")])]

#text("Bounded gaps without any exponent of distribution >1/2 would be an extraordinary achievement!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248727")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("@Emmanuel: Probably Terry meant that Maynard does not need Deligne for B[700]. I am sure he still needs to go beyond level 1/2.")

#text("@Terry: We should send Maynard some present to convince him to join the PolyMath efforts :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248729")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Gergely: given how diligently Terry seems to read everyone’s posts here, I’d be awfully surprised if his failure to reply to Emmanuel does not imply that he meant (essentially, anyway) what he wrote. But regardless, it’ll be extremely exciting to see which elements of polymath8 further improve k0 over what Maynard has (provisionally, of course) already achieved. Will we see a two-digit k0 this year? It’s beginning to be hard to bet against that. As one of the non-specialists who have been in awe of what you experts have been doing here, I feel that one of the most illuminating aspects has been the ebb and flow of perceived plausibility of progress in the various available avenues.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248389")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("P.S. Thanks for pointing out the typo…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248924")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("A related problem is to find a “good structure” for the generalized f in terms of several one-dim. functions for which the optimization may lead to a system of ODE (rather than PDE for the most general f.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248325")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("I am continuing in section 4. Here’s a point that puzzles me: page 52 of the current newgap.pdf, we write (between (4.37) and (4.38)): “so by repeating the analysis in Section 4.2 to deal with error terms, we conclude…” How does this work?")

#text("Compared with Section 4.2, there is a factor F(d)-\\tilde{F}(d), and if I understood right, the point in Section 4.2 was to get a negligible error by having a difference of two sums with the same asymptotic behavior. Here we do not have an asymptotic formula for the difference F(d)-\\tilde{F}(d), only estimates, so I don’t see how to cancel the main terms to get a negligible contribution from the error term for F(d). Or did I misunderstand something in the treatment of Section 4.2??")

#text("It seems to me that Section 4.2 can be done asymptotically (by doing the Möbius inversion asymptotically instead of isolating the contribution of the divisor 1 and saying that the remainder is O(d/varphi(d)-1), as in the last line of page 48), using a variant of Lemma 4.2 that has a coprimality condition inserted (i.e., that is uniform with respect to such changes of the multiplicative function of Lemma 4.2). This might even give a slightly nicer-looking argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("I guess there wasn’t enough explanation for this step. By using the crude bound")

#mi("0 \\leq F(d_0) -\\tilde F(d_0) \\leq F(d_0) \\leq \\frac{\\phi(W)}{W} \\log R ( O(1) + \\frac{d}{\\phi{d}}-1 + o(1) )")

#text("the discrepancy between (4.36) and (4.38) is bounded in magnitude by")

#mi("O( (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0} \\frac{h(d_0)}{d_0} ( O( \\frac{d}{\\phi(d)}-1)^2 + O( \\frac{d}{\\phi(d)}-1) + o(1) )")

#text("which are error terms of the forms all treated in Section 4.2.")

#text("But perhaps there is a cleaner rearrangement of the argument as you say…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248376")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("Right, I see what I missed! I will add a few words to the argument…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248380")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("I have now finished reading Section 4.4.")

#text("I’ve added a lemma 4.10 which encapsulates the use of the Mertens formula for the sums over primes which occur twice in this section and two times more in the next. The location might not be the best: it’s analogue to Lemma 4.2, and maybe would be better around there?")

#text("Apart from that, there are only cosmetic changes and some more details for certain computations.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("I think the lemma is fine where it is; it would also come in handy for Section 4.5 actually. In any case the proof is so short that it is not intrusive.")

#text("Minor typos and comments:")

#text("Beginning of Section 4: “All but the first one [of the four theorems]” should be “The latter two”. (Theorem 2.12 still needs some sort of Elliott-Halberstam.)")

#text("near (4.26): one can use := instead of = for the definitions of ")#mi("\\varepsilon(d)")#text(" and ")#mi("\\varepsilon_1(d)")#text(". Shortly afterwards, “the main term is equal to…” should be “the main term is equal to … up to negligible errors”.")

#text("page 50: for (4.25), one might wish to put absolute values on the LHS since it is negative (although strictly speaking it is unnecessary with our definition of the ")#mi("\\ll")#text(" notation).")

#text("page 51, a bit after (4.28): “where ")#mi("\\Gamma")#text(" the Gamma function” is missing an “is”.")

#text("page 53, start of Section 4.4: “unconditionnally” -> “unconditionally”. “first of our result” -> “first of our results”")

#text("Page 55, first half: in the formula for F(d), ")#mi("O(\\varepsilon(d))")#text(" should be ")#mi("\\varepsilon(d)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248393")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("Thanks for the corrections, I’ll put them in right away.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248394")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("It appears that my version of section 4 may soon be out of date. I’ve only gotten through the first five pages so far, so maybe I’ll wait a day or two and download the new version. Anyway, here are my suggestions (hopefully the numbering still matches):")

#text("1. First paragraph of section 4, it says “All but the first one can be used…” I recommend change “one” to “of these sieves” [to clarify you are talking about the sieves, and not the previous list of Theorems].")

#text("2. The second offset equation in the proof of Lemma 4.1, reads ")#mi("((\\alpha+o(1))\\log 3x - (\\beta-o(1))\\log R) B \\frac{x}{W}")#text(". This is the negative of the correct lower bound, and the \\alpha,\\beta summands should be switched.")

#text("3. In the next paragraph, it says that ")#mi("\\nu")#text(" is set equal to an elementary Selberg sieve. It might sound better to say something like ")#mi("\\nu")#text(" is a weight/counting function in the sieve (rather than equal to the [whole] sieve).")

#text("4. In equation (4.7), the summation is over ")#mi("d\\in \\mathcal{S}_{(w,+\\infty)}")#text(". In responses to my suggestions for Section 1, it was stated that the notation ")#mi("\\mathcal{S}_I")#text(" is used only finite intervals, but it might be good to rethink that since this notation is used often in this section.")

#text("5. In that same equation, in the subscript, we also have the restriction ")#mi("d|P(n)")#text(". I cannot seem to find the definition of P(n) anywhere in the paper. I looked pretty thoroughly, but may have missed it. [If I recall correctly, this is the place where the admissible tuples comes in, and P(n) does NOT equal to the product of primes up to n, which is how P(z) is usually defined in sieves.]")

#text("6. In the proof of Lemma 4.2, the second sentence reads “By rescaling we may assume that ")#mi("g")#text(" is supported on ")#mi("[-1.1]")#text(".” I can’t seem to find any place that this is ever used, so you may want to delete this sentence.")

#text("7. Later in the proof, in the second offset equation after (4.12), in one of the summations, the subscript is ")#mi("d:(d,W)=1;d")#text(". The ending “;d” should be removed.")

#text("8. Throughout Lemma 4.2, and its proof, there seems to be a weird extra space between ")#mi("g")#text(" and the left parenthesis, when the left parenthesis is larger. This spacing isn’t especially awful, except in the offset equation I mentioned in point 7, where it almost looks like you have ")#mi("1/ d^g")#text(".")

#text("[I also noticed that the infinity signs in the paper are not symmetric–the left side is smaller than the right side, which is somewhat odd.]")

#text("9. Later in the proof of Lemma 4.2, it says “and hence by summation by parts…” followed by an offset equation. I’m sad to admit that when I was reading this part it took me nearly half an hour to figure out why this equality holds. Part of the problem for me was that I didn’t believe that a summation by parts would result in an integral involving g. Finally, when I decided to just try the actual integration by parts, I realized where the g came from– we are doing a chain rule on ")#mi("g(stuff(d)) * 1/d")#text(", and the g’ part gets absorbed into the error terms.")

#text("I don’t know that anything needs to be done here. If I had just believed the statement that I should do summation by parts, it would have worked out cleanly and quickly. But maybe a statement about simplifying or absorbing terms into the errors would be helpful.")

#text("10. In my version of the paper, bottom of page 42, offset equation directly before (4.13). In the subscript it has ")#mi("\\mathcal{S}_I")#text(" — where in all previous summations the interval ")#mi("I")#text(" is ")#mi("(w,+\\infty)")#text(". It might be helpful to state explicitly that we let ")#mi("I=(w,+\\infty)")#text(" at this point.")

#text("11. Sentence below (4.13): it say “by another application of Lemma 4.2 the previous expression may be upper bounded…”. It isn’t clear at first whether the “previous expression” is (4.13), or the offset equation directly before that [I believe you meant the latter].")

#text("Later in the same sentence, it has ")#mi("O((W/\\varphi(W))^{0(1)}")#text(". The extra parentheses can be removed. Also, is there any specific reason for the flip from ")#mi("\\varphi(W)/W")#text(" to the reciprocal?")

#text("Later in the same sentence, it says “which is negligible for (4.2) by (4.5),(4.1).” It may be better to say “…by (4.1), (4.5), and (4.6).”")

#text("12. In the subscript of the summation in (4.15), I recommend changing ")#mi("d|d_1,d_2")#text(" to ")#mi("d|(d_1,d_2)")#text(". [Add the parens.]")

#text("13. In the second offset equation after (4.17), the RHS is ")#tao-math("\\sup_{d\\leq R} \\left|a_d\\right|", block: false)#text(". Should it be |a_d|^2 rather than |a_d|?")

#text("That’s as far as I got.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248399")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("By the way, thank you for putting my equations in math mode here. I’ll try to remember to do that myself in the future. And thanks for fixing some of my own typos!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248402")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("Indeed, this section is undergoing changes as I continue reading through, so a number of corrections have already been made or are not directly relevant (e.g., the polynomial P(n) that was missing is now defined…)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248403")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("In the proof of lemma 4.9 (folder ek), claim (ii) is immediate for ")#mi("t+t^{\\prime} \\ge 1")#text(" (not just ")#mi("t+t^{\\prime} > 1")#text(") because ")#mi("f(1) = 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248417")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("A couple of small typos:")#linebreak()#text(" 1. middle of p7, ")#mi("ee_q(a) = \\left(\\frac{a}q\\right)")#text(", one of the ")#mi("e")#text("‘s should be after =.")#linebreak()#text(" 2. Same page, definition of Dirichlet convolution, subscript of final summation sign should be ")#mi("ab=n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248426")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2013")])]

#text("p 13, line above Definition 2.7, ")#mi("\\varpi \\geq 1/2")#text(" should be ")#mi("\\varpi > 0")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248519")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")])]

#text("Definition 2.21(iii), Type III should have ")#mi("\\sigma")#text(" in […].")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248456")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")])]

#text("I have just finished re-reading Lemma 4.11 (properties of dense divisibility). Apart from a few typos, I just expanded the shorter proofs — since I was checking the details anyway. It may be possible to make it more concise again (obviously, checking the details for oneself helps a lot in clarifying the concept). I also used references to the d.d. property of smooth numbers (which is part of the lemma) instead of speaking of “greedy algorithm”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248488")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")])]

#text("I finished with section 4.5. Nothing special to mention, except that I moved the final remark of that section (on quantitativer results) to the end fo Section 4.1, since it seems to fit better at the end of the general discussion of the basic ideas of the GPY method. (I uniformized the notation of the parameters with the changes I had made for typographical reasons in subtheorems.tex)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248554")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("I read the final optimizing section of Section 4. The changes I made are cosmetic, since I don’t know anything about this type of optimization methods (for the same reason, this should be checked again to make sure I didn’t inadvertently introduce a problem). I’d suggest adding a standard reference at the beginning, that might be useful to orient readers like me.")

#text("I downloaded the scripts K0Finder.zip mentioned in the footnote, but I haven’t succeeded in making them work on my computer. From just looking at the shell files, it seems that the DEPSO instance does not contain the required problem file (?) (at least running OptSolver.sh leads to an error of this type). Also I didn’t see where/how the Maple script is created.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248572")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Thanks for the revisions for this section.")

#text("Just tested the K0Finder.zip package on another machine. Seems I did introduce some errors as trying to make the package clearer. Sorry for that. Now the package (and README) is updated.")

#text("Until now, it has been only tested it on mac and Ubuntu linux. Please let me know if there are any problems to make it work on your machine.")

#text("BTW: There are two examples in the directory “test”. The components for the Maple script will not be deleted if you comment out the lines in exec/clear.sh. The original files are located in the directory “inst” (for instances of c_varpi,c_delta, i) and “opt” (for optimization models).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248590")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("I will try the new version right away.")

#text("On a related note, I am trying to reproduce the values in Table 4 (for k_0=632) using Pari/GP. Everything works fine, except that I get a much smaller value of kappa_3. Here are some intermediate values that I got, which are not in Table 4, so that we can figure out where the computation goes wrong:")

#text("j_{k0-2} = 646.0292074…")

#text("the integral term \\int_xi^theta exp(-(A+2eta)t dt/t) =0.06841941358…")

#text("A+(k0-1)*(integral) = 243.17264997…")

#text("e = 4.06 * 10^(105)")

#text("tn = j*omega = 221.058250…")

#text("gd = 0.0002203823…")

#text("gn= 2.33353008… E-429")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248596")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Here is the only variable with significantly different value in Maple 16:")

#text("e = 0.5660882668 * 10 ^(419)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248597")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Besides:")

#text("int( exp(-(A+2*eta)*t)/t, t=deltat..theta, numeric ) = 1.211115925")

#text("A + (k0-1) * int( exp(-(A+2*eta)*t)/t, t=deltat..theta, numeric ) = 964.2141487")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248600")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Thanks, I found the mistake in my checks (I had changed the name of a variable…) Now everything fits!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248595")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("I have just updated optimize.tex in your directory (the original version is renamed as optimize.tex.ek), for the TODO tags that you put.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248578")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Corrections.")

#text("Proof of Lemma 4.12, l. 4: “")#mi("(0,y)")#text(" d.d” -> “")#mi("(0,y)")#text("-d.d”")#linebreak()#text(" Proof of Lemma 4.12, l. 16: “")#mi("(k,yn_1)")#text("-d.d.” -> “")#mi("(k,yn_1)")#text("-d.d”")#linebreak()#text(" Proof of Lemma 4.12, l. 17: “")#mi("(j,yn_1^{\\prime})")#text("-d.d.” -> “")#mi("(j,yn_1^{\\prime})")#text("-d.d”")#linebreak()#text(" P. 59, l. 8: “")#mi("(j,y)")#text("-d.d.” -> “")#mi("(j,y)")#text("-d.d”")#linebreak()#text(" P. 59, l. 9: “")#mi("(k,y)-d.d.")#text("” -> “")#mi("(k,y)")#text("-d.d”")#linebreak()#text(" P. 59, l. 13: “")#mi("1")#text("-d.d.” -> “")#mi("1")#text("-d.d”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248586")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Thanks, I’ll correct these!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Btw. is there a way for me to edit my own posts? (The wrong rendering is do to the ‘ where I should have used \\prime (I guess).)")

#emph[#text("[Unfortunately not, but I can manually edit comments to fix these issues – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248598")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("The j-folded convolution notation (introduced in lemma 5.3) should be added to subsection 1.3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("It’s true that this notation is currently being used in two sections (Section 5 and Section 11.1); but I am thinking in fact that we may end up deferring Section 11 (which is rapidly becoming obsolete) to a second paper (perhaps renaming the current paper as “A new bound for gaps between primes, I”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248615")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Hi, in Table 5 we include a number of upper bounds on ")#mi("H(k)")#text(" obtained by various methods. The first row “k primes past k” refers to the tuple obtained by taking the first ")#mi("k")#text(" primes greater than ")#mi("k")#text(". The second row “Zhang sieve” refers to the tuple corresponding to the minimal ")#mi("m")#text(" for which ")#mi("(p_{m+1}, \\dots, p_{m+k})")#text(" is admissible. Is there a reason why we call this the Zhang sieve?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248624")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("This follows the wiki write-up, but I think it would make more sense to call it the sieve of Eratosthenes, per the description on p. 28 (in the paragraph beginning “More practically”). I believe one can likely prove that this sieve will always yields tuples of the form ")#mi("(p_{m+1},\\ldots,p_{m+k})")#text(" (c.f. footnote 10), but in any case it certainly applies to all the tuples listed in Table 5.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Yes, the Eratosthenes sieve would make more sense as terminology (and is broadly consistent with the usage in Gordon-Rodemich, ")#link("http://www.ccrwest.org/gordon/ants.pdf")[#text("http://www.ccrwest.org/gordon/ants.pdf")]#text(" ). I think the name Zhang sieve originated very early in the Polymath project, before we knew of the relevant literature, and needed a name to distinguish the sieve arising from blocks of primes from Hensley-Richards type sieves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248641")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("I didn’t notice this when reading Section 3; I think “Zhang’s sieve” is only used in the table, however, so it’s probably best to replace it by something else, and add a few words somewhere at the beginning to indicate this terminology.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248669")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Hi, thanks for the clarification, I replaced the label “Zhang sieve” by “Eratosthenes” in the table, and added a line about this in Section 3.2.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("P. 64, l. -2: “")#mi("k_0^{opt}")#text("” -> “")#mi("k_0^\\mathrm{opt}")#text("” (this should be changed in quite a few places).")#linebreak()#text(" P. 65, l. -1: “")#mi("k_0^{init}")#text("” -> “")#mi("k_0^\\mathrm{init}")#text("” (this should be changed in quite a few places).")

#text("Furthermore, the aesthetic of the tables can be improved a bit. I will gladly give my (second) suggestion on how to type them properly, when the proof-reading is all over and no further changed to the tables will be needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248623")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Changed in the ek directory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("P. 68, l. 9 (not counting the picture and caption): “for if ")#mi("c = 10")#text("” -> “if ")#mi("c = 10")#text("”")

#text("P.S. “I will gladly give my (second) suggestion” -> “I will gladly give my (second) try”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248617")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("Near the end of the proof of theorem 2.16, ")#mi("\\tilde {\\theta}")#text(" is still mentioned several times, but it was replaced by ")#mi("\\omega ^2")#text(". (the reason for this replacement is not clear to me.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248674")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("I changed this just for typographical reasons (especially, I found the multiple \\sqrt{\\tilde{\\theta}} in the Bessel functions somewhat ugly…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248675")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("… but note that I kept \\tilde{\\theta}_{\\eps}, which is used in the proof, and which tends to the old \\tilde{\\theta} as \\eps –> 0. As far as I can see, this is the only occurence of \\tilde{\\theta}.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248680")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("I understand. (I meant that it still appears in the main folder.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248684")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Yes, the main folder has not yet been updated to the new version of gpy.tex")

#text("If there is no objection, I will make the change later today.")

#text("I also began reviewing heath-brown.tex.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("I implemented a number of corrections, largely to Section 10 in the main folder, that were supplied to me by Paul Nelson, who also noted that he had gone carefully through this section of the paper. Now that all the sections of the paper have been at least double-checked (though not by the same sets of authors), I feel comfortable now with removing the question mark on our main result of H=4,670 from the wiki.")

#text("Incidentally, when I compiled newgap in the main folder, my local copy of LaTeX (which is MiKTeX) failed to find the images h-plot, h-plot-rel, plot-pi, and plotk0-2, but this is presumably a local issue since I can see those files in the directory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248702")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("I have incorporated the changes in the subfolder and corrected a typo in the main folder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248709")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("I notice that question marks on k0=1788 and H=14994 were removed, but not the ones on k0=1783 and H=14950, which are the values that appear in the paper. Was that intentional?")

#emph[#text("[Oops, that was an oversight on my part; they are all removed now. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248708")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("The solution of (4.56) can be written explicitly in terms of the Lambert W function (which is implemented in Maple and Mathematica.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("There is an typo in either eqn. (5.9) or in the expression just below, I think (said by a non-mathematician): On the left-hand side of (5.9), it says “")#mi("(1-")#text("…” but in the equation just below, it says “")#mi("(1+")#text("…”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248713")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Thanks, I’ll correct this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248730")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("P. 68, l. 9 (not counting the picture and caption): “for if ")#mi("c = 10")#text("” -> “if ")#mi("c = 10")#text("”.")

#text("(I have mentioned this once but I’m not sure if anyone noticed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248738")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Changed, thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Table 7, right-most column: The minus signs are not in math mode.")

#text("Also, I would write “Objective” instead of “objective”, i.e., with a capital O.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248744")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Changed, thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("The \\num macro needs to be applyed to the two numbers in ")#mi("\\mathcal{H}_{250151,\\dots,3750150}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("That is in the last line on page 27.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AndrewVSutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248767")[#strong[#text("AndrewVSutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Fixed, thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248793")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("I’d like to record here a small refinement to the asymptotics in Section 3.2 that Wouter pointed out (and which I just verified). In the ")#text("progress report")#text(" it was noted that taking the first k primes greater than k gives the bound")

#mi("H(k) \\le k\\log k + k\\log\\log k + O(k)")#text(".")

#text("But if you carefully compute ")#mi("p_{\\pi(k)+k} - p_{\\pi(k)+1}")#text(" using the bounds in (3.1) that follow from a strong form of the Prime Number Theorem, you can actually show that taking the first k primes greater than k yields the tighter bound")

#mi("H(k) \\le k\\log k + k\\log\\log k - k + o(k)")#text(",")

#text("which is the same thing you get for the tuple ")#mi("(p_{m+1},\\ldots,p_{m_k})")#text(" for any ")#mi("m\\le \\pi(k)")#text(" (even ")#mi("m=0")#text("). There is a small asymptotic improvement from taking ")#mi("m = o(k/\\log k)")#text(", but it is hidden inside the ")#mi("o(k)")#text(" term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("– P. 5, l. -1: “Appendix” –> “appendix”")#linebreak()#text(" – Table 1: “Claim1.1” –> “Claim 1.1”")#linebreak()#text(" – Page 16, five lines after Theorem 2.12: The \\num macro should be applied to ")#mi("c = 1.855757\\dots")#linebreak()#text(" – Footnotes 4, 6, 13, 15: There is a space at the beginning of the note")#linebreak()#text(" – Footnote 5: The \\num macro should be applied to ")#mi("c_3 = 0.89379\\dots")#linebreak()#text(" – Footnote 16: “\\url{…}” -> “See \\url{…}.” [two things]")#linebreak()#text(" – Footnote 17: Remove colon after “at” and end with a full stop")#linebreak()#text(" – Footnote 27: Remove it and instead put it’s centents the parentheses in the text")#linebreak()#text(" – Equation (8.13) and two and three equations below this: “")#mi("geom")#text("” –> “")#mi("\\mathrm{geom}")#text("”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("“centents” –> “contents”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248801")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Section 4 comments (just the first 6 pages):")

#text("1. At the end of footnote 14 (given on page 39): the references can be grouped together if you want.")

#text("2. Second offset equation in the proof of Lemma 4.1: the two summands inside the curly braces are in reverse order. It should be ")#mi("(\\beta-o(1)\\log R - (\\alpha+o(1))\\log 3x")#text(".")

#text("3. Lemma 4.2.")

#text("3a. In the statement of the lemma, the second line of the first offset equation has the condition “")#mi("p>w")#text(" and ")#mi("j \\geq 1")#text(".” To make this match the corresponding restrictions on the next page for ")#mi("h")#text(", and to make the three cases be mutually disjoint, I recommend changing ")#mi("j\\geq 1")#text(" to j>1.")

#text("3b. In the next paragraph, when it says “this formula holds uniformly for any…” it might be helpful to the reader to add “in ")#mi("g")#text("” after “uniformly.”")

#text("3c. The next sentence starts “In particular,…” This currently reads as though the “in particular” statement follows from the sentence directly beforehand about uniformness. But I think the “in particular” statement just follows directly from (4.11). Maybe some sentences could be moved around to make this clearer.")

#text("3d. In the statement of the lemma, ")#mi("g")#text(" is assumed to be *fixed*. However, this is never explicitly assumed in the proof. If it is a necessary restriction it should probably be assumed in the first sentence of the proof, and then when that assumption is used it may be helpful to the reader to point it out.")

#text("Further, the sentence about the equation holding “uniformly for uniformly integrable families” leaves open the possibility that the family being used is *NOT* fixed (with respect to x). Indeed, I believe that this is forced, since the translates ")#mi("y\\mapsto g(y_0+y)")#text(" are not fixed, since ")#mi("y_0")#text(" depends on ")#mi("x")#text(".")

#text("Maybe a word of explanation on these points would be helpful?")

#text("3e. In the first offset equation in the proof of the lemma, I recommend changing ")#mi("\\int g(t)dt")#text(" to ")#mi("\\int_{0}^{\\infty} g(t)dt")#text(". [Add the integration index.]")

#text("3f. Next paragraph, change “We use prove the…” by removing “use”")

#text("3g. In the offset equation directly following the phrase “and in turn the inner sum transforms into…”, on the RHS, the parentheses are smaller than on the LHS.")

#text("3h. Two offset equations later, on the RHS there is a formula using curly braces, which are smaller than some of the parentheses used inside. I recommend using \\left\\{ … \\right\\}.")

#text("3i. In that same offset equation, in the little-o term, in the summation subscript, I recommend changing ")#mi("a\\leq R")#text(" just to ")#mi("a")#text(". [The restriction is unnecessary, and the change then matches what is done on the next line.]")

#text("3j. The end of the next sentence, which reads “… and so ")#tao-math("\\sum_{a\\neq 1}\\frac{\\left|h(a)\\right|}{a}=o(1)", block: false)#text(".” doesn’t seem to be necessary (but I may be missing something).")

#text("4. Fourth line of the proof of Proposition 4.3: change “are pairwise non-congruence modulo” but replacing “congruence” with “congruent”.")

#text("5. Last page of the proof of Proposition 4.3, starting at “Following Selberg…” through the end of the proof: I personally found the original argument, using a sum over the variable ")#mi("d=\\gcd(d_1,d_2)")#text(", followed by Mobius inversion, to be easier to follow. I’m not an expert on these things, so take that for what it’s worth. [By the way, I did find many of the other changes very helpful!]")

#text("6. Two offset equations after 4.18: I had a great deal of trouble trying to understand the claimed equality. Here is what I think needs to be done, but again maybe I’m missing something.")

#text("First, on the RHS on the inner sum, I believe that the third line of the subscript should be ")#mi("n=a-h_i\\ ([d_1,d_2])")#text(".")

#text("Second, even with this change I don’t believe that this is a true equality. For instance, if ")#mi("d_1=d_2=p")#text(" is prime, and ")#mi("n+h_i")#text(" is a power of ")#mi("p")#text(", then this should contribute a single term to the summation on the LHS (from ")#mi("[d_1,d_2]|P(n)")#text(") that is not accounted for on the RHS. This is easily fixed by adding ")#mi("O(1)")#text(" to the RHS. Perhaps a short word on this issue should be mentioned?")

#text("7. In equation (4.19), in the second line of the subscript of the inner sum, I believe you want ")#mi("n=b+h_i\\ (W)")#text(".")

#text("8. A few lines later, change “arihmetic” to “arithmetic”.")

#text("I hope these are helpful to you. The paper is looking very good from what I’ve seen.")

#text("Cheers,")#linebreak()#text(" Pace")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("I don’t want to interfere with Emmanuel’s editing, so I won’t edit in these corrections directly, but just wanted to comment on a few of them:")

#text("regarding point 3b, you are correct that for our application, g is not fixed, but instead lies in an fixed equicontinuous family of functions, namely the translates of a fixed function. I think we can address this by strengthening the “Moreover” claim of the lemma to something like “Moreover, this formula holds uniformly when g is not necessarily fixed, but instead varies within a fixed equicontinuous family of functions”. One would also need to slightly modify the first line of the proof of this lemma accordingly.")

#text("regarding point 3j, I think this estimate is needed to control the ")#mi("a \\neq 1")#text(" terms of ")#mi("\\sum_a \\frac{h(a)}{a} \\int_{\\log a/\\log R}^\\infty g(t)\\ dt")#text(" a few lines previously. (But perhaps this could be stated explicitly.)")

#text("Regarding point 6: you’re right that ")#mi("n = a\\ ([d_1,d_2])")#text(" should be ")#mi("n + h_i = a\\ ([d_1,d_2])")#text(", but I don’t see the problem with any missing terms here. The identity has nothing to do with the nature of ")#mi("\\Lambda")#text(", it is simply asserting that if n is an integer, then ")#mi("[d_1,d_2] | P(n)")#text(" holds if and only if there is an ")#mi("a \\in C_i([d_1,d_2])")#text(" such that ")#mi("n+h_i = a\\ ([d_1,d_2])")#text(", and furthermore this a is unique. Again, maybe one could state this more explicitly since it seems to be causing confusion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248811")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Thank you for the comments on 3b, and 3j.")

#text("On point 6, consider the polynomial ")#mi("P_i(X) :=\\prod_{j\\neq i}(X+h_j-h_i)")#text(". If we evaluate at ")#mi("X=n+h_i")#text(", then we have ")#mi("\\prod_{j\\neq i}(n+h_j)")#text(". This is nearly the same as ")#mi("P(n)")#text(", except we are missing a factor ")#mi("(n+h_i)")#text(". So, it appears that ")#mi("[d_1,d_2]")#text(" can divide ")#mi("P(n)")#text(" and not divide ")#mi("P_i(n+h_i)")#text(", in the case that ")#mi("[d_1,d_2]")#text(" has a common factor with ")#mi("(n+h_i)")#text(". [My earlier comment about the nature of ")#mi("\\Lambda")#text(" was only meant to point out that this trivial exception can actually contribute to the summation, for arbitrarily large ")#mi("x")#text(".] In particular, if ")#mi("d_1=d_2=p")#text(" is prime, and ")#mi("n+h_i")#text(" is (say) a power of ")#mi("p")#text(", then we have ")#mi("[d_1,d_2]|P(n)")#text(", but we don’t have that ")#mi("n=a-h_i\\ ([d_1,d_2])")#text(" for any ")#mi("a\\in C_i([d_1,d_2])")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Ah, I see now, thanks. Well caught! In any case we only need a lower bound here, so we can replace the = sign here by a ")#mi("\\geq")#text(" sign (and note that it is almost an equality), after modifying some of the later displays on this page accordingly.")

#emph[#text("[Edit: actually, a lower bound here is not enough, due to the presence of the Mobius function elsewhere in the calculation. So the O(1) fix (or more precisely, ")#mi("O( \\log x )")#text(") is probably the simplest.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248813")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("I was busy much of today, but I’ll put in the corrections tomorrow (as well as continue with Section 5, though maybe a bit slowly since I will be a bit busy with other things.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248864")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("Another option here is to replace ")#mi("P_i")#text(" with ")#mi("x\\cdot P_i")#text(", but I don’t know if that would have a big affect later.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248830")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("On 3e, it looks most natural to get ")#mi("\\int_0^\\varepsilon g(t) dt")#text(" in the first equation. But later it looks like we need ")#mi("\\infty")#text(". Am I missing something obvious here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248837")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("We apply this equation to estimate ")#mi("\\sum_{(d,W)=1} g(\\frac{\\log a}{\\log R} + \\frac{\\log d}{\\log R}) \\frac{1}{d}")#text(". As g is supported on [0,1], d goes ranges up to ")#mi("R^{1 - \\log a / \\log R}")#text(", but then we can extend the range of integration on g up to infinity, again because of the support.")

#text("But actually, now that I think about it, we could alternatively remove the restriction ")#mi("d \\leq R^\\varepsilon")#text(" from the first display (and have the integration range from 0 to infinity); but we also need to add a hypothesis that the support of ")#mi("g")#text(" is bounded uniformly in x (in addition to equicontinuity).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248855")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("I just heard from Fouvry that Maynard announced his gap of 700 obtained using only Bombieri-Vinogradov this morning in Oberwolfach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248857")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("Do you know if the 700 bound is coming from a triple of primes inside an admissible k-tuple (and if so, what value of k he is using?). Even without knowing any details of his proof, if we know the parameters we might be able to sharpen his result by enumerating all the admissible k-tuples (at this point I have provably complete lists for all k’s with H(k) up to about 2000).")#linebreak()#text(" I note that there is no k for which H(k) is exactly 700 or 1400, so I’d be curious to know where the 700 is coming from.")

#text("Sharpening his result (even trivially) might give him an incentive to join forces with us :).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("Or maybe 700 is just 1/100,000 of 70,000,000. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248865")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("I have no other information at the moment, but I am sure that a preprint should be available quite soon.")

#text("It certainly answers the question that I had added at the end of Section 2, of whether requiring exponent of distribution >1/2 (in one way or another) was somehow necessary to get bounded gaps!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248898")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("János Pintz (who is in Oberwolfach at the moment) told me that Maynard can take ")#mi("k=110")#text(" and this leads to ")#mi("H=700")#text(". I understand you have a better ")#mi("H")#text(" for this ")#mi("k")#text(". Valentin Blomer (who is also in Oberwolfach at the moment) told me that there is hope that any weak Bombieri-Vinogradov ")#mi("\\theta>0")#text(" leads to bounded gaps between primes. All this is very exciting indeed. It is always a good sign when a proof simplifies and the result becomes stronger simultaneously.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248907")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("Yes, H = 628 when k = 110, and this is optimal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248926")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("David, where is the figure coming from? ")#link("http://math.mit.edu/~drew/ktuple/primegap.html")[#text("http://math.mit.edu/~drew/ktuple/primegap.html")]#text(" reports 684.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248927")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("The link you give is to a *test* version of the admissible tuples database (as indicated in the bold note at the top of the page, it was intentionally populated with sub-optimal tuples so that it would be easy for people to submit improvements). The correct link for the admissible tuples database is:")

#link("http://math.mit.edu/~primegaps/")[#text("http://math.mit.edu/~primegaps/")]

#text("which lists the H(110)=628 value that David Roberts noted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248931")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("Ah, I have been looking at the wrong link for a while, then! Sorry for the confusion, and thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248950")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("I went ahead and changed the test URL to")

#link("http://math.mit.edu/~drew/ktuple/primegaptest.html")[#text("http://math.mit.edu/~drew/ktuple/primegaptest.html")]

#text("just to avoid the possibility of anyone else being similarly confused.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("Yes, I believe by using the sieve with a multidimensional cutoff, one can deduce bounded gaps from any ")#mi("\\theta > 0")#text("; similarly, for any fixed ")#mi("\\theta > 0")#text(", one should be able to get bounded gaps with any number of primes in it (not just 2). I’ve talked to Maynard a bit about this and have made some supporting calculations, but as Maynard has priority, it is probably not appropriate to discuss them in detail until after he has a preprint (or if he decides to join our efforts). [In any case, we have a paper to finish!]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248934")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("If the limit ")#mi("H=12")#text(" is implied by using three primes, perhaps it may be reduced (hopefully even to 2) by using more primes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248952")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("@ Eytan,")

#text("From what I understand (without having seen Maynard’s work) is that the limit ")#mi("H=12")#text(" comes from the multi-dimensionality of the analysis (perhaps optimizations of a 5-dimensional sieve?). To get ")#mi("H=2")#text(", one would need to work with ")#mi("k_0=2")#text(", and in that case the dimension of the sieve would just be 2. In that case, using “more primes” would be of no use.")

#text("However, I may be shown to be quite off here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248956")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("I agree that (by using the new method) the limit of H seems to be ")#mi("> 2")#text(", but it still may be ")#mi("< 12")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248941")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("Dear Terry, I agree with you. I only shared information that I learned (through Pintz and Blomer) from public sources (namely a lecture in Oberwolfach). I hope that PolyMath8 will continue, and the sequel will be equally exciting. If Emmanuel and others have finished updating the paper, I will try to go through it quickly. It does not make sense to me to do this while the paper is constantly changing, and I also got busy with another project.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248949")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("I was busy the last two days (I will give a lecture tomorrow concerning conductors of linear transforms of trace functions) but I will continue reading the paper carefully, probably finishing Section 5 by Saturday.")

#text("I then hope that the next sections will go a bit faster, but in any case Sections 1 to 4 can be re-read now I believe (one should probably update the proof of Lemma 4.2 at some point, since it is rather condensed at the moment). I will move the ek-subfolder version of Section 4 to the main folder tomorrow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16171a179a58e41af4e2f4d6ddf644ee9ba89aabe8694dec0f0cde2995f7c2e8-2bb005f08470bbc7ee43caff841690e641eb82dce11238b1df2351f67804217c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siavash Teh")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249229")[#strong[#text("Siavash Teh")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Small question: having more than 2 primes in bounded gap is by assuming E.H or you can get for example 3 primes in a bounded gap just using B.V?")#linebreak()#text(" Thanks")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-248969")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")])]

#text("A few typos:")#linebreak()#text(" 1. On p 30, 4 lines above Remark 3.2, “In practive” should be “In practice”.")#linebreak()#text(" 2. p 43, first line of Proof of Prop 4.3, (4.8) should be (4.7).")#linebreak()#text(" 3. p 49, 2 lines above Proof of Th 2.6, ")#mi("a_1n_1+...")#text(" should be ")#mi("a_1n+...")#text(".")#linebreak()#text(" 4. p 51, Proof of Th 2.12. “Theorem 2.6” and “Theorem 2.12” need to be reversed.")#linebreak()#text(" 5. p 54, display in Proof of Lemma 4.11, p is missing after log?")#linebreak()#text(" 6. p 67, last sentence of 3rd paragraph, “4.54” is missing parentheses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249112")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2013")])]

#text("I got a cold on Thursday so I only finished going through heathbrown.tex today (and I didn’t yet review the corrections to gpy.tex suggested above — I will do it tomorrow).")

#text("Someone pointed out that the definition of discrepancy in Section 2 was not quite the usual one (used by BFFI and then by Zhang), because the condition (n,q)=1 was omitted in the “main term”. I think this was a typo (since other sections use the standard definition), and I corrected it. I’ll make sure as I continue reading that we use the notation consistently.")

#text("Apart from that, I only corrected typos and changed wording in minor ways (the proof of Lemma 5.1 is maybe very slightly simpler), and added a second reference for Siegel-Walfisz for the Möbius function, since I think that the paper of Siebert is probably impossible to find.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249487")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("Dear Emmanuel, I am a bit confused that the official newgap.pdf and the one in your folder differ by 10 pages. Are these merged regularly? Which one should I read? I plan to read Sections 1 to 4 soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249538")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("I haven’t yet merged Sections 4, 5, 6 into the main folder, which explains the difference in page numbers (especially section 4 is longer). I will merge them soon.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249129")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2013")])]

#text("I’ve made some minor edits to the abstract and introduction, to emphasise more the distribution theorem on primes in arithmetic progressions we have that improves upon Zhang’s theorem (and also does not necessarily rely on Deligne’s work), given that this is the portion of our work which is not directly superseded by Maynard’s newest results. (I also made a small mention of Maynard’s work in the intro in a footnote. We should probably revisit the question of how to refer to his work, and/or to any future paper by us, when the paper is closer to being done. James tells me that he may have a preprint on his work ready within a week or two, so in particular we would be able to directly refer to his paper by the time we’re done with the proofreading.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249169")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2013")])]

#text("I have also been thinking about the best way to present the paper once Maynard’s work is public and fully checked. Indeed an essential contribution of Polymath8 is, in my mind, the new results on the distribution of primes in arithmetic progressions to large moduli (i.e., beyond the Riemann Hypothesis). I think that the new variants of the exponent of distribution (with densely divisible moduli) that we define, where one can significantly beyond the 1/2 bound, are certainly going to be useful in other applications. I also think that (building on Zhang’s work) we bring a potentially critical new insight to this question: the importance and potential of relying on Deligne’s work in its strongest forms. In some sense, this replaces the spectral theory of automorphic forms, and happens to bring extra flexibility.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249172")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2013")])]

#text("I have finished editing Section 3. The only significant changes I made were to section 3.1 where I fixed some errors in the the fast admissibility test and tried to improve the clarity of the description.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249271")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("I started reviewing exponential.tex and I am almost done (only the last corollary remains).")

#text("My version has relatively big changes in some technical aspects of the presentation (no important corrections).")

#text("(1) Instead of formal quotients, I use simply the extension of e_q to the projective line over Z/qZ. I think this fits better with the Deligne material (where this extension for finite fields is natural). In practice it makes almost no difference of course, but this means we can’t write e_q(0/0)…")

#text("Lemma 6.5 is changed a bit. Unless I misunderstood the intent of the formal quotients, there was a minor mistake as stated: if f=1/(qX²), then (f,q)=1, but (f’,q), as defined, is large since no cancellation between numerator and denominator seems to be intended in the formal quotient of polynomials. Indeed, the proof used an assumption that the denominator of f is monic, which did not appear in the statement.")

#text("I’ve adapted the lemma to my setting, and added a second part which was used implicitly: if (q,f)=1 and deg(P)<deg(Q), then then (q,f')=1 (adding the assumption that the degree of Q doesn't change by reduction modulo primes dividing q; this is automatic if Q is monic, which is the most likely case in applications, but it can be convenient to have this slight generalization).")

#text("(2) Because the results of this section are very general and I think it might be used by other people as a kind of nice summary and reference, I made it independent of the asymptotic convention of having a single variable x tending to infinity (and moduli q of polynomial size with respect to x, etc). This requires a bit more notation and care with q^{eps}'s and similar small quantities, but it seems worth it. (Similarly, the Deligne section is/will be independent of the asymptotic conventions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249275")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Ah, this is a nice way to deal with the division-by-zero issue! Some minor comments on this section:")

#text("* should the title of the section be “One-dimensional exponential sums” rather than “One-dimensional exponential sum”? Also, we should probably give a reason why we are suspending the asymptotic notation (namely, to produce bounds which are more portable for future applications).")

#text("* It was pointed out to me by Andrew Granville that the assertion after (6.4) that (6.3), (6.4) are basically the only 1D complete exponential sum bounds we need is not quite true; due to the van der Corput process, we also need to control sums of the form ")#mi("\\sum_x e_p( ax + \\frac{b}{x} + \\frac{c}{x+l} + \\frac{d}{x+m} + \\frac{e}{x+l+m} )")#text(".")

#text("* We could put absolute values on the LHS of (6.7)-(6.9) for emphasis (although it is, strictly speaking, unnecessary). Similarly for the display in the proof of Lemma 6.8.")

#text("* in the display after (6.11) defining the inner product, one could use := instead of =.")

#text("* The hypothesis that d_1,d_2 be coprime in Lemma 6.8 should probably be dropped.")

#text("* Remark 6.10: “prohibitive restriction” should be “a prohibitive restriction”. Also, I am not sure what uniformity of estimates means in this context – what parameter is one considering uniformity with respect to?")

#text("* Remark 6.13 is still written with the asymptotic notation of the paper in force (i.e. using \\lessapprox instead of \\ll q^\\eps). Similarly for the final corollary (but I guess you are still working on that).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249280")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Thanks for the remarks and corrections!")#linebreak()#text(" Remark 6.10 is indeed unclear (I re-read the original version and I realize that I probably did not capture the meaning while trying to expand the remark). What I mean by “uniformity” is that the estimates are fully explicit and often give at least some decay of incomplete sums, independently of any special features of the rational function f (in the case of e_q(f(n))) with the exception of the numerator and denominator (so it is uniform with respect to the summand in wide classes). I have in mind that (as indeed with estimates for primes in arithmetic progressions) it is not so much the extent of the gain compared with the trivial bound that may be relevant for applications, but rather the fact that a relatively weak decay is valid uniformly.")

#text("I will finish Remark 6.13 and the corollary and make the changes (though maybe only tomorrow morning…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249288")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("I did finish a first draft this evening…")

#text("One thing I noticed is that the current 1-van der Corput estimate is written for N<q_1, but Lemma 6.14 uses the more general version. I'll adapt the vdC estimate tomorrow.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249311")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Something I missed earlier. In Eq. (4.14), on the RHS, in the main term, I believe ")#mi("x/W")#text(" is missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("Andrew Granville has released a first draft of his “Current Events” article for the Bulletin of the AMS on “Bounded gaps between primes” at ")#link("http://www.dms.umontreal.ca/~andrew/CurrentEventsArticle.pdf")[#text("http://www.dms.umontreal.ca/~andrew/CurrentEventsArticle.pdf")]#text(" . Among other things, he traces out the “minimal” route to bounded gaps from our Polymath draft paper (avoiding Deligne, dense divisibility, or really narrow admissible tuples). (Of course, with the upcoming Maynard preprint, there will likely be a much shorter route to just bounded gaps between primes, but this route also establishes a distribution theorem for primes in arithmetic progressions that goes beyond Bombieri-Vinogradov and should be useful in other contexts.)")

#text("Anyway, I am sure he would be interested in any feedback on the article.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249477")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("I read through the article very quickly, just to get a feeling for the techniques and ideas. I thought the statement on Zhang was very nice. I also liked how each of the arguments was worked out explicitly. The first few sections were an easy read for non-experts.")

#text("There were two things I ran into that were a bit confusing to me–probably typo related. On page 30, one of the corollaries has “")#mi("B=B(A)>0")#text("” which I couldn’t see used anywhere. Also, on page 34, there is a place which says “…with ")#mi("r\\leq N/x^{\\epsilon}")#text(". Evidently, ")#mi("r>N/x^{\\epsilon}>x^{1/4}")#text("…” This sudden reversal of inequalities was confusing.")

#text("Finally, there was one question I had for the experts. One aspect of this work I’ve been working the hardest to figure out is the sieve portion of the argument. In Granville’s paper, he takes the weights ")#mi("\\nu")#text(" slightly differently than is done in the polymath paper. Am I correct in gathering that his choice, while sufficient, is not as optimized as the polymath choice? How much affect do these differences incur?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249486")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("We should make sure that these comments reach Andrew. If he does not confirm here that he is following this blog, then email seems to be the best way of communication.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249631")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("The $B(A)$ was a legacy from an earlier version (so irrelevant to this version and now deleted).")

#text("It should have been $r>N/(yx^{\\epsilon})>x^{1/4}$; ie a $y$ was inadvertently missed.")

#text("In my choice of weights I was not trying to optimize, just to find the simplest route to getting the result")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249796")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2013")])]

#text("I made a mistake in Footnote 10, suggesting that the proposed strengthening of Conjecture 5.3 in [BFI] is wrong, when in fact it is still open. Friedlander had told me this a few weeks ago, but I neglected to edit it right away, and forgot!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249536")[#strong[#text("Prime gaps update | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")]

#text("[…] One of the many very long comment threads on Terry Tao’s blog discussing the Polymath8 paper. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249547")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("Hi,")

#text("This is Andrew. I have just been made aware that I should look for comments here — thanks very very much! And thanks for your preprint that made my task easy!")#linebreak()#text(" Andrew")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249624")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("I just merged my changes (up to exponential.tex) to the main folder, after reviewing the last changes to intro.tex and subtheorems.tex.")

#text("I plan to go through as much of typei-ii.tex as possible over the week-end (I didn’t have much time this week).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249652")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("There was a small editing conflict in the first part of the introduction. I tried to make our edits compatible, but feel free to undo (I promise I won’t touch Section 1 anymore). Essentially I just moved the reference to Bombieri’s proof of the Weil conjectures to the point where you mentioned Stepanov: as far as I understand it, Bombieri’s proof is a natural reinterpretation/generalization of Stepanov’s proof, which was restricted to hyperelliptic curves? I also changed the precise reference (we referred to the wrong article, I think).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249630")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("In the proof of claim (ii) of lemma 4.10, it should be ")#mi("t+t^{\\prime} \\geq 1")#text(" (instead of ")#mi("t+t^{\\prime} > 1")#text(") since ")#mi("f(1) = 0")#text(" (and also ")#mi("\\log f(t)")#text(" is not defined for ")#mi("t = 1")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249633")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("In the proof of claim (i) of lemma 4.10, the integral on the RHS is a function of ")#mi("x")#text(" while the LHS is a function of t.")

#text("Later in the proof, a “from” should be deleted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249635")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("In theorem 2.16, there is a typo in the definition of ")#mi("\\xi")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249639")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("In remark 2.18, “the above table” should be replaced by “table 4” (now located below remark 2.18)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249654")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("Thanks, I fixed these errors in Section 2, which I’m currently re-reading (didn’t touch Section 4 yet).")

#text("I also have a consistency question: we sometimes attribute the prime tuples conjecture to Hardy-Littlewoord, and sometimes to Dickson-Hardy-Littlewood. Maybe we should uniformize this? Which one is more standard?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249656")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("I believe the statement “for all positive integers k, DHL[k,k] holds” is precisely the intersection of Dickson’s conjecture (1904) and the first Hardy-Littlewood conjecture (1928), both of which are more general (Dickson treats arbitrary linear forms, Hardy-Littlewood gives a precise asymptotic, not just an infinite set).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("I found that the ek copy of biblio.tex was not synchronised with the main copy, so I syncronised it by hand; also I added a reference to Granville’s new survey at the end of Sec 2 (and commented out the speculation as to whether one can proceed just with Bombieri-Vinogradov, as the question seemsto have been answered by Maynard.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249679")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("Indeed, I forgot to copy the biblio.tex file this morning.")

#text("Certainly the question about Bombieri-Vinogradov has been resoundingly answered (and once his preprint is out, it will probably suggest some other changes to the introduction.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/comment-page-1/#comment-249805")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2013")])]

#text("In Chapter 11, line 20 on the first page, “modulo translation” is repeated at the beginning and end of the sentence.")
]
