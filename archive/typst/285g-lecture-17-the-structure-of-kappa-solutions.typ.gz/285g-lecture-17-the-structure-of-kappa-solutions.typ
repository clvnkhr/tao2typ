// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/
// Converted to Typst by tao2typ: "2026-10-14T16:35:20.883219+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 17: The structure of κ-solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 17: The structure of κ-solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")[#text("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Having classified all asymptotic gradient shrinking solitons in three and fewer dimensions in the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(", we now use this classification, combined with extensive use of compactness and contradiction arguments, as well as the comparison geometry of complete Riemannian manifolds of non-negative curvature, to understand the structure of ")#mi("\\kappa")#text("-solutions in these dimensions, with the aim being to state and prove precise versions of Theorem 1 and Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("Lecture 12")]#text(".")

#text("The arguments are particularly simple when the asymptotic gradient shrinking soliton is compact; in this case, the rounding theorems of Hamilton show that the ")#mi("\\kappa")#text("-solution is a (time-shifted) round shrinking spherical space form. This already classifies ")#mi("\\kappa")#text("-solutions completely in two dimensions; the only remaining case is the three-dimensional case when the asymptotic gradient soliton is a round shrinking cylinder (or a quotient thereof by an involution). To proceed further, one has to show that the ")#mi("\\kappa")#text("-solution exhibits significant amounts of curvature, and in particular that one does not have bounded normalised curvature at infinity. This curvature (combined with comparison geometry tools such as the Bishop-Gromov inequality) will cause asymptotic volume collapse of the ")#mi("\\kappa")#text("-solution at infinity. These facts lead to the fundamental ")#emph[#text("Perelman compactness theorem")]#text(" for ")#mi("\\kappa")#text("-solutions, which then provides enough geometric control on such solutions that one can establish the structural theorems mentioned earlier.")

#text("The treatment here is a (slightly simplified) version of the arguments in ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(", which is based in turn on ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(" and the notes of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(" (see also the paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=2233789")[#text("Cao-Zhu")]#text(" for a slightly different treatment of this theory).")

#metadata(none) <tao-326c8266efe5eb82d238>

#heading(level: 1)[#text("— The compact soliton case —")]

#text("As we saw in ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(", every ")#mi("\\kappa")#text("-solution ")#mi("t \\mapsto (M,g(t))")#text(" has at least one asymptotic gradient shrinking soliton ")#mi("t \\mapsto (M_\\infty,g_\\infty(t))")#text(" associated to it. Suppose we are in the case in which at least one of these asymptotic gradient shrinking solitons is compact; by Theorem 1 of ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 16")]#text(", this means that this soliton is a round shrinking spherical space form. Since this soliton is the geometric limit of a rescaled sequence of M, this implies that M is homeomorphic to ")#mi("M_\\infty")#text(" and, along a sequence of times ")#mi("t_n \\to \\infty")#text(", converges geometrically after rescaling to a round spherical space form. Thus M is asymptotically round as ")#mi("t \\to -\\infty")#text(".")

#text("One can now apply Hamilton’s rounding theorems in ")#link("http://www.ams.org/mathscinet-getitem?mr=954419")[#text("two")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("three")]#text(" dimensions to conclude that M is in fact perfectly round. In the case of two dimensions this can be done by a variety of methods; let me sketch one way, using Perelman entropy; this is not the most elementary way to proceed but allows us to quickly utilise a lot of the theory we have built up. First we can lift M up to be ")#mi("S^2")#text(" instead of the quotient ")#mi("\\Bbb{RP}^2")#text(". Then we observe from the Gauss-Bonnet theorem (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(") that ")#mi("\\int_M R\\ d\\mu = 4\\pi")#text(", and hence by the volume variation formula (equation (33) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") the volume ")#mi("\\int_M\\ d\\mu")#text(" is decreasing in time at a constant rate ")#mi("-4\\pi")#text(". Let us shift time so that the volume is in fact equal to ")#mi("4 \\pi \\tau")#text(", and consider the Perelman entropy ")#mi("\\mu( M, g(t), \\tau)")#text(" defined in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(". Testing this entropy with ")#mi("f := 0")#text(") we obtain an upper bound ")#mi("\\mu( M, g(t), \\tau) \\leq -4\\pi")#text(". On the other hand, on the sequence of times ")#mi("t_n \\to -\\infty")#text(", ")#mi("(M,g(t))")#text(" is smoothly approaching a round sphere, on which the entropy can be shown to be ")#emph[#text("exactly")]#text(" ")#mi("-4\\pi")#text(" by the log-Sobolev inequality for the sphere (which can be proven in a similar way to the log-Sobolev inequality for Euclidean space in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text("). Thus one can soon show that ")#mi("\\mu( M, g(t_n), \\tau_n) \\to -4\\pi")#text(". On the other hand, this entropy is non-increasing in ")#mi("\\tau")#text("; thus ")#mi("\\mu(M,g(t),\\tau)")#text(" is constant. Applying the results from ")#link("https://terrytao.wordpress.com/2008/05/21/285g-lecture-14-stationary-points-of-perelman-entropy-or-reduced-volume-are-gradient-shrinking-solitons/")[#text("Lecture 14")]#text(" we conclude that this time-shifted manifold M is itself a gradient shrinking soliton, and thus is round by the results of ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(".")

#strong[#text("Exercise 1.")]#text(" In this exercise we give an alternate way to establish the roundness of M in two dimensions, using a slightly different notion of “entropy”. Firstly, observe that under conformal change of metric ")#mi("g = ah")#text(" on a surface, one has ")#mi("d\\mu_g = a d\\mu_h")#text(", ")#mi("\\Delta_g = \\frac{1}{a} \\Delta_h")#text(", and ")#mi("R_g = \\frac{1}{a} ( R_h - \\Delta_h \\log a )")#text(". If we then express ")#mi("g = ah")#text(" where h is the metric on ")#mi("S^2")#text(" of constant curvature +1, show that the Ricci flow equation becomes ")#mi("\\partial_t a = \\Delta \\log a - 1")#text(", and in particular that the volume ")#mi("\\int_M a\\ d\\mu_h")#text(" is decreasing at constant rate ")#mi("4\\pi")#text(". If we time shift so that ")#mi("\\int_M a\\ d\\mu_h = 4\\pi \\tau")#text(", show that the ")#link("http://en.wikipedia.org/wiki/Relative_entropy")[#text("relative entropy")]#emph[#text(" ")]#mi("\\int_M \\frac{a}{\\tau} \\log \\frac{a}{\\tau}\\ d\\mu_h")#text(" is non-decreasing in ")#mi("\\tau")#text(", and converges to 0 along ")#mi("\\tau_n")#text(" (here one needs a stability result for the uniformisation theorem). From this and the converse to ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(", conclude that a is constant at every time, which gives the rounding. (For more proofs of the rounding theorem, for instance using the ")#emph[#text("Hamilton entropy")]#text(" ")#mi("\\int_M R \\log R\\ d\\mu")#text(", see the ")#link("http://www.ams.org/mathscinet-getitem?mr=2061425")[#text("book of Chow and Knopf")]#text(".) ")#mi("\\diamond")

#text("In two dimensions, we saw in the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(" that the only gradient shrinking soliton was the round shrinking sphere. We have thus shown the following classification of ")#mi("\\kappa")#text("-solutions in two dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("The only two-dimensional ")#mi("\\kappa")#text("-solutions are time translates of the round shrinking ")#mi("S^2")#text(" and ")#mi("\\Bbb{RP}^2")#text(".")
]

#text("For three dimensions, we can argue as in Case 4 of the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(". Write ")#mi("\\lambda \\geq \\mu \\geq \\nu")#text(" for the eigenvalues of the curvature tensor. At the times ")#mi("t_n")#text(", we have ")#mi("(\\mu + \\nu)/\\lambda \\geq 2-\\delta_n")#text(" for some ")#mi("\\delta_n \\to 0")#text(". Applying the tensor maximum principle (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(") and the analysis from Case 4 of the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(", we thus see that ")#mi("(\\mu + \\nu)/\\lambda \\geq 2-\\delta_n")#text(" for all times ")#mi("t \\geq t_n")#text("; sending n to infinity we conclude that ")#mi("(\\mu + \\nu)/\\lambda \\geq 2")#text(" for all times, and so curvature is conformal. Using the ")#link("http://en.wikipedia.org/wiki/Bianchi_identity#Bianchi_identities")[#text("Bianchi identity")]#text(" as in Case 4 of the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(", we conclude that the manifold is round.")

#heading(level: 1)[#text("— The case of a vanishing curvature —")]

#text("Now we deal with the case in which there is a vanishing curvature:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("Let ")#mi("t \\mapsto (M,g(t))")#text(" be a 3-dimensional ")#mi("\\kappa")#text("-solution for which the Ricci curvature has a null eigenvector at some point in spacetime. Then M is a time-shifted round shrinking cylinder, or the oriented or unoriented quotient of that cylinder by an involution.")
]

#strong[#text("Proof.")]#text(" If the Ricci curvature vanishes at any point, then by Hamilton’s splitting theorem (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") the flow splits (locally, at least) as a line and a two-dimensional flow. Passing to a double cover if necessary, we see that the flow is the product of a two-dimensional Ricci flow and either a line or a circle. The two-dimensional flow is itself a ")#mi("\\kappa")#text("-solution and is thus a round shrinking ")#mi("S^2")#text(" or ")#mi("{\\Bbb RP}^2")#text(". Checking all the cases and eliminating those which are not ")#mi("\\kappa")#text("-noncollapsed we obtain the claim. ")#mi("\\Box")

#heading(level: 1)[#text("— Asymptotic volume collapse —")]

#text("Our next structural result on ")#mi("\\kappa")#text("-solutions is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text("(Asymptotic collapse of Bishop-Gromov reduced volume) Let ")#mi("(M,g(t))")#text(" be a ")#mi("\\kappa")#text("-solution of dimension 3. Then for any time t and ")#mi("r \\in M")#text(", ")#mi("\\lim_{r \\to \\infty} \\text{Vol}(B_{g(t)}(p,r))/r^3 \\to 0")#text(".")
]

#strong[#text("Proof.")]#text(" We first observe, by inspecting all the possibilities from Theorem 1 of ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 16")]#text(", that the claim is already true of all 3-dimensional asymptotic gradient shrinking solitons. We apply this to a gradient shrinking soliton for M and conclude that for any ")#mi("\\varepsilon > 0")#text(" there exists arbitrarily negative times ")#mi("t_n")#text(", points ")#mi("x_n")#text(" and radii ")#mi("r_n")#text(" such that ")#mi("B_{g(t_n)}(x_n,r_n)/r_n^3 \\leq \\varepsilon")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Bishop%E2%80%93Gromov_inequality")[#text("Bishop-Gromov comparison inequality")]#text(" (Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text(") we conclude that ")#mi("\\lim_{r \\to \\infty} B_{g(t_n)}(x_n,r)/r^3 \\leq \\varepsilon")#text(". By the triangle inequality this implies that ")#mi("\\lim_{r \\to \\infty} B_{g(t_n)}(p,r)/r^3 \\leq \\varepsilon")#text(".")

#text("Now we need to move from time ")#mi("t_n")#text(" to time t; since ")#mi("t_n")#text(" is arbitrarily negative we can assume ")#mi("t \\geq t_n")#text(". Recall from Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(" and the bounded curvature hypothesis that ")#mi("\\int_\\gamma \\text{Ric}(X,X)")#text(" is bounded for all times and all geodesics ")#mi("\\gamma")#text(". Plugging this into the Ricci flow equation, we see that ")#mi("\\frac{d}{dt} d_{g(t)}(x,y)")#text(" is also bounded (in the sense of forward difference quotients) for all times and all geodesics. In particular we have the additive distance fluctuation estimate ")#tao-math("d_{g(t)}(p,x) = d_{g(t_n)}(p,x) + O( \\left|t_n-t\\right| )", block: false)#text(", where the error is bounded even as ")#mi("d_{g(t_n)}(p,x)")#text(" or ")#mi("d_{g(t)}(p,x)")#text(" goes to infinity. Also, from equation (33) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow")[#text("Lecture 1")]#text(" we know that the volume measure ")#mi("d\\mu")#text(" is decreasing over time. From this we conclude that ")#mi("\\lim_{r \\to \\infty} B_{g(t)}(p,r)/r^3 \\leq \\varepsilon")#text(". Since ")#mi("\\varepsilon")#text(" is arbitrary, the claim follows. ")#mi("\\Box")

#text("We have a corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("Let ")#mi("(M,g(t))")#text(" be a non-compact ")#mi("\\kappa")#text("-solution of dimension 3. Then for any time t and point ")#mi("p \\in M")#text(" we have ")#mi("\\limsup_{x \\to \\infty} R(x) d(p,x)^2 = +\\infty")#text(". (Of course, the claim is vacuous for compact solutions.)")
]

#strong[#text("Proof. ")]#text(" By time shifting we may take t=0. Suppose for contradiction that ")#mi("\\limsup_{x \\to \\infty} R(x) d(p,x)^2")#text(" is finite, thus ")#mi("R(x) = O( 1 / d(p,x)^2 )")#text(" at time t=0, and thus at all previous times since ")#mi("\\partial_t R \\geq 0")#text(" (equation (29) of ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text("). From the non-negativity of the curvature we obtain the similar upper bounds on the Riemann curvature. From the ")#mi("\\kappa")#text("-noncollapsed nature of M we may thus conclude that ")#mi("\\text{Vol} B( x, c d(p,x) ) / d(p,x)^3")#text(" is bounded away from zero for some small c > 0. But this contradicts Proposition 3. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" In other treatments of this argument (e.g. in ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text("), Corollary 1 is established first (using the Topogonov theory from ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 16")]#text(") and then used to derive Proposition 3. The two approaches are essentially just permutations of each other, but the arguments above seem to be slightly simpler (in particular, the theory of the Tits cone is avoided). ")#mi("\\diamond")

#text("By combining Proposition 3 with another compactness argument, we obtain an important relationship:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2. ")]#text("(Volume noncollapsing implies curvature bound) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a 3-dimensional ")#mi("\\kappa")#text("-solution, and let ")#mi("B(x_0,r)")#text(" be a ball at time zero with volume at least ")#mi("\\nu r^3")#text(". Then for every ")#mi("A > 0")#text(" we have a bound ")#mi("R(x) = O_{\\kappa,\\nu,A}(r^{-2})")#text(" for all x in ")#mi("B(x_0,Ar)")#text(".")
]

#text("This result can be viewed as a converse to the ")#mi("\\kappa")#text("-noncollapsing property (bounded curvature implies volume noncollapsing). A key point here is that the bound depends only on ")#mi("\\kappa,\\nu,A")#text(" and not on the ")#mi("\\kappa")#text("-solution itself; this uniformity will be a crucial ingredient in the Perelman compactness theorem below.")

#strong[#text("Proof. ")]#text("Since ")#mi("B(x_0,r)")#text(" is contained in ")#mi("B(x,(A+1)r)")#text(", it suffices to establish the claim when ")#mi("x=x_0")#text(". By replacing r with Ar if necessary we may normalise A=1; we may also rescale ")#mi("R(x_0)=1")#text(". Suppose the claim failed, then there exists a sequence of pointed ")#mi("\\kappa")#text("-solutions ")#mi("t \\mapsto (M_n,g_n(t),x_n)")#text(" with ")#mi("R_n(0,x_n) = 1")#text(" and balls ")#mi("B_{g_n(0)}(x_n,r_n)")#text(" with ")#mi("r_n \\to \\infty")#text(" whose volume is bounded below by ")#mi("\\nu r_n^3")#text(" for some ")#mi("\\nu > 0")#text(". Using the point picking argument (Exercise 1 from Lecture 16) we can also ensure that for each r, we have ")#mi("R_n(0,x) \\leq 4")#text(" on ")#mi("B_{g_n(0)}(0,r)")#text(" if n is sufficiently large depending on r. Using the monotonicity ")#mi("\\partial_t R \\geq 0")#text(" and Hamilton’s compactness theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/06/02/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(") we may may thus pass to a subsequence and assume that the flows ")#mi("t \\mapsto (M_n, g_n(t), x_n)")#text(" converge geometrically to a limit ")#mi("t \\mapsto (M_\\infty, g_\\infty(t), x_\\infty)")#text(", which one easily verifies to be a ")#mi("\\kappa")#text("-solution whose asymptotic volume at time zero is bounded below by ")#mi("\\nu")#text(". But this contradicts Proposition 3. ")#mi("\\Box")

#heading(level: 1)[#text("— The Perelman compactness theorem —")]

#text("Corollary 2 leads to another important bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" (Bounded curvature at bounded distance). Let ")#mi("\\kappa > 0")#text(", and let ")#mi("t \\mapsto (M, g(t))")#text(" be a three-dimensional ")#mi("\\kappa")#text("-solution. Then at time zero, for every ")#mi("x_0 \\in M")#text(" and ")#mi("A > 0")#text(" we have ")#mi("R(x) = O_{\\kappa, A}( R(x_0) )")#text(" on ")#mi("B(x_0, A R(x_0)^{-1/2} )")#text(".")
]

#strong[#text("Proof.")]#text(" If the claim failed, then there will be an ")#mi("A > 0")#text(" sequence ")#mi("t \\mapsto (M_n,g_n(t),x_n)")#text(" of pointed ")#mi("\\kappa")#text("-solutions and ")#mi("y_n \\in B_{g_n(0)}(x_n, R_n(x_n)^{-1/2})")#text(" and ")#mi("R_n(y_n)/R_n(x_n) \\to \\infty")#text(". Applying Corollary 2 in the contrapositive we conclude that ")#mi("\\text{Vol}_{g_n(0)}( B_{g_n(0)}( x_n, R_n(x_n)^{-1/2} ) / R_n(x_n)^{-3/2} = o(1)")#text(". By the Bishop-Gromov inequality, we can thus find a radius ")#mi("r_n = o( R_n(x_n)^{-1/2} )")#text(" such that ")#mi("\\text{Vol}_{g_n(0)}( B_{g_n(0)}( x_n, r_n )/r_n^3 = \\omega_3/2")#text(" (say), where ")#mi("\\omega_3 := \\frac{4}{3} \\pi")#text(" is the volume of the Euclidean 3-ball. By rescaling we may normalise ")#mi("r_n=1")#text(", thus ")#mi("R_n(x_n)=o(1)")#text(". By Corollary 2 we now have ")#mi("R_n(x) = O_{\\kappa,A}(1)")#text(" on ")#mi("B_{g_n(0)}(x_n,A)")#text(" for every ")#mi("A > 0")#text(". We may thus use monotonicity ")#mi("\\partial_t R_n \\geq 0")#text(" and Hamilton compactness as before to extract a limiting solution ")#mi("t \\mapsto (M_\\infty, g_\\infty(t), x_\\infty)")#text(" with ")#mi("R_\\infty(0,x_\\infty)=0")#text(" and with ")#mi("B_{g_\\infty(0)}(x_\\infty,1) = \\omega_3/2")#text(". But then by the strong maximum principle (see Exercise 7 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text("), ")#mi("M_\\infty")#text(" must be flat; since it is ")#mi("\\kappa")#text("-non-collapsed, it must be ")#mi("{\\Bbb R}^3")#text(". But then we have ")#mi("B_{g_\\infty(0)}(x_\\infty,1) = \\omega_3")#text(", a contradiction. ")#mi("\\Box")

#strong[#text("Exercise 2.")]#text(" Use Proposition 4 to improve the lim sup in Corollary 1 to a lim inf. ")#mi("\\diamond")

#text("This in turn gives a fundamental compactness theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Perelman compactness theorem). Let ")#mi("\\kappa > 0")#text(", and let ")#mi("t \\mapsto (M_n, g_n(t), p_n)")#text(" be a sequence of three-dimensional ")#mi("\\kappa")#text("-solutions, normalised so that ")#mi("R_n(0,p_n)=1")#text(". Then after passing to a subsequence, these solutions converge geometrically to another ")#mi("\\kappa")#text("-solution ")#mi("t \\mapsto (M_\\infty, g_\\infty(t), p_\\infty)")#text(".")
]

#strong[#text("Proof. ")]#text("By Proposition 4, we have ")#mi("R_n(0,x) = O_A(1)")#text(" on ")#mi("B_{g_n(0)}(p_n,A)")#text(" for every ")#mi("A > 0")#text(". Using monotonicity ")#mi("\\partial_t R_n \\geq 0")#text(" and Hamilton compactness as before, the claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("— Universal noncollapsing —")]

#text("The Perelman compactness theorem requires ")#mi("\\kappa")#text(" to be fixed. However, the theorem can be largely extended to allow for variable ")#mi("\\kappa")#text(" by the following proposition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5. ")]#text("(Universal ")#mi("\\kappa")#text(") There exists a universal ")#mi("\\kappa_0 > 0")#text(" such that every 3-dimensional ")#mi("\\kappa")#text("-solution which is not round, is in fact a ")#mi("\\kappa_0")#text("-solution (no matter how small ")#mi("\\kappa > 0")#text(" is).")
]

#text("The reason one needs to exclude the round case is that sphere quotients ")#mi("S^3/\\Gamma")#text(" can be arbitrarily collapsed if one takes ")#mi("\\Gamma")#text(" to be large (e.g. consider the action of the ")#mi("n^{th}")#text(" roots of unity on the unit ball of ")#mi("{\\Bbb C}^2")#text(" (which is of course identifiable with ")#mi("S^3")#text(") for n large).")

#strong[#text("Proof.")]#text(" By time shifting it suffices to show ")#mi("\\kappa_0")#text("-noncollapsing at time zero at at some spatial origin ")#mi("x_0")#text(", which we now fix.")

#text("Let ")#mi("t \\mapsto (M,g(t))")#text(" be a ")#mi("\\kappa")#text("-solution. By Proposition 1, M is non-compact, which means that any asymptotic gradient shrinking soliton must also be non-compact. By Theorem 1 from the ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(", all asymptotic gradient shrinking solitons are thus round shrinking cylinders, or the oriented or unoriented quotient of such a cylinder.")

#text("Let ")#mi("l = l_{(0,x_0)}")#text(" be the reduced length function from ")#mi("(0,x_0)")#text(". Recall from ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(" that one can find a sequence of points ")#mi("(t_n,x_n)")#text(" with ")#mi("t_n \\to -\\infty")#text(" with ")#mi("l = O_A(1)")#text(" and ")#mi("R = O_A(t_n^{-1})")#text(" on any cylinder ")#mi("{}[At_n, t_n/A] \\times B_{g(t_n)}(x_n, A t_n^{1/2})")#text(", whose rescalings by ")#mi("t_n")#text(" converge geometrically to an asymptotic gradient shrinking soliton (and thus to a round cylinder or quotient thereof), and the bound ")#mi("O_A(1)")#text(" does not depend on ")#mi("\\kappa")#text(". A computation shows that these round cylinders or quotients are ")#mi("\\kappa^{\\prime}_0")#text("-noncollapsed for some universal ")#mi("\\kappa^{\\prime}_0 > 0")#text(", and so the cylinders ")#mi("{}[At_n, t_n/A] \\times B_{g(t_n)}(x_n, A t_n^{1/2})")#text(" are similarly ")#mi("\\kappa^{\\prime\\prime}_0")#text("-noncollapsed (for some slightly smaller but universal ")#mi("\\kappa^{\\prime\\prime}_0")#text("). From the bounds on l and R, this implies that reduced volume at time ")#mi("t_n")#text(" is bounded from below by a constant independent of ")#mi("\\kappa")#text(". Using monotonicity of reduced volume, we thus have this lower bound for all times. The arguments in ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text(" then give ")#mi("\\kappa_0")#text("-noncollapsing for some other universal ")#mi("\\kappa_0 > 0")#text(". ")#mi("\\Box")

#text("Here is one useful corollary of Perelman compactness and universality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3.")]#text(" (Universal derivative bounds) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a three-dimensional ")#mi("\\kappa")#text("-solution. Then we have the pointwise bounds ")#tao-math("\\left|\\partial_t^k \\nabla^m \\text{Riem}\\right| = O_{k,m}( R^{1 + m/2 + k} )", block: false)#text(" for all ")#mi("m,k \\geq 0")#text(". In particular we have ")#tao-math("\\left|\\partial_t^k \\nabla^m R\\right| = O_{k,m}( R^{1 + m/2 + k} )", block: false)#text(".")
]

#strong[#text("Proof. ")]#text("The claim is clear for the round shrinking solitons (which we can lift up to live on the sphere ")#mi("S^3")#text("), so we may assume that the ")#mi("\\kappa")#text("-solution is not round. By Proposition 5, we may then replace ")#mi("\\kappa")#text(" by a universal ")#mi("\\kappa_0")#text(". We may then time shift so that t=0 and rescale so that R(0,x)=1. If the claim failed, then we could find a sequence ")#mi("t \\mapsto (M_n, g_n(t), x_n)")#text(" of pointed ")#mi("\\kappa")#text("-solutions with ")#mi("R_n(0,x_n)=1")#text(", but such that some derivative of the curvature goes to infinity at this point. But this contradicts Theorem 1. ")#mi("\\Box")

#text("Here is another useful consequence:")

#strong[#text("Exercise 3.")]#text(" Let ")#mi("t \\mapsto (M_n, g_n(t))")#text(" be a sequence of three-dimensional ")#mi("\\kappa_n")#text("-solutions, and let ")#mi("x_n, y_n \\in M_n")#text(" and ")#mi("t_n \\leq 0")#text(". If ")#mi("R_n(t_n,x_n) d_{g(t_n)}(x_n,y_n)^2 \\to \\infty")#text(", show that ")#mi("R_n(t_n,y_n) d_{g(t_n)}(x_n,y_n)^2 \\to \\infty")#text(". (Note that this generalises Corollary 1 or Exercise 2. Hint: the claim is trivial in the round case, so assume non-roundness; then apply universality and compactness.) ")#mi("\\diamond")

#heading(level: 1)[#text("— Global structure of ")#mi("\\kappa")#text("-solutions —")]

#text("Roughly speaking, the above theory tells us that the geometry around any point ")#mi("(t,x)")#text(" in a 3-dimensional ")#mi("\\kappa")#text("-solutions has only bounded complexity if we only move ")#mi("O( R(t,x)^{-1/2} )")#text(" in space and ")#mi("O( R(t,x)^{-1} )")#text(" in time. This is about as good a control on the local geometry of such solutions as we can hope for; we now turn to the global geometry. [")#emph[#text("Aside")]#text(": It is unlikely that the space of 3-dimensional ")#mi("\\kappa")#text("-solutions is finite dimensional, as it is in the 2-dimensional case; see for instance Example 1.4 of ")#link("http://arxiv.org/abs/math.DG/0303109")[#text("Perelman’s second paper")]#text(" for what is probably an infinite-dimensional family of ")#mi("\\kappa")#text("-solutions.]")

#text("Let us begin with non-compact 3-dimensional ")#mi("\\kappa")#text("-solutions. A key point is that if such solutions are not already round cylinders (or quotients thereof), they must mostly resemble such cylinders.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Necks) Let ")#mi("\\varepsilon > 0")#text(". An ")#emph[#mi("\\varepsilon")#text("-neck ")]#text("in a Riemannian 3-manifold ")#mi("(M,g)")#text(" centred at a point ")#mi("x \\in M")#text(" is a diffeomorphism ")#mi("\\phi: S^2 \\times (-\\frac{1}{\\varepsilon}, \\frac{1}{\\varepsilon} ) \\to M")#text(" from a long cylinder to M, such that the normalised pullback metric ")#mi("R(x) \\phi^* g")#text(" lies within ")#mi("\\varepsilon")#text(" of the standard round metric on the cylinder in the ")#mi("C^{\\lfloor 1/\\varepsilon \\rfloor}")#text(" topology, where we require of course that R(x) > 0. The number ")#mi("R(x)^{-1/2}")#text(" is called the ")#emph[#text("width scale")]#text(" of the neck, and ")#mi("R(x)^{-1/2}/\\varepsilon")#text(" is the ")#emph[#text("length scale")]#text(".")
]

#text("Clearly, the notion of a ")#mi("\\varepsilon")#text("-neck is a scale-invariant concept. Note that if a sequence of pointed manifolds ")#mi("(M_n,g_n,x_n)")#text(" is converging geometrically (after rescaling) to a round cylinder ")#mi("S^2 \\times {\\Bbb R}")#text(", then for any ")#mi("\\varepsilon > 0")#text(", ")#mi("x_n")#text(" will be in the centre of an ")#mi("\\varepsilon")#text("-neck for sufficiently large n. Since round cylinders appear prominently as geometric limits, it is then not surprising that ")#mi("\\kappa")#text("-solutions, particularly non-compact ones, tend to be awash in ")#mi("\\varepsilon")#text("-necks. For instance, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6. ")]#text("For every ")#mi("\\varepsilon > 0")#text(" there exists an ")#mi("A > 0")#text(" such that whenever ")#mi("(t,x)")#text(" is a point in a 3-dimensional non-compact ")#mi("\\kappa")#text("-solution of strictly positive curvature and ")#mi("\\gamma: [0,+\\infty) \\to M")#text(" is a unit speed minimising geodesic from x to infinity (such things can easily be shown to exist by compactness arguments) at time t, then every point in ")#mi("\\gamma([A R(x)^{-1/2},+\\infty))")#text(" lies in the centre of an ")#mi("\\varepsilon")#text("-neck at time t.")
]

#strong[#text("Proof. ")]#text(" By time shifting we can take t=0. Suppose the claim is not the case, then we have a sequence ")#mi("t \\mapsto (M_n, g_n(t), x_n)")#text(" of pointed 3-dimensional non-compact ")#mi("\\kappa")#text("-solutions of strictly positive curvature and ")#mi("y_n")#text(" on a minimising geodesic from ")#mi("x_n")#text(" to infinity such that ")#mi("d_n(x_n,y_n)^2 R_n(x_n) \\to \\infty")#text(" and ")#mi("y_n")#text(" is not the centre of a ")#mi("\\varepsilon")#text("-neck at time zero. By Exercise 3 we thus have ")#mi("d_n(x_n,y_n)^2 R_n(y_n) \\to \\infty")#text(". Let us now rescale so that ")#mi("R(y_n) = 1")#text(". Since the ")#mi("M_n")#text(" are non-compact, they are non-round and so by Proposition 5 we can take ")#mi("\\kappa")#text(" to be universal, at which point by Perelman compactness (Theorem 1) we can pass to a subsequence and assume that ")#mi("t \\mapsto (M_n,g_n(t),y_n)")#text(" is converging to a limit ")#mi("t \\mapsto (M_\\infty,g_\\infty(t),y_\\infty)")#text(", which is also a ")#mi("\\kappa")#text("-solution. Since ")#mi("d_n(x_n,y_n) \\to \\infty")#text(", we see that the limit manifold contains a minimising geodesic line through ")#mi("y_\\infty")#text(", and hence by the Cheeger-Gromoll splitting theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 16")]#text(") ")#mi("M_\\infty")#text(" must split into the product of a line and a positively curved manifold. By Proposition 2, we conclude that ")#mi("M_\\infty")#text(" is either a cylinder ")#mi("S^2 \\times {\\Bbb R}")#text(" or a projective cylinder ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(".")

#text("The latter can be ruled out by topological considerations; a positively curved complete non-compact 3-manifold ")#mi("M_n")#text(" is homoemorphic to ")#mi("{\\Bbb R}^3")#text(" by the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(", and so does not contain any embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. (In any event, for applications to the Poincaré conjecture one can always assume that no such embedded projective plane exists in any manifold being studied.) So ")#mi("M_\\infty")#text(" is a round cylinder, and thus ")#mi("y_n")#text(" is the centre of an ")#mi("\\varepsilon")#text("-neck, a contradiction, and the claim follows. ")#mi("\\Box")

#text("There is a variant of Proposition 6 that works in the compact case also:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7. ")]#text("For every ")#mi("\\varepsilon > 0")#text(" there exists an ")#mi("A > 0")#text(" such that whenever ")#mi("(t,x), (t,y)")#text(" are points in a 3-dimensional ")#mi("\\kappa")#text("-solution (either compact or noncompact) then at time t, any point on the minimising geodesic between x and y at a distance at least ")#mi("A R(x)^{-1/2}")#text(" from x and ")#mi("A R(y)^{-1/2}")#text(" from y, lies in the centre of an ")#mi("\\varepsilon")#text("-neck at time t.")
]

#strong[#text("Proof.")]#text(" We can repeat the proof of Proposition 6. The one non-trivial task is the topological one, namely to show that M does not contain an embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle in the compact case (the non-compact case already being covered in Proposition 6). But M is compact and has strictly positive curvature (thanks to Proposition 2) and so by Hamilton’s ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("rounding theorem")]#text(", is diffeomorphic to a spherical space form ")#mi("S^3/\\Gamma")#text(" for some finite ")#mi("\\Gamma")#text("; in particular the ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("\\pi_1(M) \\equiv \\Gamma")#text(" is finite. On the other hand, an embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle cannot separate M (as its ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler characteristic")]#text(" is 1) and so a closed loop in M can have a non-trivial intersection number with such a projective plane (using the normal bundle to give a sign to each intersection), leading to a non-trivial homomorphism from ")#mi("\\pi_1(M)")#text(" to ")#mi("{\\Bbb Z}")#text(", contradicting the finiteness of the fundamental group. [An alternate argument would be to use Perelman compactness to extract a non-compact (but positively curved) limiting ")#mi("\\kappa")#text("-solution from a sequence of increasingly long compact ")#mi("\\kappa")#text("-solutions. Proposition 6 prohibits the limiting solutions from asymptotically looking like ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(", and so the long compact solutions cannot have such projective necks either.] ")#mi("\\Box")

#text("Informally, the above proposition shows that any two sufficiently far apart points in a compact ")#mi("\\kappa")#text("-solution will be separated almost entirely by ")#mi("\\varepsilon")#text("-necks. Since the only way that necks can be glued together is by forming a tube, one can then show the following two corollaries:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4. ")]#text("(Description of non-compact positively curved ")#mi("\\kappa")#text("-solutions) For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("A > 0")#text(" such that for every non-compact 3-dimensional positively curved ")#mi("\\kappa")#text("-solution ")#mi("t \\mapsto (M,g(t))")#text(" and time t there exists a point ")#mi("p \\in M")#text(" such that at time t")

#enum(start: 1, 
[#text("Every point outside of ")#mi("B( p, A R(p)^{-1/2} )")#text(" lies in an ")#mi("\\varepsilon")#text("-neck (and in particular, the exterior of this ball is topologically a half-infinite cylinder ")#mi("S^2 \\times [0,+\\infty)")#text("); and")],
[#text("Inside the ball ")#mi("B( p, A R(p)^{-1/2} )")#text(" (which is topologically a standard 3-ball by the soul theorem) all sectional curvatures are comparable to R(p) modulo constants C depending only on ")#mi("\\varepsilon")#text(", and the volume of the ball is comparable to ")#mi("R(p)^{-3/2}")#text(" modulo similar constants C.")]
)
]

#text("(The control inside the ball is coming from results such as Corollary 3, as well as the non-collapsed nature of M.)")

#text("In the language of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(", we have described non-compact positively curved 3-dimensional ")#mi("\\kappa")#text("-solutions as ")#emph[#text("C-capped ")#mi("\\varepsilon")#text("-tubes")]#text(". [Actually, Morgan-Tian prove a little more: they control the time evolution of the necks and not just individual time slices, leading to the notion of a ")#emph[#text("strong ")#mi("\\varepsilon")#text("-neck")]#text(". See Section 9.8 of that book for details, as well as a precise definition of the C-capped ")#mi("\\varepsilon")#text("-tubes.] Combined with Proposition 2, we now have a satisfactory description of non-compact ")#mi("\\kappa")#text("-solutions: they are either round cylinders (and thus doubly infinite ")#mi("\\varepsilon")#text("-tubes), oriented quotients of round cylinders (and thus a half-infinite ")#mi("\\varepsilon")#text("-tube capped off by a punctured ")#mi("\\Bbb{RP}^3")#text("), oriented quotients of round cylinders (and thus containing an ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle), or a half-infinite ")#mi("\\varepsilon")#text("-tube capped off by a 3-ball.")

#text("For compact ")#mi("\\kappa")#text("-solutions, we have something similar:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8.")]#text(" (Characterisation of large compact ")#mi("\\kappa")#text("-solutions) For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("A, A^{\\prime} > 0")#text(" such that if ")#mi("t \\mapsto (M,g)")#text(" is a compact 3-dimensional ")#mi("\\kappa")#text("-solution with ")#mi("\\text{diam}(M) \\geq A^{\\prime} (\\sup R)^{-1/2}")#text(" at some time t, then ")#mi("(M,g(t))")#text(" can be partitioned into an ")#mi("\\varepsilon")#text("-tube (roughly speaking, a region in which every point lies in the middle of an ")#mi("\\varepsilon")#text("-neck, and bordered on both ends by an ")#mi("S^2")#text(") and two ")#mi("(C,\\varepsilon)")#text("-caps (roughly speaking, two regions diffeomorphic to either a 3-ball or punctured ")#mi("\\Bbb{RP}^3")#text(", bounded by an ")#mi("S^2")#text(", in which the sectional curvatures are comparable to a scalar R, the diameter is comparable to ")#mi("R^{-1/2}")#text(", and volume comparable to ")#mi("R^{-3/2}")#text("). See Section 9.8 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for precise definitions.")
]

#text("The topological characterisation of the caps (that they are either 3-balls or punctured ")#mi("\\Bbb{RP}^3")#text("s) follows from the corresponding characterisations of the caps in the non-compact case, followed by a compactness argument. Note that the round compact manifolds have diameter ")#mi("O(R^{-1/2})")#text(", where R is the constant curvature, and thus are not covered by the above Proposition.")

#text("By considering the various topologies for the caps, we see from basic topology then tells us that the manifolds in this case are homeomorphic to either ")#mi("S^3")#text(" or ")#mi("{\\Bbb RP}^3")#text(", or ")#mi("{\\Bbb RP}^3 \\# {\\Bbb RP}^3")#text(". The latter has infinite fundamental group, though, and thus not homeomorphic to a spherical space form; thus it cannot actually arise since Hamilton’s rounding theorem asserts that all compact manifolds of positive curvature are homeomorphic to spherical space forms.")

#text("Finally, we turn to small compact non-round ")#mi("\\kappa")#text("-solutions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9.")]#text(" (Characterisation of small compact ")#mi("\\kappa")#text("-solutions) Let ")#mi("C > 0")#text(", and let ")#mi("t \\mapsto (M,g)")#text(" be a compact 3-dimensional ")#mi("\\kappa")#text("-solution with ")#mi("\\text{diam}(M) \\leq C (\\sup R)^{-1/2}")#text(" at some time t which is not round, then all sectional curvatures are comparable up to constants depending on C, the diameter is comparable to ")#mi("(\\sup R)^{-1/2}")#text(" up to similar constants, the volume is comparable to ")#mi("(\\sup R)^{-3/2}")#text(", and the manifold is topologically either ")#mi("S^3")#text(" or ")#mi("{\\Bbb RP}^3")#text(".")
]

#strong[#text("Proof.")]#text(" The diameter, curvature, and volume bounds follow from the compactness theory. To get the topological type, observe from the treatment of the compact soliton case that as M is not round, the asymptotic gradient shrinking soliton is non-compact, and thus must be a cylinder or one of its quotients. In particular this implies that as one goes back in time, the manifold M must eventually become large in the sense of Proposition 8. Since the manifolds in that proposition were topologically either ")#mi("S^3")#text(" or ")#mi("{\\Bbb RP}^3")#text(", the same is true here. ")#mi("\\Box")

#text("Putting all of the above results together, we obtain Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("Lecture 12")]#text(" (modulo some imprecision in the definitions which I have decided not to detail here).")

#text("[")#emph[#text("Updated")]#text(", June 3: Proposition 9 added.]")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/#comment-30218")[#strong[#text("285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("[…] of canonical neighbourhood is associated to the small compact manifolds from Proposition 9 of the previous lecture. Definition 2. (C-component) Let . A C-component is a connected 3-manifold homeomorphic to or , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/#comment-34878")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2009")])]

#text("[…] a -solution; but then the vanishing curvature forces it to be a round cylinder, by Proposition 2 of Lecture 17. This implies that the rescaled are eventually -necks, a […]")
]
