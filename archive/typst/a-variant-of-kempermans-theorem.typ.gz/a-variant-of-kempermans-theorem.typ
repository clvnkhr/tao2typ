// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:45.655920+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A variant of Kemperman’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A variant of Kemperman’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/")[#text("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In 1964, ")#link("http://www.ams.org/mathscinet-getitem?mr=202913")[#text("Kemperman established")]#text(" the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-c2ade0cb22bbb6cb1d2b>#text(" Let ")#mi("{G}")#text(" be a compact connected group, with a Haar probability measure ")#mi("{\\mu}")#text(". Let ")#mi("{A, B}")#text(" be compact subsets of ")#mi("{G}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mu(AB) \\geq \\min( \\mu(A) + \\mu(B), 1 ).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The estimate is sharp, as can be seen by considering the case when ")#mi("{G}")#text(" is a unit circle, and ")#mi("{A, B}")#text(" are arcs; similarly if ")#mi("{G}")#text(" is any compact connected group that projects onto the circle. The connectedness hypothesis is essential, as can be seen by considering what happens if ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are a non-trivial open subgroup of ")#mi("{G}")#text(". For locally compact connected groups which are unimodular but not compact, there is an analogous statement, but with ")#mi("{\\mu}")#text(" now a Haar measure instead of a Haar probability measure, and the right-hand side ")#mi("{\\min(\\mu(A)+\\mu(B),1)}")#text(" replaced simply by ")#mi("{\\mu(A)+\\mu(B)}")#text(". The case when ")#mi("{G}")#text(" is a torus is due ")#link("http://www.ams.org/mathscinet-getitem?mr=56670")[#text("to Macbeath")]#text(", and the case when ")#mi("{G}")#text(" is a circle is due ")#link("http://www.ams.org/mathscinet-getitem?mr=1776")[#text("to Raikov")]#text(". The theorem is closely related to the ")#link("http://en.wikipedia.org/wiki/Restricted_sumset#Cauchy-Davenport_theorem")[#text("Cauchy-Davenport inequality")]#text("; indeed, it is not difficult to use that inequality to establish the circle case, and the circle case can be used to deduce the torus case by considering increasingly dense circle subgroups of the torus (alternatively, one can also use ")#link("http://www.ams.org/mathscinet-getitem?mr=56632")[#text("Kneser’s theorem")]#text(").")

#text("By inner regularity, the hypothesis that ")#mi("{A,B}")#text(" are compact can be replaced with Borel measurability, so long as one then adds the additional hypothesis that ")#mi("{A+B}")#text(" is also Borel measurable.")
]

#text("A short proof of Kemperman’s theorem was given ")#link("http://www.ams.org/mathscinet-getitem?mr=1173766")[#text("by Ruzsa")]#text(". In this post I wanted to record how this argument can be used to establish the following more “robust” version of Kemperman’s theorem, which not only lower bounds ")#mi("{AB}")#text(", but gives many elements of ")#mi("{AB}")#text(" some multiplicity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-0727fc6654c3e54739f2>#text(" Let ")#mi("{G}")#text(" be a compact connected group, with a Haar probability measure ")#mi("{\\mu}")#text(". Let ")#mi("{A, B}")#text(" be compact subsets of ")#mi("{G}")#text(". Then for any ")#mi("{0 \\leq t \\leq \\min(\\mu(A),\\mu(B))}")#text(", one has ")#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_G \\min(1_A*1_B, t)\\ d\\mu \\geq t \\min(\\mu(A)+\\mu(B) - t,1).")]]




]

#text("Indeed, Theorem ")#link(<tao-c2ade0cb22bbb6cb1d2b>)[#text("1")]#text(" can be deduced from Theorem ")#link(<tao-0727fc6654c3e54739f2>)[#text("2")]#text(" by dividing ")#link(<tao-eeea394806ada3056899>)[#text("(1)")]#text(" by ")#mi("{t}")#text(" and then taking limits as ")#mi("{t \\rightarrow 0}")#text(". The bound in ")#link(<tao-eeea394806ada3056899>)[#text("(1)")]#text(" is sharp, as can again be seen by considering the case when ")#mi("{A,B}")#text(" are arcs in a circle. The analogous claim for cyclic groups for prime order was established ")#link("http://www.ams.org/mathscinet-getitem?mr=354517")[#text("by Pollard")]#text(", and for general abelian groups ")#link("http://www.ams.org/mathscinet-getitem?mr=2166359")[#text("by Green and Ruzsa")]#text(".")

#text("Let us now prove Theorem ")#link(<tao-0727fc6654c3e54739f2>)[#text("2")]#text(". It uses a submodularity argument related to one discussed in ")#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/")[#text("this previous post")]#text(". We fix ")#mi("{B}")#text(" and ")#mi("{t}")#text(" with ")#mi("{0 \\leq t \\leq \\mu(B)}")#text(", and define the quantity")

#align(center)[#tao-fit-display[#mitex("c(A) := \\int_G \\min(1_A*1_B, t)\\ d\\mu - t (\\mu(A)+\\mu(B)-t).")]]

#text("for any compact set ")#mi("{A}")#text(". Our task is to establish that ")#mi("{c(A) \\geq 0}")#text(" whenever ")#mi("{t \\leq \\mu(A) \\leq 1-\\mu(B)+t}")#text(".")

#text("We first verify the extreme cases. If ")#mi("{\\mu(A) = t}")#text(", then ")#mi("{1_A*1_B \\leq t}")#text(", and so ")#mi("{c(A)=0}")#text(" in this case (since ")#mi("{\\int_G 1_A*1_B = \\mu(A)\\mu(B) = t \\mu(B)}")#text("). At the other extreme, if ")#mi("{\\mu(A) = 1-\\mu(B)+t}")#text(", then from the inclusion-exclusion principle we see that ")#mi("{1_A * 1_B \\geq t}")#text(", and so again ")#mi("{c(A)=0}")#text(" in this case.")

#text("To handle the intermediate regime when ")#mi("{\\mu(A)}")#text(" lies between ")#mi("{t}")#text(" and ")#mi("{1-\\mu(B)+t}")#text(", we rely on the ")#emph[#text("submodularity inequality")]#text(" ")#metadata(none) <tao-6d9e26c2e0533e2488c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("c(A_1) + c(A_2) \\geq c(A_1 \\cap A_2) + c(A_1 \\cup A_2)")]]



#text(" for arbitrary compact ")#mi("{A_1,A_2}")#text(". This inequality comes from the obvious pointwise identity")

#align(center)[#tao-fit-display[#mitex("1_{A_1} + 1_{A_2} = 1_{A_1 \\cap A_2} + 1_{A_1 \\cup A_2}")]]

#text("whence")

#align(center)[#tao-fit-display[#mitex("1_{A_1}*1_B + 1_{A_2}*1_B = 1_{A_1 \\cap A_2}*1_B + 1_{A_1 \\cup A_2}*1_B")]]

#text("and thus (noting that the quantities on the left are closer to each other than the quantities on the right)")

#align(center)[#tao-fit-display[#mitex("\\min(1_{A_1}*1_B,t) + \\min(1_{A_2}*1_B,t)")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\min(1_{A_1 \\cap A_2}*1_B,t) + \\min(1_{A_1 \\cup A_2}*1_B,t)")]]

#text("at which point ")#link(<tao-6d9e26c2e0533e2488c7>)[#text("(2)")]#text(" follows by integrating over ")#mi("{G}")#text(" and then using the inclusion-exclusion principle.")

#text("Now introduce the function")

#align(center)[#tao-fit-display[#mitex("f(a) := \\inf \\{ c(A) : \\mu(A) = a \\}")]]

#text("for ")#mi("{t \\leq a \\leq 1-\\mu(B)+t}")#text(". From the preceding discussion ")#mi("{f(a)}")#text(" vanishes at the endpoints ")#mi("{a = t, 1-\\mu(B)+t}")#text("; our task is to show that ")#mi("{f(a)}")#text(" is non-negative in the interior region ")#mi("{t < a < 1-\\mu(B)+t}")#text(". Suppose for contradiction that this was not the case. It is easy to see that ")#mi("{f}")#text(" is continuous (indeed, it is even Lipschitz continuous), so there must be ")#mi("{t < a < 1-\\mu(B)+t}")#text(" at which ")#mi("{f}")#text(" is a local minimum and not locally constant. In particular, ")#mi("{0 <a <1}")#text(". But for any ")#mi("{A}")#text(" with ")#mi("{\\mu(A) = a}")#text(", we have the translation-invariance ")#metadata(none) <tao-cbd31fe312a05a4718b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("c(gA) = c(A)")]]



#text(" for any ")#mi("{g \\in G}")#text(", and hence by ")#link(<tao-6d9e26c2e0533e2488c7>)[#text("(2)")]

#align(center)[#tao-fit-display[#mitex("c(A) \\geq \\frac{1}{2} c(A \\cap gA) + \\frac{1}{2} c(A \\cup gA ).")]]

#text("Note that ")#mi("{\\mu(A \\cap gA)}")#text(" depends continuously on ")#mi("{g}")#text(", equals ")#mi("{a}")#text(" when ")#mi("{g}")#text(" is the identity, and has an average value of ")#mi("{a^2}")#text(". As ")#mi("{G}")#text(" is connected, we thus see from the intermediate value theorem that for any ")#mi("{0 < \\epsilon < a-a^2}")#text(", we can find ")#mi("{g}")#text(" such that ")#mi("{\\mu(A \\cap gA) = a-\\epsilon}")#text(", and thus by inclusion-exclusion ")#mi("{\\mu(A \\cup gA) = a+\\epsilon}")#text(". By definition of ")#mi("{f}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("c(A) \\geq \\frac{1}{2} f(a-\\epsilon) + \\frac{1}{2} f(a+\\epsilon).")]]

#text("Taking infima in ")#mi("{A}")#text(" (and noting that the hypotheses on ")#mi("{\\epsilon}")#text(" are independent of ")#mi("{A}")#text(") we conclude that")

#align(center)[#tao-fit-display[#mitex("f(a) \\geq \\frac{1}{2} f(a-\\epsilon) + \\frac{1}{2} f(a+\\epsilon)")]]

#text("for all ")#mi("{0 < \\epsilon < a-a^2}")#text(". As ")#mi("{f}")#text(" is a local minimum and ")#mi("{\\epsilon}")#text(" is arbitrarily small, this implies that ")#mi("{f}")#text(" is locally constant, a contradiction. This establishes Theorem ")#link(<tao-0727fc6654c3e54739f2>)[#text("2")]#text(".")

#text("We observe the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" Let ")#mi("{G}")#text(" be a compact connected group, with a Haar probability measure ")#mi("{\\mu}")#text(". Let ")#mi("{A, B, C}")#text(" be compact subsets of ")#mi("{G}")#text(", and let ")#mi("{\\delta := \\min(\\mu(A),\\mu(B),\\mu(C))}")#text(". Then one has the pointwise estimate")

#align(center)[#tao-fit-display[#mitex("1_A * 1_B * 1_C \\geq \\frac{1}{4} (\\mu(A)+\\mu(B)+\\mu(C)-1)_+^2")]]

#text("if ")#mi("{\\mu(A)+\\mu(B)+\\mu(C)-1 \\leq 2 \\delta}")#text(", and")

#align(center)[#tao-fit-display[#mitex("1_A * 1_B * 1_C \\geq \\delta (\\mu(A)+\\mu(B)+\\mu(C)-1-\\delta)")]]

#text("if ")#mi("{\\mu(A)+\\mu(B)+\\mu(C)-1 \\geq 2 \\delta}")#text(".")
]

#text("Once again, the bounds are completely sharp, as can be seen by computing ")#mi("{1_A*1_B*1_C}")#text(" when ")#mi("{A,B,C}")#text(" are arcs of a circle. For quasirandom ")#mi("{G}")#text(", one can do much better than these bounds, as discussed in ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("this recent blog post")]#text("; thus, the abelian case is morally the worst case here, although it seems difficult to convert this intuition into a rigorous reduction.")

#emph[#text("Proof:")]#text(" By cyclic permutation we may take ")#mi("{\\delta = \\mu(C)}")#text(". For any")

#align(center)[#tao-fit-display[#mitex("(\\mu(A)+\\mu(B)-1)_+ \\leq t \\leq \\min(\\mu(A),\\mu(B)),")]]

#text("we can bound")

#tao-aligned(keep: true)[


#tao-math("1_A*1_B*1_C  & \\geq \\min(1_A*1_B,t)*1_C", block: true)



#tao-math(" & \\geq \\int_G \\min(1_A*1_B,t)\\ d\\mu - t (1-\\mu(C))", block: true)



#tao-math(" & \\geq t (\\mu(A)+\\mu(B)-t) - t (1-\\mu(C))", block: true)



#tao-math(" & = t \\min( \\mu(A)+\\mu(B)+\\mu(C)-1-t )", block: true)
]

#text("where we used Theorem ")#link(<tao-0727fc6654c3e54739f2>)[#text("2")]#text(" to obtain the third line. Optimising in ")#mi("{t}")#text(", we obtain the claim. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc14d93c8648c9f8c27b3e1e0c49d17fc6c91ae03d4b012efb1ae26054976925-f6f9cd080f3adaa5541571b73a70326edb6db35cdb0cbee741396b0b7630143a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-118752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2011")])]

#text("Dear Terry ,")#linebreak()#text(" From the estimate you explained for \\mu(AB) (A, B are two compact subset of the group G) I am wondering that when the distribution ")#mi("1_A \\star 1_B")#text(" is absolutely continuous with respect to the Haar measure of the group ")#mi("G")#text(".")#linebreak()#text(" Also what is the least integer number n=n(A, B) for which the power measure ")#mi("(1_A \\star 1_B)^n")#text(" is absolutely continuous ? I think This integer number has interesting property which depend on the sets A and B.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-118857")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2011")])]

#text("Dear Terence,")

#text("the inequality in the proof of (2) is probably reversed.")

#text("It might also be worth mentioning that f(a) is in fact Lipschitz to avoid people like me following a wrong lead. :)")

#text("best regards,")#linebreak()#text(" pavel")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-192740")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Dear Terry,")

#text("To what extent can one generalise this argument to not-necessarily-connected groups? Can one get a more robust version of Kneser’s theorem (in a locally compact group), or at least an alternative proof of Kneser’s theorem?")

#text("Best wishes,")#linebreak()#text(" Sean")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-192743")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("That’s a good question. I know some people have already tried to use submodularity methods to prove Kneser’s theorem, but it seems to be a surprisingly difficult task; it seems to be quite difficult to hit upon a way of iterating submodularity so that one arrives at a trivially true inequality in finite time (as is the case for connected groups as outlined above).")

#text("Certainly I would like to see a new proof of that theorem, as the current proofs are quite involved…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-240292")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("Tiny correction: the parenthetical remark “since ")#mi("\\int_G 1_A \\ast 1_B = \\mu(A)\\mu(B) = t\\mu(B)")#text("” just before equation (2) is attached to the wrong sentence, which confused me briefly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Additive limits | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-429519")[#strong[#text("Additive limits | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("[…] and are supported on sets of measure at least and . Applying Kemperman’s theorem (see this previous post) , we conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for Kemperman’s inequality | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/#comment-488840")[#strong[#text("An inverse theorem for Kemperman’s inequality | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("[…] of Mathematics in honour of Sergei Konyagin. It concerns an inequality of Kemperman discussed previously in this blog, namely […]")
]
