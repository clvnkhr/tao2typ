// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:38:45.067186+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247B, Notes 1: Restriction theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247B, Notes 1: Restriction theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This set of notes focuses on the ")#emph[#text("restriction problem")]#text(" in Fourier analysis. Introduced by Elias Stein in the 1970s, the restriction problem is a key model problem for understanding more general oscillatory integral operators, and which has turned out to be connected to many questions in geometric measure theory, harmonic analysis, combinatorics, number theory, and PDE. Only partial results on the problem are known, but these partial results have already proven to be very useful or influential in many applications.")#linebreak()#text(" We work in a Euclidean space ")#mi("{{\\bf R}^d}")#text(". Recall that ")#mi("{L^p({\\bf R}^d)}")#text(" is the space of ")#mi("{p^{th}}")#text("-power integrable functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", quotiented out by almost everywhere equivalence, with the usual modifications when ")#mi("{p=\\infty}")#text(". If ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" then the Fourier transform ")#mi("{\\hat f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" will be defined in this course by the formula ")#metadata(none) <tao-9c3aee7110b787f0fb5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\hat f(\\xi) := \\int_{{\\bf R}^d} f(x) e^{-2\\pi i x \\cdot \\xi}\\ dx.")]]

#text(" From the dominated convergence theorem we see that ")#mi("{\\hat f}")#text(" is a continuous function; from ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("the Riemann-Lebesgue lemma")]#text(" we see that it goes to zero at infinity. Thus ")#mi("{\\hat f}")#text(" lies in the space ")#mi("{C_0({\\bf R}^d)}")#text(" of continuous functions that go to zero at infinity, which is a subspace of ")#mi("{L^\\infty({\\bf R}^d)}")#text(". Indeed, from the triangle inequality it is obvious that ")#metadata(none) <tao-4a7dbeadca28aac2aa25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|\\hat f\\right\\|_{L^\\infty({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^1({\\bf R}^d)}.", block: true)]]

#text(" If ")#mi("{f \\in L^1({\\bf R}^d) \\cap L^2({\\bf R}^d)}")#text(", then ")#link("https://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(" tells us that we have the identity ")#metadata(none) <tao-ea242a3fb45034524055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|\\hat f\\right\\|_{L^2({\\bf R}^d)} = \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text(" Because of this, there is a unique way to extend the Fourier transform ")#mi("{f \\mapsto \\hat f}")#text(" from ")#mi("{L^1({\\bf R}^d) \\cap L^2({\\bf R}^d)}")#text(" to ")#mi("{L^2({\\bf R}^d)}")#text(", in such a way that it becomes a unitary map from ")#mi("{L^2({\\bf R}^d)}")#text(" to itself. By abuse of notation we continue to denote this extension of the Fourier transform by ")#mi("{f \\mapsto \\hat f}")#text(". Strictly speaking, this extension is no longer defined in a pointwise sense by the formula ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("(1)")]#text(" (indeed, the integral on the RHS ceases to be absolutely integrable once ")#mi("{f}")#text(" leaves ")#mi("{L^1({\\bf R}^d)}")#text("; we will return to the (surprisingly difficult) question of whether pointwise convergence continues to hold (at least in an almost everywhere sense) later in this course, when we discuss ")#link("https://en.wikipedia.org/wiki/Carleson%27s_theorem")[#text("Carleson’s theorem")]#text(". On the other hand, the formula ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("(1)")]#text(" remains valid in the sense of distributions, and in practice most of the identities and inequalities one can show about the Fourier transform of “nice” functions (e.g., functions in ")#mi("{L^1({\\bf R}^d) \\cap L^2({\\bf R}^d)}")#text(", or in the Schwartz class ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(", or test function class ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(") can be extended to functions in “rough” function spaces such as ")#mi("{L^2({\\bf R}^d)}")#text(" by standard limiting arguments.")#linebreak()#text(" By ")#link(<tao-4a7dbeadca28aac2aa25>)[#text("(2)")]#text(", ")#link(<tao-ea242a3fb45034524055>)[#text("(3)")]#text(", and the ")#link("https://en.wikipedia.org/wiki/Riesz%E2%80%93Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(", we also obtain the ")#link("https://en.wikipedia.org/wiki/Hausdorff%E2%80%93Young_inequality")[#text("Hausdorff-Young inequality")]#text(" ")#metadata(none) <tao-02b9fee20b66a5d1fe46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|\\hat f\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text(" for all ")#mi("{1 \\leq p \\leq 2}")#text(" and ")#mi("{f \\in L^1({\\bf R}^d) \\cap L^2({\\bf R}^d)}")#text(", where ")#mi("{2 \\leq p^{\\prime} \\leq \\infty}")#text(" is the dual exponent to ")#mi("{p}")#text(", defined by the usual formula ")#mi("{\\frac{1}{p} + \\frac{1}{p^{\\prime}} = 1}")#text(". (One can improve this inequality by a constant factor, with the optimal constant worked out ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=385456")[#text("by Beckner")]#text(", but the focus in these notes will not be on optimal constants.) As a consequence, the Fourier transform can also be uniquely extended as a continuous linear map from ")#mi("{L^p({\\bf R}^d) \\rightarrow L^{p^{\\prime}}({\\bf R}^d)}")#text(". (The situation with ")#mi("{p>2}")#text(" is much worse; see below the fold.)")#linebreak()#text(" The ")#emph[#text("restriction problem")]#text(" asks, for a given exponent ")#mi("{1 \\leq p \\leq 2}")#text(" and a subset ")#mi("{S}")#text(" of ")#mi("{{\\bf R}^d}")#text(", whether it is possible to meaningfully restrict the Fourier transform ")#mi("{\\hat f}")#text(" of a function ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" to the set ")#mi("{S}")#text(". If the set ")#mi("{S}")#text(" has positive Lebesgue measure, then the answer is yes, since ")#mi("{\\hat f}")#text(" lies in ")#mi("{L^{p^{\\prime}}({\\bf R}^d)}")#text(" and therefore has a meaningful restriction to ")#mi("{S}")#text(" even though functions in ")#mi("{L^{p^{\\prime}}}")#text(" are only defined up to sets of measure zero. But what if ")#mi("{S}")#text(" has measure zero? If ")#mi("{p=1}")#text(", then ")#mi("{\\hat f \\in C_0({\\bf R}^d)}")#text(" is continuous and therefore can be meaningfully restricted to any set ")#mi("{S}")#text(". At the other extreme, if ")#mi("{p=2}")#text(" and ")#mi("{f}")#text(" is an arbitrary function in ")#mi("{L^2({\\bf R}^d)}")#text(", then by Plancherel’s theorem, ")#mi("{\\hat f}")#text(" is also an arbitrary function in ")#mi("{L^2({\\bf R}^d)}")#text(", and thus has no well-defined restriction to any set ")#mi("{S}")#text(" of measure zero.")#linebreak()#text(" It was observed by Stein (as reported in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2618897")[#text("the Ph.D. thesis of Charlie Fefferman")]#text(") that for certain measure zero subsets ")#mi("{S}")#text(" of ")#mi("{{\\bf R}^d}")#text(", such as the sphere ")#tao-math("{S^{d-1} := \\{ \\xi \\in {\\bf R}^d: \\left|\\xi\\right| = 1\\}}", block: false)#text(", one can obtain meaningful restrictions of the Fourier transforms of functions ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" for certain ")#mi("{p}")#text(" between ")#mi("{1}")#text(" and ")#mi("{2}")#text(", thus demonstrating that the Fourier transform of such functions retains more structure than a typical element of ")#mi("{L^{p^{\\prime}}({\\bf R}^d)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Preliminary ")#mi("{L^2}")#text(" restriction theorem)")]#text(" ")#metadata(none) <tao-9a4cf4b8b0f50f4b8634>#text(" If ")#mi("{d \\geq 2}")#text(" and ")#mi("{1 \\leq p < \\frac{4d}{3d+1}}")#text(", then one has the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^2(S^{d-1}, d\\sigma)} \\lesssim_{d,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(", where ")#mi("{d\\sigma}")#text(" denotes surface measure on the sphere ")#mi("{S^{d-1}}")#text(". In particular, the restriction ")#mi("{\\hat f|_S}")#text(" can be meaningfully defined by continuous linear extension to an element of ")#mi("{L^2(S^{d-1},d\\sigma)}")#text(".")
]

#emph[#text("Proof:")]#text(" Fix ")#mi("{d,p,f}")#text(". We expand out")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^2(S^{d-1}, d\\sigma)}^2 = \\int_{S^{d-1}} \\left|\\hat f(\\xi)\\right|^2\\ d\\sigma(\\xi).", block: true)]]

#text("From ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("(1)")]#text(" and Fubini’s theorem, the right-hand side may be expanded as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} f(x) \\overline{f}(y) (d\\sigma)^\\vee(y-x)\\ dx dy")]]

#text("where the inverse Fourier transform ")#mi("{(d\\sigma)^\\vee}")#text(" of the measure ")#mi("{d\\sigma}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("(d\\sigma)^\\vee(x) := \\int_{S^{d-1}} e^{2\\pi i x \\cdot \\xi}\\ d\\sigma(\\xi).")]]

#text("In other words, we have the identity ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\hat f \\right\\|_{L^2(S^{d-1}, d\\sigma)}^2 = \\langle f, f * (d\\sigma)^\\vee \\rangle_{L^2({\\bf R}^d)},", block: true)]]

#text(" using the Hermitian inner product ")#mi("{\\langle f, g\\rangle_{L^2({\\bf R}^d)} := \\int_{{\\bf R}^d} \\overline{f(x)} g(x)\\ dx}")#text(". Since the sphere ")#mi("{S^{d-1}}")#text(" have bounded measure, we have from the triangle inequality that ")#metadata(none) <tao-5f2b1d6f5492140fa7b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(d\\sigma)^\\vee(x) \\lesssim_d 1.")]]

#text(" Also, from the method of stationary phase (as covered in the previous class 247A), or Bessel function asymptotics, we have the decay ")#metadata(none) <tao-720f6ac947ab8e448c3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("(d\\sigma)^\\vee(x) \\lesssim_d \\left|x\\right|^{-(d-1)/2}", block: true)]]

#text(" for any ")#mi("{x \\in {\\bf R}^d}")#text(" (note that the bound already follows from ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(6)")]#text(" unless ")#tao-math("{\\left|x\\right| \\geq 1}", block: false)#text("). We remark that the exponent ")#mi("{-\\frac{d-1}{2}}")#text(" here can be seen geometrically from the following considerations. For ")#tao-math("{\\left|x\\right|>1}", block: false)#text(", the phase ")#mi("{e^{2\\pi i x \\cdot \\xi}}")#text(" on the sphere is stationary at the two antipodal points ")#tao-math("{x/\\left|x\\right|, -x/\\left|x\\right|}", block: false)#text(" of the sphere, and constant on the tangent hyperplanes to the sphere at these points. The wavelength of this phase is proportional to ")#tao-math("{1/\\left|x\\right|}", block: false)#text(", so the phase would be approximately stationary on a cap formed by intersecting the sphere with a ")#tao-math("{\\sim 1/\\left|x\\right|}", block: false)#text(" neighbourhood of the tangent hyperplane to one of the stationary points. As the sphere is tangent to second order at these points, this cap will have diameter ")#tao-math("{\\sim 1/\\left|x\\right|^{1/2}}", block: false)#text(" in the directions of the ")#mi("{d-1}")#text("-dimensional tangent space, so the cap will have surface measure ")#tao-math("{\\sim \\left|x\\right|^{-(d-1)/2}}", block: false)#text(", which leads to the prediction ")#link(<tao-720f6ac947ab8e448c3a>)[#text("(7)")]#text(". We combine ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(6)")]#text(", ")#link(<tao-720f6ac947ab8e448c3a>)[#text("(7)")]#text(" into the unified estimate ")#metadata(none) <tao-f8d0e595bebdb641eb7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(d\\sigma)^\\vee(x) \\lesssim_d \\langle x\\rangle^{-(d-1)/2},")]]

#text(" where the “Japanese bracket” ")#mi("{\\langle x\\rangle}")#text(" is defined as ")#tao-math("{\\langle x \\rangle := (1+\\left|x\\right|^2)^{1/2}}", block: false)#text(". Since ")#mi("{\\langle x \\rangle^{-\\alpha}}")#text(" lies in ")#mi("{L^p({\\bf R}^d)}")#text(" precisely when ")#mi("{p > \\frac{d}{\\alpha}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("(d\\sigma)^\\vee \\in L^q({\\bf R}^d) \\text{ iff } q > \\frac{d}{(d-1)/2}.")]]

#text("Applying ")#link("https://en.wikipedia.org/wiki/Young%27s_convolution_inequality")[#text("Young’s convolution inequality")]#text(", we conclude (after some arithmetic) that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f * (d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("whenever ")#mi("{1 \\leq p < \\frac{4d}{3d+1}}")#text(", and the claim now follows from ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(5)")]#text(" and Hölder’s inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" By using the ")#link("https://en.wikipedia.org/wiki/Sobolev_inequality#Hardy%E2%80%93Littlewood%E2%80%93Sobolev_lemma")[#text("Hardy-Littlewood-Sobolev inequality")]#text(" in place of Young’s convolution inequality, one can also establish this result for ")#mi("{p = \\frac{4d}{3d+1}}")#text(".")
]

#text("Motivated by this result, given any Radon measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^d}")#text(" and any exponents ")#mi("{1 \\leq p,q \\leq \\infty}")#text(", we use ")#mi("{R_\\mu(p \\rightarrow q)}")#text(" to denote the claim that the ")#emph[#text("restriction estimate")]#text(" ")#metadata(none) <tao-05a9bf223fedf80a9d0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d, \\mu)} \\lesssim_{d,p,q,\\mu} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text(" for all Schwartz functions ")#mi("{f}")#text("; if ")#mi("{S}")#text(" is a ")#mi("{k}")#text("-dimensional submanifold of ")#mi("{{\\bf R}^d}")#text(" (possibly with boundary), we write ")#mi("{R_S(p \\rightarrow q)}")#text(" for ")#mi("{R_\\mu(p \\rightarrow q)}")#text(" where ")#mi("{\\mu}")#text(" is the ")#mi("{k}")#text("-dimensional surface measure on ")#mi("{S}")#text(". Thus, for instance, we trivially always have ")#mi("{R_S(1 \\rightarrow \\infty)}")#text(", while Theorem ")#link(<tao-9a4cf4b8b0f50f4b8634>)[#text("1")]#text(" asserts that ")#mi("{R_{S^{d-1}}(p \\rightarrow 2)}")#text(" holds whenever ")#mi("{1 \\leq p < \\frac{4d}{3d+1}}")#text(". We will not give a comprehensive survey of restriction theory in these notes, but instead focus on some model results that showcase some of the basic techniques in the field. (I have ")#link("https://arxiv.org/abs/math/0311181")[#text("a more detailed survey on this topic from 2003")]#text(", but it is somewhat out of date.)")#linebreak()#text(" ")#metadata(none) <tao-969e343d0b6cc7510bce>

#heading(level: 1)[#strong[#text(" — 1. Necessary conditions — ")]]

#text("It is relatively easy to find necessary conditions for a restriction estimate ")#mi("{R_S(p \\rightarrow q)}")#text(" to hold, as one simply needs to test the estimate ")#link(<tao-05a9bf223fedf80a9d0d>)[#text("(9)")]#text(" against a suitable family of examples. We begin with the simplest case ")#mi("{S = {\\bf R}^d}")#text(". The Hausdorff-Young inequality ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(4)")]#text(" tells us that we have the restriction estimate ")#mi("{R_{{\\bf R}^d}(p \\rightarrow p^{\\prime})}")#text(" whenever ")#mi("{1 \\leq p \\leq 2}")#text(". These are the only restriction estimates available:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Restriction to ")#mi("{{\\bf R}^d}")#text(")")]#text(" ")#metadata(none) <tao-c3ca7d8dca22f4506818>#text(" Suppose that ")#mi("{1 \\leq p,q \\leq \\infty}")#text(" are such that ")#mi("{R_{{\\bf R}^d}(p \\rightarrow q)}")#text(" holds. Then ")#mi("{q=p^{\\prime}}")#text(" and ")#mi("{1 \\leq p \\leq 2}")#text(".")
]

#text("We first establish the necessity of the duality condition ")#mi("{q=p^{\\prime}}")#text(". This is easily shown, but we will demonstrate it in three slightly different ways in order to illustrate different perspectives. The first perspective is from scale invariance. Suppose that the estimate ")#mi("{R_{{\\bf R}^d}(p \\rightarrow q)}")#text(" holds, thus one has ")#metadata(none) <tao-43e5f5bd9ae46ba20b1e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text(" for all Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". For any scaling factor ")#mi("{\\lambda>0}")#text(", we define the scaled version ")#mi("{f_\\lambda \\in {\\mathcal S}({\\bf R}^d)}")#text(" of ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f_\\lambda(x) := f(x/\\lambda).")]]

#text("Applying ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" with ")#mi("{f}")#text(" replaced by ")#mi("{f_\\lambda}")#text(", we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f_\\lambda \\right\\|_{L^q({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\|f_\\lambda\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("From change of variables, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_\\lambda\\right\\|_{L^p({\\bf R}^d)} = \\lambda^{d/p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and from the definition of Fourier transform and further change of variables we have")

#align(center)[#tao-fit-display[#mitex("\\hat f_\\lambda(\\xi) = \\lambda^d \\hat f(\\lambda \\xi)")]]

#text("so that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\hat f_\\lambda\\right\\|_{L^q({\\bf R}^d)} = \\lambda^{d-d/q} \\left\\|\\hat f\\right\\|_{L^q({\\bf R}^d)};", block: true)]]

#text("combining all these estimates and rearranging, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d)} \\lesssim_{d,p,q} \\lambda^{d/p+d/q-d} \\left\\|f \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("If ")#mi("{d/p+d/q-d}")#text(" is non-zero, then by sending ")#mi("{\\lambda}")#text(" either to zero or infinity we conclude that ")#tao-math("{\\left\\| \\hat f\\right\\|_{L^q({\\bf R}^d)}=0}", block: false)#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(", which is absurd. Thus we must have the necessary condition ")#mi("{d/p+d/q-d=0}")#text(", or equivalently that ")#mi("{q=p^{\\prime}}")#text(".")#linebreak()#text(" We now establish the same necessary condition from the perspective of ")#link("https://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(", which one can view as an abstraction of scale invariance arguments. We give the spatial variable a unit ")#mi("{L}")#text(" of length. It is not so important what units we assign to the range of the function ")#mi("{f}")#text(" (it will cancel out of both sides), but let us make it dimensionless for sake of discussion. Then the ")#mi("{L^q}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p({\\bf R}^d)} = (\\int_{{\\bf R}^d} \\left|f(x)\\right|^p\\ dx)^{1/p}", block: true)]]

#text("will have the units of ")#mi("{L^{d/q}}")#text(", because integration against ")#mi("{d}")#text("-dimensional Lebesgue measure will have the units of ")#mi("{L^d}")#text(" (note this conclusion can also be justified in the limiting case ")#mi("{p=\\infty}")#text("). For similar reasons, the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\int_{{\\bf R}^d} f(x) e^{-2\\pi i x \\cdot \\xi}\\ dx")]]

#text("will have the units of ")#mi("{L^d}")#text("; also, the frequency variable ")#mi("{\\xi}")#text(" must have the units of ")#mi("{L^{-1}}")#text(" in order to make the exponent ")#mi("{-2\\pi i x \\cdot \\xi}")#text(" appearing in the exponential dimensionless. As such, the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d)} = (\\int_{{\\bf R}^d} \\left|\\hat f(\\xi)\\right|^q\\ d\\xi)^{1/q}", block: true)]]

#text("has units ")#mi("{L^d (L^{-1})^{d/q} = L^{d-d/q}}")#text(". In order for the estimate ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" to be dimensionally consistent, we must therefore have ")#mi("{d-d/q = d/p}")#text(", or equivalently that ")#mi("{q=p^{\\prime}}")#text(".")#linebreak()#text(" Finally, we establish the necessary condition ")#mi("{q=p^{\\prime}}")#text(" once again using the example of a rescaled bump function, which is basically the same as the first approach but with ")#mi("{f}")#text(" replaced by a bump function. We will argue at a slightly heuristic level, but it is not difficult to make the arguments below rigorous and we leave this as an exercise to the reader. Given a length scale ")#mi("{R}")#text(", let ")#mi("{\\varphi_R}")#text(" be a bump function adapted to the ball ")#tao-math("{B(0,R) := \\{ x \\in {\\bf R}^d: \\left|x\\right| \\leq R \\}}", block: false)#text(" of radius ")#mi("{R}")#text(" around the origin, thus ")#mi("{\\varphi_R(x) = \\varphi(x/R)}")#text(" where ")#mi("{\\varphi \\in C^\\infty_c({\\bf R}^d)}")#text(" is some fixed test function ")#mi("{\\varphi}")#text(" supported on ")#mi("{B(0,1)}")#text(". We refer to this as a bump function ")#emph[#text("adapted")]#text(" to ")#mi("{B(0,R)}")#text("; more generally, given an ellipsoid (or other convex region, such as a cube, tube, or disk) ")#mi("{B}")#text(", we define a bump function adapted to ")#mi("{B}")#text(" to be a function of the form ")#mi("{x \\mapsto \\varphi(T^{-1} x)}")#text(", where ")#mi("{T}")#text(" is an affine map from ")#mi("{B(0,1)}")#text(" (or other fixed convex region) to ")#mi("{B}")#text(" and ")#mi("{\\varphi}")#text(" is a bump function with all derivatives uniformly bounded. As long as ")#mi("{\\varphi}")#text(" is non-zero, the norm ")#tao-math("{\\left\\| \\varphi_R \\right\\|_{L^p({\\bf R}^d)}}", block: false)#text(" is comparable to ")#mi("{R^{d/p}}")#text(" (up to constant factors that can depend on ")#mi("{d,p,\\varphi}")#text(" but are independent of ")#mi("{R}")#text("). The uncertainty principle then predicts that the Fourier transform ")#mi("{\\widehat{\\varphi_R}}")#text(" will be concentrated in the dual ball ")#mi("{B(0,1/R)}")#text(", and within this ball (or perhaps a slightly smaller version of this ball) ")#mi("{\\widehat{\\varphi_R}(\\xi) = \\int_{{\\bf R}^d} \\varphi_R(x) e^{-2\\pi ix \\cdot \\xi}\\ dx}")#text(" would be expected to be of size comparable to ")#mi("{R^{d}}")#text(" (the phase ")#mi("{x \\cdot \\xi}")#text(" does not vary enough to cause significant cancellation). From this we expect ")#tao-math("{\\left\\| \\widehat{\\varphi_R} \\right\\|_{L^q({\\bf R}^d)}}", block: false)#text(" to be comparable in size to ")#mi("{R^{d-d/q}}")#text(". If ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" held, we would then have")

#align(center)[#tao-fit-display[#mitex("R^{d-d/q} \\lesssim_{d,p,q,\\varphi} R^{d/p}")]]

#text("for all ")#mi("{R>0}")#text(", which is only possible if ")#mi("{d-d/q = d/p}")#text(", or equivalently ")#mi("{q=p^{\\prime}}")#text(".")#linebreak()#text(" Now we turn to the other necessary condition ")#mi("{p \\leq 2}")#text(". Here one does not use scaling considerations; instead, it is more convenient to work with randomised examples. A useful tool in this regard is ")#link("https://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(", which encodes the ")#emph[#text("square root cancellation")]#text(" heuristic that a sum ")#mi("{\\sum_{j=1}^n f_j}")#text(" of numbers or functions ")#mi("{f_j}")#text(" with randomised signs (or phases) should have magnitude roughly comparable to the ")#emph[#text("square function")]#text(" ")#tao-math("{(\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2}}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Khintchine’s inequality)")]#text(" ")#metadata(none) <tao-2dd725365e5cff997505>#text(" Let ")#mi("{0 < p < \\infty}")#text(", and let ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_n \\in \\{-1,+1\\}}")#text(" be independent random variables that each take the values ")#mi("{-1,+1}")#text(" with an equal probability of ")#mi("{1/2}")#text(".")

#list(
[#text("(i) For any complex numbers ")#mi("{z_1,\\dots,z_n}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j z_j\\right|^p)^{1/p} \\sim_p (\\sum_{j=1}^n \\left|z_j\\right|^2)^{1/2}.", block: true)]]],
[#text("(ii) For any functions ")#mi("{f_1,\\dots,f_n \\in L^p(X,\\mu)}")#text(" on a measure space ")#mi("{(X,\\mu)}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left\\|\\sum_{j=1}^n \\epsilon_j f_j\\right\\|_{L^p(X,\\mu)}^p)^{1/p} \\sim_p \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p(X,\\mu)}.", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" We begin with (i). By taking real and imaginary parts we may assume without loss of generality that the ")#mi("{z_j}")#text(" are all real, then by normalisation it suffices to show the upper bound ")#metadata(none) <tao-aee610558292023758a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("{\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^p \\lesssim_p 1", block: true)]]

#text(" and the lower bound ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^p \\gtrsim_p 1", block: true)]]

#text(" for all ")#mi("{0 < p < \\infty}")#text(", whenever ")#mi("{x_1,\\dots,x_n}")#text(" are real numbers with ")#mi("{\\sum_{j=1}^n x_j^2=1}")#text(".")#linebreak()#text(" When ")#mi("{p=2}")#text(" the upper and lower bounds follow by direct calculation (in fact we have equality ")#tao-math("{ {\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^2 = 1}", block: false)#text(" in this case). By Hölder’s inequality, this yields the upper bound for ")#mi("{p \\leq 2}")#text(" and the lower bound for ")#mi("{p>2}")#text(". To handle the remaining cases of ")#link(<tao-aee610558292023758a4>)[#text("(11)")]#text(" it is convenient to use the exponential moment method. Let ")#mi("{\\lambda>0}")#text(" be an arbitrary threshold, and consider the upper tail probability")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sum_{j=1}^n \\epsilon_j x_j \\geq \\lambda ).")]]

#text("For any ")#mi("{t>0}")#text(", we see from Markov’s inequality that this quantity is less than or equal to")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda} {\\bf E} \\exp( t \\sum_{j=1}^n \\epsilon_j x_j ).")]]

#text("The expectation here can be computed to equal")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp( t \\sum_{j=1}^n \\epsilon_j x_j ) = \\prod_{j=1}^n {\\bf E} \\exp( \\epsilon_j t x_j ) = \\prod_{j=1}^n \\cosh(tx_j).")]]

#text("By comparing power series we see that ")#mi("{\\cosh(y) \\leq \\exp( y^2/2)}")#text(" for any real ")#mi("{y}")#text(", hence by the normalisation ")#mi("{\\sum_{j=1}^n x_j^2=1}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sum_{j=1}^n \\epsilon_j x_j \\geq \\lambda ) \\leq e^{-t\\lambda} e^{t^2/2}.")]]

#text("If we set ")#mi("{t := \\lambda}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sum_{j=1}^n \\epsilon_j x_j \\geq \\lambda ) \\leq e^{-\\lambda^2/2};")]]

#text("since the random variable ")#mi("{\\sum_{j=1}^n \\epsilon_j x_j}")#text(" is symmetric around the origin, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right| \\geq \\lambda ) \\leq 2e^{-\\lambda^2/2}.", block: true)]]

#text("From the Fubini-Tonelli theorem we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right|^p = \\int_0^\\infty p \\lambda^{p-1} {\\bf P}(\\left|X\\right| \\geq \\lambda)\\ d\\lambda", block: true)]]

#text("and this then gives the upper bound ")#link(<tao-aee610558292023758a4>)[#text("(11)")]#text(" for any ")#mi("{2 < p < \\infty}")#text(". The claim ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(12)")]#text(" for ")#mi("{0 < p < 2}")#text(" then follows from this, Hölder’s inequality (applied in reverse), and the fact that ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(12)")]#text(" was already established for ")#mi("{p=2}")#text(".")#linebreak()#text(" To prove (ii), observe from (i) that for every ")#mi("{x \\in X}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j f_j(x)\\right|^p \\sim_p (\\sum_{j=1}^n \\left|f_j(x)\\right|^2)^{p/2};", block: true)]]

#text("integrating in ")#mi("{X}")#text(" and applying the Fubini-Tonelli theorem, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" For any ")#mi("{p>0}")#text(", let ")#mi("{C_p}")#text(" denote the ")#mi("{p^{th}}")#text(" root of the implied constant in ")#link(<tao-aee610558292023758a4>)[#text("(11)")]#text(", that is to say")

#align(center)[#tao-fit-display[#tao-math("C_p = \\sup ({\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^p)^{1/p}", block: true)]]

#text("where the supremum is over all ")#mi("{n}")#text(" and all reals ")#mi("{x_1,\\dots,x_n}")#text(" with ")#mi("{\\sum_{j=1}^n x_j^2=1}")#text(".")

#list(
[#text("(i) If one analyzes the argument used above to prove ")#link(<tao-aee610558292023758a4>)[#text("(11)")]#text(" carefully, one obtains an upper bound for ")#mi("{C_p}")#text(". How does this upper bound depend on ")#mi("{p}")#text(" asymptotically in the limit ")#mi("{p \\rightarrow \\infty}")#text("?")],
[#text("(ii) Establish ")#link(<tao-aee610558292023758a4>)[#text("(11)")]#text(" for the case of even integers ")#mi("{p}")#text(" by direct expansion of the left-hand side and some combinatorial calculation. This gives another upper bound on ")#mi("{C_p}")#text(". How does this upper bound compare with that in (i) in the limit ")#mi("{p \\rightarrow \\infty}")#text(".")],
[#text("(iii) Establish a matching lower bound (up to absolute constants) for the quantity ")#mi("{C_p}")#text(" in the limit ")#mi("{p \\rightarrow \\infty}")#text(".")]
)
]

#text("Now we show that the estimate ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" fails in the large ")#mi("{p}")#text(" regime ")#mi("{p>2}")#text(", even when ")#mi("{q=p^{\\prime}}")#text(". Here, the idea is to have ")#mi("{f}")#text(" “spread out” in physical space (in order to keep the ")#mi("{L^p}")#text(" norm low), and also having ")#mi("{\\hat f}")#text(" somewhat spread out in frequency space (in order to prevent the ")#mi("{L^{p^{\\prime}}}")#text(" norm from dropping too much). We use the probabilistic method (constructing a random counterexample rather than a deterministic one) in order to exploit Khintchine’s inequality. Let ")#mi("{\\varphi}")#text(" be a non-zero bump function supported on (say) the unit ball ")#mi("{B(0,1)}")#text(", and consider a (random) function of the form")

#align(center)[#tao-fit-display[#mitex("f(x) = \\sum_{j=1}^n \\epsilon_j \\varphi(x-x_j)")]]

#text("where ")#mi("{\\epsilon_1,\\dots,\\epsilon_n}")#text(" are the random signs from Lemma ")#link(<tao-2dd725365e5cff997505>)[#text("4")]#text(", and ")#mi("{x_1,\\dots,x_n \\in {\\bf R}^d}")#text(" are sufficiently separated points in ")#mi("{{\\bf R}^d}")#text(" (all we need for this construction is that ")#tao-math("{\\left|x_j-x_k\\right| \\geq 2}", block: false)#text(" for all ")#mi("{1 \\leq j < k \\leq n}")#text("); thus ")#mi("{f}")#text(" is the random sum of bump functions adapted to disjoint balls ")#mi("{B(x_j,1)}")#text(". In particular, the summands here have disjoint supports and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{L^p({\\bf R}^d)} \\sim_{p,\\varphi} n^{1/p}", block: true)]]

#text("(note that the signs ")#mi("{\\epsilon_j}")#text(" have no effect on the magnitude of ")#mi("{f}")#text("). If ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" were true, this would give the (deterministic) bound ")#metadata(none) <tao-d7fdf501dcccb6c80b0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| \\hat f \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{p,\\varphi,d} n^{1/p}.", block: true)]]

#text(" On the other hand, the Fourier transform of ")#mi("{f}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\sum_{j=1}^n \\epsilon_j e^{2\\pi i x_j \\cdot \\xi} \\hat \\varphi(\\xi),")]]

#text("so by Khintchine’s inequality")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left\\| \\hat f\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)}^{p^{\\prime}})^{1/p^{\\prime}} \\sim_{p,d} \\left\\| (\\sum_{j=1}^n \\left|e^{2\\pi i x_j \\cdot \\xi} \\hat \\varphi(\\xi)\\right|^2)^{1/2} \\right\\|_{L^{p^{\\prime}}_\\xi({\\bf R}^d)}.", block: true)]]

#text("The phases ")#mi("{e^{2\\pi i x_j \\cdot \\xi}}")#text(" can be deleted, and ")#mi("{\\hat \\varphi}")#text(" is not identically zero, so one arrives at")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left\\| \\hat f\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)}^{p^{\\prime}})^{1/p^{\\prime}} \\sim_{p,d,\\varphi} n^{1/2}.", block: true)]]

#text("Comparing this with ")#link(<tao-d7fdf501dcccb6c80b0b>)[#text("(13)")]#text(" and sending ")#mi("{n \\rightarrow \\infty}")#text(", we obtain a contradiction if ")#mi("{p>2}")#text(". This completes the proof of Proposition ")#link(<tao-c3ca7d8dca22f4506818>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Find a deterministic construction that explains why the estimate ")#link(<tao-43e5f5bd9ae46ba20b1e>)[#text("(10)")]#text(" fails when ")#mi("{p>2}")#text(" and ")#mi("{q=p^{\\prime}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Marcinkiewicz-Zygmund theorem)")]#text(" Let ")#mi("{(X,\\mu), (Y,\\nu)}")#text(" be measure spaces, let ")#mi("{0 < q \\leq p < \\infty}")#text(", and suppose ")#mi("{T: L^p(X,\\mu) \\rightarrow L^q(Y,\\nu)}")#text(" is a bounded linear operator with operator norm ")#tao-math("{\\left\\|T\\right\\|}", block: false)#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{\\alpha \\in A} \\left|Tf_\\alpha\\right|^2)^{1/2} \\right\\|_{L^q(Y,\\nu)} \\lesssim_{p,q} \\left\\|T\\right\\| \\left\\| (\\sum_{\\alpha \\in A} \\left|f_\\alpha\\right|^2)^{1/2} \\right\\|_{L^p(X,\\mu)}", block: true)]]

#text("for any at most countable index set ")#mi("{A}")#text(" and any functions ")#mi("{f_\\alpha \\in L^p(X,\\mu)}")#text(". Informally, this result asserts that if a linear operator ")#mi("{T}")#text(" is bounded from scalar-valued ")#mi("{L^p}")#text(" functions to scalar-valued ")#mi("{L^q}")#text(" functions, then it is automatically bounded from ")#emph[#text("vector-valued")]#text(" ")#mi("{L^p}")#text(" functions to vector-valued functions. (By using gaussians instead of random sums, one can even obtain this bound with the implied constant equal to ")#mi("{1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{U}")#text(" be a bounded open subset of ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{1 \\leq p,q \\leq \\infty}")#text(". Show that ")#mi("{R_U(p \\rightarrow q)}")#text(" holds if and only if ")#mi("{1 \\leq p \\leq 2}")#text(" and ")#mi("{q \\leq p^{\\prime}}")#text(". (Note: in order to use either the scale invariance argument or the dimensional analysis argument to get the condition ")#mi("{q \\leq p^{\\prime}}")#text(", one should replace ")#mi("{U}")#text(" with something like a ball ")#mi("{B(0,r)}")#text(" of some radius ")#mi("{r>0}")#text(", and allow the estimates to depend on ")#mi("{r}")#text(".)")
]

#text("Now we study the restriction problem for two model hypersurfaces:")

#list(
[#text("(i) The ")#emph[#text("paraboloid")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\Sigma := \\{ (\\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2): \\xi^{\\prime} \\in {\\bf R}^{d-1} \\}", block: true)]]

#metadata(none) <tao-6901b6412940f5d09525>#text(" equipped with the measure ")#mi("{\\mu}")#text(" induced from Lebesgue measure ")#mi("{d\\xi^{\\prime}}")#text(" in the horizontal variables ")#mi("{{\\bf R}^{d-1}}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\int_\\Sigma f\\ d\\mu = \\int_{{\\bf R}^{d-1}} f( \\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2)\\ d\\xi^{\\prime}", block: true)]]

#text("(note this is ")#emph[#text("not")]#text(" the same as surface measure on ")#mi("{\\Sigma}")#text(", although it is mutually absolutely continuous with this measure).")],
[#text("(ii) The ")#emph[#text("sphere")]#text(" ")#tao-math("{S^{d-1} = \\{ \\xi \\in {\\bf R}^d: \\left|\\xi\\right| = 1 \\}}", block: false)#text(".")]
)

#text("These two hypersurfaces differ from each other in one important respect: the paraboloid is non-compact, while the sphere is compact. Aside from that, though, they behave very similarly; they are both quadric hypersurfaces with everywhere positive curvature. Furthermore, they are also very highly symmetric surfaces. The sphere of course enjoys the rotation symmetry under the orthogonal group ")#mi("{O(d)}")#text(". At first glance the paraboloid ")#mi("{\\Sigma}")#text(" only enjoys symmetry under the smaller orthogonal group ")#mi("{O(d-1)}")#text(" that rotates the ")#mi("{\\xi^{\\prime}}")#text(" variable (leaving the final coordinate ")#mi("{\\xi_d}")#text(" unchanged), but it also has a family of ")#link("https://en.wikipedia.org/wiki/Galilean_transformation")[#text("Galilean symmetries")]

#align(center)[#tao-fit-display[#tao-math("(\\xi^{\\prime}, \\xi_d) \\mapsto (\\xi^{\\prime} + \\xi_0, \\xi_d + 2 \\xi^{\\prime} \\cdot \\xi_0 + \\left|\\xi_0\\right|^2 )", block: true)]]

#text("for any ")#mi("{\\xi_0 \\in {\\bf R}^{d-1}}")#text(", which preserves ")#mi("{\\Sigma}")#text(" (and also can be seen to preserve the measure ")#mi("{\\mu}")#text(", since the horizontal variable ")#mi("{\\xi^{\\prime}}")#text(" is simply translated by ")#mi("{\\xi_0}")#text("). Furthermore, the paraboloid also enjoys a ")#emph[#text("parabolic scaling symmetry")]

#align(center)[#tao-fit-display[#mitex("(\\xi^{\\prime}, \\xi_d) \\mapsto (\\lambda \\xi^{\\prime}, \\lambda^2 \\xi_d)")]]

#text("for any ")#mi("{\\lambda > 0}")#text(", for which the sphere does not have an exact analogue (though morally Taylor expansion suggests that the sphere “behaves like” the paraboloid at small scales, or equivalently that certain parabolically rescaled copies of the sphere behave like the paraboloid in the limit). The following exercise exploits these symmetries:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-0599b22abfb1eb4db9c1>

#list(
[#text("(i) Let ")#mi("{V}")#text(" be a non-empty open subset of ")#mi("{S^{d-1}}")#text(", and let ")#mi("{1 \\leq p,q \\leq \\infty}")#text(". Show that ")#mi("{R_{V}(p \\rightarrow q)}")#text(" holds if and only if ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds.")],
[#text("(ii) Let ")#mi("{V_1, V_2}")#text(" be bounded non-empty open subsets of ")#mi("{\\Sigma}")#text(" (endowed with the restriction of ")#mi("{\\mu}")#text(" to ")#mi("{V_1,V_2}")#text("), and let ")#mi("{1 \\leq p,q \\leq \\infty}")#text(". Show that ")#mi("{R_{V_1}(p \\rightarrow q)}")#text(" holds if and only if ")#mi("{R_{V_2}(p \\rightarrow q)}")#text(" holds.")],
[#text("(iii) Suppose that ")#mi("{1 \\leq p,q \\leq \\infty}")#text(" are such that ")#mi("{R_\\Sigma(p \\rightarrow q)}")#text(" holds. Show that ")#mi("{q = \\frac{d-1}{d+1} p^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" Any of the three methods of scale invariance, dimensional analysis, or rescaled bump functions will work here.)")],
[#text("(iv) Suppose that ")#mi("{1 \\leq p,q \\leq \\infty}")#text(" are such that ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds. Show that ")#mi("{q \\leq \\frac{d-1}{d+1} p^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" The same three methods still work, but some will be easier to pull off than others.)")],
[#text("(v) Suppose that ")#mi("{1 \\leq p,q \\leq \\infty}")#text(" are such that ")#mi("{R_V(p \\rightarrow q)}")#text(" holds for some bounded non-empty open subset ")#mi("{V}")#text(" of ")#mi("{\\Sigma}")#text(", and that ")#mi("{q = \\frac{d-1}{d+1} p^{\\prime}}")#text(". Conclude that ")#mi("{R_\\Sigma(p \\rightarrow q)}")#text(" holds.")],
[#text("(vi) Suppose that ")#mi("{1 \\leq p,q \\leq \\infty}")#text(" are such that ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds, and that ")#mi("{q = \\frac{d-1}{d+1} p^{\\prime}}")#text(". Conclude that ")#mi("{R_\\Sigma(p \\rightarrow q)}")#text(" holds.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (No non-trivial restriction estimates for flat hypersurfaces)")]#text(" Let ")#mi("{S}")#text(" be an open non-empty subset of a hyperplane in ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{1 \\leq p,q \\leq \\infty}")#text(". Show that ")#mi("{R_S(p \\rightarrow q)}")#text(" can only hold when ")#mi("{p=1}")#text(".")
]

#text("To obtain a further necessary condition on the restriction estimates ")#mi("{R_\\Sigma(p \\rightarrow q)}")#text(" or ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holding, it is convenient to dualise the restriction estimate to an ")#emph[#text("extension estimate")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Duality)")]#text(" ")#metadata(none) <tao-8ccf2f9e9cc41e7ad5bf>#text(" Let ")#mi("{\\mu}")#text(" be a Radon measure on ")#mi("{{\\bf R}^d}")#text(", let ")#mi("{1 \\leq p,q \\leq \\infty}")#text(", and let ")#mi("{A > 0}")#text(". Show that the following claims are equivalent:")

#list(
[#text("(i) (Restriction estimate) One has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d,\\mu)} \\leq A \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(".")],
[#text("(ii) (Extension estimate) one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g\\ d\\mu)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\leq A \\left\\| g\\right\\|_{L^{q^{\\prime}}({\\bf R}^d, \\mu)}", block: true)]]

#text("for all ")#mi("{g \\in C^\\infty_c({\\bf R}^d)}")#text(", where the inverse Fourier transform ")#mi("{(g\\ d\\mu)^\\vee: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" of the finite measure ")#mi("{g\\ d\\mu}")#text(" is defined by the formula ")#metadata(none) <tao-a303517c07f1d0005ae9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("(g\\ d\\mu)^\\vee(x) := \\int_{{\\bf R}^d} g(\\xi) e^{2\\pi i x \\cdot \\xi}\\ d\\mu(\\xi).")]]

]
)
]

#text("This gives a further necessary condition as follows. Suppose for instance that ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds; then by the above exercise, one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g\\ d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\| g\\right\\|_{L^{q^{\\prime}}(S^{d-1},\\sigma)}", block: true)]]

#text("for all ")#mi("{g \\in C^\\infty_c({\\bf R}^d)}")#text(". In particular, ")#mi("{(g\\ d\\sigma)^\\vee \\in L^{p^{\\prime}}({\\bf R}^d)}")#text(". However, we have the following stationary phase computation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-139d544b821b13ebea14>#text(" If ")#mi("{g \\in C^\\infty_c({\\bf R}^d)}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("(g\\ d\\sigma)^\\vee (x)  & = \\frac{1}{\\left|x\\right|^{\\frac{d-1}{2}}} ( c_+ g(\\frac{x}{\\left|x\\right|}) e^{2\\pi i \\left|x\\right|} + c_- g(-\\frac{x}{\\left|x\\right|}) e^{-2\\pi i \\left|x\\right|})", block: true)



#tao-math(" & + O_{g,d}( \\left|x\\right|^{-\\frac{d}{2}} )", block: true)
]

#text("for all ")#tao-math("{\\left|x\\right| \\geq 1}", block: false)#text(" and some non-zero constants ")#mi("{c_+, c_-}")#text(" depending only on ")#mi("{d}")#text(". Conclude that the estimate ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" can only hold if ")#mi("{p < \\frac{2d}{d+1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that the estimate ")#mi("{R_\\Sigma(p \\rightarrow q)}")#text(" can only hold if ")#mi("{p < \\frac{2d}{d+1}}")#text(". (")#emph[#text("Hint:")]#text(" one can explicitly test ")#link(<tao-a303517c07f1d0005ae9>)[#text("(15)")]#text(" when ")#mi("{g}")#text(" is a gaussian; the fact that gaussians are not, strictly speaking, compactly supported can be dealt with by a limiting argument.)")
]

#text("It is conjectured that the necessary conditions claimed above are sufficient. Namely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 14 (Restriction conjecture for the sphere)")]#text(" ")#metadata(none) <tao-0f58b78bc54e0c3e5556>#text(" Let ")#mi("{d \\geq 2}")#text(". Then we have ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" whenever ")#mi("{p < \\frac{2d}{d+1}}")#text(" and ")#mi("{q \\leq \\frac{d-1}{d+1} p^{\\prime}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 15 (Restriction conjecture for the paraboloid)")]#text(" ")#metadata(none) <tao-910cd9c0fbf44ca52706>#text(" Let ")#mi("{d \\geq 2}")#text(". Then we have ")#mi("{R_{\\Sigma}(p \\rightarrow q)}")#text(" whenever ")#mi("{p < \\frac{2d}{d+1}}")#text(" and ")#mi("{q = \\frac{d-1}{d+1} p^{\\prime}}")#text(".")
]

#text("It is also conjectured that Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(" holds if one replaces the sphere ")#mi("{S^{d-1}}")#text(" by any bounded open non-empty subset of the paraboloid ")#mi("{\\Sigma}")#text(".")#linebreak()#text(" The current status of these conjectures is that they are fully solved in the two-dimensional case ")#mi("{d=2}")#text(" (as we will see later in these notes) and partially resolved in higher dimensions. For instance, in ")#mi("{d=3}")#text(" one of the strongest results currently is ")#link("https://arxiv.org/abs/1802.04312")[#text("due to Hong Wang")]#text(", who established ")#mi("{R_{U}(p \\rightarrow 1)}")#text(" for ")#mi("{U}")#text(" a bounded open non-empty subset of ")#mi("{\\Sigma}")#text(" when ")#mi("{p^{\\prime} > 3 + \\frac{1}{13}}")#text(" (conjecturally this should hold for all ")#mi("{p^{\\prime}>3}")#text("); for higher dimensions see ")#link("https://arxiv.org/abs/1807.10940")[#text("this paper of Hickman and Rogers")]#text(" for the most recent results.")#linebreak()#text(" We close this section with an important connection between the restriction conjecture and another conjecture known as the ")#emph[#text("Kakeya maximal function conjecture")]#text(". To describe this connection, we first give an alternate derivation of the necessary condition ")#mi("{q \\leq \\frac{d-1}{d+1} p^{\\prime}}")#text(" in Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(", using a basic example known as the ")#emph[#text("Knapp example")]#text(" (as described for instance in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=512086")[#text("this article")]#text(" of Strichartz).")#linebreak()#text(" Let ")#mi("{\\kappa}")#text(" be a spherical cap in ")#mi("{S^{d-1}}")#text(" of some small radius ")#mi("{\\delta>0}")#text(", thus ")#mi("{\\kappa = S^{d-1} \\cap B(\\omega_0,\\delta)}")#text(" for some ")#mi("{\\omega_0 \\in S^{d-1}}")#text(". Let ")#mi("{g \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function adapted to this cap, say ")#mi("{g(\\xi) = \\varphi( \\frac{\\xi-\\omega_0}{\\delta})}")#text(" where ")#mi("{\\varphi}")#text(" is a fixed non-zero bump function supported on ")#mi("{B(0,1)}")#text(". We refer to ")#mi("{g}")#text(" as a ")#emph[#text("Knapp example")]#text(" at frequency ")#mi("{\\omega_0}")#text(" (and spatially centred at the origin). The cap ")#mi("{\\kappa}")#text(" (or any slightly smaller version of ")#mi("{\\kappa}")#text(") has surface measure ")#mi("{\\sim_d \\delta^{d-1}}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g\\right\\|_{L^{q^{\\prime}}(S^{d-1})} \\sim_{d,\\varphi,q} \\delta^{(d-1)/q^{\\prime}}", block: true)]]

#text("for any ")#mi("{1 \\leq q \\leq \\infty}")#text(". We then apply the extension operator to ")#mi("{g}")#text(": ")#metadata(none) <tao-0ad081759c63452e407b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("(g d\\sigma)^\\vee(x) = \\int_{\\kappa} e^{2\\pi i x \\cdot \\omega} \\varphi( \\frac{\\omega-\\omega_0}{\\delta})\\ d\\sigma(\\omega).")]]

#text(" The integrand is only non-vanishing if ")#mi("{\\omega = \\omega_0 + O(\\delta)}")#text("; since also from the cosine rule we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\omega-\\omega_0\\right|^2 = \\left|\\omega\\right|^2 + \\left|\\omega_0\\right|^2 - 2 \\omega \\cdot \\omega_0 = 2 - 2 \\omega \\cdot \\omega_0", block: true)]]

#text("we also have ")#mi("{\\omega \\cdot \\omega_0 = 1 + O(\\delta^2)}")#text(". Thus, if ")#mi("{x}")#text(" lies in the tube")

#align(center)[#tao-fit-display[#tao-math("T^{c/\\delta \\times (c/\\delta)^2}_{\\omega_0,0} := \\{ x \\in {\\bf R}^d: \\left|x \\cdot \\omega_0\\right| \\leq (c/\\delta)^2; \\left|x - (x \\cdot \\omega_0) \\omega_0\\right| \\leq c/\\delta \\}", block: true)]]

#text("for a sufficiently small absolute constant ")#mi("{c>0}")#text(", then the phase ")#mi("{e^{2\\pi i x \\cdot (\\omega-\\omega_0)}}")#text(" has real part ")#mi("{\\gg 1}")#text(". If we set ")#mi("{\\varphi}")#text(" to be non-negative and not identically zero, and factor out the constant phase ")#mi("{e^{2\\pi i x \\cdot \\omega_0}}")#text(" from the integral in ")#link(<tao-0ad081759c63452e407b>)[#text("(16)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|(g d\\sigma)^\\vee(x)\\right| \\gtrsim_{d,\\varphi} \\delta^{d-1}", block: true)]]

#text("for ")#mi("{x \\in T^{c/\\delta \\times (c/\\delta)^2}_{\\omega_0,0}}")#text(". Since the tube ")#mi("{T^{c/\\delta \\times (c/\\delta)^2}_{\\omega_0,0}}")#text(" has dimensions ")#mi("{c/\\delta \\times (c/\\delta)^2}")#text(", its volume is")

#align(center)[#tao-fit-display[#mitex("\\sim_d (c/\\delta)^2 \\times (c/\\delta)^{d-1} \\sim_d \\delta^{-(d+1)}")]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (gd\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\gtrsim_{d,\\varphi,p} \\delta^{d-1} \\delta^{-(d+1)/p^{\\prime}}", block: true)]]

#text("for any ")#mi("{1 \\leq p \\leq \\infty}")#text(". By Exercise ")#link(<tao-8ccf2f9e9cc41e7ad5bf>)[#text("11")]#text(", we thus see that if the estimate ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds, then")

#align(center)[#tao-fit-display[#mitex("\\delta^{d-1} \\delta^{-(d+1)/p^{\\prime}} \\lesssim_{d,\\varphi,p,q} \\delta^{(d-1)/q^{\\prime}}")]]

#text("for all small ")#mi("{\\delta>0}")#text("; sending ")#mi("{\\delta}")#text(" to zero, we conclude that")

#align(center)[#tao-fit-display[#mitex("d-1 - \\frac{d+1}{p^{\\prime}} \\geq \\frac{d-1}{q^{\\prime}}")]]

#text("or equivalently that ")#mi("{q \\leq \\frac{d-1}{d+1} p^{\\prime}}")#text(", recovering the second necessary condition in Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-65d5b3a58321eee93bc6>

#list(
[#text("(i) By considering a random superposition of Knapp examples located at different frequencies ")#mi("{\\omega_0}")#text(", and using Khintchine’s inequality, recover (a weak form of) the first necessary condition ")#mi("{p \\leq \\frac{2d}{d+1}}")#text(" of Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(". (It is possible to recover the strong form ")#mi("{p < \\frac{2d}{d+1}}")#text(" of this condition by using the observation of Besicovitch that there exist Kakeya sets of arbitrarily small measure; we leave this as a challenge for the interested reader.)")],
[#text("(ii) Suppose that ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" holds for some ")#mi("{1 \\leq p, q < \\infty}")#text(". Establish the estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| \\sum_{T \\in {\\mathcal T}} c_T 1_T \\right\\|_{L^{p^{\\prime}/2}} \\lesssim_{p,q,d} \\delta^{2(\\frac{2d}{p^{\\prime}}-d+1)} (\\delta^{d-1} \\sum_{T \\in \\mathcal T} \\left|c_T\\right|^{q^{\\prime}/2})^{2/q^{\\prime}}", block: true)]]

#metadata(none) <tao-5a376993386af8e4af5c>#text(" whenever ")#mi("{{\\mathcal T}}")#text(" is a collection of ")#mi("{\\delta \\times 1}")#text(" tubes – that is to say, sets of the form")

#tao-aligned(keep: true)[


#tao-math("T  & = T^{\\delta \\times 1}_{\\omega_T, x_T} = \\{ x \\in {\\bf R}^d: \\left|(x-x_T) \\cdot \\omega_T\\right| \\leq 1;", block: true)



#tao-math("\\left|(x-x_T) - ((x-x_T) \\cdot \\omega_T) \\omega_T\\right|  & \\leq \\delta \\}", block: true)
]

#text("whose directions ")#mi("{\\omega_T}")#text(" are ")#mi("{\\delta}")#text("-separated (thus ")#tao-math("{\\left|\\omega_T - \\omega_{T^{\\prime}}\\right| \\geq \\delta}", block: false)#text(" for any two distinct ")#mi("{T,T^{\\prime} \\in {\\mathcal T}}")#text("), and the ")#mi("{c_T}")#text(" are arbitrary real numbers.")],
[#text("(iii) Establish claims (i) and (ii) with the sphere ")#mi("{S^{d-1}}")#text(" replaced by a bounded non-empty open subset of the paraboloid ")#mi("{\\Sigma}")#text(".")]
)
]

#text("Using this exercise, we can show that restriction estimates imply assertions about the dimension of ")#link("https://en.wikipedia.org/wiki/Kakeya_set")[#text("Kakeya sets")]#text(" (also known as ")#emph[#text("Besicovitch sets")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Restriction implies Kakeya)")]#text(" ")#metadata(none) <tao-6a4da766522caacace3b>#text(" Assume that either Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(" or Conjecture ")#link(<tao-910cd9c0fbf44ca52706>)[#text("15")]#text(" holds. Define a ")#emph[#text("Kakeya set")]#text(" to be a compact subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text(" that contains a unit line segment in every direction (thus for every ")#mi("{\\omega \\in S^{d-1}}")#text(", there exists a line segment ")#mi("{\\{ x_\\omega + t \\omega: t \\in [0,1] \\}}")#text(" for some ")#mi("{x_\\omega \\in {\\bf R}^d}")#text(" that is contained in ")#mi("{E}")#text("). Show that for any ")#mi("{0 < \\delta < 1}")#text(", the ")#mi("{\\delta}")#text("-neighbourhood of ")#mi("{E}")#text(" has Lebesgue measure ")#mi("{\\gtrsim_{d,\\varepsilon} \\delta^\\varepsilon}")#text(" for any ")#mi("{\\varepsilon}")#text(". (This is equivalent to the assertion that ")#mi("{E}")#text(" has Minkowski dimension ")#mi("{d}")#text(".) It is also possible to show that the restriction conjecture implies that all Kakeya sets have ")#link("https://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff")]#text(" dimension ")#mi("{d}")#text(", but this is trickier; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1097257")[#text("this paper of Bourgain")]#text(". (This can be viewed as a challenge problem for those students who are familiar with the concept of Hausdorff dimension.)")
]

#text("The ")#emph[#text("Kakeya conjecture")]#text(" asserts that all Kakeya sets in ")#mi("{{\\bf R}^d}")#text(" have Minkowski and Hausdorff dimension equal to ")#mi("{d}")#text(". As with the restriction conjecture, this is known to be true in two dimensions (as was first proven ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=272988")[#text("by Davies")]#text("), but only partial results are known in higher dimensions. For instance, in three dimensions, Kakeya sets are known to have (upper) Minkowski dimension at least ")#mi("{\\frac{5}{2}+\\epsilon_0}")#text(" for some absolute constant ")#mi("{\\epsilon_0>0}")#text(" (a result of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1804528")[#text("Katz, Laba, and myself")]#text("), and also more recently for Hausdorff dimension (a result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3868003")[#text("of Katz and Zahl")]#text("). For the latest results in higher dimensions, see these papers ")#link("https://arxiv.org/abs/1908.05589")[#text("of Hickman-Rogers-Zhang")]#text(" and ")#link("https://arxiv.org/abs/1908.05314")[#text("Zahl")]#text(".")#linebreak()#text(" Much of the modern progress on the restriction conjecture has come from trying to reverse the implication in Exercise ")#link(<tao-6a4da766522caacace3b>)[#text("17")]#text(", and use known partial results towards the Kakeya conjecture (or its relatives) to obtain restriction estimates. We will not give the latest arguments in this direction here, but give an illustrative example (in the multilinear setting) at the end of this set of notes.")

#heading(level: 1)[#strong[#text(" — 2. ")#mi("{L^2}")#text(" theory — ")]]

#text("One of the best understood cases of the restriction conjecture is the ")#mi("{q=2}")#text(" case. Note that Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text(" asserts that ")#mi("{R_{S^{d-1}}(p \\rightarrow 2)}")#text(" holds whenever ")#mi("{p \\leq \\frac{2(d+1)}{d+3}}")#text(", and Conjecture ")#link(<tao-910cd9c0fbf44ca52706>)[#text("15")]#text(" asserts that ")#mi("{R_{\\Sigma}(p \\rightarrow 2)}")#text(" holds when ")#mi("{p = \\frac{2(d+1)}{d+3}}")#text(". Theorem ")#link(<tao-9a4cf4b8b0f50f4b8634>)[#text("1")]#text(" already gave a partial result in this direction. Now we establish the full range of the ")#mi("{L^2}")#text(" restriction conjecture, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=545245")[#text("due to Tomas and Stein")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18 (Tomas-Stein restriction theorem)")]#text(" Let ")#mi("{d \\geq 2}")#text(". Then ")#mi("{R_{S^{d-1}}(p \\rightarrow 2)}")#text(" holds for all ")#mi("{1 \\leq p \\leq \\frac{2(d+1)}{d+3}}")#text(", and ")#mi("{R_{\\Sigma}(p \\rightarrow 2)}")#text(" holds for ")#mi("{p = \\frac{2(d+1)}{d+3}}")#text(".")
]

#text("The exponent ")#mi("{p = \\frac{2(d+1)}{d+3}}")#text(" is sometimes referred to in the literature as the ")#emph[#text("Tomas-Stein exponent")]#text("; though the dual exponent ")#mi("{p^{\\prime} = \\frac{2(d+1)}{d-1}}")#text(" is also referred to by this name.")#linebreak()#text(" We first establish the restriction estimate ")#mi("{R_{S^{d-1}}(p \\rightarrow 2)}")#text(" in the non-endpoint case ")#mi("{1 \\leq p < \\frac{2(d+1)}{d+3}}")#text(" by an interpolation method. Fix ")#mi("{p,d}")#text(". By the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(5)")]#text(" and Hölder’s inequality, it suffices to establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f * (d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("We use the standard technique of ")#emph[#text("dyadic decomposition")]#text(". Let ")#mi("{\\varphi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function supported on ")#mi("{B(0,1)}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{B(0,1/2)}")#text(". Then one has the telescoping series")

#align(center)[#tao-fit-display[#mitex("1 = \\varphi(x) + \\sum_{k=1}^\\infty \\psi(x/2^k)")]]

#text("where ")#mi("{\\psi(x) := \\varphi(x) - \\varphi(2x)}")#text(" is a bump function supported on the annulus ")#mi("{B(0,1) \\backslash B(0,1/4)}")#text(". We can then decompose the convolution kernel ")#mi("{(d\\sigma)^\\vee}")#text(" as")

#align(center)[#tao-fit-display[#mitex("(d\\sigma)^\\vee(x) = \\varphi(x) (d\\sigma)^\\vee(x) + \\sum_{k=1}^\\infty \\psi(x/2^k) (d\\sigma)^\\vee(x)")]]

#text("so by the triangle inequality it will suffice to establish the bounds ")#metadata(none) <tao-5a94a27c8371c0adcd93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left\\| f * \\varphi (d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p,\\varphi} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text(" and ")#metadata(none) <tao-7005b03df3ad0fb511bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left\\| f * \\psi(\\cdot/2^k) (d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p,\\varphi} 2^{-ck} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text(" for all ")#mi("{k \\geq 1}")#text(" and some constant ")#mi("{c>0}")#text(" depending only on ")#mi("{d,p}")#text(".")#linebreak()#text(" The function ")#mi("{\\varphi (d\\sigma)^\\vee}")#text(" is smooth and compactly supported, so ")#link(<tao-5a94a27c8371c0adcd93>)[#text("(18)")]#text(" is immediate from Young’s inequality (note that ")#mi("{p^{\\prime} \\geq p}")#text(" when ")#mi("{p \\leq \\frac{2(d+1)}{d+3} \\leq 2}")#text("). So it remains to prove ")#link(<tao-7005b03df3ad0fb511bb>)[#text("(19)")]#text(". Firstly, we recall from ")#link(<tao-720f6ac947ab8e448c3a>)[#text("(7)")]#text(" (or ")#link(<tao-f8d0e595bebdb641eb7f>)[#text("(8)")]#text(") that the kernel ")#mi("{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}")#text(" is of magnitude ")#mi("{O_d( 2^{-k(d-1)/2})}")#text(". Thus by Young’s inequality we have ")#metadata(none) <tao-879baa17bc4ea59e323b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\| f * \\psi(\\cdot/2^k) (d\\sigma)^\\vee \\right\\|_{L^{\\infty}({\\bf R}^d)} \\lesssim_{d} 2^{-k(d-1)/2} \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text(" We now complement this with an ")#mi("{L^2}")#text(" estimate. The Fourier transform of ")#mi("{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}")#text(" can be computed as")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}(\\xi) = \\int_{S^{d-1}} 2^{kd} \\hat\\psi(2^k(\\xi-\\eta)) d\\sigma(\\eta)")]]

#text("for any ")#mi("{\\xi\\in {\\bf R}^d}")#text(", and hence by the triangle inequality and the rapid decay of the Schwartz function ")#mi("{\\hat \\psi}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}(\\xi) \\lesssim_{d,\\varphi} \\int_{S^{d-1}} 2^{kd} \\langle 2^k(\\xi-\\eta) \\rangle^{-100d} d\\sigma(\\eta).")]]

#text("By dyadic decomposition we then have")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}(\\xi) \\lesssim_{d,\\varphi} \\sum_{j=0}^\\infty 2^{kd} 2^{-100jd} \\sigma( B(\\xi, 2^{j-k} )).")]]

#text("From elementary geometry we have")

#align(center)[#tao-fit-display[#mitex("\\sigma( B(\\xi, 2^{j-k} )) \\lesssim_d \\min( 1, 2^{(d-1)(j-k)} )")]]

#text("(basically because the sphere is ")#mi("{d-1}")#text("-dimensional), and then on summing the geometric series we conclude that")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\psi(\\cdot/2^k) (d\\sigma)^\\vee}(\\xi) \\lesssim_{d,\\varphi} 2^k.")]]

#text("From Plancherel’s theorem we conclude that ")#metadata(none) <tao-8a1cee436cbac1489a18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left\\| f * \\psi(\\cdot/2^k) (d\\sigma)^\\vee \\right\\|_{L^{2}({\\bf R}^d)} \\lesssim_{d} 2^{k} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text(" Applying either the ")#link("https://en.wikipedia.org/wiki/Marcinkiewicz_interpolation_theorem")[#text("Marcinkiewicz interpolation theorem")]#text(" (or the ")#link("https://en.wikipedia.org/wiki/Riesz%E2%80%93Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(") to ")#link(<tao-879baa17bc4ea59e323b>)[#text("(20)")]#text(" and ")#link(<tao-8a1cee436cbac1489a18>)[#text("(21)")]#text(", we conclude (after some arithmetic) the required estimate ")#link(<tao-7005b03df3ad0fb511bb>)[#text("(19)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("c := \\frac{d+1}{2} (\\frac{1}{p} - \\frac{1}{p^{\\prime}}) - 1,")]]

#text("which is indeed positive when ")#mi("{p < \\frac{2(d+1)}{d+3}}")#text(".")#linebreak()#text(" At the endpoint ")#mi("{p = \\frac{2(d+1)}{d+3}}")#text(" the above argument does not quite work; we obtain a decent bound for each dyadic component ")#mi("{f * \\psi(\\cdot/2^k) (d\\sigma)^\\vee}")#text(" of ")#mi("{f * (d\\sigma)^\\vee}")#text(", but then we have trouble getting a good bound for the sum. The original argument of Stein got around this problem by using complex interpolation instead of dyadic decomposition, embedding ")#mi("{f * (d\\sigma)^\\vee}")#text(" in an analytic family of functions. We present here another approach, which is now popular in PDE applications; the basic inputs (namely, an ")#mi("{L^1}")#text(" to ")#mi("{L^\\infty}")#text(" estimate similar to ")#link(<tao-879baa17bc4ea59e323b>)[#text("(20)")]#text(", an ")#mi("{L^2}")#text(" estimate similar to ")#link(<tao-8a1cee436cbac1489a18>)[#text("(21)")]#text(", and an interpolation) are the same, but we employ the additional tool of Hardy-Littlewood-Sobolev fractional integration to recover the endpoint.")#linebreak()#text(" We turn to the details. Set ")#mi("{p = p_0 := \\frac{2(d+1)}{d+3}}")#text(". We write ")#mi("{{\\bf R}^d}")#text(" as ")#mi("{{\\bf R}^{d-1} \\times {\\bf R}}")#text(" and parameterise the frequency variable ")#mi("{\\xi}")#text(" by ")#mi("{(\\xi^{\\prime},\\xi_d)}")#text(" with ")#mi("{\\xi^{\\prime} \\in {\\bf R}^{d-1}, \\xi_d \\in {\\bf R}}")#text(", thus for instance ")#tao-math("{S^{d-1} = \\{ (\\xi^{\\prime},\\xi_d): \\left|\\xi^{\\prime}\\right|^2 + \\xi_d^2 = 1\\}}", block: false)#text(". We split the spatial variable ")#mi("{x = (x^{\\prime},x_d)}")#text(" similarly. (One can think of ")#mi("{x_d}")#text(" as a “time” variable that we will give a privileged role in the physical domain ")#mi("{{\\bf R}^d}")#text(", with ")#mi("{\\xi_d}")#text(" being the dual time-frequency variable.) Let ")#mi("{\\eta \\in C^\\infty_c}")#text(" be a non-negative bump function localised to a small neighbourhood of the north pole ")#mi("{(0,1)}")#text(" of ")#mi("{S^{d-1}}")#text(". By Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("9")]#text(" it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^2({\\bf R}^d, \\eta d\\sigma)} \\lesssim_{d,\\eta} \\left\\|f\\right\\|_{L^{p_0}({\\bf R}^d)}", block: true)]]

#text("for ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(". Squaring as before, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f * (\\eta d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}_0}({\\bf R}^d)} \\lesssim_{d,\\eta} \\left\\|f\\right\\|_{L^{p_0}({\\bf R}^d)}.", block: true)]]

#text("For each ")#mi("{x_d \\in {\\bf R}}")#text(", let ")#mi("{f_{x_d}: {\\bf R}^{d-1} \\rightarrow {\\bf C}}")#text(" denote the function ")#mi("{f_{x_d}(x^{\\prime}) := f(x^{\\prime},x_d)}")#text(", and let ")#mi("{K_{x_d}}")#text(" denote the function")

#align(center)[#tao-fit-display[#mitex("K_{x_d}(x^{\\prime}) := (\\eta d\\sigma)^\\vee(x^{\\prime}, x_d).")]]

#text("Then we have")

#align(center)[#tao-fit-display[#mitex("f * (\\eta d\\sigma)^\\vee(x^{\\prime},x_d) = \\int_{\\bf R} f_{y_d} * K_{x_d-y_d}(x^{\\prime})\\ dy_d")]]

#text("where on the right-hand side the convolution is now over ")#mi("{{\\bf R}^{d-1}}")#text(" rather than ")#mi("{{\\bf R}^d}")#text(". By the Fubini-Tonelli theorem and Minkowski’s inequality, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f * (\\eta d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}_0}({\\bf R}^d)} \\leq \\left\\| \\int_{\\bf R} \\right\\| f_{y_d} * K_{x_d-y_d} \\left\\|_{L^{p^{\\prime}_0}({\\bf R}^{d-1})}\\ dy_d \\right\\|_{L^{p^{\\prime}_0}_{x_d}({\\bf R})}.", block: true)]]

#text("From Exercise ")#link(<tao-139d544b821b13ebea14>)[#text("12")]#text(" (and the trivial bounds ")#mi("{K_{x_d}(x^{\\prime}) = O_{\\eta,d}(1)}")#text(" to treat the case when ")#mi("{(x^{\\prime},x_d) = O(1)}")#text(") we have the bounds")

#align(center)[#tao-fit-display[#tao-math("K_{x_d}(x^{\\prime}) \\lesssim_{\\eta,d} \\left|(x^{\\prime},x_d)\\right|^{-\\frac{d-1}{2}} \\leq \\left|x_d\\right|^{-\\frac{d-1}{2}}", block: true)]]

#text("leading to the ")#emph[#text("dispersive estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| g * K_{x_d-y_d} \\right\\|_{L^\\infty({\\bf R}^{d-1})} \\lesssim_{\\eta,d} \\left|x_d-y_d\\right|^{-\\frac{d-1}{2}} \\left\\|g\\right\\|_{L^1({\\bf R}^{d-1})}", block: true)]]

#text("for any ")#mi("{g \\in L^1({\\bf R}^{d-1})}")#text(" (the claim is vacuous when ")#mi("{x_d-y_d}")#text(" vanishes). On the other hand, the ")#mi("{d-1}")#text("-dimensional Fourier transform of ")#mi("{K_{x_d}}")#text(" can be computed as")

#align(center)[#tao-fit-display[#tao-math("\\hat K_{x_d}(\\xi^{\\prime}) = \\frac{\\eta(\\xi^{\\prime}, \\sqrt{1-\\left|\\xi^{\\prime}\\right|^2})}{\\sqrt{1-\\left|\\xi^{\\prime}\\right|^2}} e^{2\\pi i x_d \\sqrt{1-\\left|\\xi^{\\prime}\\right|^2}}", block: true)]]

#text("which is bounded by ")#mi("{O_\\eta(1)}")#text(", hence by Plancherel we have the ")#emph[#text("energy estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| g * K_{x_d-y_d} \\right\\|_{L^2({\\bf R}^{d-1})} \\lesssim_{\\eta,d} \\left\\|g\\right\\|_{L^2({\\bf R}^{d-1})}.", block: true)]]

#text("Interpolating, we conclude after some arithmetic that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g * K_{x_d-y_d} \\right\\|_{L^{p^{\\prime}_0}({\\bf R}^{d-1})} \\lesssim_{\\eta,d} \\left|x_d-y_d\\right|^{-\\frac{d-1}{d+1}} \\left\\|g\\right\\|_{L^{p_0}({\\bf R}^{d-1})}.", block: true)]]

#text("Applying the one-dimensional Hardy-Littlewood-Sobolev inequality we conclude (after some more arithmetic) that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\int_{\\bf R} \\right\\| f_{y_d} * K_{x_d-y_d} \\left\\|_{L^{p^{\\prime}_0}({\\bf R}^{d-1})}\\ dy_d \\right\\|_{L^{p^{\\prime}_0}_{x_d}({\\bf R})} \\lesssim_d \\left\\| \\left\\| f_{x_d} \\right\\|_{L^{p_0}({\\bf R}^{d-1})} \\right\\|_{L^{p_0}_{x_d}({\\bf R})}", block: true)]]

#text("and the claim follows.")#linebreak()#text(" This latter argument can be adapted for the paraboloid, which in turn leads to some very useful estimates for the Schrödinger equation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Strichartz estimates for the Schrödinger equation)")]#text(" Let ")#mi("{d \\geq 2}")#text(".")

#list(
[#text("(i) By modifying the above arguments, establish the restriction estimate ")#mi("{R_\\Sigma(\\frac{2(d+1)}{d+3} \\mapsto 2)}")#text(".")],
[#text("(ii) Let ")#mi("{f \\in {\\mathcal S}({\\bf R}^{d-1})}")#text(", and let ")#mi("{u: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" denote the function")

#align(center)[#tao-fit-display[#tao-math("u(x^{\\prime},x_d) := \\int_{{\\bf R}^{d-1}} \\hat f(\\xi^{\\prime}) e^{2\\pi i (x^{\\prime} \\cdot \\xi^{\\prime} + x_d \\left|\\xi^{\\prime}\\right|^2)}\\ d\\xi^{\\prime}.", block: true)]]

#text("(This is the solution to the Schrödinger equation ")#mi("{2\\pi i \\partial_{x_d} u = \\Delta_{x^{\\prime}} u}")#text(" with initial data ")#mi("{u(x^{\\prime},0) = f(x^{\\prime})}")#text(".) Establish the ")#emph[#text("Strichartz estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^{\\frac{2(d+1)}{d-1}}({\\bf R}^d)} \\lesssim_d \\left\\|f\\right\\|_{L^2({\\bf R}^{d-1})}.", block: true)]]],
[#text("(iii) More generally, with the hypotheses as in (ii), establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left\\| u_{x_d} \\right\\|_{L^r({\\bf R}^{d-1})} \\right\\|_{L^q_{x_d}({\\bf R})} \\lesssim_{d,q,r} \\left\\|f\\right\\|_{L^2({\\bf R}^{d-1})}", block: true)]]

#text("whenever ")#mi("{2 < q,r \\leq \\infty}")#text(" are exponents obeying the scaling condition ")#mi("{\\frac{2}{q} + \\frac{d-1}{r} = \\frac{d-1}{2}}")#text(". (The endpoint case ")#mi("{q=2}")#text(" of this estimate is also available when ")#mi("{d \\neq 3}")#text(", using a more sophisticated interpolation argument; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1646048")[#text("this paper")]#text(" of Keel and myself.)")]
)
]

#text("The Strichartz estimates in the above exercise were for the linear Schrödinger equation, but Strichartz estimates can also be established by the same method (namely, interpolating between energy and dispersive estimates) for other linear dispersive equations, such as the linear wave equation ")#mi("{\\partial_{x_d}^2 u = \\Delta_{x^{\\prime}} u}")#text(". Such Strichartz estimates are a fundamental tool in the modern analysis of ")#emph[#text("nonlinear")]#text(" dispersive equations, as they often allow one to view such nonlinear equations as perturbations of linear ones. The topic is too vast to survey in these notes, but see for instance ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("my monograph on this topic")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Bilinear estimates — ")]]

#text("A restriction estimate such as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^q({\\bf R}^d,\\mu)} \\lesssim_{p,q,d,\\mu} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("or its equivalent dual form ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\| (g\\ d\\mu)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{p,q,d,\\mu} \\left\\| g\\right\\|_{L^{q^{\\prime}}({\\bf R}^d,\\mu)}", block: true)]]

#text(" are ")#emph[#text("linear")]#text(" estimates, asserting the boundedness of either a restriction operator ")#mi("{f \\mapsto \\hat f|_S}")#text(" (where ")#mi("{S}")#text(" denotes the support of ")#mi("{\\mu}")#text(") or an extension operator ")#mi("{g \\mapsto (g\\ d\\mu)^\\vee}")#text(". In the last ten or twenty years, it has been realised that one should also consider ")#emph[#text("bilinear")]#text(" or ")#emph[#text("multilinear")]#text(" versions of the extension estimate, both as stepping stones towards making progress on the linear estimate, and also as being of independent interest and application.")#linebreak()#text(" In this section we will show how the consideration of bilinear extension estimates can be used to resolve the restriction conjecture for the circle (i.e., the ")#mi("{d=2}")#text(" case of Conjecture ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("14")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 20 (Restriction conjecture for ")#mi("{S^1}")#text(")")]#text(" ")#metadata(none) <tao-8dc179570516ec1a38c7>#text(" One has ")#mi("{R_{S^1}(p \\rightarrow q)}")#text(" whenever ")#mi("{p < \\frac{4}{3}}")#text(" and ")#mi("{q \\leq \\frac{1}{3} p^{\\prime}}")#text(".")
]

#text("Note from Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("9")]#text("(vi) that this theorem also implies the ")#mi("{d=2}")#text(" case of Conjecture ")#link(<tao-910cd9c0fbf44ca52706>)[#text("15")]#text(". This case of the restriction conjecture was first established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=387950")[#text("by Zygmund")]#text("; Zygmund’s proof is shorter than the one given here (relying on the Hausdorff-Young inequality ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(4)")]#text("), but the arguments here have broader applicability, in particular they are also useful in higher-dimensional settings.")#linebreak()#text(" To prove this conjecture, it suffices to verify it at the endpoint ")#mi("{q = \\frac{1}{3} p^{\\prime}}")#text(", since from Hölder’s inequality the norm ")#tao-math("{\\left\\| \\hat f \\right\\|_{L^q(S^1, d\\sigma)}}", block: false)#text(" is essentially non-decreasing in ")#mi("{q}")#text(", where ")#mi("{d\\sigma}")#text(" is arclength measure on ")#mi("{S^1}")#text(". By Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("9")]#text(", we may replace ")#mi("{S^1}")#text(" here by (say) the first quadrant ")#mi("{\\phi([0,1/4])}")#text(" of the circle, where ")#mi("{\\phi}")#text(" is the map ")#mi("{\\phi(\\theta) := (\\cos 2\\pi \\theta, \\sin 2\\pi \\theta)}")#text("; we let ")#mi("{d\\sigma_{[0,1/4]}}")#text(" be the arc length measure on that quadrant. (This reduction is technically convenient to avoid having to deal with antipodal points with parallel tangents a little later in the argument.)")#linebreak()#text(" By ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("(22)")]#text(" and relabeling, it suffices to show that ")#metadata(none) <tao-900edf18886f9806d1fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\left\\| (g\\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^q({\\bf R}^2)} \\lesssim_{q} \\left\\| g\\right\\|_{L^p(\\phi([0,1/4]))}", block: true)]]

#text(" whenever ")#mi("{q > 4}")#text(", ")#mi("{p^{\\prime} = \\frac{q}{3}}")#text(", and ")#mi("{g \\in L^p(\\phi([0,1/4]))}")#text(" (we drop the requirement that ")#mi("{g}")#text(" is smooth, in order to apply rough cutoffs shortly), and arcs such as ")#mi("{\\phi([0,1/4])}")#text(" are always understood to be endowed with arclength measure.")#linebreak()#text(" We now bilinearise this estimate. It is clear that the estimate ")#link(<tao-900edf18886f9806d1fa>)[#text("(23)")]#text(" is equivalent to ")#metadata(none) <tao-5c5ff1da5d95d6732573>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\left\\| (g_1\\ d\\sigma_{[0,1/4]})^\\vee (g_2\\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^{q/2}({\\bf R}^2)} \\lesssim_{q} \\left\\| g_1\\right\\|_{L^p(\\phi([0,1/4]))} \\left\\| g_2\\right\\|_{L^p(\\phi([0,1/4]))}", block: true)]]

#text(" for any ")#mi("{g_1,g_2 \\in L^p(\\phi([0,1/4]))}")#text(", since ")#link(<tao-5c5ff1da5d95d6732573>)[#text("(24)")]#text(" follows from ")#link(<tao-900edf18886f9806d1fa>)[#text("(23)")]#text(" and Hölder’s inequality, and ")#link(<tao-900edf18886f9806d1fa>)[#text("(23)")]#text(" follows from ")#link(<tao-5c5ff1da5d95d6732573>)[#text("(24)")]#text(" by setting ")#mi("{g_1=g_2}")#text(".")#linebreak()#text(" Right now, the two functions ")#mi("{g_1}")#text(" and ")#mi("{g_2}")#text(" are both allowed to occupy the entirety of the arc ")#mi("{\\phi([0,1/4])}")#text(". However, one can get better estimates if one separates the functions ")#mi("{g_1,g_2}")#text(" to lie in ")#emph[#text("transverse")]#text(" sub-arcs ")#mi("{\\phi(I), \\phi(J)}")#text(" of ")#mi("{\\phi([0,1/4])}")#text(" (where by “transverse” we mean that there is some non-zero separation between the normal vectors of ")#mi("{\\phi(I)}")#text(" and the normal vectors of ")#mi("{\\phi(J)}")#text(". The key estimate is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21 (Bilinear ")#mi("{L^2}")#text(" estimate)")]#text(" ")#metadata(none) <tao-bb3be5d12d4e85f6a02c>#text(" Let ")#mi("{I,J}")#text(" be subintervals of ")#mi("{[0,1/4]}")#text(" such that ")#tao-math("{\\left|I\\right| \\sim \\left|J\\right| \\sim \\mathrm{dist}(I,J)}", block: false)#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1\\ d\\sigma_I)^\\vee (g_2\\ d\\sigma_J)^\\vee \\right\\|_{L^2({\\bf R}^2)} \\lesssim \\left|I\\right|^{-1/2} \\left\\| g_1\\right\\|_{L^2(\\phi(I))} \\left\\| g_2\\right\\|_{L^2(\\phi(J))}", block: true)]]

#text("for an ")#mi("{g_1,g_2 \\in C^\\infty({\\bf R}^2)}")#text(", where ")#mi("{\\sigma_I}")#text(" denotes the arclength measure on ")#mi("{\\phi(I)}")#text(".")
]

#emph[#text("Proof:")]#text(" To avoid some very minor technicalities involving convolutions of measures, let us approximate the arclength measures ")#mi("{d\\sigma_I, d\\sigma_J}")#text(". Observe that we have")

#align(center)[#tao-fit-display[#mitex("d\\sigma_I(\\xi) = \\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{2\\varepsilon} 1_{A_{I,\\varepsilon}}(\\xi)\\ d\\xi")]]

#text("in the sense of distributions, where ")#mi("{A_{I,\\varepsilon}}")#text(" is the annular region")

#align(center)[#tao-fit-display[#mitex("A_{I,\\varepsilon} := \\{ r \\phi(\\theta): \\theta \\in I, 1-\\varepsilon \\leq r \\leq 1+\\varepsilon \\}.")]]

#text("Thus we have the pointwise bound")

#align(center)[#tao-fit-display[#mitex("(g_1\\ d\\sigma_I)^\\vee = \\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{2\\varepsilon} (g_1 1_{A_{I,\\varepsilon}})^\\vee")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1\\right\\|_{L^2(\\phi(I))} = \\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{\\sqrt{2\\varepsilon}} \\left\\|g_1\\right\\|_{L^2(A_{I,\\varepsilon})}", block: true)]]

#text("and similarly for ")#mi("{g_2}")#text(". Hence by monotone convergence it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1 1_{A_{I,\\varepsilon}})^\\vee (g_2 1_{A_{J,\\varepsilon}})^\\vee \\right\\|_{L^2({\\bf R}^2)} \\lesssim \\left|I\\right|^{-1/2} \\varepsilon \\left\\| g_1\\right\\|_{L^2(A_{I,\\varepsilon})} \\left\\| g_2\\right\\|_{L^2(A_{J,\\varepsilon})}", block: true)]]

#text("for sufficiently small ")#mi("{\\varepsilon>0}")#text(". By Plancherel’s theorem, it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1 1_{A_{I,\\varepsilon}}) * (g_2 1_{A_{J,\\varepsilon}}) \\right\\|_{L^2({\\bf R}^2)} \\lesssim \\left|I\\right|^{-1/2} \\varepsilon \\left\\| g_1\\right\\|_{L^2(A_{I,\\varepsilon})} \\left\\| g_2\\right\\|_{L^2(A_{J,\\varepsilon})}", block: true)]]

#text("for ")#mi("{g_1 \\in L^2(A_{I,\\varepsilon}), g_2 \\in L^2(A_{J,\\varepsilon})}")#text(", if ")#mi("{\\varepsilon}")#text(" is sufficiently small. From Young’s inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1 1_{A_{I,\\varepsilon}}) * (g_2 1_{A_{J,\\varepsilon}}) \\right\\|_{L^1({\\bf R}^2)} \\lesssim \\left\\| g_1\\right\\|_{L^1(A_{I,\\varepsilon})} \\left\\| g_2\\right\\|_{L^1(A_{J,\\varepsilon})}", block: true)]]

#text("so by interpolation it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1 1_{A_{I,\\varepsilon}}) * (g_2 1_{A_{J,\\varepsilon}}) \\right\\|_{L^\\infty({\\bf R}^2)} \\lesssim \\left|I\\right|^{-1} \\varepsilon^2 \\left\\| g_1\\right\\|_{L^\\infty(A_{I,\\varepsilon})} \\left\\| g_2\\right\\|_{L^\\infty(A_{J,\\varepsilon})}.", block: true)]]

#text("But this follows from the pointwise bound ")#metadata(none) <tao-251fecd592e56e6c4a95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\left\\| 1_{A_{I,\\varepsilon}} * 1_{A_{J,\\varepsilon}} \\right\\|_{L^\\infty({\\bf R}^2)} \\lesssim \\left|I\\right|^{-1} \\varepsilon^2,", block: true)]]

#text(" for sufficiently small ")#mi("{\\varepsilon>0}")#text(", whose proof we leave as an exercise. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Establish ")#link(<tao-251fecd592e56e6c4a95>)[#text("(25)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" Higher-dimensional bilinear ")#mi("{L^2}")#text(" estimates, involving more complicated manifolds than arcs, play an important role in the modern theory of nonlinear dispersive equations, especially when combined with the formalism of dispersive variants of Sobolev spaces known as ")#emph[#mi("{X^{s,b}}")#text(" spaces")]#text(", introduced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1209299")[#text("by Bourgain")]#text(" (and independently ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1420552")[#text("by Klainerman-Machedon")]#text("). See for instance ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("this book of mine")]#text(" for further discussion.")
]

#text("From the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g_1\\ d\\sigma_I)^\\vee (g_2\\ d\\sigma_J)^\\vee \\right\\|_{L^\\infty({\\bf R}^2)} \\leq \\left\\| g_1\\right\\|_{L^1(\\phi(I))} \\left\\| g_2\\right\\|_{L^1(\\phi(J))}", block: true)]]

#text("so by complex interpolation (which works perfectly well for bilinear operators; see for instance the appendix to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3052499")[#text("Muscalu-Schlag")]#text(") we have ")#metadata(none) <tao-1759f7a2eb8085ca9435>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\left\\| (g_1\\ d\\sigma_I)^\\vee (g_2\\ d\\sigma_J)^\\vee \\right\\|_{L^{q/2}({\\bf R}^2)}", block: true)]]



#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left|I\\right|^{-2/q} \\left\\| g_1\\right\\|_{L^{(q/2)^{\\prime}}(\\phi(I))} \\left\\| g_2\\right\\|_{L^{(q/2)^{\\prime}}(\\phi(J))}", block: true)]]

#text("for any ")#mi("{q > 4}")#text(". The estimate ")#link(<tao-1759f7a2eb8085ca9435>)[#text("(26)")]#text(" begins to look rather similar to ")#link(<tao-5c5ff1da5d95d6732573>)[#text("(24)")]#text(", and we can deduce ")#link(<tao-5c5ff1da5d95d6732573>)[#text("(24)")]#text(" from ")#link(<tao-1759f7a2eb8085ca9435>)[#text("(26)")]#text(" as follows. Firstly, it is convenient to use Marcinkiewicz interpolation (using the fact that we have an open range of ")#mi("{q}")#text(", and using the Lorentz space form of this theorem ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=169037")[#text("due to Hunt")]#text(") to reduce ")#link(<tao-900edf18886f9806d1fa>)[#text("(23)")]#text(" to proving a restricted strong-type estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (1_E\\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^q({\\bf R}^2)} \\lesssim_{q} \\sigma_{[0,1/4]}( E )^{1 - 3/q}", block: true)]]

#text("for any measurable subset ")#mi("{E}")#text(" of the circle, so to prove ")#link(<tao-5c5ff1da5d95d6732573>)[#text("(24)")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (1_E \\ d\\sigma_{[0,1/4]})^\\vee (1_E \\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^{q/2}({\\bf R}^2)} \\lesssim_{q} \\sigma_{[0,1/4]}( E )^{2 - 6/q}.", block: true)]]

#text("We can view the expression ")#mi("{(1_E \\ d\\sigma_{[0,1/4]})^\\vee (1_E \\ d\\sigma_{[0,1/4]})^\\vee(x)}")#text(" as a two-dimensional integral ")#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("(2\\pi)^2 \\int_{[0,1/4] \\times [0,1/4]} 1_E(\\phi(\\theta_1)) 1_E (\\phi(\\theta_2)) e^{2\\pi i x \\cdot (\\phi(\\theta_1)+\\phi(\\theta_2))}\\ d\\theta_1 d\\theta_2.")]]

#text(" We now perform a ")#link("https://en.wikipedia.org/wiki/Whitney_covering_lemma")[#text("Whitney decomposition")]#text(" away from the diagonal ")#mi("{\\{ (\\theta,\\theta): \\theta \\in [0,1/4]\\}}")#text(" of the square ")#mi("{[0,1/4] \\times [0,1/4]}")#text(" to decompose it as rectangles ")#mi("{I \\times J}")#text(" of the form for which Proposition ")#link(<tao-bb3be5d12d4e85f6a02c>)[#text("21")]#text(" applies. There are many ways to perform this decomposition; here is one such. Define a ")#emph[#text("dyadic interval")]#text(" in ")#mi("{[0,1/4]}")#text(" to be a subinterval of ")#mi("{[0,1/4]}")#text(" of the form ")#mi("{[\\frac{j}{2^k}, \\frac{j+1}{2^k}]}")#text("; then each dyadic interval ")#mi("{I}")#text(" other than the full interval ")#mi("{[0,1/4]}")#text(" is contained in a unique parent interval ")#mi("{I^*}")#text(" of twice the length. Let us say that two dyadic intervals ")#mi("{I,J}")#text(" are ")#emph[#text("close")]#text(", and write ")#mi("{I \\sim J}")#text(", if they are the same length and are disjoint, but whose parents ")#mi("{I^*, J^*}")#text(" are not disjoint. Observe that if ")#mi("{I \\sim J}")#text(" then ")#tao-math("{\\left|I\\right|=\\left|J\\right| \\sim \\mathrm{dist}(I,J)}", block: false)#text(" and almost every pair ")#mi("{(\\theta_1,\\theta_2) \\in [0,1/4]}")#text(" lies in exactly one pair of the form ")#mi("{I \\times J}")#text(" with ")#mi("{I \\sim J}")#text(". Therefore we can decompose ")#link(<tao-e81935fb86434cdaaeee>)[#text("(42)")]#text(" as the sum of")

#align(center)[#tao-fit-display[#mitex("(2\\pi)^2 \\int_{I \\times J} 1_E(\\phi(\\theta_1)) 1_E(\\phi(\\theta_2)) e^{2\\pi i x \\cdot (\\phi(\\theta_1)+\\phi(\\theta_2))}\\ d\\theta_1 d\\theta_2")]]

#text("where ")#mi("{I,J}")#text(" range over pairs of close dyadic intervals, leading to the decomposition")

#align(center)[#tao-fit-display[#mitex("(1_E\\ d\\sigma_{[0,1/4]})^\\vee (1_E\\ d\\sigma_{[0,1/4]})^\\vee = \\sum_{I \\sim J} (1_E\\ d\\sigma_I)^\\vee (1_E\\ d\\sigma_J)^\\vee.")]]

#text("We perform a triangle inequality based on the length ")#tao-math("{2^{-k} = \\left|I\\right|=\\left|J\\right|}", block: false)#text(" of the dyadic intervals, thus it will suffice to show that ")#metadata(none) <tao-360f84035942243c6a36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\sum_{k>0} \\left\\| \\sum_{I \\sim J: \\left|I\\right|=\\left|J\\right|=2^{-k}} (1_E\\ d\\sigma_I)^\\vee (1_E\\ d\\sigma_J)^\\vee \\right\\|_{L^{q/2}({\\bf R}^2)} \\lesssim_q \\sigma_{[0,1/4]}( E )^{2 - 6/q}.", block: true)]]

#text(" One could apply the triangle inequality a second time to pull out the sum on the left-hand side, but this turns out to be too inefficient for certain ranges of ")#mi("{q}")#text(". Instead we need to exploit some further orthogonality of the factors ")#mi("{(1_E\\ d\\sigma_I)^\\vee (1_E\\ d\\sigma_J)^\\vee}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{k>0}")#text(".")

#list(
[#text("(i) Show that for each pair ")#mi("{I, J}")#text(" with ")#mi("{I \\sim J}")#text(" and ")#tao-math("{\\left|I\\right|=\\left|J\\right|=2^{-k}}", block: false)#text(", the function ")#mi("{(1_E\\ d\\sigma_I)^\\vee (1_E\\ d\\sigma_J)^\\vee}")#text(" has Fourier transform supported in a rectangle ")#mi("{R_{I,J}}")#text(" in ")#mi("{{\\bf R}^2}")#text(" with the property that the dilates ")#mi("{2 R_{I,J}}")#text(" of these rectangles (the rectangle of twice the sidelengths of ")#mi("{R_{I,J}}")#text(" but the same center) have bounded overlap (any point in ")#mi("{{\\bf R}^2}")#text(" is contained in ")#mi("{O(1)}")#text(" of these dilates ")#mi("{2 R_{I,J}}")#text(").")],
[#text("(ii) Establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{I,J: I \\sim J; \\left|I\\right|=\\left|J\\right|=2^{-k}} f_{I,J} \\right\\|_{L^p({\\bf R}^2)} \\lesssim (\\sum_{I,J: I \\sim J; \\left|I\\right|=\\left|J\\right|=2^{-k}} \\left\\| f_{I,J} \\right\\|_{L^p({\\bf R}^2)}^{\\min(p,p^{\\prime})})^{1/\\min(p,p^{\\prime})}", block: true)]]

#text("for all ")#mi("{1 \\leq p \\leq \\infty}")#text(" and all functions ")#mi("{f_{I,J} \\in L^p({\\bf R}^2)}")#text(" whose Fourier transform is supported in ")#mi("{R_{I,J}}")#text(". (")#emph[#text("Hint:")]#text(" one needs to apply an interpolation theorem, but one has to take care to make sure the interpolation is rigorous.)")]
)
]

#text("Using the above exercise, we can bound the left-hand side of ")#link(<tao-360f84035942243c6a36>)[#text("(28)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\sum_{k>0} (\\sum_{I \\sim J: \\left|I\\right|=\\left|J\\right|=2^{-k}} \\left\\| (1_E\\ d\\sigma_I)^\\vee (1_E\\ d\\sigma_J)^\\vee \\right\\|_{L^{q/2}({\\bf R}^2)}^{(q/2)^{\\prime}})^{1/(q/2)^{\\prime}}.", block: true)]]

#text("Applying ")#link(<tao-1759f7a2eb8085ca9435>)[#text("(26)")]#text(", this is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\sum_{k>0} (\\sum_{I \\sim J: \\left|I\\right|=\\left|J\\right|=2^{-k}} (\\left|I\\right|^{-2/q} \\left\\| 1_E \\right\\|_{L^{(q/2)^{\\prime}}(d\\sigma_I)} \\left\\| 1_E \\right\\|_{L^{(q/2)^{\\prime}}(d\\sigma_J)})^{(q/2)^{\\prime}})^{1/(q/2)^{\\prime}};", block: true)]]

#text("since ")#mi("{1/(q/2)^{\\prime} = 1-2/q}")#text(", this simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\lesssim_q \\sum_{k>0} 2^{2k/q} (\\sum_{I \\sim J: \\left|I\\right|=\\left|J\\right|=2^{-k}} \\sigma_I(E) \\sigma_J(E))^{1-2/q}.", block: true)]]

#text("Bounding ")#mi("{\\sigma_I(E) \\sigma_J(E) \\lesssim \\sigma_I(E)^2 + \\sigma_J(E)^2}")#text(" and noting that each ")#mi("{I}")#text(" is close to only ")#mi("{O(1)}")#text(" intervals ")#mi("{J}")#text(" and vice versa, we can bound this by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim_q \\sum_{k>0} 2^{2k/q} (\\sum_{I: \\left|I\\right|=2^{-k}} \\sigma_I(E)^2)^{1-2/q}.", block: true)]]

#text("Since ")#mi("{\\sigma_I(E) \\leq \\min(2^{-k}, \\sigma_{[0,1/4]}(E))}")#text(" and ")#tao-math("{\\sum_{I: \\left|I\\right|=2^{-k}} \\sigma_I(E) \\leq \\sigma_{[0,1/4]}(E)}", block: false)#text(", we can bound this by")

#align(center)[#tao-fit-display[#mitex("\\lesssim_q \\sum_{k>0} 2^{2k/q} (\\sigma_{[0,1/4]}(E) \\min( 2^{-k}, \\sigma_{[0,1/4]}(E)) )^{1-2/q},")]]

#text("and a routine calculation (dividing into the regimes ")#mi("{2^{-k} \\leq \\sigma_{[0,1/4]}(E)}")#text(" and ")#mi("{2^{-k} > \\sigma_{[0,1/4]}(E)}")#text(" and using the hypothesis ")#mi("{q>4}")#text(") shows that the right-hand side is ")#mi("{\\lesssim_q \\sigma_{[0,1/4]}(E)^{2-6/q}}")#text(" as required. This completes the proof of Theorem ")#link(<tao-8dc179570516ec1a38c7>)[#text("20")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Bilinear restriction for paraboloid implies linear restriction)")]#text(" It is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2033842")[#text("a known theorem")]#text(" (first conjectured by Klainerman and Machedon) that one has the bilinear restriction theorem ")#metadata(none) <tao-a93ac0b6b9070111801e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\left\\| (g_1\\ d\\mu_{S_1})^\\vee (g_2\\ d\\mu_{S_2})^\\vee \\right\\|_{L^q({\\bf R}^d)} \\lesssim_{q,d,S_1,S_2} \\left\\|g_1\\right\\|_{L^2(\\mu_{S_1})} \\left\\|g_2\\right\\|_{L^2(\\mu_{S_2})}", block: true)]]

#text(" whenever ")#mi("{d \\geq 2}")#text(", ")#mi("{q > \\frac{d+2}{d}}")#text(", disjoint compact subsets ")#mi("{S_1,S_2}")#text(" of ")#mi("{{\\bf R}^{d-1}}")#text(", and functions ")#mi("{g_1,g_2 \\in C^\\infty_c({\\bf R}^d)}")#text(", where ")#mi("{\\mu_S}")#text(" denotes the measure given by the integral")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} f(\\xi)\\ d\\mu_S(\\xi) := \\int_S f(\\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2)\\ d\\xi^{\\prime}.", block: true)]]

#text("(The range ")#mi("{q > \\frac{d+2}{d}}")#text(" is known to be sharp for ")#link(<tao-a93ac0b6b9070111801e>)[#text("(29)")]#text(" except possibly for the endpoint ")#mi("{q = \\frac{d+2}{d}}")#text(", which remains open currently.) Assuming this result, show that Conjecture ")#link(<tao-910cd9c0fbf44ca52706>)[#text("15")]#text(" holds for all ")#mi("{p < \\frac{2(d+2)}{d+4}}")#text(". (")#emph[#text("Hint:")]#text(" one repeats the above arguments, but at one point one will be faced with estimating a bilinear expression involving two “close” regions ")#mi("{S_1,S_2}")#text(", which could be very large or very small. The hypothesis ")#link(<tao-a93ac0b6b9070111801e>)[#text("(29)")]#text(" does not specify how the implied constants depend on the size or location of ")#mi("{S_1,S_2}")#text(", but one can obtain such a dependence by exploiting the parabolic rescaling and Galilean symmetries of the paraboloid.)")
]

#heading(level: 1)[#strong[#text(" — 4. Multilinear estimates — ")]]

#text("We now turn to multilinear (or more precisely, ")#mi("{d}")#text("-linear) Kakeya and restriction estimates, where we happen to have nearly optimal estimates. For instance, we have the following estimate (cf. ")#link(<tao-5a376993386af8e4af5c>)[#text("(17)")]#text("), first ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("established by Bennett, Carbery, and myself")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Multilinear Kakeya estimate)")]#text(" ")#metadata(none) <tao-a02cd7e1c6810a9ab2ec>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{c \\geq 0}")#text(" be sufficiently small, and let ")#mi("{0 < \\delta < 1}")#text(". Suppose that ")#mi("{{\\mathcal T}_1,\\dots,{\\mathcal T}_d}")#text(" are collections of ")#mi("{\\delta \\times 1}")#text(" tubes such that each tube ")#mi("{T_i}")#text(" in ")#mi("{{\\mathcal T}_i}")#text(" is oriented within ")#mi("{c}")#text(" of the basis vector ")#mi("{e_i}")#text(". Then we have ")#metadata(none) <tao-0e07cf830957701d43c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon} \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text(" for any ")#mi("{\\varepsilon>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Assuming Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(", obtain an estimate for ")#tao-math("{\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{p}({\\bf R}^d)}}", block: false)#text(" for any ")#mi("{\\frac{1}{d} \\leq p < \\infty}")#text(" in terms of ")#mi("{\\delta}")#text(" and ")#mi("{\\prod_{i=1}^d \\# {\\mathcal T}_i}")#text(", and use examples to show that this estimate is optimal in the sense that the exponents for ")#mi("{\\delta}")#text(" and ")#mi("{\\prod_{i=1}^d \\# {\\mathcal T}_i}")#text(" can only be improved by epsilon factors at best, and that no such estimate is available for ")#mi("{0 < p < \\frac{1}{d}}")#text(".")
]

#text("In the two-dimensional case ")#mi("{d=2}")#text(" the estimate is easily established with no epsilon loss. Indeed, in this case we can expand the left-hand side of ")#link(<tao-0e07cf830957701d43c1>)[#text("(30)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} (\\sum_{T_1 \\in {\\mathcal T}_1} 1_{T_1}) (\\sum_{T_2 \\in {\\mathcal T}_2} 1_{T_2})")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{T_1 \\in {\\mathcal T}_1} \\sum_{T_2 \\in {\\mathcal T}_2} |T_1 \\cap T_2|.")]]

#text("But if ")#mi("{T_1}")#text(" is a ")#mi("{\\delta \\times 1}")#text(" rectangle oriented near ")#mi("{e_1}")#text(", and ")#mi("{T_2}")#text(" is a ")#mi("{\\delta \\times 1}")#text("-rectangle oriented near ")#mi("{e_2}")#text(", then ")#tao-math("{\\left|T_1 \\cap T_2\\right|}", block: false)#text(" is comparable with ")#mi("{\\delta^2}")#text(", and the claim follows.")#linebreak()#text(" The epsilon loss was removed in general dimension ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2746348")[#text("by Guth")]#text(", using the polynomial method. We will not give that argument here, but instead give a simpler proof of Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(", also ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3300318")[#text("due to Guth")]#text(", and based primarily on the method of ")#emph[#text("induction on scales")]#text(". We first treat the case when ")#mi("{c=0}")#text(", that is when all the tubes in each family ")#mi("{{\\mathcal T}_i}")#text(" are completely parallel:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Loomis%E2%80%93Whitney_inequality")[#text("Loomis-Whitney inequality")]#text(") Let ")#mi("{d \\geq 2}")#text(", and for each ")#mi("{i=1,\\dots,d}")#text(", let ")#mi("{\\pi_i: {\\bf R}^d \\rightarrow {\\bf R}^{d-1}}")#text(" be the linear projection ")#mi("{\\pi_i(x_1,\\dots,x_d) := (x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_d)}")#text(". Establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} \\prod_{i=1}^d f_i(\\pi_i(x))\\ dx\\right| \\leq \\prod_{i=1}^d \\left\\| f_i \\right\\|_{L^{d-1}({\\bf R}^{d-1})}", block: true)]]

#text("for all ")#mi("{f_1,\\dots,f_d \\in L^{d-1}({\\bf R}^{d-1})}")#text(". (")#emph[#text("Hint:")]#text(" induct on ")#mi("{d}")#text(" and use Hölder’s inequality and the Fubini-Tonelli theorem.)")],
[#text("(ii) Establish Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(" in the case ")#mi("{c=0}")#text(".")]
)
]

#text("Now we turn to the case of positive ")#mi("{c}")#text(". Fix ")#mi("{d}")#text(". For any ")#mi("{0 < c, \\delta \\leq 1}")#text(", let ")#mi("{K_c(\\delta)}")#text(" denote the best constant in the inequality ")#metadata(none) <tao-d7cea7305a333d5c9ceb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\leq K_c(\\delta) \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text(" whenever ")#mi("{{\\mathcal T}_1,\\dots,{\\mathcal T}_d}")#text(" are collections of ")#mi("{\\delta \\times 1}")#text(" tubes such that each tube ")#mi("{T_i}")#text(" in ")#mi("{{\\mathcal T}_i}")#text(" is oriented within ")#mi("{c}")#text(" of the basis vector ")#mi("{e_i}")#text(". Note that each tube ")#mi("{T_i}")#text(" can be covered by ")#mi("{O_d( (1+c/\\delta)^{d-1} )}")#text(" ")#mi("{\\delta \\times 1}")#text(" tubes whose direction is ")#emph[#text("exactly")]#text(" equal to ")#mi("{e_i}")#text(". From this we obtain the crude bound")

#align(center)[#tao-fit-display[#mitex("K_c(\\delta) \\lesssim_d (1+c/\\delta)^{d(d-1)}.")]]

#text("In particular, ")#mi("{K_c(\\delta)}")#text(" is finite, and we have ")#metadata(none) <tao-27981437250f8de06c27>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("K_c(\\delta) \\lesssim_d 1")]]

#text(" whenever ")#mi("{\\delta > c}")#text(". Our objective is to show that ")#mi("{K_c(\\delta) \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon}}")#text(" whenever ")#mi("{c}")#text(" is sufficiently small, ")#mi("{\\varepsilon>0}")#text(", and ")#mi("{0 < \\delta \\leq 1}")#text(". The bound ")#link(<tao-27981437250f8de06c27>)[#text("(32)")]#text(" establishes the claim when ")#mi("{\\delta}")#text(" is large; the strategy is now to use the ")#emph[#text("induction on scales")]#text(" method to push this “base case” bound down to smaller values of ")#mi("{\\delta}")#text(". The key estimate is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29 (Iteration)")]#text(" ")#metadata(none) <tao-aa82c33012cb40613015>#text(" If ")#mi("{d \\geq 2}")#text(" and ")#mi("{0 < c, \\delta \\leq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("K_c(\\delta) \\lesssim_d K_c(\\sqrt{\\delta}) \\times K_c(\\sqrt{\\delta}).")]]
]

#emph[#text("Proof:")]#text(" For each ")#mi("{i=1,\\dots,d}")#text(", let ")#mi("{{\\mathcal T}_i}")#text(" be a collection of ")#mi("{\\delta \\times 1}")#text(" tubes oriented within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(". Our objective is to show that ")#metadata(none) <tao-69b22a06ce5c5ca19c4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_d K_c(\\sqrt{\\delta})^2 \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i.", block: true)]]

#text(" Let ")#mi("{c_0>0}")#text(" be a small constant depending only on ")#mi("{d}")#text(". We partition ")#mi("{{\\bf R}^d}")#text(" into cubes ")#mi("{Q}")#text(" of sidelength ")#mi("{c_0 \\sqrt{\\delta}}")#text(", then the left-hand side of ")#link(<tao-69b22a06ce5c5ca19c4c>)[#text("(33)")]#text(" can be decomposed as")

#align(center)[#tao-fit-display[#tao-math("( \\sum_Q \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}(Q)}^{1/(d-1)})^{d-1}.", block: true)]]

#text("Clearly we can restrict the inner sum to those tubes ")#mi("{T_i}")#text(" that actually intersect ")#mi("{Q}")#text(". For ")#mi("{c_0}")#text(" small enough, the intersection of ")#mi("{T_i}")#text(" with ")#mi("{Q}")#text(" is contained in a ")#mi("{\\delta \\times \\sqrt{\\delta}}")#text(" tube oriented within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text("; such a tube can be viewed as a rescaling by ")#mi("{\\sqrt{\\delta}}")#text(" of a ")#mi("{\\sqrt{\\delta} \\times 1}")#text(" tube, also oriented within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(". From ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("(31)")]#text(" and rescaling we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}(Q)}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq (\\sqrt{\\delta})^{d(d-1)} K_c(\\sqrt{\\delta}) \\prod_{i=1}^d \\sqrt{\\delta}^{d-1} \\# \\{ T_i \\in {\\mathcal T}_i: T_i \\cap Q \\neq \\emptyset\\}.")]]

#text("Now let ")#mi("{T^*_i}")#text(" be the ")#mi("{2\\sqrt{\\delta} \\times 2}")#text(" tube with the same central axis and center of mass as ")#mi("{T_i}")#text(". For ")#mi("{c_0}")#text(" small enough, if ")#mi("{T_i \\cap Q \\neq \\emptyset}")#text(" then ")#mi("{1_{T^*_i}}")#text(" equals ")#mi("{1}")#text(" on all of ")#mi("{Q}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^d \\# \\{ T_i \\in {\\mathcal T}_i: T_i \\cap Q \\neq \\emptyset\\} \\lesssim_{c_0,d} \\sqrt{\\delta}^{-d(d-1)} \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T^*_i} \\right\\|_{L^{1/(d-1)}(Q)}.", block: true)]]

#text("Combining all these estimates, we can bound the left-hand side of ")#link(<tao-69b22a06ce5c5ca19c4c>)[#text("(33)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim_{c_0,d} (\\sqrt{\\delta})^{d(d-1)} K_c(\\sqrt{\\delta}) \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T^*_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)}.", block: true)]]

#text("But by ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("(31)")]#text(" and rescaling we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T^*_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_d K_c(\\sqrt{\\delta}) \\prod_{i=1}^d \\sqrt{\\delta}^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" We remark that the same argument also gives the more general estimate ")#mi("{K_c(\\delta_1 \\delta_2) \\lesssim_d K_c(\\delta_1) K_c(\\delta_2)}")#text(" whenever ")#mi("{0 < c,\\delta_1,\\delta_2 \\leq 1}")#text(".")#linebreak()#text(" Now let ")#mi("{\\varepsilon>0}")#text(", and let ")#mi("{A>1}")#text(" be sufficiently large depending on ")#mi("{d}")#text(". If ")#mi("{c>0}")#text(" is sufficiently small depending on ")#mi("{A,\\varepsilon,d}")#text(", then from ")#link(<tao-27981437250f8de06c27>)[#text("(32)")]#text(" we have the claim ")#metadata(none) <tao-525eca1d5089dbdcbb67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("K_c(\\delta) \\leq A^{-1} \\delta^{-\\varepsilon}")]]

#text(" whenever ")#mi("{c \\leq \\delta \\leq \\sqrt{c}}")#text(". On the other hand, from Proposition ")#link(<tao-aa82c33012cb40613015>)[#text("29")]#text(" we see (for ")#mi("{A}")#text(" large enough) that if ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(34)")]#text(" holds in some range ")#mi("{r \\leq \\delta \\leq \\sqrt{c}}")#text(" with ")#mi("{r \\leq c}")#text(" then it also holds in the larger range ")#mi("{r^2 \\leq \\delta \\leq \\sqrt{c}}")#text(". By induction we then have ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(34)")]#text(" for all ")#mi("{0 < \\delta \\leq \\sqrt{c}}")#text(". Combining this with ")#link(<tao-27981437250f8de06c27>)[#text("(32)")]#text(", we have shown that")

#align(center)[#tao-fit-display[#mitex("K_c(\\delta) \\lesssim_d \\delta^{-\\varepsilon}")]]

#text("for all ")#mi("{0 < \\delta < 1}")#text(", whenever ")#mi("{c}")#text(" is sufficiently small depending on ")#mi("{\\varepsilon,d}")#text(". This is ")#emph[#text("almost")]#text(" what we need to prove Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(", except that we are requiring ")#mi("{c}")#text(" to be small depending on ")#mi("{\\varepsilon}")#text(" as well as ")#mi("{d}")#text(", whereas Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(" only requires ")#mi("{c}")#text(" to be sufficiently small depending on ")#mi("{d}")#text(" and not ")#mi("{\\varepsilon}")#text(". We can overcome this (at the cost of worsening the implied constants by an ")#mi("{\\varepsilon}")#text("-dependent factor) by the triangle inequality and exploiting affine invariance (somewhat in the spirit of Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("9")]#text("). Namely, suppose that ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{c}")#text(" is only assumed to be small depending on ")#mi("{d}")#text(" but not on ")#mi("{\\varepsilon}")#text(". By what we have previously established, we have ")#metadata(none) <tao-22b3cf5281ba12d71f33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_d \\delta^{-\\varepsilon} \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text(" whenever the tubes ")#mi("{T_i}")#text(" lie within ")#mi("{c_\\varepsilon}")#text(" of ")#mi("{e_i}")#text(", where ")#mi("{c_\\varepsilon>0}")#text(" is a quantity that is sufficiently small depending on ")#mi("{\\varepsilon,d}")#text(". Now we apply a linear transformation to both sides, and also modify ")#mi("{\\delta}")#text(" slightly, and conclude that for any ")#mi("{\\omega_i}")#text(" within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(", we still have the bound ")#link(<tao-22b3cf5281ba12d71f33>)[#text("(35)")]#text(" if the ")#mi("{T_i}")#text(" are assumed to lie within ")#mi("{c_\\varepsilon/2}")#text(" (say) of ")#mi("{\\omega_i}")#text(" instead of ")#mi("{e_i}")#text(". On the other hand, by compactness (or more precisely, total boundedness), we can find ")#mi("{O_{c_\\varepsilon,c,d}(1)}")#text(" directions ")#mi("{\\omega_i}")#text(" that lie within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(", such that any other direction that lies within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(" lies within ")#mi("{c_\\varepsilon/2}")#text(" of one of the ")#mi("{\\omega_i}")#text(". Applying the (quasi-)triangle inequality for ")#mi("{L^{1/(d-1)}}")#text(", we conclude that ")#metadata(none) <tao-1c142d5dd3844d22fa35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon} \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text(" whenever the direction of ")#mi("{T_i}")#text(" are merely assumed to lie within ")#mi("{c}")#text(" of ")#mi("{e_i}")#text(". This concludes the proof of Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-04ac4067b6af83a7ef4a>#text(" By optimising the parameters in the above argument, refine the estimate in Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(" slightly to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i} \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\lesssim_{d} \\exp( O_d(\\sqrt{\\log \\frac{1}{\\delta}}) ) \\prod_{i=1}^d \\delta^{d-1} \\# {\\mathcal T}_i", block: true)]]

#text("for any ")#mi("{0 < \\delta \\leq \\frac{1}{2}}")#text(".")
]

#text("We can use the multilinear Kakeya estimate to prove a multilinear restriction (or more precisely, multilinear extension) estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 31 (Multilinear restriction estimate)")]#text(" ")#metadata(none) <tao-a4cbe2d6c48880a0550a>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{c \\geq 0}")#text(" be sufficiently small, and let ")#mi("{R \\geq 1}")#text(". Suppose that ")#mi("{S_1,\\dots,S_d}")#text(" are open subsets of ")#mi("{S^{d-1}}")#text(" that lie within ")#mi("{c}")#text(" of the basis vector ")#mi("{e_i}")#text(". Then we have ")#metadata(none) <tao-597c28c381ef1feee61f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\left\\| \\prod_{i=1}^d (g_i\\ d\\sigma_{S_i})^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))} \\lesssim_{d,\\varepsilon} R^{\\varepsilon} \\prod_{i=1}^d \\left\\| g_i \\right\\|_{L^2(S_i, d\\sigma_{S_i})},", block: true)]]

#text(" for any ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{\\sigma_{S_i}}")#text(" denotes surface measure on ")#mi("{S_i}")#text(" and ")#mi("{g_i \\in C^\\infty({\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" By modifying the arguments used to prove Exercise ")#link(<tao-65d5b3a58321eee93bc6>)[#text("16")]#text("(ii), show that Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(" implies Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Assuming Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(", obtain for each ")#mi("{0 < q < \\infty}")#text(" and ")#mi("{1 < p < \\infty}")#text(" an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d (g_i\\ d\\sigma_{S_i})^\\vee \\right\\|_{L^q(B(0,R))} \\lesssim_{d,\\varepsilon} R^{\\alpha+\\varepsilon} \\prod_{i=1}^d \\left\\|g_i\\right\\|_{L^p(S_i, d\\sigma_i)}", block: true)]]

#text("whenever ")#mi("{\\varepsilon>0}")#text(", ")#mi("{R>1}")#text(", and ")#mi("{g_i \\in L^p(S_i,d\\sigma_i)}")#text(" and some exponent ")#mi("{\\alpha = \\alpha(p,q,d)}")#text(", and use examples to show that the exponent ")#mi("{\\alpha}")#text(" you obtain is best possible.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 34")]#text(" In the ")#mi("{d=2}")#text(" case, this result with no epsilon loss follows from Proposition ")#link(<tao-bb3be5d12d4e85f6a02c>)[#text("21")]#text(". It is an open question whether the epsilon can be removed in higher dimensions; see ")#link("https://arxiv.org/abs/1907.11342")[#text("this recent paper of mine")]#text(" for some progress in this direction.")
]

#text("To prove Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(", we again turn to induction on scales; the argument here is a corrected version of one from ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("this paper of Bennett, Carbery and myself")]#text(", which first appeared in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3204854")[#text("this paper of Bennett")]#text(". Fix ")#mi("{d}")#text(", and let ")#mi("{c>0}")#text(" be sufficiently small. For technical reasons it is convenient to replace the subsets ")#mi("{S_i}")#text(" of the sphere by annuli. More precisely, for each ")#mi("{R \\geq c^{-1}}")#text(", let ")#mi("{C(R)}")#text(" denote the best constant in the inequality ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("\\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))} \\leq C(R) R^{-\\frac{d}{2}} \\prod_{i=1}^d \\left\\| G_i \\right\\|_{L^2(A_{i,R})},", block: true)]]

#text(" whenever ")#mi("{G_i \\in L^2(A_{i,R})}")#text(", where ")#mi("{A_{i,R}}")#text(" is the annular cap")

#align(center)[#tao-fit-display[#tao-math("A_{i,R} := \\{ \\xi \\in {\\bf R}^d: 1-\\frac{1}{R} \\leq \\left|\\xi\\right| \\leq 1+\\frac{1}{R}; \\quad \\left|\\xi - e_i\\right| \\leq c + \\frac{1}{R} \\}.", block: true)]]

#text("The extra factor of ")#mi("{\\frac{1}{R}}")#text(" in the upper bound for ")#tao-math("{\\left|\\xi - e_i\\right|}", block: false)#text(" is technically convenient, as it creates a certain “margin” of room in the nesting ")#mi("{A_{i,R} \\subset A_{i,\\sqrt{R}}}")#text(" that will be useful later on when we perform spatial cutoffs that blur the Fourier support slightly.")#linebreak()#text(" Because we have restricted both the Fourier and spatial domains to be compactly supported it is clear that ")#mi("{C(R)}")#text(" is finite for each ")#mi("{R}")#text(", thus ")#metadata(none) <tao-6f3095ea2b3eeae3895d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("C(R) \\lesssim_{d,R} 1.")]]

#text(" We will show that ")#metadata(none) <tao-53e124d93ccf9ec99364>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("C(R) \\lesssim_{d,\\varepsilon} R^\\varepsilon")]]

#text(" for any ")#mi("{R \\geq c^{-1}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Show that ")#link(<tao-53e124d93ccf9ec99364>)[#text("(40)")]#text(" implies Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(". (")#emph[#text("Hint:")]#text(" starting with ")#mi("{g_i \\in L^2(S_i,d\\sigma_{S_i})}")#text(", multiply ")#mi("{(g_i\\ d\\sigma_{S_i})^\\vee}")#text(" by a suitable weight function that is large on ")#mi("{B(0,R)}")#text(" and has Fourier transform supported on ")#mi("{B(0,1/R)}")#text(", and write this as ")#mi("{G_i^\\vee}")#text(" for a suitable ")#mi("{G_i}")#text(". Then obtain ")#mi("{L^2}")#text(" estimates on ")#mi("{G_i}")#text(".)")
]

#text("To establish ")#link(<tao-53e124d93ccf9ec99364>)[#text("(40)")]#text(", the key estimate is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 36 (Induction on scales)")]#text(" ")#metadata(none) <tao-1cd48562a299d2d34ba6>#text(" For any ")#mi("{R \\geq c^{-2}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("C(R) \\lesssim_d C(\\sqrt{R}) K_{2c}(1/\\sqrt{R})^{1/2}")]]

#text("where the multilinear Kakeya constant ")#mi("{K_{2c}(\\sqrt{R})}")#text(" was defined in ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("(31)")]#text(".")
]

#text("Suppose we can establish this claim. Applying Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(", we conclude that if ")#mi("{R \\geq R_\\varepsilon}")#text(" for a sufficiently large ")#mi("{R_\\varepsilon \\geq c^{-2}}")#text(" depending on ")#mi("{\\varepsilon,d}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("C(R) \\leq C(\\sqrt{R}) \\sqrt{R}^\\varepsilon.")]]

#text("From ")#link(<tao-6f3095ea2b3eeae3895d>)[#text("(39)")]#text(" one has ")#metadata(none) <tao-199fe04c889bda7c09d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("C(R) \\leq C_\\varepsilon R^\\varepsilon")]]

#text(" for all ")#mi("{1 \\leq R \\leq R_\\varepsilon}")#text(" and some ")#mi("{C_\\varepsilon = O_{\\varepsilon,d}(1)}")#text(", and then an easy induction then shows that ")#link(<tao-199fe04c889bda7c09d5>)[#text("(41)")]#text(" holds for all ")#mi("{R \\geq 1}")#text(", giving the claim.")#linebreak()#text(" It remains to prove Proposition ")#link(<tao-1cd48562a299d2d34ba6>)[#text("36")]#text(". We will rely on the ")#emph[#text("wave packet decomposition")]#text(". Informally, this decomposes ")#mi("{G_i^\\vee}")#text(" into a sum of “wave packets” that is approximately of the form ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("G_i^\\vee(x) \\approx \\sum_{T_i} c_{i,T_i} 1_{T_i}(x) e^{2\\pi i x \\cdot \\omega_{T_i}},")]]

#text(" where ")#mi("{T_i}")#text(" ranges over ")#mi("{\\sqrt{R} \\times R}")#text("-tubes in ")#mi("{B(0,R)}")#text(" oriented in various directions ")#mi("{\\omega_{T_i}}")#text(" oriented near ")#mi("{e_i}")#text(", and the coefficients ")#mi("{c_{i,T_i}}")#text(" obey an ")#mi("{L^2}")#text(" type estimate ")#metadata(none) <tao-733859c1fc6b9331793b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\sum_{T_i} \\left|c_{i,T_i}\\right|^2 \\lessapprox R^{-\\frac{d+1}{2}} \\left\\|G_i\\right\\|_{L^2(A_{i,R})}^2.", block: true)]]

#text(" (This decomposition is inaccurate in a number of technical ways, for instance the sharp cutoff ")#mi("{1_{T_i}}")#text(" should be replaced by something smoother, but we ignore these issues for the sake of this informal discussion.) Heuristically speaking, ")#link(<tao-e81935fb86434cdaaeee>)[#text("(42)")]#text(" is asserting that ")#mi("{G_i^\\vee}")#text(" behaves like a superposition of various (translated) Knapp examples ")#link(<tao-0ad081759c63452e407b>)[#text("(16)")]#text(" with ")#mi("{\\delta = R^{-1/2}}")#text(".")#linebreak()#text(" Let us informally indicate why we would expect the wave packet decomposition to hold, and then why it should imply something like Proposition ")#link(<tao-1cd48562a299d2d34ba6>)[#text("36")]#text(". Geometrically, the annular cap ")#mi("{A_{i,R}}")#text(" behaves like the union of essentially disjoint ")#mi("{1/R \\times 1/\\sqrt{R}}")#text("-disks ")#mi("{D_i}")#text(", each centred at some point ")#mi("{\\omega_{D_i}}")#text(" on the unit sphere that is close to ")#mi("{e_i}")#text(", and oriented normal to the direction ")#mi("{\\omega_{D_i}}")#text(". Thus ")#mi("{G_i^\\vee}")#text(" should behave like the sum of the components ")#mi("{(G_i 1_{D_i})^\\vee}")#text(". By the uncertainty principle, each such component ")#mi("{(G_i 1_{D_i})^\\vee}")#text(" should behave like a constant multiple of the plane wave ")#mi("{e^{2\\pi ix \\cdot \\omega_{D_i}}}")#text(" on each translate of the dual region ")#mi("{D_i^\\perp}")#text(" to ")#mi("{D_i}")#text(", which is a ")#mi("{\\sqrt{R} \\times R}")#text(" tube oriented in the direction ")#mi("{\\omega_{D_i}}")#text(". By Plancherel’s theorem, the total ")#mi("{L^2}")#text(" norm of ")#mi("{(G_i 1_{D_i})^\\vee}")#text(" should equal ")#tao-math("{\\left\\| G_i\\right\\|_{L^2(D_i)}}", block: false)#text(". Thus we expect to have a decomposition roughly of the form")

#align(center)[#tao-fit-display[#mitex("(G_i 1_{D_i})^\\vee(x) \\approx \\sum_{T_i \\in {\\mathcal T}_{D_i}} c_{i,T_i} 1_{T_i}(x) e^{2\\pi i x \\cdot \\omega_{D_i}}")]]

#text("where ")#mi("{{\\mathcal T}_{D_i}}")#text(" is a collection of parallel and boundedly overlapping ")#mi("{\\sqrt{R} \\times R}")#text(" tubes ")#mi("{T_i}")#text(" oriented in the direction ")#mi("{\\omega_{D_i}}")#text(", and the ")#mi("{c_{i,T}}")#text(" are coefficients with")

#align(center)[#tao-fit-display[#tao-math("R^{\\frac{d+1}{2}} \\sum_{T_i \\in {\\mathcal T}_{D_i}} \\left|c_{i,T_i}\\right|^2 \\approx \\left\\| G_i 1_{D_i} \\right\\|_{L^2({\\bf R}^d)}^2.", block: true)]]

#text("Summing over ")#mi("{D_i}")#text(" and collecting powers of ")#mi("{R}")#text(", we (heuristically) obtain the wave packet decomposition ")#link(<tao-e81935fb86434cdaaeee>)[#text("(42)")]#text(" with bound ")#link(<tao-733859c1fc6b9331793b>)[#text("(43)")]#text(".")#linebreak()#text(" Now we informally explain why the decomposition ")#link(<tao-e81935fb86434cdaaeee>)[#text("(42)")]#text(" (and attendant bound ")#link(<tao-733859c1fc6b9331793b>)[#text("(43)")]#text(") should yield Proposition ")#link(<tao-1cd48562a299d2d34ba6>)[#text("36")]#text(". Our task is to show that ")#metadata(none) <tao-0ddc70666215b083611c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#tao-math("\\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))} \\lesssim_d C(\\sqrt{R}) K_{2c}(\\sqrt{R})^{1/2} R^{-d/2} \\prod_{i=1}^d \\left\\| G_i \\right\\|_{L^2(A_{i,R})}", block: true)]]

#text(" for ")#mi("{G_i \\in L^2(A_{i,R})}")#text(". We may as well normalise ")#tao-math("{\\left\\| G_{i} \\right\\|_{L^2(A_{i,R})}=1}", block: false)#text(". Applying the wave packet decomposition, one expects to have an approximation of the form")

#align(center)[#tao-fit-display[#mitex("G_i^\\vee(x) \\approx \\sum_{T_i \\in {\\mathcal T}_i} c_{i,T_i} 1_{T_i}(x) e^{2\\pi i x \\cdot \\omega_{T_i}}")]]

#text("for some coefficients ")#mi("{c_{i,T_i}}")#text(" with ")#metadata(none) <tao-0d45f5fd462b8c70bffb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\sum_{T_i \\in {\\mathcal T}_i} \\left|c_{i,T_i}\\right|^2 \\lessapprox R^{-\\frac{d+1}{2}}", block: true)]]

#text(" and the ")#mi("{T_i}")#text(" are essentially distinct ")#mi("{\\sqrt{R} \\times R}")#text(" tubes oriented within ")#mi("{2c}")#text(" of ")#mi("{e_i}")#text(". We cover ")#mi("{B(0,R)}")#text(" by balls ")#mi("{B(x_0,\\sqrt{R})}")#text(" of radius ")#mi("{\\sqrt{R}}")#text(". On each such ball, the cutoffs ")#mi("{1_{T_i}(x)}")#text(" are morally constant, and so ")#metadata(none) <tao-909104cdb5b06af2606e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#tao-math("\\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))}", block: true)]]



#align(center)[#tao-fit-display[#tao-math("\\approx \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i: x_0 \\in T_i} c_{i,T_i} e^{2\\pi i x \\cdot \\omega_{T_i}} \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))}.", block: true)]]

#text("From the uncertainty principle, the trigonometric polynomial ")#mi("{\\sum_{T_i \\in {\\mathcal T}_i: x_0 \\in T_i} c_{i,T_i} e^{2\\pi i x \\cdot \\omega_{T_i}}}")#text(" behaves on ")#mi("{B(x_0,\\sqrt{R})}")#text(" like the inverse Fourier transform ")#mi("{G_{i,x_0}^\\vee}")#text(" of a function ")#mi("{G_{i,x_0}}")#text(" supported on ")#mi("{A_{i,\\sqrt{R}}}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G_{i,x_0} \\right\\|_{L^2(A_{i,\\sqrt{R}})}^2 \\approx \\sqrt{R}^{d} \\sum_{T_i \\in {\\mathcal T}_i: x_0 \\in T_i} \\left|c_{i,T_i}\\right|^2", block: true)]]

#text("and hence by ")#link(<tao-597c28c381ef1feee61f>)[#text("(38)")]#text(" we expect the expression ")#link(<tao-909104cdb5b06af2606e>)[#text("(46)")]#text(" to be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox C(\\sqrt{R}) \\sqrt{R}^{-d/2} \\prod_{i=1}^d \\sqrt{R}^{\\frac{d}{2}} (\\sum_{T_i \\in {\\mathcal T}_i: x_0 \\in T_i} \\left|c_{i,T_i}\\right|^2)^{1/2}", block: true)]]

#text("which is also morally")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox C(\\sqrt{R}) \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} \\left|c_{i,T_i}\\right|^2 1_{T_i} \\right\\|_{L^{1/(d-1)}(B(x_0,\\sqrt{R}))}^{1/2}.", block: true)]]

#text("Averaging in ")#mi("{x_0}")#text(", we thus expect the left-hand side of ")#link(<tao-0ddc70666215b083611c>)[#text("(44)")]#text(" to be")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox C(\\sqrt{R}) \\left\\| \\prod_{i=1}^d \\sum_{T_i \\in {\\mathcal T}_i} \\left|c_{i,T_i}\\right|^2 1_{T_i} \\right\\|_{L^{1/(d-1)}(B(0,R))}^{1/2}.", block: true)]]

#text("Applying a rescaled (and weighted) version of Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(", this is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox C(\\sqrt{R}) (K_{2c}(1/\\sqrt{R}))^{1/2} \\prod_{i=1}^d \\sqrt{R}^{\\frac{d-1}{2}} (\\sum_{T_i \\in {\\mathcal T}_i} \\left|c_{i,T_i}\\right|^2)^{1/2}", block: true)]]

#text("and the claim now follows from ")#link(<tao-0d45f5fd462b8c70bffb>)[#text("(45)")]#text(".")#linebreak()#text(" Now we begin the rigorous argument. We need to prove ")#link(<tao-0ddc70666215b083611c>)[#text("(44)")]#text(", and we normalise ")#tao-math("{\\left\\| G_{i} \\right\\|_{L^2(A_{i,R})}=1}", block: false)#text(". By Fubini’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_d (R^{-d/2} \\int_{B(0,R)} \\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))}^{2/(d-1)}\\ dx_0)^{(d-1)/2}.", block: true)]]

#text("Let ")#mi("{\\phi}")#text(" be a fixed Schwartz function that is bounded away from zero on ")#mi("{B(0,1)}")#text(" and has Fourier transform supported on ")#mi("{B(0,1/2)}")#text(", thus the function ")#mi("{\\phi^{x_0}_{\\sqrt{R}}(x) := \\phi(\\frac{x-x_0}{\\sqrt{R}})}")#text(" is bounded away from zero on ")#mi("{B(x_0,\\sqrt{R})}")#text(" and has Fourier transform supported on ")#mi("{B(0,1/2\\sqrt{R})}")#text(". In particular we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))} \\lesssim_d \\left\\| \\prod_{i=1}^d \\phi^{x_0}_{\\sqrt{R}} G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))}.", block: true)]]

#text("We can write")

#align(center)[#tao-fit-display[#mitex("\\phi^{x_0}_{\\sqrt{R}} G_i^\\vee = (G_i * \\widehat{\\phi^{x_0}_{\\sqrt{R}}})^\\vee")]]

#text("and observe that ")#mi("{(G_i * \\widehat{\\phi^{x_0}_{\\sqrt{R}}})^\\vee}")#text(" has Fourier transform supported in ")#mi("{A_{i,\\sqrt{R}}}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d \\phi^{x_0}_{\\sqrt{R}} G_i^\\vee \\right\\|_{L^{2/(d-1)}(B(x_0,\\sqrt{R}))}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq C(\\sqrt{R}) \\sqrt{R}^{-d/2} \\prod_{i=1}^d \\left\\| G_i * \\widehat{\\phi^{x_0}_{\\sqrt{R}}} \\right\\|_{L^2(A_{i,\\sqrt{R}})}.", block: true)]]

#text("Thus it remains to establish the bound ")#metadata(none) <tao-411b0496da5eeced5314>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("(R^{-d/2} \\int_{B(0,R)} \\prod_{i=1}^d \\left\\| G_i * \\widehat{\\phi^{x_0}_{\\sqrt{R}}} \\right\\|_{L^2(A_{i,\\sqrt{R}})}^{2/(d-1)}\\ dx_0)^{(d-1)/2}", block: true)]]



#align(center)[#tao-fit-display[#mitex("\\lesssim K_{2c}(1/\\sqrt{R})^{1/2} \\sqrt{R}^{-d/2}.")]]

#text("We cover ")#mi("{A_{i,R}}")#text(" by a collection of ")#mi("{O(1/\\sqrt{R}) \\times O(1/R)}")#text(" disks ")#mi("{D_i}")#text(", each one centered at an element ")#mi("{\\omega_{D_i} \\in S^{d-1}}")#text(" that lies within ")#mi("{2c}")#text(" of ")#mi("{e_i}")#text(", and is oriented with normal ")#mi("{\\omega_{D_i}}")#text(", with the ")#mi("{\\omega_{D_i}}")#text(" separated from each other by ")#mi("{\\gg 1/\\sqrt{R}}")#text(". A partition of unity then lets us write ")#mi("{G_i = \\sum_{D_i} G_{i,D_i}}")#text(" where each ")#mi("{G_{i,D_i} \\in L^2(D_i)}")#text(" with ")#metadata(none) <tao-4d2f4b668cfc48e6059d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#tao-math("\\sum_{D_i} \\left\\| G_{i,D_i}\\right\\|_{L^2(D_i)}^2 = 1.", block: true)]]

#text(" The functions ")#mi("{G_{i,D_i} * \\widehat{\\phi^{x_0}_{\\sqrt{R}}}}")#text(" then have bounded overlapping supports in the sense that every ")#mi("{\\xi \\in {\\bf R}^d}")#text(" is contained in at most ")#mi("{O_d(1)}")#text(" of these supports. Hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G_i * \\widehat{\\phi^{x_0}_{\\sqrt{R}}} \\right\\|_{L^2(A_{i,\\sqrt{R}})}^2 \\lesssim_d \\sum_{D_i} \\left\\| G_{i,D_i} * \\widehat{\\phi^{x_0}_{\\sqrt{R}}} \\right\\|_{L^2(A_{i,\\sqrt{R}})}^2.", block: true)]]

#text("By Plancherel’s theorem the right-hand side is at most")

#align(center)[#tao-fit-display[#tao-math("\\sum_{D_i} \\left\\| G_{i,D_i}^\\vee \\phi^{x_0}_{\\sqrt{R}} \\right\\|_{L^2({\\bf R}^d)}^2.", block: true)]]

#text("This is morally bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{D_i} \\left\\| G_{i,D_i}^\\vee \\right\\|_{L^2(B(x_0,\\sqrt{R}))}^2", block: true)]]

#text("so one has morally bounded the left-hand side of ")#link(<tao-411b0496da5eeced5314>)[#text("(47)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("(R^{-d/2} \\int_{B(0,R)} \\prod_{i=1}^d (\\sum_{D_i} \\left\\| G_{i,D_i}^\\vee \\right\\|_{L^2(B(x_0,\\sqrt{R}))}^2)^{1/(d-1)}\\ dx_0)^{(d-1)/2}.", block: true)]]

#text("In practice, due to the rapid decay of ")#mi("{\\phi^{x_0}_{\\sqrt{R}}}")#text(", one has to add some additional terms involving some translates of the balls ")#mi("{B(x_0,\\sqrt{R})}")#text(", but these can be handled by the same method as the one given below and we omit this technicality for brevity. We can write ")#mi("{G_{i,D_i} = \\tilde G_{i,D_i} \\psi_{i,D_i}}")#text(", where ")#mi("{\\psi_{i,D_i}}")#text(" is a Schwartz function adapted to a slight dilate of ")#mi("{D_i}")#text(" whose inverse Fourier transform ")#mi("{\\psi_{i,D_i}^\\vee}")#text(" is a bump function adapted to a ")#mi("{O(\\sqrt{R}) \\times O(R)}")#text(" tube ")#mi("{D_i^\\perp}")#text(" oriented along ")#mi("{\\omega_i}")#text(" through the origin, and ")#mi("{\\tilde G_{i,D_i} \\in L^2(D_i)}")#text(" with ")#metadata(none) <tao-61daa82e47c5ce57acb5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("\\left\\|\\tilde G_{i,D_i} \\right\\|_{L^2(D_i)} \\sim_d \\left\\|G_{i,D_i} \\right\\|_{L^2(D_i)}.", block: true)]]

#text(" This gives a reproducing-type formula")

#align(center)[#tao-fit-display[#mitex("G_{i,D_i}^\\vee = \\tilde G_{i,D_i}^\\vee * \\psi_{i,D_i}^\\vee")]]

#text("which by Cauchy-Schwarz (or Jensen’s inequality) gives the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|G_{i,D_i}^\\vee\\right|^2(x) \\lesssim_d R^{-(d+1)/2} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 * 1_{D_i^\\perp}(x).", block: true)]]

#text("By enlarging ")#mi("{D_i^\\perp}")#text(" slightly, we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|G_{i,D_i}^\\vee\\right|^2(x) \\lesssim_d R^{-(d+1)/2} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 * 1_{D_i^\\perp}(x_0)", block: true)]]

#text("for all ")#mi("{x \\in B(x_0,\\sqrt{R})}")#text(", hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G_{i,D_i}^\\vee \\right\\|_{L^2(B(x_0,\\sqrt{R}))}^2 \\lesssim_d R^{-1/2} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 * 1_{D_i^\\perp}(x_0).", block: true)]]

#text("We have thus bounded the left-hand side of ")#link(<tao-411b0496da5eeced5314>)[#text("(47)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("(R^{-d/2} \\int_{B(0,R)} \\prod_{i=1}^d (\\sum_{D_i} R^{-1/2} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 * 1_{D_i^\\perp}(x_0))^{1/(d-1)}\\ dx_0)^{(d-1)/2}", block: true)]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#tao-math("R^{-d^2/4} \\left\\| \\prod_{i=1}^d \\sum_{D_i} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 * 1_{D_i^\\perp}(x_0) \\right\\|_{L^{1/(d-1)}(B(0,R))}^{1/2}.", block: true)]]

#text("Using a rescaled version of ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("(31)")]#text(" (and viewing the convolution here as a limit of Riemann sums) we can bound this by")

#align(center)[#tao-fit-display[#tao-math("R^{-d^2/4} ( R^{d(d-1)/2} K_{2c}(1/\\sqrt{R}) \\prod_{i=1}^d \\left\\| \\sum_{D_i} \\left|\\tilde G_{i,D_i}^\\vee\\right|^2 \\right\\|_{L^1({\\bf R}^d)} ) ^{1/2},", block: true)]]

#text("which by ")#link(<tao-61daa82e47c5ce57acb5>)[#text("(49)")]#text(", ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(48)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("R^{-d/4} K_{2c}(1/\\sqrt{R})^{1/2}")]]

#text("giving ")#link(<tao-411b0496da5eeced5314>)[#text("(47)")]#text(" as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Show that Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(" continues to hold (but now with implied constants depending on ")#mi("{S_1,\\dots,S_d}")#text(") if the hypersurfaces ")#mi("{S_1,\\dots,S_d}")#text(" are no longer assumed to lie on the sphere ")#mi("{S^{d-1}}")#text(", but are compact smooth surfaces with boundary with the property that whenever ")#mi("{n_i}")#text(" is a unit normal to a point in ")#mi("{S_i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(", then the wedge product ")#mi("{n_1 \\wedge \\dots \\wedge n_d}")#text(" has magnitude comparable to ")#mi("{1}")#text(" (that is to say, the determinant of the ")#mi("{d \\times d}")#text(" matrix with rows ")#mi("{n_!,\\dots,n_d}")#text(" has magnitude comparable to ")#mi("{1}")#text("). In particular, the hypersurfaces ")#mi("{S_1,\\dots,S_d}")#text(" are permitted to be flat; it is not the curvature of these surfaces that induces the multilinear restriction estimate, but rather the transversality between the surfaces.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Let the notation and hypotheses be as in Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(", except that we now assume ")#mi("{R \\geq 2}")#text(" (in order to keep ")#mi("{\\log R}")#text(" bounded away from zero).")

#list(
[#text("(i) Using Exercise ")#link(<tao-04ac4067b6af83a7ef4a>)[#text("30")]#text(", improve the conclusion ")#link(<tao-597c28c381ef1feee61f>)[#text("(38)")]#text(" of Theorem ")#link(<tao-a4cbe2d6c48880a0550a>)[#text("31")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d (g_i\\ d\\sigma_{S_i})^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))} \\lesssim_d \\exp( O_d(\\sqrt{\\log R}) ) \\prod_{i=1}^d \\left\\| g_i \\right\\|_{L^2(S_i, d\\sigma_{S_i})}.", block: true)]]],
[#text("(ii) It is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2746348")[#text("a result of Guth")]#text(" that Theorem ")#link(<tao-a02cd7e1c6810a9ab2ec>)[#text("26")]#text(" holds at the endpoint ")#mi("{\\varepsilon=0}")#text(". Assuming this claim, improve ")#link(<tao-597c28c381ef1feee61f>)[#text("(38)")]#text(" further to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{i=1}^d (g_i\\ d\\sigma_{S_i})^\\vee \\right\\|_{L^{2/(d-1)}(B(0,R))} \\lesssim_d (\\log R)^{O_d(1)} \\prod_{i=1}^d \\left\\| g_i \\right\\|_{L^2(S_i, d\\sigma_{S_i})}.", block: true)]]]
)
]

#text("For further discussion of the multilinear Kakeya and restriction theorems, see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3204854")[#text("this survey of Bennett")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 39")]#text(" In recent years, multilinear restriction estimates have been useful to establish linear ones (although the implication is still not perfectly efficient), starting with ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2860188")[#text("this paper of Bourgain and Guth")]#text(".")
]

#heading(level: 1)[#text("Comments (217)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694089")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("Is the restriction theorem for the cone in dimensions $n\\geq3$ solved?I see the results related to this in Strichartz’s article Restriction of Fourier transforms to quadratic surfaces and decay of solutions of wave equations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694100")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("I am ")#link("https://claude.ai/share/2ba0b4c3-ab1c-48db-932b-f3d7373e63cf")[#text("outsourcing this question to an AI")]#text(". The short answer is that the cone restriction problem is currently solved up to dimension 5.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694106")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("How to prove the necessary condition of the restriction theorem for the cone?I think this case is quitely different from the case on the sphere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("This problem is generally left as an exercise to the reader, as it is a good test of one’s basic understanding of restriction theory. Some relevant references are ")#link("https://chatgpt.com/share/6a8e8d1e-8cfc-83e8-85d8-b036f8d6628b")[#text("collected in this AI literature search")]#text("; I expect that modern AI could also supply the construction directly for you if you requested it, though I would personally recommend doing this exercise yourself with pen and paper if you genuinely want to learn the material. There are two basic constructions: a Knapp type example (but now concentrated on a sector rather than a cap), or the examp;le involving uniform measure (or some variant thereof) on some dyadic portion of the cone.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694128")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2026")])]

#text("How to calculate the cardinality of $A$ on line 11 on page 5 on your article ")#link("https://arxiv.org/abs/math/0204234")[#text("arxiv.org")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2026")])]

#text("I am ")#link("https://claude.ai/share/be108aca-aea2-4965-837f-8b2da1f22439")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694134")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2026")])]

#text("Do we need to impose the convex condition on the manifold $M$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694142")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("No; the volume packing arguments used to count lattice points here are relatively crude and do not need any curvature or convexity hypotheses on the underlying manifold. (For more precise lattice point problems, such as the Gauss circle problem, the geometry of the surface plays a much more critical role, but the analysis here does not require such subtleties.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694147")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("Does the fact that the measure of this region is equivalent to $R^d$ not rely on the convexity of $M$?I can only see this fact from Federer’s Book Geometric measure theory，the convex property is needed on that book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("Convexity is not required as long as the thickness of the region is small compared to the radius of curvature, so that the normal bundle remains well behaved and one avoids caustics etc..")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-3/#comment-694479")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Is Corollary $1.2$ of your article ")#link("https://sci-hub.red/storage/moscow/715/1d4d36fba2883c6b3e8b9ca246512b82/tao2003.pdf")[#text("tao.dvi")]#text(" contradicted from Knapp’s example?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In the 8th line below (16) there is a missing formula which “does not parse”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Instead of the Schwartz class approach, can one define the Fourier transform on ")#mi("L^2")#text(" via the Riesz representation theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In principle yes, through the formal identity ")#mi("\\langle \\hat f, g \\rangle = \\langle f, g^\\vee \\rangle")#text(", but when ")#mi("f \\in L^2")#text(" and ")#mi("g \\in C_c")#text(" it is not immediately obvious that the inner product ")#mi("\\langle f, g^\\vee \\rangle = \\int_{{\\bf R}^d} f(x) \\overline{g^\\vee(x)}\\ dx")#text(" is absolutely convergent, unless one already has proven enough of Plancherel’s theorem that one can establish that ")#mi("g^\\vee")#text(" is square-integrable. I would imagine that a purely Riesz representation theorem approach is going to be nontrivial, as it would also likely extend to other locally compact abelian groups, and the construction of the Fourier transform at this level of generality seems to require some machinery (e.g., Bochner’s theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("How do you think about why the crude covering of each ")#mi("T_i")#text(" by ")#mi("O_d( (1+c/\\delta)^{d-1})")#text(" ")#mi("\\delta\\times 1")#text(" tubes automatically gives the bound ")#mi("K_c(\\delta)\\lesssim_d(1+c/\\delta)^{d(d-1)}")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("This covering lets one dominate ")#mi("\\sum_{T_i \\in {\\mathcal T}_i} 1_{T_i}")#text(" pointwise by ")#mi("\\sum_{T^{\\prime}_i \\in {\\mathcal T}^{\\prime}_i} 1_{T^{\\prime}_i}")#text(" where ")#mi("{\\mathcal T}^{\\prime}_i")#text(" is a collection of tubes oriented parallel to ")#mi("e_1")#text(" with ")#tao-math("\\left|{\\mathcal T}^{\\prime}_i\\right| \\lesssim_d (1+c/\\delta)^{d-1} \\left|{\\mathcal T}_i\\right|", block: false)#text(". If one then applies Exercise 28(ii) to these families of tubes, we obtain the claim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552845")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("Typos in the proof of multilinear Kakeya (after equation (33)): you switch between ")#mi("\\delta \\times 1")#text(" tubes to ")#mi("\\sqrt\\delta\\times\\delta")#text(" tubes and ")#mi("2\\times 2\\sqrt\\delta")#text("-tubes (it should be the reverse in the latter cases). Also, when you count tubes meeting a cube using norms of characteristic functions, you get several times ")#mi("\\sum_{i=1}^d 1_{T_i^*}")#text(" which I think should be ")#mi("\\sum_{T_i\\in \\cal{T}_i} 1_{T_i^*}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-552928")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("I’m trying to prove inequality (25) (which you left as an exercise), I thought it would be easy but that it seems more involved. I guess that one has to use the separation hypothesis ")#tao-math("dist(I,J) \\sim \\left|I\\right|=\\left|J\\right|", block: false)#text(" efficiently. Usually this is done by making a change of variable directly in the ")#mi("L^2")#text(" integral, just like in the proof of Bourgain’s bilinear estimates in the dispersive pde’s context. But here, you ask for a pointwise bound. However ")#mi("1_{A_{I, \\varepsilon}} * 1_{A_{J,\\varepsilon}}")#text(" is not easy to compute explicitely. If I start by writing")

#tao-math("\\displaystyle 1_{A_{I, \\varepsilon}} * 1_{A_{J,\\varepsilon}} (x) = \\int_{r \\in [1-\\varepsilon, 1+\\varepsilon]}\\int_{\\theta \\in [\\theta_I, \\theta_I + \\left|I\\right|]} 1_{A_{J,\\varepsilon}} (x-re^{i\\theta}) rdrd\\theta", block: false)

#text("then how can I bound this by the required ")#tao-math("\\varepsilon ^2 \\left|I\\right|^{-1}", block: false)#text("? I can see that there will be an ")#mi("\\varepsilon")#text(" coming from the integral in ")#mi("r")#text(" with brutal estimates. My guess is that the inner integral should be bounded by ")#tao-math("\\varepsilon \\left|I\\right|^{-1}", block: false)#text(" but I do not see how.")

#text("Can you give me a hint or some help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("This problem is much easier to understand if you approach it geometrically rather than purely analytically. A convolution ")#mi("1_A * 1_B(x)")#text(" of two indicator functions evaluated at a point is nothing more than the area of the intersection of ")#mi("A")#text(" with a reflected translate ")#mi("x-B")#text(" of ")#mi("B")#text(", so the main issue is to understand the shape and size of the intersection ")#mi("A \\cap (x-B)")#text(". Drawing pictures should convince you that this intersection (when it is non-empty and does not occur on the angular boundary of the annular sectors involved) resembles a parallelogram whose dimensions one can work out, and this should lead you to a heuristic bound of ")#tao-math("O(\\epsilon^2 \\left|I\\right|^{-1})", block: false)#text(". One can then make this rigorous by proving that the intersection lies in an actual parallelogram (or other object whose area is easy to compute, such as a rectangle).")

#text("It may also be worth revisiting the proof of the change of variables formula in several dimensions to see exactly where the Jacobian term in that formula comes from. In particular the geometric fact that a determinant can be viewed as the area of a parallelogram or parallelopiped, when applied to certain infinitesimal approximate parallelopipeds, is the geometric essence of the change of variables formula, and that fact is also the essence of the computation here. (It is also possible to establish the desired claim from the change of variables formula and a duality argument, working primarily with the integration over the angular variables; this is also a good exercise for you to work out.)")

#text("More generally, this exercise is an illustration of the substantial gain in effectiveness one gains when one transitions from the “rigorous” approach to mathematics to the “post-rigorous” one, as I discuss in ")#link("https://terrytao.wordpress.com/career-advice/theres-more-to-mathematics-than-rigour-and-proofs/")[#text("https://terrytao.wordpress.com/career-advice/theres-more-to-mathematics-than-rigour-and-proofs/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553019")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("Thank you for this geometric insight, it is really helpful! I think that your geometrical proof can be turned into a rigorous proof (without change of variables), I’ll try to also write a proof with a change of variable as you suggested. It seems that I am still at the “rigorous” stage of my mathematical development.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("For the interpretation of multilinear kakeya estimate, equation (30), you wrote ")#mi("(k^d\\delta^d)^{d-1} = (k^{d-1}\\delta^{d-1})^d")#text(", what does ")#mi("k")#text(" stands for?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#mi("k")#text(" was an arbitrary natural number parameter (well, it shouldn’t exceed ")#mi("1/\\delta")#text(", but otherwise it is arbitrary) used to construct a certain testing example for (30) (in which each family ")#mi("{\\mathcal T}_i")#text(" of ")#mi("\\delta \\times 1")#text(" tube occupied a ")#mi("k \\delta \\times 1")#text(" tube).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553117")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("On the interpolation in Ex 24(ii), if A denote the index set ")#tao-math("I,J: I \\sim J; \\left|I\\right| = \\left|J\\right| = 2^{-k}", block: false)#text(" one can show boundedness from ")#mi("l^2(A\\to L^2) \\to L^2")#text(", ")#mi("l^1(A\\to L^1) \\to L^1")#text(", and ")#mi("l^1(A\\to L^\\infty) \\to L^\\infty")#text(". One concern is that the ")#mi("L^p")#text(" space in which to evaluate functions in ")#mi("l^q")#text(", i.e. the ")#mi("p")#text(" in ")#mi("l^q(A\\to L^p)")#text(", is changing as well. How do one justify interpolation in this case? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553122")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("The proof of the Riesz-Thorin interpolation theorem can be adapted to this context.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553154")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("In Exercise 30 I’m not able to recover the ")#mi("\\sqrt{\\log (\\delta ^{-1})}")#text(" but I have instead a ")#mi("\\log (\\delta ^{-1})")#text(", what am I missing?")

#text("Here is how I get it: let ")#mi("\\delta<1")#text(", then Proposition 29 tells us that ")#mi("K(\\delta)\\lesssim K(\\delta^{2^{-n}})^{2^n}")#text(". Now we already have the \"good estimate\" in the range ")#mi("c\\leq \\delta \\leq 1")#text(" so for ")#mi("\\delta \\leq 1")#text(" one seeks for ")#mi("n")#text(" such that ")#mi("\\delta^{2^{-n}} \\geq c")#text(" which is done by taking ")#mi("2^n \\sim \\log (\\delta^{-1})")#text(" and then the estimate follows. However, proving the bound with the square root is more challenging, and I feel like the induction Proposition can not do better than that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("A bound of ")#mi("\\exp( O_d(\\log(\\delta^{-1})) = \\delta^{-O_d(1)}")#text(" is in fact worse than the qualitative version of Theorem 26. One should stop using Proposition 29 at a smaller value of ")#mi("n")#text(", e.g., ")#mi("2^n \\sim \\sqrt{\\log \\delta^{-1}}")#text(", and use the arguments near (35) and (36) to conclude, rather than (32).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553404")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("You are right my estimates was worse than what was obtained before. Thank you for the hint, it is greatly effective.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("You mentioned in class that rotation symmetry is not strong enough because it preserves angles, we should use ")#mi("GL(R^d)")#text(" symmetry. Doesn’t rotation symmetry also have the properties of ")#mi("GL(R^d)")#text(" symmetry?, i.e. determinant =1, … How does ")#mi("GL(R^d)")#text(" symmetry remove the angle preservation problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("Matrices in ")#mi("GL({\\bf R}^d)")#text(" are not required to have determinant 1, and furthermore determinant 1 is not enough to preserve angles (it preserves volume instead). For instance the shear transformation ")#mi("(x,y) \\mapsto (x+y,y)")#text(" in the plane is an element of ")#mi("GL({\\bf R}^2)")#text(" of determinant 1, but does not preserve angles.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Dear Prof. Tao:")

#text("Wonder if you can target the audience towards graduate students more. It seems that the only people ask questions during lectures are professional mathematicians who are familiar with the subject already. It is too fast for graduate students to grasp the material the first time. Or do you intend the course to be like an overview of the subject?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-553976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("Prof. Tao:")

#text("Could you post some solutions to the HWs?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554020")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("The fourth displayed equation after (46) should be ")#mi("C(\\sqrt{R})^2 \\sqrt{R}^{-d}")#text(" because we have the squared ")#mi("L^2")#text("-norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554023")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("Sorry — this is wrong (I missed the point where you took the square root). However, three equations down (right after the mention of Theorem 26) you are missing the left parenthesis that matches the right parenthesis at the end of the equation (presumably it goes to the left of the sum over the ")#mi("T_i")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("For the proof of multilinear restriction estimate, you mentioned again that the important thing is transversality, not curvature. The first time you introduced the concept of transversality is in Proposition 21. I am not sure I understand (or fully appreciate) the importance of transversality as you indicated. In equation (37), ")#mi("R \\to \\infty")#text(" for flat surface, which makes (37) trivial. Back to Proposition 21, transversality comes in equation (25). ")#tao-math("\\left|I\\right|=0", block: false)#text(" if no transversality, which makes (25) obviously true. It seems that transversality becomes important because you set up the problem (Prop. 25) to make it important, not because it is intrinsically important. I feel that curvature and transversality are two sides of the same coin. ???")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554047")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("The parameter ")#mi("R")#text(" in (37) is not directly related to the curvature of the surfaces; (37) is indeed simpler to prove in the case of completely flat surfaces (it follows from the Loomis-Whitney inequality and Plancherel’s theorem, with no ")#mi("R^{\\varepsilon}")#text(" loss) but it is not entirely trivial. But the point is that the inequality (37) continues to hold for flat transverse hypersurfaces (Exercise 37), in contrast to linear restriction estimates that fail in the flat case (Exercise 10). In the linear theory curvature and transversality are essentially equivalent hypotheses (a surface is curved if different portions of it tend to be transversely arranged), but in the multilinear theory there is a distinction between the hypotheses (both flat and curved surfaces can be transverse to other flat or curved surfaces).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/054c0ffe169deeabe6657ffb1c28b044aa30c091b5c4a88680ce5d3d5761850f-b2f8fe604fa6c7f901acb864a3b0f5a32f401fdf736a320f7dcb372ab2987c36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("I have two questions. First, in Exercise 27, we are asked to obtain an estimate for all p>0, but in your paper given before Theorem 26, it seems to me that the estimates were proved for p>=1/(d-1) only. I was wondering how we can prove the estimate for p<1/(d-1), and whether there is a typo here.")

#text("In addition, in the estimate of L^2 norm of G_{i,x_0} (the first displayed equation after (46)), I was wondering whether the power of sqrt(R) should be d instead of d+1. In the third displayed formula after (46) (right after \"which is also morally\"), if we assume 1_{T_i}(x)\\approx 1_{T_i}(x_0), then we get a factor sqrt(R)^{d(d-1)/2}, which doesn't seem to match the power of sqrt(R) in the formula right above this one.")

#text("Thank you in advance for your time and help!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554175")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("I’ve edited the problem slightly: ")#mi("L^p")#text(" estimates are in fact available for all ")#mi("p \\geq \\frac{1}{d}")#text(", with the range ")#mi("\\frac{1}{d} \\leq p < \\frac{1}{d-1}")#text(" being deducible from the ")#mi("p = \\frac{1}{d-1}")#text(" case by localising to balls or cubes of scale ")#mi("\\sim 1")#text(" and using H\\\"older's inequality. There are counterexamples that show that no estimate is possible below ")#mi("1/d")#text(".")

#text("The exponent of ")#mi("R")#text(" has now been fixed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554151")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("In the two centered equations following “From the uncertainty principle, the trigonometric polynomial ")#mi("{\\sum_{T_i \\in {\\mathcal T}_i: x_0 \\in T_i} c_{i,T_i} e^{2\\pi i x \\cdot \\omega_{T_i}}}")#text(" behaves…,” should the exponent be d instead of d+1?")

#text("This is what I get when I apply the uncertainty principle. Also, an exponent of d seems to agree with the centered equation following “which is also morally.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554152")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("LaTeX typos: Starting with the centered equation after “This gives a reproducing-type formula,” there are three instances of “vee” instead of “\\vee.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554159")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("Some other typos: There are several instances of ")#mi("K_{2c}(\\sqrt {R})")#text(" when I think you mean ")#mi("K_{2c}(1/sqrt R)")#text(":")

#text("in Proposition 36")#linebreak()#text(" in line (44)")#linebreak()#text(" in line (47)")#linebreak()#text(" in the two centered equations following “Using a rescaled version of (31)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554414")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("I believe the centered equation following “Applying a rescaled (and weighted) version of Theorem 26, this is bounded by” is missing two square roots. It should be:")

#tao-math("\\displaystyle \\lessapprox C(\\sqrt{R}) (K_{2c}(1/\\sqrt{R}))^{1/2} \\prod_{i=1}^d \\sqrt{R}^{(d-1)/2} (\\sum_{T_i \\in {\\mathcal T}_i} \\left|c_{i,T_i}\\right|^2)^{1/2}", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16fc121e3b84418ae1faae922eee373edcc15c29c38598863b1e3739735552a9-31289b5ed6c7488efba3b20156847f14d4837d0793610734a2904316eec9d616.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554454")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("In Exercise 24, I am confused about the stated definition of “bounded overlap.” Is this sort of eluding to the almost disjoint (or finite overlap) in Fourier support for a product of two functions, like paraproducts?")

#text("Also, a little further down, you say that ")#mi("\\sigma_J (E)")#text(" is controlled by ")#mi("\\sigma_I(E)")#text(" because I is close to J. Could you explain why this is the case?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554459")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("A collection of sets ")#mi("E_j")#text(" is said to have overlap at most ")#mi("A")#text(" if any given point lies in at most ")#mi("A")#text(" of the ")#mi("E_j")#text(". In particular, bounded overlap means that any given point lies in ")#mi("O(1)")#text(" of the ")#mi("E_j")#text(". In this particular case the ")#mi("E_j")#text(" (which are called ")#mi("2R_{I,J}")#text(" in the exercise) have an interpretation as a container for the Fourier support of a certain product (with some room to spare), but this is not essential to the definition of bounded overlap.")

#text("The quantities ")#mi("\\sigma_J(E)")#text(" and ")#mi("\\sigma_I(E)")#text(" do not control each other. However, by symmetry and the fact that each ")#mi("I")#text(" is close to ")#mi("O(1)")#text(" ")#mi("J")#text(" and vice versa, the sums ")#tao-math("\\sum_{I \\sim J: \\left|I\\right|=2^k} \\sigma_I(E)^2", block: false)#text(" and ")#tao-math("\\sum_{I \\sim J: \\left|I\\right|=2^k} \\sigma_J(E)^2", block: false)#text(" are both controlled by ")#tao-math("\\lesssim \\sum_{I: \\left|I\\right|=2^k} \\sigma_I(E)^2", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554497")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("Your ")#mi("\\lessapprox")#text(" notation is defined in other articles on this blog, but it doesn’t appear to be defined in this one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("This symbol (as well as the ")#mi("\\approx")#text(" symbol) is not being assigned a precise interpretation; it is only used in the heuristic portions of the disucssion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554628")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("Regarding the statement of Theorem 26, should it be that the choice of \\delta is arbitrarily small after one fixes the set of families, or at least the directions of tubes? Here I am a bit confused with the order of choices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("The family of tubes ")#mi("{\\mathcal T}_i")#text(" will have to depend on ")#mi("\\delta")#text(", since each tube in these collections have thickness ")#mi("\\delta")#text(". The set of directions that these tubes point in is also permitted to depend on ")#mi("\\delta")#text(". The key point though is that the implied constant in the conclusion (30) is uniform in ")#mi("\\delta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5c103ba8fb7edebc2a99d7941e9fca2082ddaafb7190ffb7a446718702f87d1-32bbe8fd0b82c70659b02ab701068f21a031b31eb47f84d01e24832e872af09b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiqiang Zheng")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554838")[#strong[#text("Jiqiang Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Dear Prof. Tao:")#linebreak()#text(" From Exercise 9(vi), we know that the restriction estimate for the sphere implies the restriction estimate for the paraboloid. My question is “How about the reverse?” Is it possible to use the restriction estimate for the paraboloid to deduce the restriction estimate for the sphere? Thank you for your reply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-554924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Currently there is no known satisfactory implication of this form. (The restriction conjecture for the paraboloid does imply the Kakeya conjecture, which can be used to improve slightly the known restriction estimates for the sphere, but at our current level of understanding we cannot recover the full restriction conjecture for the sphere in this fashion.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-557897")[#strong[#text("Fourier multipliers: examples on the torus – Zeros and Ones")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2020")]

#text("[…] question what happens in higher dimensions when . Bourgain made some progress. See also these lecture notes on Euclidean space . Such type of estimates are called Fourier Restriction […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-558204")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("an interesting non computability theorem, ")#link("https://www.sciencedirect.com/science/article/pii/S0021904519301121")[#text("https://www.sciencedirect.com/science/article/pii/S0021904519301121")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-559715")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("[…] of two. By performing a suitable Whitney type decomposition (similar to that used in Section 3 of Notes 1), establish the pointwise […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-560012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Thank you for this blog post.")

#text("I want to remark on the proof of Lemma 4 (Khintchine’s inequality).")

#text("I believe the trick with ")#mi("\\lambda")#text(" and ")#mi("t")#text(" is employed to obtain a sharper constant in the inequality. Since the constant is hidden, a simpler exposition is possible: Estimate")

#tao-math("\\mathbb{P}(\\left|\\sum \\epsilon_j x_j\\right|) \\lesssim \\exp(-\\lambda).", block: false)

#text("The p-norm should still be estimable. I am remarking this because that trick always confused me, and only now I realized it is probably not necessary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-560025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("To reply to my own comment, I now realize the constant is looked at in Exercise 5.")

#text("I also solved the confusion with ")#mi("\\lambda")#text(" and ")#mi("t")#text(": If you follow the method I posted, you put “all” of ")#mi("\\lambda")#text(" in the denominator (of Chebyshev inequality right hand side); you may elect to put it in the numerator instead, or some power in the numerator and its complementary in the denominator. The optimization in the power results in the analysis that is presented in this blog.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-560625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("“we first give an alternate derivation of the necessary condition ")#mi("q \\leq \\frac{d+1}{d-1} p^{\\prime}")#text(" in Conjecture 14″")

#text("I think this should be ")#mi("q \\leq \\frac{d-1}{d+1} p^{\\prime}")#text(", the signs are reversed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-561469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2020")])]

#text("“we have the bounds”")

#tao-math("\\displaystyle K_{x_d}(x^{\\prime}) \\lesssim_{\\eta,d} \\left|(x^{\\prime},x_d)\\right|^{-\\frac{d-1}{2}} \\leq \\left|x_d\\right|^{-\\frac{d-1}{2}}", block: false)

#text("should be ")#tao-math("\\left|K_{x_d}(x^{\\prime})\\right|", block: false)

#emph[#text("[I am using the notational convention that ")#mi("X \\lesssim Y")#text(" if ")#tao-math("\\left|X\\right| \\leq CY", block: false)#text(" (thus the absolute values are automatically applied) -T.]")]

#text("and")

#text("” Applying the one-dimensional Hardy-Littlewood-Sobolev inequality we conclude (after some more arithmetic) that”")

#tao-math("\\displaystyle \\left\\| \\int_{\\bf R} \\right\\| f_{y_d} * K_{x_d-y_d} \\left\\|_{L^{p^{\\prime}_0}({\\bf R}^{d-1})} \\right\\|_{L^{p^{\\prime}_0}_{x_d}({\\bf R})} \\lesssim_d \\left\\| \\left\\| f_{x_d} \\right\\|_{L^{p_0}({\\bf R}^{d-1})} \\right\\|_{L^{p_0}_{x_d}({\\bf R})}", block: false)

#text("should have a ")#mi("dy_d")#text(", so")

#tao-math("\\displaystyle \\left\\| \\int_{\\bf R} \\right\\| f_{y_d} * K_{x_d-y_d} \\left\\|_{L^{p^{\\prime}_0}({\\bf R}^{d-1})} dy_d \\right\\|_{L^{p^{\\prime}_0}_{x_d}({\\bf R})} \\lesssim_d \\left\\| \\left\\| f_{x_d} \\right\\|_{L^{p_0}({\\bf R}^{d-1})} \\right\\|_{L^{p_0}_{x_d}({\\bf R})}", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-562233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("A question, I am grateful for help:")

#text("I am trying to follow the reduction of")

#tao-math("\\displaystyle \\left\\| (g\\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^q({\\bf R}^2)} \\lesssim_{q} \\left\\| g\\right\\|_{L^p(\\phi([0,1/4]))} \\quad (23)", block: false)

#text("into that of")

#tao-math("\\displaystyle \\left\\| (1_E\\ d\\sigma_{[0,1/4]})^\\vee \\right\\|_{L^q({\\bf R}^2)} \\lesssim_{q} \\sigma_{[0,1/4]}( E )^{1 - 3/q}.", block: false)

#text("I took a look at the Marcinkiewicz theorem for Lorentz spaces; I have not worked with Lorentz spaces before. Still, I don’t understand how to do that reduction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-562288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("I think I figured it out, but not sure yet. I will post tomorrow with my findings. One thing I missed is that there was a relabeling of what ")#mi("p")#text(" and ")#mi("q")#text(" were.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-562426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2020")])]

#text("Here it is: a relabeling of ")#mi("p,q")#text(" given in the blog text gives ")#mi("q > 4")#text(" and ")#mi("p^{\\prime} \\geq q/3")#text(". As mentioned, ")#mi("p^{\\prime} = q/3")#text(" may be taken since ")#mi("d\\sigma")#text(" is a finite measure, thus ")#mi("1/p = 1 - 3/q")#text(". It is then immediate that (23) implies the “restricted strong-type estimate”.")

#text("Then to establish (23) for a given pair ")#mi("(q,p)")#text(", we establish it for two pairs ")#mi("(q_j, p_j), j = 0,1")#text(" for characteristic functions (i.e. the restricted strong-type estimate) where ")#mi("q_0 < q < q_1")#text(" and use Marcinkiewicz interpolation. The openness simply allows us to always find such ")#mi("q_j")#text(".")

#text("This \"distributional inequality\" is also mentioned in Bourgain's paper ( Geom. Funct. Anal. 1 (1991), see (1.21) there) which is linked to in Exercise 17. I didn't understand it at the time I encountered it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-563253")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("For Exercise 13, I took a (d-1) gaussian g and try to compute ")#mi("(gd \\sigma)^{\\vee}(x,x_d)")#text(" following the hint. However, I only get the estimate of this function of (x’,x_d) with the order ")#mi("x_d^{-(d-1)/2}")#text(", which is not enough for me. I might not really understand how to use gaussian as hinted.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-563448")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("This is the right order of decay in the ")#mi("x_d")#text(" variable. Of course, to get necessary conditions we need lower bounds on ")#mi("(gd\\sigma)^\\vee")#text(" rather than upper bounds, and good lower bounds will be available in the parabolic region ")#tao-math("\\left|x\\right| \\leq x_d^{1/2}", block: false)#text(" for ")#mi("x_d \\geq 1")#text(" which will give the required claim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-563874")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2020")])]

#text("For the challenge problem in exercise 16(i), could you please give a hint? I suppose the endpoint exponent ")#mi("p^{\\prime}=\\frac{2d}{d-1}")#text(" and try to repeat the Khintchine inequality with the superposition of Knapp’s examples with no success..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Leng")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-565263")[#strong[#text("James Leng")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2020")])]

#text("I’m also a bit stuck on this. I tried applying a phase shift to rearrange these delta^{-1} \\times \\delta^{-2} tunes to be an approximate Kakeya set. Then I applied Holder’s inequality with that and the characteristic function of the approximate Kekaya set while varying the L^r on the left hand side (e.g. varying r so that 1 \\le r \\le 2d/(d + 1) or something similar to that). However, whatever benefit that the Kakeya set gives you gets cancelled out if you let p = r (since you work with the L^infty norm with the characteristic function) leading you to only get the condition p \\le 2d/(d + 1). So I don’t think the Holder inequality approach I used is correct…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/993c4448f60352dbef47a08584cfa398614bc115dc34721d3d2ff976284c95e5-4bada9804f4ae67cb9f3d2bd311dd8cfcc30e1b2cbb6f6664da6823a0ded2fbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giacomo Del Nin")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-624604")[#strong[#text("Giacomo Del Nin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2021")])]

#text("Superimpose ")#mi("\\approx \\tfrac{1}{\\delta^{d-1}}")#text(" Knapp examples, so that ")#tao-math("\\left\\|g\\right\\|_{L^{q^{\\prime}}(\\mathbb{S}^{d-1})}\\approx 1", block: false)#text(". After rescalings, the non-strict inequality boils down to the following: given ")#mi("\\tfrac{1}{\\delta^{d-1}}")#text(" ")#mi("\\delta")#text("-separated tubes ")#mi("T_i^\\delta")#text(" of size ")#mi("1\\times \\delta")#text(", then ")#tao-math("\\delta^{\\frac{2d}{p^{\\prime}}-(d-1)}\\gtrsim \\left\\|\\sum_{i} \\chi_{T_i^\\delta}\\right\\|_{p^{\\prime}}\\gtrsim 1", block: false)#text(", which forces ")#mi("p\\leq \\tfrac{2d}{d+1}")#text(". The rightmost inequality can be proved by Holder for any disposition of the tubes (the worst case is when they are disjoint). To prove that ")#mi("p=\\tfrac{2d}{d+1}")#text(" can not happen, it is sufficient to improve the rightmost inequality from ")#mi("\\gtrsim 1")#text(" to ")#mi("\\gg 1")#text(". To do this you have to phase-shift the tubes in an approximate Kakeya set (i.e. with total area ")#mi("o(\\delta)")#text("). Then the estimate follows again by Holder’s inequality (and because ")#mi("p>1")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-564232")[#strong[#text("MATH 247B: Modern Real-Variable Harmonic Analysis – Countable Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")]

#text("[…] Restriction Theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-564617")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Some minor corrections:")

#text("In (43), the sum should be over ")#mi("T_i")#text(" instead of ")#mi("T")#text(" and in the right hand side the ")#mi("L^2")#text(" space should be over ")#mi("A_{i,R}")#text(" instead of ")#mi("S^{d-1}")#text(".")

#text("“and observe that ")#mi("(G_i * \\widehat{\\phi^{x_0}_{\\sqrt {R}}})")#text(" has Fourier transform”, there it should be ")#mi("(G_i * \\widehat{\\phi^{x_0}_{\\sqrt {R}}})^\\vee")#text(", the inverse Fourier transform is missing.")

#text("(48) can’t be an equality, only ")#mi("\\sim_d")#text(" comparable, I think. It doesn’t affect the rest of the proof.")

#emph[#text("[Corrected, thanks. An equality can be obtained by defining each ")#mi("G_i")#text(" to be the restriction of ")#mi("G")#text(" to ")#mi("D_i \\backslash (D_1 \\cup \\dots \\cup D_{i-1})")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-678107")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2023")])]

#text("But if you define $G_i$ to be the restriction like that, it is no longer smooth.")

#emph[#text("[This is not a problem in practice, since one can smoothly approximate to arbitrary accuracy in various norms. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-586163")[#strong[#text("Strichartz estimates, nonendpoint and homogeneous – Mathssww's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2020")]

#text("[…] estimates for the Schordinger equations follow from the restriction estimates of paraboloid. See this note by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7eeb955a96e17bf7bc3768a3f842e3f25bbeb4dd2ec8a8047af3cdf357940fd-5f5d26f7bb59cf66d7c83cc3a20c2a5601a2417d216bfb110f719cdf980c1c52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luyuf")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-603285")[#strong[#text("luyuf")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("Dear Tao: thanks a lot for the note. I have some problems with the proof of proposition 36. Firstly, why we can just control the cutoff function by the character function in")

#tao-math("\\displaystyle  \\sum_{D_i} \\left\\| G_{i, D_i}^\\vee \\right\\|_{L^2(B(x_0,\\sqrt{R}))}^2,", block: false)

#text("I try to control it by the sum of the character function of the ball with radius ")#mi("2^k")#text(", but if so, the convolution of the character function of the tube below that equation may not with the same scale and cannot use the multilinear Kakeya estimate. Secondly, why can we see the convolution of the character function as the limit of Riemann sum so that to use the multilinear Kakeya.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-604450")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2020")])]

#text("This is only morally true, as the text indicates. In practice one has to instead replace the expression ")#tao-math("\\left\\| G_{i, D_i}^\\vee \\right\\|_{L^2(B(x_0,\\sqrt{R}))}^2", block: false)#text(" by a more complicated expression such as ")#tao-math("\\sum_{m \\in {\\bf Z}^d} \\langle m \\rangle^{-100d} \\left\\| G_{i, D_i}^\\vee \\right\\|_{L^2(B(x_0 + \\sqrt{R} m / 100d,\\sqrt{R}))}^2", block: false)#text(".")

#text("A convolution ")#mi("f*g(x) = \\int_{{\\bf R}^d} f(y) g(x-y)\\ dy")#text(" can be written as the limit of Riemann sums ")#mi("\\delta^d \\sum_{y \\in \\delta {\\bf Z}^d} f(y) g(x-y)")#text(" if say ")#mi("f, g")#text(" are Schwartz functions. (The indicator functions ")#mi("1_{D_i^\\perp}")#text(" are not quite Schwartz functions, but one can approximate them by such functions without much difficulty.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-625050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2021")])]

#text("Klainerman and Machedon’s conjecture was motivated by a nonlinear PDE kind of problem to which regular Strichartz estimates were not well suited. I wonder if the something similar happens in the $k$-linear world: in other words, if you have $k$ transversal caps on a paraboloid (or cone) and you manage to prove the correct $k$-linear restriction estimate, would that help studying regularity of some nonlinear PDE to which not even bilinear estimates are well suited?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-625206")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("In principle one could concoct an artificial nonlinear PDE designed specifically to take advantage of such a multilinear estimate, but there is no a priori reason to expect that there is a “natural” PDE (e.g., one arising from physics or geometry) that would be able to benefit from these estimates. (I ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1869874")[#text("once worked")]#text(" with a wave maps equation with a trilinear nonlinearity that required a somewhat delicate trilinear estimate that did not follow immediately from bilinear estimates. One could say that this estimate was a sort of trilinear restriction estimate, but the function spaces involved were customised to the wave maps equation and were not exactly the standard ")#mi("L^p")#text(" type spaces appearing in the usual restriction theory.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/740c5eb9cdfdffb40348e61bc73c921057721fd3d344e7c92f1e6d49b9653066-d146fb125298580ab26e236c9b491c7466a611d47f446222c7d4c0528ab79b91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boningdi")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-628986")[#strong[#text("boningdi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2021")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the proof of Prop. 36, more precisely in (48), you say that “cover ")#mi("A_{i,R^{1/2}}")#text(" by ")#mi("O(R^{-1/2})\\times O(R^{-1})")#text(" disks ")#mi("D_i")#text(" whose centers are at ")#mi("S^{d-1}")#text(" around ")#mi("e_i")#text(", and the centers are separated from each other by ")#mi("\\gg R^{-1/2}")#text("”. I’m a little confused about this. As far as I understand, due to the curvature of the sphere and ")#mi("1/R\\leq 1/\\sqrt{R}")#text(", the disks should be ")#mi("O(R^{-1/4})\\times O(R^{-1/2})")#text(" if the centers are at ")#mi("S^{d-1}")#text(". Here the disks with sizes ")#mi("O(R^{-1/2})\\times O(R^{-1})")#text(" are only able to cover ")#mi("A_{i,R}")#text(" rather than ")#mi("A_{i,R^{1/2}}")#text(".")

#text("Besides, I don’t really understand why we need the conditiont “centers are separated from each other by ")#mi("\\gg R^{-1/2}")#text("”. I wonder if the bounded overlapping condition (i.e. Heine-Borel Theorem) is enough here in this proof.")

#text("Thanks in advance for your help!")

#emph[#text("[This was a typo: I have corrected ")#mi("A_{i,R^{1/2}}")#text(" to ")#mi("A_{i,R}")#text(". Bounded overlap would be a satisfactory substitute for separation if desired. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-678108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2023")])]

#text("I think the typo has not been corrected?")

#emph[#text("[Corrected (again), thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7eeb955a96e17bf7bc3768a3f842e3f25bbeb4dd2ec8a8047af3cdf357940fd-5f5d26f7bb59cf66d7c83cc3a20c2a5601a2417d216bfb110f719cdf980c1c52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luyuf")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-629290")[#strong[#text("luyuf")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2021")])]

#text("Dear Prof.Tao,")#linebreak()#text(" I have some questions about Hausdorff-Young’s inequality. First, we know that it is sharp for ")#mi("1\\leq p \\leq 2,q=p^{\\prime}")#text(", my question is that if we know that ")#tao-math("\\left\\| \\hat{f} \\right\\|_p \\leq C \\left\\| f\\right\\|_s", block: false)#text(" for all function f which is supported on the unit cube, what is the sufficient and necessary condition for this inequality? I guess the result is ")#mi("p^{\\prime}\\leq s")#text(",and ")#mi("p^{\\prime}\\leq 2")#text(". By scaling, we can have ")#mi("p^{\\prime} \\leq s")#text(", but I do not know how to prove ")#mi("p^{\\prime}\\leq 2")#text(".")#linebreak()#text(" Thanks for your time.")

#emph[#text("[Hint: experiment with random Fourier series using Khintchine’s inequality. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/740c5eb9cdfdffb40348e61bc73c921057721fd3d344e7c92f1e6d49b9653066-d146fb125298580ab26e236c9b491c7466a611d47f446222c7d4c0528ab79b91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boning Di")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-639424")[#strong[#text("Boning Di")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("Dear Prof. Tao:")#linebreak()#text(" Thank you very much for this note! It’s very helpful. In Exercise 25, for the implied constant in bilinear restriction for the paraboloid, you mentioned that we could get the dependence of subsets ")#mi("S_1")#text(" and ")#mi("S_2")#text(" by parabolic rescaling and Galilean symmetries. And I do get this by following the hint there. But I wonder what about other surfaces such as ")#mi("(\\xi, \\xi^{m})")#text("? In this case, can we still get a similar dependence of the distance ")#mi("dist(S_1, S_2)")#text("? I’m a little confused since there will be some extra terms when ")#mi("m\\neq2")#text(". Is this possible to obtain this dependence?")

#text("Thanks in advance for your reply!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/740c5eb9cdfdffb40348e61bc73c921057721fd3d344e7c92f1e6d49b9653066-d146fb125298580ab26e236c9b491c7466a611d47f446222c7d4c0528ab79b91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boning Di")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-639425")[#strong[#text("Boning Di")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("Maybe the example of surface should be ")#tao-math("(\\xi,\\left|\\xi\\right|^{m})", block: false)#text(" which is better…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-639568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2022")])]

#text("For surfaces without an exact parabolic rescaling, such as the surface you mention, one can still use rescaling to obtain quantitative dependence on ")#mi("S_1,S_2")#text(" as long as the base bilinear restriction estimate used (when ")#mi("S_1, S_2")#text(" are uniformly separated) holds uniformly for all pairs of surfaces ")#mi("S_1,S_2")#text(" obeying various smoothness and curvature bounds. See for instance Section 2 of my paper ")#link("https://arxiv.org/abs/math/9807163")[#text("https://arxiv.org/abs/math/9807163")]#text(" with Vargas and Vega for an example of this.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-644992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("Is there a higher dimensional version of Proposition 21 where the measures of the caps appear on the RHS instead of the measure of I?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-644999")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("Yes, there are similar estimates in any dimension (though with possibly different numerology regarding the dependence on the size of the cap), with similar proofs; among other things, they form the backbone of the ")#mi("X^{s,b}")#text(" bilinear estimates of Bourgain, Klainerman-Machedon, Kenig-Ponce-Vega, and others, which are of importance in nonlinear dispersive equations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-645003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("Thanks! Can you point out some references in the literature?")

#emph[#text("[See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1854113")[#text("this paper of mine")]#text(". – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fce5aa48b326c44dfc81eef272c349f48c974ad3989457e4f6e7b7cfb513243-d068e9f848935b665485d99cddcc9cea9f572b22ac7f2a12efa3a10f75c4e1ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wbshu")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-678169")[#strong[#text("wbshu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2023")])]

#text("Dear Prof. TAO:")#linebreak()#text(" If ")#mi("f \\in L^1")#text(" and then its fourier transform ")#mi("\\hat{f}")#text(" is defined in your formula (1), I wonder if ")#mi("\\hat{f} \\in L^2")#text(" can infer that ")#mi("f \\in L^2")#text(". i.e., Do the plancherel inverse fourier transform of ")#mi("\\hat{f}")#text(" have the same L2 norm with ")#mi("f")#text("? If ")#mi("f \\in L^2")#text(", this is trivial. The problem is that how about if we only know ")#mi("f \\in L^1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-678200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Yes, this is a consequence of Plancherel’s theorem and the uniqueness of the Fourier transform (the latter can for instance be derived from the theory of the Fourier transform on (tempered) distributions).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wbshu")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-678213")[#strong[#text("wbshu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Thanks very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-682206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2023")])]

#text("There is a paper on arXiv claiming the proof of the fourier restriction conjecture:")

#link("https://arxiv.org/pdf/2311.03145.pdf")[#text("Click to access 2311.03145.pdf")]

#text("Has anyone read it? Is the problem solved?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-682254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("Dr. Tao: Are arXiv papers reliable? Are they peer reviewed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28adb13b372f50d66f8c5be5a61bb0c0104ecb91139785dd5489d57915f24987-a3ae8b15730f6680f3b20883efd151a8fd19096f02895cbf2163ef59a7cef53a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Days Gone By")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-682349")[#strong[#text("Days Gone By")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2023")])]

#text("Judging from the main theorem (if the Lp norm notations on both side is not a typo), it is unlikely correct, at least inconsistent with interpolation theorem (of any kind).")#linebreak()#text(" The author seems to be a serious mathematician though…waiting for Terry’s comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-682901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2024")])]

#text("Doesn’t it destroy his reputation to claim such and then withdraw the paper?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-682860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2024")])]

#text("The paper has been withdrawn. What does it mean?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-687654")[#strong[#text("Hong Wang and Joshua Zahl’s Solution for Kakeya’s Problem in Three Dimensions – Reflections and Links | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")]

#text("[…] would imply the Kakeya conjecture. Here is a blog post by Terry Tao on the restriction problem and lecture notes also by Tao, and here is a related videotaped lecture by Larry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-691775")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2026")])]

#text("Dear Professor Tao,")

#text("I am stuck in an knapp’s example. You mentioned the plate structure of the knapp’s example for the restriction theorem on the conic surface. But what if the things on Lie groups, such as conic surface in Heisenberg groups, what is the knapp’s example should be (for various operators such as restriction or maximal operator)?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-691785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2026")])]

#text("I think one first needs to clarify what precisely one even means by a restriction operator when working on a nonabelian group such as the Heisenberg group, where the (nonabelian) Fourier transform has a much different form than the standard Fourier transform for locally compact abelian groups.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-692256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2026")])]

#text("Could you please tell me how far the study of the restriction conjecture has progressed following Hahn and Cairo’s proof of the Mizohata–Takeuchi conjecture, and Hong Wang’s proof of the Kakeya conjecture in three dimensions? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-692267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2026")])]

#text("Still very much an active area of research! Over a year ago, ")#link("https://arxiv.org/abs/2411.08871")[#text("Wang and Wu proposed")]#text(" a route to the restriction conjecture via a Furstenberg type conjecture. Unfortunately, Alex Cohen ")#link("https://cims.nyu.edu/~ac6074/TwoEndsCounterexample.pdf")[#text("demonstrated that this conjecture is false")]#text(", but it is possible that the underlying approach can be salvaged. I would imagine there will be several further developments along these lines in the near future; conferences on harmonic analysis are probably the best way to keep up to date on these topics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-693354")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("How to conclude the spherical cap has surface measure $\\delta^{d-1}$ above (16)?I’m sorry I’ve just missed this part of your lesson.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-693355")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("I am ")#link("https://claude.ai/share/d52fb185-dae2-4efe-bbe5-776565ebd205")[#text("outsourcing this question to an AI")]#text(".")

#text("Heuristically, the sphere, being smooth, is locally similar to a flat ")#mi("d-1")#text("-dimensional space, so the cap is similar to a ")#mi("d-1")#text("-dimensional ball of radius ")#mi("\\delta")#text(", which explains the numerology; but as indicated in the AI answer, one can compute rigorously using spherical coordinates if desired.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-693357")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Can you help send the AI answer of it to me?Thank you very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-694034")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("What is the example of the necessary condition of the Fourier restriction theorem for the cone?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-694041")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("I am ")#link("https://claude.ai/share/0c386435-ff6f-46c4-a010-2f3b2a2f5bc9")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-694088")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("How to conclude the surface measure of the light cone is $\\frac{1}{|\\xi|}$?I think the surface measure of it should be a constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-2/#comment-694098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("On compact subsets of the cone, the choice of surface measure is not critical since most standard choices of such measures are equivalent up to constants, but the weight ")#tao-math("1/\\left|\\xi\\right|", block: false)#text(" has the advantage of being Lorentz-invariant (this is easiest to see by showing that this choice of surface measure is essentially the distribution ")#tao-math("\\delta(\\tau^2 - \\left|\\xi\\right|^2)", block: false)#text(" up to normalization constants).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bd3520a9a45f5a59cb99d16fec8a9fa83ec641045934efa4ed5305da1c7f76f-615006709b00526f7f45f54427581dab0e15ffd1011babc668f8c849a8f6cfe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aidan Backus")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549031")[#strong[#text("Aidan Backus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("By “By (20), (3), and the Riesz-Thorin interpolation theorem” do you mean “By (2), (3), …”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549228")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("The Beginning of Section 3 (bilinear estimates) has a non-typeset equation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d8678dff8d510113f8f21cc974b4b29903c4254de91cbfa6718f98bb2e7bd43-7043504b21ee22b7940ab185d17ca60bfc824d2e6844482bde4fd59d4b1a8e96.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549245")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Thank you for making your lectures public. It was fantastic! I had one question about the content covered today. I was a little confused about how you were relating curvature with the estimate (7). Specifically the following sentence from your note:")

#text("“As the sphere is tangent to first order at these points, this cap will have diameter {\\sim 1/|x|^{1/2}} in the directions of the {d-1}-dimensional tangent space…”")

#text("How exactly is the degree of tangency at stationary points affecting the new diameter (which is {1/|x|^{1/2}}) in this case? You were also trying to make an example with {y=x^3} graph during lecture, but this concept is not clicking with me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Regarding diameter it comes from Taylor series. Regarding the second part what’s the curvature of y=x^3 at x=0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("Because the sphere is tangent to the indicated hyperplane at second order (first order was a typo), if one moves a distance ")#mi("\\varepsilon")#text(" away from the point of tangency, the sphere and hyperplane will be separated by ")#mi("O(\\varepsilon^2)")#text(". Therefore, if one wants to stay within a single wavelength ")#tao-math("1/\\left|x\\right|", block: false)#text(" of the plane wave ")#mi("\\xi \\mapsto e^{2\\pi i x \\cdot \\xi}")#text(", one can only afford to move a distance ")#tao-math("1/\\left|x\\right|^{1/2}", block: false)#text(" or so away from the point of tangency, so the region of stationary phase is a spherical cap of width ")#tao-math("\\sim 1/\\left|x\\right|^{1/2}", block: false)#text(", and hence measure ")#tao-math("\\sim_d 1/\\left|x\\right|^{(d-1)/2}", block: false)#text(".")

#text("Now consider the integral ")#mi("\\int_{-1}^1 e^{2\\pi i \\xi^3 y}\\ d\\xi")#text(", which can be interpreted as the inverse Fourier transform of a measure on the cubic curve ")#mi("\\{ (\\xi,\\xi^3): -1 \\leq \\xi \\leq 1 \\}")#text(" evaluated at the point ")#mi("(0,y)")#text(". The stationary point of the phase ")#mi("(\\xi,\\xi^3) \\mapsto \\xi^3 y")#text(" is at the origin ")#mi("(0,0)")#text(", and a single wavelength of the plane wave ")#mi("(\\xi_1,\\xi_2) \\mapsto e^{2\\pi i (\\xi_1,\\xi_2) \\cdot (0,y)}")#text(" is a horizontal strip of width ")#tao-math("1/\\left|y\\right|", block: false)#text(" centred at this origin. Since the cubic curve is tangent to the x-axis to third order, one has to move a distance about ")#tao-math("1/\\left|y\\right|^{1/3}", block: false)#text(" along the cubic curve in order to move one wavelength away from the stationary point, so the stationary region ")#tao-math("\\{ (\\xi,\\xi^3): \\xi = O(1/\\left|y\\right|^{1/3})\\}", block: false)#text(" has measure about ")#tao-math("1/\\left|y\\right|^{1/3}", block: false)#text(". Thus one expects a decay of ")#tao-math("1/\\left|y\\right|^{1/3}", block: false)#text(" for this measure in the vertical direction (in other directions one has non-zero curvature again and one recovers the asymptotic decay of order ")#mi("1/2")#text(" rather than ")#mi("1/3")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549257")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Some thoughts about different Zoom setups, in case anyone here might find it helpful…")

#text("The most successful live-writing setup I’ve seen is using an Apple pencil on an ipad pro, hooked up to a mac running Zoom. I believe this can be simplified to just running Zoom on the ipad directly and sharing screens from there. Personally, Apple pencil/ipad is my favorite electronic writing device because it has a very fine tip and non-existent lag. There are many free programs, such as penultimate, which display nicely on screen share. The only drawback I noticed is that the pencil makes a loud tapping on the ipad glass when writing (very audible to the audience); this can be fixed by wrapping the tip in a few layers of plastic wrap.")

#text("Another setup I’ve seen is using a webcam to point at a piece of paper on a table, and writing on that. The advantage is that you can do anything you can do with paper, just as easily. One disadvantage is that sometimes only part of the paper is visible, and so not much can fit into the screen at once. Another tricky part is angling the camera correctly. I’ve seen people use a smartphone for the same purpose (but be careful that it doesn’t run out of power mid-session).")

#text("Slides work very easily over Zoom, as slides. Naturally, they retain the usual disadvantages of slides (pre-determined pacing, no freedom to write, etc.). They seem to be the most popular option for Zoom math seminars.")

#text("Finally, a recommendation: run a test meeting with someone every time you want to try a new setup. A few unexpected things happened to me when I did this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc91e377d91b4633c6fcd96dfe4b6116f72d1223c70f98669b8a05960ece7ed0-bf826328ee45997edd10312b4570a792f0dfcb348c7ae7b7d580536a5b47388f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Garo")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549262")[#strong[#text("Garo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Slight typo in the first proof of Prop 3, right before “combining all these estimates,” should be L^p norms of the Fourier transform of f on both sides")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cac83d02dd6977f5061804a4d894be3b9645d27f1db4a0e7cf9ce8553dc363aa-69e35e29c8ac7ea9f000156bb9ea41e7eaf611d0e38e2c932ac1c2d0adfae094.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Calvin Khor")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549266")[#strong[#text("Calvin Khor")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Typo in the geometric explanation for the exponent ")#mi("-\\frac{d-1}2")#text(" – “As the sphere is tangent to first order at these points,”, this should be tangent to second order. Also, in Remark 23, your LaTeX is showing “(and independently \\href)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("Does anyone have an example of a L^1 function whose Fourier transform lies exclusively in C^0, i.e. f^ has no higher regularity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("The function ")#mi("f(x) = \\sum_{n=1}^\\infty \\frac{1}{n^2} e^{-\\pi (x-x_n)^2}")#text(" is in ")#mi("L^1")#text(" for any sequence of shifts ")#mi("x_n")#text(", and has Fourier transform ")#mi("\\hat f(\\xi) = \\sum_{n=1}^\\infty \\frac{1}{n^2} e^{-2\\pi i x_n \\xi} e^{-\\pi \\xi^2}")#text(". This becomes a Weierstrass type function when the ")#mi("x_n")#text(" go to infinity sufficiently quickly, and in particular can exit all higher regularity spaces, such as ")#mi("C^1")#text(" or the Holder spaces ")#mi("C^{0,\\alpha}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-560030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Let ")#mi("d\\sigma")#text(" be the measure of the sphere. Consider ")#mi("f(x) = (d\\sigma)^\\vee(x)\\cdot (d\\sigma)^\\vee (x)")#text(". It is continuous as explained in these notes. Its Fourier transform is equal to ")#mi("d\\sigma * d\\sigma")#text(", which with trigonometry may be calculated exactly to be a piecewise linear function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-560032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("What I meant to say is to take")

#mi("f(x) = (d\\sigma)^\\vee(x)(d\\sigma)^\\vee(x)(d\\sigma)^\\vee(x)")

#text("Then ")#mi("f(x)")#text(" is in ")#mi("L^1")#text(" by stationary phase (as explained in these notes). Its Fourier transform is equal to")

#mi("(d\\sigma)*(d\\sigma)*(d\\sigma)")

#text("which with trigonometry may be calculated exactly to be a piecewise linear function.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549273")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("In the following identity")#linebreak()#text(" ")#tao-math("\\displaystyle  \\left\\| \\hat f \\right\\|_{L^2(S^{d-1}, d\\sigma)}^2 = \\langle f, f * (d\\sigma)^\\vee \\rangle_{L^2({\\bf R}^d)}. \\ \\ \\ \\ \\ (5)", block: false)#linebreak()#text(" should the second ")#mi("f")#text(" on the right be its conjugate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549280")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("Here we are using the Hermitian inner product ")#mi("\\langle f, g \\rangle_{L^2({\\bf R}^d)}")#text("; I’ve updated the notes to record this convention.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b91c38baa9f942c691912d7e92e27f2434ebf23e23a51ae3470d5bc2656a807a-e70dbf2417bc9b96ed3c69aedd2a64637568cce6f9d0f37da6dd7845a5d337a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksandar Bulj")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549419")[#strong[#text("Aleksandar Bulj")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("Professor Tao, there is some gap in the notes right after the equation (27). Also, there is a minor typo in Exercise 16 – ")#mi("p<\\frac{2d}{d-1}")#text(" should be ")#mi("p<\\frac{2d}{d+1}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549450")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("If one looks at the space ")#mi("L^p(\\mathbb{R}^d)")#text(", then ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text(" tells roughly the “width” and “hight” (")#mi("AV^{1/p}")#text(") of ")#mi("f")#text(" as mentioned in the 245B notes. Does one have the “similar” information when one works on ")#mi("L^p(\\mathbb{T})")#text(" or ")#mi("\\ell(\\mathbb{Z})")#text("?")

#emph[#text("[Yes – in all cases the volume ")#mi("V")#text(" is the measure of the region where it is concentrated -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bd3520a9a45f5a59cb99d16fec8a9fa83ec641045934efa4ed5305da1c7f76f-615006709b00526f7f45f54427581dab0e15ffd1011babc668f8c849a8f6cfe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aidan Backus")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549477")[#strong[#text("Aidan Backus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("Sure, as you can always view a function in ")#mi("L^p(\\mathbb T)")#text(" as a function in ")#mi("L^p([0, 1])")#text(" such that ")#mi("f(0) = f(1)")#text(" and you can always view a function in ")#mi("\\ell^p(\\mathbb Z)")#text(" as a function in ")#mi("L^p(\\mathbb R)")#text(" which is constant on each half-open interval ")#mi("[n, n+1)")#text(" (")#mi("n \\in \\mathbb Z")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549549")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("Hi Prof. Tao,")

#text("(1) In the proof of Khintchine’s inequality, the exponential moment method works for all 0 < p < infinity right? It also works for p between 0 and 2, although that was taken care of by Holder's inequality in the proof.")

#text("(2) In the proof of the lower bound for 0 < p 1. One could write ")#tao-math("E\\left|\\sum_{j} \\epsilon_j x_j\\right|^2 = E\\left|\\sum_{j} \\epsilon_j x_j\\right|^{p/2} \\left|\\sum_{j} \\epsilon_j x_j\\right|^{2 - p/2}", block: false)#text(", apply Cauchy-Schwarz, then apply the upper bound estimate for the exponent 4 – p to get the final estimate. You drew a graph involving exponent but it was fast and I could not get what you were trying to say. Is this what you are trying to say? I am also not sure what you mean by applying Holder inequality in reverse.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("(1) Yes, the exponential tail bound also implies the upper ")#mi("p^{th}")#text(" moment bound in the range ")#mi("p \\leq 2")#text(".")

#text("(2) Cauchy-Schwarz is a special case of H\\”older. You are interpolating the ")#mi("L^2")#text(" moment between the ")#mi("L^p")#text(" moment and the ")#mi("L^{4-p}")#text(" moment and using the lower bound for the ")#mi("L^2")#text(" moment and upper bound for the ")#mi("L^{4-p}")#text(" moment to deduce an lower bound for the ")#mi("L^p")#text(" moment (this is a “contrapositive” of the “usual” way one applies Cauchy-Schwarz, which in this case would be to deduce an upper bound for the ")#mi("L^2")#text(" norm from upper bounds on the ")#mi("L^p")#text(" and ")#mi("L^{4-p}")#text(" norms). Similarly, one can use H\\”older’s inequality to interpolate the ")#mi("L^2")#text(" moment between the ")#mi("L^p")#text(" and ")#mi("L^4")#text(" norms (see e.g., Lemma 9 of ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")]#text(" ) and give an essentially identical argument (deciding which one is preferable is largely a matter of personal taste).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("The displayed formula above (28) is missing (“does not parse”).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59b9e528bfec265ece9e5221e6a1be5ef013e2d951e0df6a271dda781dc70d30-1d47102bdbad905cd902ceddd0b22146e1c417c20f081e5920a7ae7f16948110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Hi Professor Tao,")

#text("Could you explain what isotypic components have to do with ")#mi("L^p")#text(" norms?")

#text("How does one make sense of exponentiating a symplectic form or more generally a dimensioned quantity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Let ")#mi("V")#text(" denote the space of all observables ")#mi("v: {\\mathcal S}({\\bf R}^d) \\to {\\bf C}")#text(" on the space of Schwartz functions. This is an infinite dimensional vector space, and expressions such as ")#tao-math("f \\mapsto \\left\\|f\\right\\|_{L^p({\\bf R})^d)}", block: false)#text(", ")#tao-math("f \\mapsto \\left\\|\\hat f\\right\\|_{L^q({\\bf R}^d)}", block: false)#text(" can be viewed as individual vectors in this vector space.")

#text("The multiplicative group ")#mi("{\\bf R}^+ := \\{ \\lambda: \\lambda > 0 \\}")#text(" acts on ")#mi("{\\mathcal S}({\\bf R}^d)")#text(" by the scaling ")#mi("f \\mapsto f_\\lambda")#text(", and thus also acts on ")#mi("V")#text(" by the Koopman action ")#mi("v \\mapsto v_\\lambda")#text(", where ")#mi("v_\\lambda(f) := v( f_{\\lambda})")#text(" (one can also use ")#mi("f_{1/\\lambda}")#text(" instead of ")#mi("f_\\lambda")#text(" here, though in this abelian setting it doesn’t make much of a difference). This is a linear action on ")#mi("V")#text(", so in principle one can use this action to decompose ")#mi("V")#text(" into isotypic components of the action, which in this one-parameter abelian setting just corresponds to eigenspaces ")#mi("V_\\alpha = \\{ v \\in V: v_\\lambda = \\lambda^\\alpha v \\text{ for all } \\lambda \\in {\\bf R}^+\\}")#text(" of a given weight ")#mi("\\alpha")#text(". For instance the observable ")#tao-math("f \\mapsto \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: false)#text(" lies in the eigenspace of weight ")#mi("d/p")#text(", and the observable ")#tao-math("f \\mapsto \\left\\|\\hat f\\right\\|_{L^q({\\bf R}^d)}", block: false)#text(" lies in the eigenspace of weight ")#mi("d-d/q")#text(". It is not possible for a non-trivial observable of one weight to be pointwise dominated by a non-trivial observable of a different weight, thus leading to the necessary condition ")#mi("d/p = d-d/q")#text(". One can thus view the units that dimensional analysis attaches to each (dimensionally consistent) observable as just describing the weight of the isotypic component that this observable lives in. (Observables that are not dimensionally consistent would be (morally, at least) a linear combination of terms from different components.)")

#text("The exponential of a dimensionful quantity such as a symplectic form ")#mi("\\omega \\in \\Lambda^2(M)")#text(" would live in the graded algebra ")#mi("\\bigoplus_{k \\geq 0} \\Lambda^k(M)")#text(" of formal linear combinations of differential forms of different orders; in particular, the top order term of ")#mi("\\exp(\\omega)")#text(" in a ")#mi("2n")#text("-dimensional symplectic manifold would be Liouville measure ")#mi("\\omega^n/n!")#text(", and I believe there is some useful symplectic geometry interpretation of the other terms as well (and I vaguely remember being told it is also useful to consider exponentials of deformations ")#mi("\\omega+H")#text(" (or was it ")#mi("\\omega+dH")#text("?) of ")#mi("\\omega")#text(" by a Hamiltonian ")#mi("H")#text(", though I forget why this was so – maybe something to do with Poisson geometry or contact geometry or equivariant cohomology?). The ")#link("https://en.wikipedia.org/wiki/Todd_class")[#text("Todd class")]#text(" in algebraic topology is also constructed in a fashion somewhat like this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04cb5cc46cbd11becbc6c85e76aaa98f21284f09ba67500a2c0d011f7fe723ec-4a18deec6b52fbdb9ab4aa4fa75365b66167d685d711c95260b9e89599a9b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Berndtsson")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549847")[#strong[#text("Bo Berndtsson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2020")])]

#text("If we take ")#mi("M")#text(" to be the cotangent bundle of ")#mi("R^n")#text(" and ")#mi("\\omega")#text(" its standard symplectic form ")#mi("\\sum_i dx_i\\wedge d\\xi_i")#text(" one can also look at the ‘deformation’ ")#mi("\\omega+ i x \\cdot \\xi")#text(". Then, for a ")#mi("p")#text("-form ")#mi("f")#text(",")

#mi("\\displaystyle \\int_x f(x)\\wedge e^{\\omega+i x \\cdot \\xi}=:\\hat f(\\xi)")

#text("is an ")#mi("n-p")#text("-form that can be seen as the Fourier transform of ")#mi("f")#text(", and the usual calculus goes over.")

#text("Concerning ")#mi("\\omega+H")#text(" (yes, I think that is the good one), it satisfies")

#mi("\\displaystyle (d-V_H)(\\omega+H)=0,")

#text("with ")#mi("V_H")#text(" being the Hamiltonian vector field associated to ")#mi("H")#text(". This can be used to derive formulas a la Duistermaat-Heckman.")

#text("I believe there is something about both these things in the article")#linebreak()#text(" ‘Integral representations with weights I’, by Mats Andersson in Math Ann 2003, and in the references there, but I cannot access it right now.")#linebreak()#text(" A good reference related to the second part is the book by Weiping Zhang, ‘Lectures on Chern-Weil theory and Witten deformations’.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2020")])]

#text("Thanks for this! Yes, I now recall that it was in the context of establishing the Duistermaat-Heckman formula that I was told that it was useful to combine the symplectic form ")#mi("\\omega")#text(" with the Hamiltonian ")#mi("H")#text(" and manipulate the inhomogeneous differential form ")#mi("\\omega+H")#text(". (Not 100% sure if it was also a good idea to exponentiate this form, though.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Michael Hitrik has kindly pointed me to these lecture notes of Alekseev at ")#link("https://www.esi.ac.at/static/esiprpr/esi744.pdf")[#text("https://www.esi.ac.at/static/esiprpr/esi744.pdf")]#text(" that explain the link between exponentials of deformed symplectic forms and the Duistermaat-Heckman formula further. The DH formula concerns Fourier integrals of the form ")#mi("\\int_M e^{i \\xi H} \\frac{\\omega^n}{n!}")#text(" against Louiville measure ")#mi("\\omega^n/n!")#text(" for some Hamiltonian ")#mi("H")#text(" and frequency ")#mi("\\xi")#text("; this can be written in exponential notation as ")#mi("\\int_M e^{\\omega + i\\xi H}")#text(". As Bo pointed out, the deformed symplectic form ")#mi("\\omega + i \\xi H")#text(" is closed with respect to the equivariant differential ")#mi("d - i \\xi V_H")#text(", and hence so is ")#mi("e^{\\omega +i \\xi H}")#text(". The DH formula then follows from a more general fixed point formula for integration of equivariantly closed (inhomogeneous) forms, due to Belrine-Vergne and Atiyah-Bott.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Dear Dr. Tao:")

#text("Could you post your notes in .pdf format? It is easier to print them first and take notes during lectures.")

#emph[#text("[If you print a blog post to PDF it should be fairly readable, indeed I lectured from such a PDF on Wednesday. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("I don’t follow the proof of Khintchine’s inequality.")

#emph[#linebreak()#text(" When ")#mi("{p=2}")#text(" the upper and lower bounds follow by direct calculation (in fact we have equality ")#tao-math("{ {\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^2 = 1}", block: false)#text(" in this case). By Hölder’s inequality, this yields the upper bound for ")#mi("{p \\leq 2}")#text(" and the lower bound for ")#mi("{p>2}")#text(".")#linebreak()#text(" ")]

#text("True that by direct calculation, one gets:")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2\\sim 1", block: false)#text(" (1).")

#text("How does the log convexity of ")#mi("L^p")#text(" norm (Holder),")

#tao-math("\\displaystyle  \\left\\|f\\right\\|_2\\leq \\left\\|f\\right\\|_p^{1-\\theta}\\left\\|f\\right\\|_q^{\\theta}", block: false)

#text("where ")#mi("\\frac{1}{2}=\\frac{1-\\theta}{p}+\\frac{\\theta}{q}")#text(", together with (1), imply that for ")#mi("p\\leq 2")#text(",")

#tao-math("\\displaystyle \\left\\|f\\right\\|_p \\gtrsim 1\\ \\ ?", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549716")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#tao-math("\\left\\|f\\right\\|_2 \\leq \\left\\|f\\right\\|_p^{1-\\theta} \\left\\|f\\right\\|_q^\\theta \\iff \\left\\|f\\right\\|_p \\geq \\left\\|f\\right\\|_2^{\\frac{1}{1-\\theta}} \\left\\|f\\right\\|_q^{-\\frac{\\theta}{1-\\theta}}", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("I must miss something rather obvious: but the quantity ")#tao-math("\\left\\|f\\right\\|_q", block: false)#text(" on the right, depending on ")#mi("f")#text(" and ")#mi("q")#text(", is also unknown, isn’t it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("The upper bound (11) in the post controls this quantity.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("But one has yet to establish (11) up to this point (the excerpt below), right?")

#emph[#linebreak()#text(" Proof: We begin with (i). By taking real and imaginary parts we may assume without loss of generality that the ")#mi("{z_j}")#text(" are all real, then by normalisation it suffices to show the upper bound")]

#tao-math("\\displaystyle {\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^p \\lesssim_p 1 \\ \\ \\ \\ \\ (11)", block: false)

#text("and the lower bound")

#tao-math("\\displaystyle {\\bf E} \\left|\\sum_{j=1}^n \\epsilon_j x_j\\right|^p \\gtrsim_p 1 \\ \\ \\ \\ \\ (12)", block: false)

#text("for all ")#mi("{0 < p 2}")#text(".")#linebreak()

#text("I may significantly misunderstand the logic of your proof. But in the log convexity inequality")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2 \\leq \\left\\|f\\right\\|_p^{1-\\theta} \\left\\|f\\right\\|_q^\\theta \\iff \\left\\|f\\right\\|_p \\geq \\left\\|f\\right\\|_2^{\\frac{1}{1-\\theta}} \\left\\|f\\right\\|_q^{-\\frac{\\theta}{1-\\theta}}", block: false)

#text("there are three quantities: ")#tao-math("\\left\\|f\\right\\|_2", block: false)#text(", ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text(", and ")#tao-math("\\left\\|f\\right\\|_q", block: false)#text(".")

#text("In order to bound ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text(" (resp. ")#tao-math("\\left\\|f\\right\\|_q", block: false)#text("), one needs to first bound ")#tao-math("\\left\\|f\\right\\|_2", block: false)#text(" and ")#tao-math("\\left\\|f\\right\\|_q", block: false)#text(" (resp. ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text(").")

#text("But so far, one has only bounds for ")#tao-math("\\left\\|f\\right\\|_2", block: false)#text(". How can one draw any conclusion for ")#tao-math("\\left\\|f\\right\\|_q", block: false)#text(" or ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("This inequality is used for the last part of the argument, namely to establish the lower bound (12) for ")#mi("p<2")#text(", which is what you initially asked about. To obtain the lower bound (12) for ")#mi("p \\geq 2")#text(", one uses the inequality")

#tao-math("({\\bf E} \\left|f\\right|^q)^{1/q} \\leq ({\\bf E} \\left|f\\right|^p)^{1/p}", block: false)

#text("for ")#mi("q \\leq p")#text(", which follows from H\\\"older by writing ")#mi("f = f \\times 1")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2020")])]

#text("Ah, I was looking at the wrong combinations of cases in")

#mi("\\displaystyle \\{ub(11), lb(12)\\}\\times\\{p\\leq 2, p>2\\}")

#text("and confused myself.")

#text("Writing ")#tao-math("\\left\\|f\\right\\|_p", block: false)#text(" instead of ")#tao-math("({\\bf E} \\left|f\\right|^p)^{1/p}", block: false)#text(", I overlooked the assumption that we are in a probability space! Now I believe it is very clear.")

#text("Case I. ((11), p<2)")#linebreak()#text(" After establishing ")#tao-math("\\left\\|f\\right\\|_2\\sim 1", block: false)#text(", one immediately has")

#tao-math("\\displaystyle \\left\\|f\\right\\|_p\\lesssim \\left\\|f\\right\\|_2\\sim 1\\quad (0<p<2)", block: false)

#text("by applying Holder to ")#tao-math("\\left|f\\right|^p=\\left|f\\right|^p\\cdot 1", block: false)#text(", which works because one is in a space with finite measure, particularly a probability space.")

#text("Case II. ((12), p>2)")#linebreak()#text(" Now one can use the log convexity of ")#mi("L^p")#text(" norms (and ")#tao-math("\\left\\|f\\right\\|_2\\sim 1", block: false)#text("):")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2\\leq \\left\\|f\\right\\|_{q}^{1-\\theta}\\left\\|f\\right\\|_{p}^\\theta,\\quad \\frac{1}{2}=\\frac{1-\\theta}{q}+\\frac{\\theta}{p}", block: false)

#text("and Case I to get ")#tao-math("\\left\\|f\\right\\|_{p}\\gtrsim 1", block: false)#text(" for ")#mi("p>2")#text(": one has ")#tao-math("\\left\\|f\\right\\|_{q}^{1-\\theta}\\lesssim 1", block: false)#text(" by Case I.")

#text("Case III. ((11), p>2)")#linebreak()#text(" This follows from the exponential moment method.")

#text("Case IV. ((12), p<2)")#linebreak()#text(" Use the log convexity as in Case II (but now one has ")#mi("p<2")#text(" and ")#mi("q>2")#text("):")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2\\leq \\left\\|f\\right\\|_{q}^{1-\\theta}\\left\\|f\\right\\|_{p}^\\theta,\\quad \\frac{1}{2}=\\frac{1-\\theta}{q}+\\frac{\\theta}{p}", block: false)#text(".")

#text("I was confused by the uses of “Holder inequality” in different places: in Case I, it is the version of ")#tao-math("\\left\\|fg\\right\\|_r\\leq\\left\\|f\\right\\|_p \\left\\|g\\right\\|_q", block: false)#text(" which appears in many textbooks with ")#mi("r=1")#text("; in Case II and IV, it is used as the “log convexity” of ")#mi("L^p")#text(" norms. These two versions are equivalent, although one may confuse themselves if one sticks to one of them without noticing the other. I may fail you 245C if I don’t remember how to exchange between these two versions… :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Calvin Khor")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549785")[#strong[#text("Calvin Khor")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("For $p2$. I guess this is the log convexity at “$q=0$”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Hm, this was slightly longer and had a small computation, but doesnt “compile”. In any case Prof. Tao has already replied so there’s no need for me to reproduce it. It seems the LaTeX here isn’t done with dollar signs? is it with the slash+parentheses…? ")#mi("slashparens")#text(" ")#tao-fit-display[#mitex("slashsquarebrackets")]

#emph[#text("[See ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" for how to comment in LaTeX. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("It is interesting to see many people use “Khintchine” instead of “Khinchin” when writing “Khintchine’s inequality” in English, while “Khintchine” seems to be the French spelling according to Wikipedia (")#link("https://en.wikipedia.org/wiki/Aleksandr_Khinchin")[#text("https://en.wikipedia.org/wiki/Aleksandr_Khinchin")]#text("). Is there any norm in mathematical literature about how to spell a mathematician’s name? (In your linked survey, it is spelled as “Khinchin”.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("I will have to defer to a native Russian speaker on the many subtleties of how to transliterate a Cyrillic name such as Хи́нчин into the Roman alphabet. But in the early twentieth century, French (and German) were the dominant languages used in mathematical papers, so it is unsurprising to me that Russian mathematicians of that era were often transliterated into French instead of English.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549803")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I am following your lecture but I’m not affiliated to UCLA. I find the exercises really hard (I can’t solve most of them). Do you think it is possible to open a somewhat collaborative / git based “exercise book” where people can upload a solution or a part of a solution (even less) of some exercises ? Or do you think that such an initiative is useless?")#linebreak()#text(" Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d8678dff8d510113f8f21cc974b4b29903c4254de91cbfa6718f98bb2e7bd43-7043504b21ee22b7940ab185d17ca60bfc824d2e6844482bde4fd59d4b1a8e96.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550116")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2020")])]

#text("Perhaps we can form a study group for exercises ourselves rather than putting this extra burden on Professor Tao. I would be happy to be a part of it. We can figure out the logistics if people are interested. I am thinking that we could make a google group to post questions and have zoom sessions where we can talk also. Let me know if anyone is interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550346")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("You are completely right! However, is it possible to write latex on google groups? If yes then it is perfect. If not maybe we should have an overleaf document and we could even hand out the .tex file to T. Tao and share the file with anyone!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d8678dff8d510113f8f21cc974b4b29903c4254de91cbfa6718f98bb2e7bd43-7043504b21ee22b7940ab185d17ca60bfc824d2e6844482bde4fd59d4b1a8e96.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550373")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("I don’t think google groups would work with latex. But you can share a screen capture as an image. That’s what I usually do in e-mails with students. Or, we can just read latex codes. Unfortunately, Overleaf requires a paid membership to share with 2+ people, which I don’t have.")

#text("Since this is a course in progress and grades depend on homework exercises, we should avoid posting solutions in a public forum. Instead, we could limit to discussing ideas and hints and questions rather than the full solution.")

#text("I just created a public group to try. Here is the link:")#linebreak()#text(" ")#link("https://groups.google.com/forum/#!forum/math-247b")[#text("https://groups.google.com/forum/#!forum/math-247b")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("Dear Dr. Tao:")

#text("Could you post solutions after the due date? so others can study from? It would be one of the students’ hw, with his/her permission of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("The group is invisible to me… Is it just for me or you guys have the same problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16fc121e3b84418ae1faae922eee373edcc15c29c38598863b1e3739735552a9-31289b5ed6c7488efba3b20156847f14d4837d0793610734a2904316eec9d616.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551185")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("@Anonymous: Can you try it now? I changed some permission settings, but I am new to managing Google groups. I have permission set to public now.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549814")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Hi Prof. Tao,")

#text("Just want to make sure I understand the geometric heuristic to the decay of the Fourier transform of the surface measure of the sphere. The constancy of the phase near the stationary point prevents cancellation and thus contribute to the integral. We are looking for the area where the phase is roughly constant. My question is why do we then look at the area of the sphere between the tangent plane at the antipodal points and a parallel plane one wavelength away towards the origin? What is significant about one wavelength?")

#text("Also I am trying to apply the heuristic to see the asymptotics of the Bessel function ")#mi("J_m(r) = \\frac{1}{2\\pi} \\int_0^{2\\pi} e^{ir \\sin x} e^{-imx} dx")#text(". Two critical points are located at ")#mi("\\pi/2")#text(" and ")#mi("3\\pi/2")#text(" and the order of tangency is ")#mi("2")#text(". If assuming that the wavelength is ")#mi("1/r")#text(", then we would have the correct asymptotics ")#mi("r^{-1/2}")#text(". But what would be the wavelength in this case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2020")])]

#text("A wavelength is the distance one travels (in the direction of the frequency) to obtain a full revolution of the phase. If one only travels less than say one quarter of the wavelength then the phase is restricted to a single quadrant and there will be no significant phase cancellation.")

#text("In the case of the Bessel function, we are not integrating a plane wave and so the wavelength is not constant in space, it is instead variable. Around say ")#mi("x=\\pi/2")#text(" the phase ")#mi("r \\sin x")#text(" is roughly ")#mi("r - \\frac{r}{2} (x-\\pi/2)^2")#text(" by Taylor expansion and so one would have to move about ")#mi("r^{-1/2}")#text(" away from the stationary point to pass from one crest or trough of the phase to the next. So the wavelength near the stationary point is ")#mi("\\sim r^{-1/2}")#text(" (but when one is well away from the stationary points the wavelength is closer to ")#mi("r^{-1}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-549895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2020")])]

#text("In the formula below equation (14), did you mean integrate over ")#mi("\\mathbb{R}^{d-1}")#text(" rather than integrate over ")#mi("\\mathbb{R}^{d}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d8678dff8d510113f8f21cc974b4b29903c4254de91cbfa6718f98bb2e7bd43-7043504b21ee22b7940ab185d17ca60bfc824d2e6844482bde4fd59d4b1a8e96.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550115")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2020")])]

#text("How do you perform dimensional analysis on the sphere where there is no linear scaling invariance?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2020")])]

#text("This can’t be done directly for a single sphere or ellipsoid, but what one can do instead is work with a one-parameter family of ellipsoids, related to each other by parabolic scaling, and converging to the paraboloid when the scaling parameter goes to infinity, and use dimensional analysis to study the restriction theory of these ellipsoids. (A similar argument also works for Exercise 8.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552750")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("The intuition behind this is ‘clear’ and , nevertheless I find it very challenging to produce a proof of that strategy (namely for Exercise 9 (vi)). To be clear, assume that ")#mi("R(p\\to q)")#text(" for the sphere with the right scaling between ")#mi("p")#text(" and ")#mi("q")#text(". The restriction assumption writes")

#tao-math("\\displaystyle \\left(\\int \\left|\\hat f (\\xi)\\right|^q d\\sigma (\\xi)\\right)^{1/q} \\leqslant C \\left(\\int \\left|f(x)\\right|^p\\right)^{1/p}", block: false)

#text("where ")#mi("\\sigma")#text(" is the surface measure of the translated sphere (that touches the paraboloid at ")#mi("(0,0)")#text("). It is graphically clear that when the sphere is parabolically rescaled then the family of ellipsoid that produces is approximating the paraboloïd near the origin. I want to set a coordinate change in the form ")#mi("(\\xi ^{\\prime}, \\xi_d) \\mapsto (\\lambda \\xi ^{\\prime}, \\xi_d)")#text(". The main problem is that since there is no “explicit” description of ")#mi("d\\sigma")#text(" (of course there is but I think the point here is not to use it), I’m not able to make the coordinate change properly (only able to handwave). So my question has two points:")

#text("(i) Is it straightforward that the change of variable I am using transforms the ")#mi("R_{\\mathbb{S}^{d-1}}(p \\to q)")#text(" estimate into")

#tao-math("\\displaystyle \\left(\\int \\left|\\hat f (\\xi ^{\\prime}, \\xi_d)\\right|^q d\\sigma_{\\lambda} (\\xi)\\right)^{1/q} \\leqslant C \\left(\\int \\left|f(x)\\right|^p\\right)^{1/p}", block: false)

#text("(where we must use the scaling condition between ")#mi("p")#text(" and ")#mi("q")#text(" at some point) and where ")#mi("d \\sigma _{\\lambda}")#text(" stands for the surface measure of the ellipsoid image of the sphere under the map ")#mi("\\Phi : (\\xi ^{\\prime}, \\xi_d) \\mapsto (\\lambda \\xi ^{\\prime}, \\xi _d)")#text(".")

#text("(ii) Then we need the surface measure ")#mi("d\\sigma_{\\lambda}")#text(" to go to ")#mi("d \\xi ^{\\prime}")#text(" (we may loose a constant factor). This is reasonable on a sketch and by Taylor exansion, the sphere around ")#mi("(0,0)")#text(" has approximate equation: ")#tao-math("\\xi_d = 1- \\sqrt{1-\\left|\\lambda \\xi^{\\prime}\\right|^2} \\sim \\frac{1}{2}\\lambda ^2 \\left|\\xi^{\\prime}\\right|^2", block: false)#text(" which is a “handwaving” proof that the family of ellipsoid approximates the paraboloid. But how can one turn that idea into a rigorous proof?")

#text("If there is a way to make this work, then we can use the dominated convergence theorem (or monotone version) to conclude, by sending ")#mi("\\lambda \\to 0")#text(" in the previous inequality.")

#text("Is it posible to have some help/solution to this exercise, either from you or anyone who has a solution? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("It’s best not to work with surface measure directly (as it behaves somewhat messily with respect to scaling), but instead with the pushforward measure of ")#mi("d\\xi^{\\prime}")#text(" to the various surfaces involved (the sphere, the rescaled spheres, and the paraboloid). For the sphere, the conversion factor between ")#mi("d\\sigma")#text(" and the pushforward of ")#mi("d\\xi^{\\prime}")#text(" is not all that bad, it is just ")#tao-math("1 / \\sqrt{1-\\left|\\xi^{\\prime}\\right|^2}", block: false)#text(", and this scales away in the limit by a dominated convergence argument as you mention.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552823")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("Thank you, again! This was really helpful and the change of variable is now straightforward.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550503")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("Hi Prof. Tao,")

#text("Sever questions regarding the exercises:")#linebreak()#text(" 1) In exercise 12, I need to show the determinant of the Hessian of the phase ")#tao-math("\\phi(x) = 2\\pi \\frac{x}{\\left|x\\right|} \\cdot \\xi", block: false)#text(" (where I regard ")#mi("\\phi")#text(" to be a function of ")#mi("d-1")#text(" variable by precomposing with some parametrization of the sphere) at ")#tao-math("\\pm \\frac{x}{\\left|x\\right|}", block: false)#text(" is non-zero, and also should be independent of ")#mi("x")#text(" so that I can incorporate it into ")#mi("c_+")#text(" and ")#mi("c_-")#text(". I try to parametrize ")#mi("S^{d-1}")#text(" and calculate the second derivatives but it got me nowhere. Is there any easy to to calculate ")#tao-math("\\det \\nabla^2 \\phi\\left(\\frac{\\pm x}{\\left|x\\right|}\\right)", block: false)#text(" explicitly or do we simply need to see it is non-zero and only depend on ")#mi("d")#text(" using some symmetry argument?")

#text("2) In exercise 10 (flat hypersurface), can we assume S is bounded? I feel like we could because once we have the conclusion for bounded open S, we just note that every open nonempty S contains a bounded open ball. If the contrary holds for S, then the contrary would holds for the bounded open ball. Then we can reduce to ")#mi("q= 1")#text(" and showing ")#mi("R_S(p\\to 1)")#text(" implies ")#mi("p = 1")#text(". I haven’t figure out how to use the flatness here to show necessity. I understand that flatness gives that the Fourier transform of the surface measure exhibit no decay in the direction normal to the hyperplane, which is insufficient for any restriction estimate.")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550504")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("By the way, in exercise 12, it should be ")#mi("R_{S^{d-1}}")#text(" and the error term is ")#tao-math("O_{g,d}(\\left|x\\right|^{-\\frac{d-1}{2} - 1}", block: false)#text(" I think.")

#emph[#text("[This is indeed the true order of decay, but depending on the stationary phase estimates used, one may only obtain the weaker bound of ")#tao-math("O_{g,d}(\\left|x\\right|^{-d/2})", block: false)#text(", which already suffices for the application -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("(1) ")#mi("\\phi")#text(" should be a function of ")#mi("\\xi")#text(", not ")#mi("x")#text(". One can first work for instance with the case ")#tao-math("x = \\left|x\\right| e_d", block: false)#text(" and then use rotation invariance to establish the general case.")

#text("(2) Yes, establishing the bounded case will also establish the unbounded case. As with Exercise 9, the three related methods of scaling arguments, dimensional analysis, and/or rescaled bump functions will work here (some of these may be more convenient to apply than others, though)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf39df540f0dfc4ec83435cd675f78dd722185c2db39244e6a73c189a89172ed-1b2b9f57ff0a3026d70a2ba214a09fbff6e4585625f635a11a9441c7b3d9b77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasper Liang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550748")[#strong[#text("Jasper Liang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("For stationary phase computation like 1), Page 42-43 of Wolff’s “Lectures on Harmonic Analysis” might be helpful.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("How can one justify that the cap in the Knapp example has surface measure ")#mi("\\sim_d\\delta^{d-1}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Without loss of generality one can rotate the cap to be centered at say ")#mi("e_d")#text(". Using the coordinate chart ")#tao-math("\\xi^{\\prime} \\mapsto (\\xi^{\\prime}, (1-\\left|\\xi^{\\prime}\\right|^2)^{1/2})", block: false)#text(", one can map the cap into a region that contains a disk ")#mi("B^{d-1}(0,c\\delta)")#text(" and is contained in a disk ")#mi("B^{d-1}(0,C\\delta)")#text(" for some absolute constants ")#mi("c,C>0")#text(", and the Jacobian factors of the coordinate chart will be comparable to 1 on these disks (assuming ")#mi("\\delta")#text(" is small enough). The claim now follows from the change of variables formula.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("How is the set ")#mi("T^{(c/\\delta)^2\\times c/\\delta}_{\\omega_0,0}")#text(" a tube? Even for the case when ")#mi("d = 2")#text(" and ")#mi("\\omega_0=(1,0)")#text(", how should one understand the set? The part ")#tao-math("\\left|x\\cdot\\omega_0\\right|\\leq (c/\\delta)^2", block: false)#text(" seems to be an infinite strip. What is the geometry of ")#tao-math("\\left|x-(x\\cdot\\omega_0)\\omega_0\\right|\\leq c/\\delta", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550703")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#tao-math("\\left|x\\cdot \\omega_0\\right|", block: false)#text(" is the component of ")#mi("x")#text(" in the direction ")#mi("\\omega_0")#text(" and ")#tao-math("\\left|x - (x\\cdot \\omega_0)\\omega_0\\right|", block: false)#text(" is the component of ")#mi("x")#text(" in the direction perpendicular to ")#mi("\\omega_0")#text(" (")#tao-math("\\left|\\omega_0\\right| = 1", block: false)#text("). So the set ")#mi("T")#text(" is the set of all ")#mi("x")#text(" with the property that the component in the direction of ")#mi("\\omega_0")#text(" is bounded by ")#mi("(c/\\delta)^2")#text(" and the component in the direction perpendicular to ")#mi("\\omega_0")#text(" is bounded by ")#mi("c/\\delta")#text(", which is a tube. In the case when ")#mi("d = 2")#text(" and ")#mi("\\omega_0 = (1,0)")#text(", T describes a rectangle with horizontal side of length ")#mi("(c/\\delta)^2")#text(" and vertical side of length ")#mi("c/\\delta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16fc121e3b84418ae1faae922eee373edcc15c29c38598863b1e3739735552a9-31289b5ed6c7488efba3b20156847f14d4837d0793610734a2904316eec9d616.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550700")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("For paraboloids, we have been using the flat ")#mi("{\\bf R}^{d-1}")#text(" measures, but how is this ")#mi("d \\mu")#text(" different from the measure of a hyperplane? Using this measure, it seems like the only influence of its curvature is in scaling arguments and not sure how it manifests in duality arguments with ")#mi("d\\mu^{\\vee}")#text(". Also, how does this connect to the restriction estimate on paraboloid using its surface measure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("The measure ")#mi("d\\mu")#text(" on the paraboloid is not the flat ")#mi("{\\bf R}^{d-1}")#text(" measure ")#mi("d\\xi^{\\prime}")#text(", but is rather the ")#emph[#text("pushforward")]#text(" of that measure with respect to the graphing map ")#tao-math("\\xi^{\\prime} \\mapsto (\\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2)", block: false)#text(". In particular, the two measures give rise to different Fourier transforms: ")#tao-math("\\int_{{\\bf R}^{d-1}} g(\\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2) e^{2\\pi i(x^{\\prime} \\cdot \\xi^{\\prime} + x_d \\left|\\xi^{\\prime}\\right|^2}\\ d\\xi^{\\prime}", block: false)#text(" rather than ")#mi("\\int_{{\\bf R}^{d-1}} g(\\xi^{\\prime}, 0) e^{2\\pi i(x^{\\prime} \\cdot \\xi^{\\prime}}\\ d\\xi^{\\prime}")#text(".")

#text("The surface measure ")#mi("d\\sigma")#text(" on the paraboloid can be computed to ")#mi("\\langle 2 \\xi^{\\prime} \\rangle d\\mu")#text(", so one can write ")#mi("gd\\sigma = \\tilde g d\\mu")#text(" for any test function ")#mi("g")#text(" with ")#mi("\\tilde g(\\xi) := \\langle 2 \\xi^{\\prime} \\rangle g(\\xi)")#text(". Using this relation it is possible to deduce restriction estimates for paraboloids (or compact subsets thereof) endowed with surface measure from restriction estimates for paraboloids with the measure ")#mi("d\\mu")#text(", or vice versa. However the surface measure is less natural in applications (for instance in applications to the Schrodinger equation it is the pushforward measure ")#mi("d\\mu")#text(" which is relevant), and also does not enjoy the Galilean invariance that the pushforward measure does.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550840")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("In Exercise 16 (ii) why is it ")#mi("p^{\\prime}/2")#text(" instead of ")#mi("p^{\\prime}")#text("? If one applies the restriction hypothesis then one gets an inequality in ")#mi("L^{p^{\\prime}}")#text(" norms, but then we do not recover bounds on ")#mi("L^{p^{\\prime}/2}")#text(" norms. Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("A square root will appear once one applies Khintchine’s inequality which will end up halving the exponent in the ")#mi("L^{p^{\\prime}}")#text(" norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550963")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("This works like a charm! Thank you! Apparently this techniques allows one to prove the Marcinkiewcz-Zygmund inequality, this is really an amazing technique.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf39df540f0dfc4ec83435cd675f78dd722185c2db39244e6a73c189a89172ed-1b2b9f57ff0a3026d70a2ba214a09fbff6e4585625f635a11a9441c7b3d9b77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasper Liang")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-550926")[#strong[#text("Jasper Liang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("Dear Professor Tao,")

#text("For the equation below Exercise 11, should it be ")#tao-math("\\left\\| (g\\ d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\| g\\right\\|_{L^{q^{\\prime}}(S^{d-1},\\sigma)}", block: false)#text(" instead of ")#tao-math("\\left\\| (g\\ d\\sigma)^\\vee \\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\lesssim_{d,p,q} \\left\\| g\\right\\|_{L^{q^{\\prime}}(S^{d-1},\\mu)}", block: false)#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551143")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Typo: two lines above the dispersive estimate, where we use the Minkowski inequality to bound the norm of the convolution, the ")#mi("\\int_\\mathbb{R}")#text(" is superfluous because the integration over ")#mi("y_d")#text(" is implicit in the convolution star.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551144")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("My comment above is wrong: the star is for the convolution in the ")#mi("x^{\\prime}")#text(" variable. Then it would help to add ")#mi("dy_d")#text(" to the integral.")

#emph[#text("[Corrected, thanks -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("How do you get the formula for Fourier transform of ")#mi("\\phi(./s^k)(d\\sigma)^{\\vee}")#text("?")

#text("Fourier transform of a product equals to the convolution of the transform, so")#linebreak()#text(" ")#mi("\\hat{\\phi}\\ast d\\sigma = \\int\\hat{\\phi(\\xi-\\zeta)/2^k}d\\sigma(\\zeta)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551161")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("The Fourier transform of ")#mi("x \\mapsto \\phi(x/2^k)")#text(" is ")#mi("\\xi \\mapsto 2^{dk} \\hat \\phi(2^k \\xi)")#text(", so the convolution should be ")#mi("\\int 2^{dk} \\hat \\phi(2^k(\\xi-\\zeta)) d\\sigma(\\zeta)")#text(", which is what is stated in the notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("While the existence is guaranteed by the Urysohn lemma, do you have an explicit example of the smooth bump function ")#mi("\\psi")#text(" (supported on ")#mi("B(0,1)")#text(" that equals ")#mi("1")#text(" on ")#mi("B(0,1/2)")#text(") used in the proof of Theorem 18?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551162")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("One could for instance set ")#tao-math("\\psi(x) = \\int_{\\left|x\\right|}^\\infty f(r)\\ dr", block: false)#text(", where ")#mi("f(r) := c e^{-\\frac{1}{1-r}} e^{-\\frac{1}{r-1/2}} 1_{(1/2,1)}(r)")#text(" and the constant ")#mi("c")#text(" is chosen so that ")#mi("f")#text(" has total mass one. (But there isn’t too much advantage to be had by having such an explicit form for such bump functions.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("In the Littlewood–Paley decomposition introduced in Schlag’s book, one has (Lemma 8.1) ")#mi("\\psi\\in C^\\infty(\\mathbf{R}^d)")#text(" with ")#mi("\\textrm{supp}(\\psi)\\subset\\mathbf{R}^d\\setminus\\{0\\}")#text(" is compact and such that")

#mi("\\displaystyle \\sum_{k\\in\\mathbf{Z}}\\psi(2^{-k}x) = 1,\\quad \\forall x\\neq =0.")

#text("What is the reason that one does not need ")#mi("\\psi(x/2^k)")#text(" with negative integer ")#mi("k")#text(" in the proof of Tomas-Stein restriction theorem? Is there a case when one should use only the negative part instead of the positive ones?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("The decay bound ")#mi("(d\\sigma)^\\vee(x) \\lesssim \\langle x \\rangle^{-\\frac{d-1}{2}}")#text(" does not exhibit any singularity as ")#mi("x")#text(" approaches the origin, so there is no need to perform a dyadic decomposition near that origin. Rather, it is the decay at spatial infinity that one wishes to exploit, and so that is why we focus on dyadically decomposing the large scales while keeping the contribution of all the fine scales together.")

#text("One can also predict this sort of decomposition from the uncertainty principle. The sphere is localised to a bounded region ")#mi("\\xi = O(1)")#text(" of frequency space, so any decomposition of physical space should naturally come with a spatial uncertainty of ")#mi("\\gtrsim 1")#text(". In particular it is not natural in this problem to ever make any decomposition that involves spatial scales finer than ")#mi("1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("The identity (5) and Holder together are used several places for reducing the restriction estimate to estimating the convolution of ")#mi("f")#text(" and the inverse Fourier transform ")#mi("(d\\sigma)^\\vee")#text(".")

#text("While (5) follows from Fubini (how can one justify the use of Fubini by the way?), is there any other intuition/motivation (than just algebraic manipulation) that explain why (5) is true?")

#text("Eventually, one uses Young’s convolution inequality for ")#mi("g:=f*(d\\sigma)^\\vee")#text(". What is the magic of this quantity ")#mi("g")#text("? You once explain the convolution as a fuzzy version of addition/multiplication, do we have a similar explanation here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Fubini’s theorem is not difficult to justify when ")#mi("f")#text(" is a test function, as both the spatial variable and frequency variable are now compactly supported.")

#text("One can think of ")#tao-math("\\left\\|f\\right\\|_{L^2(\\sigma)}^2", block: false)#text(" as the inner product of ")#mi("f")#text(" with ")#mi("f d\\sigma")#text(", in which case the identity in question is just a case of the Parseval formula (and the fact that the Fourier transform converts multiplication to convolution).")

#text("The convolution kernel ")#mi("d\\sigma^\\vee")#text(" is oscillatory, and so heuristics from probability theory are somewhat misleading in this case. Nevertheless one still expects ")#mi("f * d\\sigma^\\vee")#text(" to be smoother and more “spread out” than ")#mi("f")#text(" itself, although the effects of constructive or destructive interference are not all that intuitive (although the heuristic of square root cancellation does yield some predictions as to the behaviour of such a convolution).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551443")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")])]

#text("Dear Pr. Tao,")#linebreak()#text(" My question might be odd: do you have a heuristics to explain why the dyadic trick in the proof of the Thomas-Stein theorem leads to better range of exponents, rather than just applying directly the Young inequality (as in the introduction)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("The better range is not coming from the dyadic decomposition; one can also run the Young inequality argument by a similar dyadic decomposition of the kernel. The main difference is that the argument in Theorem 1 only uses the decay estimate (8) on ")#mi("d\\sigma^\\vee")#text(", whereas the argument in Theorem 18 uses both the decay estimate (8) as well as the bound on the Fourier transform of components of ")#mi("d\\sigma^\\vee")#text(" that occurs just before (21).")

#text("Indeed, one can rephrase the proof of Theorem 1 in a way that resembles the proof of Theorem 18 as follows. As in the proof of Theorem 18, the decay estimate (8) gives the ")#mi("L^1 \\to L^\\infty")#text(" estimate (20). To get an ")#mi("L^2 \\to L^2")#text(" estimate, instead of taking the Fourier transform we can instead use (8) to get the bound")

#tao-math("\\displaystyle \\left\\| \\psi(\\cdot/2^k) d\\sigma^\\vee \\right\\|_{L^1({\\bf R}^d)} \\lesssim_d 2^{kd} 2^{-\\frac{(d-1)}{2} k}", block: false)

#text("(because ")#mi("\\psi(\\cdot/2^k)")#text(" is supported on an annulus of volume ")#mi("O_d(2^{kd})")#text(") and so by Young’s inequality")

#tao-math("\\left\\| f * \\psi(\\cdot/2^k) d\\sigma^\\vee \\right\\|_{L^2({\\bf R}^d)} \\lesssim_d 2^{kd} 2^{-\\frac{(d-1)}{2} k} \\left\\|f\\right\\|_{L^2({\\bf R})^d)}.", block: false)

#text("This is a significantly worse estimate than (21) because it is not exploiting the oscillatory nature of ")#mi("d\\sigma^\\vee")#text(" and is instead relying primarily on the decay estimate (8), which is not the most appropriate input for the ")#mi("L^2")#text(" theory. But one can check that if one uses the above estimate as a substitute for (21) one recovers the preliminary restriction theorem in Theorem 1 rather than the optimal (other than endpoints) restriction theorem in Theorem 18.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551961")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Thank you, this is very clear!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("Hi Professor Tao,")

#text("Could you elaborate on ")#tao-math("\\left|(gd\\sigma)^{\\vee}\\right| \\gtrsim_{d,\\phi} \\delta^{d-1}", block: false)#text(" (the inequality 3 lines down from 16)? Is this because of the stationary phase formula and the fact that ")#tao-math("\\left|x\\right| \\lesssim \\frac{1}{\\delta^2}", block: false)#text(" in the tube?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("From (16) and pulling out the phase ")#mi("e^{2\\pi i x \\cdot \\omega_0}")#text(" we have")

#tao-math("\\displaystyle \\left|(gd\\sigma)^\\vee(x)\\right| = \\left|\\int_{\\kappa} e^{2\\pi i x \\cdot(\\omega-\\omega_0)} \\varphi(\\frac{x-x_0}{\\delta})\\ d\\sigma(\\omega)\\right|.", block: false)

#text("From the preceding discussion the integrand has real part ")#mi("\\sim_\\phi 1")#text(" on a slightly smaller version of the cap ")#mi("\\kappa")#text(", which has measure ")#mi("\\gtrsim_d \\delta^{d-1}")#text(", giving the claim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("In the last centered equation for the proof of the endpoint of Tomas-Stein there shouldn’t be an extra ")#mi("\\ast K_{x_d - y_d}")#text(" on the right hand side.")

#emph[#text("[Corrcted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("On the left-hand side of (6) and (7), absolute values are missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551640")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("Here we are using the asymptotic notation that ")#mi("X \\lesssim Y")#text(" denotes an estimate of the form ")#tao-math("\\left|X\\right| \\leq CY", block: false)#text(" (i.e., the absolute values are automatically in place).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("Professor Tao, you mentioned in class today in the proof Proposition 21, that we want to use convolution because there is no cancellation anymore, and the kernel of convolution operator is zero. Could you elaborate on this? Also, why don’t people study bilinear version of the restriction operator instead of the extension operator?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("The kernel ")#mi("\\delta(x-x_1-x_2)")#text(" of the bilinear convolution operation")

#mi("\\displaystyle f*g(x) = \\int f(x_1) g(x-x_1)\\ dx_1 = \\int\\int f(x_1) g(x_2) \\delta(x-x_1-x_2)")

#text("is a non-negative distribution (or equivalently: ")#mi("f*g")#text(" is non-negative whenever ")#mi("f,g")#text(" is). This is in contrast to Fourier-analytic operators such as the restriction operator ")#mi("f \\mapsto \\hat f|_S")#text(", or the extension operator ")#mi("g \\mapsto (g\\ d\\sigma)^\\vee")#text(", or variants thereof, where the kernel is oscillatory. In the latter case one has to somehow measure the amount of cancellation present in the operator in order to obtain efficient estimates; cruder tools (such as the triangle inequality, or Young’s inequality) that only exploit information about magnitudes of functions, but not phases, cannot pick up this cancellation and hence will be insufficient to obtain such estimates. In contrast, an inequality that has no cancellation in it has a chance of being established by purely non-cancellative tools such as Young’s inequality, as is the case here.")

#text("Bilinear versions of the restriction estimate turn out to not be so useful for two reasons: firstly, the exponent on the left-hand side will often become less than 1, which is very inconvenient technically, but more importantly such a bilinearisation does not create any transversality in the surfaces one is restricting to, which we now realise is one of the major sources of the restriction phenomenon. (Bilinearisation of a restriction estimate does generate some separation in physical space, but this does not seem to be a decisive influence on the strength and availability of restriction estimates, given that translation in physical space only affects the phase of the Fourier transform, but not the magnitude.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("In general, are the scaling argument and dimensional analysis “equivalent”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("I am a bit confused with the scaling argument.")

#text("If one knows ")#emph[#text("a priori")]#text(" that an estimate for ")#mi("\\int_a^be^{i\\lambda\\phi(x)}\\;dx")#text(" that is independent of ")#mi("a")#text(" and ")#mi("b")#text(" is of the form")

#mi("\\displaystyle \\int_a^be^{i\\lambda\\phi(x)}\\;dx\\lesssim \\lambda^\\beta,")

#text("then the change of variable ")#mi("x\\mapsto \\lambda^{-1/k}x^{\\prime}")#text(" shows that")

#mi("\\displaystyle \\int_a^be^{i\\lambda\\phi(x)}\\;dx = \\lambda^{-1/k}\\int_{a/\\lambda^{1/k}}^{b/\\lambda^{1/k}}e^{i\\lambda\\phi(x/\\lambda^{1/k})}dx\\lesssim \\lambda^\\beta")

#text("and thus")

#mi("\\displaystyle \\int_{a/\\lambda^{1/k}}^{b/\\lambda^{1/k}}e^{i\\lambda\\phi(x/\\lambda^{1/k})}dx\\lesssim \\lambda^{\\beta+1/k}")

#text("which implies ")#mi("\\beta=-1/k")#text(".")

#text("(0) How can one know in general what the bound should look like (e.g. ")#mi("\\lambda^\\beta")#text(")?")

#text("(1) Does one need to justify (can one?) that it is impossible that ")#mi("\\int_{a/\\lambda^{1/k}}^{b/\\lambda^{1/k}}e^{i\\lambda\\phi(x/\\lambda^{1/k})}dx\\to 0")#text(" as ")#mi("\\lambda\\to0")#text(" of ")#mi("\\lambda\\to \\infty")#text(" so that one can argue neither ")#mi("\\beta>1/k")#text(" nor ")#mi("\\beta<1/k")#text(" can happen?")

#text("(2) If one wants to get the ")#emph[#text("possible")]#text(" estimate ")#mi("\\lambda^{-1/k}")#text(" using dimensional analysis instead, what is the correct dimension of ")#mi("\\int_{a/\\lambda^{1/k}}^{b/\\lambda^{1/k}}e^{i\\lambda\\phi(x/\\lambda^{1/k})}dx")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("You are not applying the scaling argument correctly. In order to be able to exploit scaling for this particular claim properly, one needs to use not only the uniformity of the estimate in the parameters ")#mi("a,b,\\lambda")#text(", but also the uniformity in the phase ")#mi("\\phi")#text(". The claim that one should actually be analysing (for a fixed choice of ")#mi("k,\\beta")#text(") is")

#text("“Let ")#mi("a < b")#text(", and let ")#mi("\\phi \\in C^k([a,b])")#text(" be such that ")#tao-math("\\left|\\phi^{(k)}(x)\\right| \\geq 1", block: false)#text(" for all ")#mi("x \\in [a,b]")#text(". Then for any ")#mi("\\lambda>0")#text(", one has ")#mi("\\int_a^b e^{i\\lambda \\phi(x)}\\ dx \\lesssim_k \\lambda^\\beta")#text("“.")

#text("The point is that the hypotheses of this claim obey the following scale invariance: if ")#mi("a,b,\\lambda")#text(", and ")#mi("\\phi: x \\mapsto \\phi(x)")#text(" obey the above hypotheses, and ")#mi("\\lambda_0>0")#text(" is a scaling parameter, then ")#mi("\\lambda_0^{1/k} a, \\lambda_0^{1/k} b, \\lambda/\\lambda_0")#text(", and ")#mi("\\phi_{\\lambda_0}: x \\mapsto \\lambda_0 \\phi(x/\\lambda_0^{1/k})")#text(" also obey the above hypotheses. Applying the conclusion of the above claim to this rescaled data and applying a change of variables, one concludes that")

#mi("\\displaystyle \\int_a^b e^{i\\lambda \\phi(x)}\\ dx \\lesssim_k \\lambda_0^{-1/k-\\beta} \\lambda^\\beta")

#text("for any ")#mi("\\lambda_0>0")#text(" and any ")#mi("a,b,\\phi,\\lambda")#text(" obeying the hypotheses of the claim. Since one can easily construct ")#mi("a,b,\\phi,\\lambda")#text(" for which the left-hand side is non-zero, we arrive at a contradiction by sending ")#mi("\\lambda_0")#text(" to either zero or infinity unless ")#mi("\\beta=-1/k")#text(". Thus we conclude that ")#mi("\\beta = -1/k")#text(" is a necessary condition for this claim (though this does not show that it is sufficient; indeed, the claim is false when ")#mi("k=1")#text(").")

#text("Alternatively, one can arrive at the necessary condition ")#mi("\\beta = -1/k")#text(" by the following dimensional analysis argument. Give ")#mi("x")#text(" the units of length ")#mi("L")#text(". For the hypothesis ")#tao-math("\\left|\\phi^{(k)}(x)\\right| \\geq 1", block: false)#text(" to be dimensionally meaningful, the quantity ")#mi("\\phi^{(k)}(x)")#text(" must be dimensionless, hence ")#mi("\\phi")#text(" should have the units of ")#mi("L^k")#text(". In order for the exponential ")#mi("e^{i\\lambda \\phi(x)}")#text(" to be dimensionally meaningful, the quantity ")#mi("\\lambda \\phi(x)")#text(" must be dimensionless, hence ")#mi("\\lambda")#text(" must have the units of ")#mi("L^{-k}")#text(". The integral ")#mi("\\int_a^b e^{i\\lambda \\phi(x)}\\ dx")#text(" has the units of ")#mi("L")#text(", so one must then have ")#mi("\\beta=-1/k")#text(" for dimensional consistency. It will be instructive for you to work out why this dimensional analysis argument is simply an abstraction of the preceding scaling argument, with the units assigned to any given quantity (as a power of ")#mi("L")#text(") determining how that quantity scales with the scaling parameter ")#mi("\\lambda_0")#text(" (actually with this choice of notation ")#mi("L")#text(" determines the scaling exponent relative to ")#mi("\\lambda_0^{1/k}")#text(" rather than ")#mi("\\lambda_0")#text(").")

#text("In general if there is a scale invariance in the problem one expects to have power type dependencies in the parameters that are affected by the scaling, once the bound has been optimised by ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("arbitrage")]#text(". One could however produce non-optimised bounds that do not have this power law dependence. To give an artificial example, if one can prove a power law upper bound of the form ")#mi("\\lambda^\\beta")#text(" for the above claim, this obviously implies any weaker upper bound such as ")#mi("e^{\\lambda} \\lambda^\\beta")#text(", even though the latter bound is not of power law type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("Thank you for the details!")

#text("Before the proposition by van der Corput, Stein described in his Harmonic Analysis the scaling argument (very!) briefly as follows.")#linebreak()#text(" ")#emph[#linebreak()#text(" Suppose we know only that ")#tao-math("\\left|\\frac{d^k\\phi(x)}{dx^k}\\right|\\geq 1", block: false)#text(" for some fixed ")#mi("k")#text(", and we wish to obtain an estimate for ")#mi("I(\\lambda) =  \\int_a^be^{i\\lambda\\phi(x)}\\; dx")#text(" that is independent of ")#mi("a")#text(" and ")#mi("b")#text(". ")#strong[#text("The change of variable ")#mi("x\\mapsto \\lambda^{-1/k}x^{\\prime}")#text(" shows")]#text(" that the only possible estimate for the integral is ")#mi("O(\\lambda^{-1/k})")#text(".")#linebreak()#text(" ")]

#text("So “The change of variable ")#mi("x\\mapsto \\lambda^{-1/k}x^{\\prime}")#text("” above should be really understood as the change of variable ")#mi("x\\mapsto \\lambda_0^{-1/k}x^{\\prime}")#text(" where ")#mi("\\lambda_0")#text(" is the scaling parameter, which has nothing to do with the argument ")#mi("\\lambda")#text(" in ")#mi("I(\\lambda)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("One can run the scaling argument with ")#mi("\\lambda_0=\\lambda")#text(" if desired (this amounts to “spending” the scale invariance to normalise ")#mi("\\lambda=1")#text("). If one rescales ")#mi("x =\\lambda^{-1/k} x^{\\prime}")#text(", then the estimate ")#mi("\\int_a^b e^{i\\lambda \\phi(x)}\\ dx \\lesssim_k \\lambda^\\beta")#text(" becomes ")#mi("\\int_{a^{\\prime}}^{b^{\\prime}} e^{i\\phi^{\\prime}(x^{\\prime})}\\ dx^{\\prime} \\lesssim_k \\lambda^{\\beta+1/k}")#text(", where ")#mi("a^{\\prime} := \\lambda^{1/k} a")#text(", ")#mi("b^{\\prime} := \\lambda^{1/k} b")#text(", and ")#mi("\\phi^{\\prime}(x^{\\prime}) := \\lambda \\phi(\\lambda^{-1/k} x^{\\prime})")#text(". The rescaled data ")#mi("a^{\\prime},b^{\\prime},\\phi^{\\prime}")#text(" range in exactly the same class as the original data ")#mi("a,b,\\phi")#text(". Fixing a single ")#mi("a^{\\prime},b^{\\prime},\\phi^{\\prime}")#text(" in this class for which the integral ")#mi("\\int_{a^{\\prime}}^{b^{\\prime}} e^{i\\phi^{\\prime}(x^{\\prime})}\\ dx^{\\prime}")#text(" does not vanish, and sending ")#mi("\\lambda")#text(" to either zero or infinity, one recovers the scaling condition ")#mi("\\beta = -1/k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551878")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("In the dispersive estimate in Tomas-Stein theorem, we use Exercise 12 (stationary phase for ")#mi("S^{d-1}")#text(") to conclude the decay of the convolution kernel ")#tao-math("K_{x_d}(x^{\\prime}) \\lesssim \\left|x_d\\right|^{-(d-1)/2}", block: false)#text(". But the exercise 12 requires the parameter ")#tao-math("\\left|x\\right| \\ge 1", block: false)#text(" since in stationary phase we are interested in when the parameter tends to infinity. What about when ")#mi("x_d")#text(" or ")#mi("(x^{\\prime},x_d)")#text(" is relatively small, say close to 0? In this case, doesn’t the error term ")#tao-math("\\left|x\\right|^{-d/2}", block: false)#text(" overtakes the main term? How do we bound ")#tao-math("K_{x_d}(x^{\\prime}) \\lesssim \\left|x_d\\right|^{-(d-1)/2}", block: false)#text(" in this case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("We have ")#mi("K_{x_d}(x^{\\prime}) = O(1)")#text(" from the triangle inequality, so the case ")#tao-math("\\left|x_d\\right| \\leq 1", block: false)#text(" is trivial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551914")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("I am aware of the standard way to establish the general Strichartz estimate: one first write the solution to the linear Schrodinger equation as convolution of initial data with the fundamental solution ")#mi("K_t")#text(". Then by triangle inequality, we have a dispersive estimate ")#tao-math("\\left\\|u\\right\\|_{L^\\infty} <= \\left|t\\right|^{-(d-1)/2} \\left|\\left|f\\right|\\right|_{L^1}", block: false)#text(". By interpolating between ")#mi("(1,\\infty)")#text(" and ")#mi("(2,2)")#text(" we have a general dispersive estimate for ")#mi("(p,p^{\\prime})")#text(". Then one uses ")#mi("TT^*")#text(", the general dispersive estimate for ")#mi("(p,p^{\\prime})")#text(", and then finally Hardy-Littlewood-Sobolev. This string of argument is almost identical to the argument to prove endpoint Tomas-Stein for ")#mi("S^{d-1}")#text(" / paraboloid. So I would expect to conclude the general Strichartz estimate directly from the L^2 restriction theorem for the paraboloid. But it seems to me that the L^2 restriction estimate is only good enough to conclude the estimate in (ii), where ")#mi("q = r = \\frac{2(d+1)}{d-1}")#text(". By Marcinkiewicz interpolation on the sublinear operator that maps f to ")#tao-math("\\left\\|u_{x_d}\\right\\|_r", block: false)#text(" between ")#mi("q = r = \\frac{2(d+1)}{d-1}")#text(" and ")#mi("(q,r) = (\\infty, 2)")#text(" (the L^2 conversation law), I could get a line segment between the two, but I there is still a line segment between ")#mi("2 < q <  \\frac{2(d+1)}{d-1}")#text(" that I could not touch. Am I missing anything or do you intend for us to do the standard argument I describe above?")

#text("Also, because their argument is so similar, can one conclude L^2 restriction estimate for the paraboloid from the general Strichartz estimate / are they equivalent?")

#text("Typo: In Exercise 5 definition of ")#mi("C_p")#text(", sup should be over all ")#mi("x_i")#text(" that square sum to 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("The full range of mixed-norm Strichartz estimates are not directly obtainable from the pure-norm restriction theorem and interpolation, but can be proven by essentially the same method, as you indicated.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2591b48e4f346c9b6d76a6fe80a61a0a76668f1f03e17dadceea9e5799317a2b-a337237f65c623e3b812ba838ce421701824f99025fd57fd90866bb6c78f7363.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-551997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Dear Prof. Tao,")

#text("Isn’t it ")#mi("\\delta^{2(\\frac{2d}{p^{\\prime}}-d+1)}")#text(" instead of ")#mi("\\delta^{2(\\frac{d}{p^{\\prime}}-d+1)}")#text(" in the display (17)? It seems to me that the factor ")#mi("\\delta^{2(\\frac{2d}{p^{\\prime}})}")#text(" comes from the dilation by ")#mi("\\delta^2")#text(" in ")#mi("L^{p^{\\prime}/2}(\\bf{R}^d)")#text(".")

#text("And, “sidelenth” -> “sidelength” in the second line below the display (33).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552246")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Just after (38), should’nt the definition of {A_{i,R}} be with {|\\xi – e_i| \\leq c} instead of {|\\xi – e_i| \\leq c + 1/R} ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("The artificial additional factor of ")#mi("1/R")#text(" is technically convenient, as it creates a suitable “margin” of room between ")#mi("A_{i,R}")#text(" and ")#mi("A_{i,\\sqrt{R}}")#text(" that is useful for later induction on scale arguments (where one smoothly cuts off in physical space a function with Fourier support in ")#mi("A_{i,R}")#text(", but still wants the resulting function to have Fourier support in ")#mi("A_{i,\\sqrt{R}}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("I tried to interpolate ")#mi("L^2")#text(" and ")#mi("L^\\infty")#text(" to get the ")#mi("L^{q/2}")#text(" norm to get equation (26) using complex interpolation for linear operators, but couldn’t get the ")#mi("g_1")#text(" and ")#mi("g_2")#text(" norms specified on the right. I got ")#tao-math("\\left|\\left|g_1\\right|\\right|_{L^2}^{4/q}", block: false)#text(". Does bilinear interpolation works differently?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Looks like you must have made some sort of error in your calculations, as the left-hand side of (26) scales linearly with ")#mi("g_1")#text(" whereas ")#tao-math("\\left\\|g_1\\right\\|_{L^2}^{4/q}", block: false)#text(" does not. With bilinear complex interpolation one has to vary both ")#mi("g_1")#text(" and ")#mi("g_2")#text(" simultaneously in a holomorphic fashion; fixing (say) ")#mi("g_1")#text(" and only varying ")#mi("g_2")#text(" only works if the exponent for ")#mi("g_1")#text(" is held constant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("3 lines below exercise 24 writes ")#mi("1/(q/2)^{\\prime} = 1-2/q")#text(". Do you mean $ latex 1/(q/2)’=(1/(q/2))’=(2/q)’ $?")

#emph[#text("[No – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552373")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("The claim 1/(q/2)’=(1/(q/2))’ is false. Take q=6 to find that the LHS equals 2/3 while the RHS equals a negative number, -1/2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Of course, silly error.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 2: Decoupling theory | What's new")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552341")[#strong[#text("247B, Notes 2: Decoupling theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("[…] square root cancellation heuristic, briefly mentioned in the preceding set of notes, predicts that if a collection of complex numbers have phases that are sufficiently […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552345")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("In the line preceding the display after the definition fo the tube, there is a missing block of text after “and note that”")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552375")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Is the reasoning in “Applying (26) and noting that …” correct? There seem to be some issues: there is a (q/2)’ power in the preceding display, and (26) involves powers of |I|, which is not present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("The power of ")#mi("I")#text(" becomes the ")#mi("2^{2k/q}")#text(" factor since ")#tao-math("\\left|I\\right| = 2^{-k}", block: false)#text(", and the ")#mi("(q/2)^{\\prime}")#text(" power is counteracted by the ")#mi("L^{(q/2)^{\\prime}}")#text(" norm on the RHS of (26). I’ve added an additional line of computation to emphasise this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552392")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Ah, of course.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shapiro")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552412")[#strong[#text("Shapiro")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’m not affiliated to UCLA, nevertheless I watched your zoom session yesterday. At the begining you said you were recording the sessions. Will you upload the videos somewhere and sometime? In Europe your course is scheduled at ~ midnight so it is very challenging to follow it.")#linebreak()#text(" Best wishes,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Unfortunately, due to UCLA privacy policies, the video for these lectures is only available to UCLA students enrolled in the class.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Sorry for the off-topic comment:")

#text("I am curious about what the UCLA privacy policies actually say about this. (What kind of privacies is it protecting while it is already open to the public when the class is being lectured?)")

#text("IAS has many of the recent Zoom talks available on YouTube; but the Zomminar seems not to be open to the public (password needed) while it was being recorded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552553")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("UCLA’s policy may be found at ")#link("https://www.adminvc.ucla.edu/covid-19/academic-continuity/protecting-privacy-and-data-during-remote-working-and-using-zoom")[#text("https://www.adminvc.ucla.edu/covid-19/academic-continuity/protecting-privacy-and-data-during-remote-working-and-using-zoom")]#text(" . The most relevant item is C.2: “Recordings should be retained no longer than necessary and should only be retained on approved University devices, platforms or networks.” (In this case, the approved platform is CCLE, ")#link("https://ccle.ucla.edu/")[#text("https://ccle.ucla.edu/")]#text(" , which restricts course content such as recorded video to enrolled students.) Research seminars (like those given at the IAS) are more of a grey area, but they are officially classified as courses by UCLA, and the supplemental guidance we were given was that due to the participation in those seminars by UCLA graduate and undergraduate students who have not explicitly opted in to be recorded, they are also subject to the same restrictions on recordings as traditional courses.")

#text("Of course, it is not technically possible to completely prevent any online talk from being recorded in one fashion or another, but I am not able to officially endorse or encourage such recordings for my class.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shapiro")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552533")[#strong[#text("Shapiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Thank you for the answer!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/148ec9b54386ea15af9c351562fb5f15aa810f733954a9a8fdea69872db562b4-ba74c00d1c29a6e2b801b8b4c5d189b19a274d4f05a781163de6b034f3daac09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("from the course page ")#link("https://ccle.ucla.edu/mod/page/view.php?id=2840550")[#text("https://ccle.ucla.edu/mod/page/view.php?id=2840550")]#text(" he says basically no, unless you are a UCLA student. I have a private recording that I won’t share since it seems that Prof. Tao or at least UCLA wouldn’t want them available (because for me the class starts at 5AM). Perhaps you can set up a recording at midnight?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("How do you set up a private recording?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/comment-page-1/#comment-552496")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("I’m getting an error message in the section about the Knapp example here:")

#text("“If we set {\\varphi} to be non-negative and not identically zero, and factor out the constant phase {e^{2\\pi i x \\cdot \\omega_0} from the integral in (16), we conclude that ”")

#text("where the constant phase is replaced with “Formula does not parse”. Is there a missing bracket?")
]
