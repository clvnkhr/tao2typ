// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/
// Converted to Typst by tao2typ: "2026-10-14T16:35:58.590001+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random Martingales and localization of maximal inequalities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random Martingales and localization of maximal inequalities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/")[#text("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.cims.nyu.edu/~naor/")[#text("Assaf Naor")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0912.1140")[#text("Random Martingales and localization of maximal inequalities")]#text("“, to be submitted shortly. This paper investigates the best constant in generalisations of the classical ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_function")[#text("Hardy-Littlewood maximal inequality")]#text(" ")#metadata(none) <tao-50b8d2c3973594d74271>



#text("for any absolutely integrable ")#mi("{f: {\\mathbb R}^n \\rightarrow {\\mathbb R}}")#text(", where ")#mi("{B(x,r)}")#text(" is the Euclidean ball of radius ")#mi("{r}")#text(" centred at ")#mi("{x}")#text(", and ")#tao-math("{\\left|E\\right|}", block: false)#text(" denotes the Lebesgue measure of a subset ")#mi("{E}")#text(" of ")#mi("{{\\mathbb R}^n}")#text(". This inequality is fundamental to a large part of real-variable harmonic analysis, and in particular to ")#emph[#text("Calderón-Zygmund theory")]#text(". A similar inequality in fact holds with the Euclidean norm replaced by any other convex norm on ")#mi("{{\\mathbb R}^n}")#text(".")

#text("The exact value of the constant ")#mi("{C_n}")#text(" is only known in ")#mi("{n=1}")#text(", with a remarkable ")#link("http://www.ams.org/mathscinet-getitem?mr=1973058")[#text("result of Melas")]#text(" establishing that ")#mi("{C_1 = \\frac{11+\\sqrt{61}}{12}}")#text(". Classical covering lemma arguments give the exponential upper bound ")#mi("{C_n \\leq 2^n}")#text(" when properly optimised (a direct application of the ")#link("http://en.wikipedia.org/wiki/Vitali_covering_lemma")[#text("Vitali covering lemma")]#text(" gives ")#mi("{C_n \\leq 5^n}")#text(", but one can reduce ")#mi("{5}")#text(" to ")#mi("{2}")#text(" by being careful). In an important ")#link("http://www.ams.org/mathscinet-getitem?mr=727348")[#text("paper of Stein and Strömberg")]#text(", the improved bound ")#mi("{C_n = O( n \\log n )}")#text(" was obtained for any convex norm by a more intricate covering norm argument, and the slight improvement ")#mi("{C_n = O(n)}")#text(" obtained in the Euclidean case by another argument more adapted to the Euclidean setting that relied on heat kernels. In the other direction, a recent ")#link("http://arxiv.org/abs/0805.1565")[#text("result of Aldaz")]#text(" shows that ")#mi("{C_n \\rightarrow \\infty}")#text(" in the case of the ")#mi("{\\ell^\\infty}")#text(" norm, and in fact in an even more recent ")#link("http://arxiv.org/abs/0902.4305")[#text("preprint of Aubrun")]#text(", the lower bound ")#mi("{C_n \\gg_\\epsilon \\log^{1-\\epsilon} n}")#text(" for any ")#mi("{\\epsilon > 0}")#text(" has been obtained in this case. However, these lower bounds do not apply in the Euclidean case, and one may still conjecture that ")#mi("{C_n}")#text(" is in fact uniformly bounded in this case.")

#text("Unfortunately, we do not make direct progress on these problems here. However, we do show that the Stein-Strömberg bound ")#mi("{C_n = O(n \\log n)}")#text(" is extremely general, applying to a wide class of metric measure spaces obeying a certain “microdoubling condition at dimension ")#mi("{n}")#text("“; and conversely, in such level of generality, it is essentially the best estimate possible, even with additional metric measure hypotheses on the space. Thus, if one wants to improve this bound for a specific maximal inequality, one has to use specific properties of the geometry (such as the connections between Euclidean balls and heat kernels). Furthermore, in the general setting of metric measure spaces, one has a general ")#emph[#text("localisation principle")]#text(", which roughly speaking asserts that in order to prove a maximal inequality over all scales ")#mi("{r \\in (0,+\\infty)}")#text(", it suffices to prove such an inequality in a smaller range ")#mi("{r \\in [R, nR]}")#text(" uniformly in ")#mi("{R>0}")#text(". It is this localisation which ultimately explains the significance of the ")#mi("{n \\log n}")#text(" growth in the Stein-Strömberg result (there are ")#mi("{O(n \\log n)}")#text(" essentially distinct scales in any range ")#mi("{[R,nR]}")#text("). It also shows that if one restricts the radii ")#mi("{r}")#text(" to a lacunary range (such as powers of ")#mi("{2}")#text("), the best constant improvees to ")#mi("{O(\\log n)}")#text("; if one restricts the radii to an even sparser range such as powers of ")#mi("{n}")#text(", the best constant becomes ")#mi("{O(1)}")#text(".")

#metadata(none) <tao-880554f0e8214a88af07>

#text("The method of proof is a little unusual from a harmonic analysis perspective, though it is now quite standard in computer science and metric space geometry. The main idea is to try to convert the underlying metric to an ")#link("http://en.wikipedia.org/wiki/Ultrametric_space")[#text("ultrametric")]#text(", such as those arising from dyadic models of Euclidean space (e.g. from infinite binary trees). The reason for this is that maximal inequalities are easy to prove for ultrametrics, indeed the Hardy-Littlewood inequality is always true in such settings with constant ")#mi("{C=1}")#text(". A key reason for this is the following nesting property: in an ultrametric space, if two balls ")#mi("{B(x,r)}")#text(", ")#mi("{B(x,r^{\\prime})}")#text(" intersect, then the larger ball in fact contains the smaller ball. Because of this, the Hardy-Littlewood maximal inequality becomes essentially trivial, as can be seen by considering maximal balls ")#mi("{B(x,r)}")#text(" in which the function ")#mi("{f}")#text(" has mean at least ")#mi("{\\lambda}")#text(", which are disjoint by the ultrametric property.")

#text("Now, a direct application of this idea to such metric as the Euclidean metric gives losses that are exponential in the dimension, mainly because one has to triple (resp. double) the size of a ball ")#mi("{B(x,r)}")#text(" before it will capture all the balls ")#mi("{B(x^{\\prime},r^{\\prime})}")#text(" of lesser radius that intersect it (resp. contain the centre ")#mi("{x}")#text(" of the original ball). Indeed, this is morally speaking where the Vitali covering lemma bound ")#mi("{C_n \\leq 2^n}")#text(" comes from. The standard way to say this is that the ")#emph[#text("doubling constant")]#text(" ")#tao-math("{\\sup_{x,r} \\left|B(x,2r)\\right|/\\left|B(x,r)\\right|}", block: false)#text(" of the Euclidean metric is exponentially large (indeed, it is ")#mi("{2^n}")#text("), and indeed it is easy to construct examples of metric measure spaces where the best constant in the Hardy-Littlewood inequality is as large as the doubling constant. (The canonical example here is the ")#link("http://en.wikipedia.org/wiki/Star_(graph_theory)")[#text("star graph")]#text(" with the ")#link("http://en.wikipedia.org/wiki/Graph_metric")[#text("graph metric")]#text(" and counting measure, where the doubling constant and maximal constant are both essentially the degree of the star.)")

#text("But suppose that if instead of trying to capture all balls of lesser radius, one only wanted to capture all balls ")#mi("{B(x^{\\prime},r^{\\prime})}")#text(" intersecting a given ball of ")#emph[#text("much")]#text(" smaller radius, and in particular if ")#mi("{r^{\\prime} \\leq r/n}")#text(". Then one only needs to enlarge the original ball ")#mi("{B(x,r)}")#text(" by a factor of ")#mi("{1+2/n}")#text(" to achieve this, and this only increases the volume by ")#mi("{(1+2/n)^n \\approx e^2 = O(1)}")#text(". Thus we see that the Euclidean metric behaves “like an ultrametric” so long as one can somehow separate scales by a ratio of ")#mi("{n}")#text(" or more. (This observation has also turned out to be crucial for efficient estimates in modern additive combinatorics, resulting in a technique of scale separation for balls (or related objects such as Bohr sets) that is sometimes informally referred to as “Bourgainisation” due to the ")#link("http://www.ams.org/mathscinet-getitem?mr=2403433")[#text("breakthrough work of Bourgain")]#text(" on Roth’s theorem, which introduced the technique.) This is the intuition behind the localisation result.")

#text("How can one formalise this intuition? To avoid some annoying technical issues it is convenient to work on the unit torus ")#mi("{({\\mathbb R}/{\\mathbb Z})^n}")#text(" (with the induced Euclidean metric) rather than the Euclidean space ")#mi("{{\\mathbb R}^n}")#text("; note that a simple scaling argument shows that the maximal inequality constants for the former control those of the latter.")

#text("Let us impose a random ")#mi("{n}")#text("-ary mesh on the torus by identifying the torus with a randomly translated copy of the unit cube ")#mi("{[0,1]^n}")#text(", then partitioning this cube into ")#mi("{n^n}")#text(" subcubes of length ")#mi("{n^{-1}}")#text(", each of which is partitioned further into ")#mi("{n^n}")#text(" subcubes of length ")#mi("{n^{-2}}")#text(", and so forth.")

#text("This mesh induces an ultrametric on the torus, with the distance between two distinct points ")#mi("{x, y}")#text(" defined as ")#mi("{n^{-j}}")#text(" where ")#mi("{n^{-j}}")#text(" is the length of the minimal cube in the mesh that contains both ")#mi("{x}")#text(" and ")#mi("{y}")#text("; this is basically the ultrametric coming from viewing the mesh as an infinite ")#mi("{n^n}")#text("-ary tree. However, this ultrametric is not particularly close to the Euclidean metric; in particular, two points close to, but on opposite sides, of a cube in the mesh will be close in the Euclidean metric but far apart in the ultrametric.")

#text("But one can avoid this issue by the standard trick of ")#emph[#text("padding")]#text(" the mesh. Suppose one takes every cube in the mesh and shrinks it by a factor of ")#mi("{1/n}")#text(", thus decreasing the volume by ")#mi("{(1-1/n)^n \\approx 1/e \\sim 1}")#text("; call this the ")#emph[#text("padded")]#text(" cube at this scale. Note from the random nature of the mesh construction that every point has a constant probability of lying in the padded cube at a fixed scale; in particular, by Fubini’s theorem (aka the first moment method), given a measurable set ")#mi("{E}")#text(" in the torus, the padded cubes at a fixed scale will capture a constant fraction of ")#mi("{E}")#text(". It is because of this that we can afford to restrict the maximal function to padded cubes without significantly losing control of the constants (let me be a bit vague here about exactly how one does this).")

#text("The key point is that inside a padded cube of sidelength ")#mi("{R}")#text(", any ball of radius ")#mi("{R/n}")#text(" or less intersecting this padded cube, will not intersect any other padded cube at this scale. Thus, balls at this scale or less behave somewhat as if the Euclidean metric was an ultrametric, and this turns out to be enough to achieve localisation.")

#text("This argument turns out to be extremely general, and applies to any metric measure space ")#mi("{(X,d,\\mu)}")#text(" (i.e. a metric space with a Radon measure) for which one has the ")#emph[#text("microdoubling condition")]#text(" ")#mi("{\\mu(B(x,(1+\\frac{1}{n})r)) = O( \\mu(x,r))}")#text(". In particular, this applies to ")#emph[#text("Alhfors-David regular spaces")]#text(" in which ")#mi("{\\mu(B(x,r))}")#text(" is comparable to ")#mi("{\\omega_n r^n}")#text(" for some constant ")#mi("{\\omega_n > 0}")#text(". Instead of using cubes to create the mesh, it turns out that one can just use randomly placed balls whose radii are essentially powers of ")#mi("{n}")#text(" to achieve a much stranger looking, but functionally comparable, mesh.")

#text("Because of microdoubling, one can assume without loss of generality that all radii are powers of ")#mi("{(1+\\frac{1}{n})}")#text(", since one can round off to the nearest such power without much loss. There are only ")#mi("{O(n \\log n)}")#text(" such powers in any range ")#mi("{[R,nR]}")#text(", which thus gives the Stein-Strömberg result in the general microdoubling setting. (We also give an alternate proof of this result, adapting a slightly different probabilistic ")#link("http://www.ams.org/mathscinet-getitem?mr=1865397")[#text("argument of Lindenstrauss")]#text(".)")

#text("On the other hand, one can concoct microdoubling spaces in which the balls of radius ")#mi("{(1+\\frac{1}{n})^j}")#text(" for ")#mi("{j = O(n \\log n)}")#text(" are genuinely “different”, so much so that the best constant in the maximal inequality is ")#mi("{\\gg n \\log n}")#text(", even if one makes reasonable assumptions such as translation-invariance (assuming an abelian group structure on the space), Ahlfors-David regularity, and ")#mi("{L^p}")#text(" bounds (the maximal operator is bounded on ")#mi("{L^p}")#text(" for every ")#mi("{p>1}")#text("). The basic counterexample here is constructed by working in a finite field vector space with counting measure and creating a rather unusual (but still Ahlfors-David regular) metric which, for each ")#mi("{j}")#text(", distributes a large portion of the mass of the ball of radius ")#mi("{(1+\\frac{1}{n})^j}")#text(" centred at the origin to a different subspace of the vector space. This essentially converts the Hardy-Littlewood maximal function to a maximal function over averages of unrelated subspaces, which one can show to be large by straightforward computations.")

#text("Finally, we give an example of a natural space without any microdoubling properties whatsoever for which one still has a maximal inequality, namely the free non-abelian group on a bounded number of generators. Here one can rely instead on the expander (or isoperimetric) properties of the Cayley graph. This suggests to us that one should have a Hardy-Littlewood maximal inequality for measure-preserving actions of the free group on a probability space, but unfortunately the standard transference technology for doing this does not apply because the free group is highly non-amenable. This question therefore remains open (although ")#mi("{L^p}")#text(" bounds were previously established by ")#link("http://www.ams.org/mathscinet-getitem?mr=1294672")[#text("Nevo and Stein")]#text(").")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84be0185f70b82d3e9c9250bce1d174ff91adf30e636737df3ae6250419ce1a6-8afbf902862335ec3420ea6fedb9ac0029c191dd77658426af59c2cfbc5e15f7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave G")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42733")[#strong[#text("Dave G")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("I think a word (maybe “holds”?) is missing from the final sentence of the first paragraph. “A similar inequality in fact with the Euclidean norm…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21ed7448495a0cdb8fa383596a2755216a1d734dd923e587e5b5e9c26947c800-07ecfcf90d3780fca6a3ce5771c7664998a887868f314731c5baee0156402902.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ioannis parissis")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42736")[#strong[#text("ioannis parissis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("First of all this is a very interesting article, and I can’t claim to understand it in the depth that it goes. I will stick to the Euclidean world:")

#text("– It is my impression that in order to improve the known bounds in the Euclidean case (or in the ")#mi("\\ell^\\infty")#text("-case), one has to “address all scales at the same time”. The Stein-Strömberg proof (via the covering lemma) as well as the Lindenstrauss lemma approach, use the localization principle you explain here and get the final ")#mi("O(n\\log n)")#text(" bound by counting how many distinct scales there are. Another, more naive, way to put it is that everything happens for radii that are between powers of ")#mi("n")#text(" and powers of ")#mi("n^\\frac{1}{n \\log n}")#text(" as you mention in your notes for the Lindenstrauss Lemma. Any sparser set of radii gives ")#mi("O(1)")#text(" constants and any denser set than powers of ")#mi("n^\\frac{1}{n\\log n}")#text(" is already the unrestricted maximal function (up to absolute constants). This has already been observed by ")#strike[#link("http://www.springerlink.com/content/u840r7q070186v0r/")[#text("Soria and Menarguez")]]#text(" (corrected link ")#link("http://www.collectanea.ub.edu/index.php/Collectanea/article/view/3780/4458")[#text("here")]#text(") to do them justice. Between these two endpoints, there are essentially ")#mi("O(n\\log n)")#text(" scales. Philosophically speaking, this approach cannot ever give us anything better that ")#mi("O(n\\log n)")#text(". Contrast that to the Euclidean case; the comparison with the heat kernel does not use this localization, but rather the Euclidean symmetry for all scales at the same time (and it is enough to do that for ")#mi("n")#text(" large enough).")

#text("– Aiming somewhere in the middle, it would be interesting to understand if the ")#mi("O(\\log n)")#text(" bound for (say) lacunary radii ")#mi("2^k,\\ k\\in \\mathbb Z")#text(", is best possible. We get this bound, again, as a consequence of the localization principle. But I don’t know of a direct approach to this, meaning an approach that’s specific to this scale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Thanks for the Soria-Menarguez reference (though it appears that their Collectanea paper is more relevant here than the one you linked, which is mostly concerned with the 1D case). Yes, the localisation principle formalises the gap between powers of ")#mi("n")#text(" (where everything is understood) and powers of ")#mi("n^{1/n \\log n}")#text(" (which is essentially the full case) by saying that we can reduce to just the ")#mi("n \\log n")#text(" scales between, say, 1 and n. At this point, it seems that one cannot get any further just from the triangle inequality, and must now use something special about the underlying metric structure.")

#text("It was also pointed out to us that we neglected to mention some closely related work of Stromberg, Rochberg-Taibleson, and Cowling-Meda-Setti on the free group and on hyperbolic space (we had already intended to cite these papers, but somehow things got lost in the process). The next revision of the paper will address these issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21ed7448495a0cdb8fa383596a2755216a1d734dd923e587e5b5e9c26947c800-07ecfcf90d3780fca6a3ce5771c7664998a887868f314731c5baee0156402902.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ioannis parissis")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42750")[#strong[#text("ioannis parissis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("You are absolutely right. I linked the wrong paper so feel free to edit my comment with the correct link (the collectanea paper is freely available ")#link("http://www.collectanea.ub.edu/index.php/Collectanea/article/view/3780/4458")[#text("here")]#text(" as far as I can tell).")

#emph[#text("[OK, fixed. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514c9d2fec4118dc92fb137fc85aa3e6873b3a4ebd44055bfa34d4f9cf0fb6cd-a51c14f3bd738f3fd312256ea6147aeadede1fd214dad6adbd41fd93bf2bd2a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42772")[#strong[#text("CJ")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("Some formulas in this post aren’t showing up, like in a previous posting of yours. For example, whatever formula defining C_n in the first few sentences doesn’t show up. (I’m running firefox on OS 10.4, if that matters.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c23fddc6998ce0ec65a3cf62b2ad3ab144990071004bc3a676561d1fdcf0be7-bf9ee5fb646bad1459880c423ac08ab3ac8278241dbcba3e552db49f6c44053c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-457785")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("That main formula again doesn’t show up.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21ed7448495a0cdb8fa383596a2755216a1d734dd923e587e5b5e9c26947c800-07ecfcf90d3780fca6a3ce5771c7664998a887868f314731c5baee0156402902.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ioannis parissis")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-42784")[#strong[#text("ioannis parissis")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("Not very important but for the sake of accuracy: on page 4, line 23 of the article […] it was necessary to exploit the relationship between averaging on balls and the Poisson semi-group […] ; i think you mean the Heat semi-group.")

#text("à propos: I haven’t actually checked whether we can we use the Poisson semi-group instead here. In the Bourgain/Carberry strong ")#mi("L^p")#text(" result, the Poisson semi-group is used instead and seems to be more appropriate. I also haven’t checked (maybe a naive comment, but an obvious one) whether an improvement on the weak (1,1) bound can be achieved for the ")#mi("\\ell^\\infty")#text(" metric by comparing to a suitable semi-group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-47647")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] to a result of Stein and Strömberg, but it is not known if is bounded in or grows as . See this blog post for some further discussion. Exercise 19 (Dyadic maximal inequality) If is an absolutely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-193644")[#strong[#text("A Few Mathematical Snapshots from India (ICM2010) | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2012")]

#text("[…] by Hardy and Littlewood depending on the dimension. Here is a related paper by Naor and Tao and a related post on “what’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Failure of the L^1 pointwise and maximal ergodic theorems for the free group | What's new")]], [#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/#comment-455950")[#strong[#text("Failure of the L^1 pointwise and maximal ergodic theorems for the free group | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2015")])]

#text("[…] this for the Cesáro averages , but not for itself. About six years ago, Assaf Naor and I tried our hand at this problem, and was able to show an associated maximal inequality on , but due to the non-amenability of , […]")
]
