// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-18T11:27:32.419439+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "How to Formalize All of Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("How to Formalize All of Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Jeremy Avigad, Kevin Buzzard, Johan Commelin, Rémy Degenne, Kim Morrison, Oliver Nash and Adam Topaz have written a ")#link("https://xenaproject.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")[#text("blog post over on Kevin Buzzard’s blog entitled “How to Formalize All of Mathematics”")]#text(", regarding recent proposals to automatically formalize the entirety of the mathematical literature. The issues regarding formal mathematics are parallel to those regarding informal mathematics, in particular the tradeoff between speed, scale, and understanding when one prioritizes the production of output over all other desiderata, and the blog post is largely focused on this tradeoff.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698194")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("We are not robots, and empty formalism ≠ understanding. Truly great mathematics is a living art. Who cares about a proof without any insight?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698233")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("This misses the point of formalization. Who cares about a “proof” which isn’t a proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698259")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("A proof being rigorous is necessary (otherwise it’s not a proof), but it’s not sufficient (because we need ideas, not just rigorous arguments that merely certify something is true without explaining anything at all). It’s the best of both worlds that we need.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698266")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Ideas are present all around us and come from many different sources. To have good ideas (i.e. those which produce more insightful results which improve our understanding), we certainly also need correct proofs. We need to know that we can simply trust the content of a paper without having to second-guess if there isn’t a subtle mistake in it or not.")

#text("It is not wise for us to continually miss the point of formalization. While there is much beauty and usefulness in math, we are also in the business of producing correct results and we should not forget that it took much strife before we could reach a level where this is possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698265")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Many people care about a proof which isn’t a proof, see, for example, studies on Euclid’s ")#emph[#text("Elements")]#text(", which contains many non-rigorous proofs, but anyways all the theorems are correct.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-f29ed3b3a1d56c4929e33b73a529a979f0114bfddd62e6d8e8222d804e330b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698252")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Formal proof verification systems – specifically Lean – strike me as the foundation that AI’s progress in Mathematics is built upon. Once we’ve accepted Lean as valid (any formal proof verifier would do), feeding it the output of Monkeys tapping away at keyboards will eventually find a proof for any theorem that has a formal proof in Lean. As with the appearance of Hamlet in random output, the problem is the time it will take. The more we teach the monkeys to bias toward the plausibly Shakespearean, the sooner Hamlet pops out. (In single-mindedly seeking Hamlet, we’ll also have thrown away tons of original plays that Shakespeare could have written, many far better than Hamlet – although we may not agree on which ones those are.)")

#text("What’s unexpected (at least to someone who studied Computer Science in the ’90s) is that progress in automated theorem proving has been glacial and I, at least, thought The Great Mechanical Math Library was decades away. Instead, massive AGI chatbot systems are able to discover proofs before we’ve developed more focused tools – what did we miss?")
]
