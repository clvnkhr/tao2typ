// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-22T12:07:54.505489+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "How to Formalize All of Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("How to Formalize All of Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-22 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Jeremy Avigad, Kevin Buzzard, Johan Commelin, Rémy Degenne, Kim Morrison, Oliver Nash and Adam Topaz have written a ")#link("https://xenaproject.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/")[#text("blog post over on Kevin Buzzard’s blog entitled “How to Formalize All of Mathematics”")]#text(", regarding recent proposals to automatically formalize the entirety of the mathematical literature. The issues regarding formal mathematics are parallel to those regarding informal mathematics, in particular the tradeoff between speed, scale, and understanding when one prioritizes the production of output over all other desiderata, and the blog post is largely focused on this tradeoff.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698194")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("We are not robots, and empty formalism ≠ understanding. Truly great mathematics is a living art. Who cares about a proof without any insight?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698233")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("This misses the point of formalization. Who cares about a “proof” which isn’t a proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698259")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("A proof being rigorous is necessary (otherwise it’s not a proof), but it’s not sufficient (because we need ideas, not just rigorous arguments that merely certify something is true without explaining anything at all). It’s the best of both worlds that we need.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698266")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Ideas are present all around us and come from many different sources. To have good ideas (i.e. those which produce more insightful results which improve our understanding), we certainly also need correct proofs. We need to know that we can simply trust the content of a paper without having to second-guess if there isn’t a subtle mistake in it or not.")

#text("It is not wise for us to continually miss the point of formalization. While there is much beauty and usefulness in math, we are also in the business of producing correct results and we should not forget that it took much strife before we could reach a level where this is possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698265")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Many people care about a proof which isn’t a proof, see, for example, studies on Euclid’s ")#emph[#text("Elements")]#text(", which contains many non-rigorous proofs, but anyways all the theorems are correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698531")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Replying to “Who cares about a “proof” which isn’t a proof?”:")

#text("Avi Wigderson, from the Institute for Advanced Study, has a lecture titled “The Value of Error in Proofs”. It’s available at Vimeo: ")#link("https://vimeo.com/608634903")[#text("https://vimeo.com/608634903")]

#text("Also, please remember that a very famous flawed proof by Henri Poincaré ended giving birth to chaos theory: L. E. Phragmén found a critical gap in Poincaré’s proof, who then tried to correct the proof and ended up discovering the concept of chaos!")

#text("Errors/mistakes are very important in mathematics. There are many more examples.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698588")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Sure but you wouldn’t use this as justification for allowing papers full of errors to be published, right?")

#text("Also, I think that there is a difference between a technical error (which is often what happens and can destroy specific proofs) and conceptual errors (which often use a black-box that needs further theory). The latter are usually “valuable” insofar as people notice them & use them to create new research directions. The former actually impede progress to some degree.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-f29ed3b3a1d56c4929e33b73a529a979f0114bfddd62e6d8e8222d804e330b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698252")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Formal proof verification systems – specifically Lean – strike me as the foundation that AI’s progress in Mathematics is built upon. Once we’ve accepted Lean as valid (any formal proof verifier would do), feeding it the output of Monkeys tapping away at keyboards will eventually find a proof for any theorem that has a formal proof in Lean. As with the appearance of Hamlet in random output, the problem is the time it will take. The more we teach the monkeys to bias toward the plausibly Shakespearean, the sooner Hamlet pops out. (In single-mindedly seeking Hamlet, we’ll also have thrown away tons of original plays that Shakespeare could have written, many far better than Hamlet – although we may not agree on which ones those are.)")

#text("What’s unexpected (at least to someone who studied Computer Science in the ’90s) is that progress in automated theorem proving has been glacial and I, at least, thought The Great Mechanical Math Library was decades away. Instead, massive AGI chatbot systems are able to discover proofs before we’ve developed more focused tools – what did we miss?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698277")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("I respect the idea of formalizing math through proof verification, but I feel like on the whole math is going in the wrong direction now. It seems more about generating results or going into deeper levels of complexity rather than appreciating its beauty through communication.")

#text("The dream of logicians to put everything down into symbols was a good one, but with modern technology it’s become like a miracle drug that cures cancer but kills you. It just doesn’t seem right.")

#text("Because mathematicians such as the names listed in the first sentence having embraced AI, I have simulatenously lost respect for the field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-f29ed3b3a1d56c4929e33b73a529a979f0114bfddd62e6d8e8222d804e330b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698512")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Valuing the shared human experience of appreciating beauty, not only in Mathematics, but in all things, seems like the cultural shift human civilizations have to make in the face of increasingly capable AI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/how-to-formalize-all-of-mathematics/comment-page-1/#comment-698279")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("On the other hand I’ve felt since very long that we need to ")#strong[#text("Informalize")]#text(" mathematics, that Annals of Mathematics style I never found to be natural at all, but I’m not doctrinaire: more styles the better! And frankly, though I’ve written a few joint papers, I’m allergic to the phrase “mathematical community” let alone various sub-communities in it, far too many since far too long. And hunting in groups and those masses of people trying to tune up some result is antithetical to my way of thinking. I was attracted to mathematics for the happiness and pleasure it gives: both when we learn something really well (which often takes many cycles of thinking “oh yes now I’ve got it” to realize later “oh no I didn’t reaize)! And this pleasure comes when I alone do the unravelling. In all these “groups” de facto there is a certain heirarchy and a distinct air of master and slaves. Some mathematicians – for example one from IHES in his memoirs – have even alluded to it in writing. I’m an individualist and I think a university’s aim is to encourage individual thinking. Too much group-think, by far too much now. And top mathematicians like you getting paid far too much in USA to remain impartial. Good samaritans like Library Genesis etc — now rendered quasi defunct by billionaires whose LLMs were trained in part by soaking up the contents of these very same “pirate” libraries — have never been openly praised by top mathematicians of the west. The unbridled no holds barred capitalism that ensued after the cold war was “won” needs to be turned down. Nothing is/was ever perfect and political stances once formed change very slowly if at all from teenages onwards. But oh! for the days of early 1970 when I came to Stony Brook as a graduate student quite unexpectedly — a kind Princeton mathematician Norman Steenrod had sent me totally adrift… in a letter a problem which I was lucky enough to solve, and he was kind enough on the basis of it to write a letter of recommendation. And there was more than a whiff of freedom of thought around there: SB was aboil with anti Vietnam War protests. And Smale of those days was leading a protest in far off Berkeley. Have the top US mathematicians of today lost their soul? There has been except for very few cases stunning silence on the genocides in the middle east for example. Anyway — this is just being written off the cuff, and I knew I would never post this comment (indeed have never posted any comment ever before on the web and perhaps may never again!) if I were to start thinking about it and perfecting it etc etc — again this might be construed as ‘political’ — otoh it seems safe and professorial to talk at length of ‘climate change’ and now ‘x-risk’ etc — so let me end this impromptu heartpouring by returning to what I consider is the model way of writing mathematics: informal and like in Poincare, Jordan, Riemann etc. In trying to formalize them much real mathematics has been lost. There are ideas in all three that have never been developed though all three I’ve mentioned are celebrated. Informally written good mathematics also merges well with way other subjects to some extent are still being written. The dogmas of journals, editors and referees are obstructions: how much of Poincare would have been published by today’s “high standards” ? Indeed “retraction watch” would probably howl for some of Riemann’s best papers also to be deleted. Let’s give up toxicity. For example that hounding of Mochizuki was shameful. Continues even now that his work is no longer just on his website — yes all those are publications too! — but “duly” refereed etc : not that I understand it at all but frankly I didn’t understand fully Thurston’s best papers (on foliations and I worked in that ‘field’ for my Ph D!) either. However I’m totally with Scholze of now when he says human understanding — Serre put it better as pleasure, I prefer happiness though — will always remain. Let us detoxify mathematical so-called “community” and go back to individualism and enjoyment : mathematics done with an amateur’s glee, dunno why “professional” is even considered a good word. As I said all this written off the cuff only, apologies in advance if I rubbed anyone the wrong way. Have fun!")

#text("K. S. Sarkaria")
]
