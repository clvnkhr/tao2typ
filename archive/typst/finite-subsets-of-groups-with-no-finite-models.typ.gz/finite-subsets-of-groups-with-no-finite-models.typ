// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/
// Converted to Typst by tao2typ: "2026-10-14T15:16:52.865702+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite subsets of groups with no finite models", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite subsets of groups with no finite models")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/")[#text("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#emph[#text("Additive combinatorics")]]#text(" is largely focused on the additive properties of finite subsets A of an additive group ")#mi("G = (G,+)")#text(". This group can be finite or infinite, but there is a very convenient trick, the ")#emph[#text("Ruzsa projection trick")]#text(", which allows one to reduce the latter case to the former. For instance, consider the set ")#mi("A = \\{1,\\ldots,N\\}")#text(" inside the integers ")#mi("{\\Bbb Z}")#text(". The integers of course form an infinite group, but if we are only interested in sums of at most two elements of A at a time, we can embed A ininside the finite cyclic group ")#mi("{\\Bbb Z}/2N{\\Bbb Z}")#text(" without losing any combinatorial information. More precisely, there is a ")#emph[#text("Freiman isomorphism of order 2")]#text(" between the set ")#mi("\\{1,\\ldots,N\\}")#text(" in ")#mi("{\\Bbb Z}")#text(" and the set ")#mi("\\{1,\\ldots,N\\}")#text(" in ")#mi("{\\Bbb Z}/2N{\\Bbb Z}")#text(". One can view the latter version of ")#mi("\\{1,\\ldots,N\\}")#text(" as a ")#emph[#text("model")]#text(" for the former version of ")#mi("\\{1,\\ldots,N\\}")#text(". More generally, it turns out that any finite set A in an additive group can be modeled in the above set by an equivalent set in a finite group, and in fact one can ensure that this ambient modeling group is not much larger than A itself if A has some additive structure; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1281447")[#text("paper of Ruzsa")]#text(" (or Lemma 5.26 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(") for a precise statement. This projection trick has a number of important uses in additive combinatorics, most notably in Ruzsa’s simplified proof of Freiman’s theorem.")

#text("Given the interest in non-commutative analogues of Freiman’s theorem, it is natural to ask whether one can similarly model finite sets A in multiplicative (and non-commutative) groups ")#mi("G = (G,\\times)")#text(" using finite models. Unfortunately (as I learned recently from ")#link("http://en.wikipedia.org/wiki/Akshay_Venkatesh")[#text("Akshay Venkatesh")]#text(", via ")#link("http://en.wikipedia.org/wiki/Ben_J._Green")[#text("Ben Green")]#text("), this turns out to be impossible in general, due to an old ")#link("http://www.ams.org/mathscinet-getitem?mr=38348")[#text("example of Higman")]#text(". More precisely, Higman shows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" There exists an infinite group G generated by four distinct elements a,b,c,d that obey the relations")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("ab = ba^2; bc = cb^2; cd = dc^2; da = ad^2;")]]

#text("in fact, a and c generate the free group in G. On the other hand, if G’ is a finite group containing four elements a,b,c,d obeying (1), then a,b,c,d are all trivial.")
]

#text("As a consequence, the finite set ")#mi("A := \\{ 1, a, b, c, d, ab, bc, cd, da \\}")#text(" in G has no model (in the sense of Freiman isomorphisms) in a finite group.")

#text("Theorem 1 is proven by a small amount of elementary group theory and number theory, and it was neat enough that I thought I would reproduce it here.")

#metadata(none) <tao-788c2ecfdf657f07091b>

#heading(level: 1)[#text("— No non-trivial finite models —")]

#text("Let’s first show the second part of Theorem 1. The key point is that in a finite group G’, all elements have finite ")#link("http://en.wikipedia.org/wiki/Order_(group_theory)")[#text("order")]#text(", thanks to ")#link("http://en.wikipedia.org/wiki/Lagrange%27s_theorem_(group_theory)")[#text("Lagrange’s theorem")]#text(". From (1) we have")

#align(center)[#tao-fit-display[#mitex("b^{-1}ab = a^2")]]

#text("and hence by induction")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("b^{-n}ab^n = a^{2^n}")]]

#text("for any positive n. One consequence of (2) is that if ")#mi("b^n=1")#text(", then ")#mi("a = a^{2^n}")#text(", and thus ")#mi("a^{2^n-1} = 1")#text(". Applying this with n equal to the ")#link("http://en.wikipedia.org/wiki/Order_(group_theory)")[#text("order")]#text(" ")#mi("\\text{ord}(b)")#text(" of b, we conclude that")

#align(center)[#mi("\\text{ord}(a) | 2^{\\text{ord}(b)}-1")#text(".")]

#text("As a consequence, if ")#mi("\\text{ord}(a)")#text(" is divisible by some prime p, then ")#mi("2^{\\text{ord}(b)}-1")#text(" is divisible by p, which forces p to be odd and ")#mi("\\text{ord}(b)")#text(" to be divisible by the multiplicative order of 2 modulo p. This is at most p-1 (by ")#link("http://en.wikipedia.org/wiki/Fermat%27s_little_theorem")[#text("Fermat’s little theorem")]#text("), and so ")#mi("\\text{ord}(b)")#text(" is divisible by a prime strictly smaller than the prime dividing ")#mi("\\text{ord}(a)")#text(". But we can cyclically permute this argument and conclude that ")#mi("\\text{ord}(c)")#text(" is divisible by an even smaller prime than the prime dividing ")#mi("\\text{ord}(b)")#text(", and so forth, creating an ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("infinite descent")]#text(", which is absurd. Thus none of ")#mi("\\text{ord}(a), \\text{ord}(b), \\text{ord}(c), \\text{ord}(d)")#text(" can be divisible by any prime, and so a,b,c,d are trivial as claimed.")

#strong[#text("Remark 1.")]#text(" There is nothing special here about using four generators; the above arguments work with any number of generators (adapting (1) appropriately). But we will need four generators in order to establish the infinite model below. ")#mi("\\diamond")

#strong[#text("Remark 2. T")]#text("he above argument also shows that the group G has no non-trivial finite-dimensional linear representation. Indeed, let a, b, c, d be matrices obeying (1), then b is conjugate to ")#mi("b^2 = c^{-1} b c")#text(", which by the spectral theorem forces the eigenvalues of b to be roots of unity, which implies in particular that ")#mi("b^n")#text(" grows at most polynomially in n; similarly for ")#mi("a^n")#text(". Applying (2) we see that ")#mi("a^{2^n}")#text(" grows at most polynomially in n, which by the ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(" for a implies that a is diagonalisable; since its eigenvalues are roots of unity, it thus has finite order. Similarly for b,c,d. Now apply the previous argument to conclude that a,b,c,d are trivial. ")#mi("\\diamond")

#heading(level: 1)[#text("— Existence of an infinite model —")]

#text("To build the infinite group G that obeys the relations (1), we need the notion of an ")#emph[#text("amalgamated free product")]#text(" of groups.")

#text("Recall that the ")#link("http://en.wikipedia.org/wiki/Free_product")[#text("free product")]#text(" ")#mi("G_1 * G_2")#text(" of two groups ")#mi("G_1")#text(" and ")#mi("G_2")#text(" can be defined (up to group isomorphism) in one of three equivalent ways:")

#enum(start: 1, 
[#text("(Relations-based definition) ")#mi("G_1 * G_2")#text(" is the group ")#link("http://en.wikipedia.org/wiki/Generating_set_of_a_group")[#text("generated")]#text(" by the disjoint union ")#mi("G_1 \\uplus G_2")#text(" of ")#mi("G_1")#text(" and ")#mi("G_2")#text(", with no further relations between these elements beyond those already present in ")#mi("G_1")#text(" and ")#mi("G_2")#text(" separately.")],
[#text("(Category-theoretic definition) ")#mi("G_1 * G_2")#text(" is a group with ")#link("http://en.wikipedia.org/wiki/Homomorphism")[#text("homomorphisms")]#text(" from ")#mi("G_1")#text(" and ")#mi("G_2")#text(" into ")#mi("G_1 * G_2")#text(", which is ")#link("http://en.wikipedia.org/wiki/Universal_property")[#text("universal")]#text(" in the sense that any other group G’ with homomorphisms from ")#mi("G_1, G_2")#text(" will have these homomorphisms factor uniquely through ")#mi("G_1 * G_2")#text(".")],
[#text("(Word-based definition) ")#mi("G_1 * G_2")#text(" is the collection of all ")#link("http://en.wikipedia.org/wiki/Word_(group_theory)")[#text("words")]#text(" ")#mi("g_1 g_2 \\ldots g_n")#text(", where each ")#mi("g_i")#text(" lies in either ")#mi("G_1")#text(" or ")#mi("G_2")#text(", with no two adjacent ")#mi("g_i, g_{i+1}")#text(" lying in the same ")#mi("G_j")#text(" (let’s label ")#mi("G_1, G_2")#text(" here to be disjoint to avoid notational confusion), with the obvious group operations.")]
)

#text("It is not hard to see that all three definitions are equivalent, and that the free product exists and is unique up to group isomorphism.")

#strong[#text("Example 1.")]#text(" The free product of the free cyclic group ")#mi("\\langle a \\rangle")#text(" with one generator a, and the free cyclic group ")#mi("\\langle b \\rangle")#text(" with one generator b, is the free (non-abelian) group ")#mi("\\langle a, b \\rangle")#text(" on two generators. ")#mi("\\diamond")

#text("We will need a “relative” generalisation of the free product concept, in which the groups ")#mi("G_1, G_2")#text(" are not totally disjoint, but instead share a common subgroup H (or if one wants to proceed more category-theoretically, with a group H that embeds into both ")#mi("G_1")#text(" and ")#mi("G_2")#text("). In this situation, we define the amalgamated free product ")#mi("G_1 *_H G_2")#text(" by one of the following two equivalent definitions:")

#enum(start: 1, 
[#text("(Relations-based definition) ")#mi("G_1 * _H G_2")#text(" is the group ")#link("http://en.wikipedia.org/wiki/Generating_set_of_a_group")[#text("generated")]#text(" by the relative disjoint union ")#mi("G_1 \\uplus_H G_2")#text(" of ")#mi("G_1")#text(" and ")#mi("G_2")#text(" (which is the same as the disjoint union but with the common subgroup H identified), with no further relations between these elements beyond those already present in ")#mi("G_1")#text(" and ")#mi("G_2")#text(" separately.")],
[#text("(Category-theoretic definition) ")#mi("G_1 *_H G_2")#text(" is a group with ")#link("http://en.wikipedia.org/wiki/Homomorphism")[#text("homomorphisms")]#text(" from ")#mi("G_1")#text(" and ")#mi("G_2")#text(" into ")#mi("G_1 *_H G_2")#text(" that agree on H, which is ")#link("http://en.wikipedia.org/wiki/Universal_property")[#text("universal")]#text(" in the sense that any other group G’ with homomorphisms from ")#mi("G_1, G_2")#text(" that agree on H will have these homomorphisms factor uniquely through ")#mi("G_1 *_H G_2")#text(".")]
)

#strong[#text("Example 2.")]#text(" Let ")#mi("G_1 := \\langle a, b | ab = ba^2 \\rangle")#text(" be the group generated by two elements ")#mi("a, b")#text(" with one relation ")#mi("ab = ba^2")#text(". It is not hard to see that all elements of ")#mi("G_1")#text(" can be expressed uniquely as ")#mi("b^n a^m")#text(" for some integers n, m, and in particular that ")#mi("H := \\langle b \\rangle")#text(" is a free cyclic group. Let ")#mi("G_2 := \\langle b, c | bc = cb^2 \\rangle")#text(" be the group generated by two elements ")#mi("b, c")#text(" with one relation ")#mi("bc = cb^2")#text(", then again ")#mi("H := \\langle b \\rangle")#text(" is a free cyclic group, and isomorphic to the previous copy of H. The amalgamated free product ")#mi("G_1 *_H G_2 = \\langle a, b, c | ab=ba^2, bc = cb^2 \\rangle")#text(" is then generated by three elements ")#mi("a, b, c")#text(" with two relations ")#mi("ab = ba^2, bc = cb^2")#text(". ")#mi("\\diamond")

#text("It is not hard to see that the above two definitions are equivalent, and that ")#mi("G_1 *_H G_2")#text(" exists and is unique up to group isomorphism. But note that I did not give the word-based definition of the amalgamated free product yet. We will need to do so now; I will use the arguments from this 1954 paper of Neumann (who I briefly overlapped with, actually, at ANU), though the basic result I need here (namely, Corollary 1) dates all the way back to the work of Schreier in 1927.")

#text("In order to analyse these groups, we will need to study how they act on various spaces. If G is a group, we define a ")#emph[#text("G-space")]#text(" to be a set X together with an ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" ")#mi("(g, x) \\mapsto gx")#text(" of G on X (or equivalently, a homomorphism from G to the permutation group ")#mi("\\text{Sym}(X)")#text(" of X). Thus for instance G is itself a G-space. A G-space X is ")#emph[#text("transitive")]#text(" if for every ")#mi("x,y \\in X")#text(", there exists ")#mi("g \\in G")#text(" such that ")#mi("gx=y")#text(". A ")#link("http://en.wikipedia.org/wiki/Morphism")[#emph[#text("morphism")]]#text(" from one G-space X to another G-space Y is a map ")#mi("\\phi:X \\to Y")#text(" such that ")#mi("\\phi(gx) = g\\phi(x)")#text(" for all ")#mi("g \\in G")#text(" and ")#mi("x \\in X")#text(". If a morphism has an inverse that is also a morphism, we say that it is an ")#emph[#text("isomorphism")]#text(".")

#text("The first observation is that a G-space with certain properties will necessarily be isomorphic to G itself.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Criterion for isomorphism with G) Let G be a group, and let X be a non-empty transitive G-space, and suppose there is a morphism ")#mi("\\pi: X \\to G")#text(" from the G-space X to the G-space G. Then ")#mi("\\pi")#text(" is in fact an isomorphism of G-spaces.")
]

#strong[#text("Proof.")]#text(" It suffices to show that ")#mi("\\pi")#text(" is both injective and surjective. To show surjectivity, observe that the image ")#mi("\\pi(X)")#text(" is G-invariant and non-empty. But the action of G on G is transitive, and so ")#mi("\\pi(X)=G")#text(" as desired. To show injectivity, observe from transitivity that if ")#mi("x, x^{\\prime}")#text(" are distinct elements of X then ")#mi("x^{\\prime} = gx")#text(" for some non-identity ")#mi("g \\in G")#text(", thus ")#mi("\\pi(x^{\\prime}) = g \\pi(x)")#text(", thus ")#mi("\\pi(x^{\\prime}) \\neq \\pi(x)")#text(", establishing injectivity. ")#mi("\\Box")

#text("Now we can give the word formulation of the amalgamated free product.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Word-based description of amalgamated free product) Let ")#mi("G_1, G_2")#text(" be two groups with common subgroup H, and let ")#mi("G := G_1 *_H G_2")#text(" be the amalgamated free product. Let ")#mi("G_1 = \\bigcup_{s_1 \\in S_1} H \\cdot s_1")#text(", ")#mi("G_2 = \\bigcup_{s_2 \\in S_2} H \\cdot s_2")#text(" be some partitions of ")#mi("G_1, G_2")#text(" into right-cosets of H. Let X be the space of all formal words of the form ")#mi("h s_1 s_2 \\ldots s_n")#text(", where ")#mi("h \\in H")#text(", each ")#mi("s_i")#text(" lies in either ")#mi("S_1")#text(" or ")#mi("S_2")#text(", and no two adjacent ")#mi("s_i, s_{i+1}")#text(" lie in the same ")#mi("S_j")#text(". let ")#mi("\\pi: X \\to G")#text(" be the obvious evaluation map. Then there is an action of G on X for which ")#mi("\\pi")#text(" becomes an isomorphism of G-spaces.")
]

#strong[#text("Proof.")]#text(" It is easy to verify that ")#mi("G_1")#text(" and ")#mi("G_2")#text(" act separately on X in a manner consistent (via ")#mi("\\pi")#text(") with their action on G, and these actions agree on H. Hence the amalgamated free product G also acts on this space and turns ")#mi("\\pi")#text(" into a morphism of G-spaces. From construction of X we see that the G-action is transitive, and the claim now follows from Lemma 1. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" Let ")#mi("G_1, G_2")#text(" be two groups with common subgroup H, and let ")#mi("G := G_1 *_H G_2")#text(" be the amalgamated free product. Let ")#mi("g_1 \\in G_1")#text(" and ")#mi("g_2 \\in G_2")#text(" be such that the cyclic groups ")#mi("\\langle g_1 \\rangle, \\langle g_2 \\rangle")#text(" are infinite and have no intersection with H. Then ")#mi("g_1, g_2")#text(" generate a free subgroup in G.")
]

#strong[#text("Proof. ")]#text(" By hypothesis (and the axiom of choice), we can find a partition ")#mi("G_1 = \\bigcup_{s_1 \\in S_1} H \\cdot s_1")#text(" where ")#mi("S_1")#text(" contains the infinite cyclic group ")#mi("\\langle g_1 \\rangle")#text(", and similarly we can find a partition ")#mi("G_2 = \\bigcup_{s_2 \\in S_2} H \\cdot s_2")#text(". Let X be the space in Lemma 2. Each reduced word formed by ")#mi("g_1, g_2")#text(" then generates a distinct element of X, and thus (by Lemma 2) a distinct element of G. The claim follows. ")#mi("\\Box")

#strong[#text("Remark 3.")]#text(" The above corollary can also be established by the ")#link("http://en.wikipedia.org/wiki/Ping-pong_lemma")[#text("ping-pong lemma")]#text(" (which is not surprising, since the proof of that lemma uses many of the same ideas, and in particular exploiting an action of G on a space X in order to distinguish various words in G from each other). Indeed, observe that ")#mi("g_1, g_1^{-1}")#text(" map those words ")#mi("h s_1 s_2 \\ldots s_n")#text(" in X with ")#mi("s_1 \\not \\in S_1")#text(" into words ")#mi("h s_0 s_1 \\ldots s_n")#text(" with ")#mi("s_0 \\in S_1")#text(", and similarly for ")#mi("g_2, g_2^{-1}")#text(", which is the type of hypothesis needed to apply the ping-pong lemma. [Thanks to Ben Green for this observation.] ")#mi("\\diamond")

#text("Now we can finish the proof of Theorem 1. As discussed in Example 2, the group ")#mi("G_1 := \\langle a, b, c | ab=ba^2, bc = cb^2 \\rangle")#text(" is the amalgamated free product of ")#mi("\\langle a, b | ab=ba^2 \\rangle")#text(" and ")#mi("\\langle b, c | bc=cb^2 \\rangle")#text(" relative to ")#mi("\\langle b \\rangle")#text(". By Corollary 1, a and c generate the free group here, thus ")#mi("G_1")#text(" contains ")#mi("H = \\langle a, c \\rangle")#text(" as a subgroup. Similarly, the group ")#mi("G_2 := \\langle c, d, a | cd=dc^2; da=ad^2 \\rangle")#text(" also contains ")#mi("H = \\langle a, c \\rangle")#text(" as a subgroup. We may then form the amalgamated free product")

#align(center)[#tao-fit-display[#mitex("G := G_1 *_H G_2 = \\langle a, b, c, d | ab = ba^2, bc = cb^2, cd = dc^2, da=ad^2 \\rangle")]]

#text("and another application of Theorem 1 shows that b,d generate the free group (and are in particular distinct); similarly a, c are distinct. Finally, the group ")#mi("\\langle a,b | ab=ba^2 \\rangle")#text(" embeds into ")#mi("G_1")#text(", which embeds into G, and so a, b, are also distinct; cyclically permuting this we conclude that all of the a, b, c, d are distinct as claimed.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben green")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-32811")[#strong[#text("ben green")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2008")])]

#text("Terry,")

#text("Thanks for explaining this! The example is potentially disturbing in that if one aspires towards a Freiman-type theory for arbitrary groups (a theory which would only involve finite sets) then it may be necessary to understand infinite groups and even infinite-dimensional representations.")

#text("I say only *potentially* disturbing because there is some hope that a weaker statement holds. Namely, if ")#mi("K")#text(" is a constant and if ")#mi("A")#text(" is a set for which ")#tao-math("\\left|A\\cdot A\\right| \\leq K\\left|A\\right|", block: false)#text(" then there is a subset ")#mi("A^{\\prime} \\subseteq A")#text(" with ")#tao-math("\\left|A^{\\prime}\\right| \\geq c(K)\\left|A\\right|", block: false)#text(" which has a Freiman-isomorphic copy inside some finite group ")#mi("G")#text(". I can’t see it being easy to produce a counterexample to this!")

#text("One cannot hope for ")#mi("G")#text(" to have size comparable to ")#tao-math("\\left|A\\right|", block: false)#text(" (thus ")#tao-math("\\left|G\\right| \\leq C(K)\\left|A\\right|", block: false)#text(", say) as is the case in the abelian setting. I worked out the slightly painful details of an example a few months ago and have posted it here")

#link("http://www.dpmms.cam.ac.uk/~bjg23/papers/nonabelianmodels.pdf")[#text("Click to access nonabelianmodels.pdf")]

#text("since I don’t have any intention of publishing it.")

#text("Best wishes")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-32819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2008")])]

#text("professor tao,")

#text("thank you for your well written posts. i am learning a lot of math mainly through your posts.")#linebreak()#text(" if it is not too much trouble can you plaese include some references, ideally to books that can")#linebreak()#text(" with easy availability. i don’t have access to jstor or a good math library with easy access to")#linebreak()#text(" journals.")

#text("again thanks for writing up beautiful math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-32875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2008")])]

#text("In the beginning of the proof of theorem 1: “The key point is that in a finite group G’, all elements have finite order, thanks to Cauchy’s theorem”.")#linebreak()#text(" Apart from this fact being obvious, could you explain how it follows from Cauchys theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-32877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2008")])]

#text("Oops! I meant Lagrange’s theorem rather than Cauchy’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fisher")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-32931")[#strong[#text("David Fisher")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("Hi Terry,")

#text("That is a cool example.")

#text("A remark: all linear groups are residually finite i.e. have finite quotients")#linebreak()#text(" that separate any finite set.")

#text("So Remark 2 actually follows from the the fact that G has no finite quotients.")

#text("Your proof that G is non-linear is easier than the proof that linear groups")#linebreak()#text(" are residually finite.")

#text("Best,")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabor Elek")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-33245")[#strong[#text("Gabor Elek")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("Gordon and Vershik have a paper that characterizes those groups G such that")#linebreak()#text(" all finite subset of G can be modelled in finite groups.")#linebreak()#text(" They call these groups LEF (locally finitely embeddable). ")#link("http://www.esi.ac.at/preprints/esi334.pdf")[#text("http://www.esi.ac.at/preprints/esi334.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van Kampen’s theorem via covering spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-186980")[#strong[#text("van Kampen’s theorem via covering spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("[…] in and using the combinatorial description of the amalgamated free product (which was discussed in this previous blog post). But I recently learned (thanks to the responses to this recent MathOverflow question of mine) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d37a90e0a87f142de7cd0562fdf8c017d926c0f959ed87bc6e8bea45769fc2-ac07214c1e07b43680453f38c92b37224b98e315473b3a4ed6c01810549e2274.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-270717")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Joining a little late, but regarding remark 2: every linear group is residually finite, and so the remark follows immediately from the theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/#comment-469920")[#strong[#text("Shtetl-Optimized » Blog Archive » Entanglement without end")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")]

#text("[…] have a good intuition for Higman’s group, but if I did, it would come from rereading this post by Terry Tao. Certainly it has no known “physical interpretation” analogous to the […]")
]
