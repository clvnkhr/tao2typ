// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/
// Converted to Typst by tao2typ: "2026-10-14T16:35:03.599519+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Jordan normal form and the Euclidean algorithm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Jordan normal form and the Euclidean algorithm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/")[#text("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In one of my recent posts, I used the ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(" for a matrix in order to justify a couple of arguments. As a student, I learned the derivation of this form twice: firstly (as an undergraduate) by using the ")#link("http://en.wikipedia.org/wiki/Minimal_polynomial")[#text("minimal polynomial")]#text(", and secondly (as a graduate) by using the ")#link("http://en.wikipedia.org/wiki/Structure_theorem_for_finitely_generated_modules_over_a_principal_ideal_domain")[#text("structure theorem for finitely generated modules over a principal ideal domain")]#text(". I found though that the former proof was too concrete and the latter proof too abstract, and so I never really got a good intuition on how the theorem really worked. So I went back and tried to synthesise a proof that I was happy with, by taking the best bits of both arguments that I knew. I ended up with something which wasn’t too different from the standard proofs (relying primarily on the ")#link("http://en.wikipedia.org/wiki/Extended_Euclidean_algorithm")[#text("(extended) Euclidean algorithm")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text("), but seems to get at the heart of the matter fairly quickly, so I thought I’d put it up on this blog anyway.")

#text("Before we begin, though, let us recall what the Jordan normal form theorem is. For this post, I’ll take the perspective of abstract linear transformations rather than of concrete matrices. Let ")#mi("T: V \\to V")#text(" be a linear transformation on a finite dimensional complex vector space V, with no preferred coordinate system. We are interested in asking what possible “kinds” of linear transformations V can support (more technically, we want to classify the conjugacy classes of ")#mi("\\text{End}(V)")#text(", the ring of linear endomorphisms of V to itself). Here are some simple examples of linear transformations.")

#enum(start: 1, 
[#strong[#text("The right shift")]#text(". Here, ")#mi("V = {\\Bbb R}^n")#text(" is a standard vector space, and the ")#emph[#text("right shift")]#text(" ")#mi("U: V \\to V")#text(" is defined as ")#mi("U(x_1,\\ldots,x_n) = (0,x_1,\\ldots,x_{n-1})")#text(", thus all elements are shifted right by one position. (For instance, the 1-dimensional right shift is just the zero operator.)")],
[#strong[#text("The right shift plus a constant.")]#text(" Here we consider an operator ")#mi("U + \\lambda I")#text(", where ")#mi("U: V \\to V")#text(" is a right shift, I is the identity on V, and ")#mi("\\lambda \\in {\\Bbb C}")#text(" is a complex number.")],
[#strong[#text("Direct sums")]#text(". Given two linear transformations ")#mi("T: V \\to V")#text(" and ")#mi("S: W \\to W")#text(", we can form their direct sum ")#mi("T \\oplus S: V \\oplus W \\to V \\oplus W")#text(" by the formula ")#mi("(T \\oplus S)(v,w) := (Tv, Sw)")#text(".")]
)

#text("Our objective is then to prove the")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Jordan normal form theorem")]#text(". Every linear transformation ")#mi("T: V \\to V")#text(" on a finite dimensional complex vector space V is similar to a direct sum of transformations, each of which is a right shift plus a constant.")
]

#text("(Of course, the same theorem also holds with left shifts instead of right shifts.)")

#metadata(none) <tao-1bd70fe59be81f99198e>

#heading(level: 1)[#text("— Reduction to the nilpotent case —")]

#text("Recall that a linear transformation ")#mi("T: V \\to V")#text(" is ")#link("http://en.wikipedia.org/wiki/Nilpotent")[#text("nilpotent")]#text(" if we have ")#mi("T^m=0")#text(" for some positive integer m. For instance, every right shift operator is nilpotent, as is any direct sum of right shifts. In fact, these are essentially the only nilpotent transformations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Nilpotent Jordan normal form theorem")]#text(". Every nilpotent linear transformation ")#mi("T: V \\to V")#text(" on a finite dimensional vector space is similar to a direct sum of right shifts.")
]

#text("We will prove this theorem later, but for now let us see how we can quickly deduce the full Jordan normal form theorem from this special case. The idea here is, of course, to split up the ")#link("http://en.wikipedia.org/wiki/Minimal_polynomial")[#text("minimal polynomial")]#text(", but it turns out that we don’t actually need the minimal polynomial ")#emph[#text("per se")]#text("; any polynomial that annihilates the transformation will do.")

#text("More precisely, let ")#mi("T: V \\to V")#text(" be a linear transformation on a finite-dimensional complex vector space V. Then the powers ")#mi("I, T, T^2, T^3, \\ldots")#text(" are all linear transformations on V. On the other hand, the space of all linear transformations on V is a finite-dimensional vector space. Thus there must be a non-trivial linear dependence between these powers. In other words, we have P(T) = 0 (or equivalently, ")#mi("V = \\text{ker}(P(T))")#text(") for some polynomial P with complex coefficients.")

#text("Now suppose that we can factor this polynomial P into two coprime factors of lower degree, P = QR. Using the ")#link("http://en.wikipedia.org/wiki/Extended_Euclidean_algorithm")[#text("extended Euclidean algorithm")]#text(" (or more precisely, ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_identity")[#text("Bézout’s identity")]#text("), we can find more polynomials A, B such that AQ + BR = 1. In particular,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A(T)Q(T) + B(T)R(T) = I.")]]

#text("The formula (1) has two important consequences. Firstly, it shows that ")#mi("\\text{ker}(Q(T)) \\cap \\text{ker}(R(T)) = \\{0\\}")#text(", since if a vector v was in the kernel of both Q(T) and R(T), then by applying (1) to v we obtain v=0. Secondly, it shows that ")#mi("\\text{ker}(Q(T)) + \\text{ker}(R(T)) = V")#text(". Indeed, given any ")#mi("v \\in V")#text(", we see from (1) that ")#mi("v = R(T) B(T) v + Q(T) A(T) v")#text("; since ")#mi("Q(T) R(T) = R(T) Q(T) = P(T) = 0")#text(" on V, we see that ")#mi("R(T) B(T) v")#text(" and ")#mi("Q(T) A(T)")#text(" lie in ")#mi("\\text{ker}(Q(T))")#text(" and ")#mi("\\text{ker}(R(T))")#text(" respectively. Finally, since all polynomials in T commute with each other, the spaces ")#mi("\\text{ker}(Q(T))")#text(" and ")#mi("\\text{ker}(R(T))")#text(" are T-invariant.")

#text("Putting all this together, we see that the linear transformation T on ")#mi("\\ker(P(T))")#text(" is similar to the direct sum of the restrictions of T to ")#mi("\\text{ker}(Q(T))")#text(" and ")#mi("\\text{ker}(R(T))")#text(" respectively. We can iterate this observation, reducing the degree of the polynomial P which annihilates T, until we reduce to the case in which this polynomial P cannot be split into coprime factors of lesser degree. But by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(", this can only occur if P takes the form ")#mi("P(t) = (t - \\lambda)^m")#text(" for some ")#mi("\\lambda \\in {\\Bbb C}")#text(" and ")#mi("m \\geq 0")#text(". In other words, we can reduce to the case when ")#mi("(T - \\lambda I)^m = 0")#text(", or in other words T is equal to ")#mi("\\lambda I")#text(" plus a nilpotent transformation. If we then subtract off the ")#mi("\\lambda I")#text(" term, the claim now easily follows from the nilpotent Jordan normal form theorem.")

#text("[From a modern algebraic geometry perspective, all we have done here is split the spectrum of T (or of the ring generated by T) into connected components.]")

#text("It is interesting to see what happens when two eigenvalues get very close together. If one carefully inspects how the Euclidean algorithm works, one concludes that the coefficients of the polynomials A(T) and B(T) above become very large (one is trying to separate two polynomials Q(T) and R(T) that are only barely coprime to each other). Because of this, the Jordan decomposition becomes very unstable when eigenvalues begin to collide.")

#text("Because the fundamental theorem of algebra is used, it was necessary to work in an algebraically closed field such as the complex numbers ")#mi("{\\Bbb C}")#text(". (Indeed, one can in fact ")#emph[#text("deduce")]#text(" the fundamental theorem of algebra from the Jordan normal form theorem.) Over the reals, one picks up other “elliptic” components, such as ")#mi("2 \\times 2")#text(" rotation matrices, which are not decomposable into translates of shift operators.")

#text("Thus far, the decompositions have been canonical – the spaces one is decomposing into can be defined uniquely in terms of T (they are the kernels of the primary factors of the minimal polynomial). However, the further splitting of the nilpotent (or shifted nilpotent) operators into smaller components will be non-canonical, depending on an arbitrary choice of basis. [However, the multiplicities of each type of shift-plus-constant factor will remain canonical; this is easiest to see by inspecting the dimensions of the kernels of ")#mi("(T-\\lambda I)^m")#text(" for various ")#mi("\\lambda, m")#text(" using a Jordan normal form.]")

#heading(level: 1)[#text("— Proof of the nilpotent case —")]

#text("To prove the nilpotent Jordan normal form theorem, I would like to take a dynamical perspective, looking at orbits ")#mi("x, Tx, T^2 x, ....")#text(" of T. (These orbits will be a cheap substitute for the concept of a Jordan chain.) Since T is nilpotent, every such orbit terminates in some finite time ")#mi("m_x")#text(", which I will call the ")#emph[#text("lifespan")]#text(" of the orbit (i.e. ")#mi("m_x")#text(" is the least integer such that ")#mi("T^{m_x} x = 0")#text("). We will call x the ")#emph[#text("initial point")]#text(" of the orbit, and ")#mi("T^{m_x-1} x")#text(" the ")#emph[#text("final point")]#text(".")

#text("The elements of a finite orbit ")#mi("x, Tx, \\ldots, T^{m_x-1}x")#text(" are all linearly independent. This is best illustrated with an example. Suppose x has lifespan 3, thus ")#mi("T^3 x = 0")#text(" and ")#mi("T^2 x \\neq 0")#text(". Suppose there linear dependence between ")#mi("x, Tx, T^2 x")#text(", say ")#mi("3 x + 4 Tx + 5 T^2 x = 0")#text(". Applying ")#mi("T^2")#text(" we obtain ")#mi("3T^2 x = 0")#text(", a contradiction. A similar argument works for any other linear dependence or for any other lifespan. (Note how we used the shift T here to eliminate all but the final point of the orbit; we shall use a similar trick with multiple orbits shortly.)")

#text("The vector space spanned by a finite orbit ")#mi("x, Tx, \\ldots, T^{m_x-1} x")#text(" is clearly T-invariant, and if we use this finite orbit as a basis for this space then the restriction of T to this space is just the right shift. Thus to prove the nilpotent Jordan normal form theorem, it suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Nilpotent Jordan normal form theorem, again")]#text(". Let ")#mi("T: V \\to V")#text(" be nilpotent. Then there exists a basis of V which is the concatenation of finite orbits ")#mi("x, Tx, \\ldots,  T^{m_x-1} x")#text(".")
]

#text("We can prove this by the following argument (basically the same argument used to prove the Steinitz exchange lemma, but over the ring ")#mi("{\\Bbb C}[T]")#text(" instead of ")#mi("{\\Bbb C}")#text("). First observe that it is a triviality to obtain a concatenation of finite orbits which ")#emph[#text("span")]#text(" V: just take any basis of V and look at all the finite orbits that they generate. Now all we need to do is to keep whittling down this over-determined set of vectors so that they span ")#emph[#text("and")]#text(" are linearly independent, thus forming a basis.")

#text("Suppose instead that we had some collection of finite orbits ")#mi("x_i, T x_i, \\ldots, T^{m_{x_i}-1} x_i")#text(", for ")#mi("i = 1,\\ldots,r")#text(" which spanned V, but which contained some non-trivial linear relation. To take a concrete example, suppose we had three orbits ")#mi("x, Tx")#text(", ")#mi("y, Ty, T^2 y")#text(" and ")#mi("z, Tz, T^2 z, T^3 z")#text(" which had a non-trivial linear relation")

#align(center)[#mi("3x + 4Tx + 5Ty + 6T^2  y + 7T^2 z = 0")#text(".")]

#text("By applying some powers of T if necessary, and stopping just before everything vanishes, we may assume that our non-trivial linear relation only involves the final points ")#mi("T^{m_{x_i}-1} x_i")#text(" of our orbits. For instance, in the above case we can apply T once to obtain the non-trivial linear relation")

#align(center)[#tao-fit-display[#mitex("3 Tx + 5 T^2 y + 7 T^3 z = 0.")]]

#text("We then factor out as many powers of T as we can; in this case, we have")

#align(center)[#tao-fit-display[#mitex("T ( 3x + 5 Ty + 7 T^2 z ) = 0.")]]

#text("The expression in parentheses is a linear combination of various elements of our putative basis, in this case x, Ty, and ")#mi("T^2 z")#text(", with each orbit being represented at most once. At least one of these elements is an initial point (in this case x). We can then replace that element with the element in parentheses, thus shortening one of the orbits but keeping the span of the concatenated orbits unchanged. (In our example, we replace the orbit ")#mi("x, Tx")#text(" of lifespan 2 with an orbit ")#mi("3x+5Ty + 7T^2 z")#text(" of lifespan 1.)")

#text("Iterating this procedure until no further linear dependences remain, we obtain the nilpotent Jordan normal form theorem, and thus the usual Jordan normal form.")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11808")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("Dear Terence,")#linebreak()#text(" like you I was dissatisfied by both paths to Jordan’s theorem, but I would never have had the guts to admit it, nor the talent to find a satisfying new way .")#linebreak()#text(" Your blog is truly liberating in showing how a great mathematician cares and thinks about relatively elementary mathematics, and then improves the traditional presentation.")#linebreak()#text(" I value this psychological effect of your blog as highly as its wonderful mathematical content.")#linebreak()#text(" Yours thankfully ,")#linebreak()#text(" Attila")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of im")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11821")[#strong[#text("im")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("bring back snap!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bart")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11888")[#strong[#text("Bart")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("Nice job, Terry!")

#text("There is another result, namely Fermat’s Little Theorem (a^p congruent to a mod p), for which I’ve seen two proofs as a student: one by induction over a, using the fact that the (p choose k) are divisible by p, and one via Lagrange’s theorem in the multiplicative group F_p\\{0}. There, too, I find the first proof “too concrete” and the second one “too abstract”.")

#text("Does anybody see a way of “combining” them similarly to what Terry did with Jordan’s theorem?")

#text("(Of course, there are many more proofs; see .)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bart")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11889")[#strong[#text("Bart")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("Sorry, there should have been an URL at the end of my comment: ")#link("http://en.wikipedia.org/wiki/Proofs_of_Fermat%27s_little_theorem")[#text("http://en.wikipedia.org/wiki/Proofs_of_Fermat%27s_little_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11912")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("I can only like this proof of the Jordan canonical form theorem. Who could be against it? But I don’t completely agree with the precept that the classification of finitely-generated PID modules is too abstract. Because, basically, you’ve proved that more general result in the important case of finitely-generated modules with a non-trivial annihilator. In the case of modules over a polynomial ring F[X], these modules are finite-dimensional vector spaces on which an operator acts. In the case of Z-modules, these modules are finite abelian groups.")

#text("For example, consider your discussion step by step for finite abelian groups. First you prove the abelian Sylow theorem, then you show dynamically that an abelian p-group is a direct sum of cyclic groups. The dynamic in this case is multiplication by p.")

#text("Certainly the classification of finitely generated modules over a PID can be proved in an excessively abstract style. Even so, I considered a great revelation to learn that Jordan canonical form and canonical form for finite abelian groups are really the same theorem.")

#text("For that matter, I was even more excited to learn that the spectral theorem for self-adjoint operators in infinite dimensions has a strong form that also looks the same. One form of the classification for PID modules is the prime-power form that you emphasize here. I don’t know of a way in which it that view is useful for Hermitian operators. The other form is the minimal cyclic form, in which you say that any finitely-generated module is a direct sum of R/n_k, such that each cyclic period n_k is divisible by the next one, n_{k+1}. That form generalizes to the Hahn-Hellinger theorem, the revelatory result to which I refer.")

#text("Since the answer is so good for self-adjoint operators on a Hilbert space, it makes me wonder why life is so much harder for non-self-adjoint bounded operators. Certainly there are examples that look like nice infinite forms of Jordan blocks. But is it that there are also more complicated examples, or that no one can show that the nice examples are everything?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-11928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("Dear Greg,")

#text("That is a nice observation! I had not realised that the classification of finite abelian groups and the classification of linear transformations were essentially the same. I guess this shows the power of the abstract viewpoint.")

#text("As for what goes wrong in the non-self-adjoint case, it seems to me the problem is that the spectrum no longer controls the resolvent, due to the presence of pseudospectrum (i.e. the operator norm of ")#mi("(A - zI)^{-1}")#text(" can be large even when z is nowhere near the spectrum). This seems to destroy the utility of the spectrum for the analysis of non-self-adjoint infinite-dimensional operators. As for your last question, you are veering dangerously close to the invariant subspace problem and so I suspect there is no simple answer.")

#text("Dear Bart: this type of algebra is not really my forte, but I think the two proofs are not truly related, being caused by the field of p elements “wearing two hats”: one has a field of characteristic p, and the other as a multiplicative group with a zero element adjoined. In the former, we have the Frobenius automorphism, and in the latter, we have Lagrange’s theorem. Now ")#mi("F_p")#text(" is one-dimensional and so the Frobenius automorphism happens to be the identity, but this is sort of a coincidence due to the absence of a non-trivial Galois group in this field. In higher fields ")#mi("F_{p^m}")#text(", the Lagrange identity approach gives ")#mi("x^{p^m} = x")#text(", whereas the Frobenius automorphism ")#mi("x \\mapsto x^p")#text(", while still an automorphism, is no longer the identity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbcb2117596b443a44ef9922b7eadb6612cc7a3fc928fe5413d091a7f530abf-c46ac5f2335097af1f794b39e6b46e5d4f994837160c908696eca62bc4210c2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-12147")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I think rather than a top down approach, where one takes a whole bunch of orbits and slowly makes them linearly independent; it is more intuitive (and computationally efficient) to take a bottom up approach.")

#text("To do this, one lets V_i be the vector subspace killed by T^i. We arrive at the chain V_0 <= V_1 <= … <= V_k = V. Fix *any* basis A_(k-1) for V_(k-1), and extend to a basis A’_(k-1) for V_k. Let B_k=A’_(k-1)\\A_(k-1). The elements in B_k will generate linearly independent orbits (of maximal length). I like to think of these vectors as a basis for some maximal complement to the stuff killed by T^{k-1}.")

#text("At this point, one repeats the construction, working with V_(k-2). To avoid linear dependencies, we make sure that all of the new bases we construct at the very least contain the appropriate elements in the orbits of B_k, B_(k-1), etc… (In other words, once we have constructed an orbit we want to keep, we always force everything new we work with to be linearly independent from these orbits.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbcb2117596b443a44ef9922b7eadb6612cc7a3fc928fe5413d091a7f530abf-c46ac5f2335097af1f794b39e6b46e5d4f994837160c908696eca62bc4210c2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-12148")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("In other words, we let B_(k-1) be a basis for a maximal complement in V_(k-1) of V_(k-2), but containing T(B_k). In turn, we let B_(k-2) be a basis for a maximal complement in V_(k-2) of V_(k-3), containing T(B_(k-1)). etc…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-12457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")])]

#text("I would like to ask something only tangentially related to the topic. You mentioned you learned the proof “using the structure theorem for finitely generated modules over a principal ideal domain” in your graduate years. There’s a rather big controversy where I study (University of Buenos Aires) as to whether it’s right to teach something like that at the undergraduate level (third/fourth year). Sorry to bother you with this, but it called our attention and would love to hear an outside opinion (feels like we’re running around in circles here…). Thank You.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-12644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("Dear Said,")

#text("I’m afraid I’m not really the right person to ask; I haven’t taught algebra at either level. My undergraduate education in algebra got as far as Galois theory, which was a fun topic for that level I thought, but anything more abstract would have to be done properly. (My graduate education in algebra mostly consisted of reading Hungerford in order to prepare for qualifying exams; not exactly the most thorough education in the subject, but it did suffice for the type of maths I was doing at the time.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-24567")[#strong[#text("Not Even Wrong » Blog Archive » Accumulated Links")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")]

#text("[…] As always, Terry Tao’s blog has wonderful postings and articles, often of a general expository nature. For some recent examples, see one about the Schrodinger Equation, and another about Jordan normal form. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-25110")[#strong[#text("Prokrastination oder Blogroll (I): Terence Tao at LEMUREN-Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2008")]

#text("[…] Jordansche Normalenform und Euklidischer Algorithmus […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-27407")[#strong[#text("254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2008")])]

#text("[…] many eigenvalues of , and so is nilpotent on each of the generalised eigenvectors of . By the Jordan normal form, these generalised eigenvectors span V, and we are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7256f7926c74a72bb30c37fa93a89692c899c5adf4c61198116a6f8eead3536a-348ee92ccae650cfb9a71faec417cdd60f119d542bf02639e12bcafe4404f450.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-32950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")])]

#text("Hello Terrence,")

#text("Thank you for this fascinating discussion. As a physics student I have found utility in the idea of extending the jordan form to infinite dimensions. Could you help me understand why this isn’t possible?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-32956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")])]

#text("Dear anonymous,")

#text("Basically, the problem is that the Jordan normal form becomes extremely sensitive to small perturbations in high dimensions, as the eigenvalues become increasingly close to each other (and thus difficult to separate), and also due to some related phenomena such as the emergence of pseudospectrum, and the increasingly degenerate nature of the Jordan basis. So there does not appear to be a useful and well-defined limiting normal form for general bounded linear operators on (say) a Hilbert space (this issue also comes dangerously close to the notorious invariant subspace problem, which remains open).")

#text("The situation is much better though for special classes of operators such as compact, Hermitian, unitary, or normal operators, which do not have much pseudospectrum and so enjoy a useful spectral theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f64bc22c7f3f5dfb60cbb4923ff6c5eebf3aeaed577624ca586fd91b6908078b-60d4ff61b6f593d28b87f67bf47cdf30ccddd91eb7430d002734373a5b317b4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jamal")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-140728")[#strong[#text("jamal")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("I can’t see why the span is unchanged after replacing the orbits. Is it not possible that ")#mi("3x+5Ty+7T^2z")#text(" belongs to span(y,z)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-140759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("Replacing ")#mi("x")#text(" with ")#mi("x^{\\prime} := 3x + 5Ty + 7T^2 z")#text(" is basically an elementary row operation and thus replacing x by x’ does not affect the span, because x’ can be written as a linear combination of x and various shifts of y,z, and x can conversely be written as a linear combination of x’ and various shifts of y,z, and similarly for shifts of x,x’. In particular,")

#mi("span( x, Tx, y, T y, T^2 y , z, Tz, T^2 z) = span(x^{\\prime}, Tx^{\\prime}, y, Ty, T^2 y, z, Tz, T^2 z)")

#text("and then since ")#mi("Tx^{\\prime}=0")#text(", we can shorten the spanning set by one element.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-140788")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("Your exchange lemma is just what I need! It’s a simple argument but I find the exchanging part strangely unintuitive, in the sense that my mind recoils from the idea of applying a nilpotent operator and _then_ looking for something linearly independent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the classification of complex Lie algebras | What's new")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-226586")[#strong[#text("Notes on the classification of complex Lie algebras | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("[…] is not difficult to then place in Jordan normal form by selecting a suitable basis for ; see e.g. this previous blog post. But in contrast to the Jordan-Chevalley decomposition, the basis is not unique in general, and we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-453117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2015")])]

#text("Dear Terrance,")

#text("Was looking to provide better understanding to my students on Jordan canonical theory and stumbled upon your page. This is my favourite proof too and is described in the book by Blyth and Robertson titled Further Linear Algebra.")

#text("Thanks much!")

#text("Best wishes,")#linebreak()#text(" Anupam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-474527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("Knuth mentioned in his article Computer Science and Its relation to Mathematics that")

#emph[#linebreak()#text(" For three years I taught a sophomore course in abstract algebra, for mathematics majors at Caltech, and the most difficult topic was always the study of “Jordan canonical form” for matrices. The third year I tried a new approach, by looking at the subject algorithmically, and suddenly it became quite clear. The same thing happened with the discussion of finite groups defined by generators and relations; and in another course, with the reduction theory of binary quadratic forms. By presenting the subject in terms of algorithms, the purpose and meaning of the mathematical theorems became transparent.")#linebreak()#text(" ")]

#text("Are you presenting the proof in a “global” algorithm-way or just using (locally) the Euclidean algorithm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-481218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Would you sketch or give a reference for the minimal polynomial approach mentioned in the beginning? I don’t see how minimal polynomials should be involved in a proof. In some popular textbooks of linear algebra I know, e.g. Freidberg-Insel-Spence or Axler, minimal polynomials are not used.")

#text("Can one use the approach in this post to give a Jordan basis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-482147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("See for instance ")#link("http://www.ctr.maths.lu.se/media/MATM14/2011MATM14_vt11/jordan_.pdf")[#text("http://www.ctr.maths.lu.se/media/MATM14/2011MATM14_vt11/jordan_.pdf")]#text(" for a proof of the existence of Jordan normal form using minimal polynomials.")

#text("I don’t know what you mean by “giving” a Jordan basis here – the existence of a Jordan basis is equivalent to the existence of Jordan normal form, and the proof is in principle constructive enough that an algorithm to describe the basis can be provided.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-482151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("Ah, thanks for the reference. For the second question, if one has a ")#mi("6\\times 6")#text(" matrix ")#mi("A")#text(", say, how would one use the method in this post to explicitly write down ")#mi("B")#text(" and ")#mi("\\Lambda")#text(" such that ")#mi("A=B\\Lambda B^{-1}")#text(" where ")#mi("\\Lambda")#text(" is the Jordan normal form?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-639664")[#strong[#text("Plaidheron")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2022")]

#text("[…] Tao (who is very smart and has the ability to explain things) has examined the Jordan normal form:")#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/and")[#text("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/and")]#text(" I am inclined to remove my discussion/usage justification; replacing it with references to his, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3173d779e3f41997cc11f20b3d93d162702fdb02f4ca9551b26e3b4c59767b93-191bd82bf5c2112c5789b497e23c9b35378e473b56c5514b26b203f52c20279f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond Rogers")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-639793")[#strong[#text("Raymond Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("I am doing some work with the standard t=ln(Pascal Matrix) which has no Eigenvalues ne. 0, and transforms going into and out of the Jordan Normal forms. Finite cases (t^n) seem easy to deal with, but the infinite closure is a little iffy. Does your concern “Jordan normal form becomes extremely sensitive to small perturbations” really apply? I can think of a couple of ways to explicitly prove infinite properties, but they are “sidewise”. This work deals with “formal” series where the terms are needed and convergence is irrelevant. I don’t want to step into things like Cantor’s diagonalization counterargument; of course, that seems irrelevant?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/#comment-693423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#emph[#text("So I went back and tried to synthesise a proof that I was happy with, by taking the best bits of both arguments that I knew.")]

#text("When I was learning these two proof methods from the textbook, I always felt confused. May I ask what is the ")#emph[#text("best bits")]#text(" of each of the two arguments you mentioned here?")
]
