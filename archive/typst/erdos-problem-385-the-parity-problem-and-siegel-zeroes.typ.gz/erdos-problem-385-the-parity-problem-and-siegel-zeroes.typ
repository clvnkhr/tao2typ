// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/
// Converted to Typst by tao2typ: "2026-10-14T15:21:00.996860+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Erdos problem #385, the parity problem, and Siegel zeroes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Erdos problem #385, the parity problem, and Siegel zeroes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 August 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/")[#text("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://www.erdosproblems.com/start")[#text("Erdös problem site")]#text(" was created last year, and announced ")#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/")[#text("earlier this year on this blog")]#text(". Every so often, I have taken a look at a random problem from the site for fun. A few times, I was able to make progress on one of the problems, leading to ")#link("https://terrytao.wordpress.com/tag/paul-erdos/")[#text("a couple papers")]#text("; but the more common outcome is that I play around with the problem for a while, see why the problem is difficult, and then eventually give up and do something else. But, as is common in this field, I don’t make public the observations that I made, and the next person who looks at the same problem would likely have to go through the same process of trial and error to work out what the main obstructions that are present are.")

#text("So, as an experiment, I thought I would record here my preliminary observations on one such problem – ")#link("https://www.erdosproblems.com/385")[#text("Erdös problem #385")]#text(" – to discuss why it looks difficult to solve with our current understanding of the primes. Here is the problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Erdös Problem #385)")]#text(" Let")

#align(center)[#tao-fit-display[#mitex("F(n) =\\max_{\\stackrel{m<n}{m\\text{\\ composite}}} m+p(m),")]]

#text("where ")#mi("{p(m)}")#text(" is the least prime divisor of ")#mi("{m}")#text(" . Is it true that ")#mi("{F(n)>n}")#text(" for all sufficiently large ")#mi("{n}")#text("? Does ")#mi("{F(n)-n \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text("?")
]

#text("This problem is mentioned on page 73 of this ")#link("https://zbmath.org/0393.10046")[#text("1979 paper of Erdös")]#text(" (where he attributes the problem to an unpublished work of Eggelton, Erdös, and Selfridge that, to my knowledge, has never actually appeared), as well as briefly in page 92 of ")#link("https://zbmath.org/0434.10001")[#text("this 1980 paper of Erdös and Graham")]#text(".")

#text("At first glance, this looks like a somewhat arbitrary problem (as many of Erdös’s problems initially do), as the function ")#mi("{F}")#text(" is not obviously related to any other well-known function or problem. However, it turns out that this problem is closely related to the parity barrier in sieve theory (as discussed in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this previous post")]#text("), with the possibility of Siegel zeroes presenting a particular obstruction. I suspect that Erdös was well aware of this connection; certainly he mentions the relation with questions on gaps between primes (or almost primes), which is in turn connected to the parity problem and Siegel zeroes (as is discussed recently in ")#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/")[#text("my paper with Banks and Ford")]#text(", and in more depth in these papers ")#link("https://zbmath.org/1480.11111")[#text("of Ford")]#text(" and ")#link("https://zbmath.org/1504.11089")[#text("of Granville")]#text(").")

#text("Let us now explore the problem further. Let us call a natural number ")#mi("{n}")#text(" ")#emph[#text("bad")]#text(" if ")#mi("{F(n) \\leq n}")#text(", so the first part of the problem is asking whether there exist bad numbers that are sufficiently large. We unpack the definitions: ")#mi("{n}")#text(" is bad if and only if ")#mi("{m+p(m) \\leq n}")#text(" for any composite ")#mi("{m}")#text(", so placing ")#mi("{m}")#text(" in intervals of the form ")#mi("{[n-h,n]}")#text(" we are asking to show that")

#align(center)[#tao-fit-display[#mitex("p(m) \\leq h \\text{ for all composite } m \\in [n-h, n]")]]

#text("for each ")#mi("{1 \\leq h \\leq n}")#text(". To put it another way, the badness of ")#mi("{n}")#text(" asserts that for each ")#mi("{1 \\leq h \\leq n}")#text(" that the residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{p \\leq h}")#text(" cover all the natural numbers in the interval ")#mi("{[n-h,n]}")#text(" except for the primes.")

#text("It is now natural to try to understand this problem for a specific choice of interval ")#mi("{h}")#text(" as a function of ")#mi("{n}")#text(". If ")#mi("{h}")#text(" is large in the sense that ")#mi("{h > \\sqrt{n}}")#text(", then the claimed covering property is automatic, since every composite number less than or equal to ")#mi("{n}")#text(" has a prime factor less than or equal to ")#mi("{\\sqrt{n}}")#text(". On the other hand, for ")#mi("{h}")#text(" very small, in particular ")#mi("{h = o(\\log n)}")#text(", it is also possible to find ")#mi("{n}")#text(" with this property. Indeed, if one takes ")#mi("{n}")#text(" to lie in the residue class ")#mi("{0 \\text{ mod } \\prod_{p \\leq h}}")#text(", then we see that the residue classes cover all of ")#mi("{[n-h,n]}")#text(" except for ")#mi("{n-1}")#text(", and from ")#link("https://en.wikipedia.org/wiki/Linnik%27s_theorem")[#text("Linnik’s theorem")]#text(" we can ensure that ")#mi("{n-1}")#text(" is prime. Thus, to rule out bad numbers, we need to understand the covering problem at intermediate scales ")#mi("{\\log n \\ll h \\ll \\sqrt{n}}")#text(".")

#text("A key case is when ")#mi("{h = n^{1/u}}")#text(" for some ")#mi("{2 < u < 3}")#text(". Here, the residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{p \\leq h}")#text(" sieve out everything in ")#mi("{[n-h,n]}")#text(" except for primes and ")#link("https://en.wikipedia.org/wiki/Semiprime")[#text("semiprimes")]#text(", and specifically the semiprimes that are product of two primes between ")#mi("{n^{1/u}}")#text(" and ")#mi("{n^{1-1/u}}")#text(". If one can show for some ")#mi("{2 < u < 3}")#text(" that the largest gap between semiprimes in say ")#mi("{[x,2x]}")#text(" with prime factors in ")#mi("{[x^{1/u}, x^{1-1/u}]}")#text(" is ")#mi("{o( x^{1/u} )}")#text(", then this would affirmatively answer the first part of this problem (and also the second). This is certainly very plausible – it would follow from a semiprime version of the ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér conjecture")]#text(" (and this would also make the more precise prediction ")#mi("{F(n) = n + n^{1/2-o(1)}}")#text(") – but remains well out of reach for now. Even assuming the Riemann hypothesis, the best upper bound on prime gaps in ")#mi("{[x,2x]}")#text(" is ")#mi("{O( \\sqrt{x} \\log x )}")#text(", and the best upper bound on semiprime gaps is not significantly better than this – in particular, one cannot reach ")#mi("{x^{1/u}}")#text(" for any ")#mi("{2 < u < 3}")#text(". (There is a remote possibility that an ")#emph[#text("extremely")]#text(" delicate analysis near ")#mi("{u=2}")#text(", together with additional strong conjectures on the zeta function, such as a sufficiently quantitative version of the GUE hypothesis, may barely be able to resolve this problem, but I am skeptical of this, absent some further major breakthrough in analytic number theory.)")

#text("Given that multiplicative number theory does not seem powerful enough (even on RH) to resolve these problems, the other main approach would be to use sieve theory. In this theory, we do not really know how to exploit the specific location of the interval ")#mi("{[n-h,n]}")#text(" or the specific congruence classes used, so one can study the more general problem of trying to cover an interval ")#mi("{I}")#text(" of length ")#mi("{h}")#text(" by one residue class mod ")#mi("{p}")#text(" for each ")#mi("{p \\leq h}")#text(", and only leaving a small number of survivors which could potentially be classified as “primes”. The discussion of the small ")#mi("{h}")#text(" case already reveals a problem with this level of generality: one can sieve out the interval ")#mi("{[-h, 1]}")#text(" by the residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{p \\leq h}")#text(", and leave only one survivor, ")#mi("{-1}")#text(". Indeed, thanks to known bounds on Jacobsthal’s function, one can be more efficient than this; for instance, using equation (1.2) from ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("this paper of Ford, Green, Konyagin, Maynard, and myself")]#text(", it is possible to completely sieve out any interval of sufficiently large length ")#mi("{h}")#text(" using only those primes ")#mi("{p}")#text(" up to ")#mi("{O(\\frac{h \\log\\log h}{\\log h \\log\\log\\log h})}")#text(". On the other hand, from ")#link("https://zbmath.org/0378.10029")[#text("the work of Iwaniec")]#text(", we know that sieving up to ")#mi("{o(h^{1/2})}")#text(" is insufficient to completely sieve out such an interval; related to this, if one only sieves up to ")#mi("{h^{1/u}}")#text(" for some ")#mi("{2 < u < 3}")#text(", the linear sieve (see e.g., Theorem 2 of ")#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/")[#text("this previous blog post")]#text(") shows that one must have at least ")#mi("{(f(u)+o(1)) \\frac{h}{\\log h}}")#text(" survivors, where ")#mi("{f(u)}")#text(" can be given explicitly in the regime ")#mi("{2 < u < 3}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(u) := \\frac{2e^\\gamma}{u} \\log(u-1).")]]

#text("These lower bounds are not believed to be best possible. For instance, the Maier–Pomerance conjecture on Jacobsthal’s function would indicate that one needs to sieve out primes up to ")#mi("{\\gg h/\\log^2 h}")#text(" in order to completely sieve out an interval of length ")#mi("{h}")#text(", and it is also believed that sieving up to ")#mi("{h^{1-\\varepsilon}}")#text(" should leave ")#mi("{\\gg_\\varepsilon h/\\log h}")#text(" survivors, although even these strong conjectures are not enough to positively resolve this problem, since we are permitted to sieve all the way up to ")#mi("{h}")#text(" (and we are allowed to leave every prime number as a survivor, which in view of the Brun–Titchmarsh theorem could permit as many as ")#mi("{O(h/\\log n)}")#text(" survivors).")

#text("Unfortunately, as discussed in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this previous blog post")]#text(", the parity problem blocks such improvements from taking place from most standard analytic number theory methods, in particular sieve theory. A particularly dangerous enemy arises from Siegel zeroes. This is discussed in detail in the papers of ")#link("https://zbmath.org/1480.11111")[#text("of Ford")]#text(" and ")#link("https://zbmath.org/1504.11089")[#text("of Granville")]#text(" mentioned previously, but an informal discussion is as follows. If there is a Siegel zero associated to the quadratic character of some conductor ")#mi("{q}")#text(", this roughly speaking means that almost all primes ")#mi("{p}")#text(" (in certain ranges) will be quadratic non-residues mod ")#mi("{q}")#text(". In particular, if one restricts attention to numbers ")#mi("{n}")#text(" in a residue class ")#mi("{a \\text{ mod } q}")#text(" that is a quadratic residue, we then expect most numbers in this class to have an ")#emph[#text("even")]#text(" number of prime factors, rather than an odd number.")

#text("This alters the effect of sieving in such residue classes. Consider for instance the classical sieve of Eratosthenes. If one sieves out ")#mi("{0 \\text{ mod } p}")#text(" for each prime ")#mi("{p \\leq \\sqrt{h}}")#text(", the sieve of Eratosthenes tells us that the surviving elements of ")#mi("{[1,h]}")#text(" are simply the primes between ")#mi("{\\sqrt{h}}")#text(" and ")#mi("{h}")#text(", of which there are about ")#mi("{h/\\log h}")#text(" many. However, if one restricts attention to ")#mi("{[1,h] \\cap a \\text{ mod } q}")#text(" for a quadratic residue class ")#mi("{a \\text{ mod } q}")#text(" (and taking ")#mi("{h}")#text(" to be somewhat large compared to ")#mi("{q}")#text("), then by the preceding discussion, this eliminates most primes, and so now sieving out ")#mi("{0 \\text{ mod } p}")#text(" should leave almost no survivors. Shifting this example by ")#mi("{a}")#text(" and then dividing by ")#mi("{q}")#text(", one can end up with an example of an interval ")#mi("{I}")#text(" of length ")#mi("{h}")#text(" that can be sieved by residue classes ")#mi("{b_p \\text{ mod } p}")#text(" for each ")#mi("{p \\leq \\sqrt{h}}")#text(" in such a manner as to leave almost no survivors (in particular, ")#mi("{o(h/\\log h)}")#text(" many). In the presence of a Siegel zero, it seems quite difficult to prevent this scenario from “infecting” the above problem, creating a bad scenario in which for all ")#mi("{\\log n \\ll h \\ll \\sqrt{n}}")#text(", the residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{p \\leq \\sqrt{h}}")#text(" already eliminate almost all elements of ")#mi("{[n-h,n]}")#text(", leaving it mathematically possible for the remaining survivors to either be prime, or eliminated by the remaining residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{\\sqrt{h} < p \\leq h}")#text(".")

#text("Because of this, I suspect that it will not be possible to resolve this Erdös problem without a major breakthrough on the parity problem that (at a bare minimum) is enough to exclude the possibility of Siegel zeroes existing. (But it is not clear at all that Siegel zeroes are be the only “enemy” here, so absent a major advance in “inverse sieve theory”, one cannot simply assume GRH to run away from this problem).")

#heading(level: 1)[#strong[#text(" — 0.1. Addendum: heuristics for Siegel zero scenarios — ")]]

#text("This post also provides a good opportunity to refine some heuristics I had previously proposed regarding Siegel zeroes and their impact on various problems in analytic number theory. In ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this previous blog post")]#text(", I wrote")

#text("“The parity problem can also be sometimes be overcome when there is an exceptional Siegel zero … [this] suggests that to break the parity barrier, we may assume without loss of generality that there are no Siegel zeroes.”")

#text("On the other hand, it was pointed out in a ")#link("https://dms.umontreal.ca/~andrew/PDF/Sieve.Remark.20.09.26.pdf")[#text("more recent article of Granville")]#text(" that (as with the current situation), Siegel zeroes can sometimes serve to enforce the parity barrier, rather than overcome it, and responds to my previous statement with the comment “this claim needs to be treated with caution, since its truth depends on the context”.")

#text("I actually agree with Granville here, and I propose here a synthesis of the two situations. In the absence of a Siegel zero, standard heuristic models in analytic number theory (such as the ones discussed in ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this post")]#text(") typically suggest that a given quantity ")#mi("{X}")#text(" of interest in number theory (e.g., the number of primes in a certain set) obey an asymptotic law of the form")

#align(center)[#tao-fit-display[#mitex("X = \\mathrm{Main\\ term} + \\mathrm{Error\\ term}")]]

#text("where ")#mi("{\\mathrm{Main\\ term}}")#text(" is generally fairly well understood, while ")#mi("{\\mathrm{Error\\ term}}")#text(" is expected to fluctuate “randomly” (or more precisely, ")#link("https://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandomly")]#text(") and thus be smaller than the main term. However, a major difficulty in analytic number theory is that we often cannot prevent a “conspiracy” from occurring in which the error term becomes as large as, or even larger than the main term: the fluctuations present in that term are often too poorly understood to be under good control. The parity barrier manifests by providing examples of analogous situations in which the error term is indeed as large as the main term (with an unfavorable sign).")

#text("However, the presence of a Siegel zero tends to “magnetize” the error term by pulling most of the fluctuations in a particular direction. In many situations, what this means is that one can obtain a refined asymptotic of the form")

#align(center)[#tao-fit-display[#mitex("X = \\mathrm{Main\\ term} + \\mathrm{Siegel\\ correction} + \\mathrm{Better\\ error\\ term}")]]

#text("where ")#mi("{\\mathrm{Better\\ error\\ term}}")#text(" now fluctuates less than the original ")#mi("{\\mathrm{Error\\ term}}")#text(", and in particular can (in some cases) be shown to be lower order than ")#mi("{\\mathrm{Main\\ term}}")#text(", while ")#mi("{\\mathrm{Siegel\\ correction}}")#text(" is a new term that is often explicitly describable in terms of the exceptional character ")#mi("{\\chi}")#text(" associated to the Siegel zero, as well as the location ")#mi("{\\beta}")#text(" of the Siegel zero ")#mi("{L(\\beta,\\chi)=0}")#text(". A typical example is the problem of estimating the sum ")#mi("{\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n)}")#text(" of primes in an arithmetic progression. The ")#link("https://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel–Walfisz theorem")]#text(" gives a bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\varphi(q)} + O_A( x \\log^{-A} x )")]]

#text("for any ")#mi("{A>0}")#text(" (with an ineffective constant); in the regime ")#mi("{q = O(\\log^{O(1)} x)}")#text(" one can improve the error term to ")#mi("{O( x \\exp(-c \\log^{1/2} x) )}")#text(", but for large ")#mi("{q}")#text(" one cannot do better than the Brun–Titchmarsh bound of ")#mi("{O(x / \\varphi(q))}")#text(". However, when there is a Siegel zero ")#mi("{L(\\beta,\\chi)}")#text(" in an appropriate range, we can obtain the refined bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = \\frac{x}{\\varphi(q)} - \\chi(a) 1_{q_0|q} 1_{(a,q)=1} \\frac{x^{\\beta-1}}{\\beta} + O( x \\exp(\\log^{-c} x))")]]

#text("for some ")#mi("{c>0}")#text(", where ")#mi("{q_0}")#text(" is the conductor of ")#mi("{\\chi}")#text("; see e.g., Theorem 5.27 of ")#link("https://zbmath.org/1059.11001")[#text("Iwaniec–Kowalski")]#text(". Thus we see the error term is much improved (and in fact can even be made effective), at the cost of introduicing a Siegel correction term which (for ")#mi("{\\beta}")#text(" close to ")#mi("{1}")#text(" and ")#mi("{x}")#text(" not too large) is of comparable size to the main term, and can either be aligned with or against the main term depending on the sign of ")#mi("{\\chi(a)}")#text(".")

#text("The implications of this refined asymptotic then depend rather crucially on how the Siegel correction term is aligned with the main term, and also whether it is of comparable order or lower order. In many situations (particularly those concerning “average case” problems, in which one wants to understand the behavior for typical choices of parameters), the Siegel correction term ends up being lower order, and so one ends up with the situation described in my initial blog post, where we are able to get the predicted asymptotic ")#mi("{X \\approx \\mathrm{Main\\ term}}")#text(" in the Siegel zero case. However, as pointed out by Granville, there are other situations (particularly those involving “worst case” problems, in which some key parameter can be chosen adversarially) in which the Siegel correction term can align to completely cancel (or to highly reinforce) the main term. In such cases, the Siegel zero becomes a very concrete manifestation of the parity barrier, rather than a means to avoid it. (There is a tiny chance that there may be some sort of “repulsion” phenomenon in which having no semiprimes in ")#mi("{[n-h,n]}")#text(" for one value of ")#mi("{h}")#text(" somehow generates semiprimes in ")#mi("{[n-h^{\\prime},n]}")#text(" for another value of ")#mi("{h^{\\prime}}")#text(", which would allow one to solve the problem without having to directly address the Siegel issue, but I don’t see how two such intervals could “communicate” in order to achieve such a repulsion effect.)")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("Profesor Tao:")

#text("For primes p ≥ 5, they always fall into either p ≡ 1 (mod 6) or p ≡ 5 (mod 6).")

#text("This is because:")

#enum(start: 1, 
[#text("All integers can be expressed as n ≡ 0, 1, 2, 3, 4, or 5 (mod 6).")],
[#text("Among these, the classes n ≡ 0, 2, 3, 4 (mod 6) do not produce primes for")#linebreak()#text("n ≥ 5 (as these classes represent composite numbers like multiples of 2 or 3).")],
[#text("Therefore, for primes p ≥ 5, they must belong to either p ≡ 1 (mod 6) or")#linebreak()#text("p ≡ 5 (mod 6).")]
)

#text("Equidistribution of Primes in Classes 1 and 5 modulo 6")

#text("The primes are roughly equidistributed between the classes 1 and 5 (mod 6) according to the Dirichlet theorem on arithmetic progressions. This theorem asserts that for any two coprime numbers a and m, there are infinitely many primes congruent to a (mod m), and they are asymptotically equally distributed across all valid congruence classes.")

#text("What is the problem with the Parity problem in this particular Sieve Configuration? Thanks for your response.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("use exponential to convert summation to multiplication. And binomial coeffcients.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("Dirichlet’s theorem is proven through the techniques of multiplicative number theory, which are one of the few methods we have that are able to break through the parity barrier, since the parity of number of prime factors of a number (i.e., the Liouville function) is a multiplicative function. Sieve theory on its own has never been able to reproduce Dirichlet’s theorem without such a multiplicative input.")

#text("Unfortunately, this type of result (primes in arithmetic progressions, or more generally mean values of multiplicative functions, or functions closely related to multiplicative functions), are almost the only results for which multiplicative number theory techniques can be directly applied. Finding primes in sets other than arithmetic progressions, for instance, requires other techniques, as most sets do not have the type of multiplicative structure that allows multiplicative number theory methods to be effective.")

#text("It’s also worth noting that Siegel zeroes, if they existed, would *almost* contradict Dirichlet’s theorem; if one had an exceptional character ")#mi("\\chi")#text(" of some conductor ")#mi("q")#text(", then the primitive quadratic residues modulo ")#mi("q")#text(" would contain far fewer primes (in certain regions) than one would expect from Dirichlet’s theorem, and conversely the quadratic non-residues contain about twice as many primes as expected. (One can see vestiges of this effect for instance in Euler’s prime-generating polynomial ")#mi("n^2+n+41")#text(", which initially contains far more primes than one might expect (in particular for all ")#mi("0 \\leq n < 40")#text("), in part due to the very small value of ")#mi("L(1,\\chi)")#text(" when ")#mi("\\chi")#text(" is the quadratic character of conductor equal to the magnitude of the discriminant ")#mi("1-4*41=-163")#text(" of this polynomial.) Indeed, the core of Dirichlet’s theorem is establishing the non-vanishing ")#mi("L(1,\\chi) \\neq 0")#text(", which is a surprisingly delicate task, either requiring tools outside of analytic number theory (such as algebraic number theory), or some rather crude Fourier-analytic or complex analytic results that give fairly weak bounds. Getting a better proof of this non-vanishing is in fact very closely tied to resolving the Siegel zero problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("Thank you Professor! , you touched a critical point ( multiplicative number theory ) we know that there are infinitely many primes congruent to 1 and 5 modulo 6, then let’s make a really bad assumption, all numbers congruent to 1 and 5 are primes, we immediately know that is not the case, because multiplications among prime numbers congruent to 1 and 5 modulo 6 will yield composites also congruent to 1 and 5 modulo 6,( Chen’s Theorem ) then if I continue this multiplications ( using combinatorics ) for every single prime starting from 5 we Sieve Out all primes, indirectly, thanks to the Hyper-exponential growth of this multiplications… then twin primes ( p,p+2 ) are p ≡ 5 (mod 6) & p ≡ 1 (mod 6). Due to the constraints of the Sieve.")

#text("Examples: 5*5=25, 5*7=35, 7*7=49,,,, keep adding primes 11,13… finding all posible multiplications..")

#text("the results are always composites congruent to 1 and 5 this process is infinite and since we always have a new prime either congruent to 1 and 5 appearing we can continuously generating more multiplications among primes. This process gives rise to the pseudo randomness in primes and prime Constellation, I took me 11 years to realize this. But I was worth the effort. ( also cousin primes and sexy primes fit this framework )")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685602")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("The formular after “we can obtain the refined bound” misses two closing brackets at the O(..).")

#emph[#text("[This may be an issue with the size of your device; the brackets do not seem to be missing on my browser – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("A slightly weaker vertion of this problem is to ask if the sequence of “bad numbers” has zero density. Is this version still too difficult for current methods?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685611")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("Yes, this should be well within reach. It is known (from the work of Huxley) that for any ")#mi("1/6 < \\theta < 1")#text(", that almost all intervals ")#mi("[n-n^\\theta, n]")#text(" contains a prime; in fact the recent work of Guth and Maynard have lowered the ")#mi("1/6")#text(" threshold further, to ")#mi("2/15")#text(". The same technology should show, for ")#mi("\\theta")#text(" slightly below ")#mi("1/2")#text(", that almost all such intervals ")#mi("[n-n^\\theta, n]")#text(" should contain semiprimes whose prime factors are at least ")#mi("n^\\theta")#text(", which would imply that almost all numbers are good (and in fact should give the asymptotic ")#mi("f(n) = n + n^{1/2+o(1)}")#text(" for almost all ")#mi("n")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685621")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("Nice! Thanks Professor")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8b7224bf66cc6a43c55125319dcb2a6ebe87c596364e0e68c19dbdd26a5082-279c0f1f91664e6ea3255e450952ee500d1df7cd936254900a1be63360a430c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CKS")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685651")[#strong[#text("CKS")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2024")])]

#text("A bad ")#mi("n")#text(" is of form ")#mi("n=p+1")#text(" for prime ")#mi("p")#text(" so zero density. Numerical computation suggests the largest bad ")#mi("n")#text(" is 8742.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8b7224bf66cc6a43c55125319dcb2a6ebe87c596364e0e68c19dbdd26a5082-279c0f1f91664e6ea3255e450952ee500d1df7cd936254900a1be63360a430c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CKS")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685677")[#strong[#text("CKS")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2024")])]

#text("Two more bad ")#mi("n")#text(" at 267672,267680")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("I am not able to follow all of the arguments in the post because my knowledge of mathematics is limited, but I can’t help but wonder, might one consider ")#strong[#text("F(n) – n → ∞")]#text(" to be representing various ways to sum up towards infinity starting from either 0 (for natural numbers) and 1 (for primes)? Such that ")#strong[#text("F(n) – n → ∞")]#text(" would then mean if taking one particular way to sum up to infinity and subtracting some other plain way to sum up to infinity (like counting n and upwards), you ended up with a notion of a singular infinity on the far right side, and then because the two ways of counting to infinity were different, you ended up with an inequality of sorts that by itself must be infinite when trying to count downwards from an imagined infinity (then either aiming for reaching a 0 for n, or a 1 relying on prime numbers).")

#text("This point just above, about an inequality itself explained as being infinite, I imagine that one might resolve to a mathematical structure by acknowledging that the regularized spacing between n counting 0,1,2,3,4.. equal 1, being congruent with the spacing between every prime. Presumably with the largest primes, this spacing becomes infinitely large, and so this in turn I imagine leads back to this notion of one ending up with a difference if comparing counting number of primes vs counting n. Then, if acknowleding that this inequality, the difference of the two ways of counting numbers (counting primes vs counting n) must be infinitely large, there must be some modulo space that can only exist with an infinite product formula and relying on exponentiation, like with the Langlands program with those peculiar 11’s, 22’s, 33’s and 44s in the exponent (presumably there because of how adding 11 for each step with squaring, is baking in two primes, 2×5 and adding 1, for a total of 11, as if guaranteeing that this multiplication involving accumulative 11’s in the exponents in turn ensured an infinite inequality between two ways of counting numbers. One counting n from 0 to infinity, and one counting down from infinity towards a 1 involving pairs of primes.")

#text("Then I imagine that at the end, counting down from a singular infinity (as if infinity must be a 1dim n number), this must yield a prime number of 2 (the smallest of any prime number, that can only exist as a square root of 2 vs Pythagoras theorem with sides of square root of 1 length), while counting n backwards from infinity goes towards a forever deferred 0 value. Both ways of counting regularized by n equal to being 1 (imagine procedurally squaring largest numbers to infinity and getting 1).")

#text("Presumably, I think what is maintaining this structure of infinite inequalities but regularized to a 1 value, or n, between the two ways of counting n as if same as ")#strong[#text("F(n) – n → ∞")]#text(", is this oscillation between having numbers in dimension 1 and dimension 2 when relying on the infinite product of numbers like with the Langlands program, where I guess ‘q’ equate to being 1, ensuring a balancing act of multiplication and division with infinite sums.")

#text("The particular formula re. Langlands I was referring to, was this:")

#text("q(1-q²) (1-q¹¹)² (1-q²)² (1-q²²)² (1-q³)² (1-q³³)² etc..")

#text("Presumably, the infinite sum here would look like two hardly overlapping squares, each square representing a prime number ensuring paired prime numbers always can be summed to an even integer number more than the number 2, and only overlapping with a shared point, as if the two squares were a non-manifold surface, the shared point being a 1dim value existing in a 2dim structure, this forever smallest point, equating to a diagonal length having a regularized 1 value. And so the hypothenuse, this smallest diagonal itself making up a possible square shape if imagining everything rotating by 45 deg, in turn creating a 2d space, this regularized rotation of 45 deg, then is like a duality that in turn would explain perpetual oscillations between 1 and 2 dimensional number when trying to count towards infinity using exponent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("To add to what I wrote in length above:")

#text("Presumably such a structure of infinite recursion is what makes the imaginary number being the square root of ")#strong[#text("i")]#text(" work with precision and towards infinity, the imaginary number ")#strong[#text("i")]#text(" forcing a two dimensional representation of anything one dimensional, and so a perpetual oscillation betwenn someting point like, and something ring like, and any variant of this. Such a duality also representing a perpetual shadowy half point, a continuous halving, whenever multiplying any numbers I guess.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685622")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("I am reminded of a question I asked in 2016: Let C be a certain collection of integer intervals; does this collection cover almost all natural numbers? I started with C being open intervals of the form (pq – p, pq) with p < q distinct primes, and then added more and more intervals to C and asked the same question.")

#text("it turns out the original and smallest version of C covered all but 400 of the first roughly 10^8 positive integers with the largest uncovered being 33510 ( or near that ). I wonder what statistics are available for F(n).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685635")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2024")])]

#text("Correction to August 20 comment of mine: 493 instead of 400 were uncovered.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685641")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2024")])]

#text("A similar experiment (covering the integers up to 10^7 with open intervals (pq, pq+p) gives 495 uncovered integers, the largest being 267689. Heuristics given by Max Alekseyev last year likely apply to this version and suggest only finitely many uncovered integers. Given that we ask only that p<q be distinct primes, I think this supports the statement that F(n)-n grows without bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8b7224bf66cc6a43c55125319dcb2a6ebe87c596364e0e68c19dbdd26a5082-279c0f1f91664e6ea3255e450952ee500d1df7cd936254900a1be63360a430c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CKS")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685636")[#strong[#text("CKS")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2024")])]

#text("We have ")#mi("F(n) \\ge n")#text(" for all ")#mi("n")#text(". The first question can be reduced elementarily to condition (*) about primes.")

#text("If ")#mi("n")#text(" is odd, then with ")#mi("m=n-1")#text(", ")#mi("m+p(m)=n+1")#text(" so ")#mi("F(n) \\ge n+1")#text(". If ")#mi("n")#text(" is even and ")#mi("m=n-1")#text(" is composite, then ")#mi("m+p(m) \\ge n+2")#text(" so ")#mi("F(n) \\ge n+2")#text(". So we only need to consider the case ")#mi("n=p+1")#text(" for an odd prime ")#mi("p")#text(". In this case with ")#mi("m=n-2")#text(", ")#mi("m+p(m) =n")#text(" so ")#mi("F(n) \\ge n")#text(". So ")#mi("n")#text(" is bad iff ")#mi("F(n)=n")#text(", ")#mi("n=p+1")#text(" and for all ")#mi("1 \\le k \\le \\lfloor p/2 \\rfloor")#text(", ")#mi("p(p-2k) \\le 2k+1")#text(". Numerical computations suggests that this can only hold for ")#mi("p \\le 8741")#text(".")

#text("So it suffices to show that for all prime ")#mi("p > 8741")#text(", (*) there is some composite ")#mi("p-2k")#text(" with least prime divisor greater than ")#mi("2k+1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8b7224bf66cc6a43c55125319dcb2a6ebe87c596364e0e68c19dbdd26a5082-279c0f1f91664e6ea3255e450952ee500d1df7cd936254900a1be63360a430c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CKS")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685652")[#strong[#text("CKS")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2024")])]

#text("For ")#mi("n=p^2+1")#text(" and ")#mi("m=n-1")#text(", ")#mi("F(n)-n \\ge p-2 \\rightarrow \\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685640")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2024")])]

#text("The semiprime version of the problem is equivalent to the claim that for some ")#mi("p<\\sqrt{(}n)")#text(" not dividing ")#mi("n")#text(" we have ")#mi("\\lfloor \\frac{n}{p} \\rfloor")#text(" also a prime. So this problem bears some vague similarity to the twin primes and Goldbach problems in that we have an injective function from natural numbers to natural numbers and we need both the input and output to be prime.")

#text("For the remote possibility of a solution via strong conjectures about the zeta function, an approach to see how remote this is to consider a function field analogue, and use GRH and make strong conjectures about the distribution of function field L-functions, but don’t use other geometric techniques. The point is that the function field setting makes delicate analysis much less delicate.")

#text("The problem I am thinking of is given a monic polynomial ")#mi("f")#text(" to find a polynomial ")#mi("g")#text(" such that the least prime factor of ")#mi("f-g")#text(" has degree greater than the degree of ")#mi("g")#text(". In the semiprime case, we are looking for prime polynomials ")#mi("ab")#text(" with ")#mi("\\mathrm{deg} f-ab< \\mathrm{deg} a \\leq \\mathrm{deg} b")#text(". The count of such things with ")#mi("f")#text(" of degree ")#mi("n")#text(" and ")#mi("a")#text(" of degree ")#mi("m")#text(" looks like a sum over “short interval” characters of conductor ")#mi("\\leq n-m+1")#text(" of the ")#mi("m")#text("th coefficient of the logarithm of the L-function of the character times the ")#mi("n-m")#text("th coefficient of the logarithm. The trivial character gives the main term of size ")#mi("q^n")#text(" and the other ")#mi("q^{n-m}-1")#text(" characters each contribute an error term of size at most ")#mi("(n-m-1)^2 q^{n/2}")#text(". That’s a purely GRH bound. Getting rid of the ")#mi("(n-m-1)^2")#text(" factors would almost give victory (we’d lose since this is calculating with the von Mangoldt function and we still have to subtract off prime poewrs) so we need to do a bit better than that.")

#text("If we make a super-strong assumption that these L-functions behave exactly like random samples from a GUE distribution then I guess it’s OK as we’ll get square-root cancellation in the sum over L-functions. However, if we only make the weaker assumption that the size of the contribution of each L-function follows a GUE distribution, without assuming anything about it’s phase, we’re in trouble. I think in that case we only get an improvement from ")#mi("(n-m-1)^2")#text(" to about ")#mi("(n-m-1)")#text(" since the late coefficients of the logarithm of the characteristic polynomial of a unitary random matrix only exhibit square-root cancellation when expressed as a sum over the eigenvalues rather than the beyond-square-root cancellation that the early coefficients do.")

#text("In terms of the Riemann zeta function the different characters correspond to regions of the critical line that are a distance of more than 1 apart. So I also don’t think a version of the GUE hypothesis that mandates good behavior only at small scales, or even at O(1) scales, will be enough (unless it’s strong enough to pin down the distribution of phases) but a hypothesis that controls behavior at larger scales (maybe the ratios conjecture or some variant of it) might be.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2024")])]

#text("Thanks for the analysis of the function field case. I agree with your conclusion that standard GUE type hypotheses are probably not quite strong enough to completely close the gap between what one can prove and one wants to show here, although it does seem to narrow that gap somewhat.")

#text("There is still the outside chance that the ability to work with the best-case ")#mi("m")#text(" rather than the worst-case ")#mi("m")#text(" might possibly help narrow the gap even further, but I don’t see a mechanism to exploiting the ")#mi("m")#text(" parameter (and likely it will still not be enough, saving an additional factor of maybe ")#mi("\\sqrt{n}")#text(" perhaps, at best).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("I think two more of your posts deserve to get the Paul Erdos tag. the one about #437 and your paper on #442.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2024")])]

#text("wow!!!")

#text("THE LINEAR INDEPENDENCE OF 1, ζ(2), AND L(2, χ−3)")

#text("FRANK CALEGARI, VESSELIN DIMITROV, AND YUNQING TANG")

#text("Abstract. We prove the irrationality of the classical Dirichlet L-value")

#link("https://arxiv.org/pdf/2408.15403")[#text("https://arxiv.org/pdf/2408.15403")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")])]

#text("Terry, could you comment on the preprint above? (THE LINEAR INDEPENDENCE OF 1, ζ(2), AND L(2, χ−3)). It appears to be a breakthrough in Diophantine approximation ‘à la Apéry’. However, it’s still unclear to me how they were able to exploit the analyticity of Zagier sequences (the arithmetic holonomy bound), even though these sequences don’t directly provide a fast convergent approximation to L(2, χ−3). Could this technique be promising for proving irrationality of other periods?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-685693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")])]

#text("I would recommend Calegari’s lecture on this from June at ")#link("https://www.youtube.com/watch?v=znBdPEyDScY")[#text("https://www.youtube.com/watch?v=znBdPEyDScY")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/19/erdos-problem-385-the-parity-problem-and-siegel-zeroes/#comment-688565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2025")])]

#text("If we know how to count pi(n) (number of primes below n) and sum_{i=1}^n gcd(i,n) both in polylog(n) (say O(log^2(n)) with a reasonable constant factor) time could we get any more closer to the truth or invalidity of Siegel zeros, Riemann Hypothesis etc? This can number of primes below say 10^100000 in a reasonable time. I read somewhere that failure of RH could be a larger number phenomenon but cannot find the reference nor any reference to Siegel zeros.")
]
