// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/
// Converted to Typst by tao2typ: "2026-10-14T16:36:12.844024+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 6: The inverse conjecture for the Gowers norm II.  The integer case", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II.  The integer case")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/")[#text("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/")[#text("Notes 5")]#text(", we saw that the Gowers uniformity norms on vector spaces ")#mi("{{\\bf F}^n}")#text(" in high characteristic were controlled by classical polynomial phases ")#mi("{e(\\phi)}")#text(".")

#text("Now we study the analogous situation on cyclic groups ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". Here, there is an unexpected surprise: the polynomial phases (classical or otherwise) are no longer sufficient to control the Gowers norms ")#mi("{U^{s+1}({\\bf Z}/N{\\bf Z})}")#text(" once ")#mi("{s}")#text(" exceeds ")#mi("{1}")#text(". To resolve this problem, one must enlarge the space of polynomials to a larger class. It turns out that there are at least three closely related options for this class: the ")#emph[#text("local polynomials")]#text(", the ")#emph[#text("bracket polynomials")]#text(", and the ")#emph[#text("nilsequences")]#text(". Each of the three classes has its own strengths and weaknesses, but in my opinion the nilsequences seem to be the most natural class, due to the rich algebraic and dynamical structure coming from the nilpotent Lie group undergirding such sequences. For reasons of space we shall focus primarily on the nilsequence viewpoint here.")

#text("Traditionally, nilsequences have been defined in terms of linear orbits ")#mi("{n \\mapsto g^n x}")#text(" on nilmanifolds ")#mi("{G/\\Gamma}")#text("; however, in recent years it has been realised that it is convenient for technical reasons (particularly for the quantitative “single-scale” theory) to generalise this setup to that of ")#emph[#text("polynomial")]#text(" orbits ")#mi("{n \\mapsto g(n) \\Gamma}")#text(", and this is the perspective we will take here.")

#text("A polynomial phase ")#mi("{n \\mapsto e(\\phi(n))}")#text(" on a finite abelian group ")#mi("{H}")#text(" is formed by starting with a polynomial ")#mi("{\\phi: H \\rightarrow {\\bf R}/{\\bf Z}}")#text(" to the unit circle, and then composing it with the exponential function ")#mi("{e: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(". To create a nilsequence ")#mi("{n \\mapsto F(g(n) \\Gamma)}")#text(", we generalise this construction by starting with a polynomial ")#mi("{g \\Gamma: H \\rightarrow G/\\Gamma}")#text(" into a ")#emph[#text("nilmanifold")]#text(" ")#mi("{G/\\Gamma}")#text(", and then composing this with a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(". (The Lipschitz regularity class is convenient for minor technical reasons, but one could also use other regularity classes here if desired.) These classes of sequences certainly include the polynomial phases, but are somewhat more general; for instance, they ")#emph[#text("almost")]#text(" include ")#emph[#text("bracket polynomial")]#text(" phases such as ")#mi("{n \\mapsto e( \\lfloor \\alpha n \\rfloor \\beta n )}")#text(". (The “almost” here is because the relevant functions ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" involved are only piecewise Lipschitz rather than Lipschitz, but this is primarily a technical issue and one should view bracket polynomial phases as “morally” being nilsequences.)")

#text("In these notes we set out the basic theory for these nilsequences, including their equidistribution theory (which generalises the equidistribution theory of polynomial flows on tori from ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(") and show that they are indeed obstructions to the Gowers norm being small. This leads to the ")#emph[#text("inverse conjecture for the Gowers norms")]#text(" that shows that the Gowers norms on cyclic groups are indeed controlled by these sequences.")

#metadata(none) <tao-c8731365072b71b57b7e>

#heading(level: 1)[#strong[#text(" — 1. General theory of polynomial maps — ")]]

#text("In previous notes, we defined the notion of a (non-classical) polynomial map ")#mi("{\\phi}")#text(" of degree at most ")#mi("{d}")#text(" between two additive groups ")#mi("{H, G}")#text(", to be a map ")#mi("{\\phi: H \\rightarrow G}")#text(" obeying the identity")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{d+1}} \\phi(x) = 0")]]

#text("for all ")#mi("{x,h_1,\\ldots,h_{d+1} \\in H}")#text(", where ")#mi("{\\partial_h \\phi(x) := \\phi(x+h)-\\phi(x)}")#text(" is the additive discrete derivative operator.")

#text("There is another way to view this concept. For any ")#mi("{k,d \\geq 0}")#text(", define the ")#emph[#text("Host-Kra group")]#text(" ")#mi("{HK^{k}(H, \\leq d)}")#text(" of ")#mi("{H}")#text(" of dimension ")#mi("{k}")#text(" and degree ")#mi("{d}")#text(" to be the subgroup of ")#mi("{H^{\\{0,1\\}^{d}}}")#text(" consisting of all tuples ")#mi("{(x_\\omega)_{\\omega \\in \\{0,1\\}^k}}")#text(" obeying the constraints")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega \\in F} (-1)^{\\left|\\omega\\right|} x_\\omega = 0", block: true)]]

#text("for all faces ")#mi("{F}")#text(" of the unit cube ")#mi("{\\{0,1\\}^k}")#text(" of dimension at least ")#mi("{d+1}")#text(", where ")#tao-math("{\\left|(\\omega_1,\\ldots,\\omega_k)\\right| := \\omega_1+\\ldots+\\omega_k}", block: false)#text(". (These constraints are of course trivial if ")#mi("{k \\leq d}")#text(".) A ")#mi("{r}")#text("-dimensional face of the unit cube ")#mi("{\\{0,1\\}^k}")#text(" is of course formed by freezing ")#mi("{k-r}")#text(" of the coordinates to a fixed value in ")#mi("{\\{0,1\\}}")#text(", and letting the remaining ")#mi("{r}")#text(" coordinates vary freely in ")#mi("{\\{0,1\\}}")#text(".")

#text("Thus for instance ")#mi("{HK^2(H, \\leq 1)}")#text(" is (essentially) space of parallelograms ")#mi("{(x,x+h,x+k,x+h+k)}")#text(" in ")#mi("{H^4}")#text(", while ")#mi("{HK^2(H,\\leq 0)}")#text(" is the diagonal group ")#mi("{\\{ (x,x,x,x): x \\in H^4 \\}}")#text(", and ")#mi("{HK^2(H,\\leq 2)}")#text(" is all of ")#mi("{H^4}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-46273d7c3f42babd4165>#text(" Let ")#mi("{\\phi: H \\rightarrow G}")#text(" be a map between additive groups, and let ")#mi("{k > d \\geq 0}")#text(". Show that ")#mi("{\\phi}")#text(" is a (non-classical) polynomial of degree at most ")#mi("{d}")#text(" if it maps ")#mi("{HK^k(H,\\leq 1)}")#text(" to ")#mi("{HK^k(G,\\leq d)}")#text(", i.e. that ")#mi("{(\\phi(x_\\omega))_{\\omega \\in \\{0,1\\}^k} \\in HK^{k}(G,\\leq d)}")#text(" whenever ")#mi("{(x_\\omega)_{\\omega \\in \\{0,1\\}^{k}} \\in HK^{k}(H,\\leq 1)}")#text(".")
]

#text("It turns out (somewhat remarkably) that these notions can be satisfactorily generalised to non-abelian setting, this was first observed by Leibman (in ")#link("http://www.ams.org/mathscinet-getitem?mr=1608723")[#text("these")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1910931")[#text("papers")]#text(", and also later by personal communication, in which the role of the Host-Kra group was emphasised). The (now multiplicative) groups ")#mi("{H,G}")#text(" need to be equipped with an additional structure, namely that of a ")#emph[#text("filtration")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Filtration)")]#text(" A ")#emph[#text("filtration")]#text(" on a multiplicative group ")#mi("{G}")#text(" is a family ")#mi("{(G_{\\geq i})_{i=0}^\\infty}")#text(" of subgroups of ")#mi("{G}")#text(" obeying the nesting property")

#align(center)[#tao-fit-display[#mitex("G \\geq G_{\\geq 0} \\geq G_{\\geq 1} \\geq \\ldots")]]

#text("and the filtration property")

#align(center)[#tao-fit-display[#mitex("[G_{\\geq i}, G_{\\geq j}] \\subset G_{\\geq i+j}")]]

#text("for all ")#mi("{i,j \\geq 0}")#text(", where ")#mi("{[H,K]}")#text(" is the group generated by ")#mi("{\\{ [h,k]: h \\in H, k \\in K \\}}")#text(", where ")#mi("{[h,k] := hkh^{-1}k^{-1}}")#text(" is the commutator of ")#mi("{h}")#text(" and ")#mi("{k}")#text(". We will refer to the pair ")#mi("{G_\\bullet = (G,(G_{\\geq i})_{i=0}^\\infty)}")#text(" as a ")#emph[#text("filtered group")]#text(". We say that an element ")#mi("{g}")#text(" of ")#mi("{G}")#text(" has ")#emph[#text("degree ")#mi("{\\geq i}")]#text(" if it belongs to ")#mi("{G_{\\geq i}}")#text(", thus for instance a degree ")#mi("{\\geq i}")#text(" and degree ")#mi("{\\geq j}")#text(" element will commute modulo ")#mi("{\\geq i+j}")#text(" errors.")
]

#text("In practice we usually have ")#mi("{G_{\\geq 0} = G}")#text(". As such, we see that ")#mi("{[G, G_{\\geq j}] \\subset G_{\\geq j}}")#text(" for all ")#mi("{j}")#text(", and so all the ")#mi("{G_{\\geq j}}")#text(" are normal subgroups of ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Define the ")#link("http://en.wikipedia.org/wiki/Central_series#Lower_central_series")[#text("lower central series")]

#align(center)[#tao-fit-display[#mitex("G = G_0 = G_1 \\geq G_2 \\geq \\ldots")]]

#text("of a group ")#mi("{G}")#text(" by setting ")#mi("{G_0, G_1 := G}")#text(" and ")#mi("{G_{i+1} := [G,G_i]}")#text(" for ")#mi("{i \\geq 1}")#text(". Show that the lower central series ")#mi("{(G_j)_{j =0}^\\infty}")#text(" is a filtration of ")#mi("{G}")#text(". Furthermore, show that the lower central series is the minimal filtration that starts at ")#mi("{G}")#text(", in the sense that if ")#mi("{(G^{\\prime}_{\\geq j})_{j=0}^\\infty}")#text(" is any other filtration with ")#mi("{G^{\\prime}_{\\geq 0}=G^{\\prime}_{\\geq 1}=G}")#text(", then ")#mi("{G^{\\prime}_{\\geq j} \\supset G_{\\geq j}}")#text(" for all ")#mi("{j}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" If ")#mi("{G}")#text(" is an abelian group, and ")#mi("{d \\geq 0}")#text(", we define the ")#emph[#text("degree ")#mi("{d}")]#text(" filtration ")#mi("{(G,\\leq d)}")#text(" on ")#mi("{G}")#text(" by setting ")#mi("{G_{\\geq i} := G}")#text(" if ")#mi("{i \\leq d}")#text(" and ")#mi("{G_{\\geq i} = \\{\\text{id}\\}}")#text(" for ")#mi("{i>d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-ecd3fad7a4d35d7130c6>#text(" If ")#mi("{G_\\bullet=(G,(G_{\\geq i})_{i=0}^\\infty)}")#text(" is a filtered group, and ")#mi("{k \\geq 0}")#text(", we define the shifted filtered group ")#mi("{G_\\bullet^{+k} := (G,(G_{\\geq i+k})_{i=0}^\\infty)}")#text("; this is clearly again a filtered group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Host-Kra groups)")]#text(" ")#metadata(none) <tao-710467e6f41f33fd988f>#text(" Let ")#mi("{G_\\bullet=(G,(G_{\\geq i})_{i=0}^\\infty)}")#text(" be a filtered group, and let ")#mi("{k \\geq 0}")#text(" be an integer. The ")#emph[#text("Host-Kra group")]#text(" ")#mi("{HK^k(G_\\bullet)}")#text(" is the subgroup of ")#mi("{G^{\\{0,1\\}^k}}")#text(" generated by the elements ")#mi("{g_F}")#text(" with ")#mi("{F}")#text(" an arbitrary face in ")#mi("{\\{0,1\\}^k}")#text(" and ")#mi("{g}")#text(" an element of ")#mi("{G_{\\geq k - \\text{dim}(F)}}")#text(", where ")#mi("{g_F}")#text(" is the element of ")#mi("{G^{\\{0,1\\}^k}}")#text(" whose coordinate at ")#mi("{\\omega}")#text(" is equal to ")#mi("{g}")#text(" when ")#mi("{\\omega \\in F}")#text(" and equal to ")#mi("{\\{\\text{id}\\}}")#text(" otherwise.")
]

#text("From construction we see that the Host-Kra group is symmetric with respect to the symmetry group ")#mi("{S_k \\ltimes ({\\bf Z}/2{\\bf Z})^k}")#text(" of the unit cube ")#mi("{\\{0,1\\}^k}")#text(". We will use these symmetries implicitly in the sequel without further comment.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Let us parameterise an element of ")#mi("{G^{\\{0,1\\}^2}}")#text(" as ")#mi("{(g_{00}, g_{01}, g_{10}, g_{11})}")#text(". Then ")#mi("{HK^2(G)}")#text(" is generated by elements of the form ")#mi("{(g_0,g_0,g_0,g_0)}")#text(" for ")#mi("{g_0 \\in G_{\\geq 0}}")#text(", ")#mi("{(\\text{id},\\text{id},g_1,g_1)}")#text(" and ")#mi("{(\\text{id},g_1,\\text{id},g_1)}")#text(", and ")#mi("{(\\text{id},\\text{id},\\text{id},g_2)}")#text(" for ")#mi("{g_0 \\in G_{\\geq 0}, g_1 \\in G_{\\geq 1}, g_2 \\in G_{\\geq 2}}")#text(". (This does not cover all the possible faces of ")#mi("{\\{0,1\\}^2}")#text(", but it is easy to see that the remaining faces are redundant.) In other words, ")#mi("{HK^2(G)}")#text(" consists of all group elements of the form ")#mi("{(g_0,g_0 g_1, g_0 g^{\\prime}_1, g_0 g_1 g^{\\prime}_1 g_2)}")#text(", where ")#mi("{g_0 \\in G_{\\geq 0}}")#text(", ")#mi("{g_1,g^{\\prime}_1 \\in G_{\\geq 1}}")#text(", and ")#mi("{g_2 \\in G_{\\geq 2}}")#text(". This example is generalised in the exercise below.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-39e741eddb03e3118da6>#text(" Define a ")#emph[#text("lower face")]#text(" to be a face of a discrete cube ")#mi("{\\{0,1\\}^k}")#text(" in which all the frozen coefficients are equal to ")#mi("{0}")#text(". Let us order the lower faces as ")#mi("{F_1,\\ldots,F_{2^k-1}}")#text(" in such a way that ")#mi("{i \\geq j}")#text(" whenever ")#mi("{F_i}")#text(" is a subface of ")#mi("{F_j}")#text(". Let ")#mi("{G_\\bullet}")#text(" be a filtered group. Show that every element of ")#mi("{HK^k(G_\\bullet)}")#text(" has a unique representation of the form ")#mi("{\\prod_{i=0}^{2^{k-1}} (g_i)_{F_i}}")#text(", where ")#mi("{g_i \\in G_{\\geq k - \\text{dim}(F_i)}}")#text(" and the product is taken from left to right (say).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" If ")#mi("{G}")#text(" is an abelian group, show that the group ")#mi("{HK^k(G, \\leq d)}")#text(" defined in Definition ")#link(<tao-710467e6f41f33fd988f>)[#text("2")]#text(" agrees with the group defined at the beginning of this section for additive groups (after transcribing the former to multiplicative notation).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-fd13d46bad4ba114699a>#text(" Let ")#mi("{G_\\bullet}")#text(" be a filtered group. Let ")#mi("{F}")#text(" be an ")#mi("{r}")#text("-dimensional face of ")#mi("{\\{0,1\\}^k}")#text(". Identifying ")#mi("{F}")#text(" with ")#mi("{\\{0,1\\}^r}")#text(" in an obvious manner, we then obtain a restriction homomorphism from ")#mi("{G^{\\{0,1\\}^k}}")#text(" with ")#mi("{G^F \\equiv G^{\\{0,1\\}^r}}")#text(". Show that the restriction of any element of ")#mi("{HK^k(G_\\bullet)}")#text(" to ")#mi("{G^{\\{0,1\\}^r}}")#text(" then lies in ")#mi("{HK^r(G_\\bullet)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-bd36e2455121f8ffec77>#text(" Let ")#mi("{G_\\bullet}")#text(" be a filtered group, let ")#mi("{k \\geq 0}")#text(" and ")#mi("{l \\geq 1}")#text(" be integers, and let ")#mi("{g = (g_\\omega)_{\\omega \\in \\{0,1\\}^k}}")#text(" and ")#mi("{h = (h_\\omega)_{\\omega \\in \\{0,1\\}^k}}")#text(" be elements of ")#mi("{G^{\\{0,1\\}^k}}")#text(". Let ")#mi("{f = (f_\\omega)_{\\omega \\in \\{0,1\\}^{k+l}}}")#text(" be the element of ")#mi("{G^{\\{0,1\\}^{k+l}}}")#text(" defined by setting ")#mi("{f_{\\omega_k,\\omega_l}}")#text(" for ")#mi("{\\omega_k \\in \\{0,1\\}^k, \\omega_l \\in \\{0,1\\}^l}")#text(" to equal ")#mi("{g_{\\omega_k}}")#text(" for ")#mi("{\\omega_l \\neq (1,\\ldots,1)}")#text(", and equal to ")#mi("{g_{\\omega_k} h_{\\omega_k}}")#text(" otherwise. Show that ")#mi("{f \\in HK^{k+l}(G_\\bullet)}")#text(" if and only if ")#mi("{g \\in HK^k(G_\\bullet)}")#text(" and ")#mi("{h \\in HK^k(G_\\bullet^{+l})}")#text(", where ")#mi("{G_\\bullet^{+l}}")#text(" is defined in Example ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("2")]#text(". (")#emph[#text("Hint:")]#text(" use Exercises ")#link(<tao-39e741eddb03e3118da6>)[#text("3")]#text(", ")#link(<tao-fd13d46bad4ba114699a>)[#text("5")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-6ab11babbb223998dde1>#text(" Let ")#mi("{G_\\bullet}")#text(" be a filtered group, let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{g = (g_\\omega)_{\\omega \\in \\{0,1\\}^k}}")#text(" be an element of ")#mi("{G^{\\{0,1\\}^k}}")#text(". We define the ")#emph[#text("derivative")]#text(" ")#mi("{\\partial_1 g \\in G^{\\{0,1\\}^{k-1}}}")#text(" in the first variable to be the tuple ")#mi("{(g_{\\omega,1} g_{\\omega,0}^{-1})_{\\omega \\in \\{0,1\\}^{k-1}}}")#text(". Show that ")#mi("{g \\in HK^k(G_\\bullet)}")#text(" if and only if the restriction of ")#mi("{g}")#text(" to ")#mi("{\\{0,1\\}^{k-1}}")#text(" lies in ")#mi("{HK^{k-1}(G_\\bullet)}")#text(" and ")#mi("{\\partial_1 g}")#text(" lies in ")#mi("{HK^k(G_\\bullet^{+1})}")#text(", where ")#mi("{G_\\bullet^{+1}}")#text(" is defined in Example ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The the Host-Kra groups of a filtered group in fact form a ")#emph[#text("cubic complex")]#text(", a concept used in topology; but we will not pursue this connection here.")
]

#text("In analogy with Exercise ")#link(<tao-46273d7c3f42babd4165>)[#text("1")]#text(", we can now define the general notion of a polynomial map:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3")]#text(" A map ")#mi("{\\phi: H \\rightarrow G}")#text(" between two filtered groups ")#mi("{H_\\bullet, G_\\bullet}")#text(" is said to be ")#emph[#text("polynomial")]#text(" if it maps ")#mi("{HK^k(H_\\bullet)}")#text(" to ")#mi("{HK^k(G_\\bullet)}")#text(" for each ")#mi("{k \\geq 0}")#text(". The space of all such maps is denoted ")#mi("{\\text{Poly}(H_\\bullet \\rightarrow G_\\bullet)}")#text(".")
]

#text("Since ")#mi("{HK^k(H_\\bullet), HK^k(G_\\bullet)}")#text(" are groups, we immediately obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Lazard-Leibman theorem)")]#text(" ")#mi("{\\text{Poly}(H_\\bullet \\rightarrow G_\\bullet)}")#text(" forms a group under pointwise multiplication.")
]

#text("(From our choice of definitions, this theorem is a triviality, but the theorem is less trivial when using an alternate but non-trivially equivalent definition of a polynomial, which we will give shortly.) In a similar spirit, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Filtered groups and polynomial maps form a category)")]#text(" If ")#mi("{\\phi: H \\rightarrow G}")#text(" and ")#mi("{\\psi: G \\rightarrow K}")#text(" are polynomial maps between filtered groups ")#mi("{H_\\bullet, G_\\bullet, K_\\bullet}")#text(", then ")#mi("{\\psi \\circ \\phi: H \\rightarrow K}")#text(" is also a polynomial map.")
]

#text("We can also give some basic examples of polynomial maps. Any constant map from ")#mi("{H}")#text(" to ")#mi("{G}")#text(" taking values in ")#mi("{G_{\\geq 0}}")#text(" is polynomial, as is any map ")#mi("{\\phi: H \\rightarrow G}")#text(" which is a ")#emph[#text("filtered homomorphism")]#text(" in the sense that it is a homomorphism from ")#mi("{H_{\\geq i}}")#text(" to ")#mi("{G_{\\geq i}}")#text(" for any ")#mi("{i \\geq 0}")#text(".")

#text("Now we turn to an alternate definition of a polynomial map. For any ")#mi("{h \\in H}")#text(" and any map ")#mi("{\\phi: H \\rightarrow G}")#text(" Define the ")#emph[#text("multiplicative derivative")]#text(" ")#mi("{\\Delta_h \\phi: H \\rightarrow G}")#text(" by the formula ")#mi("{\\Delta_h \\phi(x) := \\phi(hx) \\phi(x)^{-1}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Alternate description of polynomials)")]#text(" Let ")#mi("{\\phi: H \\rightarrow G}")#text(" be a map between two filtered groups ")#mi("{H, G}")#text(". Then ")#mi("{\\phi}")#text(" is polynomial if and only if, for any ")#mi("{i_1,\\ldots,i_m \\geq 0}")#text(", ")#mi("{x \\in H_{\\geq 0}}")#text(", and ")#mi("{h_j \\in H_{\\geq i_j}}")#text(" for ")#mi("{j=1,\\ldots,m}")#text(", one has ")#mi("{\\Delta_{h_1} \\ldots \\Delta_{h_m} \\phi(x) \\in G_{\\geq i_1+\\ldots+i_m}}")#text(".")
]

#text("In particular, from Exercise ")#link(<tao-46273d7c3f42babd4165>)[#text("1")]#text(", we see that a non-classical polynomial of degree ")#mi("{d}")#text(" from one additive group ")#mi("{H}")#text(" to another ")#mi("{G}")#text(" is the same thing as a polynomial map from ")#mi("{(H,\\leq 1)}")#text(" to ")#mi("{(G,\\leq d)}")#text(". More generally, a ")#mi("{\\phi}")#text(" map from ")#mi("{(H,\\leq 1)}")#text(" to a filtered group ")#mi("{G_\\bullet}")#text(" is polynomial if and only if")

#align(center)[#tao-fit-display[#mitex("\\Delta_{h_1} \\ldots \\Delta_{h_i} \\phi(x) \\in G_{\\geq i}")]]

#text("for all ")#mi("{i \\geq 0}")#text(" and ")#mi("{x,h_1,\\ldots,h_i \\in H}")#text(".")

#emph[#text("Proof:")]#text(" We first prove the “only if” direction. It is clear (by using ")#mi("{0}")#text("-dimensional cubes) that a polynomial map must map ")#mi("{H_{\\geq 0}}")#text(" to ")#mi("{G_{\\geq 0}}")#text(". To obtain the remaining cases, it suffices by induction on ")#mi("{m}")#text(" to show that if ")#mi("{\\phi}")#text(" is polynomial from ")#mi("{H_\\bullet}")#text(" to ")#mi("{G_\\bullet}")#text(", and ")#mi("{h \\in H_{\\geq i}}")#text(" for some ")#mi("{i \\geq 0}")#text(", then ")#mi("{\\Delta_h \\phi}")#text(" is polynomial from ")#mi("{H_\\bullet}")#text(" to ")#mi("{G_\\bullet^{+i}}")#text(". But this is easily seen from Exercise ")#link(<tao-6ab11babbb223998dde1>)[#text("7")]#text(".")

#text("Now we establish the “if” direction. We need to show that ")#mi("{\\phi}")#text(" maps ")#mi("{HK^k(H_\\bullet)}")#text(" to ")#mi("{HK^k(G_\\bullet)}")#text(" for each ")#mi("{k}")#text(". We establish this by induction on ")#mi("{k}")#text(". The case ")#mi("{k=0}")#text(" is trivial, so suppose that ")#mi("{k \\geq 1}")#text(" and that the claim has already been estabilshed for all smaller values of ")#mi("{k}")#text(".")

#text("Let ")#mi("{h \\in HK^k(H_\\bullet)}")#text(". We split ")#mi("{H^{\\{0,1\\}^k}}")#text(" as ")#mi("{H^{\\{0,1\\}^{k-1}} \\times H^{\\{0,1\\}^{k-1}}}")#text(". From Exercise ")#link(<tao-6ab11babbb223998dde1>)[#text("7")]#text(" we see that we can write ")#mi("{h = (h_0, h_1 h_0)}")#text(" where ")#mi("{h_0 \\in HK^{k-1}(H_\\bullet)}")#text(" and ")#mi("{h_1 \\in HK^{k-1}(H_\\bullet^{+1})}")#text(", thus ")#mi("{\\phi(h) = (\\phi(h_0), \\phi(h_1 h_0))}")#text(" (extending ")#mi("{\\phi}")#text(" to act on ")#mi("{H^{\\{0,1\\}^{k-1}}}")#text(" or ")#mi("{H^{\\{0,1\\}^k}}")#text(" in the obvious manner). By induction hypothesis, ")#mi("{\\phi(h_0) \\in HK^{k-1}(G_\\bullet)}")#text(", so by Exercise ")#link(<tao-6ab11babbb223998dde1>)[#text("7")]#text(", it suffices to show that ")#mi("{\\phi(h_1 h_0) \\phi^{-1}(h_0) \\in HK^{k-1}(G_\\bullet^{+1})}")#text(".")

#text("By telescoping series, it suffices to establish this when ")#mi("{h_1 = h_F}")#text(" for some face ")#mi("{F}")#text(" of some dimension ")#mi("{r}")#text(" in ")#mi("{\\{0,1\\}^{k-1}}")#text(" and some ")#mi("{h \\in H_{\\geq k-r}}")#text(", as these elements generate ")#mi("{HK^{k-1}(H_\\bullet^{+1})}")#text(". But then ")#mi("{\\phi(h_1 h_0) \\phi^{-1}(h_0)}")#text(" vanishes outside of ")#mi("{F}")#text(" and is equal to ")#mi("{\\Delta_{h_1} \\phi(h_0)}")#text(" on ")#mi("{F}")#text(", so by Exercise ")#link(<tao-bd36e2455121f8ffec77>)[#text("6")]#text(" it will suffice to show that ")#mi("{\\Delta_{h_1} \\phi(h^{\\prime}_0) \\in HK^{r}(G_\\bullet^{+k-r})}")#text(", where ")#mi("{h^{\\prime}_0}")#text(" is ")#mi("{h_0}")#text(" restricted to ")#mi("{F}")#text(" (which one then identifies with ")#mi("{\\{0,1\\}^r}")#text("). But by the induction hypothesis, ")#mi("{\\Delta_{h_1} \\phi}")#text(" maps ")#mi("{HK^r(H_\\bullet)}")#text(" to ")#mi("{HK^r(H_\\bullet^{+k-r})}")#text(", and the claim then follows from Exercise ")#link(<tao-fd13d46bad4ba114699a>)[#text("5")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{i_1,\\ldots,i_k \\geq 0}")#text(" be integers. If ")#mi("{G_\\bullet}")#text(" is a filtered group, define ")#mi("{HK^{(i_1,\\ldots,i_k)}(G_\\bullet)}")#text(" to be the subgroup of ")#mi("{G^{\\{0,1\\}^k}}")#text(" generated by the elements ")#mi("{g_F}")#text(", where ")#mi("{F}")#text(" ranges over all faces of ")#mi("{\\{0,1\\}^k}")#text(" and ")#mi("{g \\in G_{\\geq i_{j_1}+\\ldots+i_{j_r}}}")#text(", where ")#mi("{1 \\leq j_1 < \\ldots < j_r \\leq k}")#text(" are the coordinates of ")#mi("{F}")#text(" that are frozen. This generalises the Host-Kra groups ")#mi("{HK^k(G_\\bullet)}")#text(", which correspond to the case ")#mi("{i_1=\\ldots=i_k=1}")#text(". Show that if ")#mi("{\\phi}")#text(" is a polynomial map from ")#mi("{H_\\bullet}")#text(" to ")#mi("{G_\\bullet}")#text(", then ")#mi("{\\phi}")#text(" maps ")#mi("{HK^{(i_1,\\ldots,i_k)}(H_\\bullet)}")#text(" to ")#mi("{HK^{(i_1,\\ldots,i_k)}(G_\\bullet)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Suppose that ")#mi("{\\phi: H \\rightarrow G}")#text(" is a non-classical polynomial of degree ")#mi("{\\leq d}")#text(" from one additive group to another. Show that ")#mi("{\\phi}")#text(" is a polynomial map from ")#mi("{(H,\\leq m)}")#text(" to ")#mi("{(G,\\leq dm)}")#text(" for every ")#mi("{m \\geq 1}")#text(". Conclude in particular that the composition of a non-classical polynomial of degree ")#mi("{\\leq d}")#text(" and a non-classical polynomial of degree ")#mi("{\\leq d^{\\prime}}")#text(" is a non-classical polynomial of degree ")#mi("{\\leq dd^{\\prime}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{\\phi_1: H \\rightarrow G_1}")#text(", ")#mi("{\\phi_2: H \\rightarrow G_2}")#text(" be non-classical polynomials of degrees ")#mi("{\\leq d_1}")#text(", ")#mi("{\\leq d_2}")#text(" respectively between additive groups ")#mi("{H, G_1, G_2}")#text(", and let ")#mi("{B: G_1 \\times G_2 \\rightarrow G}")#text(" be a bihomomorphism to another additive group (i.e. ")#mi("{B}")#text(" is a homomorphism in each variable separately). Show that ")#mi("{B(\\phi_1,\\phi_2): H \\rightarrow G}")#text(" is a non-classical polynomial of degree ")#mi("{\\leq d_1+d_2}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Nilsequences — ")]]

#text("We now specialise the above theory of polynomial maps ")#mi("{\\phi: H \\rightarrow G}")#text(" to the case when ")#mi("{H}")#text(" is just the integers ")#mi("{{\\bf Z} = ({\\bf Z},\\leq 1)}")#text(" (viewed additively) and ")#mi("{G}")#text(" is a nilpotent group. Recall that a group ")#mi("{G}")#text(" is ")#emph[#text("nilpotent")]#text(" of step at most ")#mi("{s}")#text(" if the ")#mi("{(s+1)^{th}}")#text(" group ")#mi("{G_{s+1}}")#text(" in the lower central series vanishes; thus for instance a group is nilpotent of step at most ")#mi("{1}")#text(" if and only if it is abelian. Analogously, let us call a filtered group ")#mi("{G_\\bullet}")#text(" ")#emph[#text("nilpotent")]#text(" of degree at most ")#mi("{s}")#text(" if ")#mi("{G}")#text(" is nilpotent and ")#mi("{G_{\\geq s+1}}")#text(" vanishes. Note that if ")#mi("{G_{\\geq 1} = G}")#text(" and ")#mi("{G_\\bullet}")#text(" is nilpotent of degree at most ")#mi("{s}")#text(", then ")#mi("{G}")#text(" is nilpotent of step at most ")#mi("{s}")#text(". On the other hand, the degree of a filtered group can exceed the step; for instance, given an additive group ")#mi("{G}")#text(" and an integer ")#mi("{d \\geq 1}")#text(", ")#mi("{(G,\\leq d)}")#text(" has degree ")#mi("{d}")#text(" but step ")#mi("{1}")#text(". The step is the traditional measure of nilpotency for groups, but the degree seems to be a more suitable measure in the filtered group category. One is primarily interested in the case when ")#mi("{G_{\\geq 0} = G_{\\geq 1} = G}")#text(", but for technical reasons it is occasionally convenient to allow ")#mi("{G_{\\geq 1}}")#text(" to be strictly less than ")#mi("{G}")#text(", although this does not add much generality (see Exercise ")#link(<tao-a3d92ef00ea150ebe63e>)[#text("18")]#text(" below).")

#text("We refer to sequences ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" which are polynomial maps from ")#mi("{({\\bf Z},\\leq 1)}")#text(" to ")#mi("{G_\\bullet}")#text(" as ")#emph[#text("polynomial sequences")]#text(" or ")#emph[#text("Hall-Petresco sequences")]#text(" adapted to ")#mi("{G_\\bullet}")#text(". The space of all such sequences is denoted ")#mi("{\\text{Poly}({\\bf Z} \\rightarrow G)}")#text("; by the machinery of the previous section, this is a multiplicative group. These sequences can be described explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{s \\geq 0}")#text(" be an integer, and let ")#mi("{G_\\bullet}")#text(" be a filtered group which is nilpotent of degree ")#mi("{s}")#text(". Show that a sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" is a Hall-Petresco sequence if and only if one has ")#metadata(none) <tao-76b0165e5ecbab994118>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("g(n) = g_0 g_1^{\\binom{n}{1}} g_2^{\\binom{n}{2}} \\ldots g_s^{\\binom{n}{s}}")]]

#text("for all ")#mi("{n \\in {\\bf Z}}")#text(" and some ")#mi("{g_i \\in G_{\\geq i}}")#text(" for ")#mi("{i=0,\\ldots,s}")#text(", where ")#mi("{\\binom{n}{i} := \\frac{n(n-1)\\ldots(n-i+1)}{i!}}")#text(". Furthermore, show that the ")#mi("{g_i}")#text(" are unique. We refer to the ")#mi("{g_0,\\ldots,g_s}")#text(" as the ")#emph[#text("Taylor coefficients")]#text(" of ")#mi("{g}")#text(" at the origin.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" In a degree ")#mi("{2}")#text(" nilpotent group ")#mi("{G}")#text(", establish the formula")

#align(center)[#tao-fit-display[#mitex("g^n h^n = (gh)^n [g,h]^{-\\binom{n}{2}}")]]

#text("for all ")#mi("{g,h \\in G}")#text(" and ")#mi("{n \\in {\\bf Z}}")#text(". This is the first non-trivial case of the ")#emph[#text("Hall-Petresco formula")]#text(", a discrete analogue of the Baker-Campbell-Hausdorff formula that expresses the polynomial sequence ")#mi("{n \\mapsto g^n h^n}")#text(" explicitly in the form ")#link(<tao-76b0165e5ecbab994118>)[#text("(1)")]#text(".")
]

#text("Define a ")#emph[#text("nilpotent filtered Lie group")]#text(" of degree ")#mi("{\\leq s}")#text(" to be a nilpotent filtered group of degree ")#mi("{\\leq s}")#text(", in which ")#mi("{G = G_{\\geq 0}}")#text(" and all of the ")#mi("{G_{\\geq i}}")#text(" are connected, simply connected finite-dimensional Lie groups. A model example here is the ")#emph[#text("Heisenberg group")]#text(", which is the degree ")#mi("{2}")#text(" nilpotent filtered Lie group")

#align(center)[#tao-fit-display[#mitex("G = G_{\\geq 0} = G_{\\geq 1} := \\begin{pmatrix} 1 \\\\ 0 & 1 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("(i.e. the group of upper-triangular unipotent matrices with arbitrary real entries in the upper triangular positions) with")

#align(center)[#tao-fit-display[#mitex("G_{\\geq 2} := \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("and ")#mi("{G_{\\geq i}}")#text(" trivial for ")#mi("{i>2}")#text(" (so in this case, ")#mi("{G_{\\geq i}}")#text(" is also the lower central series).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that a sequence")

#align(center)[#tao-fit-display[#mitex("g(n) = \\begin{pmatrix} 1 & x(n) & y(n) \\\\ 0 & 1 & z(n) \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("from ")#mi("{{\\bf Z}}")#text(" to the Heisenberg group ")#mi("{G}")#text(" is a polynomial sequence if and only if ")#mi("{x, z}")#text(" are linear polynomials and ")#mi("{z}")#text(" is a quadratic polynomial.")
]

#text("It is a standard fact in the theory of Lie groups that a connected, simply connected nilpotent Lie group ")#mi("{G}")#text(" is topologically equivalent to its Lie algebra ")#mi("{{\\mathfrak g}}")#text(", with the homeomorphism given by the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" (or its inverse, the logarithm function ")#mi("{\\log: G \\rightarrow {\\mathfrak g}}")#text(". Indeed, the Baker-Campbell-Hausdorff formula lets one use the nilpotent Lie algebra ")#mi("{{\\mathfrak g}}")#text(" to build a connected, simply connected Lie group with that Lie algebra, which is then necessarily isomorphic to ")#mi("{G}")#text(". One can thus classify filtered nilpotent Lie groups in terms of filtered nilpotent Lie algebras, i.e. a nilpotent Lie algebras ")#mi("{{\\mathfrak g} = {\\mathfrak g}_{\\geq 0}}")#text(" together with a nested family of sub-Lie algebras")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}_{\\geq 0} \\geq {\\mathfrak g}_{\\geq 1} \\geq \\ldots \\geq {\\mathfrak g}_{\\geq s+1} = \\{0\\}")]]

#text("with the inclusions ")#mi("{[{\\mathfrak g}_i, {\\mathfrak g}_j] \\subset {\\mathfrak g}_{i+j}}")#text(" (in which the bracket is now the Lie bracket rather than the commutator). One can describe such filtered nilpotent Lie algebras even more precisely using ")#emph[#text("Mal’cev bases")]#text("; see these papers ")#link("http://www.ams.org/mathscinet-getitem?mr=28842")[#text("of Mal’cev")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("of Leibman")]#text(". For instance, in the case of the Heisenberg group, one has")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g} = {\\mathfrak g}_{\\geq 0} = {\\mathfrak g}_{\\geq 1} := \\begin{pmatrix} 0 \\\\ 0 & 0 \\\\ 0 & 0 & 0 \\end{pmatrix}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak g}_{\\geq 2} := \\begin{pmatrix} 0 & 0 \\\\ 0 & 0 & 0 \\\\ 0 & 0 & 0 \\end{pmatrix}.")]]

#text("From the filtration property, we see that for ")#mi("{i \\geq 0}")#text(", each ")#mi("{G_{\\geq i+1}}")#text(" is a normal closed subgroup of ")#mi("{G_{\\geq i}}")#text(", and for ")#mi("{i \\geq 1}")#text(", the quotient group ")#mi("{G_{\\geq i+1}/G_{\\geq i}}")#text(" is connected, simply connected abelian Lie group (with Lie algebra ")#mi("{{\\mathfrak g}_{\\geq i+1}/{\\mathfrak g}_{\\geq i}}")#text("), and is thus isomorphic to a vector space (with the additive group law). Related to this, one can view ")#mi("{G = G_{\\geq 0}}")#text(" as a group extension of the quotient group ")#mi("{G/G_{\\geq s}}")#text(" (with the degree ")#mi("{s-1}")#text(" filtration ")#mi("{(G_{\\geq i}/G_{\\geq s})}")#text(") by the central vector space ")#mi("{G_{\\geq s}}")#text(". Thus one can view degree ")#mi("{s}")#text(" filtered nilpotent groups as an ")#mi("{s}")#text("-fold iterated tower of central extensions by finite-dimensional vector spaces starting from the base space ")#mi("{G/G_{\\geq 1}}")#text(" (which is a point in the most important case ")#mi("{G_{\\geq 1}=G}")#text("); for instance, the Heisenberg group is an extension of ")#mi("{{\\bf R}^2}")#text(" by ")#mi("{{\\bf R}}")#text(".")

#text("We thus see that nilpotent filtered Lie groups are generalisations of vector spaces (which correspond to the degree ")#mi("{1}")#text(" case). We now turn to filtered ")#emph[#text("nilmanifolds")]#text(", which are generalisations of tori. A degree ")#mi("{s}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma = (G/\\Gamma, G_\\bullet, \\Gamma)}")#text(" is a filtered degree ")#mi("{s}")#text(" nilpotent Lie group ")#mi("{G_\\bullet}")#text(", together with a discrete subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{G}")#text(", such that all the subgroups ")#mi("{G_{\\geq i}}")#text(" in the filtration are ")#emph[#text("rational")]#text(" relative to ")#mi("{\\Gamma}")#text(", which means that the subgroup ")#mi("{\\Gamma_{\\geq i} := \\Gamma \\cap G_{\\geq i}}")#text(" is a cocompact subgroup of ")#mi("{G_{\\geq i}}")#text(" (i.e. the quotient space ")#mi("{G_{\\geq i}/\\Gamma_{\\geq i}}")#text(" is cocompact, or equivalently one can write ")#mi("{G_{\\geq i} = \\Gamma_{\\geq i} \\cdot K_{\\geq i}}")#text(" for some compact subset ")#mi("{K_{\\geq i}}")#text(" of ")#mi("{G_{\\geq i}}")#text(". Note that the subgroups ")#mi("{\\Gamma_{\\geq i}}")#text(" give ")#mi("{\\Gamma}")#text(" the structure of a degree ")#mi("{s}")#text(" filtered nilpotent group ")#mi("{\\Gamma_\\bullet}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{G:={\\bf R}^2}")#text(" and ")#mi("{\\Gamma := {\\bf Z}^2}")#text(", and let ")#mi("{\\alpha \\in {\\bf R}}")#text(". Show that the subgroup ")#mi("{\\{ (x,\\alpha x): x \\in {\\bf R} \\}}")#text(" of ")#mi("{G}")#text(" is rational relative to ")#mi("{\\Gamma}")#text(" if and only if ")#mi("{\\alpha}")#text(" is a rational number; this may help explain the terminology “rational”.")
]

#text("By hypothesis, the quotient space ")#mi("{G/\\Gamma = G_{\\geq 0}/\\Gamma_{\\geq 0}}")#text(" is a smooth compact manifold. The space ")#mi("{G_{\\geq s}/\\Gamma_{\\geq s}}")#text(" is a compact connected abelian Lie group, and is thus a torus; the degree ")#mi("{s}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" can then be viewed as a principal torus bundle over the degree ")#mi("{s-1}")#text(" filtered nilmanifold ")#mi("{G/(G_{\\geq s} \\Gamma)}")#text(" with ")#mi("{G_{\\geq s}/\\Gamma_{\\geq s}}")#text(" as the structure group; thus one can view degree ")#mi("{s}")#text(" filtered nilmanifolds as an ")#mi("{s}")#text("-fold iterated tower of torus extensions starting from ")#mi("{G/(G_{\\geq 1}\\Gamma)}")#text(", which is a point in the most important case ")#mi("{G_{\\geq 1} = G}")#text(". For instance, the ")#emph[#text("Heisenberg nilmanifold")]

#align(center)[#tao-fit-display[#mitex("G/\\Gamma := \\begin{pmatrix} 1 \\\\ 0 & 1 \\\\ 0 & 0 & 1 \\end{pmatrix} / \\begin{pmatrix} 1 \\\\ 0 & 1 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("is an extension of the two-dimensional torus ")#mi("{{\\bf R}^2/{\\bf Z}^2}")#text(" by the circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(".")

#text("Every torus of some dimension ")#mi("{d}")#text(" can be viewed as a unit cube ")#mi("{[0,1]^d}")#text(" with opposite faces glued together; up to measure zero sets, the cube then serves as a fundamental domain for the nilmanifold. Nilmanifolds can be viewed the same way, but the gluing can be somewhat “twisted”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-985604c2b60243122c24>#text(" Let ")#mi("{G/\\Gamma}")#text(" be the Heisenberg nilmanifold. If we abbreviate")

#align(center)[#tao-fit-display[#mitex("[x,y,z] := \\begin{pmatrix} 1 & x & y \\\\ 0 & 1 & z \\\\ 0 & 0 & 1 \\end{pmatrix} \\Gamma \\in G/\\Gamma")]]

#text("for all ")#mi("{x,y,z \\in {\\bf R}}")#text(", show that for almost all ")#mi("{x,y,z}")#text(", that ")#mi("{[x,y,z]}")#text(" has exactly one representation of the form ")#mi("{[a,b,c]}")#text(" with ")#mi("{a,b,c \\in [0,1]}")#text(", which is given by the identity")

#align(center)[#tao-fit-display[#mitex("[x,y,z] = [ \\{x\\}, \\{ y - x \\lfloor z \\rfloor \\}, \\{z\\} ]")]]

#text("where ")#mi("{\\lfloor x \\rfloor}")#text(" is the greatest integer part of ")#mi("{x}")#text(", and ")#mi("{\\{x\\} := x - \\lfloor x \\rfloor \\in [0,1)}")#text(" is the fractional part function. Conclude that ")#mi("{G/\\Gamma}")#text(" is topologically equivalent to the unit cube ")#mi("{[0,1]^3}")#text(" quotiented by the identifications")

#tao-aligned(keep: true)[


#tao-math("(0,y,z)  & \\sim (1,y,z)", block: true)



#tao-math("(x,0,z)  & \\sim (x,1,z)", block: true)



#tao-math("(x,y,0)  & \\sim (x,\\{y-x\\},1)", block: true)
]

#text("between opposite faces.")

#text("Note that by using the projection ")#mi("{(x,y,z) \\mapsto (x,z)}")#text(", we can view the Heisenberg nilmanifold ")#mi("{G/\\Gamma}")#text(" as a twisted circle bundle over ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(", with the fibers being isomorphic to the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". Show that ")#mi("{G/\\Gamma}")#text(" is ")#emph[#text("not")]#text(" homeomorphic to ")#mi("{({\\bf R}/{\\bf Z})^3}")#text(". (Hint: show that there are some non-trivial homotopies between loops that force the fundamental group of ")#mi("{G/\\Gamma}")#text(" to be smaller than ")#mi("{{\\bf Z}^3}")#text(".)")
]

#text("The logarithm ")#mi("{\\log(\\Gamma)}")#text(" of the discrete cocompact subgroup ")#mi("{\\Gamma}")#text(" can be shown to be a lattice of the Lie algebra ")#mi("{{\\mathfrak g}}")#text(". After a change of basis, one can thus view the latter algebra as a standard vector space ")#mi("{{\\bf R}^d}")#text(" and the lattice as ")#mi("{{\\bf Z}^d}")#text(". Denoting the standard generators of the lattice (and the standard basis of ")#mi("{{\\bf R}^d}")#text(") as ")#mi("{e_1,\\ldots,e_d}")#text(", we then see that the Lie bracket ")#mi("{[e_i,e_j]}")#text(" of two such generators must be an integer combination of more generators:")

#align(center)[#tao-fit-display[#mitex("[e_i,e_j] = \\sum_{k=1}^d c_{ijk} e_k.")]]

#text("The ")#emph[#text("structure constants")]#text(" ")#mi("{c_{ijk}}")#text(" describe completely the Lie group structure of ")#mi("{G}")#text(" and ")#mi("{\\Gamma}")#text(". The rational subgroups ")#mi("{G_{\\geq l}}")#text(" can also be described by picking some generators for ")#mi("{\\log(\\Gamma_{\\geq i})}")#text(", which are integer combinations of the ")#mi("{e_1,\\ldots,e_d}")#text(". We say that the filtered nilmanifold has ")#emph[#text("complexity")]#text(" at most ")#mi("{M}")#text(" if the dimension and degree is at most ")#mi("{M}")#text(", and the structure constants and coefficients of the generators also have magnitude at most ")#mi("{M}")#text(". This is an admittedly artificial definition, but for quantitative applications it is necessary to have ")#emph[#text("some")]#text(" means to quantify the complexity of a nilmanifold.")

#text("A ")#emph[#text("polynomial orbit")]#text(" in a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" is a map ")#mi("{{\\mathcal O}: {\\bf Z} \\rightarrow G/\\Gamma}")#text(" of the form ")#mi("{{\\mathcal O}(n) := g(n) \\Gamma}")#text(", where ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" is a polynomial sequence. For instance, any linear orbit ")#mi("{{\\mathcal O}(n) = g^n x}")#text(", where ")#mi("{x \\in G/\\Gamma}")#text(" and ")#mi("{g \\in G}")#text(", is a polynomial orbit. The space of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-7152e6ec048e24fadb10>#text(" For any ")#mi("{\\alpha,\\beta \\in {\\bf R}}")#text(", show that the sequence")

#align(center)[#tao-fit-display[#mitex("n \\mapsto [ \\{ -\\alpha n \\}, \\{ \\alpha n \\lfloor \\beta n \\rfloor \\}, \\{ \\beta n \\} ]")]]

#text("(using the notation from Exercise ")#link(<tao-985604c2b60243122c24>)[#text("15")]#text(") is a polynomial sequence in the Heisenberg nilmaniofold.")
]

#text("With the above example, we see the emergence of ")#emph[#text("bracket polynomials")]#text(" when representing polynomial orbits in a fundamental domain. Indeed, one can view the entire machinery of orbits in nilmanifolds as a means of efficiently capturing such polynomials in an algebraically tractable framework (namely, that of polynomial sequences in nilpotent groups). The piecewise continuous nature of the bracket polynomials is then ultimately tied to the twisted gluing needed to identify the fundamental domain with the nilmanifold.")

#text("Finally, we can define the notion of a (basic Lipschitz) nilsequence of degree ")#mi("{\\leq s}")#text(". This is a sequence ")#mi("{\\psi: {\\bf Z} \\rightarrow {\\bf C}}")#text(" of the form ")#mi("{\\psi(n) := F( {\\mathcal O}(n) )}")#text(", where ")#mi("{{\\mathcal O}: {\\bf Z} \\rightarrow G/\\Gamma}")#text(" is a polynomial orbit in a filtered nilmanifold of degree ")#mi("{\\leq s}")#text(", and ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" is a Lipschitz function. (One needs a metric on ")#mi("{G/\\Gamma}")#text(" to define the Lipschitz constant, but this can be done for instance by using a basis ")#mi("{e_1,\\ldots,e_d}")#text(" of ")#mi("{\\Gamma}")#text(" to identify ")#mi("{G/\\Gamma}")#text(" with a fundamental domain ")#mi("{[0,1]^d}")#text(", and using this to construct some (artificial) metric on ")#mi("{G/\\Gamma}")#text(". The details of such a construction will not be important here.) We say that the nilsequence has ")#emph[#text("complexity")]#text(" at most ")#mi("{M}")#text(" if the filtered nilmanifold has complexity at most ")#mi("{M}")#text(", and the (inhomogeneous Lipschitz norm) of ")#mi("{F}")#text(" is also at most ")#mi("{M}")#text(".")

#text("A basic example of a degree ")#mi("{\\leq s}")#text(" nilsequence is a polynomial phase ")#mi("{n \\mapsto e( P(n) )}")#text(", where ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a polynomial of degree ")#mi("{\\leq s}")#text(". A bit more generally, ")#mi("{n \\mapsto F(P(n))}")#text(" is a degree ")#mi("{\\leq s}")#text(" sequence, whenever ")#mi("{F: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" is a Lipschitz function. In view of Exercises ")#link(<tao-985604c2b60243122c24>)[#text("15")]#text(", ")#link(<tao-7152e6ec048e24fadb10>)[#text("16")]#text(", we also see that ")#metadata(none) <tao-5509840d0873adb04055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("n \\mapsto e( \\alpha n \\lfloor \\beta n \\rfloor ) \\psi( \\{ \\alpha n \\} ) \\psi( \\{ \\beta n \\} )")]]

#text("or more generally")

#align(center)[#tao-fit-display[#mitex("n \\mapsto F( \\alpha n \\lfloor \\beta n \\rfloor ) \\psi( \\{ \\alpha n \\} ) \\psi( \\{ \\beta n \\} )")]]

#text("are also degree ")#mi("{\\leq 2}")#text(" nilsequences, where ")#mi("{\\psi: [0,1] \\rightarrow {\\bf C}}")#text(" is a Lipschitz function that vanishes near ")#mi("{0}")#text(" and ")#mi("{1}")#text(". The ")#mi("{\\psi(\\{\\alpha n \\})}")#text(" factor is not needed (as there is no twisting in the ")#mi("{x}")#text(" coordinate in Exercise ")#link(<tao-985604c2b60243122c24>)[#text("15")]#text("), but the ")#mi("{\\psi(\\{\\beta n\\})}")#text(" factor is (unfortunately) necessary, as otherwise one encounters the discontinuity inherent in the ")#mi("{\\lfloor \\beta n \\rfloor}")#text(" term (and one would merely have a ")#emph[#text("piecewise Lipschitz")]#text(" nilsequence rather than a genuinely Lipschitz nilsequence). Because of this discontinuity, bracket polynomial phases ")#mi("{n \\mapsto e( \\alpha n \\lfloor \\beta n \\rfloor )}")#text(" cannot quite be viewed as Lipschitz nilsequences, but from a heuristic viewpoint it is often helpful to pretend as if bracket polynomial phases are model instances of nilsequences.")

#text("The only degree ")#mi("{\\leq 0}")#text(" nilsequences are the constants. The degree ")#mi("{\\leq 1}")#text(" nilsequences are essentially the quasiperiodic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that a degree ")#mi("{\\leq 1}")#text(" nilsequence of complexity ")#mi("{M}")#text(" is Fourier-measurable with growth function ")#mi("{{\\mathcal F}_M}")#text(" depending only on ")#mi("{M}")#text(", where Fourier measurability was defined in ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-a3d92ef00ea150ebe63e>#text(" Show that the class of nilsequences of degree ")#mi("{\\leq s}")#text(" does not change if we drop the condition ")#mi("{G=G_{\\leq 0}}")#text(", or if we add the additional condition ")#mi("{G=G_{\\leq 1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The space of nilsequences is also unchanged if one insists that the polynomial orbit be linear, and that the filtration be the lower central series filtration; and this is in fact the original definition of a nilsequence. The proof of this equivalence is a little tricky, though, and will appear in a forthcoming paper of Green, Ziegler, and myself.")
]

#heading(level: 1)[#strong[#text(" — 3. Connection with the Gowers norms — ")]]

#text("We define the Gowers norm ")#tao-math("{\\left\\|f\\right\\|_{U^d[N]}}", block: false)#text(" of a function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^d[N]} := \\left\\|f\\right\\|_{U^d({\\bf Z}/N^{\\prime}{\\bf Z})} / \\left\\|1_{[N]}\\right\\|_{U^d({\\bf Z}/N^{\\prime}{\\bf Z})}", block: true)]]

#text("where ")#mi("{N^{\\prime}}")#text(" is any integer greater than ")#mi("{(d+1)N}")#text(", ")#mi("{[N]}")#text(" is embedded inside ")#mi("{{\\bf Z}/N^{\\prime}{\\bf Z}}")#text(", and ")#mi("{f}")#text(" is extended by zero outside of ")#mi("{[N]}")#text(". It is easy to see that this definition is independent of the choice of ")#mi("{N^{\\prime}}")#text(". Note also that the normalisation factor ")#tao-math("{\\left\\|1_{[N]}\\right\\|_{U^d({\\bf Z}/N^{\\prime}{\\bf Z})}}", block: false)#text(" is comparable to ")#mi("{1}")#text(" when ")#mi("{d}")#text(" is fixed and ")#mi("{N^{\\prime}}")#text(" is comparable to ")#mi("{N}")#text(".")

#text("One of the main reasons why nilsequences are relevant to the theory of the Gowers norms is that they are an obstruction to that norm being small. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Converse to the inverse conjecture for the Gowers norms)")]#text(" ")#metadata(none) <tao-83ef8b564c63a20814ea>#text(" Let ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty[N]} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left|\\langle f, \\psi \\rangle_{L^2([N])}\\right| \\geq \\delta}", block: false)#text(" for some degree ")#mi("{\\leq s}")#text(" nilsequence of complexity at most ")#mi("{M}")#text(". Then ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}[N]} \\gg_{s,\\delta,M} 1}", block: false)#text(".")
]

#text("We now prove this theorem, following an argument ")#link("http://arxiv.org/abs/0911.5681")[#text("of Green, Ziegler, and myself")]#text(". It is convenient to introduce a few more notions. Define a ")#emph[#text("vertical character")]#text(" of a degree ")#mi("{\\leq s}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" to be a continuous homomorphism ")#mi("{\\eta: G_{\\geq s} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" that annihilates ")#mi("{\\Gamma_{\\geq s}}")#text(", or equivalently an element of the Pontryagin dual ")#mi("{\\widehat{G_{\\geq s}/\\Gamma_{\\geq s}}}")#text(" of the torus ")#mi("{G_{\\geq s}/\\Gamma_{\\geq s}}")#text(". A function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" is said to have ")#emph[#text("vertical frequency")]#text(" ")#mi("{\\eta}")#text(" if ")#mi("{F}")#text(" obeys the equation")

#align(center)[#tao-fit-display[#mitex("F(g_s x) = e( \\eta(g_s) ) F(x)")]]

#text("for all ")#mi("{g_s \\in G_{\\geq s}}")#text(" and ")#mi("{x \\in G/\\Gamma}")#text(". A degree ")#mi("{\\leq s}")#text(" nilsequence is said to ")#emph[#text("have a vertical frequency")]#text(" if it can be represented in the form ")#mi("{n \\mapsto F({\\mathcal O}(n))}")#text(" for some Lipschitz ")#mi("{F}")#text(" with a vertical frequency.")

#text("For instance, a polynomial phase ")#mi("{n \\mapsto e(P(n))}")#text(", where ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a polynomial of degree ")#mi("{\\leq s}")#text(", is a degree ")#mi("{\\leq s}")#text(" nilsequence with a vertical frequency. Any nilsequence of degree ")#mi("{\\leq s-1}")#text(" is trivially a nilsequence of degree ")#mi("{\\leq s}")#text(" with a vertical frequency of ")#mi("{0}")#text(". Finally, observe that the space of degree ")#mi("{\\leq s}")#text(" nilsequences with a vertical frequency is closed under multiplication and complex conjugation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that a degree ")#mi("{\\leq 1}")#text(" nilsequence with a vertical frequency necessarily takes the form ")#mi("{\\psi(n) = c e( \\alpha n)}")#text(" for some ")#mi("{c \\in {\\bf C}}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(" (and conversely, all such sequences are degree ")#mi("{\\leq 1}")#text(" nilsequences with a vertical frequency). Thus, up to constants, degree ")#mi("{\\leq 1}")#text(" nilsequences with a vertical frequency are the same as Fourier characters.")
]

#text("A basic fact (generalising the invertibility of the Fourier transform in the degree ")#mi("{\\leq 1}")#text(" case) is that the nilsequences with vertical frequency generate all the other nilsequences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-9dfbc63747c6ec4e8d43>#text(" Show that any degree ")#mi("{\\leq s}")#text(" nilsequence can be approximated to arbitrary accuracy in the uniform norm by a linear combination of nilsequences with a vertical frequency. (")#emph[#text("Hint:")]#text(" use the Stone-Weierstrass theorem.)")

#text("More quantitatively, show that a degree ")#mi("{\\leq s}")#text(" nilsequence of complexity ")#mi("{\\leq M}")#text(" can be approximated uniformly to error ")#mi("{\\epsilon}")#text(" by a sum of ")#mi("{O_{M,\\epsilon,s}(1)}")#text(" nilsequences, each with a representation with a vertical frequency that is of complexity ")#mi("{O_{M,\\epsilon,s}(1)}")#text(". (")#emph[#text("Hint:")]#text(" this can be deduced from the qualitative result by a compactness argument using the Arzelá-Ascoli theorem.)")
]

#text("A derivative ")#mi("{\\Delta_h e(P(n))}")#text(" of a polynomial phase is a polynomial phase of one lower degree. There is an analogous fact for nilsequences with a vertical frequency:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Differentiating nilsequences with a vertical frequency)")]#text(" ")#metadata(none) <tao-e049bd056f936d1b39b7>#text(" Let ")#mi("{s \\geq 1}")#text(", and let ")#mi("{\\psi}")#text(" be a degree ")#mi("{\\leq s}")#text(" nilsequence with a vertical frequency. Then for any ")#mi("{h \\in {\\bf Z}}")#text(", ")#mi("{\\Delta_h \\psi}")#text(" is a degree ")#mi("{\\leq s-1}")#text(" nilsequence. Furthermore, if ")#mi("{\\psi}")#text(" has complexity ")#mi("{\\leq M}")#text(" (with a vertical frequency representation), then ")#mi("{\\Delta_h \\psi}")#text(" has complexity ")#mi("{O_{M,s}(1)}")#text(".")
]

#emph[#text("Proof:")]#text(" We just prove the first claim, as the second claim follows by refining the argument.")

#text("We write ")#mi("{\\psi = F( g(n) \\Gamma )}")#text(" for some polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G/\\Gamma}")#text(" and some Lipschitz function ")#mi("{F}")#text(" with a vertical frequency. We then express")

#align(center)[#tao-fit-display[#mitex("\\Delta_h \\psi(n) = \\tilde F( \\tilde g(n) (\\Gamma \\times \\Gamma))")]]

#text("where ")#mi("{\\tilde F: G \\times G/(\\Gamma \\times \\Gamma) \\rightarrow {\\bf C}}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\tilde F(x,y) := F(x) \\overline{F(y)}")]]

#text("and ")#mi("{\\tilde g: {\\bf Z} \\rightarrow G \\times G}")#text(" is the sequence")

#align(center)[#tao-fit-display[#mitex("\\tilde g(n) := (g(n), \\partial_h g(n) g(n)).")]]

#text("Now we give a filtration on ")#mi("{G \\times G}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("(G \\times G)_{\\geq j} := G_{\\geq j} \\times_{G_{\\geq j+1}} G_{\\geq j}")]]

#text("for ")#mi("{j \\geq 0}")#text(", where ")#mi("{G_{\\geq j} \\times_{G_{\\geq j+1}} G_{\\geq j}}")#text(" is the subgroup of ")#mi("{G_{\\geq j} \\times_{G_{\\geq j+1}} G_{\\geq j}}")#text(" generated by ")#mi("{G_{\\geq j+1} \\times G_{\\geq j+1}}")#text(" and the diagonal group ")#mi("{G_{\\geq j}^\\Delta := \\{ (g_j,g_j): g_j \\in G_{\\geq j}}")#text(". One easily verifies that this is a filtration on ")#mi("{G \\times G}")#text(". The sequences ")#mi("{(g(n), g(n))}")#text(" and ")#mi("{(\\text{id}, \\partial_h g(n))}")#text(" are both polynomial with respect to this filtration, and hence by the Lazard-Leibman theorem, ")#mi("{\\tilde g}")#text(" is polynomial also.")

#text("Next, we use the hypothesis that ")#mi("{F}")#text(" has a vertical frequency to conclude that ")#mi("{F}")#text(" is invariant with respect to the action of the diagonal group ")#mi("{G_s^\\Delta = (G \\times G)_{\\geq s}}")#text(". If we then define ")#mi("{G^\\Box}")#text(" to be the Lie group ")#mi("{G^\\Box := (G \\times G)_{\\geq 0}/G_s^\\Delta}")#text(" with filtration ")#mi("{G^\\Box_{\\geq j} := (G \\times G)_{\\geq j} / G_s^\\Delta}")#text(", then ")#mi("{G^\\Box}")#text(" is a degree ")#mi("{\\leq s-1}")#text(" filtered nilpotent Lie group; setting ")#mi("{\\Gamma^\\Box := (\\Gamma \\times\\Gamma) \\cap G^\\Box}")#text(", we conclude that ")#mi("{G^\\Box/\\Gamma^\\Box}")#text(" is a degree ")#mi("{\\leq s-1}")#text(" nilmanifold and")

#align(center)[#tao-fit-display[#mitex("\\Delta_h \\psi(n) = F^\\Box(g^\\Box(n) \\Gamma^\\Box)")]]

#text("where ")#mi("{F^\\Box, g^\\Box}")#text(" are the projections of ")#mi("{\\tilde F, \\tilde g}")#text(" from ")#mi("{G \\times G}")#text(" to ")#mi("{G^\\Box}")#text(". The claim follows. ")#mi("\\Box")

#text("We now prove Theorem ")#link(<tao-83ef8b564c63a20814ea>)[#text("7")]#text(" by induction on ")#mi("{s}")#text(". The claim is trivial for ")#mi("{s=0}")#text(", so we assume that ")#mi("{s \\geq 1}")#text(" and that the claim has already been proven for smaller values of ")#mi("{s}")#text(".")

#text("Let ")#mi("{f, \\delta, \\psi}")#text(" be as in Theorem ")#link(<tao-83ef8b564c63a20814ea>)[#text("7")]#text(". From Exercise ")#link(<tao-9dfbc63747c6ec4e8d43>)[#text("20")]#text(" we see (after modifying ")#mi("{\\delta, M}")#text(") that we may assume that ")#mi("{\\psi}")#text(" has a vertical frequency. Next, we use the identity")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}^{\\prime}} f(n) \\overline{\\psi(n)}\\right|^2 = \\mathop{\\bf E}_{h \\in {\\bf Z}/N^{\\prime}{\\bf Z}} \\mathop{\\bf E}_{n\\in {\\bf Z}/N^{\\prime}{\\bf Z}} \\Delta_h f(n) \\overline{\\Delta_h \\psi(n)}", block: true)]]

#text("(extending ")#mi("{f}")#text(" by zero outside of ")#mi("{[N]}")#text(", and extending ")#mi("{\\psi}")#text(" arbitrarily) to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} \\Delta_h f(n) \\overline{\\Delta_h \\psi(n)}\\right| \\gg_\\delta 1", block: true)]]

#text("for ")#mi("{\\gg N}")#text(" values of ")#mi("{h \\in [-N,N]}")#text(". By induction hypothesis and Lemma ")#link(<tao-e049bd056f936d1b39b7>)[#text("8")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_h f\\right\\|_{U^s[N]} \\gg_{\\delta, M} 1", block: true)]]

#text("for ")#mi("{\\gg N}")#text(" values of ")#mi("{h \\in [-N,N]}")#text(". Using the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{s+1}({\\bf Z}/N^{\\prime}{\\bf Z})}^{2^{s+1}} = \\mathop{\\bf E}_{h \\in {\\bf Z}/N^{\\prime}{\\bf Z}} \\left\\|\\Delta_h f\\right\\|_{U^s({\\bf Z}/N^{\\prime}{\\bf Z})}^{2^s}", block: true)]]

#text("we close the induction and obtain the claim.")

#text("In the other direction, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Inverse conjecture for the Gowers norms on ")#mi("{{\\bf Z}}")#text(")")]#text(" ")#metadata(none) <tao-1de03f1ee0ff04d34c80>#text(" Let ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty[N]} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}[N]} \\geq \\delta}", block: false)#text(". Then ")#tao-math("{\\left|\\langle f, \\psi \\rangle_{L^2([N])}\\right| \\gg_{s,\\delta} 1}", block: false)#text(" for some degree ")#mi("{\\leq s}")#text(" nilsequence of complexity ")#mi("{O_{s,\\delta}(1)}")#text(".")
]

#text("This conjecture has recently been proven by Green, Ziegler, and myself; an announcement of this result, which will contain extensive heuristic discussion of how this conjecture is proven, will appear very shortly, and the paper itself soon after that. For a discussion of the history of the conjecture, including the cases ")#mi("{s \\leq 3}")#text(", see ")#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/")[#text("our previous paper")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (")#mi("{99\\%}")#text(" inverse theorem)")]

#enum(start: 1, 
[#text("(Straightening an approximately linear function) Let ")#mi("{\\epsilon, \\kappa > 0}")#text(". Let ")#mi("{\\xi: [-N,N] \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a function such that ")#tao-math("{\\left|\\xi(a+b) - \\xi(a)-\\xi(b)\\right| \\leq \\kappa}", block: false)#text(" for all but ")#mi("{\\epsilon N^2}")#text(" of all ")#mi("{a, b \\in [-N,N]}")#text(" with ")#mi("{a+b \\in [-N,N]}")#text(". If ")#mi("{\\epsilon}")#text(" is sufficiently small, show that there exists an affine linear function ")#mi("{n \\mapsto \\alpha n + \\beta}")#text(" with ")#mi("{\\alpha, \\beta \\in {\\bf R}/{\\bf Z}}")#text(" such that ")#tao-math("{\\left|\\xi(n) - \\alpha n - \\beta\\right| \\ll_\\epsilon \\kappa}", block: false)#text(" for all but ")#mi("{\\delta(\\epsilon) N}")#text(" values of ")#mi("{n \\in [-N,N]}")#text(", where ")#mi("{\\delta(\\epsilon) \\rightarrow 0}")#text(" as ")#mi("{\\epsilon \\rightarrow 0}")#text(". (")#emph[#text("Hint:")]#text(" One can take ")#mi("{\\kappa}")#text(" to be small. First find a way to lift ")#mi("{\\xi}")#text(" in a nice manner from ")#mi("{{\\bf R}/{\\bf Z}}")#text(" to ")#mi("{{\\bf R}}")#text(".)")],
[#text("Let ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty[N]} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}[N]} \\geq 1-\\epsilon}", block: false)#text(". Show that there exists a polynomial ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree ")#mi("{\\leq s}")#text(" such that ")#tao-math("{\\left\\|f-e(P)\\right\\|_{L^2([N])} \\leq \\delta}", block: false)#text(", where ")#mi("{\\delta = \\delta_s(\\epsilon) \\rightarrow 0}")#text(" as ")#mi("{\\epsilon \\rightarrow 0}")#text(" (holding ")#mi("{s}")#text(" fixed). ")#emph[#text("Hint:")]#text(" Adapt the argument of the analogous finite field statement. One cannot exploit the discrete nature of polynomials any more; and so one must use the preceding part of the exercise as a substitute.")]
)
]

#text("The inverse conjecture for the Gowers norms, when combined with the equidistribution theory for nilsequences that we will turn to next, has a number of consequences, analogous to the consequences for the finite field analogues of these facts; see ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("this paper of Green and myself")]#text(" for further discussion.")

#heading(level: 1)[#strong[#text(" — 4. Equidistribution of nilsequences — ")]]

#text("In the subject of higher order Fourier analysis, and in particular in the proof of the inverse conjecture for the Gowers norms, as well as in several of the applications of this conjecture, it will be of importance to be able to compute statistics of nilsequences ")#mi("{\\psi}")#text(", such as their averages ")#mi("{\\mathop{\\bf E}_{n \\in [N]} \\psi(n)}")#text(" for a large integer ")#mi("{N}")#text("; this generalises the computation of exponential sums such as ")#mi("{\\mathop{\\bf E}_{n \\in [N]} e(P(n))}")#text(" that occurred in ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(". This is closely related to the equidistribution of polynomial orbits ")#mi("{{\\mathcal O}: {\\bf Z} \\rightarrow G/\\Gamma}")#text(" in nilmanifolds. Note that as ")#mi("{G/\\Gamma}")#text(" is a compact quotient of a locally compact group ")#mi("{G}")#text(", it comes endowed with a unique left-invariant Haar measure ")#mi("{\\mu_{G/\\Gamma}}")#text(" (which is isomorphic to the Lebesgue measure on a fundamental domain ")#mi("{[0,1]^d}")#text(" of that nilmanifold). By default, when we talk about equidistribution in a nilmanifold, we mean with respect to the Haar measure; thus ")#mi("{{\\mathcal O}}")#text(" is asymptotically equidistributed if and only if")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\mathop{\\bf E}_{n \\in [N]} F({\\mathcal O}(n)) = 0")]]

#text("for all Lipschitz ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(". One can also describe single-scale equidistribution (and non-standard equidistribution) in a similar fashion, but for sake of discussion let us restrict attention to the simpler and more classical situation of asymptotic equidistribution here (although it is the single-scale equidistribution theory which is ultimately relevant to questions relating to the Gowers norms).")

#text("When studying equidistribution of polynomial sequences in a torus ")#mi("{{\\bf T}^d}")#text(", a key tool was the ")#emph[#text("van der Corput lemma")]#text(". This lemma asserts that if a sequence ")#mi("{x: {\\bf Z} \\rightarrow {\\bf T}^d}")#text(" is such that all derivatives ")#mi("{\\partial_h x: {\\bf Z} \\rightarrow {\\bf T}^d}")#text(" with ")#mi("{h \\neq 0}")#text(" are asymptotically equidistributed, then ")#mi("{x}")#text(" itself is also asymptotically equidistributed.")

#text("The notion of a derivative requires the ability to perform subtraction on the range space ")#mi("{{\\bf T}^d}")#text(": ")#mi("{\\partial_h x(n+h) - \\partial_h x(n)}")#text(". When working in a higher degree nilmanifold ")#mi("{G/\\Gamma}")#text(", which is not a torus, we do not have a notion of subtraction. However, such manifolds are still torus ")#emph[#text("bundles")]#text(" with torus ")#mi("{{\\bf T} := G_{\\geq s}/\\Gamma_{\\geq s}}")#text(". This gives a weaker notion of subtraction, namely the map ")#mi("{\\pi: G/\\Gamma \\times G/\\Gamma \\rightarrow (G/\\Gamma \\times G/\\Gamma) / {\\bf T}^\\Delta}")#text(", where ")#mi("{{\\bf T}^\\Delta}")#text(" is the diagonal action ")#mi("{g_s: (x,y) \\mapsto (g_s x, g_s y)}")#text(" of the torus ")#mi("{{\\bf T}}")#text(" on the product space ")#mi("{G/\\Gamma \\times G/\\Gamma}")#text(". This leads to a generalisation of the van der Corput lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Relative van der Corput lemma)")]#text(" ")#metadata(none) <tao-f83f647281f1f8110e10>#text(" Let ")#mi("{x: {\\bf Z} \\rightarrow G/\\Gamma}")#text(" be a sequence in a degree ")#mi("{\\leq s}")#text(" nilmanifold for some ")#mi("{s \\geq 1}")#text(". Suppose that the projection of ")#mi("{x}")#text(" to the degree ")#mi("{\\leq s-1}")#text(" filtered nilmanifold ")#mi("{G/G_s \\Gamma}")#text(" is asymptotically equidistributed, and suppose also that for each non-zero ")#mi("{h \\in {\\bf Z}}")#text(", the sequence ")#mi("{\\partial_h x: n \\mapsto \\pi( x(n+h), x(n) )}")#text(" is asymptotically equidistributed with respect to some ")#mi("{{\\bf T}}")#text("-invariant measure ")#mi("{\\mu_h}")#text(" on ")#mi("{(G/\\Gamma \\times G/\\Gamma) / {\\bf T}^\\Delta}")#text(". Then ")#mi("{x}")#text(" is asymptotically equidistributed in ")#mi("{G/\\Gamma}")#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to show that, for each Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mathop{\\bf E}_{n \\in [N]} F(x(n)) = \\int_{G/\\Gamma} F\\ d\\mu_{G/\\Gamma}.")]]

#text("By Exercise ")#link(<tao-9dfbc63747c6ec4e8d43>)[#text("20")]#text(", we may assume that ")#mi("{F}")#text(" has a vertical frequency. If this vertical frequency is non-zero, then ")#mi("{F}")#text(" descends to a function on the degree ")#mi("{\\leq s-1}")#text(" filtered nilmanifold ")#mi("{G/G_s \\Gamma}")#text(", and the claim then follows from the equidistribution hypothesis on this space. So suppose instead that ")#mi("{F}")#text(" has a non-zero vertical frequency. By vertically rotating ")#mi("{F}")#text(" (and using the ")#mi("{G_s}")#text("-invariance of ")#mi("{\\mu_{G/\\Gamma}}")#text(" we conclude that ")#mi("{\\int_{G/\\Gamma} F \\mu_{G/\\Gamma} = 0}")#text(". Applying the van der Corput inequality (see ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text("), we now see that it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mathop{\\bf E}_{n \\in [N]} F(x(n+h)) \\overline{F(x(n))} = 0")]]

#text("for each non-zero ")#mi("{h}")#text(". The function ")#mi("{(x,y) \\rightarrow F(x) \\overline{F(y)}}")#text(" on ")#mi("{G/\\Gamma \\times G/\\Gamma}")#text(" is ")#mi("{T^\\Delta}")#text("-invariant (because of the vertical frequency hypothesis) and so descends to a function ")#mi("{\\tilde F}")#text(" on ")#mi("{(G/\\Gamma \\times G/\\Gamma)/T^\\Delta}")#text(". We thus have")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mathop{\\bf E}_{n \\in [N]} F(x(n+h)) \\overline{F(x(n))} = \\int_{(G/\\Gamma \\times G/\\Gamma)/T^\\Delta} \\tilde F\\ d\\mu_h.")]]

#text("The function ")#mi("{\\tilde F}")#text(" has a non-zero vertical frequency with respect to the residual action of ")#mi("{{\\bf T}}")#text(" (or more precisely, of ")#mi("{({\\bf T} \\times {\\bf T})/{\\bf T}^\\Delta}")#text(", which is isomorphic to ")#mi("{{\\bf T}}")#text("). As ")#mi("{\\mu_h}")#text(" is invariant with respect to this action, the integral thus vanishes, as required. ")#mi("\\Box")

#text("This gives a useful criterion for equidistribution of polynomial orbits. Define a ")#emph[#text("horizontal character")]#text(" to be a continuous homomorphism ")#mi("{\\eta}")#text(" from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(" that annihilates ")#mi("{\\Gamma}")#text(" (or equivalently, an element of the Pontryagin dual of the ")#emph[#text("horizontal torus")]#text(" ")#mi("{G/([G,G]\\Gamma)}")#text("). This is easily seen to be a torus. Let ")#mi("{\\pi_i: G_{\\geq i} \\rightarrow {\\bf T}_i}")#text(" be the projection map.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Leibman equidistribution criterion)")]#text(" ")#metadata(none) <tao-2b102c62335a31455b0c>#text(" Let ")#mi("{{\\mathcal O}: n \\mapsto g(n) \\Gamma}")#text(" be a polynomial orbit on a degree ")#mi("{\\leq s}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma}")#text(". Suppose that ")#mi("{G=G_{\\geq 0}=G_{\\geq 1}}")#text(". Then ")#mi("{{\\mathcal O}}")#text(" is asymptotically equidistributed in ")#mi("{G/\\Gamma}")#text(" if and only if ")#mi("{\\eta \\circ g}")#text(" is non-constant for each non-trivial horizontal character.")
]

#text("This theorem was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("by Leibman")]#text(" (by a slightly different method), and also follows from the above van der Corput lemma and some tedious additional computations; see ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("this paper of Green and myself")]#text(" for details. For linear orbits, this result was established ")#link("http://www.ams.org/mathscinet-getitem?mr=267558")[#text("by Parry")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("by Leon Green")]#text(". Using this criterion (together with more quantitative analogues for single-scale equidistribution), one can develop Ratner-type decompositions that generalise those in (")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text("). Again, the details are technical and I refer to ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("my paper with Green")]#text(" for details. We give a special case of Theorem ")#link(<tao-2b102c62335a31455b0c>)[#text("11")]#text(" as an exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-7f1b55b860590406f84f>#text(" Use Lemma ")#link(<tao-f83f647281f1f8110e10>)[#text("10")]#text(" to show that if ")#mi("{\\alpha, \\beta}")#text(" are two real numbers such that ")#mi("{\\alpha, \\beta, \\alpha \\beta}")#text(" are linearly independent modulo ")#mi("{1}")#text(" over the integers, then the polynomial orbit")

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\begin{pmatrix} 1 & \\alpha n & 0 \\\\ 0 & 1 & \\beta n \\\\ 0 & 0 & 1 \\end{pmatrix} \\Gamma")]]

#text("is asymptotically equidistributed in the Heisenberg nilmanifold ")#mi("{G/\\Gamma}")#text("; note that this is a special case of Theorem ")#link(<tao-2b102c62335a31455b0c>)[#text("11")]#text(". Conclude that the map ")#mi("{n \\mapsto \\alpha n \\lfloor \\beta n \\rfloor \\text{ mod } 1}")#text(" is asymptotically equidistributed in the unit circle.")
]

#text("Unfortunately Lemma ")#link(<tao-f83f647281f1f8110e10>)[#text("10")]#text(" is not strong enough to cover all cases of Theorem ")#link(<tao-2b102c62335a31455b0c>)[#text("11")]#text("; in particular, if ")#mi("{\\alpha,\\beta}")#text(" are independent but ")#mi("{\\alpha,\\beta,\\alpha \\beta}")#text(" are not, then the hypotheses of Lemma ")#link(<tao-f83f647281f1f8110e10>)[#text("10")]#text(" are not obeyed for any fixed non-zero ")#mi("{h}")#text(", although they are in some sense asymptotically obeyed in the limit when ")#mi("{h}")#text(" is large. To obtain Theorem ")#link(<tao-2b102c62335a31455b0c>)[#text("11")]#text(" in this case one either needs a quantitative (single-scale) version of Lemma ")#link(<tao-f83f647281f1f8110e10>)[#text("10")]#text(", or else one has to invoke the ergodic theorem in a number of places. The former approach is the one taken in the above mentioned paper of Green and myself, and the latter in the paper of Leibman.")

#text("One application of this equidistribution theory is to show that bracket polynomial objects such as ")#link(<tao-5509840d0873adb04055>)[#text("(2)")]#text(" have a negligible correlation with any genuinely quadratic phase ")#mi("{n \\mapsto e(\\alpha n^2 + \\beta n + \\gamma)}")#text(" (or more generally, with any genuinely polynomial phase of bounded degree); this result was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=1247389")[#text("by Haland")]#text(". On the other hand, from Theorem ")#link(<tao-83ef8b564c63a20814ea>)[#text("7")]#text(" we know that ")#link(<tao-5509840d0873adb04055>)[#text("(2)")]#text(" has a large ")#mi("{U^3[N]}")#text(" norm. This shows that even when ")#mi("{s=2}")#text(", one cannot invert the Gowers norm purely using polynomial phases. This observation first appeared in the work ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("of Gowers")]#text(" (with a related observation due ")#link("http://www.ams.org/mathscinet-getitem?mr=1412607")[#text("to Furstenberg and Weiss")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let the notation be as in Exercise ")#link(<tao-7f1b55b860590406f84f>)[#text("22")]#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow\\infty} \\mathop{\\bf E}_{n \\in [N]} e( \\alpha n \\lfloor \\beta n \\rfloor - \\gamma n^2 - \\delta n ) = 0")]]

#text("for any ")#mi("{\\gamma, \\delta \\in {\\bf R}}")#text(". (You can either apply Theorem ")#link(<tao-2b102c62335a31455b0c>)[#text("11")]#text(", or go back to Lemma ")#link(<tao-f83f647281f1f8110e10>)[#text("10")]#text(".)")
]

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45231")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("Dear Professor Tao")

#text("Am I correct that Theorem 9 (Inverse conjecture for the Gowers norms on Z) is exactly the same conjecture mentioned in the paper “Linear equations in primes”, and thus that results are now fully unconditional?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45249")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("It is equivalent to the conjecture formulated there, yes. We’re preparing a formal announcement of the results which should appear here within a week or so, and the full paper should be ready shortly afterwards.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jingzheng")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45329")[#strong[#text("Jingzheng")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2010")])]

#text("Dear Professor Tao")

#text("Inverse conjecture for Gowers norms roughly says for example that if a bounded function f does not resemble a nilsequence then the sum of terms f(a)g(a+b)h(a+2b)k(a+3b) (for a, b from suitable ranges and g,h,k bounded) is of smaller order than the magnitude resulting from estimating trivially. Are there any partial results or conjectures concerning nonlinear equations? For instance: is there any conjecture about sum of f(a)g(d)h(b)k(c) over quadruples (a,b,c,d) satisfying ad-bc=1? If this sum is as large as possible then what are the functions that f,g,h and k must resemble?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2010")])]

#text("This is an important question, but not much is known presently, even in the simplest example of nonlinearity, namely averages over polynomials. If one is working in a finite field, and all parameters range freely in this field, then one can usually use a version of the van der Corput inequality (combined with PET induction) to control things by Gowers norms. But over an interval of integers [N], the problem once one has nonlinearity is that some of the parameters now need to be restricted to smaller intervals, such as [N^{1/d}] for some d. In some cases one can still hope to control things by “local” Gowers norms – Tamar Ziegler and I did something like this for instance when finding polynomial progressions in primes. But the general situation is still quite murky. I suspect that some of the theory from sum-product estimates and expansion in linear groups may have to come into play, particularly for patterns such as ad-bc=1 that are clearly connected to linear groups such as SL_2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jingzheng")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45331")[#strong[#text("Jingzheng")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2010")])]

#text("Dear Professor Tao")

#text("Thank you for the answer. Your mentioning of the paper with dr Ziegler about polynomial progressions of primes reminded me of another interesting problem. Since the progressions of length at least 4 involve as complicated objects as nilsequences then in order to try to find an asymptotics for polynomial progressions maybe it is appropriate first to investigate asymptotics for polynomial progressions of length 3? The simplest nontrivial case would be: a, a+b^2, a+2b^2. A relevant question here would be: is it true that if the sum of terms f(a)g(a+b^2)h(a+2b^2) is of magnitude N^(3/2) where a is of order N and b is of order N^(1/2) then necessarily f has a large Fourier coefficient?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45332")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2010")])]

#text("Yes, something like this should be true (but perhaps one has to deal with a local Fourier coefficient rather than a global one), but this has not been proved yet as far as I know (this would correspond to a polynomial version of a conjecture of Gowers and Wolf, which has only been proven so far in the linear case). There is an ergodic counterpart to your question to which the answer is affirmative, thanks to the work of Bergelson, Leibman, and Lesigne, so heuristically the same should be true for the finitary version of the question, but unfortunately the correspondence principle does not seem to yield this directly.")

#text("If one applies the Cauchy-Schwarz inequality enough times, I believe one can control the above sum by something like the (local) U^7 norm of f, which suggests that f will at least correlate with a 6-step nilsequence, but one presumably do better than this with more work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-45333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2010")])]

#text("陶教授")#linebreak()#text(" 我非常感谢您回答")#linebreak()#text(" 晶正")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-185901")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] some (standard) finite number of group elements of ; see e.g. Exercise 11 of this previous blog post. In the abelian case, we used the largest for which was non-trivial as the degree of . This turns […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-217771")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("Dear Terry,")#linebreak()#text(" it seems that the relative van der Corput lemma 10 does not apply directly in Exercise 22 (Exercise 1.6.22 in the book draft). Consider the following example: ")#mi("\\alpha=2^{1/4},\\beta=2^{3/4}")#text(" (these are linearly independent mod 1 over Z because ")#mi("X^4-2")#text(" is irreducible over Z, say by Cohn’s criterion in base 3). Then")

#mi("g(n+h) = \\begin{pmatrix}1&\\alpha(n+h)&0\\\\ &1&\\beta(n+h)\\\\ &&1\\end{pmatrix} = \\begin{pmatrix}1&\\alpha h&-\\alpha\\beta hn\\\\ &1&\\beta h\\\\ &&1\\end{pmatrix} \\begin{pmatrix}1&\\alpha n&0\\\\ &1&\\beta n\\\\ &&1\\end{pmatrix} \\cong \\begin{pmatrix}1&\\alpha h&0\\\\ &1&\\beta h\\\\ &&1\\end{pmatrix} \\begin{pmatrix}1&\\alpha n&0\\\\ &1&\\beta n\\\\ &&1\\end{pmatrix} \\mod \\Gamma")

#text("Hence ")#mi("(g(n+h)\\Gamma,g(n)\\Gamma)T^\\Delta = const(h) (g(n)\\Gamma,g(n)\\Gamma)T^\\Delta")#text(".")#linebreak()#text(" If the closure of this orbit was ")#mi("T^2/T^\\Delta")#text("-invariant then also the closure of the orbit")#linebreak()#text(" ")#mi("(g(n)\\Gamma,g(n)\\Gamma)T^\\Delta")#text(" would be ")#mi("T^2/T^\\Delta")#text("-invariant since ")#mi("T^2/T^\\Delta")#text(" is central and multiplication by a constant is a homeomorphism. However, this closure is contained in the diagonal of ")#mi("(G/\\Gamma)^2 / T^\\Delta")#text(".")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-217838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("Gah, you’re right, this particular argument only works under the stronger hypothesis that ")#mi("\\alpha, \\beta, \\alpha\\beta")#text(" are linearly independent. (In the example you gave, one does not have equidistribution for any fixed h, though in some sense the orbits become asymptotically equidistributed as h becomes large, though it is hard to formalise this at the qualitative level.) It seems that to handle the general case one has to either use a quantitative (single-scale) version of the van der Corput lemma (as was done in my paper with Ben) or else rely on the ergodic theorem (this is the approach in Leibman).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-221345")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] the cost of turning the observable into a slightly messy piecewise smooth function; see e.g. this blog post for details. More generally, any function arising from phases that are bracket polynomials (or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-687751")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2025")])]

#text("For the lower central series, I feel as if a condition is missing. if <G> is an abelian group, one could define <G_0 =G> and <G_i = {id}> for <igtr 0>. In this case one would not have containment for <G_1> in the lower central series of <G>. This is probably a pathological example, but I do want to check that my understanding of filtrations as written is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-687752")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2025")])]

#text("Ah, right, one also has to impose ")#mi("G_1=G")#text(" for this remark to be valid; I’ll make the correction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-688322")[#strong[#text("Shakhar Smorodinsky’s Solution to a Radon-Type Problem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2025")]

#text("[…] the first Erdos lecture by Mehtaab S. Sawhney. On the blackboard, you can see the important “bracket polynomials”. To the right, a picture of Erdős. In the top-right corner, there is a digital thermometer. About […]")
]
