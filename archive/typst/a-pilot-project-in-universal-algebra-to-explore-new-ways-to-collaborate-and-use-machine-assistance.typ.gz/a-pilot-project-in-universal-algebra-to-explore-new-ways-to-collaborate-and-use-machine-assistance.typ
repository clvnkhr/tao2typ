// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/
// Converted to Typst by tao2typ: "2026-10-14T15:21:01.963814+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A pilot project in universal algebra to explore new ways to collaborate and use machine assistance?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A pilot project in universal algebra to explore new ways to collaborate and use machine assistance?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/")[#text("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Traditionally, mathematics research projects are conducted by a small number (typically one to five) of expert mathematicians, each of which are familiar enough with all aspects of the project that they can verify each other’s contributions. It has been challenging to organize mathematical projects at larger scales, and particularly those that involve contributions from the general public, due to the need to verify all of the contributions; a single error in one component of a mathematical argument could invalidate the entire project. Furthermore, the sophistication of a typical math project is such that it would not be realistic to expect a member of the public, with say an undergraduate level of mathematics education, to contribute in a meaningful way to many such projects.")

#text("For related reasons, it is also challenging to incorporate assistance from modern AI tools into a research project, as these tools can “hallucinate” plausible-looking, but nonsensical arguments, which therefore need additional verification before they could be added into the project.")

#link("https://en.wikipedia.org/wiki/Proof_assistant")[#text("Proof assistant")]#text(" languages, such as ")#link("https://en.wikipedia.org/wiki/Lean_(proof_assistant)")[#text("Lean")]#text(", provide a potential way to overcome these obstacles, and allow for large-scale collaborations involving professional mathematicians, the broader public, and/or AI tools to all contribute to a complex project, provided that it can be broken up in a modular fashion into smaller pieces that can be attacked without necessarily understanding all aspects of the project as a whole. Projects to formalize an existing mathematical result (such as the formalization of the recent proof of the PFR conjecture of Marton, discussed in ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("this previous blog post")]#text(") are currently the main examples of such large-scale collaborations that are enabled via proof assistants. At present, these formalizations are mostly crowdsourced by human contributors (which include both professional mathematicians and interested members of the general public), but there are also some nascent efforts to incorporate more automated tools (either “good old-fashioned” automated theorem provers, or more modern AI-based tools) to assist with the (still quite tedious) task of formalization.")

#text("However, I believe that this sort of paradigm can also be used to explore new mathematics, as opposed to formalizing existing mathematics. The online collaborative “Polymath” projects that several people including myself organized in the past are one example of this; but as they did not incorporate proof assistants into the workflow, the contributions had to be managed and verified by the human moderators of the project, which was quite a time-consuming responsibility, and one which limited the ability to scale these projects up further. But I am hoping that the addition of proof assistants will remove this bottleneck.")

#text("I am particularly interested in the possibility of using these modern tools to explore a ")#emph[#text("class")]#text(" of many mathematical problems at once, as opposed to the current approach of focusing on only one or two problems at a time. This seems like an inherently modularizable and repetitive task, which could particularly benefit from both crowdsourcing and automated tools, if given the right platform to rigorously coordinate all the contributions; and it is a type of mathematics that previous methods usually could not scale up to (except perhaps over a period of many years, as individual papers slowly explore the class one data point at a time until a reasonable intuition about the class is attained). Among other things, having a large data set of problems to work on could be helpful for benchmarking various automated tools and compare the efficacy of different workflows.")

#text("One recent example of such a project was the ")#link("https://bbchallenge.org/13132838")[#text("Busy Beaver Challenge")]#text(", which showed this July that the fifth ")#link("https://en.wikipedia.org/wiki/Busy_beaver")[#text("Busy Beaver")]#text(" number ")#mi("{BB(5)}")#text(" was equal to ")#mi("{47176870}")#text(". Some older crowdsourced computational projects, such as the ")#link("https://www.mersenne.org/")[#text("Great Internet Mersenne Prime Search (GIMPS)")]#text(", are also somewhat similar in spirit to this type of project (though using more traditional proof of work certificates instead of proof assistants). I would be interested in hearing of any other extant examples of crowdsourced projects exploring a mathematical space, and whether there are lessons from those examples that could be relevant for the project I propose here.")

#text("More specifically I would like to propose the following (admittedly artificial) project as a pilot to further test out this paradigm, which was inspired by a ")#link("https://mathoverflow.net/questions/450930/is-there-an-identity-between-the-associative-identity-and-the-constant-identity")[#text("MathOverflow question")]#text(" from last year, and discussed somewhat further on ")#link("https://mathstodon.xyz/@tao/110736805384878353")[#text("my Mastodon account")]#text(" shortly afterwards.")

#text("The problem is in the field of ")#link("https://en.wikipedia.org/wiki/Universal_algebra")[#text("universal algebra")]#text(", and concerns the (medium-scale) exploration of simple equational theories for ")#link("https://en.wikipedia.org/wiki/Magma_(algebra)")[#text("magmas")]#text(". A magma is nothing more than a set ")#mi("{G}")#text(" equipped with a binary operation ")#mi("{\\circ: G \\times G \\rightarrow G}")#text(". Initially, no additional axioms on this operation ")#mi("{\\circ}")#text(" are imposed, and as such magmas by themselves are somewhat boring objects. Of course, with additional axioms, such as the identity axiom or the associative axiom, one can get more familiar mathematical objects such as groups, semigroups, or monoids. Here we will be interested in (constant-free) ")#emph[#text("equational axioms")]#text(", which are axioms of equality involving expressions built from the operation ")#mi("{\\circ}")#text(" and one or more indeterminate variables in ")#mi("{G}")#text(". Two familiar examples of such axioms are the ")#emph[#text("commutative axiom")]

#align(center)[#tao-fit-display[#mitex("x \\circ y = y \\circ x")]]

#text("and the ")#emph[#text("associative axiom")]

#align(center)[#tao-fit-display[#mitex("(x \\circ y) \\circ z = x \\circ (y \\circ z),")]]

#text("where ")#mi("{x,y,z}")#text(" are indeterminate variables in the magma ")#mi("{G}")#text(". On the other hand the (left) identity axiom ")#mi("{e \\circ x = x}")#text(" would not be considered an equational axiom here, as it involves a constant ")#mi("{e \\in G}")#text(" (the identity element), which we will not consider here.")

#text("To illustrate the project I have in mind, let me first introduce eleven examples of equational axioms for magmas:")

#list(
[#text("Equation1: ")#mi("{x=y}")],
[#text("Equation2: ")#mi("{x \\circ y = z \\circ w}")],
[#text("Equation3: ")#mi("{x \\circ y = x}")],
[#text("Equation4: ")#mi("{(x \\circ x) \\circ y = y \\circ x}")],
[#text("Equation5: ")#mi("{x \\circ (y \\circ z) = (w \\circ u) \\circ v}")],
[#text("Equation6: ")#mi("{x \\circ y = x \\circ z}")],
[#text("Equation7: ")#mi("{x \\circ y = y \\circ x}")],
[#text("Equation8: ")#mi("{x \\circ (y \\circ z) = (x \\circ w) \\circ u}")],
[#text("Equation9: ")#mi("{x \\circ (y \\circ z) = (x \\circ y) \\circ w}")],
[#text("Equation10: ")#mi("{x \\circ (y \\circ z) = (x \\circ y) \\circ z}")],
[#text("Equation11: ")#mi("{x = x}")]
)

#text("Thus, for instance, Equation7 is the commutative axiom, and Equation10 is the associative axiom. The trivial axiom Equation1 is the strongest, as it forces the magma ")#mi("{G}")#text(" to have at most one element; at the opposite extreme, the reflexive axiom Equation11 is the weakest, being satisfied by every single magma.")

#text("One can then ask which axioms imply which others. For instance, Equation1 implies all the other axioms in this list, which in turn imply Equation11. Equation8 implies Equation9 as a special case, which in turn implies Equation10 as a special case. The full poset of implications can be depicted by the following ")#link("https://en.wikipedia.org/wiki/Hasse_diagram")[#text("Hasse diagram")]#text(":")

#image("../assets/a7d44b55a5419b5290158976c7e8023e0379127f3473c624c1cc44ce0d3856a2-314548a3e521145b33d493fdf8d49bcebf96a33e304407dfbcdea161fe82a968.png", width: 90%)

#text("This in particular answers the MathOverflow question of whether there were equational axioms intermediate between the constant axiom Equation1 and the associative axiom Equation10.")

#text("Most of the implications here are quite easy to prove, but there is one non-trivial one, obtained in ")#link("https://mathoverflow.net/a/450905/766")[#text("this answer to a MathOverflow post")]#text(" closely related to the preceding one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Equation4 implies Equation7.")
]

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{G}")#text(" obeys Equation4, thus ")#metadata(none) <tao-f0d853d26e0e2652683e>#mi("\\displaystyle  (x \\circ x) \\circ y = y \\circ x \\ \\ \\ \\ \\ (1)")#text(" ")#text(" for all ")#mi("{x,y \\in G}")#text(". Specializing to ")#mi("{y=x \\circ x}")#text(", we conclude")

#align(center)[#tao-fit-display[#mitex("(x \\circ x) \\circ (x \\circ x) = (x \\circ x) \\circ x")]]

#text("and hence by another application of ")#link(<tao-f0d853d26e0e2652683e>)[#text("(1)")]#text(" we see that ")#mi("{x \\circ x}")#text(" is idempotent:")

#metadata(none) <tao-b43aae102b191a96b0ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(x \\circ x) \\circ (x \\circ x) = x \\circ x.")]]

#text("Now, replacing ")#mi("{x}")#text(" by ")#mi("{x \\circ x}")#text(" in ")#link(<tao-f0d853d26e0e2652683e>)[#text("(1)")]#text(" and then using ")#link(<tao-b43aae102b191a96b0ee>)[#text("(2)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("(x \\circ x) \\circ y = y \\circ (x \\circ x),")]]

#text("so in particular ")#mi("{x \\circ x}")#text(" commutes with ")#mi("{y \\circ y}")#text(":")

#metadata(none) <tao-27bfcd1dee4f22c8fe8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(x \\circ x) \\circ (y \\circ y) = (y \\circ y) \\circ (x \\circ x).")]]

#text("Also, from two applications ")#link(<tao-f0d853d26e0e2652683e>)[#text("(1)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("(x \\circ x) \\circ (y \\circ y) = (y \\circ y) \\circ x = x \\circ y.")]]

#text("Thus ")#link(<tao-27bfcd1dee4f22c8fe8a>)[#text("(3)")]#text(" simplifies to ")#mi("{x \\circ y = y \\circ x}")#text(", which is Equation7. ")#mi("\\Box")

#text("A formalization of the above argument in Lean can be found ")#link("https://live.lean-lang.org/#codez=JYWwDg9gTgLgBAWQIYwBYBtgCMB0AVJAYxmEICgyBXAO2ADcBTKAZwbkosPSWecSQDmIJHAAUgRuA4ALjh4AnmDaUAlHADuqJgzJw4EMNLiTASYRG4p8RWDUAZsAAe6KQDYArHABEcQBhEn3XABeAD5+ISQcfQoAEwYbOABRAEdKFGAIagAWMQBxGXlFACpVAG1kMLhsgF1pALhAACI4ezg5Q2yAGjEm33tVXxbalu7o2ITk1PSAdhy8hQYiuFLBYQrqqVqGppaZdsafZsD9obI0BmgGEFGUknSMgH1QMEwGZlukq7TqKdFc2Vn5xfKVTEqBkb3GmQqqlBY2unwqNTgWDkOjgqCQjDgwBiF1ETW2UM6ex6e1xRNUtVJ3ShtSRKN0UDUC1Qu0pjWUHWZTXslRRaIxhAgIBxm1aBNZxL6B0GhKpCNp/jgDIWAB4ALRY86NDkytnNDoai7c3notj6e7YwlbSGGcW9MTSuTk3aStaI5EKpXFTn2vaO7UtI26awwKAQXbuxWM4pqvRgc2azYdAVClkO9mx+MXAOVIA")[#text("here")]#text(".")

#text("I will remark that the general question of determining whether one set of equational axioms determines another is undecidable; see Theorem 14 of ")#link("https://zbmath.org/0197.28201")[#text("this paper of Perkins")]#text(". (This is similar in spirit to the more well known undecidability of various ")#link("https://en.wikipedia.org/wiki/Word_problem_(mathematics)")[#text("word problems")]#text(".) So, the situation here is somewhat similar to the Busy Beaver Challenge, in that past a certain point of complexity, we would necessarily encounter unsolvable problems; but hopefully there would be interesting problems and phenomena to discover before we reach that threshold.")

#text("The above Hasse diagram does not just assert implications between the listed equational axioms; it also asserts ")#emph[#text("non-implications")]#text(" between the axioms. For instance, as seen in the diagram, the commutative axiom Equation7 does ")#emph[#text("not")]#text(" imply the Equation4 axiom")

#align(center)[#tao-fit-display[#mitex("(x+x)+y = y + x.")]]

#text("To see this, one simply has to produce an example of a magma that obeys the commutative axiom Equation7, but not the Equation4 axiom; but in this case one can simply choose (for instance) the natural numbers ")#mi("{{\\bf N}}")#text(" with the addition operation ")#mi("{x \\circ y := x+y}")#text(". More generally, the diagram asserts the following non-implications, which (together with the indicated implications) completely describes the poset of implications between the eleven axioms:")

#list(
[#text("Equation2 does not imply Equation3.")],
[#text("Equation3 does not imply Equation5.")],
[#text("Equation3 does not imply Equation7.")],
[#text("Equation5 does not imply Equation6.")],
[#text("Equation5 does not imply Equation7.")],
[#text("Equation6 does not imply Equation7.")],
[#text("Equation6 does not imply Equation10.")],
[#text("Equation7 does not imply Equation6.")],
[#text("Equation7 does not imply Equation10.")],
[#text("Equation9 does not imply Equation8.")],
[#text("Equation10 does not imply Equation9.")],
[#text("Equation10 does not imply Equation6.")]
)

#text("The reader is invited to come up with counterexamples that demonstrate some of these implications. The hardest type of counterexamples to find are the ones that show that Equation9 does not imply Equation8: a solution (in Lean) can be found ")#link("https://live.lean-lang.org/#codez=JYWwDg9gTgLgBAWQIYwBYBtgCMB0ARFJHAORXwFMAzAZwChRJZEUNscAVJAYxmC9toBXAHbAAbuSjVycQQK7ok1aswDmIJHAAUgRuA4ALjjsAnmBmCAlHADuqSeVpw4EMAbh7ASYTu4XnQODClMAAHuj6AGwArHAARHCAGESxTnAAvAB8aho4LgIAJlRwAKIAjoIowBDCABzaAOKGJmYAVFYA2sjqmrUAugYpcIAARHDBcMZwAF42sm61ADTDCdpjieNW/VojidZWiXK0+ZRFpeWVAJx1DabkLXDtSJ1wPX2DC2OT1jPzm0uLq6na32MOxsAjQ5Gg5BARzKvDOAH1hBAYHCGJhyNQ4SUYRVqm5AMBEFyMVysWjhhg6GkeFnmWJOwnOtTggHIiOAAGuhdJqjP0/SwxkccHQ5HgqG5mU0pHgPLgAG8BU4XM9KCJXqkMsBDiN+gAGOBg4TaDWjOCAEyI4AAmPV2A0ARjg5HQ0gtVgdTuCAoAvgLBE7AKiE81FAq4lWoMCggh40AFODgATDEFV73lcD5cK4SnRcFQbi1cG1yZj1AYt1FAe6yacqCQEjc7K0RrGZst+rgdtdMnNazzzz5FeSqfT0hUqAA5G5Gxa+05C8XWqPy8lF3Ai+ASyOF0uV65WmhgNQN4vg8JVFBW32Bxnh7rDGMdX2Z6u59qD0uL0Os5NDJMm1O4A/t6g4wvouW4lkB57GGml5ZmON6mpOS5/sus6oNqAbrn2oFziOAbPsmWGllmG4DpUYaaKgApQOQYCKFwMjZtK2a6sxcAAMxsQKuQEU8KBZgKmDCEgUDAGgtBAA")[#text("here")]#text(". I placed proofs in Lean of all the above implications and anti-implications can be found in ")#link("https://github.com/teorth/equational_theories/blob/main/equational_theories/Basic.lean")[#text("this github repository file")]#text(".")

#text("As one can see, it is already somewhat tedious to compute the Hasse diagram of just eleven equations. The project I propose is to try to expand this Hasse diagram by a couple orders of magnitude, covering a significantly larger set of equations. The set I propose is the set ")#mi("{{\\mathcal E}}")#text(" of equations that use the magma operation ")#mi("{\\circ}")#text(" at most four times, up to relabeling and the reflexive and symmetric axioms of equality; this includes the eleven equations above, but also many more. How many more? Recall that the ")#link("https://en.wikipedia.org/wiki/Catalan_number")[#text("Catalan number")]#text(" ")#mi("{C_n}")#text(" is the number of ways one can form an expression out of ")#mi("{n}")#text(" applications of a binary operation ")#mi("{\\circ}")#text(" (applied to ")#mi("{n+1}")#text(" placeholder variables); and, given a string of ")#mi("{m}")#text(" placeholder variables, the ")#link("https://en.wikipedia.org/wiki/Bell_number")[#text("Bell number")]#text(" ")#mi("{B_m}")#text(" is the number of ways (up to relabeling) to assign names to each of these variables, where some of the placeholders are allowed to be assigned the same name. As a consequence, ignoring symmetry, the number of equations that involve at most four operations is")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,m \\geq 0: n+m \\leq 4} C_n C_m B_{n+m+2} = 9341.")]]

#text("The number of equations in which the left-hand side and right-hand side are identical is")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^2 C_n B_{n+1} = 1 * 1 + 1 * 2 + 2 * 5 = 13;")]]

#text("these are all equivalent to reflexive axiom (Equation11). The remaining ")#mi("{9328}")#text(" equations come in pairs by the symmetry of equality, so the total size of ")#mi("{{\\mathcal E}}")#text(" is")

#align(center)[#tao-fit-display[#mitex("1 + \\frac{9328}{2} = 4665.")]]

#text("I have not yet generated the full list of such identities, but presumably this will be straightforward to do in a standard computer language such as Python (I have not tried this, but I imagine some back-and-forth with a modern AI would let one generate most of the required code). [UPDATE, Sep 26: Amir Livne Bar-on has kindly enumerated all the equations, of which there are actually 4694.]")

#text("It is not clear to me at all what the geometry of ")#mi("{{\\mathcal E}}")#text(" will look like. Will most equations be incomparable with each other? Will it stratify into layers of “strong” and “weak” axioms? Will there be a lot of equivalent axioms? It might be interesting to record now any speculations as what the structure of this poset, and compare these predictions with the outcome of the project afterwards.")

#text("A brute force computation of the poset ")#mi("{{\\mathcal E}}")#text(" would then require ")#mi("{4665 \\times (4665-1) = 21757560}")#text(" comparisons, which looks rather daunting; but of course due to the axioms of a partial order, one could presumably identify the poset by a much smaller number of comparisons. I am thinking that it should be possible to crowdsource the exploration of this poset in the form of submissions to a central repository (such as the ")#link("https://github.com/teorth/equational_theories")[#text("github repository I just created")]#text(") of proofs in Lean of implications or non-implications between various equations, which could be validated in Lean, and also checked against some file recording the current status (true, false, or open) of all the ")#mi("{21757560}")#text(" comparisons, to avoid redundant effort. Most submissions could be handled automatically, with relatively little human moderation required; and the status of the poset could be updated after each such submission.")

#text("I would imagine that there is some “low-hanging fruit” that could establish a large number of implications (or anti-implications) quite easily. For instance, laws such as Equation2 or Equation3 more or less completely describe the binary operation ")#mi("{\\circ}")#text(", and it should be quite easy to check which of the ")#mi("{4665}")#text(" laws are implied by either of these two laws. The poset ")#mi("{{\\mathcal E}}")#text(" has a reflection symmetry associated to replacing the binary operator ")#mi("{\\circ}")#text(" by its reflection ")#mi("{\\circ^{\\mathrm{op}}: (x,y) \\mapsto y \\circ x}")#text(", which in principle cuts down the total work by a factor of about two. Specific examples of magmas, such as the natural numbers with the addition operation, obey some set of equations in ")#mi("{{\\mathcal E}}")#text(" but not others, and so could be used to generate a large number of anti-implications. Some existing automated proving tools for equational logic, such as ")#link("https://www.cs.unm.edu/~mccune/prover9/")[#text("Prover9 and Mace4")]#text(" (for obtaining implications and anti-implications respectively), could then be used to handle most of the remaining “easy” cases (though some work may be needed to convert the outputs of such tools into Lean). The remaining “hard” cases could then be targeted by some combination of human contributors and more advanced AI tools.")

#text("Perhaps, in analogy with formalization projects, we could have a semi-formal “blueprint” evolving in parallel with the formal Lean component of the project. This way, the project could accept human-written proofs by contributors who do not necessarily have any proficiency in Lean, as well as contributions from automated tools (such as the aforementioned Prover9 and Mace4), whose output is in some other format than Lean. The task of converting these semi-formal proofs into Lean could then be done by other humans or automated tools; in particular I imagine modern AI tools could be particularly valuable for this portion of the workflow. I am not quite sure though if existing blueprint software can scale to handle the large number of individual proofs that would be generated by this project; and as this portion would not be formally verified, a significant amount of human moderation might also be needed here, and this also might not scale properly. Perhaps the semi-formal portion of the project could instead be coordinated on a forum such as this blog, in a similar spirit to past Polymath projects.")

#text("It would be nice to be able to integrate such a project with some sort of graph visualization software that can take an incomplete determination of the poset ")#mi("{{\\mathcal E}}")#text(" as input (in which each potential comparison ")#mi("{E \\implies E^{\\prime}}")#text(" in ")#mi("{{\\mathcal E}}")#text(" is marked as either true, false, or open), completes the graph as much as possible using the axioms of partial order, and then presents the partially known poset in a visually appealing way. If anyone knows of such a software package, I would be happy to hear of it in the comments.")

#text("Anyway, I would be happy to receive any feedback on this project; in addition to the previous requests, I would be interested in any suggestions for improving the project, as well as gauging whether there is sufficient interest in participating to actually launch it. (I am imagining running it vaguely along the lines of a Polymath project, though perhaps not formally labeled as such.)")

#strong[#text("UPDATE")]#text(", Sep 30 2024: The project is up and running (and highly active), with the main page being ")#link("https://github.com/teorth/equational_theories")[#text("this Github repository")]#text(". See also the ")#link("https://leanprover.zulipchat.com/#narrow/stream/458659-Equational/")[#text("Lean Zulip chat")]#text(" for some (also very active) discussion on the project.")

#heading(level: 1)[#text("Comments (81)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8227f99ec4952fff9a5f3fa21caf4d99bb95fa1f01a956516f2393806ca8de66-311487389dee65622d7b642b4f4a7d348f1cd3f60fb9b7132effa2ab9bd4fac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oussama Basta")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685848")[#strong[#text("Oussama Basta")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2024")])]

#text("Hello, I am working on a resembling topic, were an expression of any field of mathematics can be denoted using prime numbers using a map, and then we can in the prime-encoded-domain use prime-encoded-domain operators, thid domain work in a way that resembles binary and boolean representation of algebra as an example, well here are the implications: all math fields expressions will be treated the same way in this domain and solved with the same number of steps, 1. Prime encoding 2. Simplifying 3. Factorization 4. Decoding to the original notation. I developed a proving algorithm and tested on some proven problems and also used to solve problems like PDEs and such. Please visit my ResearchGate preprint:")#link("https://www.researchgate.net/publication/382477678_Prime_Encoding_in_Mathematics_A_Novel_Approach_to_Symbolic_Computation")[#text("https://www.researchgate.net/publication/382477678_Prime_Encoding_in_Mathematics_A_Novel_Approach_to_Symbolic_Computation")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8227f99ec4952fff9a5f3fa21caf4d99bb95fa1f01a956516f2393806ca8de66-311487389dee65622d7b642b4f4a7d348f1cd3f60fb9b7132effa2ab9bd4fac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oussama Basta")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686064")[#strong[#text("Oussama Basta")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2024")])]

#text("We have an Arabic proverb and it goes like “My Allah bless you with pilgrimage when they are coming back”, did you buy the dislikes, i don’t think any mathematical peice deserves this many, specially if it wrong TT.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8227f99ec4952fff9a5f3fa21caf4d99bb95fa1f01a956516f2393806ca8de66-311487389dee65622d7b642b4f4a7d348f1cd3f60fb9b7132effa2ab9bd4fac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oussama Basta")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686065")[#strong[#text("Oussama Basta")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2024")])]

#text("Here’s my dislike")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("You probably need to state whether the answer to the mathematical problem or the development of new ways of collaboration in mathematics is more important to you. Formative process evaluation is going to change the process a lot. A.I. is constantly upgraded at the moment as are online collaboration tools. On the meta level you are going to re-invent the wheel many times. The people contributing should be made aware of that and ready to accept that they will have to learn a new structure of the entire project several times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685858")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("For this project I would say the latter, although I also think that some unexpected features or phenomena of the space of equational theories may emerge from such an exploration that could be quite mathematically interesting, simply because these sorts of explorations have not really been made before and so there will be ")#emph[#text("terra incognita")]#text(". I think a proof-of-concept such as this may help determine what types of collaborative or AI-assisted workflows are more effective than others, and these lessons may be robust even as the technology develops at a rapid pace. But I expect some technologies to stay stable; for instance, the Github platform is rather well established with a successful track record, and I imagine that it, or some derived clone, will remain useful for many years to come.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("I generated the list of equations, you can find it here:")

#link("https://github.com/amirlb/magma/blob/trunk/equations.txt")[#text("https://github.com/amirlb/magma/blob/trunk/equations.txt")]

#text("This is slightly longer than your calculation – 4694 equations. I think the calculation doesn’t account for the fact that equations such as")

#text("x ◦︎ x = y ◦︎ y")

#text("aren’t counted twice, so should be excluded from the division by two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Thanks for this (and for uploading the script and text to the github)! You are right, I undercounted the number of equations slightly, though fortunately I still got the order of magnitude correct, which was the main thing…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("EDIT: I have decided to make your numbering and labeling of the equations the canonical one for this project. In particular, what used to be called Equations 1-11 in the Lean file is now Equations 2, 46, 4, 387, 4582, 42, 43, 4552, 4513, 4512, 1 as per your text file. Also this provides an easy way to slowly scale up the project, one simply adds some appropriately sized set of new equations from the master list into the working Lean document. So I have gone ahead and added five more equations (Equations 3, 5, 6, 7, 8 in your list) to the Lean file. In principle anyone can now contribute new implications involving this larger set of 16 equations to the Lean file via a pull request, but I will now focus on setting up suitable CI so that will be able to automatically verify such contributions, as well as a blueprint that could track what implications are desired.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3529ef3432f19f545244ebd5f1dcf2e0c12c9d7a202f84575075a8a6a8f28b46-4e0415730b98015d10729ff930abd4ed7e2d3b9eb85d1d109c12918dde1913bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoseBrox")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-688833")[#strong[#text("JoseBrox")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2025")])]

#text("I think there is a typo in the approximate computation ignoring symmetries. It doesn’t matter much now, but since the project’s report paper references this page, it could be better to fix it. You wrote")

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle++%5Csum_%7Bn%2Cm+%5Cgeq+0%3A+n%2Bm+%5Cleq+4%7D+C_n+C_m+B_%7Bn%2Bm%2B2%7D+%3D+9131.&bg=ffffff&fg=000000&s=0&c=20201002&zoom=4.5")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle++%5Csum_%7Bn%2Cm+%5Cgeq+0%3A+n%2Bm+%5Cleq+4%7D+C_n+C_m+B_%7Bn%2Bm%2B2%7D+%3D+9131.&bg=ffffff&fg=000000&s=0&c=20201002&zoom=4.5")]

#text("SAGE gives me 9341 instead of 9131 (can you double check?). Consequently, the final approximation is 4665 instead of 4560 -even closer to the actual figure!")

#emph[#text("[Confirmed and corrected – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("can someone explain please why x ◦︎ x = x ◦︎ x isn’t on the list?")

#text("wouldn’t it mean “only elements that are possible results of x ◦︎ x are guaranteed to be equal to themselves”? which is slightly weaker than x = x, where it applies to all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685892")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("The law ")#mi("x = x")#text(" and the law ")#mi("x \\circ x = x \\circ x")#text(" are satisfied by all magmas, due to the reflexive axiom for equality (which is part of the axioms of first-order logic, which is the ambient logical framework that is implicitly assumed here), so they are logically equivalent.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Some of the proofs of the implications can get extremely long if the axioms are compatible in subtle ways. A good example of such surprising scaling was the proof of the Robbins conjecture generated with automated theorem prover by William McCune in 1996. The proof is rather hard with several thousands steps of various substitutions. Current version of the proof was optimized by humans but it is still “barely” readable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Right, I am hoping that this space is just complex enough to capture a reasonable data set of difficult implications that could then serve as a benchmark for various automated tools, at a larger scale than that of individual conjectures such as the Robbins conjecture. Alternatively, the exploration could reveal that the theories of a single equation are considerably simpler than the theories of multiple equations; this also would be an interesting empirical observation to learn about.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Allready ? There are so many nice encoding, since the syntax of a magma is a simple algebraic datatype :")

#text("M = Var + M*M")

#text("Where + is a disjoint sum, * a cartesian product, and = an isomorphism (or a least fixed point operator). Var, the set of variables is isomorphic to the set of natural number.")

#text("I’m sure Lean could have handled it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d68edaf1b08f310886b89f27f77459c80d00e7e66f95d1d949724f6aed20f4-169737cd43f66f0dc8e17d4cc5f25a93edc6616f77e278f9a1f0943afd7ac9ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul F Dietz")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685889")[#strong[#text("Paul F Dietz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("I was going to say that this subject seems closely related to the work done at Argonne, of which the result you mention is a part. This is very old school theorem proving.")

#link("https://www.mcs.anl.gov/research/projects/AR/")[#text("https://www.mcs.anl.gov/research/projects/AR/")]

#text("I don’t think this group is still there at Argonne; I know Larry Wos died in 2020. Wos started doing theorem proving in 1963!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("I didn’t notice the Github link when reading before, sending this as a PR there too")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685862")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Thanks! I also see you constructed a script to automatically detect if there are any missing implications. Using that tool, I found that I neglected to add a proof that Equation3 implies Equation8, but I have now added this implication. On the other hand, your tool reports that (For instance) there is no proof or disproof of Equation6 implying Equation9, but the file contains a proof that Equation6 does not imply Equation10, while Equation9 implies Equation10, so together this shows that Equation6 does not imply Equation9. Still, this is a very useful tool to have in the project! I have not currently implemented any continuous integration in the github project, but I could imagine that this tool could somehow be placed into the CI (I am not an expert in this aspect of github though, and would need some help to implement it properly).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Oops! I had a bug in the script – it wouldn’t recognize equations whose number was more than one digit.")

#text("Fixing now, I’ll send a pull request soon.")

#text("There are now 3 missing counter-examples, in the new numbering they are 387 => 42, 387 => 4512, and 43 => 387.")

#text("The script prints 7 missing proofs, I’ll develop a version that reduces to the minimal required proofs later on. We’re unlikely to be at the point where undecidability occurs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Thanks! After fixing some naming typos in the current version, I have now put stubs for the 387 => 42 and 43 => 387 counterexamples in the Lean code and in the blueprint, see ")#link("https://teorth.github.io/equational_theories/blueprint/sect0004.html#387_not_imply_42")[#text("here")]#text(" and ")#link("https://teorth.github.io/equational_theories/blueprint/sect0004.html#43_not_imply_387")[#text("here")]#text(". Anyone is welcome to fill in the `sorry`s here with a suitable construction!")

#text("Regarding the counterexample for 387 => 4512, it appears this should be covered by the existing implication 387 => 43 together with the existing counterexample for 43 => 4512. (But this may have been an artefact of the typos I previously mentioned; when I changed over the equation numbering, some of the Lean theorem names did not change properly.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a76ca8548c89d9589598628323376f4259e39eebd80ddcae78759b8ca07a0b1-abd193314a20d6bde09857a88f1c1aec7b995ba146f829dac06f34e235df9096.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amirlb")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685883")[#strong[#text("amirlb")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("The counter-example for 43 => 4512 is x ∘ y = xy + 1.")

#text("This doesn’t satisfy equation 387 (x ∘ y = (y ∘ y) ∘ x), and anyway it would need to be stated in Lean for the script to acknowledge it.")

#text("I’ll add a sorry for that later, or we can delay it until we figure out a structure for the other millions of propositions.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Should the projet also include composed implications, e.g., of the form (a) & (b) => (c) or (a) & (b) & (c) => (d)? Or would this make the number of implications to prove explose in an unreasonnable way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("i am not sure on the feasibility aspect. but, to me, being able to ask about the relations between composite axioms is a much more compelling project.")

#text("this turns the structure from a poset to a meet-semilattice. obviously a Hasse diagram can be made either from (1) the atomic axioms or (2) the logically distinct composites. but maybe a more natural (at least, more full) diagrammatic representation would be some kind of hypergraph. (is there any existing software for such a thing?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685861")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("This could well be a future direction of the project, if the pilot is successful, but given that so many of the aspects of this project are novel, I think it would be prudent to be relatively unambitious mathematically for the initial stage, and defer more complex and interesting mathematical challenges to after all the initial kinks in the workflow are smoothed out, and we have a better idea of what can and cannot be easily achieved with this sort of paradigm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abdf3e4b60ac3acbe57e897c4c23049f57b9ce606a2b589a804eeb77a9d39a23-fbba79dce71acdd210094ee1982e6d9f0751054b9ced244bbca7b18290c7512f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uzi Vishne")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685961")[#strong[#text("Uzi Vishne")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")])]

#text("By considering implications between sets of equations you would be studying *varieties* of magmas, rather than *equations*. This is more reasonable from a structural perspective.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685863")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("A commenter on my Mastodon account has pointed me towards the recent paper ")#link("https://dl.acm.org/doi/10.1145/3632900")[#text("https://dl.acm.org/doi/10.1145/3632900")]#text(" of Koehler et al. which provides software to perform automated proving of equations in Lean, so this would presumably be an ideal tool to deploy in this project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c75520eec1db386d193781135cf0ec1d4fc672ebb3047590ba9b360133890f3-de115aa4b3182275039e0c73fc88a94f0f28f976bf916e0d80f30c9a91c97eca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bollu")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685871")[#strong[#text("bollu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("As an author on the guided equality saturation paper (Siddharth Bhat), I’d like to chime in: The e-graph is a very powerful data structure, but grows very quickly. The human ingenuity was a critical component to get the guided equality saturation to work, and it would indeed be very interesting to see if a AI-assisted prover could provide these sketches for us. Happy to chat more on the Lean zulip: ")#link("https://leanprover.zulipchat.com/#narrow/dm/130575-Siddharth-Bhat")[#text("https://leanprover.zulipchat.com/#narrow/dm/130575-Siddharth-Bhat")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685864")[#strong[#text("在普遍代数领域开展试点项目，探索新的合作方式并利用人工智能。 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Note: I am moving the github repository to a new location ")#link("https://github.com/teorth/equational_theories")[#text("https://github.com/teorth/equational_theories")]#text(" which supports the Lean blueprint CI. I will also move over the most recent PRs to the old site, but going forward please use the new repository. (I will also update the blog post links to redirect to this new repo shortly.)")

#text("UPDATE: the new repository is now active, with a ")#link("https://teorth.github.io/equational_theories/blueprint/")[#text("blueprint")]#text(" (complete with ")#link("https://teorth.github.io/equational_theories/blueprint/dep_graph_document.html")[#text("dependency graph")]#text("), ")#link("https://teorth.github.io/equational_theories/")[#text("web page")]#text(", ")#link("https://leanprover.zulipchat.com/#narrow/stream/458659-Equational/")[#text("Lean Zulip stream")]#text(", and ")#link("https://leanprover.zulipchat.com/#narrow/stream/458659-Equational/")[#text("documentation page")]#text(", among other things. I’ve also updated the graph of dependencies to reflect the new numbering as well as the newly added equations that need to be placed within the graph ")#link("https://github.com/teorth/equational_theories/blob/main/images/implications.png")[#text("here")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e2af9d00667e0f89cedce6a8da9de80793e598e70a463d84880846491ad7085-b311d6eeebd5845ce4f87ee16e2fd40b6e870126c7891d967d527a2006454b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Varga")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685875")[#strong[#text("Alexander Varga")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("We could generate a 4694 x 4694 pixel image where each pixel is colored by whether x -> y is proven, disproven, or unknown. And then animate it over time :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("This could be a nice visualization tool. I see you uploaded a proof of concept to the repository, but the ")#link("https://private-user-images.githubusercontent.com/1190809/371270808-bee6a5a1-6904-495a-bd09-f5d4bf5171af.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MjczNzc3MzksIm5iZiI6MTcyNzM3NzQzOSwicGF0aCI6Ii8xMTkwODA5LzM3MTI3MDgwOC1iZWU2YTVhMS02OTA0LTQ5NWEtYmQwOS1mNWQ0YmY1MTcxYWYucG5nP1gtQW16LUFsZ29yaXRobT1BV1M0LUhNQUMtU0hBMjU2JlgtQW16LUNyZWRlbnRpYWw9QUtJQVZDT0RZTFNBNTNQUUs0WkElMkYyMDI0MDkyNiUyRnVzLWVhc3QtMSUyRnMzJTJGYXdzNF9yZXF1ZXN0JlgtQW16LURhdGU9MjAyNDA5MjZUMTkwMzU5WiZYLUFtei1FeHBpcmVzPTMwMCZYLUFtei1TaWduYXR1cmU9OTYyNWY3ZGE1NjczNTJkMGU5MDQwMTg4NjA0NDExNDFmYjIyMDY4NzIyMGQxNDI0N2FmY2IwYzU4Y2E4ZjNjZiZYLUFtei1TaWduZWRIZWFkZXJzPWhvc3QifQ.3utvES5VVL9VdVTSR-v31RChKmKIR8leVbiQ0ntNWjY")[#text("image you provided")]#text(" is almost completely black. Are you just reporting the implications that are given in the Lean file, or are you completing them with respect to the poset axioms? (For instance, the Lean file contains the implications 2 => 46 and 46 => 387, which then implies 2 => 387, even though this implication is not explicitly stated in the Lean file.)")

#text("In the meantime, I ")#link("https://github.com/teorth/equational_theories/blob/main/images/implications.png")[#text("updated my Inkscape image")]#text(" of the implications to reflect the new numbering and also the newly added equations that need to be placed in the graph. If anyone wishes to work out where these equations go in the graph (by determining enough implications and anti-implications between these new equations and the existing ones to get a reasonably good placement), please feel free to do so. Presumably this manually created Inkscape image will not scale well as the project expands, but for the very short term it might suffice as a guide until we find an automatic image generation solution that is more scaleable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685926")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2024")])]

#text("Such a visualisation is fun, but the set of orderings of the axioms needs to be explored a little, to make sense of the image. For instance, doing something like pushing a lot of the trivial information down the back of the list, and then only showing the interesting part of the image. Or some other kind of filtering process.")

#text("As an example, in a computational paper with a student, I visualised the {0,1}-valued (twisted) cocycle for the Moufang loop extension of the Golay code by proving that the O(16million) pixels in our first image that looked like noise were generated by a more ordered 128×128 grid, which we sorted judiciously to reveal interesting structure. There was lots of exploration, both in a coded random-walk way, but also by noticing patterns and doing some theoretical work.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("This is an incredibly exciting project, and I believe it has the potential to significantly advance not only the formalization of mathematics but also the development of AI tools that can ")#strong[#text("“think”")]#text(" and assist in automating complex mathematical arguments.")

#text("By creating a comprehensive database of equations and their relationships, as you propose, we would not only crowdsource mathematical discovery but also build a ")#strong[#text("benchmarking tool")]#text(" for AI-based theorem provers and automated tools. AI systems could use this structured data to better understand patterns in mathematical logic and even improve their reasoning capabilities. This is especially valuable in the development of ")#strong[#text("next-generation AI")]#text(" tools that might one day assist with, or even automate, more sophisticated aspects of mathematical research.")

#text("Additionally, I see enormous value in this project for people who are not yet fully proficient in proof assistants like Lean. Such a ")#strong[#text("collaborative platform")]#text(" could help bridge the gap for those who want to contribute to formalization but might find the process of formal proof writing daunting. Automated tools or more experienced users could help convert “blueprints” or informal proofs into fully verified formal proofs, reducing the burden on contributors.")

#text("This database could also have a profound impact on the ")#strong[#text("publishing and peer-review process")]#text(". Having formalized proofs integrated into this process would make it much faster and more reliable to verify mathematical results, ensuring that new discoveries can be checked for correctness much more efficiently. This could be a game-changer for the peer-review system in mathematics, which can sometimes be slow due to the complexity and length of verification.")

#text("Lastly, perhaps giving this project a ")#strong[#text("formal name")]#text(" would help attract broader participation and recognition, much like ")#strong[#text("Polymath")]#text(" or ")#strong[#text("GIMPS")]#text(" (the Great Internet Mersenne Prime Search). A strong, recognizable name would not only reflect the collaborative, crowdsourced nature of this project, but also signal its innovative approach to exploring new mathematics. This could help generate more interest from both the mathematical community and those working in AI and automation, as well as emphasize the project’s potential to scale to a wider range of problems.")

#text("Just a thought…")

#text("Well done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2024")])]

#text("Thank you so much for articulating these points!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("One process improvement might be a sort of “bounty list” to show on the repo or associated website with the most interesting implications to prove or disprove at any given time. Given a partial state of known implied/known not implied/unknown relationships in the poset, it should be possible to automatically pick up high-value relationships (in the sense that figuring them out would have the largest automatic knock-down effect on others).")

#text("— Marcelo Rinesi")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("This is a nice idea. I do not know how to implement it automatically, but for now I will start managing the blueprint to highlight the unproven implications that one would like to see settled. Right now, the ")#link("https://teorth.github.io/equational_theories/blueprint/dep_graph_document.html")[#text("dependency graph")]#text(" of this blueprint lists two such requests (the bubbles in blue), to fill in two counterexamples that I overlooked in my initial Lean file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12a2829e0040623a16c8f47fc89b6eec518e163cae67bf077179223992208d4a-ca5ce197c201526630d94a4c2f9b1b522f5b37794ee0c7df3f17f13d34a04401.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mrinesi")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685886")[#strong[#text("mrinesi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Extremely quick-and-dirty PoC here ")#link("https://github.com/teorth/equational_theories/pull/13")[#text("https://github.com/teorth/equational_theories/pull/13")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685952")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2024")])]

#text("A partial formal definition of this is, first, if a relationship is proven, to see how many other relationships will follow from this, then, if the negation is proven, how many other relationships will follow from this, and then take the minimum of the two figures. The relationships that maximize this ranking will tend to give a lot of information whether they are proven or disproven.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Very interesting project! BTW, Prover9 is far from being state-of-the-art in (equational) automated proving currently. I’d say that Vampire ")#link("https://tptp.org/CASC/J12/WWWFiles/DivisionSummary1.html")[#text("probably is")]#text(". Caveat: I used to be a Vampire developer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685887")[#strong[#text("一个普遍代数的试点项目，探索新的协作方式. - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685888")[#strong[#text("A pilot project in universal algebra to explore new ways to collaborate")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")]

#text("[…] Article URL: ")#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-t&#8230")[#text("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-t&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aabce89ba03489e45e456ef444db545b77a0f7391e47a13c6e90ed4d06456c8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685891")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("In addition to forming a Hasse diagram between individual identities, another project might be forming the Euler diagram between Boolean combinations of the identities (perhaps starting with just three, rather than four, instances of the operation, to control the size of the project).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685893")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("Hopefully once we figure out the most efficient workflow to handle this sort of project in a way that can allow both human and automated contributions, one could adapt that workflow to many other problems (including ones not in the field of universal algebra). For now I would prefer to focus just on this specific project; as mentioned in the post, the goal is somewhat artificial, but has the advantage of being simple and amenable to a large number of existing tools. I’ll leave it to the experts in universal algebra to decide what type of explorations of this type would be most interesting for their field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aabce89ba03489e45e456ef444db545b77a0f7391e47a13c6e90ed4d06456c8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685898")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("In my opinion as an ring theorist (and occasional universal algebraist), describing connections between sets of identities, rather than merely single identities, is much more natural and useful. When restricted to identities with 3-compositions in them, the advantages you mention (of “being simple and amenable to a large number of existing tools”) remain. I haven’t done the back-of-the-napkin calculation, but I suspect such a task may not be much harder (after taking into account how so many identities imply others, hence many of the Euler regions are subsets of others). The visualization wouldn’t be as simple as a poset of arrows all directed downwards, but I suspect it would also be quite beautiful. Perhaps as a proof-of-concept, this could be done with the forty-six 2-composition identities [which may disprove my claims…]")

#text("The major downside I see is that you would lose the associativity axiom from the mix.")

#text("Anyway, just thought I’d raise this issue early on, in case it changed your mind. Whatever you decide, I think this project sounds awesome, and I’m happy to help however I can.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Well, when I first made the blog post way back in Wednesday, I was expecting a somewhat leisurely discussion before officially launching the project, in which we could have discussions on focusing the project onto the most suitable goal, but it has since taken on quite a life of its own and now has significant momentum. But I think that once we stabilize (and decentralize) the workflow, we will be able to accomodate multiple projects at once, and in particular I could imagine your variant of the project (with a smaller set of identities, but a more complex set of relations between them) being pursued in parallel (and with significant synergy) with the current one. Right now though we are having logistical bottlenecks in that the contributions are coming in far faster than our current non-automated organizational structure is able to handle, so I am definitely not looking to add additional goals to the project in the immediate term…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aabce89ba03489e45e456ef444db545b77a0f7391e47a13c6e90ed4d06456c8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685903")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Ah, that makes sense! [It is great how much interest this is generating!]")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2024")])]

#text("I was wondering but is there a similar kind of Hasse Diagram one could make for unary functions?. I was able to think of four but I was not sure if the latter two would count as equational axioms. The first two I thought of were ")#mi("(\\exists n \\in \\mathbb{N})[f^n(a)=b]")#text(" where ")#mi("f^n")#text(" is defined recursively using ")#mi("f^0(a)=a")#text(" ")#mi("f^n+1(a)=f(f^n(a))")#text(". The second one was ")#mi("(\\exists n \\in \\mathbb{Z})[f^n(a)=b]")#text(" which would imply that f is bijective since f^-1 or the inverse of f would not be defined otherwise I believe(but I am not sure of this). The third and fourth were ")#mi("f(a)=f(b)")#text(" and ")#mi("f(a)=b")#text(". The third just meaning f was a constant function and the fourth meaning as I understand it would just imply that the domain is just a singleton.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aabce89ba03489e45e456ef444db545b77a0f7391e47a13c6e90ed4d06456c8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685899")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Let ")#mi("f")#text(" be a unary function symbol on a set ")#mi("S")#text(". There are exactly two (doubly-indexed) families of identities: ")#mi("f^m(x)=f^n(x)")#text(" and ")#mi("f^m(x)=f^n(y)")#text(", with ")#mi("m \\leq n")#text(" ranging over the nonnegative integers.")

#text("Let’s consider the family with two variables first. The identity ")#mi("f^m(x)=f^n(y)")#text(", when ")#mi("m \\leq n")#text(", means that the descending chain of images ")#mi("S \\supseteq f(S) \\supseteq \\ldots")#text(" must stabilize at (or before) ")#mi("f^m(S)")#text(" to a singleton set that ")#mi("f")#text(" fixes.")

#text("Now consider the family with one variables. When ")#mi("m=n")#text(", the identity ")#mi("f^m(x)=f^n(x)")#text(" yields no restrictions at all. When ")#mi("m<n")#text(", the identity instead implies that the chain of images stabilizes at (or before) ")#mi("f^m(S)")#text(", and that on this set the map ")#mi("f")#text(" is a permutation of order dividing ")#mi("n-m")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a0225da49d2d91225552a51a12578969407b9e354f3bf6009762501da80f747-6c0dc02480d3c5783d9af8e5dff5a5f4dfa0879b952e92dfdd88f9132ec4f723.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tristan Stérin")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685895")[#strong[#text("Tristan Stérin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Hello,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I would be interested in hearing of any other extant examples of crowdsourced projects exploring a mathematical space, and whether there are lessons from those examples that could be relevant for the project I propose here.")
]

#text("I created the Busy Beaver Challenge and am now one of the maintainers. I’m really thrilled to read that you are launching a new collaborative project and wanted to give a few elements that we’ve learned with bbchallenge since it was launched in 2022.")

#text("I apologise, in advance for the long comment as I’m going to try to be as exhaustive as possible.")

#text("As you mentioned, we achieved bbchallenge’s initial goal this July, and the final Coq-formalised proof is critically based on the work of 15+ people and approx ~50 people have been active throughout the years in the online discussions that led to this result (you can see the ")#link("https://cosearch.bbchallenge.org/")[#text("dependency graph of results")]#text(" that I’m trying to maintain).")

#text("We believe that the following elements have played an important role in bbchallenge’s ability to produce results:")

#text("1. Working on a problem with a clear goal (in our case, proving BB(5)=47,176,870) and quantifiable “distance-to-the-goal” metric (in our case, the number of Turing machines left to decide). It seems to me that the problem you propose has these properties.")

#text("2. Having a platform dedicated to the problem (bbchallenge.org) which provides:")#linebreak()#text(" – An entry-point to the project displaying the “distance-to-the-goal” indicator in “real-time” ")#linebreak()#text(" – An URL-addressable database for the objects of interest (in our case, Turing machines, such as ")#link("https://bbchallenge.org/2977651")[#text("this one")]#text(" or ")#link("https://bbchallenge.org/1RB1LC_1RC1RB_1RD0LE_1LA1LD_1RZ0LA&status=halt")[#text("that one")]#text("). This gives collaborators a common language and makes exchanging / referring to problems very easy. (in your case maybe you could access a formula by URL and on that page see all the implications going in and out of that formula)")#linebreak()#text(" – A visualisation engine for the objects of interest (space-time diagrams in our case). I will point that our engine is quite limited (only a few lines of javascript) but I believe it helped a lot of newcomers to get interested in the problem thanks to this “eye candy”.")#linebreak()#text(" – Various resources (papers, tutorials for new contributors, wiki) and links to “socials” (discourse forum, discord server, github org)")

#text("3. Having a chat forum. This point is probably the most important in bbchallenge’s case. Our chat forum (discord) really unlocked and scaled-up entropically-driven research: although chaotic at times, >80% of key research ideas have been discussed in public at early stages and/or discovered through these conversations. Similarly to developers that benefit from the “build in public” approach, the chat forum allows for “research in public”. A few points that come to mind:")

#text("– The specific chat forum system probably matters and does not matter: most chat forums should achieve the above purpose (I see you have a Zulip setup which looks great for research project) but at the same time I believe that different chat systems will attract different crowds. Discord has downfalls (especially concerning their data model) but I hypothetise that it attracted people (non-academics in the vast majority) extremely fit to solve the problem (excellent programmers with maths skills that were already using Discord).")

#text("– Anonymity (or the possibility to be anonymous) matters. On our chat forum, most people go by pseudonyms (including core contributors) and some people are completely anonymous (i.e. no name linked to the pseudonym), including core contributors. I believe that this creates an environment where people don’t feel judged on anything else than their contributions. I believe that it also makes people less stressed about publicly making mistakes (which happens all the time and is instrumental to the research process).")

#text("– Very little to no moderation has been required so far in bbchallenge. One of the worries with chat forums is the moderation effort and having to deal with trolls. Our chat forum has ~500 participants and at this scale at least we’ve encountered almost no issues of that type.")

#text("– The hard thing is to keep track of discoveries made in the chats. The demanding task for maintainers, in my opinion, is that through the entropy of the chat a lot of discoveries or important ideas happen. It is a bit overwhelming to keep track of them and make sure they are not lost in limbo. ")#linebreak()#text(" – When the discoveries are made with code, we can track things with github (although, ")#link("https://wiki.bbchallenge.org/wiki/Code_repositories")[#text("the number of repositories of contributors")]#text(" is high) ")#linebreak()#text(" – For fully formed ideas/results, a wiki is good")#linebreak()#text(" – The trickiest thing is for more atomic results / ideas that do not really fit on a wiki as they are still very much “alive” and evolving. I’ve been developing a tool, ")#link("https://cosearch.bbchallenge.org/")[#text("cosearch")]#text(", for this purpose as well as the purpose of keeping track of the knowledge produced by all contributors and the depedency graph between those discoveries. This is still very experimental and ")#link("https://github.com/orgs/cosearch-lab/repositories")[#text("under development")]#text(".")

#text("4. Allowing for diversity of “contribution format” (in our case programming languages). bbchallenge’s contributions have been done in many programming languages: Go, Rust, C++, Python, Haskell, Coq, Lean, Dafny. Again, this entropy can feel overwhelming, but it really helped reducing the barrier to contribute as anyone could use what they were familiar with. That way we very rapidly had a great diversity of contributions (of great quality) and contributors.")

#text("When starting bbchallenge, I was only dreaming we’d ever get formal proofs in Coq/Lean and I had absolutely not the skills to make that happen. However, until Coq/Lean contributors arrived, we developed non-halt certificates in which ever languages we were familiar with (and were very strict about having to have several implementations of verifiers to accept a proof). It turns out that some of these certificates ideas have been implemented/reused in the Coq/Lean proofs, so it was not a waste of time but rather a first step until contributors with the appropriate Coq/Lean skills joined the project.")

#text("I don’t know how this last point can realistically apply to your project and I like the appeal of having Lean as an universal way to communicate mathematics in a reliable way (and without trust issues), but I think it necessarily restricts the set of contributors you can reach.")

#text("In our experience, having a wide diversity of contributors really helped distribute the workload (in a completely non-supervised fashion) as contributors naturally start working in areas of the project where (a) their skills apply the most and (b) that are not too crowded already (like when people naturally sit on a bus leaving space between each others).")

#text("Lastly, I’d like to mention other massively collaborative research projects (I try to maintain a list ")#link("https://docs.google.com/spreadsheets/d/1o-IK5l_H5o4QnPaGfUhnHMBr27FRjrY9G4q3mzg7VaM/edit?gid=0#gid=0")[#text("here")]#text(") that also work with large problem spaces:")

#text("– ")#link("https://conwaylife.com/")[#text("ConwayLife")]#text(" ")#linebreak()#text("– ")#link("https://googology.fandom.com/wiki/Googology_Wiki")[#text("Googology")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685910")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Thanks, this is very helpful and insightful!")

#text("Having a platform with visible progress indicators and other “eye candy”: totally agree. We are soon going to have some capability to generate all the implications and anti-implications established at the current time, and then we can work on automatically putting various metrics and visualizations based on that data on the github front page.")

#text("Anonymity: the Lean Zulip that has become the de facto hub of activity seems to discourage anonymous or pseudonymous accounts, but I guess this blog could serve as a secondary discussion site that permits anonymity.")

#text("Tracking non-code contributions: I certainly see some of the entropy you are referring to! We do have a blueprint within the github repository which could in principle serve as an equivalent of a wiki, though right now we don’t have many theoretical contributions of this form.")

#text("Non-Lean contributions: right now the solution we are floating is to rely on the “proof_wanted” keyword in Lean to track all non-Lean based claims (converting them to a statement that is formalized in Lean, but without the accompanying proof), perhaps accompanied with some justification of those claims as a comment in the Lean code. This should hopefully allow for a diverse range of contributions to be made to the project, while permitting the main processing and workflow to happen entirely within Lean.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a0225da49d2d91225552a51a12578969407b9e354f3bf6009762501da80f747-6c0dc02480d3c5783d9af8e5dff5a5f4dfa0879b952e92dfdd88f9132ec4f723.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tristan Stérin")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685917")[#strong[#text("Tristan Stérin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2024")])]

#text("OK! Perhaps my view of the benefits of potential anonymity is a bit too strong and non-anonymous will probably do fine as well!")

#text("I did not know about the “proof_wanted” keyword, and it sounds like a really cool feature.")

#text("It is amazing to see everything that has been done on the project in just three days and how it has already “self”-organised. It comforts my enthusiasm for the massively collaborative approach to this type of research.")

#text("Very much looking forward to the coming days/weeks :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("This is a game-changer for mathematics research! I’ve participated in Polymath projects and understand the verification bottleneck. Proof assistants like ")#link("https://www.my-sedgwick.com")[#text("Sedgwick")]#text(" Lean can revolutionize collaboration and crowdsource complex projects. Exploring multiple problems simultaneously will accelerate discovery and make math more accessible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9d7f847bcf3c3702943027dd885d6dc4370a6c870290539ca744f4735bc26f4-8231c9640646e04d30cf35b4b169ea31d106d3d8645513f9d7165f14c00a7bb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexei Lisitsa")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685897")[#strong[#text("Alexei Lisitsa")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("I find the project very interesting and feasible, especially in the part of harvesting “easy fruits” by using automated tools like prover9 and mace4.")

#text("The interesting question here is also about anti-implications: which of these can be established by finite countermodels and which of these require infinite countermodels. I expect Mace 4 can easily handle finite countermodels (especially of smaller size up to size of a few dozens), while larger sizes will be a challenge, and infinite sizes would require human insight.")

#text("I would also gently disagree with the opinion by Anonymous above that Prover9 is far from being state-of-the-art in (equational) automated proving currently. Prover9 is still very good in equational reasoning despite its last version is about 15 or so year old. I have dozens of (mathematically meaningful) equational problems instances where Prover9 outperforms Vampire and other state-of art provers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2024")])]

#text("Regarding your last point, that is very interesting. Could you share those problem instances with me? My email address is ahmed_bhayat at hotmail.com. It would be really great if you could also share Prover9 settings used to obtain a proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c2661c54fb7aff6e56f84ddcaf84040481ebd2b75ef0035c8ecf31ee0086c0e-d01a98b424f8ccb9680ef61ac14a4c072f0b8ee58139cc992c5ab85c7c56e085.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dániel Varga")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685900")[#strong[#text("Dániel Varga")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Awesome project! I wrote a piece of code that enumerates all k-element magmas, can verify an equation for all of them, and can check for implications. k=2 is fast, k=3 is reasonable, k=4 is not completely out of the question. As an example of what it can do, i’ve given it the first 10 equations with at most 4 variables, and it says:")

#text("“`number of true implications for 2-magmas 56 out of 100")

#text("number of true implications for 3-magmas 54 out of 100“`")

#text("These are the two implications in the 56-54 difference:")

#text("——-")

#text("x = x + y implies x = x + (x + y) for 2-magmas, but not for 3-magmas.")

#text("counterexample:")

#text("[[0 0 0]")

#text("[1 1 0]")

#text("[1 2 2]]")

#text("——-")

#text("x = x + (y + x) implies x = x + (x + y) for 2-magmas, but not for 3-magmas.")

#text("counterexample:")

#text("[[0 0 0]")

#text("[1 0 0]")

#text("[2 0 0]]")

#text("Do these claims seem to be correct?")

#text("Here is the code: ")#link("https://github.com/danielvarga/magmas")[#text("https://github.com/danielvarga/magmas")]

#text("I’ll run it for more equations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a777b2f6e5996fd6966d4476b71d8bb6b9900717f0f76542a9cf51b89d32b41-2f9bc401f3b262dcfa92322ec124164ef2ee63755d8b23fc0ff26509bfbbb7ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan Zheng")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685904")[#strong[#text("Fan Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("Are you sure that x = x + y does not imply x = x + (x + y)? Here’s the proof: x + (x + y) = x + x = x. So maybe there is some misunderstanding of the problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("I think it’s not a misunderstanding of the problem, it’s just a stupid mistake in my write-up. Thank you for spotting it! The direction of the implication is reversed, all else is hopefully fine. For 2-magmas, ")#mi("x = x + y \\iff x = x + (x + y)")#text(". The left side trivially implies the right side, for any magmas, as you say. But the right side also implies the left side, for 2-magmas. (I don’t have a short proof, but there are only 16 magmas to check. The right side is only true for one of those.) This direction is not true for 3-magmas and further.")

#text("All in all, when I wrote “implies” above, it should have been “is implied by”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c2661c54fb7aff6e56f84ddcaf84040481ebd2b75ef0035c8ecf31ee0086c0e-d01a98b424f8ccb9680ef61ac14a4c072f0b8ee58139cc992c5ab85c7c56e085.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dániel Varga")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685911")[#strong[#text("Dániel Varga")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2024")])]

#text("These two plots are similar to the 4694 x 4694 images, but they are only 4347 x 4347, because right now my code is limited to 4 variables, and there are 4347 equations with 4 variables. I think I can easily fix this later. Red means falsified, black is the rest. On the first image, falsified by some 2-element magma, on the second, falsified by some 3-element magma. Notably, the 3-magmas image does not have that much more red. (11,814,111 versus 11,110,683 falsified, out of ")#linebreak()#text("4347^2 = 18,896,409.)")

#link("https://static.renyi.hu/ai-shared/daniel/magmas/implications_2.png")[#text("https://static.renyi.hu/ai-shared/daniel/magmas/implications_2.png")]

#link("https://static.renyi.hu/ai-shared/daniel/magmas/implications_3.png")[#text("https://static.renyi.hu/ai-shared/daniel/magmas/implications_3.png")]

#text("(I hope WordPress treats these links correctly.)")

#text("Some more stats: The 3-magmas Hasse diagram only have ")#linebreak()#text("1045 nodes, not 4347, where 1045 is the number of logical equivalence classes of equations. It has 4037 edges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2024")])]

#text("Nice! Feel free to pr the code and images to the repo!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c2661c54fb7aff6e56f84ddcaf84040481ebd2b75ef0035c8ecf31ee0086c0e-d01a98b424f8ccb9680ef61ac14a4c072f0b8ee58139cc992c5ab85c7c56e085.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dániel Varga")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685914")[#strong[#text("Dániel Varga")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2024")])]

#text("Thank you! Modestly, I’ve started with an issue :) :")

#link("https://github.com/teorth/equational_theories/issues/50")[#text("https://github.com/teorth/equational_theories/issues/50")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("I wrote code for a smaller project that has much in common with this proposal: given a simple representation of a finite mathematical structure (a text file describing elements and a single operator) generate a set of axioms describing that structure. The goal was more philosophical proof of concept than new mathematical program, but it relies on Prover9 and Mace4, and includes brute-force generation of potential formulas in the manner you suggest, although my code produces more verbose formulas in first-order logic.")

#text("My own part of this work was only ever published as a poster, but the (unmaintained!) code is here: ")#link("https://github.com/gsfk/aa")[#text("https://github.com/gsfk/aa")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a777b2f6e5996fd6966d4476b71d8bb6b9900717f0f76542a9cf51b89d32b41-2f9bc401f3b262dcfa92322ec124164ef2ee63755d8b23fc0ff26509bfbbb7ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan Zheng")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685905")[#strong[#text("Fan Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("As a first observation, if the identity has one variable on one side which does not appear on the other side (for example, x = y + y or x = (y + z) + w), then it implies that the magma has only one element, so it is equivalent to x = y. That may simplify the impilcation graph quite a lot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a777b2f6e5996fd6966d4476b71d8bb6b9900717f0f76542a9cf51b89d32b41-2f9bc401f3b262dcfa92322ec124164ef2ee63755d8b23fc0ff26509bfbbb7ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan Zheng")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685906")[#strong[#text("Fan Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("More precisely I mean equations with ")#strong[#text("only a single variable")]#text(" on one side. More on this: it seems that some of the equations enjoy the property that in whatever order you use it to simply an expression, you get the same result. Examples are x = x+x, x=(x+x)+x and x=x+(x+x). For such equations, another equation is its consequence if and only if the two sides of its simplified form are identical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a777b2f6e5996fd6966d4476b71d8bb6b9900717f0f76542a9cf51b89d32b41-2f9bc401f3b262dcfa92322ec124164ef2ee63755d8b23fc0ff26509bfbbb7ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan Zheng")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685908")[#strong[#text("Fan Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("As a non-example, the equation x=(x+x)+y does not have this property: because ((x+x)+(x+x))+y=x+x and also ((x+x)+(x+x))+y=x+y.")

#text("So it begs the question: where does this type of meta-argument belong? Should we repeat it in every implication where it is applicable or should we refine our code to automatically sort out such instances?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685909")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2024")])]

#text("This issue is being discussed at the Lean Zulip. The long-term plan is to create an API for Magma words and implications as syntactic objects, at which point one should be able to prove these metatheorems within Lean. In the nearer term, there are already volunteers who are writing code in other languages to automatically generate files of all instances of these metatheorems in the current dataset.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2024")])]

#text("I’ll be grateful if you could point to books/materials/courses which can help one design an undergraduate (or graduate) course on AI Mathematical Assistants. Thanking you in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a777b2f6e5996fd6966d4476b71d8bb6b9900717f0f76542a9cf51b89d32b41-2f9bc401f3b262dcfa92322ec124164ef2ee63755d8b23fc0ff26509bfbbb7ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan Zheng")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685922")[#strong[#text("Fan Zheng")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2024")])]

#text("After playing around a little bit using pen and paper, I found that things start to get out of control from Equation 49:")

#text("In ")#mi("x=x(x(yx))")#text(" substitute ")#mi("x:=y(xy)")#text(" so ")#mi("yx")#text(" becomes ")#mi("y")#text(". Then")

#mi("y(xy)=(y(xy))((y(xy))y)")#text(".")

#text("Then substitue ")#mi("y:=x(yx)")#text(" so ")#mi("xy")#text(" becomes ")#mi("x")#text(". Then")

#mi("(x(yx))x=((x(yx))x)(((x(yx))x)(x(yx)))")

#text("etc. etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2024")])]

#text("Google: Michael Kinyon, Robert Veroff, Joao Araujo, J.D. Phillips, Peter Jipsen, Petr Vojtechovsky, Andrei Lisitsa, Boris Shminke.")

#text("Also, their talks at the AITP conference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2024")])]

#text("Dr Tao, always your safely assumed, humble student, even when you have to cater for most other smaller problems, Thanks for all the efforts, in its most sincerest gratitudes.. Even when there are a lot more indignant People who are only in it for the Money..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")])]

#text("Let E denote the poset of magma equations with up to 4 operations, ordered by implication. By casting the equations to ")#emph[#text("magmas with a unit element")]#text(", one obtains a quotient poset E’ (there are more implications: e.g. x(xy)=xy implies xx=x when the magma has a unit element, but not in general). Further casting the equations to ")#emph[#text("loops")]#text(" (magmas with unit where all left- and right- multiplications are invertible) will project the poset E’ further, say to E” (e.g. from x(yx)=x(xy) we immediately get yx=xy).")

#text("I will not try to advocate here that loops are “more interesting” than magmas. But from the point of view of a human being having to digest a computational project of this magnitude, E” would be more appealing and more manageable than E.")

#text("The sub-poset of E” consisting of ordered homogeneous equations of degree 1+1+2 (three operations), was determined in ")#link("https://arxiv.org/abs/math/0701714")[#text("https://arxiv.org/abs/math/0701714")]#text(". It would be quite nice if the current project will be able to determine the poset of ordered homogeneous loop equations of degree 1+2+2 or 1+1+3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I placed proofs in Lean of all the above implications and anti-implications can be found in ")#link("https://github.com/teorth/equational_theories/blob/main/equational_theories/Basic.lean")[#text("this github repository file")]#text(".")
]

#text("link died")

#text("I guess the file got moved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686010")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("The project has been refactored a couple times in the last few weeks. The successor to that file is ")#link("https://github.com/teorth/equational_theories/blob/main/equational_theories/Subgraph.lean")[#text("https://github.com/teorth/equational_theories/blob/main/equational_theories/Subgraph.lean")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The equational theories project: a brief tour | What's new")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686009")[#strong[#text("The equational theories project: a brief tour | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("[…] three weeks ago, I proposed a collaborative project, combining the efforts of professional and amateur mathematicians, automatic theorem provers, AI […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686022")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2024")])]

#text("Could you please replace the link to ")#link("https://mathscinet.ams.org/mathscinet/article?mr=236012")[#text("this paper of Perkins")]#text(" by something with open access like ")#link("https://mathscinet.ams.org/mathscinet/relay-station?mr=236012")[#text("relay-station")]#text(" or even ")#link("https://zbmath.org/0197.28201")[#text("zbMATH")]#text("? Thanks")

#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2024")])]

#text("I don’t understand much of this but I thank God that we have such really smart gifted people in our country. God Bless you Terence, and all other gifted contributors🙏")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aab36595c70dcf1ad092cbeea68ab5bedc30c3c92767777857f5f547c88b7d6-0149ae2f725b794ee1468641a530cf47bcabcecda487a89c28cab7627e731574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alephlogics")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686066")[#strong[#text("Alephlogics")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2024")])]

#text("9 and 8 are ez, if x or y then not x then not y. Then x then not y, by contraposition, eq 9 and 8 are different but y could be replaced with w and w with u which may make them equivalent. Anyways, how did you come up with this abstraction? I also did not verify this using the way you would normally, so this may actually be complete nonsense. It is definitely interesting tho, from a logic perspective. I actually have done something similar, but I would sometimes get confused.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686068")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2024")])]

#text("Are there interesting examples (even in the original setting of 11 relations) where two (say) equations A,B imply a third one C without any of them imply C alone?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2024")])]

#text("Certainly. For instance, the associative and commutative laws together imply that ")#mi("x \\circ (y \\circ z) = z \\circ (y \\circ x)")#text(", but this is not implied by either law separately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-686982")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2024")])]

#text("Dear Prof. Tao,")

#text("I also plan to study a proof assistant currently. There are quite a few proof assistants. Even without any experience with them, I have previously heard about Lean and Coq a few times, and after learning more about their uses, I probably will choose to learn Coq for its extensive uses in software engineering.")

#text("I am curious, though — may I ask what the reasons are that made you select Lean among all the others as a mathematician?")

#text("I appreciate your time in advance. Yours truly, Guanyuming He")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-687086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2025")])]

#text("Minor point, but I think what the MathOverflow question refers to as the “constant identity” isn’t the same as your “constant axiom” Equation1 (all elements are equal), but rather Equation2 (the binary operation evaluates to a constant).")

#emph[#text("[“Constant” reworded to “trivial” -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale | What's new")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-689289")[#strong[#text("The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("[…] at Scale. This is the final report for the Equational Theories Project, which was proposed in this blog post and also showcased in this subsequent blog post. The aim of this project was to see whether one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics Distillation Challenge – Equational Theories | What's new")]], [#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-691979")[#strong[#text("Mathematics Distillation Challenge – Equational Theories | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("[…] some circles. And in 2024, I launched the Equational Theories Project (ETP) (discussed on this blog here and here), combining the rigor of Lean formalization with “good old fashioned AI” (in […]")
]
