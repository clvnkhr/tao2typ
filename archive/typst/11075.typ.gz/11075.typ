// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/04/30/11075/
// Converted to Typst by tao2typ: "2026-10-14T15:20:16.500710+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Effective approximation of heat flow evolution of the Riemann xi function, and a new upper bound for the de Bruijn-Newman constant", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Effective approximation of heat flow evolution of the Riemann xi function, and a new upper bound for the de Bruijn-Newman constant")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 April 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/04/30/11075/")[#text("https://terrytao.wordpress.com/2019/04/30/11075/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15")]#text(" paper “")#link("https://arxiv.org/abs/1904.12438")[#text("Effective approximation of heat flow evolution of the Riemann ")#mi("{\\xi}")#text(" function, and a new upper bound for the de Bruijn-Newman constant")]#text("“, submitted to ")#link("https://resmathsci.springeropen.com/")[#text("Research in the Mathematical Sciences")]#text(", has just been uploaded to the arXiv. This paper records the mix of theoretical and computational work needed to improve the upper bound on the de Bruijn-Newman constant ")#mi("{\\Lambda}")#text(". This constant can be defined as follows. The function")

#align(center)[#tao-fit-display[#mitex("H_0(z) := \\frac{1}{8} \\xi\\left(\\frac{1}{2} + \\frac{iz}{2}\\right),")]]

#text("where ")#mi("{\\xi}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann ")#mi("{\\xi}")#text(" function")]

#align(center)[#tao-fit-display[#mitex("\\xi(s) := \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma\\left(\\frac{s}{2}\\right) \\zeta(s)")]]

#text("has a Fourier representation")

#align(center)[#tao-fit-display[#mitex("H_0(z) = \\int_0^\\infty \\Phi(u) \\cos(zu)\\ du")]]

#text("where ")#mi("{\\Phi}")#text(" is the super-exponentially decaying function")

#align(center)[#tao-fit-display[#mitex("\\Phi(u) := \\sum_{n=1}^\\infty (2\\pi^2 n^4 e^{9u} - 3\\pi n^2 e^{5u} ) \\exp(-\\pi n^2 e^{4u} ).")]]

#text("The Riemann hypothesis is equivalent to the claim that all the zeroes of ")#mi("{H_0}")#text(" are real. ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=37351")[#text("De Bruijn")]#text(" introduced (in different notation) the deformations")

#align(center)[#tao-fit-display[#mitex("H_t(z) := \\int_0^\\infty e^{tu^2} \\Phi(u) \\cos(zu)\\ du")]]

#text("of ")#mi("{H_0}")#text("; one can view this as the solution to the backwards heat equation ")#mi("{\\partial_t H_t = -\\partial_{zz} H_t}")#text(" starting at ")#mi("{H_0}")#text(". From the work of de Bruijn and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=434982")[#text("of Newman")]#text(", it is known that there exists a real number ")#mi("{\\Lambda}")#text(" – the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" – such that ")#mi("{H_t}")#text(" has all zeroes real for ")#mi("{t \\geq \\Lambda}")#text(" and has at least one non-real zero for ")#mi("{t < \\Lambda}")#text(". In particular, the Riemann hypothesis is equivalent to the assertion ")#mi("{\\Lambda \\leq 0}")#text(". Prior to this paper, the best known bounds for this constant were")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\Lambda < 1/2")]]

#text("with the lower bound due ")#link("https://arxiv.org/abs/1801.05914")[#text("to Rodgers and myself")]#text(", and the upper bound due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2531375")[#text("to Ki, Kim, and Lee")]#text(". One of the main results of the paper is to improve the upper bound to ")#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Lambda \\leq 0.22.")]]

#text("At a purely numerical level this gets “closer” to proving the Riemann hypothesis, but the methods of proof take as input a finite numerical verification of the Riemann hypothesis up to some given height ")#mi("{T}")#text(" (in our paper we take ")#mi("{T \\sim 3 \\times 10^{10}}")#text(") and converts this (and some other numerical verification) to an upper bound on ")#mi("{\\Lambda}")#text(" that is of order ")#mi("{O(1/\\log T)}")#text(". As discussed in the final section of the paper, further improvement of the numerical verification of RH would thus lead to modest improvements in the upper bound on ")#mi("{\\Lambda}")#text(", although it does not seem likely that our methods could for instance improve the bound to below ")#mi("{0.1}")#text(" without an infeasible amount of computation.")

#text("We now discuss the methods of proof. An ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=37351")[#text("existing result of de Bruijn")]#text(" shows that if all the zeroes of ")#mi("{H_{t_0}(z)}")#text(" lie in the strip ")#tao-math("{\\{ x+iy: \\left|y\\right| \\leq y_0\\}}", block: false)#text(", then ")#mi("{\\Lambda \\leq t_0 + \\frac{1}{2} y_0^2}")#text("; we will verify this hypothesis with ")#mi("{t_0=y_0=0.2}")#text(", thus giving ")#link(<tao-7f1b55b860590406f84f>)[#text("(1)")]#text(". Using the symmetries and the known zero-free regions, it suffices to show that ")#metadata(none) <tao-48089e9357ae6b665dbf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("H_{0.2}(x+iy) \\neq 0")]]

#text("whenever ")#mi("{x \\geq 0}")#text(" and ")#mi("{0.2 \\leq y \\leq 1}")#text(".")

#text("For large ")#mi("{x}")#text(" (specifically, ")#mi("{x \\geq 6 \\times 10^{10}}")#text("), we use effective numerical approximation to ")#mi("{H_t(x+iy)}")#text(" to establish ")#link(<tao-48089e9357ae6b665dbf>)[#text("(2)")]#text(", as discussed in a bit more detail below. For smaller values of ")#mi("{x}")#text(", the existing numerical verification of the Riemann hypothesis (we use the results ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3647966")[#text("of Platt")]#text(") shows that")

#align(center)[#tao-fit-display[#mitex("H_0(x+iy) \\neq 0")]]

#text("for ")#mi("{0 \\leq x \\leq 6 \\times 10^{10}}")#text(" and ")#mi("{0.2 \\leq y \\leq 1}")#text(". The problem though is that this result only controls ")#mi("{H_t}")#text(" at time ")#mi("{t=0}")#text(" rather than the desired time ")#mi("{t = 0.2}")#text(". To bridge the gap we need to erect a “barrier” that, roughly speaking, verifies that ")#metadata(none) <tao-f0dc3075f012ecffa922>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("H_t(x+iy) \\neq 0")]]

#text("for ")#mi("{0 \\leq t \\leq 0.2}")#text(", ")#mi("{x = 6 \\times 10^{10} + O(1)}")#text(", and ")#mi("{0.2 \\leq y \\leq 1}")#text("; with a little bit of work this barrier shows that zeroes cannot sneak in from the right of the barrier to the left in order to produce counterexamples to ")#link(<tao-48089e9357ae6b665dbf>)[#text("(2)")]#text(" for small ")#mi("{x}")#text(".")

#text("To enforce this barrier, and to verify ")#link(<tao-48089e9357ae6b665dbf>)[#text("(2)")]#text(" for large ")#mi("{x}")#text(", we need to approximate ")#mi("{H_t(x+iy)}")#text(" for positive ")#mi("{t}")#text(". Our starting point is the Riemann-Siegel formula, which roughly speaking is of the shape")

#align(center)[#tao-fit-display[#mitex("H_0(x+iy) \\approx B_0(x+iy) ( \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2}}} + \\gamma_0(x+iy) \\sum_{n=1}^N \\frac{n^y}{n^{\\frac{1+y+ix}{2}}} )")]]

#text("where ")#mi("{N := \\sqrt{x/4\\pi}}")#text(", ")#mi("{B_0(x+iy)}")#text(" is an explicit “gamma factor” that decays exponentially in ")#mi("{x}")#text(", and ")#mi("{\\gamma_0(x+iy)}")#text(" is a ratio of gamma functions that is roughly of size ")#mi("{(x/4\\pi)^{-y/2}}")#text(". Deforming this by the heat flow gives rise to an approximation roughly of the form ")#metadata(none) <tao-8adae94861b43bc7dc26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("H_t(x+iy) \\approx B_t(x+iy) ( \\sum_{n=1}^N \\frac{b_n^t}{n^{s_*}} + \\gamma_t(x+iy) \\sum_{n=1}^N \\frac{n^y}{n^{\\overline{s_*}}} )")]]

#text("where ")#mi("{B_t(x+iy)}")#text(" and ")#mi("{\\gamma_t(x+iy)}")#text(" are variants of ")#mi("{B_0(x+iy)}")#text(" and ")#mi("{\\gamma_0(x+iy)}")#text(", ")#mi("{b_n^t := \\exp( \\frac{t}{4} \\log^2 n )}")#text(", and ")#mi("{s_*}")#text(" is an exponent which is roughly ")#mi("{\\frac{1+y-ix}{2} + \\frac{t}{4} \\log \\frac{x}{4\\pi}}")#text(". In particular, for positive values of ")#mi("{t}")#text(", ")#mi("{s_*}")#text(" increases (logarithmically) as ")#mi("{x}")#text(" increases, and the two sums in the Riemann-Siegel formula become increasingly convergent (even in the face of the slowly increasing coefficients ")#mi("{b_n^t}")#text("). For very large values of ")#mi("{x}")#text(" (in the range ")#mi("{x \\geq \\exp(C/t)}")#text(" for a large absolute constant ")#mi("{C}")#text("), the ")#mi("{n=1}")#text(" terms of both sums dominate, and ")#mi("{H_t(x+iy)}")#text(" begins to behave in a sinusoidal fashion, with the zeroes “freezing” into an approximate arithmetic progression on the real line much like the zeroes of the sine or cosine functions (we give some asymptotic theorems that formalise this “freezing” effect). This lets one verify ")#link(<tao-48089e9357ae6b665dbf>)[#text("(2)")]#text(" for extremely large values of ")#mi("{x}")#text(" (e.g., ")#mi("{x \\geq 10^{12}}")#text("). For slightly less large values of ")#mi("{x}")#text(", we first multiply the Riemann-Siegel formula by an “Euler product mollifier” to reduce some of the oscillation in the sum and make the series converge better; we also use a technical variant of the triangle inequality to improve the bounds slightly. These are sufficient to establish ")#link(<tao-48089e9357ae6b665dbf>)[#text("(2)")]#text(" for moderately large ")#mi("{x}")#text(" (say ")#mi("{x \\geq 6 \\times 10^{10}}")#text(") with only a modest amount of computational effort (a few seconds after all the optimisations; on my own laptop with very crude code I was able to verify all the computations in a matter of minutes).")

#text("The most difficult computational task is the verification of the barrier ")#link(<tao-f0dc3075f012ecffa922>)[#text("(3)")]#text(", particularly when ")#mi("{t}")#text(" is close to zero where the series in ")#link(<tao-8adae94861b43bc7dc26>)[#text("(4)")]#text(" converge quite slowly. We first use an Euler product heuristic approximation to ")#mi("{H_t(x+iy)}")#text(" to decide where to place the barrier in order to make our numerical approximation to ")#mi("{H_t(x+iy)}")#text(" as large in magnitude as possible (so that we can afford to work with a sparser set of mesh points for the numerical verification). In order to efficiently evaluate the sums in ")#link(<tao-8adae94861b43bc7dc26>)[#text("(4)")]#text(" for many different values of ")#mi("{x+iy}")#text(", we perform a Taylor expansion of the coefficients to factor the sums as combinations of other sums that do not actually depend on ")#mi("{x}")#text(" and ")#mi("{y}")#text(" and so can be re-used for multiple choices of ")#mi("{x+iy}")#text(" after a one-time computation. At the scales we work in, this computation is still quite feasible (a handful of minutes after software and hardware optimisations); if one assumes larger numerical verifications of RH and lowers ")#mi("{t_0}")#text(" and ")#mi("{y_0}")#text(" to optimise the value of ")#mi("{\\Lambda}")#text(" accordingly, one could get down to an upper bound of ")#mi("{\\Lambda \\leq 0.1}")#text(" assuming an enormous numerical verification of RH (up to height about ")#mi("{4 \\times 10^{21}}")#text(") and a very large distributed computing project to perform the other numerical verifications.")

#text("This post can serve as the (presumably final) thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" (continuing ")#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t")[#text("this post")]#text("), to handle any remaining discussion topics for that project.")

#heading(level: 1)[#text("Comments (58)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f26a2d0289ddde1a4e44394a28e7d9a66f2b65b1eec97dc63a9404b3331dae-e9a8a246cbd2478017fcf1c118a96323fc2115ee572d531e98341d0f700f9eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ndwork")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515706")[#strong[#text("ndwork")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("Congratulations to all!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50ede3ebc4cc847a115c9e388be7d78199e606498365bfed9137118ae2bee1b7-8f846b28964b2adf31d0eeae71d16fcec0d1c6f1c820307174b9994b7b1b0067.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of God's Geological/ Astrophysical Math Signs")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515709")[#strong[#text("God's Geological/ Astrophysical Math Signs")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("neat stuff here ! I don’t understand it, but you got something going here!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("The implied constant in the estimate")#linebreak()#text(" ")#mi("\\Lambda \\leq O(1/ \\log T)")#linebreak()#text(" (given that RH is verified up to height ")#mi("T")#text(")")#linebreak()#text(" seems to be close to")#linebreak()#text(" ")#mi("0.22 \\log (3 \\times 10^{10}) = 5.307...")

#text("It would be interesting to find a good numerical upper bound on this constant (at least for sufficiently large ")#mi("T")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("Figure 20 in the writeup (and also Table 1) gives the numerical relationship between ")#mi("x")#text(" or ")#mi("X")#text(" (which corresponds to ")#mi("2T")#text(") and the upper bound for ")#mi("\\Lambda")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a09971234162a15562647a9298f2360626bba53001f4aeea0032eb6628efe388-14bee498c35907261aa2cb911d5eeecc8a147dde11ac3c0e361d90d8bcd34052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Bauer")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515725")[#strong[#text("William Bauer")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("Congratulations from a camp follower.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MikeRuxton")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515731")[#strong[#text("MikeRuxton")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("Wikipedia de Bruijn-Newman constant page says")

#text("“In brief, the Riemann hypothesis is equivalent to the conjecture that Λ ≤ 0.”")

#text("Your intro says something different about Riemann hypothesis equivalence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515732")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("It can be equivalent to multiple things")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ddb2932f75fce714a4ee7d91dae89a8bd85d72e3a60b5795d6a2434f5e71af-a788db6748036dabecc6eaea2fb41740c9f05215f2630ece0f1a46929cc5c196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Sugar")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515738")[#strong[#text("Joseph Sugar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("So pushing down λ (e.g. below 0.1) is just another way of verifying that millions (depending on 0.1) of nontrivial zeros of the Zeta-function are on the critical line? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("I think it’s the other way around, where verified zeros implies small lambda, not that small lambda implies verified zeros.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515759")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("verified zeros plus the other two verifications (large x and barrier), right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515760")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("yes, verified zeros plus other stuff implies small lambda")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515750")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2019")])]

#text("In the sentence about the work of de Bruijn and Newman you have the two cases as ")#mi("t\\geq\\Lambda")#text(" and ")#mi("t>\\Lambda")#text(", but I think the second should be ")#mi("t<\\Lambda")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("In the extensive numerical study of ")#mi("H_t")#text(" zeros with ")#mi("t < 0")#text(", is there any evidence for the existence of a non-real multiple zero of ")#mi("H_{t_0}")#text(" for some ")#mi("t_0 < 0")#text(" ?")

#text("This question is motivated by the heuristic that it should be very unlikely (because of the strong \"horizontal repelling\" of nearby ")#mi("H_t")#text(" zeros) to have a non-real multiple zero of ")#mi("H_t")#text(" for any real ")#mi("t")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("Are the red and green tangencies double zeros in fig 19?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("It seems that these tangencies represent only real zeros (since the y-coordinates at these tangencies are seen to be 0 – so these tangencies happen precisely when two “branches” representing the paths of two conjugate zeros are “colliding” on the real line.")#linebreak()#text(" A (hypothetical) non-real double zero in figure 19 should be similar but with its y-coordinate non-zero (obviously, there should be a corresponding conjugate non-real double zero with its y-coordinate having the same magnitude but different sign.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515786")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("As far as I know there is no numerical evidence of such a double zero, which should indeed be a very unlikely event (two complex equations ")#mi("H^{\\prime}_t(x+iy) = 0, H_t(x+iy)=0")#text(" in three real unknowns, with no functional equation to make one or more of the equations redundant).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Suppose that ")#mi("z_j(t_0)")#text(" is non-real multiple zero of ")#mi("H_{t_0}")#text(" for some ")#mi("t_0 > 0")#text(" (which obviously requires ")#mi("\\Lambda > 0")#text(") such that ")#tao-math("y_j(t_0) \\geq \\left|y_k(t_0)\\right|", block: false)#text(" for all ")#mi("k")#text(".")#linebreak()#text(" By considering the Puiseux expansion (given by proposition 3.1(ii) on the dynamics of repeated ")#mi("H_t")#text(" zeros) of the conjugate branches of ")#mi("z_j(t)")#text(" for ")#mi("t")#text(" near ")#mi("t_0")#text(", is it possible to show that there is always a branch of ")#mi("z_j(t)")#text(" with its ")#mi("y_j(t)")#text(" strictly increasing over a sufficiently small interval ")#mi("(t_0, t_1)")#text(" ?")

#text("If true, it contradicts the assumption that ")#tao-math("y_j(t_0) \\geq \\left|y_k(t_0)\\right|", block: false)#text(" for all ")#mi("k")#text(" – thereby showing that such ")#mi("z_j(t_0)")#text(" must be a simple(!) zero of ")#mi("H_{t_0}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515842")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Immediately after a repeated complex zero, the zeroes move in a mostly horizontal direction (becoming at distance about ")#mi("\\sqrt{t-t_0}")#text(" from their initial location for ")#mi("t")#text(" a little bit larger than ")#mi("t_0")#text("), but if the repeated zero was higher than all the other zeroes, they should also drift downwards. The latter effect gives a displacement of the order of ")#mi("t-t_0")#text(", so the trajectories would then resemble a downward pointing parabola immediately after the double zero.")

#text("For a simple model to use as a specific numeric example, one can try the initial polynomial ")#mi("H_0(z) = (z^2+1)^2 = z^4 + 2z^2 + 1")#text(" that has a repeated zero at ")#mi("i")#text(". The backwards heat flow for this is")

#mi("H_t(z) = H_0(z) - t \\partial_{zz} H_0(z) + \\frac{t^2}{2} \\partial_{zzzz} H_0(z)")#linebreak()#text(" ")#mi("= z^4 + (2-12 t) z^2 + (1 - 4t + 12 t^2)")

#text("which has zeroes at ")#mi("\\pm \\sqrt{ -(1-6t) \\pm \\sqrt{(1-6t)^2 - (1-4t+12t^2)} }")#text(" (if I did not make any numerical errors) and one should be able to plot these trajectories explicitly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515757")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("“…counterexamples to (2) to small x” ->")#linebreak()#text(" “…counterexamples to (2) for small x”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515771")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("A naive question from a non-native speaker. When you write")

#text("“From the work of de Bruijn and of Newman, it is known that there exists a real number {\\Lambda} – the de Bruijn-Newman constant – such that {H_t} has purely real zeroes for {t \\geq \\Lambda} …”")

#text("does this mean that {H_t} has NO purely real zeroes for {t} strictly less than {\\Lambda} or just that based on the work of de Bruijn and Newman we can’t (or won’t) say anything about zeroes for t smaller than {\\Lambda}?")

#text("Given the equivalence to the Riemann hypothesis further down the text I think the first of the two possibilities is intended, but as I read the sentence by itself the latter interpretation seems more plausible. If indeed the former interpretation is correct, then where lies my mistake, i.e. what is the general linguistic rule at work here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515773")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("I just read the abstract on Arxiv and now I think the source of my confusion lies somewhere else than I thought. The text of the blog suggests that for t as least as big Lambda we have some purely real zeroes, but, except possibly in the case of t exactly equal to Lambda, they are accompanied by some non-real zeroes as well. Now Arxiv says that this latter statement is false, and that probably you meant to write that the non-real zeroes appear for t SMALLER than lambda. Is that correct? I guess this is also the content of Lior Silberman’s comment above that somehow refuses to parse in my browser.")

#emph[#text("[Text reworded – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("In the arxiv paper, in the line below (2), it seems clearer to replace “after removing all the singularities” by “after removing all trivial zeros and the singularity at ")#mi("s=1")#text("“.")

#emph[#text("[Thanks, this will be reworded in the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("In the arxiv paper, in remark 8.3, it seems clearer to add a definition of the “imaginary error function” erfi.")

#emph[#text("[Thanks, this will be done in the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("I know this is out of context but I don’t know the best place to ask the following: can you infer something more important from what is on the link below?")

#text("– Are prime numbers really random?")#linebreak()#text(" ")#link("https://math.stackexchange.com/q/3113307")[#text("https://math.stackexchange.com/q/3113307")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515783")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2019")])]

#text("The connection between the height of the RH verification and the ")#mi("\\Lambda")#text(" achieved, actually is the result of the approach we chose. However, to achieve a lower ")#mi("\\Lambda")#text(" we don’t have to verify the RH at ")#mi("t=0")#text(", but only that the ‘elevated’ ")#mi("(x,y)")#text("-rectangle ")#mi("(0,y_0), (x_b, y_0), (x_b,1), (0, 1)")#text(" at ")#mi("t_0")#text(" is zero free (with ")#mi("x_b")#text(" is the Barrier location). The work of Platt, Gourdon et al made this a very convenient choice, that only came at a small ‘cost’ of needing to introduce a Barrier to prevent zeros flying ‘under the elevated roof’ from the right.")

#text("I wondered whether the recently developed approach to verify the right side of the Barrier ‘roof’, could also be applied to (part of) its left side, thereby making the Barrier itself obsolete? Or will we run into trouble with the bound and/or the error terms at lower ")#mi("N")#text("? (I do recall the error terms became too large around ")#mi("N=6")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515825")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2019")])]

#text("Ah wait, that won’t work since the Lemma-bound will become negative at some point left of the Barrier and we can’t just add mollifiers to make it positive again (")#mi("N=50.000, y_0=t_0=0.2")#text(" at 6 primes was the lowest positive bound I managed to achieve).")

#text("Even though it appears to be a bit of an ‘overkill’, verifying the RH using its already optimised techniques (Gram/Rosser’s law, Turing’s method, etc), is probably always going to beat some form of applying the argument principle to the ‘elevated’, smaller rectangle at ")#mi("t=t_0")#text("…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Also, numerical verification of RH has many orders of magnitude more applications than verification of zero free-region of ")#mi("H_{t_0}")#text(" at some distance ")#mi("y_0")#text(" away from the critical line, so if one were to undertake a massive computational effort, it would be much more useful to direct it towards the former rather than the latter. :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-515922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("In the arxiv paper, it seems that in (28) (and also in its proof)")#linebreak()#text(" ")#mi("\\partial z_j(t) / \\partial t")#text(" should be an ordinary derivative ")#mi("z_j^{\\prime}(t)")

#text("Similar corrections are needed for (34) (the function ")#mi("Y(t)")#text(") and perhaps remark 9.4")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-516215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2019")])]

#text("Is this polymath over?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-517496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2019")])]

#text("It is interesting to observe that the dynamics of ")#mi("H_t")#text(" zeros is quite similar to the “guiding equation” dynamics of particles in De Broglie – Bohm theory (for a deterministic non-local interpretation of quantum mechanics), see")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/De_Broglie-Bohm_theory")[#text("https://en.wikipedia.org/wiki/De_Broglie-Bohm_theory")]

#text("In which the 3D deterministic guiding equation for the particles (based on a wave function ")#mi("\\psi")#text(" satisfying Schrodinger equation which is similar to the heat equation satisfied by ")#mi("H_t")#text(") is similar to ")#mi("H_t")#text(" zero dynamics. It seems that ")#mi("H_t")#text(" plays the role of a “wave function” which determine the dynamics of its own zeros (interpreted as particles).")#linebreak()#text(" As is well-known, the predictions of De Broglie – Bohm theory are completely consistent with the standard interpretation of quantum mechanics, it seems that this analogy may explain certain “probabilistic properties” of the dynamics of ")#mi("H_t")#text(" zeros.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-517537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2019")])]

#text("It seems that the approximations of ")#mi("H_t(x+ i y)")#text(" in the critical strip by elementary functions is perhaps less efficient than similar approximations of the slightly modified function ")#mi("H_t((x+ i y) \\log (x + i y))")#text(" for sufficiently large ")#mi("x")#text(" because the distribution of its zeros is more uniform (the number of its zeros up to ")#mi("X")#text(" grows asymptotically linearly with ")#mi("X")#text(" while growing like ")#mi("X \\log X")#text(" for ")#mi("H_t(x + i y)")#text(") – so it seems more adapted for asymptotic approximations by elementary functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518938")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2019")])]

#text("Update from the submission: we received two positive referee reports on the paper with some minor corrections suggested at ")#link("https://terrytao.files.wordpress.com/2019/07/de-bruijn-newman-report.pdf")[#text("https://terrytao.files.wordpress.com/2019/07/de-bruijn-newman-report.pdf")]#text(" and ")#link("https://terrytao.files.wordpress.com/2019/07/condensed-review.pdf")[#text("https://terrytao.files.wordpress.com/2019/07/condensed-review.pdf")]#text(" . I should be able to attend to these changes and send back the revision soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("congratulations! and that second reviewer’s attention to detail")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("Yes, that referee certainly went through many of the calculations in fine detail! I have implemented the corrections and am now returning it back to the journal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("Congratulations on your papers’ submissions!")

#text("And are you now convinced that the Riemann Hypothesis is true?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("The constant moved from 0.50 to 0.22 and when it reaches 0.00 the Riemann hypothesis is proved, so we have progressed 56% of the way to proving the Riemann hypothesis. Analytic number theorists call that amusing. Other academics call that a mnemonic. Bureaucrats call that a metric.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518991")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("After Rodgers and Tao showed last year that ")#mi("\\Lambda \\ge 0")#text(", we know that Newman’s conjecture that “if the RH is true, then it is barely so” has become true. However, even with a reduced upper bound of ")#mi("\\Lambda \\le 0.22")#text(" there is still plenty of room for the conjecture: “if the RH is false, then it could be considerably so”… ;-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-519131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("The paper has now been accepted for publication in RIMS.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-519194")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2019")])]

#text("The arXiv paper is still not updated.")

#emph[#text("[Thanks for the reminder! I have sent in an update and it should appear in a day or two. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-519256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2019")])]

#text("Some typos in the updated arXiv paper:")#linebreak()#text(" In page 13, for ")#mi("m = 2")#text(", ")#mi("x_2")#text(" should be ")#mi("\\lambda_2")#text(" and for ")#mi("m=3")#text(", “")#mi("x \\lambda 1")#text("” should be corrected.")#linebreak()#text(" In page 66, in the explanation of figure 20, ")#mi("1/ \\log x")#text(" should be ")#mi("\\log x")#text(".")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Dear Terry")#linebreak()#text(" I have a girlfriend and I always talk to her that until Pro. Tao receives $1M from Clay Millenium award , I take her to 10 nations in the world")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-518968")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("I find this solid/liquid/gaseous analogy highly inspiring. It brings me to the following question: What is the structure of a crystalline solid substance exactly at the melting point? In the solid it will be anything with a discrete diffraction pattern (say Fourier transform) and highly anisotropic (in general at least for n>1 dimensions) in the liquid it will be isotroic (radially symmetric diffraction pattern) and be determined by statistical properties like average distances and higher momenta of the distribution. I suspect regarding exactly the melting point will be severely hampered by discontinuities of characterizing properties. For example free energy or other thermodynamic properties have cusps at the melting point. Maybe one has to uncover what is hidden behind such “discontinuities” to understand what is going on at the phase border. Possibly the structure at the melting point is something analogous to the distribution of the zeros of the ")#mi("zeta")#text("-function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-520336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("The Riemann Hypothesis is true!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-520386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Yes! The Riemann Hypothesis is true!")

#text("The Goldbach conjecture is also true!")

#text("The ABC conjecture is also true!")

#text("The Collatz conjecture is also true!")

#text("The Polignac conjecture is also true!")

#text("…")

#text("Why? I proved those conjecture are true!")

#text("David Cole")

#link("https://www.researchgate.net/profile/David_Cole29")[#text("https://www.researchgate.net/profile/David_Cole29")]

#link("https://www.math10.com/forum/viewforum.php?f=63&sid=0f36c9b09298e37868fc5eb2adea1a06")[#text("https://www.math10.com/forum/viewforum.php?f=63&sid=0f36c9b09298e37868fc5eb2adea1a06")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-520387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Fermat’s Last Theorem is also true too!")

#link("https://math.stackexchange.com/questions/1993460/prove-a-statement-about-a-conditional-diophantine-equation")[#text("https://math.stackexchange.com/questions/1993460/prove-a-statement-about-a-conditional-diophantine-equation")]

#text("David Cole.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-520405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Life is not fair!…. :-(")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-521847")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("I wondered whether other functions than ")#mi("\\xi(s)")#text(" exist that also involve ")#mi("\\zeta(s)")#text(" and possess similar properties. in particular being real-valued when ")#mi("\\Re(s)=\\frac12")#text(" and having a Fourier representation that could be perturbed by the time-factor ")#mi("e^{t\\,u^2}")#text(".")

#text("A potentially interesting one is:")

#mi("\\Upsilon(s) = \\Gamma(s)\\zeta(s)+\\Gamma(1-s) \\zeta(1-s)")

#text("that induces an extra set of more regularly spaced zeros ")#mi("\\mu")#text(" on top of the non-trivial zeros ")#mi("\\rho")#text(". Also, by adding an additional parameter ")#mi("\\kappa")#text(" as follows:")

#mi("\\Upsilon(s,\\kappa) = \\Gamma(\\kappa s)\\zeta(s)+\\Gamma(\\kappa(1-s)) \\zeta(1-s)")

#text("it seems possible to increase the density of these ")#mi("\\mu")#text("‘s whilst keeping them on the critical line.")

#text("Just for fun, I dusted off some of the software tools used in our Polymath 15 project to see whether there was something interesting about the trajectories of these zeros over ‘time’. To keep this post short, I have summarised my observations in a few visuals in the link:")

#link("https://drive.google.com/open?id=1k7WIbUPoGe7HGr1MDd5wI3Kydx0fnT5j")[#text("PPT")]

#link("https://drive.google.com/open?id=1CFsxRGcbe3P4D67uW2Avq9mEXPWJR80F")[#text("PDF")]

#text("Open to feedback/suggestions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-523454")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("Did some further computations. Suppose the regularly spaced ")#mi("\\mu")#text(" are indeed all real at ")#mi("t=0")#text(", then when their density is increased through parameter ")#mi("\\kappa")#text(":")

#text("1) collisions at negative ")#mi("t")#text(" appear to occur closer to ")#mi("t=0")#text(". This could be explained by the fact that when the density of the ")#mi("\\mu")#text("‘s increases, they will get closer to the (fixed) ")#mi("\\rho")#text("‘s and form “Lehmer-like”-pairs at ")#mi("t=0")#text(". This phenomenon would imply the lower bound of ")#mi("\\Lambda^*")#text(" moves up when ")#mi("\\kappa")#text(" increases.")

#text("2) collisions at positive ")#mi("t")#text(" are difficult to test since we don’t have a ")#mi("\\rho")#text(" lying off the critical line. However, after injecting a ‘fake’ ")#mi("\\rho^*")#text(" close to the edge of the strip, the data shows that its associated collision will occur ‘sooner’. This could be explained by the trajectories of the real zeros eventually all leaning in the north-western direction. So, when more ")#mi("\\mu")#text("-trajectories are induced, more of these trajectories will travel above than below the collision point associated to ")#mi("\\rho^*")#text(". Hence that point experiences a downward pressure towards ")#mi("t=0")#text(" and this would imply the upper bound of ")#mi("\\Lambda^*")#text(" moves down when ")#mi("\\kappa")#text(" increases.")

#text("The observations above do not yield any new insights about ")#mi("t=0")#text(" where the ")#mi("\\mu")#text("‘s and the ")#mi("\\rho")#text("’s are just ‘givens’ that are perturbed into the positive and negative ")#mi("t")#text("-directions (i.e. all information originates from ")#mi("H_0^*")#text(" and nothing flows back).")

#link("https://drive.google.com/open?id=113RDhpIJdMeKuSAtDkMhPnXwGEI1Y7rB")[#text("Updated pdf.")]

#text("Asked about the ")#mi("\\mu")#text("‘s")#linebreak()#text(" ")#link("https://mathoverflow.net/questions/342436/the-complex-roots-of-left-gamma-kappa-s21-s-pi-s-cos-left-frac-pi”")[#text(" at mathoverflow.")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-523461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("It seems that by using asymptotic approximations (with remainder term) for the function whose zeros are the ")#mi("\\mu")#text("‘s, it is possible to get asymptotic approximation for the ")#mi("\\mu")#text(" – trajectories. The derivation of the aymptotic approximation of this function may use the known asymptotic form (with remainder term) of the ")#mi("\\Gamma")#text(" function (as done in Polymath15 paper.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-554457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("Just a small comment to note that there has been a recent numerical verification of RH up to height ")#mi("3 \\times 10^{12}")#text(" in ")#link("https://arxiv.org/abs/2004.09765")[#text("https://arxiv.org/abs/2004.09765")]#text(" which, among other things, immediately improves the upper bound ")#mi("\\Lambda \\leq 0.22")#text(" in the Polymath15 paper to ")#mi("\\Lambda \\leq 0.20")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-554539")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("“Just a small comment” :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-554556")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("Are there any ways to confirm the verification of RH up to the said point? More precisely, does the calculation produce data points that can be used for verification of the result in significantly less time than it would take to run the verification again? (simplest example would be prime factorization, which can easily be checked afterwards).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-554639")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("This is a good question. I think with our current technology any verification of RH up to height ")#mi("T")#text(" is going to need something like ")#mi("O(T^{3/2+o(1)})")#text(" steps, so it’s not going to be quickly replicable. In principle one could maybe convert their verification into some enormous probabilistically checkable proof or something, but that seems more effort than it is really worth. On the other hand having some “checksums” (e.g. collecting some statistics of the zeroes computed) might be doable without having to run the entire code again. But one would have to contact the authors about this; I didn’t see much discussion of these topics in the paper itself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-556524")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("From the paper: “(…)The next entry in Table 1 of [24] is conditional on taking ")#mi("H")#text(" a little higher than ")#mi("10^{13}")#text(", which of course, is not achieved by Theorem 1. This would enable one to prove ")#mi("\\Lambda \\le 0.19")#text(". Given that our value of ")#mi("H")#text(" falls between the entries in this table, it is possible that some extra decimals could be wrought out of the calculation. We have not pursued this(…)”")

#text("This is not so difficult to pursue. The new RH-verification height ")#mi("H=3000175332800")#text(" translates into ")#mi("X=6000350665600")#text(" (since ")#mi("X=2H")#text(") and ")#mi("N=690988")#text(". At this ")#mi("N")#text(", the mollified triangle lower bound becomes and stays larger than ")#mi("0.03")#text(" for the choice ")#mi("t_0 = y_0 = 0.1809")#text(". These yield a ")#mi("\\Lambda \\le 0.1972624050")#text(", and to be on the safe side let’s take ")#mi("0.1973")#text(" (note that slightly different choices for ")#mi("t_0, y_0")#text(" might lead to a further reduction).")

#text("With these parameters, an optimal barrier location can be established, i.e. where ")#mi("H_t(x+iy)")#text(" shows a larger peak. It turns out that ")#mi("6000000185827")#text(" is a suitable location. Then running the barrier computations yields a winding number of ")#mi("0")#text(", so that we have verified that no complex zeros could have flown through the barrier from the right and no zeros could have flown in through the bottom at ")#mi("t=0")#text(" on its left, since the RH has been verified up that point.")

#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/output/windingnumbers/windnum_nolemma_x6000000185827_y_0.1809_1_t_0_0.1809.txt")[#text("Barrier computation output")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-632149")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2021")])]

#text("Gaseous implies the existence of a complex conjugate pair of zeros of $ latex H_t $, while liquid implies purely real zeros. What would the phase border gaseous/liquid look like? Would it imply the existence of zeros of order >1 (say 2)? If so, and if there is an operator whose eigenvalues are the zeros, what symmetry properties (which symmetry goup) would this operator have (belong to)? I suppose it would be a just about non-, abelian group. Because the eigenvalue “degeneracy” reflects the non-abelianess of the corresponding symmetry group. Do such operators exist, or can we construct such operators?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-694208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("I have posted a new computer-assisted argument claiming the unconditional bound Λ<0.172422\\Lambda<0.172422 for the de Bruijn–Newman constant.")

#text("The main theorem excludes multiple real zeros of HtH_t throughout 0.172422≤t≤0.20.172422\\le t\\le0.2. Combined with the published Platt–Trudgian/Polymath15 anchor Λ≤0.2\\Lambda\\le0.2, this gives the stated bound. The mechanism is a collision-exclusion descent: a finite-collision reduction is combined with a moving-separator Hermite analysis, a mollified double-zero resultant across the Riemann–Siegel transitions, and an exact-phase freezing theorem in the tail.")

#text("The paper, theorem certificate, and a separate full replay bundle are deposited here:")

#link("https://doi.org/10.5281/zenodo.22337308")[#text("https://doi.org/10.5281/zenodo.22337308")]

#text("All author-side computational layers have been replayed from source in a fresh environment; the result is not yet peer reviewed, so I would be grateful for any scrutiny of the mathematical reductions or certificate-to-theorem implications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-697784")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#strong[#text("Proposition.")]#text(" Assume the recent proof of the quasi-Riemann hypothesis that")

#mi("\\zeta(s)\\neq 0 \\qquad (\\Re s>3/4).")

#text("is correct, then ")#mi("0\\leq\\Lambda\\leq 1/8")#text(", where ")#mi("\\Lambda")#text(" is the de Bruijn–Newman constant.")

#strong[#text("Proof.")]#text(" By the functional equation, every nontrivial zero ")#mi("\\rho")#text(" satisfies")

#mi("\\displaystyle \\frac14\\leq\\Re\\rho\\leq\\frac34.")

#text("Since")

#mi("\\displaystyle H_0(z)=\\frac18\\xi\\left(\\frac12+\\frac{iz}{2}\\right),")

#text("every zero of ")#mi("H_0")#text(" satisfies")

#tao-math("\\displaystyle \\left|\\Im z\\right|\\leq\\frac12.", block: false)

#text("By de Bruijn’s strip-shrinking theorem, the zeros of ")#mi("H_t")#text(" lie in")

#tao-math("\\displaystyle \\left|\\Im z\\right|\\leq\\sqrt{\\max\\left\\{\\frac14-2t,0\\right\\}}.", block: false)

#text("For ")#mi("t=1/8")#text(", all zeros are real. Hence")

#mi("\\displaystyle \\Lambda\\leq\\frac18.")

#text("Rodgers–Tao/Dobner proved ")#mi("\\Lambda\\geq0")#text(". Therefore,")

#mi("\\displaystyle 0\\leq\\Lambda\\leq\\frac18.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2019/04/30/11075/#comment-697792")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Oops. Made a mistake and ignore this post. I was way too optimistic about future zero free regions and should have used 7/8 instead of 3/4 !")
]
