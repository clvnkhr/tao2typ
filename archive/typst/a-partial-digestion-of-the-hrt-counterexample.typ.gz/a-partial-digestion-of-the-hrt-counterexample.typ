// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/
// Converted to Typst by tao2typ: "2026-10-14T16:39:25.817385+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A partial digestion of the HRT counterexample", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A partial digestion of the HRT counterexample")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/")[#text("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A function ")#mi("{f(t) \\in L^2({\\bf R})}")#text(" of one variable can be translated in space by a spatial shift ")#mi("{x}")#text(" to obtain a new function")

#align(center)[#tao-fit-display[#mitex("\\pi(x,0) f(t) := f(t-x),")]]

#text("and also modulated in frequency by a frequency shift ")#mi("{\\omega}")#text(" to obtain a new function")

#align(center)[#tao-fit-display[#mitex("\\pi(0,\\omega) f(t) := e^{2\\pi i \\omega t} f(t).")]]

#text("One can compose these two operations to obtain a time-frequency shift:")

#align(center)[#tao-fit-display[#mitex("\\pi(x,\\omega) f(t) := \\pi(0, \\omega) \\pi(x,0) f(t) = e^{2\\pi i \\omega t} f(t-x).")]]

#text("As per the time-frequency uncertainty principle, the two shifts do not quite commute with each other. For instance, we have")

#metadata(none) <tao-44438343c52ee70594e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\pi(x, 0) \\pi(0, \\omega) = e^{-2\\pi i \\omega x} \\pi(0, \\omega) \\pi(x, 0).")]]

#text("As such, ")#mi("{\\pi}")#text(" is not a representation of the abelian group ")#mi("{{\\bf R}^2}")#text(", but rather a portion of the ")#link("https://en.wikipedia.org/wiki/Heisenberg_group")[#text("Weyl representation of the Heisenberg group")]#text(", but we will not adopt a representation-theoretic perspective here.")

#text("Some functions obey finite linear relations between their time-frequency shifts. For instance, a sinusoid ")#mi("{f(t) = A \\sin(k t + \\phi)}")#text(" obeys the relation")

#align(center)[#tao-fit-display[#mitex("\\pi(\\frac{\\pi}{k},0) f + f = 0.")]]

#text("However, the Heil-Ramanathan-Topiwala (HRT) conjecture states that once one imposes some reasonable decay condition on ")#mi("{f}")#text(", no such relations exist:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (HRT conjecture)")]#text(" If ")#mi("{f \\in L^2({\\bf R})}")#text(" is non-zero, then there is no relation of the form")

#metadata(none) <tao-68b076be5ba974795f92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("c_1 \\pi(z_1) f + \\dots + c_n \\pi(z_n) f = 0")]]

#text("for some distinct time-frequency shifts ")#mi("{z_1,\\dots,z_n \\in {\\bf R}^2}")#text(" and some coefficients ")#mi("{c_1,\\dots,c_n \\in {\\bf C}}")#text(", not all zero.")
]

#text("A special case of the HRT conjecture, which was also open, makes the additional assumption that ")#mi("{f}")#text(" was Schwartz.")

#text("Many positive results towards this conjecture were known. I will mention only a few here. A simple case is when we only have frequency shifts rather than spatial shifts:")

#align(center)[#tao-fit-display[#mitex("c_1 \\pi(0, \\omega_1) f + \\dots + c_n \\pi(0, \\omega_n) f = 0.")]]

#text("In this case, the operator ")#mi("{(c_1 \\pi(0, \\omega_1) + \\dots + c_n \\pi(0, \\omega_n))}")#text(" is simply a physical space multiplier")

#align(center)[#tao-fit-display[#mitex("c_1 \\pi(0, \\omega_1) f(t) + \\dots + c_n \\pi(0, \\omega_n) f(t) = B(t) f(t)")]]

#text("with symbol")

#align(center)[#tao-fit-display[#mitex("B(t) = c_1 e^{2\\pi i \\omega_1 t} + \\dots + c_n e^{2\\pi i \\omega_n t}")]]

#text("so that the relation ")#link(<tao-68b076be5ba974795f92>)[#text("(2)")]#text(" now takes the simple pointwise form")

#metadata(none) <tao-5e73d6d7edd38daeae9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("B(t) f(t) = 0.")]]

#text("If the coefficients ")#mi("{c_1,\\dots,c_n}")#text(" are not all zero, then ")#mi("{B}")#text(" is a non-zero analytic function and thus has isolated zeroes. It is thus not possible to solve this equation for any ")#mi("{f \\in L^2({\\bf R})}")#text(". Thus the HRT conjecture is true when all the time-frequency shifts ")#mi("{z_1,\\dots,z_n}")#text(" lie on the vertical axis. Using the ")#link("https://en.wikipedia.org/wiki/Metaplectic_group")[#text("metaplectic representation")]#text(", one can then handle the case when all the ")#mi("{z_1,\\dots,z_n}")#text(" are collinear.")

#text("What about the non-collinear case? Suppose first that all the ")#mi("{z_j}")#text(" lie in the lattice ")#mi("{{\\bf Z}^2}")#text(", thus ")#mi("{z_j = (k_j, l_j)}")#text(" for some integers ")#mi("{k_j, l_j}")#text(". Here, the phase shift in ")#link(<tao-44438343c52ee70594e7>)[#text("(1)")]#text(" disappears, and all the time-frequency shifts ")#mi("{\\pi(k_j, l_j) = \\pi(k_j,0) \\pi(0,l_j)}")#text(" commute with each other. This suggests that it should be possible to diagonalize the situation with a suitable transform to convert ")#link(<tao-68b076be5ba974795f92>)[#text("(2)")]#text(" to a pointwise equation similar to ")#link(<tao-5e73d6d7edd38daeae9f>)[#text("(3)")]#text(". To find this diagonalization, observe that if one restricts the function ")#mi("{f : {\\bf R} \\rightarrow {\\bf C}}")#text(" to a coset ")#mi("{s + {\\bf Z}}")#text(" of the integers, then ")#mi("{\\pi(0,l_j)}")#text(" just multiplies the function by the scalar ")#mi("{2^{2\\pi i l_j s}}")#text(", while ")#mi("{\\pi(k_j, 0)}")#text(" shifts the function on this coset by ")#mi("{k_j}")#text(". The latter translation operation can also be converted to pointwise multiplication by performing the Fourier transform on the integers. Thus, if one introduces the ")#link("https://en.wikipedia.org/wiki/Zak_transform")[#text("Zak transform")]

#align(center)[#tao-fit-display[#mitex("Zf(s,\\nu) := \\sum_{k \\in {\\bf Z}} f(s+k) e^{2\\pi i k \\nu}")]]

#text("of ")#mi("{f}")#text(" then the equation")

#align(center)[#tao-fit-display[#mitex("c_1 \\pi(k_1, l_1) f + \\dots + c_n \\pi(k_n, l_n) f = 0")]]

#text("can be transformed after a brief calculation to the equation")

#align(center)[#tao-fit-display[#mitex("B(s,\\nu) Zf(s,\\nu) = 0")]]

#text("where the symbol ")#mi("{B(s,\\nu)}")#text(" is now given by the formula")

#align(center)[#tao-fit-display[#mitex("B(s,\\nu) = c_1 e^{2\\pi i (k_1 \\nu + l_1 s)} + \\dots + c_n e^{2\\pi i (k_n \\nu + l_n s)}.")]]

#text("As before, if the coefficients ")#mi("{c_1,\\dots,c_n}")#text(" are not all zero, then ")#mi("{B}")#text(" is a non-zero analytic function and thus non-zero almost everywhere. Thus ")#mi("{Zf}")#text(" has to vanish almost everywhere, which for ")#mi("{f \\in L^2({\\bf R})}")#text(" can be used to show that ")#mi("{f}")#text(" also vanishes.")

#text("More generally, there is a ")#link("https://arxiv.org/abs/math/9807057")[#text("result of Linnell")]#text(" that the conjecture is true if ")#mi("{z_1,\\dots,z_n}")#text(" lie in a translate of a discrete subgroup of ")#mi("{{\\bf R}^2}")#text("; this (together with the argument handling the collinear case) establishes all cases where ")#mi("{n \\leq 3}")#text(", and several partial results involving the ")#mi("{n=4}")#text(" cases are also known. The conjecture is also known if ")#mi("{f}")#text(" is decays at a suitably super-exponential rate, by ")#link("https://math.umd.edu/~rvbalan/TEACHING/RIT2023/Bownick_Speegel2012.pdf")[#text("work of Bownik and Speegle")]#text(".")

#text("I was aware of this conjecture through various talks and conversations with colleagues, and even briefly tried my hand at it for a while, though not with particularly serious effort (or progress). It was thus a nice surprise to see that it has ")#link("https://arxiv.org/abs/2608.05044")[#text("just been resolved by Faulhuber, Petersen, van Velthoven, and Voigtlaender")]#text(", even in the Schwartz case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" There exist complex numbers ")#mi("{c_1,\\dots,c_{12}\\in {\\bf C}}")#text(", not all zero, distinct points ")#mi("{z_1,\\dots,z_{12} \\in {\\bf R}^2}")#text(", and a non-zero Schwartz function ")#mi("{f_* \\in \\mathcal{S}({\\bf R})}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("c_1 \\pi(z_1) f_* + \\dots + c_{12} \\pi(z_{12}) f_* = 0.")]]
]

#text("It is perhaps unsurprising that this result is AI-assisted. However, I think the authors have disclosed their AI use responsibly, with the final arguments written by hand with a readable overview of the argument, as well as proper discussion of methods, relation to past literature, and other independent numerical checks on the result.")

#text("The negative result lies only a little beyond the positive results: ")#mi("{n}")#text(" is now increased to ")#mi("{12}")#text(", and all but one of the points ")#mi("{z_1,\\dots,z_{12}}")#text(" lie in (a translate of) a discrete subgroup of ")#mi("{{\\bf R}^2}")#text(" (in fact the explicit subgroup ")#mi("{{\\bf Z} \\times \\frac{1}{2}{\\bf Z}}")#text(" is used). The functions constructed are smooth and rapidly decaying, but not analytic or super-exponentially decaying, which would start being in conflict with the known positive results.")

#text("In addition to AI being used to come up with the initial proof strategy, a more traditional numerical computation was used to verify one step of the argument.")

#text("I have not had the time to do a full digestion of the result, but (after reading the introduction, and ")#link("https://chatgpt.com/share/6a74d097-5e68-83e8-8786-57e90f849e41")[#text("using a little AI assistance of my own")]#text(") I was able to understand the main ideas at a high level. The first few reductions are relatively standard. Setting ")#mi("{z_{12} = 0}")#text(" and ")#mi("{c_{12} = -c_*}")#text(", one can view the problem as one of solving an eigenvalue problem")

#align(center)[#tao-fit-display[#mitex("(c_1 \\pi(z_1) + \\dots + c_{11} \\pi(z_{11})) f_* = c_* f_*.")]]

#text("The time-frequency shifts ")#mi("{z_1,\\dots,z_{11}}")#text(" are chosen to lie in a translate of the discrete subgroup ")#mi("{{\\bf Z} \\times \\frac{1}{2}{\\bf Z}}")#text(" by a certain irrational shift ")#mi("{(\\alpha, \\beta/2)}")#text(". As mentioned previously, if in the shifts of a standard lattice ")#mi("{{\\bf Z} \\times {\\bf Z}}")#text(", it would be natural to work with the ")#link("https://en.wikipedia.org/wiki/Zak_transform")[#text("Zak transform")]#text(" of ")#mi("{f_*}")#text(", but it turns out that the approach does not quite work when doing this for topological reasons (relating to the fact that scalar quasiperiodic functions of mean zero are forced to have zeroes), and so the authors used the slightly denser lattice instead ")#mi("{{\\bf Z} \\times \\frac{1}{2}{\\bf Z}}")#text(", which relates to a vector-valued version of the Zak transform taking values in ")#mi("{{\\bf C}^2}")#text(" rather than ")#mi("{{\\bf C}}")#text(". Here, the phase shift in ")#link(<tao-44438343c52ee70594e7>)[#text("(1)")]#text(" does not completely disappear, but becomes a sign change. This slight loss of abelianness means that we cannot hope to diagonalize the problem all the way to a scalar problem, but we can still hope to reduce it to a two-dimensional vector-valued problem. Indeed, by applying a suitable vector-valued version of the Zak transform, the eigenvalue problem can be transformed to a a “vector cocycle problem”")

#metadata(none) <tao-70868ce890a49e8cc136>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("B_*(z) F_*(z - \\tau) = c_* F_*(z),")]]

#text("where ")#mi("{F_* : {\\bf R}^2 \\rightarrow {\\bf C}^2}")#text(" is a non-zero smooth quasiperiodic vector-valued function, ")#mi("{\\tau}")#text(" is an irrational shift ")#mi("{\\tau= (\\alpha,\\beta)}")#text(", and ")#mi("{B_*(z)}")#text(" is a certain explicit ")#mi("{2 \\times 2}")#text(" matrix-valued function depending on the choices of ")#mi("{c_1,\\dots,c_{11}}")#text(", ")#mi("{z_1,\\dots,z_{11}}")#text(", and ")#mi("{\\tau}")#text(".")

#text("How to solve this equation? The motivating scenario here is if the matrix function ")#mi("{B_*(z)}")#text(" was replaced by a rank one function")

#align(center)[#tao-fit-display[#mitex("B_0(z) = \\chi(z) \\chi(z-\\tau)^*")]]

#text("for some smooth vector-valued function ")#mi("{\\chi : {\\bf R}^2 \\rightarrow {\\bf C}}")#text(" of unit magnitude. Then one could solve the equation by taking ")#mi("{F_*(z) = \\chi(z)}")#text(" and ")#mi("{c_* = 1}")#text(". It is not possible to make the function ")#mi("{B_*}")#text(" exactly of this form, but through some numerical computation and clever AI-assisted guesswork, the authors were able to find a choice of ")#mi("{c_1,\\dots,c_{11}}")#text(" and ")#mi("{z_1,\\dots,z_{11}}")#text(", and ")#mi("{\\tau}")#text(" that made ")#mi("{B_*}")#text(" ")#emph[#text("approximately equal")]#text(" to a rank one function ")#mi("{B_0}")#text(" of this form, in fact getting a uniform estimate")

#align(center)[#tao-fit-display[#tao-math("\\sup_{z \\in {\\bf R}^2} \\left\\| B_*(z) - B_0(z) \\right\\|_{op} < \\frac{1}{3}.", block: true)]]

#text("As it turns out, such an approximation is sufficient to run a contraction mapping argument to find a solution to a variant of ")#link(<tao-70868ce890a49e8cc136>)[#text("(4)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("B_*(z) v_*(z - \\tau) = q_*(z) v_*(z)")]]

#text("for some smooth ")#mi("{v_* : {\\bf R}^2 \\rightarrow {\\bf C}^2}")#text(" and ")#mi("{q_* : {\\bf R}^2 \\rightarrow {\\bf C}}")#text(". (Here it was important to get the operator norm bound below ")#mi("{\\frac{1}{3}}")#text("; they are barely able to do this, with a numerically obtained bound of ")#mi("{0.333032}")#text(", though this bound might not be optimal.)")

#text("The main remaining obstacle is that the “eigenvalue function” ")#mi("{q_*(z)}")#text(" is varying in the parameter ")#mi("{z}")#text(" rather than constant. (This issue was, by the way, anticipated to some extent in ")#link("https://arxiv.org/abs/1006.0732")[#text("previous work of Demeter")]#text(", who observed that eigenfunctions of the almost Matthieu discrete Schrödinger operator gave a near-miss counterexample to the HRT conjecture, but with an eigenvalue that depended on an auxiliary phase shift parameter rather than constant.) However, if one was able to solve the scalar cocycle equation ")#metadata(none) <tao-19042a467cb03f74f8dc>#mi("\\displaystyle  q_*(z) h(z-\\tau) = c_* h(z) \\ \\ \\ \\ \\ (5)")#text(" ")#text(" for some smooth ")#mi("{h : {\\bf R}^2 \\rightarrow {\\bf C}}")#text(", then one could solve the equation ")#link(<tao-70868ce890a49e8cc136>)[#text("(4)")]#text(" by setting ")#mi("{F_*(z) = h(z) v_*(z)}")#text(". The approach to solve ")#link(<tao-19042a467cb03f74f8dc>)[#text("(5)")]#text(" is standard: take logarithms, apply a Fourier transform, and then divide out by the multiplier associated to the ")#mi("{\\tau}")#text(" shift. This can cause a well-known “small divisor” problem (which arises in various dynamical contexts, such as in the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%E2%80%93Arnold%E2%80%93Moser_theorem")[#text("KAM theorem")]#text(") if ")#mi("{\\tau}")#text(" behaves too much like a rational vector, but the standard resolution to this is to select a shift ")#mi("{\\tau}")#text(" that obeys good Diophantine approximation properties. For the purposes of numerics the authors selected an extremely concrete shift, namely")

#align(center)[#tao-fit-display[#mitex("\\tau = (2^{1/3} - 1, 2^{2/3} - 1)")]]

#text("but I get the impression that the exact choice here was not crucial for the argument, and that many other irrational algebraic numbers could have worked here.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bcf76f63440f7d79f4d6a36dd9618b4808d330395daf5d19dcbec4f77b09c78-49c4881b95c0d221d329660a593af13b6c9d9adf71763763ef5974b85918a77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693811")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("I’m curious to see what obstructions come with reducing the size of the counter example if possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("This was one of the topics I discussed in my ")#link("https://chatgpt.com/share/6a74dfc3-c614-83e8-b36b-9b07bf8d55fa")[#text("conversation with an AI")]#text(". The specific construction used would be difficult to directly reduce in size, but it seems likely that some variant of the construction could lower ")#mi("n")#text(" slightly from its current value of ")#mi("12")#text(", though it seems unlikely that the lowest theoretically possible value ")#mi("n=4")#text(" would be attainable by this method.")

#text("In the opposite direction, it appears that if one is fine with disproving the HRT conjecture with a large unspecified value of ")#mi("n")#text(", that one can adapt the arguments in the preprint to do this without any numerical computation whatsoever, roughly speaking by developing a Stone-Weierstrass type result that asserts that the set of all possible matrix functions ")#mi("B_*")#text(" (with unspecified ")#mi("n")#text(") is dense enough that one can approximate any given rank one candidate ")#mi("B_0")#text(" uniformly to any desired accuracy. In fact one does not even need the full strength of the Stone-Weierstrass theorem; a standard Fourier series expansion, followed by a truncation, is sufficient. I used an AI to generate a quick sketch of this variant of the argument ")#link("https://terrytao.wordpress.com/wp-content/uploads/2026/08/qualitative_hrt_counterexample.pdf")[#text("here")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc6e749d910dbb2c9494728177d00b0309abcdc3fcee34da788496a6e4d2bf1-4875e058b252eb967df05b4b3c6eeb8b696cf5aad07ae41b9654319b293bc479.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jt.vanvelthoven")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693829")[#strong[#text("jt.vanvelthoven")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("Many thanks for this interesting post!")

#text("I can confirm that, to our understanding, the numerical part is indeed only needed to justify the specific point configuration. As written in Section 1.2 of the paper, the initial counterexample we obtained (with the help of ChatGPT) was an at-first-only-existential construction. Only after we urged for a fixed configuration was the numerical part established. As already observed in the post, one interesting feature of this configuration is that it only differs from a (translate of a) lattice by one point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c6377b9dbb9aa0844f36e716456cf8527f0fa678645e329b95202b5ba68bdc-cbc655b374f534cc75a94fbd4bb5f177ac12d730496c1a0d49e4b7511a79872e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vignon Oussa")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693833")[#strong[#text("Vignon Oussa")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("Professor Tao, thank you for this very helpful digestion. I believe your qualification “by this method” identifies exactly the relevant difficulty. A direct compression of the one-step rank-one approximation appears implausible with only three Weyl terms.")

#text("The four-point candidate I have been studying attempts to evade that obstruction rather than overcome it directly. Its one-step symbol is")

#text("A(x,ω) = I + (3/5)e^{-πiω}D + (3/5)e^{πix}S.")

#text("It is not uniformly close to rank one. Indeed, at x=ω=1/2 one has A* A=(43/25)I, so its operator-norm distance from every rank-one matrix is √43/5, far above the 1/3 perturbative threshold.")

#text("The proposed mechanism instead uses long-block domination. Outward-rounded interval calculations give, uniformly in z,")

#text("σ₂(P₁₆(z))/σ₁(P₁₆(z)) < 10⁻³,")

#text("together with a consecutive-block junction bound greater than 1/4. The invariant line is therefore produced by sixteen-step dominated dynamics rather than by one-step proximity to a prescribed rank-one transporter. A two-gauge half-plane calculation is then used to control the multiplier winding, after which the cubic Diophantine cohomological argument produces the eigenfunction.")

#text("This leads to the proposed relation")

#text("[I+(3/5)ρ(1,0)+(3/5)ρ(0,1/2)]ρ(ζ)g=λg,")

#text("where ζ=(∛2−1,(∛4−1)/2), giving four shifts after including the eigenvalue term.")

#text("Because a four-point counterexample would be a minimal and very surprising result, I am treating the manuscript as provisional pending independent specialist checking. The complete Arb verification supplement is available ")#link("https://www.dropbox.com/scl/fo/zgsmpuar02zar5eayz1p3/AGHWT_hP_nLAFQBumvb-U7U?rlkey=i76xop0nhajwh7n1o0bzpaqf6&dl=0")[#text("here")]#text(", and the partial Lean companion is available ")#link("https://www.dropbox.com/scl/fi/foq7hpfwfd0sabm9ot462/SubcriticalFourPointCertificate.lean?rlkey=smt87jkdex7bkhezdrb942j8h&dl=0")[#text("here")]#text(". The Lean file verifies many finite algebraic bridges but is not an end-to-end formalization.")

#text("I would be especially grateful for scrutiny of the passage from the block-dominated splitting to the globally sewn one-step invariant section, and of the subsequent winding and cohomological steps. Thus, as I presently understand it, your skepticism remains correct for the one-step approximation architecture, while the candidate uses a different, long-block dynamical mechanism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c6377b9dbb9aa0844f36e716456cf8527f0fa678645e329b95202b5ba68bdc-cbc655b374f534cc75a94fbd4bb5f177ac12d730496c1a0d49e4b7511a79872e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vignon Oussa")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693834")[#strong[#text("Vignon Oussa")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("I forgot to provide a link to the four case: ")#link("https://www.researchgate.net/publication/411785687_An_intrinsically_subcritical_four-point_counterexample_to_the_HRT_conjecture#fullTextFileContent")[#text("https://www.researchgate.net/publication/411785687_An_intrinsically_subcritical_four-point_counterexample_to_the_HRT_conjecture#fullTextFileContent")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d63d41c9cf4d921d6ceef87c9b8d0d1f57254f648e0c2e785efad352a850e419-3771e98838d83e6eca535b731538af957220cec5537ec9d1f017f45ad85aca5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin G. Mixon")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693915")[#strong[#text("Dustin G. Mixon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("I worked with John Jasper to flesh out this Stone-Weierstrass type idea, and we managed to show that Bownik and Speegle’s faster-than-exponential result is nearly tight: ")#link("https://arxiv.org/abs/2608.13539")[#text("https://arxiv.org/abs/2608.13539")]#text(" . We tried to optimize our write-up for human readability. Feedback is welcome.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("You highlight in your post that the authors responsibly disclosed their AI use, and as a consequence I got curious and had a look, making me then ponder about the question of whether expecting such disclosures is actually helpful. I understand that naming a tool precisely can be crucial in research, for the purpose of making the obtained results reproducible by others. But AI acknowledgements in math seem not to help much in this direction. If all sources of used ideas have been correctly and carefully cited (which may be hard work in the case of AI assistance, as AI tools could omit origins of ideas) and if all colleagues who gave some useful input have been acknowledged (at least those who wanted to be acknowledged), I feel it could be already sufficient. In my working country, it can be quite difficult to get access to strong AI tools for research, and seeing all these disclosures recently I don’t really know what to think about them. Do papers without AI disclosures now receive increasing skepticism (like people thinking along the lines of “they most likely used AI in an essential way but just hide it”)? What about authors who cannot afford good AI tools, should they consider making up fake AI disclosures just for the sake of not looking suspicious? (of course the answer to that one should be a clear no, but I was still wondering about this). And on the contrary, could honest AI disclosures (even in the case of very minor AI use) be actually hurtful for the careers of unexperienced and young authors (say with their first paper in 2026 or later)? Sorry for drifting off topic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("My view is that AI disclosure is consistent with the scientific principle of disclosing one’s research methodology, which I believe to be good practice even if not directly reproducible. For instance, knowing that a certain problem is amenable to AI assistance provides useful information that related problems might also benefit from such assistance. Also, it is possible that authors might be willing to supply prompts or other information about their use of AI upon request.")

#text("I have also seen negative AI disclosures, in that the authors declared for instance that they tried using AI tools but did not obtain useful output from them. This I think is also useful information (and it would be more broadly useful in general to have more normalized reporting of negative results).")

#text("I will also note that disclosure of tool use is one of the recommendations of the ")#link("https://leidendeclaration.ai/")[#text("Leiden declaration")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("Would you also be kind enough to have recommendations on how to navigate AI systems to solve problems? Would there be certain types of formulations that make questions and prompts more successful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693854")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("You can find my advice on AI usage summarized at ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("https://teorth.github.io/tao-web/ai-views.html")]#text(", with links to the source interviews, talks, and posts I have given on this topic.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("What about Crozeuix conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("AI is really good at constructing examples and counterexamples. It sucks at proving universal statements for all objects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f5e75dd5d1b84462a93fda2757d25279ed40d7abfe639eb97c2d3c4360bac0-20128771c050417854a2a39358afc5479821fc71248c3788ac63054a269a920d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Ktitarev")]], [#link("https://terrytao.wordpress.com/2026/08/06/a-partial-digestion-of-the-hrt-counterexample/#comment-693872")[#strong[#text("Tim Ktitarev")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("There is an extra “is” in the sentence")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The conjecture is also known if {f} ")#emph[#text("is")]#text(" decays at a suitably super-exponential rate […]")
]

#emph[#text("[Corrected, thanks – T.]")]
]
