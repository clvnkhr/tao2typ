// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/
// Converted to Typst by tao2typ: "2026-10-14T11:10:43.469668+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A lower bound on the mean value of the Erdős-Hooley delta function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A lower bound on the mean value of the Erdős-Hooley delta function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 August 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/")[#text("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://en.wikipedia.org/wiki/Kevin_Ford_(mathematician)")[#text("Kevin Ford")]#text(", ")#link("https://dms.umontreal.ca/~koukoulo/")[#text("Dimitris Koukoulopoulos")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/2308.11987")[#text("A lower bound on the mean value of the Erdős-Hooley delta function")]#text("“. This paper complements the ")#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/")[#text("recent paper of Dimitris and myself")]#text(" obtaining the upper bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\Delta(n) \\ll (\\log\\log x)^{11/4}")]]

#text("on the mean value of the ")#emph[#text("Erdős-Hooley delta function")]

#align(center)[#tao-fit-display[#mitex("\\Delta(n) := \\sup_u \\# \\{ d|n: e^u < d \\leq e^{u+1} \\}")]]

#text("In this paper we obtain a lower bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\Delta(n) \\gg (\\log\\log x)^{1+\\eta-o(1)}")]]

#text("where ")#mi("{\\eta = 0.3533227\\dots}")#text(" is an exponent that arose in previous work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4588563")[#text("result of Ford, Green, and Koukoulopoulos")]#text(", who showed that")

#metadata(none) <tao-a21252ca46990e1e2c23>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Delta(n) \\gg (\\log\\log n)^{\\eta-o(1)}")]]

#text("for all ")#mi("{n}")#text(" outside of a set of density zero. The previous best known lower bound for the mean value was")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\Delta(n) \\gg \\log\\log x,")]]

#link("https://mathscinet.ams.org/mathscinet-getitem?mr=964687")[#text("due to Hall and Tenenbaum")]#text(".")

#text("The point is the main contributions to the mean value of ")#mi("{\\Delta(n)}")#text(" are driven not by “typical” numbers ")#mi("{n}")#text(" of some size ")#mi("{x}")#text(", but rather of numbers that have a splitting")

#align(center)[#tao-fit-display[#mitex("n = n^{\\prime} n^{\\prime\\prime}")]]

#text("where ")#mi("{n^{\\prime\\prime}}")#text(" is the product of primes between some intermediate threshold ")#mi("{1 \\leq y \\leq x}")#text(" and ")#mi("{x}")#text(" and behaves “typically” (so in particular, it has about ")#mi("{\\log\\log x - \\log\\log y + O(\\sqrt{\\log\\log x})}")#text(" prime factors, as per the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy-Ramanujan law")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdős-Kac law")]#text(", but ")#mi("{n^{\\prime}}")#text(" is the product of primes up to ")#mi("{y}")#text(" and has double the number of typical prime factors – ")#mi("{2 \\log\\log y + O(\\sqrt{\\log\\log x})}")#text(", rather than ")#mi("{\\log\\log y + O(\\sqrt{\\log\\log x})}")#text(" – thus ")#mi("{n^{\\prime\\prime}}")#text(" is the type of number that would make a significant contribution to the mean value of the divisor function ")#mi("{\\tau(n^{\\prime\\prime})}")#text(". Here ")#mi("{y}")#text(" is such that ")#mi("{\\log\\log y}")#text(" is an integer in the range")

#align(center)[#tao-fit-display[#mitex("\\varepsilon\\log\\log x \\leq \\log \\log y \\leq (1-\\varepsilon) \\log\\log x")]]

#text("for some small constant ")#mi("{\\varepsilon>0}")#text(" there are basically ")#mi("{\\log\\log x}")#text(" different values of ")#mi("{y}")#text(" give essentially disjoint contributions. From the easy inequalities")

#metadata(none) <tao-d5e806904f5982a2a99f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta(n) \\gg \\Delta(n^{\\prime}) \\Delta(n^{\\prime\\prime}) \\geq \\frac{\\tau(n^{\\prime})}{\\log n^{\\prime}} \\Delta(n^{\\prime\\prime})")]]

#text("(the latter coming from the pigeonhole principle) and the fact that ")#mi("{\\frac{\\tau(n^{\\prime})}{\\log n^{\\prime}}}")#text(" has mean about one, one would expect to get the above result provided that one could get a lower bound of the form")

#metadata(none) <tao-4392356c1d08b116c065>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Delta(n^{\\prime\\prime}) \\gg (\\log \\log n^{\\prime\\prime})^{\\eta-o(1)}")]]

#text("for most typical ")#mi("{n^{\\prime\\prime}}")#text(" with prime factors between ")#mi("{y}")#text(" and ")#mi("{x}")#text(". Unfortunately, due to the lack of small prime factors in ")#mi("{n^{\\prime\\prime}}")#text(", the arguments of Ford, Green, Koukoulopoulos that give ")#link(<tao-a21252ca46990e1e2c23>)[#text("(1)")]#text(" for typical ")#mi("{n}")#text(" do not quite work for the rougher numbers ")#mi("{n^{\\prime\\prime}}")#text(". However, it turns out that one can get around this problem by replacing ")#link(<tao-d5e806904f5982a2a99f>)[#text("(2)")]#text(" by the more efficient inequality")

#align(center)[#tao-fit-display[#mitex("\\Delta(n) \\gg \\frac{\\tau(n^{\\prime})}{\\log n^{\\prime}} \\Delta^{(\\log n^{\\prime})}(n^{\\prime\\prime})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Delta^{(v)}(n) := \\sup_u \\# \\{ d|n: e^u < d \\leq e^{u+v} \\}")]]

#text("is an enlarged version of ")#mi("{\\Delta^{(n)}}")#text(" when ")#mi("{v \\geq 1}")#text(". This inequality is easily proven by applying the pigeonhole principle to the factors of ")#mi("{n}")#text(" of the form ")#mi("{d^{\\prime} d^{\\prime\\prime}}")#text(", where ")#mi("{d^{\\prime}}")#text(" is one of the ")#mi("{\\tau(n^{\\prime})}")#text(" factors of ")#mi("{n^{\\prime}}")#text(", and ")#mi("{d^{\\prime\\prime}}")#text(" is one of the ")#mi("{\\Delta^{(\\log n^{\\prime})}(n^{\\prime\\prime})}")#text(" factors of ")#mi("{n^{\\prime\\prime}}")#text(" in the optimal interval ")#mi("{[e^u, e^{u+\\log n^{\\prime}}]}")#text(". The extra room provided by the enlargement of the range ")#mi("{[e^u, e^{u+1}]}")#text(" to ")#mi("{[e^u, e^{u+\\log n^{\\prime}}]}")#text(" turns out to be sufficient to adapt the Ford-Green-Koukoulopoulos argument to the rough setting. In fact we are able to use the main technical estimate from that paper as a “black box”, namely that if one considers a random subset ")#mi("{A}")#text(" of ")#mi("{[D^c, D]}")#text(" for some small ")#mi("{c>0}")#text(" and sufficiently large ")#mi("{D}")#text(" with each ")#mi("{n \\in [D^c, D]}")#text(" lying in ")#mi("{A}")#text(" with an independent probability ")#mi("{1/n}")#text(", then with high probability there should be ")#mi("{\\gg c^{-1/\\eta+o(1)}}")#text(" subset sums of ")#mi("{A}")#text(" that attain the same value. (Initially, what “high probability” means is just “close to ")#mi("{1}")#text("“, but one can reduce the failure probability significantly as ")#mi("{c \\rightarrow 0}")#text(" by a “tensor power trick” taking advantage of Bennett’s inequality.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e04b796630860f6b9ecc1c9395de109de4fbb15ba089fb8b75955223f5eeacf-5548be6be7d16f81d2cb326b616e4b838102b08aafdab5dd483a337cab552c8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isaacg227")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681139")[#strong[#text("isaacg227")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("Looks like there’s a typo in the equation just after “In this paper we obtain a lower bound “. Thanks for the post!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e04b796630860f6b9ecc1c9395de109de4fbb15ba089fb8b75955223f5eeacf-5548be6be7d16f81d2cb326b616e4b838102b08aafdab5dd483a337cab552c8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isaacg227")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681141")[#strong[#text("isaacg227")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("Similarly, the 1/x in front of the summations in the first two inequalities seem to be redundant with the x in front of the log log … on the right hand side of those inequalities.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b639a16da0221dbab5f23f98d6184b2d114968d92d6adaca2ecad6a0578a8ba-c5d80be4937db331a653fdb5c30da9c0d5c55f1fb7e99ac5feb5697e6432a564.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe34")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681143")[#strong[#text("joe34")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("Is there a conjecture for tight bounds, or even an exact growth rate, between the 11/4=3.75 and the 1.353…? And what is your hunch on the sort of difficulty it requires? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681151")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2023")])]

#text("Good question. My co-authors, who have worked more extensively with the Erdős-Hooley function than I have, are more inclined to conjecture that the exponent 1.353… is in fact the truth. I do not have a strong opinion here, though certainly I do not think the 11/4 exponent is optimal, as it comes from some clear limitations to our upper bound method (actually, I am surprised that our upper bound approach, based on the moment method, is as effective as it is).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681145")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2023")])]

#text("It would be interesting to consider this problem for a generalization of the function ")#mi("\\Delta(n)")#text(" to ")#mi("\\Delta(n, \\delta)")#text(" where in the definition of ")#mi("\\Delta(n)")#text(" the upper bound ")#mi("e^{u+1}")#text(" is replaced by ")#mi("e^{u+\\delta}")#text(" for some fixed positive parameter ")#mi("\\delta")#text(" (i.e. using a general “window” for the divisors d inthe definition)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681152")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2023")])]

#text("For ")#mi("\\delta \\geq 1")#text(", one has from the triangle inequality that ")#mi("\\Delta(n) \\leq \\Delta(n,\\delta) \\ll \\delta \\Delta(n)")#text(", while similarly for ")#mi("0 < \\delta \\leq 1")#text(" one has ")#mi("\\delta \\Delta(n) \\ll \\Delta(n,\\delta) \\leq \\Delta(n)")#text(". So for fixed ")#mi("\\delta")#text(" the asymptotics are not much different from the ")#mi("\\delta=1")#text(" case, but it could be interesting to consider values of ")#mi("\\delta")#text(" that grow or shrink with ")#mi("n")#text(". For instance in the arguments of our paper it becomes important to consider a choice of ")#mi("\\delta")#text(" which is comparable to ")#mi("\\log n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2023")])]

#text("There appears to be a couple of typos with the co-author’s surname. It should be Koukoulopoulos instead of Koukoulopolous.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-681161")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2023")])]

#text("Small typo in your writeup: “area” is written rather than “are” in Definition 1 on page 2.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2023/08/23/a-lower-bound-on-the-mean-value-of-the-erdos-hooley-delta-function/#comment-682192")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2023")])]

#text("Can we use the ratio 𝜎(n+1)/𝜎(n) and the Lagarias inequality to prove RH? Dear Professor Terence Tao")
]
