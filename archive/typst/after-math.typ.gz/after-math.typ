// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/12/after-math/
// Converted to Typst by tao2typ: "2026-10-14T11:19:03.831937+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "After Math", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("After Math")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/12/after-math/")[#text("https://terrytao.wordpress.com/2026/09/12/after-math/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.silviadetoffoli.net/")[#text("Silvia De Toffoli")]#text(" and ")#link("https://eamonduede.com/")[#text("Eamon Duede")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#link("https://www.silviadetoffoli.net/")[#text("Silvia De Toffoli")]#text(" ")#emph[#text("(University School for Advanced Studies IUSS Pavia)")]#text(" ")#linebreak()#text(" ")#link("https://eamonduede.com/")[#text("Eamon Duede")]#text(" ")#emph[#text("(Princeton University and Purdue University)")]

#text("On September 8th, 2026, ")#link("https://openai.com/index/navier-stokes-solution/")[#text("OpenAI announced")]#text(" that it had produced an AI-generated solution to the Navier–Stokes existence and smoothness problem, one of the seven Millennium Prize Problems. The announcement kicked off debate over credit allocation and the respective contributions of humans and machines to the result. Moreover, the announcement intensified already circulating comparisons with earlier AI conquests in domains believed to otherwise exemplify human intellectual prowess. In a recent ")#link("https://cims.nyu.edu/~tristanb/statement.pdf")[#text("statement")]#text(", Tristan Buckmaster, one of the mathematicians involved in the Navier–Stokes saga, wrote: “This is a Deep Blue–Kasparov moment.”")

#text("Existential questions for mathematics follow naturally: if AI can now provide answers to questions at the very frontier of mathematics, is the discipline on the verge of being “solved” as many have said of chess and Go? Like chess and Go players, should mathematicians just “keep playing” and rearrange their practices?")

#metadata(none) <tao-444c694478b37c275d89>

#text("There is something right about the “keep playing” response. As philosopher C. Thi Nguyen (")#link("https://philpapers.org/archive/NGUGAT-2.pdf")[#text("2019")]#text(") has been insisting, the purpose of playing a game is not exhausted by its aim (winning). The real point is not only the outcome but the process. This is perhaps clearer with a party game such as Twister than with chess: the aim of playing Twister is certainly not winning. But something similar also applies to deep intellectual games, like chess and Go. For instance, playing a game of Go well can be an achievement in defeat.")

#text("But in the context of mathematical practice, this feels like an unnecessary retreat. Instead, we can make a stronger move: ")#emph[#text("reject the characterization of mathematics as a game that makes the retreat seem necessary in the first place")]#text(".")

#text("The question, then, is not simply what comes after math, once AI can answer its hardest questions. It is also what we are after when we do mathematics in the first place.")

#text("The narrative that AI has “solved” mathematics rests on two assumptions, both seductive and plausible, but both wrong:")

#enum(start: 1, 
[#text("AI really did solve a problem in mathematics.")],
[#text("Mathematics is only about solving problems.")]
)

#text("The first assumption is wrong because to really solve a mathematical problem, providing a mere answer (even if formally certified) is not sufficient. What is missing is an intelligible proof that human mathematicians can understand and use to advance the aims of mathematics. And, as we will argue below, even if AI were to give us just that, the story would not be over because the second assumption is wrong. Mathematics is clearly a much broader enterprise than just problem solving. Mathematicians strive to develop new concepts and theories, to ask and answer new questions, to unify disparate areas, to educate and sustain scholarly communities, and to produce work that is valued for its beauty and depth.")

#text("We can (and should) therefore reject the narrative of AI defeating humans at mathematics and start thinking hard about what mathematics really is and what we want it to be.")

#strong[#text("Not All Answers Are Solutions")]

#text("OpenAI produced an answer to the question of whether Navier–Stokes can develop a singularity: ")#emph[#text("yes")]#text(". In ")#emph[#text("The Hitchhiker’s Guide to the Galaxy")]#text(", Deep Thought produced an answer to life, the universe, and everything: ")#emph[#text("42")]#text(". Neither is exactly what we wanted.")

#text("Of course, OpenAI gave us much more than “yes.” Deep Thought offered only a number, whereas OpenAI produced two artifacts that many are willing to call proofs. The first is a Lean formalization certifying validity. This was accompanied by a manuscript that appears to contain the corresponding informal proof. So, why is this still dissatisfying? The reason has to do with the underlying notion of proof itself.")

#text("There are, in fact, two notions of proof: a ")#emph[#text("logical")]#text(" notion and an ")#emph[#text("intelligible")]#text(" notion.")

#text("Modern logic characterizes proof in terms of deductive validity such that a proof can be checked by a mechanical procedure that does not itself require understanding of the mathematical argument. A Lean formalization meets these standards exactly and a Lean formalization of the Navier–Stokes result is therefore a genuine and important contribution: by meeting the demands of the logical notion of proof, it secures certainty.")

#text("But mathematicians also want something else from proof. They want understanding (")#link("https://arxiv.org/pdf/math/9404236")[#text("Thurston 1994")]#text("). They want to know what makes a proposition true. This kind of knowledge trades in mathematical ideas that they can grasp, communicate to other experts, connect with existing knowledge, and use to make further progress. This is the intelligible notion of proof. As of now, it is not clear that OpenAI’s result has given the mathematical community the kind of value that one expects from the intelligible notion of proof.")

#text("Genuine proofs are at the same time logical and intelligible proofs. Historically, the two notions have tended to run together. This is because no mathematician could produce an enormously complicated logical proof without first grasping some of the key shareable ideas that made the theorem true. The logical notion of proof was primarily used to verify the correctness of intelligible proofs (")#link("https://philpapers.org/archive/BURWIM-6.pdf")[#text("Burgess and De Toffoli 2022")]#text(").")

#text("But with AI, these two notions can now come apart dramatically. We can end up with formal proofs that float free from any intelligible proof.")

#text("This is not a criticism of formal proof. The converse problem is at least as serious. An intelligible mathematical argument can convey a grand idea while failing to establish that the result is actually true. Jaffe and Quinn (")#link("https://arxiv.org/pdf/math/9307227")[#text("1993")]#text(") famously used Thurston’s geometrization theorem for Haken three-manifolds as an example: a major insight accompanied by insufficiently complete proofs could become a “roadblock rather than an inspiration.” And one motivation for Hales’s Flyspeck formalization project was to verify that the intelligible (but hard to check) proof presented for the Kepler conjecture was, indeed, a genuine proof (")#link("https://arxiv.org/pdf/0902.0350")[#text("Hales et al. 2009")]#text(").")

#text("Therefore, falling short of either the logical or intelligible notion creates roadblocks where genuine proofs clear the way for mathematical progress. A real mathematical solution requires both logical correctness and intelligibility.")

#text("This is particularly clear in the case of the seven Millennium Prize Problems. They were not selected because mathematicians merely wanted seven ")#emph[#text("answers")]#text(", but rather because they wanted ")#emph[#text("fruitful solutions")]#text(". The Clay Mathematics Institute itself ")#link("https://www.claymath.org/millennium/navier-stokes-equation/")[#text("explains")]#text(" why proof matters in the case of Navier–Stokes: “Because a proof gives not only certitude, but also understanding.”")

#text("What OpenAI has given us is an answer. But it is not clear that they have delivered a fruitful solution. Perhaps, we will find that they have, but at the moment, the situation is far from clear. A genuine solution will provide adequate grounds for believing the result but also an intelligible mathematical argument that allows the result to become part of mathematics as understood and practiced by mathematicians.")

#text("Nevertheless, if it turns out that what OpenAI has provided is a mere answer, this is not enough to dispel the existential threat that mathematics is facing. Future AI systems are likely to produce genuine proofs that are at once formally certified and fully intelligible to mathematicians. So, current concerns that mathematics is on the verge of being “solved” by AI are not fully dispelled by simply insisting on genuine solutions rather than mere answers.")

#strong[#text("You Need More than Solutions to “Solve Math”")]

#text("If future AI systems will produce genuine proofs, logically correct and intelligible, like those produced by “master” mathematicians, it would still be incorrect to think that mathematics would have been “solved” as some say that chess or Go have been solved.")

#text("In chess and Go, we accept radically uneven competition between humans and machines because both are, in the relevant sense, ")#emph[#text("playing the same game")]#text(".")

#text("But mathematics is not (or at least not only) a game. To begin with, there is no winner. Mathematics is not an adversarial game with determinate conditions for victory. It is certainly true that mathematicians compete with one another for fame, prizes, jobs, and credit. Chess players do those things too. But chess players also win chess. There is no corresponding condition for winning mathematics. There is no mathematical checkmate.")

#text("In mathematics, it is more natural to treat AI as an assistant rather than as a competitor. As Jeremy Avigad (")#link("https://proofsandprompts.com/2026/09/07/what-is-mathematics-now-and-what-should-it-be/")[#text("2026")]#text(") puts it, “We should keep in mind that AI is nothing more than technology, designed to serve our purposes. It is misguided to think of mathematicians as competing with AI; when we drive a car, we aren’t competing to see who can go faster, and when we use a phone, we aren’t competing to see who can speak louder.”")

#text("But there is a deeper, and in many ways prior, problem with the competition framing. It requires accepting the assumption that solving problems is the activity by which mathematical success should be measured.")

#text("Genuine problem solving is certainly one of the principal aims of mathematics. It is not, however, its only aim. Mathematics is a body of knowledge engaged with, interpreted, and digested by a scholarly community and not a registry of results in the abstract. This simple point has even motivated an entire movement in the philosophy of mathematics: ")#link("https://plato.stanford.edu/entries/mathematical-practice/")[#text("the philosophy of mathematical practice")]#text(".")

#text("Terence Tao (")#link("https://arxiv.org/pdf/2608.16753")[#text("2026")]#text(") lists many goals of mathematics beyond problem solving. These include developing new theories and techniques, understanding the world, sustaining a community, training the next generation of mathematicians, contributing to cumulative knowledge, and creating works of aesthetic value. Of course, these have been positively correlated with genuine solutions.")

#text("But AI breaks that correlation, for the same reason it separates the two notions of proof. So, even genuine solutions would not satisfy us.")

#emph[#text("This is not moving the goalposts but recognizing that any specific goalpost is inadequate.")]#text(" If mathematics is a game, it is an infinite one.")

#text("This attitude is not reactionary. We reject both the concession that logically establishing a theorem is sufficient for a genuine proof and the reduction of “AI for mathematics” to proving theorems. Accepting this, we may find many opportunities for AI in mathematics to support human mathematical flourishing.")

#strong[#text("Aftermath")]

#text("We do not deny that, if OpenAI’s announcement is correct, this is an extraordinary achievement. But we should get clear about what type of achievement it is. At this moment, it is an answer, not a solution. And, even if in time the result reveals itself as a genuine solution, we have argued that, in the practice of mathematics, solutions are not everything.")

#text("The urgency of rethinking what we value in mathematics is already being recognized within the mathematical community. In a recent ")#link("https://mathandai.org/")[#text("declaration")]#text(" initially signed by 25 Fields Medallists, mathematicians warn of a “severe misalignment” between the goals of AI companies and those of the mathematical community.")

#text("Mathematicians need to do more to examine their norms. The priority norm is not the problem here (though it is likely a separate problem). The current failure to distinguish genuine solutions from answers, and the growing focus on problem-solving alone, are. This way of thinking is inspired by the current credit economy in mathematics and, as David Bessis recently discussed in his ")#link("https://davidbessis.substack.com/p/the-fall-of-the-theorem-economy")[#text("blog")]#text(", the credit economy needs rethinking.")

#text("AI presents mathematics not with an ending but with a choice about what mathematical practice should become. If mathematical success comes to be identified too closely with the production of certified answers, mathematics risks adapting itself to precisely those features that are easiest to benchmark and automate away.")

#text("If, instead, mathematicians treat AI as a technology for advancing its long-standing and centrally human purposes, the technology may come to contribute to an accelerated flourishing and enrichment of the discipline. The important question is, therefore, not whether AI will defeat mathematicians, but which mathematical ends we want AI to serve.")

#text("What remains in the aftermath is not merely leftovers for humans to scramble for once machines have devoured all of the real problems. Rather, it is an opportunity to clarify what mathematics is all about. We should ask again what we are after when we do mathematics.")

#text("(An extended version of this text will appear elsewhere.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("this is correct and somewhat more understood in arts (but perhaps it should indeed more correct to think of math as a form of art with a rather specific language)")

#text("As Bela Bartok said:")

#text("competitions are for horses, not for artists (nor for mathematicians)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694943")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“Mathematics is only about solving problems.”")

#text("If this is wrong, then why does achieving tenure heavily depend on mathematicians solving problems, and why are there so many prizes for solving problems, like the Millennium Prizes? There’s a significant mismatch between what mathematics is supposedly really about, and how mathematics academia structures the incentives to a successful mathematics career.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Historically since we are human solving a problem usually means you’ve discovered an intelligent path to the solution. This article successfully argues that AI has divorced these two concepts and therefore that problem-solving is not a useful benchmark.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("İn practice, however, problem solving has always come first. This has been the nature: once a problem has been solved, people quickly lose interest and move on to work on others. (Also most people need to use the statement of a theorem, not the proof.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This doesn’t ring true to me. It’s not like people move on to any old problem; rather once a technique has seen value in tackling one problem then there is hope in using it to tackle similar problems, or work on natural extensions, or build out some of the results into a wider theory etc.")

#text("E.g. people didn’t lose interest in Ricci flow once the Poincaré conjecture was solved, if anything interest in the area grew")

#text("Also your last statement (that “most” people only need the theorem and not the proof) is at best partially true in some areas; it is certainly false e.g. in most of analysis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This is not exactly the case in practice: if you are working hard on an important problem, it is a very painful process and all you want is to find a solution (and be the first to do it); you would not care if the proof is beatiful or not. The novelty comes first in academia; “digestive” work is not valued so much).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The mere fact there are prizes for hard math problems doesn’t justify the argument of “mathematics is only about solving problems”. As Tao said, this is only one of the aims of the field.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694944")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("[")#strong[#emph[#text("quote")]]#text("] ")#emph[#text("But mathematicians also want something else from proof. They want understanding (Thurston 1994). They want to know what makes a proposition true. This kind of knowledge trades in mathematical ideas that they can grasp, communicate to other experts, connect with existing knowledge, and use to make further progress. This is the intelligible notion of proof. As of now, it is not clear that OpenAI’s result has given the mathematical community the kind of value that one expects from the intelligible notion of proof.")]#text(" [")#strong[#emph[#text("unquote")]]#text("]")

#text("Yes indeed. Moreover:")

#strong[#text("I:")]#text(" Open AI’s result can claim to illuminate the ‘understanding’ mathematicians expects from a formal proof ")#emph[#text("only")]#text(" if it also validates that the proof interprets as a ‘mathematical truth’ over ")#emph[#text("some")]#text(" categorically communicable domain.")

#text("Reasons for the caveat? Three.")

#text("1. ")#emph[#link("https://www.dropbox.com/scl/fi/3pf0dztzrmawves7hhjpa/49_4CT_Submission_TCS__Rev-1_260527.pdf?rlkey=a0v13wucgyo79q9ny4qn7rtwp&dl=0")[#text("Understanding Why the Four Colour Theorem is True")]]#text(".")

#text("2. ")#emph[#link("https://www.dropbox.com/scl/fi/uk8nscl18s5y034hwin1k/54_Holy-Grail_240728_Update.pdf?rlkey=7o9rnigrnyatodbprcij7jey0&dl=0")[#text("The Holy Grail of Mathematics Is Arithmetical Truth, Not Set-Theoretical Proof")]]#text(".")

#text("3. ")#emph[#link("https://www.dropbox.com/scl/fi/2t36h3k048fciv7hudhg3/54_FLT_Understanding-Why-Fermat-s-Last-Theorem-is-True_260602.pdf?rlkey=umw97xyvf6featxl6qp3kbank&dl=0")[#text("Understanding Why Fermat’s Last Theorem is True")]]#text(".")

#text("In other words, AI agents must (even if only in principle) be capable of:")

#text("(a) distinguishing between ‘reportedly true’ statements and ‘mathematically true’ statements;")

#text("(b) validating a Lean theorem as a ‘mathematical truth’ over some well-defined (essentially ‘constructible’) domain.")

#strong[#text("II:")]#text(" I would further argue that:")

#text("(i) ")#strong[#emph[#text("if")]]#text(" a mathematicians overriding responsibility is to ensure that ")#emph[#text("any")]#text(" ‘proof’ proffered as definitive ‘knowledge’ by an AI formalises some intuitive, pre-formal human ‘truth’ that the AI — like any other formal mathematical language — was originally designed to express, and capture, formally as a ‘proof’;")

#text("(ii) ")#strong[#emph[#text("then")]]#text(" no AI will ever make mathematicians’ responsibility redundant.")

#strong[#emph[#text("Reason")]]#text("? There are mathematical ‘truths’ which an AI can ‘recognise’, but not ‘prove’; as admitted by ChatGPT in the dialogue reproduced in the preprint:")

#emph[#link("https://www.dropbox.com/scl/fi/xhrniw7be8nrcgnwu4plp/29_Are-you-a-man-or-a-machine_Godel_Submission_ICLA-2027_260821.pdf?rlkey=t44r24o5hzscirtufmk7s1fjj&dl=0")[#text("The Gödelian Turing Test: Both Copilot and ChatGPT ‘failed’ this Test")]]

#text("In other words:")

#list(
[#text("although an AI will undoubtedly become ‘robustly superhuman’ at establishing the internal consistency of a formal proof sequence of a (presumably first-order) mathematical language,")]
)

#list(
[#text("only a human intelligence can validate that the proof actually formalised the ‘mathematical truth’ of that which was sought to be formalised.")]
)

#text("The distinction can be expressed as the:")

#emph[#strong[#text("COMPLEMENTARITY THESIS")]]#text(": Mathematical ‘provability’ and mathematical ‘truth’ need to be interdependent and complementary, ‘evidence-based’, assignments-by-convention towards achieving:")

#text("(1) The goal of proof theory, post Peano, Dedekind and Hilbert, which is:")

#text("— to uniquely characterise each informally defined mathematical structure S (e.g., the Peano Postulates and their associated, classical, predicate logic),")

#text("– by a corresponding, formal, first-order language L, and a set P of finitary axioms/axiom schemas and rules of inference (e.g., the first-order Peano Arithmetic PA and its associated first-order logic FOL),")

#text("– which assign unique provability values (provable/unprovable) to each well-formed proposition of the language L without contradiction;")

#text("(2) The goal of constructive mathematics, post Brouwer and Tarski, which must be:")

#text("— to assign unique, evidence-based, truth values (true/false) to each well-formed proposition of the language L,")

#text("– under an, unarguably constructive, well-defined interpretation I over the domain D of the structure S,")

#text("– such that the provable formulas of L are true under the interpretation.")

#text("In other words:")

#text("(a) Whilst the goal of proof theory may be viewed as seeking to ensure that any mathematical language intended to formally represent our pre-formal conceptual metaphors and their inter-relatedness is unambiguous, and free from contradiction;")

#text("(b) The goal of constructive mathematics must be viewed as seeking to ensure that any such representation does, indeed, uniquely identify and adequately represent such metaphors and their inter-relatedness;")

#text("thus essentially ‘validating’ them in the sense of Per Martin-Löf’s 1987 analysis of the meaning and truth of a proposition, which can be treated as:")

#strong[#emph[#text("Löf’s Thesis")]]#text(": A proposition ‘A’ is a ‘truth’ if, and only if, it can be ‘asserted or judged’ as ‘A is true’ by appeal to some ‘evidence/proof’ for the truth of A which can be ‘validated’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#link("https://github.com/Lapin0t/grothendieck-cern")[#text("https://github.com/Lapin0t/grothendieck-cern")]

#link("https://publish.uwo.ca/~jbell/univ.pdf")[#text("https://publish.uwo.ca/~jbell/univ.pdf")]

#link("https://www.science.org/content/blog-post/business-scientific-publishing")[#text("https://www.science.org/content/blog-post/business-scientific-publishing")]

#link("https://web.archive.org/web/20191208021148/https://search.edwardsnowden.com/docs/SKYNETCourierDetectionviaMachineLearning2015-05-08nsadocs")[#text("https://web.archive.org/web/20191208021148/https://search.edwardsnowden.com/docs/SKYNETCourierDetectionviaMachineLearning2015-05-08nsadocs")]

#text("Very excited for the tech behind ")#link("https://en.wikipedia.org/wiki/2026_Minab_school_attack")[#text("https://en.wikipedia.org/wiki/2026_Minab_school_attack")]#text(" to solve the hodge conjecture can’t wait this is great what an exciting time to do math!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think knee-jerk reactions to defend the status quo in mathematical practice are understandable but misguided.")

#text("A machine that is able to prove statements that a human has formulated, on the basis of human concepts (e.g. distance & volume) that have evolved through time, would seem helpful to the human endeavour of mathematics rather than destructive. In particular it does not eliminate the role that human mathematicians play in using their intuition in ways that a machine cannot substitute for (at the moment this includes the initiation of a new subject or choosing problems that are of interest to humans).")

#text("No doubt many mathematicians would feel displeased that their efforts in solving specific, hard problems have been superceded. But it’s important to try and understand which part of these reactions are reasonable and which are merely hubris.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694964")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We should keep in mind that AI is nothing more than technology, designed to serve our purposes")
]

#text("Is it designed to serve ")#emph[#text("our")]#text(" purposes? And ‘AI’ is not what people have the biggest anxieties about, but say the companies developing such systems. ")#emph[#text("They")]#text(" do not exist to serve our purposes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Without human mathematicians, who would care what math problems can AI solve?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“Mathematics is only about solving problems.”")

#text("Mathematics is only about solving problems in the high school mathematics curriculum. If you want to change the perception of mathematics among the general public, many of whom don’t ever attend college, then the high school mathematics curriculum needs to be completely overhauled with significantly less emphasis on e.g. solving problems in their algebra classes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Pure mathematicians will never win in any curriculum battle at the high school or university level vs the engineers and business leaders who have a “shut up and calculate” attitude towards mathematics. It’s why pure mathematics is getting defunded by universities, and all the money is headed towards research in data science, statistics, applied mathematics, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("That’s already being done in high schools across the United States. Go check out Ohio’s Algebra II equivalent classes for example. The data science and advanced quantitative reasoning classes have much less emphasis on getting the answer correct, because you’re dealing with real world data and building mathematical models. There isn’t a single correct answer here because of the messiness of the real world and the inherent limitations of simplified mathematical models to explain the world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-694972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Since the post referred several times to games, I want to make a book recommendation: ")#emph[#text("The Well-Played Game")]#text(", by Bernard De Koven is an excellent meditation on why we play games. The thesis is that playing a game isn’t really about winning or losing–it is about achieving “the well-played game.” The book discusses the paradoxical need to at once care deeply about the game, but at the same time not to become so competitive that your opponent has to remind you to relax–it’s just a game. Another thesis is that the pursuit of the well-played game has much in common with the pursuit of the well-lived life.")

#text("I think many of these lessons carry over to mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695036")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("In chess, engines have become an oracle that tells chess players what is the “best move”, after which chess players start to theorise why the move proposed by the engine is the “best”. Even as AI produces intelligible proofs, would AI then become an oracle for truth and falsity of mathematical statements or which the job of mathematicians then becomes to digest these statements into what is termed in this blogpost as “logical” proofs?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The main counterargument for this essay is that the LLM’s could (and do) also help with producing the “intelligible notion of proof”. My main evidence for this claim is in fact from this very blog:")

#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/")[#text("A digestion of the Jacobian conjecture counterexample")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I don’t think this is a requirement: “,,,intelligible proof that human mathematicians can understand,,,”")

#text("I mean, if aliens showed up with a faster than light starship (to make a fun and extreme example), and they gave us a proof it works, could we understand it? What is they are simply smarter than the smartest human and we could never understand the proof? We could still hop on the ship and explore/infest the galaxy.")

#text("If other AI agents understand and accept the proof, would that be enough?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of guillaume")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695065")[#strong[#text("guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Although I do agree that the way we do mathematics today is problematic and could be changed, I think one must be very careful with the idea that with AI we will just have a great new tool to do mathematics in another way. This might be true for me (an active mathematician who already spent years working hard, and most of the time failing on problems), but what about the next generation? How can they even become mathematicians without spending days and months and years trying, and often failing? Even if mathematics is about understanding more than about solving problems, we do not know another way of building understanding than the very patient process of research, and I do not see how it can survive if the use of AI oracles becomes normalized.")

#text("The idea that we can use AI for math looks short-sighted to me, I do not see how it is compatible with creating new generations of mathematicians.")

#text("This point of view seems (statistically) reflected in what I observe around me: some older or middle-aged colleagues are tempted to use it as a tactical tool, but the PhD students are all terrified and very much against its use.")

#text("(note: I wish I missed something and everything turned great in the end… )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("About mathematics belonging to humanities. I definitely adhere to this, and I think that most mathematicians do what they do in such a spirit. But if this became the public’s view, we know what this implies in terms of funding…")

#text("Mathematicians should acknowledge that humanities are important, which, as a community, is not really what we have done so far. It was just too comfortable to rest on the public’s idea that math=technology=money, which, even we prefer not to think about it, is eventually the reason why math is widely taught and funded (an this is a card that our universities, departments, grant agencies, etc. have played regularly)")

#text("Siding with humanities and arts is the right thing to do, but the fight will be tough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695073")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Agreed. IIt’s a stage play that AI companies are doing, first about RH claim, then FLT and now this. During last 2-3 years I worked with AI for numerical verifications and observed that they are nothing for math perspectives or are purely dependent on humans. This is my honest observation, in parallel we humans including junior FMs are playing at both sides worst to worst they are writing articles from other to praise their nonsense results by using the words like Breakthrough. This is absurd and a significant crime. So to put all burden on Ai companies is not justified. Math always survives and AI is a good addition. Dnt affraid. Just do your work. If someone tried to delete this comment then he is a real cowered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thank you for the wonderful and thoughtful post!")

#text("I recently stumbled into two old Richard Feynman quotes that feel apt for the moment:")

#list(
[#strong[#text("“I couldn’t reduce it to the freshman level. That means we really don’t understand it.”")]],
[#strong[#text("“We do not yet know all the basic laws: there is an expanding frontier of ignorance.”")]]
)

#text("In my own explorations, I’ve found that: (a) while AI is very capable of synthesizing, constructing and expanding from what is currently believed (and therefore in its weights), it struggles with areas that might be deeply wrong but are “against its weights” and (b) the existence of a formal proof might provide a crack in a problem, but it by no means we have captured the whole of the problem or passed Feynman’s test of understanding.")

#text("Given we’ve been handed an infinite accelerator to the frontier of ignorance, the path might be something more like the Langlands project to look beneath the classical axioms and strengthen our foundations. Terry’s extraordinary work on Equational Theories could be a lighthouse for the future. What would it look like to re-define the classical types based on their raw magma equational laws to push the limits of an axiom-free foundation for math? The LLMs have no priors for exploring the truncation effect of Nat on a freemagma tree, or the implications of selecting a single magma and arbitrarily labeling it zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695106")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("millions of $s teams of engineers 1000s of watts on 10000 agents in a few days + billions of $s teams of scientists and engineers multi year work and megawatts of power to build the model vs 10-20 mathematicians over 80 years which is less than 1 mw of brain power to get the formulation right to feed into the ai. You call this progress?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695109")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I agree with the broader point that mathematics is about more than obtaining correct answers, and that understanding is central to its value. However, I would be cautious about classifying this particular work as merely an answer rather than a solution before its mathematical content has been carefully assessed.")

#text("I would be interested to hear from mathematicians who have read the manuscript closely: does it contain new mathematical ideas, useful constructions, or insights that could inspire further work? Even if discovering the argument required enormous computational resources, it does not follow that the argument itself is merely brute force or devoid of mathematical ideas. The resources used to find a proof and the mathematical understanding it offers are distinct questions.")

#text("We should also distinguish between a proof that has not yet been understood and one that does not offer understanding. AI may itself help us unpack a long manuscript and identify its conceptual structure. I am not claiming that this particular manuscript necessarily contains important new insights; rather, I think that an assessment of its mathematical value should be grounded in careful engagement with the argument.")

#text("There is a related issue within our own mathematical culture. I have heard one mathematician dismiss another’s work as “just technical computation” without new ideas. Sometimes such criticism is justified, but it can also be premature or unfair. Ideas need not take the form of a visibly new conceptual framework; they may also be embedded in difficult technical arguments. As we articulate standards for evaluating AI-generated mathematics, we should reflect on how carefully and fairly we apply those standards to one another. The call for understanding should motivate engagement with a proof, rather than become a substitute for it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I agree with you that understanding methodology and techniques involved in a proof is very important. But, if this counterexample found more or less by brute force, passes per-review, why to worry? Proof is a proof")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I agree that mathematics is about more than correct answers. However, I would hesitate to classify this manuscript as an “answer, not a solution” before its mathematical content has been carefully assessed. Does it contain ideas or constructions that could inspire further work? The enormous computational resources used to discover a proof do not imply that the proof itself is merely brute force or lacks insight. The resources used to find a proof and the mathematical understanding it offers are distinct questions. AI may also help us understand a long manuscript more quickly.")

#text("There is a parallel within our own mathematical culture: mathematicians sometimes dismiss others’ work as “just technical computation” without new ideas. Such criticism can be justified, but it can also be premature or unfair. Important ideas may be embedded in technical arguments, rather than expressed as a new conceptual framework. We should reflect on these habits when evaluating AI-generated mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("It will always be valuable for humans, so long as we exist, to support a relatively small group of pure mathematicians who cherish mathematics and its history–even if we soon have AI capable of producing logical and intelligible proofs. It would be a loss to humanity for this group to disappear, just as it would be a loss if people who like to sew were never to sew again simply because machines can manufacture clothes of equal or better quality faster. (If that analogy makes you uncomfortable because it compares mathematics to sewing, then you will be in for a rough time in the AI future of mathematics.)")

#text("What AI will do for mathematics is weed out those who view mathematics primarily as a job or as a status-competition to be “won” via awards, breakthrough discoveries, aggressive social one-upmanship, or the thrill of intellectual dominance. The question is how many mathematicians of quality will this do away with? A lot, I suspect–many of whom, had strong mathematical AI not arrived, would have gone on to make great contributions.")

#text("But over time a new and gentler equilibrium will be established. To think that pure mathematicians will disappear completely is to take a rather cynical view of the motivations and psychology of most mathematicians. The beauty of mathematics in itself, the struggle to understand for oneself that beauty at a deeper and deeper level within a pleasant community of the like-minded, will reign supreme. And probably for the better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I feel like a lot of discussion about AI in mathematics (and to some extent, the arts and other knowledge disciplines) involves a lot of justified and yet premature existential dread. Frontier models, in their current form, are not sustainable. Not economically, not socially, and not environmentally. No-one really knows what a sustainable model of LLMs will look like and what is technologically possible.")

#text("It feels akin to seeing a peaceful but heretofore relatively isolated village suddenly attacked by invaders, who try to carry off what they think is valuable and destroy anything else. That people can and will invade the village may come as a shock, but the exact implications of that can wait until the villagers band together and drive the invaders off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695148")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Disclaimer: I am not a Mathematician.")

#text("Lots of the recent AI discussions sound pre-Mochizuki to me. With Mochizuki the public perception of mathematical proofs and the perception of the health of the field changed. If we only had a formalization .. was often heard. Honest people in the field found his papers AI-Slop before the name was invented, nice people called it “as if we got a paper from the future”.")

#text("Maybe read about other fields flooded with AI-Papers that have no LEAN or Isabelle/HOL. They have a REAL problem.")

#text("On Navier-Stokes: I think it was ripe to be plucked and obviously a multitude of people worked against that goal with similar approaches. With Alpoge involved there is also a conception of “oh AI people A lost against AI people B “.")

#text("My prediction: Math tried to get the public excited with stuff like “Millenium problems” and the popularisation of FLT. Now it gets the results: The public is excited about stuff it has heard off. But the news cycle will fade quickly. The next falling millenial problem will get way less fanfare. Remember the 7th man on the moon? Riemann will be the last bang but then AI companies will loose interest in expensive PR-stunts in math. The real problem is people loose interest in learning anything. There will be no junior mathematicians, junior programmers .. you name it – so where will future seniors that guide it or use it come from?")

#text("Lets hope for the best, Nils")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thank you, Silvia and Eamon, for sharing your thoughts on this topic! I agree with a lot of what has been said: it is true that ")#emph[#text("current")]#text(" AI models produce proofs of unclear intelligibility, and they are not yet able to produce new theory or create work of aesthetic value, among other things. But for how long do you think this will be the case? You grant that future systems will likely produce genuine, intelligible proofs, but the same reasoning applies to the other goals you list. Just a few months ago, nobody would have believed that a Millennium Prize problem would be solved autonomously by an AI model this year. I suspect that, in a few years, AI models will also be excellent at building new theory, communicating their results, and fulfilling many of the other goals that mathematicians currently value. And I don’t think this should fill people with dread: a world in which these scientific (including mathematical) g can be made quickly and easily by AI models is perhaps a world in which certain people are out of a job, but it is also a world in which the vast majority of people, who are not scientists but would benefit from the advances of science, experience huge improvements in their wellbeing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kolen Cheung")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695167")[#strong[#text("Kolen Cheung")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I really enjoy this piece.")

#text("Some software engineers out there might be a bit tone deaf and label mathematicians being in denial, extrapolating from their own experience in how agentic engineering shocked the software engineering world.")

#text("So I wrote this companion piece hoping to translate your message to them. I hope that would be helpful:")

#text("Mathematicians aren’t mourning their craft: Translating “After Math” for software engineers")

#link("https://blog.kolen.dev/math/after-math")[#text("https://blog.kolen.dev/math/after-math")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695198")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("As a computer scientist and mathematician that actually refuses to use AI tools myself, I don’t understand how even after this incident, there is an appetite for continued AI usage as a tool. AI is parasitic, and downstream usage of any sort is a tacit approval of possibly the greatest profit-motivated mass theft in history. These tools would not survive without the effectively free labor of millions, and yet not a dime is paid back in compensation. I fail to see how incentives will ever be aligned for humanity as a whole to produce creative and technical works in the future. Even streaming platforms pay their dues to the creators of content they host. Are we not falling into the “middle road” paradoxical trap? Often, a compromise is warranted yes, but sometimes, the correct response is at one of the extremeties.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Because getting tenure is the key to a career in mathematics, and the tenure system in academia depends on people publishing papers, and AI can be used to accelerate that process, allowing people to make their CVs more impressive than their fellow peers. Until tenure gets completely overhauled, mathematicians will continue to use AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695290")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I’m not arguing that AI can’t confer some short term benefits. My point is that AI is a global slow-acting poison akin to a Monkey’s Paw, so our collective movements should be to unequivocally shun and discourage AI usage, as opposed to arguing semantics or trying to figure out appropriate usage. What incentives are there to write cogent math books in a world where an AI company cqn scrape it and incorporate it into a model with impunity? What incentives are there to make educational materials or presentations? Anything created currently is doomed to be hopelessly diluted by a non-thinking machine, consumed by a user high on fast results without comprehension. We are truly in a dark time in my opinion, and I don’t think this is a place mathematicians should seek to compromise. AI usage should be shunned, and AI users with AI-results outright rejected.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/140781a1a827230642e4ef8ca18adf5688874ae5e06a134a4dcb64e7a10c390d-4141ec25c116c936d60585cf478fed83d66310f2bfcf2fdc544655721886a729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Berk İdem")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695302")[#strong[#text("Berk İdem")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I enjoyed this a lot. Aristotle also separates knowing the fact from knowing the reason why: In the stronger sense, we understand something (only) when we know its ")#emph[#text("cause")]#text(". I think this sharpens the issue with a formal certificate further. The missing thing in a Lean proof is not simply that it is difficult for humans to read, but that it doesn’t tell us which assumptions, definitions, and ideas are actually doing the important conceptual work.")

#text("I wrote up some further thoughts on this ")#link("https://finiteape.com/posts/knowledge-understanding-proofs/")[#text("here")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("​I do not agree with the analysis. Consider playing chess for fun: it is only enjoyable when you are playing against another person. If your opponent is using a computer, the game is no longer fun or fair.")

#text("​Furthermore, in academia, what criteria will be used to hire a full professor if it becomes impossible to know how much of their work was generated by AI? A candidate’s success might simply come down to having more funding to access more powerful AI models than their peers.")

#text("​While I do see a positive side to this (AI could help level the playing field and reduce unfair advantages based purely on who supervised your PhD) I believe we must take this issue much more seriously. We need a deeper, more thoughtful analysis of how to fundamentally reshape the profession.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("It’s absolutely correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("While I agree that there is much more to math than results, I do not think disregarding the importance of results is the solution to this existential problem. For me personally, what drew me to math was the promise of willing new ideas into existence, of manifesting a new reality through nothing more than self-reflection. In many ways, I saw my first textbooks as spell books, and theorems as the essential incantations.")

#text("Frankly, what rubs me the wrong way about AI in mathematics is not the rate of progress, or even the lack of understanding (new results after all will help drive an understanding). No, it is that it feels suspiciously like a “pump and dump”, where mathematics is being exploited for PR and to drive equity, and that it is unlikely to be pursued seriously after it is no longer profitable (of course, this does not even get into the enormous plagiarism concerns). That frontier models are unlikely to remain affordable for the broad community. That after mathematics takes enormous damage at the hands of AI it will in fact reap little reward.")

#text("What would sate my concerns in math is the same that would sate them for the general adoption of AI. We need assurances that these tools will be accessible and oriented toward goals of our common interest, that they will be regulated, that credit will be given fairly. There are many more practical problems that would need to be addressed, including a greater emphasis on understanding, but my resolution is that AI does not have to be scary. Unfortunately, every indication has been given that it has not been implemented with our interests in mind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("I find it worrisome how popular it has become the retreat")

#text("“not just proving theorems, but understanding”")

#text("For one, it is valid pointing it out, but that remark is nothing new. Understanding has been part of the goals of the scientific method since before digital computers.")

#text("Now, my worry is that I don’t see anything what makes “understanding” exclusively human, or even not amenable to be accomplished by the current technologies (LLMs the main one).")

#text("I think that all the mathematicians taking refuge behind the shield of “understanding”, should pause to determine or define what that is, and also to note in which ways can and cannot be accomplished by LLMs.")

#text("Anyone can adventure listing some essential characteristics of what understanding is. For example, sectioning a proof and selecting parts ranked with some notion of importance. This can be applicability (appearing in many other proofs), or novelty, or having an identifiable source (as in this part is important because we should thank X for introducing it). What is a fairly comprehensive list?")

#text("It is important to remember that not long ago “thinking logically” used to also be a refuge of those seeking safety from the capabilities of machines. “Understanding” doesn’t look like very solid bunker, if further computational cost (many more passes to the LLM with new goals) is all it is needed to accomplish it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/140781a1a827230642e4ef8ca18adf5688874ae5e06a134a4dcb64e7a10c390d-4141ec25c116c936d60585cf478fed83d66310f2bfcf2fdc544655721886a729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Berk İdem")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695345")[#strong[#text("Berk İdem")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("I mean, unless someone is a dualist, there is no reason to think that theoretically, an AI model cannot understand, to the extent we do. And I hope this doesn’t remain a theoretical possibility. However, I also don’t think scaling up the LLMs can get us there, which is both fortunate (we can do something better), and unfortunate (we don’t have it yet).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I have the following question: I have the following question: what (in your opinion) impact would an inconsistency of the system of classical logic have on AI (assuming, of course, that the system of classical logic is inconsistent)?")

#text("PS. For the impact of the inconsistency of classical logic on mathematics is surely obvious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdeba673b41e8c25bf074ac21abf212b80e70ba4bf6590f5e5a9137e6adceb3d-f785ff9df1f155565205d910b2b6698b6014dd68fb72a915506956df779ab6aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Costanzo")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695431")[#strong[#text("Jason Costanzo")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("The reality (evidenced from ChatGPT’s solution) is that AI will be solving mathematical problems / theorems both now and in the future.")

#text("I don’t necessarily see this itself as a problem in-itself. The problem is how we develop AI and the kind of “autonomy” that is given to it. If we use AI as a tool that serves and extends human knowledge, then AI can be of great benefit. If we just let AI “evolve” without following and charting and directing this evolution, then problems are likely to result.")

#text("So I think there are two paths that this can lead to:")

#enum(start: 1, 
[#text("The “Lean formalization” (a formally-logical proof) is equivalent to understanding — for AI. Intelligibility as we know it does not exist for AI (and likely never will). AI does not “think”. It processes. It regurgitates. It spits out. Purely abstract, algorithmic, formalized thinking is its domain. Hence, the danger would be to allow AI to run rampant around mathematics, solving problems / theorems, providing formal proofs that are unintelligible to us. Now there would be a lot of solved theorems and no understanding of their relevance. This echoes the fear that many have of AI becoming “too” intelligent. AI has not become too intelligent. It has merely produced results, proofs, etc., which we understand, but which lack intelligibility, lack a relation to what ")#emph[#text("we")]#text(" understand, and how we understand mathematics and other fields of knowledge. It lacks ")#emph[#text("human")]#text(" intelligibility.")],
[#text("This simultaneously opens up a field of inquiry, which is precisely the assessment of formal proofs generated by AI — relative to intelligibility. Mathematicians wills need to assess the proofs of AI, analyze them, interpret them, and connect them to the larger domain of human knowledge. AI can likely help, but never fulfill that role.")]
)

#enum(start: 1, 

)

#text("So I don’t think that all is lost. I think that, as with all new things, the intrusion of AI into mathematics is inevitable, but also not necessarily a reason to think that the discipline has come to an end.")

#text("Nevertheless, it is game-changing – and mathematicians will need to start rethinking their role.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/after-math/#comment-695609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Engaging, amazing read. Thank you 🙏🏼")
]
