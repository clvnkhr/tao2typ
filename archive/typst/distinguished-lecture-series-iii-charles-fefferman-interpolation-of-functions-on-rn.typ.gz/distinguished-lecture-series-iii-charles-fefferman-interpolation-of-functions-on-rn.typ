// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/
// Converted to Typst by tao2typ: "2026-10-14T16:35:05.204325+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Charles Fefferman, “Interpolation of functions on R^n”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Charles Fefferman, “Interpolation of functions on R^n”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/")[#text("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Today, Charlie wrapped up several loose ends in his lectures, including the connection with the classical ")#link("http://en.wikipedia.org/wiki/Whitney_extension_theorem")[#text("Whitney extension theorem")]#text(", the role of convex bodies and Whitney convexity, and a glimpse as to how one obtains the remarkably fast (almost linear time) algorithms in which one actually computes interpolation of functions from finite amounts of data.")

#metadata(none) <tao-13a98a0ddc6841d819b2>

#text("With all the notational machinery from the preceding lecture, the Whitney extension theorem can be stated rather cleanly in the language of bundles, sections, and Glaeser-stability as follows. Consider a bundle ")#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(" on a compact set ")#mi("E \\subset {\\Bbb R}^n")#text(" in which every fibre is simply a point: ")#mi("H_x = \\{ P_x\\}")#text(". The Whitney extension problem is then to see whether such bundles have sections. The theorem is then:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Whitney extension theorem")]#text(". Let ")#mi("{\\mathcal H}")#text(" be a bundle in which every fibre is a point. Then this bundle has sections if and only if it is Glaeser stable.")
]

#text("It is then clear that the main theorem of the previous lecture generalises the Whitney extension theorem (which represents the case of exactly one stratum, consisting entirely of zero-dimensional fibres). It is then unsurprising that the main tools used to prove the latter theorem (Whitney cubes, smooth partitions of unity, etc.) also come up in the proof of the former. It is also worth noting that Whitney’s proof shows that the map from the polynomials ")#mi("P_x")#text(" to the section F can be chosen to be linear. In particular, if the set E is finite, one can bound the ")#mi("C^m({\\Bbb R}^n)")#text(" norm of F by some linear combination of the magnitudes of the coefficients of the polynomials ")#mi("P_x")#text(".")

#text("In the proof of the Whitney extension theorem, it was necessary to ")#link("http://en.wikipedia.org/wiki/Partition_of_unity")[#text("smoothly partition")]#text(" space into cubes, perform some sort of extension on each cube, and then sum everything up. In order to guarantee convergence, it is necessary that the bounds on the extension are (a) uniform in some sense over all cubes, and (b) are stable under multiplication by smooth cutoff functions. It turns out that we can abstract these properties by means of a quantitative generalisation of the notion of a bundle, namely that of a collection of ")#emph[#text("Whitney convex sets")]#text(". Recall that a bundle is a collection ")#mi("{\\mathcal H} = (H_x)_{x \\in E}")#text(", where each ")#mi("H_x")#text(" is either empty, or takes the form ")#mi("H_x = P_x + \\sigma(x)")#text(" for some ")#mi("P_x \\in {\\mathcal P}_x")#text(" and some ideal ")#mi("\\sigma(x) \\subset {\\mathcal P}_x")#text(". Just to belabor the definitions, an ideal is a vector subspace ")#mi("\\sigma(x)")#text(" with the property that ")#mi("PQ \\in \\sigma(x)")#text(" whenever ")#mi("P \\in \\sigma(x)")#text(" and ")#mi("Q \\in {\\mathcal P}_x")#text(".")

#text("We can generalise the notion of an ideal as follows. If ")#mi("x\\in {\\Bbb R}^n")#text(" and $A > 0$, we say that a set ")#mi("\\sigma(x) \\subset {\\mathcal P}_x")#text(" is Whitney convex with Whitney constant A if it is a closed convex symmetric set, and if for every ")#mi("0 < \\delta \\leq 1")#text(" we have the ideal-like property")

#align(center)[#mi("PQ \\in A \\sigma(x)")#text(" whenever ")#mi("P \\in \\sigma(x)")#text(", ")#mi("Q \\in {\\mathcal P}_x")#text(", and we have the bounds ")#tao-math("\\left|\\nabla^j P(x)\\right| \\leq \\delta^{m-j}", block: false)#text(", ")#tao-math("\\left|\\nabla^j Q(x)\\right| \\leq \\delta^{-j}", block: false)#text(" for ")#mi("0 \\leq j \\leq m")#text(".")]

#text("The point if this rather technical definition is that if a jet is lying in $\\sigma(x)$ and it has controlled ")#mi("C^m")#text(" behaviour at some small length scale ")#mi("\\delta")#text(", then one can smoothly localise to that scale ")#mi("\\delta")#text(" without causing the jet to escape ")#mi("\\sigma")#text(" too much. This is the key property needed for Whitney-type arguments to work. (This is why Whitney-type extension problems are tractable, whereas general linear PDE problems are not; one can glue together local extensions to form a global extension via partitions of unity, whereas one cannot build, say, a globally harmonic function from unrelated locally harmonic pieces.)")

#text("There was also a slightly weaker notion of Whitney convexity relating to a ")#link("http://en.wikipedia.org/wiki/Modulus_of_continuity")[#text("modulus of continuity")]#text(" ")#mi("\\omega")#text(", called Whitney ")#mi("\\omega")#text("-convexity, which was the same except that the polynomial P had to now obey the bounds ")#tao-math("\\left|\\nabla^j P(x)\\right| \\leq \\omega(\\delta) \\delta^{m-j}", block: false)#text(" instead of ")#tao-math("\\left|\\nabla^j P(x)\\right| \\leq \\delta^{m-j}", block: false)#text(".")

#text("Charlie then stated the main technical theorem that underpinned all of the results he presented in this lecture series:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finiteness theorem, full version")]#text(". Given n, m, a collection ")#mi("(\\sigma(x))_{x \\in E}")#text(" of Whitney ")#mi("\\omega")#text("-convex sets on a compact set ")#mi("E \\subset {\\Bbb R}^n")#text(" with some Whitney constant A and modulus of continuity ")#mi("\\omega")#text(", and some polynomials ")#mi("P = (P_x)_{x \\in E}")#text(", define ")#tao-math("\\left\\|P\\right\\|_{(E,\\sigma,\\omega)}", block: false)#text(" to be the best constant M such that there exists ")#mi("F \\in C^{m,\\omega}({\\Bbb R}^n)")#text(" with norm at most M such that ")#mi("J_x(F) \\in P_x + M \\sigma(x)")#text(" for all ")#mi("x \\in E")#text(". Then there exists a finite subset S of E of cardinality O(1) such that ")#tao-math("\\left\\|P\\right\\|_{(E,\\sigma,\\omega)} \\sim_A \\left\\|P\\right\\|_{(S,\\sigma,\\omega)}", block: false)#text(".")
]

#text("(As in the previous talks, all implied constants can depend on n and m.) This generalises the finiteness theorem mentioned in the first talk, by replacing the ideals with Whitney-convex bodies. As mentioned in the second talk, this generalisation turns out to be necessary in the proof, in order for the induction on the number of strata to work properly. The presence of the modulus of continuity prevents any compactness failures, and so E can be infinite here without difficulty.")

#text("Charlie didn’t want to discuss the proof of the above finiteness theorem in all of its gory detail. But he did identify the classical finiteness theorem which is in fact the key to the whole argument, namely ")#link("http://en.wikipedia.org/wiki/Helly%27s_theorem")[#text("Helly’s theorem")]#text(". This theorem asserts that in order to verify the simultaneous satisfiability of an arbitrary number of compact convex constraints in ")#mi("{\\Bbb R}^n")#text(", it suffices to verify satisfiability of n+1 of them at a time. Apparently, one can view the above finiteness theorem as a massively iterated version of Helly’s theorem, together with several other ingredients (such as partitions of unity adapted to Whitney cubes).")#linebreak()#text(" Charlie then finished up by briefly discussing the computer science aspects of his work, and in particular the nearly linear-time algorithms used to compute the near-optimal extensions. He did not attempt to discuss the full details of these algorithms, but instead focused on a very simplified model case (which had been extensively studied earlier in the computer science literature, in particular by ")#link("http://www.ams.org/mathscinet-getitem?mr=1370371")[#text("Callahan-Kosaraju ")]#text("and ")#link("http://www.ams.org/mathscinet-getitem?mr=1678846")[#text("Arya-Mount-Netanyahu-Silverman-Wu")]#text("), namely that of efficiently computing the ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{Lip(E)} := \\sup_{x,y \\in E: x \\neq y} \\frac{\\left|f(x)-f(y)\\right|}{\\left|x-y\\right|}", block: true)]]

#text("of a function ")#mi("f: E \\to {\\Bbb R}")#text(" on a finite set ")#mi("E \\subset {\\Bbb R}^n")#text(" of N points. Note that a brute force computation of this Lipschitz norm would take ")#mi("O(N^2)")#text(" computations. Can one do better?")

#text("In one dimension, one can get by in just ")#mi("O(N \\log N)")#text(" computations, by first using a sorting algorithm (such as ")#link("http://en.wikipedia.org/wiki/Quicksort")[#text("quicksort")]#text(") to arrange E in order, and then only compute the Lipschitz quotient for ")#emph[#text("adjacent")]#text(" x, y, which clearly suffices. But what to do in higher dimensions?")

#text("If one is willing to give up a multiplicative error of ")#mi("1 \\pm O(\\varepsilon)")#text(", then it turns out that there is a technique, called the ")#emph[#text("well-separated pairs decomposition")]#text(", which can compute the Lipschitz norm up to this error in merely ")#mi("O_\\varepsilon( N \\log N )")#text(" computations.")

#text("It works like this. By a ")#link("http://en.wikipedia.org/wiki/Divide_and_conquer_algorithm")[#text("divide-and-conquer algorithm")]#text(", one can partition the off-diagonal set ")#mi("\\{ (x,y) \\in E \\times E: x \\neq y \\}")#text(" into product sets ")#mi("E_j \\times E^{\\prime}_j")#text(" for ")#mi("j=1,\\ldots,J")#text(", where we have the separation condition ")#mi("\\text{diam}(E_j), \\text{diam}(E^{\\prime}_j) \\leq \\varepsilon \\text{dist}(E_j,E^{\\prime}_j)")#text(" and the cardinality condition ")#mi("J = O_\\varepsilon(N)")#text(".")

#text("Even with this decomposition in hand, it is not entirely obvious how to quickly compute the Lipschitz norm approximately. But there is a neat trick to pull this off. For each product set ")#mi("E_j \\times E^{\\prime}_j")#text(", pick just one representative ")#mi("x_j \\in E_j")#text(" and one representative ")#mi("y_j \\in E^{\\prime}_j")#text(". Then the quantity")

#align(center)[#tao-fit-display[#tao-math("K := \\sup_{1 \\leq j \\leq J} \\frac{\\left|f(x_j)-f(y_j)\\right|}{\\left|x_j-y_j\\right|},", block: true)]]

#text("which can be computed in ")#mi("O_\\varepsilon(N)")#text(" time, is certainly a lower bound for ")#tao-math("\\left\\|f\\right\\|_{Lip}", block: false)#text(". It turns out that it is a pretty good upper bound too; in fact, ")#tao-math("\\left\\|f\\right\\|_{Lip}", block: false)#text(" cannot exceed ")#mi("(1 + 100 \\varepsilon)K")#text(" (say). This can be demonstrated by a clever ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("infinite descent")]#text(" argument. More precisely, suppose for contradiction that the Lipschitz norm was larger than this, then there exist distinct x, y such that")

#align(center)[#tao-math("\\left|f(x)-f(y)\\right| > (1 + 100 \\varepsilon) K \\left|x-y\\right|", block: false)#text(".")]

#text("On the other hand, we know that there must be some product ")#mi("E_j \\times E^{\\prime}_j")#text(" such that ")#mi("x \\in E_j")#text(" and ")#mi("y \\in E^{\\prime}_j")#text(". Then by definition of K we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x_j)-f(y_j)\\right| \\leq K \\left|x_j-y_j\\right|", block: true)]]

#text("and also")

#align(center)[#tao-math("\\left|x-x_j\\right|, \\left|y-y_j\\right| \\leq \\varepsilon \\left|x-y\\right|", block: false)#text(".")]

#text("Putting all this together using the triangle inequality, we soon see that either")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)-f(x_j)\\right| > (1 + 100 \\varepsilon) K \\left|x-x_j\\right|", block: true)]]

#text("or")

#align(center)[#tao-math("\\left|f(y)-f(y_j)\\right| > (1 + 100 \\varepsilon) K \\left|y-y_j\\right|", block: false)#text(",")]

#text("thus leading to a pair ")#mi("(x,x_j)")#text(" or ")#mi("(y,y_j)")#text(" which also exhibits large Lipschitz norm but which has a smaller separation than ")#mi("(x,y)")#text(". But if we keep iterating this we obtain an infinite descent, which is absurd. This explains how one obtains the nearly linear time computation of the Lipschitz norm; and apparently a similar method also computes higher extension norms.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/766db427af01d1159708ad617772dc6337f400236ca96b136649b73c6653f914-07e6b7c5f3d4f89892e70408fa48b0fbc1e4fac45f895df7ceeeb84e74647a19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael VanValkenburgh")]], [#link("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/#comment-15460")[#strong[#text("Michael VanValkenburgh")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2007")])]

#text("Thank you for this blog–I am grateful for the summaries of")#linebreak()#text(" Professor Fefferman’s lectures, and I am glad that we have this")#linebreak()#text(" forum for further discussing them. I would like to take this")#linebreak()#text(" opportunity to reframe the question I asked at the end of the")#linebreak()#text(" third lecture.")

#text("Let me begin by recapping some of the other questions and answers")#linebreak()#text(" (forgive me if, in being brief, I misrepresent them–in that case,")#linebreak()#text(" please add comments):")

#text("Q1: Is the “Whitney convexity condition” a natural condition?")

#text("A1: Yes. That sort of thing comes up whenever you have a partition")#linebreak()#text(" of unity such that the derivatives of the cutoffs have scales")#linebreak()#text(" corresponding to the scales of the sets they are supported on.")#linebreak()#text(" This of course comes up in the classical picture for Whitney’s")#linebreak()#text(" extension theorem, e.g., on page 17 of Stein’s *Singular Integrals")#linebreak()#text(" and Differentiability Properties of Functions*.")

#text("Q2: Do the results have consequences for the study of partial")#linebreak()#text(" differential equations?")

#text("A2: Yes–and recall that *without* the Whitney convexity")#linebreak()#text(" condition, the main theorem (a generalized sharp Whitney Theorem")#linebreak()#text(" for Whitney $\\omega$-convex sets) is false; it would, in")#linebreak()#text(" particular, imply that any linear partial differential equation")#linebreak()#text(" with any linear boundary conditions is solvable. (See the blog")#linebreak()#text(" entry for Professor Fefferman’s second lecture.)")

#text("These two questions caused me to think of the theorem of Beals and")#linebreak()#text(" Fefferman on the local solvability of linear partial differential")#linebreak()#text(" equations of principal type, with smooth coefficients, satisfying")#linebreak()#text(" the Nirenberg-Treves condition. The seminal method Beals and")#linebreak()#text(" Fefferman devised, which they subsequently generalized, as did")#linebreak()#text(" H\\”{o}rmander (with the introduction of the Weyl calculus of")#linebreak()#text(" pseudodifferential operators), was to introduce “spatially")#linebreak()#text(" inhomogeneous” pseudodifferential operators–pseudodifferential")#linebreak()#text(" operators where the properties of the corresponding symbols vary")#linebreak()#text(" point-to-point in a way that is specialized for the operator at")#linebreak()#text(" hand.")

#text("This is presented in H\\”{o}rmander’s massive book in the following")#linebreak()#text(" way: In chapter one, he constructs “partitions of unity")#linebreak()#text(" corresponding to a covering by convex symmetric neighborhoods")#linebreak()#text(" which may vary in both size and shape” (p.28); as he notes")#linebreak()#text(" (p.32), this is essentially due to Whitney. Then, in chapter two,")#linebreak()#text(" he uses a partition of unity of this type to prove Whitney’s")#linebreak()#text(" extension theorem (p.48); of course, this is also due to Whitney.")

#text("However, H\\”{o}rmander’s main reason for studying the “spatially")#linebreak()#text(" inhomogeneous” partitions of unity is for use in sections 18.4")#linebreak()#text(" and 18.5, where he uses them to construct the Weyl")#linebreak()#text(" calculus–which, again, was inspired by Beals and Fefferman. The")#linebreak()#text(" Weyl calculus provides the framework for the recent work on")#linebreak()#text(" solvability, most notably, Dencker’s recent paper on the")#linebreak()#text(" resolution of the Nirenberg-Treves conjecture, which generalizes")#linebreak()#text(" the result of Beals and Fefferman to classical pseudodifferential")#linebreak()#text(" operators of principal type.")

#text("I meant for my question to be of a historical nature–for")#linebreak()#text(" instance, to ask if the Beals-Fefferman paper was in some way")#linebreak()#text(" inspired by the work of Whitney, or if there is some deep")#linebreak()#text(" connection between the two areas. But it appears that the answer")#linebreak()#text(" to my question is the same as the answer to question 1 above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/#comment-15530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2007")])]

#text("Dear Michael,")

#text("Thanks for posting the discussion after Charlie’s last talk. As I recall, though, the answer to Q2 was “No” rather than “Yes”, because the Whitney convexity condition is almost never satisfied for a general linear PDE problem. For instance, trying to solve Poisson’s equation ")#mi("\\Delta u = f")#text(" does not fall under this framework, basically because the space of harmonic polynomials is not an ideal (nor is it Whitney convex). But the space of polynomials which vanish to (say) third order at a point is an ideal (and hence Whitney convex), which is why the above theory can say something about how to solve for a function which is specified up to third order at various points.")

#text("It may be that the Whitney convexity condition is overkill; it requires, at every point, the constraint body ")#mi("\\sigma(x)")#text(" to be well-behaved with respect to ")#emph[#text("every")]#text(" scale ")#mi("\\delta > 0")#text(". But from what I gather from the proof, one only needs to know this fact for very specific scales ")#mi("\\sigma")#text(", namely the distance from x to various strata of E. So it could well be possible to proceed instead with a Hormander-type approach, in which one defines scale functions ")#mi("\\delta(x)")#text(" adapted to these strata, and requires that the constraint bodies ")#mi("\\sigma(x)")#text(" obey estimates only at those scales (somewhat analogous to the Weyl calculus adapted to a given partition of unity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/#comment-29442")[#strong[#text("The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2008")])]

#text("[…] 30 November, 2007 in expository, math.CO, math.FA, math.MG by Terence Tao Tags: Hahn-Banach theorem, Helly’s theorem, linear programming, Menger’s theorem, minimax theorem, separation theorem In the previous post, I discussed how an induction on dimension approach could establish Hilbert’s nullstellensatz, which we interpreted as a result describing all the obstructions to solving a system of polynomial equations and inequations over an algebraically closed field. Today, I want to point out that exactly the same approach also gives the Hahn-Banach theorem (at least in finite dimensions), which we interpret as a result describing all the obstructions to solving a system of linear inequalities over the reals (or in other words, a linear programming problem); this formulation of the Hahn-Banach theorem is sometimes known as Farkas’ lemma. Then I would like to discuss some standard applications of the Hahn-Banach theorem, such as the separation theorem of Dieudonné, the minimax theorem of von Neumann, Menger’s theorem, and Helly’s theorem (which was mentioned recently in an earlier post). […]")
]
