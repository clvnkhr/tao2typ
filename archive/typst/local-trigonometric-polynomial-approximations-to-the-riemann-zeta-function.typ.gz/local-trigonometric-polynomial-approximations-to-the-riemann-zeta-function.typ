// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/
// Converted to Typst by tao2typ: "2026-10-14T15:20:16.326526+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Local trigonometric polynomial approximations to the Riemann zeta function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Local trigonometric polynomial approximations to the Riemann zeta function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/")[#text("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A useful rule of thumb in complex analysis is that holomorphic functions ")#mi("{f(z)}")#text(" behave like large degree polynomials ")#mi("{P(z)}")#text(". This can be evidenced for instance at a “local” level by the Taylor series expansion for a complex analytic function in the disk, or at a “global” level by factorisation theorems such as the ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation theorem")]#text(" (or the closely related Hadamard factorisation theorem). One can truncate these theorems in a variety of ways (e.g., Taylor’s theorem with remainder) to be able to approximate a holomorphic function by a polynomial on various domains.")

#text("In some cases it can be convenient instead to work with polynomials ")#mi("{P(Z)}")#text(" of another variable ")#mi("{Z}")#text(" such as ")#mi("{Z = e^{2\\pi i z}}")#text(" (or more generally ")#mi("{Z=e^{2\\pi i z/N}}")#text(" for a scaling parameter ")#mi("{N}")#text("). In the case of the Riemann zeta function, defined by meromorphic continuation of the formula ")#metadata(none) <tao-164200a298bafec89fd3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s}")]]

#text("one ends up having the following heuristic approximation in the neighbourhood of a point ")#mi("{\\frac{1}{2}+it}")#text(" on the critical line:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Heuristic 1 (Polynomial approximation)")]#text(" Let ")#mi("{T \\ggg 1}")#text(" be a height, let ")#mi("{t}")#text(" be a “typical” element of ")#mi("{[T,2T]}")#text(", and let ")#mi("{1 \\lll N \\ll \\log T}")#text(" be an integer. Let ")#mi("{\\phi_t = \\phi_{t,T}: {\\bf C} \\rightarrow {\\bf C}}")#text(" be the linear change of variables")

#align(center)[#tao-fit-display[#mitex("\\phi_t(z) := \\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}.")]]

#text("Then one has an approximation ")#metadata(none) <tao-be99d7122a591433cba0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\zeta( \\phi_t(z) ) \\approx P_t( e^{2\\pi i z/N} )")]]

#text("for ")#mi("{z = o(N)}")#text(" and some polynomial ")#mi("{P_t = P_{t,T}}")#text(" of degree ")#mi("{N}")#text(".")
]

#text("The requirement ")#mi("{z=o(N)}")#text(" is necessary since the right-hand side is periodic with period ")#mi("{N}")#text(" in the ")#mi("{z}")#text(" variable (or period ")#mi("{\\frac{2\\pi i N}{\\log T}}")#text(" in the ")#mi("{s = \\phi_t(z)}")#text(" variable), whereas the zeta function is not expected to have any such periodicity, even approximately.")

#text("Let us give two non-rigorous justifications of this heuristic. Firstly, it is standard that inside the critical strip (with ")#mi("{\\mathrm{Im}(s) = O(T)}")#text(") we have an approximate form")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\sum_{n \\leq T} \\frac{1}{n^s}")]]

#text("of ")#link(<tao-164200a298bafec89fd3>)[#text("(11)")]#text(". If we group the integers ")#mi("{n}")#text(" from ")#mi("{1}")#text(" to ")#mi("{T}")#text(" into ")#mi("{N}")#text(" bins depending on what powers of ")#mi("{T^{1/N}}")#text(" they lie between, we thus have")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\sum_{j=0}^N \\sum_{T^{j/N} \\leq n < T^{(j+1)/N}} \\frac{1}{n^s}")]]

#text("For ")#mi("{s = \\phi_t(z)}")#text(" with ")#mi("{z = o(N)}")#text(" and ")#mi("{T^{j/N} \\leq n < T^{(j+1)/N}}")#text(" we heuristically have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n^s} \\approx \\frac{1}{n^{\\frac{1}{2}+it}} e^{2\\pi i j z / N}")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\sum_{j=0}^N a_j(t) (e^{2\\pi i z/N})^j")]]

#text("where ")#mi("{a_j(t)}")#text(" are the partial Dirichlet series ")#metadata(none) <tao-c84d520e29e420ce3d33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("a_j(t) \\approx \\sum_{T^{j/N} \\leq n < T^{(j+1)/N}} \\frac{1}{n^{\\frac{1}{2}+it}}.")]]

#text("This gives the desired polynomial approximation.")

#text("A second non-rigorous justification is as follows. From factorisation theorems such as the Hadamard factorisation theorem we expect to have")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\propto \\prod_\\rho (s-\\rho) \\times \\dots")]]

#text("where ")#mi("{\\rho}")#text(" runs over the non-trivial zeroes of ")#mi("{\\zeta}")#text(", and there are some additional factors arising from the trivial zeroes and poles of ")#mi("{\\zeta}")#text(" which we will ignore here; we will also completely ignore the issue of how to renormalise the product to make it converge properly. In the region ")#mi("{s = \\frac{1}{2} + it + o( N / \\log T) = \\phi_t( \\{ z: z = o(N) \\})}")#text(", the dominant contribution to this product (besides multiplicative constants) should arise from zeroes ")#mi("{\\rho}")#text(" that are also in this region. The ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann-von Mangoldt formula")]#text(" suggests that for “typical” ")#mi("{t}")#text(" one should have about ")#mi("{N}")#text(" such zeroes. If one lets ")#mi("{\\rho_1,\\dots,\\rho_N}")#text(" be any enumeration of ")#mi("{N}")#text(" zeroes closest to ")#mi("{\\frac{1}{2}+it}")#text(", and then repeats this set of zeroes periodically by period ")#mi("{\\frac{2\\pi i N}{\\log T}}")#text(", one then expects to have an approximation of the form")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\propto \\prod_{j=1}^N \\prod_{k \\in {\\bf Z}} (s-(\\rho_j+\\frac{2\\pi i kN}{\\log T}) )")]]

#text("again ignoring all issues of convergence. If one writes ")#mi("{s = \\phi_t(z)}")#text(" and ")#mi("{\\rho_j = \\phi_t(\\lambda_j)}")#text(", then Euler’s famous ")#link("https://en.wikipedia.org/wiki/List_of_trigonometric_identities#Infinite_product_formulae")[#text("product formula for sine")]#text(" basically gives")

#tao-aligned(keep: true)[


#tao-math("\\prod_{k \\in {\\bf Z}} (s-(\\rho_j+\\frac{2\\pi i kN}{\\log T}) )  & \\propto \\prod_{k \\in {\\bf Z}} (z - (\\lambda_j+2\\pi k N) )", block: true)



#tao-math(" & \\propto (e^{2\\pi i z/N} - e^{2\\pi i \\lambda j/N})", block: true)
]

#text("(here we are glossing over some technical issues regarding renormalisation of the infinite products, which can be dealt with by studying the asymptotics as ")#mi("{\\mathrm{Im}(z) \\rightarrow \\infty}")#text(") and hence we expect")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\propto \\prod_{j=1}^N (e^{2\\pi i z/N} - e^{2\\pi i \\lambda j/N}).")]]

#text("This again gives the desired polynomial approximation.")

#text("Below the fold we give a rigorous version of the second argument suitable for “microscale” analysis. More precisely, we will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{N = N(T)}")#text(" be an integer going sufficiently slowly to infinity. Let ")#mi("{W_0 \\ll N}")#text(" go to zero sufficiently slowly depending on ")#mi("{N}")#text(". Let ")#mi("{t}")#text(" be drawn uniformly at random from ")#mi("{[T,2T]}")#text(". Then with probability ")#mi("{1-o(1)}")#text(" (in the limit ")#mi("{T \\rightarrow \\infty}")#text("), and possibly after adjusting ")#mi("{N}")#text(" by ")#mi("{1}")#text(", there exists a polynomial ")#mi("{P_t(Z)}")#text(" of degree ")#mi("{N}")#text(" and obeying the functional equation ")#link(<tao-75a1b65144b46b8739e3>)[#text("(9)")]#text(" below, such that ")#metadata(none) <tao-6c126e81fa8dc29d6413>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\zeta( \\phi_t(z) ) = (1+o(1)) P_t( e^{2\\pi i z/N} )")]]

#text("whenever ")#tao-math("{\\left|z\\right| \\leq W_0}", block: false)#text(".")
]

#text("It should be possible to refine the arguments to extend this theorem to the mesoscale setting by letting ")#mi("{N}")#text(" be anything growing like ")#mi("{o(\\log T)}")#text(", and ")#mi("{W_0}")#text(" anything growing like ")#mi("{o(N)}")#text("; also we should be able to delete the need to adjust ")#mi("{N}")#text(" by ")#mi("{1}")#text(". We have not attempted these optimisations here.")

#text("Many conjectures and arguments involving the Riemann zeta function can be heuristically translated into arguments involving the polynomials ")#mi("{P_t(Z)}")#text(", which one can view as random degree ")#mi("{N}")#text(" polynomials if ")#mi("{t}")#text(" is interpreted as a random variable drawn uniformly at random from ")#mi("{[T,2T]}")#text(". These can be viewed as providing a “toy model” for the theory of the Riemann zeta function, in which the complex analysis is simplified to the study of the zeroes and coefficients of this random polynomial (for instance, the role of the gamma function is now played by a monomial in ")#mi("{Z}")#text("). This model also makes the zeta function theory more closely resemble the function field analogues of this theory (in which the analogue of the zeta function is also a polynomial (or a rational function) in some variable ")#mi("{Z}")#text(", as per the Weil conjectures). The parameter ")#mi("{N}")#text(" is at our disposal to choose, and reflects the scale ")#mi("{\\approx N/\\log T}")#text(" at which one wishes to study the zeta function. For “macroscopic” questions, at which one wishes to understand the zeta function at unit scales, it is natural to take ")#mi("{N \\approx \\log T}")#text(" (or very slightly larger), while for “microscopic” questions one would take ")#mi("{N}")#text(" close to ")#mi("{1}")#text(" and only growing very slowly with ")#mi("{T}")#text(". For the intermediate “mesoscopic” scales one would take ")#mi("{N}")#text(" somewhere between ")#mi("{1}")#text(" and ")#mi("{\\log T}")#text(". Unfortunately, the statistical properties of ")#mi("{P_t}")#text(" are only understood well at a conjectural level at present; even if one assumes the Riemann hypothesis, our understanding of ")#mi("{P_t}")#text(" is largely restricted to the computation of low moments (e.g., the second or fourth moments) of various linear statistics of ")#mi("{P_t}")#text(" and related functions (e.g., ")#mi("{1/P_t}")#text(", ")#mi("{P^{\\prime}_t/P_t}")#text(", or ")#mi("{\\log P_t}")#text(").")

#text("Let’s now heuristically explore the polynomial analogues of this theory in a bit more detail. The Riemann hypothesis basically corresponds to the assertion that all the ")#mi("{N}")#text(" zeroes of the polynomial ")#mi("{P_t(Z)}")#text(" lie on the unit circle ")#tao-math("{\\left|Z\\right|=1}", block: false)#text(" (which, after the change of variables ")#mi("{Z = e^{2\\pi i z/N}}")#text(", corresponds to ")#mi("{z}")#text(" being real); in a similar vein, the GUE hypothesis corresponds to ")#mi("{P_t(Z)}")#text(" having the asymptotic law of a random scalar ")#mi("{a_N(t)}")#text(" times the characteristic polynomial of a random unitary ")#mi("{N \\times N}")#text(" matrix. Next, we consider what happens to the functional equation ")#metadata(none) <tao-f0ac255c776f4378eece>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\zeta(s) = \\chi(s) \\zeta(1-s)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\chi(s) := 2^s \\pi^{s-1} \\sin(\\frac{\\pi s}{2}) \\Gamma(1-s).")]]

#text("A routine calculation involving Stirling’s formula reveals that ")#metadata(none) <tao-560c48d6c73e72bde5e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\chi(\\frac{1}{2}+it) = (1+o(1)) e^{-2\\pi i L(t)}")]]

#text("with ")#mi("{L(t) := \\frac{t}{2\\pi} \\log \\frac{t}{2\\pi} - \\frac{t}{2\\pi} + \\frac{7}{8}}")#text("; one also has the closely related approximation ")#metadata(none) <tao-dffe602cd1e0bfa9b4d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{\\chi^{\\prime}}{\\chi}(s) = -\\log T + O(1)")]]

#text("and hence ")#metadata(none) <tao-7f5a9ba14cb89dc20e90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\chi(\\phi_t(z)) = (1+o(1)) e^{-2\\pi i \\theta(t)} e^{2\\pi i z}")]]

#text("when ")#mi("{z = o(\\log T)}")#text(". Since ")#mi("{\\zeta(1-s) = \\overline{\\zeta(\\overline{1-s})}}")#text(", applying ")#link(<tao-f0ac255c776f4378eece>)[#text("(5)")]#text(" with ")#mi("{s = \\phi_t(z)}")#text(" and using the approximation ")#link(<tao-be99d7122a591433cba0>)[#text("(2)")]#text(" suggests a functional equation for ")#mi("{P_t}")#text(":")

#align(center)[#tao-fit-display[#mitex("P_t(e^{2\\pi i z/N}) = e^{-2\\pi i L(t)} e^{2\\pi i z} \\overline{P_t(e^{2\\pi i \\overline{z}/N})}")]]

#text("or in terms of ")#mi("{Z := e^{2\\pi i z/N}}")#text(", ")#metadata(none) <tao-75a1b65144b46b8739e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("P_t(Z) = e^{-2\\pi i L(t)} Z^N \\overline{P_t}(1/Z)")]]

#text("where ")#mi("{\\overline{P_t}(Z) := \\overline{P_t(\\overline{Z})}}")#text(" is the polynomial ")#mi("{P_t}")#text(" with all the coefficients replaced by their complex conjugate. Thus if we write")

#align(center)[#tao-fit-display[#mitex("P_t(Z) = \\sum_{j=0}^N a_j Z^j")]]

#text("then the functional equation can be written as")

#align(center)[#tao-fit-display[#mitex("a_j(t) = e^{-2\\pi i L(t)} \\overline{a_{N-j}(t)}.")]]

#text("We remark that if we use the heuristic ")#link(<tao-c84d520e29e420ce3d33>)[#text("(3)")]#text(" (interpreting the cutoffs in the ")#mi("{n}")#text(" summation in a suitably vague fashion) then this equation can be viewed as an instance of the Poisson summation formula.")

#text("Another consequence of the functional equation is that the zeroes of ")#mi("{P_t}")#text(" are symmetric with respect to inversion ")#mi("{Z \\mapsto 1/\\overline{Z}}")#text(" across the unit circle. This is of course consistent with the Riemann hypothesis, but does not obviously imply it. The phase ")#mi("{L(t)}")#text(" is of little consequence in this functional equation; one could easily conceal it by working with the phase rotation ")#mi("{e^{\\pi i L(t)} P_t}")#text(" of ")#mi("{P_t}")#text(" instead.")

#text("One consequence of the functional equation is that ")#mi("{e^{\\pi i L(t)} e^{-i N \\theta/2} P_t(e^{i\\theta})}")#text(" is real for any ")#mi("{\\theta \\in {\\bf R}}")#text("; the same is then true for the derivative ")#mi("{e^{\\pi i L(t)} e^{i N \\theta} (i e^{i\\theta} P^{\\prime}_t(e^{i\\theta}) - i \\frac{N}{2} P_t(e^{i\\theta})}")#text(". Among other things, this implies that ")#mi("{P^{\\prime}_t(e^{i\\theta})}")#text(" cannot vanish unless ")#mi("{P_t(e^{i\\theta})}")#text(" does also; thus the zeroes of ")#mi("{P^{\\prime}_t}")#text(" will not lie on the unit circle except where ")#mi("{P_t}")#text(" has repeated zeroes. The analogous statement is true for ")#mi("{\\zeta}")#text("; the zeroes of ")#mi("{\\zeta^{\\prime}}")#text(" will not lie on the critical line except where ")#mi("{\\zeta}")#text(" has repeated zeroes.")

#text("Relating to this fact, it is a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1512953")[#text("classical result of Speiser")]#text(" that the Riemann hypothesis is true if and only if all the zeroes of the derivative ")#mi("{\\zeta^{\\prime}}")#text(" of the zeta function in the critical strip lie on or to the ")#emph[#text("right")]#text(" of the critical line. The analogous result for polynomials is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\} = N - 2 \\# \\{ \\left|Z\\right| > 1: P^{\\prime}_t(Z) = 0 \\}", block: true)]]

#text("(where all zeroes are counted with multiplicity.) In particular, the zeroes of ")#mi("{P_t(Z)}")#text(" all lie on the unit circle if and only if the zeroes of ")#mi("{P^{\\prime}_t(Z)}")#text(" lie in the closed unit disk.")
]

#emph[#text("Proof:")]#text(" From the functional equation we have")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\} = N - 2 \\# \\{ \\left|Z\\right| > 1: P_t(Z) = 0 \\}.", block: true)]]

#text("Thus it will suffice to show that ")#mi("{P_t}")#text(" and ")#mi("{P^{\\prime}_t}")#text(" have the same number of zeroes outside the closed unit disk.")

#text("Set ")#mi("{f(z) := z \\frac{P^{\\prime}(z)}{P(z)}}")#text(", then ")#mi("{f}")#text(" is a rational function that does not have a zero or pole at infinity. For ")#mi("{e^{i\\theta}}")#text(" not a zero of ")#mi("{P_t}")#text(", we have already seen that ")#mi("{e^{\\pi i L(t)} e^{-i N \\theta/2} P_t(e^{i\\theta})}")#text(" and ")#mi("{e^{\\pi i L(t)} e^{i N \\theta} (i e^{i\\theta} P^{\\prime}_t(e^{i\\theta}) - i \\frac{N}{2} P_t(e^{i\\theta})}")#text(" are real, so on dividing we see that ")#mi("{i f(e^{i\\theta}) - \\frac{iN}{2}}")#text(" is always real, that is to say")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} f(e^{i\\theta}) = \\frac{N}{2}.")]]

#text("(This can also be seen by writing ")#mi("{f(e^{i\\theta}) = \\sum_\\lambda \\frac{1}{1-e^{-i\\theta} \\lambda}}")#text(", where ")#mi("{\\lambda}")#text(" runs over the zeroes of ")#mi("{P_t}")#text(", and using the fact that these zeroes are symmetric with respect to reflection across the unit circle.) When ")#mi("{e^{i\\theta}}")#text(" is a zero of ")#mi("{P_t}")#text(", ")#mi("{f(z)}")#text(" has a simple pole at ")#mi("{e^{i\\theta}}")#text(" with residue a positive multiple of ")#mi("{e^{i\\theta}}")#text(", and so ")#mi("{f(z)}")#text(" stays on the right half-plane if one traverses a semicircular arc around ")#mi("{e^{i\\theta}}")#text(" outside the unit disk. From this and continuity we see that ")#mi("{f}")#text(" stays on the right-half plane in a circle slightly larger than the unit circle, and hence by the argument principle it has the same number of zeroes and poles outside of this circle, giving the claim. ")#mi("\\Box")

#text("From the functional equation and the chain rule, ")#mi("{Z}")#text(" is a zero of ")#mi("{P^{\\prime}_t}")#text(" if and only if ")#mi("{1/\\overline{Z}}")#text(" is a zero of ")#mi("{N P_t - P^{\\prime}_t}")#text(". We can thus write the above proposition in the equivalent form")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\} = N - 2 \\# \\{ \\left|Z\\right| < 1: NP_t(Z) - P^{\\prime}_t(Z) = 0 \\}.", block: true)]]

#text("One can use this identity to get a lower bound on the number of zeroes of ")#mi("{P_t}")#text(" by the method of mollifiers. Namely, for any other polynomial ")#mi("{M_t}")#text(", we clearly have")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\geq N - 2 \\# \\{ \\left|Z\\right| < 1: M_t(Z)(NP_t(Z) - P^{\\prime}_t(Z)) = 0 \\}.", block: true)]]

#text("By ")#link("https://en.wikipedia.org/wiki/Jensen%27s_formula")[#text("Jensen’s formula")]#text(", we have for any ")#mi("{r>1}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|M_t(0)\\right| \\left|NP_t(0)-P^{\\prime}_t(0)\\right|", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq -(\\log r) \\# \\{ \\left|Z\\right| < 1: M_t(Z)(NP_t(Z) - P^{\\prime}_t(Z)) = 0 \\}", block: true)



#tao-math(" & + \\frac{1}{2\\pi} \\int_0^{2\\pi} \\log \\left|M_t(re^{i\\theta})(NP_t(e^{i\\theta}) - P^{\\prime}_t(re^{i\\theta}))\\right|\\ d\\theta.", block: true)
]

#text("We therefore have")

#tao-aligned(keep: true)[


#tao-math("\\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\}  & \\geq N + \\frac{2}{\\log r} \\log \\left|M_t(0)\\right| \\left|NP_t(0)-P^{\\prime}_t(0)\\right|", block: true)



#tao-math(" & - \\frac{1}{\\log r} \\frac{1}{2\\pi} \\int_0^{2\\pi} \\log \\left|M_t(re^{i\\theta})(NP_t(e^{i\\theta}) - P^{\\prime}_t(re^{i\\theta}))\\right|^2\\ d\\theta.", block: true)
]

#text("As the logarithm function is concave, we can apply ")#link("https://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" to conclude")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\# \\{ \\left|Z\\right| = 1: P_t(Z) = 0 \\}  & \\geq N", block: true)



#tao-math(" & + {\\bf E} \\frac{2}{\\log r} \\log \\left|M_t(0)\\right| \\left|NP_t(0)-P^{\\prime}_t(0)\\right|", block: true)



#tao-math(" & - \\frac{1}{\\log r} \\log \\left( \\frac{1}{2\\pi} \\int_0^{2\\pi} {\\bf E} \\left|M_t(re^{i\\theta})(NP_t(e^{i\\theta}) - P^{\\prime}_t(re^{i\\theta}))\\right|^2\\ d\\theta\\right).", block: true)
]

#text("where the expectation is over the ")#mi("{t}")#text(" parameter. It turns out that by choosing the mollifier ")#mi("{M_t}")#text(" carefully in order to make ")#mi("{M_t P_t}")#text(" behave like the function ")#mi("{1}")#text(" (while keeping the degree ")#mi("{M_t}")#text(" small enough that one can compute the second moment here), and then optimising in ")#mi("{r}")#text(", one can use this inequality to get a positive fraction of zeroes of ")#mi("{P_t}")#text(" on the unit circle on average. This is the polynomial analogue of a classical ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=564081")[#text("argument of Levinson")]#text(", who used this to show that at least one third of the zeroes of the Riemann zeta function are on the critical line; all later improvements on this fraction have been based on some version of Levinson’s method, mainly focusing on more advanced choices for the mollifier ")#mi("{M_t}")#text(" and of the differential operator ")#mi("{N - \\partial_z}")#text(" that implicitly appears in the above approach. (The most recent lower bound I know of is ")#mi("{0.4191637}")#text(", due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3760368")[#text("to Pratt and Robles")]#text(". In principle (as observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1239132")[#text("by Farmer")]#text(") this bound can get arbitrarily close to ")#mi("{1}")#text(" if one is allowed to use arbitrarily long mollifiers, but establishing this seems of comparable difficulty to unsolved problems such as the pair correlation conjecture; see ")#link("https://arxiv.org/abs/1207.6583")[#text("this paper of Radziwill")]#text(" for more discussion.) A variant of these techniques can also establish “zero density estimates” of the following form: for any ")#mi("{W \\geq 1}")#text(", the number of zeroes of ")#mi("{P_t}")#text(" that lie further than ")#mi("{\\frac{W}{N}}")#text(" from the unit circle is of order ")#mi("{O( e^{-cW} N )}")#text(" on average for some absolute constant ")#mi("{c>0}")#text(". Thus, roughly speaking, most zeroes of ")#mi("{P_t}")#text(" lie within ")#mi("{O(1/N)}")#text(" of the unit circle. (Analogues of these results for the Riemann zeta function were worked out ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=20594")[#text("by Selberg")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=820237")[#text("by Jutila")]#text(", and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=959210")[#text("by Conrey")]#text(", with increasingly strong values of ")#mi("{c}")#text(".)")

#text("The zeroes of ")#mi("{P^{\\prime}_t}")#text(" tend to live somewhat closer to the origin than the zeroes of ")#mi("{P_t}")#text(". Suppose for instance that we write")

#align(center)[#tao-fit-display[#mitex("P_t(Z) = \\sum_{j=0}^N a_j(t) Z^j = a_N(t) \\prod_{j=1}^N (Z - \\lambda_j)")]]

#text("where ")#mi("{\\lambda_1,\\dots,\\lambda_N}")#text(" are the zeroes of ")#mi("{P_t(Z)}")#text(", then by evaluating at zero we see that")

#align(center)[#tao-fit-display[#mitex("\\lambda_1 \\dots \\lambda_N = (-1)^N a_0(t) / a_N(t)")]]

#text("and the right-hand side is of unit magnitude by the functional equation. However, if we differentiate")

#align(center)[#tao-fit-display[#mitex("P^{\\prime}_t(Z) = \\sum_{j=1}^N a_j(t) j Z^{j-1} = N a_N(t) \\prod_{j=1}^{N-1} (Z - \\lambda^{\\prime}_j)")]]

#text("where ")#mi("{\\lambda^{\\prime}_1,\\dots,\\lambda^{\\prime}_{N-1}}")#text(" are the zeroes of ")#mi("{P^{\\prime}_t}")#text(", then by evaluating at zero we now see that")

#align(center)[#tao-fit-display[#mitex("\\lambda^{\\prime}_1 \\dots \\lambda^{\\prime}_{N-1} = (-1)^N a_1(t) / N a_N(t).")]]

#text("The right-hand side would now be typically expected to be of size ")#mi("{O(1/N) \\approx \\exp(- \\log N)}")#text(", and so on average we expect the ")#mi("{\\lambda^{\\prime}_j}")#text(" to have magnitude like ")#mi("{\\exp( - \\frac{\\log N}{N} )}")#text(", that is to say pushed inwards from the unit circle by a distance roughly ")#mi("{\\frac{\\log N}{N}}")#text(". The analogous result for the Riemann zeta function is that the zeroes of ")#mi("{\\zeta^{\\prime}(s)}")#text(" at height ")#mi("{\\sim T}")#text(" lie at a distance roughly ")#mi("{\\frac{\\log\\log T}{\\log T}}")#text(" to the right of the critical line on the average; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=417074")[#text("this paper of Levinson and Montgomery")]#text(" for a precise statement.")

#metadata(none) <tao-96f0d941bd2914cc94ed>

#heading(level: 1)[#strong[#text(" — 1. An exact factorisation of ")#mi("{\\zeta}")#text(" — ")]]

#text("In this section we give an an exact factorisation of ")#mi("{\\zeta}")#text(" into a “mesoscopic” part involving a finite Dirichlet series relating to the von Mangoldt function, and a “microscopic” part involving nearby zeroes; this can be viewed as an interpolant between the classical formula")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\exp( \\sum_n \\frac{\\Lambda(n)}{n^s \\log n} )")]]

#text("for ")#mi("{\\mathrm{Re}(s)>1}")#text(" on one hand, and the Weierstrass or Hadamard factorisations on the other. This factorisation will be useful in the eventual proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text(". (UPDATE: I have since learned that this factorisation was previously introduced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2309173")[#text("by Gonek, Hughes, and Keating")]#text(" (see also ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3348772")[#text("this later paper of Gonek")]#text("), for essentially the same purposes as in this post.)")

#text("The starting point will be the explicit formula, which we use in the form ")#metadata(none) <tao-3a2f9831dcd1d323649f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_n \\Lambda(n) g( \\log n ) = - \\sum_\\rho^* \\hat g(-i\\rho)")]]

#text("for any test function ")#mi("{g}")#text(" supported in ")#mi("{(0,\\infty)}")#text(", where ")#mi("{\\Lambda}")#text(" is the von Mangoldt function, ")#mi("{\\hat g}")#text(" is the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat g(t) := \\int_0^\\infty g(u) e^{itu}\\ du,")]]

#text("and ")#mi("{\\sum_\\rho^*}")#text(" sums over all zeroes of the Riemann zeta function (both trivial and non-trivial), together with the pole at ")#mi("{s=1}")#text(" counted wiht multiplicity ")#mi("{-1}")#text(". See for instance Exercise 46 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("this previous blog post")]#text(". If ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a test function that equals ")#mi("{1}")#text(" near the origin, and ")#mi("{s \\in {\\bf C}}")#text(" has sufficiently large real part, then this formula, together with a limiting argument, implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s} (1 - \\varphi(\\log n)) = - \\sum_\\rho^* G_\\varphi(s-\\rho)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G_\\varphi(s) := \\int_0^\\infty (1-\\varphi(u)) e^{-su}\\ du")]]

#text("is the Laplace transform of ")#mi("{1-\\varphi}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("we conclude that ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = - \\sum_n \\frac{\\Lambda(n)}{n^s} \\varphi(\\log n) + \\sum_\\rho^* G_\\varphi(s-\\rho)")]]

#text("when the real part of ")#mi("{s}")#text(" is sufficiently large. We can integrate by parts to write")

#align(center)[#tao-fit-display[#mitex("G_\\varphi(s) = -\\frac{1}{s} \\int_0^\\infty \\varphi^{\\prime}(u) e^{-su}\\ du,")]]

#text("and now it is clear ")#mi("{G_\\varphi(s)}")#text(" extends meromorphically to the entire complex plane with a simple pole at ")#mi("{s=0}")#text(" with residue ")#mi("{-\\int_0^\\infty \\varphi^{\\prime}(u)\\ du = 1}")#text("; also, since ")#mi("{\\varphi^{\\prime}}")#text(" is smooth and supported in some compact subinterval ")#mi("{[c_1,c_2]}")#text(" of ")#mi("{[0,+\\infty)}")#text(", we see that we have estimates of the form ")#metadata(none) <tao-2fe840e13244a9d74888>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|G_\\varphi(s)\\right| \\ll_{A,\\varphi} \\frac{1}{s} (1 + \\left|\\mathrm{Im}(s)\\right|)^{-A} (e^{-c_1 \\mathrm{Re}(s)} + e^{-c_2 \\mathrm{Re}(s)})", block: true)]]

#text("for any ")#mi("{A \\geq 0}")#text(", thus ")#mi("{G_\\varphi}")#text(" decays exponentially as ")#mi("{\\mathrm{Re}(s) \\rightarrow +\\infty}")#text(" and is rapidly decreasing as ")#mi("{\\mathrm{Im}(s) \\rightarrow \\pm \\infty}")#text(". (If ")#mi("{\\varphi}")#text(" is not merely smooth, but is in fact in a ")#link("https://en.wikipedia.org/wiki/Gevrey_class")[#text("Gevrey class")]#text(", one can improve the ")#tao-math("{(1 + \\left|\\mathrm{Im}(s)\\right|)^{-A}}", block: false)#text(" factor to ")#tao-math("{e^{-c \\left|\\mathrm{Im}(s)\\right|^{1/\\alpha}}}", block: false)#text(" for some ")#mi("{c>0}")#text(" and ")#mi("{\\alpha>1}")#text(". This is basically the maximum decay one can hope for here thanks to the ")#link("https://en.wikipedia.org/wiki/Paley%E2%80%93Wiener_theorem")[#text("Paley-Wiener theorem")]#text(" (or the more advanced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=543504")[#text("Beurling-Malliavin theorem")]#text("). However, we will not need such strong decay here.) Both sides of ")#link(<tao-164200a298bafec89fd3>)[#text("(11)")]#text(" now extend meromorphically to the entire complex plane and so the identity ")#link(<tao-164200a298bafec89fd3>)[#text("(11)")]#text(" holds for all ")#mi("{s}")#text(" other than the zeroes and poles of ")#mi("{\\zeta}")#text(".")

#text("By taking an antiderivative of ")#mi("{G_\\varphi}")#text(" and then integrating, we may write")

#align(center)[#tao-fit-display[#mitex("G_\\varphi(s) = \\frac{H^{\\prime}_\\varphi(s)}{H_\\varphi(s)}")]]

#text("for some entire function ")#mi("{H_\\varphi(s)}")#text(" that has a simple zero at ")#mi("{s=0}")#text(" and no other zeroes, and converges to ")#mi("{1}")#text(" at ")#mi("{+\\infty}")#text("; one can express ")#mi("{H}")#text(" explicitly in terms of the ")#link("https://en.wikipedia.org/wiki/Exponential_integral")[#text("exponential integral")]#text(" ")#mi("{E_1(z) := \\int_z^\\infty \\frac{e^t}{t}\\ dt}")#text(" as")

#align(center)[#tao-fit-display[#mitex("H_\\varphi(s) = \\exp( \\int_0^\\infty \\varphi^{\\prime}(u) E_1(su)\\ du )")]]

#text("for ")#tao-math("{\\left|\\mathrm{Arg}(s)\\right| < \\pi}", block: false)#text(", and then extended continuously to the negative real axis. From ")#link(<tao-2fe840e13244a9d74888>)[#text("(12)")]#text(" one has the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|H_\\varphi(s)\\right| \\ll_{r,\\varphi} \\left|s\\right|", block: true)]]

#text("for ")#tao-math("{\\left|s\\right| \\leq r}", block: false)#text(", and ")#metadata(none) <tao-9bfc0acfbfd57053fb0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("H_\\varphi(s) = \\exp( O_{A,r,\\varphi}( (1 + \\left|\\mathrm{Im}(s)\\right|)^{-A} (e^{-c_1 \\mathrm{Re}(s)} + e^{-c_2 \\mathrm{Re}(s)}) ) )", block: true)]]

#text("for ")#tao-math("{\\left|s\\right| \\geq r}", block: false)#text(" and any ")#mi("{A \\geq 0}")#text(", for any ")#mi("{r>0}")#text(".")

#text("From ")#link(<tao-164200a298bafec89fd3>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = - \\sum_n \\frac{\\Lambda(n)}{n^s} \\varphi(\\log n) + \\sum_\\rho^* \\frac{H^{\\prime}_\\varphi}{H_\\varphi}(s-\\rho)")]]

#text("and we can integrate this to obtain")

#align(center)[#tao-fit-display[#mitex("\\log \\zeta(s) = \\sum_n \\frac{\\Lambda(n)}{n^s \\log n} \\varphi(\\log n) + \\sum_\\rho^* \\log H_\\varphi(s-\\rho)")]]

#text("at least when the real part of ")#mi("{s}")#text(" is large enough (and we choose branches of ")#mi("{\\log \\zeta}")#text(" and ")#mi("{\\log H}")#text(" to vanish at ")#mi("{+\\infty}")#text("); one can justify the interchange of summation and integration using ")#link(<tao-9bfc0acfbfd57053fb0f>)[#text("(13)")]#text(" (and the fact that ")#mi("{\\zeta}")#text(" is of order ")#mi("{1}")#text("). We can then exponentiate to conclude the formula ")#metadata(none) <tao-16b482635bb53781dea0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\zeta(s) = \\exp( \\sum_n \\frac{\\Lambda(n)}{n^s \\log n} \\varphi(\\log n) ) \\prod_\\rho^* H_\\varphi(s-\\rho).")]]

#text("for ")#mi("{\\mathrm{Re} s}")#text(" sufficiently large (where the factor at the pole ")#mi("{\\rho=1}")#text(" is ")#mi("{H_\\varphi(s-1)^{-1}}")#text(" due to the negative multiplicity); the right-hand side extends meromorphically to the entire complex plane, so ")#link(<tao-16b482635bb53781dea0>)[#text("(14)")]#text(" in fact holds for all ")#mi("{s \\neq 1}")#text(".")

#text("Rescaling ")#mi("{\\varphi(u)}")#text(" to ")#mi("{\\varphi(u/\\log R)}")#text(" (which rescales ")#mi("{H_\\varphi(s)}")#text(" to ")#mi("{H_\\varphi(s \\log R)}")#text(") for any ")#mi("{R > 1}")#text(", we obtain the generalisation ")#metadata(none) <tao-d0c56de9926e8073d674>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\zeta(s) = \\exp( \\sum_n \\frac{\\Lambda(n)}{n^s \\log n} \\varphi(\\frac{\\log n}{\\log R}) ) \\prod_\\rho^* H_\\varphi((s-\\rho) \\log R)")]]

#text("for all ")#mi("{s \\neq 1}")#text(". While this formula is valid in the entire complex plane (other than the pole ")#mi("{s=1}")#text("), it is most useful to the right of the critical line, where most of the ")#mi("{H_\\varphi}")#text(" factors become close to ")#mi("{1}")#text(" thanks to ")#link(<tao-9bfc0acfbfd57053fb0f>)[#text("(13)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. A microscale zero-free region — ")]]

#text("Let ")#mi("{\\Sigma}")#text(" denote the non-trivial zeroes ")#mi("{\\rho}")#text(" of zeta (counting multiplicity), and let ")#mi("{N(T)}")#text(" denote the number elements ")#mi("{\\rho}")#text(" of ")#mi("{\\Sigma}")#text(" with ")#mi("{0 \\leq \\mathrm{Im}(\\rho) \\leq T}")#text(". The ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann-von Mangoldt formula")]#text(" then gives the asymptotic ")#metadata(none) <tao-a354f2cd736bb7cd76b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("N(T) = \\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + O(\\log T).")]]

#text("For any ")#mi("{1/2 < \\sigma < 1}")#text(", let ")#mi("{N(\\sigma,T)}")#text(" denote the number of elements ")#mi("{\\rho}")#text(" of ")#mi("{\\Sigma}")#text(" with ")#mi("{\\mathrm{Re}(\\rho)>\\sigma}")#text(" and ")#mi("{0 \\leq \\mathrm{Im}(\\rho) \\leq T}")#text(". Clearly ")#mi("{N(\\sigma,T) \\leq N(T) \\ll T \\log T}")#text(". The Riemann hypothesis asserts that ")#mi("{N(\\sigma,T)=0}")#text(". The ")#emph[#text("Density hypothesis")]#text(" (in the log-free form) asserts the weaker bound that")

#align(center)[#tao-fit-display[#mitex("N(\\sigma,T) \\ll T^{-2(\\sigma-1/2)} T \\log T.")]]

#text("This remains open; however bounds of the form ")#metadata(none) <tao-7bfba6e0021f1fd1183d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("N(\\sigma,T) \\ll T^{-c(\\sigma-1/2)} T \\log T")]]

#text("are known unconditionally for some ")#mi("{c>0}")#text(". This was first achieved ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=20594")[#text("by Selberg")]#text(" for ")#mi("{c=1/4}")#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=820237")[#text("by Jutila")]#text(" for any ")#mi("{c<1/2}")#text(", and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1004130")[#text("by Conrey")]#text(" for any ")#mi("{c < 4/7}")#text(". However, for our analysis any positive value of ")#mi("{c}")#text(" will suffice.")

#text("As a corollary of ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(17)")]#text(" (and ")#link(<tao-a354f2cd736bb7cd76b5>)[#text("(16)")]#text("), we see that for any ")#mi("{W \\geq 0}")#text(", there are ")#mi("{O( e^{-cW} T \\log T )}")#text(" zeroes ")#mi("{\\rho \\in \\Sigma}")#text(" with ")#tao-math("{\\left|\\mathrm{Im}(\\rho)\\right| \\leq 3T}", block: false)#text(" and ")#mi("{\\mathrm{Re}(\\rho) > \\frac{1}{2} + \\frac{W}{\\log T}}")#text(". If we denote this set of zeroes by ")#mi("{\\Sigma_W}")#text(", then by ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_function#Hardy%E2%80%93Littlewood_maximal_inequality")[#text("the Hardy-Littlewood maximal inequality")]#text(" (applied to the sum of Dirac masses at the imaginary parts of these zeroes), for any ")#mi("{\\lambda > 0}")#text(", the event")

#align(center)[#tao-fit-display[#tao-math("\\sup_{H>0} \\frac{1}{H} \\# \\{ \\rho \\in \\Sigma_W: \\left|\\mathrm{Im} \\rho - t\\right| \\leq H\\} \\geq \\lambda", block: true)]]

#text("holds with probability ")#mi("{O( \\frac{1}{\\lambda} e^{-cW} \\log T )}")#text(". Setting ")#mi("{\\lambda = e^{cW/2} \\log T}")#text(" and then taking the union bound over ")#mi("{W \\geq W_0/2}")#text(" that are powers of two, we conclude that with probability ")#mi("{1-o(1)}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\rho \\in \\Sigma_W: \\left|\\mathrm{Im} \\rho - t\\right| \\leq H\\} \\leq H e^{-cW/2} \\log T", block: true)]]

#text("for all ")#mi("{H>0}")#text(" and all ")#mi("{W \\geq W_0/2}")#text(" that are a power of two. From this, ")#link(<tao-a354f2cd736bb7cd76b5>)[#text("(16)")]#text(", and renormalising ")#mi("{H = h / \\log T}")#text(", we thus have with probability ")#mi("{1-o(1)}")#text(" that ")#metadata(none) <tao-9d067cb2f21af3da9584>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\# \\{ \\rho \\in \\Sigma: \\left|\\mathrm{Im} \\rho - t\\right| \\leq \\frac{h}{\\log T}; \\mathrm{Re}(\\rho) \\geq \\frac{1}{2} + \\frac{W}{\\log T} \\} \\ll h e^{-cW/2}", block: true)]]

#text("for ")#emph[#text("all")]#text(" ")#mi("{h > 0}")#text(" and ")#mi("{W \\geq W_0}")#text(".")

#text("A similar argument (using the Riemann-von Mangoldt formula) shows that with probability ")#mi("{1-o(1)}")#text(", one has ")#metadata(none) <tao-c0c04ed4468cd0032f51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\# \\{ \\rho \\in \\Sigma: \\left|\\mathrm{Im} \\rho - t\\right| \\leq \\frac{h}{\\log T} \\} \\ll h \\log W_0", block: true)]]

#text("for all ")#mi("{h > 0}")#text(" (in fact one could replace ")#mi("{\\log W_0}")#text(" here by any other quantity that goes to infinity). We will improve this bound later (after discarding another exceptional event of ")#mi("{t}")#text("‘s).")

#text("Henceforth we restrict to the event that ")#link(<tao-9d067cb2f21af3da9584>)[#text("(18)")]#text(", ")#link(<tao-c0c04ed4468cd0032f51>)[#text("(19)")]#text(" both hold. Since the left-hand side of ")#link(<tao-9d067cb2f21af3da9584>)[#text("(18)")]#text(" cannot go below one without vanishing entirely, we now have a “microscale” zero-free region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\phi_t(x+iy): y \\geq \\frac{W_0}{2\\pi}, \\left|x\\right| \\leq e^{-cy} \\}", block: true)]]

#text("(say) for the Riemann zeta function. If we define the rescaled zero set ")#metadata(none) <tao-cd8336b83b08f00a5d59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\tilde \\Sigma := \\phi_t^{-1}(\\Sigma)")]]

#text("then we can rescale ")#link(<tao-9d067cb2f21af3da9584>)[#text("(18)")]#text(", ")#link(<tao-c0c04ed4468cd0032f51>)[#text("(19)")]#text(" to be ")#metadata(none) <tao-832379e8eb737825d932>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\# \\{ \\lambda \\in \\tilde \\Sigma: \\left|\\mathrm{Re} \\lambda\\right| \\leq h; \\mathrm{Im} \\lambda \\geq W \\} \\ll h e^{-cW/2}", block: true)]]

#text("for ")#emph[#text("all")]#text(" ")#mi("{h > 0}")#text(" and ")#mi("{W \\geq W_0}")#text(", and ")#metadata(none) <tao-a6b66d034d7790bdd9e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\# \\{ \\lambda \\in \\tilde \\Sigma: \\left|\\mathrm{Re} \\lambda\\right| \\leq h \\} \\ll h \\log W_0", block: true)]]

#text("for all ")#mi("{h>0}")#text(".")

#text("After shrinking the region a little bit, we have a quite precise formula for ")#mi("{\\zeta}")#text(" in this region:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-13ffa0daa97bd3484134>#text(" If ")#mi("{s = \\phi_t(x+iy)}")#text(" lies in the region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\phi_t(x+iy): y \\geq \\frac{W_0}{\\pi}, \\left|x\\right| \\leq e^{-cy}/2 \\}", block: true)]]

#text("and ")#mi("{0 < \\varepsilon < c}")#text(", then ")#metadata(none) <tao-81fdb63820a831693748>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\log \\zeta(s) = \\sum_n \\frac{\\Lambda(n)}{n^s \\log n} \\varphi(\\frac{\\log n}{\\log T^\\varepsilon}) + O_{\\varepsilon}(e^{-c^{\\prime} \\varepsilon y} \\log W_0)")]]

#text("for some absolute constant ")#mi("{c^{\\prime}>0}")#text(". (We allow implied constants to depend on ")#mi("{\\varphi}")#text(".)")
]

#emph[#text("Proof:")]#text(" We apply ")#link(<tao-d0c56de9926e8073d674>)[#text("(15)")]#text(" with ")#mi("{R := T^\\varepsilon}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("H_\\varphi( (s-1) \\log R ) = \\exp( O( T^{-100} ) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H_\\varphi( (s+2n) \\log R ) = \\exp( O( T^{-100} n^{-100} ) )")]]

#text("for all ")#mi("{n=1,2,\\dots}")#text(", so")

#align(center)[#tao-fit-display[#mitex("\\prod_\\rho^* H_\\varphi((s-\\rho) \\log R) = (1+o(1)) \\prod_{\\rho \\in \\Sigma} H_\\varphi( (s-\\rho) \\varepsilon \\log T ).")]]

#text("To evaluate the product, we write ")#mi("{\\rho = \\phi_t(\\lambda)}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\rho \\in \\Sigma} H_\\varphi( (s-\\rho) \\varepsilon \\log T ) = \\prod_{\\lambda \\in \\tilde \\Sigma} H_\\varphi( 2\\pi \\varepsilon (x+iy-\\lambda) ).")]]

#text("We first consider those rescaled zeroes ")#mi("{\\lambda}")#text(" for which ")#mi("{\\mathrm{Im} \\lambda \\leq y / 2}")#text(". Here we see from ")#link(<tao-9bfc0acfbfd57053fb0f>)[#text("(13)")]#text(" and the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("H_\\varphi( 2\\pi \\varepsilon(x+iy-\\lambda) ) = \\exp( O_\\varepsilon( (1 + \\left|\\mathrm{Im}(\\lambda)\\right|)^{-10} e^{-c_1 \\varepsilon y / 2} ) )", block: true)]]

#text("which we can then multiply using ")#link(<tao-a6b66d034d7790bdd9e5>)[#text("(22)")]#text(" and dyadic decomposition to conclude that")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\lambda \\in \\tilde \\Sigma: \\mathrm{Im} \\lambda \\leq y / 2} H_\\varphi( 2\\pi \\varepsilon (x+iy-\\lambda) ) = \\exp( O_{\\varepsilon}( e^{-c_1 \\varepsilon y / 2} \\log W_0 ) ).")]]

#text("Now consider those ")#mi("{\\lambda}")#text(" for which ")#mi("{2^{j-1} y \\leq \\mathrm{Im} \\lambda \\leq 2^j y}")#text(" for some ")#mi("{j \\geq 0}")#text(". Here we see from ")#link(<tao-9bfc0acfbfd57053fb0f>)[#text("(13)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("H_\\varphi( 2\\pi \\varepsilon(x+iy-\\lambda) ) = \\exp( O_{\\varepsilon,A}( \\left|\\mathrm{Re} \\lambda\\right|^{-A} e^{2^j c_2 \\varepsilon y} ) )", block: true)]]

#text("for any ")#mi("{A > 0}")#text(". Multiplying this using ")#link(<tao-832379e8eb737825d932>)[#text("(21)")]#text(" and dyadic decomposition, we conclude for ")#mi("{A}")#text(" large enough that")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\lambda \\in \\tilde \\Sigma: 2^{j-1} y \\leq \\mathrm{Im} \\lambda \\leq 2^j y} H_\\varphi( 2\\pi \\varepsilon (x+iy-\\lambda) ) = \\exp( O_{\\varepsilon}( e^{- 2^j c_1 \\varepsilon y / 2} ) ).")]]

#text("Putting all this together, we conclude ")#link(<tao-81fdb63820a831693748>)[#text("(23)")]#text(". ")#mi("\\Box")

#text("From the Cauchy integral formula one then has the bound ")#metadata(none) <tao-5e38e47f4e4d426aa2d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = \\sum_n \\frac{\\Lambda(n)}{n^s} \\varphi(\\frac{\\log n}{\\log T^\\varepsilon}) + O_{\\varepsilon}(e^{-c^{\\prime} \\varepsilon y} \\log T)")]]

#text("for all ")#mi("{s = \\phi_t(x+iy)}")#text(" in the region")

#align(center)[#tao-fit-display[#tao-math("\\{ \\phi_t(x+iy): y \\geq W_0, \\left|x\\right| \\leq e^{-cy}/4 \\}.", block: true)]]

#text("We can use the moment method to control the right-hand side of ")#link(<tao-5e38e47f4e4d426aa2d0>)[#text("(24)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-7f13cfe15716b0dee840>#text(" Let ")#mi("{\\delta>0}")#text(" be fixed. With probability ")#mi("{1-o(1)}")#text(", one has the bound")

#align(center)[#tao-fit-display[#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) \\ll (\\left|x\\right| + y)^{\\delta} \\frac{\\log T}{y}", block: true)]]

#text("for all ")#mi("{s = \\phi_t(x+iy)}")#text(" in the region ")#metadata(none) <tao-c501c0c468aa97a0279e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\{ \\phi_t(x+iy): y \\geq 2W_0, \\left|x\\right| \\leq e^{-cy}/8 \\}.", block: true)]]
]

#text("One could improve the ")#tao-math("{(\\left|x\\right|+y)^\\delta}", block: false)#text(" loss here somewhat, in the spirit of the ")#link("https://en.wikipedia.org/wiki/Law_of_the_iterated_logarithm")[#text("law of the iterated logarithm")]#text(", but we will not attempt to do so here.")

#emph[#text("Proof:")]#text(" We can tile the region ")#link(<tao-c501c0c468aa97a0279e>)[#text("(25)")]#text(" by squares of the form")

#align(center)[#tao-fit-display[#mitex("Q = \\{ \\phi_t(x+iy): W \\leq y \\leq 2W; x_0 \\leq x \\leq x_0+W \\}")]]

#text("for various ")#mi("{W \\geq W_0}")#text(" and ")#mi("{x_0}")#text(". By the union bound, it will suffice to show the bound")

#align(center)[#tao-fit-display[#tao-math("\\sup_{s \\in Q} \\left|\\frac{\\zeta^{\\prime}}{\\zeta}(s)\\right| \\ll (1 + \\left|x_0\\right| + W)^\\delta \\frac{\\log T}{W}", block: true)]]

#text("with probability ")#tao-math("{1 - O_\\delta( (\\left|x_0\\right|+W)^{-10} )}", block: false)#text(" (say) for each such square ")#mi("{Q}")#text(", after restricting to the event that Proposition ")#link(<tao-13ffa0daa97bd3484134>)[#text("4")]#text(". Taking ")#mi("{\\varepsilon = 1/W}")#text(", it then suffices by that proposition to show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{s \\in Q} \\left|F(s)\\right| \\ll (\\left|x_0\\right|+W)^\\delta", block: true)]]

#text("with probability ")#tao-math("{1 - O_\\delta( (\\left|x_0\\right|+X)^{-10} )}", block: false)#text(", where")

#align(center)[#tao-fit-display[#mitex("F(s) := \\frac{W}{\\log T} \\sum_n \\frac{\\Lambda(n)}{n^s} \\varphi(\\frac{\\log n}{\\log T^{1/W}}).")]]

#text("Let ")#mi("{k}")#text(" be a large fixed even integer depending on ")#mi("{\\delta}")#text(".")

#align(center)[#tao-fit-display[#tao-math("(\\sup_{s \\in Q} \\left|F(s)\\right|)^{k} \\ll_k \\frac{1}{\\left|Q\\right|} \\int_Q \\left|F(s)\\right|^k\\ ds + \\frac{1}{\\left|Q\\right|} \\int_Q \\left|\\frac{W}{\\log T} F^{\\prime}(s)\\right|^k\\ ds", block: true)]]

#text("where ")#mi("{ds}")#text(" is Lebesgue measure on ")#mi("{Q}")#text(". By linearity of expectation and Markov’s inequality, it then suffices to establish the bounds")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|F(s)\\right|^k \\ll_k 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\frac{W}{\\log T} F^{\\prime}(s)\\right|^k \\ll_k 1", block: true)]]

#text("uniformly for ")#mi("{s \\in Q}")#text(". But this is a routine moment calculation (after first restoring the exceptional events in which ")#link(<tao-c0c04ed4468cd0032f51>)[#text("(19)")]#text(", ")#link(<tao-a6b66d034d7790bdd9e5>)[#text("(22)")]#text(" fail in order to more easily compute the moment). ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Microscale Riemann-von Mangoldt formulae — ")]]

#text("Henceforth we restrict attention to the probability ")#mi("{1-o(1)}")#text(" event where ")#link(<tao-c0c04ed4468cd0032f51>)[#text("(19)")]#text(", ")#link(<tao-a6b66d034d7790bdd9e5>)[#text("(22)")]#text(", and Proposition ")#link(<tao-7f13cfe15716b0dee840>)[#text("5")]#text(" all hold. Then we have a microscale zero-free region slightly to the right of the critical line with good bounds on the log-derivative; by the functional equation, we also have good bounds slightly to the left of the critical line. Meanwhile, ")#link(<tao-c0c04ed4468cd0032f51>)[#text("(19)")]#text(", ")#link(<tao-a6b66d034d7790bdd9e5>)[#text("(22)")]#text(" gives some preliminary control between these two lines. One can then put all this information together by standard techniques to obtain a microscale version of the Riemann-von Mangoldt formula, which we can then use to establish Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text(".")

#text("We turn to the details. We start from the well known identity ")#metadata(none) <tao-693c278188ead836d92b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = C - \\sum_\\rho^* (\\frac{1}{s-\\rho} - \\frac{1}{\\rho})")]]

#text("(see e.g., equation (45) of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("this previous blog post")]#text(") for an absolute constant ")#mi("{C}")#text(" and all ")#mi("{s^{\\prime}}")#text(" that are not zeroes or poles of ")#mi("{\\zeta}")#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) + \\frac{\\zeta^{\\prime}}{\\zeta}(\\overline{1-s}) = - \\sum_\\rho^* (\\frac{1}{s-\\rho} - \\frac{1}{\\overline{1-s}-\\rho}).")]]

#text("On the other hand, from the functional equation ")#link(<tao-f0ac255c776f4378eece>)[#text("(5)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime}}{\\zeta}(s) = \\frac{\\chi^{\\prime}}{\\chi}(s) - \\frac{\\zeta^{\\prime}}{\\zeta}(1-s)")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta^{\\prime}}{\\zeta}(\\overline{1-s}) = \\overline{\\frac{\\chi^{\\prime}}{\\chi}(s)} - \\overline{\\frac{\\zeta^{\\prime}}{\\zeta}(s) }")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("- 2 \\mathrm{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(s) + \\overline{\\frac{\\chi^{\\prime}}{\\chi}(s)} = - \\sum_\\rho^* (\\frac{1}{s-\\rho} - \\frac{1}{\\overline{1-s}-\\rho}).")]]

#text("Writing ")#mi("{s = \\phi_t(z)}")#text(" and using ")#link(<tao-dffe602cd1e0bfa9b4d8>)[#text("(7)")]#text(", ")#link(<tao-cd8336b83b08f00a5d59>)[#text("(20)")]#text(" we conclude")

#align(center)[#tao-fit-display[#mitex("- 2 \\mathrm{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(s) + \\log T= - \\frac{\\log T}{2\\pi} \\sum_{\\lambda \\in \\tilde \\Sigma} (\\frac{1}{z-\\lambda} - \\frac{1}{\\overline{z}-\\lambda}) + O(1).")]]

#text("Using the functional equation we can replace ")#mi("{\\frac{1}{\\overline{z}-\\lambda}}")#text(" here by ")#mi("{\\frac{1}{\\overline{z-\\lambda}}}")#text(", and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\lambda \\in \\tilde \\Sigma} \\frac{\\mathrm{Im}(z-\\lambda)}{\\left|z-\\lambda\\right|^2} = \\pi - \\frac{2\\pi}{\\log T} \\mathrm{Re} \\frac{\\zeta^{\\prime}}{\\zeta}(s) + O( \\frac{1}{\\log T}.", block: true)]]

#text("In particular from Proposition ")#link(<tao-7f13cfe15716b0dee840>)[#text("5")]#text(" and writing ")#mi("{z=x+iy}")#text(" one has ")#metadata(none) <tao-ddaac836a2b41fb30eca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\sum_{\\lambda \\in \\tilde \\Sigma} \\frac{\\mathrm{Im}(x+iy-\\lambda)}{\\left|x+iy-\\lambda\\right|^2} = \\pi + O( \\frac{(\\left|x\\right|+y)^{0.1}}{y} )", block: true)]]

#text("when one is in the region ")#link(<tao-c501c0c468aa97a0279e>)[#text("(25)")]#text(" with ")#mi("{y = o(\\log T)}")#text(". The zeroes ")#mi("{\\lambda}")#text(" of imaginary part less than ")#mi("{y/2}")#text(" give a positive contribution to the LHS (which is comparable to ")#mi("{1/y}")#text(" when ")#mi("{\\mathrm{Re}\\lambda = x + O(y)}")#text(", while the contributions of the zeroes of imaginary part greater than or equal to ")#mi("{y/2}")#text(" is ")#mi("{O(e^{-c^{\\prime\\prime}y})}")#text(" for some ")#mi("{c^{\\prime\\prime}>0}")#text(" thanks to ")#link(<tao-9d067cb2f21af3da9584>)[#text("(18)")]#text(". We conclude in particular the crude estimate ")#metadata(none) <tao-b5fd4da6901078530ad0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\# \\{ \\lambda \\in \\tilde \\Sigma: \\left|\\mathrm{Re} \\lambda - x\\right| \\leq y \\} \\ll y", block: true)]]

#text("whenever one is in the region ")#link(<tao-c501c0c468aa97a0279e>)[#text("(25)")]#text(" with ")#mi("{y = o(\\log T)}")#text(". If we then go back to ")#link(<tao-ddaac836a2b41fb30eca>)[#text("(27)")]#text(" and integrate it for ")#mi("{x}")#text(" in an interval ")#mi("{I}")#text(" in ")#mi("{[-e^{-cy/16}, e^{cy/16}]}")#text(" and use ")#link(<tao-b5fd4da6901078530ad0>)[#text("(28)")]#text(" to control errors, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\# \\{ \\lambda \\in \\tilde \\Sigma: \\mathrm{Re} \\lambda \\in I \\} = \\left|I\\right| + O( \\frac{(\\mathrm{dist}(I,0)+y)^{0.1} \\left|I\\right|}{y} ) + O(y).", block: true)]]

#text("In particular, if we arrange the sort the rescaled zeroes ")#mi("{\\lambda_n \\in \\tilde \\Sigma}")#text(" in nondecreasing order of real part, with ")#mi("{\\mathrm{Re} \\lambda_n \\geq 0}")#text(" for ")#mi("{n \\geq 0}")#text(" and ")#mi("{\\mathrm{Re} \\lambda_n < 0}")#text(" for ")#mi("{n < 0}")#text(", and such that any conjugate pairs of zeroes are consecutive, then we have the microscale Riemann-von Mangoldt formula ")#metadata(none) <tao-fce144e53afe0ea9e827>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\lambda_n = n + O( W_0^2 + \\left|n\\right|^{0.6} )", block: true)]]

#text("for ")#mi("{n = o(T \\log T)}")#text(" (as can be seen by applying the above formula with ")#mi("{I = [0,x]}")#text(" or ")#mi("{I = [-x,0]}")#text(" for ")#tao-math("{\\left|x\\right|}", block: false)#text(" near ")#tao-math("{\\left|n\\right|}", block: false)#text(" and ")#tao-math("{y = 100 W_0 + \\left|n\\right|^{1/2}}", block: false)#text(". Likely the error term can be improved with further effort. For ")#mi("{n \\gg T \\log T}")#text(" one can also get very good control on ")#mi("{\\lambda_n}")#text(" from the classical Riemann-von Mangoldt formula.")

#text("From ")#link(<tao-693c278188ead836d92b>)[#text("(26)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = C_t - i \\frac{\\log T}{2\\pi} \\mathrm{p.v.} \\sum_n \\frac{1}{z-\\lambda_n}")]]

#text("for some constant ")#mi("{C_t}")#text(" depending on ")#mi("{t}")#text(" but not on ")#mi("{z}")#text(", where we use ")#link(<tao-fce144e53afe0ea9e827>)[#text("(29)")]#text(" (and the classical Riemann-von Mangoldt formula) to ensure convergence of the principal value summation. If we set ")#mi("{z = iW}")#text(" for some ")#mi("{W_0^3 \\leq W = o(\\log T)}")#text(" then from ")#link(<tao-fce144e53afe0ea9e827>)[#text("(29)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{p.v.} \\sum_n \\frac{1}{z-\\lambda_n} = -i\\pi + O(W^{-0.4})")]]

#text("while from Proposition ")#link(<tao-7f13cfe15716b0dee840>)[#text("5")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) \\ll W^{-0.9}")]]

#text("and hence ")#mi("{C_t = O(W^{-0.4})}")#text(". Optimising in ")#mi("{W}")#text(" we thus have ")#mi("{C_t = \\frac{1}{2} \\log T + O( \\log^{-0.3} T )}")#text(" (say), hence")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = \\frac{1}{2} \\log T - i \\frac{\\log T}{2\\pi} \\mathrm{p.v.} \\sum_n \\frac{1}{z-\\lambda_n} + O( \\log^{-0.3} T ).")]]

#text("Next, let ")#mi("{\\lambda_{-N_-}, \\dots, \\lambda_{N_+}}")#text(" be a consecutive string of rescaled zeroes in ")#mi("{\\tilde \\Sigma}")#text(" with ")#mi("{N_-, N_+ = N/2+O(1)}")#text(". By adjusting ")#mi("{N}")#text(" by one if necessary, we can assume that there are exactly ")#mi("{N}")#text(" zeroes in this string and that whenever one complex zero is in this set, its complex conjugate is also. Then we can define a degree ")#mi("{N}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("P(Z) := A \\prod_{j=-N_-}^{N_+} (Z - e^{2\\pi i \\lambda_j / N})")]]

#text("for some non-zero constant ")#mi("{A}")#text(" to be chosen later. This polynomial obeys a functional equation ")#metadata(none) <tao-01243390c5866df0f29e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("P_t(Z) = e^{-2\\pi i \\theta} Z^N \\overline{P_t}(1/Z)")]]

#text("for some phase ")#mi("{\\theta}")#text(" (which at present need not be equal to ")#mi("{L(T)}")#text(", but we will address this issue later). If we set")

#align(center)[#tao-fit-display[#mitex("G_t(s) := P_t( e^{-2\\pi i \\phi_t^{-1}(s)/N} )")]]

#text("then ")#mi("{G_t}")#text(" is an entire function, and from the Euler product formula for sine we have")

#align(center)[#tao-fit-display[#mitex("-\\frac{G^{\\prime}_t}{G_t}(s) = \\frac{1}{2} \\log T -i \\frac{\\log T}{2\\pi} \\sum_{j=-N_-}^{N_+} \\mathrm{p.v.} \\sum_n \\frac{1}{z - \\lambda_j - N n}")]]

#text("whenever ")#mi("{s = \\phi_t(z)}")#text(". Thus if we factor ")#mi("{\\zeta_t = G_t K_t}")#text(", then by using ")#link(<tao-fce144e53afe0ea9e827>)[#text("(29)")]#text(" one can compute that")

#align(center)[#tao-fit-display[#mitex("-\\frac{K^{\\prime}_t}{K_t}(s) = O(W_0 N^{-0.4} \\log T)")]]

#text("if ")#mi("{s = \\frac{1}{2} + it - O( \\frac{W_0}{\\log T})}")#text(". Thus, ")#mi("{\\log K_t}")#text(" only fluctuates by ")#mi("{O( W_0^2 N^{-0.4}) = o(1)}")#text(" in this region. By choosing the normalising constant ")#mi("{A}")#text(" appropriately, one may thus ensure that ")#mi("{\\log K_t = o(1)}")#text(" in this region, thus giving the approximation ")#link(<tao-6c126e81fa8dc29d6413>)[#text("(4)")]#text(" when ")#tao-math("{\\left|z\\right| \\leq W_0}", block: false)#text(". From ")#link(<tao-f0ac255c776f4378eece>)[#text("(5)")]#text(" one thus has")

#align(center)[#tao-fit-display[#mitex("P_t(e^{-2\\pi i z/N}) = (1+o(1)) \\chi(s) \\overline{P_t}(e^{-2\\pi i \\overline{z}/N})")]]

#text("when ")#tao-math("{\\left|z\\right| \\leq W_0}", block: false)#text(". From ")#link(<tao-7f5a9ba14cb89dc20e90>)[#text("(8)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\chi(s) = (1+o(1)) e^{-2\\pi i L(t)} Z^N")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("P_t(Z) = (1+o(1)) e^{-2\\pi i L(t)} Z^N \\overline{P_t}(1/Z)")]]

#text("for at least one choice of ")#mi("{Z}")#text(". Thus the phase ")#mi("{\\theta}")#text(" in ")#link(<tao-01243390c5866df0f29e>)[#text("(30)")]#text(" differs from ")#mi("{L(t)}")#text(" by ")#mi("{o(1)}")#text(" (after shifting by an integer). Thus by adjusting the normalising constant ")#mi("{A}")#text(" by a multiplicative factor of ")#mi("{1+o(1)}")#text(", we obtain ")#link(<tao-75a1b65144b46b8739e3>)[#text("(9)")]#text(" as required.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2019")])]

#text("The local trigonometric polynomial approximation to ")#mi("H_t(x)")#text(" should be a good example for large x (for which ")#mi("H_t")#text(" zeros “solidify” to be very close to the zeros of a trigonometric polynomial), is it possible to generalize this to L- functions (or even to a larger class of Dirichlet series)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8905cee19ba19805e5e09fa8c5a7abb5d2fadf12e60e58a2c5786c6c0446f40-6f0c7044d81d043a595d40ca3c742e4ec5f2cfe20c7ee4b4718dfa5cf07116f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515811")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2019")])]

#text("is there any way to turn these theoretical results about the zeta function into arithmetically useful information?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Well, certainly many existing results and conjectures about the zeta function can be phrased in this framework, where they become marginally cleaner. For instance, one can establish the Selberg central limit theorem using this formalism: by pushing the analysis in this post a bit further, one can extract a factorisation")

#mi("P_t(Z) = \\exp( \\sum_n \\frac{\\Lambda(n)}{n^{1/2+it}} \\psi( \\frac{\\log n}{\\log R} ) ) Q_{t,\\varepsilon}(Z)")

#text("where ")#mi("R = T^\\varepsilon")#text(" and ")#mi("Q_{t,\\varepsilon}")#text(" is a polynomial which is “bounded in probability” in some sense (it is determined more or less completely by the nearby zeroes of zeta). The first factor has an asymptotically log-normal distribution and dominates the second factor (in probability) at say ")#mi("Z=1")#text(", which gives the Selberg central limit theorem. Conjecturally, ")#mi("Q_{t,\\varepsilon}")#text(" should essentially be the characteristic polynomial of a random unitary matrix distributed using Haar measure, which would give the GUE hypothesis (and also 100% of zeroes on the critical line), and also predicts things like the moment and ratio conjectures for the Riemann zeta function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("Study the harmonic series since it’s a prime source of prime number theory in regards to the Riemann Hypothesis and the Prime Number Theorem. Gauss and Riemann applied some tools of real analysis and complex analysis, respectively, to the harmonic series to achieve some great results.")

#text("Too much esoteric theory (above) is beside the point — it’s fancy mathematics which may lead one astray…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Is the Riemann Hypothesis true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("Hmm. Let’s take a poll. (It does not require a RH proof here.)")

#text("Press ‘Thumb Up’ Button to indicate a ‘Yes’ answer.")

#text("Press ‘Thumb Down’ Button to indicate a ‘No’ answer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2019")])]

#text("Hints: A nontrivial zeta zero off the critical line (Re(z) = 1/2) does not make any sense. There’s no good reason for it. And it’s pure fiction or fake news too think otherwise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("Yes! Any attempt to refute the famous and important Riemann Hypothesis, Re(z_n) = 1/2, is a very futile exercise since the hypothesis is true! Please do something worthwhile.")

#text("And I can give you n (from one to infinity) reasons why the Riemann Hypothesis is true! Amen!")

#text("Moreover, it is unsound (incomplete) to discuss the properties of the nontrivial and simple zeta zeros of the Riemann Zeta Function without discussing the properties of primes.")

#text("They are are interdependent or interrelated. Amen!")

#text("Note: The nth nontrivial and simple zeta zero exists if and only if the nth prime exists.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2019")])]

#text("Since my work in mathematics has brought me no happiness nor awards, I have decided to retire from it today…")

#text("Goodbye and good luck to all,")

#text("David Cole,")

#link("https://www.researchgate.net/profile/David_Cole29")[#text("https://www.researchgate.net/profile/David_Cole29")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2019")])]

#text("Keywords: Fundamental Theorem of Arithmetic and the Riemann Hypothesis")

#text("Basic and Important Fact Confirming RH (Riemann Hypothesis or Right Hypothesis, Re(z) = 1/2) where z is any nontrivial and simple zero of the Riemann Zeta Function:")

#text("For all n > 1, where n is any positive composite number, there exists a prime number, p, such that p|n (p divides n) where p ≤ n^(1/2) (p is less than or equal to the square root of n).")

#text("And thus, the exponent of of the expression, n^(1/2), which is 1/2 represents the critical line (Re(z) = 1/2) and confirms RH. And in turn, RH confirms the above basic and important fact. Amen!")

#text("The Riemann Hypothesis or the Right Hypothesis is true! Please acknowledge that fact!")

#text("David Cole.")

#text("Relevant Reference Link:")

#link("https://www.math10.com/forum/viewtopic.php?f=63&t=1549")[#text("https://www.math10.com/forum/viewtopic.php?f=63&t=1549")]

#text("P.S. I cannot retired from mathematics in peace while there are ‘experts’")#linebreak()#text(" of RH who claimed RH is still a open problem. They are either in denial or they do not understand RH!")#linebreak()#text(" ​")

#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-517909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2019")])]

#text("I made some harsh/ignorant comments below…, and I apologize. I wish everyone the best. David Cole.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/131d5639e45253d3b32884a17344a26f0f34a81116a3ca10ed5d5a083d97b99a-a23dacb03b67e3ebd00a069edbb99797d1ed657d23d2266b042fea78cc26217a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515851")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("About a local approximation of ")#mi("\\zeta")#text(" by trigonometric polynomials, I have thought about the following expression, for any ")#mi("t_0 > 2")#text(":")

#mi("\\displaystyle Z_{t_0}(t) := 2 \\sum_{1 \\leq k \\leq \\sqrt{t_0/2\\pi}} \\frac{1}{\\sqrt{k}} \\cos \\left( \\frac{t}{2} \\log \\left(\\frac{t_0}{2 \\pi k^2} \\right) - \\frac{t_0}{2} - \\frac{\\pi}{8} \\right)")

#text("which approximate the Riemann-Siegel function ")#mi("Z")#text(" with an error ")#mi("O(t_0^{-1/4})")#text(" for ")#mi("t \\in [t_0 - t_0^{1/4}, t_0 + t_0^{1/4}]")#text(" (a consequence of the Riemann-Siegel formula, after linearizing the Riemann-Siegel theta function around ")#mi("t_0")#text(").")#linebreak()#text(" I have been curious about the behavior of the asymptotic proportion of zeros ")#mi("Z_{t_0}")#text(" on the real line, in function of ")#mi("t_0")#text(". I don’t know if there are sufficiently convenient and powerful tools to study that. A few numerical simulations suggested me that most of the zeros of ")#mi("Z_{t_0}")#text(" are on the real line for ")#mi("\\mathrm{Re}(t)")#text(" close to ")#mi("t_0")#text(" (where ")#mi("Z_{t_0}")#text(" approximates ")#mi("Z")#text(" well), but not for ")#mi("\\mathrm{Re}(t)")#text(" far from ")#mi("t_0")#text(", except for values of ")#mi("t_0")#text(" such that he sum defining ")#mi("Z_{t_0}")#text(" has one or two terms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2019")])]

#text("Suppose that ")#mi("\\phi_t(z)")#text(" is allowed to be a quadratic polynomial in ")#mi("z")#text(", is there an optimal coefficient (which may depend on ")#mi("t")#text(") of ")#mi("z^2")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515907")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2019")])]

#text("Right now ")#mi("\\phi_t")#text(" describes a linear change of variables between the global coordinate ")#mi("s")#text(" and a “microscale” coordinate ")#mi("z")#text(", which one can then convert nonlinearly to the coordinate ")#mi("e^{2\\pi i z/N}")#text(". Both coordinates have some convenient features: in the microscale coordinate ")#mi("z")#text(", the critical line is the real line (and the symmetry is reflection around that line), and in the nonlinear coordinate ")#mi("e^{2\\pi i z/N}")#text(" the critical line is now the unit circle (and the symmetry is the usual inversion across that circle). In the spirit of the Riemann mapping theorem one could consider a conformal change of coordinates to make the critical line some other Jordan curve, but it’s hard to imagine any of these being any more tractable than the line or circle, given how well understood the half-plane and disk domains are in complex analysis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The alternative hypothesis for unitary matrices | What's new")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-515974")[#strong[#text("The alternative hypothesis for unitary matrices | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2019")])]

#text("[…] a recent post I discussed how the Riemann zeta function can be locally approximated by a polynomial, in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2019")])]

#text("Are these new results (especially Proposition 5) ? It seems quite strong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516332")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2019")])]

#text("The basic tool powering these results – the zero density theorems of Selberg, Jutlia, and Conrey near the critical line – are not new, but I haven’t seen this application of these theorems in the prior literature. It was already known that these theorems tell us that “most” of the zeroes of zeta lie within ")#mi("O(1/\\log T)")#text(" of the critical line, giving a reasonable substitute for RH near a generic height ")#mi("t")#text("; the calculations here carry this sort of “near-RH on average” a bit further, giving a number of results of comparable strength to RH at generic heights. For instance there is also a prime number theorem for partial sums of ")#mi("\\frac{\\Lambda(n)}{n^{1/2+it}}")#text(" with RH-like error term that one could get from Proposition 5 and Perron’s formula, though I didn’t write it down explicitly here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2019")])]

#text("Is it possible to combine theorem 2 and the probabilistic method to establish certain deterministic structures among consecutive zeta zeros on sufficiently short intervals?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516333")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2019")])]

#text("Possibly, if one also was able to get further information on the polynomial ")#mi("P_t")#text(". Certainly for instance one can reinterpret existing results regarding the proportion of zeroes on the critical line, or bounds on the smallest or largest gap between zeroes, using this language, and viewing various known mean value theorems and moment theorems for the zeta function and related Dirichlet series as probabilistic estimates on ")#mi("P_t")#text(" (or on the log derivative of ")#mi("P_t")#text(", or on moments of the zeroes, etc.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A function field analogue of Riemann zeta statistics | What's new")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516396")[#strong[#text("A function field analogue of Riemann zeta statistics | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2019")])]

#text("[…] is another sequel to a recent post in which I showed the Riemann zeta function can be locally approximated by a polynomial, in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("Are these polynomial approximations related to the Jensen polynomials being discussed in that paper making the news recently? ")#link("https://www.pnas.org/content/early/2019/05/20/1902572116")[#text("https://www.pnas.org/content/early/2019/05/20/1902572116")]

#text("Have you read it? Could you comment on the significance of their findings and maybe on the if and how of it relating to the things you’ve been looking at with respect to the RH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("I don’t see any connection. The approximations in this post are to the Riemann zeta function in a region ")#mi("s = \\frac{1}{2}+it + o(1)")#text(" at large height in the critical strip. The polynomials in that paper are constructed instead out of a (smoothed out) Taylor approximation of a high derivative of the Riemann xi function (with poles removed) at the central point ")#mi("s = \\frac{1}{2}")#text(". In this regime there does not seem to be a strong influence of either the zeroes of zeta or the rational primes, which are of course the two aspects of the zeta function that are of most importance in analytic number theory., and as a consequence the authors are able to get quite strong asymptotics in this regime.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16514b6868ba7d94f1f775dd5ea3e7545286114ba9e1529fe6086c440054d8b2-49971cc57cbbebc2419e9fa665afa2b7ba316162959127bb23bf63cdef9c5b93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunkhirous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516812")[#strong[#text("Sunkhirous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Roots are all on Zero line S = 0+- i(pi +2kpi)/lnP^2^n , P is Prime pi =3.14… It’s sad that every mathematician trying to prove they lie on 1/2 line where don’t even know the exact value of these zeros , XI function have 1/2")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Sunkhirous, is that a formula for the nontrivial zeros of the Riemann zeta function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Yes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16514b6868ba7d94f1f775dd5ea3e7545286114ba9e1529fe6086c440054d8b2-49971cc57cbbebc2419e9fa665afa2b7ba316162959127bb23bf63cdef9c5b93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunkhirous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516815")[#strong[#text("Sunkhirous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("i is for imaginary for S in the formula")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16514b6868ba7d94f1f775dd5ea3e7545286114ba9e1529fe6086c440054d8b2-49971cc57cbbebc2419e9fa665afa2b7ba316162959127bb23bf63cdef9c5b93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunkhirous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516821")[#strong[#text("Sunkhirous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("i = -1^.5")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2019")])]

#text("How are k, P, and n related to each other?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16514b6868ba7d94f1f775dd5ea3e7545286114ba9e1529fe6086c440054d8b2-49971cc57cbbebc2419e9fa665afa2b7ba316162959127bb23bf63cdef9c5b93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunkhirous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-516917")[#strong[#text("Sunkhirous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("k = 0,1,2,3…. n= 0,1,2… use k=0 for Riemann f(x) function")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/#comment-688241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("Hi Terry,")

#text("(I left a briefer version of my comment below on MathOverflow, but I’m not sure you could read it.)")

#text("I think that factorization is present in one way or the other in the literature from long before Gonek. In particular, you’ll find it (well, as a formula for zeta’/zeta, but that’s equivalent and they even integrate and exponentiate to find zeta) in section 13.2 of Montgomery-Vaughan, which uses $varphi$ piecewise linear; surely it’s following older sources.")

#text("I’m positive some people here know the history better than I do and can give us further references. Of course there is the annoying fact that plenty of sources (including Montgomery-Vaughan itself) tend to choose a smooth weight for the start, often without motivation; that’s a general issue.")
]
