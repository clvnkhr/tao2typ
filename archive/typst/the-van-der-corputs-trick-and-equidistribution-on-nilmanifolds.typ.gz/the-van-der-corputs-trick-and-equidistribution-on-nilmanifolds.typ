// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/
// Converted to Typst by tao2typ: "2026-10-14T16:35:21.809927+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The van der Corput trick, and equidistribution on nilmanifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The van der Corput trick, and equidistribution on nilmanifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/")[#text("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I was in Columbus, Ohio, attending a ")#link("http://www.math.osu.edu/~manfred/conference")[#text("conference on equidistribution on manifolds")]#text(". I talked about ")#link("http://arxiv.org/abs/0709.3562")[#text("my recent paper")]#text(" with ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" on the quantitative behaviour of polynomial sequences in nilmanifolds, which I have ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("blogged about previously")]#text(". During my talk (and inspired by the immediately preceding talk of Vitaly Bergelson), I stated explicitly for the first time a generalisation of the van der Corput trick which morally underlies our paper, though it is somewhat buried there as we specialised it to our application at hand (and also had to deal with various quantitative issues that made the presentation more complicated). After the talk, several people asked me for a more precise statement of this trick, so I am presenting it here, and as an application reproving an old theorem of Leon Green that gives a necessary and sufficient condition as to whether a linear sequence ")#mi("(g^n x)_{n=1}^\\infty")#text(" on a nilmanifold ")#mi("G/\\Gamma")#text(" is ")#link("http://en.wikipedia.org/wiki/Equidistributed")[#text("equidistributed")]#text(", which generalises the famous theorem of Weyl on equidistribution of polynomials.")

#text("UPDATE, Feb 2013: It has been pointed out to me by Pavel Zorin that this argument does not fully recover the theorem of Leon Green; to cover all cases, one needs the more complicated van der Corput argument in our paper.")

#metadata(none) <tao-d8d5d3344048d4cd438f>

#heading(level: 1)[#text("— The classical van der Corput trick —")]

#text("The classical van der Corput trick (first used implicitly by Weyl) gives a means to establish the equidistribution of a sequence ")#mi("(x_n)_{n = 1}^\\infty")#text(" in a torus ")#mi("{\\Bbb T}^d")#text(" (e.g. a sequence ")#mi("(P(n) \\text{ mod } 1)_{n=1}^\\infty")#text(" in the unit circle ")#mi("{\\Bbb T} = {\\Bbb R}/{\\Bbb Z}")#text(" for some function P, such as a polynomial.) Recall that such a sequence is said to be ")#emph[#text("equidistributed")]#text(" if one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N f(x_n) \\to \\int_{{\\Bbb T}^d} f")]]

#text("as ")#mi("N \\to \\infty")#text(" for every continuous function ")#mi("f: {\\Bbb T}^d \\to {\\Bbb C}")#text("; an equivalent formulation of equidistribution is that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\left| \\{ 1 \\leq n \\leq N: x_n \\in B \\} \\right| \\to \\text{vol}(B)", block: true)]]

#text("for every box B in the torus ")#mi("{\\Bbb T}^d")#text(". (The equivalence can be deduced easily from ")#link("http://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text(".) Equidistribution is an important phenomenon to study in ergodic theory and number theory, but also arises in applications such as ")#link("http://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo integration")]#text(" and pseudorandom number generation.")

#text("The fundamental ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text(" of Weyl states that a sequence is equidistributed if and only if the ")#link("http://en.wikipedia.org/wiki/Exponential_sum")[#text("exponential sums")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N e^{2\\pi i \\chi(x_n)}")]]

#text("converge to zero for every non-trivial ")#link("http://en.wikipedia.org/wiki/Character_%28mathematics%29")[#text("character")]#text(" ")#mi("\\chi: {\\Bbb T}^d \\to {\\Bbb T}")#text(", i.e. a non-zero continuous homomorphism to the unit cicle. Indeed, it is clear that (2) is a special case of (1), and conversely the general case of (1) can be deduced from (2) and either the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(" or basic Fourier analysis.")

#text("The significance of the equidistribution theorem is that it reduces the study of equidistribution to the question of estimating exponential sums, which is a problem in analysis and number theory. For instance, from the equidistribution theorem and the ")#link("http://en.wikipedia.org/wiki/Geometric_series")[#text("geometric series formula")]#text(" we immediately obtain the following result (stronger than ")#link("http://en.wikipedia.org/wiki/Kronecker%27s_theorem")[#text("Kronecker’s approximation theorem")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (Equidistribution of linear sequences in torii) Let ")#mi("\\alpha \\in {\\Bbb T}^d")#text(". Then the sequence ")#mi("(\\alpha n)_{n =1}^\\infty")#text(" is equidistributed in ")#mi("{\\Bbb T}^d")#text(" if and only if ")#mi("\\alpha")#text(" is ")#emph[#text("totally irrational")]#text(", which means that ")#mi("\\chi(\\alpha) \\neq 0")#text(" for all non-zero characters ")#mi("\\chi")#text(".")
]

#text("For instance, the linear sequence ")#mi("(\\sqrt{2} n \\text{ mod } 1, \\sqrt{3} n \\text{ mod } 1)")#text(" is equidistributed in the two-torus ")#mi("{\\Bbb T}^2")#text(", since ")#mi("(\\sqrt{2}, \\sqrt{3})")#text(" is totally irrational, but the linear sequence ")#mi("(\\sqrt{2} n \\text{ mod } 1, \\sqrt{8} n \\text{ mod } 1)")#text(" is not (the character ")#mi("\\chi: (x,y) \\mapsto y-2x")#text(" annihilates ")#mi("(\\sqrt{2}, \\sqrt{8})")#text(" and thus obstructs equidistribution). [Of course, in the latter case, the orbit is still equidistributed in a smaller torus, namely the kernel of the character ")#mi("\\chi")#text(" mentioned above; this is an extremely simple case of a much more general result known as ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’s theorem")]#text(", which I will not talk further about here.]")

#text("One elementary but very useful tool for estimating exponential sums is ")#emph[#text("Weyl’s differencing trick")]#text(", that ultimately rests on the humble ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(". One formulation of this trick can be phrased as the following inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text("(van der Corput inequality) Let ")#mi("a_1,a_2,\\ldots")#text(" be a sequence of complex numbers bounded in magnitude by 1. Then for any ")#mi("1 \\leq H \\leq N")#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\frac{1}{N} \\sum_{n=1}^N a_n \\right| \\ll (\\frac{1}{H} \\sum_{h=0}^{H -1}\\left|\\frac{1}{N} \\sum_{n=1}^N a_{n+h} \\overline{a_n}\\right| )^{1/2} + O( \\frac{H}{N} ).", block: true)]]
]

#strong[#text("Proof. ")]#text(" Observe that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N a_n = \\frac{1}{N} \\sum_{n=1}^N a_{n+h} + O( \\frac{H}{N})")]]

#text("for every ")#mi("0 \\leq h \\leq H-1")#text(". Averaging this in h we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N a_n = \\frac{1}{N} \\sum_{n=1}^N \\frac{1}{H} \\sum_{h=0}^{H-1} a_{n+h} + O( \\frac{H}{N})")]]

#text("and hence by the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{N} \\sum_{n=1}^N a_n\\right| \\leq (\\frac{1}{N} \\sum_{n=1}^N \\left|\\frac{1}{H} \\sum_{h=0}^{H-1} a_{n+h}\\right|^2)^{1/2} + O( \\frac{H}{N}).", block: true)]]

#text("Expanding out the square and rearranging a bit, we soon obtain the upper bound (3) (in fact one can sharpen the constants slightly here, though this will not be important for this discussion). ")#mi("\\Box")

#text("The significance of this inequality is that it replaces the task of bounding a sum of coefficients ")#mi("a_n")#text(" by that of bounding a sum of “differentiated” coefficients ")#mi("a_{n+h} \\overline{a_n}")#text(". This trick is thus useful in “polynomial” type situations when the differentiated coefficients are often simpler than the original coefficients. One particularly clean application of this inequality is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2. ")]#text("(Van der Corput’s difference theorem) Let ")#mi("(x_n)_{n=1}^\\infty")#text(" be a sequence in a torus ")#mi("{\\Bbb T}^d")#text(" such that the difference sequences ")#mi("(x_{n+h}-x_n)_{n=1}^\\infty")#text(" are equidistributed for every non-zero h. Then ")#mi("(x_n)_{n=1}^\\infty")#text(" is itself equidistributed.")
]

#strong[#text("Proof. ")]#text(" By Weyl’s equidistribution theorem, it suffices to show that (2) holds for every non-trivial character ")#mi("\\chi")#text(". But by Lemma 1, we can bound the magnitude of the left-hand side of (2) by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\ll (\\frac{1}{H} \\sum_{h=0}^{H -1}\\left|\\frac{1}{N} \\sum_{n=1}^N e^{2\\pi i \\chi(x_{n+h})} e^{-2\\pi i \\chi(x_n)}\\right| )^{1/2} + O( \\frac{H}{N} )", block: true)]]

#text("for any fixed H.")

#text("Now we use the fact that ")#mi("\\chi")#text(" is a character to simplify ")#mi("e^{2\\pi i \\chi(x_{n+h})} e^{-2\\pi i \\chi(x_n)}")#text(" as ")#mi("e^{2\\pi i \\chi(x_{n+h}-x_n)}")#text(". By hypothesis and the equidistribution theorem, the inner sum ")#mi("\\frac{1}{N} \\sum_{n=1}^N e^{2\\pi i \\chi(x_{n+h})} e^{-2\\pi i \\chi(x_n)}")#text(" goes to zero as ")#mi("N \\to \\infty")#text(" for any fixed non-zero h; when instead h is zero, this sum is of course just 1. We conclude that for fixed H, the expression (4) is bounded by O(1/H) in the limit ")#mi("N \\to \\infty")#text(". Thus the limit (or limit superior) of the magnitude of (2) is bounded in magnitude by O(1/H) for every H, and is thus zero. The claim follows. ")#mi("\\Box")

#text("By iterating this theorem, and using the observation that the difference sequence ")#mi("(P(n+h) - P(n))_{n=1}^\\infty")#text(" of a polynomial sequence ")#mi("(P(n))_{n=1}^\\infty")#text(" of degree d becomes a polynomial sequence of degree d-1 for any non-zero h, we can conclude by induction the following famous result of Weyl, generalising Corollary 1:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Equidistribution of polynomial sequences in torii) Let ")#mi("P: {\\Bbb Z} \\to {\\Bbb T}^d")#text(" be a polynomial sequence taking values in a torus. Then the sequence ")#mi("(P(n))_{n =1}^\\infty")#text(" is equidistributed in ")#mi("{\\Bbb T}^d")#text(" if and only if ")#mi("\\chi(P(\\cdot))")#text(" is non-constant for all non-zero characters ")#mi("\\chi")#text(".")
]

#text("In the one-dimensional case d=1, this theorem asserts that a polynomial ")#mi("P: {\\Bbb Z} \\to {\\Bbb R}")#text(" with real coefficients is equidistributed modulo one if and only if it has at least one irrational non-constant coefficient; thus for instance the sequence ")#mi("(\\pi n^3 + \\sqrt{2} n^2 + \\frac{1}{4} n \\text{ mod } 1)_{n=1}^\\infty")#text(" is equidistributed.")

#heading(level: 1)[#text("— A variant of the trick —")]

#text("It turns out that van der Corput’s difference theorem (Corollary 2) can be generalised to deal not just on torii, but on more general measure spaces with a torus action. Given a topological probability space ")#mi("(X,\\mu)")#text(" (which one should probably take to be a ")#link("http://en.wikipedia.org/wiki/Polish_space")[#text("Polish space")]#text(" to avoid various technicalities) and a sequence ")#mi("(x_n)_{n = 1}^\\infty")#text(" in X, we say that such a sequence is equidistributed with respect to ")#mi("\\mu")#text(" if we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N f(x_n) \\to \\int_X f\\ d\\mu")]]

#text("for all continuous compactly supported functions ")#mi("f: X \\to {\\Bbb C}")#text(". This clearly generalises the previous notion of equidistribution, in which X was a torus and ")#mi("\\mu")#text(" was uniform probability measure.")

#text("To motivate our generalised version of Corollary 2, we observe that the hypothesis “the sequence ")#mi("(x_{n+h}-x_n)_{n=1}^\\infty")#text(" is equidistributed in ")#mi("{\\Bbb T}^d")#text("” can be phrased in a more dynamical fashion (eliminating the subtraction operation, which is algebraic) as the equivalent assertion that the sequence of pairs ")#mi("((x_{n+h},x_n))_{n=1}^\\infty")#text(" in ")#mi("{\\Bbb T}^d \\times {\\Bbb T}^d")#text(", after quotienting out by the action of the diagonal subgroup ")#mi("({\\Bbb T})^d)^\\Delta := \\{ (y, y): y \\in {\\Bbb T}^d \\}")#text(", becomes equidistributed on the ")#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("quotient space")]#text(" ")#mi("{\\Bbb T}^d \\times {\\Bbb T}^d / ({\\Bbb T})^d)^\\Delta")#text(". This convoluted reformulation is necessary for generalisations, in which we do not have a good notion of subtraction, but we still have a good notion of group action and quotient spaces.")

#text("We can now prove")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Generalised van der Corput difference theorem) Let ")#mi("(X,\\mu)")#text(" be a (Polish) probability space with a continuous (right-)action of a torus ")#mi("{\\Bbb T}^d")#text(", and let ")#mi("\\pi: X \\to X/{\\Bbb T}^d")#text(" be the projection map onto the quotient space (which then has the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward measure")]#text(" ")#mi("\\pi_* \\mu")#text(". Let ")#mi("(x_n)_{n = 1}^\\infty")#text(" be a sequence in X obeying the following properties:")

#enum(start: 1, 
[#text("(Horizontal equidistribution) The projected sequence ")#mi("(\\pi(x_n))_{n =1}^\\infty")#text(" in ")#mi("X/{\\Bbb T}^d")#text(" is equidistributed with respect to ")#mi("\\pi_* \\mu")#text(".")],
[#text("(Vertical differenced equidistribution) For every non-zero h, the sequence ")#mi("( (x_{n+h},x_n) ({\\Bbb T}^d)^\\Delta )_{n=1}^\\infty")#text(" in the quotiented product space ")#mi("(X \\times X)/({\\Bbb T}^d)^\\Delta")#text(" is equidistributed with respect to some measure ")#mi("\\nu_h")#text(" which is invariant under the action of the torus ")#mi("{\\Bbb T}^d \\times {\\Bbb T}^d / ({\\Bbb T}^d)^\\Delta")#text(".")]
)

#text("Then ")#mi("(x_n)_{n=1}^\\infty")#text(" is equidistributed with respect to ")#mi("\\mu")#text(".")
]

#text("Note that Corollary 2 is the special case of Proposition 1 in which X is itself the torus ")#mi("{\\Bbb T}^d")#text(" with the usual translation action and uniform measure (so that the quotient space is a point).")

#strong[#text("Proof.")]#text(" We need to verify the property (1). If the function f was invariant under the action of the torus ")#mi("{\\Bbb T}^d")#text(", then we could push it down to the quotient space ")#mi("X/{\\Bbb T}^d")#text(" and the claim would follow from hypothesis 1. We may therefore subtract off the invariant component ")#mi("\\int_{{\\Bbb T}^d} f(\\cdot y)\\ dy")#text(" from our function and assume instead that f has zero vertical mean in the sense that ")#mi("\\int_{{\\Bbb T}^d} f(x y)\\ dy = 0")#text(" for all x. A Fourier expansion in the vertical variable (or the Weierstrass approximation theorem) then allows us to reduce to the case when f has a ")#emph[#text("vertical frequency")]#text(" given by some non-zero character ")#mi("\\chi: {\\Bbb T}^d \\to {\\Bbb T}")#text(" of the torus, in the sense that ")#mi("f(xy) = f(x) e^{2\\pi i \\chi(y)}")#text(" for all ")#mi("x \\in X")#text(" and ")#mi("y \\in {\\Bbb T}^d")#text(".")

#text("Now we apply van der Corput’s inequality as in the proof of Corollary 2. Using these arguments, we find that it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N f(x_{n+h}) \\overline{f(x_n)} \\to 0")]]

#text("for each non-zero h. But the summand here is just the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" function ")#mi("f \\otimes \\overline{f}: X \\times X \\to {\\Bbb C}")#text(" applied to the pair ")#mi("(x_{n+h},x_n)")#text(". The fact that f has a vertical frequency implies that ")#mi("f \\otimes \\overline{f}")#text(" is invariant with respect to the diagonal action ")#mi("({\\Bbb T}^d)^\\Delta")#text(", and thus this function descends to the quotient space ")#mi("(X \\times X)/({\\Bbb T}^d)^\\Delta")#text(". On the other hand, as the vertical frequency is non-trivial, the latter function also has zero mean on every orbit of ")#mi("{\\Bbb T}^d \\times {\\Bbb T}^d / ({\\Bbb T}^d)^\\Delta")#text(" and thus vanishes when integrated against ")#mi("\\nu_h")#text(". The claim then follows from hypothesis 2. ")#mi("\\Box")

#text("As an application, let us prove the following result, first established ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("by (Leon) Green")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Equidistribution of linear sequences in nilmanifolds) Let ")#mi("G/\\Gamma")#text(" be a ")#link("http://en.wikipedia.org/wiki/Nilmanifold")[#text("nilmanifold")]#text(" (where we take the nilpotent group G to be connected for simplicity, although this is not strictly necessary), and let ")#mi("g \\in G")#text(" and ")#mi("x \\in G/\\Gamma")#text(". Then ")#mi("(g^n x)_{n=1}^\\infty")#text(" is equidistributed with respect to Haar measure on ")#mi("G/\\Gamma")#text(" if and only if ")#mi("\\chi(g^n x)")#text(" is non-constant in n for every non-trivial ")#emph[#text("horizontal character")]#text(" ")#mi("\\chi: G/\\Gamma \\to {\\Bbb T}")#text(", where a horizontal character is any continuous homomorphism ")#mi("\\chi: G \\to {\\Bbb T}")#text(" that vanishes on ")#mi("\\Gamma")#text(" (and thus descends to ")#mi("G/\\Gamma")#text(").")
]

#text("This statement happens to contain Weyl’s result (Theorem 1) as a special case, because polynomial sequences can be encoded as linear sequences in nilmanifolds; but it is actually stronger, allowing extensions to generalised polynomials that involve the ")#link("http://en.wikipedia.org/wiki/Floor_function")[#text("floor function")]#text(" ")#mi("\\lfloor \\cdot \\rfloor")#text(" or the fractional part function ")#mi("\\{ \\}")#text(". For instance, if we take")

#align(center)[#tao-fit-display[#mitex("G := \\begin{pmatrix} 1 & {\\Bbb R} & {\\Bbb R} \\\\ 0 & 1 & {\\Bbb R} \\\\ 0 & 0 & 1 \\end{pmatrix}; \\Gamma := \\begin{pmatrix} 1 & {\\Bbb Z} & {\\Bbb Z} \\\\ 0 & 1 & {\\Bbb Z} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g := \\begin{pmatrix} 1 & \\alpha & \\beta \\\\ 0 & 1 & \\gamma \\\\ 0 & 0 & 1 \\end{pmatrix}; x = \\Gamma")]]

#text("for some real numbers ")#mi("\\alpha,\\beta,\\gamma")#text(" then a computation shows that")

#align(center)[#tao-fit-display[#mitex("g^n x = \\begin{pmatrix} 1 & \\{\\alpha n\\} & \\{ \\beta n + \\alpha \\frac{n(n-1)}{2} - \\{ \\alpha n \\} \\lfloor \\gamma n \\rfloor \\} \\\\ 0 & 1 & \\{ \\gamma n \\} \\\\ 0 & 0 & 1 \\end{pmatrix} \\Gamma")]]

#text("and then Green’s theorem asserts that the triple")

#align(center)[#tao-fit-display[#mitex("( \\{ \\alpha n\\}, \\{ \\beta n + \\alpha \\frac{n(n-1)}{2} - \\{ \\alpha n \\} \\lfloor \\gamma n \\rfloor \\}, \\{ \\gamma n \\} )")]]

#text("is equidistributed in the unit cube ")#mi("{}[0,1]^3")#text(" if and only if the pair ")#mi("(\\alpha, \\gamma)")#text(" is totally irrational (the rationality of ")#mi("\\beta")#text(" turns out to be irrelevant). Even for concrete values such as ")#mi("\\alpha = \\sqrt{2}, \\beta = 0, \\gamma = \\sqrt{3}")#text(", it is not obvious how to establish this fact directly; for instance a direct application of Corollary 2 does not obviously simplify the situation.")

#strong[#text("Proof of Theorem 2. ")]#text("(Sketch) It is clear that if ")#mi("\\chi(g^n x)")#text(" is constant for some non-trivial character, then the orbit ")#mi("g^n x")#text(" is trapped on a level set of ")#mi("\\chi")#text(" and thus cannot equidistribute. Conversely, suppose that ")#mi("\\chi(g^n x)")#text(" is never constant. We induct on the step s of the nilmanifold. The case s=0 is trivial, and the case s=1 follows from Corollary 1, so suppose inductively that ")#mi("s \\geq 2")#text(" and that the claim has already been proven for smaller s. We then look at the vertical torus ")#mi("G_s / (\\Gamma \\cap G_s) \\equiv {\\Bbb T}^d")#text(", where ")#mi("G_s")#text(" is the last non-trivial group in the ")#link("http://en.wikipedia.org/wiki/Lower_central_series#Lower_central_series")[#text("lower central series")]#text(" (and thus ")#link("http://en.wikipedia.org/wiki/Central_subgroup")[#text("central")]#text("). The quotient of the nilmanifold ")#mi("G/\\Gamma")#text(" by this torus action turns out to be a nilmanifold of one lower step (in which G is replaced by ")#mi("G/G_s")#text(") and so the projection of the orbit ")#mi("(g^n x)_{n=1}^\\infty")#text(" is then equidistributed by induction hypothesis. Applying Proposition 1, it thus suffices to check that for each non-zero h, the sequence of pairs ")#mi("(g^{n+h} x, g^n x)")#text(" in ")#mi("G/\\Gamma \\times G/\\Gamma")#text(", after quotienting out by the diagonal action of the torus, is equidistributed with respect to some measure which is invariant under the residual torus ")#mi("{\\Bbb T}^d \\times {\\Bbb T}^d / ({\\Bbb T}^d)^\\Delta")#text(".")

#text("We first pass to the ")#link("http://en.wikipedia.org/wiki/Abelianization#Abelianization")[#text("abelianisation")]#text(" (or ")#emph[#text("horizontal torus")]#text(") ")#mi("G/G_2 \\Gamma")#text(" of the nilmanifold, and observe that the projections ")#mi("\\pi(g^{n+h} x), \\pi(g^n x)")#text(" of the coefficients of the pair ")#mi("(g^{n+h} x, g^n x)")#text(" to this torus only differ by a constant ")#mi("\\pi(g^h)")#text(". Thus the pair ")#mi("(g^{n+h} x, g^n x)")#text(" does not range freely in ")#mi("G/\\Gamma \\times G/\\Gamma")#text(", but is instead constrained to a translate of a smaller nilmanifold ")#mi("G/\\Gamma \\times_\\pi G/\\Gamma")#text(", defined as the space of pairs (x,y) with ")#mi("\\pi(x)=\\pi(y)")#text(". After quotienting out also by the diagonal vertical torus, we obtain a nilmanifold coming from the group ")#mi("(G \\times_{G_2} G) / G_s^\\Delta")#text(", where ")#mi("G \\times_{G_2} G")#text(" is the space of pairs ")#mi("(g,h)")#text(" of group elements ")#mi("g,h \\in G")#text(" whose projections to the abelianisation ")#mi("G/G_2")#text(" agree, and ")#mi("G_s^\\Delta := \\{ (g_s,g_s): g_s \\in G_s \\}")#text(" is the vertical diagonal group. But a short computation shows that this new group is at most s-1 step nilpotent. One can then apply the induction hypothesis to show the required equidistribution properties of ")#mi("(x_{n+h},x_n)")#text(", thus closing the induction by Proposition 1. [UPDATE, Feb 2013: This doesn’t work in all cases, because sometimes the orbit ")#mi("(g^{n+h} x, g^n x)")#text(" is not equidistributed in the abelianisation of this nilmanifold.] ")#mi("\\Box")

#text("There are many further generalisations of these results, including a polynomial version of Theorem 2 due ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("to Leibman")]#text(" (that also permits G to be disconnected), and quantitative versions of all of these results in ")#link("http://arxiv.org/abs/0709.3562")[#text("my paper with Ben Green")]#text(" that I discuss in my ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("earlier blog post")]#text(".")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-30391")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("It’s a nitpick, but the statement of corollary 2 isn’t parsing correctly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-30395")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lectures II, “Linear equations in primes” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-33572")[#strong[#text("Marker lectures II, “Linear equations in primes” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2008")])]

#text("[…] turns out to be somewhat unpleasant; the standard technology of Weyl differencing and the van der Corput lemma eventually works (see this paper of Ben Green and myself), but does not scale well to bracket […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-42001")[#strong[#text("ERT2: Polynomial Von Neumann’s Theorem « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")]

#text("[…] true, by the induction hypothesis). This is done with the use of Van der Corput’s Trick (see this lecture of Terry Tao for a broader discussion on this trick). Theorem 3 (Van der Corput Trick) If is a bounded sequence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-43767")[#strong[#text("ERT9: Weak Mixing implies Weak Mixing of all orders « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")]

#text("[…] van der Corput trick allows an inductive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aec19de3251f677275a11b0fcdab5eafc48153ec481a092f49b6b1cd55a85b7-8a7161f1bc3c05df6ee87bc37f0e81ce811f8054ab6da7d2d1c10675374e31cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilotpal Sinha")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-47822")[#strong[#text("Nilotpal Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("A remark on Corollary 1.")

#text("Reading this post reminded me of an old observation of mine of which I thought would be fit to share in this post on equidistribution.")

#text("Let u(n) be any sequence such that for every in (0,1), u(nt) ~ t u(n). If α is any real such that αu(n) and n are linearly independent then the sequence αu(n) is equidistributed mod 1.")

#text("Applications:")

#text("Eg 1. Take u(n) = n and α irrational. Then the above remark implies that the sequence αn is equidistributed mod 1. This was the original equidistribution theorem of Weyl in 1909.")

#text("Eg 2. Take u(n) = p(n) where p(n) is the n-th prime. Then our remark implies that the sequence α p(n) is equidistributed mod 1. This was the result of I.M. Vinogradov, 1935.")

#text("Taking advantage of the liner independence condition in the remark, we have have similar results for rational numbers too.")

#text("Eg 3. Taking α = 1 and u(n) ~ 2Πn/log(n) we see that the imaginary parts of the non-trivial zeta zeros are equidistributed mod 1. This was the result of Hlawka.")

#text("In short the remark looks very powerful and if applied in the right places, it can yield many interesting results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-185900")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] for . (We will see why these particular functions arise in the argument shortly.) The key step in proving Theorem 8 is then the following result, reminiscent of the van der Corput lemma in ergodic theory (see e.g. this blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-247209")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Dear Prof Tao,")

#text("I’m trying to understand the proof of Theorem 2, whether the sketch you give here or a proof in the literature somewhere. I thought I understood the proof until I read your update from Feb 2013. It suffices to check that ")#mi("(g^n x, g^n x)")#text(" equidistributes in the nilmanifold coming from ")#mi("(G\\times_{G_2} G)/G_s^\\Delta")#text(": it would then follow that ")#mi("(g^{n+h}x,g^n x)")#text(" is equidistributed in a translate of this nilmanifold. Since this nilmanifold has step ")#mi("s-1")#text(", if this fails it follows by induction that there is a nontrivial horizontal character ")#mi("\\chi")#text(" of ")#mi("(G\\times_{G_2} G)/G_s^\\Delta")#text(" such that ")#mi("\\chi(g^n x, g^n x)")#text(" is constant. But then by precomposing with the diagonal embedding ")#mi("\\Delta:G\\to G\\times_{G_2} G")#text(" we get a nontrivial character ")#mi("\\chi\\circ\\Delta")#text(" of ")#mi("G")#text(" such that ")#mi("\\chi(\\Delta(g^n x))")#text(" is constant, contradicting our hypothesis. Doesn’t this work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-247218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Unfortunately, the non-triviality of ")#mi("\\chi")#text(" does not imply the non-triviality of ")#mi("\\chi \\circ \\Delta")#text(",and in any event ")#mi("(g^n x, g^n x)")#text(" is clearly trapped in the diagonal ")#mi("\\Delta(G)/G_s^\\Delta")#text(" of ")#mi("G \\times_{G_2} G / G_s^\\Delta")#text(" and so cannot equidistribute. (A similar problem was pointed out to me by Pavel Zorin in ")#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-217771")[#text("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/#comment-217771")]#text(" , which prompted the above correction.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-247225")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("I see. The point that was getting me is that ")#mi("G\\times_{G_2} G/G_s^\\Delta")#text(" typically has abelianisation larger than just ")#mi("G/G_2")#text(". Where is the best place to find the missing details?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-247226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("Unfortunately I do not know of a quick way to make the strategy outlined in this blog post to work in full generality; one either has to work in a fully quantitative setting (as in my paper with Ben, ")#link("http://arxiv.org/abs/0709.3562")[#text("http://arxiv.org/abs/0709.3562")]#text(" ) or else work in an ergodic theory setting (taking full advantage of the ergodic theorem) as in the original paper of Leibman, ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("http://www.ams.org/mathscinet-getitem?mr=2122919")]#text(" .")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7623bac5d45f2d15d00486e34c76dbe92a014639fb1d263bedd661765c0a781e-fbe1da168dfd7c1e14aa47d82f0a3c5b092b5d34a47988fe33410d6796c4870c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cyril")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-383528")[#strong[#text("Cyril")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2014")])]

#text("Hello. I am a beginner in the theory you are dealing with. However I think there is a link with an old problem I have for a long time:")

#text("Is the sequence ")#mi("\\left(\\sum_{k=0}^n\\cos(k^2)\\right)_n")#text(" bounded ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-383968")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2014")])]

#text("No, it is unbounded. If it were bounded, then the sequence ")#tao-math("n \\mapsto \\left|\\sum_{k=0}^K \\cos( (n+k)^2 )\\right|^2", block: false)#text(" would be bounded uniformly in ")#mi("K")#text(", but from Weyl’s theorem and the irrationality of ")#mi("\\pi")#text(", the asymptotic mean of this sequence is comparable to ")#mi("K")#text(", a contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7623bac5d45f2d15d00486e34c76dbe92a014639fb1d263bedd661765c0a781e-fbe1da168dfd7c1e14aa47d82f0a3c5b092b5d34a47988fe33410d6796c4870c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cyril")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384180")[#strong[#text("Cyril")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2014")])]

#text("Thank you very much but I don’t really understand. Can you give me a link to the Weyl’s theorem you are talking about ?")#linebreak()#text(" When you say “bounded uniformly in K” you mean that it exists a constant C such that for all K, for all n, the sequence is bounded by C ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384547")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Yes.")

#text("Weyl’s theorem can be found for instance in Corollary 6 of my notes ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")]#text(" . The point is that when one expands out the square in the indicated sequence in terms of complex exponentials, one gets terms such as ")#mi("e( \\frac{1}{2\\pi} ( (n+k)^2 - (n+k^{\\prime})^2) )")#text(" for various ")#mi("k,k^{\\prime}")#text(". For ")#mi("k \\neq k^{\\prime}")#text(", the phase here contains an irrational nonconstant coefficient and so has asymptotic mean zero in n. If one worked with ")#mi("\\cos(k)")#text(" instead of ")#mi("\\cos(k^2)")#text(" then ")#mi("e( \\frac{1}{2\\pi} ( (n+k) - (n+k^{\\prime})) )")#text(" would instead be constant in ")#mi("n")#text(" and Weyl’s theorem would not apply.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7623bac5d45f2d15d00486e34c76dbe92a014639fb1d263bedd661765c0a781e-fbe1da168dfd7c1e14aa47d82f0a3c5b092b5d34a47988fe33410d6796c4870c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cyril")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384555")[#strong[#text("Cyril")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Ouawww I got it !!!! Thank you very much ! I love this trick.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384651")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Thanks! I expected this question to be much more difficult – because it seems related to the complicated behavior of the (theta) function")

#mi("\\varphi (q) := 1 + 2 \\sum_{k \\geq 1} q^{k^2}")#text(" , ")#tao-math("\\left|q\\right| < 1", block: false)

#text("near the irrational point ")#mi("e^i")#text(" on the unit circle – its natural boundary!")

#text("The function ")#mi("\\varphi (q)")#text(" (defined e.g. in page 36, Entry 22(i) in Berndt's book \"Ramanujan Notebooks\" Part III, 1991)")

#text("From the proof of Entry 23(i) (page 38 in this book) it follows that")

#mi("\\varphi (-q) = \\prod _{k \\geq 1} \\frac {1-q^k}{1+q^k}")

#mi("= \\frac {F(q^2)}{F(q)^2}")

#text("Where ")#mi("F(q) := \\prod _{k \\geq 1} (1-q^k)^{-1}")#text(" is the generating function for the partition function ")#mi("p(n)")#text(".")

#text("Therefore, ")#mi("\\varphi (q)")#text(" behavior near the unit circle may be studied via the well known complicated behavior of ")#mi("F(q)")#text(" there (in particular, it follows that ")#mi("\\varphi (q)")#text(" has the unit circle as its natural boundary!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384439")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("It is not clear why this argument is working for ")#mi("\\cos (k^2)")#text(" but not for ")#mi("\\cos k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7623bac5d45f2d15d00486e34c76dbe92a014639fb1d263bedd661765c0a781e-fbe1da168dfd7c1e14aa47d82f0a3c5b092b5d34a47988fe33410d6796c4870c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cyril")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-384453")[#strong[#text("Cyril")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("That’s why I’m asking the reference of the theorem.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-385066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2014")])]

#text("In your paper, I think there is a typo in line 2 in the introduction. Shouldn’t it be “role” rather than “rôle”? (English is not my first language.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-385142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2014")])]

#text("I see that I’m wrong. (Please delete this and the previous comment.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-459654")[#strong[#text("Frogs and Lily Pads and Discrepancy | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] The connection with products of the form is analyzed by an old trick which Tao once discussed here. There is finally an important use of Andrew Granville’s notion of pretending, which we once […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0dd54fb945d9f86052786c7bac3798620f0de5c0476f85bc7252ee4577a3f29e-71d380840887664c9e6dc9c08f432053c3e94efd7ab789adc5efc0f3a9e81248.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-486250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2017")])]

#text("Dear Prof. Tao,")

#text("I am trying to understand the proof of Proposition 1. I got stuck in the first part of the proof, where you claim that we can assume the continuous function ")#mi("f")#text(" has the property that ")#mi("f(xy) = f(x) e^{2\\pi i \\chi(y)}")#text(" for all ")#mi("x \\in X")#text(" and ")#mi("y \\in {\\Bbb T}^d")#text(", where ")#mi("\\chi")#text(" is some non-zero character of the torus. I assume this is true because functions of this kind generate an algebra that separates points and hence, by Stone-Weierstrass (like you suggested in the proof), this algebra is dense in ")#mi("C(X)")#text(". However, I am stuck on proving that this family actually separates points. Can you please clarify the argument that I am missing here. Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-486252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2017")])]

#text("If ")#mi("x_1,x_2")#text(" do not lie in the same ")#mi("{\\mathbb T}^d")#text("-orbit, one can take a bump function ")#mi("\\phi")#text(" supported in a small neighbourhood of ")#mi("x_1")#text(" and average it along the action to obtain a suitable function ")#mi("\\int_{{\\mathbb T}^d}\\phi(xy)\\ dy")#text(" to separate ")#mi("x_1,x_2")#text(". If instead ")#mi("x_2")#text(" lies in the orbit of ")#mi("x_1")#text(", then the set ")#mi("\\{ y \\in {\\mathbb T}^d: x_2 = x_1 y \\}")#text(" is a non-trivial coset ")#mi("y_0 + H")#text(" of some closed subgroup ")#mi("H")#text(" of ")#mi("{\\mathbb T}^d")#text(". One can then locate a frequency ")#mi("k \\in {\\mathbb Z}^d")#text(" which annihilates ")#mi("H")#text(" but not ")#mi("y_0")#text(" (because the characters on ")#mi("{\\mathbb T}^d/H")#text(" separate points, by Plancherel’s theorem), and then the modulated average ")#mi("\\int_{{\\mathbb T}^d} \\phi(xy) e(k \\cdot y)\\ dy")#text(" will work if the support of ")#mi("\\phi")#text(" is small enough.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/#comment-687008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2025")])]

#text("For a particular problem coming from information theory I was asked to check your paper ")#link("https://arxiv.org/pdf/0709.3562")[#text("0709.3562")]#text(" for “quantitative (or effective) equidistribution,” (in particular Theorem 1.16 (Quantitative Leibman theorem)). What background do I need to build to this level? My background is in Electrical Engineering and taken engineering versions of Fourier transforms. Essentially I was told to convert 1.16 to statement about sequences being dense in the torus. Thank you.")
]
