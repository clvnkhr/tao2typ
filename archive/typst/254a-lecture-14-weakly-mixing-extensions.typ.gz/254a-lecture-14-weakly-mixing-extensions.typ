// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/
// Converted to Typst by tao2typ: "2026-10-14T06:56:50.797459+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 14: Weakly mixing extensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 14: Weakly mixing extensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/")[#text("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Having studied compact extensions in the ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("previous lecture")]#text(", we now consider the opposite type of extension, namely that of a ")#emph[#text("weakly mixing extension")]#text(". Just as compact extensions are “relative” versions of ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("compact systems")]#text(", weakly mixing extensions are “relative” versions of ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("weakly mixing systems")]#text(", in which the underlying algebra of scalars ")#mi("{\\Bbb C}")#text(" is replaced by ")#mi("L^\\infty(Y)")#text(". As in the case of unconditionally weakly mixing systems, we will be able to use the van der Corput lemma to neglect “conditionally weakly mixing” functions, thus allowing us to lift the uniform multiple recurrence property (UMR) from a system to any weakly mixing extension of that system.")

#text("To finish the proof of the Furstenberg recurrence theorem requires two more steps. One is a relative version of the dichotomy between mixing and compactness: if a system is not weakly mixing relative to some factor, then that factor has a non-trivial compact extension. This will be accomplished using the theory of conditional Hilbert-Schmidt operators in this lecture. Finally, we need the (easy) result that the UMR property is preserved under limits of chains; this will be accomplished in the next lecture.")

#metadata(none) <tao-2c86b35f34b5f9a0a121>

#heading(level: 1)[#text("— Conditionally weakly mixing functions —")]

#text("Recall that in a measure-preserving system ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(", a function ")#mi("f \\in L^2(X) = L^2(X,{\\mathcal X},\\mu)")#text(" is said to be ")#emph[#text("weakly mixing")]#text(" if the squared inner products ")#tao-math("\\left|\\langle T^n f, f \\rangle_X\\right|^2 := (\\int_X T^n f \\overline{f}\\ d\\mu)^2", block: false)#text(" converge in the Cesàro sense, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\left|\\int_X T^n f \\overline{f}\\ d\\mu\\right|^2 = 0.", block: true)]]

#text("Now let ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(" be a factor of X, so that ")#mi("L^\\infty(Y)")#text(" can be viewed as a subspace of ")#mi("L^\\infty(X)")#text(". Recall that we have the conditional inner product ")#mi("\\langle f, g \\rangle_{X|Y} := {\\Bbb E}( f \\overline{g}|Y)")#text(" and the Hilbert module ")#mi("L^2(X|Y)")#text(" of functions f for which ")#mi("\\langle f, f \\rangle_{X|Y}")#text(" lies in ")#mi("L^\\infty(Y)")#text(". We shall say that a function ")#mi("f \\in L^2(X|Y)")#text(" is ")#emph[#text("conditionally weakly mixing")]#text(" relative to Y if the ")#mi("L^2")#text(" norms ")#tao-math("\\left\\|\\langle T^n f, f \\rangle_{X|Y}\\right\\|_{L^2(Y)}^2", block: false)#text(" converge to zero in the Cesàro sense, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X \\left|{\\Bbb E}(T^n f \\overline{f}|Y)\\right|^2\\ d\\mu = 0.", block: true)]]

#strong[#text("Example 1. ")]#text("If ")#mi("X = Y \\times Z")#text(" is a product system of the factor space ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(" and another system ")#mi("Z = (Z, {\\mathcal Z}, \\rho, R)")#text(", then a function ")#mi("f(y,z) = f(z)")#text(" of the vertical variable ")#mi("z \\in Z")#text(" is weakly mixing relative to Y if and only if f(z) is weakly mixing in Z. ")#mi("\\diamond")

#text("Much of the theory of weakly mixing systems extends easily to the conditionally weakly mixing case. For instance:")

#strong[#text("Exercise 1.")]#text(" By adapting the proof of Corollary 2 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(", show that if ")#mi("f \\in L^2(X|Y)")#text(" is conditionally weakly mixing and ")#mi("g \\in L^2(X|Y)")#text(", then ")#tao-math("\\left\\|\\langle T^n f, g \\rangle_{X|Y}\\right\\|_{L^2(Y)}^2", block: false)#text(" and ")#tao-math("\\left\\|\\langle f, T^n g \\rangle_{X|Y}\\right\\|_{L^2(Y)}^2", block: false)#text(" converge to zero in the Cesàro sense. (")#emph[#text("Hint")]#text(": you will need to show that expressions such as ")#mi("\\langle g, T^n f \\rangle_{X|Y} T^n f")#text(" converge in ")#mi("L^2(X)")#text(" in the Cesàro sense. Apply the van der Corput lemma and use the fact that ")#mi("\\langle g, T^n f \\rangle_{X|Y}")#text(" are uniformly bounded in ")#mi("L^\\infty(Y)")#text(" by conditional Cauchy-Schwarz.) ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Show that the space of conditionally weakly mixing functions in ")#mi("L^2(X|Y)")#text(" is a module over ")#mi("L^\\infty(Y)")#text(" (i.e. it is closed under addition and multiplication by the “scalars” ")#mi("L^\\infty(Y)")#text("), which is also shift-invariant and topologically closed in the topology of ")#mi("L^2(X|Y)")#text(" (see Exercise 2 from ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("Lecture 13")]#text("). ")#mi("\\diamond")

#text("Let us now see the first link between conditional weak mixing and conditional almost periodicity (cf. Exercise 18 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" If ")#mi("f \\in L^2(X|Y)")#text(" is conditionally weakly mixing and ")#mi("g \\in L^2(X|Y)")#text(" is conditionally almost periodic, then ")#mi("\\langle f, g \\rangle_{X|Y} = 0")#text(" a.e.")
]

#strong[#text("Proof.")]#text(" Since ")#mi("\\langle f,g \\rangle_{X|Y} = T^{-n} \\langle T^n f, T^n g \\rangle_{X|Y}")#text(", it will suffice to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("C\\!-\\!\\sup_{n \\to \\infty} \\left\\|\\langle T^n f, T^n g \\rangle_{X|Y}\\right\\|_{L^2(Y)} = 0.", block: true)]]

#text("Let ")#mi("\\varepsilon > 0")#text(" be arbitrary. As g is conditionally almost periodic, one can find a finitely generated module zonotope ")#tao-math("\\{ c_1 f_1 + \\ldots + c_d f_d: \\left\\| c_1\\right\\|_{L^\\infty(Y)},\\ldots,\\left\\|c_d\\right\\|_{L^\\infty(Y)} \\leq 1 \\}", block: false)#text(" with ")#mi("f_1,\\ldots,f_d \\in L^2(X|Y)")#text(" such that all the shifts ")#mi("T^n g")#text(" lie within ")#mi("\\varepsilon")#text(" (in ")#mi("L^2(X|Y)")#text(") of this zonotope. Thus (by conditional Cauchy-Schwarz) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| \\langle T^n f, T^n g \\rangle_{X|Y} \\right\\|_{L^2(Y)} = \\left\\| \\langle T^n f, c_{1,n} f_1 + \\ldots + c_{d,n} f_d \\rangle_{X|Y} \\right\\|_{L^2(Y)} + O(\\varepsilon)", block: true)]]

#text("for all n and some ")#mi("c_{1,n},\\ldots,c_{d,n} \\in L^\\infty(Y)")#text(" with norm at most 1. We can pull these constants out of the conditional inner product and bound the left-hand side of (4) by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|\\langle T^n f, f_1 \\rangle_{X|Y}\\right\\|_{L^2(Y)} + \\ldots + \\left\\| \\langle T^n f, f_1 \\rangle_{X|Y}\\right\\|_{L^2(Y)} + O(\\varepsilon).", block: true)]]

#text("By Exercise 1, the Cesàro supremum of (5) is at most ")#mi("O(\\varepsilon)")#text(". Since ")#mi("\\varepsilon")#text(" is arbitrary, the claim (3) follows. ")#mi("\\Box")

#text("Since all functions in ")#mi("L^\\infty(Y)")#text(" are conditionally almost periodic, we conclude that every conditionally weakly mixing function f is orthogonal to ")#mi("L^\\infty(Y)")#text(", or equivalently that ")#mi("{\\Bbb E}(f|Y) = 0")#text(" a.e. Let us say that f has relative mean zero if the latter holds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1. ")]#text("A system X is a ")#emph[#text("weakly mixing extension")]#text(" of a factor Y if every ")#mi("f \\in L^2(X|Y)")#text(" with relative mean zero is relatively weakly mixing.")
]

#strong[#text("Exercise 3.")]#text(" Show that a product ")#mi("X=Y \\times Z")#text(" of a system Y with a weakly mixing system Z is always a weakly mixing extension of Y. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" If X is regular, then we can disintegrate the measure ")#mi("\\mu")#text(" as an average ")#mi("\\mu = \\int_Y \\mu_y d\\nu(y)")#text(", see Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(". It is then possible to construct a relative product system ")#mi("X \\times_Y X")#text(", which is the product system ")#mi("X \\times X")#text(" but with the measure ")#mi("\\mu \\times_\\nu \\mu := \\int_Y \\mu_y \\times \\mu_y d\\nu(y)")#text(" instead of ")#mi("\\mu \\times \\mu")#text(". It can then be shown (cf. Exercise 9 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(") that X is a weakly mixing extension of Y if and only if ")#mi("X \\times_Y X")#text(" is ergodic; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("Furstenberg’s book")]#text(" for details. However, in these notes we shall focus instead on the more abstract operator-algebraic approach which avoids the use of disintegrations. ")#mi("\\diamond")

#text("Now we show that the uniform multiple recurrence property (UMR) from ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("Lecture 13")]#text(" is preserved under weakly mixing extensions (cf. Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("Lecture 13")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("Suppose that ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is a weakly mixing extension of ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(". If Y obeys UMR, then so does X.")
]

#text("The proof of this theorem rests on the following analogue of Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("Let ")#mi("a_1,\\ldots,a_k \\in \\Bbb Z")#text(" be distinct integers for some ")#mi("k \\geq 1")#text(". Let ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is a weakly mixing extension of ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(", and let ")#mi("f_1,\\ldots,f_k \\in L^\\infty(X)")#text(" be such that at least one of ")#mi("f_1,\\ldots,f_k")#text(" has relative mean zero. Then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("C\\!-\\!\\lim_{n \\to \\infty} T^{a_1 n} f_1 \\ldots T^{a_k n} f_k = 0")]]

#text("in ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(".")
]

#strong[#text("Exercise 4.")]#text(" Prove Proposition 1. (")#emph[#text("Hint")]#text(": modify (or “relativise”) the proof of Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(".) ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("Let ")#mi("a_1,\\ldots,a_k \\in {\\Bbb Z}")#text(" be distinct integers for some ")#mi("k \\geq 1")#text(". Let ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is a weakly mixing extension of ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(", and let ")#mi("f_1,\\ldots,f_k \\in L^\\infty(X)")#text(". Then")

#align(center)[#tao-fit-display[#mitex("C\\!-\\!\\lim_{n \\to \\infty} \\int_X T^{a_1 n} f_1 \\ldots T^{a_k n} f_k\\ d\\mu")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("- \\int_X T^{a_1 n} {\\Bbb E}(f_1|Y) \\ldots T^{a_k n} {\\Bbb E}(f_k|Y)\\ d\\mu = 0.")]]
]

#strong[#text("Exercise 5.")]#text(" Prove Corollary 1. (Hint: adapt the proof of Corollary 2 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-26556")[#text("Lecture 12")]#text(".) ")#mi("\\diamond")

#strong[#text("Proof of Theorem 1. ")]#text("Let ")#mi("f \\in L^\\infty(X)")#text(" be non-negative with positive mean. Then ")#mi("{\\Bbb E}(f|Y) \\in L^\\infty(Y)")#text(" is also non-negative with positive mean. Since Y obeys UMR, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} {\\Bbb E}(f|Y) T^n {\\Bbb E}(f|Y) \\ldots T^{(k-1) n} {\\Bbb E}(f|Y) > 0.")]]

#text("Applying Corollary 1 we see that the same statement holds with ")#mi("{\\Bbb E}(f|Y)")#text(" replaced by f, and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 2.")]#text(" As the above proof shows, Corollary 1 lets us replace functions in the weakly mixing extension X by their expectations in Y for the purposes of computing k-fold averages. In the notation ")#link("http://www.ams.org/mathscinet-getitem?mr=1412607")[#text("of Furstenberg and Weiss")]#text(", Corollary 1 asserts that Y is a ")#emph[#text("characteristic factor")]#text(" of X for the average (7). The deeper structural theory of such characteristic factors (and in particular, on the minimal characteristic factor for any given average) is an active and difficult area of research, with surprising connections with Lie group actions (and in particular with flows on nilmanifolds), as well as the theory of inverse problems in additive combinatorics (and in particular to inverse theorems for the Gowers norms); see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=2275670")[#text("ICM paper of Kra")]#text(" for a survey of recent developments. The concept of a characteristic factor (or more precisely, finitary analogues of this concept) also is fundamental in ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my work with Ben Green on primes in arithmetic progression")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— The dichotomy between structure and randomness —")]

#text("The remainder of this lecture is devoted to proving the following “relative” generalisation of Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(", and which is a fundamental ingredient in the proof of the Furstenberg recurrence theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text("Suppose that ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is an extension of a system ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(". Then exactly one of the following statements is true:")

#enum(start: 1, 
[#text("(Structure) X has a factor Z which is a non-trivial compact extension of Y.")],
[#text("(Randomness) X is a weakly mixing extension of Y.")]
)
]

#text("As in ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(", the key to proving this theorem is to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Suppose that ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is an extension of a system ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(". Then a function ")#mi("f \\in L^2(X|Y)")#text(" is relatively weakly mixing if and only if ")#mi("\\langle f, g \\rangle_{X|Y} = 0")#text(" a.e. for all relatively almost periodic g.")
]

#text("The “only if” part of this proposition is Lemma 1; the harder part is the “if” part, which we will prove shortly. But for now, let us see why Proposition 2 implies Theorem 2.")

#text("From Lemma 1, we already know that no non-trivial function can be simultaneously conditionally weakly mixing and conditionally almost periodic, which shows that cases 1 and 2 of Theorem 2 cannot simultaneously hold. To finish the proof of Theorem 2, suppose that X is not a weakly mixing extension of Y, thus there exists a function ")#mi("f \\in L^2(X|Y)")#text(" of relative mean zero which is not weakly mixing. By Proposition 2, there must exist a relatively almost periodic ")#mi("g \\in L^2(X|Y)")#text(" such that ")#mi("\\langle f, g\\rangle_{X|Y}")#text(" does not vanish a.e.. Since f is orthogonal to all functions in ")#mi("L^\\infty(Y)")#text(", we conclude that g is ")#emph[#text("not")]#text(" in ")#mi("L^\\infty(Y)")#text(", thus we have a single relatively almost periodic function. From Exercise 6 of ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("Lecture 13")]#text(", this shows that the maximal compact extension of Y is non-trivial, and the claim follows.")

#text("It thus suffices to prove the “if” part of Proposition 2; thus we need to show that every non-conditionally-weakly-mixing function correlates with some conditionally almost periodic function. But observe that if ")#mi("f \\in L^2(X|Y)")#text(" is not conditionally weakly mixing, then by definition we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\limsup_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\left| {\\Bbb E}( T^n f \\overline{f} | Y ) \\right|_{L^2(Y)}^2 > 0.", block: true)]]

#text("We can rearrange this as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\limsup_{N \\to \\infty} \\langle S_{f,N} f, f \\rangle_X > 0.")]]

#text("where ")#mi("S_{f,N}: L^2(X|Y) \\to L^2(X|Y)")#text(" is the operator")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("S_{f,N} g := \\frac{1}{N} \\sum_{n=0}^{N-1} {\\Bbb E}( g \\overline{T^n f}|Y) T^n f.")]]

#text("To prove Proposition 2, it thus suffices (by weak compactness) to show that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" (Dual functions are almost periodic) Suppose that ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is an extension of a system ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(", and let ")#mi("f \\in L^2(X|Y)")#text(". Let ")#mi("S_f")#text(" be any limit point of ")#mi("S_{f,N}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topology")]#text(". Then ")#mi("S_f f")#text(" is relatively almost periodic.")
]

#strong[#text("Remark 3.")]#text(" By applying the mean ergodic theorem to the dynamical system ")#mi("X \\times_Y X")#text(", one can show that the sequence ")#mi("D_N")#text(" is in fact convergent in the weak or ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong")]#text(" operator topologies (at least when X is regular). But to avoid some technicalities we shall present an argument that does not rely on existence of a strong limit. ")#mi("\\diamond")

#text("As one might expect from the experience with unconditional weak mixing, the proof of Proposition 3 relies on the theory of conditionally Hilbert-Schmidt operators on ")#mi("L^2(X|Y)")#text(". We give here a definition of such operators which is suited for our needs.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" Let X, Y be as above. A ")#emph[#text("sub-orthonormal set")]#text(" in ")#mi("L^2(X|Y)")#text(" is any at most countable sequence ")#mi("e_\\alpha \\in L^2(X|Y)")#text(" such that ")#mi("\\langle e_\\alpha, e_\\beta \\rangle_{X|Y} = 0")#text(" a.e. for all ")#mi("\\alpha \\neq \\beta")#text(" and ")#mi("\\langle e_\\alpha, e_\\alpha \\rangle_{X|Y} \\leq 1")#text(" a.e. for all ")#mi("\\alpha")#text(". A linear operator ")#mi("A: L^2(X|Y) \\to L^2(X|Y)")#text(" is said to be a ")#emph[#text("conditionally Hilbert-Schmidt operator")]#text(" if we have the module property")

#align(center)[#mi("A(cf) = cAf")#text(" for all ")#mi("c \\in L^\\infty(Y)")#text(" (12)")]

#text("and the bound")

#align(center)[#tao-math("\\sum_\\alpha \\sum_\\beta \\left|\\langle A e_\\alpha, f_\\beta \\rangle_{X,Y}\\right|^2 \\leq C^2", block: false)#text(" a.e. (13)")]

#text("for all sub-orthonormal sets ")#mi("\\{ e_\\alpha\\}")#text(", ")#mi("\\{f_\\beta\\}")#text(" and some constant ")#mi("C>0")#text("; the best such C is called the ")#emph[#text("(uniform) conditional Hilbert-Schmidt norm")]#text(" ")#tao-math("\\left\\|\\left\\|A\\right\\|_{HS(X|Y)}\\right\\|_{L^\\infty(Y)}", block: false)#text(" of A.")
]

#strong[#text("Remark 4. ")]#text(" As in ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(", one can also set up the concept of a tensor product of two Hilbert modules, and use that to define conditionally Hilbert-Schmidt operators in a way which does not require sub-orthonormal sets. But we will not need to do so here. One can also define a pointwise conditional Hilbert-Schmidt norm ")#tao-math("\\left\\|A\\right\\|_{HS(X|Y)}(y)", block: false)#text(" for each ")#mi("y \\in Y")#text(", but we will not need this concept. ")#mi("\\diamond")

#strong[#text("Example 2. ")]#text("Suppose Y is just a finite set (with the discrete ")#mi("\\sigma")#text("-algebra), then X splits into finitely many fibres ")#mi("\\pi^{-1}(\\{y\\})")#text(" with the conditional measures ")#mi("\\mu_y")#text(", and ")#mi("L^2(X|Y)")#text(" can be direct sum (with the ")#mi("l^\\infty")#text(" norm) of the Hilbert spaces ")#mi("L^2(\\mu_y)")#text(". A conditional Hilbert-Schmidt operator is then equivalent to a family of Hilbert-Schmidt operators ")#mi("A_y: L^2(\\mu_y) \\to L^2(\\mu_y)")#text(" for each y, with the ")#mi("A_y")#text(" uniformly bounded in Hilbert-Schmidt norm. ")#mi("\\diamond")

#strong[#text("Example 3. ")]#text("In the skew shift example ")#mi("X = ({\\Bbb R}/{\\Bbb Z})^2 = \\{ (y,z): y, z \\in {\\Bbb R}/{\\Bbb Z} \\}")#text(", ")#mi("Y = ({\\Bbb R}/{\\Bbb Z})")#text(", one can show that an operator A is conditionally Hilbert-Schmidt if and only if it takes the form ")#mi("A f(y,z) = \\int_{{\\Bbb R}/{\\Bbb Z}} K_y(z,z^{\\prime}) f(y,z^{\\prime})\\ dz^{\\prime}")#text(" a.e. for all ")#mi("f \\in L^2(X|Y)")#text(", with ")#tao-math("\\left\\|\\left\\|A\\right\\|_{HS(X|Y)}\\right\\|_{L^\\infty(Y)} = \\sup_y (\\int_{{\\Bbb R}/{\\Bbb Z}} \\int_{{\\Bbb R}/{\\Bbb Z}} \\left|K_y(z,z^{\\prime})\\right|^2 dz dz^{\\prime})^{1/2}", block: false)#text(" finite. ")#mi("\\diamond")

#strong[#text("Exercise 6. ")]#text("Let ")#mi("f_1, f_2 \\in L^2(X|Y)")#text(" with ")#tao-math("\\left\\|f_1\\right\\|_{L^2(X|Y)}, \\left\\|f_2\\right\\|_{L^2(X|Y)} \\leq 1", block: false)#text(" a.e.. Show that the rank one operator ")#mi("g \\mapsto \\langle g, f_1 \\rangle_{X|Y} f_2")#text(" is conditionally Hilbert-Schmidt with norm at most 1. ")#mi("\\diamond")

#text("Observe from (11) that the ")#mi("S_{f,N}")#text(" are averages of rank one operators arising from the functions ")#mi("T^n f")#text(", and so by Exercise 6 and the triangle inequality we see that the ")#mi("S_{f,N}")#text(" are uniformly conditionally Hilbert-Schmidt. Taking weak limits using (13) (and ")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(") we conclude that ")#mi("S_f")#text(" is also conditionally Hilbert-Schmidt.")

#text("Next, we observe from the telescoping identity that for every h, ")#mi("T^h S_{f,N} - S_{f,N} T^h")#text(" converges to zero in the weak operator topology (and even in the operator norm topology) as ")#mi("N \\to \\infty")#text("; taking limits, we see that ")#mi("S_f")#text(" commutes with T. To show that ")#mi("S_f f")#text(" is conditionally almost periodic, it thus suffices to show the following analogue of Lemma 2 from ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("Lecture 12")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2. ")]#text("Let ")#mi("A: L^2(X|Y) \\to L^2(X|Y)")#text(" be a conditionally Hilbert-Schmidt operator. Then the image of the unit ball of ")#mi("L^2(X|Y)")#text(" under ")#mi("A")#text(" is conditionally precompact.")
]

#strong[#text("Proof.")]#text(" We shall prove this lemma by establishing a sort of conditional ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(" for A. We can normalise A to have uniform conditional Hilbert-Schmidt norm 1. We fix ")#mi("\\varepsilon > 0")#text(", and we will also need an integer k and a small quantity ")#mi("\\delta > 0")#text(" depending on ")#mi("\\varepsilon")#text(" to be chosen later.")

#text("We first consider the quantities ")#tao-math("\\left|\\langle Ae_1, f_1 \\rangle_{X|Y}\\right|^2", block: false)#text(" where ")#mi("e_1, f_1")#text(" ranges over all sub-orthonormal sets of cardinality 1. On the one hand, these quantities are bounded pointwise by 1, thanks to (13). On the other hand, observe that if ")#tao-math("\\left|\\langle Ae_1, f_1 \\rangle_{X|Y}\\right|^2", block: false)#text(" and ")#tao-math("\\left|\\langle Ae^{\\prime}_1, f^{\\prime}_1 \\rangle_{X|Y}\\right|^2", block: false)#text(" are of the above form, then so is the join ")#tao-math("\\max( \\left|\\langle Ae_1, f_1 \\rangle_{X|Y}\\right|^2, \\left|\\langle Ae^{\\prime}_1, f^{\\prime}_1 \\rangle_{X|Y}\\right|^2 )", block: false)#text(", as can be seen by taking ")#mi("\\tilde e_1 := e_1 1_E + e^{\\prime}_1 1_{E^c}")#text(" and ")#mi("\\tilde f_1 := f_1 1_E + f^{\\prime}_1 1_{E^c}")#text(", where E is the set where ")#tao-math("\\left|\\langle Ae_1,f_1\\rangle_{X|Y}\\right|^2", block: false)#text(" exceeds ")#tao-math("\\left|\\langle Ae^{\\prime}_1,f^{\\prime}_1\\rangle_{X|Y}\\right|^2", block: false)#text(". By using a maximising sequence for the quantity ")#tao-math("\\int_Y \\left|\\langle Ae, f \\rangle_{X|Y}\\right|^2\\ d\\nu", block: false)#text(" and applying joins repeatedly, we can thus (on taking limits) find a pair ")#mi("e_1, f_1")#text(" which is near-optimal in the sense that ")#tao-math("\\left|\\langle Ae_1, f_1 \\rangle_{X|Y}\\right|^2 \\geq (1-\\delta) \\left|\\langle Ae^{\\prime}_1, f^{\\prime}_1\\rangle_{X|Y}\\right|^2", block: false)#text(" a.e. for all competitors ")#mi("e^{\\prime}_1, f^{\\prime}_1")#text(".")

#text("Now fix ")#mi("e_1, f_1")#text(", and consider the quantity ")#tao-math("\\left|\\langle Ae_2, f_2 \\rangle_{X|Y}\\right|^2", block: false)#text(", where ")#mi("\\{e_1,e_2\\}")#text(" and ")#mi("\\{f_1,f_2\\}")#text(" are sub-orthonormal sets. By arguing as before we can find an ")#mi("e_2, f_2")#text(" which is near optimal in the sense that ")#tao-math("\\left|\\langle Ae_2, f_2 \\rangle_{X|Y}\\right|^2 \\geq (1-\\delta) \\left|\\langle Ae^{\\prime}_2, f^{\\prime}_2 \\rangle_{X|Y}\\right|^2", block: false)#text(" a.e. for all competitors ")#mi("e^{\\prime}_2, f^{\\prime}_2")#text(".")

#text("We continue in this fashion k times to obtain sub-orthonormal sets ")#mi("\\{e_1,\\ldots,e_k\\}")#text(" and ")#mi("\\{f_1,\\ldots,f_k\\}")#text(" with the property that ")#tao-math("\\left|\\langle Ae_i, f_i \\rangle_{X|Y}\\right|^2 \\geq (1-\\delta) \\left|\\langle Ae^{\\prime}_i, f^{\\prime}_i \\rangle_{X|Y}\\right|^2", block: false)#text(" whenever ")#mi("\\{e_1,\\ldots,e_{i-1},e^{\\prime}_i\\}, \\{f_1,\\ldots,f_{i-1},f^{\\prime}_i\\}")#text(" are sub-orthonormal sets. On the other hand, from (13) we know that ")#tao-math("\\sum_i \\left|\\langle Ae_i, f_i \\rangle_{X|Y}\\right|^2 \\leq 1", block: false)#text(". From these two facts we soon conclude that ")#tao-math("\\left|\\langle Ae, f\\rangle_{X|Y}\\right|^2 \\leq 1/k+O_k(\\delta)", block: false)#text(" a.e. whenever ")#mi("\\{e_1,\\ldots,e_k,e\\}")#text(" and ")#mi("\\{f_1,\\ldots,f_k,f\\}")#text(" are sub-orthonormal. If ")#mi("k, \\delta")#text(" are chosen appropriately we obtain ")#tao-math("\\left|\\langle Ae, f\\rangle_{X|Y}\\right| \\leq \\varepsilon", block: false)#text(" a.e. Thus (by duality) A maps the unit ball of the orthogonal complement of the span of ")#mi("\\{e_1,\\ldots,e_k\\}")#text(" to the ")#mi("\\varepsilon")#text("-neighbourhood of the span of ")#mi("\\{f_1,\\ldots,f_k\\}")#text(" (with notions such as orthogonality, span, and neighbourhood being defined conditionally of course, using the ")#mi("L^\\infty(Y)")#text("-Hilbert module structure of ")#mi("L^2(X|Y)")#text("). From this it is not hard to establish the desired precompactness. ")#mi("\\Box")

#text("[Update, Mar 1: Typo corrected.]")

#text("[Update, June 2 2009: Some minor changes in the proof of Lemma 1. Thanks to Jeremy Avigad for corrections.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-26857")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2008")])]

#text("I may be confused, but in the proof of Thm. 2 shouldn’t the almost periodic function g have ")#emph[#text("non-zero")]#text(" correlation with f?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-26860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2008")])]

#text("Oops! You’re right of course; thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-26970")[#strong[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("[…] be a measure-preserving system, and let be a factor. In Theorem 2 of the previous lecture, we showed that X was not a weakly mixing extension of Y, then we could find a non-trivial compact […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-27005")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("I take it you’ve noticed the TeXbreakage? (Looks like backslashes are getting eaten somewhere.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orr")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-27037")[#strong[#text("orr")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("Hello,")#linebreak()#text(" After prop. 2, you write “let us see why Proposition 2 implies Proposition 1”,")#linebreak()#text(" and you probably meant Theorem 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-27039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("Dear orr: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第十四讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-34606")[#strong[#text("陶哲轩遍历论习题解答：第十四讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第十四讲的六个习题。这里是本讲的链接。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-34664")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear Professor Tao:")

#text("Here are several typos:")

#text("1,Just before (2) the “L^2” should be “")#mi("L^2")#text("“.")

#text("2,the last sentence of exercise, a “the” repeated twice.")

#text("3,In Corrollary 1, should “…be such that at least one of ")#mi("f_1\\cdots f_k")#text(" has relative mean zero.” be deleted?")

#text("4,in (13), the sub of second sum is ")#mi("\\beta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-41997")[#strong[#text("Ergodic Ramsey Theory (by Yuri Lima) « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2009")]

#text("[…] Compact and weak-mixing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-51633")[#strong[#text("ERT15: Weakly mixing extensions « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2011")]

#text("[…] is the other way of defining the concepts, in terms of ergodic averages and its expectations. See this post of Terry Tao for further details on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f9ea44efe8a2f418166d0488a336d7321b9bee00170f6aa90d3babca2736ed3-571a16e60d27c18800fa8829eed19bb1624ccf0793adec345bb01fa19c7a4961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-58980")[#strong[#text("Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("Dear Prof Tao,")

#text("the Hilbert module L^2(X|Y) is not a Hilbert space, so what kind of weak compactness are you talking about, when you say “To prove Proposition 2, it thus suffices (by weak compactness) to show that …”?")#linebreak()#text(" Is it true that bounded subsets in a Hilbert module are somehow relatively weakly compact?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-59102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2011")])]

#text("One can use the embedding of L^2(X|Y) in L^2(X) and use the weak topology of the latter. (It is not difficult to see that the closed unit ball in L^2(X|Y) is weakly closed in L^2(X).)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cuttheknot")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-211897")[#strong[#text("cuttheknot")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Dear Professor, in the end of the proof of Lemma 2 how do we infer that ‘A maps the unit ball of the orthogonal complement of the span of ")#mi("\\{e_1,\\ldots,e_k\\}")#text(" to the ")#mi("\\varepsilon")#text("-neighbourhood of the span of ")#mi("\\{f_1,\\ldots,f_k\\}")#text("?")#linebreak()#text(" Maybe this is a stupid question, but the issue is that in this Hilbert module we cannot take the usual orthogonal projections:")#linebreak()#text(" I mean, given ")#mi("u,v\\in L^2(X|Y)")#text(" we may not be able to find a ")#mi("z \\in L^\\infty(Y)")#text(" such that ")#mi("\\langle u-zv, v \\rangle_{X|Y}=0")#text(", am I right?")#linebreak()#text(" Thank you for your patience.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-211951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Well, if one normalises v so that ")#tao-math("\\left\\|v\\right\\|_{L^2(X|Y)}", block: false)#text(" to only take the values 0 and 1, then one can do this, by setting ")#mi("z := \\langle u,v\\rangle_{X|Y}")#text(" as per usual. A sub-orthonormal system can always be normalised in this fashion, dividing each basis element ")#mi("e")#text(" by ")#tao-math("\\left\\|e\\right\\|_{L^2(X|Y)}", block: false)#text(" when the latter quantity is non-zero, and the theory continues as before. (Basically, a sub-orthonormal system, after normalisation, should be viewed as a family of orthonormal systems in which some basis elements could be zeroed out on certain fibres.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cuttheknot")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-211966")[#strong[#text("cuttheknot")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("Thanks, indeed if I’m not wrong ")#mi("\\langle u,v\\rangle_{X|Y}=0")#text(" iff ")#mi("\\langle u,v^{\\prime}\\rangle_{X|Y}=0")#text(" where v’ is the ‘normalized’ v, so everything is fine now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mizar")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-453875")[#strong[#text("Mizar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2015")])]

#text("Dear Professor, in the paragraph after Exercise 6 you state that ")#mi("S_f")#text(" is conditionally Hilbert-Schmidt.")#linebreak()#text(" I think that ")#mi("S_f")#text(" is only required to guarantee that ")#mi("S_{f,N_j}g")#text(" converges to ")#mi("S_f g")#text(" weakly in ")#mi("L^2(X)")#text(" for any ")#mi("g\\in L^2(X|Y)")#text(" (for some suitable subsequence ")#mi("N_j")#text(").")#linebreak()#text(" If this is the case, how do you deduce the pointwise bound ")#tao-math("\\sum_\\alpha \\sum_\\beta \\left|\\langle S_f e_\\alpha, f_\\beta \\rangle_{X|Y}\\right|^2 \\leq 1", block: false)#text("?")#linebreak()#text(" One would need to know something like ")#tao-math("\\left|\\langle S_f e_\\alpha,f_\\beta\\rangle_{X|Y}\\right|\\le \\left|\\lim\\inf \\langle S_{f,N,j} e_\\alpha,f_\\beta\\rangle_{X|Y}\\right|", block: false)#text(" pointwise, but I fail to see why this is true.")

#text("Sorry for this terrible necroposting!")#linebreak()#text(" (BTW: in Proposition 3, ‘topology’ is misspelled as ‘technology’, although ‘technology’ is suggestive!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-453876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2015")])]

#text("The pointwise bound can be deduced from the assertion that ")#mi("\\sum_\\alpha \\sum_\\beta c_{\\alpha,\\beta} \\langle S_f e_\\alpha, f_\\beta 1_A \\rangle_X \\leq \\nu(A)")#text(" for any finitely supported constants ")#mi("c_{\\alpha,\\beta}")#text(" that square-sum to 1 (this is the weak formulation of the bound), and any ")#mi("A")#text(" measurable in Y. This in turn already holds for the ")#mi("S_{f,N_j}")#text(" and one can then take limits using weak convergence.")

#text("(This is an instance of a more general rule of thumb, namely that any “convex” condition is likely to be preserved under any reasonable notion of a “weak” limit, basically because of the weak formulation of that condition that is available through convex duality.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szemerédi Theorem Part VI – Dichotomy between weak mixing and compact extension | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-460110")[#strong[#text("Szemerédi Theorem Part VI – Dichotomy between weak mixing and compact extension | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("[…] properties of disintegration of measures). The only alternative I know of is presented in this post of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fd1243d1813d506891de7f7f6a3cd5c0c76ca07d3bf41804a212987abf7c5b5-548d6c3a5e084ac61ae89e77525846fd34b34ca006690132d9168167f40553c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Schnurr")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-469441")[#strong[#text("Michael Schnurr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Correct me if I’m wrong, but I believe you made a typo in (2) where you wrote out the limit for the definition of a conditionally/relatively weakly mixing function ")#mi("f")#text(". Since ")#mi("\\mathbb{E}(T^n f \\overline{f}|Y)")#text(" will in particular be a function of ")#mi("Y")#text(", then shouldn’t the integral be over ")#mi("Y")#text(" and with respect to ")#mi("\\nu")#text("?")

#text("I wanted to be certain, because I’m currently writing up a result about weak mixing extensions, using the definition of use here, and I want to be absolutely certain I’m using the correct definition")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fd1243d1813d506891de7f7f6a3cd5c0c76ca07d3bf41804a212987abf7c5b5-548d6c3a5e084ac61ae89e77525846fd34b34ca006690132d9168167f40553c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Schnurr")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-469451")[#strong[#text("Michael Schnurr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("After thinking about it some more, I think it might not be a typo, but, well… I’m viewing my systems as lying in a set Z= X \\times Y, and then my systems are extensions of systems on X, though the natural projection. So while in general it might make sense to be integrating over Z (in my notation), should I not be integrating over X?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/#comment-469509")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("In this post I am identifying ")#mi("L^\\infty(Y)")#text(" with a subspace of ")#mi("L^\\infty(X)")#text(", so either integral would be appropriate here.")
]
]
