// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/04/24/notes-on-the-bbt-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:39:11.435939+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on the B+B+t theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on the B+B+t theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 April 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/04/24/notes-on-the-bbt-theorem/")[#text("https://terrytao.wordpress.com/2024/04/24/notes-on-the-bbt-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A ")#link("https://arxiv.org/abs/2206.12377")[#text("recent paper of Kra, Moreira, Richter, and Robertson")]#text(" established the following theorem, resolving a ")#link("https://zbmath.org/0305.10050")[#text("question of Erdös")]#text(". Given a discrete amenable group ")#mi("{G = (G,+)}")#text(", and a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(", we define the ")#link("https://en.wikipedia.org/wiki/Natural_density")[#text("Banach density")]#text(" of ")#mi("{A}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\sup_\\Phi \\limsup_{N \\rightarrow \\infty} \\left|A \\cap \\Phi_N\\right|/\\left|\\Phi_N\\right|,", block: true)]]

#text("where the supremum is over all ")#link("https://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequences")]#text(" ")#mi("{\\Phi = (\\Phi_N)_{N=1}^\\infty}")#text(" of ")#mi("{G}")#text(". Given a set ")#mi("{B}")#text(" in ")#mi("{G}")#text(", we define the restricted sumset ")#mi("{B \\oplus B}")#text(" to be the set of all pairs ")#mi("{b_1+b_2}")#text(" where ")#mi("{b_1, b_2}")#text(" are ")#emph[#text("distinct")]#text(" elements of ")#mi("{B}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{G}")#text(" be a countably infinite abelian group with the index ")#mi("{[G:2G]}")#text(" finite. Let ")#mi("{A}")#text(" be a positive Banach density subset of ")#mi("{G}")#text(". Then there exists an infinite set ")#mi("{B \\subset A}")#text(" and ")#mi("{t \\in G}")#text(" such that ")#mi("{B \\oplus B + t \\subset A}")#text(".")
]

#text("Strictly speaking, the main result of Kra et al. only claims this theorem for the case of the integers ")#mi("{G={\\bf Z}}")#text(", but as noted in the recent preprint of ")#link("https://arxiv.org/abs/2402.07779")[#text("Charamaras and Mountakis")]#text(", the argument in fact applies for all countable abelian ")#mi("{G}")#text(" in which the subgroup ")#mi("{2G := \\{ 2x: x \\in G \\}}")#text(" has finite index. This condition is in fact necessary (as observed by forthcoming work of Ethan Acklesberg): if ")#mi("{2G}")#text(" has infinite index, then one can find a subgroup ")#mi("{H_j}")#text(" of ")#mi("{G}")#text(" of index ")#mi("{2^j}")#text(" for any ")#mi("{j \\geq 1}")#text(" that contains ")#mi("{2G}")#text(" (or equivalently, ")#mi("{G/H_j}")#text(" is ")#mi("{2}")#text("-torsion). If one lets ")#mi("{y_1,y_2,\\dots}")#text(" be an enumeration of ")#mi("{G}")#text(", and one can then check that the set")

#align(center)[#tao-fit-display[#mitex("A := G \\backslash \\bigcup_{j=1}^\\infty (H_{j+1} + y_j) \\backslash \\{y_1,\\dots,y_j\\}")]]

#text("has positive Banach density, but does not contain any set of the form ")#mi("{B \\oplus B + t}")#text(" for any ")#mi("{t}")#text(" (indeed, from the pigeonhole principle and the ")#mi("{2}")#text("-torsion nature of ")#mi("{G/H_{j+1}}")#text(" one can show that ")#mi("{B \\oplus B + y_j}")#text(" must intersect ")#mi("{H_{j+1} + y_j \\backslash \\{y_1,\\dots,y_j\\}}")#text(" whenever ")#mi("{B}")#text(" has cardinality larger than ")#mi("{j 2^{j+1}}")#text("). It is also necessary to work with restricted sums ")#mi("{B \\oplus B}")#text(" rather than full sums ")#mi("{B+B}")#text(": a counterexample to the latter is provided for instance by the example with ")#mi("{G = {\\bf Z}}")#text(" and ")#mi("{A := \\bigcup_{j=1}^\\infty [10^j, 1.1 \\times 10^j]}")#text(". Finally, the presence of the shift ")#mi("{t}")#text(" is also necessary, as can be seen by considering the example of ")#mi("{A}")#text(" being the odd numbers in ")#mi("{G ={\\bf Z}}")#text(", though in the case ")#mi("{G=2G}")#text(" one can of course delete the shift ")#mi("{t}")#text(" at the cost of giving up the containment ")#mi("{B \\subset A}")#text(".")

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" resembles other theorems in density Ramsey theory, such as ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", but with the notable difference that the pattern located in the dense set ")#mi("{A}")#text(" is ")#emph[#text("infinite")]#text(" rather than merely arbitrarily large but finite. As such, it does not seem that this theorem can be proven by purely finitary means. However, one can view this result as the conjunction of an infinite number of statements, each of which is a finitary density Ramsey theory statement. To see this, we need some more notation. Observe from Tychonoff’s theorem that the collection ")#mi("{2^G := \\{ B: B \\subset G \\}}")#text(" is a compact topological space (with the topology of pointwise convergence) (it is also metrizable since ")#mi("{G}")#text(" is countable). Subsets ")#mi("{{\\mathcal F}}")#text(" of ")#mi("{2^G}")#text(" can be thought of as properties of subsets of ")#mi("{G}")#text("; for instance, the property a subset ")#mi("{B}")#text(" of ")#mi("{G}")#text(" of being finite is of this form, as is the complementary property of being infinite. A property of subsets of ")#mi("{G}")#text(" can then be said to be ")#emph[#text("closed")]#text(" or ")#emph[#text("open")]#text(" if it corresponds to a closed or open subset of ")#mi("{2^G}")#text(". Thus, a property is closed and only if if it is closed under pointwise limits, and a property is open if, whenever a set ")#mi("{B}")#text(" has this property, then any other set ")#mi("{B^{\\prime}}")#text(" that shares a sufficiently large (but finite) initial segment with ")#mi("{B}")#text(" will also have this property. Since ")#mi("{2^G}")#text(" is compact and Hausdorff, a property is closed if and only if it is compact.")

#text("The properties of being finite or infinite are neither closed nor open. Define a ")#emph[#text("smallness property")]#text(" to be a closed (or compact) property of subsets of ")#mi("{G}")#text(" that is only satisfied by finite sets; the complement to this is a ")#emph[#text("largeness property")]#text(", which is an open property of subsets of ")#mi("{G}")#text(" that is satisfied by all infinite sets. (One could also choose to impose other axioms on these properties, for instance requiring a largeness property to be an ")#link("https://en.wikipedia.org/wiki/Upper_set")[#text("upper set")]#text(", but we will not do so here.) Examples of largeness properties for a subset ")#mi("{B}")#text(" of ")#mi("{G}")#text(" include:")

#list(
[#mi("{B}")#text(" has at least ")#mi("{10}")#text(" elements.")],
[#mi("{B}")#text(" is non-empty and has at least ")#mi("{b_1}")#text(" elements, where ")#mi("{b_1}")#text(" is the smallest element of ")#mi("{B}")#text(".")],
[#mi("{B}")#text(" is non-empty and has at least ")#mi("{b_{b_1}}")#text(" elements, where ")#mi("{b_n}")#text(" is the ")#mi("{n^{\\mathrm{th}}}")#text(" element of ")#mi("{B}")#text(".")],
[#mi("{T}")#text(" halts when given ")#mi("{B}")#text(" as input, where ")#mi("{T}")#text(" is a given Turing machine that halts whenever given an infinite set as input. (Note that this encompasses the preceding three examples as special cases, by selecting ")#mi("{T}")#text(" appropriately.)")]
)

#text("We will call a set obeying a largeness property ")#mi("{{\\mathcal P}}")#text(" an ")#emph[#mi("{{\\mathcal P}}")#text("-large set")]#text(".")

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" is then equivalent to the following “almost finitary” version (cf. ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this previous discussion")]#text(" of almost finitary versions of the infinite pigeonhole principle):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Almost finitary form of main theorem)")]#text(" ")#metadata(none) <tao-dda5e4fa5f1f1ab97e24>#text(" Let ")#mi("{G}")#text(" be a countably infinite abelian group with ")#mi("{[G:2G]}")#text(" finite. Let ")#mi("{\\Phi_n}")#text(" be a Følner sequence in ")#mi("{G}")#text(", let ")#mi("{\\delta>0}")#text(", and let ")#mi("{{\\mathcal P}_t}")#text(" be a largeness property for each ")#mi("{t \\in G}")#text(". Then there exists ")#mi("{N}")#text(" such that if ")#mi("{A \\subset G}")#text(" is such that ")#tao-math("{\\left|A \\cap \\Phi_n\\right| / \\left|\\Phi_n\\right| \\geq \\delta}", block: false)#text(" for all ")#mi("{n \\leq N}")#text(", then there exists a shift ")#mi("{t \\in G}")#text(" and ")#mi("{A}")#text(" contains a ")#mi("{{\\mathcal P}_t}")#text("-large set ")#mi("{B}")#text(" such that ")#mi("{B \\oplus B + t \\subset A}")#text(".")
]

#strong[#text("Proof of Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(" assuming Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(".")]#text(" Let ")#mi("{G, \\Phi_n}")#text(", ")#mi("{\\delta}")#text(", ")#mi("{{\\mathcal P}_t}")#text(" be as in Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(". Suppose for contradiction that Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(" failed, then for each ")#mi("{N}")#text(" we can find ")#mi("{A_N}")#text(" with ")#tao-math("{\\left|A_N \\cap \\Phi_n\\right| / \\left|\\Phi_n\\right| \\geq \\delta}", block: false)#text(" for all ")#mi("{n \\leq N}")#text(", such that there is no ")#mi("{t}")#text(" and ")#mi("{{\\mathcal P}_t}")#text("-large ")#mi("{B}")#text(" such that ")#mi("{B, B \\oplus B + t \\subset A_N}")#text(". By compactness, a subsequence of the ")#mi("{A_N}")#text(" converges pointwise to a set ")#mi("{A}")#text(", which then has Banach density at least ")#mi("{\\delta}")#text(". By Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", there is an infinite set ")#mi("{B}")#text(" and a ")#mi("{t}")#text(" such that ")#mi("{B, B \\oplus B + t \\subset A}")#text(". By openness, we conclude that there exists a finite ")#mi("{{\\mathcal P}_t}")#text("-large set ")#mi("{B^{\\prime}}")#text(" contained in ")#mi("{B}")#text(", thus ")#mi("{B^{\\prime}, B^{\\prime} \\oplus B^{\\prime} + t \\subset A}")#text(". This implies that ")#mi("{B^{\\prime}, B^{\\prime} \\oplus B^{\\prime} + t \\subset A_N}")#text(" for infinitely many ")#mi("{N}")#text(", a contradiction.")

#strong[#text("Proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" assuming Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(".")]#text(" Let ")#mi("{G, A}")#text(" be as in Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". If the claim failed, then for each ")#mi("{t}")#text(", the property ")#mi("{{\\mathcal P}_t}")#text(" of being a set ")#mi("{B}")#text(" for which ")#mi("{B, B \\oplus B + t \\subset A}")#text(" would be a smallness property. By Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(", we see that there is a ")#mi("{t}")#text(" and a ")#mi("{B}")#text(" obeying the complement of this property such that ")#mi("{B, B \\oplus B + t \\subset A}")#text(", a contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Define a relation ")#mi("{R}")#text(" between ")#mi("{2^G}")#text(" and ")#mi("{2^G \\times G}")#text(" by declaring ")#mi("{A\\ R\\ (B,t)}")#text(" if ")#mi("{B \\subset A}")#text(" and ")#mi("{B \\oplus B + t \\subset A}")#text(". The key observation that makes the above equivalences work is that this relation is ")#emph[#text("continuous")]#text(" in the sense that if ")#mi("{U}")#text(" is an open subset of ")#mi("{2^G \\times G}")#text(", then the inverse image")

#align(center)[#tao-fit-display[#mitex("R^{-1} U := \\{ A \\in 2^G: A\\ R\\ (B,t) \\text{ for some } (B,t) \\in U \\}")]]

#text("is also open. Indeed, if ")#mi("{A\\ R\\ (B,t)}")#text(" for some ")#mi("{(B,t) \\in U}")#text(", then ")#mi("{B}")#text(" contains a finite set ")#mi("{B^{\\prime}}")#text(" such that ")#mi("{(B^{\\prime},t) \\in U}")#text(", and then any ")#mi("{A^{\\prime}}")#text(" that contains both ")#mi("{B^{\\prime}}")#text(" and ")#mi("{B^{\\prime} \\oplus B^{\\prime} + t}")#text(" lies in ")#mi("{R^{-1} U}")#text(".")
]

#text("For each specific largeness property, such as the examples listed previously, Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(" can be viewed as a finitary assertion (at least if the property is “computable” in some sense), but if one quantifies over all largeness properties, then the theorem becomes infinitary. In the spirit of the ")#link("https://en.wikipedia.org/wiki/Paris%E2%80%93Harrington_theorem")[#text("Paris-Harrington theorem")]#text(", I would in fact expect some cases of Theorem ")#link(<tao-dda5e4fa5f1f1ab97e24>)[#text("2")]#text(" to undecidable statements of Peano arithmetic, although I do not have a rigorous proof of this assertion.")

#text("Despite the complicated finitary interpretation of this theorem, I was still interested in trying to write the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" in some sort of “pseudo-finitary” manner, in which one can see analogies with finitary arguments in additive combinatorics. The proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" that I give below the fold is my attempt to achieve this, although to avoid a complete explosion of “")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("epsilon management")]#text("” I will still use at one juncture an ergodic theory reduction from the original paper of Kra et al. that relies on such infinitary tools as the ergodic decomposition, the ergodic theory, and the spectral theorem. Also some of the steps will be a little sketchy, and assume some familiarity with additive combinatorics tools (such as the arithmetic regularity lemma).")

#metadata(none) <tao-89186ab95e2fa50962c3>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("The proof of Kra et al. proceeds by establishing the following related statement. Define a ")#emph[#text("(length three) combinatorial Erdös progression")]#text(" to be a triple ")#mi("{(A,X_1,X_2)}")#text(" of subsets of ")#mi("{G}")#text(" such that there exists a sequence ")#mi("{n_j \\rightarrow \\infty}")#text(" in ")#mi("{G}")#text(" such that ")#mi("{A - n_j}")#text(" converges pointwise to ")#mi("{X_1}")#text(" and ")#mi("{X_1-n_j}")#text(" converges pointwise to ")#mi("{X_2}")#text(". (By ")#mi("{n_j \\rightarrow \\infty}")#text(", we mean with respect to the cocompact filter; that is, that for any finite (or, equivalently, compact) subset ")#mi("{K}")#text(" of ")#mi("{G}")#text(", ")#mi("{n_j \\not \\in K}")#text(" for all sufficiently large ")#mi("{j}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Combinatorial Erdös progression)")]#text(" ")#metadata(none) <tao-21ad09c113ee3e7e67e1>#text(" Let ")#mi("{G}")#text(" be a countably infinite abelian group with ")#mi("{[G:2G]}")#text(" finite. Let ")#mi("{A}")#text(" be a positive Banach density subset of ")#mi("{G}")#text(". Then there exists a combinatorial Erdös progression ")#mi("{(A,X_1,X_2)}")#text(" with ")#mi("{0 \\in X_1}")#text(" and ")#mi("{X_2}")#text(" non-empty.")
]

#text("Let us see how Theorem ")#link(<tao-21ad09c113ee3e7e67e1>)[#text("4")]#text(" implies Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". Let ")#mi("{G, A, X_1, X_2, n_j}")#text(" be as in Theorem ")#link(<tao-21ad09c113ee3e7e67e1>)[#text("4")]#text(". By hypothesis, ")#mi("{X_2}")#text(" contains an element ")#mi("{t}")#text(" of ")#mi("{G}")#text(", thus ")#mi("{0 \\in X_1}")#text(" and ")#mi("{t \\in X_2}")#text(". Setting ")#mi("{b_1}")#text(" to be a sufficiently large element of the sequence ")#mi("{n_1, n_2, \\dots}")#text(", we conclude that ")#mi("{b_1 \\in A}")#text(" and ")#mi("{b_1 + t \\in X_1}")#text(". Setting ")#mi("{b_2}")#text(" to be an even larger element of this sequence, we then have ")#mi("{b_2, b_2+b_1+t \\in A}")#text(" and ")#mi("{b_2 +t \\in X_1}")#text(". Setting ")#mi("{b_3}")#text(" to be an even larger element, we have ")#mi("{b_3, b_3+b_1+t, b_3+b_2+t \\in A}")#text(" and ")#mi("{b_3 + t \\in X_1}")#text(". Continuing in this fashion we obtain the desired infinite set ")#mi("{B}")#text(".")

#text("It remains to establish Theorem ")#link(<tao-21ad09c113ee3e7e67e1>)[#text("4")]#text(". The proof of Kra et al. converts this to a topological dynamics/ergodic theory problem. Define a topological measure-preserving ")#mi("{G}")#text("-system ")#mi("{(X,T,\\mu)}")#text(" to be a compact space ")#mi("{X}")#text(" equipped with a Borel probability measure ")#mi("{\\mu}")#text(" as well as a measure-preserving homeomorphism ")#mi("{T: X \\rightarrow X}")#text(". A point ")#mi("{a}")#text(" in ")#mi("{X}")#text(" is said to be ")#emph[#text("generic")]#text(" for ")#mi("{\\mu}")#text(" with respect to a Følner sequence ")#mi("{\\Phi}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu = \\lim_{N \\rightarrow \\infty} {\\bf E}_{n \\in \\Phi_N} f(T^n a)")]]

#text("for all continuous ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". Define an ")#emph[#text("(length three) dynamical Erdös progression")]#text(" to be a tuple ")#mi("{(a,x_1,x_2)}")#text(" in ")#mi("{X}")#text(" with the property that there exists a sequence ")#mi("{n_j \\rightarrow \\infty}")#text(" such that ")#mi("{T^{n_j} a \\rightarrow x_1}")#text(" and ")#mi("{T^{n_j} x_1 \\rightarrow x_2}")#text(".")

#text("Theorem ")#link(<tao-21ad09c113ee3e7e67e1>)[#text("4")]#text(" then follows from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Dynamical Erdös progression)")]#text(" ")#metadata(none) <tao-aa52d7a664190d7e1451>#text(" Let ")#mi("{G}")#text(" be a countably infinite abelian group with ")#mi("{[G:2G]}")#text(" finite. Let ")#mi("{(X,T,\\mu)}")#text(" be a topological measure-preserving ")#mi("{G}")#text("-system, let ")#mi("{a}")#text(" be a ")#mi("{\\Phi}")#text("-generic point of ")#mi("{\\mu}")#text(" for some Følner sequence ")#mi("{\\Phi}")#text(", and let ")#mi("{E}")#text(" be a positive measure open subset of ")#mi("{X}")#text(". Then there exists a dynamical Erdös progression ")#mi("{(a,x_1,x_2)}")#text(" with ")#mi("{x_1 \\in E}")#text(" and ")#mi("{x_2 \\in \\bigcup_{t \\in G} T^t E}")#text(".")
]

#text("Indeed, we can take ")#mi("{X}")#text(" to be ")#mi("{2^G}")#text(", ")#mi("{a}")#text(" to be ")#mi("{A}")#text(", ")#mi("{T}")#text(" to be the shift ")#mi("{T^n B := B-n}")#text(", ")#mi("{E := \\{ B \\in 2^G: 0 \\in B \\}}")#text(", and ")#mi("{\\mu}")#text(" to be a weak limit of the ")#mi("{\\mathop{\\bf E}_{n \\in \\Phi_N} \\delta_{A-n}}")#text(" for a Følner sequence ")#mi("{\\Phi_N}")#text(" with ")#tao-math("{\\lim_{N \\rightarrow \\infty} \\left|A \\cap \\Phi_N\\right| / \\left|\\Phi_N\\right| > 0}", block: false)#text(", at which point Theorem ")#link(<tao-21ad09c113ee3e7e67e1>)[#text("4")]#text(" follows from Theorem ")#link(<tao-aa52d7a664190d7e1451>)[#text("5")]#text(" after chasing definitions. (It is also possible to establish the reverse implication, but we will not need to do so here.)")

#text("A remarkable fact about this theorem is that the point ")#mi("{a}")#text(" need not be in the support of ")#mi("{\\mu}")#text("! (In a related vein, the elements ")#mi("{\\Phi_j}")#text(" of the Følner sequence are not required to contain the origin.)")

#text("Using a certain amount of ergodic theory and spectral theory, Kra et al. were able to reduce this theorem to a special case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Reduction)")]#text(" ")#metadata(none) <tao-c0e8a8f34046a3ab7d3f>#text(" To prove Theorem ")#link(<tao-aa52d7a664190d7e1451>)[#text("5")]#text(", it suffices to do so under the additional hypotheses that ")#mi("{X}")#text(" is ergodic, and there is a continuous factor map to the Kronecker factor. (In particular, the eigenfunctions of ")#mi("{X}")#text(" can be taken to be continuous.)")
]

#text("We refer the reader to the paper of Kra et al. for the details of this reduction. Now we specialize for simplicity to the case where ")#mi("{G = {\\bf F}_p^\\omega = \\bigcup_N {\\bf F}_p^N}")#text(" is a countable vector space over a finite field of size equal to an odd prime ")#mi("{p}")#text(", so in particular ")#mi("{2G=G}")#text("; we also specialize to Følner sequences of the form ")#mi("{\\Phi_j = x_j + {\\bf F}_p^{N_j}}")#text(" for some ")#mi("{x_j \\in G}")#text(" and ")#mi("{N_j \\geq 1}")#text(". In this case we can prove a stronger statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Odd characteristic case)")]#text(" ")#metadata(none) <tao-24662b8dadce67970fac>#text(" Let ")#mi("{G = {\\bf F}_p^\\omega}")#text(" for an odd prime ")#mi("{p}")#text(". Let ")#mi("{(X,T,\\mu)}")#text(" be a topological measure-preserving ")#mi("{G}")#text("-system with a continuous factor map to the Kronecker factor, and let ")#mi("{E_1, E_2}")#text(" be open subsets of ")#mi("{X}")#text(" with ")#mi("{\\mu(E_1) + \\mu(E_2) > 1}")#text(". Then if ")#mi("{a}")#text(" is a ")#mi("{\\Phi}")#text("-generic point of ")#mi("{\\mu}")#text(" for some Følner sequence ")#mi("{\\Phi_j = y_j + {\\bf F}_p^{n_j}}")#text(", there exists an Erdös progression ")#mi("{(a,x_1,x_2)}")#text(" with ")#mi("{x_1 \\in E_1}")#text(" and ")#mi("{x_2 \\in E_2}")#text(".")
]

#text("Indeed, in the setting of Theorem ")#link(<tao-aa52d7a664190d7e1451>)[#text("5")]#text(" with the ergodicity hypothesis, the set ")#mi("{\\bigcup_{t \\in G} T^t E}")#text(" has full measure, so the hypothesis ")#mi("{\\mu(E_1)+\\mu(E_2) > 1}")#text(" of Theorem ")#link(<tao-24662b8dadce67970fac>)[#text("7")]#text(" will be verified in this case. (In the case of more general ")#mi("{G}")#text(", this hypothesis ends up being replaced with ")#mi("{\\mu(E_1)/[G:2G] + \\mu(E_2) > 1}")#text("; see Theorem 2.1 of ")#link("https://arxiv.org/abs/2404.12201")[#text("this recent preprint of Kousek and Radic")]#text(" for a treatment of the case ")#mi("{G={\\bf Z}}")#text(" (but the proof extends without much difficulty to the general case).)")

#text("As with Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", Theorem ")#link(<tao-24662b8dadce67970fac>)[#text("7")]#text(" is still an infinitary statement and does not have a direct finitary analogue (though it can likely be expressed as the conjunction of infinitely many such finitary statements, as we did with Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("). Nevertheless we can formulate the following finitary statement which can be viewed as a “baby” version of the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Finitary model problem)")]#text(" ")#metadata(none) <tao-9372c470eeadd5ecd9c3>#text(" Let ")#mi("{X = (X,d)}")#text(" be a compact metric space, let ")#mi("{G = {\\bf F}_p^N}")#text(" be a finite vector space over a field of odd prime order. Let ")#mi("{T}")#text(" be an action of ")#mi("{G}")#text(" on ")#mi("{X}")#text(" by homeomorphisms, let ")#mi("{a \\in X}")#text(", and let ")#mi("{\\mu}")#text(" be the associated ")#mi("{G}")#text("-invariant measure ")#mi("{\\mu = {\\bf E}_{x \\in G} \\delta_{T^x a}}")#text(". Let ")#mi("{E_1, E_2}")#text(" be subsets of ")#mi("{X}")#text(" with ")#mi("{\\mu(E_1) + \\mu(E_2) > 1 + \\delta}")#text(" for some ")#mi("{\\delta>0}")#text(". Then for any ")#mi("{\\varepsilon>0}")#text(", there exist ")#mi("{x_1 \\in E_1, x_2 \\in E_2}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ h \\in G: d(T^h a,x_1) \\leq \\varepsilon, d(T^h x_1,x_2) \\leq \\varepsilon \\}\\right| \\gg_{p,\\delta,\\varepsilon,X} |G|.", block: true)]]
]

#text("The important thing here is that the bounds are uniform in the dimension ")#mi("{N}")#text(" (as well as the initial point ")#mi("{a}")#text(" and the action ")#mi("{T}")#text(").")

#text("Let us now give a finitary proof of Theorem ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("8")]#text(". We can cover the compact metric space ")#mi("{X}")#text(" by a finite collection ")#mi("{B_1,\\dots,B_M}")#text(" of open balls of radius ")#mi("{\\varepsilon/2}")#text(". This induces a coloring function ")#mi("{\\tilde c: X \\rightarrow \\{1,\\dots,M\\}}")#text(" that assigns to each point in ")#mi("{X}")#text(" the index ")#mi("{m}")#text(" of the first ball ")#mi("{B_m}")#text(" that covers that point. This then induces a coloring ")#mi("{c: G \\rightarrow \\{1,\\dots,M\\}}")#text(" of ")#mi("{G}")#text(" by the formula ")#mi("{c(h) := \\tilde c(T^h a)}")#text(". We also define the pullbacks ")#mi("{A_i := \\{ h \\in G: T^h a \\in E_i \\}}")#text(" for ")#mi("{i=1,2}")#text(". By hypothesis, we have ")#tao-math("{\\left|A_1\\right| + \\left|A_2\\right| > (1+\\delta)\\left|G\\right|}", block: false)#text(", and it will now suffice by the triangle inequality to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ h \\in G: c(h) = c(x_1); c(h+x_1)=c(x_2) \\}\\right| \\gg_{p,\\delta,M} |G|.", block: true)]]

#text("Now we apply the ")#link("https://arxiv.org/abs/1002.2028")[#text("arithmetic lemma of Green")]#text(" with some regularity parameter ")#mi("{\\kappa>0}")#text(" to be chosen later. This allows us to partition ")#mi("{G}")#text(" into cosets of a subgroup ")#mi("{H}")#text(" of index ")#mi("{O_{p,\\kappa}(1)}")#text(", such that on all but ")#mi("{\\kappa [G:H]}")#text(" of these cosets ")#mi("{y+H}")#text(", all the color classes ")#mi("{\\{x \\in y+H: c(x) = c_0\\}}")#text(" are ")#mi("{\\kappa^{100}}")#text("-regular in the Fourier (")#mi("{U^2}")#text(") sense. Now we sample ")#mi("{x_1}")#text(" uniformly from ")#mi("{G}")#text(", and set ")#mi("{x_2 := 2x_1}")#text("; as ")#mi("{p}")#text(" is odd, ")#mi("{x_2}")#text(" is also uniform in ")#mi("{G}")#text(". If ")#mi("{x_1}")#text(" lies in a coset ")#mi("{y+H}")#text(", then ")#mi("{x_2}")#text(" will lie in ")#mi("{2y+H}")#text(". By removing an exceptional event of probability ")#mi("{O(\\kappa)}")#text(", we may assume that neither of these cosetgs ")#mi("{y+H}")#text(", ")#mi("{2y+H}")#text(" is a bad coset. By removing a further exceptional event of probability ")#mi("{O_M(\\kappa)}")#text(", we may also assume that ")#mi("{x_1}")#text(" is in a popular color class of ")#mi("{y+H}")#text(" in the sense that")

#metadata(none) <tao-ad667b78ba8ed0275868>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\{ x \\in y+H: c(x) = c(x_1) \\}\\right| \\geq \\kappa \\left|H\\right|", block: true)]]

#text("since the set of exceptional ")#mi("{x_1}")#text(" that fail to achieve this only are hit with probability ")#mi("{O(M\\kappa)}")#text(". Similarly we may assume that")

#metadata(none) <tao-9d1dca7a0105ab51bd0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\{ x \\in 2y+H: c(x) = c(x_2) \\}\\right| \\geq \\kappa |H|.", block: true)]]

#text("Now we consider the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ h \\in y+H: c(h) = c(x_1); c(h+x_1)=c(x_2) \\}\\right|", block: true)]]

#text("which we can write as")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| {\\bf E}_{h \\in y+H} 1_{c^{-1}(c(x_1))}(h) 1_{c^{-1}(c(x_2))}(h+x_1).", block: true)]]

#text("Both factors here are ")#mi("{O(\\kappa^{100})}")#text("-uniform in their respective cosets. Thus by standard Fourier calculations, we see that after excluding another exceptional event of probabitiy ")#mi("{O(\\kappa)}")#text(", this quantity is equal to")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| (({\\bf E}_{h \\in y+H} 1_{c^{-1}(c(x_1))}(h)) ({\\bf E}_{h \\in y+H} 1_{c^{-1}(c(x_2))}(h+x_1)) + O(\\kappa^{10})).", block: true)]]

#text("By ")#link(<tao-ad667b78ba8ed0275868>)[#text("(1)")]#text(", ")#link(<tao-9d1dca7a0105ab51bd0c>)[#text("(2)")]#text(", this expression is ")#tao-math("{\\gg \\kappa^2 \\left|H\\right| \\gg_{p,\\kappa} \\left|G\\right|}", block: false)#text(". By choosing ")#mi("{\\kappa}")#text(" small enough depending on ")#mi("{M,\\delta}")#text(", we can ensure that ")#mi("{x_1 \\in E_1}")#text(" and ")#mi("{x_2 \\in E_2}")#text(", and the claim follows.")

#text("Now we can prove the infinitary result in Theorem ")#link(<tao-24662b8dadce67970fac>)[#text("7")]#text(". Let us place a metric ")#mi("{d}")#text(" on ")#mi("{X}")#text(". By sparsifying the Følner sequence ")#mi("{\\Phi_j = y_j + {\\bf F}_p^{N_j}}")#text(", we may assume that the ")#mi("{n_j}")#text(" grow as fast as we wish. Once we do so, we claim that for each ")#mi("{J}")#text(", we can find ")#mi("{x_{1,J}, x_{2,J} \\in X}")#text(" such that for each ")#mi("{1 \\leq j \\leq J}")#text(", there exists ")#mi("{n_j \\in \\Phi_j}")#text(" that lies outside of ")#mi("{{\\bf F}_p^j}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d(T^{n_j} a, x_{1,J}) \\leq 1/j, \\quad d(T^{n_j} x_{1,J}, x_{2,J}) \\leq 1/j.")]]

#text("Passing to a subsequence to make ")#mi("{x_{1,J}, x_{2,J}}")#text(" converge to ")#mi("{x_1, x_2}")#text(" respectively, we obtain the desired Erdös progression.")

#text("Fix ")#mi("{J}")#text(", and let ")#mi("{M}")#text(" be a large parameter (much larger than ")#mi("{J}")#text(") to be chosen later. By genericity, we know that the discrete measures ")#mi("{{\\bf E}_{h \\in \\Phi_M} \\delta_{T^h a}}")#text(" converge vaguely to ")#mi("{\\mu}")#text(", so any point in the support in ")#mi("{\\mu}")#text(" can be approximated by some point ")#mi("{T^h a}")#text(" with ")#mi("{h \\in \\Phi_M}")#text(". Unfortunately, ")#mi("{a}")#text(" does not necessarily lie in this support! (Note that ")#mi("{\\Phi_M}")#text(" need not contain the origin.) However, we are assuming a continuous factor map ")#mi("{\\pi:X \\rightarrow Z}")#text(" to the Kronecker factor ")#mi("{Z}")#text(", which is a compact abelian group, and ")#mi("{\\mu}")#text(" pushes down to the Haar measure of ")#mi("{Z}")#text(", which has full support. In particular, thus pushforward contains ")#mi("{\\pi(a)}")#text(". As a consequence, we can find ")#mi("{h_M \\in \\Phi_M}")#text(" such that ")#mi("{\\pi(T^{h_M} a)}")#text(" converges to ")#mi("{\\pi(a)}")#text(", even if we cannot ensure that ")#mi("{T^{h_M} a}")#text(" converges to ")#mi("{a}")#text(". We are assuming that ")#mi("{\\Phi_M}")#text(" is a coset of ")#mi("{{\\bf F}_p^{n_M}}")#text(", so now ")#mi("{{\\bf E}_{h \\in {\\bf F}_p^{n_M}} \\delta_{T^{h+h_M} a}}")#text(" converges vaguely to ")#mi("{\\mu}")#text(".")

#text("We make the random choice ")#mi("{x_{1,J} := T^{h_*+h_M} a}")#text(", ")#mi("{x_{2,J} := T^{2h_*+h_M} a}")#text(", where ")#mi("{h_*}")#text(" is drawn uniformly at random from ")#mi("{{\\bf F}_p^{n_M}}")#text(". This is not the only possible choice that can be made here, and is in fact not optimal in certain respects (in particular, it creates a fair bit of coupling between ")#mi("{x_{1,J}}")#text(", ")#mi("{x_{2,J}}")#text("), but is easy to describe and will suffice for our argument. (A more appropriate choice, closer to the arguments of Kra et al., would be to ")#mi("{x_{2,J}}")#text(" in the above construction by ")#mi("{T^{2h_*+k_*+h_M} a}")#text(", where the additional shift ")#mi("{k_*}")#text(" is a random variable in ")#mi("{{\\bf F}_p^{n_M}}")#text(" independent of ")#mi("{h_*}")#text(" that is uniformly drawn from all shifts annihilated by the first ")#mi("{M}")#text(" characters associated to some enumeration of the (necessarily countable) point spectrum of ")#mi("{T}")#text(", but this is harder to describe.)")

#text("Since we are in odd characteristic, the map ")#mi("{h \\mapsto 2h}")#text(" is a permutation on ")#mi("{h \\in {\\bf F}_p^{n_M}}")#text(", and so ")#mi("{x_{1,J}}")#text(", ")#mi("{x_{2,J}}")#text(" are both distributed according to the law ")#mi("{{\\bf E}_{h \\in {\\bf F}_p^{n_M}} \\delta_{T^{h+h_M} a}}")#text(", though they are coupled to each other. In particular, by vague convergence (and inner regularity) we have")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( x_{1,J} \\in E_1 ) \\geq \\mu(E_1) - o(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( x_{2,J} \\in E_2 ) \\geq \\mu(E_2) - o(1)")]]

#text("where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{M \\rightarrow \\infty}")#text(" (holding all other parameters fixed). By the hypothesis ")#mi("{\\mu(E_1)+\\mu(E_2) > 1}")#text(", we thus have")

#metadata(none) <tao-12988d949c75d06e324e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf P}( x_{1,J} \\in E_1, x_{2,J} \\in E_2 ) \\geq \\kappa - o(1)")]]

#text("for some ")#mi("{\\kappa>0}")#text(" independent of ")#mi("{M}")#text(".")

#text("We will show that for each ")#mi("{1 \\leq j \\leq J}")#text(", one has ")#metadata(none) <tao-5a286081bdfcd45d4980>#tao-math("\\displaystyle  \\left|\\{ h \\in \\Phi_j: d(T^{h} a,x_{1,J}) \\leq 1/j, d(T^h x_{1,J},x_{2,J}) \\leq 1/j \\}\\right| \\ \\ \\ \\ \\ (4)", block: false)

#align(center)[#tao-fit-display[#tao-math("\\gg_{p,\\kappa,j,X} (1-o(1)) \\left|\\Phi_j\\right|", block: true)]]

#text("outside of an event of probability at most ")#mi("{\\kappa/2^{j+1}+o(1)}")#text(" (compare with Theorem ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("8")]#text("). If this is the case, then by the union bound we can find (for ")#mi("{M}")#text(" large enough) a choice of ")#mi("{x_{1,J}}")#text(", ")#mi("{x_{2,J}}")#text(" obeying ")#link(<tao-12988d949c75d06e324e>)[#text("(3)")]#text(" as well as ")#link(<tao-5a286081bdfcd45d4980>)[#text("(4)")]#text(" for all ")#mi("{1 \\leq j \\leq J}")#text(". If the ")#mi("{N_j}")#text(" grow fast enough, we can then ensure that for each ")#mi("{1 \\leq j \\leq J}")#text(" one can find (again for ")#mi("{M}")#text(" large enough) ")#mi("{n_j}")#text(" in the set in ")#link(<tao-5a286081bdfcd45d4980>)[#text("(4)")]#text(" that avoids ")#mi("{{\\bf F}_p^j}")#text(", and the claim follows.")

#text("It remains to show ")#link(<tao-5a286081bdfcd45d4980>)[#text("(4)")]#text(" outside of an exceptional event of acceptable probability. Let ")#mi("{\\tilde c: X \\rightarrow \\{1,\\dots,M_j\\}}")#text(" be the coloring function from the proof of Theorem ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("8")]#text(" (with ")#mi("{\\varepsilon := 1/j}")#text("). Then it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ h \\in \\Phi_j: c_0(h) = c(h_*); c(h+h_*)=c(2h_*) \\}\\right| \\gg_{p,\\kappa,M_j} (1-o(1)) \\left|\\Phi_j\\right|", block: true)]]

#text("where ")#mi("{c_0(h) := \\tilde c(T^h a)}")#text(" and ")#mi("{c(h) := \\tilde c(T^{h+h_M} a)}")#text(". This is a counting problem associated to the patterm ")#mi("{(h_*, h, h+h_*, 2h_*)}")#text("; if we concatenate the ")#mi("{h_*}")#text(" and ")#mi("{2h_*}")#text(" components of the pattern, this is a classic “complexity one” pattern, of the type that would be expected to be amenable to Fourier analysis (especially if one applies Cauchy-Schwarz to eliminate the ")#mi("{h_*}")#text(" averaging and absolute value, at which point one is left with the ")#mi("{U^2}")#text(" pattern ")#mi("{(h, h+h_*, h^{\\prime}, h^{\\prime}+h_*)}")#text(").")

#text("In the finitary setting, we used the arithmetic regularity lemma. Here, we will need to use the Kronecker factor instead. The indicator function ")#mi("{1_{\\tilde c^{-1}(i)}}")#text(" of a level set of the coloring function ")#mi("{\\tilde c}")#text(" is a bounded measurable function of ")#mi("{X}")#text(", and can thus be decomposed into a function ")#mi("{f_i}")#text(" that is measurable on the Kronecker factor, plus an error term ")#mi("{g_i}")#text(" that is orthogonal to that factor and thus is weakly mixing in the sense that ")#tao-math("{\\left|\\langle T^h g_i, g_i \\rangle\\right|}", block: false)#text(" tends to zero on average (or equivalently, that the Host-Kra seminorm ")#tao-math("{\\left\\|g_i\\right\\|_{U^2}}", block: false)#text(" vanishes). Meanwhile, for any ")#mi("{\\varepsilon > 0}")#text(", the Kronecker-measurable function ")#mi("{f_i}")#text(" can be decomposed further as ")#mi("{P_{i,\\varepsilon} + k_{i,\\varepsilon}}")#text(", where ")#mi("{P_{i,\\varepsilon}}")#text(" is a bounded “trigonometric polynomial” (a finite sum of eigenfunctions) and ")#tao-math("{\\left\\|k_{i,\\varepsilon}\\right\\|_{L^2} < \\varepsilon}", block: false)#text(". The polynomial ")#mi("{P_{i,\\varepsilon}}")#text(" is continuous by hypothesis. The other two terms in the decomposition are merely meaurable, but can be approximated to arbitrary accuracy by continuous functions. The upshot is that we can arrive at a decomposition")

#align(center)[#tao-fit-display[#mitex("1_{\\tilde c^{-1}(i)} = P_{i,\\varepsilon} + k_{i,\\varepsilon,\\varepsilon^{\\prime}} + g_{i,\\varepsilon^{\\prime}}")]]

#text("(analogous to the arithmetic regularity lemma) for any ")#mi("{\\varepsilon,\\varepsilon^{\\prime}>0}")#text(", where ")#mi("{k_{i,\\varepsilon,\\varepsilon^{\\prime}}}")#text(" is a bounded continuous function of ")#mi("{L^2}")#text(" norm at most ")#mi("{\\varepsilon}")#text(", and ")#mi("{g_{i,\\varepsilon^{\\prime}}}")#text(" is a bounded continuous function of ")#mi("{U^2}")#text(" norm at most ")#mi("{\\varepsilon^{\\prime}}")#text(" (in practice we will take ")#mi("{\\varepsilon^{\\prime}}")#text(" much smaller than ")#mi("{\\varepsilon}")#text("). Pulling back to ")#mi("{c}")#text(", we then have")

#metadata(none) <tao-dffe602cd1e0bfa9b4d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("1_{c(h)=i} = P_{i,\\varepsilon}(T^{h+h_M} a) + k_{i,\\varepsilon,\\varepsilon^{\\prime}}(T^{h+h_M}a) + g_{i,\\varepsilon^{\\prime}}(T^{h+h_M}a).")]]

#text("Let ")#mi("{\\varepsilon,\\varepsilon^{\\prime}>0}")#text(" be chosen later. The trigonometric polynomial ")#mi("{h \\mapsto P_{i,\\varepsilon}(T^{h} a)}")#text(" is just a sum of ")#mi("{O_{\\varepsilon,M_j}(1)}")#text(" characters on ")#mi("{G}")#text(", so one can find a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" of index ")#mi("{O_{p,\\varepsilon,M_j}(1)}")#text(" such that these polynomial are constant on each coset of ")#mi("{H}")#text(" for all ")#mi("{i}")#text(". Then ")#mi("{h_*}")#text(" lies in some coset ")#mi("{a_*+H}")#text(" and ")#mi("{2h_*}")#text(" lies in the coset ")#mi("{2a_*+H}")#text(". We then restrict ")#mi("{h}")#text(" to also lie in ")#mi("{a_*+H}")#text(", and we will show that")

#metadata(none) <tao-8b0805c2044b4e5eff78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\{ h \\in \\Phi_j \\cap (a_*+H): c_0(h) = c(h_*); c(h+h_*)=c(2h_*) \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\gg_{\\kappa,p,M_j} (1-o(1)) \\left|\\Phi_j \\cap (a_*+H)\\right|", block: true)]]

#text("outside of an exceptional event of proability ")#mi("{\\kappa/2+o(1)}")#text(", which will establish our claim because ")#mi("{\\varepsilon}")#text(" will ultimately be chosen to dependon ")#mi("{p,\\kappa,M_j}")#text(".")

#text("The left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i,i^{\\prime}} \\sum_{h \\in \\Phi_j \\cap (a_*+H)} 1_{c_0(h)=i} 1_{c(h_*)=i, c(2h_*)=i^{\\prime}} 1_{c(h+h_*)=i^{\\prime}}.")]]

#text("The coupling of the constraints ")#mi("{c(h_*)=i}")#text(" and ")#mi("{c(2h_*)=i^{\\prime}}")#text(" is annoying (as ")#mi("{(h_*,2h_*)}")#text(" is an “infinite complexity” pattern that cannot be controlled by any uniformity norm), but (perhaps surprisingly) will not end up causing an essential difficulty to the argument, as we shall see when we start eliminating the terms in this sum one at a time starting from the right.")

#text("We decompose the ")#mi("{1_{c(h+h_*)=i^{\\prime}}}")#text(" term using ")#link(<tao-dffe602cd1e0bfa9b4d8>)[#text("(5)")]#text(":")

#align(center)[#tao-fit-display[#mitex("1_{c(h+h_*)=i^{\\prime}} = P_{i^{\\prime},\\varepsilon}(T^{h+h_*+h_M} a) + k_{i,\\varepsilon,\\varepsilon^{\\prime}}(T^{h+h_*+h_M}a) + g_{i,\\varepsilon^{\\prime}}(T^{h+h_*+h_M}a).")]]

#text("By Markov’s inequality, and removing an exceptional event of probabiilty at most ")#mi("{\\kappa/100}")#text(", we may assume that the ")#mi("{g_{i^{\\prime},\\varepsilon}}")#text(" have normalized ")#mi("{L^2}")#text(" norm ")#mi("{O_{\\kappa,M_j}(\\varepsilon)}")#text(" on both of these cosets ")#mi("{a_*+H, 2a_*+H}")#text(". As such, the contribution of ")#mi("{k_{i^{\\prime},\\varepsilon,\\varepsilon^{\\prime}}(T^{h+h_*+h_M}a)}")#text(" to ")#link(<tao-8b0805c2044b4e5eff78>)[#text("(6)")]#text(" become negligible if ")#mi("{\\varepsilon}")#text(" is small enough (depending on ")#mi("{\\kappa,p,M_j}")#text("). From the near weak mixing of the ")#mi("{g_{i,\\varepsilon^{\\prime}}}")#text(", we know that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{h \\in \\Phi_j \\cap (a_*+H)} \\left|\\langle T^h g_{i,\\varepsilon^{\\prime}}, g_{i,\\varepsilon^{\\prime}} \\rangle\\right| \\ll_{p,\\varepsilon,M_j} \\varepsilon^{\\prime}", block: true)]]

#text("for all ")#mi("{i}")#text(", if we choose ")#mi("{\\Phi_j}")#text(" large enough. By genericity of ")#mi("{a}")#text(", this implies that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{h \\in \\Phi_j \\cap (a_*+H)} \\left|{\\bf E}_{l \\in {\\bf F}_p^{n_M}} g_{i,\\varepsilon^{\\prime}}(T^{h+l+h_M} a) g_{i,\\varepsilon^{\\prime}}(T^{l+h_M} a)\\right| \\ll_{p,\\varepsilon,M_j} \\varepsilon^{\\prime} + o(1).", block: true)]]

#text("From this and standard Cauchy-Schwarz (or van der Corput) arguments we can then show that the contribution of the ")#mi("{g_{i^{\\prime},\\varepsilon^{\\prime}}(T^{h+h_*+h_M}a)}")#text(" to ")#link(<tao-8b0805c2044b4e5eff78>)[#text("(6)")]#text(" is negligible outside of an exceptional event of probability at most ")#mi("{\\kappa/100+o(1)}")#text(", if ")#mi("{\\varepsilon^{\\prime}}")#text(" is small enough depending on ")#mi("{\\kappa,p,M_j,\\varepsilon}")#text(". Finally, the quantity ")#mi("{P_{i^{\\prime},\\varepsilon}(T^{h+h_*+h_M} a)}")#text(" is independent of ")#mi("{h}")#text(", and in fact is equal up to negligible error to the density of ")#mi("{c^{-1}(i^{\\prime})}")#text(" in the coset ")#mi("{{\\bf F}_p^{M_j}(2a_*+H)}")#text(". This density will be ")#mi("{\\gg_{p,\\kappa,M_j}}")#text(" except for those ")#mi("{i^{\\prime}}")#text(" which would have made a negligible impact on ")#link(<tao-8b0805c2044b4e5eff78>)[#text("(6)")]#text(" in any event due to the rareness of the event ")#mi("{c(2h_*)=i^{\\prime}}")#text(" in such cases. As such, to prove ")#link(<tao-8b0805c2044b4e5eff78>)[#text("(6)")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i,i^{\\prime}} \\sum_{h \\in \\Phi_j \\cap (a_*+H)} 1_{c_0(h)=i} 1_{c(h_*)=i, c(2h_*)=i^{\\prime}} \\gg_{\\kappa,p,M_j} (1-o(1)) \\left|\\Phi_j \\cap (a_*+H)\\right|", block: true)]]

#text("outside of an event of probability ")#mi("{\\kappa/100+o(1)}")#text(". Now one can sum in ")#mi("{i^{\\prime}}")#text(" to simplify the above estiamte to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i} 1_{c(h_*)=i} (\\sum_{h \\in \\Phi_j \\cap (a_*+H)} 1_{c_0(h)=i}) / \\left|\\Phi_j \\cap (a_*+H)\\right| \\gg_{\\kappa,p,M_j} 1-o(1).", block: true)]]

#text("If ")#mi("{i}")#text(" is such that ")#tao-math("{(\\sum_{h \\in \\Phi_j \\cap (a_*+H)} 1_{c_0(h)=i})/\\left|\\Phi_j \\cap (a_*+H)\\right|}", block: false)#text(" is small compared with ")#mi("{p,\\kappa,M_j}")#text(", then by genericity (and assuming ")#mi("{\\Phi_j}")#text(" large enough), the probability that ")#mi("{c(h_*)=i}")#text(" will similarly be small (up to ")#mi("{o(1)}")#text(" errors), and thus have a negligible influence on the above sum. As such, the above estimate simplifies to")

#align(center)[#tao-fit-display[#mitex("\\sum_{i} 1_{c(h_*)=i} \\gg_{\\kappa,p,M_j} 1-o(1).")]]

#text("But the left-hand side sums to one, and the claim follows.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/24/notes-on-the-bbt-theorem/#comment-684810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("In Theorem 2 you have “each integer $t$”. Should this be “each $t in G$”?")

#emph[#text("[Corrected, thanks – T.]")]
]
