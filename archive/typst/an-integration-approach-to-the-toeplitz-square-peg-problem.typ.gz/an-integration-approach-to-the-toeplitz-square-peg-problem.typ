// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/
// Converted to Typst by tao2typ: "2026-10-14T10:38:24.369505+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An integration approach to the Toeplitz square peg problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An integration approach to the Toeplitz square peg problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 November 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/")[#text("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1611.07441")[#text("An integration approach to the Toeplitz square peg problem")]#text("“, submitted to ")#link("https://www.cambridge.org/core/journals/forum-of-mathematics-sigma")[#text("Forum of Mathematics, Sigma")]#text(". This paper resulted from my attempts recently to solve the Toeplitz square peg problem (also known as the ")#link("https://en.wikipedia.org/wiki/Inscribed_square_problem")[#text("inscribed square problem")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Toeplitz square peg problem)")]#text(" ")#metadata(none) <tao-798b3ab7f95ee6a72bb5>#text(" Let ")#mi("{\\gamma}")#text(" be a simple closed curve in the plane. Is it necessarily the case that ")#mi("{\\gamma}")#text(" contains four vertices of a square?")
]

#text("See ")#link("http://www.ams.org/notices/201404/rnoti-p346.pdf")[#text("this recent survey")]#text(" of Matschke in the Notices of the AMS for the latest results on this problem.")

#text("The route I took to the results in this paper was somewhat convoluted. I was motivated to look at this problem after lecturing recently on the ")#link("https://en.wikipedia.org/wiki/Jordan_curve_theorem")[#text("Jordan curve theorem")]#text(" in my class. The problem is superficially similar to the Jordan curve theorem in that the result is known (and rather easy to prove) if ")#mi("{\\gamma}")#text(" is sufficiently regular (e.g. if it is a polygonal path), but seems to be significantly more difficult when the curve is merely assumed to be continuous. Roughly speaking, all the known positive results on the problem have proceeded using (in some form or another) tools from homology: note for instance that one can view the conjecture as asking whether the four-dimensional subset ")#mi("{\\gamma^4}")#text(" of the eight-dimensional space ")#mi("{({\\bf R}^2)^4}")#text(" necessarily intersects the four-dimensional space ")#mi("{\\mathtt{Squares} \\subset ({\\bf R}^2)^4}")#text(" consisting of the quadruples ")#mi("{(v_1,v_2,v_3,v_4)}")#text(" traversing a square in (say) anti-clockwise order; this space is a four-dimensional linear subspace of ")#mi("{({\\bf R}^2)^4}")#text(", with a two-dimensional subspace of “degenerate” squares ")#mi("{(v,v,v,v)}")#text(" removed. If one ignores this degenerate subspace, one can use intersection theory to conclude (under reasonable “transversality” hypotheses) that ")#mi("{\\gamma^4}")#text(" intersects ")#mi("{\\mathtt{Squares}}")#text(" an odd number of times (up to the cyclic symmetries of the square), which is basically how Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(" is proven in the regular case. Unfortunately, if one then takes a limit and considers what happens when ")#mi("{\\gamma}")#text(" is just a continuous curve, the odd number of squares created by these homological arguments could conceivably all degenerate to points, thus blocking one from proving the conjecture in the general case.")

#text("Inspired by my ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("previous work")]#text(" on finite time blowup for various PDEs, I first tried looking for a counterexample in the category of (locally) self-similar curves that are smooth (or piecewise linear) away from a single origin where it can oscillate infinitely often; this is basically the smoothest type of curve that was not already covered by previous results. By a rescaling and compactness argument, it is not difficult to see that such a counterexample would exist if there was a counterexample to the following periodic version of the conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Periodic square peg problem)")]#text(" ")#metadata(none) <tao-b8b40d56d2a67d525f10>#text(" Let ")#mi("{\\gamma_1, \\gamma_2}")#text(" be two disjoint simple closed piecewise linear curves in the cylinder ")#mi("{({\\bf R}/{\\bf Z}) \\times {\\bf R}}")#text(" which have a winding number of one, that is to say they are homologous to the loop ")#mi("{x \\mapsto (x,0)}")#text(" from ")#mi("{{\\bf R}/{\\bf Z}}")#text(" to ")#mi("{({\\bf R}/{\\bf Z}) \\times {\\bf R}}")#text(". Then the union of ")#mi("{\\gamma_1}")#text(" and ")#mi("{\\gamma_2}")#text(" contains the four vertices of a square.")
]

#text("In contrast to Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(", which is known for polygonal paths, Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(" is still open even under the hypothesis of polygonal paths; the homological arguments alluded to previously now show that the number of inscribed squares in the periodic setting is ")#emph[#text("even")]#text(" rather than ")#emph[#text("odd")]#text(", which is not enough to conclude the conjecture. (This flipping of parity from odd to even due to an infinite amount of oscillation is reminiscent of the “")#link("http://en.wikipedia.org/wiki/Eilenberg%E2%80%93Mazur_swindle")[#text("Eilenberg-Mazur swindle")]#text("“, discussed in ")#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/")[#text("this previous post")]#text(".)")

#text("I therefore tried to construct counterexamples to Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(". I began perturbatively, looking at curves ")#mi("{\\gamma_1, \\gamma_2}")#text(" that were small perturbations of constant functions. After some initial Taylor expansion, I was blocked from forming such a counterexample because an inspection of the leading Taylor coefficients required one to construct a continuous periodic function of mean zero that never vanished, which of course was impossible by the intermediate value theorem. I kept expanding to higher and higher order to try to evade this obstruction (this, incidentally, was when I discovered ")#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/")[#text("this cute application of Lagrange reversion")]#text(") but no matter how high an accuracy I went (I think I ended up expanding to sixth order in a perturbative parameter ")#mi("{\\varepsilon}")#text(" before figuring out what was going on!), this obstruction kept resurfacing again and again. I eventually figured out that this obstruction was being caused by a “conserved integral of motion” for both Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(" and Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(", which can in fact be used to largely rule out perturbative constructions. This yielded a new positive result for both conjectures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>

#list(
[#text("(i) Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(" holds when ")#mi("{\\gamma}")#text(" is the union ")#mi("{\\{ (t,f(t)): t \\in [t_0,t_1]\\} \\cup \\{ (t,g(t)): t \\in [t_0,t_1]\\}}")#text(" of the graphs of two Lipschitz functions ")#mi("{f,g: [t_0,t_1] \\rightarrow {\\bf R}}")#text(" of Lipschitz constant less than one that agree at the endpoints.")],
[#text("(ii) Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(" holds when ")#mi("{\\gamma_1, \\gamma_2}")#text(" are graphs of Lipschitz functions ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}, g: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(" of Lipschitz constant less than one.")]
)
]

#text("We sketch the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("3")]#text("(i) as follows (the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("3")]#text("(ii) is very similar). Let ")#mi("{\\gamma_1: [t_0, t_1] \\rightarrow {\\bf R}}")#text(" be the curve ")#mi("{\\gamma_1(t) := (t,f(t))}")#text(", thus ")#mi("{\\gamma_1}")#text(" traverses one of the two graphs that comprise ")#mi("{\\gamma}")#text(". For each time ")#mi("{t \\in [t_0,t_1]}")#text(", there is a unique square with first vertex ")#mi("{\\gamma_1(t)}")#text(" (and the other three vertices, traversed in anticlockwise order, denoted ")#mi("{\\gamma_2(t), \\gamma_3(t), \\gamma_4(t)}")#text(") such that ")#mi("{\\gamma_2(t)}")#text(" also lies in the graph of ")#mi("{f}")#text(" and ")#mi("{\\gamma_4(t)}")#text(" also lies in the graph of ")#mi("{g}")#text(" (actually for technical reasons we have to extend ")#mi("{f,g}")#text(" by constants to all of ")#mi("{{\\bf R}}")#text(" in order for this claim to be true). To see this, we simply rotate the graph of ")#mi("{g}")#text(" clockwise by ")#mi("{\\frac{\\pi}{2}}")#text(" around ")#mi("{\\gamma_1(t)}")#text(", where (by the Lipschitz hypotheses) it must hit the graph of ")#mi("{f}")#text(" in a unique point, which is ")#mi("{\\gamma_2(t)}")#text(", and which then determines the other two vertices ")#mi("{\\gamma_3(t), \\gamma_4(t)}")#text(" of the square. The curve ")#mi("{\\gamma_3(t)}")#text(" has the same starting and ending point as the graph of ")#mi("{f}")#text(" or ")#mi("{g}")#text("; using the Lipschitz hypothesis one can show this graph is simple. If the curve ever hits the graph of ")#mi("{g}")#text(" other than at the endpoints, we have created an inscribed square, so we may assume for contradiction that ")#mi("{\\gamma_3(t)}")#text(" avoids the graph of ")#mi("{g}")#text(", and hence by the Jordan curve theorem the two curves enclose some non-empty bounded open region ")#mi("{\\Omega}")#text(".")

#text("Now for the conserved integral of motion. If we integrate the ")#mi("{1}")#text("-form ")#mi("{y\\ dx}")#text(" on each of the four curves ")#mi("{\\gamma_1, \\gamma_2, \\gamma_3, \\gamma_4}")#text(", we obtain the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_1} y\\ dx - \\int_{\\gamma_2} y\\ dx + \\int_{\\gamma_3} y\\ dx - \\int_{\\gamma_4} y\\ dx = 0.")]]

#text("This identity can be established by the following calculation: one can parameterise")

#tao-aligned(keep: true)[


#tao-math("\\gamma_1(t)  & = (x(t), y(t))", block: true)



#tao-math("\\gamma_2(t)  & = (x(t)+a(t), y(t)+b(t))", block: true)



#tao-math("\\gamma_3(t)  & = (x(t)+a(t)-b(t), y(t)+a(t)+b(t))", block: true)



#tao-math("\\gamma_4(t)  & = (x(t)-b(t), y(t)+a(t))", block: true)
]

#text("for some Lipschitz functions ")#mi("{x,y,a,b: [t_0,t_1] \\rightarrow {\\bf R}}")#text("; thus for instance ")#mi("{\\int_{\\gamma_1} y\\ dx = \\int_{t_0}^{t_1} y(t)\\ dx(t)}")#text(". Inserting these parameterisations and doing some canceling, one can write the above integral as")

#align(center)[#tao-fit-display[#mitex("\\int_{t_0}^{t_1} d \\frac{a(t)^2-b(t)^2}{2}")]]

#text("which vanishes because ")#mi("{a(t), b(t)}")#text(" (which represent the sidelengths of the squares determined by ")#mi("{\\gamma_1(t), \\gamma_2(t), \\gamma_3(t), \\gamma_4(t)}")#text(" vanish at the endpoints ")#mi("{t=t_0,t_1}")#text(".")

#text("Using this conserved integral of motion, one can show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_3} y\\ dx = \\int_{t_0}^{t_1} g(t)\\ dt")]]

#text("which by Stokes’ theorem then implies that the bounded open region ")#mi("{\\Omega}")#text(" mentioned previously has zero area, which is absurd.")

#text("This argument hinged on the curve ")#mi("{\\gamma_3}")#text(" being simple, so that the Jordan curve theorem could apply. Once one left the perturbative regime of curves of small Lipschitz constant, it became possible for ")#mi("{\\gamma_3}")#text(" to be self-crossing, but nevertheless there still seemed to be some sort of integral obstruction. I eventually isolated the problem in the form of a strengthened version of Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 4 (Area formulation of square peg problem)")]#text(" ")#metadata(none) <tao-4a91ee5f0106c2b35c11>#text(" Let ")#mi("{\\gamma_1, \\gamma_2, \\gamma_3, \\gamma_4: {\\bf R}/{\\bf Z} \\rightarrow ({\\bf R}/{\\bf Z}) \\times {\\bf R}}")#text(" be simple closed piecewise linear curves of winding number ")#mi("{1}")#text(" obeying the area identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_1} y\\ dx - \\int_{\\gamma_2} y\\ dx + \\int_{\\gamma_3} y\\ dx - \\int_{\\gamma_4} y\\ dx = 0")]]

#text("(note the ")#mi("{1}")#text("-form ")#mi("{y\\ dx}")#text(" is still well defined on the cylinder ")#mi("{({\\bf R}/{\\bf Z}) \\times {\\bf R}}")#text("; note also that the curves ")#mi("{\\gamma_1,\\gamma_2,\\gamma_3,\\gamma_4}")#text(" are allowed to cross each other.) Then there exists a (possibly degenerate) square with vertices (traversed in anticlockwise order) lying on ")#mi("{\\gamma_1, \\gamma_2, \\gamma_3, \\gamma_4}")#text(" respectively.")
]

#text("It is not difficult to see that Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(" implies Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(". Actually I believe that the converse implication is at least morally true, in that any counterexample to Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(" can be eventually transformed to a counterexample to Conjecture ")#link(<tao-b8b40d56d2a67d525f10>)[#text("2")]#text(" and Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(". The conserved integral of motion argument can establish Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(" in many cases, for instance if ")#mi("{\\gamma_2,\\gamma_4}")#text(" are graphs of functions of Lipschitz constant less than one.")

#text("Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(" has a model special case, when one of the ")#mi("{\\gamma_i}")#text(" is assumed to just be a horizontal loop. In this case, the problem collapses to that of producing an intersection between two three-dimensional subsets of a six-dimensional space, rather than to four-dimensional subsets of an eight-dimensional space. More precisely, some elementary transformations reveal that this special case of Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(" can be formulated in the following fashion in which the geometric notion of a square is replaced by the additive notion of a triple of real numbers summing to zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 5 (Special case of area formulation)")]#text(" ")#metadata(none) <tao-7d4c5c8894e016e772e9>#text(" Let ")#mi("{\\gamma_1, \\gamma_2, \\gamma_3: {\\bf R}/{\\bf Z} \\rightarrow ({\\bf R}/{\\bf Z}) \\times {\\bf R}}")#text(" be simple closed piecewise linear curves of winding number ")#mi("{1}")#text(" obeying the area identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_1} y\\ dx + \\int_{\\gamma_2} y\\ dx + \\int_{\\gamma_3} y\\ dx = 0.")]]

#text("Then there exist ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(" and ")#mi("{y_1,y_2,y_3 \\in {\\bf R}}")#text(" with ")#mi("{y_1+y_2+y_3=0}")#text(" such that ")#mi("{(x,y_i) \\in \\gamma_i}")#text(" for ")#mi("{i=1,2,3}")#text(".")
]

#text("This conjecture is easy to establish if one of the curves, say ")#mi("{\\gamma_3}")#text(", is the graph ")#mi("{\\{ (t,f(t)): t \\in {\\bf R}/{\\bf Z}\\}}")#text(" of some piecewise linear function ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(", since in that case the curve ")#mi("{\\gamma_1}")#text(" and the curve ")#mi("{\\tilde \\gamma_2 := \\{ (x, -y-f(x)): (x,y) \\in \\gamma_2 \\}}")#text(" enclose the same area in the sense that ")#mi("{\\int_{\\gamma_1} y\\ dx = \\int_{\\tilde \\gamma_2} y\\ dx}")#text(", and hence must intersect by the Jordan curve theorem (otherwise they would enclose a non-zero amount of area between them), giving the claim. But when none of the ")#mi("{\\gamma_1,\\gamma_2,\\gamma_3}")#text(" are graphs, the situation becomes combinatorially more complicated.")

#text("Using some elementary homological arguments (e.g. breaking up closed ")#mi("{1}")#text("-cycles into closed paths) and working with a generic horizontal slice of the curves, I was able to show that Conjecture ")#link(<tao-7d4c5c8894e016e772e9>)[#text("5")]#text(" was equivalent to a one-dimensional problem that was largely combinatorial in nature, revolving around the sign patterns of various triple sums ")#mi("{y_{1,a} + y_{2,b} + y_{3,c}}")#text(" with ")#mi("{y_{1,a}, y_{2,b}, y_{3,c}}")#text(" drawn from various finite sets of reals.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 6 (Combinatorial form)")]#text(" ")#metadata(none) <tao-8fb32026dd05ec848f71>#text(" Let ")#mi("{k_1,k_2,k_3}")#text(" be odd natural numbers, and for each ")#mi("{i=1,2,3}")#text(", let ")#mi("{y_{i,1},\\dots,y_{i,k_i}}")#text(" be distinct real numbers; we adopt the convention that ")#mi("{y_{i,0}=y_{i,k_i+1}=-\\infty}")#text(". Assume the following axioms:")

#list(
[#text("(i) For any ")#mi("{1 \\leq p \\leq k_1, 1 \\leq q \\leq k_2, 1 \\leq r \\leq k_3}")#text(", the sums ")#mi("{y_{1,p} + y_{2,q} + y_{3,r}}")#text(" are non-zero.")],
[#text("(ii) (Non-crossing) For any ")#mi("{i=1,2,3}")#text(" and ")#mi("{0 \\leq p < q \\leq k_i}")#text(" with the same parity, the pairs ")#mi("{\\{ y_{i,p}, y_{i,p+1}\\}}")#text(" and ")#mi("{\\{y_{i,q}, y_{i,q+1}\\}}")#text(" are non-crossing in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in \\{p,p+1\\}} \\sum_{b \\in \\{q,q+1\\}} (-1)^{a+b} \\mathrm{sgn}( y_{i,a} - y_{i,b} ) = 0.")]]],
[#text("(iii) (Non-crossing sums) For any ")#mi("{0 \\leq p \\leq k_1}")#text(", ")#mi("{0 \\leq q \\leq k_2}")#text(", ")#mi("{0 \\leq r \\leq k_3}")#text(" of the same parity, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in \\{p,p+1\\}} \\sum_{b \\in \\{q,q+1\\}} \\sum_{c \\in \\{r,r+1\\}} (-1)^{a+b+c} \\mathrm{sgn}( y_{1,a} + y_{2,b} + y_{3,c} ) = 0.")]]]
)

#text("Then one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^3 \\sum_{p=1}^{k_i} (-1)^{p-1} y_{i,p} < 0.")]]
]

#text("Roughly speaking, Conjecture ")#link(<tao-8fb32026dd05ec848f71>)[#text("6")]#text(" and Conjecture ")#link(<tao-7d4c5c8894e016e772e9>)[#text("5")]#text(" are connected by constructing curves ")#mi("{\\gamma_i}")#text(" to connect ")#mi("{(0, y_{i,p})}")#text(" to ")#mi("{(0,y_{i,p+1})}")#text(" for ")#mi("{0 \\leq p \\leq k+1}")#text(" by various paths, which either lie to the right of the ")#mi("{y}")#text(" axis (when ")#mi("{p}")#text(" is odd) or to the left of the ")#mi("{y}")#text(" axis (when ")#mi("{p}")#text(" is even). The axiom (ii) is asserting that the numbers ")#mi("{-\\infty, y_{i,1},\\dots,y_{i,k_i}}")#text(" are ordered according to the permutation of a ")#link("https://en.wikipedia.org/wiki/Meander_(mathematics)")[#text("meander")]#text(" (formed by gluing together two non-crossing perfect matchings).")

#text("Using various ")#emph[#text("ad hoc")]#text(" arguments involving “winding numbers”, it is possible to prove this conjecture in many cases (e.g. if one of the ")#mi("{k_i}")#text(" is at most ")#mi("{3}")#text("), to the extent that I have now become confident that this conjecture is true (and have now come full circle from trying to disprove Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(" to now believing that this conjecture holds also). But it seems that there is some non-trivial combinatorial argument to be made if one is to prove this conjecture; purely homological arguments seem to partially resolve the problem, but are not sufficient by themselves.")

#text("While I was not able to resolve the square peg problem, I think these results do provide a roadmap to attacking it, first by focusing on the combinatorial conjecture in Conjecture ")#link(<tao-8fb32026dd05ec848f71>)[#text("6")]#text(" (or its equivalent form in Conjecture ")#link(<tao-7d4c5c8894e016e772e9>)[#text("5")]#text("), then after that is resolved moving on to Conjecture ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("4")]#text(", and then finally to Conjecture ")#link(<tao-798b3ab7f95ee6a72bb5>)[#text("1")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474555")[#strong[#text("Simple unsolved math problem, 2 | Yet Another Mathblog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")]

#text("[…] Added 2016-11-23: See also this recent post by T. Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("Abstract: “ including a a periodic” –> “ including a periodic”")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37531d9674938adc67767adf8c404b8f7ad94e5ed0ddfc5d6cbe8fee940d50a3-6bcd915693ec7827ecaa612d58d15fd4bfbd8447d8cf41dab6bfd6cceb258d69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO T.")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474563")[#strong[#text("HUMBERTO T.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("Revisar, aplicación “g”, conjetura (ii), teorema 3.")

#emph[#text("[Corregido, gracias – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d2cb9ca02c4d5b007613279715ceadb73d74fa735c8cb96096180c783ce4d4-39dbfdd0d1918888e10e662128898a9a50818b189a24d4b037447f6b82d854e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kevinburri")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474564")[#strong[#text("kevinburri")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("In part (ii) of Conjecture 6, should it be “q<=k_i\" instead of \"q<=k_1\"?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474569")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("How large can $k_1$ get in your ad hoc arguments if $k_1=k_2=k_3$? I wonder if a computational method would be feasible for extending the range of applicability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474570")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("I did not systematically check all the cases of low ")#mi("k")#text(", but I imagine it would be fairly straightforward to verify the case ")#mi("k_1=k_2=k_3=5")#text(" for instance numerically (it is a linear programming problem, albeit a non-convex one).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474679")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("Is it a linear programming problem? Doesn’t the presence of the sgn function make it an integer programming problem?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("Consider a generalized form of this problem in which the Eucleadian metric is replaced by a Riemannian metric. Is it possible to apply your method to such generalized problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0dad6b6f8dbf394ca35c19fadc4a4d471004f422e7dd2075fc58ddfe992caf8c-eaf62f5e2772ea435733b346a2e9a2565988e23b0d18db4984a3bdfd4d4bb980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Zsolt Wagner")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474578")[#strong[#text("Adam Zsolt Wagner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("A quick and rough computer search yielded no counterexamples to Conjecture 6.")

#text("I kept generating random arrays ")#mi("y_1, y_2, y_3")#text(" until they satisfied the conditions of the conjecture. Quite unsurprisingly, random arrays are very unlikely to satisfy the last condition so this algorithm is extremely slow. But this remarkably stupid approach was still sufficient to verify Conjecture 6 in about five hundred random instances of the case ")#mi("(k_1,k_2,k_3)=(7,7,7)")#text(" (and many thousands for smaller values of the ")#mi("k_i")#text("-s).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474637")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2016")])]

#text("“(I think I ended up expanding to sixth order in a perturbative parameter ￼ before figuring out what was going on!)”")

#text("I get asked quite regularly “What’s it really like to work with Terry Tao?” and now I know what quote to point them to first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi A. Bajaj")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474674")[#strong[#text("Ravi A. Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("To be perfectly honest, I actually had more trouble with Jordan Curve Theorem than anything else I’ve encountered in my math education… I actually really worked hard on one of your exercises, Exercise 49 in Notes 3, a weekend about a month ago (Halloween time) but arrived at no conclusion and attempted to consult with a reputable classmate to no avail. I will simply say that we both agreed, after I was just really attempting to understand that exercise, that it was non-trivial that “for any Jordan curve \\gamma, the closure of Int(\\gamma) is just Int(\\gamma) \\cup \\gamma.” So I imagine that I am not clear as to why \\gamma cannot be space-filling. Not quite a reply to your post, but perhaps another return to the Jordan Curve Theorem’s difficulty in my opinion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474678")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#link("https://www.youtube.com/watch?v=AmgkSdhK4K8")[#text("Here")]#text("‘s a nice elementary video on the (much easier) inscribed rectangle problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("Absolutely beautiful video!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474696")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("perhaps you mean the ")#strong[#text("four vertex theorem")]#text(" which says “a simple, closed, smooth plane curve has at least four local extrema (specifically, at least two local maxima and at least two local minima)” E.g. an ellipse or circle or conchoid.")

#link("https://en.wikipedia.org/wiki/Four-vertex_theorem")[#text("https://en.wikipedia.org/wiki/Four-vertex_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474715")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("The square peg problem has a simple solution.")

#text("With the integration is very complex to give a solution because it is not asked that the square is inscribed in the curve.")

#text("Let’s go with the solution.")

#text("1º every simple closed curve does not nedd the four vértices of the square. Example all oval (not circle) of the function ")#mi("\\frac{a^{2}(b^{2} - x^{2})}{b^{2}}")#text(" ; ")#mi("a< b")#text(".")

#text("2º In any closed curve we have that.")

#mi("f(x) = f(x+n)")

#text("3º In any simple closed curve ( not oval).")

#mi("\\exists [f(x) = f(x+2f(x))]")

#text("Which implies that: ")#mi("f(x) * 2f(x) = \\frac{A^{2}}{2}")

#text("By point 2 follows that.")

#mi("f(x+n) = f(x_{i}-n)")

#text("If along the whole curve this equality is met, the curve will not have the four vértices of the square.")

#text("Therefore we will have a ")#mi("(x)")#text(" where.")

#mi("f(x+n) \\neq f(x_{i}-n)")#text(" (1)")

#text("And it is at this point that we will resume.")

#mi("f(x_{i}+n) = f(x_{j}-n)")#text("; ")#mi("(x_{i} < x)")

#text("until the value of.")

#mi("[(x_{i} + n) - (x_{j} - n)] = 2f(x_{i} + n)")

#mi("(x_{j} - x_{i}) = 2f(x_{i} + n)")

#text("We know that always ")#mi("\\exists (x_{i} - x = even)")#text(" and therefore in one of them the following relationship will be fulfilled.")

#mi("\\frac{f(x+n)}{x_{i} - x} = \\frac{1}{2}")

#text("Abstract: If it is necessary the existence of the four vertices of the square in the simple closed curve; because if not, we are before and oval.")#linebreak()#text(" This came to be the demonstration by contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("In reference [17] I would probably remove “pp.” in order to use consistant notation.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474747")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Professor Tao, I thonk you may be interested to know what rally matters in my previous comment.")

#text("The relationship.")

#mi("\\frac{f(x+n)}{x_{i} - x} = \\frac{1}{2} = tan \\alpha")

#text("Where:")

#mi("\\alpha = \\frac{90^\\circ}{\\pi}")

#text("Your demonstration will be able to see it in.")

#text("International J. Math. computation Vol 28 (2) 2017.")

#text("You already know how to build with ruler and compass the angle ")#mi("(\\alpha)")#text(" the following is………..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Hi Professor. Tao,")

#text("Nice paper (‘An integration approach to the Toeplitz square peg problem’)! I’m confident your work will lead to more advance research and innovation in topology and in other related areas of mathematics. That’s a very positive development. Thank you! :-)")

#text("However, it may also be the result of over thinking the problem at hand. The Inscribed Square Problem (ISP) is difficult because the general Jordan curve may take countless forms. So we should seek out its invariant properties and apply our knowledge of analytic geometry (equations of parallel and perpendicular lines, and Pythagoras’s Theorem) and Euclidean geometry (similar or almost similar triangles with common diagonals, Law of sines and the Law of cosines, angular rotation about a point and translation from a point to another point).")

#text("I believe the first step is to inscribe the general Jordan curve (J) in a square box (B) with a diagonal whose endpoints are the two points on J that are farthest apart. And we define the center point (cp) of J as the intersection of the two diagonals of the B. And the work of analysis can begin here… And I believe the result should be affirmative! Good luck!")

#text("I believe I can have a tentative proof of ISP in less than a week. Wish me luck! :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Let J’ be the complement object of J such that B = J’ + J.")

#text("Hmm. Let’s filled our square (B) with unit squares (s_1) and let’s assume our inscribed Jordan curve (J) does not have four points on it which form an inscribed square of any size from s_1 to s_n less than the size of B. We should expect a mix of square sizes and shapes in and about J without violating our prime assumption.")

#text("Moreover, we need to formulate boundary conditions between J and J’ and search for a contradiction to our assumption about J. It could be a limiting process or some kind of process of elimination. I am not sure what will work initially. But I have hope in our formulation of the boundary conditions between J and J’ that we shall discover the correct process or procedure and solve our problem affirmatively.. .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2016")])]

#text("Note: We can arrange and rearrange (translate or rotate) our squares (s_1) appropriately without affecting our general Jordan Curve (J).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("In formulating a proof of the Inscribed Square Conjecture, we can distinguish between Jordan curves which obey our assumption (simple closed curves which does not have four points on it that form an inscribed square of any size from the unit square, s_1, to s_n less than the size of the square which inscribes it) and those which do not obey our assumption.")

#text("A Jordan curve which obeys our assumption is exceptional, and we can label it, J_e. And a Jordan curve which does not obey our assumption is regular, and we can label it, J_r.")

#text("Our task is to prove that J_e does not exist. And we can use J_r to help us prove that result. How? Hmm…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("Can we develop J_e from J_r?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("Inscribed Square Conjecture is true! The mapping all four points of the Jordan curve will eventually converge to the four corners or vertices, respectively, of a square of size, s_1, or greater.")

#text("I challenge the great Professor Tao to write the proof. He has the technical skill to do. Good luck!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("Oops… Correction!")

#text("I challenge the great Professor Tao to write the proof. He has the technical skill… Good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2016")])]

#text("Reference link: ")#link("https://www.researchgate.net/post/What_is_the_solution_to_the_inscribed_square_problem_Toeplitz_square_peg_problem")[#text("https://www.researchgate.net/post/What_is_the_solution_to_the_inscribed_square_problem_Toeplitz_square_peg_problem")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-474967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2016")])]

#text("Hmm. Is there a computer program which verifies the Inscribed Square Conjecture?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-488354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2017")])]

#text("coulde there be a highe of")#linebreak()#text(" dimension generate？In general this problem is deal with multiper imtersection of a space so called “cube space generate by the curve” and the curve itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad448442279e2b094820a0249ae860a0ae07ef59738bb42c0f882ed776001c79-71e7cf834e8db5ee421aeb7556c55ea90ba64dd96eaac238b40a3a68eae46b3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo Rampazzo")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-506821")[#strong[#text("Paolo Rampazzo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("Well, I don’t know if you’re going to read this professor Tao, and in case you’re, I don’t know if it will make sense. But an approach I think that maybe one could try to exploit is by trying to see the problem as a linear algebra problem. Given a curve, we could select two points on this curve. The first point we can just pick a random one, and keeping it fixed, the second we can vary along the curve. Two points on the curve will define a vector. Given this vector, we could try to get its orthogonal vector. As there will be an infinite number of vectors orthogonal to the first one, we would then check the set of them which are orthogonal to the first one and for which a line on its direction would intersect the curve at least twice. If we are able to find a orthogonal vector to the first one which intersects the curve twice and whose length matches the length of the first one, then we are done. Is there any chance this would work for a general curve ? Besides the difficult of the problem itself, problems would also arise because for the first point we would have to go through “all” the points on the curve. Well, you’re the right person anyway to tackle this approach.")#linebreak()#text(" Best regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-569510")[#strong[#text("곡선 위의 직사각형들 – Pseudorandom Things")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")]

#text("[…] 동영상과 Zariski님의 관련글에서 이 풀이를 소개하기도 했다. 몇 년 전에는 테렌스 타오도 시도를 해서 주어진 Jordan curve가 두개의 특정한 Lipschitz curve로 나누어지는 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/11/22/an-integration-approach-to-the-toeplitz-square-peg-problem/#comment-686990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2025")])]

#text("Dear professor Tao .I am a 15 year old student exploring a wavelet theory-based approach to the square peg problem. The goal is to inscribe a square inside a Jordan curve by finding distinct points in the domain of a one-to-one, compactly supported function . Rather than relying on traditional methods , I propose utilizing wavelet transformations to enforce the geometric constraints.The square peg problem requires the following conditions to be satisfied:")#mi("(f(a) - f(b)) e^{ik_1} = f(b) - f(c), \\quad(f(a) - f(b)) e^{ik_2} = f(c) - f(d), \\quad(f(a) - f(b)) e^{ik_3} = f(d) - f(a), \\quad(f(a) - f(c)) e^{ik_4} = f(b) - f(d)")#text("These equations enforce equal side lengths (first three equations) and equal diagonals (fourth equation). The key idea is that the left-hand side (LHS) of each equation is represented as the difference of wavelet coefficients (or the inverse wavelet representation) of and , and similarly for the right-hand side (RHS), where the wavelet representation is different.By using different wavelet bases on the LHS and on the RHS of the equations, the effects of distinct variables are nullified.The main advantage of this approach is that, unlike traditional Fourier-based or kernel inversion methods, the wavelet coefficients depend on both the function and the point in the domain. In traditional kernel-based methods, such as Fourier inversion, the kernel is independent of the function , meaning that any transformation will be applied uniformly across the entire function space. This results in solutions that are too general and do not capture the specific geometry of the problem, leading to an inherent limitation when trying to solve for specific shapes like squares.In contrast, the wavelet coefficients vary based on both (the spatial location) and (the function values). The choice of wavelets allows flexibility, ensuring that the transformations depend on the geometry of the Jordan curve itself and enforce equality in the equations. The wavelet transformation creates a dynamic relationship between the variables and the function, which is critical for finding the specific solution to the square peg problem.By leveraging wavelet theory, we avoid the pitfall of using the same kernel for both sides, which would otherwise force a solution that is independent of the function and not tailored to the specific problem geometry. Wavelets provide a more localized and adaptable transformation, making this approach a promising direction to investigate for solving the square peg problem.Could this wavelet-based approach be a feasible direction for solving the square peg problem, or are there any significant obstacles in applying wavelets to this geometric problem?")
]
