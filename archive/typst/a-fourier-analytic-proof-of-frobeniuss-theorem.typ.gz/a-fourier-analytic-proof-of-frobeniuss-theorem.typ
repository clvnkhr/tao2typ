// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:37:01.981624+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Fourier-analytic proof of Frobenius’ theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Fourier-analytic proof of Frobenius’ theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 May 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/")[#text("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A finite group ")#mi("{G=(G,\\cdot)}")#text(" is said to be a ")#link("http://en.wikipedia.org/wiki/Frobenius_group")[#text("Frobenius group")]#text(" if there is a non-trivial subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" (known as the ")#emph[#text("Frobenius complement")]#text(" of ")#mi("{G}")#text(") such that the conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(" are “disjoint as possible” in the sense that ")#mi("{H \\cap gHg^{-1} = \\{1\\}}")#text(" whenever ")#mi("{g \\not \\in H}")#text(". This gives a decomposition ")#metadata(none) <tao-54ca7b83a424aed496ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("G = \\bigcup_{gH \\in G/H} (gHg^{-1} \\backslash \\{1\\}) \\cup K")]]

#text("where the ")#emph[#text("Frobenius kernel")]#text(" ")#mi("{K}")#text(" of ")#mi("{G}")#text(" is defined as the identity element ")#mi("{1}")#text(" together with all the non-identity elements that are not conjugate to any element of ")#mi("{H}")#text(". Taking cardinalities, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right| = \\frac{\\left|G\\right|}{\\left|H\\right|} (\\left|H\\right| - 1) + \\left|K\\right|", block: true)]]

#text("and hence ")#metadata(none) <tao-78032858b52002ee5de8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|H\\right| \\left|K\\right| = \\left|G\\right|.", block: true)]]

#text("A remarkable theorem of Frobenius gives an unexpected amount of structure on ")#mi("{K}")#text(" and hence on ")#mi("{G}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Frobenius’ theorem)")]#text(" ")#metadata(none) <tao-9adf009b9ea42792e73e>#text(" Let ")#mi("{G}")#text(" be a Frobenius group with Frobenius complement ")#mi("{H}")#text(" and Frobenius kernel ")#mi("{K}")#text(". Then ")#mi("{K}")#text(" is a normal subgroup of ")#mi("{G}")#text(", and hence (by ")#link(<tao-78032858b52002ee5de8>)[#text("(2)")]#text(" and the disjointness of ")#mi("{H}")#text(" and ")#mi("{K}")#text(" outside the identity) ")#mi("{G}")#text(" is the semidirect product ")#mi("{K \\rtimes H}")#text(" of ")#mi("{H}")#text(" and ")#mi("{K}")#text(".")
]

#text("I discussed Frobenius’ theorem and its proof in ")#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("this recent blog post")]#text(". This proof uses the theory of ")#link("http://en.wikipedia.org/wiki/Character_theory")[#text("characters on a finite group")]#text(" ")#mi("{G}")#text(", in particular relying on the fact that a character on a subgroup ")#mi("{H}")#text(" can ")#link("http://en.wikipedia.org/wiki/Induced_representation")[#text("induce")]#text(" a character on ")#mi("{G}")#text(", which can then be decomposed into irreducible characters with ")#emph[#text("natural number")]#text(" coefficients. Remarkably, even though a century has passed since Frobenius’ original argument, there is no proof known of this theorem which avoids character theory entirely; there are elementary proofs known when the complement ")#mi("{H}")#text(" has even order or when ")#mi("{H}")#text(" is solvable (we review both of these cases below the fold), which by the ")#link("http://en.wikipedia.org/wiki/Feit%E2%80%93Thompson_theorem")[#text("Feit-Thompson theorem")]#text(" does cover all the cases, but the proof of the Feit-Thompson theorem involves plenty of character theory (and also relies on Theorem ")#link(<tao-9adf009b9ea42792e73e>)[#text("1")]#text("). (The answers to ")#link("http://mathoverflow.net/questions/63142/character-free-proof-that-frobenius-kernel-is-a-normal-subgroup")[#text("this MathOverflow question")]#text(" give a good overview of the current state of affairs.)")

#text("I have been playing around recently with the problem of finding a character-free proof of Frobenius’ theorem. I didn’t succeed in obtaining a completely elementary proof, but I did find an argument which replaces character theory (which can be viewed as coming from the representation theory of the non-commutative group algebra ")#mi("{{\\bf C} G \\equiv L^2(G)}")#text(") with the Fourier analysis of class functions (i.e. the representation theory of the centre ")#mi("{Z({\\bf C} G) \\equiv L^2(G)^G}")#text(" of the group algebra), thus replacing non-commutative representation theory by commutative representation theory. This is not a particularly radical depature from the existing proofs of Frobenius’ theorem, but it did seem to be a new proof which was technically “character-free” (even if it was not all that far from character-based in spirit), so I thought I would record it here.")

#text("The main ideas are as follows. The space ")#mi("{L^2(G)^G}")#text(" of class functions can be viewed as a commutative algebra with respect to the convolution operation ")#mi("{*}")#text("; as the regular representation is unitary and faithful, this algebra contains no nilpotent elements. As such, (Gelfand-style) Fourier analysis suggests that one can analyse this algebra through the idempotents: class functions ")#mi("{\\phi}")#text(" such that ")#mi("{\\phi*\\phi = \\phi}")#text(". In terms of characters, idempotents are nothing more than sums of the form ")#mi("{\\sum_{\\chi \\in \\Sigma} \\chi(1) \\chi}")#text(" for various collections ")#mi("{\\Sigma}")#text(" of characters, but we can perform a fair amount of analysis on idempotents directly without recourse to characters. In particular, it turns out that idempotents enjoy some important integrality properties that can be established without invoking characters: for instance, by taking traces one can check that ")#mi("{\\phi(1)}")#text(" is a natural number, and more generally we will show that ")#mi("{{\\bf E}_{(a,b) \\in S} {\\bf E}_{x \\in G} \\phi( a x b^{-1} x^{-1} )}")#text(" is a natural number whenever ")#mi("{S}")#text(" is a subgroup of ")#mi("{G \\times G}")#text(" (see Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(" below). For instance, the quantity")

#align(center)[#tao-fit-display[#mitex("\\text{rank}(\\phi) := {\\bf E}_{a \\in G} {\\bf E}_{x \\in G} \\phi(a xa^{-1} x^{-1})")]]

#text("is a natural number which we will call the ")#emph[#text("rank")]#text(" of ")#mi("{\\phi}")#text(" (as it is also the linear rank of the transformation ")#mi("{f \\mapsto f*\\phi}")#text(" on ")#mi("{L^2(G)}")#text(").")

#text("In the case that ")#mi("{G}")#text(" is a Frobenius group with kernel ")#mi("{K}")#text(", the above integrality properties can be used after some elementary manipulations to establish that for any idempotent ")#mi("{\\phi}")#text(", the quantity ")#metadata(none) <tao-a02f920d3a079fc21c08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{a \\in K} {\\bf E}_{x \\in G} \\phi( axa^{-1}x^{-1} ) - \\frac{1}{\\left|G\\right| \\left|K\\right|} \\sum_{a,b \\in K} \\phi(ab^{-1})", block: true)]]

#text("is an integer. On the other hand, one can also show by elementary means that this quantity lies between ")#mi("{0}")#text(" and ")#mi("{\\text{rank}(\\phi)}")#text(". These two facts are not strong enough on their own to impose much further structure on ")#mi("{\\phi}")#text(", unless one restricts attention to ")#emph[#text("minimal")]#text(" idempotents ")#mi("{\\phi}")#text(". In this case spectral theory (or Gelfand theory, or the fundamental theorem of algebra) tells us that ")#mi("{\\phi}")#text(" has rank one, and then the ")#emph[#text("integrality gap")]#text(" comes into play and forces the quantity ")#link(<tao-a02f920d3a079fc21c08>)[#text("(3)")]#text(" to always be either zero or one. This can be used to imply that the convolution action of every minimal idempotent ")#mi("{\\phi}")#text(" either preserves ")#tao-math("{\\frac{\\left|G\\right|}{\\left|K\\right|} 1_K}", block: false)#text(" or annihilates it, which makes ")#tao-math("{\\frac{\\left|G\\right|}{\\left|K\\right|} 1_K}", block: false)#text(" itself an idempotent, which makes ")#mi("{K}")#text(" normal.")

#metadata(none) <tao-06ba5855cd5e4a897ed2>

#heading(level: 1)[#strong[#text(" — 1. Idempotent theory — ")]]

#text("Let ")#mi("{G}")#text(" be a finite group. Then we can form the Hilbert space ")#mi("{L^2(G)}")#text(" of complex functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" with inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle := {\\bf E}_{x \\in G} f(x) \\overline{g(x)}")]]

#text("where we use the usual averaging notation ")#tao-math("{{\\bf E}_{x \\in G} f(x) = \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x)}", block: false)#text(". This Hilbert space is also a complex ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("*-algebra")]#text(" using the adjoint map")

#align(center)[#tao-fit-display[#mitex("f^*(x) := \\overline{f(x^{-1})}")]]

#text("and the convolution product")

#align(center)[#tao-fit-display[#mitex("f*g(x) := {\\bf E}_{y \\in G} f(y) g(y^{-1} x) = {\\bf E}_{y \\in G} f(xy^{-1}) g(y).")]]

#text("For future reference, we record the adjoint relations")

#align(center)[#tao-fit-display[#mitex("\\langle f*g, h \\rangle = \\langle g, f^* * h \\rangle")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\langle g*f, h \\rangle = \\langle g, h * f^* \\rangle")]]

#text("for any ")#mi("{f,g,h \\in L^2()}")#text(".")

#text("As an algebra, ")#mi("{L^2(G)}")#text(" is isomorphic to the ")#link("http://en.wikipedia.org/wiki/Group_algebra")[#text("group algebra")]#text(" ")#mi("{{\\bf C} G}")#text(" of ")#mi("{G}")#text(", if one identifies each group element ")#mi("{x}")#text(" with the “Dirac delta function” ")#mi("{\\delta_x \\in L^2(G)}")#text(" at ")#mi("{x}")#text(", defined by")

#align(center)[#tao-fit-display[#tao-math("\\delta_x(y) := \\left|G\\right| 1_{x=y}.", block: true)]]

#text("Note that")

#align(center)[#tao-fit-display[#mitex("f * \\delta_1 = \\delta_1 * f = f")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\delta_x * \\delta_y = \\delta_{xy}")]]

#text("for any ")#mi("{x,y \\in G}")#text(" and ")#mi("{f \\in L^2(G)}")#text(".")

#text("The convolution algebra ")#mi("{L^2(G)}")#text(" will in general be non-commutative. However, it contains a commutative (in fact central) *-subalgebra ")#mi("{L^2(G)^G}")#text(", namely the space of ")#link("http://en.wikipedia.org/wiki/Class_function")[#text("class functions")]#text(", that is to say the functions ")#mi("{f \\in L^2(G)}")#text(" which are conjugation invariant in the sense that")

#align(center)[#tao-fit-display[#mitex("f(gxg^{-1}) = f(x)")]]

#text("for all ")#mi("{x,g \\in G}")#text(". It is easy to see that ")#mi("{L^2(G)^G}")#text(" is a central *-subalgebra of ")#mi("{L^2(G)}")#text(", thus if ")#mi("{f, g}")#text(" are class functions then so is ")#mi("{f*g}")#text(" and ")#mi("{f^*}")#text(", and one has ")#mi("{f*h = h*f}")#text(" for any ")#mi("{h \\in L^2(G)}")#text(". Indeed it is not hard to show that ")#mi("{L^2(G)^G}")#text(" is the centre of ")#mi("{L^2(G)}")#text(", although we will not need this fact here.")

#text("Let us call a class function ")#mi("{\\phi}")#text(" an ")#link("http://en.wikipedia.org/wiki/Idempotent")[#text("idempotent")]#text(" if ")#mi("{\\phi*\\phi = \\phi}")#text(". Thus for instance ")#mi("{0}")#text(", ")#mi("{1}")#text(", and ")#mi("{\\delta_1}")#text(" are idempotents, and the convolution of any two idempotents is again an idempotent. Note that if ")#mi("{\\phi}")#text(" is idempotent, then the linear transformation ")#mi("{P_\\phi: f \\mapsto f*\\phi = \\phi*f}")#text(" on ")#mi("{L^2(G)}")#text(" is also idempotent and also self-adjoint (since ")#mi("{\\phi}")#text(" and ")#mi("{\\phi^*}")#text(" are class functions and thus commute with each other), and thus ")#mi("{P_\\phi}")#text(" is an orthogonal projection onto the space ")#mi("{L^2(G) * \\phi = \\phi * L^2(G)}")#text(". The projection ")#mi("{P_\\phi}")#text(" similarly projects ")#mi("{L^2(G)^G}")#text(" to the subspace ")#mi("{L^2(G)^G * \\phi}")#text(". We define the ")#emph[#text("rank")]#text(" ")#mi("{\\text{rank}(P_\\phi)}")#text(" of the idempotent ")#mi("{\\phi}")#text(" to be the rank of ")#mi("{P_\\phi}")#text(" on ")#mi("{L^2(G)^G}")#text(", or equivalently the dimension of the space ")#mi("{L^2(G)^G * \\phi}")#text(". Thus for instance ")#mi("{0}")#text(" has rank ")#mi("{0}")#text(", ")#mi("{\\delta_1}")#text(" has rank equal to the number of conjugacy classes of ")#mi("{G}")#text(", and ")#mi("{1}")#text(" has rank one.")

#text("We place an ordering on idempotents by declaring ")#mi("{\\phi \\leq \\psi}")#text(" if ")#mi("{\\phi*\\psi = \\phi}")#text(", thus for instance ")#mi("{0 \\leq 1 \\leq \\delta_1}")#text(", and ")#mi("{\\phi*\\psi \\leq \\phi, \\psi}")#text(" for any idempotents ")#mi("{\\phi,\\psi}")#text(". The relation ")#mi("{\\phi \\leq \\psi}")#text(" is equivalent to the range of the projection ")#mi("{P_\\phi}")#text(" being a subspace of the range of the projection ")#mi("{P_\\psi}")#text(". In particular this shows that ")#mi("{\\leq}")#text(" is a partial order on idempotents, and that ")#mi("{\\text{rank}(\\phi) < \\text{rank}(\\psi)}")#text(" whenever ")#mi("{\\phi < \\psi}")#text(". If ")#mi("{\\phi \\leq \\psi}")#text(", we see that ")#mi("{\\psi-\\phi}")#text(" is also an idempotent with ")#mi("{\\psi-\\phi \\leq \\psi}")#text(". From this we see that every non-zero idempotent ")#mi("{\\psi}")#text(" is either ")#emph[#text("minimal")]#text(" (in the sense that there are no other non-zero idempotents ")#mi("{\\phi}")#text(" such that ")#mi("{\\phi < \\psi}")#text(", or can be split up as the sum of two strictly smaller idempotents. From this we see that we can decompose ")#mi("{\\delta_1}")#text(" into the sum ")#mi("{\\delta = \\sum_{\\phi \\in I} \\phi}")#text(" of minimal idempotents ")#mi("{\\phi}")#text(", whose ranges ")#mi("{L^2(G) * \\phi}")#text(" then form an orthogonal decomposition of ")#mi("{L^2(G)}")#text(" (and similarly the ")#mi("{L^2(G)^G * \\phi}")#text(" form an orthogonal decomposition of ")#mi("{L^2(G)}")#text("); and by convolving this fact with any other idempotent ")#mi("{\\psi}")#text(" we see that all other idempotents ")#mi("{\\psi}")#text(" take the form ")#mi("{\\sum_{\\phi \\in I^{\\prime}} \\phi}")#text(" for some subset ")#mi("{I^{\\prime}}")#text(" of ")#mi("{I}")#text(". Conversely, one can show that ")#mi("{\\sum_{\\phi \\in I^{\\prime}} \\phi}")#text(" is an idempotent for every ")#mi("{I^{\\prime} \\subset I}")#text(". Thus, the structure of idempotents is completely determined by the set of minimal idempotents.")

#text("The theory thus far relied only on elementary algebra; in particular, one could replace the complex numbers here by any other field of characteristic not a factor of ")#tao-math("{\\left|G\\right|}", block: false)#text(" and still get essentially an identical theory (replacing the complex conjugate by some other automorphism, such as the trivial automorphism). But the next fact is less elementary (being analogous to Plancherel’s theorem for finite groups) and relies crucially on the algebraically closed nature of ")#mi("{{\\bf C}}")#text(" (or closely related facts, such as Liouville’s theorem).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-7692c3ad3540bb803c02>#text(" All minimal idempotents have rank one.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\phi}")#text(" be an idempotent of rank greater than one, then ")#mi("{L^2(G)^G * \\phi}")#text(" contains a function ")#mi("{g}")#text(" which is not a scalar multiple of ")#mi("{\\phi}")#text(". The linear transformation ")#mi("{T: f \\mapsto f*g}")#text(" is a normal transformation on ")#mi("{L^2(G)^G * \\phi}")#text(". Since ")#mi("{\\phi*g = g}")#text(" is not a multiple of ")#mi("{\\phi}")#text(", ")#mi("{T}")#text(" is not a multiple of the identity, thus by the spectral theorem there is an eigenspace ")#mi("{V = \\{ f \\in L^2(G)^G * \\phi: f*g = \\lambda f \\}}")#text(" which is a proper non-trivial subspace of ")#mi("{L^2(G)^G * \\phi}")#text(". This space is a convolution ideal of ")#mi("{L^2(G)^G}")#text("; if we let ")#mi("{P_V}")#text(" be the orthogonal projection from ")#mi("{L^2(G)^G}")#text(" to ")#mi("{V}")#text(", then ")#mi("{P_V}")#text(" commutes with convolutions and in particular ")#mi("{P_V f = f * P_V \\delta_1}")#text(" for all ")#mi("{f \\in L^2(G)^G}")#text(". Applying this to ")#mi("{f = P_V \\delta_1}")#text(" we conclude that ")#mi("{P_V \\delta_1}")#text(" is an idempotent, with ")#mi("{0 < P_V \\delta_1 < \\phi}")#text(", thus ")#mi("{\\phi}")#text(" is not minimal. The claim follows (note that minimal idempotents by definition cannot be of rank zero). ")#mi("\\Box")

#text("Now we record some integrality properties of idempotents. We have the following trivial but crucial fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-60bb7fa83227741d8386>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional vector space, and let ")#mi("{P: V \\rightarrow V}")#text(" be an idempotent linear transformation. Then the trace ")#mi("{\\text{tr}(P)}")#text(" of ")#mi("{P}")#text(" is equal to the dimension ")#mi("{\\text{dim}(PV)}")#text(" of the range of ")#mi("{P}")#text(". In particular, the trace is a natural number.")
]

#emph[#text("Proof:")]#text(" This follows by computing the trace in a basis of ")#mi("{PV}")#text(" together with a basis of some complementary subspace of ")#mi("{PV}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-b38222d243e636f95235>#text(" Let ")#mi("{\\phi}")#text(" be an idempotent in ")#mi("{L^2(G)^G}")#text(", and let ")#mi("{S}")#text(" be a subgroup of ")#mi("{G \\times G}")#text(". Then the quantity")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{(a,b) \\in S} {\\bf E}_{x \\in G} \\phi( a x b^{-1} x^{-1} )")]]

#text("is a natural number.")
]

#emph[#text("Proof:")]#text(" We introduce the left and right translation operators")

#align(center)[#tao-fit-display[#mitex("L_a f := \\delta_a * f")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("R_b f := f * \\delta_{b^{-1}}")]]

#text("on ")#mi("{L^2(G)}")#text(" for ")#mi("{a,b \\in G}")#text(", together with the projection operator")

#align(center)[#tao-fit-display[#mitex("P_\\phi f := f * \\phi")]]

#text("introduced previously. Observe that the three operators ")#mi("{P_\\phi, L_a, R_b}")#text(" commute with each other. As such, the operator")

#align(center)[#tao-fit-display[#mitex("P := {\\bf E}_{(a,b) \\in S} P_\\phi L_a R_b")]]

#text("is idempotent. A short computation shows that the trace of ")#mi("{P}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{(a,b) \\in S} {\\bf E}_{x \\in G} \\phi( a x b^{-1} x^{-1} )")]]

#text("and the claim now follows from Lemma ")#link(<tao-60bb7fa83227741d8386>)[#text("3")]#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Proof of Frobenius’ theorem — ")]]

#text("We now begin the proof of Frobenius’ theorem. We begin with an elementary consequence of Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-d2e4a8af82700b1db628>#text(" Let ")#mi("{G}")#text(" be a finite group with Frobenius complement ")#mi("{H}")#text(" and Frobenius kernel ")#mi("{K}")#text(". Then for any idempotent ")#mi("{\\phi}")#text(" in ")#mi("{L^2(G)}")#text(", the quantity ")#metadata(none) <tao-ad9a67fefa847de87753>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{a \\in K} {\\bf E}_{x \\in G} \\phi( axa^{-1}x^{-1} ) - \\frac{1}{\\left|G\\right| \\left|K\\right|} \\sum_{a,b \\in K} \\phi(ab^{-1})", block: true)]]

#text("is an integer.")
]

#emph[#text("Proof:")]#text(" When ")#mi("{\\phi=1}")#text(" the quantity ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(" vanishes, so we may assume (by the decomposition ")#mi("{\\phi = (\\phi*1) + (\\phi-\\phi*1)}")#text(") that the idempotent ")#mi("{\\phi}")#text(" has mean zero.")

#text("Applying Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(" to the subgroups ")#mi("{G^\\Delta := \\{ (g,g): g \\in G \\}}")#text(", ")#mi("{H^\\Delta := \\{ (h,h): h \\in H \\}}")#text(", ")#mi("{H \\times \\{1\\}}")#text(" and ")#mi("{H \\times H}")#text(" of ")#mi("{G \\times G}")#text(", we conclude that the expressions ")#metadata(none) <tao-db87cee52504ca5732ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\bf E}_{g \\in G} {\\bf E}_{x \\in G} \\phi( g x g^{-1} x^{-1} ),")]]

#metadata(none) <tao-33112ee14ee469c3eb52>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf E}_{h \\in H} {\\bf E}_{x \\in G} \\phi( h x h^{-1} x^{-1} ),")]]

#metadata(none) <tao-f998fe06afa0cfbe73e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf E}_{h \\in H} {\\bf E}_{x \\in G} \\phi( h )")]]

#text("and ")#metadata(none) <tao-97fb5f8538b89f6c1acc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\bf E}_{h,h^{\\prime} \\in H} {\\bf E}_{x \\in G} \\phi( h x (h^{\\prime})^{-1} x^{-1} )")]]

#text("are natural numbers (and hence integers). We now consider various linear combinations of these quantities. We write ")#link(<tao-33112ee14ee469c3eb52>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|H\\right|} \\phi(1) + \\frac{1}{\\left|H\\right|} \\sum_{g \\in H \\backslash \\{1\\}} {\\bf E}_{x \\in G} \\phi( g x g^{-1} x^{-1} ).", block: true)]]

#text("Observe that as ")#mi("{\\phi}")#text(" is a class function the quantity ")#mi("{{\\bf E}_{x \\in G} \\phi( g x h^{-1} x^{-1} )}")#text(" is invariant with respect to conjugation of either ")#mi("{g}")#text(" or ")#mi("{h}")#text(" (or both). From this and ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(", we see that ")#link(<tao-33112ee14ee469c3eb52>)[#text("(6)")]#text(" is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|H\\right|} \\phi(1) + \\frac{1}{\\left|G\\right|} \\sum_{g \\in G \\backslash K} {\\bf E}_{x \\in G} \\phi( g x g^{-1} x^{-1} ).", block: true)]]

#text("Subtracting this from ")#link(<tao-db87cee52504ca5732ba>)[#text("(5)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{g \\in K} {\\bf E}_{x \\in G} \\phi( g x g^{-1} x^{-1} ) - \\frac{1}{\\left|H\\right|} \\phi(1)", block: true)]]

#text("is an integer; comparing this with ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(", we see that it suffices to show that ")#metadata(none) <tao-3bdea8d9f6b92bce4d7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\frac{1}{\\left|G\\right| \\left|K\\right|} \\sum_{a,b \\in K} \\phi(ab^{-1}) - \\frac{1}{\\left|H\\right|} \\phi(1)", block: true)]]

#text("is an integer.")

#text("If we multiply ")#link(<tao-97fb5f8538b89f6c1acc>)[#text("(8)")]#text(" by ")#tao-math("{\\left|H\\right|}", block: false)#text(" and isolate the terms where ")#mi("{h}")#text(" or ")#mi("{h^{\\prime}}")#text(" is equal to ")#mi("{1}")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|H\\right|} \\phi(1) + \\frac{2}{\\left|H\\right|} \\sum_{h \\in H \\backslash \\{1\\}} {\\bf E}_{x \\in G} \\phi(h) + \\frac{1}{\\left|H\\right|} \\sum_{h,h^{\\prime} \\in H \\backslash \\{1\\}} {\\bf E}_{x \\in G} \\phi( h x (h^{\\prime})^{-1} x^{-1} ).", block: true)]]

#text("Subtracting two copies of ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("(7)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|H\\right|} \\sum_{h,h^{\\prime} \\in H \\backslash \\{1\\}} {\\bf E}_{x \\in G} \\phi( h x (h^{\\prime})^{-1} x^{-1} ) - \\frac{1}{\\left|H\\right|} \\phi(1)", block: true)]]

#text("is an integer. Using the conjugation invariance of ")#mi("{{\\bf E}_{x \\in G} \\phi( h x (h^{\\prime})^{-1} x^{-1} )}")#text(" in ")#mi("{h}")#text(" and ")#mi("{h^{\\prime}}")#text(", together with ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(", we can rewrite this expression as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right| \\left|K\\right|} \\sum_{g,g^{\\prime} \\in G \\backslash K} {\\bf E}_{x \\in G} \\phi( g x (g^{\\prime})^{-1} x^{-1} ) - \\frac{1}{\\left|H\\right|} \\phi(1).", block: true)]]

#text("On the other hand, as ")#mi("{\\phi}")#text(" has mean zero, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{g \\in G} \\phi(g x (g^{\\prime})^{-1} x^{-1}) = 0")]]

#text("for any ")#mi("{g^{\\prime}}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("\\sum_{g^{\\prime} \\in G} \\phi(g x (g^{\\prime})^{-1} x^{-1}) = 0")]]

#text("for any ")#mi("{g}")#text(". Thus we can rewrite the previous expression as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right| \\left|K\\right|} \\sum_{g,g^{\\prime} \\in K} {\\bf E}_{x \\in G} \\phi( g x (g^{\\prime})^{-1} x^{-1} ) - \\frac{1}{\\left|H\\right|} \\phi(1);", block: true)]]

#text("but from ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(" ")#mi("{K}")#text(" is closed under conjugation, and hence ")#link(<tao-3bdea8d9f6b92bce4d7f>)[#text("(9)")]#text(" is an integer as required. ")#mi("\\Box")

#text("On the other hand, we have an alternate representation for the quantity ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-c22f6eeb797ab5b7ebc3>#text(" Let ")#mi("{G}")#text(" be a finite group with Frobenius complement ")#mi("{H}")#text(" and Frobenius kernel ")#mi("{K}")#text(". Then for any idempotent ")#mi("{\\phi}")#text(" in ")#mi("{L^2(G)^G}")#text(", the quantity ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(" is equal to ")#mi("{\\text{tr}( P_V P_\\phi P_V )}")#text(", where ")#mi("{P_V: L^2(G) \\rightarrow V}")#text(" is the orthogonal projection to the space ")#mi("{V}")#text(" of class functions of mean zero supported on ")#mi("{K}")#text(". In particular, since ")#mi("{V}")#text(" is a subspace of ")#mi("{L^2(G)^G}")#text(", the quantity ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(" lies between ")#mi("{0}")#text(" and ")#mi("{\\text{rank}(\\phi)}")#text(".")
]

#emph[#text("Proof:")]#text(" The quantity ")#mi("{\\text{tr}(P_V P_\\phi P_V )}")#text(" can be expanded as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{g \\in G} \\langle P_\\phi P_V \\delta_g, P_V \\delta_g \\rangle", block: true)]]

#text("which can be expanded further as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{g \\in K} \\langle P_\\phi ({\\bf E}_{x \\in G} \\delta_{xgx^{-1}} - \\frac{\\left|G\\right|}{\\left|K\\right|} 1_K), ({\\bf E}_{y \\in G} \\delta_{ygy^{-1}} - \\frac{\\left|G\\right|}{\\left|K\\right|} 1_K) \\rangle.", block: true)]]

#text("This simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{g \\in K} \\langle P_\\phi {\\bf E}_{x \\in G} \\delta_{xgx^{-1}}, {\\bf E}_{y \\in G} \\delta_{ygy^{-1}} \\rangle - \\frac{\\left|K\\right|}{\\left|G\\right|} \\langle P_\\phi \\frac{\\left|G\\right|}{\\left|K\\right|} 1_K, \\frac{\\left|G\\right|}{\\left|K\\right|} 1_K \\rangle", block: true)]]

#text("and a routine computation (using the conjugation invariance of ")#mi("{K}")#text(") shows that this is the same quantity as ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(". ")#mi("\\Box")

#text("Let ")#mi("{G}")#text(" be a finite group with Frobenius complement ")#mi("{H}")#text(" and Frobenius kernel ")#mi("{K}")#text(", and let ")#mi("{\\phi}")#text(" be a minimal idempotent of ")#mi("{L^2(G)^G}")#text(". By Lemma ")#link(<tao-60bb7fa83227741d8386>)[#text("3")]#text(", Lemma ")#link(<tao-d2e4a8af82700b1db628>)[#text("5")]#text(", and Lemma ")#link(<tao-c22f6eeb797ab5b7ebc3>)[#text("6")]#text(", we see that the quantity ")#link(<tao-ad9a67fefa847de87753>)[#text("(4)")]#text(" is an integer between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", and is thus exactly ")#mi("{0}")#text(" or exactly ")#mi("{1}")#text(". From Lemma ")#link(<tao-c22f6eeb797ab5b7ebc3>)[#text("6")]#text(", we thus conclude that the space ")#mi("{V}")#text(" either contains the range ")#mi("{P_\\phi L^2(G)^G}")#text(" of ")#mi("{P_\\phi}")#text(", or is orthogonal to this range. Summing over minimal idempotents, we conclude that ")#mi("{V}")#text(" is the direct sum of the ranges ")#mi("{P_\\phi L^2(G)^G}")#text(" of some minimal idempotents ")#mi("{\\phi}")#text("; the same is thus true of the orthogonal complement ")#mi("{V^\\perp}")#text(" of ")#mi("{V}")#text(" in ")#mi("{L^2(G)^G}")#text(", that is to say the space of class functions that are constant on ")#mi("{K}")#text(". In particular, this space ")#mi("{V^\\perp}")#text(" is closed under convolution, which implies that ")#mi("{1_K*1_K}")#text(" is constant on ")#mi("{K}")#text(". However, this convolution attains a maximum value of ")#tao-math("{\\left|K\\right|/\\left|G\\right|}", block: false)#text(" at the set ")#mi("{\\{ g \\in G: gK = K \\}}")#text(", and hence ")#mi("{KK = K}")#text(", thus ")#mi("{K}")#text(" is a subgroup. As ")#mi("{K}")#text(" was already known to be closed under conjugation, Theorem ")#link(<tao-9adf009b9ea42792e73e>)[#text("1")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" As mentioned previously, one can use character theory to describe the minimal idempotents as the functions of the form ")#mi("{\\chi(1) \\chi}")#text(", where ")#mi("{\\chi}")#text(" are the irreducible characters of ")#mi("{G}")#text(". The integrality property in Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(" can then be obtained by taking the representation of ")#mi("{G \\times G}")#text(" associated to ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" and decomposing it into irreducible representations of ")#mi("{S}")#text("; we omit the details. Thus one can view the above argument as being a disguised version of the usual character-theoretic proof. However, the point is that one can prove Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(" without knowing the relationship between minimal idempotents, irreducible characters, and irreducible representations. (Indeed, Corollary ")#link(<tao-b38222d243e636f95235>)[#text("4")]#text(" seems to be weaker than the fact from character theory that the restriction or induction of a character is again a character (and in particular decomposes into a natural number combination of irreducible characters); see ")#link("http://mathoverflow.net/questions/131364/how-much-of-character-theory-can-be-done-without-schurs-lemma-or-the-artin-wedde")[#text("this MathOverflow post")]#text(" for some further discussion.)")
]

#heading(level: 1)[#strong[#text(" — 3. The solvable case — ")]]

#text("In the case when the Frobenius complement ")#mi("{H}")#text(" is solvable, an elementary proof of Theorem ")#link(<tao-9adf009b9ea42792e73e>)[#text("1")]#text(" was discovered ")#link("http://www.ams.org/mathscinet-getitem?mr=28831")[#text("by Grun")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=52430")[#text("by Shaw")]#text(", based on the ")#link("http://en.wikipedia.org/wiki/Transfer_(group_theory)")[#text("transfer homomorphism")]#text(". To describe this argument, we first consider the model case when ")#mi("{H}")#text(" is abelian. We then enumerate the right cosets of ")#mi("{H}")#text(" as ")#mi("{g_1 H, \\ldots, g_k H}")#text(" for some ")#mi("{g_1,\\ldots,g_k \\in G}")#text(". This enumeration is not unique; in addition to permutations of the ")#mi("{g_1,\\ldots,g_k}")#text(", we have the freedom to arbitrarily multiply each ")#mi("{g_i}")#text(" on the right by an element ")#mi("{h_i}")#text(" of ")#mi("{H}")#text(" to obtain ")#mi("{g_i h_i}")#text(" without affecting the coset: ")#mi("{g_i H = g_i h_i H}")#text(".")

#text("Regardless of this freedom, we can define the ")#emph[#text("transfer homomorphism")]#text(" ")#mi("{\\phi: G \\rightarrow H}")#text(" for ")#mi("{g \\in G}")#text(" by noting that for each coset ")#mi("{g_i H}")#text(", one has ")#mi("{g g_i H = g_j H}")#text(" for some unique ")#mi("{j=1,\\ldots,k}")#text(" depending on ")#mi("{g_i}")#text(" and ")#mi("{g}")#text(", thus ")#mi("{g g_i = g_j a_i}")#text(" for some ")#mi("{a_i \\in H}")#text(" depending on ")#mi("{g_i, g_j}")#text(", and ")#mi("{g}")#text(". We then set")

#align(center)[#tao-fit-display[#mitex("\\phi(g) := a_1 \\ldots a_k.")]]

#text("One observes that this map is in fact independent of the choice of coset enumeration ")#mi("{g_1 H,\\ldots,g_k H}")#text("; permutations of ")#mi("{g_1,\\ldots,g_k}")#text(" are irrelevant as ")#mi("{H}")#text(" is assumed to be abelian, and shifting one of the ")#mi("{g_i}")#text(" by an element ")#mi("{h_i}")#text(" of ")#mi("{H}")#text(" causes one of the ")#mi("{a_j}")#text(" to be multiplied by ")#mi("{h_i}")#text(", byt another of the ")#mi("{a_j}")#text(" to be divided by ")#mi("{h_i}")#text(", leaving ")#mi("{\\phi(g)}")#text(" unchanged. Once one knows that ")#mi("{\\phi}")#text(" is independent of the choice of coset enumeration, it is not difficult to verify the homomorphism property ")#mi("{\\phi(gg^{\\prime}) = \\phi(g) \\phi(g^{\\prime})}")#text(", for instance by using one enumeration ")#mi("{g_1 H,\\ldots,g_k H}")#text(" to compute ")#mi("{\\phi(g^{\\prime})}")#text(" and ")#mi("{\\phi(gg^{\\prime})}")#text(", and another enumeration ")#mi("{gg_1 H,\\ldots,gg_k H}")#text(" to compute ")#mi("{\\phi(g)}")#text(".")

#text("We now make the crucial observation that if ")#mi("{H}")#text(" is an abelian Frobenius complement, then the transfer map ")#mi("{\\phi: G \\rightarrow H}")#text(" is the identity on ")#mi("{H}")#text(", thus ")#mi("{\\phi(h) = h}")#text(" for all ")#mi("{h \\in H}")#text(". To see this, let ")#mi("{n}")#text(" be the order of ")#mi("{h}")#text(". We claim that the action ")#mi("{gH \\mapsto hgH}")#text(" of ")#mi("{h}")#text(" on the quotient space ")#mi("{G/H}")#text(" consists of a single fixed point at ")#mi("{H}")#text(", together with orbits of size exactly ")#mi("{n}")#text(". Indeed, ")#mi("{H}")#text(" is clearly fixed by ")#mi("{h}")#text(" since ")#mi("{hH = H}")#text(", and if we have ")#mi("{h^i g H = gH}")#text(" for some coset ")#mi("{gH \\neq H}")#text(" and some ")#mi("{i}")#text(", then ")#mi("{h^i}")#text(" lies in ")#mi("{H \\cap gHg^{-1} = \\{1\\}}")#text(" and so ")#mi("{i}")#text(" is a multiple of ")#mi("{n}")#text(", whence the claim. If we then use a coset enumeration that consists of ")#mi("{H}")#text(" together with ")#mi("{n}")#text("-tuples of the form ")#mi("{gH, hgH, \\ldots, h^{n-1} gH}")#text(" for each orbit of ")#mi("{h}")#text(", we see that ")#mi("{\\phi(h)=h}")#text(" as claimed.")

#text("As ")#mi("{\\phi}")#text(" is a surjective homomorphism from ")#mi("{G}")#text(" to ")#mi("{H}")#text(", the kernel is a normal subgroup of order ")#tao-math("{\\left|G\\right|/\\left|H\\right| = \\left|K\\right|}", block: false)#text("; also, as ")#mi("{\\phi}")#text(" is the identity on ")#mi("{H}")#text(", this kernel is disjoint from ")#mi("{H}")#text(", and hence also from every conjugate of ")#mi("{H}")#text(". From ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(" we conclude that the kernel is ")#mi("{K}")#text(", and hence ")#mi("{K}")#text(" is normal as required.")

#text("Now we adapt the above argument to the case when ")#mi("{H}")#text(" is solvable instead of abelian. Here, one can still define a transfer map ")#mi("{\\phi: G \\rightarrow H/[H,H]}")#text(", but it takes values in the abelianisation ")#mi("{H/[H,H]}")#text(" of ")#mi("{H}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\phi(g) := a_1 \\ldots a_k \\text{ mod } H/[H,H].")]]

#text("One can verify as before that ")#mi("{\\phi}")#text(" is independent of the choice of enumeration, and is a homomorphism. The previous argument also shows that the restriction of ")#mi("{\\phi}")#text(" to ")#mi("{H}")#text(" is the quotient map from ")#mi("{H}")#text(" to ")#mi("{[H,H]}")#text(". Thus, the kernel ")#mi("{\\text{ker}(\\phi)}")#text(" is a normal subgroup of ")#mi("{G}")#text(" whose order is ")#tao-math("{\\left|K\\right| \\left|[H,H]\\right|}", block: false)#text(" and which intersects ")#mi("{H}")#text(" in precisely ")#mi("{[H,H]}")#text(". From this we see that ")#mi("{\\text{ker}(\\phi)}")#text(" is the union of ")#mi("{K}")#text(" and the conjugates of ")#mi("{[H,H] \\backslash \\{1\\}}")#text(", and so ")#mi("{\\text{ker}(\\phi)}")#text(" is also a Frobenius group with Frobenius complement ")#mi("{[H,H]}")#text(" and Frobenius kernel ")#mi("{K}")#text(". The claim then follows by an induction of the derived length of ")#mi("{H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" This argument in fact shows that to prove Frobenius’s theorem, it suffices to do so in the case that ")#mi("{H}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect group")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. The even order case — ")]]

#text("When ")#tao-math("{\\left|H\\right|}", block: false)#text(" is even, ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_theorem_(group_theory)")[#text("Cauchy’s theorem")]#text(" shows that ")#mi("{H}")#text(" contains at least one non-trivial ")#link("http://en.wikipedia.org/wiki/Involution_(mathematics)")[#text("involution")]#text(" – an element of order two, since otherwise ")#mi("{H}")#text(" would split up into the identity and pairs ")#mi("{\\{x,x^{-1}\\}}")#text(", contradicting the even nature of ")#tao-math("{\\left|H\\right|}", block: false)#text(". One can then analyse the action of these involutions combinatorially; this was first done ")#link("http://www.ams.org/mathscinet-getitem?mr=288172")[#text("by Bender")]#text(" (and we use an argument from ")#link("http://www.ams.org/mathscinet-getitem?mr=237627")[#text("this text of Passman")]#text("). Indeed, if ")#mi("{u}")#text(" is an involution in ")#mi("{H}")#text(", then as discussed in the previous section, the action ")#mi("{gH \\mapsto ugH}")#text(" of ")#mi("{u}")#text(" on ")#mi("{G/H}")#text(" fixes ")#mi("{H}")#text(" and breaks the rest of ")#mi("{G/H}")#text(" into orbits of size two; in particular, ")#tao-math("{\\left|K\\right|=\\left|G\\right|/\\left|H\\right|}", block: false)#text(" is odd, and there are ")#tao-math("{\\frac{\\left|K\\right|-1}{2}}", block: false)#text(" pairs of cosets in ")#mi("{G/H}")#text(" that are swapped by ")#mi("{u}")#text(". More generally, any involution in a conjugate ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(" will fix ")#mi("{gH}")#text(" and then swap ")#tao-math("{\\frac{\\left|K\\right|-1}{2}}", block: false)#text(" pairs among the other cosets of ")#mi("{G/H}")#text(".")

#text("Suppose that ")#mi("{H}")#text(" contains at least two involutions; then by ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(" ")#mi("{\\bigcup_{g \\in G} gHg^{-1}}")#text(" contains at least ")#tao-math("{2\\left|K\\right|}", block: false)#text(" involutions, each of which swaps ")#tao-math("{\\frac{\\left|K\\right|-1}{2}}", block: false)#text(" pairs in ")#mi("{G/H}")#text(". But there are only ")#tao-math("{\\frac{\\left|K\\right| (\\left|K\\right|-1)}{2}}", block: false)#text(" such pairs; thus by the pigeonhole principle there are two cosets, say ")#mi("{aH}")#text(" and ")#mi("{bH}")#text(", which are swapped by two different involutions ")#mi("{u,v}")#text(" in ")#mi("{G}")#text(", thus ")#mi("{uaH = vaH = bH}")#text(" and ")#mi("{ubH = vbH = aH}")#text(". But this implies that ")#mi("{v^{-1} u}")#text(" fixes both ")#mi("{aH}")#text(" and ")#mi("{bH}")#text(", and thus lies in ")#mi("{aHa^{-1} \\cap bHb^{-1}}")#text(", and is thus trivial by ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(", contradicting the disjoint nature of ")#mi("{u}")#text(" and ")#mi("{v}")#text(". Thus ")#mi("{H}")#text(" contains exactly one involution. The same argument then shows that ")#mi("{K}")#text(" cannot contain any involutions. Thus the set ")#mi("{S := \\{ u \\in G \\backslash \\{1\\}: u^2 = 1 \\}}")#text(" of involutions has order exactly ")#mi("{K}")#text(", consisting of the involution of ")#mi("{H}")#text(" and all of its conjugates.")

#text("If ")#mi("{u, v}")#text(" are involutions, then by the above discussion ")#mi("{u}")#text(" and ")#mi("{v}")#text(" lie in different conjugates of ")#mi("{H}")#text(", and so the actions ")#mi("{gH \\mapsto ugH}")#text(" and ")#mi("{gh \\mapsto vgH}")#text(" fix different cosets of ")#mi("{G/H}")#text(". Also, we have seen that they swap different pairs of cosets. As such, the combined action ")#mi("{gH \\mapsto uv^{-1}gH}")#text(" cannot fix any elements of ")#mi("{G/H}")#text(", and thus by ")#link(<tao-54ca7b83a424aed496ef>)[#text("(1)")]#text(" lies in ")#mi("{K}")#text(". We conclude that ")#mi("{S S^{-1} \\subset K}")#text("; since ")#mi("{S}")#text(" and ")#mi("{K}")#text(" have the same order, this implies that ")#mi("{sK = S}")#text(" for all ")#mi("{s \\in S}")#text(", and hence ")#mi("{K^{-1} K = K}")#text(". This makes ")#mi("{K}")#text(" a group (and thus a normal group, since it is conjugation invariant), as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In this setting we can even establish the additional fact that ")#mi("{K}")#text(" is abelian. Indeed, if ")#mi("{u}")#text(" is an involution, then ")#mi("{uK = S}")#text(", so for every ")#mi("{k \\in K}")#text(", ")#mi("{uk}")#text(" is an involution, which implies that ")#mi("{uku^{-1} = k^{-1}}")#text(". Thus the inversion map ")#mi("{k \\mapsto k^{-1}}")#text(" is a homomorphism on ")#mi("{K}")#text(", which forces ")#mi("{K}")#text(" to be abelian.")
]

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-231127")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2013")])]

#text("Theorem 1:")

#text("“with Frobenius complement H and Frobenius complement K.” <– Frob. kernel K.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-231326")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("The statement of Frobenius theorem at the beginning of the post still says “frobenius complement K”.")

#emph[#text("[Fixed properly this time, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-231345")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("Wikipedia expresses Frobenius groups in terms of permutation actions. Is it the same?")

#text("“A Frobenius group is a transitive permutation group on a finite set, such that no non-trivial element fixes more than one point and some non-trivial element fixes a point.”")

#text("And then it says the Dihedral group is an example of a Frobenius group. And the groups of transformations ")#mi("\\{ az + b : a, b \\in \\mathbb{F}_p \\}")

#text("—")

#text("Lemma 5 is very interesting. I thought when ")#mi("\\phi")#text(" is a character it was always zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-231348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("Yes, they are equivalent; this is discussed in my previous post at ")#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")]#text(" .")

#text("A minimal idempotent ")#mi("\\phi")#text(" takes the form ")#mi("\\phi(g) = \\chi(1) \\chi(g)")#text(" for some irreducible character ")#mi("\\chi")#text(". One can then simplify ")#mi("{\\bf E}_{x \\in G} \\phi( axbx^{-1})")#text(" as ")#mi("\\chi(a) \\chi(b)")#text(" for any ")#mi("a,b \\in G")#text(" from the Fourier inversion formula for characters, so the first sum in Lemma 5 simplifies to ")#tao-math("\\frac{1}{\\left|G\\right|} \\sum_{a \\in K} \\left|\\chi(k)\\right|^2", block: false)#text(". It turns out in fact that in the irreducible case, the quantity in Lemma 5 vanishes when ")#mi("\\chi")#text(" is an exceptional character associated with a character in ")#mi("H")#text(", and is equal to 1 otherwise (this is basically the content of Lemma 6).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/919d9611ca7063152af539b7cafb931743eb7004204a6e8ca090019afcdbc0b9-b9487e2d711d42c4fcc7d903ed346ec99aa66a316f9029d86c9474204d614e59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Drayton")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-234530")[#strong[#text("Andrew Drayton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Great article, thanks! I believe that the semidirect product is backwards in the statement of Frobenius thm. In other words, I seen ")#mi("G=K \\rtimes H")#text(", since ")#mi("K")#text(" is the normal subgroup (see e.g. Rotman).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/847af1314d41470b1c060fdbcdefd8c566d597c474388c20cc2b283a9ef8c9f1-6cff516c73199b7b062156412ec04e754c8761642ed566f877bbd08b225acbad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adriana82100")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-456162")[#strong[#text("adriana82100")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2015")])]

#text("Could you advise please: in the Proof of Proposition 2 you wrote “if we let {P_V} be the orthogonal projection from {L^2(G)^G} to {V}, then {P_V} commutes with convolutions”.Why does {P_V} commute with convolutions?")

#emph[#text("[")#mi("V")#text(" is translation-invariant, hence ")#mi("P_V")#text(" commutes with translations and hence with convolutions. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb13c8ea66c0de16b013c58ae6e37c603b242ff6fe100ea427ee4e2346cef276-fc7c03e0ba82ceac01bc4d002a4598bef8af9cfca5598a073c3daa11936df27e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juri")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-461555")[#strong[#text("Juri")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("I try to use your argument about idempotent functions to proof a more general theorem about Wielandt-Groups (it’s a group G with proper subgroup H and H0 is the smallest normal subgroup of H such that H intersected with gH(g^-1) is contained in H0 for each g from G\\H). The problem is to show that the quantity (4) in the Lemma 5 is an integer. How did you find the right linear combinations of (5), (6), (7) and (8) in the proof of this Lemma? I will be grateful if you can give me some hint.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/05/24/a-fourier-analytic-proof-of-frobeniuss-theorem/#comment-461567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("I no longer remember my exact thought processes here, but I think I was basically running Remark 1 in reverse, namely starting with the usual character-based proof, trying to write everything in terms of the idempotents ")#mi("\\chi(1) \\chi")#text(" instead of the characters ")#mi("\\chi")#text(", and then rewriting various integrality properties of ")#mi("\\chi(1) \\chi")#text(" in terms of traces.")
]
]
