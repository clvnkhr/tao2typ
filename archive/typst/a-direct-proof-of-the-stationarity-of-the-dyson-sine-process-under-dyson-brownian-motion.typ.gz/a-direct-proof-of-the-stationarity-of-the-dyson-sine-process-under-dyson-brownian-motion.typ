// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/
// Converted to Typst by tao2typ: "2026-10-14T09:28:33.113759+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/")[#text("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{n}")#text(" be a large natural number, and let ")#mi("{M_n}")#text(" be a matrix drawn from the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), by which we mean that ")#mi("{M_n}")#text(" is a Hermitian matrix whose upper triangular entries are ")#link("http://en.wikipedia.org/wiki/Independent_and_identically_distributed_random_variables")[#text("iid")]#text(" complex gaussians with mean zero and variance one, and whose diagonal entries are iid real gaussians with mean zero and variance one (and independent of the upper triangular entries). The eigenvalues ")#mi("{\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)}")#text(" are then real and almost surely distinct, and can be viewed as a random ")#link("http://en.wikipedia.org/wiki/Point_process")[#text("point process")]#text(" ")#mi("{\\Sigma^{(n)} := \\{\\lambda_1(M_n),\\ldots,\\lambda_n(M_n)\\}}")#text(" on the real line. One can then form the ")#mi("{k}")#text("-point correlation functions ")#mi("{\\rho_k^{(n)}: {\\bf R}^k \\rightarrow {\\bf R}^+}")#text(" for every ")#mi("{k \\geq 0}")#text(", which can be defined by duality by requiring")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\sum_{i_1,\\ldots,i_k \\text{ distinct}} F( \\lambda_{i_1}(M_n),\\ldots,\\lambda_{i_k}(M_n))")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{{\\bf R}^k} \\rho_k^{(n)}(x_1,\\ldots,x_k) F(x_1,\\ldots,x_k)\\ dx_1 \\ldots dx_k")]]

#text("for any test function ")#mi("{F: {\\bf R}^k \\rightarrow {\\bf R}^+}")#text(". For GUE, which is a continuous matrix ensemble, one can also define ")#mi("{\\rho_k^{(n)}(x_1,\\ldots,x_k)}")#text(" for distinct ")#mi("{x_1<\\ldots<x_k}")#text(" as the unique quantity such that the probability that there is an eigenvalue in each of the intervals ")#mi("{[x_1,x_1+\\epsilon],\\ldots,[x_k,x_k+\\epsilon]}")#text(" is ")#mi("{(\\rho_k^{(n)}(x_1,\\ldots,x_k)+o(1))\\epsilon^k}")#text(" in the limit ")#mi("{\\epsilon\\rightarrow 0}")#text(".")

#text("As is well known, the GUE process is a ")#link("http://en.wikipedia.org/wiki/Determinantal_point_process")[#text("determinantal point process")]#text(", which means that ")#mi("{k}")#text("-point correlation functions can be explicitly computed as")

#align(center)[#tao-fit-display[#mitex("\\rho^{(n)}_k(x_1,\\ldots,x_k) = \\det( K^{(n)}(x_i,x_j) )_{1 \\leq i,j \\leq k}")]]

#text("for some kernel ")#mi("{K^{(n)}: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text("; explicitly, one has")

#align(center)[#tao-fit-display[#mitex("K^{(n)}(x,y) := \\sum_{k=0}^{n-1} P_k(x) e^{-x^2/4}P_k(y) e^{-y^2/4}")]]

#text("where ")#mi("{P_0, P_1,\\ldots}")#text(" are the (normalised) ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomials")]#text("; see ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("this previous blog post for details")]#text(".")

#text("Using the asymptotics of Hermite polynomials (which then give asymptotics for the kernel ")#mi("{K^{(n)}}")#text("), one can take a limit of a (suitably rescaled) sequence of GUE processes to obtain the ")#emph[#text("Dyson sine process")]#text(", which is a determinantal point process ")#mi("{\\Sigma}")#text(" on the real line with correlation functions ")#metadata(none) <tao-a4ad773f1bc065664076>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho_k(x_1,\\ldots,x_k) = \\det( K(x_i,x_j) )_{1 \\leq i,j \\leq k}")]]

#text("where ")#mi("{K}")#text(" is the ")#emph[#text("Dyson sine kernel")]#text(" ")#metadata(none) <tao-ef7c967436632d3042bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("K(x,y) := \\frac{\\sin(\\pi(x-y))}{\\pi(x-y)}.")]]

#text("A bit more precisely, for any fixed bulk energy ")#mi("{-2 < u < 2}")#text(", the renormalised point processes ")#mi("{\\rho_{sc}(u) \\sqrt{n} ( \\Sigma^{(n)} - \\sqrt{n} u )}")#text(" converge in distribution in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to ")#mi("{\\Sigma}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", where ")#mi("{\\rho_{sc}(u) := \\frac{1}{2\\pi} (4-u^2)^{1/2}_+}")#text(" is the semi-circular law density.")

#text("On the other hand, an important feature of the GUE process ")#mi("{\\Sigma^{(n)} = \\{\\lambda_1,\\ldots,\\lambda_n\\}}")#text(" is its stationarity (modulo rescaling) under Dyson Brownian motion")

#align(center)[#tao-fit-display[#mitex("d\\lambda_i = dB_i + \\sum_{j \\neq i} \\frac{dt}{\\lambda_i-\\lambda_j}")]]

#text("which describes the stochastic evolution of eigenvalues of a Hermitian matrix under independent Brownian motion of its entries, and is discussed in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(". To cut a long story short, this stationarity tells us that the self-similar ")#mi("{n}")#text("-point correlation function")

#align(center)[#tao-fit-display[#mitex("\\rho^{(n)}_n(t,x) := t^{-n/2} \\rho^{(n)}_n(x/\\sqrt{t})")]]

#text("obeys the ")#emph[#text("Dyson heat equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\rho^{(n)}_n = \\frac{1}{2} \\sum_{i=1}^n \\partial_{x_i}^2 \\rho^{(n)}_n - \\sum_{1 \\leq i,j \\leq n;i\\neq j} \\partial_{x_i} \\frac{\\rho^{(n)}_n}{x_i-x_j}")]]

#text("(see Exercise 11 of the previously mentioned blog post). Note that ")#mi("{\\rho^{(n)}_n}")#text(" vanishes to second order whenever two of the ")#mi("{x_i}")#text(" coincide, so there is no singularity on the right-hand side. Setting ")#mi("{t=1}")#text(" and using self-similarity, we can rewrite this equation in time-independent form as")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{2} \\sum_{i=1}^n \\partial_i (x_i \\rho^{(n)}_n) = \\frac{1}{2} \\sum_{i=1}^n \\partial_{x_i}^2 \\rho^{(n)}_n - \\sum_{1 \\leq i,j \\leq n;i\\neq j} \\partial_{x_i} \\frac{\\rho^{(n)}_n}{x_i-x_j}.")]]

#text("One can then integrate out all but ")#mi("{k}")#text(" of these variables (after carefully justifying convergence) to obtain a system of equations for the ")#mi("{k}")#text("-point correlation functions ")#mi("{\\rho^{(n)}_k}")#text(":")

#tao-aligned(keep: true)[


#tao-math("-\\frac{1}{2} \\sum_{i=1}^k \\partial_i (x_i \\rho^{(n)}_k)  & = \\frac{1}{2} \\sum_{i=1}^k \\partial_{x_i}^2 \\rho^{(n)}_k - \\sum_{1 \\leq i,j \\leq k;i\\neq j} \\partial_{x_i} \\frac{\\rho^{(n)}_k}{x_i-x_j}", block: true)



#tao-math(" & - \\sum_{i=1}^k \\partial_{x_i} \\int_{\\bf R} \\frac{\\rho^{(n)}_{k+1}(x_1,\\ldots,x_{k+1})}{x_i-x_{k+1}}\\ dx_{k+1},", block: true)
]

#text("where the integral is interpreted in the principal value case. This system is an example of a ")#link("http://en.wikipedia.org/wiki/BBGKY_hierarchy")[#text("BBGKY hierarchy")]#text(".")

#text("If one carefully rescales and takes limits (say at the energy level ")#mi("{u=0}")#text(", for simplicity), the left-hand side turns out to rescale to be a lower order term, and one ends up with a hierarchy for the Dyson sine process: ")#metadata(none) <tao-e2bd9c6236a519d406d1>

#tao-aligned(keep: true)[


#tao-math("0  & = \\frac{1}{2} \\sum_{i=1}^k \\partial_{x_i}^2 \\rho_k - \\sum_{1 \\leq i,j \\leq k;i\\neq j} \\partial_{x_i} \\frac{\\rho_k}{x_i-x_j}", block: true, numbering: n => [#text("(3)")])



#tao-math(" & - \\sum_{i=1}^k \\partial_{x_i} \\int_{\\bf R} \\frac{\\rho_{k+1}(x_1,\\ldots,x_{k+1})}{x_i-x_{k+1}}\\ dx_{k+1}.", block: true)
]

#text("Informally, these equations show that the Dyson sine process ")#mi("{\\Sigma = \\{ \\lambda_i: i \\in {\\bf Z} \\}}")#text(" is stationary with respect to the infinite Dyson Brownian motion")

#align(center)[#tao-fit-display[#mitex("d\\lambda_i = dB_i + \\sum_{j \\neq i} \\frac{dt}{\\lambda_i-\\lambda_j}")]]

#text("where ")#mi("{dB_i}")#text(" are independent Brownian increments, and the sum is interpreted in a suitable principal value sense.")

#text("I recently set myself the exercise of deriving the identity ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(3)")]#text(" directly from the definition ")#link(<tao-a4ad773f1bc065664076>)[#text("(1)")]#text(" of the Dyson sine process, without reference to GUE. This turns out to not be too difficult when done the right way (namely, by modifying the proof of Gaudin’s lemma), although it did take me an entire day of work before I realised this, and I could not find it in the literature (though I suspect that many people in the field have privately performed this exercise in the past). In any case, I am recording the computation here, largely because I really don’t want to have to do it again, but perhaps it will also be of interest to some readers.")

#metadata(none) <tao-c539a1c9866a81932734>

#text("The basic tool here is ")#link("http://en.wikipedia.org/wiki/Laplace_expansion")[#text("cofactor expansion")]#text(", which we write as follows. Given an ")#mi("{n \\times n}")#text(" matrix ")#mi("{A_n = (a_{i,j})_{1 \\leq i,j \\leq n}}")#text(", we can expand the determinant ")#mi("{\\det(A_n)}")#text(" as ")#metadata(none) <tao-ae47dca90741322b53c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\det(A_n) = a_{n,n} \\det(A_{n-1}) - \\sum_{i=1}^{n-1} a_{i,n} \\det( R_i( A_{n-1}, X ) )")]]

#text("where ")#mi("{X := (a_{n,1},\\ldots,a_{n,n-1})}")#text(" is the bottom left row of ")#mi("{A_n}")#text(", ")#mi("{A_{n-1} := (a_{i,j})_{1 \\leq i,j \\leq n-1}}")#text(" is the top left minor of ")#mi("{A_{n-1}}")#text(", and ")#mi("{R_i(A_{n-1},X)}")#text(" is the ")#mi("{n-1 \\times n-1}")#text(" matrix formed by replacing the ")#mi("{i^{th}}")#text(" row of ")#mi("{A_{n-1}}")#text(" by ")#mi("{X}")#text(".")

#text("As an example of how this cofactor expansion is used in determinantal point processes, let us recall ")#emph[#text("Gaudin’s lemma")]#text(", which we state slightly informally:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Gaudin’s lemma)")]#text(" Let ")#mi("{K: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" be a (sufficiently nice) function obeying the idempotent relation ")#metadata(none) <tao-b43aae102b191a96b0ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("K(x,z) = \\int_{\\bf R} K(x,y) K(y,z)\\ dy")]]

#text("and the trace formula ")#metadata(none) <tao-658447540603e4b7eaf8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{\\bf R} K(x,x)\\ dx = n.")]]

#text("For each ")#mi("{k}")#text(", let ")#mi("{\\rho_k}")#text(" be the correlation function")

#align(center)[#tao-fit-display[#mitex("\\rho_k(x_1,\\ldots,x_k) := \\det( K(x_i,x_j) )_{1 \\leq i,j \\leq k}.")]]

#text("Then we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\rho_{k+1}(x_1,\\ldots,x_k,x_{k+1})\\ dx_{k+1} = (n-k) \\rho_k(x_1,\\ldots,x_k).")]]
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-ae47dca90741322b53c7>)[#text("(4)")]#text(" we have ")#metadata(none) <tao-956fc30bfe11b61e7962>

#tao-aligned(keep: true)[


#tao-math("\\rho_{k+1}(x_1,\\ldots,x_k,x_{k+1})  & = K(x_{k+1},x_{k+1}) \\rho_k(x_1,\\ldots,x_k)", block: true, numbering: n => [#text("(7)")])



#tao-math(" & - \\sum_{i=1}^{k} K(x_i,x_{k+1}) \\det( R_i( A_k, X(x_{k+1}) ) )", block: true)
]

#text("where ")#mi("{A_k := (K(x_i,x_j))_{1 \\leq i,j \\leq k}}")#text(" and ")#mi("{X(x_{k+1}) := (K(x_{k+1},x_1),\\ldots,K(x_{k+1},x_k))}")#text(". Integrating using ")#link(<tao-658447540603e4b7eaf8>)[#text("(6)")]#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\bf R} \\rho_{k+1}(x_1,\\ldots,x_k,x_{k+1})\\ dx_{k+1}  & = n \\rho_k(x_1,\\ldots,x_k)", block: true)



#tao-math(" & - \\sum_{i=1}^{k} \\int_{\\bf R} K(x_i,x_{k+1}) \\det( R_i( A_k, X(x_{k+1}) )\\ dx_{k+1} ).", block: true)
]

#text("By the multilinearity of determinant, we can write")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} K(x_i,x_{k+1}) \\det( R_i( A_k, X(x_{k+1}) ) )\\ dx_{k+1}")]]

#align(center)[#tao-fit-display[#mitex("= \\det( R_i(A_k, \\int_{\\bf R} K(x_i,x_{k+1}) X(x_{k+1})\\ dx_{k+1} ) ).")]]

#text("But from ")#link(<tao-b43aae102b191a96b0ee>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} K(x_i,x_{k+1}) X(x_{k+1})\\ dx_{k+1} = (K(x_i,x_1),\\ldots,K(x_i,x_k))")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("R_i(A_k, \\int_{\\bf R} K(x_i,x_{k+1}) X(x_{k+1})\\ dx_{k+1} ) = A_k,")]]

#text("and the claim follows. ")#mi("\\Box")

#text("To establish ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(3)")]#text(", we will need some identities that are specific to the sine kernel ")#link(<tao-ef7c967436632d3042bd>)[#text("(2)")]#text(" that are reminiscent of ")#link(<tao-b43aae102b191a96b0ee>)[#text("(5)")]#text(" and ")#link(<tao-658447540603e4b7eaf8>)[#text("(6)")]#text(". The analogue of ")#link(<tao-658447540603e4b7eaf8>)[#text("(6)")]#text(" is very easy: ")#metadata(none) <tao-4a79665ec6e53ada95f4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("K(x,x) = 1.")]]

#text("The sine kernel actually does obey ")#link(<tao-b43aae102b191a96b0ee>)[#text("(5)")]#text(", but we will need the following more general identity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-b5fd4da6901078530ad0>#text(" For any real numbers ")#mi("{x,y,z}")#text(", one has ")#metadata(none) <tao-854391e53e480b621e0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_{\\bf R} K(x,t) K(y,t) \\frac{dt}{z-t} = \\frac{K(x,y) - \\cos(\\pi(z-y)) K(x,z)}{z-y}")]]

#text("(using the principal value interpretation of the integral) when ")#mi("{y,z}")#text(" are distinct. In particular, by ")#link("http://en.wikipedia.org/wiki/L%27H%C3%B4pital%27s_rule")[#text("l’Hopital’s rule")]#text(" one has ")#metadata(none) <tao-a9f615c4e7d33cf9a6a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\int_{\\bf R} K(x,t) K(y,t) \\frac{dt}{y-t} = - \\partial_y K(x,y)")]]
]

#text("Note that if one multiplies by ")#mi("{z}")#text(" in ")#link(<tao-854391e53e480b621e0b>)[#text("(9)")]#text(" and then sends ")#mi("{z \\rightarrow \\infty}")#text(", one recovers ")#link(<tao-b43aae102b191a96b0ee>)[#text("(5)")]#text(".")

#emph[#text("Proof:")]#text(" This can be verified by a routine contour integration, but we will give a more Fourier analytic proof instead. We will omit some (routine) details concerning justifying the various interchanges of integrals we will be using here. By a limiting argument we may take ")#mi("{x,y,z}")#text(" to be distinct. Observe that ")#metadata(none) <tao-c16ecf95fcaae6b03016>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("K(x,y) = \\int_{-1/2}^{1/2} e^{2\\pi i \\alpha(x-y)}\\ d\\alpha")]]

#text("and so the left-hand side of ")#link(<tao-854391e53e480b621e0b>)[#text("(9)")]#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\int_{-1/2}^{1/2} \\int_{-1/2}^{1/2} e^{2\\pi i (\\alpha x + \\beta y)} \\int_{\\bf R} \\frac{e^{-2\\pi i (\\alpha+\\beta) t}}{z-t}\\ dt d\\alpha d\\beta.")]]

#text("From the basic identity ")#mi("{\\int_{\\bf R} \\frac{\\sin x}{x}\\ dx = \\frac{\\pi}{2}}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{e^{-2\\pi i \\theta t}}{z-t}\\ dt = \\text{sgn}(\\theta) \\pi i e^{-2\\pi i \\theta z}")]]

#text("for any ")#mi("{\\theta \\in {\\bf R}}")#text(", so the preceding expression simplifies to")

#align(center)[#tao-fit-display[#mitex("\\pi i \\int_{-1/2}^{1/2} \\int_{-1/2}^{1/2} e^{2\\pi i (\\alpha (x-z) + \\beta (y-z))} \\text{sgn}(\\alpha+\\beta)\\ d\\alpha d\\beta.")]]

#text("We split this as the difference of ")#metadata(none) <tao-f55ff16f66f43360266b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\pi i \\int_{\\bf R} \\int_{-1/2}^{1/2} e^{2\\pi i (\\alpha (x-z) + \\beta (y-z))} \\text{sgn}(\\alpha+\\beta)\\ d\\alpha d\\beta.")]]

#text("and ")#metadata(none) <tao-2c3a4249d77070058649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\pi i \\int_{\\left|\\beta\\right| > 1/2} \\int_{-1/2}^{1/2} e^{2\\pi i (\\alpha (x-z) + \\beta (y-z))} \\text{sgn}(\\alpha+\\beta)\\ d\\alpha d\\beta.", block: true)]]

#text("For ")#link(<tao-f55ff16f66f43360266b>)[#text("(12)")]#text(", we make the change of variables ")#mi("{\\gamma := \\alpha+\\beta}")#text(" and rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\pi i \\int_{-1/2}^{1/2} e^{2\\pi i \\alpha (x-y)} \\int_{\\bf R} e^{2\\pi i \\gamma (y-z)} \\text{sgn}(\\gamma)\\ d\\gamma d\\alpha.")]]

#text("We have (in the distributional sense at least) that")

#align(center)[#tao-fit-display[#mitex("\\pi i \\int_{\\bf R} e^{2\\pi i \\gamma (y-z)} \\text{sgn}(\\gamma)\\ d\\gamma = \\frac{1}{z-y}")]]

#text("and so by ")#link(<tao-854391e53e480b621e0b>)[#text("(9)")]#text(" this term simplifies to ")#mi("{\\frac{K(x,y)}{z-y}}")#text(".")

#text("Now we turn to ")#link(<tao-2c3a4249d77070058649>)[#text("(13)")]#text(". Here we observe that in the region of integration we have ")#mi("{\\text{sgn}(\\alpha+\\beta)=\\text{sgn}(\\beta)}")#text(", and so this expression can be factored as")

#align(center)[#tao-fit-display[#tao-math("\\pi i (\\int_{\\left|\\beta\\right| > 1/2} e^{2\\pi i \\beta(y-z)} \\text{sgn}(\\beta)\\ d\\beta) (\\int_{-1/2}^{1/2} e^{2\\pi i \\alpha(x-z)}\\ d\\alpha).", block: true)]]

#text("The final factor here is ")#mi("{K(x,z)}")#text(" thanks to ")#link(<tao-854391e53e480b621e0b>)[#text("(9)")]#text(", while a brief computation shows (in the distributional sense, at least) that")

#align(center)[#tao-fit-display[#tao-math("\\pi i (\\int_{\\left|\\beta\\right| > 1/2} e^{2\\pi i \\beta(y-z)} \\text{sgn}(\\beta)\\ d\\beta) = \\frac{\\cos(\\pi(z-y))}{z-y}", block: true)]]

#text("and the claim follows.")

#text("Now we turn to the verification of ")#link(<tao-e2bd9c6236a519d406d1>)[#text("(3)")]#text(". It will suffice to establish the identity ")#metadata(none) <tao-4021fadf187fd2c8277a>

#tao-aligned(keep: true)[


#tao-math("\\int_{\\bf R} \\frac{\\rho_{k+1}(x_1,\\ldots,x_{k+1})}{x_i-x_{k+1}}\\ dx_{k+1}  & = \\frac{1}{2} \\partial_{x_i} \\rho_k(x_1,\\ldots,x_k)", block: true, numbering: n => [#text("(14)")])



#tao-math(" & - \\sum_{1 \\leq j \\leq k;i\\neq j} \\frac{\\rho_k(x_1,\\ldots,x_k)}{x_i-x_j}", block: true)
]

#text("for each ")#mi("{i=1,\\ldots,k}")#text(". By a continuity argument we may take the ")#mi("{x_1,\\ldots,x_k}")#text(" to be distinct.")

#text("Fix ")#mi("{i}")#text(". By ")#link(<tao-956fc30bfe11b61e7962>)[#text("(7)")]#text(", the left-hand side of ")#link(<tao-4021fadf187fd2c8277a>)[#text("(14)")]#text(" can be written as the difference of")

#align(center)[#tao-fit-display[#mitex("\\rho_k(x_1,\\ldots,x_k) \\int_{\\bf R} \\frac{K(x_{k+1},x_{k+1})}{x_i-x_{k+1}}\\ dx_{k+1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^{k}\\det( R_j( A_k, \\int_{\\bf R} K(x_j,x_{k+1}) X(x_{k+1}) \\frac{dx_{k+1}}{x_i-x_{k+1}}) ).")]]

#text("The first expression vanishes thanks to ")#link(<tao-4a79665ec6e53ada95f4>)[#text("(8)")]#text(", so we turn to the second. From Lemma ")#link(<tao-b5fd4da6901078530ad0>)[#text("2")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\bf R} K(x_j,x_{k+1}) X(x_{k+1}) \\frac{dx_{k+1}}{x_i-x_{k+1}}  & = \\frac{1}{x_i-x_j} ( K(x_j,x_a) )_{a=1}^k", block: true)



#tao-math(" & - \\frac{\\cos(\\pi(x_i-x_j))}{x_i-x_j} ( K(x_i,x_a) )_{a=1}^k", block: true)
]

#text("when ")#mi("{i \\neq j}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} K(x_j,x_{k+1}) X(x_{k+1}) \\frac{dx_{k+1}}{x_i-x_{k+1}}) = -( \\partial_i K(x_i,x_a) )_{a=1}^k")]]

#text("when ")#mi("{i=j}")#text(". In the former case, we see from row operations that")

#align(center)[#tao-fit-display[#mitex("\\det( R_j( A_k, \\int_{\\bf R} K(x_j,x_{k+1}) X(x_{k+1}) \\frac{dx_{k+1}}{x_i-x_{k+1}}) ) = \\frac{1}{x_i-x_j} \\det(A_k)")]]

#text("while from the Leibniz rule and symmetry (and ")#link(<tao-4a79665ec6e53ada95f4>)[#text("(8)")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\partial_{x_i} \\det(A_k) = 2 \\det( R_i( A_k, ( \\partial_i K(x_i,x_a) )_{a=1}^k ) );")]]

#text("putting all of these facts together, we obtain ")#link(<tao-4021fadf187fd2c8277a>)[#text("(14)")]#text(" as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Presumably, a similar exercise can be performed for the Airy process that governs the asymptotics of extreme eigenvalues of GUE (which include the famous Tracy-Widom law), but I did not attempt this.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af70954b0a101e163339ce534f07c608a14bf5a27e30b0eb7def692e53d0496e-2703e998dda8936fa3ce4ce91158e6253e52cbfdf941966369574c2c25d72385.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ANDI")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-191754")[#strong[#text("ANDI")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("Interesting! Well done!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f998e3f067772f8c91578fe41f02b0a82bbab965d705f23d5c2945fb0f4c7b-d94a3a7060677700900fe5ee42cbc2c84d99ae473e5fd06c642e9b47ae6c432b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoffrey Irving")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-191767")[#strong[#text("Geoffrey Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("Unfortunately the formatting for this post is very distorted for me: ")#link("http://naml.us/random/tao-formatting.png")[#text("http://naml.us/random/tao-formatting.png")]#text(". It might be due to a Mac Retina display issue. Do you know if anyone else has seen this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f998e3f067772f8c91578fe41f02b0a82bbab965d705f23d5c2945fb0f4c7b-d94a3a7060677700900fe5ee42cbc2c84d99ae473e5fd06c642e9b47ae6c432b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoffrey Irving")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-191769")[#strong[#text("Geoffrey Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("And…it just fixed itself. Odd.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-191774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("“it just fixed itself” –> “it just got fixed” ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-191974")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2012")])]

#text("After the sentence “…are the (normalised) Hermite polynomials; …” I think a link is missing. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-192467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2012")])]

#text("I see properly formatted equations until two equations past eq. (11), where it says “From the basic identity…”, the dispay equation after that, and all later equations, are distorted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a62b5f8c212067614f9a13cfd212368f5a688c8cbcb8ec61fc37befb0798efeb-90c41cf26b3c63f146b1262569eee78a8e1dc930dd18fe33478e6b2a578ebb48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yypus")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-196066")[#strong[#text("yypus")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2012")])]

#text("In (10), x-t should be y-t. Any one can explain or refer to a book why the two displays are true after “(in the distributional sense, at least)”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-196192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2012")])]

#text("Thanks for the correction! These identities are essentially equivalent to the fact that the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" is a Fourier multiplier with symbol ")#mi("-i \\text{sgn}(\\xi)")#text(" (depending on one’s sign conventions). Note that these integrals can also be evaluated in the principal value sense by contour integration, and with some standard truncation arguments one can show that the principal value sense of the integral matches up with the distributional interpretation of the integral.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e663f38891a2ec1c88dea11eb62e14d0873595c6407cecd17302672a64819ca5-ce654d3bf623e2cfd153dfdbeca1ee8b842c54ec15d7d917276879ec4b82dbd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike J")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-196602")[#strong[#text("Mike J")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("Terence, I have a completely out-of-office question. I have a truly marvelous reason for asking, which this box is too narrow to contain. I could think of no more appropriate place to ask than here, though even here it is still far from appropriate – I can only hope I catch you in a fine and humorous mood.")

#text("Do you drink coffee?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/033785f5481699c61cc69ed4eaa0af2aa50842b1e61afbb3b60c8002cf4f3fd4-3eb74f76d62cc33ec06a9c0e0e64d15c69668f16ad3f33a90315d6b85ec56d3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Watson")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-214840")[#strong[#text("Thomas Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2013")])]

#text("Good question. I am curious too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/11/a-direct-proof-of-the-stationarity-of-the-dyson-sine-process-under-dyson-brownian-motion/#comment-693843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("The cofactor expansion mentioned here is not only useful in determinantal point processes, but can also be used to prove certain related results in random matrix theory. However, it is not the only way to define or compute determinants. I’d like to ask, what are the advantages of using cofactor expansion as a tool (in these areas)?")
]
