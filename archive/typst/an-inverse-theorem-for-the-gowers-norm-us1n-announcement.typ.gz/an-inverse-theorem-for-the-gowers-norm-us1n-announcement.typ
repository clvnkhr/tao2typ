// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/
// Converted to Typst by tao2typ: "2026-10-14T16:36:12.965368+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the Gowers norm U^{s+1}[N] (announcement)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the Gowers norm U^{s+1}[N] (announcement)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/")[#text("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", ")#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the note “")#link("http://arxiv.org/abs/1006.0205")[#text("An inverse theorem for the Gowers norm ")#mi("{U^{s+1}[N]}")#text(" (announcement)")]#text("“, not intended for publication. This is an announcement of our forthcoming solution of the ")#emph[#text("inverse conjecture for the Gowers norm")]#text(", which roughly speaking asserts that ")#mi("{U^{s+1}[N]}")#text(" norm of a bounded function is large if and only if that function correlates with an ")#mi("{s}")#text("-step nilsequence of bounded complexity.")

#text("The full argument is quite lengthy (our most recent draft is about 90 pages long), but this is in large part due to the presence of various technical details which are necessary in order to make the argument fully rigorous. In this 20-page announcement, we instead sketch a ")#emph[#text("heuristic")]#text(" proof of the conjecture, relying in a number of “cheats” to avoid the above-mentioned technical details. In particular:")

#list(
[#text("In the announcement, we rely on somewhat vaguely defined terms such as “bounded complexity” or “linearly independent with respect to bounded linear combinations” or “equivalent modulo lower step errors” without specifying them rigorously. In the full paper we will use the machinery of nonstandard analysis to rigorously and precisely define these concepts.")],
[#text("In the announcement, we deal with the traditional linear nilsequences rather than the polynomial nilsequences that turn out to be better suited for finitary equidistribution theory, but require more notation and machinery in order to use.")],
[#text("In a similar vein, we restrict attention to scalar-valued nilsequences in the announcement, though due to topological obstructions arising from the twisted nature of the torus bundles used to build nilmanifolds, we will have to deal instead with vector-valued nilsequences in the main paper.")],
[#text("In the announcement, we pretend that nilsequences can be described by bracket polynomial phases, at least for the sake of making examples, although strictly speaking bracket polynomial phases only give examples of ")#emph[#text("piecewise")]#text(" Lipschitz nilsequences rather than genuinely Lipschitz nilsequences.")]
)

#text("With these cheats, it becomes possible to shorten the length of the argument substantially. Also, it becomes clearer that the main task is a cohomological one; in order to inductively deduce the inverse conjecture for a given step ")#mi("{s}")#text(" from the conjecture for the preceding step ")#mi("{s-1}")#text(", the basic problem is to show that a certain (quasi-)cocycle is necessarily a (quasi-)coboundary. This in turn requires a detailed analysis of the top order and second-to-top order terms in the cocycle, which requires a certain amount of nilsequence equidistribution theory and additive combinatorics, as well as a “sunflower decomposition” to arrange the various nilsequences one encounters into a usable “normal form”.")

#text("It is often the case in modern mathematics that the informal heuristic way to explain an argument looks quite different (and is significantly shorter) than the way one would formally present the argument with all the details. This seems to be particularly true in this case; at a superficial level, the full paper has a very different set of notation than the announcement, and a lot of space is invested in setting up additional machinery that one can quickly gloss over in the announcement. We hope though that the announcement can provide a “road map” to help navigate the much longer paper to come.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-45289")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Congratulations to you and Ben and Tamar, not only for the wonderful mathematics, but also for taking the time to write this accessible announcement. It’s so encouraging to see powerful math being done by people who also care deeply about exposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbaceb23bc4bdb2cf44f56c293ca939c8150001499d57bdaf33bb09ad37b8a8d-cff216297cef8bd17dbe10e2edae68d23c59d0efe07f73a921e9828bef8b68c8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Doty")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-45290")[#strong[#text("Dave Doty")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Culturally, this is a project almost worthy of theoretical computer science. But have made a classic novice error by working out the details first, before making the announcement. To make the project worthy of TCS, you should to send the heuristic, informal paper to a top-tier conference where acceptance will win more prestige and future grants than even the best journal, mention the upcoming full version throughout the paper whenever you need to skip details, and then the last crucial step: never write the full version. Bonus points if one of the main theorems whose proof you “delay until the full version” turns out to be incorrect. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-45292")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Possibly a typo: in the abstract it is mentioned “…for any ")#mi("k\\geq 3")#text("” while on page 3 of the paper just below theorem 1.3 it is mentioned only “…for every fixed positive integer ")#mi("k")#text("” (which would include twin primes if I’m not mistaken).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-45296")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("The results also apply for k=1,2, but in those cases the claim (counting arithmetic progressions of primes of length one or two) is equivalent to the prime number theorem. (The key difference between the arithmetic progression problem and the twin prime problem is that in the former, the spacing is not fixed.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b5e8b767c54854c71db2fcfcc5346fb8cbd066ba4e99aee473f1ef4419a3510-6dc981e01a3082a27ac0d4950e1e8cad3dd0ef0be5259ea79f9df5fb886dff7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-45624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("At this rate, Hardy-Littlewood will be solved in my lifetime. Congratulations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the Gowers U^{s+1}[N] norm « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/#comment-47194")[#strong[#text("An inverse theorem for the Gowers U^{s+1}[N] norm « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("[…] to the arXiv our paper “An inverse theorem for the Gowers U^{s+1}[N] norm“, which was previously announced on this blog. We are still planning one final round of reviewing the preprint before submitting the paper, but […]")
]
