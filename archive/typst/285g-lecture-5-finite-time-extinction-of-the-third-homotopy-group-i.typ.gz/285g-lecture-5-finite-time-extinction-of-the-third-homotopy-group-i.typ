// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/
// Converted to Typst by tao2typ: "2026-10-14T15:16:44.525453+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 5: Finite time extinction of the third homotopy group, I", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 5: Finite time extinction of the third homotopy group, I")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("previous lecture")]#text(", we saw that Ricci flow with surgery ensures that the second ")#link("http://en.wikipedia.org/wiki/Homotopy_group")[#text("homotopy group")]#text(" ")#mi("\\pi_2(M)")#text(" became extinct in finite time (assuming, as stated in the above erratum, that there is no embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle). It turns out that the same assertion is true for the third homotopy group, at least in the simply connected case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Finite time extinction of ")#mi("\\pi_3(M)")#text(") Let ")#mi("t \\mapsto (M(t),g(t))")#text(" be a Ricci flow with surgery on compact 3-manifolds with ")#mi("t \\in [0,+\\infty)")#text(", with M(0) simply connected. Then for all sufficiently large t, ")#mi("\\pi_3(M(t))")#text(" is trivial (or more precisely, every connected component of M(t) has trivial ")#mi("\\pi_3")#text(").")
]

#text("[")#emph[#text("Aside")]#text(": it seems to me that this theorem should also be true if one merely assumes that M(0) contains no embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial bundle, as opposed to M(0) being simply connected, but I will be conservative and only state Theorem 1 with this stronger hypothesis, as this is all that is necessary for proving the Poincaré conjecture.]")

#text("Suppose we apply Ricci flow with surgery to a compact simply connected Riemannian 3-manifold (M,g) (which, by Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(", has no embedded ")#mi("\\Bbb {RP}^2")#text(" with trivial normal bundle). From the above theorem, as well as Theorem 1 from the ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("previous lecture")]#text(", we know that all components of M(t) eventually have trivial ")#mi("\\pi_2")#text(" and ")#mi("\\pi_3")#text(" for all sufficiently large t. Also, since M is initially simply connected, we see from Exercise 2 of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(", as well as Theorem 2.1 of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(", that all components of M(t) also have trivial ")#mi("\\pi_1")#text(". The finite time extinction result (Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(") then follows immediately from Theorem 1 and the following topological result, combined with the following topological observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let M be a compact non-empty connected 3-manifold. Then it is not possible for ")#mi("\\pi_1(M)")#text(", ")#mi("\\pi_2(M)")#text(", and ")#mi("\\pi_3(M)")#text(" to simultaneously be trivial.")
]

#text("This lemma follows immediately from the ")#link("http://en.wikipedia.org/wiki/Hurewicz_theorem")[#text("Hurewicz theorem")]#text(", but for sake of self-containedness we give a proof of it here.")

#text("There are two known approaches to establishing Theorem 1; one due to ")#link("http://xxx.lanl.gov/abs/math.AP/0308090")[#text("Colding and Minicozzi")]#text(", and one due to ")#link("http://arxiv.org/abs/math/0307245")[#text("Perelman")]#text(". The former is conceptually simpler, but requires a certain technical concentration-compactness type property for a min-max functional which has only ")#link("http://arxiv.org/abs/0707.0108")[#text("been established recently")]#text(". This approach will be the focus of this lecture, while the latter approach of Perelman, which has also been rigorously shown to imply finite time extinction, will be the focus of the next lecture.")

#metadata(none) <tao-428a868eda3e6c70d2a8>

#heading(level: 1)[#text("— A little algebraic topology —")]

#text("[")#emph[#text("Aside")]#text(": My algebraic topology is rather rusty; I haven’t studied it since taking an undergraduate class on the topic at Flinders 17 years ago! There may be some technical subtleties involving, e.g. the difference between simplicial complexes and ")#link("http://en.wikipedia.org/wiki/CW_complex")[#text("CW complexes")]#text(", or between free homotopy and homotopy with fixed base point, which I may not quite have rendered correctly here, though I believe that the broad details of what I wrote below are right, at least. As always, I of course welcome any and all corrections.]")

#text("We begin by proving Lemma 1. We need to recall some (very basic) ")#link("http://en.wikipedia.org/wiki/Singular_homology")[#text("singular homology")]#text(" theory (over the integers ")#mi("{\\Bbb Z}")#text("). Fix a compact manifold M, and let k be a non-negative integer. Recall that a ")#emph[#text("singular k-chain")]#text(" (or ")#emph[#text("k-chain")]#text(" for short) is a formal integer-linear combination of k-dimensional singular simplices ")#mi("\\sigma(\\Delta_k)")#text(" in M, where ")#mi("\\Delta_k")#text(" is the standard k-simplex and ")#mi("\\sigma: \\Delta_k \\to M")#text(" is a continuous map. There is a boundary map ")#mi("\\partial")#text(" taking k-chains to (k-1)-chains, defined by mapping ")#mi("{}\\sigma(\\Delta_k)")#text(" to an alternating sum of restrictions of ")#mi("\\sigma")#text(" to the (k-1)-dimensional boundary simplices of ")#mi("\\Delta_k")#text(", and then extending by linearity. A k-chain is said to be a ")#emph[#text("k-cycle")]#text(" if its boundary vanishes, and is a ")#emph[#text("k-boundary")]#text(" if it is the boundary of a (k+1)-chain. One easily verifies that ")#mi("\\partial^2 = 0")#text(", and so every k-boundary is a k-cycle. We say that M has ")#emph[#text("trivial ")#mi("k^{th}")#text(" ")#link("http://en.wikipedia.org/wiki/Homology_%28mathematics%29")[#text("homology group")]]#text(" ")#mi("H_k(M)")#text(" if the converse is true, i.e. every k-cycle is a k-boundary.")

#text("Our main tool for proving Lemma 1 is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" (Baby Hurewicz theorem). Let M be a triangulated connected compact manifold such that the fundamental groups ")#mi("\\pi_1(M),\\ldots,\\pi_k(M)")#text(" all vanish for some ")#mi("k \\geq 1")#text(". Then M has trivial ")#mi("j^{th}")#text(" homology group ")#mi("H_j(M)")#text(" for every ")#mi("1 \\leq j \\leq k")#text(".")
]

#strong[#text("Proof.")]#text(" Because of all the vanishing fundamental groups, one can show by induction on j that for any integer ")#mi("1 \\leq j \\leq k")#text(", any singular complex ")#link("http://en.wikipedia.org/wiki/Simplicial_complex")[#text("http://en.wikipedia.org/wiki/Simplicial_complex")]#text("in M involving singular simplices of dimension at most j can be continuously deformed to a point (while preserving all boundary relationships between the singular simplices in that complex). As a consequence, every j-cycle, being the combination of singular simplices in a singular complex involving singular simplices of dimension at most j, can be expressed as the boundary of a (j+1)-chain, and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 1. ")]#text(" The ")#link("http://en.wikipedia.org/wiki/Hurewicz_theorem")[#text("full Hurewicz theorem")]#text(" asserts some further relationships between homotopy groups and homology groups, in particular that under the assumptions of Proposition 1, that the ")#emph[#text("Hurewicz homomorphism")]#text(" from ")#mi("\\pi_{k+1}(M)")#text(" to ")#mi("H_{k+1}(M)")#text(" is in fact an isomorphism (and, in the k=0 case, that ")#mi("H_1(M)")#text(" is canonically isomorphic to the ")#link("http://en.wikipedia.org/wiki/Abelianization#Abelianization")[#text("abelianisation")]#text(" of ")#mi("\\pi_1(M)")#text("). However, we do not need this slightly more advanced result here. ")#mi("\\diamond")

#text("Now we can quickly prove Lemma 1.")

#strong[#text("Proof of Lemma 1.")]#text(" Suppose for contradiction that we have a non-empty connected compact 3-manifold M with ")#mi("\\pi_1(M),\\pi_2(M),\\pi_3(M)")#text(" all trivial. Since M is simply connected, it is orientable (as all loops are contractible, there can be no obstruction to extending an orientation at one point to the rest of the manifold). Also, it is a classical result ")#link("http://www.ams.org/mathscinet-getitem?mr=48805")[#text("of Moise")]#text(" that every 3-manifold can be triangulated. Using a consistent orientation on M, we may therefore build a 3-cycle on M consisting of the sum of oriented 3-simplices with disjoint interiors that cover M (i.e. a ")#link("http://en.wikipedia.org/wiki/Fundamental_class")[#text("fundamental class")]#text("), thus the net multiplicity of this cycle at any point in M is odd. On the other hand, the net multiplicity of any 3-boundary at any point can be seen to necessarily be even. Thus we have found a 3-cycle which is not a 3-boundary, which contradicts Proposition 1. [")#emph[#text("Aside")]#text(": one can avoid the use of Moise’s theorem here by working in the category of smooth manifolds, or by using more of the basic theory of singular homology. See comments. Also, the use of orientability can be avoided by working with homologies over ")#mi("{\\Bbb Z}/2{\\Bbb Z}")#text(" rather than over ")#mi("{\\Bbb Z}")#text(".] ")#mi("\\Box")

#strong[#text("Remark 2.")]#text(" Using (slightly) more advanced tools from algebraic topology, one can in fact say a lot more about the homology and homotopy groups of connected and simply connected compact 3-manifolds M. Firstly, since ")#mi("\\pi_1(M)")#text(" is trivial, one sees from the ")#link("http://en.wikipedia.org/wiki/Hurewicz_theorem")[#text("full Hurewicz theorem")]#text(" that ")#mi("H_1(M)")#text(" is also trivial. Also, as M is connected, ")#mi("H_0(M) \\equiv {\\Bbb Z}")#text(". From orientability (which comes from simple connectedness) and triangularisability we have ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_duality")[#text("Poincaré duality")]#text(", which implies that the cohomology group ")#mi("H^2(M)")#text(" is trivial and ")#mi("H^3(M) \\equiv {\\Bbb Z}")#text(", which by the ")#link("http://en.wikipedia.org/wiki/Universal_coefficient_theorem")[#text("universal coefficient theorem")]#text(" for cohomology implies that ")#mi("H_2(M)")#text(" is trivial and ")#mi("H_3(M) \\equiv {\\Bbb Z}")#text(". Of course, being 3-dimensional, all higher homology groups vanish, and so M is a ")#link("http://en.wikipedia.org/wiki/Homology_sphere")[#text("homology sphere")]#text(". On the other hand, by orientability, we can find a map from M to ")#mi("S^3")#text(" that takes a ")#link("http://en.wikipedia.org/wiki/Fundamental_class")[#text("fundamental class")]#text(" of M to a fundamental class of ")#mi("S^3")#text(", by taking a small ball in M and contracting everything else to a point; this map is thus an isomorphism on each homology group. Using the ")#link("http://en.wikipedia.org/wiki/Hurewicz_theorem#Relative_version")[#text("relative Hurewicz theorem")]#text(" (and the simply connected nature of M and ")#mi("S^3")#text(") we conclude that this map is also an isomorphism on each homotopy group, and thus by ")#link("http://en.wikipedia.org/wiki/Whitehead%27s_theorem")[#text("Whitehead’s theorem")]#text(", the map is a ")#link("http://en.wikipedia.org/wiki/Homotopy#Homotopy_equivalence_of_spaces")[#text("homotopy equivalence")]#text(", thus M is a ")#link("http://en.wikipedia.org/wiki/Homotopy_sphere")[#text("homotopy sphere")]#text(". Thus, to complete the proof of the Poincaré conjecture, it suffices to show that every compact 3-manifold which is a homotopy sphere is also homeomorphic to a sphere. Unfortunately this observation does not seem to significantly simplify the proof of that conjecture, although it does allow one at least to get the extinction of ")#mi("\\pi_2")#text(" from the previous lecture “for free” in the simply connected case. (Note also that there are homology 3-spheres that are not homeomorphic to the 3-sphere, such as the ")#link("http://en.wikipedia.org/wiki/Homology_sphere#Poincar.C3.A9_homology_sphere")[#text("Poincaré homology sphere")]#text("; thus homology theory is not sufficient by itself to resolve this conjecture.) ")#mi("\\diamond")

#heading(level: 1)[#text("— The Colding-Minicozzi approach to ")#mi("\\pi_3")#text(" extinction —")]

#text("We now sketch the Colding-Minicozzi approach towards proving Theorem 1. Our discussion here will not be fully rigorous; further details can be found in the original paper of ")#link("http://xxx.lanl.gov/abs/math.AP/0308090")[#text("Colding and Minicozzi")]#text(".")

#text("In the previous lecture, we obtained the differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dt} \\int_{f(S^2)}\\ d\\mu \\leq - 4\\pi - \\frac{1}{2} R_{\\min} \\int_{f(S^2)}\\ d\\mu;")]]

#text("for any minimal immersed 2-sphere ")#mi("f(S^2)")#text(" in a Ricci flow ")#mi("t \\mapsto (M(t),g(t))")#text(". The inequality also holds for the slightly larger class of minimal 2-spheres that are ")#emph[#text("branched")]#text(" immersions rather than just immersions; furthermore, an inspection of the proof reveals that the surface does not actually have to be a local area minimiser, but merely needs to have zero mean curvature (i.e. to be a critical point for the area functional, rather than a local minimum). The inequality (1) was a key ingredient in the proof of finite time extinction of the second homotopy group ")#mi("\\pi_2(M(t))")#text(".")

#text("The Colding-Minicozzi approach seeks to exploit the same inequality (1) to also prove finite time extinction of ")#mi("\\pi_3(M(t))")#text(". It is not immediately obvious how to do this, since ")#mi("\\pi_3()")#text(" involves immersed 3-spheres ")#mi("f(S^3)")#text(" in M, whereas (1) involves immersed 2-spheres ")#mi("f(S^2)")#text(". However, one can view the 3-sphere as a loop of 2-spheres with fixed base point; indeed if one starts with the cylinder ")#mi("{}[0,1] \\times S^2")#text(" and identifies ")#mi("\\{0,1\\} \\times S^2 \\cup [0,1] \\times \\{N\\}")#text(" to a single point, where N is a single point in ")#mi("S^2")#text(", one obtains a (topological) 3-sphere. Because of this, any immersed 3-sphere ")#mi("f(S^3)")#text(" is swept out by a loop ")#mi("s \\mapsto f_s")#text(" of immersed 2-spheres ")#mi("f_s(S^2)")#text(" for ")#mi("0 < s < 1")#text(" with fixed base point ")#mi("f_s(N)=p")#text(", with ")#mi("f_s")#text(" varying continuously in t for ")#mi("0 \\leq s \\leq 1")#text(", and ")#mi("f_0=f_1\\equiv p")#text(" being the trivial map.")

#text("Suppose that we have a Ricci flow in which M is connected and ")#mi("\\pi_3(M)")#text(" is non-trivial; then we have at least one immersed 3-sphere ")#mi("f(S^3)")#text(" which is not contractible to a point. We then define the functional ")#mi("W_3(t)")#text(" by the min-max formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("W_3(t) := \\inf_f \\sup_{0 \\leq s \\leq 1} \\int_{f_s(S^2)}\\ d\\mu")]]

#text("where f ranges over all incontractible immersed 3-spheres, and ")#mi("\\mu")#text(" is the volume element of ")#mi("f_s(S^2)")#text(" with respect to the restriction of the ambient metric g(t).")

#text("It can be shown (see e.g. page 125 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1100926")[#text("Jost’s book")]#text(") that ")#mi("W_3(t)")#text(" is strictly positive; in other words, if the area of each 2-sphere in a loop of immersed 2-spheres is sufficiently small, then the whole loop is contractible to a point.")

#text("Suppose for the moment that the infimum in (2) was actually attained, thus there exists an incontractible immersed 3-sphere f whose maximum value of ")#mi("\\int_{f_s(S^2)}\\ d\\mu")#text(" is exactly ")#mi("W_3(t)")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Mean_curvature_flow")[#text("mean curvature flow")]#text(" for a short time to reduce the area of any sphere which does not already have vanishing mean curvature, we may assume without loss of generality that the maximum value is only attained when ")#mi("f_s(S^2)")#text(" has zero mean curvature. (To make this rigorous, one either has to prove a local well-posedness result for , or else to use a cruder version of this flow, for instance deforming f a small amount along a vector field which points in the same direction as the mean curvature. We omit the details.) If we then use (1), we thus (formally, at least) obtain the differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{dt} W_3(t) \\leq - 4\\pi - \\frac{1}{2} R_{\\min} W_3(t)")]]

#text("much as in the ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("previous lecture")]#text(". Arguing as in that lecture, we obtain a contradiction if the Ricci flow persists without developing singularities for a sufficiently long time.")

#text("It should be possible that a similar analysis can also be performed when the infimum in (2) is not actually attained, in which case one has a minimising sequence of loops of 2-spheres whose width approaches ")#mi("W_3(t)")#text(". This sequence can be analysed by Sacks-Uhlenbeck theory (together with some later analysis of bubbling due to Siu and Yau) and a finite number of minimal 2-spheres extracted as a certain “limit” of the above sequence, although as in the previous lecture, these 2-spheres need only branched immersions rather than immersions. From this one can establish (3) (in a suitably weak sense) in the general case in which the infimum in (2) is not necessarily attained), assuming that one can show that all the 2-spheres with area close to ")#mi("W_3(t)")#text(" that appear in a loop in the minimising sequence are close to the union of the limiting minimal 2-spheres in a certain technical sense; see the paper of ")#link("http://xxx.lanl.gov/abs/math.AP/0308090")[#text("Colding and Minicozzi")]#text(" (and the references therein) for details. This property (which is a sort of concentration-compactness type property for the min-max functional (2), which is a partial substitute for the failure of the ")#link("http://en.wikipedia.org/wiki/Palais-Smale_condition")[#text("Palais-Smale condition")]#text(" for this functional) was recently established, again ")#link("http://arxiv.org/abs/0707.0108")[#text("by Colding and Minicozzi")]#text(", using the theory of ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic maps")]#text(".")

#text("There is also the issue of how to deal with surgery. This follows the same lines that were briefly (and incompletely) sketched out in the previous lecture. Namely, one first observes that after finitely many surgeries, all remaining surgeries are along 2-spheres that are homotopically trivial (i.e. contractible to a point). Because of this, one can show that any incontractible 3-sphere will, after surgery, lead to at least one incontractible 3-sphere on one of the components of the post-surgery manifold. Furthermore, it turns out that there is a distance-decreasing property of surgery which can be used to show that ")#mi("W_3(t)")#text(" does not increase at any surgery time. We will discuss these sorts of issues in a bit more detail in the next lecture, when we turn to the Perelman approach to ")#mi("\\pi_3")#text(" extinction.")

#text("[Update, April 16: Simplicial homology replaced with singular homology.]")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29082")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Certainly you applied the algebraic topology correctly, but the proof that you give of the baby Hurewicz theorem is more of a poof than a proof. In order to complete this argument, you would have to know how to convert a homotopy to a simplicial chain. You can do that using simplicial approximation, but it is then the lion’s share of the work in the argument. You might as well use the same simplicial approximation construction to instead show that singular and simplicial homology are isomorphic. It’s much easier to prove the baby Hurewicz theorem using singular homology; the argument reads much like what you wrote.")

#text("Another technical detail in the full Hurewicz theorem is that it is the abelianization of pi_k that is isomorphic to H_k. It just so happens that pi_k is abelian if k is at least 2. Also the full Hurewicz theorem is proved in almost the same way as the baby Hurewicz theorem. Note that when you used it in reverse, you used the stronger version, and it was important that k wasn’t 1.")

#text("If you use singular homology, then you do not need Moise’s theorem to apply the Hurewicz theorem. At the moment, I cannot think of any restrictions whatsoever on the Hurewicz theorem for singular homology; I will venture that it applies to all topological spaces.")

#text("Moreover, the context of your use of Moise’s theorem is not quite right. Perelman’s work is a classification of smooth 3-manifolds. It is not all that hard to prove — I think the result is due to Whitney or Whitehead — that every smooth manifold can be smoothly triangulated. One approach is to lay down a generic epsilon net on the manifold and then show that its Voronoi tiling admits a dual Delaunay triangulation. Again, someone such as Whitney or Whitehead showed that all smooth triangulations of a smooth manifold are equivalent under combinatorial moves, so that every smooth structure induces a unique PL structure.")

#text("Rather, the hard work that is moreover special to dimension 3 (and lower) is in the other direction: Does every topological manifold have a PL structure, and if so, how many? Does every PL manifold have a smooth structure, and if so, how many? (In both cases, “how many” is considered up to some suitable local moves or motions.) The answer to all four questions is yes in 3 dimensions. The continuous to PL cases are Moise’s theorem or the Moise-Bing theorem. Existence of a smooth structure is elementary. Uniqueness of smooth structures on a PL 3-manifold is due to Smale; although it was proved later, it’s a much easier result than Moise-Bing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29083")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Oh, sorry, I misread where you use Moise’s theorem — you implicitly used it in discussing simplicial homology, but the explicit invocation was in your Lemma 1.")

#text("Well, again, what you wrote is not fundamentally wrong, but somewhat incongruous. The fact that M has a fundamental class is a special case of Poincare duality, which you use elsewhere without reference to Moise. To be sure, it is much easier to prove Poincare duality for a triangulated manifold, or more generally for a manifold with a handle decomposition, than for general topological manifolds. A handle decomposition is really the right level of generality for either your fundamental class sublemma or for full Poincare duality. It represents a cellulation of a manifold in which cell can be thickened to a handle, so that, for instance, the n-1-cells a priori have two sides. For full Poincare duality, the handle decomposition gives you two dual cellulations, and homology on one of them is algebraically identical to cohomology on the other one.")

#text("If you have a smooth manifold and you want a handle decomposition for the sake of Poincare duality, then the best and most beautiful construction is to use the gradient flow of a Morse function. You don’t need the messier fuss with triangulations.")

#text("In fact, Poincare duality holds for every compact topological manifold, even if it doesn’t have a triangulation or a handle decomposition. This is one of the trickiest dimension-independent results in manifold topology (as opposed to dimension-dependent results or proofs such as Moise’s theorem), and I am not sure how to prove it or who deserves credit. Spanier and Whitehead, maybe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Thanks Greg! I had suspected I was somewhat confused regarding the various flavours of homology, and your comments helped clarify my confusion. So it seems that the most elementary way to proceed is to use singular homology throughout. There is still the issue of generating the fundamental class, which still seems to require something like triangulation, so I think I still need to invoke Moise there. (It is true that one can avoid Moise’s theorem if one starts off in the smooth category, but for various reasons I had decided to formulate the Poincare conjecture in the topological category, although of course the first step then is to immediately apply Moise to create a PL and then a smooth structure on the manifold.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29090")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Yes, the theory is better-founded in singular homology. Moreover, all of the properties of homology that you expect of compact manifolds hold even if they don’t have triangulations: The top cohomology is either Z or Z/2, there is a fundamental class, Poincare duality is true, all of the homology groups are finitely generated, etc. So technically speaking you don’t need Moise’s theorem at this stage. It is true that it’s harder to prove the homological structure theorems without a triangulation, but it is both dimension-independent and not as hard as Moise’s theorem. (I should review exactly how they are proved before expressing any more opinions on the matter. Google suggests to me that topological Poincare duality was proved in 1930 by William Flexner.)")

#text("Since the bulk of what you are doing has to be smooth anyway, I would say that it’s incongruous to invoke Moise’s theorem more than at the very beginning, because it is relatively easy to find a smooth triangulation of a smooth manifold. It’s even easier to make a fundamental class if that is all you want: Take the cellulation induced by a Morse function and take the sum of the top-dimensional cells. But okay, the point has been made.")

#text("—-")

#text("While I am at it, I’d like to air an open problem in geometric analysis that is related to existence of smooth structures. Allan Hatcher showed that a PL 4-manifold has a unique smooth structure. The key technical result is that the diffeomorphism group of the 3-sphere is homotopy equivalent to the isometry group O(4). Or, it turns out to be enough to show that the space of smooth fibrations of a cylinder S^2 x I by spheres is contractible. Hatcher’s proof of this (I think) largely combinatorial in spirit, and also some people have said that the proof is quite complicated. It would be interesting to prove it using geometric analysis.")

#text("A natural idea that comes to mind is one that actually works in the previous dimension: Use mean curvature flow to flatten all of the leaves of the fibration simultaneously. The flow cannot make the leaves cross. However, in 3 dimensions, mean curvature flow can develop singularities in a finite amount of time, so this construction doesn’t work. I have been wondering whether you can replace mean curvature flow by another parabolic flow that (optimistically) can’t develop singularities quickly enough to wreck the argument. Mean curvature flow is the gradient flow of th area functional. What if instead you took the gradient flow of the integral of exp(R), where R is the scalar curvature of the surface? At least the simplest sort of singularity, a shrinking hyperboloid, might not be able to form in a finite amount of time. In this context, it would approximately pinch off a bulb from the sphere, and the bulb would (if we’re lucky enough) shrink away first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec48c7b8027aa0aa442d868776dbe960e69be69e7eb92cb64ae8f3d5d8080cd4-ed5448751feb3d39689001133b47c4980138ae8dc769ccd8010b2854bb9e31ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid Barton")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29091")[#strong[#text("Reid Barton")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("A minor note: In Remark 2 you construct a map ")#mi("M \\to S^3")#text(" which is an isomorphism on H_3 (and H_0) and therefore is an isomorphism on all homology groups. You then say you’re using Whitehead’s theorem to conclude that it is a homotopy equivalence; but Whitehead’s theorem applies to maps which are isomorphisms on all pi_k, not all H_k. And S^3 (and so presumably M) has many nonzero higher homotopy groups that you haven’t dealt with.")

#text("So you first need to use the relative Hurewicz theorem to conclude that your map is indeed an isomorphism on homotopy groups. Here the fact that M and S^3 are simply connected is an important condition; as you mention, the Poincaré homology sphere P is not simply connected, and yet the construction you describe gives a map ")#mi("P \\to S^3")#text(" which is a homology isomorphism.")

#text("To be precise, a map between simply-connected spaces which is an isomorphism on integral homology groups is an isomorphism on homotopy groups, by the relative Hurewicz theorem; and a map between connected CW complexes which is an isomorphism on homotopy groups is a homotopy equivalence, by Whitehead’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29104")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("At this point, Reid and I may be saying rather more than necessary about just one part of the discussion, but it occurred to me that a lot of the appeal to algebraic topology can be simplified and made much more hands on for the specific purpose of proving lemma 1.")

#text("First, yes, if you want to state lemma 1 in the generality of topological manifolds, you might as well start with the triangulation theorem. The obvious generalization of the result to n dimensions does not require a triangulation (even though, in the end, the Poincare conjecture is true and so there is a triangulation), but the rest of the argument is then less intuitive and requires more abstract appeals to Hurewicz, Whitehead, and Flexner.")

#text("Anyway, start with a triangulation and consider the more general method of building a manifold by gluing together polytopes face to face. Then you can always reduce the number n-cells to 1 by knocking out walls. In 3 dimensions, then, every 3-manifold is obtained by gluing a single polyhedron to itself.")

#text("A slightly stronger version of Lemma 1 as stated here is that if pi_1(M) and pi_2(M) both vanish, then M is homotopy equivalent to S^3. Since pi_1 and pi_2 both vanish, you can homotop the identity map on M to collapse its 2-skeleton to a point. This collapse of M is plainly homeomorphic to S^3. So you immediately get pair of maps f:M -> S^3 and g:S^3 -> M such that the composition gf is homotopic to the identity. The other composition is also homotopic to the identity because it has degree 1. Finis.")

#text("With a little more hands-on work, and with one non-trivial application of the Hurewicz theorem, you can relax lemma 1 to show that if pi_1(M) vanishes, then pi_2(M) also vanishes. The cellulation of M can be simplified a bit further: You can identify all of the vertices by contracting edges. If you then compare the cellular presentations of pi_1 and H_1, you immediately get the k=1 case of the Hurewicz theorem, because the presentations are identical except that H_1 is abelian. You also obtain Poincare duality between H_1 and H_2 as follows. The Euler formula tells you that there are the same number of 1-cells and 2-cells. The boundary map from 2-cells to 1-cells is some matrix M, and the cellular homology computation says that H_2 is the kernel of M while H_1 is the cokernel. (Since all 1-cells are loops and all 2-cells are two sides of the same 3-cell, the other two boundary maps vanish.) So obviously H_2 is free and has the same rank as the free part of H_1. Finally the Hurewicz theorem says that if pi_1 vanishes, then pi_2 = H_2.")

#text("—-")

#text("Finally here are some remarks about how to prove either Flexner’s theorem or triangulate 3-manifolds. The basic lesson is that topological manifolds are a hard start. Flexner’s theorem proceeds by embedding the manifold M in a high-dimensional sphere or Euclidean space. It is then an intersection of polyhedral regions, and you can show (by Alexander duality) that its Cech cohomology is suitably dual to the homology of its complement. Then, separately, since M is a manifold, its Cech cohomology is isomorphic to its singular cohomology. You can also relate the homology of M to the homology of its complement using gluing axioms of homology theory. This sketch does not really do the argument justice, but it is the way to get started.")

#text("Or, if you want to triangulate 3-manifolds, there is a modern proof due to Andrew Hamilton based on the Kirby-Siebenmann method to triangulate high-dimensional manifolds (when that is possible). The proof is fairly short and fairly concrete, but it’s still quite tricky — the Kirby-Siebenmann work in general requires a number of exacting inferences. The proof also depends on a non-trivial 3-manifold classification result due to Waldhausen: if a PL 3-manifold is irreducible and homotopy equivalent to a 3-torus, then it is a PL 3-torus. It comes full circle, because Perelman reproves this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("Dear Greg,")

#text("That’s a very nice proof of Lemma 1, which avoids homology theory almost completely! (Though I admit that I was only able to verify that fg had degree 1 by using the fundamental class as in my proof of the lemma.)")

#text("It is of course very tempting to try to use the combinatorial description of a 3-manifold as a polytope with various faces identified to attack the Poincare conjecture; there of course have been many failed attempts to do so, and I wonder if there is now some sort of understanding as to why this is the case. (Certainly it is clear that it is hopeless to try to transplant Ricci flow methods to the combinatorial setting.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29111")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("Yes, you need some notion of a fundamental class to discuss degrees of maps at all. You could say, in the smooth or PL cases, that the degree of a map is the signed cardinality of the inverse image of a generic point. That looks like it does not use the fundamental class, but it actually does; it is implicitly a definition of the fundamental cohomology class in the smooth or PL cases.")

#text("Maybe people understood better why combinatorial approaches don’t prove the Poincare conjecture during the century that the Poincare conjecture was open. :-) I’m not sure that I would agree that it’s hopeless to make the Ricci flow methods combinatorial. At the moment it could seem unlikely or wrong-minded, but hopelessness could be too strong. For instance, circle-packing theorems are a combinatorial analogue of uniformization of surfaces, and there is even a combinatorial analogue of Ricci flow for imperfect circle packings. Minimal surface theory in 3-manifolds also has a combinatorial analogue called normal surface theory. Some of these combinatorial analogues are elegant or important in their own right. Others somehow seem to be miss the point, and just adulterate the geometry.")

#text("There were several stages at which manifold topology, or 3-manifold topology, was revolutionized and people thought that a proof of the Poincare conjecture might come soon. One instance was when Papakyriakopoulos proved the loop and sphere theorems. The sphere theorem is lurking behind your discussion of pi_2: The theorem says that pi_2 is generated by embedded spheres. Another was when Smale proved (a version of) the Poincare conjecture in high dimensions. Another was when Thurston introduced geometrization and geometrized a large class of manifolds.")

#text("You could say that all of the important combinatorial arguments in 3-manifold topology depend strongly on the use of surfaces. (Or in some cases, foliations or similar.) This smacks of truism, but maybe there is some depth to it. After all, it is vastly easier to prove the analogue of the Poincare conjecture for a 3-torus; it was done by Waldhausen. You do it by cutting the putative 3-torus along what is known as an essential surface. You can repeat that until the manifold becomes a cube with opposite sides glued. Papakyriakopoulos’ theorems are the underlying engine of the argument. Of course you can now also use Ricci flow, which does not clearly rely on Papakyriakopoulos.")

#text("No one other than Hamilton and Perelman have thought of a way to analyze the topology of a manifold that does not have nice surfaces in it. On this page, you call the map from S^3 or the swept out form “immersed”, but it actually isn’t immersed; it can have nasty non-immersion singularities. These singularities largely defy combinatorial understanding, but that may not be true forever.")

#text("Thurston also used essential surfaces in the part of geometrization that he established. Meanwhile Smale’s work led to surgery theory. It eventually became clear that 5 and more dimensions are very different from 4 and fewer. Topological 4-manifolds behave like high-dimensional manifolds in some ways, but 3-manifolds and smooth (equivalently, PL) 4-manifolds are quite different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29139")[#strong[#text("285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("[…] original approach to finite time extinction of the third homotopy group (Theorem 1 from the previous lecture), which, as previously discussed, can be combined with the finite time extinction of the second […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-29232")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("[…] 2 and are also supercritical. Thus the various bounds we have on these quantities from Lectures 4, 5, 6 do not directly tell us anything about asymptotic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-93546")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2011")])]

#text("[…] finite time extinction for Ricci flows, also work for Ricci flows with surgery, as discussed for in Lecture 5 and Lecture 6. Even if the manifold is not irreducible, one can show that there are only finitely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/#comment-272053")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("hi, Professor Tao, the Remark (2), third line: the compact manifold in your context means closed manifold (without boundary), right?")
]
