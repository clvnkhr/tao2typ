// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/
// Converted to Typst by tao2typ: "2026-10-14T15:20:51.170634+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Infinite partial sumsets in the primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Infinite partial sumsets in the primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 January 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/")[#text("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.ma.huji.ac.il/~tamarz/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2301.10303")[#text("Infinite partial sumsets in the primes")]#text("“. This is a short paper inspired by a ")#link("https://arxiv.org/abs/2206.12377")[#text("recent result of Kra, Moreira, Richter, and Robertson")]#text(" (discussed for instance in ")#link("https://www.quantamagazine.org/infinite-patterns-appear-in-numbers-described-as-moving-systems-20221205/")[#text("this Quanta article from last December")]#text(") showing that for any set ")#mi("{A}")#text(" of natural numbers of positive upper density, there exists a sequence ")#mi("{b_1 < b_2 < b_3 < \\dots}")#text(" of natural numbers and a shift ")#mi("{t}")#text(" such that ")#mi("{b_i + b_j + t \\in A}")#text(" for all ")#mi("{i<j}")#text(" this answers a question of Erdős). In view of the “")#link("https://terrytao.wordpress.com/tag/transference-principle/")[#text("transference principle")]#text("“, it is then plausible to ask whether the same result holds if ")#mi("{A}")#text(" is replaced by the primes. We can show the following results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]

#list(
[#text("(i) If the ")#link("https://en.wikipedia.org/wiki/Twin_prime#First_Hardy%E2%80%93Littlewood_conjecture")[#text("Hardy-Littlewood prime tuples conjecture")]#text(" (or the weaker ")#link("https://en.wikipedia.org/wiki/Dickson%27s_conjecture")[#text("conjecture of Dickson")]#text(") is true, then there exists an increasing sequence ")#mi("{b_1 < b_2 < b_3 < \\dots}")#text(" of primes such that ")#mi("{b_i + b_j + 1}")#text(" is prime for all ")#mi("{i < j}")#text(".")],
[#text("(ii) Unconditionally, there exist increasing sequences ")#mi("{a_1 < a_2 < \\dots}")#text(" and ")#mi("{b_1 < b_2 < \\dots}")#text(" of natural numbers such that ")#mi("{a_i + b_j}")#text(" is prime for all ")#mi("{i<j}")#text(".")],
[#text("(iii) These conclusions fail if “prime” is replaced by “positive (relative) density subset of the primes” (even if the density is equal to 1).")]
)
]

#text("We remark that it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1203292")[#text("by Balog")]#text(" that there (unconditionally) exist arbitrarily long but ")#emph[#text("finite")]#text(" sequences ")#mi("{b_1 < \\dots < b_k}")#text(" of primes such that ")#mi("{b_i + b_j + 1}")#text(" is prime for all ")#mi("{i < j \\leq k}")#text(". (This result can also be recovered from ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2680398")[#text("the later results")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877066")[#text("of Ben Green")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2950773")[#text("myself, and Tamar Ziegler")]#text(".) Also, it had previously ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1091350")[#text("been shown by Granville")]#text(" that on the Hardy-Littlewood prime tuples conjecture, there existed increasing sequences ")#mi("{a_1 < a_2 < \\dots}")#text(" and ")#mi("{b_1 < b_2 < \\dots}")#text(" of natural numbers such that ")#mi("{a_i+b_j}")#text(" is prime for all ")#mi("{i,j}")#text(".")

#text("The conclusion of (i) is stronger than that of (ii) (which is of course consistent with the former being conditional and the latter unconditional). The conclusion (ii) also implies the well-known ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3272929")[#text("theorem of Maynard")]#text(" that for any given ")#mi("{k}")#text(", there exist infinitely many ")#mi("{k}")#text("-tuples of primes of bounded diameter, and indeed our proof of (ii) uses the same “Maynard sieve” that powers the proof of that theorem (though we use a formulation of that sieve closer to that in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this blog post of mine")]#text("). Indeed, the failure of (iii) basically arises from the failure of Maynard’s theorem for dense subsets of primes, simply by removing those clusters of primes that are unusually closely spaced.")

#text("Our proof of (i) was initially inspired by the topological dynamics methods used by Kra, Moreira, Richter, and Robertson, but we managed to condense it to a purely elementary argument (taking up only half a page) that makes no reference to topological dynamics and builds up the sequence ")#mi("{b_1 < b_2 < \\dots}")#text(" recursively by repeated application of the prime tuples conjecture.")

#text("The proof of (ii) takes up the majority of the paper. It is easiest to phrase the argument in terms of “prime-producing tuples” – tuples ")#mi("{(h_1,\\dots,h_k)}")#text(" for which there are infinitely many ")#mi("{n}")#text(" with ")#mi("{n+h_1,\\dots,n+h_k}")#text(" all prime. Maynard’s theorem is equivalent to the existence of arbitrarily long prime-producing tuples; our theorem is equivalent to the stronger assertion that there exist an infinite sequence ")#mi("{h_1 < h_2 < \\dots}")#text(" such that every initial segment ")#mi("{(h_1,\\dots,h_k)}")#text(" is prime-producing. The main new tool for achieving this is the following cute measure-theoretic ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=809951")[#text("lemma of Bergelson")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Bergelson intersectivity lemma)")]#text(" Let ")#mi("{E_1,E_2,\\dots}")#text(" be subsets of a probability space ")#mi("{(X,\\mu)}")#text(" of measure uniformly bounded away from zero, thus ")#mi("{\\inf_i \\mu(E_i) > 0}")#text(". Then there exists a subsequence ")#mi("{E_{i_1}, E_{i_2}, \\dots}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu(E_{i_1} \\cap \\dots \\cap E_{i_k} ) > 0")]]

#text("for all ")#mi("{k}")#text(".")
]

#text("This lemma has a short proof, though not an entirely obvious one. Firstly, by deleting a null set from ")#mi("{X}")#text(", one can assume that all finite intersections ")#mi("{E_{i_1} \\cap \\dots \\cap E_{i_k}}")#text(" are either positive measure or empty. Secondly, a routine application of Fatou’s lemma shows that the maximal function ")#mi("{\\limsup_N \\frac{1}{N} \\sum_{i=1}^N 1_{E_i}}")#text(" has a positive integral, hence must be positive at some point ")#mi("{x_0}")#text(". Thus there is a subsequence ")#mi("{E_{i_1}, E_{i_2}, \\dots}")#text(" whose finite intersections all contain ")#mi("{x_0}")#text(", thus have positive measure as desired by the previous reduction.")

#text("It turns out that one cannot quite combine the standard Maynard sieve with the intersectivity lemma because the events ")#mi("{E_i}")#text(" that show up (which roughly correspond to the event that ")#mi("{n + h_i}")#text(" is prime for some random number ")#mi("{n}")#text(" (with a well-chosen probability distribution) and some shift ")#mi("{h_i}")#text(") have their probability going to zero, rather than being uniformly bounded from below. To get around this, we borrow an idea from a paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3556490")[#text("Banks, Freiberg, and Maynard")]#text(", and group the shifts ")#mi("{h_i}")#text(" into various clusters ")#mi("{h_{i,1},\\dots,h_{i,J_1}}")#text(", chosen in such a way that the probability that ")#emph[#text("at least one")]#text(" of ")#mi("{n+h_{i,1},\\dots,n+h_{i,J_1}}")#text(" is prime is bounded uniformly from below. One then applies the Bergelson intersectivity lemma to those events and uses many applications of the pigeonhole principle to conclude.")

#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("“this answers a question of >>ErdÅ‘s”, Erdős is misspelled")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("Considering theorem 1(iii), what is the strongest known necessary or sufficient conditions for the sequence ")#mi("b_1, b_2, ...")#text(" for the conclusions of theorem 1 ?")

#emph[#text("[Sorry, I am not able to interpret this question. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672711")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2023")])]

#text("I propose to take a side step or look at the integers in different ways. For that I propose to introduce all the primes less than the value of the integer and to look only at the vector of all the modulos.")

#text("the vector is decomposable in sum ->glodbach’s conjecture")#linebreak()#text(" and that must also, can be , simplify your approach")

#text("Sorry, I am not able to interpret this question.")

#text("remy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672715")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2023")])]

#text("Sorry, maybe too naive question, but can we give some explicit initial elements of any example for the two sequences?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673034")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("Unfortunately not (though we can of course normalize one of the elements to be anything we like by translating the other sequence in the opposite direction). Even the simpler problem of producing an explicit positive integer ")#mi("h")#text(" such that ")#mi("p,p+h")#text(" are prime for infinitely many ")#mi("p")#text(" is open; we know that there is at least one such ")#mi("h")#text(" with ")#mi("2 \\leq h \\leq 246")#text(", and every even integer should in fact have this property (de Polignac’s conjecture), but we cannot exhibit one explicitly. (Note that any difference ")#mi("a_j - a_i")#text(" of two elements of the first sequence will be of this form.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673068")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("Very interesting, thank you very much! Follow-up: Is there already a conjecture that for every $ latex n $ there is an infinite sequence of prime-")#mi("n")#text(" tupels (with an appropriate unique definition of prime-")#mi("n")#text(" tupel, generalizing twins, triples, …)?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672723")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2023")])]

#text("Does Theorem 1(ii) answer this question which I raised years ago on MathOverflow? ")#link("https://mathoverflow.net/questions/3347/is-the-set-of-primes-translation-finite")[#text("https://mathoverflow.net/questions/3347/is-the-set-of-primes-translation-finite")]

#text("(The original context was related to weak compactness / weak almost periodicity, see Defn 2.3 + Thm 2.4 + Lemma 2.5 of ")#link("https://arxiv.org/abs/0811.4432")[#text("https://arxiv.org/abs/0811.4432")]#text(" )")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("Yes, it seems that Theorem 1.5 of our paper is precisely the assertion that the primes are not translation-finite. I’ll add these references to the next revision of the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2023")])]

#text("It seems that the formulation of theorem 1(III) is not sufficiently clear (because the primes are “positive density subset of the primes” – so the replacement of the primes by themselves should not change the conclusions !)")

#emph[#text("[“positive density” clarified to “positive relative density” -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/049551e253bbfd2137ff0b7827ffc3f87b0dae93bbac47f4343a0e69ff33624b-efe3219ae27de107818d37f92b29b7707d8e45a3c2098ad6407bfa2bd8d46ee5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672742")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2023")])]

#text("Happy new year")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/838adb1b39b82355b34576d20a563b1bacdefaadc7ec3d2748ea8bdb923189b8-a82bf9d57a4e2cbec01fe0f2ed97b7cc5ad150542bb3ffbba2fababb2186ed67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Older but not wiser")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672779")[#strong[#text("Older but not wiser")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Been 19 years since I took grad real analysis. Forgot the arguments you posted. Yet this post is short and very understandable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Is it possible to generalize these results to sumsets in ")#mi("\\mathbb Z^d")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672804")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("as resoluções onde ele estiver presente…. com relação aos números primos, onde um Brasileiro afirma cientificamente que alguns números não são primos como todos(as) vem relatando de tempos passados, com uma simples PA(Progressão Aritmética), desvendei seus enigmas, onde afirmo cientificamente que não são primos e nem primos gêmeos: segue os números relatados a seguir: 2; 19; 41; 59; 61; 79; 101; 139; 179; 181; 199; 239; 241; 281; 359; 401; 419; 421; 439; 461; 479; 499; 521; 541; 599; 601; 619; 641; 659; 661; 701; 719; 739; 761; 821; 839; 859; 881; 919; 941; 1019; 1021; 1039; 1061; 1181; 1201; 1259; 1279; 1301; 1319; 1321; 1361; 1381; 1399; 1439; 1459; 1481; 1499; 1559; 1579; 1601; 1619; 1621; 1699; 1721; 1741; 1759; 1801; 1861; 1879; 1901; 1979; e mais alguns…… sendo assim “A Hipótese de Rielmann perde totalmente sua força” o autor Sr Sidney Silva.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673037")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("I would imagine that the tools used here (in particular, the Maynard sieve) would extend to other number fields, for instance establishing an analogous result for the Gaussian primes, but I have not checked all the details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AF")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-672798")[#strong[#text("AF")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Of the conjectures of Dickson and Hardy–Littlewood, neither is stronger than the other, because while Hardy and Littlewood do give an asymptotic formula, Dickson considers general linear functions (where the leading coefficient, ie. the step size is allowed to vary).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673124")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2023")])]

#text("In page 3, the fifth line of the proof of Prop2.1")#linebreak()#text(" j>1 will be j>i.")

#text("I think the question of how small the width h_{k}-h_{1} of the prime producing k-tuple in Theorem 1.5 can be is one of the essential questions.")#linebreak()#text(" Have you considered this?")

#emph[#text("[Thanks, this typo will be corrected in a future revision of the ms. The most recent update of the paper now contains some discussion of growth rates; see Remark 3.3. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673239")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")])]

#text("Please Prof creareate a YouTube channel and you will get more than one billion subscribers please")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#text("It will result in anger from other math agencies that have benefited from having his talk on their channel on Youtube. It’s not advised.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/401c3ec4a16f77fa272f1e26b6cd98647fea4cb0fca61454de7fe069116f9d68-bb1fbd4a0e0194e85477bb54a2a6e131b475ca01190938db85d00fcebc8a1fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673240")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")])]

#text("Prof share more if you make a video will be much clearer but if you have not time post more i am very huge fan of MATH)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673701")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2023")])]

#text("Some calculations involving prime numbers ")#link("https://www.researchgate.net/publication/367227821_Certaines-des-conseuquenceus-suivantes")[#text("https://www.researchgate.net/publication/367227821_Certaines-des-conseuquenceus-suivantes")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7b82463fa6c7d722e1a682c1b4b1724a726eb9081f2231c32306dcfb51ea43a-5180e12b25a112d655fea8aaaffb2b6ac3ed714cd2d6be174aa31908b67914f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sidney Silva Carnavale")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677825")[#strong[#text("Sidney Silva Carnavale")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2023")])]

#text("Prezados nobres amigos, com meu respeito a todos(as) aqui presente, interessantes esses relatos, porém não tem fundamento e conteúdo para tal afirmação, muita teoria de tempos passados e ainda não me deparei com um argumento mais plausível, todos(as) usam uma variável, uma integral, log, enfim relatam fatos de pensadores de tempos passados; continuo afirmando com total veracidade que todos os números que citei anteriormente não são primos, prove que minha tese esta errada. Sr Sidney Silva.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c54d746ab51b8b34b662a6117b56740381b55228d871e8f5a8d17bc37516d84-d8092cee56a31d453c3ccde7da460fac0663ff194592e9b55337194d72bc52df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rhmn")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673711")[#strong[#text("Rhmn")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2023")])]

#text("I saw your question on MO whose answer by Joel sharpens your result on uncountability of X! Can’t we simply argue by saying that X is an uncountable compact subspace of Cantor space so it is of size continuum?")

#emph[#text("[Yes, this also works, though Joel’s argument does not require the knowledge that X is compact. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f95e44a4e83f78fc985b5316a0e6b6929ae49ff3cba32265f225224903955fd-08f8cec0a316f47c416297536fe8c05fee8b43c7da0a7c57d2a7a5cb5462dd90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673754")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#text("Happy Feb 12")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6da1622eb91a9361373f5961823ae1452fa41980213f6539052e3c6b10bbeee-25665af8affa9d35267b3464aefe4cc46ca981af6d348a0d37fccfb54adeb5cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wangwei")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673816")[#strong[#text("wangwei")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2023")])]

#text("Proof of Four color theorem")#linebreak()#text(" Suppose there is a map that can only be colored in five colors. Remove a country. If it can only be colored in five colors after removal, then remove the country. Otherwise, leave it. Each country will perform and operations in turn until all countries have completed one round, and then the next round will perform the same operations until no country has been removed in one round. In this way, the new map formed in the remaining countries can only be colored in five colors, and if any country is removed, it can be colored in four colors.")#linebreak()#text(" In this way, the neighboring countries of each country must contain four colors, because if a country contains only three colors, it can be colored with four colors after removing the country, then it can also be colored with four colors without removing the country (new map), which is inconsistent with the new map.")#linebreak()#text(" If the neighboring countries of each country contain four colors, the new map should only be colored with five colors after removing one country, which is contradictory, so the assumption is not tenable. There is no map that can only be colored with five colors.")#linebreak()#text(" Is my proof correct？")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-673858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2023")])]

#text("It is not clear why your proof can’t be applied to another numbers (e.g. 3 0r 5) than 4 (in other words. it is not clear from your proof what is special about 4)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2023")])]

#text("4 is very special in analytic number theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674418")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2023")])]

#text("Prezado nobre amigo, interessante sua pergunta, pois com uma simples PA(Progressão Aritmética) padronizei duas fórmulas: vejamos como ficaria pegar um número primo e dividir ou seja usar a fatoração de números primos para ser fatorado do menor para o maior e do maior para o menor, assim será considerado um número primo:")#linebreak()#text(" esse número é primo 12280616105497 e somente pode ser dividido e fatorado somente pelos números 1867; 1871; 1873; 1877 que também são primos vejamos como fica minha tese:")#linebreak()#text(" do menor para o maior:")#linebreak()#text(" 12280616105497 1867")#linebreak()#text(" 6577726891 1871")#linebreak()#text(" 3515621 1873")#linebreak()#text(" 1877 1877")#linebreak()#text(" 1")#linebreak()#text(" Agora irei fatorar com números primos do maior para o menor:")#linebreak()#text(" 12280616105487 1877")#linebreak()#text(" 6542683061 1873")#linebreak()#text(" 3493157 1871")#linebreak()#text(" 1867 1867")#linebreak()#text(" 1")#linebreak()#text(" Provando minha tese que o numeral 2, 19 e outros já citados acima não são primos, e os primos gêmeos não existe. lendo este número primo teremos; (Doze Trilhões, Duzentos e Oitenta Bilhões, Seiscentos e Dezesseis Milhões, Cento e Cinco Mil Quatrocentos e Oitenta e Sete.), com esta simples fórmula cheguei na casa dos 92 Nonilhões, e é Finito…. Sr Sidney Silva.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674448")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("12280616105497 = 3515621*3493157")

#text("is not prime")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674481")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("Sim, são primos, agora se tiver usando o numeral dois e muitos outros que mencionei que não são primos pode ser que sua afirmação esteja correta, porém todos que fatorei são primos tanto o de 14 dígitos e seus resultados são primos, prova cientifica minha tese esta correta. Sr Sidney Silva")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674526")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("I specify that there is not a prime number at each")#linebreak()#text(" different primorielle")

#text("an example with a series of twin primes")

#text("m=11590571 = 11590571")#linebreak()#text(" mm=m+2 = 11590573")#linebreak()#text(" m%(2*3*5*7*11*13*17) = 359351= 43 * 61 * 137")#linebreak()#text(" mm%(2*3*5*7*11*13*17) = 359353")#linebreak()#text(" m%(2*3*5*7*11*13) = 29021")#linebreak()#text(" mm%(2*3*5*7*11*13) = 29023")#linebreak()#text(" m%(2*3*5*7*11) = 1301")#linebreak()#text(" mm%(2*3*5*7*11) = 1303")#linebreak()#text(" m%(2*3*5*7) = 41")#linebreak()#text(" mm%(2*3*5*7) = 43")#linebreak()#text(" m%(2*3) = 5")#linebreak()#text(" mm%(2*3) = 1->3")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674157")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")])]

#text("Know primes number (included in sequences)")

#mi("\\forall 2^{2a+1} - 1 = 42b + (31;43) \\longrightarrow (2a + 1 = p)")

#text("Hence the Mersenne primes are verified in the form:")

#mi("2^{p} - 1 =p_{n}")

#text("if")

#mi("2^{p_{n}} = 42b + (31;43)")#text(".")

#mi("\\forall p \\in [(30a + p) or (42b + p_{1})]")

#text("With ")#mi("p = (11;17;23;39)")#linebreak()#text(" ")#mi("p_{1} = (13;19;31;37;43)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674265")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2023")])]

#text("Neste enunciado o 19 não é primo, então cai por terra esta hipótese!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674453")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("your conjecture is true because,for me")

#text("(largePrimeNum)mod(2*3*5*7*11*…101)=PrimeNum")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11*…97)=PrimeNum")#linebreak()#text(" …")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11*…89)=PrimeNum")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11*…83)=PrimeNum")#linebreak()#text(" …")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11*…47)=PrimeNum")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11*…43)=PrimeNum")#linebreak()#text(" …")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7*11)=PrimeNum")#linebreak()#text(" (largePrimeNum)mod(2*3*5*7)=PrimeNum")

#text("for the demonstration it is necessary to write the prime numbers with a primorielle base")

#text("Attached is a file with the first 1000 prime numbers in primorielle base")

#link("https://www.cjoint.com/doc/23_02/MBvp6pGpfsJ_sortie.txt")[#text("https://www.cjoint.com/doc/23_02/MBvp6pGpfsJ_sortie.txt")]

#text("so")#linebreak()#text(" largePrimeNum=pq+r=primorielle n+prime")#linebreak()#text(" (largePrimeNum)mod(primorielle )=prime")

#text("it is a consequence of the proposal of the available demonstrations")

#link("https://vixra.org/pdf/2206.0068v1.pdf")[#text("Click to access 2206.0068v1.pdf")]

#text("and don’t repeat it but chatGPT doesn’t know how to make a small prime number from a large prime number")

#text("thank you for your attention")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674527")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("I specify that there is not a prime number at each")#linebreak()#text(" different primorielle")

#text("an example with a series of twin primes")

#text("m=11590571 = 11590571")#linebreak()#text(" mm=m+2 = 11590573")#linebreak()#text(" m%(2*3*5*7*11*13*17) = 359351= 43 * 61 * 137")#linebreak()#text(" mm%(2*3*5*7*11*13*17) = 359353")#linebreak()#text(" m%(2*3*5*7*11*13) = 29021")#linebreak()#text(" mm%(2*3*5*7*11*13) = 29023")#linebreak()#text(" m%(2*3*5*7*11) = 1301")#linebreak()#text(" mm%(2*3*5*7*11) = 1303")#linebreak()#text(" m%(2*3*5*7) = 41")#linebreak()#text(" mm%(2*3*5*7) = 43")#linebreak()#text(" m%(2*3) = 5")#linebreak()#text(" mm%(2*3) = 1->3")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674552")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("Prezado Srs(as), prove que esses números que mencionei pode ser encontrado números gêmeos, não vão encontrar, pois dentro da lista que me foi passado, aparece o 2, 19,41, 59, 61, 79 e muitos outros que citei não ser primos, enfim esses números não são primos, gostaria que todos(as) revesse seus conceitos, pois existe argumento dentro de um embasamento que esses números não são primos, os que citei acima em epigrafe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674553")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("Nobre amigo, ficou vago sua explanação, prove sem esses números que apresentei que não são primos para ver se seu resultado esta correto? tenta olhar de outro ângulo minhas teorias… pois minhas teses estão de acordo com a revista científicas Sidney Silva.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674764")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2023")])]

#text("I present a prime number generator based on an arithmetic progression (a sum) and I justify this progression with a demonstration proposal.")#linebreak()#text(" I do not change the rules of the game")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeb4b719ca739707f08fa774a58278e3f236a57a4b0eef32a2894fefcd41115e-883776a57fa1ebcbc3fb2ff6551fa00aefa38e3c65a9ce1bfe7cff0696a3f2e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sr Sidney Silva")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674943")[#strong[#text("Sr Sidney Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2023")])]

#text("Prezado nobre amigo interessante sua explanação com meu respeito a todos(as) aqui presente neste singelo canal, tenho um conceito sobre o que é números primos:")#linebreak()#text(" “Pra ser um número primo terá que dividir somente pelo número primo, sendo do menor para o maior, e do maior para o menor, só assim poderá ser um número primo exato e finito” essa Lei é aplicada no momento em que for feita a Fatoração de números primos”…. ao contrário que todos(as) vem relatando em tempos passados, usando uma teoria já obsoleta para os tempos atuais, Sr Sidney Silva. Porém não é possível esta sequência, pois tem alguns números que não são primos e os primos gêmeos não existe,")#linebreak()#text(" Estes números que irei apresentar não são primos!!")#linebreak()#text(" 2; 19; 41; 59; 61; 79; 101; 139; 179; 181; 199; 239; 241; 281; 359; 401; 419; 421; 439; 461; 479; 499; 521; 541; 599; 601; 619; 641; 659; 661; 701; 719; 739; 761; 821; 839; 859; 881; 919; 941; 1019; 1021; 1039; 1061; 1181; 1201; 1259; 1279; 1301; 1319; 1321; 1361; 1381; 1399; 1439; 1459; 1481; 1499; 1559; 1579; 1601; 1619; 1621; 1699; 1721; 1741; 1759; 1801; 1861; 1879; 1901; 1979; Prove que esta Tese esta errada")#linebreak()#text(" cientificamente… Sr Sidney Silva.")#linebreak()#text(" Irei relatar uma prova de que minha Tese esta correta, vejamos como fica:")#linebreak()#text(" pois com uma simples PA(Progressão Aritmética) padronizei duas fórmulas: vejamos como ficaria pegar um número primo e dividir ou seja usar a fatoração de números primos para ser fatorado do menor para o maior e do maior para o menor, assim será considerado um número primo:")#linebreak()#text(" esse número é primo 12280616105497 e somente pode ser dividido e fatorado somente pelos números 1867; 1871; 1873; 1877 que também são primos vejamos como fica minha tese:")#linebreak()#text(" do menor para o maior:")#linebreak()#text(" 12280616105497 1867")#linebreak()#text(" 6577726891 1871")#linebreak()#text(" 3515621 1873")#linebreak()#text(" 1877 1877")#linebreak()#text(" 1")#linebreak()#text(" Agora irei fatorar com números primos do maior para o menor:")#linebreak()#text(" 12280616105487 1877")#linebreak()#text(" 6542683061 1873")#linebreak()#text(" 3493157 1871")#linebreak()#text(" 1867 1867")#linebreak()#text(" 1")#linebreak()#text(" Provando minha tese que o numeral 2, 19 e outros já citados acima não são primos, e os primos gêmeos não existe. lendo este número primo teremos; (Doze Trilhões, Duzentos e Oitenta Bilhões, Seiscentos e Dezesseis Milhões, Cento e Cinco Mil Quatrocentos e Oitenta e Sete.), com esta simples fórmula cheguei na casa dos 92 Nonilhões, e é Finito…. Sr Sidney Silva. dentro deste valor encontrado multipliquei 1867*1871*1873*1877= 12280616105497 todos são números primos, irei citar outro exemplo mais simples: Sidney Silva")#linebreak()#text(" o primeiro numero primo seria o 3 vejamos como ficaria minha tese e teoria:")#linebreak()#text(" 3*5*7*11*13*17= 255255 vejamos como fica pela minha definição de números primos:")#linebreak()#text(" Do menor para o maior:")#linebreak()#text(" 255255 3")#linebreak()#text(" 85085 5")#linebreak()#text(" 17017 7")#linebreak()#text(" 2431 11")#linebreak()#text(" 221 13")#linebreak()#text(" 17 17")#linebreak()#text(" 1")#linebreak()#text(" Agora do maior para o menor:")#linebreak()#text(" 255255 17")#linebreak()#text(" 15015 13")#linebreak()#text(" 1155 11")#linebreak()#text(" 105 7")#linebreak()#text(" 15 5")#linebreak()#text(" 3 3")#linebreak()#text(" 1")#linebreak()#text(" Prova que os valores fatorados somente com números primos; será considerado números primos, pois foi dividido somente com os números primos existente dentro da minha tese e teoria…porém haverá um único numero primo que será dividido por ele mesmo e o resultado será 1, classificando como os verdadeiros números primos………esse é meu conceito e a definição para os números primos…….meu cordial abraço Sr Sidney Silva.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-675029")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2023")])]

#text("não concordaremos, lamento,a direcção do factoring não altera o resultado do factoring")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3272bd1b160121fa2aebe3a98c6abc10327c23b209c2767f52b3eb8d9cc427-661816d5b0ecd158ba320c6763edc5581b6bd5fa514cdaaded3e5c7cc7aa4740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of remy")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-674529")[#strong[#text("remy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("Attached is a file with twin primes that shares some of their writing")

#link("https://www.cjoint.com/doc/23_02/MBykOnigb1J_sortie.txt")[#text("https://www.cjoint.com/doc/23_02/MBykOnigb1J_sortie.txt")]

#text("I recommend using notepad++ there is no automatic line wrap")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ace24530dc18794ab97a5087544ea62bf0802be977ca9751919e1efb834763cc-85c7cd83e566f31541ee6796fe317cddb6acf130e83e5b5e956d1daaa1bd4c27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Prof. Zhexuan Tao: In recent years, I have repeatedly read your “Every Odd Number Greater Than 1 Is the Sum of Five Prime Numbers at Most” issued on February 1, 2012, “Heuristic Limitation of the Circle Method” issued on May 20, 2012, “Parity-Check Problem Obstacle for Binary Goldbach Conjecture with Bounded Errors” issued on July 9, 2014, “Heath-Brown’s Theorem on Twins of Prime Numbers and Siegel Zero” issued on August 26, 2015, and “the Principle of Inclusion and Exclusion for Commuting Predictions” issued on February 23, 2021, and other blog posts and related comments.")#linebreak()#text(" Researchers have been going around in circles regarding the proof of “Even Goldbach Conjecture and “Twin Prime Conjecture” based on the parity-check problem, the Möbius pseudo-randomness principle, the Siegel Zero and the screening theory, the Hall principle of inclusion and exclusion, and other obstacles. Thus, we should think about how to move our thought out of the loops made by these obstacles.")#linebreak()#text(" I think that the two major questions of “Even Goldbach’s Conjecture” and “Twin Prime Conjecture” are the defective problems of the fundamental theory of sets in essence . Thus, I would like to propose the following three propositions to have a deeper discussion with you.")#linebreak()#text(" Proposition 1: An integer set consisting of all integers greater than 1 and less than or equal to an integer is equivalent to the union of the prime factor sets less than or equal to the integer. Each integer containing a prime factor is an element of the set of prime factors, and each set of prime factors is a subset of the set of integers.")#linebreak()#text(" Each in the union sets of several subsets contains a unique personality and several different commonalities. The unique individuality of each union element makes the element exist independently in the union set. Each commonality is a property of each subset of the union set combined with the commonality of each other element. Each subset of the union set contains a unique property, which is the commonality of each union element. All elements that contain this commonality belong to elements of that subset. The number of commonalities in each union element in a union set is the number of times that the element intersects with each subset, or the number of the elements belonging to each subset in the union set Therefore, the number of commonalities contained in each element is also considered as a commonality. The elements with the same number of commonalities form a set of the number of the same commonalities.")#linebreak()#text(" As a result, a union set of several subsets can form two set forms. One is a union set consisting of union elements, and the other is a repeated set consisting of intersecting elements.")#linebreak()#text(" “The union set of sets of prime factors less than or equal to an integer” indicates that each union element contains more than one prime factor less than or equal to that integer. All elements that contain a prime factor form the set of that prime factor. Each set of prime factors is a subset of that union set. Thus, all elements containing m prime factors form a subset of the set containing m prime factors. “The principle of Inclusion and Exclusion” can be used to find the cardinal number of a set of elements containing more than m commonalities or the cardinal number of a set of elements containing only m commonalities.")#linebreak()#text(" The relevant symbols of relevant elements and sets that indicate the number of commonalities are added, and the symbols are used to describe the formula as follows:")

#text("To be continued······")

#text("Chinese Xulianke")#linebreak()#text(" ")#link("mailto:xulianke@yeah.net")[#text("xulianke@yeah.net")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ace24530dc18794ab97a5087544ea62bf0802be977ca9751919e1efb834763cc-85c7cd83e566f31541ee6796fe317cddb6acf130e83e5b5e956d1daaa1bd4c27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Ⅰ、")#linebreak()#text(" N is the set of natural numbers,")#mi("d\\in\\mathbf{N}")#text(" , ")#mi("\\mathbf{A} =\\{a \\vert 2 \\leq a \\leq d and a \\in\\mathbf{N}\\}")#text(" , ")#mi("\\{p_n\\}")#text(" is the n smallest prime numbers, and ")#mi("p_n \\leq d \\leq p_n^{2} \\cdot a _{(m)}")#text(" is an element with m commonalities in ")#mi("\\mathbf{A}")#text(" ; ")#mi("\\mathbf{P_i} =\\{a \\mid p_i \\mid a and  \\forall p_i\\leq d,1\\leq i \\leq n\\}")#text(" ; ")#mi("\\quad \\bigcap_{i=i_1}^{m} \\mathbf{P_i}=\\mathbf{P_{i_1}}\\cap\\mathbf{P_{i_2}}\\cap\\ldots\\mathbf{P_{i_m}}")#text(" , ")#mi("1\\leq i_1 \\textless i_2 \\textless \\ldots i_m \\leq n")#text(" ; ")#mi("\\mathbf{A}")#text(" is a universal set, and ")#mi("\\mathbf{A}")#text("’ is a complementary set of ")#mi("\\mathbf{A}")#text(" ; ")#mi("\\mathbf{P}=\\mathbf{P_1} \\cup \\mathbf{P_2} \\cup \\ldots \\mathbf{P_n}")#text(" ; Set ")#mi("\\prod_{j=j_i}^{m}p_j=p_{j_1} p_{j_1} \\ldots p_{j_m}")#text(" ,")#mi("1\\leq j_1 \\textless j_2 \\textless \\ldots j_m \\leq n")#text(".")

#text("ⅰ、")#linebreak()#text(" ")#mi("\\mathbf{A}_{(H_m)}=\\{a \\vert a \\in\\forall \\bigcap_{i=i_1}^{m}\\mathbf{P_i}")#text(" , ")#mi("1 \\leq m \\leq n\\}")#text(" , ")#mi("\\Rightarrow \\mathbf{A_{(H_1)}} =\\{a \\vert a \\in \\forall  \\mathbf{P_i} \\}=\\quad \\bigcup_{i=1}^{n}\\mathbf{P_i} = \\mathbf{P}")#text(" , ")#mi("\\mathbf{A}_{(H_0)} =\\{a \\vert a \\in\\mathbf{A} \\}= \\mathbf{A}")#text(";")

#text("ⅱ、")#linebreak()#text(" ")#mi("\\mathbf{A}_{(h_m)} =\\{a \\vert a \\in\\forall \\bigcap_{i=i_1}^{m}\\mathbf{P_i}")#text(" and ")#mi("a\\notin\\forall\\bigcap_{i=i_1}^{m+1}\\mathbf{P_i}")#text(" , ")#mi("1\\leq m \\leq n\\}")#text(",")#mi("\\Rightarrow \\mathbf{A_{(h_1)}} =\\{a \\vert a \\in \\forall \\mathbf{P_i}")#text(" and ")#mi("a \\notin \\forall \\bigcap_{i=i_1}^{2}\\mathbf{P_i} \\}")#text(" , ")#mi("\\mathbf{A}_{(h_0)} =\\{a  \\vert a \\in  \\mathbf{A}")#text(" and ")#mi("a \\notin\\forall \\mathbf{P_i} \\}= \\mathbf{A^{\\prime}}")#text(".")

#text("ⅲ、")#linebreak()#text(" ")#mi("\\mathbf{A}_{(H_m)}")#text(" is divided into: ")#mi("\\pi =\\{ \\mathbf{A}_{(h_m)}")#text(" , ")#mi("\\mathbf{A}_{(h_{m+1})}")#text(" , ")#mi("\\ldots \\mathbf{A}_{(h_n)} \\}")#text(" , ")#tao-math("\\left|\\pi\\right|=n-m+1", block: false)#text(" ;")#linebreak()#text(" ")#tao-math("\\Rightarrow \\left|\\mathbf{A}_{(H_m)}\\right| = \\left|\\mathbf{A}_{(h_m)}\\right| + \\left|\\mathbf{A}_{(h_{m+1})}\\right| + \\ldots \\left|\\mathbf{A}_{(h_n)}\\right|", block: false)#text(".")

#text("ⅳ、")#linebreak()#text(" Based on “the Principle of Inclusion and Exclusion”")#linebreak()#text(" ")#tao-math("\\Rightarrow\\left|\\mathbf{A}_{(H_m)}\\right| = \\sum_{1\\leq{i_1}\\textless\\ldots{i_{m+j}}\\leq n}^{n-m+1} (-1)^j C_{m+j-1}^{m-1} \\sum_{0\\leq j\\leq {n-m}}^{C_n^{m+j}}\\left|\\bigcap_{i=i_1}^{m+j}\\mathbf{P_i}\\right|", block: false)#linebreak()#text(" ")#tao-math("=C_{m-1}^{m-1} \\sum_{1\\leq i_1\\textless\\ldots i_m\\leq n}^{C_n^m} \\left|\\bigcap_{i={i_1}}^m\\mathbf{P_i}\\right| - C_m^{m-1} \\sum_{1\\leq i_1\\textless\\ldots i_{m+1}\\leq n}^{C_n^{m+1}} \\left|\\bigcap_{i=i_1}^{m+1}\\mathbf{P_i}\\right| + \\ldots C_{n-1}^{m-1} \\sum_{1\\leq i_1\\textless\\ldots i_n\\leq n}^{C_n^n} \\left|\\bigcap_{i={i_1}}^n\\mathbf{P_i}\\right|", block: false)#text(".")#linebreak()#text(" from ")#tao-math("iii\\Rightarrow\\left|\\mathbf{A}_{(h_m)}\\right| = \\left|\\mathbf{A}_{(H_m)}\\right| - \\left|\\mathbf{A}_{(H_{m+1})}\\right| = \\sum_{1\\leq i_1\\textless\\ldots i_{m+j}\\leq n}^{n-m+1} (-1)^j C_{m+j}^m \\sum_{0\\leq j\\leq{n-m}}^{C_n^{m+j}} \\left|\\bigcap_{i=i_1}^{m+j}\\mathbf{P_i}\\right|", block: false)

#text("ⅴ、")#linebreak()#text(" By the “Principle of Inclusion and Exclusion”")#mi("\\Rightarrow")#text("the inverse formula is:")#tao-math("\\sum_{1\\leq i_1\\textless\\ldots i_m\\leq n}^{C_n^m} \\left|\\bigcap_{i={i_1}}^m\\mathbf{P_i}\\right| = C_m^m \\left|\\mathbf{A}_{(h_m)}\\right| + C_{m+1}^m \\left|\\mathbf{A}_{(h_{m+1})}\\right| + \\ldots C_n^m \\left|\\mathbf{A}_{(h_n)}\\right|", block: false)#text(".")#linebreak()#text(" By “the Inverse Formula of the Principle of Inclusion and Exclusion” ")#mi("\\Rightarrow Repeated set  \\mathbf{A_0}")#text(" is:")#linebreak()#text(" ")#tao-math("\\mathbf{A_0} =\\{   \\sum_{1\\leq i_1\\textless\\ldots i_m\\leq n}^{C_n^m} \\left|\\bigcap_{i={i_1}}^m\\mathbf{P_i}\\right| \\cdot a _{(m)}", block: false)#text(" , ")#tao-math("\\sum_{1\\leq i_1\\textless\\ldots i_{m+1}\\leq n}^{C_n^m} \\left|\\bigcap_{i={i_1}}^{m+1}\\mathbf{P_i}\\right| \\cdot a _{(m+1)}", block: false)#text(" , ")#tao-math("\\ldots \\sum_{1\\leq i_1\\textless\\ldots i_n\\leq n}^{C_n^n} \\left|\\bigcap_{i={i_1}}^n\\mathbf{P_i}\\right| \\cdot a _{(n)} \\}", block: false)#text("。")#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677763")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "\\left(a_{(m)}\\in \\mathbf{A}_{(h_m)}")]#text(" ,")#mi("a_{(m+1)}\\in \\mathbf{A}_{(h_m+1)}")#text(" , ")#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677763")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "\\ldots a_{(n)}\\in \\mathbf{A}_{(h_m)}\\right)")]#text(".")

#text("ⅵ、")#linebreak()#text(" By the nature of the set ")#tao-math("\\Rightarrow \\left|\\mathbf{A}_{(h_0)}\\right| = \\left|\\mathbf{A}\\right| - \\left|\\mathbf{A}_{(H_1)}\\right| =b \\frac{\\quad \\prod_{i=1}^n\\left(p_i-1\\right)_i}{\\quad \\prod_{i=1}^np_i} -1", block: false)#text(".")

#text("To be continued······")

#text("Chinese Xulianke")#linebreak()#text(" ")#link("mailto:xulianke@yeah.net")[#text("xulianke@yeah.net")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ace24530dc18794ab97a5087544ea62bf0802be977ca9751919e1efb834763cc-85c7cd83e566f31541ee6796fe317cddb6acf130e83e5b5e956d1daaa1bd4c27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Ⅱ、Related Conjecture:")

#text("ⅰ、Obviously, each element in ")#mi("\\mathbf{A}_{(H_m)}")#text(" contains more than m prime factors. Each element in ")#mi("\\mathbf{A}_{(h_m)}")#text(" contains only m prime factors. Each element in , ")#mi("\\mathbf{A}_{(h_0)}")#text(" does not contain a prime factor in ")#mi("\\{ \\mathbf{P_n} \\}")#text(" and can only be a prime number. When d and n increase infinitely, the number of prime factors increase infinitely.")

#text("ⅱ、")#linebreak()#text(" ")#mi("\\Rightarrow a_{i_1} \\in \\mathbf{P}_j")#text(" and. ")#mi("a_{i_2} \\in \\mathbf{P}_j \\exists a_{i_1} \\equiv a_{i_2} \\left(mod \\quad p_j\\right)")#text(" ; ")#mi("a_{i_1}\\in \\mathbf{P}_{j_1} \\cap \\mathbf{P}_{j_2}")#text(" and.")#mi("a_{i_2} \\in \\mathbf{P}_{j_1} \\cap \\mathbf{P}_{j_2} \\exists a_{i_1} \\equiv a_{i_2}")#text(" ")#mi("\\left(mod \\quad p_{j_1}p_{j_2}\\right)")#text(" ; ")#mi("\\ldots a_{i_1} \\in \\bigcap_{j={j_1}}^m\\mathbf{P}_j")#text(" and. ")#mi("a_{i_2} \\in \\bigcap_{j={j_1}}^m\\mathbf{P}_j \\exists a_{i_1} \\equiv a_{i_2} \\left(mod \\quad \\prod_{j={j_1}}^mp_j\\right)")#text(".")#linebreak()#text(" Thus, the operation of ")#tao-math("\\left|\\mathbf{A}_{(H_m)}\\right|", block: false)#text(" has randomness. ")#tao-math("\\left|\\mathbf{A}_{(h_0)}\\right|", block: false)#text(" also has randomness.")

#text("ⅲ、")#linebreak()#text(" ")#mi("p_1 =2")#text(" , ")#mi("\\frac{p_1-1}{p_1} = \\frac{1}{2}")#text(" ,")#mi("p_2=3")#text(", ")#mi("\\frac{p_2-1}{p_2} = \\frac{2}{3}")#text(" ; ")#mi("\\Rightarrow \\frac{\\left(p_1-1\\right)\\left(p_2-1\\right)}{p_1p_2} = \\frac{1}{3}")#text(".")#linebreak()#text(" ")#mi("p_i -1\\textgreater  p_{i-1}")#text(",")#mi("3 \\leq  i \\leq  n")#text(" . ")#mi("\\Rightarrow  \\frac{p_i-1}{p_{i-1}} \\textgreater 1")#text(" , ")#mi("\\Rightarrow \\frac{\\prod_{i=1}^n{(p_1-1)_i}}{\\prod_{i=1}^n{p_i}} \\textgreater  \\frac{1}{p_n}")#text(".")

#text("ⅳ、")#linebreak()#text(" The definite existence of one prime number between d and 2d has been proved; ")#mi("\\Rightarrow")#text(" it is conjectured that there must be n prime numbers between d and nd ")#mi("\\left(n\\leq d\\right)")#text("; and the interval of prime numbers, the function of the nth prime number, and other prime number problems can be derived from the formula of“")#mi("\\frac{\\prod_{i=1}^n{(p_1-1)_i}}{\\prod_{i=1}^n{p_i}}")#text("”.")

#text("V.")#linebreak()#text(" Is the randomness of “")#tao-math("\\left|\\mathbf{A}_{(h_0)}\\right|", block: false)#text("” and “")#mi("\\frac{\\prod_{i=1}^n{(p_1-1)_i}}{\\prod_{i=1}^n{p_i}} \\textgreater  \\frac{1}{p_n}")#text("”related to “Siegel Zero”? Can the location of the zero bound be derived from “")#mi("\\frac{\\prod_{i=1}^n{(p_1-1)_i}}{\\prod_{i=1}^n{p_i}}")#text("”? I think there is a certain causal relationship between them. Since the process of proving the above-mentioned relevant formulas and principles above is too long, it cannot be listed in this article.")

#text("To be continued")

#text("Chinese Xulianke")#linebreak()#text(" ")#link("mailto:xulianke@yeah.net")[#text("xulianke@yeah.net")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Proposition 2: “The sum of two integers greater than 1 is equal to the set consisting of the sum of the same integer”is equivalent to“the intersection of the union of the prime factor sets less than the integer minus 2 and the set of itself is the set where the sum of the two addends of each intersection element is equal to the integer”, and is also equivalent to “one integer written as a set consisting of the sum of all two integers greater than 1”.")#linebreak()#text(" Obviously, if the integers in Proposition 2 are taken to be even numbers, it is the problem of“Even Goldbach’s Conjecture”.From Proposition 1, it is known that the “even Goldbach’s conjecture” is the intersection of union sets of two sets of prime factors less than the same even number, that is, the intersection of two identical union sets. In Proposition 1, “the Principle of Inclusion and Exclusion” can be applied to find the cardinal number of sets that contain m commonalities in any union set. In the intersection of two union sets, it is necessary to find the set consisting of the intersection of elements containing commonalities in one union set and elements containing commonalities in the other union set. This is equivalent to the form of “Goldbach’s conjecture” in which one addend contains prime factors and the other addend contains prime factors in the form of one even number written as the sum of two integers greater than 1. Obviously, there is a new principle that cannot be solved by “the Principle of Inclusion and Exclusion”, that is, “the correlation principle of finding the cardinal number of the intersection of two union sets”.")#linebreak()#text(" Each prime factor present in an even number is commonly present in both addends of each intersection element, while the same prime factor not present in an even number cannot be present in both addends of the same intersection element. Further, regarding each prime factor whose square number is smaller than the even number, there must be a term containing more than two identical prime factors, and each prime factor whose square number is greater than the even number has no repeated prime factors in each term.")#linebreak()#text(" Thus, it is necessary to divide the prime factors less than that even number into: prime factors that divide even numbers and prime factors that do not divide even numbers, as well as prime factors whose square number is smaller than an even number and do not divide evenly in an even number and prime factors whose square number is greater than an even number and do not divide evenly in an even number.")

#text("The new symbolic form is used to perform the formulaic description and operation derivation as follows:")

#text("To be continued········")

#text("Chinese Xulianke")#linebreak()#text(" xulianke")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2023/01/26/infinite-partial-sumsets-in-the-primes/#comment-677926")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2023")])]

#text("Dear Professor Terence Tao, why not prove Bunyakovsky conjecture to get 3 out of 4 problems of Landau. How does the sum of 2k primes equal to the sum of 2h primes apply to the prime number structure? And one more thing, n^2+1 is not provable by sums of three cubes.")
]
