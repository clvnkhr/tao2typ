// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/
// Converted to Typst by tao2typ: "2026-10-14T15:17:23.925588+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity of wave maps VII.  Control of delocalised or dispersed solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity of wave maps VII.  Control of delocalised or dispersed solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/")[#text("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" a draft version of the final paper in my “")#link("https://terrytao.wordpress.com/tag/project-heatwave/")[#text("heatwave")]#text("” project, “")#link("http://arxiv.org/abs/0908.0776")[#text("Global regularity of wave maps VII. Control of delocalised or dispersed solutions")]#text("“. This paper establishes the final ingredient needed to obtain global regularity and (uniform) scattering for wave maps into hyperbolic space, by showing that any sufficiently delocalised or dispersed wave map (an approximate superposition of two maps of lower energy that are widely separated in space, frequency, or time) can be controlled by wave maps of lesser energy.")

#text("This type of result is well understood for scalar semilinear equations, such as the nonlinear Schrodinger equation (NLS) or nonlinear wave equation (NLW). The main new difficulties here are that")

#list(
[#text("(a) the wave maps equation is an overdetermined system, rather than a scalar equation, rendering such basic operations as decomposing a scalar field into components, or superimposing those components to reassemble the solution, much more delicate and nonlinear;")],
[#text("(b) the wave maps equation is no longer semilinear (in the sense that it can be viewed as a perturbation of the free wave equation) unless a gauge transform is first performed, but the gauge is itself nonlinear and thus interacts in a complicated way with the decompositions and superpositions in (a);")],
[#text("(c) the function spaces required to control wave maps in two dimensions are extremely complicated and delicate compared to, say, the NLS theory (in which Strichartz spaces largely suffice), and the estimates are not as favourable. In particular, the “low-high” frequency interactions are non-negligible; the low frequency components of wave maps have a non-trivial “magnetic” effect on the high-frequency components. Furthermore, in contrast to the NLS and NLW settings, it takes substantial effort to show that the function spaces are “divisible”, which roughly means that a wave map only exhibits substantial nonlinear behaviour on a bounded number of time intervals and length scales.")]
)

#text("Juggling these three difficulties together led to an unusually large length for this paper (124 pages, and this is after taking some shortcuts, see below).")

#text("Last month, ")#link("http://arxiv.org/abs/0907.3148")[#text("Sterbenz")]#text(" ")#link("http://arxiv.org/abs/0906.3384")[#text("and Tataru managed")]#text(", by a slightly different argument, to also establish global regularity and (non-uniform) scattering for wave maps into compact targets (and thence also to hyperbolic space targets, by a lifting argument). Their argument is significantly shorter (a net length of about 100 pages, compared to about 300 pages for my heatwave project) as it relies on a clever shortcut. In my approach, I seek to control all components of the wave map at once, as well as the nonlinear interactions between those components, in order to show that a delocalised wave map can be controlled by wave maps of lesser energy. In contrast, Sterbenz and Tataru focus on just the finest scale at which nontrivial blowup behaviour occurs; it turns out that the small energy theory and finite speed of propagation, together with a regularising effect arising from the Morawetz estimate, are enough to show that this behaviour is controlled by harmonic maps, and so blowup cannot occur below the critical energy. This approach requires substantially less perturbation theory, and thus largely eliminates the need to develop a nonlinear theory of decomposition and superposition alluded to in (a) above (developing this theory, and meshing it with (b) and (c), occupies the bulk of the current paper). On the other hand, the approach in my papers provides more information on the solution, in particular providing certain spacetime “scattering” bounds on the solution that depend only on the energy, as opposed to a “non-uniform” scattering result in which the scattering norms are finite but potentially unbounded.")

#text("Nevertheless, my arguments are much more complicated (though I do feel that the machinery set up to disassemble and reassemble maps into manifolds should be useful for other applications), and in the course of this project, I found that I had not quite set up the material in the earlier papers in a way which was perfectly suited for this last (and longest paper). Because of this, this final paper proved to be far more difficult to write than it ought to have been with the correct framework. At some point in the future, when it becomes clearer exactly what that framework is, I am thinking of collecting and reorganising all this material into a reasonably self-contained book (as opposed to being spread out over a half-dozen papers totaling hundreds of pages in length). But this would take a significant amount of effort, and this project has already distracted me from my other tasks for several months now. As such, I have decided to compromise somewhat and release only a draft version of this paper here, with some of the arguments only sketched rather than given out in full, and continuing to use the existing framework provided by the preceding papers as much as possible, rather than to overhaul the entire series of papers. This is not the most satisfactory outcome – and in particular, I do not consider these papers ready for publication at this stage – but all of the important mathematical material in the arguments should be present here for those who are interested. I do hope though that the various technical components of the theory (particularly the points (a), (b), (c) mentioned above) will be simplified in the future (and the results generalised to other targets), at which point I may begin the process of converting these papers into a publication-quality monograph.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40899")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Hi Terry,")

#text("There’s a serious line overflow on page 33.")

#text("After you finish this fairly massive research and writing project, I think people might be interested in a post about what you’ve learned about the traps, pitfalls, trials and tribulations of organizing and putting together such a large project, including both the technical and writing aspects. I’ve been learning that anything that goes well beyond 100 pages is a much different animal to grapple with than a 25 page paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Is the first word on page 38 supposed to be “The” and not “Thee”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. Sterbenz")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40910")[#strong[#text("J. Sterbenz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("This is a truly outstanding piece of work. Please allow me to add a")#linebreak()#text(" few additional comments:")

#text("For those who do not know, the regularity problem problem for WM has")#linebreak()#text(" occupied research directions of a sizable number of people working")#linebreak()#text(" in PDE since at least the mid ’80s. Not only is this a topic that")#linebreak()#text(" connects well across a broad band of PDE")#linebreak()#text(" (elliptic-parabolic-hyperbolic/dispersive), it is also considered a")#linebreak()#text(" “gateway” problem to more difficult subjects in mathematical physics")#linebreak()#text(" such as the critical Yang-Mills regularity problem, and the U(1)")#linebreak()#text(" symmetry reduced Einstein vacuum equations.")

#text("There has been a long string of more or less continuous advances")#linebreak()#text(" that have led us to the current understanding. From the hard")#linebreak()#text(" regularity theory pioneered by Klainerman-Machedon on which all")#linebreak()#text(" modern approaches rely (i.e. null from estimates), to the CMC")#linebreak()#text(" foliation estimates of Grillakis, the induction on energy strategy")#linebreak()#text(" of Bourgain, and the concentration-compactness philosophy of")#linebreak()#text(" Sacks-Uhlenbeck, Struwe, and Kenig-Merle. It is safe to say that any")#linebreak()#text(" advance in this field nowadays is less the product of one")#linebreak()#text(" individuals thought than it is the synthesis of much prior work")#linebreak()#text(" glued together with some additional technical understanding. This")#linebreak()#text(" may me true of many advances in modern mathematics, but it is")#linebreak()#text(" especially clear in this case. I think I speak on behalf of many of")#linebreak()#text(" my colleagues when I say that results of this type are really the")#linebreak()#text(" triumph of a community.")

#text("Finally, I would like to point out that there are multiple groups")#linebreak()#text(" still working on aspects of this problem, and that their intention")#linebreak()#text(" is to give a complete and independent proof of WM scattering. Some")#linebreak()#text(" of these results have been mentioned several times in public")#linebreak()#text(" lectures in the past 6 months. This includes the forthcoming work of")#linebreak()#text(" Krieger-Schlag. I sincerely hope that these efforts are recognized")#linebreak()#text(" on an equal footing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Thanks for the corrections (and thanks, Jacob, for the kind words!) I forgot to mention the forthcoming Krieger-Schlag work in the above post, but I am looking forward to it; as I understand it, they manage to establish an even stronger result than uniform scattering, namely a nonlinear profile decomposition (I think in the case when the target manifold is ")#mi("{\\mathcal H}^2")#text(", the last I heard). This sounds particularly challenging due to the non-triviality of the low-high frequency interaction mentioned in (c) above, and it would be interesting to see what they did to resolve this issue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. Sterbenz")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40914")[#strong[#text("J. Sterbenz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("It is very interesting indeed. My understanding is that it is a kind")#linebreak()#text(" of “twisted” profile decomposition, perhaps analogous to the")#linebreak()#text(" parametrix constructions for gauge-fields. In the H^2 case its an")#linebreak()#text(" abelian gauge, so there is perhaps a clear rout to this. I will see")#linebreak()#text(" Wilhelm’s talk in Vancouver about a week from now for more details.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40917")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#emph[#text("this project has already distracted me from my other tasks for several months now. ")]

#text("Wait. Is this supposed to be your excuse for having only 16 papers in 2009 so far?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31b547912bb3c135e44bd5785d3a7638f64b41f1a60b55ceda0d207343fb8640-003728e02c25fb9a340e6b33ad53793823a850b11a25cc6dee2ddf4397b56124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UFC 101 Live Stream")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-40920")[#strong[#text("UFC 101 Live Stream")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("i like this article terrence! Thanks for the wonderful post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-43310")[#strong[#text("Critical wave maps « Hydrobates")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")]

#text("[…] harder and was the subject of a major project of Tao (project heatwave). For more information see this post of Tao and the comments on it. By the time the project was finished there were already alternative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/07/global-regularity-of-wave-maps-vii-control-of-delocalised-or-dispersed-solutions/#comment-566226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2020")])]

#text("Hi, do you still plan on having the conversion process to a monograph take place?")
]
