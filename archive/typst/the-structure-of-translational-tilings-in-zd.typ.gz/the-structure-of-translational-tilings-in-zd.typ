// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/
// Converted to Typst by tao2typ: "2026-10-14T11:00:54.693828+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The structure of translational tilings in Z^d", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The structure of translational tilings in Z^d")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 October 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/")[#text("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.ucla.edu/~greenfeld/")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2010.03254")[#text("The structure of translational tilings in ")#mi("{{\\bf Z}^d}")]#text("“. This paper studies the tilings ")#mi("{1_F * 1_A = 1}")#text(" of a finite tile ")#mi("{F}")#text(" in a standard lattice ")#mi("{{\\bf Z}^d}")#text(", that is to say sets ")#mi("{A \\subset {\\bf Z}^d}")#text(" (which we call ")#emph[#text("tiling sets")]#text(") such that every element of ")#mi("{{\\bf Z}^d}")#text(" lies in exactly one of the translates ")#mi("{a+F, a \\in A}")#text(" of ")#mi("{F}")#text(". We also consider more general ")#emph[#text("tilings of level ")#mi("{k}")]#text(" ")#mi("{1_F * 1_A = k}")#text(" for a natural number ")#mi("{k}")#text(" (several of our results consider an even more general setting in which ")#mi("{1_F * 1_A}")#text(" is periodic but allowed to be non-constant).")

#text("In many cases the tiling set ")#mi("{A}")#text(" will be periodic (by which we mean translation invariant with respect to some lattice (a finite index subgroup) of ")#mi("{{\\bf Z}^d}")#text("). For instance one simple example of a tiling is when ")#mi("{F \\subset {\\bf Z}^2}")#text(" is the unit square ")#mi("{F = \\{0,1\\}^2}")#text(" and ")#mi("{A}")#text(" is the lattice ")#mi("{2{\\bf Z}^2 = \\{ 2x: x \\in {\\bf Z}^2\\}}")#text(". However one can modify some tilings to make them less periodic. For instance, keeping ")#mi("{F = \\{0,1\\}^2}")#text(" one also has the tiling set")

#align(center)[#tao-fit-display[#mitex("A = \\{ (2x, 2y+a(x)): x,y \\in {\\bf Z} \\}")]]

#text("where ")#mi("{a: {\\bf Z} \\rightarrow \\{0,1\\}}")#text(" is an arbitrary function. This tiling set is periodic in a single direction ")#mi("{(0,2)}")#text(", but is not doubly periodic. For the slightly modified tile ")#mi("{F = \\{0,1\\} \\times \\{0,2\\}}")#text(", the set")

#align(center)[#tao-fit-display[#mitex("A = \\{ (2x, 4y+2a(x)): x,y \\in {\\bf Z} \\} \\cup \\{ (2x+b(y), 4y+1): x,y \\in {\\bf Z}\\}")]]

#text("for arbitrary ")#mi("{a,b: {\\bf Z} \\rightarrow \\{0,1\\}}")#text(" can be verified to be a tiling set, which in general will not exhibit any periodicity whatsoever; however, it is ")#emph[#text("weakly periodic")]#text(" in the sense that it is the disjoint union of finitely many sets, each of which is periodic in one direction.")

#text("The most well known conjecture in this area is the Periodic Tiling Conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Periodic tiling conjecture)")]#text(" If a finite tile ")#mi("{F \\subset {\\bf Z}^d}")#text(" has at least one tiling set, then it has a tiling set which is periodic.")
]

#text("This conjecture was stated explicitly ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("by Lagarias and Wang")]#text(", and also appears implicitly in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=992195")[#text("this text of Grunbaum and Shepard")]#text(". In one dimension ")#mi("{d=1}")#text(" there is a simple pigeonhole principle argument ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=429720")[#text("of Newman")]#text(" that shows that all tiling sets are in fact periodic, which certainly implies the periodic tiling conjecture in this case. The ")#mi("{d=2}")#text(" case was settled more recently by ")#link("https://arxiv.org/abs/1602.05738")[#text("Bhattacharya")]#text(", but the higher dimensional cases ")#mi("{d > 2}")#text(" remain open in general.")

#text("We are able to obtain a new proof of Bhattacharya’s result that also gives some quantitative bounds on the periodic tiling set, which are polynomial in the diameter of the set if the cardinality ")#tao-math("{\\left|F\\right|}", block: false)#text(" of the tile is bounded:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Quantitative periodic tiling in ")#mi("{{\\bf Z}^2}")#text(")")]#text(" ")#metadata(none) <tao-5630401c6f6890ef856e>#text(" If a finite tile ")#mi("{F \\subset {\\bf Z}^2}")#text(" has at least one tiling set, then it has a tiling set which is ")#mi("{M{\\bf Z}^2}")#text("-periodic for some ")#tao-math("{M \\ll_{\\left|F\\right|} \\mathrm{diam}(F)^{O(\\left|F\\right|^4)}}", block: false)#text(".")
]

#text("Among other things, this shows that the problem of deciding whether a given subset of ")#mi("{{\\bf Z}^2}")#text(" of bounded cardinality tiles ")#mi("{{\\bf Z}^2}")#text(" or not is in the NP complexity class with respect to the diameter ")#mi("{\\mathrm{diam}(F)}")#text(". (Even the decidability of this problem was not known until the result of Bhattacharya.)")

#text("We also have a closely related structural theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Quantitative weakly periodic tiling in ")#mi("{{\\bf Z}^2}")#text(")")]#text(" ")#metadata(none) <tao-73bf9e6349a772266f71>#text(" Every tiling set of a finite tile ")#mi("{F \\subset {\\bf Z}^2}")#text(" is weakly periodic. In fact, the tiling set is the union of at most ")#tao-math("{\\left|F\\right|-1}", block: false)#text(" disjoint sets, each of which is periodic in a direction of magnitude ")#tao-math("{O_{\\left|F\\right|}( \\mathrm{diam}(F)^{O(\\left|F\\right|^2)})}", block: false)#text(".")
]

#text("We also have a new bound for the periodicity of tilings in ")#mi("{{\\bf Z}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Universal period for tilings in ")#mi("{{\\bf Z}}")#text(")")]#text(" Let ")#mi("{F \\subset {\\bf Z}}")#text(" be finite, and normalized so that ")#mi("{0 \\in F}")#text(". Then every tiling set of ")#mi("{F}")#text(" is ")#mi("{qn}")#text("-periodic, where ")#mi("{q}")#text(" is the least common multiple of all primes up to ")#tao-math("{2\\left|F\\right|}", block: false)#text(", and ")#mi("{n}")#text(" is the least common multiple of the magnitudes ")#tao-math("{\\left|f\\right|}", block: false)#text(" of all ")#mi("{f \\in F \\backslash \\{0\\}}")#text(".")
]

#text("We remark that the current best complexity bound of determining whether a subset of ")#mi("{{\\bf Z}}")#text(" tiles ")#mi("{{\\bf Z}}")#text(" or not is ")#mi("{O( \\exp(\\mathrm{diam}(F)^{1/3+o(1)}))}")#text(", due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2141045")[#text("to Biro")]#text(". It may be that the results in this paper can improve upon this bound, at least for tiles of bounded cardinality.")

#text("On the other hand, we discovered a genuine difference between level one tiling and higher level tiling, by locating a counterexample to the higher level analogue of (the qualitative version of) Theorem ")#link(<tao-73bf9e6349a772266f71>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Counterexample)")]#text(" There exists an eight-element subset ")#mi("{F \\subset {\\bf Z}^2}")#text(" and a level ")#mi("{4}")#text(" tiling ")#mi("{1_F * 1_A = 4}")#text(" such that ")#mi("{A}")#text(" is not weakly periodic.")
]

#text("We do not know if there is a corresponding counterexample to the higher level periodic tiling conjecture (that if ")#mi("{F}")#text(" tiles ")#mi("{{\\bf Z}^d}")#text(" at level ")#mi("{k}")#text(", then there is a periodic tiling at the same level ")#mi("{k}")#text("). Note that it is important to keep the level fixed, since one trivially always has a periodic tiling at level ")#tao-math("{\\left|F\\right|}", block: false)#text(" from the identity ")#tao-math("{1_F * 1 = \\left|F\\right|}", block: false)#text(".")

#text("The methods of Bhattacharya used the language of ergodic theory. Our investigations also originally used ergodic-theoretic and Fourier-analytic techniques, but we ultimately found combinatorial methods to be more effective in this problem (and in particular led to quite strong quantitative bounds). The engine powering all of our results is the following remarkable fact, valid in all dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Dilation lemma)")]#text(" ")#metadata(none) <tao-9d342244e93851e7f870>#text(" Suppose that ")#mi("{A}")#text(" is a tiling of a finite tile ")#mi("{F \\subset {\\bf Z}^d}")#text(". Then ")#mi("{A}")#text(" is also a tiling of the dilated tile ")#mi("{rF}")#text(" for any ")#mi("{r}")#text(" coprime to ")#mi("{n}")#text(", where ")#mi("{n}")#text(" is the least common multiple of all the primes up to ")#tao-math("{\\left|F\\right|}", block: false)#text(".")
]

#text("Versions of this dilation lemma have previously appeared in work ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1345184")[#text("of Tijdeman")]#text(" and ")#link("https://arxiv.org/abs/1602.05738")[#text("of Bhattacharya")]#text(". We sketch a proof here. By the fundamental theorem of arithmetic and iteration it suffices to establish the case where ")#mi("{r}")#text(" is a prime ")#tao-math("{p>\\left|F\\right|}", block: false)#text(". We need to show that ")#mi("{1_{pF} * 1_A = 1}")#text(". It suffices to show the claim ")#mi("{1_{pF} * 1_A = 1 \\text{ mod } p}")#text(", since both sides take values in ")#tao-math("{\\{0,\\dots,\\left|F\\right|\\} \\subset \\{0,\\dots,p-1\\}}", block: false)#text(". The convolution algebra ")#mi("{{\\bf F}_p[{\\bf Z}^d]}")#text(" (or group algebra) of finitely supported functions from ")#mi("{{\\bf Z}^d}")#text(" to ")#mi("{{\\bf F}_p}")#text(" is a commutative algebra of characteristic ")#mi("{p}")#text(", so we have the Frobenius identity ")#mi("{(f+g)^{*p} = f^{*p} + g^{*p}}")#text(" for any ")#mi("{f,g}")#text(". As a consequence we see that ")#mi("{1_{pF} = 1_F^{*p} \\text{ mod } p}")#text(". The claim now follows by convolving the identity ")#mi("{1_F * 1_A = 1 \\text{ mod } p}")#text(" by ")#mi("{p-1}")#text(" further copies of ")#mi("{1_F}")#text(".")

#text("In our paper we actually establish a more general version of the dilation lemma that can handle tilings of higher level or of a periodic set, and this stronger version is useful to get the best quantitative results, but for simplicity we focus attention just on the above simple special case of the dilation lemma.")

#text("By averaging over all ")#mi("{r}")#text(" in an arithmetic progression, one already gets a useful structural theorem for tilings in any dimension, which appears to be new despite being an easy consequence of Lemma ")#link(<tao-9d342244e93851e7f870>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Structure theorem for tilings)")]#text(" Suppose that ")#mi("{A}")#text(" is a tiling of a finite tile ")#mi("{F \\subset {\\bf Z}^d}")#text(", where we normalize ")#mi("{0 \\in F}")#text(". Then we have a decomposition")

#metadata(none) <tao-a73fcf33964092920728>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1_A = 1 - \\sum_{f \\in F \\backslash 0} \\varphi_f")]]

#text("where each ")#mi("{\\varphi_f: {\\bf Z}^d \\rightarrow [0,1]}")#text(" is a function that is periodic in the direction ")#mi("{nf}")#text(", where ")#mi("{n}")#text(" is the least common multiple of all the primes up to ")#tao-math("{\\left|F\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-9d342244e93851e7f870>)[#text("6")]#text(" we have ")#mi("{1_A = 1 - \\sum_{f \\in F \\backslash 0} \\delta_{rf} * 1_A}")#text(" for any ")#mi("{r = 1 \\text{ mod } n}")#text(", where ")#mi("{\\delta_{rf}}")#text(" is the Kronecker delta at ")#mi("{rf}")#text(". Now average over ")#mi("{r}")#text(" (extracting a weak limit or generalised limit as necessary) to obtain the conclusion. ")#mi("\\Box")

#text("The identity ")#link(<tao-a73fcf33964092920728>)[#text("(1)")]#text(" turns out to impose a lot of constraints on the functions ")#mi("{\\varphi_f}")#text(", particularly in one and two dimensions. On one hand, one can work modulo ")#mi("{1}")#text(" to eliminate the ")#mi("{1_A}")#text(" and ")#mi("{1}")#text(" terms to obtain the equation")

#align(center)[#tao-fit-display[#mitex("\\sum_{f \\in F \\backslash 0} \\varphi_f = 0 \\text{ mod } 1")]]

#text("which in two dimensions in particular puts a lot of structure on each individual ")#mi("{\\varphi_f}")#text(" (roughly speaking it makes the ")#mi("{\\varphi_f \\text{ mod } 1}")#text(" behave in a polynomial fashion, after collecting commensurable terms). On the other hand we have the inequality")

#metadata(none) <tao-b8f64169d68d32b211d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{f \\in F \\backslash 0} \\varphi_f \\leq 1")]]

#text("which can be used to exclude “equidistributed” polynomial behavior after a certain amount of combinatorial analysis. Only a small amount of further argument is then needed to conclude Theorem ")#link(<tao-73bf9e6349a772266f71>)[#text("3")]#text(" and Theorem ")#link(<tao-5630401c6f6890ef856e>)[#text("2")]#text(".")

#text("For level ")#mi("{k}")#text(" tilings the analogue of ")#link(<tao-b8f64169d68d32b211d7>)[#text("(2)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{f \\in F \\backslash 0} \\varphi_f \\leq k")]]

#text("which is a significantly weaker inequality and now no longer seems to prohibit “equidistributed” behavior. After some trial and error we were able to come up with a completely explicit example of a tiling that actually utilises equidistributed polynomials; indeed the tiling set we ended up with was a finite boolean combination of Bohr sets.")

#text("We are currently studying what this machinery can tell us about tilings in higher dimensions, focusing initially on the three-dimensional case.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594502")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("A first typo just founded in the ref [HN] : “Caractérisation” instead of “Caracterisation”.")

#emph[#text("[This will be corrected in the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("Is there any known complete(!) classification of “tiling types” (in addition to translational tiling) in ")#mi("\\mathbb Z^d")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hansen")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594536")[#strong[#text("Hansen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("On the blog in the proof of corollary 7 the word ‘function’ may be omitted after ‘Kronecker delta’ i.e. ‘Kronecker delta at’ ===> ‘Kronecker delta function at’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594540")[#strong[#text("Luis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("In the paragraph of the blog located between Theorem 2 and Theorem 3, “Even” –>> “Even if”")

#emph[#text("[This is not the intended meaning. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("Who are you to correct him? You (and presumably all your aliases above) obviously don’t know about the subject or the English language. Most of your suggestions are nonsense.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594617")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("I wanted to suggest to change “in the sense that is the disjoint union” -> “in the sense that IT is the disjoint union”, but now I’m not sure I still dare…")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594556")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("In the preprint 2 sentesec before Remark 1.2 “implies that the problem of determine whether a tile F tiles Zd or not is decidable.”")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594618")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("As you note in the preprint, you do not allow rotations. Could any of these methods work if you do? AFAIK, the discrete Einstein problem is still open.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("In the discrete setting, every tile only has a finite number of rotational copies of it that stay in the lattice, and so tiling with one tile by both translations and rotations is a special case of tiling by translation (i.e., by [orientation-preserving] rigid motions) using more than one (but only finitely many) tiles. For the more general question of translational tiling by a finite set of tiles the tiling problem becomes quite nasty – tilings no longer need to be periodic, and in fact there are tile sets for which the question of whether a tiling exists is in fact undecidable (a result ")#link("https://www.ams.org/mathscinet-getitem?mr=0216954")[#text("of Berger")]#text("). However, in these constructions the tile set does not consist simply of rotations of a single tile, so the decidability or periodisability of rigid motion tilings remains open. It seems unlikely to me that the dilation lemma continues to hold if rotations are permitted, and this lemma is critical to our approach, so I don’t think our methods give any positive results towards tiling by rigid motions. Still, the Berger-type constructions hint that such tilings could be significantly less well-behaved than translational tilings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594805")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("In the phrase “discrete einstein problem” the word “einstein” should be lowercased, since it refers literally to “one stone” and not to a person.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594712")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("If I’m not mistaken, one of the two components in your second tiling set example needs a “+1” added to the y coordinate. Otherwise you never cover the odd-y elements of ")#mi("\\mathbb{Z}^2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a98d20754f8295451c9dca2b4d8a80219f1b9580f5d286eb322856ed7a75dba7-b137dafc8142cb6cf0c739fa5f3d88bfecc35eadabd561b13c690f796bfd9097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-594713")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("I have never had to deal with such difficult topics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Undecidable translational tilings with only two tiles, or one nonabelian tile | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-633039")[#strong[#text("Undecidable translational tilings with only two tiles, or one nonabelian tile | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("[…] conjecture is known in two dimensions (by work of Bhattacharya when , and more recently by us when ), but remains open in higher dimensions. By the preceding discussion, the conjecture implies […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Measurable tilings by abelian group actions | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-641073")[#strong[#text("Measurable tilings by abelian group actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("[…] my preprint “Measurable tilings by abelian group actions“. This paper is related to an earlier paper of Rachel Greenfeld and myself concerning tilings of lattices , but now we consider the more general situation of tiling a measure […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-641105")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("Is there any heuristic “justification” for conjecture 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-641106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("I think there is an informal intuition that it is “easier” to tile space periodically than it is to tile aperiodically, especially if one does not simply “cheat” by starting with a periodic tiling and “sliding” some of the tiles in it to make it technically aperiodic. The discovery in the 1960s that ")#link("https://en.wikipedia.org/wiki/Aperiodic_tiling")[#text("aperiodic sets of tiles")]#text(" exist at all was considered surprising at the time, but all constructions seemed to require far more than one single tile. An aperiodic tiling ")#mi("F \\oplus A = {\\bf Z}^d")#text(" also needs a quite extreme level of coordination between the Fourier transform of ")#mi("1_F")#text(" and the (distributional) Fourier transform of ")#mi("1_A")#text(", in particular the latter needs to be supported in the zero set of the former (together with the origin). This hints at an additional difficulty in constructing a single aperiodic tile, as opposed to aperiodic sets of multiple tiles where the Fourier transforms seem to be far less constrained. (This is also related to the dilation lemma being available for tilings by one tile, but not by multiple tiles.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A counterexample to the periodic tiling conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-657878")[#strong[#text("A counterexample to the periodic tiling conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("[…] (as first observed by Newman), and was proven for by Bhattacharya (with a new proof given by Greenfeld and myself). The continuous periodic tiling conjecture was established for by Lagarias and Wang. By an old […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/#comment-657889")[#strong[#text("A counterexample to the periodic tiling conjecture - Veja Online")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")]

#text("[…] (as first noticed by Newman), and was confirmed for by Bhattacharya (with a brand new proof given by Greenfeld and myself). The continual periodic tiling conjecture was established for by Lagarias and Wang. By an […]")
]
