// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T15:20:13.331273+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "255B, Notes 1: The Lagrangian formulation of the Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("255B, Notes 1: The Lagrangian formulation of the Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("These lecture notes are a continuation of the ")#link("https://terrytao.wordpress.com/category/teaching/254a-incompressible-fluid-equations/")[#text("254A lecture notes")]#text(" from the previous quarter.")#linebreak()#text(" We consider the Euler equations for incompressible fluid flow on a Euclidean space ")#mi("{{\\bf R}^d}")#text("; we will label ")#mi("{{\\bf R}^d}")#text(" as the “Eulerian space” ")#mi("{{\\bf R}^d_E}")#text(" (or “Euclidean space”, or “physical space”) to distinguish it from the “Lagrangian space” ")#mi("{{\\bf R}^d_L}")#text(" (or “labels space”) that we will introduce shortly (but the reader is free to also ignore the ")#mi("{E}")#text(" or ")#mi("{L}")#text(" subscripts if he or she wishes). Elements of Eulerian space ")#mi("{{\\bf R}^d_E}")#text(" will be referred to by symbols such as ")#mi("{x}")#text(", we use ")#mi("{dx}")#text(" to denote Lebesgue measure on ")#mi("{{\\bf R}^d_E}")#text(" and we will use ")#mi("{x^1,\\dots,x^d}")#text(" for the ")#mi("{d}")#text(" coordinates of ")#mi("{x}")#text(", and use indices such as ")#mi("{i,j,k}")#text(" to index these coordinates (with the usual summation conventions), for instance ")#mi("{\\partial_i}")#text(" denotes partial differentiation along the ")#mi("{x^i}")#text(" coordinate. (We use superscripts for coordinates ")#mi("{x^i}")#text(" instead of subscripts ")#mi("{x_i}")#text(" to be compatible with some differential geometry notation that we will use shortly; in particular, when using the summation notation, we will now be matching subscripts with superscripts for the pair of indices being summed.)")#linebreak()#text(" In Eulerian coordinates, the Euler equations read ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + u \\cdot \\nabla u  & = - \\nabla p", block: true, numbering: n => [#text("(1)")])



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("where ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" is the velocity field and ")#mi("{p: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" is the pressure field. These are functions of time ")#mi("{t \\in [0,T)}")#text(" and on the spatial location variable ")#mi("{x \\in {\\bf R}^d_E}")#text(". We will refer to the coordinates ")#mi("{(t,x) = (t,x^1,\\dots,x^d)}")#text(" as ")#link("https://en.wikipedia.org/wiki/Lagrangian_and_Eulerian_specification_of_the_flow_field")[#text("Eulerian coordinates")]#text(". However, if one reviews the physical derivation of the Euler equations from ")#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")[#text("254A Notes 0")]#text(", before one takes the continuum limit, the fundamental unknowns were not the velocity field ")#mi("{u}")#text(" or the pressure field ")#mi("{p}")#text(", but rather the trajectories ")#mi("{(x^{(a)}(t))_{a \\in A}}")#text(", which can be thought of as a single function ")#mi("{x: [0,T) \\times A \\rightarrow {\\bf R}^d_E}")#text(" from the coordinates ")#mi("{(t,a)}")#text(" (where ")#mi("{t}")#text(" is a time and ")#mi("{a}")#text(" is an element of the label set ")#mi("{A}")#text(") to ")#mi("{{\\bf R}^d}")#text(". The relationship between the trajectories ")#mi("{x^{(a)}(t) = x(t,a)}")#text(" and the velocity field was given by the informal relationship ")#metadata(none) <tao-71be07433b7138e42217>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t x(t,a) \\approx u( t, x(t,a) ).")]]

#text("We will refer to the coordinates ")#mi("{(t,a)}")#text(" as (discrete) ")#emph[#text("Lagrangian coordinates")]#text(" for describing the fluid.")#linebreak()#text(" In view of this, it is natural to ask whether there is an alternate way to formulate the continuum limit of incompressible inviscid fluids, by using a continuous version ")#mi("{(t,a)}")#text(" of the Lagrangian coordinates, rather than Eulerian coordinates. This is indeed the case. Suppose for instance one has a smooth solution ")#mi("{u, p}")#text(" to the Euler equations on a spacetime slab ")#mi("{[0,T) \\times {\\bf R}^d_E}")#text(" in Eulerian coordinates; assume furthermore that the velocity field ")#mi("{u}")#text(" is uniformly bounded. We introduce another copy ")#mi("{{\\bf R}^d_L}")#text(" of ")#mi("{{\\bf R}^d}")#text(", which we call ")#emph[#text("Lagrangian space")]#text(" or ")#emph[#text("labels space")]#text("; we use symbols such as ")#mi("{a}")#text(" to refer to elements of this space, ")#mi("{da}")#text(" to denote Lebesgue measure on ")#mi("{{\\bf R}^d_L}")#text(", and ")#mi("{a^1,\\dots,a^d}")#text(" to refer to the ")#mi("{d}")#text(" coordinates of ")#mi("{a}")#text(". We use indices such as ")#mi("{\\alpha,\\beta,\\gamma}")#text(" to index these coordinates, thus for instance ")#mi("{\\partial_\\alpha}")#text(" denotes partial differentiation along the ")#mi("{a^\\alpha}")#text(" coordinate. We will use summation conventions for both the Eulerian coordinates ")#mi("{i,j,k}")#text(" and the Lagrangian coordinates ")#mi("{\\alpha,\\beta,\\gamma}")#text(", with an index being summed if it appears as both a subscript and a superscript in the same term. While ")#mi("{{\\bf R}^d_L}")#text(" and ")#mi("{{\\bf R}^d_E}")#text(" are of course isomorphic, we will try to refrain from identifying them, except perhaps at the initial time ")#mi("{t=0}")#text(" in order to fix the initialisation of Lagrangian coordinates.")#linebreak()#text(" Given a smooth and bounded velocity field ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(", define a ")#emph[#text("trajectory map")]#text(" for this velocity to be any smooth map ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" that obeys the ODE ")#metadata(none) <tao-87e5ad485acb89c18788>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t X(t,a) = u( t, X(t,a) );")]]

#text("in view of ")#link(<tao-71be07433b7138e42217>)[#text("(2)")]#text(", this describes the trajectory (in ")#mi("{{\\bf R}^d_E}")#text(") of a particle labeled by an element ")#mi("{a}")#text(" of ")#mi("{{\\bf R}^d_L}")#text(". From the Picard existence theorem and the hypothesis that ")#mi("{u}")#text(" is smooth and bounded, such a map exists and is unique as long as one specifies the initial location ")#mi("{X(0,a)}")#text(" assigned to each label ")#mi("{a}")#text(". Traditionally, one chooses the initial condition ")#metadata(none) <tao-9dfd0eed59fbc9107d92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("X(0,a) = a")]]

#text("for ")#mi("{a \\in {\\bf R}^d_L}")#text(", so that we label each particle by its initial location at time ")#mi("{t=0}")#text("; we are also free to specify other initial conditions for the trajectory map if we please. Indeed, we have the freedom to “permute” the labels ")#mi("{a \\in {\\bf R}^d_L}")#text(" by an arbitrary ")#link("https://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphism")]#text(": if ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is a trajectory map, and ")#mi("{\\pi: {\\bf R}^d_L \\rightarrow{\\bf R}^d_L}")#text(" is any diffeomorphism (a smooth map whose inverse exists and is also smooth), then the map ")#mi("{X \\circ \\pi: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is also a trajectory map, albeit one with different initial conditions ")#mi("{X(0,a)}")#text(".")#linebreak()#text(" Despite the popularity of the initial condition ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(", we will try to keep conceptually separate the Eulerian space ")#mi("{{\\bf R}^d_E}")#text(" from the Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(", as they play different physical roles in the interpretation of the fluid; for instance, while the Euclidean metric ")#mi("{d\\eta^2 = dx^1 dx^1 + \\dots + dx^d dx^d}")#text(" is an important feature of Eulerian space ")#mi("{{\\bf R}^d_E}")#text(", it is not a geometrically natural structure to use in Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(". We have the following more general version of Exercise 8 from ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("254A Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-88053b70aab3bbfd02c7>#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" be smooth and bounded.")

#list(
[#text("If ")#mi("{X_0: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is a smooth map, show that there exists a unique smooth trajectory map ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" with initial condition ")#mi("{X(0,a) = X_0(a)}")#text(" for all ")#mi("{a \\in {\\bf R}^d_L}")#text(".")],
[#text("Show that if ")#mi("{X_0}")#text(" is a diffeomorphism and ")#mi("{t \\in [0,T)}")#text(", then the map ")#mi("{X(t): a \\mapsto X(t,a)}")#text(" is also a diffeomorphism.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The first of the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" can now be written in the form ")#metadata(none) <tao-305238273bb0fac2a73b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{d^2}{dt^2} X(t,a) = - (\\nabla p)( t, X(t,a) )")]]

#text("which can be viewed as a continuous limit of Newton’s first law ")#mi("{m^{(a)} \\frac{d^2}{dt^2} x^{(a)}(t) = F^{(a)}(t)}")#text(".")
]

#text("Call a diffeomorphism ")#mi("{Y: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" ")#emph[#text("(oriented) volume preserving")]#text(" if one has the equation ")#metadata(none) <tao-200d6dbc09aebe2fbc6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathrm{det}( \\nabla Y )(a) = 1")]]

#text("for all ")#mi("{a \\in {\\bf R}^d_L}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Total_derivative")[#text("total differential")]#text(" ")#mi("{\\nabla Y}")#text(" is the ")#mi("{d \\times d}")#text(" matrix with entries ")#mi("{\\partial_\\alpha Y^i}")#text(" for ")#mi("{\\alpha = 1,\\dots,d}")#text(" and ")#mi("{i=1,\\dots,d}")#text(", where ")#mi("{Y^1,\\dots,Y^d:{\\bf R}^d_L \\rightarrow {\\bf R}}")#text(" are the components of ")#mi("{Y}")#text(". (If one wishes, one can also view ")#mi("{\\nabla Y}")#text(" as a linear transformation from the tangent space ")#mi("{T_a {\\bf R}^d_L}")#text(" of Lagrangian space at ")#mi("{a}")#text(" to the tangent space ")#mi("{T_{Y(a)} {\\bf R}^d_E}")#text(" of Eulerian space at ")#mi("{Y(a)}")#text(".) Equivalently, ")#mi("{Y}")#text(" is orientation preserving and one has a Jacobian-free change of variables formula")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_F} f( Y(a) )\\ da = \\int_{{\\bf R}^d_E} f(x)\\ dx")]]

#text("for all ")#mi("{f \\in C_c({\\bf R}^d_E \\rightarrow {\\bf R})}")#text(", which is in turn equivalent to ")#mi("{Y(E) \\subset {\\bf R}^d_E}")#text(" having the same Lebesgue measure as ")#mi("{E}")#text(" for any measurable set ")#mi("{E \\subset {\\bf R}^d_L}")#text(".")#linebreak()#text(" The divergence-free condition ")#mi("{\\nabla \\cdot u = 0}")#text(" then can be nicely expressed in terms of volume-preserving properties of the trajectory maps ")#mi("{X}")#text(", in a manner which confirms the interpretation of this condition as an incompressibility condition on the fluid:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-fe61da860649d1497075>#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" be smooth and bounded, let ")#mi("{X_0: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" be a volume-preserving diffeomorphism, and let ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" be the trajectory map. Then the following are equivalent:")

#list(
[#mi("{\\nabla \\cdot u = 0}")#text(" on ")#mi("{[0,T) \\times {\\bf R}^d_E}")#text(".")],
[#mi("{X(t): {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is volume-preserving for all ")#mi("{t \\in [0,T)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Since ")#mi("{X_0}")#text(" is orientation-preserving, we see from continuity that ")#mi("{X(t)}")#text(" is also orientation-preserving. Suppose that ")#mi("{X(t)}")#text(" is also volume-preserving, then for any ")#mi("{f \\in C^\\infty_c({\\bf R}^d_E \\rightarrow {\\bf R})}")#text(" we have the conservation law")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_L} f( X(t,a) )\\ da = \\int_{{\\bf R}^d_E} f(x)\\ dx")]]

#text("for all ")#mi("{t \\in [0,T)}")#text(". Differentiating in time using the chain rule and ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_L} (u(t) \\cdot \\nabla f)( X(t,a)) \\ da = 0")]]

#text("for all ")#mi("{t \\in [0,T)}")#text(", and hence by change of variables")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} (u(t) \\cdot \\nabla f)(x) \\ dx = 0")]]

#text("which by integration by parts gives")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} (\\nabla \\cdot u(t,x)) f(x)\\ dx = 0")]]

#text("for all ")#mi("{f \\in C^\\infty_c({\\bf R}^d_E \\rightarrow {\\bf R})}")#text(" and ")#mi("{t \\in [0,T)}")#text(", so ")#mi("{u}")#text(" is divergence-free.")#linebreak()#text(" To prove the converse implication, it is convenient to introduce the ")#emph[#text("labels map")]#text(" ")#mi("{A:[0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_L}")#text(", defined by setting ")#mi("{A(t): {\\bf R}^d_E \\rightarrow {\\bf R}^d_L}")#text(" to be the inverse of the diffeomorphism ")#mi("{X(t): {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("A(t, X(t,a)) = a")]]

#text("for all ")#mi("{(t,a) \\in [0,T) \\times {\\bf R}^d_L}")#text(". By the implicit function theorem, ")#mi("{A}")#text(" is smooth, and by differentiating the above equation in time using ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("D_t A(t,x) = 0")]]

#text("where ")#mi("{D_t}")#text(" is the usual ")#link("https://en.wikipedia.org/wiki/Material_derivative")[#text("material derivative")]#text(" ")#metadata(none) <tao-40b30b4e8f0d137056ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("D_t := \\partial_t + u \\cdot \\nabla")]]

#text("acting on functions on ")#mi("{[0,T) \\times {\\bf R}^d_E}")#text(". If ")#mi("{u}")#text(" is divergence-free, we have from integration by parts that")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\bf R}^d_E} \\phi(t,x)\\ dx = \\int_{{\\bf R}^d_E} D_t \\phi(t,x)\\ dx")]]

#text("for any test function ")#mi("{\\phi: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(". In particular, for any ")#mi("{g \\in C^\\infty_c({\\bf R}^d_L \\rightarrow {\\bf R})}")#text(", we can calculate")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\int_{{\\bf R}^d_E} g( A(t,x) )\\ dx  & = \\int_{{\\bf R}^d_E} D_t (g(A(t,x)))\\ dx", block: true)



#tao-math(" & = \\int_{{\\bf R}^d_E} 0\\ dx", block: true)
]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} g(A(t,x))\\ dx = \\int_{{\\bf R}^d_E} g(A(0,x))\\ dx")]]

#text("for any ")#mi("{t \\in [0,T)}")#text(". Since ")#mi("{X_0}")#text(" is volume-preserving, so is ")#mi("{A(0)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} g \\circ A(t)\\ dx = \\int_{{\\bf R}^d_L} g\\ da.")]]

#text("Thus ")#mi("{A(t)}")#text(" is volume-preserving, and hence ")#mi("{X(t)}")#text(" is also. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-e02a753f0c060173d1fa>#text(" Let ")#mi("{M: [0,T) \\rightarrow \\mathrm{GL}_d({\\bf R})}")#text(" be a continuously differentiable map from the time interval ")#mi("{[0,T)}")#text(" to the general linear group ")#mi("{\\mathrm{GL}_d({\\bf R})}")#text(" of invertible ")#mi("{d \\times d}")#text(" matrices. Establish ")#link("https://en.wikipedia.org/wiki/Jacobi%27s_formula")[#text("Jacobi’s formula")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\det(M(t)) = \\det(M(t)) \\mathrm{tr}( M(t)^{-1} \\partial_t M(t) )")]]

#text("and use this and ")#link(<tao-200d6dbc09aebe2fbc6e>)[#text("(6)")]#text(" to give an alternate proof of Lemma ")#link(<tao-fe61da860649d1497075>)[#text("3")]#text(" that does not involve any integration in space.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can view the use of Lagrangian coordinates as an extension of the ")#link("https://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(". Indeed, from the chain rule we see that for any smooth function ")#mi("{f: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" of Eulerian spacetime, one has")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} f(t,X(t,a)) = (D_t f)(t,X(t,a))")]]

#text("and hence any transport equation that in Eulerian coordinates takes the form")

#align(center)[#tao-fit-display[#mitex("D_t f = g")]]

#text("for smooth functions ")#mi("{f,g: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" of Eulerian spacetime is equivalent to the ODE")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} F = G")]]

#text("where ")#mi("{F,G: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}}")#text(" are the smooth functions of Lagrangian spacetime defined by")

#align(center)[#tao-fit-display[#mitex("F(t,a) := f(t,X(t,a)); \\quad G(t,a) := g(t,X(t,a)).")]]
]

#text("In this set of notes we recall some basic differential geometry notation, particularly with regards to pullbacks and Lie derivatives of differential forms and other tensor fields on manifolds such as ")#mi("{{\\bf R}^d_E}")#text(" and ")#mi("{{\\bf R}^d_L}")#text(", and explore how the Euler equations look in this notation. Our discussion will be entirely formal in nature; we will assume that all functions have enough smoothness and decay at infinity to justify the relevant calculations. (It is possible to work rigorously in Lagrangian coordinates – see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=271984")[#text("the work of Ebin and Marsden")]#text(" – but we will not do so here.) As a general rule, Lagrangian coordinates tend to be somewhat less convenient to use than Eulerian coordinates for establishing the basic analytic properties of the Euler equations, such as local existence, uniqueness, and continuous dependence on the data; however, they are quite good at clarifying the more algebraic properties of these equations, such as conservation laws and the variational nature of the equations. It may well be that in the future we will be able to use the Lagrangian formalism more effectively on the analytic side of the subject also.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" One can also write the Navier-Stokes equations in Lagrangian coordinates, but the equations are not expressed in a favourable form in these coordinates, as the Laplacian ")#mi("{\\Delta}")#text(" appearing in the viscosity term becomes replaced with a time-varying Laplace-Beltrami operator. As such, we will not discuss the Lagrangian coordinate formulation of Navier-Stokes here.")
]

#metadata(none) <tao-b0ab63066268a8e93e57>

#heading(level: 1)[#strong[#text(" — 1. Pullbacks and Lie derivatives — ")]]

#text("In order to efficiently change coordinates, it is convenient to use the language of differential geometry, which is designed to be almost entirely independent of the choice of coordinates. We therefore spend some time recalling the basic concepts of differential geometry that we will need. Our presentation will be based on explicitly working in coordinates; there are of course more coordinate-free approaches to the subject (for instance setting up the machinery of ")#link("https://en.wikipedia.org/wiki/Vector_bundle")[#text("vector bundles")]#text(", or of ")#link("https://en.wikipedia.org/wiki/Derivation_(differential_algebra)")[#text("derivations")]#text("), but we will not adopt these approaches here.")#linebreak()#text(" Throughout this section, we fix a diffeomorphism ")#mi("{Y: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" from Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(" to Eulerian space ")#mi("{{\\bf R}^d_E}")#text("; one can for instance take ")#mi("{Y = X(t)}")#text(" where ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is a diffeomorphic trajectory map and ")#mi("{t \\in [0,T)}")#text(" is some time. Then all the differential geometry structures on Eulerian space ")#mi("{{\\bf R}^d_E}")#text(" can be ")#link("https://en.wikipedia.org/wiki/Pullback_(differential_geometry)")[#text("pulled back")]#text(" via ")#mi("{Y}")#text(" to Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(". For instance, a physical point ")#mi("{x \\in {\\bf R}^d_E}")#text(" can be pulled back to a label ")#mi("{Y^* x := Y^{-1}(x) \\in {\\bf R}^d_L}")#text(", and similarly a subset ")#mi("{E \\subset {\\bf R}^d_E}")#text(" of physical space can be pulled back to a subset ")#mi("{Y^* E := Y^{-1}(E) \\subset {\\bf R}^d_L}")#text(" of label space. A scalar field ")#mi("{f: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" can be pulled back to a scalar field ")#mi("{Y^* f: {\\bf R}^d_L \\rightarrow {\\bf R}}")#text(", defined by pre-composition:")

#align(center)[#tao-fit-display[#mitex("Y^* f(a) := f(Y(a)).")]]

#text("These operations are all compatible with each other in various ways; for instance, if ")#mi("{x \\in {\\bf R}^d_E}")#text(", ")#mi("{E \\subset {\\bf R}^d_E}")#text(", and ")#mi("{f: {\\bf R}^d_L \\rightarrow {\\bf R}}")#text(", and ")#mi("{c \\in {\\bf R}}")#text(" then")

#list(
[#mi("{x \\in E}")#text(" if and only if ")#mi("{Y^* x \\in Y^* E}")#text(".")],
[#mi("{f(x) = c}")#text(" if and only if ")#mi("{Y^* f( Y^* x ) = c}")#text(".")],
[#text("The map ")#mi("{E \\mapsto Y^* E}")#text(" is an isomorphism of ")#mi("{\\sigma}")#text("-algebras.")],
[#text("The map ")#mi("{f \\mapsto Y^* f}")#text(" is an algebra isomorphism.")]
)

#strong[#text("Differential forms.")]#text(" The next family of structures we will pull back are that of ")#link("https://en.wikipedia.org/wiki/Differential_form")[#text("differential forms")]#text(", which we will define using coordinates. (See also ")#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/")[#text("my previous notes on this topic")]#text(" for more discussion on differential forms.) For any ")#mi("{k \\geq 0}")#text(", a ")#emph[#mi("{k}")#text("-form")]#text(" ")#mi("{\\omega}")#text(" on ")#mi("{{\\bf R}^d_E}")#text(" will be defined as a family of functions ")#mi("{\\omega_{i_1 \\dots i_k}: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" for ")#mi("{i_1,\\dots,i_k \\in \\{1,\\dots,d\\}}")#text(" which is totally antisymmetric with respect to permutations of the indices ")#mi("{i_1,\\dots,i_k}")#text(", thus if one interchanges ")#mi("{i_j}")#text(" and ")#mi("{i_{j^{\\prime}}}")#text(" for any ")#mi("{1 \\leq j < j^{\\prime} \\leq k}")#text(", then ")#mi("{\\omega_{i_1 \\dots i_k}}")#text(" flips to ")#mi("{-\\omega_{i_1 \\dots i_k}}")#text(". Thus for instance")

#list(
[#text("A ")#mi("{0}")#text("-form is just a scalar field ")#mi("{\\omega: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(";")],
[#text("A ")#mi("{1}")#text("-form, when viewed in coordinates, is a collection ")#mi("{\\omega_i: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" of ")#mi("{d}")#text(" scalar functions;")],
[#text("A ")#mi("{2}")#text("-form, when viewed in coordinates, is a collection ")#mi("{\\omega_{ij}: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" of ")#mi("{d^2}")#text(" scalar functions with ")#mi("{\\omega_{ji} = -\\omega_{ij}}")#text(" (so in particular ")#mi("{\\omega_{ii}=0}")#text(");")],
[#text("A ")#mi("{3}")#text("-form, when viewed in coordinates, is a collection ")#mi("{\\omega_{ijk}: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" of ")#mi("{d^3}")#text(" scalar functions with ")#mi("{\\omega_{jik} = -\\omega_{ijk}}")#text(", ")#mi("{\\omega_{ikj} = -\\omega_{ijk}}")#text(", and ")#mi("{\\omega_{kji} = -\\omega_{ijk}}")#text(".")]
)

#text("The antisymmetry makes the component ")#mi("{\\omega_{i_1 \\dots i_k}}")#text(" of a ")#mi("{k}")#text("-form vanish whenever two of the indices agree. In particular, if ")#mi("{k>d}")#text(", then the only ")#mi("{k}")#text("-form that exists is the zero ")#mi("{k}")#text("-form ")#mi("{0}")#text(". A ")#mi("{d}")#text("-form is also known as a ")#link("https://en.wikipedia.org/wiki/Volume_form")[#text("volume form")]#text("; amongst all such forms we isolate the ")#emph[#text("standard volume form")]#text(" ")#mi("{d\\mathrm{vol}_E}")#text(", defined by setting ")#mi("{(d\\mathrm{vol}_E)_{\\sigma(1) \\dots \\sigma(d)} := \\mathrm{sgn}(\\sigma)}")#text(" for any permutation ")#mi("{\\sigma: \\{1,\\dots,d\\} \\rightarrow \\{1,\\dots,d\\}}")#text(" (with ")#mi("{\\mathrm{sgn}(\\sigma)\\in \\{-1,+1\\}}")#text(" being the ")#link("https://en.wikipedia.org/wiki/Parity_of_a_permutation")[#text("sign")]#text(" of the permutation), and setting all other components of ")#mi("{d\\mathrm{vol}_E}")#text(" equal to zero. For instance, in three dimensions one has ")#mi("{(d\\mathrm{vol}_E)_{i_1 \\dots i_3}}")#text(" equal to ")#mi("{+1}")#text(" when ")#mi("{(i_1,i_2,i_3) = (1,2,3), (2,3,1), (3,1,2)}")#text(", ")#mi("{-1}")#text(" when ")#mi("{(i_1,i_2,i_3) = (1,3,2), (3,2,1), (2,1,3)}")#text(", and ")#mi("{0}")#text(" otherwise. We use ")#mi("{\\Omega^k({\\bf R}^d_E)}")#text(" to denote the space of ")#mi("{k}")#text("-forms on ")#mi("{{\\bf R}^d_E}")#text(".")#linebreak()#text(" If ")#mi("{f: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" is a scalar field and ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(", we can define the product ")#mi("{f\\omega}")#text(" by pointwise multiplication of components:")

#align(center)[#tao-fit-display[#mitex("(f\\omega)_{i_1 \\dots i_k}(x) := f(x) \\omega_{i_1 \\dots i_k}(x).")]]

#text("More generally, given two forms ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(", ")#mi("{\\theta \\in \\Omega^l({\\bf R}^d_E)}")#text(", we define the ")#link("https://en.wikipedia.org/wiki/Exterior_algebra")[#text("wedge product")]#text(" ")#mi("{\\omega \\wedge \\theta := \\Omega^{k+l}({\\bf R}^d_E)}")#text(" to be the ")#mi("{k+l}")#text("-form given by the formula")

#align(center)[#tao-fit-display[#mitex("(\\omega \\wedge \\theta)_{i_1 \\dots i_{k+l}}(x) := \\frac{1}{k! l!} \\sum_{\\sigma \\in S_{k+l}} \\mathrm{sgn}(\\sigma) \\omega_{i_{\\sigma(1)} \\dots i_{\\sigma(k)}}(x) \\theta_{i_{\\sigma(k+1)} \\dots i_{\\sigma(k+l)}}(x)")]]

#text("where ")#mi("{S_{k+l}}")#text(" is the symmetric group of permutations on ")#mi("{\\{1,\\dots,k+l\\}}")#text(". For instance, for a scalar field ")#mi("{f: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" (so ")#mi("{f \\in \\Omega^0({\\bf R}^d_E)}")#text("), ")#mi("{f \\wedge \\omega = \\omega \\wedge f = f \\omega}")#text(". Similarly, if ")#mi("{\\theta,\\eta \\in \\Omega^1({\\bf R}^d_E)}")#text(" and ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(", we have the pointwise identities")

#tao-aligned(keep: true)[


#tao-math("(\\theta \\wedge \\eta)_{ij}  & = \\theta_i \\eta_j - \\theta_j \\eta_i", block: true)



#tao-math("(\\theta \\wedge \\omega)_{ijk}  & = \\theta_i \\omega_{jk} - \\theta_j \\omega_{ik} + \\theta_k \\omega_{ij}", block: true)



#tao-math("(\\omega \\wedge \\theta)_{ijk}  & = \\omega_{ij} \\theta_k - \\omega_{ik} \\theta_j + \\omega_{jk} \\theta_i.", block: true)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that the wedge product is a bilinear map from ")#mi("{\\Omega^k({\\bf R}^d_E) \\times \\Omega^l({\\bf R}^d_E)}")#text(" to ")#mi("{\\Omega^{k+l}({\\bf R}^d_E)}")#text(" that obeys the ")#link("https://en.wikipedia.org/wiki/Supercommutative_algebra")[#text("supercommutative property")]

#align(center)[#tao-fit-display[#mitex("\\omega \\wedge \\theta = (-1)^{kl} \\theta \\wedge \\omega")]]

#text("for ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" and ")#mi("{\\theta \\in \\Omega^l({\\bf R}^d_E)}")#text(", and the associative property")

#align(center)[#tao-fit-display[#mitex("(\\omega \\wedge \\theta) \\wedge \\eta = \\omega \\wedge (\\theta \\wedge \\eta)")]]

#text("for ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(", ")#mi("{\\theta \\in \\Omega^l({\\bf R}^d_E)}")#text(", ")#mi("{\\eta \\in \\Omega^m({\\bf R}^d_E)}")#text(". (In other words, the space of formal linear combinations of forms, ")#link("https://en.wikipedia.org/wiki/Graded_algebra")[#text("graded")]#text(" by the parity of the order of the forms, is a supercommutative algebra. Very roughly speaking, the prefix “super” means that “odd order objects anticommute with each other rather than commute”.)")
]

#text("If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" is continuously differentiable, we define the ")#link("https://en.wikipedia.org/wiki/Exterior_derivative")[#text("exterior derivative")]#text(" ")#mi("{d\\omega \\in \\Omega^{k+1}({\\bf R}^d_E)}")#text(" in coordinates as ")#metadata(none) <tao-36f70167ec844c8e7108>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(d\\omega)_{i_1 \\dots i_{k+1}} := \\sum_{j=1}^{k+1} (-1)^{j-1} \\partial_{i_j} \\omega_{i_1 \\dots i_{j-1} i_{j+1} \\dots i_{k+1}}.")]]

#text("It is easy to verify that this is indeed a ")#mi("{k+1}")#text("-form. Thus for instance:")

#list(
[#text("If ")#mi("{f \\in \\Omega^0({\\bf R}^d_E)}")#text(" is a continously differentiable scalar field, then ")#mi("{(df)_i = \\partial_i f}")#text(".")],
[#text("If ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(" is a continuously differentiable ")#mi("{1}")#text("-form, then ")#mi("{(d\\theta)_{ij} = \\partial_i \\theta_j - \\partial_j \\theta_i}")#text(".")],
[#text("If ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(" is a continuously differentiable ")#mi("{2}")#text("-form, then ")#mi("{(d\\omega)_{ijk} = \\partial_i \\omega_{jk} - \\partial_j \\omega_{ik} + \\partial_k \\omega_{ij}}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" and ")#mi("{\\theta \\in \\Omega^l({\\bf R}^d_E)}")#text(" are continuously differentiable, establish the ")#link("https://en.wikipedia.org/wiki/Derivation_(differential_algebra)#Graded_derivations")[#text("antiderivation")]#text(" (or super-Leibniz) law ")#metadata(none) <tao-6a63d2deee991139261b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("d( \\omega \\wedge \\theta ) = (d\\omega) \\wedge \\theta + (-1)^k \\omega \\wedge d\\theta")]]

#text("and if ")#mi("{\\omega}")#text(" is twice continuously differentiable, establish the ")#link("https://en.wikipedia.org/wiki/Derivation_(differential_algebra)#Graded_derivations")[#text("chain complex")]#text(" law ")#metadata(none) <tao-9414886b1ebf025db067>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("d d \\omega = 0.")]]
]

#text("Each of the coordinates ")#mi("{x^i}")#text(", ")#mi("{i=1,\\dots,d}")#text(" can be viewed as scalar fields ")#mi("{(x^1,\\dots,x^d) \\mapsto x^i}")#text(". In particular, the exterior derivatives ")#mi("{dx^i}")#text(", ")#mi("{i=1,\\dots,d}")#text(" are ")#mi("{1}")#text("-forms. It is easy to verify the identity")

#align(center)[#tao-fit-display[#mitex("\\omega = \\frac{1}{k!} \\omega_{i_1 \\dots i_k} dx^{i_1} \\wedge \\dots \\wedge dx^{i_k}")]]

#text("for any ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" with the usual summation conventions (which, in this differential geometry formalism, assert that we sum indices whenever they appear as a subscript-superscript pair). In particular the volume form ")#mi("{d\\mathrm{vol}_E}")#text(" can be written as")

#align(center)[#tao-fit-display[#mitex("d\\mathrm{vol}_E = dx^1 \\wedge \\dots \\wedge dx^d.")]]

#text("One can of course define differential forms on Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(" as well, changing the indices from Roman to Greek. For instance, if ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_L)}")#text(" is continuously differentiable, then ")#mi("{d\\theta \\in \\Omega^2({\\bf R}^d_L)}")#text(" is given in coordinates as")

#align(center)[#tao-fit-display[#mitex("(d\\theta)_{\\alpha \\beta} = \\partial_\\alpha \\theta_\\beta - \\partial_\\beta \\theta_\\alpha.")]]

#text("If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(", we define the pullback form ")#mi("{Y^* \\omega \\in \\Omega^k({\\bf R}^d_L)}")#text(" by the formula ")#metadata(none) <tao-ed679d1b475f89c62df5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("(Y^* \\omega)_{\\alpha_1 \\dots \\alpha_k}(a) := \\omega_{i_1 \\dots i_k}(Y(a)) \\partial_{\\alpha_1} Y^{i_1}(a) \\dots \\partial_{\\alpha_k} Y^{i_k}(a)")]]

#text("with the usual summation conventions. Thus for instance")

#list(
[#text("If ")#mi("{f \\in \\Omega^0({\\bf R}^d_E)}")#text(" is a scalar field, then the pullback ")#mi("{Y^* f \\in \\Omega^0({\\bf R}^d_L)}")#text(" is given by the same formula ")#mi("{Y^* f(a) = f(Y(a))}")#text(" as before.")],
[#text("If ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(" is a ")#mi("{1}")#text("-form, then the pullback ")#mi("{Y^* \\theta \\in \\Omega^1({\\bf R}^d_L)}")#text(" is given by the formula ")#mi("{(Y^* \\theta)_\\alpha(a) = \\theta_i(Y(a)) \\partial_\\alpha Y^i(a)}")#text(".")],
[#text("If ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(" is a ")#mi("{2}")#text("-form, then the pullback ")#mi("{Y^* \\omega \\in \\Omega^2({\\bf R}^d_L)}")#text(" is given by the formula")

#metadata(none) <tao-7ca7d2c480f8306967e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("(Y^* \\omega)_{\\alpha \\beta}(a) = \\omega_{ij}(Y(a)) \\partial_\\alpha Y^i(a) \\partial_\\beta Y^j(a).")]]]
)

#text("It is easy to see that pullback ")#mi("{Y^*}")#text(" is a linear map from ")#mi("{\\Omega^k({\\bf R}^d_E)}")#text(" to ")#mi("{\\Omega^k({\\bf R}^d_L)}")#text(". It also preserves the exterior algebra and exterior derivative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{\\omega, \\theta \\in \\Omega^k({\\bf R}^d_E)}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("Y^* (\\omega \\wedge \\theta) = (Y^* \\omega) \\wedge (Y^* \\theta),")]]

#text("and if ")#mi("{\\omega}")#text(" is continuously differentiable, show that")

#align(center)[#tao-fit-display[#mitex("Y^* d \\omega = d Y^* \\omega.")]]
]

#text("One can integrate ")#mi("{k}")#text("-forms on oriented ")#mi("{k}")#text("-manifolds. Suppose for instance that an oriented ")#mi("{k}")#text("-manifold ")#mi("{M \\subset {\\bf R}^d_E}")#text(" has a parameterisation ")#mi("{\\{ \\phi(a): a \\in U \\}}")#text(", where ")#mi("{U}")#text(" is an open subset of ")#mi("{{\\bf R}^k_L}")#text(" and ")#mi("{\\phi: U \\rightarrow {\\bf R}^d_E}")#text(" is an injective immersion. Then any continuous compactly supported ")#mi("{k}")#text("-form ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" can be integrated on ")#mi("{M}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_M \\omega := \\frac{1}{k!} \\int_U \\omega(\\phi(a))_{i_1 \\dots i_k} \\partial_1 Y^{i_1}(a) \\dots \\partial_k Y^{i_k}(a)\\ da")]]

#text("with the usual summation conventions. It can be shown that this definition is independent of the choice of parameterisation. For a more general manifold ")#mi("{M}")#text(", one can use a partition of unity to decompose the integral ")#mi("{\\int_M \\omega}")#text(" into parameterised manifolds, and define the total integral to be the sum of the components; again, one can show (after some tedious calculation) that this is independent of the choice of parameterisation. If ")#mi("{M}")#text(" is all of ")#mi("{{\\bf R}^d_E}")#text(" (with the standard orientation), and ")#mi("{f \\in C_c({\\bf R}^d \\rightarrow {\\bf R})}")#text(", then we have the identity ")#metadata(none) <tao-92e75e2f15aa4d25e510>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{{\\bf R}^d_E} f\\ d\\mathrm{vol}_E = \\int_{{\\bf R}^d_E} f(x)\\ dx")]]

#text("linking integration on differential forms with the Lebesgue (or Riemann) integral. We also record ")#link("https://en.wikipedia.org/wiki/Stokes%27_theorem")[#text("Stokes’ theorem")]#text(" ")#metadata(none) <tao-2b50aa6ff81012c3421a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\int_{\\partial \\Omega} \\omega = \\int_{\\Omega} d \\omega")]]

#text("whenever ")#mi("{\\Omega}")#text(" is a smooth orientable ")#mi("{k+1}")#text("-manifold with smooth boundary ")#mi("{\\partial \\Omega}")#text(", and ")#mi("{\\omega}")#text(" is a continuous, compactly supported ")#mi("{k}")#text("-form. The regularity conditions on ")#mi("{\\Omega,\\omega}")#text(" here can often be relaxed by the usual limiting arguments; for the purposes of this set of notes, we shall proceed formally and assume that identities such as ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(14)")]#text(" hold for all manifolds ")#mi("{\\Omega}")#text(" and forms ")#mi("{\\omega}")#text(" under consideration.")#linebreak()#text(" From the change of variables formula we see that pullback also respects integration on manifolds, in that ")#metadata(none) <tao-075a11f67e6b2f48fc26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\int_{Y^* \\Omega} Y^* \\omega = \\int_\\Omega \\omega")]]

#text("whenever ")#mi("{\\Omega}")#text(" is a smooth orientable ")#mi("{k}")#text("-manifold, and ")#mi("{\\omega}")#text(" a continuous compactly supported ")#mi("{k}")#text("-form.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Establish the identity")

#align(center)[#tao-fit-display[#mitex("Y^* d\\mathrm{vol}_E = \\mathrm{det}(\\nabla Y) d\\mathrm{vol}_L.")]]

#text("Conclude in particular that ")#mi("{Y}")#text(" is volume-preserving if and only if")

#align(center)[#tao-fit-display[#mitex("Y^* d\\mathrm{vol}_E = d\\mathrm{vol}_L.")]]
]

#strong[#text("Vector fields.")]#text(" Having pulled back differential forms, we now pull back vector fields. A ")#link("https://en.wikipedia.org/wiki/Vector_field")[#text("vector field")]#text(" ")#mi("{Z}")#text(" on ")#mi("{{\\bf R}^d_E}")#text(", when viewed in coordinates, is a collection ")#mi("{Z^i: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(", ")#mi("{i=1,\\dots,d}")#text(" of scalar functions; superficially, this resembles a ")#mi("{1}")#text("-form ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(", except that we use superscripts ")#mi("{Z^i}")#text(" instead of subscripts ")#mi("{\\theta_i}")#text(" to denote the components. On the other hand, we will transform vector fields under pullback in a different manner from ")#mi("{1}")#text("-forms. For each ")#mi("{i}")#text(", a basic example of a vector field is the coordinate vector field ")#mi("{\\frac{d}{dx^i}}")#text(", defined by setting ")#mi("{(\\frac{d}{dx^i})^j}")#text(" to equal ")#mi("{1}")#text(" when ")#mi("{i=j}")#text(" and ")#mi("{0}")#text(" otherwise. Then every vector field ")#mi("{Z}")#text(" may be written as")

#align(center)[#tao-fit-display[#mitex("Z = Z^i \\frac{d}{dx^i}")]]

#text("where we multiply scalar functions against vector fields in the obvious fashion; compare this with the expansion ")#mi("{\\theta = \\theta_i dx^i}")#text(" of a ")#mi("{1}")#text("-form ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(" into its components ")#mi("{\\theta_i}")#text(". The space of all vector fields will be denoted ")#mi("{\\Gamma(T {\\bf R}^d_E)}")#text(". One can of course define vector fields on ")#mi("{{\\bf R}^d_L}")#text(" similarly.")#linebreak()#text(" The pullback ")#mi("{Y^* Z}")#text(" of ")#mi("{Z}")#text(" is defined to be the unique vector field ")#mi("{Y^* Z \\in \\Gamma(T {\\bf R}^d_L)}")#text(" such that ")#metadata(none) <tao-4646e44d346dee04cfa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("Z^i(Y(a)) = (Y^* Z)^\\alpha(a) \\partial_\\alpha Y^i(a)")]]

#text("for all ")#mi("{a \\in {\\bf R}^d_L}")#text(" (so that ")#mi("{Z}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Pushforward_(differential)")[#text("pushforward")]#text(" of ")#mi("{Y_* Z}")#text("). Equivalently, if ")#mi("{(\\nabla Y)^{-1}}")#text(" is the inverse matrix to the total differential ")#mi("{\\nabla Y}")#text(" (which we recall in coordinates is ")#mi("{(\\nabla Y)^i_\\alpha := \\partial_\\alpha Y^i}")#text("), so that")

#align(center)[#tao-fit-display[#mitex("((\\nabla Y)^{-1})^\\alpha_i (\\nabla Y)^i_\\beta = \\delta^\\alpha_\\beta, \\quad (\\nabla Y)^i_\\alpha ((\\nabla Y)^{-1})^\\alpha_j = \\delta^i_j")]]

#text("with ")#mi("{\\delta}")#text(" denoting the Kronecker delta, then")

#align(center)[#tao-fit-display[#mitex("(Y^* Z)^\\alpha(a) = Z^i(Y(a)) ((\\nabla Y)^{-1})^\\alpha_i(a).")]]

#text("From the inverse function theorem one can also write")

#align(center)[#tao-fit-display[#mitex("((\\nabla Y)^{-1})^\\alpha_i(a) = (\\partial_i Y^{-1})( Y(a) ),")]]

#text("thus ")#mi("{Z}")#text(" is also the pullback of ")#mi("{Y^* Z}")#text(" by ")#mi("{Y^{-1}}")#text(".")#linebreak()#text(" If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" is a ")#mi("{k}")#text("-form and ")#mi("{Z_1,\\dots,Z_k \\in \\Gamma(T{\\bf R}^d_E)}")#text(" are vector fields, one can form the scalar field ")#mi("{\\omega(Z_1,\\dots,Z_k): {\\bf R}^d \\rightarrow {\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\omega(Z_1,\\dots,Z_k) := \\omega_{i_1 \\dots i_k} Z^{i_1}_1 \\dots Z^{i_k}_k.")]]

#text("Thus for instance if ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(" is a ")#mi("{2}")#text("-form and ")#mi("{Z,W \\in \\Gamma(T{\\bf R}^d_E)}")#text(" are vector fields, then")

#align(center)[#tao-fit-display[#mitex("\\omega(Z,W) = \\omega_{ij} Z^i W^j.")]]

#text("It is clear that ")#mi("{\\omega(Z_1,\\dots,Z_k)}")#text(" is a totally antisymmetric form in the ")#mi("{Z_1,\\dots,Z_k}")#text(". If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" is a ")#mi("{k}")#text("-form for some ")#mi("{k \\geq 1}")#text(" and ")#mi("{Z \\in \\Gamma(T{\\bf R}^d_E)}")#text(" is a vector field, we define the ")#link("https://en.wikipedia.org/wiki/Interior_product")[#text("contraction")]#text(" (or ")#emph[#text("interior product")]#text(") ")#mi("{Z \\neg \\omega \\in \\Omega^{k-1}({\\bf R}^d_E)}")#text(" in coordinates by the formula")

#align(center)[#tao-fit-display[#mitex("(Z \\neg \\omega)_{i_2 \\dots i_k} := Z^{i_1} \\omega_{i_1 \\dots i_k}")]]

#text("or equivalently that")

#align(center)[#tao-fit-display[#mitex("(Z_1 \\neg \\omega)(Z_2,\\dots,Z_k) = \\omega(Z_1,\\dots,Z_k)")]]

#text("for ")#mi("{Z_1,\\dots,Z_k \\in \\Gamma(T{\\bf R}^d_E)}")#text(". Thus for instance if ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(" is a ")#mi("{2}")#text("-form, and ")#mi("{Z \\in \\Gamma(T{\\bf R}^d_E)}")#text(" is a vector field, then ")#mi("{Z \\neg \\omega \\in \\Omega^1({\\bf R}^d_E)}")#text(" is the ")#mi("{1}")#text("-form")

#align(center)[#tao-fit-display[#mitex("(Z \\neg \\omega)_i = Z^j \\omega_{ji}.")]]

#text("If ")#mi("{Z \\in \\Gamma(T{\\bf R}^d_E)}")#text(" is a vector field and ")#mi("{f \\in \\Omega^0({\\bf R}^d_E)}")#text(" is a continuously differentiable scalar field, then ")#mi("{Z \\neg df = df(Z)}")#text(" is just the directional derivative of ")#mi("{f}")#text(" along the vector field ")#mi("{Z}")#text(":")

#align(center)[#tao-fit-display[#mitex("Z \\neg df = Z^i \\partial_i f.")]]

#text("The contraction ")#mi("{Z \\neg \\omega}")#text(" is also denoted ")#mi("{\\iota_Z \\omega}")#text(" in the literature. If one contracts a vector field ")#mi("{Z}")#text(" against the standard volume form ")#mi("{d\\mathrm{vol}_E}")#text(", one obtains a ")#mi("{d-1}")#text("-form which we will call (by slight abuse of notation) the ")#link("https://en.wikipedia.org/wiki/Hodge_star_operator")[#text("Hodge dual")]#text(" ")#mi("{*Z}")#text(" of ")#mi("{Z}")#text(":")

#align(center)[#tao-fit-display[#mitex("*Z := Z \\neg d\\mathrm{vol}_E.")]]

#text("This can easily be seen to be a bijection between vector fields and ")#mi("{d-1}")#text("-forms. The inverse of this operation will also be denoted by the Hodge star ")#mi("{*}")#text(":")

#align(center)[#tao-fit-display[#mitex("*(Z \\neg d\\mathrm{vol}_E) := Z.")]]

#text("In a similar spirit, the Hodge dual of a scalar field ")#mi("{f: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" will be defined as the volume form")

#align(center)[#tao-fit-display[#mitex("*f := f d\\mathrm{vol}_E")]]

#text("and conversely the Hodge dual of a volume form is a scalar field:")

#align(center)[#tao-fit-display[#mitex("*(f d\\mathrm{vol}_E) = f.")]]

#text("More generally one can form a Hodge duality relationship between ")#mi("{k}")#text("-vector fields and ")#mi("{d-k}")#text("-forms for any ")#mi("{0 \\leq k \\leq d}")#text(", but we will not do so here as we will not have much use for the notion of a ")#mi("{k}")#text("-vector field for any ")#mi("{k>1}")#text(".")#linebreak()#text(" These operations behave well under pullback (if one assumes volume preservation in the case of the Hodge star):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]

#list(
[#text("(i) If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" and ")#mi("{Z_1,\\dots,Z_k \\in \\Gamma(T{\\bf R}^d_E)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("Y^* ( \\omega(Z_1,\\dots,Z_k) ) = (Y^* \\omega)(Y^* Z_1, \\dots, Y^* Z_k).")]]],
[#text("(ii) If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" for some ")#mi("{k \\geq 1}")#text(" and ")#mi("{Z \\in \\Gamma(T{\\bf R}^d_E)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("Y^*( Z \\neg \\omega ) = (Y^* Z) \\neg (Y^* \\omega).")]]],
[#text("(iii) If ")#mi("{Y}")#text(" is volume-preserving, show that")

#align(center)[#tao-fit-display[#mitex("Y^*( * T ) = * Y^* T")]]

#text("whenever ")#mi("{T}")#text(" is a scalar field, vector field, ")#mi("{d-1}")#text("-form, or ")#mi("{d}")#text("-form on ")#mi("{{\\bf R}^d_E}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Cauchy-Binet formula)")]#text(" Let ")#mi("{X_1,\\dots,X_d \\in \\Gamma(T{\\bf R}^d_E)}")#text(" be vector fields. Establish (a special case of) the ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Binet_formula")[#text("Cauchy-Binet formula")]

#align(center)[#tao-fit-display[#mitex("d\\mathrm{vol}_E( X_1,\\dots,X_d )^2 = \\mathrm{det}( \\eta(X_i,X_j) )_{1 \\leq i,j \\leq d}.")]]
]

#strong[#text("Riemannian metrics.")]#text(" A ")#link("https://en.wikipedia.org/wiki/Metric_tensor")[#text("Riemannian metric")]#text(" ")#mi("{g}")#text(" on ")#mi("{{\\bf R}^d_E}")#text(", when expressed in coordinates is a collection of scalar functions ")#mi("{g_{ij}: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" such that for each point ")#mi("{x \\in {\\bf R}^d_E}")#text(", the matrix ")#mi("{(g_{ij}(x))_{1 \\leq i,j \\leq d}}")#text(" is symmetric and strictly positive definite. In particular it has an inverse metric ")#mi("{g^{-1}}")#text(", which is a collection of scalar functions ")#mi("{(g^{-1})^{ij}(x) = g^{ij}(x)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("g^{ij} g_{jk} = \\delta^i_k")]]

#text("where ")#mi("{\\delta}")#text(" denotes the Kronecker delta; here we have abused notation (and followed the conventions of general relativity) by allowing the inverse on the metric to be omitted when expressed in coordinates (relying instead on the superscripting of the indices, as opposed to subscripting, to indicate the metric inversion). The Euclidean metric ")#mi("{\\eta}")#text(" is an example of a metric tensor, with ")#mi("{\\eta_{ij}}")#text(" equal to ")#mi("{1}")#text(" when ")#mi("{i=j}")#text(" and zero otherwise; the coefficients ")#mi("{\\eta^{ij}}")#text(" of the inverse Euclidean metric ")#mi("{\\eta^{-1}}")#text(" is similarly equal to ")#mi("{1}")#text(" when ")#mi("{i=j}")#text(" and ")#mi("{0}")#text(" otherwise. Given two vector fields ")#mi("{Z,W \\in \\Gamma(T{\\bf R}^d_E)}")#text(" and a Riemannian metric ")#mi("{g}")#text(", we can form the scalar field ")#mi("{g(Z,W)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("g(Z,W) := g_{ij} Z^i W^j;")]]

#text("this is a symmetric bilinear form in ")#mi("{Z,W}")#text(".")#linebreak()#text(" We can define the pullback metric ")#mi("{Y^* g}")#text(" by the formula ")#metadata(none) <tao-b2e17fb240d351ab8c97>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("(Y^* g)_{\\alpha \\beta}(a) := g_{ij}(Y(a)) \\partial_\\alpha Y^i(a) \\partial_\\beta Y^j(a);")]]

#text("this is easily seen to be a Riemannian metric on ")#mi("{{\\bf R}^d_L}")#text(", and one has the compatibility property")

#align(center)[#tao-fit-display[#mitex("Y^*( g(Z,W) ) = (Y^* g)(Y^* Z, Y^* W)")]]

#text("for all ")#mi("{Z,W \\in \\Gamma(T{\\bf R}^d_E)}")#text(". It is then not difficult to check that if we pull back the inverse metric ")#mi("{g^{-1}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(Y^*(g^{-1}))^{\\alpha \\beta}(a) := g^{ij}(Y(a)) ((\\nabla Y)^{-1})^\\alpha_i(a) ((\\nabla Y)^{-1})^\\beta_j(a)")]]

#text("then we have the expected relationship")

#align(center)[#tao-fit-display[#mitex("Y^*(g^{-1}) = (Y^* g)^{-1}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" If ")#mi("{\\pi: {\\bf R}^d_L \\rightarrow {\\bf R}^d_L}")#text(" is a diffeomorphism, show that")

#align(center)[#tao-fit-display[#mitex("(Y \\circ \\pi)^* \\omega = \\pi^* Y^* \\omega")]]

#text("for any ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("(Y \\circ \\pi)^* Z = \\pi^* Y^* Z")]]

#text("for any ")#mi("{Z \\in \\Gamma(T{\\bf R}^d_E)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("(Y \\circ \\pi)^* g = \\pi^* Y^* g")]]

#text("for any Riemannian metric ")#mi("{g}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that ")#mi("{Y: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" is an isometry (with respect to the Euclidean metric on both ")#mi("{{\\bf R}^d_L}")#text(" and ")#mi("{{\\bf R}^d_E}")#text(") if and only if ")#mi("{Y^* \\eta = \\eta}")#text(".")
]

#text("Every Riemannian metric ")#mi("{g}")#text(" induces a ")#link("https://en.wikipedia.org/wiki/Musical_isomorphism")[#text("musical isomorphism")]#text(" between vector fields on ")#mi("{{\\bf R}^d_E}")#text(" with ")#mi("{1}")#text("-forms: if ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" is a vector field, the associated ")#mi("{1}")#text("-form ")#mi("{g \\cdot Z \\in \\Omega^1({\\bf R}^d_E)}")#text(" (also denoted ")#mi("{Z^\\flat_g}")#text(" or simply ")#mi("{Z^\\flat}")#text(") is defined in coordinates as")

#align(center)[#tao-fit-display[#mitex("(g \\cdot Z)_i := g_{ij} Z^j")]]

#text("and similarly if ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(", the associated vector field ")#mi("{g^{-1} \\cdot \\theta \\in \\Gamma(T{\\bf R}^d_E)}")#text(" (also denoted ")#mi("{\\theta^\\sharp_g}")#text(" or ")#mi("{\\theta^\\sharp}")#text(") is defined in coordinates as")

#align(center)[#tao-fit-display[#mitex("(g^{-1} \\cdot \\theta)^i := g^{ij} \\theta_j.")]]

#text("These operations clearly invert each other: ")#mi("{g^{-1} \\cdot g \\cdot Z = Z}")#text(" and ")#mi("{g \\cdot g^{-1} \\cdot \\theta = \\theta}")#text(". Note that ")#mi("{g \\cdot Z}")#text(" can still be defined if ")#mi("{g}")#text(" is not positive definite, though it might not be an isomorphism in this case. Observe the identities ")#metadata(none) <tao-ff00c4ddac16e54bf9e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("g(W,Z) = W \\neg (g \\cdot Z) = Z \\neg (g \\cdot W) = (g \\cdot Z)(W) = (g \\cdot W)(Z).")]]

#linebreak()#text(" The musical isomorphism interacts well with pullback, provided that one also pulls back the metric ")#mi("{g}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" If ")#mi("{g}")#text(" is a Riemannian metric, show that")

#align(center)[#tao-fit-display[#mitex("Y^*( g \\cdot Z ) = Y^* g \\cdot Y^* Z")]]

#text("for all ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("Y^*( g^{-1} \\cdot \\theta ) = (Y^* g)^{-1} \\cdot Y^* \\theta.")]]

#text("for all ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(".")
]

#text("We can now interpret some classical operations on vector fields in this differential geometry notation. For instance, if ")#mi("{Z,W \\in \\Gamma(T{\\bf R}^d_E)}")#text(" are vector fields, the dot product ")#mi("{Z \\cdot W: {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" can be written as")

#align(center)[#tao-fit-display[#mitex("Z \\cdot W = \\eta(Z,W) = Z \\neg (\\eta \\cdot W) = (\\eta \\cdot W)(Z)")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("Z \\cdot W = *( (\\eta \\cdot Z) \\wedge *W ),")]]

#text("and for ")#mi("{d=3}")#text(", the cross product ")#mi("{Z \\times W: {\\bf R}^3_E \\rightarrow {\\bf R}^3_E}")#text(" can be written in differential geometry notation as")

#align(center)[#tao-fit-display[#mitex("Z \\times W = *((\\eta \\cdot Z) \\wedge (\\eta \\cdot W)).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Formulate a definition for the pullback ")#mi("{Y^* T}")#text(" of a rank ")#mi("{(k,l)}")#text(" tensor field ")#mi("{T}")#text(" (which in coordinates would be given by ")#mi("{T^{i_1 \\dots i_k}_{j_1 \\dots j_l}}")#text(" for ")#mi("{i_1,\\dots,i_k,j_1,\\dots,j_l \\in \\{1,\\dots,d\\}}")#text(") that generalises the pullback of differential forms, vector fields, and Riemannian metrics. Argue why your definition is the natural one.")
]

#strong[#text("Lie derivatives.")]#text(" Let ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" is a continuously differentiable vector field, and ")#mi("{\\omega \\in \\Omega^k( {\\bf R}^d_E )}")#text(" is a continuously differentiable ")#mi("{k}")#text("-form, we will define the ")#link("https://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" ")#mi("{{\\mathcal L}_Z \\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" of ")#mi("{\\omega}")#text(" along ")#mi("{Z}")#text(" by the ")#emph[#text("Cartan formula")]#text(" ")#metadata(none) <tao-9b3fea8ad52e1f62033b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("{\\mathcal L}_Z \\omega := Z \\neg d\\omega + d(Z \\neg \\omega)")]]

#text("with the convention that ")#mi("{d(Z \\neg \\omega)}")#text(" vanishes if ")#mi("{\\omega}")#text(" is a ")#mi("{0}")#text("-form. Thus for instance:")

#list(
[#text("If ")#mi("{f \\in \\Omega^0({\\bf R}^d_E)}")#text(" is a continuously differentiable scalar field, then ")#mi("{{\\mathcal L}_Z f = Z \\neg df}")#text(" is just the directional derivative of ")#mi("{f}")#text(" along ")#mi("{Z}")#text(": ")#mi("{{\\mathcal L}_Z f = Z^i \\partial_i f}")#text(".")],
[#text("If ")#mi("{\\theta \\in \\Omega^1({\\bf R}^d_E)}")#text(" is a continuously differentiable ")#mi("{1}")#text("-form, then ")#mi("{{\\mathcal L}_Z \\theta}")#text(" is the ")#mi("{1}")#text("-form")

#metadata(none) <tao-c8b1a1a3e6bcee8660ad>

#tao-aligned(keep: true)[


#tao-math("({\\mathcal L}_Z \\theta)_i  & = Z^j(\\partial_j \\theta_i - \\partial_i \\theta_j) + \\partial_i (Z^j \\theta_j)", block: true, numbering: n => [#text("(20)")])



#tao-math(" & = Z^j \\partial_j \\theta_i + (\\partial_i Z^j) \\theta_j.", block: true)
]],
[#text("If ")#mi("{\\omega \\in \\Omega^2({\\bf R}^d_E)}")#text(" is a continuously differentiable ")#mi("{2}")#text("-form, then ")#mi("{{\\mathcal L}_Z \\omega}")#text(" is the ")#mi("{2}")#text("-form")

#tao-aligned(keep: true)[


#tao-math("({\\mathcal L}_Z \\omega)_{ij}  & = Z^k(\\partial_k \\omega_{ij} - \\partial_i \\omega_{kj} + \\partial_j \\omega_{ki}) + \\partial_i (Z^k \\omega_{kj}) - \\partial_j (Z^k \\omega_{ki})", block: true)



#tao-math(" & = Z^k \\partial_k \\omega_{ij} + (\\partial_i Z^k) \\omega_{kj} + (\\partial_j Z^k) \\omega_{ik}.", block: true)
]]
)

#text("One can interpret the Lie derivative as the infinitesimal version of pullback:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-82ebadafdeec2df737e5>#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" be smooth and bounded (so that ")#mi("{u(t)}")#text(" can be viewed as a smooth vector field on ")#mi("{{\\bf R}^d_E}")#text(" for each ")#mi("{t}")#text("), and let ")#mi("{X: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" be a trajectory map. If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" is a smooth ")#mi("{k}")#text("-form, show that")

#align(center)[#tao-fit-display[#mitex("\\partial_t (X(t)^* \\omega) = X(t)^*( {\\mathcal L}_{u(t)} \\omega ).")]]

#text("More generally, if ")#mi("{\\omega(t) \\in \\Omega^k({\\bf R}^d_E)}")#text(" is a smooth ")#mi("{k}")#text("-form that varies smoothly in ")#mi("{t}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\partial_t (X(t)^* \\omega) = X(t)^*( {\\mathcal D}_t \\omega )")]]

#text("where ")#mi("{{\\mathcal D}_t}")#text(" denotes the ")#emph[#text("material Lie derivative")]

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_t := \\partial_t + {\\mathcal L}_{u(t)}.")]]
]

#text("Note that the material Lie derivative specialises to the material derivative when applied to scalar fields. The above exercise shows that the trajectory map intertwines the ordinary time derivative ")#mi("{\\partial_t}")#text(" with the material (Lie) derivative.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" If one lets ")#mi("{(t,x) \\mapsto \\exp(tZ) x}")#text(" be the trajectory map associated to a time-independent vector field ")#mi("{Z}")#text(" with initial condition ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(" (thus ")#mi("{\\exp(0 Z) x = x}")#text(" and ")#mi("{\\frac{d}{dt} \\exp(tZ) x = Z( \\exp(tZ) x)}")#text(", then the above exercise shows that ")#mi("{{\\mathcal L}_Z \\omega = \\frac{d}{dt} \\exp(tZ)_* \\omega|_{t=0}}")#text(" for any differential form ")#mi("{\\omega}")#text(". This can be used as an alternate definition of the Lie derivative ")#mi("{{\\mathcal L}_Z}")#text(" (and has the advantage of readily extending to other tensors than differential forms, for which the Cartan formula is not available).")
]

#text("The Lie derivative behaves very well with respect to exterior product and exterior derivative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>#text(" Let ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" be continuously differentiable, and let ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E), \\alpha \\in \\Omega^l({\\bf R}^d_E)}")#text(" also be continuously differentiable. Establish the Leibniz rule")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z( \\omega \\wedge \\alpha ) = ({\\mathcal L}_Z \\omega) \\wedge \\alpha + \\omega \\wedge {\\mathcal L}_Z \\omega.")]]

#text("If ")#mi("{\\omega}")#text(" is twice continuously differentiable, also establish the commutativity")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z d \\omega = d {\\mathcal L}_Z \\omega")]]

#text("of exterior derivative and Lie derivative.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-4b4f75a672c7be48bbe3>#text(" Let ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" be continuously differentiable. Show that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z d\\mathrm{vol}_E = \\mathrm{div}(Z) d\\mathrm{vol}_E")]]

#text("where ")#mi("{\\mathrm{div}(Z) := \\partial_i Z^i}")#text(" is the divergence of ")#mi("{Z}")#text(". Use this and Exercise ")#link(<tao-82ebadafdeec2df737e5>)[#text("17")]#text(" to give an alternate proof of Lemma ")#link(<tao-fe61da860649d1497075>)[#text("3")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-fdd33982464b25638709>#text(" Let ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" be continuously differentiable. For any smooth compactly supported volume form ")#mi("{\\omega}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} {\\mathcal L}_Z \\omega = 0.")]]

#text("Conclude in particular that if ")#mi("{Z}")#text(" is divergence-free then")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} ({\\mathcal L}_Z f) d\\mathrm{vol}_E = 0")]]

#text("for any ")#mi("{f\\in C^\\infty_c({\\bf R}^d_E \\rightarrow {\\bf R})}")#text(".")
]

#text("The Lie derivative ")#mi("{{\\mathcal L}_Z W \\in \\Gamma(T {\\bf R}^d_E) }")#text(" of a continuously differentiable vector field ")#mi("{W \\in\\Gamma(T {\\bf R}^d_E)}")#text(" is defined in coordinates as")

#align(center)[#tao-fit-display[#mitex("({\\mathcal L}_Z W)^i := Z^j \\partial_j W^i - W^j \\partial_j Z^i")]]

#text("and the Lie derivative ")#mi("{{\\mathcal L}_Z g}")#text(" of a continuously differentiable rank ")#mi("{(0,2)}")#text(" tensor ")#mi("{g}")#text(" is defined in coordinates as")

#align(center)[#tao-fit-display[#mitex("({\\mathcal L}_Z g)_{ij} := Z^k \\partial_k g_{ij} + (\\partial_i Z^k) g_{kj} + (\\partial_j Z^k) g_{ik}.")]]

#text("Thus for instance the Lie derivative of the Euclidean metric ")#mi("{\\eta_{ij}}")#text(" is expressible in coordinates as ")#metadata(none) <tao-c46ec05870925e250269>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("({\\mathcal L}_Z \\eta)_{ij} = \\partial_i Z^j + \\partial_j Z^i")]]

#text("(compare with the ")#emph[#text("deformation tensor")]#text(" used in ")#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")[#text("Notes 0")]#text(").")#linebreak()#text(" We have similar properties to Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("19")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-388b9bb14384380aa9ef>#text(" Let ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" be continuously differentiable.")

#list(
[#text("(i) If ")#mi("{\\omega \\in \\Omega^k({\\bf R}^d_E)}")#text(" and ")#mi("{W_1,\\dots,W_k \\in \\Gamma(T {\\bf R}^d_E)}")#text(" are continuously differentiable, establish the Leibniz rule")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal L}_Z(\\omega(W_1,\\dots,W_k))  & = ({\\mathcal L}_Z \\omega)(W_1,\\dots,W_k)", block: true)



#tao-math(" & + \\sum_{i=1}^k \\omega(W_1,\\dots,W_{i-1}, {\\mathcal L}_Z W_i, W_{i+1},\\dots,W_k)", block: true)
]

#text("If ")#mi("{k \\geq 1}")#text(", and ")#mi("{W \\in \\Gamma(T {\\bf R}^d_E)}")#text(", establish the variant Leibniz rule")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z( W \\neg \\omega ) = ({\\mathcal L}_Z W) \\neg \\omega + W \\neg {\\mathcal L}_Z \\omega.")]]],
[#text("(ii) If ")#mi("{g}")#text(" is a continuously differentiable rank ")#mi("{(0,2)}")#text(" tensor and ")#mi("{W_1,W_2 \\in \\Gamma(T {\\bf R}^d_E)}")#text(" are continuously differentiable, establish the Leibniz rule")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal L}_Z( g(W_1,W_2) )  & = ({\\mathcal L}_Z g)(W_1,W_2)", block: true)



#tao-math(" & + g({\\mathcal L}_Z W_1,W_2) + g(W_1, {\\mathcal L}_Z W_2);", block: true)
]

#text("similarly, for ")#mi("{W \\in \\Gamma(T {\\bf R}^d_E)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z( g \\cdot W ) = ({\\mathcal L}_Z g) \\cdot W + g \\cdot ({\\mathcal L}_Z W).")]]],
[#text("(iii) Establish the analogue of Exercise ")#link(<tao-82ebadafdeec2df737e5>)[#text("17")]#text(" in which the differential form ")#mi("{\\omega}")#text(" is replaced by a vector field ")#mi("{W}")#text(" or a rank ")#mi("{(0,2)}")#text("-tensor ")#mi("{g}")#text(".")],
[#text("(iv) If ")#mi("{Z}")#text(" is divergence-free, show that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z *T = * {\\mathcal L}_Z T")]]

#text("whenever ")#mi("{T}")#text(" is a continuously differential scalar field, vector field, ")#mi("{d-1}")#text("-form, or ")#mi("{d}")#text("-form on ")#mi("{{\\bf R}^d_E}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" If ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" is continuously differentiable, establish the identity")

#align(center)[#tao-fit-display[#mitex("Y^* {\\mathcal L}_Z \\phi = {\\mathcal L}_{Y^* Z} Y^* \\phi")]]

#text("whenever ")#mi("{\\phi}")#text(" is a continuously differentiable differential form, vector field, or metric tensor.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-ef09ccb31cac21b7e834>#text(" If ")#mi("{Z,W \\in \\Gamma(T {\\bf R}^d_E)}")#text(" are smooth, define the ")#emph[#text("Lie bracket")]#text(" ")#mi("{[Z,W] \\in \\Gamma(T {\\bf R}^d_E)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("[Z,W] := {\\mathcal L}_Z W.")]]

#text("Establish the anti-symmetry ")#mi("{[Z,W] = -[W,Z]}")#text(" (so in particular ")#mi("{[Z,Z]=0}")#text(") and the ")#link("https://en.wikipedia.org/wiki/Jacobi_identity")[#text("Jacobi identity")]

#align(center)[#tao-fit-display[#mitex("[[Z_1,Z_2],Z_3] + [[Z_2,Z_3],Z_1] + [[Z_3,Z_1],Z_2] = 0,")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_{[Z,W]} \\phi = {\\mathcal L}_Z {\\mathcal L}_W \\phi - {\\mathcal L}_W {\\mathcal L}_Z \\phi")]]

#text("whenever ")#mi("{Z,W,Z_1,Z_2,Z_3 \\in \\Gamma(T {\\bf R}^d_E)}")#text(" are smooth, and ")#mi("{\\phi}")#text(" is a smooth differentiable form, vector field, or metric tensor.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Formulate a definition for the Lie derivative ")#mi("{{\\mathcal L}_Z T}")#text(" of a (continuously differentiable) rank ")#mi("{(k,l)}")#text(" tensor field ")#mi("{T}")#text(" along a vector field ")#mi("{Z}")#text(" that generalises the Lie derivative of differential forms, vector fields, and Riemannian metrics. Argue why your definition is the natural one.")
]

#heading(level: 1)[#strong[#text(" — 2. The Euler equations in differential geometry notation — ")]]

#text("Now we write the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" in differential geometry language developed in the above section. This will make it relatively painless to change coordinates. As in the rest of this set of notes, we work formally, assuming that all fields are smooth enough to justify the manipulations below.")#linebreak()#text(" The Euler equations involve a time-dependent scalar field ")#mi("{p(t)}")#text(", which can be viewed as an element of ")#mi("{\\Omega^0({\\bf R}^d_E)}")#text(", and a time-dependent velocity field ")#mi("{u(t)}")#text(", which can be viewed as an element of ")#mi("{\\Gamma(T {\\bf R}^d_E)}")#text(". The second of the Euler equations simply asserts that this vector field is divergence-free:")

#align(center)[#tao-fit-display[#mitex("\\mathrm{div} u(t) = 0")]]

#text("or equivalently (by Exercise ")#link(<tao-4b4f75a672c7be48bbe3>)[#text("20")]#text(" and the definition of material Lie derivative ")#mi("{{\\mathcal D}_t = \\partial_t + {\\mathcal L}_u}")#text(")")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_t d\\mathrm{vol}_E = 0.")]]

#text("For the first equation, it is convenient to work instead with the ")#emph[#text("covelocity field")]#text(" ")#mi("{v(t) \\in \\Omega^1({\\bf R}^d_E)}")#text(", formed by applying the Euclidean musical isomorphism to ")#mi("{u(t)}")#text(":")

#align(center)[#tao-fit-display[#mitex("v(t) = \\eta \\cdot u(t).")]]

#text("In coordinates, we have ")#mi("{v_i = \\eta_{ij} u^j}")#text(", thus ")#mi("{v_i = u^i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(". The Euler equations can then be written in coordinates as")

#align(center)[#tao-fit-display[#mitex("\\partial_t v_i + u^j \\partial_j v_i = -\\partial_i p.")]]

#text("The left-hand side is close to the ")#mi("{i}")#text(" component of the material Lie derivative ")#mi("{{\\mathcal D}_t v = \\partial_t v + {\\mathcal L}_u v}")#text(" of ")#mi("{v}")#text(". Indeed, from ")#link(<tao-c8b1a1a3e6bcee8660ad>)[#text("(20)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("({\\mathcal D}_t v)_i = \\partial_t v_i + u^j \\partial_j v_i + (\\partial_i u^j) v_j")]]

#text("and so the first Euler equation becomes")

#align(center)[#tao-fit-display[#mitex("({\\mathcal D}_t v)_i = - \\partial_i p + (\\partial_i u^j) v_j.")]]

#text("Since ")#mi("{u^j = v_j}")#text(", we can express the right-hand side as a total derivative ")#mi("{- \\partial_i \\tilde p}")#text(", where ")#mi("{\\tilde p}")#text(" is the ")#emph[#text("modified pressure")]

#align(center)[#tao-fit-display[#mitex("\\tilde p := p - \\frac{1}{2} u^j v_j = p - \\frac{1}{2} \\eta(u,u).")]]

#text("We thus see that the Euler equations can be transformed to the system ")#metadata(none) <tao-90a8cfaded168905ead3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\mathcal D}_t v = - d \\tilde p")]]

#metadata(none) <tao-8f60b972a639ce51c727>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("v = \\eta \\cdot u")]]

#metadata(none) <tao-71cd2ad5726ab772c084>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("{\\mathcal D}_t d\\mathrm{vol}_E = 0.")]]

#text("Using the Cartan formula ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("(19)")]#text(", one can also write ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(" as ")#metadata(none) <tao-b8a983e128b2b1b8ece6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_t v + u \\neg dv = - d p^{\\prime}")]]

#text("where ")#mi("{p^{\\prime}}")#text(" is another modification of the pressure:")

#align(center)[#tao-fit-display[#mitex("p^{\\prime} = \\tilde p + u \\neg v = p + \\frac{1}{2} \\eta(u,u).")]]

#text("In coordinates, ")#link(<tao-b8a983e128b2b1b8ece6>)[#text("(25)")]#text(" becomes ")#metadata(none) <tao-71e10d2b6650b9b78391>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\partial_t v_j + u^i (\\partial_i v_j - \\partial_j v_i) = - \\partial_i p^{\\prime}.")]]

#text("One advantage of the formulation ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text("–")#link(<tao-71cd2ad5726ab772c084>)[#text("(24)")]#text(" is that one can pull back by an arbitrary diffeomorphic change of coordinates (both time-dependent and time-independent), with the only things potentially changing being the material Lie derivative ")#mi("{{\\mathcal D}_t}")#text(", the metric ")#mi("{\\eta}")#text(", and the volume form ")#mi("{d\\mathrm{vol}_E}")#text(". (Another, related, advantage is that this formulation readily suggests an extension to more general Riemannian manifolds, by replacing ")#mi("{\\eta}")#text(" with a general Riemannian metric and ")#mi("{d\\mathrm{vol}_E}")#text(" with the associated volume form, without the need to explicitly introduce other Riemannian geometry concepts such as ")#link("https://en.wikipedia.org/wiki/Covariant_derivative")[#text("covariant derivatives")]#text(" or ")#link("https://en.wikipedia.org/wiki/Christoffel_symbols")[#text("Christoffel symbols")]#text(".)")#linebreak()#text(" For instance, suppose ")#mi("{d=3}")#text(", and we wish to view the Euler equations in cylindrical coordinates ")#mi("{(r,\\theta,z) \\in [0,+\\infty) \\times {\\bf R}/2\\pi {\\bf Z} \\times {\\bf R}}")#text(", thus pulling back under the time-independent map ")#mi("{Y: [0,+\\infty) \\times {\\bf R}/2\\pi {\\bf Z} \\times {\\bf R} \\rightarrow {\\bf R}^3_E}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("Y(r, \\theta,z) := (r \\cos \\theta, r \\sin \\theta, z ).")]]

#text("Strictly speaking, this is not a diffeomorphism due to singularities at ")#mi("{r=0}")#text(", but we ignore this issue for now by only working away from the ")#mi("{z}")#text(" axis ")#mi("{r=0}")#text(". As is well known, the metric ")#mi("{d\\eta^2 = (dx^1)^2 + (dx^2)^2 + (dx^3)^2}")#text(" pulls back under this change of coordinates ")#mi("{x^1 = r \\cos \\theta, x^2 = r \\sin \\theta, z = x^3}")#text(" as")

#align(center)[#tao-fit-display[#mitex("d(Y^* \\eta)^2 = dr^2 + r^2 d\\theta^2 + dz^2,")]]

#text("thus the pullback metric ")#mi("{Y^* \\eta}")#text(" is diagonal in ")#mi("{r,\\theta,z}")#text(" coordinates with entries")

#align(center)[#tao-fit-display[#mitex("(Y^* \\eta)_{rr} = 1; \\quad (Y^* \\eta)_{\\theta \\theta} = r^2; \\quad (Y^* \\eta)_{zz} = 1.")]]

#text("The volume form ")#mi("{d\\mathrm{vol}_E = dx \\wedge dy \\wedge dz}")#text(" similarly pulls back to the familiar cylindrical coordinate volume form")

#align(center)[#tao-fit-display[#mitex("Y^* d\\mathrm{vol}_E = r dr \\wedge d \\theta \\wedge dz.")]]

#text("If (by slight abuse of notation) we write the components of ")#mi("{Y^* u}")#text(" as ")#mi("{u^r, u^z, u^\\theta}")#text(", and the components of ")#mi("{Y^* v}")#text(" as ")#mi("{v_r, v_z, v_\\theta}")#text(", then the second equation ")#link(<tao-8f60b972a639ce51c727>)[#text("(23)")]#text(" in our current formulation of the Euler equations now becomes ")#metadata(none) <tao-2938b1c9e8fdf5518d26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("v_r = u^r; \\quad v_\\theta = r^2 u^\\theta; \\quad v_z = u^z")]]

#text("and the third equation ")#link(<tao-71cd2ad5726ab772c084>)[#text("(24)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_u ( r dr \\wedge d \\theta \\wedge dz ) = 0")]]

#text("which by the product rule and Exercise ")#link(<tao-4b4f75a672c7be48bbe3>)[#text("20")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_u(r) + r \\mathrm{div} u = 0")]]

#text("or after expanding in coordinates")

#align(center)[#tao-fit-display[#mitex("u^r + r (\\partial_r u^r + \\partial_\\theta u^\\theta + \\partial_z u^z) = 0.")]]

#text("If one substitutes ")#link(<tao-2938b1c9e8fdf5518d26>)[#text("(27)")]#text(" into ")#link(<tao-71e10d2b6650b9b78391>)[#text("(26)")]#text(" in the ")#mi("{r,\\theta,z}")#text(" coordinates to eliminate the ")#mi("{v}")#text(" variables, we thus see that the cylindrical coordinate form of the Euler equations is ")#metadata(none) <tao-4b005b229674230805ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\partial_t u^r + u^\\theta (\\partial_\\theta u^r - \\partial_r(r^2 u^\\theta)) + u^z (\\partial_z u^r - \\partial_r u^z) = - \\partial_r p^{\\prime}")]]

#metadata(none) <tao-90cc68830f79138d5662>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\partial_t (r^2 u^\\theta) + u^r (\\partial_r (r^2 u^\\theta) - \\partial_\\theta u^r) + u^z (\\partial_z (r^2 u^\\theta) - \\partial_\\theta u^z) = - \\partial_\\theta p^{\\prime}")]]

#metadata(none) <tao-3a372dc0cd1b0f5fcae7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\partial_t u^z + u^r (\\partial_r u^z - \\partial_z u^r) + u^\\theta (\\partial_\\theta u^r - \\partial_z (r^2 u^\\theta)) = - \\partial_z p^{\\prime}")]]

#metadata(none) <tao-fc09e87f334373bdc93f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("u^r + r (\\partial_r u^r + \\partial_\\theta u^\\theta + \\partial_z u^z) = 0.")]]

#text("One should compare how readily one can derive these equations using the differential geometry formalism with the more pedestrian aproach using the chain rule:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Starting with a smooth solution ")#mi("{(u,p)}")#text(" to the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" in ")#mi("{{\\bf R}^3_L}")#text(", and transforming to cylindrical coordinates ")#mi("{(r,\\theta,z)}")#text(", establish the chain rule formulae")

#tao-aligned(keep: true)[


#tao-math("u^1  & = u^r \\cos \\theta - r u^\\theta \\sin \\theta", block: true)



#tao-math("u^2  & = u^r \\sin \\theta + r u^\\theta \\cos \\theta", block: true)



#tao-math("u^3  & = u^z", block: true)



#tao-math("\\partial_1  & = \\cos \\theta \\partial_r - \\frac{\\sin \\theta}{r} \\partial_\\theta", block: true)



#tao-math("\\partial_2  & = \\sin \\theta \\partial_r + \\frac{\\cos \\theta}{r} \\partial_\\theta", block: true)



#tao-math("\\partial_3  & = \\partial_z", block: true)
]

#text("and use this and the identity")

#align(center)[#tao-fit-display[#mitex("p^{\\prime} := p + \\frac{1}{2} (u^1 u^1 + u^2 u^2 + u^3 u^3)")]]

#text("to rederive the system ")#link(<tao-4b005b229674230805ec>)[#text("(28)")]#text("–")#link(<tao-fc09e87f334373bdc93f>)[#text("(31)")]#text(" (away from the ")#mi("{z}")#text(" axis) without using the language of differential geometry.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=977488")[#text("Turkington coordinates")]#text(" ")#mi("{(x,y,\\zeta) \\in {\\bf R} \\times [0,+\\infty) \\times {\\bf R}/2\\pi {\\bf Z}}")#text(" are a variant of cylindrical coordinates ")#mi("{(r,\\theta,z) \\in [0,+\\infty) \\times {\\bf R}/2\\pi{\\bf Z} \\times {\\bf R}}")#text(", defined by the formulae")

#align(center)[#tao-fit-display[#mitex("(x,y,\\zeta) := (z,r^2/2, \\theta);")]]

#text("the advantage of these coordinates are that the map from Cartesian coordinates ")#mi("{(x^1,x^2,x^3)}")#text(" to Turkington coordinates ")#mi("{(x,y,z)}")#text(" is volume preserving. Show that in these coordinates, the Euler equations become")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^x + u^y (\\partial_y u^x - \\partial_x(\\frac{u^y}{2y})) + u^\\zeta (\\partial_\\zeta u^x - \\partial_x(2y u^\\zeta))  & = - \\partial_x p^{\\prime}", block: true)



#tao-math("\\partial_t (\\frac{u^y}{2y}) + u^x (\\partial_x (\\frac{u^y}{2y}) - \\partial_y u^x) + u^\\zeta (\\partial_\\zeta (\\frac{u^y}{2y}) - \\partial_y u_\\zeta)  & = - \\partial_y p^{\\prime}", block: true)



#tao-math("\\partial_t (2yu^\\zeta) + u^x (\\partial_x (2yu^\\zeta) - \\partial_\\zeta u^x) + u^y (\\partial_y (2yu_\\zeta) - \\partial_\\zeta (\\frac{u^y}{2y}))  & = - \\partial_\\zeta p^{\\prime}", block: true)



#tao-math("\\partial_x u^x + \\partial_y u^y + \\partial_\\zeta u^\\zeta  & = 0.", block: true)
]

#text("(These coordinates are particularly useful for studying solutions to Euler that are “axisymmetric with swirl”, in the sense that the fields ")#mi("{u^x, u^y, u^z, p^{\\prime}}")#text(" do not depend on the ")#mi("{\\zeta}")#text(" variable, so that all the terms involving ")#mi("{\\partial_\\zeta}")#text(" vanish; one can specialise further to the case of solutions that are “axisymmetric without swirl”, in which case ")#mi("{u_\\zeta}")#text(" also vanishes.)")
]

#text("We can use the differential geometry formalism to formally verify the conservation laws of the Euler equation. We begin with conservation of energy")

#align(center)[#tao-fit-display[#tao-math("E(t) := \\frac{1}{2} \\int_{{\\bf R}^d_E} \\left|u\\right|^2\\ d\\mathrm{vol}_E = \\frac{1}{2} \\int_{{\\bf R}^d_E} (g^{-1} \\cdot v) \\neg v\\ d\\mathrm{vol}_E.", block: true)]]

#text("Formally differentiating this in time (and noting that the form ")#mi("{(g^{-1} \\cdot w) \\neg v= g^{ij} v_i w_j}")#text(" is symmetric in ")#mi("{v,w}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) = \\int_{{\\bf R}^d_E} (g^{-1} \\cdot v) \\neg \\partial_t v \\ d\\mathrm{vol}_E = \\int_{{\\bf R}^d_E} u \\neg \\partial_t v\\ d\\mathrm{vol}(E).")]]

#text("Using ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(", we can write")

#align(center)[#tao-fit-display[#mitex("u \\neg \\partial_t v = - u \\neg {\\mathcal L}_u v - u \\neg dp^{\\prime}.")]]

#text("From the Cartan formula ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("(19)")]#text(" one has ")#mi("{u \\neg dp^{\\prime} = {\\mathcal L}_u p^{\\prime}}")#text("; from Exercise ")#link(<tao-ef09ccb31cac21b7e834>)[#text("24")]#text(" one has ")#mi("{{\\mathcal L}_u u = 0}")#text(", and hence by the Leibniz rule (Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("19")]#text("(i)) we thus can write ")#mi("{u \\neg \\partial_t v}")#text(" as a total derivative:")

#align(center)[#tao-fit-display[#mitex("u \\neg \\partial_t v = {\\mathcal L}_u ( - u \\neg v - p^{\\prime} ).")]]

#text("From Exercise ")#link(<tao-fdd33982464b25638709>)[#text("21")]#text(" we thus formally obtain the conservation law ")#mi("{\\partial_t E}")#text(".")#linebreak()#text(" Now suppose that ")#mi("{Z \\in \\Gamma(T {\\bf R}^d_E)}")#text(" is a time-independent vector field that is a ")#link("https://en.wikipedia.org/wiki/Killing_vector_field")[#text("Killing vector field")]#text(" for the Euclidean metric ")#mi("{\\eta}")#text(", by which we mean that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z \\eta = 0.")]]

#text("Taking traces in ")#link(<tao-c46ec05870925e250269>)[#text("(21)")]#text(", this implies in particular that ")#mi("{Z}")#text(" is divergence-free, or equivalently")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z d\\mathrm{vol}_E = 0.")]]

#text("(Geometrically, this implication arises because the volume form ")#mi("{d\\mathrm{vol}_E}")#text(" can be constructed from the Euclidean metric ")#mi("{\\eta}")#text(" (up to a choice of orientation).) Consider the formal quantity")

#align(center)[#tao-fit-display[#mitex("M(t) := \\int_{{\\bf R}^d_E} (Z \\neg v)\\ d\\mathrm{vol}_E.")]]

#text("As ")#mi("{v}")#text(" is the only time-dependent quantity here, we may formally differentiate to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t M(t) = \\int_{{\\bf R}^d_E} (Z \\neg \\partial_t v)\\ d\\mathrm{vol}_E")]]

#text("Using ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(", the left-hand side is")

#align(center)[#tao-fit-display[#mitex("- \\int_{{\\bf R}^d_E} (Z \\neg {\\mathcal L}_u v) + (Z \\neg dp^{\\prime})\\ d\\mathrm{vol}_E.")]]

#text("By Cartan’s formula, ")#mi("{Z \\neg dp^{\\prime}}")#text(" is a total derivative ")#mi("{{\\mathcal L}_Z p^{\\prime}}")#text(", and hence this contribution to the integral formally vanishes as ")#mi("{Z}")#text(" is divergence-free. The quantity ")#mi("{Z \\neg {\\mathcal L}_u v}")#text(" can be written using the Leibniz rule as the difference of the total derivative ")#mi("{{\\mathcal L}_u (Z \\neg v)}")#text(" and the quantity ")#mi("{{\\mathcal L}_u Z \\neg v}")#text(". The former quantity also gives no contribution to the integral as ")#mi("{u}")#text(" is divergence free, thus")

#align(center)[#tao-fit-display[#mitex("\\partial_t M(t) = \\int_{{\\bf R}^d_E} {\\mathcal L}_u Z \\neg v\\ d\\mathrm{vol}_E.")]]

#text("By Exercise ")#link(<tao-ef09ccb31cac21b7e834>)[#text("24")]#text(", we have ")#mi("{{\\mathcal L}_u Z = - {\\mathcal L}_Z u = - {\\mathcal L}_Z(\\eta^{-1} \\cdot v)}")#text(". Since ")#mi("{\\eta}")#text(" (and hence ")#mi("{\\eta^{-1}}")#text(") is annihilated by ")#mi("{{\\mathcal L}_Z}")#text(", and the form ")#mi("{(\\eta^{-1} \\cdot v) \\neg w = \\eta^{ij} v_i w_j}")#text(" is symmetric in ")#mi("{v,w}")#text(", we can express ")#mi("{{\\mathcal L}_Z(\\eta^{-1} \\cdot v) \\neg v}")#text(" as a total derivative")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_Z(\\eta^{-1} \\cdot v) \\neg v = \\frac{1}{2} {\\mathcal L}_Z ( (\\eta^{-1} \\cdot v) \\neg v ),")]]

#text("and so this integral also vanishes. Thus we obtain the conservation law ")#mi("{\\partial_t M(t) = 0}")#text(". If we set the Killing vector field ")#mi("{Z}")#text(" equal to the constant vector field ")#mi("{\\frac{d}{dx^i}}")#text(" for some ")#mi("{i=1,\\dots,d}")#text(", we obtain conservation of the momentum components")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} u^i\\ d\\mathrm{vol}_E")]]

#text("for ")#mi("{i=1,\\dots,d}")#text("; if we instead set the Killing vector field ")#mi("{Z}")#text(" equal to the rotation vector field ")#mi("{x^i \\frac{d}{dx^j} - x^j \\frac{d}{dx^i}}")#text(") (which one can easily verify to be Killing using ")#link(<tao-c46ec05870925e250269>)[#text("(21)")]#text(") we obtain conservation of the angular momentum components")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_E} x^i u^j - x^j u^i\\ d\\mathrm{vol}_E")]]

#text("for ")#mi("{i,j =1,\\dots,d}")#text(". Unfortunately, this essentially exhausts the supply of Killing vector fields:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{Z}")#text(" be a smooth Killing vector field of the Euclidean metric ")#mi("{\\eta}")#text(". Show that ")#mi("{Z}")#text(" is a linear combination (with real coefficients) of the constant vector fields ")#mi("{\\frac{d}{dx^i}}")#text(", ")#mi("{i=1,\\dots,d}")#text(" and the rotation vector fields ")#mi("{x^i \\frac{d}{dx^j} - x^j \\frac{d}{dx^i}}")#text(", ")#mi("{i,j=1,\\dots,d}")#text(". (Hint: use ")#link(<tao-c46ec05870925e250269>)[#text("(21)")]#text(" to show that all the second derivatives of components of ")#mi("{Z}")#text(" vanish.)")
]

#text("The ")#emph[#text("vorticity ")#mi("{2}")#text("-form")]#text(" ")#mi("{\\omega(t) \\in \\Omega^2( {\\bf R}^d_E)}")#text(" is defined as the exterior derivative of the covelocity:")

#align(center)[#tao-fit-display[#mitex("{}\\omega := dv.")]]

#text("It already made an appearance in ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("Notes 3 from the previous quarter")]#text(". Taking exterior derivatives of ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(" using ")#link(<tao-9414886b1ebf025db067>)[#text("(10)")]#text(" and Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("19")]#text(" we obtain the appealingly simple ")#emph[#text("vorticity equation")]#text(" ")#metadata(none) <tao-9b65d81e40811c75a092>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("{\\mathcal D}_t \\omega = 0.")]]

#linebreak()#text(" In two and three dimensions we may take the Hodge dual ")#mi("{*\\omega}")#text(" of the velocity ")#mi("{2}")#text("-form to obtain either a scalar field (in dimension ")#mi("{d=2}")#text(") or a vector field (in dimension ")#mi("{d=3}")#text("), and then Exercise ")#link(<tao-388b9bb14384380aa9ef>)[#text("22")]#text("(iv) implies that ")#metadata(none) <tao-f77f484ce99781cbf892>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("{\\mathcal D}_t *\\omega = 0.")]]

#text("In two dimensions, this gives us a lot of conservation laws, since one can apply the scalar chain rule to then formally conclude that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_t F( *\\omega) = 0")]]

#text("for any ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(", which upon integration on ")#mi("{{\\bf R}^2_E}")#text(" using Exercise ")#link(<tao-fdd33982464b25638709>)[#text("21")]#text(" gives the conservation law")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\bf R}^2_E} F(*\\omega)\\ d\\mathrm{vol}_E = 0")]]

#text("for any such function ")#mi("{F}")#text(". Thus for instance the ")#mi("{L^p({\\bf R}^2_E \\rightarrow {\\bf R})}")#text(" norms of ")#mi("{*\\omega}")#text(" are formally conserved for every ")#mi("{0 < p < \\infty}")#text(", and hence also for ")#mi("{p=\\infty}")#text(" by a limiting argument, recovering Proposition 24 from ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("Notes 3 of the previous quarter")]#text(".")#linebreak()#text(" In three dimensions there is also an interesting conservation law involving the vorticity. Observe that the wedge product ")#mi("{v \\wedge \\omega}")#text(" of the covelocity and the vorticity is a ")#mi("{3}")#text("-form and can thus be integrated over ")#mi("{{\\bf R}^3_E}")#text(". The ")#link("https://en.wikipedia.org/wiki/Hydrodynamical_helicity")[#text("helicity")]#text(" ")#metadata(none) <tao-933c53c574d35179d3f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("H(t) := \\int_{{\\bf R}^3_E} v(t) \\wedge \\omega(t)")]]

#text("is a formally conserved quantity of the Euler equations. Indeed, formally differentiating and using Exercise ")#link(<tao-fdd33982464b25638709>)[#text("21")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t H(t) = \\int_{{\\bf R}^3_E} {\\mathcal D}_t ( v \\wedge \\omega).")]]

#text("From the Leibniz rule and ")#link(<tao-9b65d81e40811c75a092>)[#text("(32)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_t ( v \\wedge \\omega) = ({\\mathcal D}_t v) \\wedge \\omega.")]]

#text("Applying ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(" we can write this expression as ")#mi("{-d\\tilde p \\wedge \\omega}")#text(". From ")#link(<tao-9414886b1ebf025db067>)[#text("(10)")]#text(" we have ")#mi("{d\\omega=0}")#text(", hence this expression is also a total derivative ")#mi("{-d(\\tilde p \\omega)}")#text(". From Stokes’ theorem ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(14)")]#text(" we thus formally obtain the conservation of helicity: ")#mi("{H(t) = H(0)}")#text("; this was first observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=128195")[#text("by Moreau")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Formally verify the conservation of momentum, angular momentum, and helicity directly from the original form ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" of the Euler equations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" In even dimensions ")#mi("{d \\geq 2}")#text(", show that the integral ")#mi("{\\int_{{\\bf R}^d_E} \\bigwedge^{d/2} \\omega(t)}")#text(" (formed by taking the exterior product of ")#mi("{d/2}")#text(" copies of ")#mi("{\\omega}")#text(") is conserved by the flow, while in odd dimensions ")#mi("{d \\geq 3}")#text(", show that the generalised helicity ")#mi("{\\int_{{\\bf R}^d_E} v(t) \\wedge \\bigwedge^{\\frac{d-1}{2}} \\omega(t)}")#text(" is conserved by the flow. (This observation is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=745013")[#text("due to Denis Serre")]#text(", as well as unpublished work of Tartar.)")
]

#text("As it turns out, there are no further conservation laws for the Euler equations in Eulerian coordinates that are linear or quadratic integrals of the velocity field and its derivatives, at least in three dimensions; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=555135")[#text("this paper of Denis Serre")]#text(". In particular, the Euler equations are not believed to be completely integrable. (But there are a few more conserved integrals of motion in the Lagrangian formalism; see Exercise ")#link(<tao-b5838798533a5a82226b>)[#text("41")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^3_E \\rightarrow {\\bf R}^3_E}")#text(" be a smooth solution to the Euler equations in three dimensions ")#mi("{{\\bf R}^3_E}")#text(", let ")#mi("{*\\omega}")#text(" be the vorticity vector field, and let ")#mi("{f: [0,T) \\times {\\bf R}^3_E \\rightarrow {\\bf R}}")#text(" be an arbitrary smooth scalar field. Establish ")#emph[#text("Ertel’s theorem")]

#align(center)[#tao-fit-display[#mitex("D_t( *\\omega \\cdot \\nabla f ) = *\\omega \\cdot \\nabla(D_t f).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Clebsch variables)")]#text(" ")#metadata(none) <tao-19d8280e9084dfabe3f4>#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" be a smooth solution to the Euler equations. Suppose that at time zero, the covelocity ")#mi("{v(0)}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("v(0) = \\sum_{j=1}^k \\theta_j(0) d \\varphi_j(0)")]]

#text("for some smooth scalar fields ")#mi("{\\theta_j(0), \\varphi_j(0): {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(".")

#list(
[#text("(i) Show that at all subsequent times ")#mi("{t}")#text(", the covelocity takes the form")

#align(center)[#tao-fit-display[#mitex("v(t) = \\sum_{j=1}^k \\theta_j(t) d \\varphi_j(t) + d n(t)")]]

#text("where ")#mi("{\\theta_j(t), \\varphi_j(t), n(t): {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" are smooth scalar fields obeying the transport equations")

#align(center)[#tao-fit-display[#mitex("D_t \\theta_j(t) = D_t \\varphi_j(t) = 0.")]]],
[#text("(ii) Suppose that we are in the classical case ")#mi("{k=1,d=3}")#text(" initially ")#link("https://eudml.org/doc/147740")[#text("studied by Clebsch in 1859")]#text(". (The extension to general ")#mi("{k,d}")#text(" was observed ")#link("https://arxiv.org/abs/math/0004059")[#text("by Constantin")]#text(".) Show that the vorticity vector field ")#mi("{*\\omega}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("*\\omega(t) = \\nabla \\theta_1(t) \\times \\nabla \\varphi_1(t)")]]

#text("and conclude in particular that ")#mi("{\\theta_1(t), \\varphi_1(t)}")#text(" are annihilated by this vector field:")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_{*\\omega(t)} \\theta_1(t) = {\\mathcal L}_{*\\omega(t)} \\varphi_1(t) = 0.")]]

#text("To put it another way, the vortex lines of ")#mi("{\\omega(t)}")#text(" lie in the joint level sets of ")#mi("{\\theta_1(t)}")#text(" and ")#mi("{\\varphi_1(t)}")#text(" (and indeed, if ")#mi("{\\theta_1, \\varphi_1}")#text(" are transverse to each other, then the vortex lines are locally the intersection of the two level sets, away from critical points at least).")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Viewing the Euler equations in Lagrangian coordinates — ")]]

#text("Throughout this section, ")#mi("{(u,p)}")#text(" is a smooth solution to the Euler equations on ")#mi("{[0,T) \\times {\\bf R}^d_E}")#text(", and let ")#mi("{X}")#text(" be a volume-preserving trajectory map.")#linebreak()#text(" We pull back the Euler equations ")#link(<tao-90a8cfaded168905ead3>)[#text("(22)")]#text(", ")#link(<tao-8f60b972a639ce51c727>)[#text("(23)")]#text(", ")#link(<tao-71cd2ad5726ab772c084>)[#text("(24)")]#text(", to create a Lagrangian velocity field ")#mi("{\\underline{u}: [0,T) \\rightarrow \\Gamma(T {\\bf R}^d_L)}")#text(", a Lagrangian covelocity field ")#mi("{\\underline{v}: [0,T) \\rightarrow \\Omega^1({\\bf R}^d_L)}")#text(", a Lagrangian modified pressure field ")#mi("{\\underline{\\tilde p}: [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}}")#text(", and a Lagrangian vorticity field ")#mi("{\\underline{\\omega}: [0,T) \\rightarrow \\Omega^2({\\bf R}^d_L)}")#text(" by the formulae")

#tao-aligned(keep: true)[


#tao-math("\\underline{u}(t)  & := X(t)^* u(t)", block: true)



#tao-math("\\underline{v}(t)  & := X(t)^* v(t)", block: true)
]

#metadata(none) <tao-6e839d21bedb0ea901a8>

#tao-aligned(keep: true)[


#tao-math("\\underline{\\omega}(t)  & := X(t)^* \\omega(t)", block: true, numbering: n => [#text("(35)")])



#tao-math("\\underline{\\tilde p}(t)  & := X(t)^* \\tilde p(t).", block: true)
]

#text("By Exercise ")#link(<tao-82ebadafdeec2df737e5>)[#text("17")]#text(", the Euler equations now take the form ")#metadata(none) <tao-f61b854ea6de4f039a83>

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\underline{v}  & = - d \\underline{\\tilde p}", block: true, numbering: n => [#text("(36)")])



#tao-math("\\mathrm{div} \\underline{u}  & = 0", block: true)



#tao-math("\\underline{v}  & = (X^* \\eta) \\cdot \\underline{u}", block: true)
]

#text("and the vorticity is given by")

#align(center)[#tao-fit-display[#mitex("\\underline{\\omega} = d \\underline{v}")]]

#text("and obeys the vorticity equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\underline{\\omega} = 0.")]]

#text("We thus see that the Lagrangian vorticity ")#mi("{\\underline{\\omega}}")#text(" is a ")#emph[#text("pointwise")]#text(" conserved quantity: ")#metadata(none) <tao-6860bc89219d80f8140f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\underline{\\omega}_{\\alpha \\beta}(t, a) = \\underline{\\omega}_{\\alpha\\beta}(0, a).")]]

#text("This lets us solve for the Eulerian vorticity ")#mi("{\\omega_{ij}}")#text(" in terms of the trajectory map. Indeed, from ")#link(<tao-7ca7d2c480f8306967e2>)[#text("(12)")]#text(", ")#link(<tao-6e839d21bedb0ea901a8>)[#text("(35)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\underline{\\omega}_{\\alpha \\beta}(0,a) = \\underline{\\omega}_{\\alpha \\beta}(t,a) = \\omega_{ij}(t,X(t,a)) \\partial_\\alpha X(t)^i(a) \\partial_\\beta X(t)^j(a);")]]

#text("applying the inverse ")#mi("{(\\nabla X(t))^{-1}}")#text(" of the linear transformation ")#mi("{\\nabla X(t)}")#text(", we thus obtain the ")#emph[#text("Cauchy vorticity formula")]#text(" ")#metadata(none) <tao-15e48df64787470fea24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\omega_{ij}(t,X(t,a)) = \\underline{\\omega}_{\\alpha \\beta}(0,a) (\\nabla X(t)^{-1})^\\alpha_i(a) (\\nabla X(t)^{-1})^\\beta_j(a).")]]

#text("If we normalise the trajectory map by ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(", then ")#mi("{\\underline{\\omega}(0) = \\omega(0)}")#text(", and we thus have ")#metadata(none) <tao-454bb5d4aa674006dfc9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\omega_{ij}(t,X(t,a)) = \\omega_{\\alpha \\beta}(0,a) (\\nabla X(t)^{-1})^\\alpha_i(a) (\\nabla X(t)^{-1})^\\beta_j(a).")]]

#text("Thus for instance, we see that the support of the vorticity is transported by the flow:")

#align(center)[#tao-fit-display[#mitex("\\mathrm{supp}(\\omega(t)) = X(t)( \\mathrm{supp}(\\omega(0)) ).")]]

#text("Among other things, this shows that the volume and topology of the support of the vorticity remain constant in time. It also suggests that the Euler equations admit a number of “vortex patch” solutions in which the vorticity is compactly supported.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-535fa30d7e25dd8a49f1>#text(" Assume the normalisation ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(".")

#list(
[#text("(i) In the two-dimensional case ")#mi("{d=2}")#text(", show that the Cauchy vorticity formula simplifies to")

#align(center)[#tao-fit-display[#mitex("\\omega_{12}(t,X(t,a)) = \\omega_{12}(0, a).")]]

#text("Thus in this case, vorticity is simply transported by the flow.")],
[#text("(ii) In the three-dimensional case ")#mi("{d=3}")#text(", show that the Cauchy vorticity formula can be written using the Hodge dual ")#mi("{*\\omega}")#text(" of the vorticity as")

#align(center)[#tao-fit-display[#mitex("*\\omega^i(t, X(t,a)) = *\\omega^\\alpha(0,a) \\partial_\\alpha X^i( t, a ).")]]

#text("Thus we see that the vorticity is transported and also ")#link("https://en.wikipedia.org/wiki/Vortex_stretching")[#text("stretched")]#text(" by the flow, with the stretching given by the matrix ")#mi("{\\partial_\\alpha X^i}")#text(".")]
)
]

#text("One can also phrase the conservation of vorticity in an integral form. If ")#mi("{S}")#text(" is a two-dimensional oriented surface in ")#mi("{{\\bf R}^3_L}")#text(" that does not vary in time, then from ")#link(<tao-6860bc89219d80f8140f>)[#text("(37)")]#text(" we see that the integral")

#align(center)[#tao-fit-display[#mitex("\\int_S \\underline{\\omega}(t)")]]

#text("is formally conserved in time:")

#align(center)[#tao-fit-display[#mitex("\\int_S \\underline{\\omega}(t) = \\int_S \\underline{\\omega}(0).")]]

#text("Composing this with the trajectory map ")#mi("{X(t)}")#text(" using ")#link(<tao-6e839d21bedb0ea901a8>)[#text("(35)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{X(t)(S)} \\omega(t) = \\int_{X(0)(S)} \\omega(0).")]]

#text("Writing ")#mi("{\\omega = dv}")#text(" and using Stokes’ theorem ")#link(<tao-2b50aa6ff81012c3421a>)[#text("(14)")]#text(", we arrive at the ")#link("https://en.wikipedia.org/wiki/Kelvin%27s_circulation_theorem")[#text("Kelvin circulation theorem")]

#align(center)[#tao-fit-display[#mitex("\\int_{X(t)(\\partial S)} v(t) = \\int_{X(0)(\\partial S)} v(0).")]]

#text("The integral of the covelocity ")#mi("{v}")#text(" along a loop ")#mi("{\\gamma}")#text(" is known as the ")#emph[#text("circulation")]#text(" of the fluid along the loop; the Kelvin circulation theorem then asserts that this circulation remains constant over time as long as the loop evolves along the flow.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Cauchy invariants)")]

#list(
[#text("(i) Use ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(" to establish the identity")

#align(center)[#tao-fit-display[#mitex("\\underline{v}_\\beta(t,a) = \\eta_{ij} (\\partial_t X^i(t,a)) \\partial_\\beta X^j(t,a)")]]

#text("expressing the Lagrangian covelocity ")#mi("{\\underline{v}}")#text(" in terms of the Euclidean metric ")#mi("{\\eta}")#text(" and the trajectory map ")#mi("{X}")#text(".")],
[#text("(ii) Use (i) and ")#link(<tao-f61b854ea6de4f039a83>)[#text("(36)")]#text(" to establish the Lagrangian equation of motion")

#metadata(none) <tao-fd216818cecbc78c0aeb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\eta_{ij} (\\partial_t^2 X^i(t,a)) \\partial_\\beta X^j(t,a) = - \\partial_\\beta \\underline{p}(t,a)")]]

#text("or equivalently")

#metadata(none) <tao-9af84c0955bf03475527>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\eta_{ij} \\partial_t^2 X^i(t,a) = - ((\\nabla X)^{-1})^\\beta_j(t,a) \\partial_\\beta \\underline{p}(t,a)")]]

#text("where the unmodified Lagrangian pressure ")#mi("{\\underline{p}}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("\\underline{p} := \\underline{\\tilde p} + \\frac{1}{2} \\eta_{ij} (\\partial_t X^i) (\\partial_t X^j).")]]],
[#text("(iii) Show that ")#mi("{\\underline{p}}")#text(" is also the pullback of the unmodified Eulerian pressure ")#mi("{p}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\underline{p}(t,a) = (X(t)^* p)(a) = p(t,X(t,a)),")]]

#text("and recover ")#emph[#text("Newton’s first law")]#text(" ")#link(<tao-305238273bb0fac2a73b>)[#text("(5)")]#text(".")],
[#text("(iv) Use (ii) to conclude the ")#emph[#text("Cauchy invariants")]

#align(center)[#tao-fit-display[#mitex("\\eta_{ij} (\\partial_t \\partial_\\alpha X^i) \\partial_\\beta X^j - \\eta_{ij} (\\partial_t \\partial_\\beta X^i) \\partial_\\alpha X^j")]]

#text("are pointwise conserved in time.")],
[#text("(v) Show that the Cauchy invariants are precisely the components ")#mi("{\\underline{\\omega}_{\\alpha \\beta}}")#text(" of the Lagrangian vorticity, thus the conservation of the Cauchy invariants is equivalent to the Cauchy vorticity formula.")]
)

#text("For more discussion of Cauchy’s investigation of the Cauchy invariants and vorticity formula, see this article of ")#link("https://arxiv.org/abs/1402.4957")[#text("Frisch and Villone")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Transport of vorticity lines)")]#text(" Suppose we are in three dimensions ")#mi("{d=3}")#text(", so that the Hodge dual ")#mi("{* \\omega}")#text(" of vorticity is a vector field. A smooth curve ")#mi("{\\gamma}")#text(" (either infinite on both ends, or a closed loop) in ")#mi("{{\\bf R}^3_E}")#text(" is said to be a ")#link("https://en.wikipedia.org/wiki/Vortex")[#text("vortex line")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Vortex_ring")[#text("vortex ring")]#text(", in the case of a closed loop) at time ")#mi("{t}")#text(" if at every point ")#mi("{x}")#text(" of the curve ")#mi("{\\gamma}")#text(", the tangent to ")#mi("{x}")#text(" at ")#mi("{\\gamma}")#text(" is parallel to the vorticity ")#mi("{\\omega(t,x)}")#text(" at that point. Suppose that the trajectory map is normalised using ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(". Show that if ")#mi("{\\gamma}")#text(" is a vortex line at time ")#mi("{0}")#text(", then ")#mi("{X(t)(\\gamma)}")#text(" is a vortex line at any other time ")#mi("{t}")#text("; thus, vortex lines (or vortex rings) flow along with the fluid.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Conservation of helicity in Lagrangian coordinates)")]

#list(
[#text("(i) In any dimension, establish the identity")

#align(center)[#tao-fit-display[#mitex("\\partial_t ( \\underline{v}(t) \\wedge \\underline{\\omega}(t) ) = - d( \\underline{p^{\\prime}} \\underline{\\omega}(t) )")]]

#text("in Lagrangian spacetime.")],
[#text("(ii) Conclude that in three dimensions ")#mi("{d=3}")#text(", the quantity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3_L} \\underline{v}(t) \\wedge \\underline{\\omega}(t)")]]

#text("is formally conserved in time. Explain why this conserved quantity is the same as the helicity ")#link(<tao-933c53c574d35179d3f7>)[#text("(34)")]#text(".")],
[#text("(iii) Continue assuming ")#mi("{d=3}")#text(". Define a ")#emph[#text("vortex tube")]#text(" at time ")#mi("{t}")#text(" to be a region ")#mi("{T \\subset {\\bf R}^3_E}")#text(" in which, at every point ")#mi("{x}")#text(" on the boundary ")#mi("{\\partial T}")#text(", the vorticity vector field ")#mi("{*\\omega(t,x)}")#text(" is tangent to ")#mi("{\\partial T}")#text(". Show that if ")#mi("{X(0)(T)}")#text(" is a vortex tube at time ")#mi("{0}")#text(", then ")#mi("{X(t)(T)}")#text(" is a vortex tube at time ")#mi("{T}")#text(", and the helicity ")#mi("{\\int_{X(t)(T)} v(t) \\wedge \\omega(t)}")#text(" on the vortex tube is formally conserved in time.")],
[#text("(iv) Let ")#mi("{d=3}")#text(". If the covelocity ")#mi("{v}")#text(" can be expressed in Clebsch variables (Exercise ")#link(<tao-19d8280e9084dfabe3f4>)[#text("32")]#text(") with ")#mi("{k=1}")#text(", show that the local helicity ")#mi("{\\int_{X(t)(T)} v(t) \\wedge \\omega(t)\\ dt}")#text(" formally vanishes on every vortex tube ")#mi("{T}")#text(". This provides an obstruction to the existence of ")#mi("{k=1}")#text(" Clebsch variables. (On the other hand, it is easy to find Clebsch variables on ")#mi("{{\\bf R}^d}")#text(" with ")#mi("{k=d}")#text(" for an arbitrary covelocity ")#mi("{v}")#text(", simply by setting ")#mi("{\\varphi_j}")#text(" equal to the coordinate functions ")#mi("{\\varphi_j(x) = x^j}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" In the three-dimensional case ")#mi("{d=3}")#text(", show that the material derivative ")#mi("{D_t}")#text(" commutes with operation ")#mi("{*\\omega \\cdot \\nabla}")#text(" of differentiation along the (Hodge dual of the) vorticity.")
]

#text("The Cauchy vorticity formula ")#link(<tao-454bb5d4aa674006dfc9>)[#text("(39)")]#text(" can be used to obtain an integral representation for the velocity ")#mi("{u}")#text(" in terms of the trajectory map ")#mi("{X}")#text(", leading to the ")#emph[#text("vorticity-stream formulation")]#text(" of the Euler equations. Recall from ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("254A Notes 3")]#text(" that if one takes the divergence of the (Eulerian) vorticity ")#mi("{\\omega}")#text(", one obtains the Laplacian of the (Eulerian) covelocity ")#mi("{u}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\Delta v_j = \\partial^i \\omega_{ij},")]]

#text("where ")#mi("{\\partial^i := \\eta^{ik} \\partial_k}")#text(" are the partial derivatives raised by the Euclidean metric. For ")#mi("{d > 2}")#text(", we can use the fundamental solution ")#tao-math("{\\frac{-1}{(d-2)\\left|S^{d-2}\\right|} \\frac{1}{\\left|x\\right|^{d-2}}}", block: false)#text(" of the Laplacian (see ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Exercise 18 of 254A Notes 1")]#text(") that (formally, at least)")

#align(center)[#tao-fit-display[#tao-math("v_j(t,x) = \\frac{-1}{(d-2)\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_E} \\frac{\\partial^i \\omega_{ij}(t,y)}{\\left|x-y\\right|^{d-2}}\\ d\\mathrm{vol}_E(y).", block: true)]]

#text("Integrating by parts (after first removing a small ball around ")#mi("{x}")#text(", and observing that the boundary terms from this ball go to zero as one shrinks the radius to zero) one obtains ")#link("https://en.wikipedia.org/wiki/Biot%E2%80%93Savart_law")[#text("the Biot-Savart law")]

#align(center)[#tao-fit-display[#tao-math("v_j(t,x) = \\frac{1}{\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_E} \\frac{(x^i-y^i) \\omega_{ij}(t,y)}{\\left|x-y\\right|^{d}}\\ d\\mathrm{vol}_E(y)", block: true)]]

#text("for the covelocity, or equivalently")

#align(center)[#tao-fit-display[#tao-math("u^k(t,x) = \\frac{1}{\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_E} \\frac{\\eta^{jk} (x^i-y^i) \\omega_{ij}(t,y)}{\\left|x-y\\right|^{d}}\\ d\\mathrm{vol}_E(y)", block: true)]]

#text("for the velocity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Show that this law is also valid in the two-dimensional case ")#mi("{d=2}")#text(".")
]

#text("Changing to Lagrangian variables, we conclude that")

#align(center)[#tao-fit-display[#tao-math("u^k(t,X(t,a)) = \\frac{1}{\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_L}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\eta^{jk} \\frac{(X^i(t,a)-X^i(t,b)) \\omega_{ij}(t,X(t,b))}{\\left|X(t,a)-X(t,b)\\right|^{d}}\\ d\\mathrm{vol}_L(b).", block: true)]]

#text("Using the Cauchy vorticity formula ")#link(<tao-454bb5d4aa674006dfc9>)[#text("(39)")]#text(" (assuming the normalisation ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text("), we obtain")

#align(center)[#tao-fit-display[#tao-math("u^k(t,X(t,a)) = \\frac{1}{\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_L}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\frac{(X^i(t,a)-X^i(t,b)) (\\nabla X(t)^{-1})^\\alpha_i(b) (\\nabla X(t)^{-1})^\\beta_j(b)}{\\left|X(t,a)-X(t,b)\\right|^{d}} \\omega_{\\alpha \\beta}(0,b) \\ d\\mathrm{vol}_L(b).", block: true)]]

#text("Combining this with ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(", we obtain an integral-differential equation for the evolution of the trajectory map: ")#metadata(none) <tao-f733055b0f9d2cd946e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\partial_t X^k(t,a) = \\frac{1}{\\left|S^{d-2}\\right|} \\int_{{\\bf R}^d_L}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\eta^{jk} \\frac{(X^i(t,a)-X^i(t,b)) (\\nabla X(t)^{-1})^\\alpha_i(b) (\\nabla X(t)^{-1})^\\beta_j(b)}{\\left|X(t,a)-X(t,b)\\right|^{d}} \\omega_{\\alpha \\beta}(0,b) \\ d\\mathrm{vol}_L(b).", block: true)]]

#text("This is known as the ")#emph[#text("vorticity-stream formulation")]#text(" of the Euler equations. In two and three dimensions, the formulation can be simplified using the alternate forms of the vorticity formula in Exercise ")#link(<tao-535fa30d7e25dd8a49f1>)[#text("33")]#text(". While the equation ")#link(<tao-f733055b0f9d2cd946e1>)[#text("(42)")]#text(" looks complicated, it is actually well suited for Picard-type iteration arguments (of the type used in ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("254A Notes 1")]#text("), due to the relatively small number of derivatives on the right-hand side. Indeed, it turns out that one can iterate this equation with the trajectory map placed in function spaces such as ")#mi("{C^0_t C^{1,\\alpha}_x( [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E)}")#text("; see Chapter 4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1867882")[#text("Bertozzi-Majda")]#text(" for details.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 39")]#text(" Because of the ability to solve the Euler equations in Lagrangian coordinates by an iteration method, the local well-posedness theory is slightly stronger in some respects in Lagrangian coordinates than it is in Eulerian coordinates. For instance, in ")#link("https://arxiv.org/abs/1504.00727")[#text("this paper of Constantin Kukavica and Vicol")]#text(" it is shown that Lagrangian coordinate Euler equations are well-posed in Gevrey spaces, while Eulerian coordinate Euler equations are not. It also happens that the trajectory maps ")#mi("{X(t,a)}")#text(" are real-analytic in ")#mi("{t}")#text(" even if the initial data is merely smooth; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3406503")[#text("this paper of Constantin-Vicol-Wu")]#text(" and the references therein. An example of this phenomenon is given in the exercise below.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (DiPerna-Majda example)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" and ")#mi("{g: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be smooth functions.")

#list(
[#text("(i) Show that the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=877643")[#text("DiPerna-Majda flow")]#text(" ")#mi("{u: {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("u(t,x) = (f(x_2), 0, g( x_1- t f(x_2), x_2))")]]

#text("solves the three-dimesional Euler equations (with zero pressure).")],
[#text("(ii) Show that the trajectory map with initial condition ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(" is given by")

#align(center)[#tao-fit-display[#mitex("X(t,a) = (a_1 + t f(a_2), a_2, a_3 + t g(a_1, a_2) );")]]

#text("in particular the trajectory map is analytic in the time variable ")#mi("{t}")#text(", even though the Eulerian velocity field ")#mi("{u}")#text(" need not be.")],
[#text("(iii) Show that the Lagrangian covelocity field ")#mi("{\\underline{v}}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("\\underline{v} = f(a_2) da_1 + g(a_1,a_2) da_3 + d( \\frac{t}{2} f^2(a_2) + \\frac{t}{2} g^2(a_1,a_2) )")]]

#text("and the Lagrangian vorticity field ")#mi("{\\underline{\\omega}}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("\\underline{\\omega} = - f^{\\prime}(a_2) da_1 \\wedge da_2 + dg(a_1,a_2) \\wedge da_3.")]]

#text("In particular the Lagrangian vorticity is conserved in time (as it ought to).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" ")#metadata(none) <tao-b5838798533a5a82226b>#text(" Show that the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d_L} \\eta_{ij} (X^j(t,a) - a^\\alpha \\partial_\\alpha X^j(t,a) - \\frac{d+2}{2} t \\partial_t X^j(t,a))")]]

#align(center)[#tao-fit-display[#mitex("\\partial_t X^i(t,a)\\ d\\mathrm{vol}_L(a)")]]

#text("is formally conserved in time. (")#emph[#text("Hint:")]#text(" some of the terms arising from computing the derivative are more easily treated by moving to Eulerian coordinates and performing integration by parts there, rather than in Lagrangian coordinates. One can also proceed by rewriting the terms in this integral using the Eulerian covelocity ")#mi("{v}")#text(" and the Lagrangian covelocity ")#mi("{\\underline{v}}")#text(".) With the normalisation ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(4)")]#text(", conclude in particular that")

#tao-aligned(keep: true)[


#tao-math("\\int_{{\\bf R}^d_E} x^i v_i(t,x)\\ d\\mathrm{vol}_E(x)  & = \\int_{{\\bf R}^d_L} a^\\alpha \\underline{v}_\\alpha(t,a)\\ d\\mathrm{vol}_L(a)", block: true)



#tao-math(" & + \\frac{d+2}{2} t \\int_{{\\bf R}^d_E} \\left|u(t,x)\\right|^2\\ d\\mathrm{vol}_E(x).", block: true)
]

#text("This conservation law is related to a scaling symmetry of the Euler equations in Lagrangian coordinates, and is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3573120")[#text("due to Shankar")]#text(". It does not have a local expression in purely Eulerian coordinates (mainly because of the appearance of the labels coordinate ")#mi("{a^\\alpha}")#text(").")
]

#text("We summarise the dictionary between Eulerian and Lagrangian coordinates in the following table:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian spacetime ")#mi("{{\\bf R} \\times {\\bf R}^d_E}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian spacetime ")#mi("{{\\bf R} \\times {\\bf R}^d_L}")],
table.cell(colspan: 1, rowspan: 1)[#text("Time ")#mi("{t}")],
table.cell(colspan: 1, rowspan: 1)[#text("Time ")#mi("{t}")],
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian position ")#mi("{x^i}")],
table.cell(colspan: 1, rowspan: 1)[#text("Trajectory map ")#mi("{X^i(t,a)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Labels map ")#mi("{A^\\alpha(t,x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian position ")#mi("{a^\\alpha}")],
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian velocity ")#mi("{u^i(t,x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian velocity ")#mi("{\\underline{u}^i(t,a)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian covelocity ")#mi("{v_i(t,x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian covelocity ")#mi("{\\underline{v}_i(t,a)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian vorticity ")#mi("{\\omega_{ij}(t,x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian vorticity ")#mi("{\\underline{\\omega}_{ij}(t,a)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Eulerian pressure ")#mi("{p(t,x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Lagrangian pressure ")#mi("{\\underline{p}(t,a)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Euclidean metric ")#mi("{\\eta_{ij}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Pullback metric ")#mi("{(X(t)^* \\eta)_{\\alpha \\beta}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Standard volume form ")#mi("{d\\mathrm{vol}_E}")],
table.cell(colspan: 1, rowspan: 1)[#text("Standard volume form ")#mi("{d\\mathrm{vol}_L}")],
table.cell(colspan: 1, rowspan: 1)[#text("Material Lie derivative ")#mi("{{\\mathcal D}_t}")],
table.cell(colspan: 1, rowspan: 1)[#text("Time derivative ")#mi("{\\partial_t}")]
)

#heading(level: 1)[#strong[#text(" — 4. Variational characterisation of the Euler equations — ")]]

#text("Our computations in this section will be even more formal than in previous sections.")#linebreak()#text(" From Exercise ")#link(<tao-88053b70aab3bbfd02c7>)[#text("1")]#text(", a (smooth, bounded) vector field ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" (together with a choice of initial map ")#mi("{X_0: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(") gives rise to a trajectory map ")#mi("{X(t): [0,T) \\times {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(". From Lemma ")#link(<tao-fe61da860649d1497075>)[#text("3")]#text(", we see that that ")#mi("{X(t)}")#text(" is volume preserving for all times ")#mi("{t \\in [0,T)}")#text(" if and only if ")#mi("{X_0}")#text(" is volume preserving and if ")#mi("{u}")#text(" is divergence-free. Given such a trajectory map, let us formally define the ")#emph[#text("Lagrangian")]#text(" ")#mi("{\\mathcal{L}(X)}")#text(" by the formula ")#metadata(none) <tao-b492d45aef584dda4446>

#tao-aligned(keep: true)[


#tao-math("\\mathcal{L}(X)  & := \\frac{1}{2} \\int_0^T \\int_{{\\bf R}^d_L} \\left|\\partial_t X\\right|_\\eta^2\\ d\\mathrm{vol}_L dt", block: true, numbering: n => [#text("(43)")])



#tao-math(" & = \\frac{1}{2} \\int_0^T \\int_{{\\bf R}^d_L} \\eta_{ij} (\\partial_t X^i) \\partial_t X^j\\ d\\mathrm{vol}_L dt.", block: true)
]

#text("As ")#link("http://www.ams.org/mathscinet-getitem?mr=202082")[#text("observed by Arnold")]#text(", the Euler equations can be viewed as the ")#link("https://en.wikipedia.org/wiki/Euler-Lagrange_equation")[#text("Euler-Lagrange equations")]#text(" for this Lagrangian, subject to the constraint that the trajectory map is always volume-preserving:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 42")]#text(" ")#metadata(none) <tao-07ed400759a0f606a8b5>#text(" Let ")#mi("{u: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" be a smooth bounded divergence-free vector field with a volume-preserving trajectory map ")#mi("{X(t)}")#text(". Then the following are formally equivalent:")

#list(
[#text("(i) There is a pressure field ")#mi("{p: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}}")#text(" such that ")#mi("{(u,p)}")#text(" solves the Euler equations.")],
[#text("(ii) The trajectory map ")#mi("{X}")#text(" is a critical point of the Lagrangian ")#mi("{\\mathcal{L}(X)}")#text(" with respect to all compactly supported infinitesimal perturbations of ")#mi("{X}")#text(" in ")#mi("{(0,T) \\times {\\bf R}^d_L}")#text(" that preserve the volume-preserving nature of the trajectory map.")]
)
]

#emph[#text("Proof:")]#text(" First suppose that (i) holds. Consider an infinitesimal deformation ")#mi("{X + \\varepsilon Y + O(\\varepsilon^2)}")#text(" of the trajectory map, with ")#mi("{Y}")#text(" compactly supported in ")#mi("{(0,T) \\times {\\bf R}^d_L}")#text(", where one can view ")#mi("{\\varepsilon}")#text(" either as an infinitesimal or as a parameter tending to zero (in this formal analysis we will not bother to make the setup more precise than this). If this deformation is still volume-preserving, then we have")

#align(center)[#tao-fit-display[#mitex("\\det( \\nabla X + \\varepsilon \\nabla Y ) = 1 + O(\\varepsilon^2);")]]

#text("differentiating at ")#mi("{\\varepsilon=0}")#text(" using Exercise ")#link(<tao-e02a753f0c060173d1fa>)[#text("4")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{tr}( (\\nabla X)^{-1} \\nabla Y ) = 0")]]

#text("or in coordinates ")#metadata(none) <tao-b3ae860f312d4ae6cc3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("(\\nabla X)^{-1})^\\alpha_i \\partial_\\alpha Y^i = 0.")]]

#text("Writing ")#mi("{y(t,x) := Y(t,X(t)^{-1}(x))}")#text(", we thus see from the chain rule that the Eulerian vector field ")#mi("{y: [0,T) \\times {\\bf R}^d_E \\rightarrow {\\bf R}^d_E}")#text(" is divergence-free: ")#metadata(none) <tao-599bc4316bacf722a80a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("\\partial_i y^i = 0.")]]

#text("Now, let us compute the infinitesimal variation of the Lagrangian:")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{d\\varepsilon} \\mathcal{L}(X + \\varepsilon Y + O(\\varepsilon^2)) |_{\\varepsilon=0}.")]]

#text("Formally differentiating under the integral sign, this expression becomes")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_0^T \\int_{{\\bf R}^d_L} \\eta_{ij} (\\partial_t X^i) \\partial_t Y^j + \\eta_{ij} (\\partial_t Y^i) \\partial_t X^j\\ d\\mathrm{vol}_L dt")]]

#text("which by symmetry simplifies to")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{{\\bf R}^d_L} \\eta_{ij} (\\partial_t X^i) \\partial_t Y^j\\ d\\mathrm{vol}_L dt")]]

#text("We integrate by parts in time to move the derivative off of the perturbation ")#mi("{Y}")#text(", to arrive at ")#metadata(none) <tao-769a4e6d0003189c7e96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("- \\int_0^T \\int_{{\\bf R}^d_L} \\eta_{ij} (\\partial_{t}^2 X^i) Y^j\\ d\\mathrm{vol}_L dt.")]]

#text("Using Newton’s first law ")#link(<tao-9af84c0955bf03475527>)[#text("(41)")]#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{{\\bf R}^d_L} ((\\nabla X)^{-1})^\\beta_j (\\partial_\\beta \\underline{p}) Y^j\\ d\\mathrm{vol}_L dt.")]]

#text("Writing ")#mi("{\\underline{p} = X(t)^* p}")#text(", we can change to Eulerian variables to obtain")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{{\\bf R}^d_E} \\partial_j p y^j\\ d\\mathrm{vol}_E dt.")]]

#text("We can now integrate by parts and use ")#link(<tao-599bc4316bacf722a80a>)[#text("(45)")]#text(" and conclude that this variation vanishes. Thus ")#mi("{X}")#text(" is a formal critical point of the Lagrangian.")#linebreak()#text(" Conversely, if ")#mi("{X}")#text(" is a formal critical point, then the above analysis shows that the expression ")#link(<tao-769a4e6d0003189c7e96>)[#text("(46)")]#text(" vanishes whenever ")#mi("{y}")#text(" obeys ")#link(<tao-599bc4316bacf722a80a>)[#text("(45)")]#text(". Changing variables to Euclidean space, this expression becomes")

#align(center)[#tao-fit-display[#mitex("- \\int_0^T \\int_{{\\bf R}^d_E} \\eta_{ij} (\\partial_{t}^2 X^i \\circ X(t)^{-1}) y^j\\ d\\mathrm{vol}_E dt.")]]

#text("Hodge theory (cf. Exercise 16 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("254A Notes 1")]#text(") then implies (formally) that ")#mi("{\\eta_{ij} (\\partial_{t}^2 X^i \\circ X(t)^{-1})}")#text(" must be a differential ")#mi("{-\\partial_j p}")#text(", which is equivalent to Newton’s first law ")#link(<tao-9af84c0955bf03475527>)[#text("(41)")]#text(", which is in turn equivalent to the Euler equations (recalling that ")#mi("{u}")#text(" is assumed to be divergence-free). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 43")]#text(" The above analysis reveals that the pressure field ")#mi("{p}")#text(" can be interpreted as a ")#link("https://en.wikipedia.org/wiki/Lagrange_multiplier")[#text("Lagrange multiplier")]#text(" arising from the constraint that the trajectory map be volume-preserving.")
]

#text("Following ")#link("http://www.ams.org/mathscinet-getitem?mr=202082")[#text("Arnold")]#text(", one can use Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("42")]#text(" to formally interpret the Euler equations as a geodesic flow on an infinite dimensional Riemannian manifold. Indeed, for a finite-dimensional Riemannian manifold ")#mi("{(M,g)}")#text(", it is well known that (constant speed) geodesics ")#mi("{\\gamma: [0,T) \\rightarrow M}")#text(" are formal critical points of the energy functional")

#align(center)[#tao-fit-display[#tao-math("\\mathcal{L}(\\gamma) := \\frac{1}{2} \\int_0^T \\left|\\partial_t \\gamma(t)\\right|_g^2\\ dt.", block: true)]]

#text("Thus we see that if we formally take ")#mi("{M}")#text(" to be the infinite-dimensional space of volume-preserving diffeomorphisms ")#mi("{X: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(", with the formal Riemannian metric ")#mi("{g(X)}")#text(" at a point ")#mi("{X \\in M}")#text(" in the directions of two infinitesimal perturbations ")#mi("{Y,Z: {\\bf R}^d_L \\rightarrow {\\bf R}^d_E}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("g(X)( Y, Z) := \\int_{{\\bf R}^d_L} \\eta(Y,Z)\\ d\\mathrm{vol}_L")]]

#text("then Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("42")]#text(" asserts, formally, that solutions to the Euler equations coincide with constant speed geodesic flows on ")#mi("{M}")#text(". As it turns out, a number of other physical equations, including several further fluid equations, also have such a geodesic interpretation, such as Burgers’ equation, the Korteweg-de Vries equation, and the Camassa-Holm equations; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2393297")[#text("this paper of Vizman")]#text(" for a survey. In principle this means that the tools of Riemannian geometry could be deployed to obtain a better understanding of the Euler equations (and of the other equations mentioned above), although to date this has proven to be somewhat elusive (except when discussing conservation laws, as in Remark ")#link(<tao-719b4802f549f1ceca27>)[#text("44")]#text(" below) for a number of reasons, not the least of which is that rigorous Riemannian geometry on infinite-dimensional manifolds is technically quite problematic. (Nevertheless, one can at least recover the local existence theory for the Euler equations this way; see the aforementioned ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=271984")[#text("work of Ebin and Marsden")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 44")]#text(" ")#metadata(none) <tao-719b4802f549f1ceca27>#text(" ")#link("https://en.wikipedia.org/wiki/Noether%27s_theorem")[#text("Noether’s theorem")]#text(" tells us that one should expect a one-to-one correspondence between symmetries of a Lagrangian ")#mi("{{\\mathcal L}}")#text(" and conservation laws of the corresponding Euler-Lagrange equation. Applying this to Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("42")]#text(", we conclude that the conservation laws of the Euler equations should correspond to symmetries of the Lagrangian ")#link(<tao-b492d45aef584dda4446>)[#text("(43)")]#text(". There are basically two obvious symmetries of this Lagrangian; one coming from isometries of Eulerian spacetime ")#mi("{{\\bf R} \\times {\\bf R}^d_E}")#text(", and in particular time translation, spatial translation, and spatial rotation; and the other coming from volume-preserving diffeomorphisms of Lagrangian space ")#mi("{{\\bf R}^d_L}")#text(". One can check that time translation corresponds to energy conservation, spatial translation corresponds to momentum conservation, and spatial rotation corresponds to angular momentum conservation, while Lagrangian diffeomorphism invariance corresponds to conservation of Lagrangian vorticity (or equivalently, the Cauchy vorticity formula). In three dimensions, if one specialises to the specific Lagrangian diffeomorphism created by flow along the vorticity vector field ")#mi("{*\\omega}")#text(", one also recovers conservation of helicity; see ")#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/")[#text("this previous blog post for more discussion")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 45")]#text(" There are also Hamiltonian formulations of the Euler equations that do not correspond exactly to the geodesic flow interpretation here; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=672198")[#text("this paper of Olver")]#text(". Again, one can explain each of the known conservation laws for the Euler equations in terms of symmetries of the Hamiltonian.")
]

#text("Further discussion of the geodesic flow interpretation of the Euler equations may be found in ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous blog post")]#text(".")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03ecbae8784286921367d68217d35bfe77ebad24a79eb5e11604219f56b55a74-0eb6a25531341fb9165226ec2b7da6288d550fde45aee59e0462ec8dc4857f3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peeterjoot")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-508866")[#strong[#text("peeterjoot")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("minor typo: Right before “Exercise 7 Show that the wedge product is a bilinear map” there’s a theta_i that should be \\theta_i")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-508870")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("There are systematic methods (e.g. via Cartan equivalence method) to find a complete system of generating differential invariants for PDE systems.")#linebreak()#text(" Is it known (e.g. by such method) that in addition to the known conservation laws, there is no new conservation law for the Euler equations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-508884")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("There do not appear to be any further local conservation laws, at least in three dimensions, according to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=555135")[#text("this paper of Denis Serre")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-508911")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2018")])]

#text("This paper is from 1979, so it is unclear why in Olver’s paper (linked in remark 42) from 1982, it is stated (in page 237) that the program for the complete classification of the conservation laws of the Euler equation is feasible but still was not completed at that time (1982).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Olver cites Serre’s paper as reference [23] and mentions it at the start of page 237. From Olver’s discussion it seems that the analysis of Serre and others is complete for integral conserved quantities that are linear or quadratic in the velocity field and its first derivatives, but may still be incomplete for more general conserved quantities. (For instance, if one works with the Lagrangian formulation instead of the Eulerian one, there is an additional conservation law coming from scale invariance that expressed locally in Lagrangian coordinates but not in Eulerian coordinates; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3573120")[#text("this paper of Shankar")]#text("; I have added this quantity to the notes as Exercise 39.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-590424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2020")])]

#text("Professor Tao, I’m sorry, what would you advise to study and read what literature and materials on the topic of the Novye_Stokes equations, in order to start solving the problem associated with it")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-590591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2020")])]

#text("I would recommend Lemarie-Rieusset “Recent Developments in the Navier-Stokes problem.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bdf576436a724a3742c3418a30149cc87676f3a52b985e613fb23a787890ec4-18121b541bfded2b9b7f9f5602da8b79f9f6922ddb712838b5b3888f02d45390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Another Flawed Human")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509015")[#strong[#text("Another Flawed Human")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("(Comment completely unrelated to math)")#linebreak()#text(" Dear Professor, I suggest you to use this picture (link below) as your new profile picture. You look way better in this. :)")#linebreak()#text(" ")#link("https://imgur.com/a/fxaa6aP")[#text("https://imgur.com/a/fxaa6aP")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bdf576436a724a3742c3418a30149cc87676f3a52b985e613fb23a787890ec4-18121b541bfded2b9b7f9f5602da8b79f9f6922ddb712838b5b3888f02d45390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Another Flawed Human")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509018")[#strong[#text("Another Flawed Human")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("Here is the full image I found in Alon Amit’s blog on Quora.")#linebreak()#text(" ")#link("https://imgur.com/a/Zxo45Q9")[#text("https://imgur.com/a/Zxo45Q9")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509135")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text(">(but the reader is free to also ignore the ")#mi("E")#text(" or ")#mi("L")#text(" subscripts if he or she wishes).")

#text("so not like in Mochizuki’s work then ;-P")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/add07e44fc2dde2cbe7469211387ade739be51a9eeb12c0487f8069010b1ecac-8e7be3e7b34f7da4cccb2d583060c9e75ca409892cc243902cb2a5896c49e32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VeryAnonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509146")[#strong[#text("VeryAnonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text("“Having pulled back differential forms, we now pull back vector fields.” How uncharacteristic. Don’t you usually push them forwards? [I know, I know.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-509595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("In the formula just below (6), the function")#linebreak()#text(" ")#mi("f")#text(" should be mapping from ")#mi("R_E^d")#text(" to ")#mi("R")#text(", and so the ")#mi("E")#text(" and ")#mi("L")#text(" under the integral sign should be switched.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 2: Onsager’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-510684")[#strong[#text("255B, Notes 2: Onsager’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("[…] indices such as (reserving the symbol for other purposes), and are retaining the convention from Notes 1 of denoting vector fields using superscripted indices rather than subscripted indices, as we will […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elgindi’s approximation of the Biot-Savart law | What's new")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-534162")[#strong[#text("Elgindi’s approximation of the Biot-Savart law | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2019")])]

#text("[…] of the musical isomorphism of the Euclidean metric applied to the velocity field ; see these previous lecture notes. However, we will not need this geometric formalism in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-598354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2020")])]

#text("Did you accidentally label this sequence of notes as 255B instead of 245B? It seems that 245B is the correct continuation of 245A. The 255 sequence is Functional Analysis at UCLA.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/#comment-598652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Sorry. I meant to say 254B… since it was claimed at the beginning that")

#emph[#linebreak()#text(" These lecture notes are a continuation of the 254A lecture notes from the previous quarter.")#linebreak()#text(" ")]
]
]
