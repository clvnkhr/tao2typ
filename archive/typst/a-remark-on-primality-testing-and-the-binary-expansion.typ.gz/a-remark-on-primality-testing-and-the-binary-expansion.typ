// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/
// Converted to Typst by tao2typ: "2026-10-14T06:53:18.849163+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A remark on primality testing and the binary expansion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A remark on primality testing and the binary expansion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/")[#text("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the short note “")#link("http://arxiv.org/abs/0802.3361")[#text("A remark on primality testing and the binary expansion")]#text("“, submitted to the ")#link("http://www.austms.org.au/Journal+of+the+Australian+Mathematical+Society")[#text("Journal of the Australian Mathematical Society")]#text(". In this note I establish the following result: for any sufficiently large integer n, there exists an n-bit prime p, such that the numbers ")#mi("p \\pm 2^i")#text(" for ")#mi("i=0,\\ldots,n-1")#text(" are all composite. In particular, if one flips any one of the bits in the binary expansion of the prime p, one obtains a composite number. As a consequence, one obtains the (rather plausible) consequence that in order to (deterministically) test whether an n-bit integer is prime or not, one needs (in the worst-case) to read all n bits of the prime. (This question was posed to me by my colleague here at UCLA, ")#link("http://www.math.ucla.edu/~ynm/")[#text("Yiannis Moschovakis")]#text(".)")

#text("Primes p of the form mentioned in the above result are somewhat rare at first; the first some prime is ")#mi("1973 = 11110110101_2")#text(". But in fact, the argument in my note shows that the set of such primes actually has positive relative density inside the set of all primes. (Amusingly, this means that one can apply a ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("theorem of Ben Green and myself")]#text(" and conclude that there are arbitrarily long arithmetic progressions of such primes, although I doubt that there is any particular significance or application to this conclusion.)")

#text("The same remark applies to other bases; thus, for instance, there exist infinitely many prime numbers with the property that if one changes any one of the base 10 digits of that number, one obtains a composite number. ")#strike[#text("(Presumably the first such number can be located by computer search, though I did not attempt to do so.)")]#text(" [")#emph[#text("Update")]#text(", Feb 25: see comments.]")

#metadata(none) <tao-6864b6d1a727c902e6f0>

#text("Heuristically, a random n-bit integer has roughly a 1/n chance (up to multiplicative constants such as ")#mi("\\log 2")#text(") of being prime. So amongst the 2n numbers ")#mi("p \\pm 2^i")#text(" for ")#mi("0 \\leq i < n-1")#text(" and a fixed prime p, one expects about O(1) of these numbers to be prime on the average. A more refined calculation (using the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text(") suggests that the expected number of primes exceeds 1 (in fact it should be asymptotically ")#mi("2 \\Pi_2 / \\log_2 2 \\approx 3.8096\\ldots")#text(", where ")#mi("\\Pi_2 := 2 \\prod_{p > 2} (1 - \\frac{1}{(p-1)^2})")#text(" is the ")#link("http://primes.utm.edu/glossary/page.php?sort=TwinPrimeConstant")[#text("twin prime constant")]#text("), which means that the main result is unlikely to be established purely by the first moment method. Fortunately, a little bit of elementary sieving using, of all things, the prime factors of ")#link("http://mathworld.wolfram.com/MersenneNumber.html")[#text("Mersenne numbers")]#text(", allows one to manipulate the expected number of primes to be significantly less than 1, to the point where standard upper bound sieves (in particular, the Selberg sieve) give satisfactory results.")

#text("It is nice for a change to write an elementary paper of ")#strike[#text("six")]#text(" eight pages in length; the only moderately advanced tools I use here are the prime number theorem in arithmetic progressions, and the standard upper bound from the Selberg sieve for any two-dimensional sieving problem (in which one is allowed to eliminate up to two residue classes mod q for every prime q).")

#text("[")#emph[#text("Update")]#text(", Feb 25: It has been pointed out to me that the base 2 result was implicitly obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=376583")[#text("by Cohen and Selfridge")]#text(", and explicitly pointed out ")#link("http://www.ams.org/mathscinet-getitem?mr=1695111")[#text("by Sun")]#text(", using the covering congruence method ")#link("http://www.ams.org/mathscinet-getitem?mr=44558")[#text("of Erdős")]#text(", so I have rewritten the paper to focus primarily on the case of general bases (to which it is not entirely clear that a set of covering congruences exists). The earlier version (which focused only on the base 2 case, and so is slightly simpler) can be ")#link("http://arxiv.org/abs/0802.3361v2")[#text("found here")]#text(".]")

#text("[")#text("Update")#text(", Feb 26: It should now also be possible to prove the following generalisation: for any base a and any r, there should exist infinitely many primes which become composite whenever one changes one of the digits, and also appends or deletes up to r of digits on either end of the digit expansion. My method comes very close to establishing this result, except for one annoying issue arising from the fact that numbers such as ")#mi("j a^i + l")#text(" (with j, l = O(1)) can occasionally have a huge number of prime factors. This seems to be a rare event, though, so presumably one should be able to modify the argument to obtain this result. I’ll leave this for someone else to try, though. One should also be similarly able to replace “change one of the digits” to “delete or insert a digit at an arbitrary location”.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26633")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("There’s a typo on the bottom of page 3: “wheneverf i if of this form” should be changed to “whenever i is of this form”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26635")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("Dear Terry, that’s very insteresting. I think these primes (at least in base 2) are called “sigularly dead end primes”, see ")#link("http://www.research.att.com/~njas/sequences/A065092")[#text("sequence A065092 on OEIS")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("294001, I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("Thanks for the comments (and for the solution to the little puzzle)!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6935aed123d8368f5a7b8b282d2dd632316fa8cf55c316f3c6adcb42d5d42b18-8a26109c85af90639e4bd1be3d8e40a5ff64594eb2e6f5d8cb5bf32cf383f6d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jens Kruse Andersen")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26638")[#strong[#text("Jens Kruse Andersen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("The base-10 case is called a weakly prime. The first are in ")#link("http://www.research.att.com/~njas/sequences/A050249")[#text("http://www.research.att.com/~njas/sequences/A050249")]#text(". I found the 1000-digit example (17*10^1000-17)/99+21686652 for ")#link("http://www.primepuzzles.net/puzzles/puzz_017.htm")[#text("http://www.primepuzzles.net/puzzles/puzz_017.htm")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1962409330cbd1beaf3d754204de210f4c67cd1750cdfd2efefde25a2d1d381c-bf504f2573995aaa199a74238dac20ffbc086c927526cf541d43288863f2df99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26639")[#strong[#text("Tony")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("Sequence A065092 does not exactly meet your requirements because if prime p is an n-bit number then A065092 also requires that the (n+1)-bit number p+2^n is composite. Hence, the correct sequence, which is not in OEIS yet, has additional terms. That sequence begins 127, 173, 191, 223, 233, 239, 251, 257, 277, 337,…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26659")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Concerning the result of Heath-Brown and Puchta you mention in the paper (about even integers large enough being sum of two primes and at most 13 powers of 2, which is a rather remarkable approximation to Goldbach’s conjecture, first considered by Linnik if I remember right), Pintz and Ruzsa have announced that 13 can be replaced by 8, but the paper is not yet published (this is mentioned e.g. in “On the sum of two primes and k powers of two”, by Languasco, Pintz and Zaccagnini, Bull. London Math. Soc. 39 (2007) 771–780).")#linebreak()#text(" Either result is really impressive…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear all: Thanks for the references!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26664")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Re the February 26 update: For fixed a, r, are there infinitely many primes that become composite when any r digits in their base-a expansion are changed? I can’t see an obvious heuristics in either direction (although I admittedly haven’t worked through the arithmetic of the PNT on this one.) Does anyone know an obvious counterexample?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear Harrison,")

#text("I suspect the answer is negative when a is large and r is at least 2, though actually proving this is probably hopeless with current technology. The prime number theorem asserts, roughly speaking, that an n-digit number has a probability about 1/n of being prime (suppressing constants). On the other hand, the number of ways one can modify r digits of an n-digit number (with r fixed and n going to infinity) is comparable to n^r. Non-rigorous heuristics then suggest that the probability that any given number will remain composite after _all_ possible r-digit modifications is about (1-1/n)^{n^r} ~ exp( – n^{r-1} ). On the other hand, the number of n-digit numbers is about exp(n). This suggests (but does not prove) that for sufficiently large n, there are only finitely many numbers with this property for r > 2.")

#text("On the other hand, one can try to use covering congruences to make an end run around this problem; by considering what happens in small moduli (mod 2, mod 3, etc.) one can already eliminate a significant fraction of all r-digit modifications from being prime by choosing the initial prime to lie in a well-chosen residue class. It may be that by pushing this enough one can get some positive result for small a and r. For instance, it was recently established by Yuan (Acta Arith. 2004) that there are infinitely many numbers which become composite after subtracting any two powers of two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26674")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("A tiny note: if the goal is to show that you have to examine every digit to prove primality, then this is immediate in bases larger than 2. For instance in base 10 you can change any digit to make the sum of the digits of the number divisible by 9, which would make it composite. I realize this is different from *any* change of digit making it composite, which is what you’re after…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-26741")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2008")])]

#text("This is also related to:")

#link("http://www.research.att.com/~njas/sequences/A133219")[#text("http://www.research.att.com/~njas/sequences/A133219")]

#text("A133219 Smallest composite integer in base n which remains composite after altering any one or two digits.")

#text("n a(n)")#linebreak()#text(" 2 1010100")#linebreak()#text(" 3 2200100")#linebreak()#text(" 4 20130000")#linebreak()#text(" 5 3243003420")#linebreak()#text(" 6 55111253530")#linebreak()#text(" 7 5411665056000")#linebreak()#text(" 8 33254100107730")#linebreak()#text(" 9 210324811482600")#linebreak()#text(" 10 977731833235239280")

#text("OFFSET")#linebreak()#text(" 2,1")

#text("COMMENT")#linebreak()#text(" Changing the most significant digit to 0 is allowed. The problem (base 10) was posed by W. Sierpinski, published in 1977. There are an infinite number of solutions if a certain Erdos conjecture on congruences is true. a(2) through a(9) are proved minimal, a(10) has not yet been proved minimal.")

#text("LINKS")#linebreak()#text(" Witold Jarnicki and Maciej Zenczykowski, On a property of the number 977731833235239280.")

#text("EXAMPLE")#linebreak()#text(" a(3) base 10 = 1953.")#linebreak()#text(" a(4) base 10 = 34560.")#linebreak()#text(" a(5) base 10 = 7000485.")#linebreak()#text(" a(6) base 10 = 354748446.")#linebreak()#text(" a(7) base 10 = 77478704205.")#linebreak()#text(" a(8) base 10 = 1878528135128.")#linebreak()#text(" a(9) base 10 = 48398467146642.")

#text("KEYWORD")#linebreak()#text(" base,more,nonn")

#text("AUTHOR")#linebreak()#text(" Jonathan Vos Post (jvospost2(AT)yahoo.com), Oct 11 2007 [not the preferred email address anymore]")

#text("EXTENSIONS")#linebreak()#text(" a(2) and the definition were corrected by Witold Jarnicki, Oct 11 2007")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/534a088b01edf6b7d8352850394f5b883eaee6f56dc3d5840d5ca485d243e049-79dea0dd669964f53df59194f5dbdf16abe3ad98b61ae8a962027c4a1e6e01bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-27785")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Fermat’s (Little) Theorem: If p is a prime and if a is any integer, then ap = a (mod p). In particular, if p does not divide a, then ap-1 = 1 (mod p).")

#text("I think it would be interesting to use base 3 a ternary code in investigating primes. More specifically I would explore pseudoprimes. Further I would explore Mersenne numbers and Stern primes as they are unusual subsets within primality. I wouldn’t consider your paper so elementry as you may think. I would choose pseudoprimes first and see what develops.")

#text("If you can envision all primes as a tapestry, I would consider unusual subsets of primes as focal points within the tapestry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f25cfe2e0171970212c1b595a209ebbd956d579ee413a8a7323fecc39d50bc9d-943d6efe2ee974645653eed52575c4e69048f0a8aea99a85a6c257fef9499ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Montuerto")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-29747")[#strong[#text("Jaime Montuerto")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2008")])]

#text("dear Dr Tao,")

#text("I am working on a binary factoring algorithm and discovered this interesting property of 3 bit binary polynomials, 2^x + 2^y + 2^z , if x,y,z are all even, then the sum of these binary terms is multiple of 3. Is there a known theorem about this?")

#text("Jaime Montuerto")#linebreak()#text(" Sydney Australia")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-29823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("Dear Jaime,")

#text("If x,y,z are all even, then ")#mi("2^x, 2^y, 2^z")#text(" are all powers of 4. Since 4 = 1 mod 3, ")#mi("2^x, 2^y, 2^z")#text(" will also be equal to 1 mod 3, which is why ")#mi("2^x+2^y+2^z")#text(" is a multiple of 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f25cfe2e0171970212c1b595a209ebbd956d579ee413a8a7323fecc39d50bc9d-943d6efe2ee974645653eed52575c4e69048f0a8aea99a85a6c257fef9499ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Montuerto")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-29977")[#strong[#text("Jaime Montuerto")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("Dear Terry,")

#text("Thank you very much for your response. It is also true that 2^x+2^y+2^z, if all x,y,z are all odd it’s also multiple of 3. The problem of a prime in binary form")#linebreak()#text(" and if one of the bit is flip off (remove) the result would have a 1/2 chance of being multiple of 3. And if not multiple of 3 then the remainder would flip from 1 to 2 and vice versa.")

#text("This problem has the same algorithmic difficulty with even goldbach conjecture, ‘all even number is sum of 2 prime numbers’. I have an algorithm that gets pairs of primes for this. The basic component is exactly analysing what bit/s to transfer to another factor and what to add.")

#text("These are the result of my works.")

#text("1. Two even power bits equals to one odd power bit. 2^x+2^y = 2^z")#linebreak()#text(" ie, x,y are even and z is odd.")

#text("2. Two odd power bits equals to one even power bit. The opposite of above.")

#text("3. One even bit and one odd bit is a multiple of 3. Hence fermat numbers with one odd power bit is always multiple of 3, 1 being considered to have even power bit.")

#text("3. So that a set of 3 odd or even bits is multiple of 3.")#linebreak()#text(" Hence in analyzing the multiplicity by 3 of all binary integers just group all even power and odd power bits into set of 3 or simply the remainder of 3 to the sum, the remaining odd and even just paired them up. The result would have either no bit remains, one odd bit or one even bit. That’s why removing or adding a bit to any prime number would result in a 1/2 chance of being multiple of 3.")

#text("I am not quite sure whether these are quite obvious the way you show the")#linebreak()#text(" first one.")

#text("truly appreciated,")#linebreak()#text(" jaime")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-30007")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("Dear Jaime,")

#text("Divisibility with regard to small moduli (2, 3, etc.) are best approached using modular arithmetic; note from ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_theorem_%28group_theory%29")[#text("Cauchy’s theorem")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Euler%27s_theorem")[#text("Euler’s theorem")]#text(") that 2^x mod p is periodic in x with period p-1, which is why one has a lot of regularity when looking at small moduli.")

#text("But the bulk of the difficulty in primality testing is not with the small moduli, but with the large moduli. Consider for instance two numbers n and m. n is a 500-bit prime, whereas m is the product of two 250-bit primes. Both of these numbers are not divisible by 2, 3, 5, 7, or indeed by any prime with 249 bits or less. Nevertheless, only one of them is prime. How does one distinguish between the two just from the binary expansion? Applying divisibility tests all the way up to the 250 bit level is impractical. There are of course other methods for primality testing (for instance, Cauchy’s theorem as mentioned above already filters out most (though not all) non-primes), but they do require a certain amount of number theory beyond the modular arithmetic of small moduli.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f25cfe2e0171970212c1b595a209ebbd956d579ee413a8a7323fecc39d50bc9d-943d6efe2ee974645653eed52575c4e69048f0a8aea99a85a6c257fef9499ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Montuerto")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-30022")[#strong[#text("Jaime Montuerto")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("Dear Terry,")

#text("Again thanks for your considerable response.")

#text("Extending my argument I only mentioned prime 3 because it has those interesting properties. But there is a misinterpretation in my analysis in terms of the probability of being multiple of 3 if any bit is removed. It’s not 1/2 chance but 1/4 chance of being multiple of 3.")

#text("Here a more elaborated analysis.")

#text("Any prime larger than 3 has either 1 or 2 remainder mod 3. This is the same as saying a 1/2 chance of either 1 or 2. In my algorithm, any bit has the same remainder mod 3. Therefore if a particular prime in question say has 1 remainder and removing any bit has same 1/2 probability of being 1. So the actual probability is 1/2 * 1/2.")

#text("The probability with prime 5 is 1/4 * 1/4. The first probability is that any prime chosen would have a 1/4 chance of remainder in one of {1,2,3,4} and the second probability factor is that a bit removed would have same probability of being the same remainder.")

#text("This is the same for 7 of 1/6*1/6, 11 of 1/10*1/10, 13 of 1/12*1/12 and so on till the largest prime but less than the actual prime in question. Then i noticed that all these probabilities are the actual euler totient function square of the small primes.")

#text("So the probability of a smaller prime being the factor of a composite result would be its 1/phi(small prime) * 1/phi(small prime). As a whole, the overall probability is the summations of these probabilities. Hence, 1/2*1/2 + 1/4*1/4 + 1/6*1/6 + … + 1/square of totient function of largest prime.")

#text("This summation is uncannily similar to the riemann zeta function summation. For the term 1/n^2 in the riemann zeta function, what is the semiotic meaning of n in relation to euler totient term function (1 – 1/p)? Somehow it seems to me that the relationship of n to p is its totient function. So that the euler expression factor of (1-1/p) on the right hand side of equation is the probability of that prime p whereas the equivalent term of probability in the riemann zeta function is 1/n^2 which is to say that 1/square of the totient function of p. The 1/n^2 is the probability that relates to (1-1/p) as one to one mapping.")

#text("This is just an observation. And I hope I am clear in what I have said.")

#text("I would be happy for any reaction you could give.")

#text("Thanks again for your response – it was much appreciated.")

#text("Jaime")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-30724")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("Dear Professor 陶：")#linebreak()#text(" Xian-Jin Li uploaded a paper giving a proof of the Riemann hypothesis.")#linebreak()#text(" ")#link("http://arxiv.org/abs/0807.0090")[#text("http://arxiv.org/abs/0807.0090")]

#text("I wonder if you are paying attention to this.")

#text("刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6280d61902511b1b7cd1ba2dd317890adabf92be3754dfd603c37e34eedd7589-25f6607288a6cbf918e488107824d59a48e7d6b26b268917f34fa24dc7bc3168.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Johnson")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-46311")[#strong[#text("Charles Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2010")])]

#text("A proof of the Riemann hypothesis")#linebreak()#text(" Authors: Xian-Jin Li")#linebreak()#text(" (Submitted on 1 Jul 2008 (v1), last revised 6 Jul 2008 (this version, v4))")

#text("Abstract: This paper has been withdrawn by the author, due to a mistake on page 29.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D.Smith")]], [#link("https://terrytao.wordpress.com/2008/02/25/a-remark-on-primality-testing-and-the-binary-expansion/#comment-222799")[#strong[#text("Warren D.Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2013")])]

#text("1. typo: the “prime” 231 should have been 331 on the first page of your paper.")

#text("2. your paper’s main result theorem 1.2 can be strengthened so that the 1<=i is replaced by 0<=i. To do so, employ Brun's theorem (stated as \"corollary A3\" on Tao paper's last page)")#linebreak()#text(" to see that the proportion of the weaker theorem's")#linebreak()#text(" primes N which disobey this strengthened theorem, is")#linebreak()#text(" asymptotically zero.")

#text("3. Define P to be an \"every bit matters\" prime if altering any single bit in its binary representation, destroys primality. I conjecture that a constant fraction B of all primes, are every bit matters primes.")#linebreak()#text(" I conjecture that B=exp(-2*C2/ln2) where")#linebreak()#text(" C2=0.660161815846869573927812110014")#linebreak()#text(" is the Hardy-Littlewood twin prime constant.")#linebreak()#text(" Thus B=0.14884878474999065378100135978.")

#text("Similar notions can be defined for radices other than 2.")#linebreak()#text(" Then similar exact conjectures can be made.")#linebreak()#text(" One can prove a positive lower bound on liminfB, but sadly I")#linebreak()#text(" have no proof that liminfB=limsupB<1.")

#text("4. To prove limsupB<1 one would want (at least) to prove there exist")#linebreak()#text(" an infinity of primes such that when you alter one bit, you still have a prime.")#linebreak()#text(" I can prove that there exist an infinite set of primes, such that")#linebreak()#text(" altering 2 bits in their binary form, still gives a prime.")#linebreak()#text(" Indeed, this is even true if the two bits are demanded to lie in")#linebreak()#text(" the $n^{0.51}$ last bits of that prime (for n-bit-long primes written")#linebreak()#text(" in binary, all large-enough n).")
]
