// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/
// Converted to Typst by tao2typ: "2026-10-14T16:35:48.870237+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Structure and randomness in the prime numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Structure and randomness in the prime numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/")[#text("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am in Bremen, where the ")#link("http://www.imo2009.de/imo/index.php?option=com_content&view=frontpage&Itemid=1&lang=en")[#text("50th International Mathematical Olympiad")]#text(" is being held. A number of former Olympians (")#link("http://en.wikipedia.org/wiki/B%C3%A9la_Bollob%C3%A1s")[#text("Béla Bollobás")]#text(", ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Tim Gowers")]#text(", ")#link("http://en.wikipedia.org/wiki/L%C3%A1szl%C3%B3_Lov%C3%A1sz")[#text("Laci Lovasz")]#text(", ")#link("http://en.wikipedia.org/wiki/Stanislav_Smirnov")[#text("Stas Smirnov")]#text(", ")#link("http://en.wikipedia.org/wiki/Jean-Christophe_Yoccoz")[#text("Jean-Christophe Yoccoz")]#text(", and myself) were invited to give a short talk (20 minutes in length) at the celebratory event for this anniversary. I chose to talk on a topic I have spoken about several times before, on “")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/07/primes1.pdf")[#text("Structure and randomness in the prime numbers")]#text("“. Given the time constraints, there was a limit as to how much substance I could put into the talk; but I try to describe, in very general terms, what we know about the primes, and what we suspect to be true, but cannot yet establish. As I have mentioned in previous talks, the key problem is that we suspect the distribution of the primes to obey no significant patterns (other than “local” structure, such as having a strong tendency to be odd (which is local information at the 2 place), or obeying the prime number theorem (which is local information at the infinity place)), but we still do not have fully satisfactory tools for establishing the ")#emph[#text("absence")]#text(" of a pattern. (This is in contrast with many types of Olympiad problems, where the key to solving a problem often lies in discovering the right pattern or structure in the problem to exploit.)")

#text("The PDF of the talk is ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/07/primes1.pdf")[#text("here")]#text("; I decided to try out the Beamer LaTeX package for a change.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of buddy")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40136")[#strong[#text("buddy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Great talk T. I had a question which I found an answer to myself, but I’ll ask and answer it anyway:")

#text("If Vinogradov’s theorem says that the odd Goldbach conjecture is true for N sufficiently large, then why don’t we just check by computer all the remaining (finitely many) cases?")

#text("Answer, according to the ")#text("wikipedia article")#text(", is that the number of remaining cases is still way too big to check. Vinogradov’s student Borozdin showed that there are about 3^14348907 cases that would need checking. In 2002 Liu Ming-Chit and Wang Tian-Ze lowered the threshold to about 10^1346.")

#text("Current computer implementations have only been able to check up to about 10^18, so there’s still a long way to go.")

#text("Thanks for a great read-")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YAW-MENSAH")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-516820")[#strong[#text("YAW-MENSAH")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("je vais bien merci et vous")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pcaceres00")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-516822")[#strong[#text("pcaceres00")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Not knowing patterns does not mean that patterns don’t exist. It just means that we are not intelligent enough to discover the patterns. Example: I keep reading that the non-trivial zeros of zeta in the critical line are random and unrelated, when there is a clear algebraic expression that links any two NT zeros and the Harmonic function.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40137")[#strong[#text("Two gold medals in Bremen « Mathematics in Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")]

#text("[…] myself was at the event, giving a talk at the celebratory event for the 50th anniversary of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f3110a4fe11b8f0b11e3ce966c2ab2ac2e8f0a67944606caffbfd26cbfe3313-6c6d41a295497437ca2e6ac72536111291bf8459ae5a38a65e89cd98d8469fe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40577")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Great talk, I enjoyed the pdf file.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40641")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("The slides are very enjoyable, like telling a story…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40949")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("Prof Tao’s lectures are wonderful, I have some naive conjectures and questions:")

#text("1. I notice the series of reciprocal squares converge to pi^2/6, smaller than twin prime constant which is 1.902160583104 approximately, does it deduce that twin primes are denser than squares?")

#text("2. some research show that prime sequence is chaotic, some research show that prime number is pseudorandom, which standpoint is more exact?")

#text("3. between additive number theory and multiplicative number theory, which branch is more essential?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-40960")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("“twin primes are denser than squares” – but we don’t know if there are really an infinite number of twin primes, though no obstruction is known, and it’s generally considered extremely likely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ab1710251aaf86341fe50ef660e00eb8e32e888ee4bc9138e9866ee13330739-35a7149694db82658200aaad82cbf4eae579cb227a9b5b8b9d0b9cf72f1842a1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ippaso")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-41362")[#strong[#text("ippaso")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2009")])]

#text("Very interesting PDF. Can we found the text or a clip of the talk somewhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Structure and randomness in the prime numbers (IMO Festschrift submission) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-41404")[#strong[#text("Structure and randomness in the prime numbers (IMO Festschrift submission) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2009")])]

#text("[…] in math.NT, paper | Tags: international mathematical olympiad | by Terence Tao A few months ago, I gave a talk at the IMO in Bremen on “Structure and randomness in the prime numbers”. I have now […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-43915")[#strong[#text("Primes! And More Primes! And More Primes…. « Math Life")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2010")]

#text("[…] If you’re interested in this sort of thing, I would recommend taking a look at a blog post by Fields Medalist Terry Tao on structure and randomness in primes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-60651")[#strong[#text("IMO 2009 | Cogito")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2011")]

#text("[…] the slide from Tao’s IMO lecture, Structure and Randomness in the Prime Numbers (pdf), on his blog. Or watch a 1-hour public seminar he gave on the topic in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-237163")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("You say “We believe that the primes do not observe any significant")#linebreak()#text(" pattern beyond the obvious ones”. Are there exist a formal conjecture which formalises this statement? This would be a “grand unifying conjecture” of the prime distribution theory, which would imply the prime tuples conjecture (including twin prime conjecture), the Riemann Hypothesis, the Cramér’s conjecture, and all other not-yet-asked questions which are easy to verify assuming that “the primes do not observe any significant pattern beyond the obvious ones”.")

#text("If not, what do you think is the major difficulty in the formulation of such a conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-237194")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Cramér’s model, providing heuristic motivation for numerous conjectures, is pretty much it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-237284")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("No, it isn’t. I am asking about the formal conjecture, which can (in principle) be proved, and, after this, all these `heuristic motivation’ would become a strict proof. There is a formal definition of a random sequence ( see e.g.")#linebreak()#text(" ")#link("http://mathdl.maa.org/images/upload_library/22/Ford/Volchan46-63.pdf")[#text("http://mathdl.maa.org/images/upload_library/22/Ford/Volchan46-63.pdf")]#text(" ), and, for any random sequence A, all these “conjectures” (like there are infinitely many members p,q of A with |p-q|=2) are very easy theorems. This, however, is the formal definition of what is called “Basic heuristic” at ")#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")]#text(" Because primes is not completely random sequence, we need to formalise the notion of “Advanced heuristic” to formulate the iniversal conjecture…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-237261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("I don’t think there is a formal one-size-fits-all conjecture for this, but I expand a little more on this heuristic at ")#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e309a9112e2faa48eb08aae7b3902c39c832183154e92963553cfb472c7f6109-d02f28c80925f8fc07cd2a887132677552b8fb765fc14be38c2694266bb1aabb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Timbrell")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-467013")[#strong[#text("Phil Timbrell")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("May I ask a simple question from a non mathematician who loves maths! All integers are either in the prime set or the non prime set. So if we consider the set of non primes, is it not true they are the result of a mathematical function – that is the multiplying together of any two integers. If they are the result of a function then surely there must exist a way to describe them mathematically. And if you can describe a set of non prime mathematically then there must be a function to describe primes (those that are not non primes). In short, whilst the function may be incredibly complex or even impossible to describe, there must exist a pattern to primes, no matter how complex. Sorry if this is garbage to exprts but it seems logical to me.")

#text("For 16 years now I have been on the track of the Collatz conjecture, and whilst I know the experts have been unable to solve it since 1937 using traditional methods, I have been employing some alternative methods and am finding distinct patterns emerge. I believe there is a solution to that conjecture as well and someone one day will solve it, maybe not me but there is a pattern there, it only has to be coded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Caceres")]], [#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/#comment-489348")[#strong[#text("Pedro Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2017")])]

#text("I have never accepted the idea that Prime numbers are random. After time of research I have been able to formulate an algorithm to understand where Primes lie.")

#text("The set of prime numbers can be expressed as (Caceres, 2017):")

#text("{Primes} =")#linebreak()#text(" {2,3}")#linebreak()#text(" ∪")#linebreak()#text(" {6kn+1 | kn≠6xy+x+y and kn≠6xy-x-y for all x,y∈N}")#linebreak()#text(" ∪")#linebreak()#text(" {6km-1 | km≠6xy-x+y for all x,y∈N}")

#text("The generation of primes using this algorithm is complete based on the following observation:")

#text("1: With k=6xy+x+y, we have 6k+1 = 36xy+6x+6y+1 = (6x+1)(6y+1), i.e. all products of two factors both equivalent to +1 (mod 6);")

#text("2: With k=6xy-x-y, we have 6k+1 = 36xy-6x-6y+1 = (6x-1)(6y-1), i.e. all products of two factors both equivalent to -1 (mod 6);")

#text("3: With k=6xy-x+y, we have 6k-1 = 36xy-6x+6y-1 = (6x+1)(6y-1), i.e. all products of two factors, one equivalent to +1 (mod 6) and the other equivalent to -1 (mod 6).")

#text("Starting with the integers equivalent to ±1 (mod 6) and excluding these three sets leaves those integers equivalent to ±1 (mod 6) which cannot be represented as a product of two factors equivalent to ±1 (mod 6), i.e. the primes p≥5.")

#text("The first numbers in the generator series kn:")

#text("kn= 1, 2, 3, 5, 7, 10, 11, 12, 13, 16, 17, 18, 21, …")

#text("Generating primes pn=6*kn+1:")

#text("pn= 7, 13, 19, 31, 43, 61, 67, 73, 79, 97, 103, 109, 127,…")

#text("The first numbers in the generator series km:")

#text("km= 1, 2, 3, 5, 7, 8, 9, 10, 12, 14, 15, 17, 18, 19, 22 …")

#text("Generating primes pm=6*km-1:")

#text("pm= 5, 11, 17, 29, 41, 47, 53, 59, 71, 83, 89, 101, 107, 113, 131…")
]
