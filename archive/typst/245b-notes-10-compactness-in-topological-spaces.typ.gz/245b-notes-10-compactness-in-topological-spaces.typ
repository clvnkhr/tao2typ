// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/
// Converted to Typst by tao2typ: "2026-10-14T16:35:35.228956+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 10: Compactness in topological spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 10: Compactness in topological spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most useful concepts for analysis that arise from topology and metric spaces is the concept of ")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("compactness")]#text("; recall that a space ")#mi("{X}")#text(" is compact if every open cover of ")#mi("{X}")#text(" has a finite subcover, or equivalently if any collection of closed sets with the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" (i.e. every finite subcollection of these sets has non-empty intersection) has non-empty intersection. In these notes, we explore how compactness interacts with other key topological concepts: the ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff property")]#text(", ")#link("http://en.wikipedia.org/wiki/Base_(topology)")[#text("bases")]#text(" and ")#link("http://en.wikipedia.org/wiki/Subbase")[#text("sub-bases")]#text(", ")#link("http://en.wikipedia.org/wiki/Product_space")[#text("product spaces")]#text(", and ")#link("http://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuity")]#text(", in particular establishing the useful ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff")]#text(" and ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorems")]#text(" that give criteria for compactness (or ")#link("http://en.wikipedia.org/wiki/Relatively_compact_subspace")[#text("precompactness")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Basic properties of compact sets)")]#text(" ")#metadata(none) <tao-62951a31fd2ac7dbec21>

#list(
[#text("Show that any finite set is compact.")],
[#text("Show that any finite union of compact subsets of a topological space is still compact.")],
[#text("Show that any image of a compact space under a continuous map is still compact.")]
)

#text("Show that these three statements continue to hold if “compact” is replaced by “")#link("http://en.wikipedia.org/wiki/Sequentially_compact")[#text("sequentially compact")]#text("”.")
]

#metadata(none) <tao-0989f78dfb50583c8868>

#heading(level: 1)[#strong[#text(" — 1. Compactness and the Hausdorff property — ")]]

#text("Recall from ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(" that a topological space is ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" if every distinct pair ")#mi("{x, y}")#text(" of points can be separated by two disjoint open neighbourhoods ")#mi("{U, V}")#text(" of ")#mi("{x, y}")#text(" respectively; every metric space is Hausdorff, but not every topological space is.")

#text("At first glance, the Hausdorff property bears no resemblance to the compactness property. However, they are in some sense “dual” to each other, as the following two exercises show:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-94c2d7203af2a8ada06e>#text(" Let ")#mi("{X = (X,{\\mathcal F})}")#text(" be a compact topological space.")

#list(
[#text("Show that every closed subset in ")#mi("{X}")#text(" is compact.")],
[#text("Show that any weaker topology ")#mi("{{\\mathcal F}^{\\prime} \\subset {\\mathcal F}}")#text(" on ")#mi("{X}")#text(" also yields a compact topological space ")#mi("{(X, {\\mathcal F}^{\\prime})}")#text(".")],
[#text("Show that the ")#link("http://en.wikipedia.org/wiki/Trivial_topology")[#text("trivial topology")]#text(" on ")#mi("{X}")#text(" is always compact.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-d85d4a82a8444e8c2732>#text(" Let ")#mi("{X}")#text(" be a Hausdorff topological space.")

#list(
[#text("Show that every compact subset of ")#mi("{X}")#text(" is closed.")],
[#text("Show that any stronger topology ")#mi("{{\\mathcal F}^{\\prime} \\supset {\\mathcal F}}")#text(" on ")#mi("{X}")#text(" also yields a Hausdorff topological space ")#mi("{(X, {\\mathcal F}^{\\prime})}")#text(".")],
[#text("Show that the ")#link("http://en.wikipedia.org/wiki/Discrete_topology")[#text("discrete topology")]#text(" on ")#mi("{X}")#text(" is always Hausdorff.")]
)
]

#text("The first exercise asserts that compact topologies tend to be weak, while the second exercise asserts that Hausdorff topologies tend to be strong. The next lemma asserts that the two concepts only barely overlap:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-343677762813eaeb6570>#text(" Let ")#mi("{{\\mathcal F} \\subset {\\mathcal F}^{\\prime}}")#text(" be a weak and strong topology respectively on a space ")#mi("{X}")#text(". If ")#mi("{{\\mathcal F}^{\\prime}}")#text(" is compact and ")#mi("{{\\mathcal F}}")#text(" is Hausdorff, then ")#mi("{{\\mathcal F} = {\\mathcal F}^{\\prime}}")#text(". (In other words, a compact topology cannot be strictly stronger than a Hausdorff one, and a Hausdorff topology cannot be strictly weaker than a compact one.)")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{{\\mathcal F} \\subset {\\mathcal F}^{\\prime}}")#text(", every set which is closed in ")#mi("{(X,{\\mathcal F})}")#text(" is closed in ")#mi("{(X,{\\mathcal F}^{\\prime})}")#text(", and every set which is compact in ")#mi("{(X,{\\mathcal F}^{\\prime})}")#text(" is compact in ")#mi("{(X,{\\mathcal F})}")#text(". But from Exercises ")#link(<tao-94c2d7203af2a8ada06e>)[#text("2")]#text(", ")#link(<tao-d85d4a82a8444e8c2732>)[#text("3")]#text(", every set which is closed in ")#mi("{(X,{\\mathcal F}^{\\prime})}")#text(" is compact in ")#mi("{(X,{\\mathcal F}^{\\prime})}")#text(", and every set which is compact in ")#mi("{(X,{\\mathcal F})}")#text(" is closed in ")#mi("{(X,{\\mathcal F})}")#text(". Putting all this together, we see that ")#mi("{(X,{\\mathcal F})}")#text(" and ")#mi("{(X,{\\mathcal F}^{\\prime})}")#text(" have exactly the same closed sets, and thus have exactly the same open sets; in other words, ")#mi("{{\\mathcal F} = {\\mathcal F}^{\\prime}}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" Any continuous bijection ")#mi("{f: X \\rightarrow Y}")#text(" from a compact topological space ")#mi("{(X,{\\mathcal F}_X)}")#text(" to a Hausdorff topological space ")#mi("{(Y,{\\mathcal F}_Y)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]#text(".")
]

#emph[#text("Proof:")]#text(" Consider the ")#emph[#text("pullback")]#text(" ")#mi("{f^\\#({\\mathcal F}_Y) := \\{ f^{-1}(U): U \\in {\\mathcal F}_Y \\}}")#text(" of the topology on ")#mi("{Y}")#text(" by ")#mi("{f}")#text("; this is a topology on ")#mi("{X}")#text(". As ")#mi("{f}")#text(" is continuous, this topology is weaker than ")#mi("{{\\mathcal F}_X}")#text(", and thus by Lemma ")#link(<tao-343677762813eaeb6570>)[#text("1")]#text(" is equal to ")#mi("{{\\mathcal F}_X}")#text(". As ")#mi("{f}")#text(" is a bijection, this implies that ")#mi("{f^{-1}}")#text(" is continuous, and the claim follows. ")#mi("\\Box")

#text("One may wish to compare this corollary with Corollary 2 from ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("Notes 9")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Spaces which are both compact and Hausdorff (e.g. the unit interval ")#mi("{[0,1]}")#text(" with the usual topology) have many nice properties and are moderately common, so much so that the two properties are often concatenated as CH. Spaces that are ")#emph[#text("locally")]#text(" compact and Hausdorff (e.g. manifolds) are much more common and have nearly as many nice properties, and so these two properties are often concatenated as ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("LCH")]#text(". One should caution that (somewhat confusingly) in some older literature (particularly those in the French tradition), “compact” is used for “compact Hausdorff”.")
]

#text("(Optional) Another way to contrast compactness and the Hausdorff property is via the machinery of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(". Define an ")#emph[#text("filter")]#text(" on a space ")#mi("{X}")#text(" to be a collection ")#mi("{p}")#text(" of sets of ")#mi("{2^X}")#text(" which is closed under finite intersection, is also monotone (i.e. if ")#mi("{E \\in p}")#text(" and ")#mi("{E \\subset F \\subset X}")#text(", then ")#mi("{F \\in p}")#text("), and does not contain the empty set. Define an ")#emph[#text("ultrafilter")]#text(" to be a filter with the additional property that for any ")#mi("{E \\in X}")#text(", exactly one of ")#mi("{E}")#text(" and ")#mi("{X \\backslash E}")#text(" lies in ")#mi("{p}")#text(". (See also ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this blog post of mine")]#text(" for more discussion of ultrafilters.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Ultrafilter lemma)")]#text(" ")#metadata(none) <tao-425ed264c86619b9975b>#text(" Show that every filter is contained in at least one ultrafilter. (")#emph[#text("Hint")]#text(": use ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(", see ")#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("Notes 7")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-14f91bc93dc4f0ff486e>#text(" A collection of subsets of ")#mi("{X}")#text(" has the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" if every finite intersection of sets in the collection has non-empty intersection. Show that every filter has the finite intersection property, and that every collection of sets with the finite intersection property is contained in a filter (and hence contained in an ultrafilter, by the ultrafilter lemma).")
]

#text("Given a point ")#mi("{x \\in X}")#text(" and an ultrafilter ")#mi("{p}")#text(" on ")#mi("{X}")#text(", we say that ")#mi("{p}")#text(" ")#emph[#text("converges")]#text(" to ")#mi("{x}")#text(" if every neighbourhood of ")#mi("{x}")#text(" belongs to ")#mi("{p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that a space ")#mi("{X}")#text(" is Hausdorff if and only if every ultrafilter has at most one limit. (")#emph[#text("Hint:")]#text(" For the “if” part, observe that if ")#mi("{x, y}")#text(" cannot be separated by disjoint neighbourhoods, then the neighbourhoods of ")#mi("{x}")#text(" and ")#mi("{y}")#text(" together enjoy the finite intersection property.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-60b71dc726e801afaf04>#text(" Show that a space ")#mi("{X}")#text(" is compact if and only if every ultrafilter has at least one limit. (")#emph[#text("Hint:")]#text(" use the finite intersection property formulation of compactness and Exercise ")#link(<tao-14f91bc93dc4f0ff486e>)[#text("5")]#text(".)")
]

#heading(level: 1)[#strong[#text(" — 2. Compactness and bases — ")]]

#text("Compactness is the property that every open cover has a finite subcover. This property can be difficult to verify in practice, in part because the class of open sets is very large. However, in many cases one can replace the class of open sets with a much smaller class of sets. For instance, in metric spaces, a set is open if and only if it is the union of open balls (note that the union may be infinite or even uncountable). We can generalise this notion as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Base)")]#text(" Let ")#mi("{(X,{\\mathcal F})}")#text(" be a topological space. A ")#link("http://en.wikipedia.org/wiki/Base_(topology)")[#text("base")]#text(" for this space is a collection ")#mi("{{\\mathcal B}}")#text(" of open sets such that every open set in ")#mi("{X}")#text(" can be expressed as the union of sets in the base. The elements of ")#mi("{{\\mathcal B}}")#text(" are referred to as ")#emph[#text("basic open sets")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" The collection of open balls ")#mi("{B(x,r)}")#text(" in a metric space forms a base for the topology of that space. As another (rather trivial) example of a base: any topology ")#mi("{{\\mathcal F}}")#text(" is a base for itself.")
]

#text("This concept should be compared with that of a ")#emph[#text("basis")]#text(" of a vector space: every vector in that space can be expressed as a linear combination of vectors in a basis. However, one difference between a base and a basis is that the representation of an open set as the union of basic open sets is almost certainly not unique.")

#text("Given a base ")#mi("{{\\mathcal B}}")#text(", define a ")#emph[#text("basic open neighbourhood")]#text(" of a point ")#mi("{x \\in X}")#text(" to be a basic open set that contains ")#mi("{x}")#text(". Observe that a set ")#mi("{U}")#text(" is open if and only if every point in ")#mi("{U}")#text(" has a basic open neighbourhood contained in ")#mi("{U}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-3f349d1fec5a4d528510>#text(" Let ")#mi("{{\\mathcal B}}")#text(" be a collection of subsets of a set ")#mi("{X}")#text(". Show that ")#mi("{{\\mathcal B}}")#text(" is a base for some topology ")#mi("{{\\mathcal F}}")#text(" if and only if it it covers ")#mi("{X}")#text(" and has the following additional property: given any ")#mi("{x \\in X}")#text(" and any two basic open neighbourhoods ")#mi("{U, V}")#text(" of ")#mi("{x}")#text(", there exists another basic open neighbourhood ")#mi("{W}")#text(" of ")#mi("{x}")#text(" that is contained in ")#mi("{U \\cap V}")#text(". Furthermore, the topology ")#mi("{{\\mathcal F}}")#text(" is uniquely determined by ")#mi("{{\\mathcal B}}")#text(".")
]

#text("To verify the compactness property, it suffices to do so for basic open covers (i.e. coverings of the whole space by basic open sets):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-99025b7cb34a9b3a92e2>#text(" Let ")#mi("{(X,{\\mathcal F})}")#text(" be a topological space with a base ")#mi("{{\\mathcal B}}")#text(". Then the following are equivalent:")

#list(
[#text("Every open cover has a finite subcover (i.e. ")#mi("{X}")#text(" is compact);")],
[#text("Every basic open cover has a finite subcover.")]
)
]

#text("A useful fact about compact metric spaces is that they are in some sense “countably generated”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-c19588ee9c7265b5eae9>#text(" Let ")#mi("{X = (X,d_X)}")#text(" be a compact metric space.")

#list(
[#text("(i) ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(" (i.e. it has an at most countably infinite dense subset).")],
[#text("(ii) ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Second-countable_space")[#text("second-countable")]#text(" (i.e. it has an at most countably infinite base).")]
)
]

#emph[#text("Proof:")]#text(" By Theorem 1 of ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(", ")#mi("{X}")#text(" is totally bounded. In particular, for every ")#mi("{n \\geq 1}")#text(", one can cover ")#mi("{X}")#text(" by a finite number of balls ")#mi("{B(x_{n,1},\\frac{1}{n}),\\ldots,B(x_{n,k_n},\\frac{1}{n})}")#text(" of radius ")#mi("{\\frac{1}{n}}")#text(". The set of points ")#mi("{\\{ x_{n,i}: n \\geq 1; 1 \\leq i \\leq k_n \\}}")#text(" is then easily verified to be dense and at most countable, giving (i). Similarly, the set of balls ")#mi("{\\{ B( x_{n,i}, \\frac{1}{n} ): n \\geq 1; 1 \\leq i \\leq k_n \\}}")#text(" can be easily verified to be a base which is at most countable, giving (ii). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can easily generalise compactness here to ")#mi("{\\sigma}")#text("-compactness; thus for instance finite-dimensional vector spaces ")#mi("{{\\mathbb R}^n}")#text(" are separable and second-countable. The properties of separability and second-countability are much weaker than ")#mi("{\\sigma}")#text("-compactness in general, but can still serve to provide some constraint as to the “size” or “complexity” of a metric space or topological space in many situations.")
]

#text("We now weaken the notion of a base to that of a ")#link("http://en.wikipedia.org/wiki/Subbase")[#text("sub-base")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Sub-base)")]#text(" Let ")#mi("{(X,{\\mathcal F})}")#text(" be a topological space. A ")#emph[#text("sub-base")]#text(" for this space is a collection ")#mi("{{\\mathcal B}}")#text(" of subsets of ")#mi("{X}")#text(" such that ")#mi("{{\\mathcal F}}")#text(" is the weakest topology that makes ")#mi("{{\\mathcal B}}")#text(" open (i.e. ")#mi("{{\\mathcal F}}")#text(" is generated by ")#mi("{{\\mathcal B}}")#text("). Elements of ")#mi("{{\\mathcal B}}")#text(" are referred to as ")#emph[#text("sub-basic open sets")]#text(".")
]

#text("Observe for instance that every base is a sub-base. The converse is not true: for instance, the half-open intervals ")#mi("{(-\\infty,a), (a,+\\infty)}")#text(" for ")#mi("{a \\in {\\mathbb R}}")#text(" form a sub-base for the standard topology on ")#mi("{{\\mathbb R}}")#text(", but not a base. In contrast to bases, which need to obey the property in Exercise ")#link(<tao-3f349d1fec5a4d528510>)[#text("8")]#text(", no property is required on a collection ")#mi("{{\\mathcal B}}")#text(" in order for it to be a sub-base; every collection of sets generates a unique topology with respect to which it is a sub-base.")

#text("The precise relationship between sub-bases and bases is given by the following exercise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-9444d59f67b9aad0a74e>#text(" Let ")#mi("{(X,{\\mathcal F})}")#text(" be a topological space, and let ")#mi("{{\\mathcal B}}")#text(" be a collection of subsets of ")#mi("{X}")#text(". Then the following are equivalent:")

#list(
[#mi("{{\\mathcal B}}")#text(" is a sub-base for ")#mi("{(X,{\\mathcal F})}")#text(".")],
[#text("The space ")#mi("{{\\mathcal B}^* := \\{ B_1 \\cap \\ldots \\cap B_k: B_1,\\ldots,B_k \\in {\\mathcal B} \\}}")#text(" of finite intersections of ")#mi("{{\\mathcal B}}")#text(" (including the whole space ")#mi("{X}")#text(", which corresponds to the case ")#mi("{k=0}")#text(") is a base for ")#mi("{(X,{\\mathcal F})}")#text(".")]
)
]

#text("Thus a set is open iff it is the union of finite intersections of sub-basic open sets.")

#text("Many topological facts involving open sets can often be reduced to verifications on basic or sub-basic open sets, as the following exercise illustrates:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{(X, {\\mathcal F})}")#text(" be a topological space, and ")#mi("{{\\mathcal B}}")#text(" be a sub-base of ")#mi("{X}")#text(", and let ")#mi("{{\\mathcal B}^*}")#text(" be a base of ")#mi("{X}")#text(".")

#list(
[#text("Show that a sequence ")#mi("{x_n \\in X}")#text(" converges to a limit ")#mi("{x \\in X}")#text(" if and only if every sub-basic open neighbourhood of ")#mi("{x}")#text(" contains ")#mi("{x_n}")#text(" for all sufficiently large ")#mi("{x_n}")#text(". (Optional: show that an analogous statement is also true for nets.)")],
[#text("Show that a point ")#mi("{x \\in X}")#text(" is adherent to a set ")#mi("{E}")#text(" if and only if every basic open neighbourhood of ")#mi("{x}")#text(" intersects ")#mi("{E}")#text(". Give an example to show that the claim fails for sub-basic open sets.")],
[#text("Show that a point ")#mi("{x \\in X}")#text(" is in the interior of a set ")#mi("{U}")#text(" if and only if ")#mi("{U}")#text(" contains a basic open neighbourhood of ")#mi("{x}")#text(". Give an example to show that the claim fails for sub-basic open sets.")],
[#text("If ")#mi("{Y}")#text(" is another topological space, show that a map ")#mi("{f: Y \\rightarrow X}")#text(" is continuous if and only if the inverse image of every sub-basic open set is open.")]
)
]

#text("There is a useful strengthening of Exercise ")#link(<tao-99025b7cb34a9b3a92e2>)[#text("9")]#text(" in the spirit of the above exercise, namely the ")#link("http://en.wikipedia.org/wiki/Subbase#Alexander_subbase_theorem")[#text("Alexander sub-base theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Alexander sub-base theorem)")]#text(" ")#metadata(none) <tao-541313cc200e4b119465>#text(" Let ")#mi("{(X,{\\mathcal F})}")#text(" be a topological space with a sub-base ")#mi("{{\\mathcal B}}")#text(". Then the following are equivalent:")

#list(
[#text("Every open cover has a finite subcover (i.e. ")#mi("{X}")#text(" is compact);")],
[#text("Every sub-basic open cover has a finite subcover.")]
)
]

#emph[#text("Proof:")]#text(" Call an open cover ")#emph[#text("bad")]#text(" if it had no finite subcover, and ")#emph[#text("good")]#text(" otherwise. In view of Exercise ")#link(<tao-99025b7cb34a9b3a92e2>)[#text("9")]#text(", it suffices to show that if every sub-basic open cover is good, then every basic open cover is good also, where we use the basis ")#mi("{{\\mathcal B}^*}")#text(" coming from Exercise ")#link(<tao-9444d59f67b9aad0a74e>)[#text("10")]#text(".")

#text("Suppose for contradiction that every sub-basic open cover was good, but at least one basic open cover was bad. If we order the bad basic open covers by set inclusion, observe that every chain of bad basic open covers has an upper bound that is also a bad basic open cover, namely the union of all the covers in the chain. Thus, by Zorn’s lemma, there exists a maximal bad basic open cover ")#mi("{{\\mathcal C} = (U_\\alpha)_{\\alpha \\in A}}")#text(". Thus this cover has no finite subcover, but if one adds any new basic open set to this cover, then there must now be a finite subcover.")

#text("Pick a basic open set ")#mi("{U_\\alpha}")#text(" in this cover ")#mi("{{\\mathcal C}}")#text(". Then we can write ")#mi("{U_{\\alpha} = B_1 \\cap \\ldots \\cap B_k}")#text(" for some sub-basic open sets ")#mi("{B_1,\\ldots,B_k}")#text(". We claim that at least one of the ")#mi("{B_1,\\ldots,B_k}")#text(" also lie in the cover ")#mi("{{\\mathcal C}}")#text(". To see this, suppose for contradiction that none of the ")#mi("{B_1,\\ldots,B_k}")#text(" was in ")#mi("{{\\mathcal C}}")#text(". Then adding any of the ")#mi("{B_i}")#text(" to ")#mi("{{\\mathcal C}}")#text(" enlarges the basic open cover and thus creates a finite subcover; thus ")#mi("{B_i}")#text(" together with finitely many sets from ")#mi("{{\\mathcal C}}")#text(" cover ")#mi("{X}")#text(", or equivalently that one can cover ")#mi("{X \\backslash B_i}")#text(" with finitely many sets from ")#mi("{{\\mathcal C}}")#text(". Thus one can also cover ")#mi("{X \\backslash U_\\alpha = \\bigcup_{i=1}^k (X \\backslash B_i)}")#text(" with finitely many sets from ")#mi("{{\\mathcal C}}")#text(", and thus ")#mi("{X}")#text(" itself can be covered by finitely many sets from ")#mi("{{\\mathcal C}}")#text(", a contradiction.")

#text("From the above discussion and the axiom of choice, we see that for each basic set ")#mi("{U_\\alpha}")#text(" in ")#mi("{{\\mathcal C}}")#text(" there exists a sub-basic set ")#mi("{B_\\alpha}")#text(" containing ")#mi("{U_\\alpha}")#text(" that also lies in ")#mi("{{\\mathcal C}}")#text(". (Two different basic sets ")#mi("{U_\\alpha, U_\\beta}")#text(" could lead to the same sub-basic set ")#mi("{B_\\alpha=B_\\beta}")#text(", but this will not concern us.) Since the ")#mi("{U_\\alpha}")#text(" cover ")#mi("{X}")#text(", the ")#mi("{B_\\alpha}")#text(" do also. By hypothesis, a finite number of ")#mi("{B_\\alpha}")#text(" can cover ")#mi("{X}")#text(", and so ")#mi("{{\\mathcal C}}")#text(" is good, which gives the desired a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-4a62c90aa8e11fe50cea>#text(" (Optional) Use Exercise ")#link(<tao-60b71dc726e801afaf04>)[#text("7")]#text(" to give another proof of the Alexander sub-base theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Use the Alexander sub-base theorem to show that the unit interval ")#mi("{[0,1]}")#text(" (with the usual topology) is compact, without recourse to the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel")]#text(" or ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass")]#text(" theorems.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{X}")#text(" be a well-ordered set, endowed with the order topology (Exercise 9 of ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text("); such a space is known as an ordinal space. Show that ")#mi("{X}")#text(" is Hausdorff, and that ")#mi("{X}")#text(" is compact if and only if ")#mi("{X}")#text(" has a maximal element.")
]

#text("One of the major applications of the sub-base theorem is to prove ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(", which we turn to next.")

#heading(level: 1)[#strong[#text(" — 3. Compactness and product spaces — ")]]

#text("Given two topological spaces ")#mi("{X = (X, {\\mathcal F}_X)}")#text(" and ")#mi("{Y = (Y, {\\mathcal F}_Y)}")#text(", we can form the ")#link("http://en.wikipedia.org/wiki/Product_space")[#text("product space")]#text(" ")#mi("{X \\times Y}")#text(", using the cylinder sets ")#mi("{\\{ U \\times Y: U \\in {\\mathcal F}_X \\} \\cup \\{ X \\times V: V \\in {\\mathcal F}_Y\\}}")#text(" as a sub-base, or equivalently using the open boxes ")#mi("{\\{ U \\times V: U \\in {\\mathcal F}_X, V \\in {\\mathcal F}_Y \\}}")#text(" as a base (cf. Example 15 from ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text("). One easily verifies that the obvious projection maps ")#mi("{\\pi_X: X \\times Y \\rightarrow X}")#text(", ")#mi("{\\pi_Y: X \\times Y \\rightarrow Y}")#text(" are continuous, and that these maps also provide homeomorphisms between ")#mi("{X \\times \\{y\\}}")#text(" and ")#mi("{X}")#text(", or between ")#mi("{\\{x\\} \\times Y}")#text(" and ")#mi("{Y}")#text(", for every ")#mi("{x \\in X, y \\in Y}")#text(". Also observe that a sequence ")#mi("{(x_n,y_n)_{n=1}^\\infty}")#text(" (or net ")#mi("{(x_\\alpha,y_\\alpha)_{\\alpha \\in A}}")#text(") converges to a limit ")#mi("{(x,y)}")#text(" in ")#mi("{X}")#text(" if and only if ")#mi("{(x_n)_{n=1}^\\infty}")#text(" and ")#mi("{(y_n)_{n=1}^\\infty}")#text(" (or ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" and ")#mi("{(y_\\alpha)_{\\alpha \\in A}}")#text(") converge in ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" to ")#mi("{x}")#text(" and ")#mi("{y}")#text(" respectively.")

#text("This operation preserves a number of useful topological properties, for instance")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Prove that the product of two Hausdorff spaces is still Hausdorff.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-52c4bcb9c169db465f20>#text(" Prove that the product of two sequentially compact spaces is still sequentially compact.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" The product of two compact spaces is compact.")
]

#emph[#text("Proof:")]#text(" By Exercise ")#link(<tao-99025b7cb34a9b3a92e2>)[#text("9")]#text(" it suffices to show that any basic open cover of ")#mi("{X \\times Y}")#text(" by boxes ")#mi("{(U_\\alpha \\times V_\\alpha)_{\\alpha \\in A}}")#text(" has a finite subcover. For any ")#mi("{x \\in X}")#text(", this open cover covers ")#mi("{\\{x\\} \\times Y}")#text("; by the compactness of ")#mi("{Y \\equiv \\{x\\} \\times Y}")#text(", we can thus cover ")#mi("{\\{x\\} \\times Y}")#text(" by a finite number of open boxes ")#mi("{U_\\alpha \\times V_\\alpha}")#text(". Intersecting the ")#mi("{U_\\alpha}")#text(" together, we obtain a neighbourhood ")#mi("{U_x}")#text(" of ")#mi("{x}")#text(" such that ")#mi("{U_x \\times Y}")#text(" is covered by a finite number of these boxes. But by compactness of ")#mi("{X}")#text(", we can cover ")#mi("{X}")#text(" by a finite number of ")#mi("{U_x}")#text(". Thus all of ")#mi("{X \\times Y}")#text(" can be covered by a finite number of boxes in the cover, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" (Optional) Obtain an alternate proof of this proposition using Exercise 14 from ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(".")
]

#text("The above theory for products of two spaces extends without difficulty to products of finitely many spaces. Now we consider infinite products.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Product spaces)")]#text(" Given a family ")#mi("{(X_\\alpha,{\\mathcal F}_\\alpha)_{\\alpha \\in A}}")#text(" of topological spaces, let ")#mi("{X := \\prod_{\\alpha \\in A} X_\\alpha}")#text(" be the Cartesian product, i.e. the space of tuples ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" with ")#mi("{x_\\alpha \\in X_\\alpha}")#text(" for all ")#mi("{\\alpha \\in A}")#text(". For each ")#mi("{\\alpha \\in A}")#text(", we have the obvious projection map ")#mi("{\\pi_\\alpha: X \\rightarrow X_\\alpha}")#text(" that maps ")#mi("{(x_\\beta)_{\\beta \\in A}}")#text(" to ")#mi("{x_\\alpha}")#text(".")

#list(
[#text("We define the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text(" on ")#mi("{X}")#text(" to be the topology generated by the cylinder sets ")#mi("{\\pi_\\alpha^{-1}(U_\\alpha)}")#text(" for ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{U_\\alpha \\in {\\mathcal F}_\\alpha}")#text(" as a sub-base, or equivalently the weakest topology that makes all of the ")#mi("{\\pi_\\alpha}")#text(" continuous.")],
[#text("We define the ")#link("http://en.wikipedia.org/wiki/Box_topology")[#text("box topology")]#text(" on ")#mi("{X}")#text(" to be the topology generated by all the boxes ")#mi("{\\prod_{\\alpha \\in A} U_\\alpha}")#text(", where ")#mi("{U_\\alpha \\in {\\mathcal F}_\\alpha}")#text(" for all ")#mi("{\\alpha \\in A}")#text(".")]
)

#text("Unless otherwise specified, we assume the product space to be endowed with the product topology rather than the box topology.")
]

#text("When ")#mi("{A}")#text(" is finite, the product topology and the box topology coincide. When ")#mi("{A}")#text(" is infinite, the two topologies are usually different (as we shall see), but the box topology is always at least as strong as the product topology. Actually, in practice the box topology is too strong to be of much use – there are not enough convergent sequences in it. For instance, in the space ")#mi("{{}{\\mathbb R}^{{\\mathbb N}}}")#text(" of real-valued sequences ")#mi("{(x_n)_{n=1}^\\infty}")#text(", even sequences such as ")#mi("{(\\frac{1}{m!} e^{-nm})_{n=1}^\\infty}")#text(" do not converge to the zero sequence as ")#mi("{m \\rightarrow \\infty}")#text(" (why?), despite converging in just about every other sense.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that the arbitrary product of Hausdorff spaces remains Hausdorff in either the product or the box topology.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{(X_n,d_n)}")#text(" be a sequence of metric spaces. Show that the the function ")#mi("{d: X \\times X \\rightarrow {\\mathbb R}^+}")#text(" on the product space ")#mi("{X := \\prod_n X_n}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("d( (x_n)_{n=1}^\\infty, (y_n)_{n=1}^\\infty ) := \\sum_{n=1}^\\infty 2^{-n} \\frac{d_n(x_n,y_n)}{1+d_n(x_n,y_n)}")]]

#text("is a metric on ")#mi("{X}")#text(" which generates the product topology on ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-251fecd592e56e6c4a95>#text(" Let ")#mi("{X = \\prod_{\\alpha \\in A} X_\\alpha}")#text(" be a product space with the product topology. Show that a sequence ")#mi("{x_n}")#text(" in that space converges to a limit ")#mi("{x \\in X}")#text(" if and only if ")#mi("{\\pi_\\alpha(x_n)}")#text(" converges in ")#mi("{X_\\alpha}")#text(" to ")#mi("{\\pi_\\alpha(x)}")#text(" for every ")#mi("{\\alpha \\in A}")#text(". (The same statement also holds for ")#link("http://en.wikipedia.org/wiki/Net_(mathematics)")[#text("nets")]#text(".) Thus convergence in the product topology is essentially the same concept as pointwise convergence (cf. Example 14 of ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(").")
]

#text("The box topology usually does not preserve compactness. For instance, one easily checks that the product of any number of discrete spaces is still discrete in the box topology. On the other hand, a discrete space is compact (or sequentially compact) if and only if it is finite. Thus the infinite product of any number of non-trivial (i.e. having at least two elements) compact discrete spaces will be non-compact, and similarly for sequential compactness.")

#text("The situation improves significantly with the product topology, however (which is weaker, and thus more likely to be compact). We begin with the situation for sequential compactness.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Sequential Tychonoff theorem)")]#text(" ")#metadata(none) <tao-4f5260d71c7e332a2c94>#text(" Any at most countable product of sequentially compact topological spaces is sequentially compact.")
]

#emph[#text("Proof:")]#text(" We will use the “Arzelá-Ascoli ")#link("http://en.wikipedia.org/wiki/Cantor%27s_diagonal_argument")[#text("diagonalisation argument")]#text("”. The finite case is already handled by Exercise ")#link(<tao-52c4bcb9c169db465f20>)[#text("16")]#text(" (and can in any event be easily deduced from the countable case), so suppose we have a countably infinite sequence ")#mi("{(X_n, {\\mathcal F}_n)_{n=1}^\\infty}")#text(" of sequentially compact spaces, and consider the product space ")#mi("{X = \\prod_{n=1}^\\infty X_n}")#text(" with the product topology. Let ")#mi("{x^{(1)}, x^{(2)}, \\ldots}")#text(" be a sequence in ")#mi("{X}")#text(", thus each ")#mi("{x^{(m)}}")#text(" is itself a sequence ")#mi("{x^{(m)} = (x^{(m)}_n)_{n=1}^\\infty}")#text(" with ")#mi("{x^{(m)}_n \\in X_n}")#text(" for all ")#mi("{n}")#text(". Our objective is to find a subsequence ")#mi("{x^{(m_j)}}")#text(" which converges to some limit ")#mi("{x = (x_n)_{n=1}^\\infty}")#text(" in the product topology, which by Exercise ")#link(<tao-251fecd592e56e6c4a95>)[#text("20")]#text(" is the same as pointwise convergence (i.e. ")#mi("{x^{(m_j)}_n \\rightarrow x_n}")#text(" as ")#mi("{j \\rightarrow \\infty}")#text(" for each ")#mi("{n}")#text(").")

#text("Consider the first coordinates ")#mi("{x^{(m)}_1 \\in X_1}")#text(" of the sequence ")#mi("{x^{(m)}}")#text(". As ")#mi("{X_1}")#text(" is sequentially compact, we can find a subsequence ")#mi("{(x^{(m_{1,j})})_{j=1}^\\infty}")#text(" in ")#mi("{X}")#text(" such that ")#mi("{x^{(m_{1,j})}_1}")#text(" converges in ")#mi("{X_1}")#text(" to some limit ")#mi("{x_1 \\in X_1}")#text(".")

#text("Now, in this subsequence, consider the second coordinates ")#mi("{x^{(m_{1,j})}_2 \\in X_2}")#text(". As ")#mi("{X_2}")#text(" is sequentially compact, we can find a further subsequence ")#mi("{(x^{(m_{2,j})})_{j=1}^\\infty}")#text(" in ")#mi("{X}")#text(" such that ")#mi("{x^{(m_{2,j})}_2}")#text(" converges in ")#mi("{X_2}")#text(" to some limit ")#mi("{x_2 \\in X_1}")#text(". Also, we inherit from the preceding subsequence that ")#mi("{x^{(m_{2,j})}_1}")#text(" converges in ")#mi("{X_1}")#text(" to ")#mi("{x_1}")#text(".")

#text("We continue in this vein, creating nested subsequences ")#mi("{(x^{(m_{i,j})})_{j=1}^\\infty}")#text(" for ")#mi("{i=1,2,3,\\ldots}")#text(" whose first ")#mi("{i}")#text(" components ")#mi("{x^{(m_{i,j})}_1, \\ldots, x^{(m_{i,j})}_i}")#text(" converge to ")#mi("{x_1 \\in X_1, \\ldots, x_i \\in X_i}")#text(" respectively.")

#text("None of these subsequences, by themselves are sufficient to finish the problem. But now we use the diagonalisation trick: we consider the diagonal sequence ")#mi("{(x^{(m_{j,j})})_{j=1}^\\infty}")#text(". One easily verifies that ")#mi("{x^{(m_{j,j})}_n}")#text(" converges in ")#mi("{X_n}")#text(" to ")#mi("{x_n}")#text(" as ")#mi("{j \\rightarrow \\infty}")#text(" for every ")#mi("{n}")#text(", and so we have extracted a sequence that is convergent in the product topology. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In the converse direction, if a product of spaces is sequentially compact, then each of the factor spaces must also be sequentially compact, since they are continuous images of the product space and one can apply Exercise ")#link(<tao-62951a31fd2ac7dbec21>)[#text("1")]#text(".")
]

#text("The sequential Tychonoff theorem breaks down for uncountable products. Consider for instance the product space ")#mi("{X := \\{0,1\\}^{\\{0,1\\}^{\\mathbb N}}}")#text(" of functions ")#mi("{f: \\{0,1\\}^{\\mathbb N} \\rightarrow \\{0,1\\}}")#text(". As ")#mi("{\\{0,1\\}}")#text(" (with the discrete topology) is sequentially compact, this is an (uncountable) product of sequentially compact spaces. On the other hand, for each ")#mi("{n \\in {\\mathbb N}}")#text(" we can define the evaluation function ")#mi("{f_n: \\{0,1\\}^{\\mathbb N} \\rightarrow \\{0,1\\}}")#text(" by ")#mi("{f_n: (a_m)_{m=1}^\\infty \\mapsto a_n}")#text(". This is a sequence in ")#mi("{X}")#text("; we claim that it has no convergent subsequence. Indeed, given any ")#mi("{n_j \\rightarrow \\infty}")#text(", we can find ")#mi("{x = (x_m)_{m=1}^\\infty \\in \\{0,1\\}^{\\mathbb N}}")#text(" such that ")#mi("{x_{n_j} = f_{n_j}(x)}")#text(" does not converge to a limit as ")#mi("{j \\rightarrow \\infty}")#text(", and so ")#mi("{f_{n_j}}")#text(" does not converge pointwise (i.e. does not converge in the product topology).")

#text("However, we can recover the result for uncountable products as long as we work with topological compactness rather than sequential compactness, leading to ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Tychonoff theorem)")]#text(" ")#metadata(none) <tao-2c2c6f9c989e1bb132d6>#text(" Any product of compact topological spaces is compact.")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{X = \\prod_{\\alpha \\in A} X_\\alpha}")#text(" for this product of compact topological spaces. By Theorem ")#link(<tao-541313cc200e4b119465>)[#text("6")]#text(", it suffices to show that any open cover of ")#mi("{X}")#text(" by sub-basic open sets ")#mi("{(\\pi_{\\alpha_\\beta}^{-1}(U_{\\beta}))_{\\beta \\in B}}")#text(" has a finite sub-cover, where ")#mi("{B}")#text(" is some index set, and for each ")#mi("{\\beta \\in B}")#text(", ")#mi("{\\alpha_\\beta \\in A}")#text(" and ")#mi("{U_{\\beta}}")#text(" is open in ")#mi("{X_{\\alpha_\\beta}}")#text(".")

#text("For each ")#mi("{\\alpha \\in A}")#text(", consider the sub-basic open sets ")#mi("{\\pi_{\\alpha}^{-1}(U_{\\beta})}")#text(" that are associated to those ")#mi("{\\beta \\in B}")#text(" with ")#mi("{\\alpha_\\beta = \\alpha}")#text(". If the open sets ")#mi("{U_\\beta}")#text(" here cover ")#mi("{X_\\alpha}")#text(", then by compactness of ")#mi("{X_\\alpha}")#text(", a finite number of the ")#mi("{U_\\beta}")#text(" already suffice to cover ")#mi("{X_\\alpha}")#text(", and so a finite number of the ")#mi("{\\pi_{\\alpha}^{-1}(U_{\\beta})}")#text(" cover ")#mi("{X}")#text(", and we are done. So we may assume that the ")#mi("{U_\\beta}")#text(" do not cover ")#mi("{X_\\alpha}")#text(", thus there exists ")#mi("{x_\\alpha \\in X_\\alpha}")#text(" that avoids all the ")#mi("{U_\\beta}")#text(" with ")#mi("{\\alpha_\\beta = \\alpha}")#text(". One then sees that the point ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" in ")#mi("{X}")#text(" avoids all of the ")#mi("{\\pi_{\\alpha}^{-1}(U_{\\beta})}")#text(", a contradiction. The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The axiom of choice was used in several places in the proof (in particular, via the Alexander sub-base theorem). This turns out to be necessary, because one can use Tychonoff’s theorem to establish the axiom of choice. This was first observed by Kelley, and can be sketched as follows. It suffices to show that the product ")#mi("{\\prod_{\\alpha \\in A} X_\\alpha}")#text(" of non-empty sets is again non-empty. We can make each ")#mi("{X_\\alpha}")#text(" compact (e.g. by using the trivial topology). We then adjoin an isolated element ")#mi("{\\infty}")#text(" to each ")#mi("{X_\\alpha}")#text(" to obtain another compact space ")#mi("{X_\\alpha \\cup \\{\\infty\\}}")#text(", with ")#mi("{X_\\alpha}")#text(" closed in ")#mi("{X_\\alpha \\cup \\{\\infty\\}}")#text(". By Tychonoff’s theorem, the product ")#mi("{X := \\prod_{\\alpha \\in A} (X_\\alpha \\cup \\{\\infty\\})}")#text(" is compact, and thus every collection of closed sets with finite intersection property has non-empty intersection. But observe that the sets ")#mi("{\\pi_\\alpha^{-1}(X_\\alpha)}")#text(" in ")#mi("{X}")#text(", where ")#mi("{\\pi_\\alpha: X \\rightarrow X_\\alpha \\cup \\{\\infty\\}}")#text(" is the obvious projection, are closed and has the finite intersection property; thus the intersection of all of these sets is non-empty, and the claim follows.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" From the above discussion, we see that the space ")#mi("{\\{0,1\\}^{\\{0,1\\}^{{\\mathbb{Z}}}}}")#text(" is compact but not sequentially compact; thus compactness does not necessarily imply sequential compactness.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let us call a topological space ")#mi("{(X,{\\mathcal F})}")#text(" ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first-countable")]#text(" if, for every ")#mi("{x \\in X}")#text(", there exists a countable family ")#mi("{B_{x,1}, B_{x,2}, \\ldots}")#text(" of open neighbourhoods of ")#mi("{x}")#text(" such that every neighbourhood of ")#mi("{x}")#text(" contains at least one of the ")#mi("{B_{x,j}}")#text(".")

#list(
[#text("Show that every metric space is first-countable.")],
[#text("Show that every second-countable space is first-countable (see Lemma ")#link(<tao-c19588ee9c7265b5eae9>)[#text("4")]#text(").")],
[#text("Show that every separable metric space is second-countable.")],
[#text("Show that every space which is second-countable, is separable.")],
[#text("Show that any compact space which is first-countable, is also sequentially compact. (The converse is not true: Exercise 9 from ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(" provides a counterexample.)")]
)
]

#text("(Optional) There is an alternate proof of the Tychonoff theorem that uses the machinery of ")#emph[#text("universal nets")]#text(". We sketch this approach in a series of exercises.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 11")]#text(" A net ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" in a set ")#mi("{X}")#text(" is ")#emph[#text("universal")]#text(" if for every function ")#mi("{f: X \\rightarrow \\{0,1\\}}")#text(", the net ")#mi("{(f(x_\\alpha))_{\\alpha \\in A}}")#text(" converges to either ")#mi("{0}")#text(" or ")#mi("{1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that a universal net ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" in a compact topological space is necessarily convergent. (")#emph[#text("Hint")]#text(": show that the collection of closed sets which contain ")#mi("{x_\\alpha}")#text(" for sufficiently large ")#mi("{\\alpha}")#text(" enjoys the finite intersection property.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Kelley’s theorem)")]#text(" Every net ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" in a set ")#mi("{X}")#text(" has a universal subnet ")#mi("{(x_{\\phi(\\beta)})_{\\beta \\in B}}")#text(". (")#emph[#text("Hint")]#text(": First use Exercise ")#link(<tao-14f91bc93dc4f0ff486e>)[#text("5")]#text(" to find an ultrafilter ")#mi("{p}")#text(" on ")#mi("{A}")#text(" that contains the upsets ")#mi("{\\{ \\beta \\in A: \\beta \\geq \\alpha\\}}")#text(" for all ")#mi("{\\alpha \\in A}")#text(". Now let ")#mi("{B}")#text(" be the space of all pairs ")#mi("{(U,\\alpha)}")#text(", where ")#mi("{\\alpha \\in U \\in p}")#text(", ordered by requiring ")#mi("{(U,\\alpha) \\leq (U^{\\prime},\\alpha^{\\prime})}")#text(" when ")#mi("{U \\supset U^{\\prime}}")#text(" and ")#mi("{\\alpha \\leq \\alpha^{\\prime}}")#text(", and let ")#mi("{\\phi: B \\rightarrow A}")#text(" be the map ")#mi("{\\phi: (U,\\alpha) \\mapsto \\alpha}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Use the previous two exercises, together with Exercise ")#link(<tao-251fecd592e56e6c4a95>)[#text("20")]#text(", to establish an alternate proof of Tychonoff’s theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Establish yet another proof of Tychonoff’s theorem using Exercise ")#link(<tao-60b71dc726e801afaf04>)[#text("7")]#text(" directly (rather than proceeding via Exercise ")#link(<tao-4a62c90aa8e11fe50cea>)[#text("12")]#text(").")
]

#heading(level: 1)[#strong[#text(" — 4. Compactness and equicontinuity — ")]]

#text("We now pause to give an important application of the (sequential) Tychonoff theorem. We begin with some definitions. If ")#mi("{X = (X, {\\mathcal F}_X)}")#text(" is a topological space and ")#mi("{Y = (Y, d_Y)}")#text(" is a metric space, let ")#mi("{BC(X \\rightarrow Y)}")#text(" be the space of bounded continuous functions from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(". (If ")#mi("{X}")#text(" is compact, this is the same space as ")#mi("{C(X \\rightarrow Y)}")#text(", the space of continuous functions from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(".) We can give this space the uniform metric")

#align(center)[#tao-fit-display[#mitex("d(f,g) := \\sup_{x \\in X} d_Y( f(x), g(x) ).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" If ")#mi("{Y}")#text(" is complete, show that ")#mi("{BC(X \\rightarrow Y)}")#text(" is a complete metric space. (Note that this implies Exercise 2 from ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Notes 6")]#text(".)")
]

#text("Note that if ")#mi("{f: X \\rightarrow Y}")#text(" is continuous if and only if, for every ")#mi("{x \\in X}")#text(" and ")#mi("{\\epsilon > 0}")#text(", there exists a neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(" such that ")#mi("{d_Y(f(x^{\\prime}),f(x)) \\leq \\epsilon}")#text(" for all ")#mi("{x^{\\prime} \\in U}")#text(". We now generalise this concept to families.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12")]#text(" Let ")#mi("{X}")#text(" be a topological space, let ")#mi("{Y}")#text(" be a metric space, and Let ")#mi("{(f_\\alpha)_{\\alpha \\in A}}")#text(" be a family of functions ")#mi("{f_\\alpha \\in BC(X \\rightarrow Y)}")#text(".")

#list(
[#text("We say that this family ")#mi("{f_\\alpha}")#text(" is ")#emph[#text("pointwise bounded")]#text(" if for every ")#mi("{x \\in X}")#text(", the set ")#mi("{\\{ f_\\alpha(x): \\alpha \\in A \\}}")#text(" is bounded in ")#mi("{Y}")#text(".")],
[#text("We say that this family ")#mi("{f_\\alpha}")#text(" is ")#emph[#text("pointwise precompact")]#text(" if for every ")#mi("{x \\in X}")#text(", the set ")#mi("{\\{ f_\\alpha(x): \\alpha \\in A \\}}")#text(" is precompact in ")#mi("{Y}")#text(".")],
[#text("We say that this family ")#mi("{f_\\alpha}")#text(" is ")#link("http://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuous")]#text(" if for every ")#mi("{x \\in X}")#text(" and ")#mi("{\\epsilon > 0}")#text(", there exists a neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(" such that ")#mi("{d_Y(f_\\alpha(x^{\\prime}), f_\\alpha(x)) \\leq \\epsilon}")#text(" for all ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{x^{\\prime} \\in U}")#text(".")],
[#text("If ")#mi("{X = (X,d_X)}")#text(" is also a metric space, we say that the family ")#mi("{f_\\alpha}")#text(" is ")#emph[#text("uniformly equicontinuous")]#text(" if for every ")#mi("{\\epsilon > 0}")#text(" there exists a ")#mi("{\\delta > 0}")#text(" such that ")#mi("{d_Y(f_\\alpha(x^{\\prime}), f_\\alpha(x)) \\leq \\epsilon}")#text(" for all ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{x^{\\prime}, x \\in X}")#text(" with ")#mi("{d_X(x,x^{\\prime}) \\leq \\delta}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" From the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(", the pointwise boundedness and pointwise precompactness properties are equivalent if ")#mi("{Y}")#text(" is a subset of ")#mi("{{\\mathbb R}^n}")#text(" for some ")#mi("{n}")#text(". Any finite collection of continuous functions is automatically an equicontinuous family (why?), and any finite collection of uniformly continuous functions is automatically a uniformly equicontinuous family; the concept only acquires additional meaning once one considers infinite families of continuous functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" With ")#mi("{X = [0,1]}")#text(" and ")#mi("{Y = {\\mathbb R}}")#text(", the family of functions ")#mi("{f_n(x) := x^n}")#text(" for ")#mi("{n=1,2,3,\\ldots}")#text(" are pointwise bounded (and thus pointwise precompact), but not equicontinuous. The family of functions ")#mi("{g_n(x) := n}")#text(" for ")#mi("{n=1,2,3,\\ldots}")#text(", on the other hand, are equicontinuous, but not pointwise bounded or pointwise precompact. The family of functions ")#mi("{h_n(x) := \\sin nx}")#text(" for ")#mi("{n=1,2,3,\\ldots}")#text(" are pointwise bounded (even uniformly bounded), but not equicontinuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" With ")#mi("{X = {\\mathbb R} \\backslash \\{0\\}}")#text(" and ")#mi("{Y = {\\mathbb R}}")#text(", the functions ")#mi("{f_n(x) = \\arctan nx}")#text(" are pointwise bounded (even uniformly bounded), are equicontinuous, and are each ")#emph[#text("individually")]#text(" uniformly continuous, but are not uniformly equicontinuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Show that the uniform boundedness principle (Theorem 2 from ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("Notes 9")]#text(") can be restated as the assertion that any family of bounded linear operators from the unit ball of a Banach space to a normed vector space is pointwise bounded if and only if it is equicontinuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" A function ")#mi("{f: X \\rightarrow Y}")#text(" between two metric spaces is said to be ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz")]#text(" (or ")#emph[#text("Lipschitz continuous")]#text(") if there exists a constant ")#mi("{C}")#text(" such that ")#mi("{d_Y(f(x),f(x^{\\prime})) \\leq C d_X(x,x^{\\prime})}")#text(" for all ")#mi("{x,x^{\\prime} \\in X}")#text("; the smallest constant ")#mi("{C}")#text(" one can take here is known as the ")#emph[#text("Lipschitz constant")]#text(" of ")#mi("{f}")#text(". Observe that Lipschitz functions are automatically continuous, hence the name. Also observe that a family ")#mi("{(f_\\alpha)_{\\alpha \\in A}}")#text(" of Lipschitz functions with uniformly bounded Lipschitz constant is equicontinuous.")
]

#text("One nice consequence of equicontinuity is that it equates uniform convergence with pointwise convergence, or even pointwise convergence on a dense subset.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" ")#metadata(none) <tao-dc26dbda2e90fe0b8a94>#text(" Let ")#mi("{X}")#text(" be a topological space, let ")#mi("{Y}")#text(" be a complete metric space, let ")#mi("{f_1, f_2, \\ldots \\in BC(X \\rightarrow Y)}")#text(" be an equicontinuous family of functions. Show that the following are equivalent:")

#list(
[#text("The sequence ")#mi("{f_n}")#text(" is pointwise convergent.")],
[#text("The sequence ")#mi("{f_n}")#text(" is pointwise convergent on some dense subset of ")#mi("{X}")#text(".")]
)

#text("If ")#mi("{X}")#text(" is compact, show that the above two statements are also equivalent to")

#list(
[#text("The sequence ")#mi("{f_n}")#text(" is uniformly convergent.")]
)

#text("(Compare with Corollary 1 from ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("Notes 9")]#text(".) Show that no two of the three statements remain equivalent if the hypothesis of equicontinuity is dropped.")
]

#text("We can now use Proposition ")#link(<tao-4f5260d71c7e332a2c94>)[#text("9")]#text(" to give a useful characterisation of precompactness in ")#mi("{C(X \\rightarrow Y)}")#text(" when ")#mi("{X}")#text(" is compact, known as the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Arzelá-Ascoli theorem)")]#text(" Let ")#mi("{Y}")#text(" be a metric space, ")#mi("{X}")#text(" be a compact metric space, and let ")#mi("{(f_\\alpha)_{\\alpha \\in A}}")#text(" be a family of functions ")#mi("{f_\\alpha \\in BC(X \\rightarrow Y)}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\{ f_\\alpha: \\alpha \\in A \\}}")#text(" is a precompact subset of ")#mi("{BC(X \\rightarrow Y)}")#text(".")],
[#text("(ii) ")#mi("{(f_\\alpha)_{\\alpha \\in A}}")#text(" is pointwise precompact and equicontinuous.")],
[#text("(iii) ")#mi("{(f_\\alpha)_{\\alpha \\in A}}")#text(" is pointwise precompact and uniformly equicontinuous.")]
)
]

#emph[#text("Proof:")]#text(" We first show that (i) implies (ii). For any ")#mi("{x \\in X}")#text(", the evaluation map ")#mi("{f \\mapsto f(x)}")#text(" is a continuous map from ")#mi("{C(X \\rightarrow Y)}")#text(" to ")#mi("{Y}")#text(", and thus maps precompact sets to precompact sets. As a consequence, any precompact family in ")#mi("{C(X \\rightarrow Y)}")#text(" is pointwise precompact. To show equicontinuity, suppose for contradiction that equicontinuity failed at some point ")#mi("{x}")#text(", thus there exists ")#mi("{\\epsilon > 0}")#text(", a sequence ")#mi("{\\alpha_n \\in A}")#text(", and points ")#mi("{x_n \\rightarrow x}")#text(" such that ")#mi("{d_Y( f_{\\alpha_n}(x_n), f_{\\alpha_n}(x) ) > \\epsilon}")#text(" for every ")#mi("{n}")#text(". One then verifies that no subsequence of ")#mi("{f_{\\alpha_n}}")#text(" can converge uniformly to a continuous limit, contradicting precompactness. (Note that in the metric space ")#mi("{C(X \\rightarrow Y)}")#text(", precompactness is equivalent to sequential precompactness.)")

#text("Now we show that (ii) implies (iii). It suffices to show that equicontinuity implies uniform equicontinuity. This is a straightforward generalisation of the more familiar argument that continuity implies uniform continuity on a compact domain, and we repeat it here. Namely, fix ")#mi("{\\epsilon > 0}")#text(". For every ")#mi("{x \\in X}")#text(", equicontinuity provides a ")#mi("{\\delta_x > 0}")#text(" such that ")#mi("{d_Y(f_\\alpha(x), f_\\alpha(x^{\\prime})) \\leq \\epsilon}")#text(" whenever ")#mi("{x^{\\prime} \\in B(x, \\delta_x)}")#text(" and ")#mi("{\\alpha \\in A}")#text(". The balls ")#mi("{B(x,\\delta_x/2)}")#text(" cover ")#mi("{X}")#text(", thus by compactness some finite subcollection ")#mi("{B(x_i,\\delta_{x_i}/2)}")#text(", ")#mi("{i=1,\\ldots,n}")#text(" of these balls cover ")#mi("{X}")#text(". One then easily verifies that ")#mi("{d_Y(f_\\alpha(x), f_\\alpha(x^{\\prime})) \\leq \\epsilon}")#text(" whenever ")#mi("{x, x^{\\prime} \\in X}")#text(" with ")#mi("{d_X(x,x^{\\prime}) \\leq \\min_{1 \\leq i \\leq n} \\delta_{x_i}/2}")#text(".")

#text("Finally, we show that (iii) implies (i). It suffices to show that any sequence ")#mi("{f_n \\in BC(X \\rightarrow Y)}")#text(", ")#mi("{n=1,2,\\ldots}")#text(", which is pointwise precompact and uniformly equicontinuous, has a convergent subsequence. By embedding ")#mi("{Y}")#text(" in its metric completion ")#mi("{\\overline{Y}}")#text(", we may assume without loss of generality that ")#mi("{Y}")#text(" is complete. (Note that for every ")#mi("{x \\in X}")#text(", the set ")#mi("{\\{ f_n(x): n=1,2,\\ldots\\}}")#text(" is precompact in ")#mi("{Y}")#text(", hence the closure in ")#mi("{Y}")#text(" is complete and thus closed in ")#mi("{\\overline{Y}}")#text(" also. Thus any pointwise limit of the ")#mi("{f_n}")#text(" in ")#mi("{\\overline{Y}}")#text(" will take values in ")#mi("{Y}")#text(".) By Lemma ")#link(<tao-c19588ee9c7265b5eae9>)[#text("4")]#text(", we can find a countable dense subset ")#mi("{x_1, x_2, \\ldots}")#text(" of ")#mi("{X}")#text(". For each ")#mi("{x_m}")#text(", we can use pointwise precompactness to find a compact set ")#mi("{K_m \\subset Y}")#text(" such that the ")#mi("{f_n(x_m)}")#text(" take values in ")#mi("{K_m}")#text(". For each ")#mi("{n}")#text(", the tuple ")#mi("{F_n := (f_n(x_m))_{m=1}^\\infty}")#text(" can then be viewed as a point in the product space ")#mi("{\\prod_{n=1}^\\infty K_n}")#text(". By Proposition ")#link(<tao-4f5260d71c7e332a2c94>)[#text("9")]#text(", this product space is sequentially compact, hence we may find a subsequence ")#mi("{n_j \\rightarrow \\infty}")#text(" such that ")#mi("{F_{n_j}}")#text(" is convergent in the product topology, or equivalently that ")#mi("{f_{n_j}}")#text(" pointwise converges on the countable dense set ")#mi("{\\{ x_1, x_2, \\ldots\\}}")#text(". The claim now follows from Exercise ")#link(<tao-dc26dbda2e90fe0b8a94>)[#text("28")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" The above theorem characterises precompact subsets of ")#mi("{BC(X \\rightarrow Y)}")#text(" when ")#mi("{X}")#text(" is a compact metric space. One can also characterise compact subsets by observing that a subset of a metric space is compact if and only if it is both precompact and closed.")
]

#text("There are many variants of the Arzelá-Ascoli theorem with stronger or weaker hypotheses or conclusions; for instance, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14 (Arzelá-Ascoli theorem, special case)")]#text(" ")#metadata(none) <tao-8760d12e729567e54d6e>#text(" Let ")#mi("{f_n: X \\rightarrow {\\mathbb R}^m}")#text(" be a sequence of functions from a compact metric space ")#mi("{X}")#text(" to a finite-dimensional vector space ")#mi("{{\\mathbb R}^m}")#text(" which are equicontinuous and pointwise bounded. Then there is a subsequence ")#mi("{f_{n_j}}")#text(" of ")#mi("{f_n}")#text(" which converges uniformly to a limit (which is necessarily bounded and continuous).")
]

#text("Thus, for instance, any sequence of uniformly bounded and uniformly Lipschitz functions ")#mi("{f_n: [0,1] \\rightarrow {\\mathbb R}}")#text(" will have a uniformly convergent subsequence. This claim fails without the uniform Lipschitz assumption (consider, for instance, the functions ")#mi("{f_n(x) := \\sin(nx)}")#text("). Thus one needs a “little bit extra” uniform regularity in addition to uniform boundedness in order to force the existence of uniformly convergent subsequences. This is a general phenomenon in infinite-dimensional function spaces: compactness in a strong topology tends to require some sort of uniform control on regularity or decay in addition to uniform bounds on the norm.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" ")#metadata(none) <tao-ecf7ab29965ca1da891c>#text(" Show that the equivalence of (i) and (ii) continues to hold if ")#mi("{X}")#text(" is assumed to be just a compact Hausdorff space rather than a compact metric space (the statement (iii) no longer makes sense in this setting). ")#emph[#text("Hint:")]#text(" ")#mi("{X}")#text(" need not be separable any more, however one can still adapt the diagonalisation argument used to prove Proposition ")#link(<tao-4f5260d71c7e332a2c94>)[#text("9")]#text(". The starting point is the observation that for every ")#mi("{\\epsilon > 0}")#text(" and every ")#mi("{x \\in X}")#text(", one can find a neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(" and some subsequence ")#mi("{f_{n_j}}")#text(" which only oscillates by at most ")#mi("{\\epsilon}")#text(" (or maybe ")#mi("{2\\epsilon}")#text(") on ")#mi("{U}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Locally compact Hausdorff version of Arzelá-Ascoli)")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is also ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{f_n \\in C(X \\rightarrow {\\mathbb R})}")#text(" be an equicontinuous, pointwise bounded sequence of functions. Then there exists a subsequence ")#mi("{f_{n_j} \\in C(X \\rightarrow {\\mathbb R})}")#text(" which converges uniformly on compact subsets of ")#mi("{X}")#text(" to a limit ")#mi("{f \\in C(X \\rightarrow {\\mathbb R})}")#text(". (")#emph[#text("Hint:")]#text(" Express ")#mi("{X}")#text(" as a countable union of compact sets ")#mi("{K_n}")#text(", each one contained in the interior of the next. Apply the compact Hausdorff Arzelá-Ascoli theorem on each compact set (Exercise ")#link(<tao-ecf7ab29965ca1da891c>)[#text("29")]#text("). Then apply the Arzelá-Ascoli argument one last time.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The Arzelá-Ascoli theorem (and other compactness theorems of this type) are often used in partial differential equations, to demonstrate existence of solutions to various equations or variational problems. For instance, one may wish to solve some equation ")#mi("{F(u) = f}")#text(", for some function ")#mi("{u: X \\rightarrow {\\mathbb R}^m}")#text(". One way to do this is to first construct a sequence ")#mi("{u_n}")#text(" of approximate solutions, so that ")#mi("{F(u_n) \\rightarrow f}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" in some suitable sense. If one can also arrange these ")#mi("{u_n}")#text(" to be equicontinuous and pointwise bounded, then the Arzelá-Ascoli theorem allows one to pass to a subsequence that converges to a limit ")#mi("{u}")#text(". Given enough continuity (or ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("semi-continuity")]#text(") properties on ")#mi("{F}")#text(", one can then show that ")#mi("{F(u)=f}")#text(" as required.")

#text("More generally, the use of compactness theorems to demonstrate existence of solutions in PDE is known as the ")#emph[#text("compactness method")]#text(". It is applicable in a remarkably broad range of PDE problems, but often has the drawback that it is difficult to establish uniqueness of the solutions created by this method (compactness guarantees existence of a limit point, but not uniqueness). Also, in many cases one can only hope for compactness in rather weak topologies, and as a consequence it is often difficult to establish regularity of the solutions obtained via compactness methods.")
]

#text("[")#emph[#text("Update")]#text(", Feb 20: some corrections, new exercise added (note renumbering).]")

#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("Below Remark 3:")

#text("we can find ")#mi("{x = (x_m)_{m=1}^\\infty \\in \\{0,1\\}^\\infty}")

#text("–>")

#text("we can find ")#mi("{x = (x_m)_{m=1}^\\infty \\in \\{0,1\\}^{\\mathbb N}}")

#text("At the end of Definition 12:")

#text("and ")#mi("{x^{\\prime}, x \\in x}")#text(" with ")#mi("{d_X(x,x^{\\prime}) \\leq \\delta}")#text(".")

#text("–>")

#text("and ")#mi("{x^{\\prime}, x \\in X}")#text(" with ")#mi("{d_X(x,x^{\\prime}) \\leq \\delta}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("Regarding Definition 12, can one still define the notion of “uniform equicontinuity” when ")#mi("X")#text(" is merely a topological space?")

#text("Does the following definition make sense?")

#text("We say that this family ")#mi("{f_\\alpha}")#text(" is “uniformly equicontinuous” (or “equi-uniformly-continuous”) if for every ")#mi("{\\epsilon > 0}")#text(", there exists an open set ")#mi("{U}")#text(" such that ")#mi("{d_Y(f_\\alpha(x^{\\prime}), f_\\alpha(x)) \\leq \\epsilon}")#text(" for all ")#mi("{\\alpha \\in A}")#text(" and ")#mi("{x, x^{\\prime} \\in U}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("This is not an interesting notion (one could take ")#mi("U")#text(" to be the empty set, for instance). In order to have a good notion of uniform continuity (or equicontinuity), one needs the structure of a ")#link("https://en.wikipedia.org/wiki/Uniform_space")[#text("uniform space")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("Some pedantic comments:")

#text("1. In the proof of “(iii) implies (i)” in Theorem 13,")

#mi("n")#text(" is used both as a fixed variable and the dummy variable:")

#emph[#linebreak()#text(" For each ")#mi("{n}")#text(", the tuple ")#mi("{F_n := (f_n(x_m))_{m=1}^\\infty}")#text(" can then be viewed as a point in the product space ")#mi("{\\prod_{n=1}^\\infty K_n}")#text(".")#linebreak()#text(" ")]

#text("… ")#mi("{\\prod_{m=1}^\\infty K_m}")#text(" is clearer")

#text("2. Possible typos in")

#emph[#linebreak()#text(" hence we may find a subsequence ")#mi("{n_j \\rightarrow \\infty}")#text(" such that ")#mi("{F_n}")#text(" is convergent in the product topology, or equivalently that ")#mi("{f_n}")#text(" pointwise")#linebreak()#text(" ")]

#text("which seems to be:")

#text("hence we may find a subsequence ")#mi("{n_j \\rightarrow \\infty}")#text(" such that ")#mi("{F_{n_j}}")#text(" is convergent in the product topology, or equivalently that ")#mi("{f_{n_j}}")#text(" pointwise")

#text("3.")

#text("The subscripts ")#mi("n(=1,2,\\ldots)")#text(" and ")#mi("\\alpha(\\in A)")#text(" are used in the proof. While it is clear that a sequence “")#mi("f_n")#text("” can be clearly understood as ")#mi("f_{\\alpha_n}")#text(", the following in the proof:")

#emph[#linebreak()#text(" … such that ")#mi("{f_\\alpha(x_m)}")#text(" takes values in ")#mi("{K_m}")#text(".")#linebreak()#text(" ")]

#text("means")

#text("… such that ")#mi("{f_\\alpha(x_m)}")#text(", ")#mi("\\alpha\\in A")#text(" take values in ")#mi("{K_m}")#text(".")

#text("not")

#text("… such that ")#mi("{f_n(x_m)}")#text(", ")#mi("n=1,2,\\ldots")#text(" take values in ")#mi("{K_m}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2023")])]

#text("In the proof of “(iii) implies (i)” in Theorem 13:")

#emph[#linebreak()#text(" Note that for every ")#mi("{x \\in X}")#text(", the set ")#mi("{\\{ f_n(x): n=1,2,\\ldots\\}}")#text(" is precompact in ")#mi("{Y}")#text(", hence the closure in ")#mi("{Y}")#text(" is complete and thus closed in ")#mi("{\\overline{Y}}")#text(" also. Thus any pointwise limit of the ")#mi("{f_n}")#text(" in ")#mi("{\\overline{Y}}")#text(" will take values in ")#mi("{Y}")#text(".")#linebreak()#text(" ")]

#text("1. I may miss something obvious. Why “any pointwise limit of the ")#mi("{f_n}")#text(" in ")#mi("{\\overline{Y}}")#text(" will take values in ")#mi("{Y}")#text("“? One only knows from the quoted argument that the closure in ")#mi("{Y}")#text(" is closed in ")#mi("{\\overline{Y}}")#text(", which means the limit should take values in ")#mi("{\\overline{Y}}")#text("?")

#text("2. “hence the closure in ")#mi("{Y}")#text(" is complete and thus closed in ")#mi("{\\overline{Y}}")#text(" also” What is the use of completeness here? Is the closure in ")#mi("{Y}")#text(" not automatically closed in ")#mi("{\\overline{Y}}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-672691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("1. Yes. If ")#mi("z")#text(" is a limit of the ")#mi("f_n(x)")#text(" in ")#mi("\\overline{Y}")#text(", then it will lie in the Y-closure of the ")#mi("f_n(x)")#text(" since this is already closed in ")#mi("\\overline{Y}")#text(".")

#text("2. No. For instance, ")#mi("{\\bf Q}")#text(" is closed in ")#mi("{\\bf Q}")#text(", but is not closed in ")#mi("\\overline{{\\bf Q}} = {\\bf R}")#text(". However, any complete subset of ")#mi("Y")#text(" will be closed in ")#mi("\\overline{Y}")#text("; this is a good exercise for you to prove.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-693441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("Dear Prof. Tao:")

#text("It seems that advanced concepts like filters and ultrafilters rarely appear in point-set topology textbooks. What are the unique advantages of using the mechanism of filters and ultrafilters to characterize results in point-set topology, such as compactness?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-693450")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("I am ")#link("https://claude.ai/share/89e5a807-bb04-4421-8d57-0b02c64b8d06")[#text("outsourcing this question to an AI")]#text(". I will also note that Lean’s implementation of point-set topology is based on filters, and in fact heavily encourages the use of filter notation when working with these concepts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-693462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("Thank you for your reply. I’d like to make my question more specific, as it has really been bothering me: in the proof of Tychonoff’s theorem, when treated as a corollary of Alexander’s subbase theorem, I find it quite mysterious. If one turn to universal nets and ultrafilters instead, besides brevity, what are the reasons for using this machinery?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-2/#comment-693463")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("I am ")#link("https://claude.ai/share/89e5a807-bb04-4421-8d57-0b02c64b8d06")[#text("outsourcing this question to an AI")]#text(".")

#text("I will also note that some of the perceived difficulty here is an artefact of the convention to express the foundations of topology in terms of open sets rather than nets, ultrafilters, C^*-algebras, topoi, or whatever. See ")#link("https://mathoverflow.net/questions/19152/why-is-a-topology-made-up-of-open-sets")[#text("https://mathoverflow.net/questions/19152/why-is-a-topology-made-up-of-open-sets")]#text(" for more discussion.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35642")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("In the proof of Remark 4, you write “The axiom of choice was used in the proof (via the Alexander sub-base theorem).” Wasn’t it also used directly, to select the element ")#mi("x_{\\alpha}")#text(" in ")#mi("X_{\\alpha}")#text("? (Note that this selection takes place infinitely many times, once for each ")#mi("\\alpha \\in A")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("True enough… though I find this invocation of the axiom of choice to be “shallower” than that in the sub-base theorem (because I consider Zorn’s lemma to be “deeper” somehow than the axiom of choice, despite being logically equivalent); it doesn’t seem to lead as easily to such “unconstructible” objects as non-principal ultrafilters, etc., as the Zorn lemma applications do. I don’t know how to make this distinction rigorous, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c6547c98ff2a1c021e41f067b4863ea434c119a41e18c5af2ebd459c8121c27-1ee9894230e785e0398c1103dd321df8d107a69c98cf6336c5d7293bbaa65a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35644")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Example 2: the functions fn are not pointwise bounded; did you mean xn?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Oops, thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c46a5974f4920e26d395f9675ae1accd8ea3842f266a56d83e481e680bafd70-85798c7c555990ae78c52148b3310ad8a363d528489a12b86a9e85bd493772c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of whuh")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35649")[#strong[#text("whuh")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Dear Prof. Tao (and Prof. Trevisan),")

#text("An aesthetic comment – congratulations, this looks fantastic! The serif fonts in the boxes are far superior and sharper to the standard fare outside. Would it be possible to use serif everywhere? Presumably this is now far easier to change with your script.")

#text("Does the script support equation numbering? And would it be possible to slightly increase the contrast or the weight of the mathematics font?")

#text("There are consistency issues with the italics in the boxes – it sometimes seems to stop for no reason – e.g. in Example 4 and Remark 8. By the way there is a unclosed end{proof} tag after Theorem 10.")

#text("It is also a little disconcerting to have clearer structural elements for theorems, remarks and examples than for sections. Presumably this, too can be incorporated?")

#text("But these are all nitpicks, it looks amazing. Will it be possible for other WordPress bloggers to use it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Thanks for the feedback (and for the corrections)! Luca can of course say more, but I believe he plans to release his code to the public once some of the kinks (such as those you pointed out) are worked out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73196101058b01a7b5178a5c0b1eb30a5a176e3bc57a7a26d1c49d8e30671304-bab8ee688d0d5fd8fe52d477c3e3eff98ad07799efeccc22e05aee131831a8eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nate Chandler")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35654")[#strong[#text("Nate Chandler")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("In the introduction, you wrote “In these notes, we explore how compactness interacts with other key topological concepts: the Hausdorff property, bases and sub-bases, product spaces, and equicontinuity, in particular establishing the useful and the Arzelá-Ascoli theorem that give criteria for compactness (or precompactness).” I think that you left out the noun which “useful” is modifying and that it should read like “the useful [theorem X] and the Arzelá-Ascoli theorem”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35656")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("I think you used \\label{bascov} twice, once in")#linebreak()#text(" Exercise 9 and once in Theorem 6.")

#text("(The effect is that \\ref{bascov} points into Exercise 9, but it")#linebreak()#text(" reads as a reference to Exercise 6)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35661")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("Re the first two comments: The use of AC that David points out, while seemingly less deep, is in fact stronger than the other uses of AC. Indeed, by Exercise 11, the sub-base lemma, which is the only other place AC is used in an essential way, requires only the ultrafilter lemma, while Tychonoff’s theorem is equivalent to the full power of AC. To get a more precise statement, consider the ultrafilter proof of Tychonoff’s theorem: given an ultrafilter on a product ")#mi("X=\\prod X_\\alpha")#text(" of compact spaces, it has a limit ")#mi("x_\\alpha")#text(" on each coordinate, and these give the coordinates of a limit ")#mi("x=(x_\\alpha)\\in X")#text(". Here again, AC is used at two points: the ultrafilter lemma is used to be able to prove compactness using only ultrafilters, and AC is used to choose each ")#mi("x_\\alpha")#text(". However, with this proof, we can say more: if each ")#mi("X_\\alpha")#text(" is Hausdorff, then the ")#mi("x_\\alpha")#text(" are all unique, so the second use of AC is unnecessary. Thus Tychonoff’s theorem for Hausdorff spaces requires only the ultrafilter lemma (and is in fact equivalent to it), whereas the full Tychonoff’s theorem is strictly stronger. This shows that the use of the strange non-Hausdorff spaces in Remark 4 was unavoidable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71a070a90c8ccee50e6862bd2f68119aa90aa1f6cf64277b7b92e07ad9936934-bd2e8318be8d02adfe8a4d934fa16e6253bf8db8227e25781129485df0e96c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RR")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35663")[#strong[#text("RR")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("Professor Tao:")

#text("I enjoy a lot your postings. They keep my love for mathematics alive. Anyway, my browser (Mozilla Firefox) has problems with the following two lines of code:")

#text("my box (running scientific linux) only shows: “Formula does not parse”")

#text("Thanks ,")

#text("RR")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2ae9087f9c962c3fa76ab6ff188f30213bb8ff2ea23ef20118881a7c61627c5-5e22559ce7e3ec1ebb8e580ab6e6e7ce7ce55a7a1c4afba6bfb8ae97eee8c3a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35665")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("I also get a few ‘formula does not parse’ errors in:")

#text("1. Exercise 18 after between “Let” and “be a sequence”")#linebreak()#text(" 2. Paragraph before Remark 3 after “diagonal sequence.”")#linebreak()#text(" 3. Example 3 after “the functions”")#linebreak()#text(" 4. Two paragraphs before Remark 7, after “finite subcollection B(x_i,\\delta_i /2),”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35670")[#strong[#text("Wikipedia-like blog entries? « Shell Beach")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")]

#text("[…] of academic bloggers posting their lecture notes on specific topics online (some even making the lecture notes themselves posts rather than linking to PDFs), so parts of me feel like we’re already seeing this kind of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("I’ve recompiled the HTML. Let me know if there are still display problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2ae9087f9c962c3fa76ab6ff188f30213bb8ff2ea23ef20118881a7c61627c5-5e22559ce7e3ec1ebb8e580ab6e6e7ce7ce55a7a1c4afba6bfb8ae97eee8c3a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35701")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("Looks like the FDNP persists in Exercise 18 between “Let” and “be a sequence.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35797")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("There is something funny with the RSS feed for this post: most, albeit not all, of the formulae in this post look broken (“formula does not parse” yellow boxes all over) when looked in an RSS feed reader (e.g. reader.google.com).")#linebreak()#text(" Needless to say, the formulae are fine on the blog page.")

#text("This probably means that the converter does not work well with the RSS feed machinery. (I see no problem with other maths posts from this blog from within the RSS feed reader)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35805")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("There is a standard terminological warning about compactness for readers who also read (or will read) French literature: the French tradition is that “compact” means “compact and Hausdorff”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35822")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Thanks for the warning, Emmanuel!")

#text("Dima: I see the RSS quirk too, but am hoping that it will sort itself out with time. (The LaTeX code was recently changed, thanks to another post here on this blog; that may have something to do with it.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35903")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第十节是关于拓扑空间中的紧致性质的探讨，无疑是非常重要的。分成了三个部分，而三个部分中常常会出现的关于ultrafilter的证明，我是最喜欢的。第一个部分是紧致性和Hausdorff性的关系，显然，以前我是没有注意到的。在某种意义上，他们有着对立的关系。最后的Alexander子基定理十分有用。第二部分讲述了乘积空间的紧致性的定理，即Tychonoff定理。不可避免的，选择公理由出现了。最后还在习题中介绍了另外一种证明方法，用到ultrafilter的方法。另外，box拓扑的概念是这么自然，怎么以前没自己研究研究呢。第三个部分是关于Arzelá-Ascoli定理，这定理重要的无以复加了。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-35995")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("Dear Professor:")#linebreak()#text(" In Exercise 27, is the space X asked to be compact or not?")

#text("In the first two of Definition 12, the set seems to be ")#mi("\\{f_\\alpha(x):\\alpha \\in A\\}")#text(", instead of ")#mi("\\{f_\\alpha(x): x \\in X\\}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("In exercise 5, you say “A collection of subsets of {X} has the finite intersection property if every finite intersection of sets in the collection.”")

#text("Do you mean “A collection of subsets of {X} has the finite intersection property if every finite intersection of sets in the collection is nonempty.”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36073")[#strong[#text("Converting LaTeX to WordPress « in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")]

#text("[…] Tao has tested it on a couple of posts. Thanks to his feedback, the current version, while surely bug-filled and very limited, is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 11: The strong and weak topologies « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36086")[#strong[#text("245B, Notes 11: The strong and weak topologies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("[…] has a subsequence which converges pointwise on , and thus converges pointwise on by Exercise 27 of Notes 10, and thus converges in the weak* topology. But as is closed in this topology, we conclude that is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/410b9c9ca6499cc5209036257f3918ac4258d3c6701d9f991efa9e24528b2df8-432d3897d03068d8e0e31ec014f2ec7c73c14643504a78c2eabf86dfc22ae74b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ke")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36147")[#strong[#text("Ke")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("Exercise 28 (about equicontinuity equating uniform convergence and pointwise convergence on a dense subset) requires completeness of Y. Example : X = [-1,1], Y = (-1,1), ")#mi("f_n(x) = (1-\\frac1n)x")#text(". The sequence ")#mi("f_n")#text(" is equicontinuous and pointwise convergent for ")#mi("-1 < x < 1")#text(" but not convergent for ")#mi("x = \\pm 1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("Hmm, you’re right, thanks. Fortunately, for the purposes of Arzela-Ascoli I can pass from Y to its metric completion (using the pointwise precompactness to ensure the limit ends up back in Y rather than the completion).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("Sorry if this is trivial but I don’t understand exercise 11, part 3. The claim to be shown to fail is, as I understand it, “a point {x \\in X} is in the interior of a set {U} if {U} contains a sub-basic open neighbourhood of {x}.”")

#text("A sub-basic open neighbourhood of x contained in U is an open set containing x and contained in U, so x is in the interior of U.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36193")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("Oops; the “if” there should be “if and only if” (and similarly for part 2). I’ve amended the post accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36196")[#strong[#text("LaTeX to WordPress « Tranvinhduc’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")]

#text("[…] far LaTeX2WP has been used at what’s new and here, at in theory. You’ll notice that the typesetting styles for theorems and section names […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 12: Continuous functions on locally compact Hausdorff spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36258")[#strong[#text("245B, Notes 12: Continuous functions on locally compact Hausdorff spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("[…] a countable union of closed sets. But as is a compact metric space, it is separable (Lemma 4 from Notes 10), and so has a countable dense subset . One then easily verifies that every point in the open set […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36573")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("Hi Professor Tao,")

#text("I think there may be a little typo in Exercise 19 above. In the sum on the right, it appears that the metrics should have subscripts and be written ")#mi("d_n")#text(". If I’m correct, thanks for the correction! ")#emph[#text("[Corrected, thanks – T.]")]

#text("Samir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 13: Compactification and metrisation (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-36958")[#strong[#text("245B, Notes 13: Compactification and metrisation (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("[…] that compact metric spaces are second countable (Lemma 4 of Notes 10), thus we have Corollary 4 A compact Hausdorff space is metrisable if and only if it is second […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-38165")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2009")])]

#text("Dear Prof. Tao,")

#text("There seems some typo in the third paragraph in the proof of Theorem 6. I guess ‘For’ there should be ‘For contradiction’.")

#text("I can understand the proof of Theorem 6, but can’t understand the following problem: In the usual topology of ")#mi("{\\bf R}")#text(", every sub-basic set cover for ")#mi("\\bf R")#text(" has finite sub-cover (our sub-base is ")#mi("\\{(a,+\\infty), (-\\infty,a) \\}_{a \\in \\bf R}")#text("), but there exist some basic set cover for ")#mi("\\bf R")#text(" does not has finite sub-cover.")

#text("I began to seriously learn topology from this blog, so my question is most probably trivial. Thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-38170")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2009")])]

#text("Dear PDEbeginner,")

#text("Thanks for the correction!")

#text("The collection ")#mi("\\{ (n,+\\infty): n \\in {\\Bbb Z} \\}")#text(" of sub-basic sets covers ")#mi("{\\Bbb R}")#text(", but has no finite subcover.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-39463")[#strong[#text("Sequential compactness theorem @ unwanted capture")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")]

#text("[…] compact because it is a countable product of the sequentially compact . (See Proposition 9 here for instance.) So the sequence of theories in has a subsequence converging to some theory . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-39636")[#strong[#text("Alan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2009")])]

#text("Dear Prof Tao,")

#text("is the space of continuous functions from ")#mi("[0,1]")#text(" to ")#mi("\\mathbb{R}")

#text("under uniform convergence topology Haussdorf?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-562160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("that topology comes from a norm $||f||=\\sup\\{|f(x)|\\,:\\,x\\in[0,1]\\}.$")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-42364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Yes.")#linebreak()#text(" f(x) = a")#linebreak()#text(" g(x) = b")#linebreak()#text(" a ≠ b")

#text("r = |a-b|/2")

#text("|a-b| ≤ d(f,g)")

#text("The open balls of radius r centered on f and g are disjoint.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-43426")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] So we see that compactness methods and ultrafilter methods are closely intertwined. (See also my earlier class notes for a related connection between ultrafilters and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-46947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2010")])]

#text("hint about exercise 14")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25049c603e128c0322d9cb67b24a31b2565e0dc6232dfd53e4fd278fb8b474a5-0951952127ef30e5873fa9eab3ff59b9307eb1edf23b5601bb74b56253843cd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Faten")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-47221")[#strong[#text("Faten")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("Dear Prof Tao,")

#text("Do not you have some papers or theorems about compactness in bi_topological spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-47927")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] holds in this more general setting, but requires Tychonoff’s theorem, which we will cover in 245B Notes 10. However, some minimal regularity hypotheses of a topological nature are needed to make the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-48231")[#strong[#text("Boolean rings, ultrafilters, and Stone’s representation theorem « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")]

#text("[…] on is stronger than or the same as the topology on . But since they are both compact Hausdorff, by Lemma 1 in the link the topologies must […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-125948")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("For Example 3: I think that the family f_n(x) = arctan(nx) is not equicontinuous at the origin. The slope of the graph there keeps getting steeper and steeper.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac427c5ea88e44040dd829cb8b053e609c044709c14bad4f877c32db0c570436-ddf6f23825051abceb23096c6526f087711dcd9ff177b9e408f5772b0e9a2296.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikita")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-465588")[#strong[#text("nikita")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2016")])]

#text("Please tell me the proof of following axiom that")#linebreak()#text(" every sequentially compact topological space is countably compact")#linebreak()#text(" as soon as possible i need the proof. Please send it to my email id")#linebreak()#text(" thanku")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-466457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2016")])]

#text("Dear Prof. Tao")

#text("In Exercise 29, do we need Hausdorff condition? I think that the both implications do not use any separation axiom. Or is it for convenience( in the next exercise)?")

#text("Best")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-466470")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2016")])]

#text("It does indeed appear that the Hausdorff axiom is unnecessary here, though I don’t know of any application where one would wish to apply the Arzela-Ascoli theorem on a non-Hausdorff domain. (Generally, enough other things go wrong on non-Hausdorff spaces that it is a bit risky to invoke standard theorems in analysis on such spaces without carefully checking the hypotheses.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00c914a50ad49c967b5c06fef6fe30d096adb2f3dfa3e7116a12b12268e0c6e4-2d1aee3db6bbc4ecb3bbffb3bc14d57bbdd06ec2c8bc7cca9ddf95b9311e9136.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ianmarqz")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-474494")[#strong[#text("ianmarqz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("Reblogged this on ")#link("https://ianmarqz.wordpress.com/2016/11/20/245b-notes-10-compactness-in-topological-spaces/")[#text("ianmarqz")]#text(" and commented:")#linebreak()#text(" compact topology a la Terrence Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-485823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2017")])]

#text("A little bit of categorical language can shorten the exposition")#linebreak()#text(" in a couple of places. This is based on the ")#link("https://ncatlab.org/nlab/show/Tychonoff+theorem#ProofViaTaimanovTheoremAndLiftingProperties")[#text("observation")]#text(" that")#linebreak()#text(" the definition of compactness via ultrafilters can be expressed")#linebreak()#text(" using the notion of Quillen lifting property (orthogonality of morphisms):")

#text("a map is proper iff it is left-orthogonal (has right lifting property)")#linebreak()#text(" in the category of topological spaces to each map associated")#linebreak()#text(" with an ultrafilter in a certain natural way.")

#text("This gives a very short diagram chasing proof of Tychonoff theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e3e10bf471189e7b9dad6311a00d8fee59d8448088d8a3657a7f76c94b1a631-27f7cd9fcb250764352c0d8d528545e2842fac20761c2b83ede82b451d866cb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernhard")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-508722")[#strong[#text("Bernhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2018")])]

#text("I have a funny question. Do you know any exercise where the equivalence of compactness and sequential compactness in metric spaces is needed? (It would be weird to consider this equivalence an important result (I do), when you could not point a single example where the equivalence is really needed)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e3e10bf471189e7b9dad6311a00d8fee59d8448088d8a3657a7f76c94b1a631-27f7cd9fcb250764352c0d8d528545e2842fac20761c2b83ede82b451d866cb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernhard")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-508723")[#strong[#text("Bernhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2018")])]

#text("Ok, Alaoglu’s theorem in the non-separable case is one example. But are there ‘easy ones’ ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-508794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("Well, very few results in mathematics are truly “needed”, since one can usually always rearrange a proof to avoid invoking any specific result. But having several equivalent definitions of a basic concept such as compactness gives one a lot of flexibility when trying to prove facts about that concept. For instance, if one wants to prove that the product of compact sets is compact, or the continuous image of a compact set is compact, etc., one can choose (at least in the setting of metric spaces) to use either the topological definition or the sequential definition of compactness. In some cases one may be conceptually easier to use one notion, and in other cases it is easier to use the other, so it helps to have both available.")

#text("There are also variants of the compactness concept in which one formulation is easier to work with than the other; for instance, the theory of concentration compactness is generally described using the sequential formalism, whereas compactness theorems in logic typically use a formalism closer to the topological formalism, particularly the version involving the finite intersection property.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72789d03a67fbeab81ef3d17c0c0745c84a6e801efb0957f79431ed2aad8ce39-a74f271550fdfa5bed81dd507db77663cbf69c670e907b5517af6ae425b0fafd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anil Pedgaonkar")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-636722")[#strong[#text("Anil Pedgaonkar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2021")])]

#text("beautiful exposition")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60c8e67ac51af50861614918e32824130e76d45c39e1ee9a8e2781ee10c68307-cc0300b48666e89def14b64ad6d9f0c6171f490bf96fec419b660ccc5d343a8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ho boon suan")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-641645")[#strong[#text("ho boon suan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("exercise 21(v) doesn’t seem right; i learned from Eric Wofsey (")#link("https://math.stackexchange.com/a/4407568/")[#text("https://math.stackexchange.com/a/4407568/")]#text(") that a constant net ")#mi("(x)_{\\alpha\\in\\omega_1}")#text(", where ")#mi("\\omega_1")#text(" is the first uncountable ordinal, has no subsequences, since every function ")#mi("\\phi\\colon\\mathbf N\\to\\omega_1")#text(" has a strict upper bound ")#mi("\\bigcup_{n=1}^\\infty\\phi(n)+1")#text(".")

#emph[#text("[You are right, this part is in error and is now deleted -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-672136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2023")])]

#text("In Exercise 8, in the “only if” implication where one concludes that the collection ")#mi("\\mathcal{B}")#text(" with the “additional properties” (together with covering ")#mi("X")#text(") is a basis for “some” topology ")#mi("{\\mathcal F}")#text(",")#linebreak()#text(" should “basic open neighbourhoods” in the statement be just members of ")#mi("{\\mathcal B}")#text(" since there is no topology yet for ")#mi("X")#text("?")

#emph[#text("[The notion of a basic open neighbourhood is defined just before Exercise 8. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/comment-page-1/#comment-672397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("Regarding Remark 5, does sequential compactness imply compactness in general topological spaces?")

#emph[#text("[No; see ")#link("https://en.wikipedia.org/wiki/Sequentially_compact_space")[#text("https://en.wikipedia.org/wiki/Sequentially_compact_space")]#text(" -T.]")]
]
