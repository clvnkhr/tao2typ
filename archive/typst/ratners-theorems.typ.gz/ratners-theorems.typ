// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/29/ratners-theorems/
// Converted to Typst by tao2typ: "2026-10-14T15:16:30.054419+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ratner’s theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ratner’s theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("While working on ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("my recent paper with Ben Green")]#text(", I was introduced to the ")#link("http://scholarpedia.org/article/Ratner_Theory")[#text("beautiful theorems")]#text(" of ")#link("http://en.wikipedia.org/wiki/Marina_Ratner")[#text("Marina Ratner")]#text(" on ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" flows on ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous spaces")]#text(", and their application to questions in number theory, such as the ")#link("http://en.wikipedia.org/wiki/Oppenheim_conjecture")[#text("Oppenheim conjecture")]#text(" (first solved ")#link("http://www.ams.org/mathscinet-getitem?mr=993328")[#text("by Margulis")]#text(", by establishing what can retrospectively be viewed as a special case of Ratner’s theorems). This is a subject that I am still only just beginning to learn, but hope to understand better in the future, especially given that quantitative analogues of Ratner’s theorems should exist, and should have even more applications to number theory (see for instance ")#link("http://arxiv.org/abs/0708.4040")[#text("this recent paper of Einsiedler, Margulis, and Venkatesh")]#text("). In this post, I will try to describe some of the background for this theorem and its connection with the Oppenheim conjecture; I will not discuss the proof at all, largely because I have not fully understood it myself yet. For a nice introduction to these issues, I recommend ")#link("http://arxiv.org/abs/math/0310402")[#text("Dave Morris’ recent book on the subject")]#text(" (and this post here is drawn in large part from that book).")

#text("Ratner’s theorem takes place on a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(". Informally, a homogeneous space is a space X which looks “the same” when viewed from any point on that space. For instance, a sphere ")#mi("S^2")#text(" is a homogeneous space, but the surface of a cube is not (the cube looks different when viewed from a corner than from a point on an edge or on a face). More formally, a homogeneous space is a space X equipped with an ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" ")#mi("(g,x) \\mapsto gx")#text(" of a group G of symmetries which is ")#link("http://en.wikipedia.org/wiki/Group_action#Types_of_actions")[#text("transitive")]#text(": given any two points x, y on the space, there is at least one symmetry g that moves x to y, thus y=gx. (For instance the cube has several symmetries, but not enough to be transitive; in contrast, the sphere ")#mi("S^2")#text(" has the transitive action of the special orthogonal group SO(3) as its symmetry group.) It is not hard to see that a homogeneous space X can always be identified (as a set with an action of G) with a quotient ")#mi("G/\\Gamma := \\{ g\\Gamma: g \\in G \\}")#text(", where ")#mi("\\Gamma")#text(" is a subgroup of G; indeed, one can take ")#mi("\\Gamma")#text(" to be the stabiliser ")#mi("\\Gamma := \\{ g \\in G: gx = x \\}")#text(" of an arbitrarily chosen point x in X, and then identify ")#mi("g\\Gamma")#text(" with ")#mi("g\\Gamma x = gx")#text(". For instance, the sphere ")#mi("S^2")#text(" has an obvious action of the special orthogonal group SO(3), and the stabiliser of (say) the north pole can be identified with SO(2), so that the sphere can be identified with SO(3)/SO(2). Similarly, the ")#link("http://en.wikipedia.org/wiki/Hyperbolic_plane")[#text("hyperbolic plane")]#text(" ")#mi("{\\Bbb H}")#text(" is isomorphic to ")#mi("SL(2,{\\Bbb R})/SO(2)")#text(". Furthermore, the ")#emph[#text("cosphere bundle")]#text(" ")#mi("S^* X")#text(" of X – the space of unit (co)tangent vectors on X – is also a homogeneous space with structure group ")#mi("SL(2,{\\Bbb R})")#text(". (For instance, the cosphere bundle ")#mi("S^* {\\Bbb H}")#text(" of the hyperbolic plane ")#mi("{\\Bbb H}")#text(" is isomorphic to ")#mi("SL(2,{\\Bbb R}) / \\{ +1, -1 \\}")#text(".)")

#text("For the purposes of Ratner’s theorem, we only consider homogeneous spaces X in which the symmetry group G is a connected finite-dimensional Lie group, and X is ")#emph[#text("finite volume")]#text(" (or more precisely, it has a finite non-trivial G-invariant measure). Every compact homogeneous space is finite volume, but not conversely; for instance the ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(" ")#mi("SO(2,{\\Bbb R}) \\backslash SL(2,{\\Bbb R})/SL(2,{\\Bbb Z})")#text(" is finite volume but not compact (it has a cusp). (The modular curve has two real dimensions, but just one complex dimension, hence the term “curve”; rather confusingly, it is also referred to as the “modular surface”. As for the term “modular”, observe that the ")#link("http://en.wikipedia.org/wiki/Moduli_space")[#text("moduli space")]#text(" of ")#link("http://en.wikipedia.org/wiki/Unimodular_lattice")[#text("unimodular lattices")]#text(" in ")#mi("{\\Bbb R}^2")#text(" has an obvious action of ")#mi("SL(2,{\\Bbb R})")#text(", with the stabiliser of ")#mi("{\\Bbb Z}^2")#text(" being ")#mi("SL(2,{\\Bbb Z})")#text(", as well as an obvious left action of ")#mi("SO(2,{\\Bbb R})")#text(" and so this moduli space can be identified with the modular curve.)")

#metadata(none) <tao-600c8890b43f91104ce8>#text("Let U be a subgroup of G. The group U then acts on X, creating an orbit ")#mi("Ux := \\{ gx: g \\in U \\}")#text(" inside X for every point x in X. Even though X “looks the same” from every point, the orbits of U need not all look alike, basically because we are not assuming U to be a normal subgroup (i.e. ")#mi("Ug \\neq gU")#text(" in general). For instance on the surface of the earth, which we model as a sphere ")#mi("S^2 = SO(3)/SO(2)")#text(", if we let ")#mi("U \\cong SO(2)")#text(" be the group of rotations around the Earth’s axis, then the orbits Ux are nothing more than the ")#link("http://en.wikipedia.org/wiki/Circle_of_latitude")[#text("circles of latitude")]#text(", together with the north and south poles as singleton orbits.")

#text("In the above example, the orbits were closed subsets of the space X. But this is not always the case. Consider for instance the 2-torus ")#mi("X := {\\Bbb R}^2/{\\Bbb Z}^2")#text(", and let ")#mi("U \\leq {\\Bbb R}^2")#text(" be a line ")#mi("U := \\{ (x, \\alpha x): x \\in {\\Bbb R} \\}")#text(". Then if the slope ")#mi("\\alpha")#text(" of this line is irrational, the orbit Ux of a point x in the torus will be a dense one-dimensional subset of that two-dimensional torus, and thus definitely not closed. More generally, when considering the orbit of a subspace ")#mi("U \\leq {\\Bbb R}^m")#text(" on a torus ")#mi("{\\Bbb R}^m/{\\Bbb Z}^m")#text(", the orbit Ux of a point x will always be a dense subset of some subtorus of ")#mi("{\\Bbb R}^m/{\\Bbb Z}^m")#text(" (this is essentially ")#link("http://en.wikipedia.org/wiki/Kronecker%27s_theorem")[#text("Kronecker’s theorem")]#text(").")

#text("From these examples we see that even if an orbit Ux is not closed, its closure ")#mi("\\overline{Ux}")#text(" is fairly “nice” – indeed, in all of the above cases, the closure can be written as a closed orbit Hx of some other group ")#mi("U \\leq H \\leq G")#text(" intermediate between U and G.")

#text("Unfortunately, this nice state of affairs is not true for arbitrary flows on homogeneous spaces. A classic example is ")#link("http://en.wikipedia.org/wiki/Geodesic_flow")[#text("geodesic flow")]#text(" on surfaces M of constant negative curvature (such as the modular curve mentioned earlier). This flow can be viewed as an action of ")#mi("{\\Bbb R}")#text(" (representing time) on the cosphere bundle ")#mi("S^* M")#text(" (which represents the state space of a particle on M moving at unit speed), which is a homogeneous space with symmetry group ")#mi("SL(2,{\\Bbb R})")#text(". In this example, the subgroup ")#mi("U \\leq SL(2,{\\Bbb R})")#text(" is given as")

#align(center)[#mi("\\displaystyle U := \\{ \\begin{pmatrix} e^t & 0 \\\\ 0 & e^{-t} \\end{pmatrix}: t \\in {\\Bbb R} \\} \\cong {\\Bbb R}")#text(". (*)")]

#text("For certain surfaces, this flow is quite chaotic, for instance Morse produced an example of a geodesic flow on a constant negative curvature surface whose closed orbit ")#mi("\\overline{Ux}")#text(" had cross-sections that were homeomorphic to a Cantor set. (For the modular curve, there is an old result of Artin that exhibits an orbit which is dense in the whole curve, but I don’t know if one can obtain Cantor-like behaviour in this curve. There also seems to be some connection between geodesic flow on this curve and continued fractions which I don’t really understand.) [")#emph[#text("Edit")]#text(", Jul 20 2017: these connections are discussed in ")#link("http://www.ams.org/mathscinet-getitem?mr=810563")[#text("this paper of Series")]#text(", and Cantor-like orbits are constructed in this ")#link("http://www.ams.org/mathscinet-getitem?mr=795536")[#text("further paper of Series")]#text(". Thanks to Caroline Series for the references.]")

#text("The reason for the “badness” of the above examples stems from the exponential instabilities present in the action of U, which can already be suspected from the presence of the exponential in (*). (Exponential instability is not a sufficient condition for chaos, but is often a necessary one.) Ratner’s theorems assert, very roughly speaking, that if one eliminates all exponential behaviour from the group U, then the orbits Ux become nicely behaved again; they are either closed, or are dense in larger closed orbits Hx.")

#text("What does it mean to eliminate “all exponential behaviour”? Consider a one-dimensional matrix group")

#align(center)[#tao-fit-display[#mitex("U = \\{ A^t: t \\in {\\Bbb R} \\}")]]

#text("where A is a matrix with some designated logarithm ")#mi("\\log(A)")#text(", and ")#mi("A^t := \\exp( t \\log(A) )")#text(". Generally, we expect the coefficients of ")#mi("A^t")#text(" to contain exponentials (as is the case in (*)), or sines and cosines (which are basically just a complex version of exponentials). However, if A is a ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" matrix (the only eigenvalue is 1, or equivalently that ")#mi("A=1+N")#text(" for some ")#link("http://en.wikipedia.org/wiki/Nilpotent")[#text("nilpotent")]#text(" matrix N), then ")#mi("A^t")#text(" is a polynomial in t, rather than an exponential or sinusoidal function of t. More generally, we say that an element g of a Lie group G is unipotent if its adjoint action ")#mi("x \\mapsto gxg^{-1}")#text(" on the Lie algebra ")#mi("\\mathfrak{g}")#text(" is unipotent. Thus for instance any element in the ")#link("http://en.wikipedia.org/wiki/Centralizer")[#text("centraliser")]#text(" of G is unipotent, and every element of a nilpotent group is unipotent.")

#text("We can now state one of Ratner’s theorems.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Ratner’s orbit closure theorem")]#text(". Let ")#mi("X = G/\\Gamma")#text(" be a homogeneous space of finite volume with a connected finite-dimensional Lie group G as symmetry group, and let U be a connected subgroup of G generated by unipotent elements. Let Ux be an orbit of U in X. Then the closure ")#mi("\\overline{Ux}")#text(" is itself a homogeneous space of finite volume; in particular, there exists a closed subgroup ")#mi("U \\leq H \\leq G")#text(" such that ")#mi("\\overline{Ux}=Hx")#text(".")
]

#text("This theorem (first conjectured by Raghunathan, I believe) asserts that the orbit of any unipotent flow is dense in some homogeneous space of finite volume. In the case of algebraic groups, it has a nice corollary: any unipotent orbit in an algebraic homogeneous space which is ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski")]#text(" dense, is topologically dense as well.")

#text("In some applications, density is not enough; we also want ")#emph[#text("equidistribution")]#text(". Happily, we have this also:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Ratner’s equidistribution theorem")]#text(". Let X, G, U, x, H be as in the orbit closure theorem. Assume also that U is a one-parameter group, thus ")#mi("U = \\{ g_t: t \\in {\\Bbb R} \\}")#text(" for some homomorphism ")#mi("t \\mapsto g_t")#text(". Then ")#mi("Ux")#text(" is equidistributed in ")#mi("Hx")#text("; thus for any continuous function ")#mi("F: Hx \\to {\\Bbb R}")#text(" we have")

#align(center)[#mi("\\displaystyle \\lim_{T \\to \\infty} \\frac{1}{T} \\int_0^T F(g_t x)\\ dt = \\int_{Hx} F")#linebreak()#text(" where ")#mi("\\int_{Hx}")#text(" represents integration on the normalised Haar measure on Hx.")]
]

#text("One can also formulate this theorem (first conjectured by Dani, I believe) for groups U that have more than one parameter, but it is a bit technical to do so and we shall omit it. My paper with Ben Green concerns a quantitative version of this theorem in the special case when X is a nilmanifold, and where the continuous orbit Ux is replaced by a discrete polynomial sequence. (There is an extensive literature on generalising Ratner’s theorems from continuous U to discrete U, which I will not discuss here.)")

#text("From the equidistribution theorem and a little bit of ergodic theory one has a measure-theoretic corollary, which describes ergodic measures of a group generated by unipotent elements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Ratner’s measure classification theorem")]#text(". Let X be a finite volume homogeneous space for a connected Lie group G, and let U be a connected subgroup of G generated by unipotent elements. Let ")#mi("\\mu")#text(" be a probability measure on X which is ergodic under the action of U. Then ")#mi("\\mu")#text(" is the Haar measure of some closed finite volume orbit Hx for some ")#mi("U \\leq H \\leq G")#text(".")
]

#heading(level: 1)[#text("— The Oppenheim conjecture —")]

#text("To illustrate the power of Ratner’s orbit closure theorem, we discuss the first major application of this theorem, namely to solve the ")#link("http://en.wikipedia.org/wiki/Oppenheim_conjecture")[#text("Oppenheim conjecture")]#text(". (Margulis’ solution of the Oppenheim conjecture predates Ratner’s papers by a year or two, but Margulis solved the conjecture by establishing a special case of the orbit closure theorem.) I will not discuss applications of the other two theorems of Ratner here.")

#text("The Oppenheim conjecture concerns the possible value of ")#link("http://en.wikipedia.org/wiki/Quadratic_form")[#text("quadratic forms")]#text(" in more than one variable, when all the variables are restricted to be integer. For instance, the famous ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/en.wikipedia.org/wiki/Lagrange's_four-square_theorem")[#text("four squares theorem")]#text(" of Lagrange asserts that the set of possible values of the quadratic form")

#align(center)[#tao-fit-display[#mitex("Q(n_1,n_2,n_3,n_4) := n_1^2 + n_2^2 + n_3^2 + n_4^2,")]]

#text("where ")#mi("n_1,n_2,n_3,n_4")#text(" range over the integers, are precisely the natural numbers ")#mi("\\{0,1,2,\\ldots\\}")#text(". More generally, if Q is a ")#link("http://en.wikipedia.org/wiki/Positive_definite_bilinear_form")[#text("positive definite")]#text(" quadratic form in m variables, possibly with irrational coefficients, then the set ")#mi("Q({\\Bbb Z}^m)")#text(" of possible values of Q can be easily seen to be a discrete subset of the positive real axis. I can’t resist mentioning here a ")#link("http://en.wikipedia.org/wiki/15_and_290_theorems")[#text("beautiful theorem")]#text(" of Jon Hanke and my friend ")#link("http://en.wikipedia.org/wiki/Manjul_Bhargava")[#text("Manjul Bhargava")]#text(": if a positive-definite quadratic form with integer coefficients represents all positive integers up to 290, then it in fact represents all positive integers. If the off-diagonal coefficients are even, one only needs to represent the integers up to 15; this was done by ")#link("http://en.wikipedia.org/wiki/John_H._Conway")[#text("John Conway")]#text(" and my classmate from Princeton, Will Schneeberger.")

#text("What about if Q is indefinite? Then a number of things can happen. If Q has integer coefficients, then clearly ")#mi("Q({\\Bbb Z}^m)")#text(" must take integer values, and can take arbitrarily large positive or negative such values, but can have interesting gaps in the representation. For instance, the question of which integers are represented by ")#mi("Q(n_1,n_2) := n_1^2 - d n_2^2")#text(" for some integer d already involves a little bit of class field theory of ")#mi("{\\Bbb Q}(\\sqrt{-d})")#text(", and was first worked out by Gauss.")

#text("Similar things can happen of course if Q has commensurate coefficients, i.e. Q has integer coefficients after dividing out by a constant. What if Q has incommensurate coefficients? In the two-variable case, we can still have some discreteness in the representation. For instance, if ")#mi("\\phi := \\frac{1+\\sqrt{5}}{2}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Golden_ratio")[#text("golden ratio")]#text(", then the quadratic form")

#align(center)[#tao-fit-display[#mitex("Q(n_1,n_2) = n_1^2 - \\phi^2 n_2^2 = (n_1-\\phi n_2) (n_1 + \\phi n_2)")]]

#text("cannot get arbitrarily close to 0, basically because the golden ratio is very hard to approximate by a rational a/b (the best approximants being given, of course, by the ")#link("http://en.wikipedia.org/wiki/Fibonacci_number")[#text("Fibonacci numbers")]#text(").")

#text("However, for indefinite quadratic forms Q of three or more variables ")#mi("m \\geq 3")#text(" with incommensurate coefficients, ")#link("http://www.pubmedcentral.nih.gov/pagerender.fcgi?artid=522544&pageindex=1")[#text("Oppenheim conjectured")]#text(" in 1929 that there was no discreteness whatsoever – the set ")#mi("Q({\\Bbb Z}^m)")#text(" was dense in ")#mi("{\\Bbb R}")#text(". There was much partial progress on this problem in the case of many variables (in large part due to the power of the Hardy-Littlewood circle method in this setting), but the hardest case of just three variables was only solved ")#link("http://www.ams.org/mathscinet-getitem?mr=993328")[#text("by Margulis")]#text(" in 1989.")

#text("Nowadays we can obtain Margulis’ result rather easily from Ratner’s theorem as follows. It is straightforward to reduce to the most difficult case, namely when m=3. We need to show that the image of ")#mi("{\\Bbb Z}^3")#text(" under the quadratic form ")#mi("Q: {\\Bbb R}^3 \\to {\\Bbb R}")#text(" is dense in ")#mi("{\\Bbb R}")#text(". Now, every quadratic form comes with a special orthogonal group SO(Q), defined as the orientation-preserving linear transformations that preserve Q; for instance, the Euclidean form ")#mi("x_1^2 + x_2^2 + x_3^2")#text(" in ")#mi("{\\Bbb R^3}")#text(" has the rotation group SO(3), the Minkowski form ")#mi("x_1^2 + x_2^2 + x_3^2 - x_4^2")#text(" has the ")#link("http://en.wikipedia.org/wiki/Lorentz_group")[#text("Lorentz group")]#text(" SO(3,1), and so forth. The image of ")#mi("{\\Bbb Z}^3")#text(" under Q is the same as that of the larger set ")#mi("SO(Q) {\\Bbb Z}^3")#text(". [We may as well make our domain as large as possible, as this can only make our job easier, in principle at least.] Since Q is indefinite, ")#mi("Q({\\Bbb R}^3) = {\\Bbb R}")#text(", and so it will suffice to show that ")#mi("SO(Q) {\\Bbb Z}^3")#text(" is dense in ")#mi("{\\Bbb R}^3")#text(". Actually, for minor technical reasons it is convenient to just work with the identity component ")#mi("SO(Q)^+")#text(" of SO(Q) (which has two connected components).")

#text("[An analogy with the Euclidean case ")#mi("Q(x_1,x_2,x_3) = x_1^2+x_2^2+x_3^2")#text(" might be enlightening here. If one spins around the lattice ")#mi("{\\Bbb Z}^3")#text(" by the Euclidean orthogonal group SO(Q)=SO(3), one traces out a union of spheres around the origin, where the radii of the spheres are precisely those numbers whose square can be expressed as the sum of three squares. In this case, ")#mi("SO(Q) {\\Bbb Z}^3")#text(" is not dense, and this is reflected in the fact that not every number is the sum of three perfect squares. The Oppenheim conjecture asserts instead that if you spin a lattice by an irrational Lorentz group, one traces out a dense set.]")

#text("In order to apply Ratner’s theorem, we will view ")#mi("SO(Q)^+ {\\Bbb Z}^3")#text(" as an orbit Ux in a symmetric space ")#mi("G/\\Gamma")#text(". Clearly, U should be the group ")#mi("SO(Q)^+")#text(", but what to do about the set ")#mi("{\\Bbb Z}^3")#text("? We have to turn it somehow into a point in a symmetric space. The obvious thing to do is to view ")#mi("{\\Bbb Z}^3")#text(" as the zero coset (i.e. the origin) in the torus ")#mi("{\\Bbb R}^3/{\\Bbb Z}^3")#text(", but this doesn’t work, because ")#mi("SO(Q)^+")#text(" does not act on this torus (it is not a subgroup of ")#mi("{\\Bbb R}^3")#text("). So we need to lift up to a larger symmetric space ")#mi("G/\\Gamma")#text(", with a symmetry group G which is large enough to accommodate ")#mi("SO(Q)^+")#text(".")

#text("The problem is that the torus is the moduli space for translations of the lattice ")#mi("{\\Bbb Z}^3")#text(", but ")#mi("SO(Q)^+")#text(" is not a group of translations; it is instead a group of ")#link("http://en.wikipedia.org/wiki/Unimodular_matrix")[#text("unimodular")]#text(" linear transformations, i.e. a subgroup of the special linear group ")#mi("SL(3,{\\Bbb R})")#text(". This group acts on lattices, and the stabiliser of ")#mi("{\\Bbb Z}^3")#text(" is ")#mi("SL(3,{\\Bbb Z})")#text(". Thus the right homogeneous space to use here is ")#mi("X := SL(3,{\\Bbb R})/SL(3,{\\Bbb Z})")#text(", which has a geometric interpretation as the ")#link("http://en.wikipedia.org/wiki/Moduli_space")[#text("moduli space")]#text(" of unimodular lattices in ")#mi("{\\Bbb R}^3")#text(" (i.e. a higher-dimensional version of the modular curve); X is not compact, but one can verify that X has finite volume, which is good enough for Ratner’s theorem to apply. Since the group ")#mi("G = SL(3,{\\Bbb R})")#text(" contains ")#mi("U=SO(Q)^+")#text(", U acts on X. Let ")#mi("x = SL(3,{\\Bbb Z})")#text(" be the origin in X (under the moduli space interpretation, x is just the standard lattice ")#mi("{\\Bbb Z}^3")#text("). If Ux is dense in X, this implies that the set of matrices ")#mi("SO(Q)^+ SL(3,{\\Bbb Z})")#text(" is dense in ")#mi("SL(3,{\\Bbb R})")#text("; applying this to, say, the unit vector (1,0,0), we conclude that ")#mi("SO(Q)^+ {\\Bbb Z}^3")#text(" is dense in ")#mi("{\\Bbb R}^3")#text(" as required. (These reductions are due to Raghunathan. Note that the new claim is actually a bit stronger than the original Oppenheim conjecture; not only are we asserting now that ")#mi("SO(Q)^+")#text(" applied to the standard lattice ")#mi("{\\Bbb Z}^3")#text(" sweeps out a dense subset of Euclidean space, we are saying the stronger statement that one can use ")#mi("SO(Q)^+")#text(" to bring the standard lattice “arbitrarily close” to any given unimodular lattice one pleases, using the topology induced from ")#mi("SL(3,{\\Bbb R})")#text(".)")

#text("How do we show that Ux is dense in X? We use Ratner’s orbit closure theorem! This theorem tells us that if Ux is ")#emph[#text("not")]#text(" dense in X, it must be much smaller – it must be contained in a closed finite volume orbit Hx for some proper closed connected subgroup H of ")#mi("SL(3,{\\Bbb R})")#text(" which still contains ")#mi("SO(Q)^+")#text(". [To apply this theorem, we need to check that U is generated by unipotent elements, which can be done by hand; here is where we need to assume ")#mi("m \\geq 3")#text(".] An inspection of the Lie algebras of ")#mi("SL(3,{\\Bbb R})")#text(" and ")#mi("SO(Q)^+")#text(" shows in fact that the only such candidate for H is ")#mi("SO(Q)^+")#text(" itself (here is where we really use the hypothesis m=3!). Thus ")#mi("SO(Q)^+ x")#text(" is closed and finite volume in X, which implies that ")#mi("SO(Q)^+ \\cap SL(3,{\\Bbb Z})")#text(" is a ")#link("http://en.wikipedia.org/wiki/Lattice_%28mathematics%29")[#text("lattice")]#text(" in ")#mi("SO(Q)^+")#text(". Some algebraic group theory (specifically, the Borel density theorem) then shows that ")#mi("SO(Q)^+")#text(" lies in the ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski closure")]#text(" of ")#mi("SO(Q)^+ \\cap SL(3,{\\Bbb Z})")#text(", and in particular is definable over ")#mi("{\\Bbb Q}")#text(". It is then not difficult to see that the only way this can happen is if Q has rational coefficients (up to scalar multiplication), and the Oppenheim conjecture follows.")

#text("[")#emph[#text("Update")]#text(", September 29: Link to Dave Morris’ book repaired slightly.]")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932ed592f893eef3bc636a8f4beb1296a0e591646747b9b56c21c30da01c6440-328e45c09d3dd1e43bcff04745a90e7031cd3f2c8e9e5a53a55855f03a975551.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-10675")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("There is a slight problem with the link to Morris’ book. Arxiv will take you to the right place but not without complaining first.")

#text("And feel free to delete ths comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-10676")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-10699")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("Dear Terry,")

#text("Are there any analogues to Ratner’s Theorem that can be extended to non-homogeneous spaces (i.e. the surface of a cube?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1926d81a4d6dade94e6cba51e47c9245a7acabbb7c771e5a57affa4e72811730-a6be2cf0bc51d30d7ff8c333ca2fae18fe5d2b0b2211f5b37ba2b34ae0c4727a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rached")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-646023")[#strong[#text("John Rached")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("This question has aged well… a 1-dimensional foliation of a surface with boundary may exist if the Euler characteristic is 0. The restriction of the SO(2) action to the circles foliating a cylinder that Terry gives is a great example. There are now analogs of Ratner’s theorem that look much different than connected Lie group quotients by lattices. This is for the SL(2,R) action on the deformation space of a Riemann surface of a fixed topological type. For unipotent subgroups of SL(2,R), Ratner’s theorems don’t quite extend – the same sort of fractal behavior Terry mentions in his post for the geodesic flow on a finite volume hyperbolic manifold is observed here. One can, however, still ask whether the rates obtained for equidistribution (in Terry’s post above) in the homogeneous setting hold in the inhomogeneous context. This is a very intriguing question to me.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matheus")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-10700")[#strong[#text("Matheus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("Dear Terry,")

#text("concerning your comment “There also seems to be some connection between geodesic flow on this curve and continued fractions which I don’t really understand.”, it seems that the article")

#text("“Symbolic dynamics for the modular surface and beyond” by Svetlana Katok and Ilie Ugarcovici (published on Bulletin of AMS, 44, n.1, (2007) p. 87-132)")

#text("gives a good explanation of the connection cited in your comment. More precisely, Katok et al. survey shows how one can undertsand the dynamics of this geodesic flow from the construction of suitable Markov partitions provided by continued fractions algorithms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-10788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Prashant: In some cases one can foliate a non-homogeneous space into homogeneous spaces, if all the orbits of the ambient group are closed, and then Ratner’s theorem can apply to each space separately. For instance, the surface of a cylinder is not a homogeneous space for the action of the rotation group SO(2) around its axis, because this action is not transitive; but one can foliate that surface into circles, each of which is a homogeneous space for SO(2). Of course, orbits are not always closed (this is why we need Ratner’s theorem in the first place!)… My impression is that once one works with more general group actions on spaces, orbits can in fact get quite chaotic and not pleasantly classifiable.")

#text("Dear Matheus: thank you for the reference! It occurred to me afterwards that geodesic flow on the modular curve is also connected to the value of quadratic forms in two variables, by the exact same reductions used in the discussion of the Oppenheim conjecture, and that problem is already known to be connected with continued fractions (cf. my discussion above on the golden ratio). Of course, in two dimensions, the orthogonal group ")#mi("SO(Q)^+")#text(" is not generated by unipotents, which can be viewed as an explanation as to why the Oppenheim conjecture is restricted to three and higher dimensions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Unipotent elements of the Lorentz group, and conic sections « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-11212")[#strong[#text("Unipotent elements of the Lorentz group, and conic sections « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2007")])]

#text("[…] rotations, polynomial growth, unipotent matrices In my discussion of the Oppenheim conjecture in my recent post on Ratner’s theorems, I mentioned in passing the simple but crucial fact that the (orthochronous) special orthogonal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 1: Overview « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-23671")[#strong[#text("254A, Lecture 1: Overview « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("[…] actions arising from a nilpotent Lie group with discrete stabiliser. One of the key results here is Ratner’s theorem, which describes the distribution of orbits in nilsystems, and also in a more general class of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Cech compactification « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-24173")[#strong[#text("254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Cech compactification « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("[…] on the Lie algebra is unipotent rather than trivial, then Theorem 2 still holds; this follows from Ratner’s theorem, of which we will discuss much later in this course. But the claim is not true for all group […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-24864")[#strong[#text("254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2008")])]

#text("[…] we characterise the distribution of polynomial sequences in torii (a baby case of a variant of Ratner’s theorem due to (Leon) Green, which we will cover later in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-27067")[#strong[#text("254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2008")])]

#text("[…] nilpotent groups, Ratner’s theorem, structure The last two lectures of this course will be on Ratner’s theorems on equidistribution of orbits on homogeneous spaces. Due to lack of time, I will not be able to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-27323")[#strong[#text("254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2008")])]

#text("[…] groups, Mautner phenomenon, Ratner’s theorem, unipotence In this final lecture, we establish a Ratner-type theorem for actions of the special linear group on homogeneous spaces. More precisely, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The van der Corput’s trick, and equidistribution on nilmanifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-30358")[#strong[#text("The van der Corput’s trick, and equidistribution on nilmanifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("[…] character mentioned above; this is an extremely simple case of a much more general result known as Ratner’s theorem, which I will not talk further about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab0cd50e81332655db6b3f2e939cc7830561dcf352a3c24ccb1125c8295f9c1f-d1133fda8930800c53eced9ca2308e6a37b0a1b22edfcffebf5957235c63bd7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete L. Clark")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-33606")[#strong[#text("Pete L. Clark")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2008")])]

#text("Dear Prof. Tao,")

#text("The 290 theorem was conjectured by John Conway around the same time as the 15 theorem. The proof of the 290 theorem is joint work of Manjul Bhargava and (my colleague) Jonathan Hanke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-33607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2008")])]

#text("Dear Pete: thanks for the correction! I think I had gotten confused because the Bhargava-Hanke paper does not yet seem to be published.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series I: Gregory Margulis, “Homogeneous dynamics and number theory I.” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-34950")[#strong[#text("Distinguished Lecture Series I: Gregory Margulis, “Homogeneous dynamics and number theory I.” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("[…] in homogeneous spaces. One famous example is the Oppenheim conjecture (which I also blogged about here), first proven in full generality by Margulis. It concerns the possible values of a real […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series III: Gregory Margulis, “Homogeneous dynamics and number theory III.” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-35027")[#strong[#text("Distinguished Lecture Series III: Gregory Margulis, “Homogeneous dynamics and number theory III.” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2009")])]

#text("[…] some of the ideas around the theory of unipotent flows on homogeneous spaces, culminating in the orbit closure, equidsitribution, and measure classification theorems of Ratner in the subject. Margulis also discussed the application to metric theory of Diophantine […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-35994")[#strong[#text("Furstenberg’s 2x, 3x (mod 1) problem « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")]

#text("[…] problems, one finds Margulis’ solution to Oppenheim conjecture (see e.g. this blog post of Terence Tao). Here, the basic idea is to convert the study of the values of indefinite quadratic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-40695")[#strong[#text("“The remarkable effectiveness of Ergodic Theory in Number Theory” « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")]

#text("[…] the several successful applications of Ergodic Theory in old problems of Number Theory (such as Margulis solution of Oppenheim conjecture, Elkies-McMullen theorem on the gap distribution of mod 1, Green-Tao theorem about long arithmetic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the Gowers U^4 norm « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-42650")[#strong[#text("An inverse theorem for the Gowers U^4 norm « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("[…] reason why this Lemma implies Claim 1 is because the joint orbit of , , can be controlled, using Ratner’ s theorem (or more precisely, a quantitative version of this theorem that Ben and I worked out a few years […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lindenstrauss, Ngo, Smirnov, Villani « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-46557")[#strong[#text("Lindenstrauss, Ngo, Smirnov, Villani « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("[…] theorems; this was discussed earlier on this blog at this writeup of a lecture of Margulis, or at this discussion of Ratner’s theorems. Indeed, even though the Oppenheim conjecture is a purely number-theoretic statement, the only […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-46595")[#strong[#text("ICM2010 — Lindenstrauss laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] of a very general and important story. I am not competent to tell that story, but fortunately Terence Tao has blogged on it. (That is not the only post of Terry’s on that topic: another I would recommend is this one. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-56143")[#strong[#text("Conférence internationale Géométrie Ergodique (Orsay 2011) I « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")]

#text("[…] Closing the “historical introduction” part of the talk, Lindenstrauss remarked that Dani-Margulis theorem is a special case of Raghunathan’s conjecture which in particular classifies orbit closures in whenever is generated by unipotent one-parameter subgroups. Furthermore, Raghunathan’s conjecture was proved in full generality by Marina Ratner. Remark 4 Of course, this is a very long history and due to the usual space-time limitations, Lindenstrauss was obliged to stop here the introductory considerations. For the curious reader wishing to learn more about the topics mentioned above, I strongly recommend reading Terence Tao’s posts on this subject, specially these ones here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ratner’s Theorems | YAMB")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-67754")[#strong[#text("Ratner’s Theorems | YAMB")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("[…] subgroups, i.e., the image of by a homomorphism. However, according to Terrence Tao’s blog post on this subject, it can be formulated for more general amenable groups . In the case when is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-107229")[#strong[#text("Diffusion in Ehrenfest wind-tree model « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2011")]

#text("[…] a celebrated Ratner-like classification theorem of closures of -orbits of genus 2 translation surfaces by K. Calta and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avila, Bhargava, Hairer, Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-404906")[#strong[#text("Avila, Bhargava, Hairer, Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("[…] of Ratner’s celebrated rigidity theorems for unipotently generated groups (discussed in this previous blog post). Ratner’s theorems are already notoriously difficult to prove, and rely very much on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-453609")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] literature, such as Ratner’s theorems on equidistribution of unipotent flows, discussed in this previous blog post. There are yet further precise instances of this principle which are conjectured to be true, but […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-476370")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("This is an ancient correction, but the modular curve is the double coset space ")#mi("SO(2, \\mathbb{R}) \\backslash SL(2, \\mathbb{R}) / SL(2, \\mathbb{Z})")#text(". It has two real dimensions, and is a one dimensional complex manifold. The quotient ")#mi("SL(2, \\mathbb{R}) / SL(2, \\mathbb{Z})")#text(" which you refer to is three dimensional, so it can’t support complex structure. It is also finite volume, because it is a circle bundle over the modular curve.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maryam Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-483780")[#strong[#text("Maryam Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("[…] spaces instead of unipotent flows on homogeneous spaces. (I discussed Ratner’s theorems in this previous post. By an unhappy coincidence, Ratner also passed away this month, aged 78.) Ratner’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a81f2214ae05cd91b405a5f653979e27684d525df38c839085bda1741cd880-682ebf6fdf567dadbbcfc7adb7f3c200c1c5008f4a776fc2ffac572494f0b0d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pallav123goyal")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-483782")[#strong[#text("pallav123goyal")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("I think there’s a minor typo. You have misspelled Prof Raghunathan’s name ‘Raghanuthan’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-483785")[#strong[#text("The unprecedented Best Seller! | My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] spaces instead of unipotent flows on homogeneous spaces. (I discussed Ratner’s theorems in this previous post. By an unhappy coincidence, Ratner also passed away this month, aged 78.) Ratner’s theorems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-483869")[#strong[#text("An Epsilon of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-483931")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("In the statement of Ratner’s orbit closure theorem there is a redundant “in”, namely:")

#text("Let Ux be an orbit in of U in X.")

#text("should be:")

#text("Let Ux be an orbit of U in X.")

#text("or even:")

#text("Let Ux be an orbit of x under U in X.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-484110")[#strong[#text("some published posts about Maryam Mirzakhani | Mathpresso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2017")]

#text("[…] spaces instead of unipotent flows on homogeneous spaces. (I discussed Ratner’s theorems in this previous post. By an unhappy coincidence, Ratner also passed away this month, aged 78.) Ratner’s theorems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russ Lyons")]], [#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-515360")[#strong[#text("Russ Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2019")])]

#text("Terry:")

#text("You wrote, “More generally, any Riemannian manifold of constant curvature is a homogeneous space; for instance, an m-dimensional torus can be identified with {\\Bbb R}^m/{\\Bbb Z}^m, while a surface X of constant negative curvature can be identified with SL(2,{\\Bbb R})/\\Gamma for some subgroup \\Gamma of SL(2,{\\Bbb R}) (e.g. the hyperbolic plane {\\Bbb H} is isomorphic to SL(2,{\\Bbb R})/SO(2)).” Is this what you meant? In the negatively curved case, all homogeneous spaces of constant curvature are simply connected, I believe.")

#emph[#text("[Oops, you are right, this was incorrect and has now been removed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/#comment-613885")[#strong[#text("Some published posts about Maryam Mirzakhani | DIRANLOU")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2020")]

#text("[…] spaces instead of unipotent flows on homogeneous spaces. (I discussed Ratner’s theorems in this previous post. By an unhappy coincidence, Ratner also passed away this month, aged 78.) Ratner’s theorems […]")
]
