// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/
// Converted to Typst by tao2typ: "2026-10-14T16:35:21.260760+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 18: The structure of high-curvature regions of Ricci flow", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 18: The structure of high-curvature regions of Ricci flow")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/")[#text("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Having characterised the structure of ")#mi("\\kappa")#text("-solutions, we now use them to describe the structure of high curvature regions of Ricci flow, as promised back in ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("Lecture 12")]#text(", in particular controlling their geometry and topology to the extent that surgery will be applied, which we will discuss in the next (and final) lecture of this class.")

#text("The material here is drawn largely from ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" and Perelman’s ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("first")]#text(" and ")#link("http://arxiv.org/abs/math.DG/0303109")[#text("second")]#text(" papers; see also ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott’s notes")]#text(" and ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu’s paper")]#text(" for closely related material. Due to lack of time, some details here may be a little sketchy.")

#metadata(none) <tao-4976c8e4edebf228afbc>

#heading(level: 1)[#text("— Canonical neighbourhoods —")]

#text("Let us formally define the notions of a canonical neighbourhood that were introduced in Lecture 12. They are associated with the various local geometries that are possible for three-dimensional ")#mi("\\kappa")#text("-solutions. The first type of neighbourhood is related to the round spherical space forms ")#mi("S^3/\\Gamma")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (")#mi("\\varepsilon")#text("-round) Let ")#mi("\\varepsilon > 0")#text(". A compact connected 3-manifold ")#mi("(M,g)")#text(" is ")#mi("\\varepsilon")#text("-round if one can identify M with a spherical space form ")#mi("S^3/\\Gamma")#text(" with the constant curvature metric h such that some multiple of g lies within ")#mi("\\varepsilon")#text(" of h in the ")#mi("C^{\\lfloor 1/\\varepsilon \\rfloor}")#text(" topology.")
]

#text("Note that if a sequence of manifolds ")#mi("(M_n,g_n,p_n)")#text(", after rescaling, is converging geometrically to a spherical space form, then for any ")#mi("\\varepsilon > 0")#text(" such manifolds will be ")#mi("\\varepsilon")#text("-round for sufficiently large n.")

#text("The next type of canonical neighbourhood is associated to the small compact manifolds from Proposition 9 of the ")#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")[#text("previous lecture")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (C-component) Let ")#mi("C > 0")#text(". A C-component is a connected 3-manifold ")#mi("(M,g)")#text(" homeomorphic to ")#mi("S^3")#text(" or ")#mi("\\Bbb{RP}^3")#text(", such that after rescaling the metric by a constant, the sectional curvatures, diameter, and volume are bounded between 1/C and C, and first and second derivatives of the curvature are also bounded by C.")
]

#text("[We have deviated slightly here from the definition in ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" by adding control of first and second derivatives for minor technical reasons.]")

#text("Thus, for instance, every compact ")#mi("\\kappa")#text("-solution which is small but not round in the sense of Proposition 9 will be a C-component for some C. Also observe that if a sequence of manifolds converge geometrically to a C-component, then these manifolds will be (say) 2C-components once one is sufficiently far along the sequence.")

#text("The remaining canonical neighbourhoods are incomplete, corresponding to portions of non-compact (or compact but large) ")#mi("\\kappa")#text("-solutions. One of them is the ")#mi("\\varepsilon")#text("-neck defined in Definition 1 of ")#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")[#text("Lecture 17")]#text(". The other is that of a cap.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" (")#mi("(C,\\varepsilon)")#text("-cap) Let ")#mi("C, \\varepsilon > 0")#text(". A ")#mi("(C,\\varepsilon)")#text("-cap ")#mi("(N \\cup Y, g)")#text(" is an incomplete 3-manifold that is the union of an ")#mi("\\varepsilon")#text("-neck N with an incomplete core ")#mi("Y")#text(" along one of the boundaries ")#mi("S^2")#text(" of the neck N. The core is homeomorphic to ")#mi("{\\Bbb R}^3")#text(" or a punctured ")#mi("{\\Bbb RP}^3")#text(", and has boundary ")#mi("S^2")#text(" equal to the above boundary of N. Furthermore, after rescaling g by a constant, the sectional curvatures, diameter, volume in the core are bounded between 1/C and C, and the zeroth, first and second derivatives of curvature in the cap are bounded above by C.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4.")]#text(" (Canonical neighbourhood) Let ")#mi("C, \\varepsilon > 0")#text(". We say that a point x in a 3-manifold (M,g) (possibly disconnected) has a ")#emph[#mi("(C,\\varepsilon)")#text("-canonical neighbourhood")]#text(" if one of the following is true:")

#enum(start: 1, 
[#text("x lies in an ")#mi("\\varepsilon")#text("-round component of M.")],
[#text("x lies in a C-component of M.")],
[#text("x is the centre of an ")#mi("\\varepsilon")#text("-neck in M.")],
[#text("x lies in the core of a ")#mi("(C,\\varepsilon)")#text("-cap in M.")]
)
]

#text("We remark that if a sequence of pointed manifolds ")#mi("(M_n,g_n,x_n)")#text(" converges to a limit ")#mi("(M_\\infty,g_\\infty,x_\\infty)")#text(", and ")#mi("x_\\infty")#text(" has a ")#mi("(C,\\varepsilon)")#text("-neighbourhood of ")#mi("M_\\infty")#text(", then for sufficiently large n, ")#mi("x_n")#text(" has a ")#mi("(2C,2\\varepsilon)")#text("-neighbourhood (say) of ")#mi("M_n")#text(". Also observe from construction that the property of having a canonical neighbourhood is scale-invariant.")

#strong[#text("Exercise 1.")]#text(" (First derivatives of curvature) Show that if ")#mi("\\varepsilon")#text(" is sufficiently small, and x has a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood, then R(x) is positive, ")#mi("\\nabla R(x) = O_C( R(x)^{3/2} )")#text(", and ")#mi("\\partial_t R(x) = O_C( R(x)^2 )")#text(". ")#mi("\\diamond")

#text("From the theory of the previous lecture we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("C>0")#text(" such that every point in a 3-dimensional ")#mi("\\kappa")#text("-solution at any given time will have a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood, unless it is a round shrinking ")#mi("{\\Bbb R} \\times \\Bbb{RP}^2")#text(".")
]

#text("Note that C and ")#mi("\\varepsilon")#text(" are independent of ")#mi("\\kappa")#text("; this is thanks to the universality property (Proposition 5 from ")#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")[#text("Lecture 17")]#text(").")

#strong[#text("Remark 1.")]#text(" For technical reasons, one actually needs a slightly stronger version of this proposition, in which any canonical neighbourhood which is an ")#mi("\\varepsilon")#text("-neck is extended backwards to some extent in time in a manner that preserves the neck structure (leading to the notion of a ")#emph[#text("strong ")#mi("\\varepsilon")#text("-neck")]#text(" and ")#emph[#text("strong canonical neighbourhood")]#text("); see Chapter 9.8 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for details. Technically, the results below need to be stated for strong canonical neighbourhoods ")#mi("\\diamond")

#text("The objective of this lecture is to establish the analogous claim for high-curvature regions of arbitrary Ricci flows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Structure of high-curvature regions) For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("C > 0")#text(" such that the following holds. Let ")#mi("t \\mapsto (M,g)")#text(" be a three-dimensional compact Ricci flow on some time interval [0,T) with no embedded ")#mi("{\\Bbb RP}^2")#text(" with trivial normal bundle. Then there exists ")#mi("K > 0")#text(" such for every time ")#mi("t \\in [0,T)")#text(", every ")#mi("x \\in (M,g(t))")#text(" with ")#mi("R(x) \\geq K")#text(" has a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood.")
]

#text("This theorem will then allow us to perform surgery on Ricci flows, as we will discuss in the final lecture.")

#text("Morally speaking, Theorem 1 follows from Proposition 1 by rescaling and compactness arguments, but there is a rather delicate issue involved, namely to gain enough control on curvature at points in spacetime both near (and far) from the chosen point (t,x) that the Hamilton compactness theorem can be applied.")

#heading(level: 1)[#text("— Overview of proof —")]

#text("We begin with some reductions. We can of course take M to be connected. Fix ")#mi("\\varepsilon")#text(", and take C sufficiently large depending on ")#mi("\\varepsilon")#text(" (but not depending on any other parameters). We first observe that it suffices to prove the theorem for closed intervals [0,T] rather than half-open ones, as long as the bounds on K depend only on an upper bound ")#mi("T_0")#text(" on T and the initial metric g(0) and not on T itself (in particular, one cannot just use the trivial fact that R will be bounded on any compact subset of spacetime such as ")#mi("{}[0,T] \\times M")#text(".) Once one does this, one sees that Theorem 1 is now true for some enormous K that depends on T; the task is to get a uniform K that depends only on the initial metric g(0) and on an upper bound ")#mi("T_0")#text(" for T.")

#text("Perelman’s argument proceeds by a downward induction on K; assume that K is large (depending on g(0) and ")#mi("T_0")#text("), and that Theorem 1 has already been established for 4K (say); and then establish the claim for K. By the previous discussion, this conditional result will in fact imply the full theorem.")

#text("By rescaling we may assume that g(0) has normalised initial conditions (curvature bounded in magnitude by 1, volume of unit balls bounded below by some positive constant ")#mi("\\omega")#text("). We will now show that the conditional version of Theorem 1 holds for K sufficiently large depending only on ")#mi("\\omega")#text(" and ")#mi("T_0")#text(".")

#text("Suppose this were not the case. Then there would be a ")#mi("\\omega")#text(" and a ")#mi("T_0")#text(", and a sequence ")#mi("t \\mapsto (M_n, g_n(t), x_n)")#text(" of pointed Ricci flows on ")#mi("{}[0,T_n]")#text(" (not containing any embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle) for some ")#mi("0 \\leq T_n \\leq T_0")#text(" with normalised initial conditions with constant ")#mi("\\omega")#text(", times ")#mi("t_n \\in [0,T_n]")#text(", and scalars ")#mi("K_n \\to \\infty")#text(" such that every point in ")#mi("{}[0,T_n] \\times M_n")#text(" of scalar curvature at least 4K_n has a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood, but that ")#mi("R_n(t_n,x_n) \\geq K_n")#text(" but does not have a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood (in particular, ")#mi("R_n(t_n,x_n) < 4 K_n")#text("). We want to extract a contradiction from this.")

#text("From the local theory (Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text(") we know that the curvature is bounded for short times (t less than a universal constant depending only on ")#mi("\\omega")#text("), so ")#mi("t_n")#text(" must be bounded uniformly from below.")

#text("As usual, we define the rescaled pointed flows ")#mi("t \\mapsto (\\tilde M_n, \\tilde g_n(t), \\tilde x_n)")#text(" by ")#mi("\\tilde M_n := M_n")#text(", ")#mi("\\tilde x_n := x_n")#text(", and ")#mi("\\tilde g_n(t) := K_n^2 g_n( t_n + K_n^{-2} t )")#text(". Thus these flows are increasingly ancient and have scalar curvature between 1 and 4 at the origin ")#mi("(0,\\tilde x_n)")#text(". Also, any point in these flows of curvature at least 4 is contained in a canonical neighbourhood.")

#text("By Perelman’s non-collapsing theorem (")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Theorem 2")]#text(" from Lecture 7), we know that the flows ")#mi("t \\mapsto (M_n, g_n(t))")#text(" flow is ")#mi("\\kappa")#text("-noncollapsed at all scales less than 1 (say) for some ")#mi("\\kappa")#text(" depending only on ")#mi("\\omega")#text("; by rescaling, the rescaled flows ")#mi("t \\mapsto (\\tilde M_n, \\tilde g_n(t))")#text(" are then ")#mi("\\kappa")#text("-noncollapsed at all scales less than 1/o(1).")

#text("Meanwhile, from the Hamilton-Ivey pinching theorem (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(") we have ")#mi("R_n \\geq -O(1)")#text(" and ")#mi("\\text{Riem}_n \\geq -o( R_n )")#text(" whenever ")#mi("R_n \\to \\infty")#text(". Rescaling this, we obtain ")#mi("\\tilde R_n \\geq -o(1)")#text(" and ")#tao-math("\\widetilde{\\text{Riem}}_n \\geq -o( 1 + \\left|\\tilde R_n\\right| )", block: false)#text(".")

#text("Suppose we were able to prove the following statement.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("(Asymptotically globally bounded normalised curvature) For any ")#mi("A,\\tau > 0")#text(" we have a bound ")#mi("\\tilde R_n( t, x ) = O_{C,\\varepsilon}(1)")#text(" for all ")#mi("x \\in B_{\\tilde g_n(0)}(\\tilde x_n, A)")#text(" and ")#mi("t \\in [-\\tau,0]")#text(", if n is sufficiently large depending on ")#mi("A,\\tau")#text(".")
]

#text("From this and the ")#mi("\\kappa")#text("-noncollapsing, we see that the Hamilton compactness theorem (Theorem 2 from Lecture 15) applies, and after passing to a subsequence we see that the pointed flows ")#mi("t \\mapsto (\\tilde M_n, \\tilde g_n(t), \\tilde x_n)")#text(" converges geometrically to a Ricci flow ")#mi("t \\mapsto (M_\\infty, g_\\infty, x_\\infty)")#text(" which has bounded scalar curvature on ")#mi("{}[-\\tau,0] \\times M_\\infty")#text(" for each ")#mi("\\tau > 0")#text(", and is automatically connected, complete, and ancient, and without an embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. From pinching we also see that we have non-negative sectional curvature; from the ")#mi("\\kappa")#text("-noncollapsing of the flows ")#mi("t \\mapsto (\\tilde M_n, \\tilde g_n(t), \\tilde x_n)")#text(" we have ")#mi("\\kappa")#text("-noncollapsing of the limiting flow ")#mi("t \\mapsto (M_\\infty, g_\\infty, x_\\infty)")#text(". From Hamilton’s Harnack inequality (cf. ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") we can show ")#mi("\\partial_t R \\geq 0")#text(", and so we in fact have globally bounded curvature. Finally, since ")#mi("\\tilde R_n(0, \\tilde x_n)")#text(" is bounded between 1 and 4, so is ")#mi("R_\\infty(0,x_\\infty)")#text("; thus the flow is not flat. Putting all this together, we conclude that ")#mi("t \\mapsto (M_\\infty, g_\\infty, x_\\infty)")#text(" is a ")#mi("\\kappa")#text("-solution (see Definition 1 from ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("Lecture 12")]#text("). From Proposition 1, ")#mi("(0,x_\\infty)")#text(" has a ")#mi("(C/2,\\varepsilon/2)")#text("-canonical neighbourhood in ")#mi("M_\\infty")#text(" (if C is chosen large enough depending on ")#mi("\\varepsilon")#text("); thus ")#mi("(0,\\tilde x_n)")#text(" will have a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood in ")#mi("\\tilde M_n")#text(" for large enough n, and so by rescaling ")#mi("(0,x_n)")#text(" has a ")#mi("(C,\\varepsilon)")#text("-canonical neighbourhood in ")#mi("M_n")#text(", contradicting the hypothesis, and we are done.")

#text("So it remains to prove Proposition 2. If we had the luxury of picking ")#mi("(t_n,x_n)")#text(" to be a point which had maximal curvature amongst all other points in ")#mi("{}[0,t_n] \\times M")#text(", then this proposition would be automatic. However, we do not have this luxury (roughly speaking, this would only let us get canonical neighbourhoods for the “highest curvature region” of the Ricci flow, leaving aside the “second highest curvature region”, “third highest curvature region”, etc., unprepared for surgery). So one has to work significantly harder to achieve this aim.")

#heading(level: 1)[#text("— Bounded curvature at bounded distance —")]

#text("A key step in the execution of Proposition 2 is the following partial result, in which the bound on curvature is allowed to depend on A, and for which one cannot go backwards in time.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text(" (Bounded curvature at bounded distance) For any A > 0 we have a bound ")#mi("\\tilde R_n( 0, x ) = O_{C,\\varepsilon,A}(1)")#text(" for all ")#mi("x \\in B_{\\tilde g_n(0)}(\\tilde x_n, A)")#text(", if n is large enough depending on A.")
]

#text("This partial result is already rather tricky; we sketch the proof as follows (full details can be found in Chapter 10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(", Section 51 of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(", or Section 7.1 of ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text("). If this result failed, then we have a sequence ")#mi("\\tilde y_n")#text(" with ")#mi("d_{\\tilde g_n(0)}(x_n,y_n)")#text(" bounded and ")#mi("\\tilde R_n(0,\\tilde y_n) \\to \\infty")#text(", thus one can move a bounded distance along a minimising geodesic from ")#mi("\\tilde x_n")#text(" (which has curvature between 1 and 4) to ")#mi("\\tilde y_n")#text(" and reach a point of arbitrarily high curvature. On the other hand, we know that every point of curvature at least 4 has a canonical neighbourhood. Thus there is a bounded length minimising geodesic in ")#mi("(\\tilde M_n, \\tilde g_n(0))")#text(" that goes entirely through canonical neighbourhoods, starts with scalar curvature 4, and ends up with arbitrarily high curvature, with curvature staying 4 or greater throughout this process. This cannot happen if the canonical neighbourhoods are ")#mi("\\varepsilon")#text("-round or C-components (since these neighhourhoods are already complete and curvatures are comparable to each other on the entire neighbourhood), so this geodesic can only go through ")#mi("\\varepsilon")#text("-necks and ")#mi("(C,\\varepsilon)")#text("-caps. One can also rule out the latter possibility (a long geodesic path that goes through the core of a ")#mi("(C,\\varepsilon)")#text("-cap can easily be shown to not be minimising); thus the geodesic is simply going through a tube of ")#mi("\\varepsilon")#text("-necks, with the width of these necks starting off being comparable to 1 and ending up being arbitrarily small. It turns out that by using a version of Hamilton’s compactness theorem for incomplete Ricci flows, one can take a limit, which at time zero is a tube (topologically ")#mi("{}[0,1] \\times S^2")#text(") of non-negative curvature in which the curvature has become infinite at one end. Also, thanks to time derivative control on the curvature (see Exercise 1), the tube can be extended a little bit backwards in time as an incomplete Ricci flow (though the amount to which one can do this shrinks to zero as one approaches the infinite curvature end of the tube).")

#text("One can show that as one approaches the infinite curvature end of the cylinder and rescales, the cylinder increasingly resembles a cone. (For instance, one can use the bound ")#mi("\\int_\\gamma \\text{Ric}(X,X) = O(1)")#text(" from Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(", where ")#mi("\\gamma")#text(" are geodesics emanating from the infinite curvature end, to establish this sort of thing.) By taking another limit one can then get an incomplete Ricci flow which at time zero is a cone. Because curvature is bounded away from zero, this cone is not flat. At this point, a version of Hamilton’s splitting theorem (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") for incomplete flows asserts that the manifold locally splits as the product of a line and a two-dimensional manifold. But non-flat cones cannot split like this, a contradiction. This establishes Proposition 3.")

#strong[#text("Remark 2. ")]#text("More generally, this argument can be used to show that if ")#mi("\\tilde R_n(t,x)")#text(" is bounded by some ")#mi("L \\geq 1")#text(", then ")#mi("\\tilde R_n(t,y)")#text(" is bounded by ")#mi("O_{A,C,\\varepsilon}(L)")#text(" for all ")#mi("y \\in B_{\\tilde g_n(t)}(x,A L^{-1/2})")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Bounded curvature at all distances —")]

#text("Now we extend Proposition 3 by making the bound global in A:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4. ")]#text(" (Bounded curvature at all distances) For any A > 0 we have a bound ")#mi("\\tilde R_n( 0, x ) = O_{C,\\varepsilon}(1)")#text(" for all ")#mi("x \\in B_{\\tilde g_n(0)}(\\tilde x_n, A)")#text(", if n is large enough depending on A.")
]

#text("We sketch a proof as follows. From Proposition 3 and compactness (taking advantage of non-collapsing, of course) we already know (passing to a subsequence if necessary) that ")#mi("(\\tilde M_n, \\tilde g_n(0), x_n)")#text(" converges to some limit")#linebreak()#text(" ")#mi("(\\tilde M_\\infty, \\tilde g_\\infty(0), x_\\infty)")#text(" which has non-negative curvature; it can also be extended a little bit backwards in time as an incomplete Ricci flow. Also, every point in this limit of curvature greater than 4 has a canonical neighbourhood. Our task is to basically to show that ")#mi("(\\tilde M_\\infty, \\tilde g_\\infty(0))")#text(" has bounded curvature. If this is not the case, then there are points of arbitrarily high curvature, which must be contained in either ")#mi("\\varepsilon")#text("-necks or ")#mi("(C,\\varepsilon)")#text("-caps. We conclude that there exist arbitrarily narrow ")#mi("\\varepsilon")#text("-necks. One can then show that the manifold had strictly positive curvature, since otherwise by Hamilton’s splitting theorem the manifold would split locally into a product of a two-dimensional manifold and a line, which can be shown to be incompatible with having arbitrarily narrow necks.")

#text("At this point one uses a general result that complete manifolds of strictly positive curvature cannot have arbitrarily narrow necks. We sketch the proof as follows. Clearly we may assume the manifold is compact, and hence by the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(" is diffeomorphic to ")#mi("{\\Bbb R}^3")#text(". This implies that every neck in fact separates the manifold into a compact part and a non-compact part. In fact, one can show that if p is a soul for the manifold, then there is a minimising geodesic ")#mi("\\gamma: [0,+\\infty) \\to M")#text(" from p to infinity that passes through all the necks. But if one then considers the Busemann function ")#mi("B(y) := \\lim_{s \\to \\infty} d(y,\\gamma(s)) - s")#text(", one can show that the gradient field ")#mi("\\nabla B")#text(" is a unit vector which is within ")#mi("O(\\varepsilon)")#text(" to parallel to the necks. This, combined with Stokes theorem, tells us that the area of the level sets of B inside a neck (which, up to errors of ")#mi("O(\\varepsilon)")#text(", are basically slices of that neck) does not fluctuate by more than ")#mi("\\varepsilon")#text(", even as one compares very distant necks together. But this contradicts the assumption that there are arbitrarily small necks. (For full details see Proposition 2.19 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(". )")

#heading(level: 1)[#text("— Bounded curvature at all times —")]

#text("Now we need to extend Proposition 4 backwards in time. The time derivative bound on curvature (Exercise 1) lets us extend backwards by some fixed amount of time, but at the cost of potentially increasing the curvature, and we cannot simply iterate this (much as one cannot iterate a local existence result for a PDE to obtain a global one without some sort of ")#emph[#text("a priori")]#text(" bound on whatever is controlling the time of existence). But what Exercise 1 does let us do, is reduce matters to establishing an ")#emph[#text("a priori")]#text(" bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5. ")]#text(" (A priori bound) Let ")#mi("\\tau > 0")#text(", and suppose ")#mi("\\tilde R_n")#text(" is uniformly bounded on ")#mi("{}[-\\tau,0] \\times \\tilde M_n")#text(" for all sufficiently large n. Then in fact we can bound ")#mi("\\tilde R_n")#text(" on these slabs by a universal bound ")#mi("O_{C,\\varepsilon,\\tau}(1)")#text(" (not depending on the previous universal bound).")
]

#text("Indeed, Exercise 1 then lets us extend the uniform bounds a little bit to the past of ")#mi("\\tau")#text(", and one can continue this procedure indefinitely to establish Proposition 2.")

#text("We sketch the proof as follows. We allow all implied constants to depend on ")#mi("C, \\varepsilon, \\tau")#text(" for brevity. The bounds are already enough to give a non-ancient limiting flow ")#mi("t \\mapsto (M_\\infty, g_\\infty(t), x_\\infty)")#text(" on ")#mi("{}[-\\tau,0]")#text(" which is complete, connected, and non-negative curvature which is bounded at all times (but with an unspecified bound), and bounded at time zero by ")#mi("O(1)")#text(". Also, every point with curvature greater than 4 is known to have a canonical neighbourhood. The challenge is now to propagate the quantitative curvature bounds backwards in time, to replace the qualitative bound.")

#text("In the case of an ancient flow of non-negative curvature, Hamilton’s Harnack inequality (equation (29) from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") gives ")#mi("\\partial_t R \\geq 0")#text(", which automatically does this propagation for us. We are however non-ancient here, and the Harnack inequality in this setting only gives a bound of the form ")#mi("\\partial_t R \\geq R / (t+\\tau)")#text(". This can be integrated to give ")#mi("R(t,x) = O( 1 / (t+\\tau) )")#text(", thus our bounds blow up as we approach ")#mi("\\tau")#text(". However, this is at least enough to get good control on distances; in particular, using Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(" we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("- O( \\frac{1}{\\sqrt{t+\\tau}} ) \\leq \\frac{d}{dt} d_{g(t)}(x,y) \\leq 0")]]

#text("for all ")#mi("x,y \\in M_\\infty")#text(". Fortunately, the left-hand side here is absolutely integrable, and so we obtain a useful global distance comparison estimate:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d_{g(0)}(x,y) - O(1) \\leq d_{g(t)}(x,y) \\leq d_{g(0)}(x,y).")]]

#text("To use this, pick a large curvature ")#mi("L \\ge 1")#text(", then a much larger radius r, then an extremely large curvature L’. Now suppose for contradiction that we have a point (t,x) in ")#mi("{}[\\tau,0] \\times M")#text(" of curvature larger than L’. This point is then contained in a canonical neighbourhood. This neighbourhood cannot be compact (i.e. an ")#mi("\\varepsilon")#text("-round or C-component), since that would mean that the")#linebreak()#text(" minimal scalar curvature ")#mi("R_{\\min}")#text(" was comparable to L’ at time t, which by monotonicity of ")#mi("R_{\\min}")#text(" (Proposition 2 of ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(") would mean that the scalar curvature is comparable to L’ at time 0, contradicting the boundedness of curvature there. This argument in fact shows that all large curvature regions are contained in either ")#mi("\\varepsilon")#text("-necks or ")#mi("(C,\\varepsilon)")#text("-caps.")

#text("Consider the ball ")#mi("B_{g(t)}(x,r)")#text(". From Remark 2 we see (if L’ is large enough) that the curvature is larger than L on this ball, and so this ball consists entirely of necks and caps of width at most ")#mi("O(L^{-1/2})")#text(". From this it is not hard to see that the volume of this ball at time t is ")#mi("O( L^{-1/2} r )")#text(". On the other hand, there must be at least one point y on the boundary of this ball, since otherwise ")#mi("R_{\\min}")#text(" would be at least L, which as noted before is not possible.")

#text("Applying (2) (and noting that Ricci flow reduces volume when there is non-negative curvature, see equation (33) of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(") we conclude that ")#mi("B_{g(t)}(x,r-O(1))")#text(" also has volume O(L^{-1/2} r). On the other hand, we know that there is a point y at distance r from x at time t, thus y at distance r-O(1) from x at time 0. Thus (by the triangle inequality, and dividing the geodesic from x to y at time zero into unit length segments) ")#mi("B_{g(0)}(x,r)")#text(" contains ")#mi("\\sim r")#text(" disjoint balls of radius 1/2 (say). By the non-collapsing and curvature bounds at time zero, this forces ")#mi("B_{g(0)}(x,r)")#text(" to have volume at least comparable to r, a contradiction. This proves Proposition 5 and thus Theorem 1.")

#strong[#text("Remark 3. ")]#text("Perelman (and the authors who follow him) uses a slight variant of this argument, using the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(" to fashion a small ")#mi("S^2")#text(" in a narrow neck that separates two widely distant points at time t, which then evolves to a small ")#mi("S^2")#text(" separating two widely distant points at time zero (here we use (2)). But this is not possible due to the bounded curvature at that time. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/#comment-30403")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("[…] through the neck near . We then rescale to have width 1 at , and then apply the machinery from Lecture 18 to obtain a limit ; the bounded curvature at bounded distance property (Proposition 3 from […]")
]
