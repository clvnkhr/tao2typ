// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/
// Converted to Typst by tao2typ: "2026-10-14T09:12:21.212951+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pappus’s theorem and elliptic curves", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pappus’s theorem and elliptic curves")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")[#text("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("An ")#link("http://en.wikipedia.org/wiki/Algebraic_curve#Plane_algebraic_curves")[#text("algebraic (affine) plane curve")]#text(" of degree ")#mi("{d}")#text(" over some field ")#mi("{k}")#text(" is a curve ")#mi("{\\gamma}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\gamma = \\{ (x,y) \\in k^2: P(x,y) = 0 \\}")]]

#text("where ")#mi("{P}")#text(" is some non-constant polynomial of degree ")#mi("{d}")#text(". Examples of low-degree plane curves include")

#list(
[#emph[#text("Degree ")#mi("{1}")#text(" (linear) curves")]#text(" ")#mi("{\\{ (x,y) \\in k^2: ax+by=c\\}}")#text(", which are simply the ")#link("http://en.wikipedia.org/wiki/Line_(geometry)")[#text("lines")]#text(";")],
[#emph[#text("Degree ")#mi("{2}")#text(" (quadric) curves")]#text(" ")#mi("{\\{ (x,y) \\in k^2: ax^2+bxy+cy^2+dx+ey+f=0\\}}")#text(", which (when ")#mi("{k={\\bf R}}")#text(") include the classical ")#link("http://en.wikipedia.org/wiki/Conic_section")[#text("conic sections")]#text(" (i.e. ellipses, hyperbolae, and parabolae), but also include the reducible example of the union of two lines; and")],
[#link("http://en.wikipedia.org/wiki/Cubic_curve")[#text("Degree ")#mi("{3}")#text(" (cubic) curves")]#text(" ")#mi("{\\{ (x,y) \\in k^2: ax^3+bx^2y+cxy^2+dy^3+ex^2+fxy+gy^2+hx+iy+j=0\\}}")#text(", which include the ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curves")]#text(" ")#mi("{\\{ (x,y) \\in k^2: y^2=x^3+ax+b\\}}")#text(" (with non-zero ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("{\\Delta := -16(4a^3+27b^2)}")#text(", so that the curve is smooth) as examples (ignoring some technicalities when ")#mi("{k}")#text(" has characteristic two or three), but also include the reducible examples of the union of a line and a conic section, or the union of three lines.")],
[#text("etc.")]
)

#text("Algebraic affine plane curves can also be extended to the projective plane ")#mi("{{\\Bbb P} k^2 = \\{ [x,y,z]: (x,y,z) \\in k^3 \\backslash 0 \\}}")#text(" by homogenising the polynomial. For instance, the affine quadric curve ")#mi("{\\{ (x,y) \\in k^2: ax^2+bxy+cy^2+dx+ey+f=0\\}}")#text(" would become ")#mi("{\\{ [x,y,z] \\in {\\Bbb P} k^2: ax^2+bxy+cy^2+dxz+eyz+fz^2=0\\}}")#text(".")

#text("One of the fundamental theorems about algebraic plane curves is ")#link("http://en.wikipedia.org/wiki/Bezout%27s_theorem")[#text("Bézout’s theorem")]#text(", which asserts that if a degree ")#mi("{d}")#text(" curve ")#mi("{\\gamma}")#text(" and a degree ")#mi("{d^{\\prime}}")#text(" curve ")#mi("{\\gamma^{\\prime}}")#text(" have no common component, then they intersect in at most ")#mi("{dd^{\\prime}}")#text(" points (and if the underlying field ")#mi("{k}")#text(" is algebraically closed, one works projectively, and one counts intersections with multiplicity, they intersect in ")#emph[#text("exactly")]#text(" ")#mi("{dd^{\\prime}}")#text(" points). Thus, for instance, two distinct lines intersect in at most one point; a line and a conic section intersect in at most two points; two distinct conic sections intersect in at most four points; a line and an elliptic curve intersect in at most three points; two distinct elliptic curves intersect in at most nine points; and so forth. Bézout’s theorem is discussed in ")#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/")[#text("this previous post")]#text(".")

#text("From linear algebra we also have the fundamental fact that one can build algebraic curves through various specified points. For instance, for any two points ")#mi("{A_1,A_2}")#text(" one can find a line ")#mi("{\\{ (x,y): ax+by=c\\}}")#text(" passing through the points ")#mi("{A_1,A_2}")#text(", because this imposes two linear constraints on three unknowns ")#mi("{a,b,c}")#text(" and is thus guaranteed to have at least one solution. Similarly, given any five points ")#mi("{A_1,\\ldots,A_5}")#text(", one can find a quadric curve passing through these five points (though note that if three of these points are collinear, then this curve cannot be a conic thanks to Bézout’s theorem, and is thus necessarily reducible to the union of two lines); given any nine points ")#mi("{A_1,\\ldots,A_9}")#text(", one can find a cubic curve going through these nine points; and so forth. This simple observation is one of the foundational building blocks of the ")#emph[#text("polynomial method")]#text(" in combinatorial incidence geometry, discussed in ")#link("https://terrytao.wordpress.com/tag/polynomial-method/")[#text("these blog posts")]#text(".")

#text("In the degree ")#mi("{1}")#text(" case, it is always true that two distinct points ")#mi("{A, B}")#text(" determine exactly one line ")#mi("{\\overleftrightarrow{AB}}")#text(". In higher degree, the situation is a bit more complicated. For instance, five collinear points determine more than one quadric curve, as one can simply take the union of the line containing those five points, together with an arbitrary additional line. Similarly, eight points on a conic section plus one additional point determine more than one cubic curve, as one can take that conic section plus an arbitrary line going through the additional point. However, if one places some “general position” hypotheses on these points, then one can recover uniqueness. For instance, given five points, no three of which are collinear, there can be at most one quadric curve that passes through these points (because these five points cannot lie on the union of two lines, and by Bézout’s theorem they cannot simultaneously lie on two distinct conic sections).")

#text("For cubic curves, the situation is more complicated still. Consider for instance two distinct cubic curves ")#mi("{\\gamma_0 = \\{ P_0(x,y)=0\\}}")#text(" and ")#mi("{\\gamma_\\infty = \\{P_\\infty(x,y)=0\\}}")#text(" that intersect in precisely nine points ")#mi("{A_1,\\ldots,A_9}")#text(" (note from Bézout’s theorem that this is an entirely typical situation). Then there is in fact an entire one-parameter family of cubic curves that pass through these points, namely the curves ")#mi("{\\gamma_t = \\{ P_0(x,y) + t P_\\infty(x,y) = 0\\}}")#text(" for any ")#mi("{t \\in k \\cup \\{\\infty\\}}")#text(" (with the convention that the constraint ")#mi("{P_0+tP_\\infty=0}")#text(" is interpreted as ")#mi("{P_\\infty=0}")#text(" when ")#mi("{t=\\infty}")#text(").")

#text("In fact, these are the only cubics that pass through these nine points, or even through eight of the nine points. More precisely, we have the following useful fact, known as the ")#link("http://en.wikipedia.org/wiki/Cayley%E2%80%93Bacharach_theorem")[#text("Cayley-Bacharach theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Cayley-Bacharach theorem)")]#text(" ")#metadata(none) <tao-c195d2d8756234367242>#text(" Let ")#mi("{\\gamma_0 = \\{ P_0(x,y)=0\\}}")#text(" and ")#mi("{\\gamma_\\infty = \\{P_\\infty(x,y)=0\\}}")#text(" be two cubic curves that intersect (over some algebraically closed field ")#mi("{k}")#text(") in precisely nine distinct points ")#mi("{A_1,\\ldots,A_9 \\in k^2}")#text(". Let ")#mi("{P}")#text(" be a cubic polynomial that vanishes on eight of these points (say ")#mi("{A_1,\\ldots,A_8}")#text("). Then ")#mi("{P}")#text(" is a linear combination of ")#mi("{P_0,P_\\infty}")#text(", and in particular vanishes on the ninth point ")#mi("{A_9}")#text(".")
]

#emph[#text("Proof:")]#text(" (This proof is based off of a ")#link("http://www.ams.org/mathscinet-getitem?mr=2024529")[#text("text of Husemöller")]#text(".) We assume for contradiction that there is a cubic polynomial ")#mi("{P}")#text(" that vanishes on ")#mi("{A_1,\\ldots,A_8}")#text(", but is not a linear combination of ")#mi("{P_0}")#text(" and ")#mi("{P_\\infty}")#text(".")

#text("We first make some observations on the points ")#mi("{A_1,\\ldots,A_9}")#text(". No four of these points can be collinear, because then by Bézout’s theorem, ")#mi("{P_0}")#text(" and ")#mi("{P_\\infty}")#text(" would both have to vanish on this line, contradicting the fact that ")#mi("{\\gamma_0, \\gamma_\\infty}")#text(" meet in at most nine points. For similar reasons, no seven of these points can lie on a quadric curve.")

#text("One consequence of this is that any five of the ")#mi("{A_1,\\ldots,A_9}")#text(" determine a unique quadric curve ")#mi("{\\sigma}")#text(". The existence of the curve follows from linear algebra as discussed previously. If five of the points lie on two different quadric curves ")#mi("{\\sigma,\\sigma^{\\prime}}")#text(", then by Bezout’s theorem, they must share a common line; but this line can contain at most three of the five points, and the other two points determine uniquely the other line that is the component of both ")#mi("{\\sigma}")#text(" and ")#mi("{\\sigma^{\\prime}}")#text(", and the claim follows.")

#text("Now suppose that three of the first eight points, say ")#mi("{A_1,A_2,A_3}")#text(", are collinear, lying on a line ")#mi("{\\ell}")#text(". The remaining five points ")#mi("{A_4,\\ldots,A_8}")#text(" do not lie on ")#mi("{\\ell}")#text(", and determine a unique quadric curve ")#mi("{\\sigma}")#text(" by the previous discussion. Let ")#mi("{B}")#text(" be another point on ")#mi("{\\ell}")#text(", and let ")#mi("{C}")#text(" be a point that does not lie on either ")#mi("{\\ell}")#text(" or ")#mi("{\\sigma}")#text(". By linear algebra, one can find a non-trivial linear combination ")#mi("{Q = aP + bP_0 + cP_\\infty}")#text(" of ")#mi("{P,P_0,P_\\infty}")#text(" that vanishes at both ")#mi("{B}")#text(" and ")#mi("{C}")#text(". Then ")#mi("{Q}")#text(" is a cubic polynomial that vanishes on the four collinear points ")#mi("{A_1,A_2,A_3,B}")#text(" and thus vanishes on ")#mi("{\\ell}")#text(", thus the cubic curve defined by ")#mi("{Q}")#text(" consists of ")#mi("{\\ell}")#text(" and a quadric curve. This curve passes through ")#mi("{A_4,\\ldots,A_8}")#text(" and thus equals ")#mi("{\\sigma}")#text(". But then ")#mi("{C}")#text(" does not lie on either ")#mi("{\\ell}")#text(" or ")#mi("{\\sigma}")#text(" despite being a vanishing point of ")#mi("{Q}")#text(", a contradiction. Thus, no three points from ")#mi("{A_1,\\ldots,A_8}")#text(" are collinear.")

#text("In a similar vein, suppose next that six of the first eight points, say ")#mi("{A_1,\\ldots,A_6}")#text(", lie on a quadric curve ")#mi("{\\sigma}")#text("; as no three points are collinear, this quadric curve cannot be the union of two lines, and is thus a conic section. The remaining two points ")#mi("{A_7, A_8}")#text(" determine a unique line ")#mi("{\\ell = \\overleftrightarrow{A_7A_8}}")#text(". Let ")#mi("{B}")#text(" be another point on ")#mi("{\\sigma}")#text(", and let ")#mi("{C}")#text(" be another point that does not lie on either ")#mi("{\\ell}")#text(" and ")#mi("{\\sigma}")#text(". As before, we can find a non-trivial cubic ")#mi("{Q = aP + bP_0+cP_\\infty}")#text(" that vanishes at both ")#mi("{B, C}")#text(". As ")#mi("{Q}")#text(" vanishes at seven points of a conic section ")#mi("{\\sigma}")#text(", it must vanish on all of ")#mi("{\\sigma}")#text(", and so the cubic curve defined by ")#mi("{Q}")#text(" is the union of ")#mi("{\\sigma}")#text(" and a line that passes through ")#mi("{A_7}")#text(" and ")#mi("{A_8}")#text(", which must necessarily be ")#mi("{\\ell}")#text(". But then this curve does not pass through ")#mi("{C}")#text(", a contradiction. Thus no six points in ")#mi("{A_1,\\ldots,A_8}")#text(" lie on a quadric curve.")

#text("Finally, let ")#mi("{\\ell}")#text(" be the line through the two points ")#mi("{A_1,A_2}")#text(", and ")#mi("{\\sigma}")#text(" the quadric curve through the five points ")#mi("{A_3,\\ldots,A_7}")#text("; as before, ")#mi("{\\sigma}")#text(" must be a conic section, and by the preceding paragraphs we see that ")#mi("{A_8}")#text(" does not lie on either ")#mi("{\\sigma}")#text(" or ")#mi("{\\ell}")#text(". We pick two more points ")#mi("{B, C}")#text(" lying on ")#mi("{\\ell}")#text(" but not on ")#mi("{\\sigma}")#text(". As before, we can find a non-trivial cubic ")#mi("{Q = aP + bP_0+cP_\\infty}")#text(" that vanishes on ")#mi("{B, C}")#text("; it vanishes on four points on ")#mi("{\\ell}")#text(" and thus ")#mi("{Q}")#text(" defines a cubic curve that consists of ")#mi("{\\ell}")#text(" and a quadric curve. The quadric curve passes through ")#mi("{A_3,\\ldots,A_7}")#text(" and is thus ")#mi("{\\sigma}")#text("; but then the curve does not pass through ")#mi("{A_8}")#text(", a contradiction. This contradiction finishes the proof of the proposition. ")#mi("\\Box")

#text("I recently learned of this proposition and its role in unifying many incidence geometry facts concerning lines, quadric curves, and cubic curves. For instance, we can recover the proof of the classical ")#link("http://en.wikipedia.org/wiki/Pappus's_hexagon_theorem")[#text("theorem of Pappus")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Pappus’ theorem)")]#text(" Let ")#mi("{\\ell, \\ell^{\\prime}}")#text(" be two distinct lines, let ")#mi("{A_1,A_2,A_3}")#text(" be distinct points on ")#mi("{\\ell}")#text(" that do not lie on ")#mi("{\\ell^{\\prime}}")#text(", and let ")#mi("{B_1,B_2,B_3}")#text(" be distinct points on ")#mi("{\\ell^{\\prime}}")#text(" that do not lie on ")#mi("{\\ell}")#text(". Suppose that for ")#mi("{ij=12,23,31}")#text(", the lines ")#mi("{\\overleftrightarrow{A_i B_j}}")#text(" and ")#mi("{\\overleftrightarrow{A_j B_i}}")#text(" meet at a point ")#mi("{C_{ij}}")#text(". Then the points ")#mi("{C_{12}, C_{23}, C_{31}}")#text(" are collinear.")
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{C_{12}, C_{23}}")#text(" are distinct, since the claim is trivial otherwise.")

#text("Let ")#mi("{\\gamma_0}")#text(" be the union of the three lines ")#mi("{\\overleftrightarrow{A_1 B_2}}")#text(", ")#mi("{\\overleftrightarrow{A_2 B_3}}")#text(", and ")#mi("{\\overleftrightarrow{A_3 B_1}}")#text(" (the purple lines in the first figure), let ")#mi("{\\gamma_1}")#text(" be the union of the three lines ")#mi("{\\overleftrightarrow{A_2 B_1}}")#text(", ")#mi("{\\overleftrightarrow{A_3 B_2}}")#text(", and ")#mi("{\\overleftrightarrow{A_1 B_3}}")#text(" (the dark blue lines), and let ")#mi("{\\gamma}")#text(" be the union of the three lines ")#mi("{\\ell}")#text(", ")#mi("{\\ell^{\\prime}}")#text(", and ")#mi("{\\overleftrightarrow{C_{12} C_{23}}}")#text(" (the other three lines). By construction, ")#mi("{\\gamma_0}")#text(" and ")#mi("{\\gamma_1}")#text(" are cubic curves with no common component that meet at the nine points ")#mi("{A_1,A_2,A_3,B_1,B_2,B_3,C_{12},C_{23},C_{31}}")#text(". Also, ")#mi("{\\gamma}")#text(" is a cubic curve that passes through the first eight of these points, and thus also passes through the ninth point ")#mi("{C_{31}}")#text(", by the Cayley-Bacharach theorem. The claim follows (note that ")#mi("{C_{31}}")#text(" cannot lie on ")#mi("{\\ell}")#text(" or ")#mi("{\\ell^{\\prime}}")#text("). ")#mi("\\Box")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/07/pappus.png")[#image("../assets/34ec2fc17375c497c9e04ca69045defcb6f23df3f2cf740d21bf0582afabfe61-d48fdca5f93e74868bf9461e10a1691e9b702fb3bb3e3d5f70d4825986d613bc.png", width: 90%)]

#text("The same argument gives the closely related ")#link("http://en.wikipedia.org/wiki/Pascal%27s_theorem")[#text("theorem of Pascal")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Pascal’s theorem)")]#text(" Let ")#mi("{A_1,A_2,A_3,B_1,B_2,B_3}")#text(" be distinct points on a conic section ")#mi("{\\sigma}")#text(". Suppose that for ")#mi("{ij=12,23,31}")#text(", the lines ")#mi("{\\overleftrightarrow{A_i B_j}}")#text(" and ")#mi("{\\overleftrightarrow{A_j B_i}}")#text(" meet at a point ")#mi("{C_{ij}}")#text(". Then the points ")#mi("{C_{12}, C_{23}, C_{31}}")#text(" are collinear.")
]

#emph[#text("Proof:")]#text(" Repeat the proof of Pappus’ theorem, with ")#mi("{\\sigma}")#text(" taking the place of ")#mi("{\\ell \\cup \\ell^{\\prime}}")#text(". (Note that as any line meets ")#mi("{\\sigma}")#text(" in at most two points, the ")#mi("{C_{ij}}")#text(" cannot lie on ")#mi("{\\sigma}")#text(".) ")#mi("\\Box")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/07/pascal.png")[#image("../assets/b7f141f945f3ae2ccb92f6b6319966b5dc7924d5cd4c2e67ad4bdfa328642816-8c0e33e6f67d10b4c364c9af1be0ca76c439633c8413337bbc7366a221660475.png", width: 90%)]

#text("One can view Pappus’s theorem as the degenerate case of Pascal’s theorem, when the conic section degenerates to the union of two lines.")

#text("Finally, Proposition ")#link(<tao-c195d2d8756234367242>)[#text("1")]#text(" gives the associativity of the elliptic curve group law:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Associativity of the elliptic curve law)")]#text(" Let ")#mi("{\\gamma := \\{ (x,y) \\in k^2: y^2 = x^3+ax+b \\} \\cup \\{O\\}}")#text(" be a (projective) elliptic curve, where ")#mi("{O := [0,1,0]}")#text(" is the point at infinity on the ")#mi("{y}")#text("-axis, and the discriminant ")#mi("{\\Delta := -16(4a^3+27b^2)}")#text(" is non-zero. Define an addition law ")#mi("{+}")#text(" on ")#mi("{\\gamma}")#text(" by defining ")#mi("{A+B}")#text(" to equal ")#mi("{-C}")#text(", where ")#mi("{C}")#text(" is the unique point on ")#mi("{\\gamma}")#text(" collinear with ")#mi("{A}")#text(" and ")#mi("{B}")#text(" (if ")#mi("{A,B}")#text(" are disjoint) or tangent to ")#mi("{A}")#text(" (if ")#mi("{A=B}")#text("), and ")#mi("{-C}")#text(" is the reflection of ")#mi("{C}")#text(" through the ")#mi("{x}")#text("-axis (thus ")#mi("{C, -C, O}")#text(" are collinear), with the convention ")#mi("{-O=O}")#text(". Then ")#mi("{+}")#text(" gives ")#mi("{\\gamma}")#text(" the structure of an abelian group with identity ")#mi("{O}")#text(" and inverse ")#mi("{-}")#text(".")
]

#emph[#text("Proof:")]#text(" It is clear that ")#mi("{O}")#text(" is the identity for ")#mi("{+}")#text(", ")#mi("{-}")#text(" is an inverse, and ")#mi("{+}")#text(" is abelian. The only non-trivial assertion is associativity: ")#mi("{(A+B)+C = A+(B+C)}")#text(". By a perturbation (or Zariski closure) argument, we may assume that we are in the generic case when ")#mi("{O,A,B,C,A+B,B+C,-(A+B), -(B+C)}")#text(" are all distinct from each other and from ")#mi("{-((A+B)+C), -(A+(B+C))}")#text(". (Here we are implicitly using the smoothness of the elliptic curve, which is guaranteed by the hypothesis that the discriminant is non-zero.)")

#text("Let ")#mi("{\\gamma^{\\prime}}")#text(" be the union of the three lines ")#mi("{\\overleftrightarrow{AB}}")#text(", ")#mi("{\\overleftrightarrow{C(A+B)}}")#text(", and ")#mi("{\\overleftarrow{O(B+C)}}")#text(" (the purple lines), and let ")#mi("{\\gamma^{\\prime\\prime}}")#text(" be the union of the three lines ")#mi("{\\overleftrightarrow{O(A+B)}}")#text(", ")#mi("{\\overleftrightarrow{BC}}")#text(", and ")#mi("{\\overleftrightarrow{A(B+C)}}")#text(" (the green lines). Observe that ")#mi("{\\gamma^{\\prime}}")#text(" and ")#mi("{\\gamma}")#text(" are cubic curves with no common component that meet at the nine distinct points ")#mi("{O, A, B, C, A+B, -(A+B), B+C, -(B+C), -((A+B)+C)}")#text(". The cubic curve ")#mi("{\\gamma^{\\prime\\prime}}")#text(" goes through the first eight of these points, and thus (by Proposition ")#link(<tao-c195d2d8756234367242>)[#text("1")]#text(") also goes through the ninth point ")#mi("{-((A+B)+C)}")#text(". This implies that the line through ")#mi("{A}")#text(" and ")#mi("{B+C}")#text(" meets ")#mi("{\\gamma}")#text(" in both ")#mi("{-(A+(B+C))}")#text(" and ")#mi("{-((A+B)+C)}")#text(", and so these two points must be equal, and so ")#mi("{(A+B)+C=A+(B+C)}")#text(" as required. ")#mi("\\Box")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/07/elliptic.png")[#image("../assets/0ae7d082de61fae311fb2dce236252a9152cd0f9a6683d58e41f2e264265e45c-bfd6da7372cf954ed4928690e96de9c182bc75da2d7265bf44a0dea71fa0ed85.png", width: 90%)]

#text("One can view Pappus’s theorem and Pascal’s theorem as a degeneration of the associativity of the elliptic curve law, when the elliptic curve degenerates to three lines (in the case of Pappus) or the union of one line and one conic section (in the case of Pascal’s theorem).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-57457")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2011")])]

#text("“For instance, any two points {A_1,A_2}”")#linebreak()#text(" ->")#linebreak()#text(" “For instance, for any two points {A_1,A_2}”")

#text("I believe Roger Penrose was interested in this topic some time in the 1970’s,")#linebreak()#text(" though I don’t know of any references. Has it ever actually been written up,")#linebreak()#text(" or is it one of these pieces of folklore that remains unknown to the majority,")#linebreak()#text(" but considered unworthy of publication by the minority who eventually")#linebreak()#text(" (re)discover it?")

#text("Fred Lunnon")

#emph[#text("[Corrected, thanks. I don’t know specifically of Penrose’s work in this area, but there is a massive literature on elliptic curves in general, and the connection to Pappus etc. is well known to the experts; for instance, the connection is stated in the text of Husemuller on elliptic curves mentioned above . -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8361501f810f10c23207f9d499f1269e2413b19dd805b969a4b9721921f33a9f-203bedfa413e279a5d8ee8cbbe59e447c01df8af339ef5bdf4b4d30de3bc2bff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Gerdes")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-57660")[#strong[#text("Peter Gerdes")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2011")])]

#text("I presume perturbation/Zariski closure really just means observing + is continuous in the induced topology from R^2 and that the set of sufficently generic points is dense in that topology.")

#text("Hmm, interesting seems like you could really use generic in a nice formal sense here using the usual Baire category argument to prove that given a formula \\phi in language of real closed fields and an open ball B there is some ball B’ contained in B forcing either \\phi or \\lnot\\phi. It follows immediately that mutually generic points (A,B) are dense and the notion lets you state the nice parts of some of those intersection theorems without the exceptions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-57701")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2011")])]

#text("One can find a statment similar to Pascal’s theorem on elliptic curves. Suppose that an elliptic curve contains 8 collinear triples on 12 points so that every point is incident to two triples. (On the picture for Pascal theorem there are 6 such triples on 9 points) The 12 points of the 8 collinear triples are the intersections of 4-4 lines. The remaining 4 intersection points (which are not on the elliptic curve) should be collinear by Bezout.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-58777")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("An elliptic curve also needs to be smooth, i.e. ")#mi("4a^3+27b^2\\neq 0")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3a1df0ccb7f6b2f541d522d5fd0ca365797f4431cc3f55f416cdb4a8dc8a455-34b638232f226a2f0961df697c855f41b547d1964e6a3c86b93afb76785b7cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Wood")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-67715")[#strong[#text("David Wood")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("See")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://topologicalmusings.wordpress.com/2009/07/22/solution-to-pow-13-highly-coincidental/")[#text("Solution to POW-13: Highly coincidental!")]
]

#linebreak()#text(" for a closely related blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-78507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2011")])]

#text("Recently, the Cayley-Bacharach theorem has been generalized in")#linebreak()#text(" “Sun H. On the Cayley-Bacharach property and the construction of vector bundles. Sci China Math, 2011, 54(9): 1891–1898, doi: 10.1007/s11425-011-4263-0”. The author showed that the Cayley-Bacharach theorem is still ture for determinental zero-dimensional subschemes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2a6106f2d7b8891ac3bd54cfa164833b8901311f66dc1e14ee5569262f947d9-f0a97d821122a8734050e9966f5ca95e2170a58893663cca2514f915200c6e1a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franz Lemmermeyer")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-110492")[#strong[#text("Franz Lemmermeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2011")])]

#text("1. Let $C$ be an irreducible affine conic and $N$ a fixed point")#linebreak()#text(" on $C$. Define the sum of two points $P$, $Q$ on $C$ as the")#linebreak()#text(" second point of intersection of the conic with line through")#linebreak()#text(" $N$ parallel to $PQ$, with obvious modifications if $P = Q$.")#linebreak()#text(" The associativity of this group law is Pascal’s Theorem.")#linebreak()#text(" Since the group law on the hyperbola $XY = 1$ with $N = (1,1)$")#linebreak()#text(" is the multiplicative group of the base field $F$, Pascal’s")#linebreak()#text(" Theorem for hyperbolas follows from the associativity of $F$.")

#text("2. The Cayley-Bacharach Theorem is discussed by D. Eisenbud,")#linebreak()#text(" M. Green, and J. Harris in")#linebreak()#text(" {\\em Cayley-Bacharach Theorems and Conjectures},")#linebreak()#text(" Bull. Amer. Math. Soc. {\\bf 33} (1996), 295–324")

#text("3. M. Kaba, {\\em A proof of Pascal’s Theorem on the hexagram},")#linebreak()#text(" gives a proof of Pascal’s Theorem over the complex numbers using")#linebreak()#text(" the Weierstrass $\\wp$-function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-147664")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2012")])]

#text("Terry, I discovered today that the Cayley-Bacharach theorem should perhaps be called Chasle’s Theorem. This nice article by Eisenbud, Green (no relation) and Harris has an extensive discussion.")#linebreak()#text(" ")#link("http://www.msri.org/~de/papers/pdfs/1996-001.pdf")[#text("http://www.msri.org/~de/papers/pdfs/1996-001.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On sets defining few ordinary lines « What’s new")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-163186")[#strong[#text("On sets defining few ordinary lines « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("[…] blogged about this theorem in this previous post; the result is intimately connected to other classical facts in plane geometry such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf57b2c49957d76aaee49b5d74a10ece16d993ae4c4a920350cc3402b6f51dc-af82d3cf93bc73713d5355a1c2b72767994524276ea014532902779b37f8e739.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Đào Thanh Oai")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-459098")[#strong[#text("Đào Thanh Oai")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("I propose a conjecture as follows:")#linebreak()#text(" **A Conjecture:** *In a plane, let two curves intersect at ")#mi("\\frac{d^2+3d}{2}+\\frac{l^2+3l}{2}+2")#text(" points. Let the ")#mi("\\frac{d^2+3d}{2}+1")#text(" points lie on a curve of degree $d$, then the ")#mi("\\frac{l^2+3l}{2}+1")#text(" extant points lie on a curve of degree ")#mi("l")#text(".*")

#text("Propose by Đào Thanh Oai, Việt Nam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-465203")[#strong[#text("Weekend miscellany")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2016")]

#text("[…] Linear dynamical systems over finite rings Pappus’s theorem and elliptic curves […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70b4e85b8dfc510250e77d0f596a47e9fd43f02b805de04e8f36d7790f71dc4a-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oai Thanh Đào")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-467176")[#strong[#text("Oai Thanh Đào")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2016")])]

#text("I am looking for a solution of the following problem:")

#text("Let ")#mi("A_1, ..., A_6")#text(" and ")#mi("B_1, ..., B_6")#text(" be 12 points lying on a conic, and suppose that for ")#mi("i=1, ..., 5")#text(" through ")#mi("A_i, A_{i+1}, B_{i+1}, B_i")#text(" passes a circle ")#mi("(O_i)")#text(". Then through ")#mi("A_6, B_6, A_1, B_1")#text(" as well passes a circle ")#mi("(O_6)")#text(". Let ")#mi("P_1, P_4")#text(" be intersection points of ")#mi("(O_1)")#text(" and ")#mi("(O_4)")#text("; the same for ")#mi("P_2, P_5")#text(" and ")#mi("P_3, P_6")#text(". Show that:")

#text("1. Three lines ")#mi("O_1O_4")#text(", ")#mi("O_2O_5")#text(", and ")#mi("O_3O_6")#text(" have a common point ")#mi("O")#text(".")

#text("2. Six points ")#mi("P_1, ..., P_6")#text(" lie on a circle with center in ")#mi("O")#text(".")

#text("Drawing to the problem: ")#link("http://i.stack.imgur.com/3tL1u.png")[#text("http://i.stack.imgur.com/3tL1u.png")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf57b2c49957d76aaee49b5d74a10ece16d993ae4c4a920350cc3402b6f51dc-af82d3cf93bc73713d5355a1c2b72767994524276ea014532902779b37f8e739.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dao Thanh Oai")]], [#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-467582")[#strong[#text("Dao Thanh Oai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2016")])]

#link("http://mathoverflow.net/questions/234722/a-chain-of-six-circles-associated-with-a-conic")[#text("http://mathoverflow.net/questions/234722/a-chain-of-six-circles-associated-with-a-conic")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-471092")[#strong[#text("线性代数与射影几何的一些结论 – 说愁客")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")[#text("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-477316")[#strong[#text("warren B (@warrenb67913304)")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")]

#text("This is terrific. I have been working at resolving Hexagonals (ie graphene lattice) as they would appear at the Zeta Zero, prime number distribution for energy level of say platinum. Following from binary quadratic forms such as they appear in J.W.Kiselik “CONIC AND CUBIC PLANE CURVES” I have got to the radicals in the abc conjecture and Pappus associativity and 9 point theorem. Not immediately obvious is such as would occur for Evens given Mertens function for (-1) . Obviously given a Riemann Surface and plane cubics. I am traversing through prime numbers to a density matix conclusion. There does seem to be a constant, that could be associated to the 9 point theorem. given 4 rappelling points going upward from riemann’s sphere, to make a Elliptic and the Elliptic of the Conic. I am looking for some good 3D graphing software to display what could end end being a probability of points")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-685086")[#strong[#text("Associativity of the group law on an elliptic curve via the Cayley-Bacharach theorem – Building Babylon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2024")]

#text("[…] Terence Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/#comment-691815")[#strong[#text("The Cayley-Bacharach theorem and its applications – Cosmin Pohoata")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")]

#text("[…] For a beautiful exposition of these connections, see Tao’s post on Pappus’s theorem and elliptic curves. […]")
]
