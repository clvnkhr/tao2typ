// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/
// Converted to Typst by tao2typ: "2026-10-14T11:21:04.956042+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Changes to the Erdős problems web site", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Changes to the Erdős problems web site")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/")[#text("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.thomasbloom.org/")[#text("Thomas Bloom")]#text(", crossposted from the ")#link("https://www.erdosproblems.com/forum/thread/blog:9")[#text("Erdős problems forum")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("AI is changing everything, for better and/or worse, and the rate of change is dizzying; in recent months this has been particularly evident in mathematics, where AI has gone from being essentially useless to helping solve some of the hardest problems in mathematics in less than a year.")

#metadata(none) <tao-635e19b22c1416867826>

#text("The website ")#link("http://www.erdosproblems.com")[#text("http://www.erdosproblems.com")]#text(" has often been on the front line of these changes, and a barometer by which one could measure AI capabilities. This was not at all my intention when I created the site — I wanted to promote these problems to a human audience, and make a useful reference on what work has been done. But the easy availability of a large pool of questions that are simple to state, ranging from easy and obscure to deep and impenetrable, provided the ideal showcase for AI.")

#text("In some ways this has led to a huge amount of progress — we now know the answer to many questions we did not before. (Although a lot of this recent progress has come from increased human efforts and renewed interest in some problems, rather than just AI solutions.) There have also been negative effects, however: some mathematicians have dismissed Erdős-style mathematics as ‘easy/recreational’; many have stopped thinking about Erdős problems believing that they cannot compete with AI; and, most significantly, there has been a wave of AI-produced solutions provided with no explanation. While of course these are useful and tell us new things, they are also displacing and discouraging those who are actually interested in the mathematics.")

#text("(These issues have stopped being Erdős-specific as AI continues to make breakthroughs in an ever wider range of fields.)")

#text("A couple of weeks ago I asked for feedback on how people used the site, and what they thought should be changed. I received, both publicly and privately, a wide variety of opinions, and I’m grateful to everyone for their feedback.")

#text("What was particularly striking was the number of people I heard from who have benefited a lot from the site, learning new mathematics and finding new problems to think about, but have never commented on the site. I have been particularly conscious of this large silent, audience, and have tried to make sure their experiences were not drowned out by the more vocal minority.")

#text("In this post I will describe the changes I am making, based on the feedback I received and my own reflections on what the site is and could be.")

#text("In the essay ")#link("https://terrytao.wordpress.com/2026/09/19/why-do-we-need-human-mathematicians-anymore/")[#text("‘Why Do We Need Human Mathematicians Anymore?’")]#text(" Po-Shen Loh suggests the following as an axiom to use when deciding how things should develop: ")#emph[#text("We (humans) should help humanity flourish.")]

#text("When thinking about what I should do about the site, I use the following variant:")

#emph[#link("http://www.erdosproblems.com")[#text("http://www.erdosproblems.com")]#text(" should help the Erdős-community of humans (defined as those who are interested in Erdős-style mathematics, and want to think about and understand it) flourish.")]

#strong[#text("Why change?")]

#text("I launched ")#link("http://www.erdosproblems.com")[#text("http://www.erdosproblems.com")]#text(" on 28th May 2023, with just over 200 problems; it has grown steadily since then. The biggest change came in August 2025 when I added a comment feature. The site now hosts 1221 problems, over 9000 comments, and almost 2000 registered users. The site typically receives between 10,000 and 25,000 unique visitors each day.")

#text("The first few months after introducing the comment feature saw a huge increase in activity, just as I had hoped. A vibrant community arose; people shared ideas on how to solve problems, made observations, gave corrections, and suggested missing references and solutions. Many papers were written and new collaborations formed.")

#text("Unfortunately, this level of activity has not been sustained. Some decline was inevitable: over time, many of the natural observations will have been made, mistakes corrected, and discussions between collaborators would move offline. This natural evolution has been dramatically sped up by the coincidental rise of AI and its ability to solve some problems with minimal human intervention.")

#text("The main way that people publicly interact with the site now is to advertise their AI-generated proofs, often without any attempt to explain them, but as a way to record a (increasingly meaningless) priority claim.")

#text("This is very different to what I imagined, and I don’t want to manage a website which does this.")

#text("I believe that websites with this function should exist — places where people can record AI-generated proofs, even if purely formal with no human understanding, to save others wasting their tokens generating the same proof, and so that other people can access and use them if they desire. There are now several candidates for such repositories, and if managed responsibly, they can serve a useful role in the mathematical ecosystem. I personally don’t want to manage one.")

#text("Just as one does not open a restaurant in an abattoir, it is important that there be a separation between such repositories and a site which aims to promote the actual questions, place them in an appropriate context, and give a useful overview of the current state of human understanding.")

#text("The situation as it stands muddies the waters, promotes a gamified glory-seeking attitude, and gives the wrong impression that the value of these questions ends as soon as someone posts a formal proof of their truth value. This is not true (regardless of whether this proof was human or AI generated).")

#text("I believe Erdős intended these questions to serve as enduring beacons for human curiosity and wonder. They are landmarks by which we measure how far we’ve come, and how much there is still to understand.")

#text("I am very proud to have helped foster an open online community to discuss Erdős problems, and the kinds of discussions that used to happen are very valuable. But these discussions have become much less frequent. If and when I can find a way to encourage such discussions again, without the site becoming an AI repository of the kind mentioned above, I will happily do so.")

#strong[#text("What are the changes?")]

#text("I will make the following changes. (As ever, these are somewhat experimental, and may themselves change and be clarified further in the next few weeks.)")

#enum(start: 1, 
[#strong[#text("A hiatus on problem comments and proof claims")]#text(": I will freeze new problem comments and proof claims. General threads and blog posts will remain open to comments. Problem comments and proof claims may be reinstated in the future. Until then, suggestions for updates can be emailed to erdosproblemsonline@gmail.com, and I will update the site manually as I see appropriate.")],
[#strong[#text("No problem statuses")]#text(": The site will not display the statuses of any problems (e.g. open, solved, etc.). All problems will be displayed in the same neutral colour. The count of currently solved problems and the solved percentage will no longer be shown.")],
[#strong[#text("No credit/ownership language to describe future solutions")]#text(": The site will continue to record relevant results and theorems, but will no longer use credit-giving language for a result (human or AI).")],
[#strong[#text("An emphasis on high-quality expositions")]#text(": I will focus more on the proof expositions feature. People are encouraged to write in with their own expositions of proofs (whether these proofs are old or new, human or AI), and I will post those I judge to be high-quality. I am exploring other ways to encourage human exposition (e.g. an online seminar). Please contact me if you have any ideas.")]
)

#text("I’ve tried to anticipate some of the questions and critiques of these changes below. (I may update this with other questions and answers in future depending on feedback.)")

#emph[#text("What about those outside of traditional academia, who are using AI tools to make advances in mathematics, but can’t post to arXiv/lack the knowledge or context to write up proper papers about their findings?")]

#text("I will post links to correct formalisations and high-quality writeups, whatever the source, whether from a traditional academic or not. Papers should acknowledge their sources and honestly disclose how AI was use; where there is evidence of plagiarism or misrepresentation about AI use, I may decline to feature the submission, even if the proof is correct.")

#text("This is removing one, unofficial, avenue of publication; there are, these days, many others (even if you are also unable to post to arXiv). AI-assisted search tools mean that people will find your work if they are interested in the area as long as you post it to one of these sites.")

#text("I encourage everyone interested in Erdős problems to think about them, and to work on them if interested. If you have a proof (AI-created or otherwise) then you should take time to carefully write up the proof yourself (rather than asking an AI to generate a PDF for you). If you are unable to understand the proof you could reach out to someone else to help write this up.")

#emph[#text("But emailing you my solution is slower, and it might be some time before you update the site.")]

#text("This is true; but there is no great rush here. As much as I like these problems, and think it is important that there are some people who do think about the distribution of prime numbers and the structure of graphs, these are not problems for which a formal proof will have an immediate impact on general society.")

#text("I will try to link to correct Lean formalisations (if verified on ")#link("https://palomar-registry.org/")[#text("Palomar")]#text(") quickly; proofs which are poorly explained, and not accompanied by a formalisation, I am unlikely to update the site with. (See below for more details.)")

#emph[#text("What’s the point? There are loads of other places I can post my proof.")]

#text("Indeed; this is partially why I feel comfortable halting such proof claims on the site, since modern search tools (including AI) make it easy to find proofs posted online about problems you are curious about, even if posted in obscure places.")

#text("I would like to use the small amount of influence I have to avoid promoting low quality proofs, and not to give an added veneer of legitimacy where it is not deserved.")

#emph[#text("I could just make my own site for people to share their proofs and discuss solving problems with AI. Heck, I can even use AI to scrape all the text off your site and make an exact clone with much more liberal policies.")]

#text("Yes, you could. This a period of great experimentation in different formats and ways to encourage mathematics; if you think you have a good idea for a site or resource, you should make it. (Although it is often better to help out an existing effort where possible, since these resources are only useful if people use them, and it is better to concentrate on creating a few high-quality sites than hundreds of very similar clones.)")

#text("I think it is, however, rude to use without permission the text from my site, which is the result of a huge amount of work from me and many others who have contributed to the site.")

#emph[#text("How long will the hiatus last for?")]

#text("I don’t know. I will monitor how things develop in the coming weeks and months, and will reintroduce comments and proof claims (perhaps in a different form) when I believe they will do more good than harm.")

#emph[#text("Why not just moderate the comments to only allow genuine discussion through?")]

#text("This has been tried; in practice the vast majority of the comments the site receives now are people announcing AI-generated proofs. It is not sustainable to have a moderation policy which would reject almost all the comments that are submitted.")

#text("I am open to alternative suggestions about how to create a space for human discussion and collaboration, either on the site or elsewhere.")

#emph[#text("What about existing comments and proof claims?")]

#text("They will remain as an archive of the site up to this point.")

#emph[#text("Will you update the remarks to reflect existing proof claims?")]

#text("Yes, I will be working through the backlog of existing proof claims and updating the remarks, linking to formalisations and so on, as appropriate. You do not need to email me about a proof claim already on the site.")

#emph[#text("How will you decide when to update the remarks? What can I do with my proof to help?")]

#text("I will update the remarks when I judge there is an interesting new result that people who are working on that problem should be aware of, that can be presented in a useful way. Some things to be aware of:")

#enum(start: 1, 
[#text("If you have a Lean formalisation register it on Palomar — this lets others see that the formalisation compiles correctly, and makes it easy to check the formal statement correctly matches the problem statement. I will then link to the Palomar registry.")],
[#text("A proof accompanied by a well-written exposition that demonstrates clear understanding and which makes it easy for others to understand the proof will be prioritised.")],
[#text("If I judge there to be some kind of academic fraud (e.g. using the ideas of others without attribution, or passing AI-generated work off as your own) then I will not post it. This may mean that there are correct proofs not acknowledged, but the alternative is to publicise and reward bad behaviour. (As mentioned above, these proofs will surely still be found by anyone who searches for them elsewhere, but at least I would not be implicitly endorsing them.)")]
)

#emph[#text("What’s the point in removing the problem status? Isn’t it just cosmetic, and doesn’t it just make the site harder to navigate?")]

#text("Yes, this does undeniably remove some information. I think, however, that what is lost is not significant for anyone seriously interested in that problem, who can see for themselves within seconds of reading what the current situation is.")

#text("It makes it harder to browse the site searching for an unsolved problem to work on; instead I recommend that people browse the site by topic, finding questions that interest them, and investigating those, whether the original question is open or solved, since there is always more to be done.")

#text("The main point is to disincentivise people who are simply glory-chasing and copying problems into their AI to get an OPEN->SOLVED dopamine hit. It also prevents people drawing wrong conclusions from the ‘rate of solved problems’.")

#text("Furthermore, there is a lot of subjectivity anyway in many problems as to what counts as solved. Many people only browse the open problems, and they’re missing out on a lot of great mathematics that way.")

#text("I think it is against the spirit of Erdős to regard any problem as ‘closed’ — whenever one form of a question is answered, many others are created, and all problems deserve continued attention.")

#emph[#text("Doesn’t the ‘no credit’ rule also devalue the work of humans?")]

#text("Unfortunately, yes. I anticipate this will only be temporary, while the norms and customs of this new age of mathematics are decided. The commentary on the site is in no way ‘official’, and just represents my own summary of the situation, and collects links which may be useful to others exploring a problem.")

#text("Information about authorship will still be available in the sources the site links to. I trust that people will be sensible enough to judge for themselves who deserves the appropriate credit, and reward them appropriately.")

#text("I will also be freer in my language when it comes to well-written papers, whether they are the first place a proof appears or explain a proof that originated elsewhere; but I will no longer use language that suggests anyone ‘owns’ a particular result or proof. (For example, instead of saying ‘Bloom proved that ")#mi("{x>y}")#text("‘, I will write ‘It is known that ")#mi("{x>y}")#text(" — an explanation of the proof is provided by Bloom [link]’.)")

#strong[#text("Erdős and AI")]

#text("I am often asked ‘what would Erdős have thought of AI?’ The short answer is ‘I don’t know’. I never met Erdős, and have no special insight into him; I know him only through biographies and his papers, and anecdotes and reminiscences from those who did know him.")

#text("I would like to honour his legacy, and create something that he would have liked. To that end, I want to stress one thing: Erdős was, as well as a mathematician, an incredibly social person. Many stories about Erdős emphasises his humour, his warmth, and his enthusiasm for talking to other people (mathematicians or not). He spent his life travelling from mathematician to mathematician, arriving on their doorstep and declaring ‘my brain is open’.")

#text("He was not the type to lock himself away for years working in isolation on a single problem. For Erdős, mathematics was a very human activity, best done out loud. Questions would arise, be solved or discarded and replaced by new questions. Some results obtained, new ideas found, and then onto the next problem.")

#text("Some view the future of mathematics as a dystopian arcade of button-pressing, staring at a screen waiting for AI to do the thinking for us, with the main human involvement limited to asking the initial question and offering sporadic words of encouragement. Each new proof is then thrown into a repository, to only ever be read by other AIs, and the human presses the next button.")

#text("I believe Erdős would have found this future grim indeed, and the antithesis of mathematics as he practised it. Use AI as you like — but do not abandon mathematics as a human activity.")

#text("Don’t solve a problem for the sake of it; life is too short to spend it doing things that don’t matter to you.")

#text("Find a question that is meaningful to you, find other humans who are interested in it, and talk about it. Be confused, be stuck, be inspired. Find a messy proof, then find a better one. Get tired, get hungry, get into a flow state. Argue, laugh, give up, drink some coffee, and attack it again.")

#text("Be human. Let your brain be open.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("I agree, mathematics is a human endeavor, and research without human understanding it would be pointless!")

#text("Question: What is the criterion for determining whether something is recreational (a mere mathematical curiosity) or something important?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("mathematics is a human endeavor, and research without human understanding it would be pointless!")
]

#text("That is not correct.")

#text("The first part has been, but it is no longer true.")

#text("The second part is also false. It is true that some parts (most parts?) of mathematics are done for human understanding, sometimes exclusively. However, if you had some result with immediate practical applications (even more if formally verified) it is not pointless. For example, **an algorithm**. It would produce immediate benefits and that would be a point that is separate from human understanding. This phenomenon is more common in sciences that deal with very complex subject matters. In medicine, how many procedures, treatments and drugs, are used, but not understood (anaesthesia? paracetamol?). The lack of examples in mathematics, might just be temporary. Nothing prevents them from exiting. Now that there are new entities that can produce mathematical results, the doors are open to be obtained. Results from Godel show that there are theorems with proofs of arbitrarily enormous lengths in comparison. The length could be such that human understanding is intractable. And not number of particles in the universe kind of intractable, just long enough that it would take 100 year, or even 20 years to understand, is sufficient for a period in which we would like to enjoy the practical applications now, even in the absence of human understanding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For example, **an algorithm**. It would produce immediate benefits and that would be a point that is separate from human understanding.")
]

#text("How would the benefits be realized without human understanding? I think we can skip human understanding when it comes to the proof itself but even realizing the benefits of an algorithm we do not fully understand– nonetheless requires understanding. We can think about fully automated research where AI understands and finds a “benefit” but whether that benefit would be the most optimal benefit still depends on the goals for such an exploration.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This phenomenon is more common in sciences that deal with very complex subject matters. In medicine, how many procedures, treatments and drugs, are used, but not understood (anaesthesia? paracetamol?)")
]

#text("They might not be perfectly understood but they are understood enough for the benefit to be applied. If the understanding was 0– we would not have those things. even experimental understanding (Basic A/B test, casual inference, is still understanding). There is a minimum level of understanding for something to be beneficial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-697201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("How would the benefits be realized without human understanding?")
]

#text("You run the algorithm. Do’h! Just like you take a paracetamol, or use anaesthesia. You enjoy not having pain from being opened in an operating room, even though we don’t understand why or how your brain stays unconscious with less drugs than is needed to make you unconscious the first time.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("skip human understanding when it comes to the proof itself")
]

#text("No, because while one can run an algorithm as a black box, without understanding it, one does want guarantees that it solves the problem that it claims to solve.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("They might not be perfectly understood but they are understood enough for the benefit to be applied.")
]

#text("Are you agreeing now? Just as much as only knowing that a proof is correct and little more. Actually, less than a proof. Lots of drugs are used supported merely by statistical tests (for almost all people we test the drug does what we want and the number and nature of side-effects are acceptable).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Change #2 seems like it would harm people who don’t use AI more than people who do use it. However, I welcome the changes overall.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e91a66f1741d372c131cfa108c23781a32b7d0d761f4295bc54fdef431b6091-141688212793369365622793c42bf31f14448c6197c01e8de4309b2975a1f383.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tolonnell")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696843")[#strong[#text("tolonnell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Thanks for your hard work on this website!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Excellent changes! The incentives will now be better aligned. Thank you for your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#emph[#text("Thomas – I’m a sometime mathematician who played go with Erdős, now a Wikipedian. A couple of points: (1) Of course if people use your website to add content not aligned with its purposes, you can stop them. WP has much experience of that. (2) I mentioned a while ago a possible Wikidata property for the ")]#link("https://www.erdosproblems.com/")[#text("https://www.erdosproblems.com/")]#emph[#text(" ID. The main immediate application would be tagging papers with Wikidata items with subjects.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-696898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("“Find a question that is meaningful to you, find other humans who are interested in it, and talk about it.”")

#text("“I will freeze new problem comments”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/06/changes-to-the-erdos-problems-web-site/#comment-697195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This reminds me of how, as a kid, I learned to solve the Rubik’s cube by simply memorizing the algorithms like most people do. But nowadays I think back and wish I didn’t know, because I spoiled myself out of figuring the solution myself. There’s a feeling of reward after struggling with a problem that feels very special.")

#text("It’s scary to think we’re we will be 10 years from now. I hope for a future where we can reap any research benefits AI can give us, while still being able to be in spaces that force us to think by ourselves. Perhaps an offline campus where cognitive friction is encouraged, without the pressure of having to make a living out of it, just for feeling mentally cultivated and healthy. But I’m afraid that future might not come and lineages of all sorts of knowledge passed down through history will be lost…")
]
