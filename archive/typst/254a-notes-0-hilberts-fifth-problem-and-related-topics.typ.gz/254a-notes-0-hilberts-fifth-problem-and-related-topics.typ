// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/
// Converted to Typst by tao2typ: "2026-10-14T16:36:37.267932+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 0: Hilbert’s fifth problem and related topics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 0: Hilbert’s fifth problem and related topics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This fall (starting Monday, September 26), I will be teaching a graduate topics course which I have entitled “")#link("http://www.math.ucla.edu/~tao/254a.1.11f/")[#text("Hilbert’s fifth problem and related topics")]#text(".” The course is going to focus on three related topics:")

#list(
[#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" on the topological description of Lie groups, as well as the closely related (local) classification of ")#link("http://en.wikipedia.org/wiki/Locally_compact_group")[#text("locally compact groups")]#text(" (the Gleason-Yamabe theorem).")],
[#text("Approximate groups in nonabelian groups, and their classification via the Gleason-Yamabe theorem (this is very recent work of Emmanuel Breuillard, Ben Green, Tom Sanders, and myself, building upon earlier work of Hrushovski);")],
[#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem on groups of polynomial growth")]#text(", as proven via the classification of approximate groups (as well as some consequences to fundamental groups of Riemannian manifolds).")]
)

#text("I have already blogged about these topics repeatedly in the past (particularly ")#link("https://terrytao.wordpress.com/tag/hilberts-fifth-problem/")[#text("with regard to Hilbert’s fifth problem")]#text("), and I intend to recycle some of that material in the lecture notes for this course.")

#text("The above three families of results exemplify two broad principles (part of what I like to call “")#link("http://arxiv.org/abs/math.NT/0512114")[#text("the dichotomy between structure and randomness")]#text("“):")

#list(
[#text("(Rigidity) If a group-like object exhibits a weak amount of regularity, then it (or a large portion thereof) often automatically exhibits a strong amount of regularity as well;")],
[#text("(Structure) This strong regularity manifests itself either as Lie type structure (in continuous settings) or ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" type structure (in discrete settings). (In some cases, “nilpotent” should be replaced by sister properties such as “")#link("http://en.wikipedia.org/wiki/Abelian_group")[#text("abelian")]#text("“, “")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable")]#text("“, or “")#link("http://en.wikipedia.org/wiki/Polycyclic_group")[#text("polycyclic")]#text("“.)")]
)

#text("Let me illustrate what I mean by these two principles with two simple examples, one in the continuous setting and one in the discrete setting. We begin with a continuous example. Given an ")#mi("{n \\times n}")#text(" complex matrix ")#mi("{A \\in M_n({\\bf C})}")#text(", define the ")#link("http://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]#text(" ")#mi("{\\exp(A)}")#text(" of ")#mi("{A}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\exp(A) := \\sum_{k=0}^\\infty \\frac{A^k}{k!} = 1 + A + \\frac{1}{2!} A^2 + \\frac{1}{3!} A^3 + \\ldots")]]

#text("which can easily be verified to be an absolutely convergent series.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that the map ")#mi("{A \\mapsto \\exp(A)}")#text(" is a real analytic (and even complex analytic) map from ")#mi("{M_n({\\bf C})}")#text(" to ")#mi("{M_n({\\bf C})}")#text(", and obeys the restricted homomorphism property ")#metadata(none) <tao-aa33996d60e89311b4d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\exp(sA) \\exp(tA) = \\exp((s+t)A)")]]

#text("for all ")#mi("{A \\in M_n({\\bf C})}")#text(" and ")#mi("{s,t \\in {\\bf C}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Rigidity and structure of matrix homomorphisms)")]#text(" ")#metadata(none) <tao-4bab36ce40d3a7f543a2>#text(" Let ")#mi("{n}")#text(" be a natural number. Let ")#mi("{GL_n({\\bf C})}")#text(" be the group of invertible ")#mi("{n \\times n}")#text(" complex matrices. Let ")#mi("{\\Phi: {\\bf R} \\rightarrow GL_n({\\bf C})}")#text(" be a map obeying two properties:")

#list(
[#text("(Group-like object) ")#mi("{\\Phi}")#text(" is a homomorphism, thus ")#mi("{\\Phi(s) \\Phi(t) = \\Phi(s+t)}")#text(" for all ")#mi("{s,t \\in {\\bf R}}")#text(".")],
[#text("(Weak regularity) The map ")#mi("{t \\mapsto \\Phi(t)}")#text(" is continuous.")]
)

#text("Then:")

#list(
[#text("(Strong regularity) The map ")#mi("{t \\mapsto \\Phi(t)}")#text(" is smooth (i.e. infinitely differentiable). In fact it is even real analytic.")],
[#text("(Lie-type structure) There exists a (unique) complex ")#mi("{n \\times n}")#text(" matrix ")#mi("{A}")#text(" such that ")#mi("{\\Phi(t) = \\exp(tA)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\Phi}")#text(" be as above. Let ")#mi("{\\epsilon > 0}")#text(" be a small number (depending only on ")#mi("{n}")#text("). By the homomorphism property, ")#mi("{\\Phi(0) = 1}")#text(" (where we use ")#mi("{1}")#text(" here to denote the identity element of ")#mi("{GL_n({\\bf C})}")#text("), and so by continuity we may find a small ")#mi("{t_0>0}")#text(" such that ")#mi("{\\Phi(t) = 1 + O(\\epsilon)}")#text(" for all ")#mi("{t \\in [-t_0,t_0]}")#text(" (we use some arbitrary norm here on the space of ")#mi("{n \\times n}")#text(" matrices, and allow implied constants in the ")#mi("{O()}")#text(" notation to depend on ")#mi("{n}")#text(").")

#text("The map ")#mi("{A \\mapsto \\exp(A)}")#text(" is real analytic and (by the ")#link("http://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(") is a diffeomorphism near ")#mi("{0}")#text(". Thus, by the inverse function theorem, we can (if ")#mi("{\\epsilon}")#text(" is small enough) find a matrix ")#mi("{B}")#text(" of size ")#mi("{B = O(\\epsilon)}")#text(" such that ")#mi("{\\Phi(t_0) = \\exp(B)}")#text(". By the homomorphism property and ")#link(<tao-aa33996d60e89311b4d1>)[#text("(1)")]#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\Phi(t_0/2)^2 = \\Phi(t_0) = \\exp(B) = \\exp(B/2)^2.")]]

#text("On the other hand, by another application of the inverse function theorem we see that the squaring map ")#mi("{A \\mapsto A^2}")#text(" is a diffeomorphism near ")#mi("{1}")#text(" in ")#mi("{GL_n({\\bf C})}")#text(", and thus (if ")#mi("{\\epsilon}")#text(" is small enough)")

#align(center)[#tao-fit-display[#mitex("\\Phi(t_0/2) = \\exp(B/2).")]]

#text("We may iterate this argument (for a fixed, but small, value of ")#mi("{\\epsilon}")#text(") and conclude that")

#align(center)[#tao-fit-display[#mitex("\\Phi(t_0/2^k) = \\exp(B/2^k)")]]

#text("for all ")#mi("{k = 0,1,2,\\ldots}")#text(". By the homomorphism property and ")#link(<tao-aa33996d60e89311b4d1>)[#text("(1)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\Phi(qt_0) = \\exp(qB)")]]

#text("whenever ")#mi("{q}")#text(" is a dyadic rational, i.e. a rational of the form ")#mi("{a/2^k}")#text(" for some integer ")#mi("{a}")#text(" and natural number ")#mi("{k}")#text(". By continuity we thus have")

#align(center)[#tao-fit-display[#mitex("\\Phi(st_0) = \\exp(sB)")]]

#text("for all real ")#mi("{s}")#text(". Setting ")#mi("{A := B/t_0}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Phi(t) = \\exp(tA)")]]

#text("for all real ")#mi("{t}")#text(", which gives existence of the representation and also real analyticity and smoothness. Finally, uniqueness of the representation ")#mi("{\\Phi(t) = \\exp(tA)}")#text(" follows from the identity")

#align(center)[#tao-fit-display[#mitex("A = \\frac{d}{dt} \\exp(tA)|_{t=0}.")]]

#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Generalise Proposition ")#link(<tao-4bab36ce40d3a7f543a2>)[#text("1")]#text(" by replacing the hypothesis that ")#mi("{\\Phi}")#text(" is continuous with the hypothesis that ")#mi("{\\Phi}")#text(" is Lebesgue measurable (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Steinhaus_theorem")[#text("Steinhaus theorem")]#text(".). Show that the proposition fails (assuming the axiom of choice) if this hypothesis is omitted entirely.")
]

#text("Note how one needs both the group-like structure and the weak regularity in combination in order to ensure the strong regularity; neither is sufficient on its own. We will see variants of the above basic argument throughout the course. Here, the task of obtaining smooth (or real analytic structure) was relatively easy, because we could borrow the smooth (or real analytic) structure of the domain ")#mi("{{\\bf R}}")#text(" and range ")#mi("{M_n({\\bf C})}")#text("; but, somewhat remarkably, we shall see that one can still build such smooth or analytic structures even when none of the original objects have any such structure to begin with.")

#text("Now we turn to a second illustration of the above principles, namely ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("Jordan’s theorem")]#text(", which uses a discreteness hypothesis to upgrade Lie type structure to nilpotent (and in this case, abelian) structure. We shall formulate Jordan’s theorem in a slightly stilted fashion in order to emphasise the adherence to the above-mentioned principles.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Jordan’s theorem)")]#text(" ")#metadata(none) <tao-136c67657614311f3223>#text(" Let ")#mi("{G}")#text(" be an object with the following properties:")

#list(
[#text("(Group-like object) ")#mi("{G}")#text(" is a group.")],
[#text("(Discreteness) ")#mi("{G}")#text(" is finite.")],
[#text("(Lie-type structure) ")#mi("{G}")#text(" is contained in ")#mi("{U_n({\\bf C})}")#text(" (the group of unitary ")#mi("{n \\times n}")#text(" matrices) for some ")#mi("{n}")#text(".")]
)

#text("Then there is a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" such that")

#list(
[#text("(")#mi("{G^{\\prime}}")#text(" is close to ")#mi("{G}")#text(") The index ")#tao-math("{\\left|G/G^{\\prime}\\right|}", block: false)#text(" of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{G}")#text(" is ")#mi("{O_n(1)}")#text(" (i.e. bounded by ")#mi("{C_n}")#text(" for some quantity ")#mi("{C_n}")#text(" depending only on ")#mi("{n}")#text(").")],
[#text("(Nilpotent-type structure) ")#mi("{G^{\\prime}}")#text(" is abelian.")]
)
]

#text("A key observation in the proof of Jordan’s theorem is that if two unitary elements ")#mi("{g, h \\in U_n({\\bf C})}")#text(" are close to the identity, then their commutator ")#mi("{[g,h] = g^{-1}h^{-1}gh}")#text(" is even closer to the identity (in, say, the operator norm ")#mi("{\\| \\|_{op}}")#text("). Indeed, since multiplication on the left or right by unitary elements does not affect the operator norm, we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| [g,h] - 1 \\right\\|_{op}  & = \\left\\| gh - hg \\right\\|_{op}", block: true)



#tao-math(" & = \\left\\| (g-1)(h-1) - (h-1)(g-1) \\right\\|_{op}", block: true)
]

#text("and so by the triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| [g,h] - 1 \\right\\|_{op} \\leq 2 \\left\\|g-1\\right\\|_{op} \\left\\|h-1\\right\\|_{op}.", block: true)]]

#text("Now we can prove Jordan’s theorem.")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{n}")#text(", the case ")#mi("{n=1}")#text(" being trivial. Suppose first that ")#mi("{G}")#text(" contains a ")#link("http://en.wikipedia.org/wiki/Center_of_a_group")[#text("central element")]#text(" ")#mi("{g}")#text(" which is not a multiple of the identity. Then, by definition, ")#mi("{G}")#text(" is contained in the ")#link("http://en.wikipedia.org/wiki/Centralizer")[#text("centraliser")]#text(" ")#mi("{Z(g)}")#text(" of ")#mi("{g}")#text(", which by the spectral theorem is isomorphic to a product ")#mi("{U_{n_1}({\\bf C}) \\times \\ldots \\times U_{n_k}({\\bf C})}")#text(" of smaller unitary groups. Projecting ")#mi("{G}")#text(" to each of these factor groups and applying the induction hypothesis, we obtain the claim.")

#text("Thus we may assume that ")#mi("{G}")#text(" contains no central elements other than multiples of the identity. Now pick a small ")#mi("{\\epsilon > 0}")#text(" (one could take ")#mi("{\\epsilon=\\frac{1}{10n}}")#text(" in fact) and consider the subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" generated by those elements of ")#mi("{G}")#text(" that are within ")#mi("{\\epsilon}")#text(" of the identity (in the operator norm). By considering a maximal ")#mi("{\\epsilon}")#text("-net of ")#mi("{G}")#text(" we see that ")#mi("{G^{\\prime}}")#text(" has index at most ")#mi("{O_{n,\\epsilon}(1)}")#text(" in ")#mi("{G}")#text(". By arguing as before, we may assume that ")#mi("{G^{\\prime}}")#text(" has no central elements other than multiples of the identity.")

#text("If ")#mi("{G^{\\prime}}")#text(" consists only of multiples of the identity, then we are done. If not, take an element ")#mi("{g}")#text(" of ")#mi("{G^{\\prime}}")#text(" that is not a multiple of the identity, and which is as close as possible to the identity (here is where we crucially use that ")#mi("{G}")#text(" is finite). By ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(", we see that if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{n}")#text(", and if ")#mi("{h}")#text(" is one of the generators of ")#mi("{G^{\\prime}}")#text(", then ")#mi("{[g,h]}")#text(" lies in ")#mi("{G^{\\prime}}")#text(" and is closer to the identity than ")#mi("{g}")#text(", and is thus a multiple of the identity. On the other hand, ")#mi("{[g,h]}")#text(" has determinant ")#mi("{1}")#text(". Given that it is so close to the identity, it must therefore be the identity (if ")#mi("{\\epsilon}")#text(" is small enough). In other words, ")#mi("{g}")#text(" is central in ")#mi("{G^{\\prime}}")#text(", and is thus a multiple of the identity. But this contradicts the hypothesis that there are no central elements other than multiples of the identity, and we are done. ")#mi("\\Box")

#text("Commutator estimates such as ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(" will play a fundamental role in many of the arguments we will see in this course; as we saw above, such estimates combine very well with a discreteness hypothesis, but will also be very useful in the continuous setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Generalise Jordan’s theorem to the case when ")#mi("{G}")#text(" is a finite subgroup of ")#mi("{GL_n({\\bf C})}")#text(" rather than of ")#mi("{U_n({\\bf C})}")#text(". (")#emph[#text("Hint:")]#text(" The elements of ")#mi("{G}")#text(" are not necessarily unitary, and thus do not necessarily preserve the standard Hilbert inner product of ")#mi("{{\\bf C}^n}")#text(". However, if one averages that inner product by the finite group ")#mi("{G}")#text(", one obtains a new inner product on ")#mi("{{\\bf C}^n}")#text(" that is preserved by ")#mi("{G}")#text(", which allows one to conjugate ")#mi("{G}")#text(" to a subgroup of ")#mi("{U_n({\\bf C})}")#text(". This averaging trick is (a small) part of ")#link("http://en.wikipedia.org/wiki/Weyl%27s_unitary_trick")[#text("Weyl’s unitary trick")]#text(" in representation theory.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Inability to discretise nonabelian Lie groups)")]#text(" Show that if ")#mi("{n \\geq 3}")#text(", then the orthogonal group ")#mi("{O_n({\\bf R})}")#text(" cannot contain arbitrarily dense finite subgroups, in the sense that there exists an ")#mi("{\\epsilon = \\epsilon_n > 0}")#text(" depending only on ")#mi("{n}")#text(" such that for every finite subgroup ")#mi("{G}")#text(" of ")#mi("{O_n({\\bf R})}")#text(", there exists a ball of radius ")#mi("{\\epsilon}")#text(" in ")#mi("{O_n({\\bf R})}")#text(" (with, say, the operator norm metric) that is disjoint from ")#mi("{G}")#text(". What happens in the ")#mi("{n=2}")#text(" case?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" More precise classifications of the finite subgroups of ")#mi("{U_n({\\bf C})}")#text(" are known, particularly in low dimensions. For instance, one can show that the only finite subgroups of ")#mi("{SO_3({\\bf R})}")#text(" (which ")#mi("{SU_2({\\bf C})}")#text(" is a double cover of) are isomorphic to either a cyclic group, a ")#link("http://en.wikipedia.org/wiki/Dihedral_group")[#text("dihedral group")]#text(", or the symmetry group of one of the ")#link("http://en.wikipedia.org/wiki/Platonic_solid")[#text("Platonic solids")]#text(".")
]

#metadata(none) <tao-49ef7445ff4a3041c41d>

#heading(level: 1)[#strong[#text(" — 1. Hilbert’s fifth problem — ")]]

#text("One of the fundamental categories of objects in modern mathematics is the category of ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(", which are rich in both algebraic and analytic structure. Let us now briefly recall the precise definition of what a Lie group is.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Smooth manifold)")]#text(" Let ")#mi("{d \\geq 0}")#text(" be a natural number. An ")#mi("{d}")#text("-dimensional ")#link("http://en.wikipedia.org/wiki/Topological_manifold")[#text("topological manifold")]#text(" is a ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" topological space ")#mi("{M}")#text(" which is ")#emph[#text("locally Euclidean")]#text(", thus every point in ")#mi("{M}")#text(" has a neighbourhood which is homeomorphic to an open subset of ")#mi("{{\\bf R}^d}")#text(".")

#text("A ")#emph[#text("smooth atlas")]#text(" on an ")#mi("{d}")#text("-dimensional topological manifold ")#mi("{M}")#text(" is a family ")#mi("{(\\phi_\\alpha)_{\\alpha \\in A}}")#text(" of homeomorphisms ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" from open subsets ")#mi("{U_\\alpha}")#text(" of ")#mi("{M}")#text(" to open subsets ")#mi("{V_\\alpha}")#text(" of ")#mi("{{\\bf R}^d}")#text(", such that the ")#mi("{U_\\alpha}")#text(" form an open cover of ")#mi("{M}")#text(", and for any ")#mi("{\\alpha, \\beta \\in A}")#text(", the map ")#mi("{\\phi_\\beta \\circ \\phi_\\alpha^{-1}}")#text(" is smooth (i.e. infinitely differentiable) on the domain of definition ")#mi("{\\phi_\\alpha(U_\\alpha \\cap U_\\beta)}")#text(". Two smooth atlases are ")#emph[#text("equivalent")]#text(" if their union is also a smooth atlas; this is easily seen to be an equivalence relation. An equivalence class of smooth atlases is a ")#emph[#text("smooth structure")]#text(". A ")#emph[#text("smooth manifold")]#text(" is a topological manifold equipped with a smooth structure.")

#text("A map ")#mi("{\\psi: M \\rightarrow M^{\\prime}}")#text(" from one smooth manifold to another is said to be smooth if ")#mi("{\\phi^{\\prime}_\\alpha \\circ \\psi \\circ \\phi_\\beta^{-1}}")#text(" is a smooth function on the domain of definition ")#mi("{V_\\beta \\cap \\phi_\\beta^{-1}( U_\\beta \\cap \\psi^{-1}(U_\\alpha) )}")#text(" for any smooth charts ")#mi("{\\phi_\\beta, \\phi^{\\prime}_\\alpha}")#text(" in any the smooth atlases of ")#mi("{M, M^{\\prime}}")#text(" respectively (one easily verifies that this definition is independent of the choice of smooth atlas in the smooth structure).")
]

#text("Note that we do not require manifolds to be connected, nor do we require them to be embeddable inside an ambient Euclidean space such as ")#mi("{{\\bf R}^n}")#text(", although certainly many key examples of manifolds are of this form. The requirement that the manifold be Hausdorff is a technical one, in order to exclude pathological examples such as the line with a doubled point (formally, consider the double line ")#mi("{{\\bf R} \\times \\{0,1\\}}")#text(" after identifying ")#mi("{(x,0)}")#text(" with ")#mi("{(x,1)}")#text(" for all ")#mi("{x \\in {\\bf R} \\backslash \\{0\\}}")#text("), which is locally Euclidean but not Hausdorff. (In some literature, additional technical assumptions such as ")#link("http://en.wikipedia.org/wiki/Paracompact_space")[#text("paracompactness")]#text(", ")#link("http://en.wikipedia.org/wiki/Second-countable_space")[#text("second countability")]#text(", or ")#link("http://en.wikipedia.org/wiki/Metrizable")[#text("metrisability")]#text(" are imposed to remove pathological examples of topological manifolds such as the long line, but it will not be necessary to do so in this course, because (as we shall see later) we can essentially get such properties “for free” for locally Euclidean groups.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It is a plausible, but non-trivial, fact that a (non-empty) topological manifold can have at most one dimension ")#mi("{d}")#text(" associated to it; thus a manifold ")#mi("{M}")#text(" cannot both be locally homeomorphic to ")#mi("{{\\bf R}^d}")#text(" and locally homeomorphic to ")#mi("{{\\bf R}^{d^{\\prime}}}")#text(" unless ")#mi("{d=d^{\\prime}}")#text(". This fact is a consequence of Brouwer’s ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain theorem")]#text(", which we will discuss in later notes (see also ")#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")[#text("this blog post")]#text("). (On the other hand, it is an easy consequence of the ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(" that a ")#emph[#text("smooth")]#text(" manifold can have at most one dimension, without the need to invoke invariance of domain; we leave this as an exercise.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Lie group)")]#text(" A ")#emph[#text("Lie group")]#text(" is a group ")#mi("{G = (G,\\cdot)}")#text(" which is also a smooth manifold, such that the group operations ")#mi("{\\cdot: G\\times G \\rightarrow G}")#text(" and ")#mi("{()^{-1}: G \\rightarrow G}")#text(" are smooth maps. (Note that the Cartesian product of two smooth manifolds can be given the structure of a smooth manifold in the obvious manner.) We will also use additive notation ")#mi("{G = (G,+)}")#text(" to describe some Lie groups, but only in the case when the Lie group is abelian.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In some literature, Lie groups are required to be connected (and occasionally, are even required to be simply connected), but we will not adopt this convention here. One can also define infinite-dimensional Lie groups, but in this course all Lie groups are understood to be finite dimensional.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Every group can be viewed as a Lie group if given the discrete topology (and the discrete smooth structure). (Note that we are not requiring Lie groups to be connected.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Finite-dimensional vector spaces such as ")#mi("{{\\bf R}^d}")#text(" are (additive) Lie groups, as are sublattices such as ")#mi("{{\\bf Z}^d}")#text(" or quotients such as ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(". However, non-closed subgroups such as ")#mi("{{\\bf Q}^d}")#text(" are not manifolds (at least with the topology induced from ")#mi("{{\\bf R}^d}")#text(") and are thus not Lie groups; similarly, quotients such as ")#mi("{{\\bf R}^d/{\\bf Q}^d}")#text(" are not Lie groups either (they are not even Hausdorff). Also, infinite-dimensional topological vector spaces (such as ")#mi("{{\\bf R}^{\\bf N}}")#text(" with the product topology) will not be Lie groups.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" The ")#link("http://en.wikipedia.org/wiki/General_linear_group")[#text("general linear group")]#text(" ")#mi("{GL_n({\\bf C})}")#text(" of invertible ")#mi("{n \\times n}")#text(" complex matrices is a Lie group. A ")#link("http://en.wikipedia.org/wiki/Cartan%27s_theorem")[#text("theorem of Cartan")]#text(" (which we will prove in later notes) asserts that any closed subgroup of a Lie group is a smooth submanifold of that Lie group and is in particular also a Lie group. In particular, closed linear groups (i.e. closed subgroups of a general linear group) are Lie groups; examples include the real general linear group ")#mi("{GL_n({\\bf R})}")#text(", the ")#link("http://en.wikipedia.org/wiki/Unitary_group")[#text("unitary group")]#text(" ")#mi("{U_n({\\bf C})}")#text(", the ")#link("http://en.wikipedia.org/wiki/Special_unitary_group")[#text("special unitary group")]#text(" ")#mi("{SU_n({\\bf C})}")#text(", the ")#link("http://en.wikipedia.org/wiki/Orthogonal_group")[#text("orthogonal group")]#text(" ")#mi("{O_n({\\bf R})}")#text(", the ")#link("http://en.wikipedia.org/wiki/Special_orthogonal_group")[#text("special orthogonal group")]#text(" ")#mi("{SO_n({\\bf R})}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("of unipotent upper triangular ")#mi("{3 \\times 3}")#text(" real matrices. Many Lie groups are isomorphic to closed linear groups; for instance, the additive group ")#mi("{{\\bf R}}")#text(" can be identified with the closed linear group")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & {\\bf R} \\\\ 0 & 1 \\end{pmatrix},")]]

#text("the circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" can be identified with ")#mi("{SO_2({\\bf R})}")#text(" (or ")#mi("{U_1({\\bf C})}")#text("), and so forth. However, not all Lie groups are isomorphic to closed linear groups. A somewhat trivial example is that of a discrete group with cardinality larger than the continuum, which is simply too large to fit inside any linear group. A less pathological example is provided by the Weil-Heisenberg group")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & {\\bf R} & {\\bf R}/{\\bf Z} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix} := \\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix} / \\begin{pmatrix} 1 & 0 & {\\bf Z} \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("which is isomorphic the image of the Heisenberg group under the ")#link("http://en.wikipedia.org/wiki/Weil_representation")[#text("Weil representation")]#text(", or equivalently the group of isometries of ")#mi("{L^2({\\bf R})}")#text(" generated by translations and modulations. Despite this, though, it is helpful to think of closed linear groups and Lie groups as being almost the same concept as a first approximation. For instance, one can show using ")#link("http://en.wikipedia.org/wiki/Ado%27s_theorem")[#text("Ado’s theorem")]#text(" that every Lie group is ")#emph[#text("locally")]#text(" isomorphic to a linear ")#emph[#text("local")]#text(" group (we will discuss local groups later in this course, and see also ")#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("this post")]#text(").")

#text("An important subclass of the closed linear groups are the ")#link("http://en.wikipedia.org/wiki/Linear_algebraic_group")[#text("linear algebraic groups")]#text(", in which the group is also a real or complex ")#link("http://en.wikipedia.org/wiki/Affine_variety")[#text("algebraic variety")]#text(" (or at least an algebraically constructible set). All of the examples of closed linear groups given above are linear algebraic groups, although there exist closed linear groups that are not isomorphic to any algebraic group; see ")#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("this post")]#text(".")
]

#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(", like many of Hilbert’s problems, does not have a unique interpretation, but one of the most commonly accepted interpretations of the question posed by Hilbert is to determine if the requirement of smoothness in the definition of a Lie group is redundant. (There is also an analogue of Hilbert’s fifth problem for group ")#emph[#text("actions")]#text(", known as the Hilbert-Smith conjecture, which was discussed at this ")#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/")[#text("blog post")]#text(".) To answer this question, we need to relax the notion of a Lie group to that of a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Topological group)")]#text(" A ")#emph[#text("topological group")]#text(" is a group ")#mi("{G = (G,\\cdot)}")#text(" that is also a topological space, in such a way that the group operations ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(" and ")#mi("{()^{-1}: G \\rightarrow G}")#text(" are continuous. (As before, we also consider additive topological groups ")#mi("{G = (G,+)}")#text(" provided that they are abelian.)")
]

#text("Clearly, every Lie group is a topological group if one simply forgets the smooth structure. Furthermore, such topological groups remain locally Euclidean. It was established by ")#link("http://www.ams.org/mathscinet-getitem?mr=49204")[#text("Montgomery-Zippin")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("Gleason")]#text(" in 1952 that the converse statement holds, thus solving at least one formulation of Hilbert’s fifth problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-1774b8eebdec58c5f119>#text(" Let ")#mi("{G}")#text(" be an object with the following properties:")

#list(
[#text("(Group-like object) ")#mi("{G}")#text(" is a topological group.")],
[#text("(Weak regularity) ")#mi("{G}")#text(" is locally Euclidean.")]
)

#text("Then")

#list(
[#text("(Lie-type structure) ")#mi("{G}")#text(" is isomorphic to a Lie group.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that a locally Euclidean topological group is necessarily Hausdorff (without invoking Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("6")]#text(").")
]

#text("As it turns out, Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("6")]#text(" is not directly useful for many applications, because it is often difficult to verify that a given topological group is locally Euclidean. On the other hand, the weaker property of ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("local compactness")]#text(", which is clearly implied by the locally Euclidean property, is much easier to verify in practice. One can then ask the more general question of whether every locally compact group is isomorphic to a Lie group. Unfortunately, the answer to this question is easily seen to be no, as the following examples show:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Trivial topology)")]#text(" A group equipped with the trivial topology is a compact (hence locally compact) group, but will not be Hausdorff (and thus not Lie) unless the group is also trivial. Of course, this is a rather degenerate counterexample and can be easily eliminated in practice. For instance, we will see later that any topological group can be made Hausdorff by quotienting out the closure of the identity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Infinite-dimensional torus)")]#text(" The infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(" (with the product topology) is an (additive) topological group, which is compact (and thus locally compact) by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(". However, it is not a Lie group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (")#mi("{p}")#text("-adics)")]#text(" Let ")#mi("{p}")#text(" be a prime. We define the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#mi("{p}")#text("-adic")]#text(" norm ")#mi("{\\|\\|_p}")#text(" on the integers ")#mi("{{\\bf Z}}")#text(" by defining ")#tao-math("{\\left\\|n\\right\\|_p := p^{-j}}", block: false)#text(", where ")#mi("{p^j}")#text(" is the largest power of ")#mi("{p}")#text(" that divides ")#mi("{n}")#text(" (with the convention ")#tao-math("{\\left\\|0\\right\\|_p := 0}", block: false)#text("). This is easily verified to generate a metric (and even an ")#link("http://en.wikipedia.org/wiki/Ultrametric")[#text("ultrametric")]#text(") on ")#mi("{{\\bf Z}}")#text("; the ")#mi("{p}")#text("-adic integers ")#mi("{{\\bf Z}_p}")#text(" are then defined as the ")#link("http://en.wikipedia.org/wiki/Completion_(metric_space)#Completion")[#text("metric completion")]#text(" of ")#mi("{{\\bf Z}}")#text(" under this metric. This is easily seen to be a compact (hence locally compact) additive group (topologically, it is homeomorphic to a ")#link("http://en.wikipedia.org/wiki/Cantor_set")[#text("Cantor set")]#text("). However, it is not locally Euclidean (or even ")#link("http://en.wikipedia.org/wiki/Locally_connected")[#text("locally connected")]#text("), and so is not isomorphic to a Lie group.")

#text("One can also extend the ")#mi("{p}")#text("-adic norm to the ring ")#mi("{{\\bf Z}[\\frac{1}{p}]}")#text(" of rationals of the form ")#mi("{a/p^j}")#text(" for some integers ")#mi("{a,j}")#text(" in the obvious manner; the metric completion of this space is then the ")#mi("{p}")#text("-adic rationals ")#mi("{{\\bf Q}_p}")#text(". This is now a locally compact additive group rather than a compact one (")#mi("{{\\bf Z}_p}")#text(" is a compact open neighbourhood of the identity); it is still not locally connected, so it is still not a Lie group.")

#text("One can also define algebraic groups such as ")#mi("{GL_n}")#text(" over the ")#mi("{p}")#text("-adic rationals ")#mi("{{\\bf Q}_p}")#text("; thus for instance ")#mi("{GL_n({\\bf Q}_p)}")#text(" is the group of invertible ")#mi("{n \\times n}")#text(" matrices with entries in the ")#mi("{p}")#text("-adics. This is still a locally compact group, and is certainly not Lie.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Solenoid)")]#text(" Let ")#mi("{p}")#text(" be a prime. Let ")#mi("{G}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Solenoid_group")[#text("solenoid group")]#text(" ")#mi("{G := ({\\bf Z}_p \\times {\\bf R})/{\\bf Z}^\\Delta}")#text(", where ")#mi("{{\\bf Z}^\\Delta := \\{ (n,n): n \\in {\\bf Z} \\}}")#text(" is the diagonally embedded copy of the integers in ")#mi("{{\\bf Z}_p \\times {\\bf R}}")#text(". (Topologically, ")#mi("{G}")#text(" can be viewed as the set ")#mi("{{\\bf Z}_p \\times [0,1]}")#text(" after identifying ")#mi("{(x+1,1)}")#text(" with ")#mi("{(x,0)}")#text(" for all ")#mi("{x \\in {\\bf Z}_p}")#text(".) Show that ")#mi("{G}")#text(" is a compact additive group that is connected but not locally connected (and thus not a Lie group). Thus one cannot eliminate ")#mi("{p}")#text("-adic type behaviour from locally compact groups simply by restricting attention to the connected case (although we will see later that one can do so by restricting to the ")#emph[#text("locally")]#text(" connected case).")
]

#text("We have now seen several examples of locally compact groups that are not Lie groups. However, all of these examples are “almost” Lie groups in that they can be turned into Lie groups by quotienting out a small compact normal subgroup. (It is easy to see that the quotient of a locally compact group by a compact normal subgroup is again a locally compact group.) For instance, a group with the trivial topology becomes Lie after quotienting out the entire group (which is “small” in the sense that it is contained in every open neighbourhood of the origin). The infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(" can be quotiented into a finite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(" (which is of course a Lie group) by quotienting out the compact subgroup ")#mi("{\\{0\\}^d \\times ({\\bf R}/{\\bf Z})^{\\bf N}}")#text("; note from the definition of the product topology that these compact subgroups shrink to zero in the sense that every neighbourhood of the group identity contains at least one (and in fact all but finitely many) of these subgroups. Similarly, with the ")#mi("{p}")#text("-adic group ")#mi("{{\\bf Z}_p}")#text(", one can quotient out by the compact (and open) subgroups ")#mi("{p^j {\\bf Z}_p}")#text(" (which also shrink to zero, as discussed above) to obtain the cyclic groups ")#mi("{{\\bf Z}/p^j {\\bf Z}}")#text(", which are discrete and thus Lie. Quotienting out ")#mi("{{\\bf Q}_p}")#text(" by the same compact open subgroups ")#mi("{p^j{\\bf Z}_p}")#text(" also leads to discrete (hence Lie) quotients; similarly for algebraic groups defined over ")#mi("{{\\bf Q}_p}")#text(", such as ")#mi("{GL_n({\\bf Q}_p)}")#text(". Finally, with the solenoid group ")#mi("{G := ({\\bf Z}_p \\times {\\bf R})/{\\bf Z}^\\Delta}")#text(", one can quotient out the copy of ")#mi("{p^j {\\bf Z}_p \\times \\{0\\}}")#text(" in ")#mi("{G}")#text(" for ")#mi("{j=0,1,2,\\ldots}")#text(" (which are another sequence of compact subgroups shrinking to zero) to obtain the quotient group ")#mi("{({\\bf Z}/p^j{\\bf Z} \\times {\\bf R})/{\\bf Z}^\\Delta}")#text(", which is isomorphic to a (highly twisted) circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" and is thus Lie.")

#text("Inspired by these examples, we might be led to the following conjecture: if ")#mi("{G}")#text(" is a locally compact group, and ")#mi("{U}")#text(" is a neighbourhood of the identity, then there exists a compact normal subgroup ")#mi("{K}")#text(" of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(" such that ")#mi("{G/K}")#text(" is a Lie group. In the event that ")#mi("{G}")#text(" is Hausdorff, this is equivalent to asserting that ")#mi("{G}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Projective_limit")[#text("projective limit")]#text(" (or ")#emph[#text("inverse limit")]#text(") of Lie groups.")

#text("This conjecture is true in several cases; for instance, one can show using the ")#link("http://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" (which we will discuss later in this course) that it is true for compact groups, and we will later see that it is also true for connected locally compact groups. However, it is not quite true in general, as the following example shows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{T: {\\bf Q}_p \\rightarrow {\\bf Q}_p}")#text(" be the automorphism ")#mi("{Tx := px}")#text(". Let ")#mi("{G := {\\bf Q}_p \\rtimes_T {\\bf Z}}")#text(" be the semidirect product of ")#mi("{{\\bf Q}_p}")#text(" and ")#mi("{{\\bf Z}}")#text(" twisted by ")#mi("{T}")#text("; more precisely, ")#mi("{G}")#text(" is the Cartesian product ")#mi("{{\\bf Q}_p\\times {\\bf Z}}")#text(" with the product topology and the group law")

#align(center)[#tao-fit-display[#mitex("(x, n) (y, m) := (x + T^n y, n+m).")]]

#text("Show that ")#mi("{G}")#text(" is a locally compact group which is not isomorphic to a Lie group, and that ")#mi("{{\\bf Z}_p \\times \\{0\\}}")#text(" is an open neighbourhood of the identity that contains no non-trivial normal subgroups of ")#mi("{G}")#text(". Conclude that the conjecture stated above is false.")
]

#text("The difficulty in the above example was that it was not easy to keep a subgroup normal with respect to the entire group ")#mi("{{\\bf Q}_p \\rtimes_T {\\bf Z}}")#text(". Note however that ")#mi("{G}")#text(" contains a “large” (and more precisely, ")#emph[#text("open")]#text(") subgroup ")#mi("{{\\bf Q}_p \\times \\{0\\}}")#text(" which ")#emph[#text("is")]#text(" the projective limit of Lie groups. So the above examples do not rule out that the conjecture can still be salvaged if one passes from a group ")#mi("{G}")#text(" to an open subgroup ")#mi("{G^{\\prime}}")#text(". This is indeed the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Gleason-Yamabe theorem)")]#text(" ")#metadata(none) <tao-a2fc59772251e266000d>#text(" Let ")#mi("{G}")#text(" obey the following hypotheses:")

#list(
[#text("(Group-like object) ")#mi("{G}")#text(" is a topological group.")],
[#text("(Weak regularity) ")#mi("{G}")#text(" is locally compact.")]
)

#text("Then for every open neighbourhood ")#mi("{U}")#text(" of the identity, there exists a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and a compact normal subgroup ")#mi("{K}")#text(" of ")#mi("{G^{\\prime}}")#text(" with the following properties:")

#list(
[#text("(")#mi("{G^{\\prime}/K}")#text(" is close to ")#mi("{G}")#text(") ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(", and ")#mi("{K}")#text(" is contained in ")#mi("{U}")#text(".")],
[#text("(Lie-type structure) ")#mi("{G^{\\prime}/K}")#text(" is isomorphic to a Lie group.")]
)
]

#text("We will spend several lectures proving this theorem (due ")#link("http://www.ams.org/mathscinet-getitem?mr=39730")[#text("to Gleason")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=58607")[#text("to Yamabe")]#text("). As stated, ")#mi("{G^{\\prime}}")#text(" may depend on ")#mi("{U}")#text(", but one can in fact take the open subgroup ")#mi("{G^{\\prime}}")#text(" to be uniform in the choice of ")#mi("{U}")#text("; we will show this in later notes. Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("6")]#text(" can in fact be deduced from Theorem ")#link(<tao-a2fc59772251e266000d>)[#text("7")]#text(" and some topological arguments involving the invariance of domain theorem; we will see this later in this course (or see ")#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")[#text("this previous blog post")]#text(").")

#text("The Gleason-Yamabe theorem asserts that locally compact groups are “essentially” Lie groups, after ignoring the very large scales (by restricting to an open subgroup) and also ignoring the very small scales (by allowing one to quotient out by a small group). In special cases, the conclusion of the theorem can be simplified. For instance, it is easy to see that an open subgroup ")#mi("{G^{\\prime}}")#text(" of a topological group ")#mi("{G}")#text(" is also closed (since the complement ")#mi("{G \\backslash G^{\\prime}}")#text(" is a union of cosets of ")#mi("{G^{\\prime}}")#text("), and so if ")#mi("{G}")#text(" is connected, there are no open subgroups other than ")#mi("{G}")#text(" itself. Thus, in the connected case of Theorem ")#link(<tao-a2fc59772251e266000d>)[#text("7")]#text(", one can take ")#mi("{G = G^{\\prime}}")#text(". In a similar spirit, if ")#mi("{G}")#text(" has the ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(" (NSS) property, that is to say that there exists an open neighbourhood of the identity that contains no non-trivial subgroups of ")#mi("{G}")#text(", then we can take ")#mi("{K}")#text(" to be trivial. Thus, as a special case of the Gleason-Yamabe theorem, we see that all connected NSS locally compact groups are Lie; in fact it is not difficult to then conclude that any locally compact NSS group (regardless of connectedness) is Lie. Conversely, this claim turns out to be a key step in the ")#emph[#text("proof")]#text(" of Theorem ")#link(<tao-a2fc59772251e266000d>)[#text("7")]#text(", as we shall see later. (It is also not difficult to show that all Lie groups are NSS, as we shall see in the next set of notes.)")

#text("The proof of the Gleason-Yamabe theorem (as well as consequences, such as Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("6")]#text(") will occupy a significant fraction of this course. The proof proceeds in a somewhat lengthy series of steps in which the initial regularity (local compactness) on the group ")#mi("{G}")#text(" is gradually upgraded to increasingly stronger regularity (e.g. metrisability, the NSS property, or the locally Euclidean property) until one eventually obtains Lie structure. A key turning point in the argument will be the construction of a metric (which we call a ")#emph[#text("Gleason metric")]#text(") on (a large portion of) ")#mi("{G}")#text(" which obeys a commutator estimate similar to ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(".")

#text("While the Gleason-Yamabe theorem does not completely classify all locally compact groups (as mentioned earlier, it primarily controls the medium-scale behaviour, and not the very fine-scale or very coarse-scale behaviour, of such groups), it is still powerful enough for a number of applications, to which we now turn.")

#heading(level: 1)[#strong[#text(" — 2. Approximate groups — ")]]

#text("Now we turn to what appears at first glance to be an unrelated topic, namely that of ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("additive combinatorics")]#text(" (and its non-commutative counterpart, multiplicative combinatorics). One of the main objects of study in either additive or multiplicative combinatorics are ")#emph[#text("approximate groups")]#text(" – sets ")#mi("{A}")#text(" (typically finite) contained in an additive or multiplicative ambient group ")#mi("{G}")#text(" that are “almost groups” in the sense that they are “almost” closed under either addition or multiplication. (One can also consider abstract approximate groups that are not contained in an ambient genuine group, but we will not do so here.)")

#text("There are several ways to quantify what it means for a set ")#mi("{A}")#text(" to be “almost” closed under addition or multiplication. Here are some common formulations of this idea (phrased in multiplicative notation, for sake of concreteness):")

#list(
[#text("(Statistical multiplicative structure) For a “large” proportion of pairs ")#mi("{(a,b) \\in A \\times A}")#text(", the product ")#mi("{ab}")#text(" also lies in ")#mi("{A}")#text(".")],
[#text("(Small product set) The “size” of the product set ")#mi("{A \\cdot A := \\{ ab: a, b \\in A \\}}")#text(" is “comparable” to the “size” of the original set ")#mi("{A}")#text(". (For technical reasons, one sometimes uses the triple product ")#mi("{A \\cdot A \\cdot A := \\{ abc: a,b,c \\in A \\}}")#text(" instead of the double product.)")],
[#text("(Covering property) The product set ")#mi("{A \\cdot A}")#text(" can be covered by a “bounded” number of (left or right) translates of the original set ")#mi("{A}")#text(".")]
)

#text("Of course, to make these notions precise one would have to precisely quantify the various terms in quotes. Fortunately, the basic theory of additive combinatorics (and multiplicative combinatorics) can be used to show that all these different notions of additive or multiplicative structure are “essentially” equivalent; see Chapter 2 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(" (or ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text(" in the non-commutative case) for more discussion.")

#text("For the purposes of this course, it will be convenient to focus on the use of covering to describe approximate multiplicative structure. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Approximate groups)")]#text(" Let ")#mi("{G}")#text(" be a multiplicative group, and let ")#mi("{K \\geq 1}")#text(" be a real number. A ")#emph[#mi("{K}")#text("-approximate subgroup")]#text(" of ")#mi("{G}")#text(", or ")#emph[#mi("{K}")#text("-approximate group")]#text(" for short, is a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" which contains the identity, is symmetric (thus ")#mi("{A^{-1}:= \\{a^{-1}: a \\in A \\}}")#text(" is equal to ")#mi("{A}")#text(") and is such that ")#mi("{A \\cdot A}")#text(" can be covered by at most ")#mi("{K}")#text(" left-translates (or equivalently by symmetry, right translates) of ")#mi("{A}")#text(", thus there exists a subset ")#mi("{X}")#text(" of ")#mi("{G}")#text(" of cardinality at most ")#mi("{K}")#text(" such that ")#mi("{A \\cdot A \\subset X \\cdot A}")#text(".")
]

#text("In most combinatorial applications, one only considers approximate groups that are finite sets, but one could certainly also consider countably or uncountably infinite approximate groups also.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" A ")#mi("{1}")#text("-approximate subgroup of ")#mi("{G}")#text(" is the same thing as a genuine subgroup of ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" ")#metadata(none) <tao-54d5dbf0124e59afba31>#text(" In the additive group of the integers ")#mi("{{\\bf Z}}")#text(", the symmetric arithmetic progression ")#mi("{\\{-N,\\ldots,N\\}}")#text(" is a ")#mi("{2}")#text("-approximate group for any ")#mi("{N \\geq 1}")#text(". More generally, in any additive group ")#mi("{G}")#text(", the ")#emph[#text("symmetric generalised arithmetic progression")]

#align(center)[#tao-fit-display[#tao-math("\\{ a_1 v_1 + \\ldots + a_r v_r: a_1,\\ldots,a_r \\in {\\bf Z}, \\left|a_i\\right| \\leq N_i \\forall i=1,\\ldots,r\\}", block: true)]]

#text("with ")#mi("{v_1,\\ldots,v_r \\in G}")#text(" and ")#mi("{N_1,\\ldots,N_r > 0}")#text(", is a ")#mi("{2^r}")#text("-approximate group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-370aed697dc503aecee7>#text(" Let ")#mi("{A}")#text(" be a convex symmetric subset of ")#mi("{{\\bf R}^d}")#text(". Show that ")#mi("{A}")#text(" is a ")#mi("{5^d}")#text("-approximate group. (Hint: greedily pack ")#mi("{2A}")#text(" with disjoint translates of ")#mi("{\\frac{1}{2} A}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 9")]#text(" If ")#mi("{A}")#text(" is an open ")#link("http://en.wikipedia.org/wiki/Relatively_compact_subspace")[#text("precompact")]#text(" symmetric neighbourhood of the identity in a locally compact group ")#mi("{G}")#text(", then ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate group for some finite ")#mi("{K}")#text(". Thus we see some connection between locally compact groups and approximate groups; we will see a deeper connection involving ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproducts")]#text(" in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 10")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{d}")#text("-dimensional Lie group. Then ")#mi("{G}")#text(" is a smooth manifold, and can thus be (non-uniquely) given the structure of a ")#link("http://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifold")]#text(". If one does so, then for sufficiently small radii ")#mi("{r}")#text(", the ball ")#mi("{B(1,r)}")#text(" around the identity ")#mi("{1}")#text(" will be a ")#mi("{O_d(1)}")#text("-approximate group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 11 (Extensions)")]#text(" Let ")#mi("{\\phi: G \\rightarrow H}")#text(" be a surjective group homomorphism (thus ")#mi("{G}")#text(" is a ")#emph[#text("group extension")]#text(" of ")#mi("{H}")#text(" by the kernel ")#mi("{\\text{ker}(\\phi)}")#text(" of ")#mi("{\\phi}")#text("). If ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{H}")#text(", then ")#mi("{\\phi^{-1}(A)}")#text(" is a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{G}")#text(". One can think of ")#mi("{\\phi^{-1}(A)}")#text(" as an extension of the approximate group ")#mi("{A}")#text(" by ")#mi("{\\text{ker}(\\phi)}")#text(".")
]

#text("The classification of approximate groups is of importance in additive combinatorics, and has connections with number theory, geometric group theory, and the theory of expander graphs. One can ask for a quantitative classification, in which one has explicit dependence of constants on the approximate group parameter ")#mi("{K}")#text(", or one can settle for a qualitative classification in which one does not attempt to control this dependence of constants. In this course we will focus on the latter question, as this allows us to bring in qualitative tools such as the Gleason-Yamabe theorem to bear on the problem.")

#text("In the abelian case when the ambient group ")#mi("{G}")#text(" is additive, approximate groups are classified by ")#emph[#text("Freiman’s theorem for abelian groups")]#text(", which was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2302736")[#text("by Green and Ruzsa")]#text(". (Freiman himself ")#link("http://www.ams.org/mathscinet-getitem?mr=360496")[#text("obtained")]#text(" an analogous classification in the case when ")#mi("{G}")#text(" was a torsion-free abelian group, such as the integers ")#mi("{{\\bf Z}}")#text(".) As before, we phrase this theorem in a slightly stilted fashion (and in a qualitative, rather than quantitative, manner) in order to demonstrate its alignment with the general principles stated in the introduction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Freiman’s theorem in an abelian group)")]#text(" ")#metadata(none) <tao-883d6eca587747477a9c>#text(" Let ")#mi("{A}")#text(" be an object with the following properties:")

#list(
[#text("(Group-like object) ")#mi("{A}")#text(" is a subset of an additive group ")#mi("{G}")#text(".")],
[#text("(Weak regularity) ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate group.")],
[#text("(Discreteness) ")#mi("{A}")#text(" is finite.")]
)

#text("Then there exists a finite subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", and a subset ")#mi("{P}")#text(" of ")#mi("{G/H}")#text(", with the following properties:")

#list(
[#text("(")#mi("{P}")#text(" is close to ")#mi("{A/H}")#text(") ")#mi("{\\pi^{-1}(P)}")#text(" is contained in ")#mi("{4A := A + A + A + A}")#text(", where ")#mi("{\\pi: G \\rightarrow G/H}")#text(" is the quotient map, and ")#tao-math("{\\left|P\\right| \\gg_K \\left|A\\right|/\\left|H\\right|}", block: false)#text(".")],
[#text("(Nilpotent type structure) ")#mi("{P}")#text(" is a symmetric generalised arithmetic progression of rank ")#mi("{O_K(1)}")#text(" (see Example ")#link(<tao-54d5dbf0124e59afba31>)[#text("8")]#text(").")]
)
]

#text("Informally, this theorem asserts that in the abelian setting, discrete approximate groups are essentially bounded rank symmetric generalised arithmetic progressions, extended by finite groups (such extensions are also known as ")#emph[#text("coset progressions")]#text("). The theorem has a simpler conclusion (and is simpler to prove) in the case when ")#mi("{G}")#text(" is a torsion-free abelian group (such as ")#mi("{{\\bf Z}}")#text("), since in this case ")#mi("{H}")#text(" is trivial.")

#text("We will not discuss Green and Ruzsa’s proof of Theorem ")#link(<tao-883d6eca587747477a9c>)[#text("9")]#text(" here, save to say that it relies heavily on Fourier-analytic methods, and as such, does not seem to easily extend to a general non-abelian setting. To state the non-abelian analogue of Theorem ")#link(<tao-883d6eca587747477a9c>)[#text("9")]#text(", one needs multiplicative analogues of the concept of a generalised arithmetic progression. An ordinary (symmetric) arithmetic progression ")#mi("{\\{ -Nv, \\ldots, Nv\\}}")#text(" has an obvious multiplicative analogue, namely a (symmetric) geometric progression ")#mi("{\\{ a^{-N}, \\ldots, a^N \\}}")#text(" for some generator ")#mi("{a \\in G}")#text(". In a similar vein, if one has ")#mi("{r}")#text(" ")#emph[#text("commuting")]#text(" generators ")#mi("{a_1, \\ldots, a_r}")#text(" and some dimensions ")#mi("{N_1,\\ldots,N_r>0}")#text(", one can form a symmetric generalised geometric progression ")#metadata(none) <tao-c6f6c6df742f71973816>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("P := \\{ a_1^{n_1} \\ldots a_r^{n_r}: \\left|n_i\\right| \\leq N_i \\forall 1 \\leq i \\leq r \\},", block: true)]]

#text("which will still be an ")#mi("{3^r}")#text("-approximate group. However, if the ")#mi("{a_1,\\ldots,a_r}")#text(" do not commute, then the set ")#mi("{P}")#text(" defined in ")#link(<tao-c6f6c6df742f71973816>)[#text("(3)")]#text(" is not quite the right concept to use here; for instance, there it is no reason for ")#mi("{P}")#text(" to be symmetric. However, it can be modified as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Noncommutative progression)")]#text(" Let ")#mi("{a_1,\\ldots,a_r}")#text(" be elements of a (not necessarily abelian) group ")#mi("{G = (G,\\cdot)}")#text(", and let ")#mi("{N_1,\\ldots,N_r > 0}")#text(". We define the ")#emph[#text("noncommutative progression")]#text(" ")#mi("{P = P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" of rank ")#mi("{r}")#text(" with generators ")#mi("{a_1,\\ldots,a_r}")#text(" and dimensions ")#mi("{N_1,\\ldots,N_r}")#text(" to be the collection of all words ")#mi("{w}")#text(" composed using the alphabet ")#mi("{a_1, a_1^{-1},\\ldots,a_r,a_r^{-1}}")#text(", such that for each ")#mi("{1 \\leq i \\leq r}")#text(", the total number of occurrences of ")#mi("{a_i}")#text(" and ")#mi("{a_i^{-1}}")#text(" combined in ")#mi("{w}")#text(" is at most ")#mi("{N_i}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 12")]#text(" ")#mi("{P(a,b;1,2)}")#text(" consists of the elements")

#align(center)[#tao-fit-display[#mitex("1, a^\\pm, b^\\pm, b^\\pm a^\\pm, a^\\pm b^\\pm, b^{\\pm 2}, b^{\\pm 2} a^\\pm, b^\\pm a^\\pm b^\\pm, a^\\pm b^{\\pm 2},")]]

#text("where each occurrence of ")#mi("{\\pm}")#text(" can independently be set to ")#mi("{+}")#text(" or ")#mi("{-}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 13")]#text(" If the ")#mi("{a_1,\\ldots,a_r}")#text(" commute, then the noncommutative progression ")#mi("{P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" simplifies to ")#link(<tao-c6f6c6df742f71973816>)[#text("(3)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-2a24e91e0f2da47c859f>#text(" Let ")#mi("{G}")#text(" be the discrete Heisenberg group ")#metadata(none) <tao-cbb2b10e001d60ce3347>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("G = \\begin{pmatrix} 1 & {\\bf Z} & {\\bf Z} \\\\ 0 & 1 & {\\bf Z} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("and let")

#align(center)[#tao-fit-display[#mitex("e_1 := \\begin{pmatrix} 1 & 1 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}, e_2 := \\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 1 & 1 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("be the two generators of ")#mi("{G}")#text(". Let ")#mi("{N \\geq 1}")#text(" be a sufficiently large natural number. Show that the noncommutative progression ")#mi("{P(e_1, e_2; N, N)}")#text(" contains all the group elements ")#mi("{\\begin{pmatrix} 1 & a & c \\\\ 0 & 1 & b \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(" of ")#mi("{G}")#text(" with ")#tao-math("{\\left|a\\right|, \\left|b\\right| \\leq \\delta N}", block: false)#text(" and ")#tao-math("{\\left|c\\right| \\leq \\delta N^2}", block: false)#text(" for a sufficiently small absolute constant ")#mi("{\\delta>0}")#text("; conversely, show that all elements of ")#mi("{P(e_1,e_2;N,N)}")#text(" are of the form ")#mi("{\\begin{pmatrix} 1 & a & c \\\\ 0 & 1 & b \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(" with ")#tao-math("{\\left|a\\right|, \\left|b\\right| \\leq CN}", block: false)#text(" and ")#tao-math("{\\left|c\\right| \\leq C N^2}", block: false)#text(" for some sufficiently large absolute constant ")#mi("{C>0}")#text(". Thus, informally, we have")

#align(center)[#tao-fit-display[#mitex("P(e_1, e_2; N, N) = \\begin{pmatrix} 1 & O(N) & O(N^2) \\\\ 0 & 1 & O(N) \\\\ 0 & 0 & 1 \\end{pmatrix}.")]]
]

#text("It is clear that noncommutative progressions ")#mi("{P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" are symmetric and contain the identity. However, if the ")#mi("{a_1,\\ldots,a_r}")#text(" do not have any commutative properties, then the size of these progressions can grow exponentially in ")#mi("{N_1,\\ldots,N_r}")#text(" and will not be approximate groups with any reasonable parameter ")#mi("{K}")#text(". However, the situation changes when the ")#mi("{a_1,\\ldots,a_r}")#text(" generate a ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent group")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11")]#text(" Suppose that ")#mi("{a_1,\\ldots,a_r \\in G}")#text(" generate a nilpotent group of step ")#mi("{s}")#text(", and suppose that ")#mi("{N_1,\\ldots,N_r}")#text(" are all sufficiently large depending on ")#mi("{r,s}")#text(". Then ")#mi("{P( a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" is an ")#mi("{O_{r,s}(1)}")#text("-approximate group.")
]

#text("We will prove this proposition later in this course (when we review the properties of nilpotent groups).")

#text("We can now state the noncommutative analogue of Theorem ")#link(<tao-883d6eca587747477a9c>)[#text("9")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Freiman’s theorem in an arbitrary group)")]#text(" ")#metadata(none) <tao-c23794e28e1a95166dfe>#text(" Let ")#mi("{A}")#text(" be an object with the following properties:")

#list(
[#text("(Group-like object) ")#mi("{A}")#text(" is a subset of an multiplicative group ")#mi("{G}")#text(".")],
[#text("(Weak regularity) ")#mi("{A}")#text(" is a ")#mi("{K}")#text("-approximate group.")],
[#text("(Discreteness) ")#mi("{A}")#text(" is finite.")]
)

#text("Then there exists a finite subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", and a subset ")#mi("{P}")#text(" of ")#mi("{N(H)/H}")#text(" (where ")#mi("{N(H) := \\{ g \\in G: gH=Hg\\}}")#text(" is the normaliser of ")#mi("{H}")#text("), with the following properties:")

#list(
[#text("(")#mi("{P}")#text(" is close to ")#mi("{A/H}")#text(") ")#mi("{\\pi^{-1}(P)}")#text(" is contained in ")#mi("{A^4 := A \\cdot A \\cdot A \\cdot A}")#text(", where ")#mi("{\\pi: N(H) \\rightarrow N(H)/H}")#text(" is the quotient map, and ")#tao-math("{\\left|P\\right| \\gg_K \\left|A\\right|/\\left|H\\right|}", block: false)#text(".")],
[#text("(Nilpotent type structure) ")#mi("{P}")#text(" is a noncommutative progression of rank ")#mi("{O_K(1)}")#text(", whose generators generate a nilpotent group of step ")#mi("{O_K(1)}")#text(".")]
)
]

#text("The proof of this theorem (which is forthcoming work of Emmanuel Breuillard, Ben Green, Tom Sanders and myself, building upon earlier ")#link("http://arxiv.org/abs/0909.2190")[#text("work of Hrushovski")]#text(") relies on the Gleason-Yamabe theorem. The key connection will take some time to explain properly, but roughly speaking, it comes from the fact that the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" of a sequence of ")#mi("{K}")#text("-approximate groups can be used to generate a locally compact group, to which the Gleason-Yamabe theorem can be applied. This in turn can be used to place a metric on approximate groups that obeys a commutator estimate similar to ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(", which allows one to run an argument similar to that used to prove Theorem ")#link(<tao-136c67657614311f3223>)[#text("2")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Gromov’s theorem — ")]]

#text("The final topic of this course will be ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem on groups of polynomial growth")]#text(". This theorem is analogous to Theorem ")#link(<tao-a2fc59772251e266000d>)[#text("7")]#text(" or Theorem ")#link(<tao-c23794e28e1a95166dfe>)[#text("12")]#text(", but in the category of ")#emph[#text("finitely generated groups")]#text(" rather than locally compact groups or approximate groups.")

#text("Let ")#mi("{G}")#text(" be a group that is generated by a finite set ")#mi("{S}")#text(" of generators; for notational simplicity we will assume that ")#mi("{S}")#text(" is symmetric and contains the origin. Then ")#mi("{S}")#text(" defines a (right-invariant) ")#link("http://en.wikipedia.org/wiki/Word_metric")[#text("word metric")]#text(" on ")#mi("{G}")#text(", defined by setting ")#mi("{d(x,y)}")#text(" for ")#mi("{x,y \\in G}")#text(" to be the least natural number ")#mi("{n}")#text(" such that ")#mi("{x \\in S^n y}")#text(". One easily verifies that this is indeed a metric that is right-invariant (thus ")#mi("{d(xg,yg)=d(x,y)}")#text(" for all ")#mi("{x,y,g \\in G}")#text("). Geometrically, this metric describes the geometry of the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(" on ")#mi("{G}")#text(" formed by connecting ")#mi("{x}")#text(" to ")#mi("{sx}")#text(" for each ")#mi("{x \\in G}")#text(" and ")#mi("{s \\in S}")#text(". (See this ")#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("previous post")]#text(" for more discussion of using Cayley graphs to study groups geometrically.)")

#text("Let us now consider the growth of the balls ")#mi("{B(1,R) = S^{\\lfloor R\\rfloor}}")#text(" as ")#mi("{R \\rightarrow \\infty}")#text(". On the one hand, we have the trivial upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|B(1,R)\\right| \\leq \\left|S\\right|^R", block: true)]]

#text("that shows that such balls can grow at most exponentially. And for “typical” non-abelian groups, this exponential growth actually occurs; consider the case for instance when ")#mi("{S}")#text(" consists of the generators of a free group (together with their inverses, and the group identity). However, there are some groups for which the balls grow at a much slower rate. A somewhat trivial example is that of a finite group ")#mi("{G}")#text(", since clearly ")#tao-math("{\\left|B(1,R)\\right|}", block: false)#text(" will top out at ")#tao-math("{\\left|G\\right|}", block: false)#text(" (when ")#mi("{R}")#text(" reaches the ")#link("http://en.wikipedia.org/wiki/Distance_(graph_theory)")[#text("diameter")]#text(" of the Cayley graph) and stop growing after that point. Another key example is the abelian case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" If ")#mi("{G}")#text(" is an abelian group generated by a finite symmetric set ")#mi("{S}")#text(" containing the identity, show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B(1,R)\\right| \\leq (1+R)^{\\left|S\\right|}.", block: true)]]

#text("In particular, ")#mi("{B(1,R)}")#text(" grows at a polynomial rate in ")#mi("{R}")#text(".")
]

#text("Let us say that a finitely group ")#mi("{G}")#text(" is a ")#emph[#text("group of polynomial growth")]#text(" if one has ")#tao-math("{\\left|B(1,R)\\right| \\leq C R^d}", block: false)#text(" for all ")#mi("{R \\geq 1}")#text(" and some constants ")#mi("{C, d > 0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Show that the notion of a group of polynomial growth (as well as the rate ")#mi("{d}")#text(" of growth) does not depend on the choice of generators ")#mi("{S}")#text("; thus if ")#mi("{S^{\\prime}}")#text(" is another set of generators for ")#mi("{G}")#text(", show that ")#mi("{G}")#text(" has polynomial growth with respect to ")#mi("{S}")#text(" with rate ")#mi("{d}")#text(" if and only if it has polynomial growth with respect to ")#mi("{S^{\\prime}}")#text(" with rate ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-e2efdd7db924f31dc81b>#text(" Let ")#mi("{G}")#text(" be a finitely generated group, and let ")#mi("{G^{\\prime}}")#text(" be a finite index subgroup of ")#mi("{G}")#text(".")

#list(
[#text("Show that ")#mi("{G^{\\prime}}")#text(" is also finitely generated. (")#emph[#text("Hint:")]#text(" Let ")#mi("{S}")#text(" be a symmetric set of generators for ")#mi("{G}")#text(" containing the identity, and locate a finite integer ")#mi("{n}")#text(" such that ")#mi("{S^{n+1} G^{\\prime} = S^n G^{\\prime}}")#text(". Then show that the set ")#mi("{S^{\\prime} := G^{\\prime} \\cap S^{2n+1}}")#text(" is such that ")#mi("{S^{n+1} \\subset S^n S^{\\prime}}")#text(". Conclude that ")#mi("{S^n}")#text(" meets every coset of ")#mi("{\\langle S^{\\prime}\\rangle}")#text(" (or equivalently that ")#mi("{G = S^n \\langle S^{\\prime} \\rangle}")#text("), and use this to show that ")#mi("{S^{\\prime}}")#text(" generates ")#mi("{G^{\\prime}}")#text(".)")],
[#text("Show that ")#mi("{G}")#text(" has polynomial growth if and only if ")#mi("{G^{\\prime}}")#text(" has polynomial growth.")],
[#text("More generally, show that any finitely generated subgroup of a group of polynomial growth also has polynomial growth. Conclude in particular that a group of polynomial growth cannot contain the free group on two generators.")]
)
]

#text("From Exercise ")#link(<tao-2a24e91e0f2da47c859f>)[#text("9")]#text(" we see that the discrete Heisenberg group ")#link(<tao-cbb2b10e001d60ce3347>)[#text("(4)")]#text(" is of polynomial growth. It is in fact not difficult to show that more generally, any nilpotent finitely generated group is of polynomial growth. By Exercise ")#link(<tao-e2efdd7db924f31dc81b>)[#text("12")]#text(", this implies that any ")#link("http://en.wikipedia.org/wiki/Virtually_nilpotent")[#text("virtually nilpotent")]#text(" finitely generated group is of polynomial growth.")

#text("Gromov’s theorem asserts the converse statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Gromov’s theorem)")]#text(" ")#metadata(none) <tao-8a5c6e9d071ebbf687f2>#text(" Let ")#mi("{G}")#text(" be an object with the following properties:")

#list(
[#text("(Group-like object) ")#mi("{G}")#text(" is a finitely generated group.")],
[#text("(Weak regularity) ")#mi("{G}")#text(" is of polynomial growth.")]
)

#text("Then there exists a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" such that")

#list(
[#text("(")#mi("{G^{\\prime}}")#text(" is close to ")#mi("{G}")#text(") The index ")#tao-math("{\\left|G/G^{\\prime}\\right|}", block: false)#text(" is finite.")],
[#text("(Nilpotent type structure) ")#mi("{G^{\\prime}}")#text(" is nilpotent.")]
)
]

#text("More succinctly: a finitely generated group is of polynomial growth if and only if it is virtually nilpotent.")

#text("Groups of polynomial growth are related to approximate groups by the following observation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Pigeonhole principle)")]#text(" Let ")#mi("{G}")#text(" be a finitely generated group, and let ")#mi("{S}")#text(" be a symmetric set of generators for ")#mi("{G}")#text(" containing the identity.")

#list(
[#text("Show that there exists a ")#mi("{C > 1}")#text(" such that ")#tao-math("{\\left|B(1,5R/2)\\right| \\leq C \\left|B(1,R/2)\\right|}", block: false)#text(" for a sequence ")#mi("{R = R_n}")#text(" of radii going to infinity.")],
[#text("Show that there exists a ")#mi("{K > 1}")#text(" such that ")#mi("{B(1,R)}")#text(" is a ")#mi("{K}")#text("-approximate group for a sequence ")#mi("{R = R_n}")#text(" of radii going to infinity. (")#emph[#text("Hint:")]#text(" Argue as in Exercise ")#link(<tao-370aed697dc503aecee7>)[#text("8")]#text(".)")]
)
]

#text("In later notes we will use this connection to deduce Theorem ")#link(<tao-8a5c6e9d071ebbf687f2>)[#text("13")]#text(" from Theorem ")#link(<tao-c23794e28e1a95166dfe>)[#text("12")]#text(". From a historical perspective, this was not the first proof of Gromov’s theorem; ")#link("http://www.ams.org/mathscinet-getitem?mr=623534")[#text("Gromov’s original proof")]#text(" relied instead on a variant of Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("6")]#text(" (as did some subsequent variants of Gromov’s argument, such as the nonstandard analysis variant ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("of van den Dries and Wilkie")]#text("), and a subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=2629989")[#text("proof of Kleiner")]#text(" went by a rather different route, based on earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=1491451")[#text("of Colding and Minicozzi")]#text(" on harmonic functions of polynomial growth. (This latter proof is discussed in ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")[#text("blog posts")]#text(".) The proof we will give in these notes is more recent, based on an ")#link("http://arxiv.org/abs/0909.2190")[#text("argument of Hrushovski")]#text(". We remark that the strategy used to prove Theorem ")#link(<tao-c23794e28e1a95166dfe>)[#text("12")]#text(" – namely taking an ultralimit of a sequence of approximate groups – also appears in Gromov’s original argument (strictly speaking, he uses ")#link("http://en.wikipedia.org/wiki/Gromov-Hausdorff_limit")[#text("Gromov-Hausdorff limits")]#text(" instead of ultralimits, but the two types of limits are closely related). We will discuss these sorts of limits later in the course, but perhaps an intuitive model to keep in mind is the following: if one takes a discrete group (such as ")#mi("{{\\bf Z}^d}")#text(") and rescales it (say to ")#mi("{\\frac{1}{N} {\\bf Z}^d}")#text(" for a large parameter ")#mi("{N}")#text("), then intuitively this rescaled group “converges” to a continuous group (in this case ")#mi("{{\\bf R}^d}")#text("). More generally, one can generate locally compact groups (or at least locally compact spaces) out of the limits of (suitably normalised) groups of polynomial growth or approximate groups, which is one of the basic observations that tie the three different topics discussed above together.")

#text("As we shall see in later notes, finitely generated groups arise naturally as the ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental groups")]#text(" of compact manifolds. Using the tools of Riemannian geometry (such as the ")#link("http://en.wikipedia.org/wiki/Bishop-Gromov_inequality")[#text("Bishop-Gromov inequality")]#text("), one can relate the growth of such groups to the curvature of a metric on such a manifold. As a consequence, Gromov’s theorem and its variants can lead to some non-trivial conclusions about the relationship between the topology of a manifold and its geometry. The following simple consequence is typical:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14")]#text(" Let ")#mi("{M}")#text(" be a compact Riemannian manifold of non-negative ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci curvature")]#text(". Then the fundamental group ")#mi("{\\pi_1(M)}")#text(" of ")#mi("{M}")#text(" is virtually nilpotent.")
]

#text("We will discuss this result and some related results (such as a relaxation of the non-negative curvature hypothesis to an almost non-negative curvature hypothesis) in later notes. We also remark that the above proposition can also be proven (with stronger conclusions) by more geometric means, but there are some results of the above type which currently have no known proof that does not employ some version of Gromov’s theorem at some point.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Principles: randomness/structure or emergent from a common cause? | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-70939")[#strong[#text("Principles: randomness/structure or emergent from a common cause? | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("[…] Terence Tao presented a sketch of his project relating Hilbert’ fifth problem and approximate groups. For me the most interesting part is his Theorem 12 and its relation with Gromov’ theorem on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-70947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("When I read this sentence in remark2,")

#text("” (non-empty) topological manifold can have at most one dimension”")

#text("I think “Are all the non-empty topological manifolds, lines?”")

#emph[#text("[Clarified, thanks = T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-70965")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("Text apparently missing preceding Theorem 13, between")#linebreak()#text(" “(when {R} reaches the”")#linebreak()#text(" and")#linebreak()#text(" “finitely generated group is of polynomial growth.”")

#text("Also in following, after")#linebreak()#text(" “The proof we will give in these notes is more recent, based on an”")

#text("WFL")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KLM")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-71040")[#strong[#text("KLM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("Terry, how much do you have to spend typing all these? Do you still have time doing research after these expository writing? It is amazing how much you can do in 24hrs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Baker-Campbell-Hausdorff polynomials and Menelaus theorem | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-71388")[#strong[#text("Baker-Campbell-Hausdorff polynomials and Menelaus theorem | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2011")])]

#text("[…] will apply sometimes in the future to real combinatorial problems, like the Tao’ project presented here, and also to the problem of understanding curvature (in non-riemannian settings), see a hint here, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-72426")[#strong[#text("254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2011")])]

#text("[…] can be defined efficiently by modifying definition (iv) above, and which was already discussed in the previous set of notes. It is however difficult to use this definition for abstract Lie algebras and Lie groups. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-74630")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2011")]

#text("[…] on the compactness theorem, n-Category Café on Hadwiger’s theorem, Terry Tao starting a series of posts on Hilbert’s fifth problem, and Vismath (in German, translation) and 0xDE on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More on Hilbert’s tenth problem | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-82311")[#strong[#text("More on Hilbert’s tenth problem | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] 254A, Notes 0 – Hilbert’s fifth problem and related topics (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/307d89f425e9b819f55b488bdedc44caedfc677831e73a7164d7cf72686138e1-c139106f246ae318a68605d5633623fb38cef19d50ba7897a3cc2d30e9cc0eea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vitali Kapovitch")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-83412")[#strong[#text("Vitali Kapovitch")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2011")])]

#text("Proposition 14 is stated incorrectly. The Ricci curvature should be nonnegative rather than nonpositive. Also, you really want to state it for almost nonnegative Ricci curvature rather than for nonnegative Ricci curvature because for nonnegative Ricci curvature the result follows directly from Gromov’s polynomial growth theorem and relative volume comparison. Moreover, compact manifolds of nonnegative Ricci curvature are known to split in a finite cover as a torus times a simply connected manifold by an old result of Cheeger and Gromoll (it’s an easy consequence of the splitting theorem). In particular, their fundamental groups are virtually abelian, not just virtually nilpotent.")

#emph[#text("[Corrected, thanks. I plan to give a more detailed discussion of the type of geometric consequences of Gromov-type theorems in a later post, with only a brief mention to give the flavour in this introductory post. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-85369")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Is it Jordan’s Theorem still true if we replace “finite G” by “every element has finite order, and orders are bounded”?")

#text("Because I think that in this case, we can choose an element with minimal distance to 1, as all the possible values for the norm ")#tao-math("{\\left|\\left|1-g\\right|\\right|_{op}}", block: false)#text(" are of the form ")#tao-math("{\\left|1-e^\\frac{2k\\pi i}{n}\\right|}", block: false)#text(" for n=0,1,…,N and ")#mi("k=0,1,\\ldots,n-1")#text(", so they are finite. (where N is the bound for the orders.)")

#text("Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-85374")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("I think this works in the unitary case (Theorem 2), but it is not immediately obvious to me that it extends to the general linear case (Exercise 3). (Your hypothesis implies discreteness of the group, which gives finiteness in the unitary case by compactness.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-85375")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Indeed, I didn’t realize that my hypothesis implies finiteness in the unitary case. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf71ed7f2549e8cface2c6751c6e48ccffff14aba32b2bb31ceccb5d8919d2b2-12d7177c3841c3939b833d41851968481c9352d2c5068be055730f2166937c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-89257")[#strong[#text("Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("Dear Alin,")

#text("Two things:")

#text("1. Your hypothesis implies finiteness in the general linear case: it is a theorem due to Burnside that any subgroup of GLn consisting of elements of bounded order must be finite.")

#text("2. Jordan’s theorem actually holds without requiring that the orders of elements be bounded. This theorem is due to Schur, who proved along the way that any such group is conjugate to a unitary group of transformations. See ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")]

#text("-Kevin")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-85827")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("[…] groups after taking inverse limits; consider for instance the solenoid example (Exercise 6 from Notes 0). Share this:PrintEmailMoreDiggTwitterFacebookRedditStumbleUponLike this:LikeBe the first to like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-86735")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2011")])]

#text("As we noted in class yesterday, in Example 8 {-N,…,N} is (more specifically) a 2-approximate subgroup of the integers.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-87323")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("I have some questions:")

#text("1) Is there an analog version of Gromov’s thm. for locally compact groups? I was thinking at something like: If a lc. group G is compactly generated by K, and the measure of K^n grows polynomial in n, does G contain a cocompact nilpotent subgroup? (or something similar?)")

#text("2) In the view of Exercise 2, if G is a group with some Borel structure such that multiplication and the inverse functions are Borel, do we get that G is actually a topological group? Or, are measurable morphisms actually continuous?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-87324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("(1) is a great question; I’d say the answer is probably yes, but it is not currently in the literature. Many of the existing proofs of Gromov’s theorem rely at some point or another on the discreteness of the problem, but Gromov’s original argument may possibly be the one with the weakest such reliance. Another possibility (which would be worth exploring in any event) would be to develop a structure theorem for continuous approximate groups along the lines of Theorem 12, which would probably also settle this question. I may pass this question on to one of my graduate students who is looking into these sorts of matters.")

#text("(2) Hmm, another good question. Certainly if one places the “wrong” topological structure then the answer is no, e.g. R with the half-open topology has group operations that are Borel but not continuous. But perhaps a measurable group can, under some conditions, be equipped with a natural topology that makes it continuous. For instance, in a compact group G with Haar measure mu, the group G is isomorphic to its image in U(L^2(G)) under the regular representation with the strong operator topology. This suggests for a measurable group equipped with a Haar probability measure to again use the regular representation with the strong operator topology to define the topology on G. I don’t know if this would work in the case when the Haar measure is infinite, though (and also I don’t know how to construct the Haar measure in general without first having a topology).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-88644")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2011")])]

#text("If G is a standard Borel group which has a Haar measure, then G is Borel isomorphic to a locally compact group, this is known as Weil’s Theorem. I believe this is proved as you said, using the strong operator topology on the left-regular representation of G. Certainly, if G does not have a Haar measure this is false. Take, e.g. a non locally compact Polish group, like U(H) with H a separable infinite dimensional Hilbert space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-88646")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2011")])]

#text("Also, it seems that the first question also has an answer:")

#text("Losert, V, On the structure of groups with polynomial growth II J. London Math. Soc. (2) 63 (2001), no. 3, 640?654.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-89152")[#strong[#text("254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("[…] this set of notes we will be able to finally prove the Gleason-Yamabe theorem from Notes 0, which we restate here: Theorem 1 (Gleason-Yamabe theorem) Let be a locally compact group. Then, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Jordan-Schur theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-89620")[#strong[#text("The Jordan-Schur theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("[…] recently learned (from this comment of Kevin Ventullo) that the finiteness hypothesis on the group in this theorem can be relaxed to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-90829")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] now establish Theorem 5. Let be a locally Euclidean group. By Exercise 5 of Notes 0, is Hausdorff; it is also locally compact and first countable. Thus, by Exercise 4, such a group […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-96268")[#strong[#text("The structure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] to Pub. IHES. We had announced the main results of this paper in various forums (including this blog) for a few months now, but it had taken some time to fully write up the paper and put in various […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-101200")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("[…] to the identity in some suitable metric (cf. the proof of Jordan’s theorem from Notes 0) would be an element associated to the microscopic scale. The orbit starts out at microscopic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-104882")[#strong[#text("254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("[…] of) a well-known theorem of Gromov on groups of polynomial growth, as promised back in Notes 0, as well as a variant result (of a type known as a “generalised Margulis lemma”) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-126689")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] subgroup of for some , a bounded index subgroup of is abelian. (Jordan’s theorem was discussed further in last quarter’s course.) The finite characteristic case is inherently more complicated though (due in large part to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, addendum: Some notes on nilprogressions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-133748")[#strong[#text("254A, addendum: Some notes on nilprogressions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")])]

#text("[…] (as was done similarly for several other sets of lecture notes on this blog). When reviewing the zeroth set of notes in particular, I found that I had made a claim (Proposition 11 from those notes) which asserted, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-250524")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("In exercise 6, is (x + 1, 0) identified with (x, 1), or (x + 1, 1) identified with (x, 0)?")

#emph[#text("[Oops, that was a typo; corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3781471082b6216201a3b09288bcb4bc36df5b08faa9e8c458eb36787c589629-b94be61e6fc362546f2b347f76de01c33762d7ea02ec8126e3258b4a01a27dab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jialun")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-454197")[#strong[#text("Jialun")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2015")])]

#text("In the proof of theorem 2, the $\\epsilon$ depends on d, what is $d$? And it is not clear that $O_{n,\\epsilon}(1)$ only depends on n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3781471082b6216201a3b09288bcb4bc36df5b08faa9e8c458eb36787c589629-b94be61e6fc362546f2b347f76de01c33762d7ea02ec8126e3258b4a01a27dab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jialun")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-454206")[#strong[#text("Jialun")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2015")])]

#text("It’s clear, and ")#mi("\\epsilon")#text(" is just a typo, ")#mi("\\epsilon=1/10n")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-685094")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2024")])]

#text("Did you want A to be bounded in exercise 8? I can see how to use a similar idea as finding the minimal number balls of radius R/2 covering a ball of radius R using volume, but unsure if the statement of this problem is true if A has infinite volume.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-685095")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2024")])]

#text("Actually I think it is fine even if A is unbounded, if A contains a line through the origin then from each point in A, A contains a line in the same direction, and we can project to the orthogonal complement of the line and reduce to the case to 1 dimension lower")
]
]
