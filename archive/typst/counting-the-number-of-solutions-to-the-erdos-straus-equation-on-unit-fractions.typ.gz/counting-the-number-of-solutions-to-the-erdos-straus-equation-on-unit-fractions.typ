// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/
// Converted to Typst by tao2typ: "2026-10-14T16:36:35.084176+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Counting the number of solutions to the Erdös-Straus equation on unit fractions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Counting the number of solutions to the Erdös-Straus equation on unit fractions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/")[#text("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.tugraz.at/~elsholtz/")[#text("Christian Elsholtz")]#text(" and I have recently finished our joint paper “")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/07/egyptian-count13.pdf")[#text("Counting the number of solutions to the Erdös-Straus equation on unit fractions")]#text("“, submitted to the ")#link("http://www.austms.org.au/Journal+of+the+Australian+Mathematical+Society")[#text("Journal of the Australian Mathematical Society")]#text(". This supercedes my ")#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/")[#text("previous paper on the subject")]#text(", by obtaining stronger and more general results. (The paper is currently in the process of being resubmitted to the arXiv, and should appear at ")#link("http://arxiv.org/abs/1107.1010")[#text("this link")]#text(" within a few days.)")

#text("As with the previous paper, the main object of study is the number ")#mi("{f(n)}")#text(" of solutions to the Diophantine equation ")#metadata(none) <tao-0869b2f9553c7fa83cd1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{4}{n} = \\frac{1}{x} + \\frac{1}{y} + \\frac{1}{z}")]]

#text("with ")#mi("{x,y,z}")#text(" positive integers. The ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Straus_conjecture")[#text("Erdös-Straus conjecture")]#text(" asserts that ")#mi("{f(n)>0}")#text(" for all ")#mi("{n>1}")#text(". Since ")#mi("{f(nm) \\geq f(n)}")#text(" for all positive integers ")#mi("{n,m}")#text(", it suffices to show that ")#mi("{f(p)>0}")#text(" for all primes ")#mi("{p}")#text(".")

#text("We single out two special types of solutions: ")#emph[#text("Type I")]#text(" solutions, in which ")#mi("{x}")#text(" is divisible by ")#mi("{n}")#text(" and ")#mi("{y,z}")#text(" are coprime to ")#mi("{n}")#text(", and ")#emph[#text("Type II")]#text(" solutions, in which ")#mi("{x}")#text(" is coprime to ")#mi("{n}")#text(" and ")#mi("{y,z}")#text(" are divisible by ")#mi("{n}")#text(". Let ")#mi("{f_I(n), f_{II}(n)}")#text(" denote the number of Type I and Type II solutions respectively. For any ")#mi("{n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("f(n) \\geq 3 f_I(n) + 3 f_{II}(n),")]]

#text("with equality when ")#mi("{n}")#text(" is an odd primes ")#mi("{p}")#text(". Thus, to prove the Erdös-Strauss conjecture, it suffices to show that at least one of ")#mi("{f_I(p)}")#text(", ")#mi("{f_{II}(p)}")#text(" is positive whenever ")#mi("{p}")#text(" is an odd prime.")

#text("Our first main results are the asymptotics")

#tao-aligned(keep: true)[


#tao-math("N \\log^3 N  & \\ll \\sum_{n \\leq N} f_I(n) \\ll N \\log^3 N", block: true)



#tao-math("N \\log^3 N  & \\ll \\sum_{n \\leq N} f_{II}(n) \\ll N \\log^3 N", block: true)



#tao-math("N \\log^2 N  & \\ll \\sum_{p \\leq N} f_I(p) \\ll N \\log^2 N \\log\\log N", block: true)



#tao-math("N \\log^2 N  & \\ll \\sum_{p \\leq N} f_{II}(p) \\ll N \\log^2 N.", block: true)
]

#text("This improves upon the results in the previous paper, which only established")

#align(center)[#tao-fit-display[#mitex("N \\log^2 N \\ll \\sum_{p \\leq N} f_I(p) \\ll N \\exp(O( \\frac{\\log x}{\\log\\log x} ))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N \\log^2 N \\ll \\sum_{p \\leq N} f_{II}(p) \\ll N \\log^2 N \\log \\log N.")]]

#text("The double logarithmic factor in the upper bound for ")#mi("{\\sum_{p \\leq N} f_I(p)}")#text(" is artificial (arising from the inefficiency in the ")#link("http://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]#text(" on very short progressions) but we do not know how to remove it.")

#text("The methods are similar to those in the previous paper (which were also independently discovered in unpublished work of Elsholtz and Heath-Brown), but with the additional input of the Erdös divisor bound on expressions of the form ")#mi("{\\sum_{n \\leq N} \\tau(P(n))}")#text(" for polynomials ")#mi("{P}")#text(", discussed in ")#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/")[#text("this recent blog post")]#text(". (Actually, we need to tighten Erdös’ bound somewhat, to obtain some uniformity in the bounds even as the coefficients of ")#mi("{P}")#text(" become large, but this turns out to be achievable by going through the original arguments of Erdös more carefully.)")

#text("We also note an ")#link("http://www.ams.org/mathscinet-getitem?mr=2075628")[#text("observation of Heath-Brown")]#text(", that in our notation gives the lower bound")

#align(center)[#tao-fit-display[#mitex("N \\log^6 N \\ll \\sum_{n \\leq N} f(n);")]]

#text("thus, we see that for typical ")#mi("{n}")#text(", that most solutions to the Erdös-Straus equation are not of Type I or Type II, in contrast to the case when ")#mi("{n}")#text(" is prime.")

#text("We also have a number other new results. We find a way to systematically unify all the previously known parameterisations of solutions to the Erdös-Straus equation, by lifting the Cayley-type surface ")#mi("{\\{ (x,y,z): \\frac{4}{n} = \\frac{1}{x} + \\frac{1}{y} + \\frac{1}{z} \\}}")#text(" to a certain three-dimensional variety in six-dimensional affine space, in such a way that integer points in the former arise from integer points in the latter. Each of the previously known characterisations of solutions then corresponds to a different choice of coordinates on this variety. (This point of view was also adopted in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2075628")[#text("paper of Heath-Brown")]#text(", who interprets this lifted variety as the ")#emph[#text("universal torsor")]#text(" of the Cayley surface.) By optimising between these parameterisations and exploiting the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(", we obtain some bounds on the worst-case behaviour of ")#mi("{f_I(n)}")#text(" and ")#mi("{f_{II}(n)}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("f_I(n) \\ll n^{3/5 + O(1/\\log \\log n)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f_{II}(n) \\ll n^{2/5 + O(1/\\log \\log n)},")]]

#text("which should be compared to a recent previous bound ")#mi("{f(n) \\ll n^{2/3 + O(1/\\log \\log n)}}")#text(" ")#link("http://www.maths.bris.ac.uk/~matdb/preprints/es.pdf")[#text("of Browning and Elsholtz")]#text(". In the other direction, we show that ")#mi("{f(n) \\gg n^{(3+o(1))/\\log\\log n}}")#text(" for infinitely many ")#mi("{n}")#text(", and ")#mi("{f(p) \\gg \\log^{\\frac{\\log 3}{2}-o(1)} p}")#text(" for almost all primes ")#mi("{p}")#text(". Here, the main tools are some bounds for the representation of a rational as a sum of two unit fractions in the above-mentioned work of Browning and Elsholtz, and also the ")#link("http://en.wikipedia.org/wiki/Tur%C3%A1n%E2%80%93Kubilius_inequality")[#text("Turán-Kubilius inequality")]#text(".")

#text("We also completely classify all the congruence classes that can be solved by polynomials, completing the partial list discussed in the ")#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/")[#text("previous post")]#text(". Specifically, the Erdös-Straus conjecture is true for ")#mi("{n}")#text(" whenever one of the following congruence-type conditions is satisfied:")

#enum(start: 1, 
[#mi("{n = -f \\mod 4ad}")#text(", where ")#mi("{a,d,f \\in {\\bf N}}")#text(" are such that ")#mi("{f|4a^2 d+1}")#text(".")],
[#mi("{n = -f \\mod 4ac}")#text(" and ")#mi("{n = -\\frac{c}{a} \\mod f}")#text(", where ")#mi("{a,c,f \\in {\\bf N}}")#text(" are such that ")#mi("{(4ac,f)=1}")#text(".")],
[#mi("{n = -f \\mod 4cd}")#text(" and ")#mi("{n^2 = -4c^2d \\mod f}")#text(", where ")#mi("{c,d,f \\in {\\bf N}}")#text(" are such that ")#mi("{(4cd,f)=1}")#text(".")],
[#mi("{n = -\\frac{1}{e} \\mod 4ab}")#text(" or ")#mi("{n = -e \\mod 4ab}")#text(", where ")#mi("{a,b,e \\in {\\bf N}}")#text(" are such that ")#mi("{e|a+b}")#text(" and ")#mi("{(e,4ab)=1}")#text(".")],
[#mi("{n = -4a^2d \\mod f}")#text(", where ")#mi("{a,d,f \\in {\\bf N}}")#text(" are such that ")#mi("{4ad|f+1}")#text(".")],
[#mi("{n = -4a^2d-e \\mod 4ade}")#text(", where ")#mi("{a,d,e \\in {\\bf N}}")#text(" are such that ")#mi("{(4ad,e)=1}")#text(".")]
)

#text("In principle, this suggests a way to extend the existing verification of the Erdös-Straus conjecture beyond the current range of ")#mi("{10^{14}}")#text(" by collecting all congruences to small moduli (e.g. up to ")#mi("{10^6}")#text("), and then using this to sieve out the primes up to a given size.")

#text("Finally, we begin a study of the more general equation ")#metadata(none) <tao-7dd7fe99a51b25537f5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{m}{n} = \\frac{1}{n_1}+\\ldots+\\frac{1}{n_k}")]]

#text("where ")#mi("{m > k \\geq 3}")#text(" are fixed. We can obtain a partial analogue of our main bounds for the ")#mi("{m=4,k=3}")#text(" case, namely that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} f_{m,k,II}(n) \\gg N \\log^{2^{k-1}-1} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq N} f_{m,k,II}(p) \\gg N \\log^{2^{k-1}-2} N / \\log\\log N")]]

#text("were ")#mi("{f_{m,k,II}(n)}")#text(" denotes the number of solutions to ")#link(<tao-7dd7fe99a51b25537f5f>)[#text("(2)")]#text(" which are of “Type II” in the sense that ")#mi("{n_2,\\ldots,n_k}")#text(" are all divisible by ")#mi("{n}")#text(". However, we do not believe our bounds to be sharp in the large ")#mi("{k}")#text(" regime, though it does show that the expected number of solutions to ")#link(<tao-7dd7fe99a51b25537f5f>)[#text("(2)")]#text(" should grow rapidly in ")#mi("{k}")#text(".")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-69173")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2011")])]

#text("Is there anything known about the (perhaps easier) case when we look for solutions to ")#mi("\\frac{4}{n} = \\frac{1}{x} + \\frac{1}{y} + \\frac{1}{z} + \\frac{1}{w}")#text("? I am trying to think whether this makes the idea easier or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-69250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("In our paper we have some lower bounds on the average number of solutions in this case (which we call the k=4 case), but we were unable to match them with good upper bounds. There are of course more solutions in the k=4 case than the k=3 case (and in particular, there is obviously at least one solution for each n) but by the same token, they are harder to parameterise efficiently.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0517203ec02b286af9a2493ae53e894d656dfc0a13cf122634d3a9a41b90e69-58a4459b29b91ad533d1f7324df817dae0a6a6cd9e222140cf037a82526d5eb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-78824")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2011")])]

#text("In Lemma 2.7 of the paper and its proof, bounds are given for some of the parameters of Type I and II solutions. In particular, it is proved that, for Type I solutions, ")#mi("{\\frac{n}{4} < y < \\frac{3n}{4}}")#text(", where ")#mi("{y}")#text(" is the smallest value among ")#mi("{x}")#text(", ")#mi("{y}")#text(", and ")#mi("{z}")#text(". It is then stated that “The constants in the bounds here could be improved slightly, but such improvements will not be of importance in our applications.”")

#text("I believe I can show that the upper bound on ")#mi("{y}")#text(" in the Type I solution case can be improved to ")#mi("{y < \\frac{n}{2}}")#text(", unless ")#mi("{n=3 \\mod{4}}")#text(", in which ")#mi("{y \\leq \\frac{n+1}{2}}")#text(". I’m not sure, maybe this is what the authors had in mind when it was said that the bounds could be improved slightly. Anyway, for what it’s worth, here is my argument. I use the notation from the paper, Lemma 2.7.")

#text("First, observe that ")#mi("{c < n}")#text(", since ")#mi("{c | y}")#text(" and ")#mi("{y < \\frac{3n}{4}}")#text(". Next, observe that ")#mi("{ na + c = b (4y - n) }")#text(". This follows by starting from (2.3) in the paper, ")#mi("{4abcd = na + nb + c}")#text(", and, since ")#mi("{y=acd}")#text(", it follows that ")#mi("{(4y-n)b = na+c}")#text(". Next, observe that ")#mi("{ z = \\frac{y}{a} b }")#text(". This follows from ")#mi("{z= bcd}")#text(", by substituting ")#mi("{cd = \\frac{y}{a}}")#text(". Next, observe that ")#mi("{ x = n \\frac{y}{c} b }")#text(". This follows from ")#mi("{x= nabd}")#text(", by substituting ")#mi("{ad = \\frac{y}{c}}")#text(". Thus the solution ")#mi("{(x,y,z) = (n \\frac{yb}{c}, y, \\frac{yb}{a} )}")#text(".")

#text("Assume now that ")#mi("{y \\geq \\frac{n}{2}}")#text(". Then ")#mi("{4y-n \\geq n}")#text(", say ")#mi("{4y-n = n+t}")#text(" where ")#mi("{t \\geq 0}")#text(". So ")#mi("{na+c = b(4y-n)= b(n+t)}")#text(".")

#text("But since ")#mi("{c < n}")#text(", ")#mi("{b \\leq a}")#text(". If ")#mi("{b < a}")#text(", then since ")#mi("{z=\\frac{y}{a} b }")#text(", ")#mi("{z < y}")#text(", a contradiction. So assume ")#mi("{b=a}")#text(". Then ")#mi("{na + c = a(n+t)}")#text(", so ")#mi("{c=at}")#text(". But ")#mi("{(c,a) = 1}")#text(", so this means ")#mi("{a = b = 1}")#text(". This means ")#mi("{4y-n = n+c}")#text(". But since ")#mi("{c|y}")#text(", this means that ")#mi("{c|2n}")#text(", and, since ")#mi("{(c,n) =1}")#text(", it must be that ")#mi("{c|2}")#text(", so ")#mi("{c}")#text(" = 1 or 2. If ")#mi("{c=1}")#text(", then ")#mi("{n+1=4y-n}")#text(", which is clearly impossible. If ")#mi("{c=2}")#text(", then ")#mi("{2|y}")#text(" and ")#mi("{4y-n = n+2}")#text(", so ")#mi("{4y =2n+2}")#text(", and ")#mi("{y = \\frac{n+1}{2}}")#text(". Since ")#mi("{2 | y}")#text(", this case can only happen when ")#mi("{n = 3 \\mod{4}}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diophantine sets and the integers | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-82097")[#strong[#text("Diophantine sets and the integers | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] Counting the number of solutions to the Erdös-Straus equation on unit fractions (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4f87880472e59ceb1a7c8c2ea68905212c1799d7947654c110240f618f22382-697facf8e927b77f721be3940fcee89174017194876c8718a9cea20ad613ea97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davie")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-123836")[#strong[#text("davie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2012")])]

#text("can i have the list of erdos-straus conjecture expressing rational number 4/n a sum of three unit fractions 1/x+1/y+1/z???email me at my account ")#link("mailto:atillodavid@yahoo.com")[#text("atillodavid@yahoo.com")]#text("…tnx a lot")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668c6388f4edd67abca8e583e7bdd2e94990e64940d99b20b6ec018a6f71f6fb-7b8ad9d4ca00b89a05a0719b5e9db7e53e82a4e20a181e78dd07dc7e2e4c13cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ibrahimaeygue")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-408519")[#strong[#text("ibrahimaeygue")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2014")])]

#text("Dear all")#linebreak()#text(" RSA numbers linked to the pythagorean triples associated with Erdös-Straus decompositions…. N = 2099999959 is factorised in less than 10 / 100th of a second almost “instantly” The general characterization is given by :")#linebreak()#text(" – p = s*N*r/((2*a*s – r*N)*( s+r+t))")#linebreak()#text(" – q = ((2*a*s – r*N)*( s+r+t))/(s*r)")#linebreak()#text(" and/or")#linebreak()#text(" – p = s*N*r/((2*a*s – r*N)*( s-r+t))")#linebreak()#text(" – q = ((2*a*s – r*N)*( s-r+t))/(s*r)")#linebreak()#text(" Best regards")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d382643c42653a35bc37f4947a47281bfb1be0a1e83e81075ddb75756c77f479-1f766434a61db4f1f08dbf7fe0cce359f7fc2a67c19f1e200b3eec143b480429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben thurston")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-473389")[#strong[#text("Ben thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("I found these I hadn’t seen anywhere else: ")#link("http://imgur.com/a/mAlIR")[#text("http://imgur.com/a/mAlIR")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d382643c42653a35bc37f4947a47281bfb1be0a1e83e81075ddb75756c77f479-1f766434a61db4f1f08dbf7fe0cce359f7fc2a67c19f1e200b3eec143b480429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben thurston")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-473391")[#strong[#text("Ben thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("they make a little more sense factoring a term I was leaving expanded…")#link("http://imgur.com/a/nDuao")[#text("http://imgur.com/a/nDuao")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a120ba83f3d9e90484f3a78987a8f4f9ab60c47782c3ea009de89d273504c316-1bd0a0bf9eb3c7dae2e17149bcab1cc7b604f6d6a37715fe5e43e4037e943918.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wlod")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-473410")[#strong[#text("wlod")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Perhaps, in the old days, many people got the result for all $n$ but for $12\\cdot m+1$ case. This follows from the three simplest cases: $4\\cdot m-1$, and $3\\cdot m-1$, and $8\\cdot m-3$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79488269e15a2d2681e0cfc37172d1af53fd26367589850891e68e95b287e375-0cdf31d0c3aabfe83dcc6f60eab7b5bbaaed298460ad658dc3928033eda27e33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of siplebrice")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-520574")[#strong[#text("siplebrice")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("I was toying with Integer Partitions of 4n into exactly 3 parts restricted to the divisors of pn. I’m not sure how to address that restriction combinatorially, but if a+b+c=4n and a, b, & c each divide pn, it’s done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/31/counting-the-number-of-solutions-to-the-erdos-straus-equation-on-unit-fractions/#comment-689204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("For the Erdős–Straus equation")#linebreak()#text("( frac{4}{n} = frac{1}{x} + frac{1}{y} + frac{1}{z} ),")#linebreak()#text("one can package the usual heuristics as")

#text("[")#linebreak()#text("f(n)")#linebreak()#text("= A_1(n) (log n)^2")

#list(
[#text("A_2(n) log n")],
[#text("O!big((log n)^alphabig),")#linebreak()#text("]")]
)

#text("with, for instance,")

#text("[")#linebreak()#text("A_1(n) = prod_{p mid n} left(1 + frac{2}{p}right), qquad")#linebreak()#text("A_2(n) = sum_{p mid n} frac{log p}{p},")#linebreak()#text("]")

#text("for some fixed (alpha < 2). This is only meant as a compact way to")#linebreak()#text("encode the standard “local factors × (log^2 n)” heuristics, not as")#linebreak()#text("a new result.")
]
