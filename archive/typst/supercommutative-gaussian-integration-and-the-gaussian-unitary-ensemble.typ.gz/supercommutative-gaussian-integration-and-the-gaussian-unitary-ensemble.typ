// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/
// Converted to Typst by tao2typ: "2026-10-14T16:36:59.349156+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Supercommutative gaussian integration, and the gaussian unitary ensemble", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Supercommutative gaussian integration, and the gaussian unitary ensemble")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/")[#text("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The fundamental notions of calculus, namely differentiation and integration, are often viewed as being the quintessential concepts in mathematical analysis, as their standard definitions involve the concept of a limit. However, it is possible to capture most of the essence of these notions by purely algebraic means (almost completely avoiding the use of limits, Riemann sums, and similar devices), which turns out to be useful when trying to generalise these concepts to more abstract situations in which it becomes convenient to permit the underlying number systems involved to be something other than the real or complex numbers, even if this makes many standard analysis constructions unavailable. For instance, the algebraic notion of a ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivation")]#text(" often serves as a substitute for the analytic notion of a derivative in such cases, by abstracting out the key algebraic properties of differentiation, namely linearity and the ")#link("http://en.wikipedia.org/wiki/Product_rule")[#text("Leibniz rule")]#text(" (also known as the ")#emph[#text("product rule")]#text(").")

#text("Abstract algebraic analogues of integration are less well known, but can still be developed. To motivate such an abstraction, consider the integration functional ")#mi("{I: {\\mathcal S}({\\bf R} \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" from the space ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" of complex-valued Schwarz functions ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" to the complex numbers, defined by")

#align(center)[#tao-fit-display[#mitex("I(f) := \\int_{\\bf R} f(x)\\ dx")]]

#text("where the integration on the right is the usual Lebesgue integral (or improper Riemann integral) from analysis. This functional obeys two obvious algebraic properties. Firstly, it is linear over ")#mi("{{\\bf C}}")#text(", thus ")#metadata(none) <tao-78a3b3f0d93ed710919f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("I(cf) = c I(f)")]]

#text(" and ")#metadata(none) <tao-d3783e8a3fb35cecac1b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("I(f+g) = I(f) + I(g)")]]

#text(" for all ")#mi("{f,g \\in {\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" and ")#mi("{c \\in {\\bf C}}")#text(". Secondly, it is translation invariant, thus ")#metadata(none) <tao-5c890cea35931c440300>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("I(\\tau_h f) = I(f)")]]

#text(" for all ")#mi("{h \\in {\\bf C}}")#text(", where ")#mi("{\\tau_h f(x) := f(x-h)}")#text(" is the translation of ")#mi("{f}")#text(" by ")#mi("{h}")#text(". Motivated by the uniqueness theory of Haar measure, one might expect that these two axioms already uniquely determine ")#mi("{I}")#text(" after one sets a normalisation, for instance by requiring that ")#metadata(none) <tao-733859c1fc6b9331793b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("I( x \\mapsto e^{-\\pi x^2} ) = 1.")]]

#text(" This is not quite true as stated (one can modify the proof of the Hahn-Banach theorem, after first applying a Fourier transform, to create pathological translation-invariant linear functionals on ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" that are not multiples of the standard Fourier transform), but if one adds a mild analytical axiom, such as continuity of ")#mi("{I}")#text(" (using the usual Schwartz topology on ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text("), then the above axioms are enough to uniquely pin down the notion of integration. Indeed, if ")#mi("{I: {\\mathcal S}({\\bf R} \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" is a continuous linear functional that is translation invariant, then from the linearity and translation invariance axioms one has")

#align(center)[#tao-fit-display[#mitex("I( \\frac{\\tau_h f - f}{h} ) = 0")]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" and non-zero reals ")#mi("{h}")#text(". If ")#mi("{f}")#text(" is Schwartz, then as ")#mi("{h \\rightarrow 0}")#text(", one can verify that the Newton quotients ")#mi("{\\frac{\\tau_h f - f}{h}}")#text(" converge in the Schwartz topology to the derivative ")#mi("{f^{\\prime}}")#text(" of ")#mi("{f}")#text(", so by the continuity axiom one has")

#align(center)[#tao-fit-display[#mitex("I(f^{\\prime}) = 0.")]]

#text("Next, note that any Schwartz function of integral zero has an antiderivative which is also Schwartz, and so ")#mi("{I}")#text(" annihilates all zero-integral Schwartz functions, and thus must be a scalar multiple of the usual integration functional. Using the normalisation ")#link(<tao-733859c1fc6b9331793b>)[#text("(4)")]#text(", we see that ")#mi("{I}")#text(" must therefore be the usual integration functional, giving the claimed uniqueness.")

#text("Motivated by the above discussion, we can define the notion of an ")#emph[#text("abstract integration functional")]#text(" ")#mi("{I: X \\rightarrow R}")#text(" taking values in some vector space ")#mi("{R}")#text(", and applied to inputs ")#mi("{f}")#text(" in some other vector space ")#mi("{X}")#text(" that enjoys a linear action ")#mi("{h \\mapsto \\tau_h}")#text(" (the “translation action”) of some group ")#mi("{V}")#text(", as being a functional which is both linear and translation invariant, thus one has the axioms ")#link(<tao-78a3b3f0d93ed710919f>)[#text("(1)")]#text(", ")#link(<tao-d3783e8a3fb35cecac1b>)[#text("(2)")]#text(", ")#link(<tao-5c890cea35931c440300>)[#text("(3)")]#text(" for all ")#mi("{f,g \\in X}")#text(", scalars ")#mi("{c}")#text(", and ")#mi("{h \\in V}")#text(". The previous discussion then considered the special case when ")#mi("{R = {\\bf C}}")#text(", ")#mi("{X = {\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(", ")#mi("{V = {\\bf R}}")#text(", and ")#mi("{\\tau}")#text(" was the usual translation action.")

#text("Once we have performed this abstraction, we can now present analogues of classical integration which bear very little ")#emph[#text("analytic")]#text(" resemblance to the classical concept, but which still have much of the ")#emph[#text("algebraic")]#text(" structure of integration. Consider for instance the situation in which we keep the complex range ")#mi("{R = {\\bf C}}")#text(", the translation group ")#mi("{V = {\\bf R}}")#text(", and the usual translation action ")#mi("{h \\mapsto \\tau_h}")#text(", but we replace the space ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" of Schwartz functions by the space ")#mi("{Poly_{\\leq d}({\\bf R} \\rightarrow {\\bf C})}")#text(" of polynomials ")#mi("{x \\mapsto a_0 + a_1 x + \\ldots + a_d x^d}")#text(" of degree at most ")#mi("{d}")#text(" with complex coefficients, where ")#mi("{d}")#text(" is a fixed natural number; note that this space is translation invariant, so it makes sense to talk about an abstract integration functional ")#mi("{I: Poly_{\\leq d}({\\bf R} \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(". Of course, one cannot apply traditional integration concepts to non-zero polynomials, as they are not absolutely integrable. But one can repeat the previous arguments to show that any abstract integration functional must annihilate derivatives of polynomials of degree at most ")#mi("{d}")#text(": ")#metadata(none) <tao-c9629fc422c960bf417f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("I(f^{\\prime}) = 0 \\text{ for all } f \\in Poly_{\\leq d}({\\bf R} \\rightarrow {\\bf C}).")]]

#text(" Clearly, every polynomial of degree at most ")#mi("{d-1}")#text(" is thus annihilated by ")#mi("{I}")#text(", which makes ")#mi("{I}")#text(" a scalar multiple of the functional that extracts the top coefficient ")#mi("{a_d}")#text(" of a polynomial, thus if one sets a normalisation")

#align(center)[#tao-fit-display[#mitex("I( x \\mapsto x^d ) = c")]]

#text("for some constant ")#mi("{c}")#text(", then one has ")#metadata(none) <tao-cfb18a6205688384cede>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("I( x \\mapsto a_0 + a_1 x + \\ldots + a_d x^d ) = c a_d")]]

#text(" for any polynomial ")#mi("{x \\mapsto a_0 + a_1 x + \\ldots + a_d x^d}")#text(". So we see that up to a normalising constant, the operation of extracting the top order coefficient of a polynomial of fixed degree serves as the analogue of integration. In particular, despite the fact that integration is supposed to be the “opposite” of differentiation (as indicated for instance by ")#link(<tao-c9629fc422c960bf417f>)[#text("(5)")]#text("), we see in this case that integration is basically (")#mi("{d}")#text("-fold) differentiation; indeed, compare ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" with the identity")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dx})^d ( a_0 + a_1 x + \\ldots + a_d x^d ) = d! a_d.")]]

#text("In particular, we see, in contrast to the usual Lebesgue integral, the integration functional ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" can be localised to an arbitrary location: one only needs to know the germ of the polynomial ")#mi("{x \\mapsto a_0 + a_1 x + \\ldots + a_d x^d}")#text(" at a single point ")#mi("{x_0}")#text(" in order to determine the value of the functional ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(". This localisation property may initially seem at odds with the translation invariance, but the two can be reconciled thanks to the extremely rigid nature of the class ")#mi("{Poly_{\\leq d}({\\bf R} \\rightarrow {\\bf C})}")#text(", in contrast to the Schwartz class ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" which admits bump functions and so can generate local phenomena that can only be detected in small regions of the underlying spatial domain, and which therefore forces any translation-invariant integration functional on such function classes to measure the function at every single point in space.")

#text("The reversal of the relationship between integration and differentiation is also reflected in the fact that the abstract integration operation on polynomials interacts with the scaling operation ")#mi("{\\delta_\\lambda f(x) := f(x/\\lambda)}")#text(" in essentially the opposite way from the classical integration operation. Indeed, for classical integration on ")#mi("{{\\bf R}^d}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x/\\lambda)\\ dx = \\lambda^d \\int f(x)\\ dx")]]

#text("for Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d \\rightarrow {\\bf C})}")#text(", and so in this case the integration functional ")#mi("{I(f) := \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" obeys the scaling law")

#align(center)[#tao-fit-display[#mitex("I( \\delta_\\lambda f ) = \\lambda^d I(f).")]]

#text("In contrast, the abstract integration operation defined in ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" obeys the opposite scaling law ")#metadata(none) <tao-1fec96915a08f68e411c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("I( \\delta_\\lambda f ) = \\lambda^{-d} I(f).")]]



#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One way to interpret what is going on is to view the integration operation ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" as a ")#emph[#text("renormalised")]#text(" version of integration. A polynomial ")#mi("{x \\mapsto a_0 + a_1 + \\ldots + a_d x^d}")#text(" is, in general, not absolutely integrable, and the partial integrals")

#align(center)[#tao-fit-display[#mitex("\\int_0^N a_0 + a_1 + \\ldots + a_d x^d\\ dx")]]

#text("diverge as ")#mi("{N \\rightarrow \\infty}")#text(". But if one renormalises these integrals by the factor ")#mi("{\\frac{1}{N^{d+1}}}")#text(", then one recovers convergence,")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N^{d+1}} \\int_0^N a_0 + a_1 + \\ldots + a_d x^d\\ dx = \\frac{1}{d+1} a_d")]]

#text("thus giving an interpretation of ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" as a renormalised classical integral, with the renormalisation being responsible for the unusual scaling relationship in ")#link(<tao-1fec96915a08f68e411c>)[#text("(7)")]#text(". However, this interpretation is a little artificial, and it seems that it is best to view functionals such as ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" from an abstract algebraic perspective, rather than to try to force an analytic interpretation on them.")
]

#text("Now we return to the classical Lebesgue integral ")#metadata(none) <tao-3b4f948671365d6fa8eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("I(f) := \\int_{\\bf R} f(x)\\ dx.")]]

#text(" As noted earlier, this integration functional has a translation invariance associated to translations along the real line ")#mi("{{\\bf R}}")#text(", as well as a dilation invariance by real dilation parameters ")#mi("{\\lambda>0}")#text(". However, if we refine the class ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" of functions somewhat, we can obtain a stronger family of invariances, in which we allow ")#emph[#text("complex")]#text(" translations and dilations. More precisely, let ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(" denote the space of all functions ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" which are entire (or equivalently, are given by a Taylor series with an infinite radius of convergence around the origin) and also admit rapid decay in a sectorial neighbourhood of the real line, or more precisely there exists an ")#mi("{\\epsilon>0}")#text(" such that for every ")#mi("{A > 0}")#text(" there exists ")#mi("{C_A > 0}")#text(" such that one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq C_A (1+\\left|z\\right|)^{-A}", block: true)]]

#text("whenever ")#tao-math("{\\left|\\text{Im}(z)\\right| \\leq A + \\epsilon \\left|\\text{Re}(z)\\right|}", block: false)#text(". For want of a better name, we shall call elements of this space ")#emph[#text("Schwartz entire functions")]#text(". This is clearly a complex vector space. A typical example of a Schwartz entire function are the complex gaussians")

#align(center)[#tao-fit-display[#mitex("f(z) := e^{-\\pi (az^2 + 2bz + c)}")]]

#text("where ")#mi("{a,b,c}")#text(" are complex numbers with ")#mi("{\\text{Re}(a) > 0}")#text(". From the Cauchy integral formula (and its derivatives) we see that if ")#mi("{f}")#text(" lies in ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(", then the restriction of ")#mi("{f}")#text(" to the real line lies in ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text("; conversely, from analytic continuation we see that every function in ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(" has at most one extension in ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(". Thus one can identify ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(" with a subspace of ")#mi("{{\\mathcal S}({\\bf R} \\rightarrow {\\bf C})}")#text(", and in particular the integration functional ")#link(<tao-3b4f948671365d6fa8eb>)[#text("(8)")]#text(" is inherited by ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(", and by abuse of notation we denote the resulting functional ")#mi("{I: \\mathcal{SE}({\\bf C} \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" as ")#mi("{I}")#text(" also. Note, in analogy with the situation with polynomials, that this abstract integration functional is somewhat localised; one only needs to evaluate the function ")#mi("{f}")#text(" on the real line, rather than the entire complex plane, in order to compute ")#mi("{I(f)}")#text(". This is consistent with the rigid nature of Schwartz entire functions, as one can uniquely recover the entire function from its values on the real line by analytic continuation.")

#text("Of course, the functional ")#mi("{I: \\mathcal{SE}({\\bf C} \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" remains translation invariant with respect to real translation:")

#align(center)[#tao-fit-display[#mitex("I(\\tau_h f) = I(f) \\text{ for all } h \\in {\\bf R}.")]]

#text("However, thanks to contour shifting, we now also have translation invariance with respect to complex translation:")

#align(center)[#tao-fit-display[#mitex("I(\\tau_h f) = I(f) \\text{ for all } h \\in {\\bf C},")]]

#text("where of course we continue to define the translation operator ")#mi("{\\tau_h}")#text(" for complex ")#mi("{h}")#text(" by the usual formula ")#mi("{\\tau_h f(x) := f(x-h)}")#text(". In a similar vein, we also have the scaling law")

#align(center)[#tao-fit-display[#mitex("I(\\delta_\\lambda f) = \\lambda I(f)")]]

#text("for any ")#mi("{f \\in \\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(", if ")#mi("{\\lambda}")#text(" is a complex number sufficiently close to ")#mi("{1}")#text(" (where “sufficiently close” depends on ")#mi("{f}")#text(", and more precisely depends on the sectoral aperture parameter ")#mi("{\\epsilon}")#text(" associated to ")#mi("{f}")#text("); again, one can verify that ")#mi("{\\delta_\\lambda f}")#text(" lies in ")#mi("{\\mathcal{SE}({\\bf C} \\rightarrow {\\bf C})}")#text(" for ")#mi("{\\lambda}")#text(" sufficiently close to ")#mi("{1}")#text(". These invariances (which relocalise the integration functional ")#mi("{I}")#text(" onto other contours than the real line ")#mi("{{\\bf R}}")#text(") are very useful for computing integrals, and in particular for computing gaussian integrals. For instance, the complex translation invariance tells us (after shifting by ")#mi("{b/a}")#text(") that")

#align(center)[#tao-fit-display[#mitex("I( z \\mapsto e^{-\\pi (az^2 + 2bz + c) } ) = e^{-\\pi (c-b^2/a)} I( z \\mapsto e^{-\\pi a z^2} )")]]

#text("when ")#mi("{a,b,c \\in {\\bf C}}")#text(" with ")#mi("{\\text{Re}(a) > 0}")#text(", and then an application of the complex scaling law (and a continuity argument, observing that there is a compact path connecting ")#mi("{a}")#text(" to ")#mi("{1}")#text(" in the right half plane) gives")

#align(center)[#tao-fit-display[#mitex("I( z \\mapsto e^{-\\pi (az^2 + 2bz + c) } ) = a^{-1/2} e^{-\\pi (c-b^2/a)} I( z \\mapsto e^{-\\pi z^2} )")]]

#text("using the branch of ")#mi("{a^{-1/2}}")#text(" on the right half-plane for which ")#mi("{1^{-1/2} = 1}")#text(". Using the normalisation ")#link(<tao-733859c1fc6b9331793b>)[#text("(4)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("I( z \\mapsto e^{-\\pi (az^2 + 2bz + c) } ) = a^{-1/2} e^{-\\pi (c-b^2/a)}")]]

#text("giving the usual gaussian integral formula ")#metadata(none) <tao-8e3987644acada3413d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_{\\bf R} e^{-\\pi (ax^2 + 2bx + c)}\\ dx = a^{-1/2} e^{-\\pi (c-b^2/a)}.")]]

#text(" This is a basic illustration of the power that a large symmetry group (in this case, the complex ")#link("http://en.wikipedia.org/wiki/Homothetic_transformation")[#text("homothety group")]#text(") can bring to bear on the task of computing integrals.")

#text("One can extend this sort of analysis to higher dimensions. For any natural number ")#mi("{n \\geq 1}")#text(", let ")#mi("{\\mathcal{SE}({\\bf C}^n \\rightarrow {\\bf C})}")#text(" denote the space of all functions ")#mi("{f: {\\bf C}^n \\rightarrow {\\bf C}}")#text(" which is jointly entire in the sense that ")#mi("{f(z_1,\\ldots,z_n)}")#text(" can be expressed as a Taylor series in ")#mi("{z_1,\\ldots,z_n}")#text(" which is absolutely convergent for all choices of ")#mi("{z_1,\\ldots,z_n}")#text(", and such that there exists an ")#mi("{\\epsilon > 0}")#text(" such that for any ")#mi("{A>0}")#text(" there is ")#mi("{C_A>0}")#text(" for which one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq C_A (1+\\left|z\\right|)^{-A}", block: true)]]

#text("whenever ")#tao-math("{\\left|\\text{Im}(z_j)\\right| \\leq A + \\epsilon \\left|\\text{Re}(z_j)\\right|}", block: false)#text(" for all ")#mi("{1 \\leq j \\leq n}")#text(", where ")#mi("{z = \\begin{pmatrix} z_1 \\\\ \\vdots \\\\ z_n \\end{pmatrix}}")#text(" and ")#tao-math("{\\left|z\\right| := (\\left|z_1\\right|^2+\\ldots+\\left|z_n\\right|^2)^{1/2}}", block: false)#text(". Again, we call such functions Schwartz entire functions; a typical example is the function")

#align(center)[#tao-fit-display[#mitex("f(z) := e^{-\\pi (z^T A z + 2b^T z + c)}")]]

#text("where ")#mi("{A}")#text(" is an ")#mi("{n \\times n}")#text(" complex symmetric matrix with positive definite real part, ")#mi("{b}")#text(" is a vector in ")#mi("{{\\bf C}^n}")#text(", and ")#mi("{c}")#text(" is a complex number. We can then define an abstract integration functional ")#mi("{I: \\mathcal{SE}({\\bf C}^n \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" by integration on the real slice ")#mi("{{\\bf R}^n}")#text(":")

#align(center)[#tao-fit-display[#mitex("I(f) := \\int_{{\\bf R}^n} f(x)\\ dx")]]

#text("where ")#mi("{dx}")#text(" is the usual Lebesgue measure on ")#mi("{{\\bf R}^n}")#text(". By contour shifting in each of the ")#mi("{n}")#text(" variables ")#mi("{z_1,\\ldots,z_n}")#text(" separately, we see that ")#mi("{I}")#text(" is invariant with respect to complex translations of each of the ")#mi("{z_j}")#text(" variables, and is thus invariant under translating the joint variable ")#mi("{z}")#text(" by ")#mi("{{\\bf C}^n}")#text(". One can also verify the scaling law")

#align(center)[#tao-fit-display[#mitex("I(\\delta_A f) = \\text{det}(A) I(f)")]]

#text("for ")#mi("{n \\times n}")#text(" complex matrices ")#mi("{A}")#text(" sufficiently close to the origin, where ")#mi("{\\delta_A f(z) := f(A^{-1} z)}")#text(". This can be seen for shear transformations ")#mi("{A}")#text(" by Fubini’s theorem and the aforementioned translation invariance, while for diagonal transformations near the origin this can be seen from ")#mi("{n}")#text(" applications of one-dimensional scaling law, and the general case then follows by composition. Among other things, these laws then easily lead to the higher-dimensional generalisation ")#metadata(none) <tao-236ab8a4a122e6c35a0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\int_{{\\bf R}^n} e^{-\\pi (x^T A x + 2 b^T x + c)}\\ dx = \\text{det}(A)^{-1/2} e^{-\\pi (c-b^T A^{-1} b)}")]]

#text(" whenever ")#mi("{A}")#text(" is a complex symmetric matrix with positive definite real part, ")#mi("{b}")#text(" is a vector in ")#mi("{{\\bf C}^n}")#text(", and ")#mi("{c}")#text(" is a complex number, basically by repeating the one-dimensional argument sketched earlier. Here, we choose the branch of ")#mi("{\\text{det}(A)^{-1/2}}")#text(" for all matrices ")#mi("{A}")#text(" in the indicated class for which ")#mi("{\\text{det}(1)^{-1/2} = 1}")#text(".")

#text("Now we turn to an integration functional suitable for computing ")#emph[#text("complex")]#text(" gaussian integrals such as ")#metadata(none) <tao-660f5656e3e8f13ca2bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_{{\\bf C}^n} e^{-2\\pi (z^\\dagger A z + b^\\dagger z + z^\\dagger \\tilde b + c)}\\ dz d\\overline{z},")]]

#text(" where ")#mi("{z}")#text(" is now a complex variable")

#align(center)[#tao-fit-display[#mitex("z = \\begin{pmatrix} z_1 \\\\ \\vdots \\\\ z_n \\end{pmatrix},")]]

#mi("{z^\\dagger}")#text(" is the adjoint")

#align(center)[#tao-fit-display[#mitex("z^\\dagger := (\\overline{z_1},\\ldots, \\overline{z_n}),")]]

#mi("{A}")#text(" is a complex ")#mi("{n \\times n}")#text(" matrix with positive definite Hermitian part, ")#mi("{b, \\tilde b}")#text(" are column vectors in ")#mi("{{\\bf C}^n}")#text(", ")#mi("{c}")#text(" is a complex number, and ")#mi("{dz d\\overline{z} = \\prod_{j=1}^n 2 d\\text{Re}(z_j) d\\text{Im}(z_j)}")#text(" is ")#mi("{2^n}")#text(" times Lebesgue measure on ")#mi("{{\\bf C}^n}")#text(". (The factors of two here turn out to be a natural normalisation, but they can be ignored on a first reading.) As we shall see later, such integrals are relevant when performing computations on the Gaussian Unitary Ensemble (GUE) in random matrix theory. Note that the integrand here is not complex analytic due to the presence of the complex conjugates. However, this can be dealt with by the trick of replacing the complex conjugate ")#mi("{\\overline{z}}")#text(" by a variable ")#mi("{z^*}")#text(" which is ")#emph[#text("formally")]#text(" conjugate to ")#mi("{z}")#text(", but which is allowed to vary independently of ")#mi("{z}")#text(". More precisely, let ")#mi("{\\mathcal{SA}({\\bf C}^n \\times {\\bf C}^n \\rightarrow {\\bf C})}")#text(" be the space of all functions ")#mi("{f: (z,z^*) \\mapsto f(z,z^*)}")#text(" of ")#emph[#text("two")]#text(" independent ")#mi("{n}")#text("-tuples")

#align(center)[#tao-fit-display[#mitex("z = \\begin{pmatrix} z_1 \\\\ \\vdots \\\\ z_n \\end{pmatrix}, z^* = \\begin{pmatrix} z_1^* \\\\ \\vdots \\\\ z_n^* \\end{pmatrix}")]]

#text("of complex variables, which is jointly entire in all ")#mi("{2n}")#text(" variables (in the sense defined previously, i.e. there is a joint Taylor series that is absolutely convergent for all independent choices of ")#mi("{z, z^* \\in {\\bf C}^n}")#text("), and such that there is an ")#mi("{\\epsilon>0}")#text(" such that for every ")#mi("{A>0}")#text(" there is ")#mi("{C_A>0}")#text(" such that one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z,z^*)\\right| \\leq C_A (1 + \\left|z\\right|)^{-A}", block: true)]]

#text("whenever ")#tao-math("{\\left|z^* - \\overline{z}\\right| \\leq A + \\epsilon \\left|z\\right|}", block: false)#text(". We will call such functions ")#emph[#text("Schwartz analytic")]#text(". Note that the integrand in ")#link(<tao-660f5656e3e8f13ca2bf>)[#text("(11)")]#text(" is Schwartz analytic when ")#mi("{A}")#text(" has positive definite Hermitian part, if we reinterpret ")#mi("{z^\\dagger}")#text(" as the transpose of ")#mi("{z^*}")#text(" rather than as the adjoint of ")#mi("{z}")#text(" in order to make the integrand entire in ")#mi("{z}")#text(" and ")#mi("{z^*}")#text(". We can then define an abstract integration functional ")#mi("{I: \\mathcal{SA}({\\bf C}^n \\times {\\bf C}^n \\rightarrow {\\bf C}) \\rightarrow {\\bf C}}")#text(" by the formula ")#metadata(none) <tao-38bec86014e3e8545676>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("I(f) := \\int_{{\\bf C}^n} f(z,\\overline{z})\\ dz d\\overline{z},")]]

#text(" thus ")#mi("{I}")#text(" can be localised to the slice ")#mi("{\\{ (z,\\overline{z}): z \\in {\\bf C}^n\\}}")#text(" of ")#mi("{{\\bf C}^n \\times {\\bf C}^n}")#text(" (though, as with previous functionals, one can use contour shifting to relocalise ")#mi("{I}")#text(" to other slices also.) One can also write this integral as")

#align(center)[#tao-fit-display[#mitex("I(f) = 2^n \\int_{{\\bf R}^n \\times {\\bf R}^n} f(x+iy, x-iy)\\ dx dy")]]

#text("and note that the integrand here is a Schwartz entire function on ")#mi("{{\\bf C}^n \\times {\\bf C}^n}")#text(", thus linking the Schwartz analytic integral with the Schwartz entire integral. Using this connection, one can verify that this functional ")#mi("{I}")#text(" is invariant with respect to translating ")#mi("{z}")#text(" and ")#mi("{z^*}")#text(" by ")#emph[#text("independent")]#text(" shifts in ")#mi("{{\\bf C}^n}")#text(" (thus giving a ")#mi("{{\\bf C}^n \\times {\\bf C}^n}")#text(" translation symmetry), and one also has the independent dilation symmetry")

#align(center)[#tao-fit-display[#mitex("I(\\delta_{A,B} f) = \\text{det}(A) \\text{det}(B) I(f)")]]

#text("for ")#mi("{n \\times n}")#text(" complex matrices ")#mi("{A,B}")#text(" that are sufficiently close to the identity, where ")#mi("{\\delta_{A,B} f(z,z^*) := f(A^{-1} z, B^{-1} z^*)}")#text(". Arguing as before, we can then compute ")#link(<tao-660f5656e3e8f13ca2bf>)[#text("(11)")]#text(" as ")#metadata(none) <tao-967763ee7f1606f5df64>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{{\\bf C}^n} e^{-2\\pi (z^\\dagger A z + b^\\dagger z + z^\\dagger \\tilde b + c)}\\ dz d\\overline{z} = \\text{det}(A)^{-1} e^{-2\\pi (c - b^\\dagger A^{-1} \\tilde b)}.")]]



#text("In particular, this gives an integral representation for the determinant-reciprocal ")#mi("{\\text{det}(A)^{-1}}")#text(" of a complex ")#mi("{n \\times n}")#text(" matrix with positive definite Hermitian part, in terms of gaussian expressions in which ")#mi("{A}")#text(" only appears linearly in the exponential:")

#align(center)[#tao-fit-display[#mitex("\\text{det}(A)^{-1} = \\int_{{\\bf C}^n} e^{-2\\pi z^\\dagger A z}\\ dz d\\overline{z}.")]]

#text("This formula is then convenient for computing statistics such as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\text{det}(W_n-E-i\\eta)^{-1}")]]

#text("for random matrices ")#mi("{W_n}")#text(" drawn from the Gaussian Unitary Ensemble (GUE), and some choice of spectral parameter ")#mi("{E+i\\eta}")#text(" with ")#mi("{\\eta>0}")#text("; we review this computation later in this post. By the trick of matrix differentiation of the determinant (as reviewed in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this recent blog post")]#text("), one can also use this method to compute matrix-valued statistics such as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\text{det}(W_n-E-i\\eta)^{-1} (W_n-E-i\\eta)^{-1}.")]]

#text("However, if one restricts attention to classical integrals over real or complex (and in particular, commuting or ")#emph[#text("bosonic")]#text(") variables, it does not seem possible to easily eradicate the negative determinant factors in such calculations, which is unfortunate because many statistics of interest in random matrix theory, such as the expected Stieltjes transform")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\frac{1}{n} \\text{tr} (W_n-E-i\\eta)^{-1},")]]

#text("which is the Stieltjes transform of the density of states. However, it turns out (as I learned recently from Peter Sarnak and Tom Spencer) that it is possible to cancel out these negative determinant factors by balancing the bosonic gaussian integrals with an equal number of ")#emph[#text("fermionic")]#text(" gaussian integrals, in which one integrates over a family of ")#emph[#text("anticommuting")]#text(" variables. These fermionic integrals are closer in spirit to the polynomial integral ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" than to Lebesgue type integrals, and in particular obey a scaling law which is inverse to the Lebesgue scaling (in particular, a linear change of fermionic variables ")#mi("{\\zeta \\mapsto A \\zeta}")#text(" ends up transforming a fermionic integral by ")#mi("{\\text{det}(A)}")#text(" rather than ")#mi("{\\text{det}(A)^{-1}}")#text("), which conveniently cancels out the reciprocal determinants in the previous calculations. Furthermore, one can combine the bosonic and fermionic integrals into a unified integration concept, known as the ")#link("http://en.wikipedia.org/wiki/Berezin_integral")[#text("Berezin integral")]#text(" (or ")#emph[#text("Grassmann integral")]#text("), in which one integrates functions of ")#link("http://en.wikipedia.org/wiki/Super_vector_space")[#text("supervectors")]#text(" (vectors with both bosonic and fermionic components), and is of particular importance in the theory of ")#link("http://en.wikipedia.org/wiki/Supersymmetry")[#text("supersymmetry")]#text(" in physics. (The prefix “super” in physics means, roughly speaking, that the object or concept that the prefix is attached to contains both bosonic and fermionic aspects.) When one applies this unified integration concept to gaussians, this can lead to quite compact and efficient calculations (provided that one is willing to work with “super”-analogues of various concepts in classical linear algebra, such as the ")#link("http://en.wikipedia.org/wiki/Supertrace")[#text("supertrace")]#text(" or ")#link("http://en.wikipedia.org/wiki/Superdeterminant")[#text("superdeterminant")]#text(").")

#text("Abstract integrals of the flavour of ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" arose in quantum field theory, when physicists sought to formally compute integrals of the form ")#metadata(none) <tao-19b9ef9c2557f9b33a8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\int F( x_1, \\ldots, x_n, \\xi_1, \\ldots, \\xi_m )\\ dx_1 \\ldots dx_n d\\xi_1 \\ldots d\\xi_m")]]

#text(" where ")#mi("{x_1,\\ldots,x_n}")#text(" are familiar ")#emph[#text("commuting")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Boson")[#text("bosonic")]#text(") variables (which, in particular, can often be localised to be scalar variables taking values in ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text("), while ")#mi("{\\xi_1,\\ldots,\\xi_m}")#text(" were more exotic ")#emph[#text("anticommuting")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Fermion")[#text("fermionic")]#text(") variables, taking values in some vector space of fermions. (As we shall see shortly, one can formalise these concepts by working in a ")#link("http://en.wikipedia.org/wiki/Supercommutative_algebra")[#text("supercommutative algebra")]#text(".) The integrand ")#mi("{F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)}")#text(" was a formally analytic function of ")#mi("{x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m}")#text(", in that it could be expanded as a (formal, noncommutative) power series in the variables ")#mi("{x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m}")#text(". For functions ")#mi("{F(x_1,\\ldots,x_n)}")#text(" that depend only on bosonic variables, it is certainly possible for such analytic functions to be in the Schwartz class and thus fall under the scope of the classical integral, as discussed previously. However, functions ")#mi("{F(\\xi_1,\\ldots,\\xi_m)}")#text(" that depend on fermionic variables ")#mi("{\\xi_1,\\ldots,\\xi_m}")#text(" behave rather differently. Indeed, a fermonic variable ")#mi("{\\xi}")#text(" must anticommute with itself, so that ")#mi("{\\xi^2 = 0}")#text(". In particular, any power series in ")#mi("{\\xi}")#text(" terminates after the linear term in ")#mi("{\\xi}")#text(", so that a function ")#mi("{F(\\xi)}")#text(" can only be analytic in ")#mi("{\\xi}")#text(" if it is a polynomial of degree at most ")#mi("{1}")#text(" in ")#mi("{\\xi}")#text("; more generally, an analytic function ")#mi("{F(\\xi_1,\\ldots,\\xi_m)}")#text(" of ")#mi("{m}")#text(" fermionic variables ")#mi("{\\xi_1,\\ldots,\\xi_m}")#text(" must be a polynomial of degree at most ")#mi("{m}")#text(", and an analytic function ")#mi("{F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)}")#text(" of ")#mi("{n}")#text(" bosonic and ")#mi("{m}")#text(" fermionic variables can be Schwartz in the bosonic variables but will be polynomial in the fermonic variables. As such, to interpret the integral ")#link(<tao-19b9ef9c2557f9b33a8c>)[#text("(14)")]#text(", one can use classical (Lebesgue) integration (or the variants discussed above for integrating Schwartz entire or Schwartz analytic functions) for the bosonic variables, but must use abstract integrals such as ")#link(<tao-cfb18a6205688384cede>)[#text("(6)")]#text(" for the fermonic variables, leading to the concept of Berezin integration mentioned earlier.")

#text("In this post I would like to set out some of the basic algebraic formalism of Berezin integration, particularly with regards to integration of gaussian-type expressions, and then show how this formalism can be used to perform computations involving GUE (for instance, one can compute the density of states of GUE by this machinery without recourse to the theory of orthogonal polynomials). The use of supersymmetric gaussian integrals to analyse ensembles such as GUE appears in the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=708812")[#text("Efetov")]#text(" (and was also proposed in the slightly earlier works of ")#link("http://www.ams.org/mathscinet-getitem?mr=609853")[#text("Parisi-Sourlas")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=594576")[#text("McKane")]#text(", with a related approach also appearing in the ")#link("http://link.springer.com/article/10.1007%2FBF01319839?LI=true")[#text("work of Wegner")]#text("); the material here is adapted from ")#link("http://www.ams.org/mathscinet-getitem?mr=1843511")[#text("this survey of Mirlin")]#text(", as well as the later papers ")#link("http://www.ams.org/mathscinet-getitem?mr=1942858")[#text("of Disertori-Pinson-Spencer")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2114358")[#text("of Disertori")]#text(".")

#metadata(none) <tao-5ee348c85809656e0a70>

#heading(level: 1)[#strong[#text(" — 1. Grassmann algebra and Berezin integration — ")]]

#text("Berezin integration can be performed on functions defined on the vectors in any ")#link("http://en.wikipedia.org/wiki/Supercommutative_algebra")[#text("supercommutative algebra")]#text(", or even more generally on a ")#link("http://en.wikipedia.org/wiki/Supermanifold")[#text("supermanifold")]#text(", but for the purposes of the applications to random matrix theory discussed here, we will only need to understand Berezin integration for analytic functions ")#mi("{F: \\bigwedge(V)_b^n \\times \\bigwedge(V)_f^m \\rightarrow \\bigwedge(V)}")#text(" of ")#mi("{n}")#text(" bosonic variables and ")#mi("{m}")#text(" fermionic variables.")

#text("We now set up the formal mathematical framework. We will need a space ")#mi("{V}")#text(" of ")#emph[#text("basic fermions")]#text(", which can be taken to be any infinite-dimensional abstract complex vector space. The infinite dimensionality of ")#mi("{V}")#text(" is convenient to avoid certain degeneracies; it may seem dangerous from an analysis perspective to integrate over such spaces, but as we will be performing integration from a purely algebraic viewpoint, this will not be a concern. (Indeed, one could avoid dealing with the individual elements of space ")#mi("{V}")#text(" altogether, and work instead with certain rings of functions on ")#mi("{V}")#text(" (thus treating ")#mi("{V}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Noncommutative_algebraic_geometry")[#text("noncommutative scheme")]#text(", rather than as a set of points), but we will not adopt this viewpoint here.)")

#text("We then form the ")#mi("{k}")#text("-fold exterior powers ")#mi("{\\bigwedge^k(V)}")#text(", which is the universal complex vector space generated by the ")#mi("{k}")#text("-fold wedge products ")#mi("{\\xi_1 \\wedge \\ldots \\wedge \\xi_k}")#text(" of elements ")#mi("{\\xi_1,\\ldots,\\xi_k}")#text(" of ")#mi("{V}")#text(", subject to the requirement that the wedge product ")#mi("{\\wedge}")#text(" is bilinear, and also antisymmetric on elements of ")#mi("{V}")#text(". We then form the exterior algebra ")#mi("{\\bigwedge(V) = \\bigoplus_{k=0}^\\infty \\bigwedge^k(V)}")#text(" of ")#mi("{V}")#text(" as the direct sum of all these exterior powers. If one endows this algebra with the ")#link("http://en.wikipedia.org/wiki/Wedge_product")[#text("wedge product")]#text(" ")#mi("{\\wedge}")#text(", one obtains a complex ")#link("http://en.wikipedia.org/wiki/Algebra_(ring_theory)")[#text("algebra")]#text(", since the wedge product is bilinear and associative. By abuse of notation, we will write the wedge product ")#mi("{\\Phi \\wedge \\Psi}")#text(" simply as ")#mi("{\\Phi \\Psi}")#text(".")

#text("We split ")#mi("{\\bigwedge(V) = \\bigwedge(V)_b + \\bigwedge(V)_f}")#text(" into the space ")#mi("{\\bigwedge(V)_b := \\bigoplus_{k=0}^\\infty \\bigwedge^{2k}(V)}")#text(" of bosons (arising from exterior powers of even order) and the space ")#mi("{\\bigwedge(V)_b := \\bigoplus_{k=0}^\\infty \\bigwedge^{2k+1}(V)}")#text(" of fermions (exterior powers of odd order). Thus, for instance, complex scalars (which make up ")#mi("{\\bigwedge^0(V)}")#text(") are bosons, while elements of ")#mi("{V}")#text(" are fermions (i.e. basic fermions are fermions). We observe that the product of two bosons or two fermions is a boson, while the product of a boson and a fermion is a fermion, which gives ")#mi("{\\bigwedge(V)}")#text(" the structure of a ")#link("http://en.wikipedia.org/wiki/Superalgebra")[#text("superalgebra")]#text(" (i.e. ")#mi("{{\\bf Z}_2}")#text("–")#link("http://en.wikipedia.org/wiki/Graded_algebra")[#text("graded algebra")]#text(", with ")#mi("{\\bigwedge(V)_b}")#text(" and ")#mi("{\\bigwedge(V)_f}")#text(" being the ")#mi("{0}")#text(" and ")#mi("{1}")#text(" graded components).")

#text("Generally speaking, we will try to use Roman symbols such as ")#mi("{x,z}")#text(" to denote bosons, and Greek symbols such as ")#mi("{\\xi,\\zeta}")#text(" to denote fermions; we will also try to use capital Greek symbols (such as ")#mi("{\\Phi, \\Psi}")#text(") to denote combinations of bosons and fermions.")

#text("It is easy to verify (as can be done for instance by using a basis ")#mi("{\\epsilon_1,\\ldots,\\epsilon_n}")#text(" for ")#mi("{V}")#text(", with the attendant basis ")#mi("{\\epsilon_{i_1} \\ldots \\epsilon_{i_k}}")#text(", ")#mi("{i_1 < \\ldots < i_k}")#text(" for ")#mi("{\\bigwedge^k(V)}")#text("), that bosonic elements of ")#mi("{\\bigwedge(V)}")#text(" are central (they commute with both bosons and fermions), while fermionic elements of ")#mi("{\\bigwedge(V)}")#text(" commute with bosonic elements but anticommute with each other. (In other words, the superalgebra ")#mi("{\\bigwedge(V)}")#text(" is ")#link("http://en.wikipedia.org/wiki/Supercommutative_algebra")[#text("supercommutative")]#text(".)")

#text("A fermionic element ")#mi("{\\xi}")#text(" will commute with all bosonic elements and anticommute with fermonic elements, which in particular implies that ")#metadata(none) <tao-e323c389c7991c579639>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\xi \\bigwedge(V) = \\bigwedge(V) \\xi.")]]

#text(" One corollary of this (and the anticommutativity of ")#mi("{\\xi}")#text(" with itself) is that any product in ")#mi("{\\bigwedge(V)}")#text(" which contains two copies of ")#mi("{\\xi}")#text(" will necessarily vanish. Another corollary is that all elements ")#mi("{\\Phi}")#text(" in ")#mi("{\\bigoplus_{k=1}^\\infty \\bigwedge^k(V)}")#text(" are nilpotent, so that ")#mi("{\\Phi^m=0}")#text(" for some ")#mi("{m}")#text(". In particular, every element in ")#mi("{\\bigwedge(V)}")#text(" can be decomposed as the sum of a scalar and a nilpotent (in fact, this decomposition is unique). A further corollary is the fact the algebra ")#mi("{\\bigwedge(V)}")#text(" is locally finitely dimensional, in the sense that every finite collection of elements in ")#mi("{\\bigwedge(V)}")#text(" generates a finite dimensional subalgebra of ")#mi("{\\bigwedge(V)}")#text(". Among other things, this implies that every element ")#mi("{\\Phi}")#text(" of ")#mi("{\\bigwedge(V)}")#text(" can be exponentiated by the usual power series")

#align(center)[#tao-fit-display[#mitex("\\exp(\\Phi) := \\sum_{k=0}^\\infty \\frac{\\Phi^k}{k!}.")]]

#text("Thus, for instance, the exponential of a bosonic element is again a bosonic element, while the exponential of a fermion ")#mi("{\\xi}")#text(" is just a linear function, since ")#mi("{y}")#text(" anticommutes with itself and thus squares to zero:")

#align(center)[#tao-fit-display[#mitex("\\exp(\\xi) = 1+\\xi.")]]

#text("As bosonic elements are central, we also see that we have the usual formula")

#align(center)[#tao-fit-display[#mitex("\\exp(x+\\Phi) = \\exp(x) \\exp(\\Phi) = \\exp(\\Phi) \\exp(x)")]]

#text("whenever ")#mi("{x}")#text(" is bosonic and ")#mi("{\\Phi}")#text(" is an arbitrary element of ")#mi("{\\bigwedge(V)}")#text(".")

#text("We now consider functions ")#mi("{F: \\bigwedge(V)_b^n \\times \\bigwedge(V)_f^m \\rightarrow \\bigwedge(V)}")#text(" of ")#mi("{n}")#text(" bosonic variables ")#mi("{x_1,\\ldots,x_n \\in \\bigwedge(V)_b}")#text(" and ")#mi("{m}")#text(" fermionic variables ")#mi("{\\xi_1,\\ldots,\\xi_m \\in \\bigwedge(V)_f}")#text(". We will abbreviate ")#mi("{\\bigwedge(V)_b^n \\times \\bigwedge(V)_f^m}")#text(" as ")#mi("{\\bigwedge(V)^{(n|m)}}")#text(", and write")

#align(center)[#tao-fit-display[#mitex("x := \\begin{pmatrix} x_1 \\\\ \\vdots \\\\ x_n \\end{pmatrix}; \\quad \\xi := \\begin{pmatrix} \\xi_1 \\\\ \\vdots \\\\ \\xi_m \\end{pmatrix}; \\quad \\Phi := \\begin{pmatrix} x \\\\ \\xi \\end{pmatrix}.")]]

#text("We will restrict attention to functions ")#mi("{F}")#text(" which are ")#emph[#text("strongly analytic")]#text(" in the sense that they can be written as a strongly convergent noncommutative Taylor series in the variables ")#mi("{\\Phi}")#text(" with coefficients in ")#mi("{\\bigwedge(V)}")#text(". By strongly convergence, we mean that for any given choice of ")#mi("{\\Phi \\in \\bigwedge(V)^{(n|m)}}")#text(", all of the terms in the Taylor series lie in a finite dimensional subspace of ")#mi("{\\bigwedge(V)}")#text(", and the series is absolutely convergent in that finite dimensional subspace. (One could consider more relaxed notions of convergence (and thus of analyticity) here, but this strong notion of analyticity is already obeyed by the functions we will care about in applications, namely supercommutative gaussian functions with polynomial weights, so we will not need to consider more general classes of analytic functions here.)")

#text("Let ")#mi("{{\\mathcal A}( \\bigwedge(V)^{(n|m)} )}")#text(" denote the space of strongly analytic functions from ")#mi("{\\bigwedge(V)^{(n|m)}}")#text(" to ")#mi("{\\bigwedge(V)}")#text(". This is clearly a complex algebra, and contains all the polynomials in the variables ")#mi("{\\Phi}")#text(" with coefficients in ")#mi("{\\bigwedge(V)}")#text(", as well as exponentials of such polynomials. It is also translation invariant in all of the variables ")#mi("{\\Phi}")#text(" (this is a variant of the basic fact in real analysis that if a Taylor series has infinite radius of convergence at the origin, then it is also equal to a Taylor series with infinite radius of sequence at any other point). On the other hand, by collecting terms in ")#mi("{\\xi_i}")#text(" for any ")#mi("{1 \\leq i \\leq m}")#text(", we see that any strongly analytic function ")#mi("{F}")#text(" can be written in the form")

#align(center)[#tao-fit-display[#mitex("F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m) = F^{(i)}_{\\emptyset}(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},\\xi_{i+1},\\ldots,\\xi_m) + F^{(i)}_i(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},\\xi_{i+1},\\ldots,\\xi_m) \\xi_i")]]

#text("for some strongly analytic functions ")#mi("{F^{(i)}_\\emptyset, F^{(i)}_i: \\bigwedge(V)^{(n|m-1)} \\rightarrow \\bigwedge(V)}")#text(". In fact, ")#mi("{F^{(i)}_\\emptyset}")#text(" and ")#mi("{F^{(i)}_i}")#text(" are uniquely determined from ")#mi("{F}")#text("; ")#mi("{F^{(i)}_\\emptyset(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{m-1})}")#text(" is necessarily equal to ")#mi("{F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},0,\\xi_{i+1},\\ldots,\\xi_m)}")#text(", and if ")#mi("{F^{(i)}_i}")#text(" were not unique, then on subtraction one could find an element ")#mi("{y \\in \\bigwedge(V)}")#text(" with the property that ")#mi("{y \\xi_i= 0}")#text(" for all ")#mi("{\\xi_i \\in \\bigwedge(V)_f}")#text(", which is not possible because ")#mi("{V}")#text(" is infinite dimensional.")

#text("We then define the (one-dimensional) ")#emph[#text("Berezin integral")]

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi_i")]]

#text("of a strongly analytic function ")#mi("{F \\in {\\mathcal A}(\\bigwedge(V)^{(n|m)})}")#text(" with respect to the ")#mi("{\\xi_i}")#text(" variable by the formula")

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi_i")]]

#align(center)[#tao-fit-display[#mitex(":= \\frac{1}{\\sqrt{2\\pi}} F^{(i)}_i(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},\\xi_{i+1},\\ldots,\\xi_m);")]]

#text("the normalisation factor ")#mi("{\\frac{1}{\\sqrt{2\\pi}}}")#text(" is convenient for gaussian integration calculations, as we shall see later, but can be ignored for now. This is a functional from ")#mi("{{\\mathcal A}(\\bigwedge(V)^{(n|m)})}")#text(" to ")#mi("{{\\mathcal A}(\\bigwedge(V)^{(n|m-1)})}")#text(", which is an abstract integration functional in the sense discussed in the the introduction, because the functional is invariant with respect to translations of the ")#mi("{\\xi_i}")#text(" variable by elements of ")#mi("{\\bigwedge(V)_f}")#text(". It also obeys the scaling law")

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},\\xi_i/\\lambda, \\xi_{i+1},\\ldots,\\xi_n)\\ d\\xi_i")]]

#align(center)[#tao-fit-display[#mitex("= \\lambda^{-1} \\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_{i-1},\\xi_i, \\xi_{i+1},\\ldots,\\xi_n)\\ d\\xi_i")]]

#text("for any invertible bosonic element ")#mi("{\\lambda \\in \\bigwedge(V)_b}")#text(", as follows immediately from the definitions.")

#text("We can iterate the above integration operation. For instance, any ")#mi("{F \\in {\\mathcal A}(\\bigwedge(V)^{(n|m)})}")#text(" can be fully decomposed in terms of the fermionic variables as ")#metadata(none) <tao-dc7d0a9121228df9b3ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m) = \\sum_{1 \\leq i_1 < \\ldots < i_k \\leq m} F^{(1,\\ldots,m)}_{i_1,\\ldots,i_k}(x_1,\\ldots,x_n) \\xi_{i_1} \\ldots \\xi_{i_m}")]]

#text(" where ")#mi("{F_{i_1,\\ldots,i_k}: \\bigwedge(V)_b^n \\rightarrow \\bigwedge(V)}")#text(" are strongly analytic functions of just the bosonic variables ")#mi("{x_1,\\ldots,x_n}")#text(", and the sum ranges over tuples ")#mi("{1 \\leq i_1 < \\ldots< i_k \\leq m}")#text(". We can then define the Berezin integral")

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi")]]

#text("of a strongly analytic function ")#mi("{F \\in {\\mathcal A}(\\bigwedge(V)^{(n|m)} )}")#text(" over all the fermionic variables")

#align(center)[#tao-fit-display[#mitex("\\xi =\\begin{pmatrix} \\xi_1 \\\\ \\vdots \\\\ \\xi_m \\end{pmatrix}")]]

#text("at once, by the formula")

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi = \\frac{1}{(2\\pi)^{m/2}} F^{(1,\\ldots,m)}_{1,\\ldots,m}(x_1,\\ldots,x_n).")]]

#text("This is an abstract integration functional from ")#mi("{{\\mathcal A}(\\bigwedge(V)^{(n|m)})}")#text(" to ")#mi("{{\\mathcal A}(\\bigwedge(V)_b^n)}")#text(" which is invariant under translations of ")#mi("{\\xi}")#text(" by ")#mi("{\\bigwedge(V)_f^m}")#text("; it can also be viewed as the iteration of the one-dimensional integrations by the Fubini-type formula")

#align(center)[#tao-fit-display[#mitex("\\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi")]]

#align(center)[#tao-fit-display[#mitex("= \\int \\ldots \\int F(x_1,\\ldots,x_n,\\xi_1,\\ldots,\\xi_m)\\ d\\xi_m \\ldots d\\xi_1")]]

#text("(note the reversal of the order of integration here). Much as fermions themselves anticommute with each other, one-dimensional Berezin integrals over fermonic variables also anticommute with each other, thus for instance")

#align(center)[#tao-fit-display[#mitex("\\int\\int F(\\xi_1,\\xi_2)\\ d\\xi_1 d\\xi_2 = - \\int\\int F(\\xi_1,\\xi_2)\\ d\\xi_2 d\\xi_1")]]

#text("(compare with integration of differential forms, with ")#mi("{d\\xi_1 \\wedge d\\xi_2 = - d\\xi_2 \\wedge d\\xi_1}")#text("). One also verifies the scaling law")

#align(center)[#tao-fit-display[#mitex("\\int F(x, A^{-1} \\xi)\\ d\\xi = \\text{det}(A)^{-1} \\int F(x,\\xi)\\ d\\xi")]]

#text("for any invertible ")#mi("{m \\times m}")#text(" matrix ")#mi("{A}")#text(" with bosonic entries, which can be verified for instance by first checking it in the case of diagonal matrices, permutation matrices, and shear matrices, and then observing that these generate all the other invertible matrices.")

#text("We can combine integration over fermionic variables with the more familiar integration over bosonic variables. We will focus attention on complex bosonic and fermionic integration rather than real bosonic and fermionic integration, as this will be the integration concept that is relevant for computations involving GUE. Thus, we will now consider strongly analytic functions ")#mi("{F \\in {\\mathcal A}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)})}")#text(" of ")#mi("{2n}")#text(" bosonic variables ")#mi("{z_1,\\ldots,z_n,z^*_1,\\ldots,z^*_n \\in \\bigwedge(V)_b}")#text(" and ")#mi("{2m}")#text(" fermionic variables ")#mi("{\\zeta_1,\\ldots,\\zeta_m,\\zeta_1^*,\\ldots,\\zeta_m^* \\in \\bigwedge(V)_f}")#text(". As previously discussed in the integration of Schwartz analytic functions, we allow the ")#mi("{z^*_i}")#text(" variable to vary independently of the ")#mi("{z_i}")#text(" variable despite being formally being denoted as an adjoint to ")#mi("{z_i}")#text(", and similarly for ")#mi("{\\zeta_j}")#text(" and ")#mi("{\\zeta_j^*}")#text(".")

#text("Observe that a strongly analytic function ")#mi("{F(z,z^*)}")#text(" of purely bosonic variables will have all Taylor coefficients take values in a finite dimensional subspace ")#mi("{W}")#text(" of ")#mi("{\\bigwedge(V)}")#text(" (otherwise it will not be strongly analytic for complex scalar non-zero ")#mi("{z_1,\\ldots,z_n,z_1^*,\\ldots,z_n^*}")#text("). In particular, if we restrict the bosonic variables ")#mi("{z_1,\\ldots,z_n,z_1^*,\\ldots,z_n^*}")#text(" to be complex scalars, then ")#mi("{F(z_1,\\ldots,z_n,z_1^*,\\ldots,z_n^*)}")#text(" takes values in this subspace ")#mi("{W}")#text(" . We then say that ")#mi("{F}")#text(" is ")#emph[#text("Schwartz analytic")]#text(" if the restriction to ")#mi("{{\\bf C}^n \\times {\\bf C}^n}")#text(" lies in ")#mi("{\\mathcal{SA}({\\bf C}^n \\times {\\bf C}^n \\rightarrow W)}")#text(", thus every component of this restriction lies in ")#mi("{\\mathcal{SA}({\\bf C}^n \\times {\\bf C}^n \\rightarrow {\\bf C})}")#text(". Note that this restriction to ")#mi("{{\\bf C}^n \\times {\\bf C}^n}")#text(" is sufficient to recover the values of ")#mi("{F}")#text(" at all other values in ")#mi("{\\bigwedge(V)^n \\times \\bigwedge(V)^n}")#text(", because one can read off all the Taylor coefficients of ")#mi("{F}")#text(" from this restriction. We denote the space of such Schwartz analytic functions as ")#mi("{\\mathcal{SA}(\\bigwedge(V)_b^n \\rightarrow \\bigwedge(V))}")#text(". We then use the functionals ")#link(<tao-38bec86014e3e8545676>)[#text("(12)")]#text(" to define Berezin integration on one or more pairs ")#mi("{z_i, z_i^*}")#text(" of bosonic variables. For instance, the Berezin integral")

#align(center)[#tao-fit-display[#mitex("\\int F(z,z^*)\\ dz_i^* dz_i")]]

#text("will, by definition, be the Lebesgue integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf C} F(z_1,\\ldots,z_{i-1},z_i,z_{i+1},\\ldots,z_n,z_1^*,\\ldots,z_{i-1}^*,\\overline{z_i},z_{i+1}^*,\\ldots,z_n^*)\\ dz_i d\\overline{z_i},")]]

#text("recalling that ")#mi("{dz_i d\\overline{z_i}}")#text(" is ")#mi("{2}")#text(" times Lebesgue measure on the complex plane in the ")#mi("{z_i}")#text(" variable, and similarly")

#align(center)[#tao-fit-display[#mitex("\\int F(z,z^*)\\ dz^* dz")]]

#text("is the quantity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf C}^n} F(z_1,\\ldots,z_n,\\overline{z_1},\\ldots,\\overline{z_n})\\ \\prod_{i=1}^n dz_i d\\overline{z_i}.")]]

#text("One easily verifies that Berezin integration with respect to a single pair ")#mi("{z_i, z_i^*}")#text(" of bosonic variables maps ")#mi("{\\mathcal{SA}(\\bigwedge(V)_b^n \\times \\bigwedge(V)_b^n \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\mathcal{SA}(\\bigwedge(V)_b^{n-1} \\times \\bigwedge(V)_b^{n-1} \\rightarrow \\bigwedge(V))}")#text(", and integration with respect to all the bosonic variables ")#mi("{z, z^*}")#text(" maps ")#mi("{\\mathcal{SA}(\\bigwedge(V)_b^n \\times \\bigwedge(V)_b^n \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\bigwedge(V)}")#text(".")

#text("As discussed in the introduction, a bosonic integral is invariant with respect to independent translations of the ")#mi("{z}")#text(" and ")#mi("{z^*}")#text(" by any complex shifts. It turns out that these integrals are in fact also invariant under independent translations of ")#mi("{z,z^*}")#text(" by arbitrary ")#emph[#text("bosonic")]#text(" shifts. For sake of notation we will just illustrate this in the ")#mi("{n=1}")#text(" case. From the invariance under complex shifts we have")

#align(center)[#tao-fit-display[#mitex("\\int F(z + w,z^* + w^*)\\ dz^* dz = \\int F(z,z^*)\\ dz dz^*")]]

#text("for any complex ")#mi("{w,w^* \\in {\\bf C}}")#text(". But both sides of this equation are entire in both variables ")#mi("{w,w^*}")#text(", so this identity must also hold on the level of (commutative) formal power series. Specialising ")#mi("{w,w^*}")#text(" from formal variables to bosonic variables we obtain the claim. For similar reasons, we have the scaling law")

#align(center)[#tao-fit-display[#mitex("\\int F( A^{-1} z, B^{-1} z^*)\\ dz dz^* = \\text{det}(A) \\text{det}(B) \\int F(z,z^*)\\ dz dz^*")]]

#text("for all invertible ")#mi("{n \\times n}")#text(" matrices ")#mi("{A, B}")#text(" with bosonic entries and scalar part sufficiently close to the identity, because the claim was already shown to be true for complex entries, and both sides are analytic in ")#mi("{A,B}")#text(".")

#text("A function ")#mi("{F \\in {\\mathcal A}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" of ")#mi("{n}")#text(" bosonic and ")#mi("{m}")#text(" fermionic variables ")#mi("{z,\\zeta}")#text(" and their formal adjoints ")#mi("{z^*,\\zeta^*}")#text(" will be called Schwartz analytic if each of its components under the decomposition ")#link(<tao-dc7d0a9121228df9b3ea>)[#text("(16)")]#text(" is Schwartz analytic, and the space of such functions will be denoted ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(". One can then perform Berezin integration with respect to a pair ")#mi("{z_i,z_i^*}")#text(" of bosonic variables by integrating each term in ")#link(<tao-dc7d0a9121228df9b3ea>)[#text("(16)")]#text(" separately; this creates an integration functional from ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n-1|m)} \\times \\bigwedge(V)^{(n-1|m)} \\rightarrow \\bigwedge(V))}")#text(". Similarly, one can integrate out all the bosonic variables at once, creating an integration functional from ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(0|m)} \\times \\bigwedge(V)^{(0|m)} \\rightarrow \\bigwedge(V))}")#text(". Meanwhile, fermionic integration in a pair ")#mi("{\\zeta_i, \\zeta_i^*}")#text(" maps can be verified to map ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m-1)} \\times \\bigwedge(V)^{(n|m-1)} \\rightarrow \\bigwedge(V))}")#text(", and integrating out all pairs at once leads to a functional from ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|0)} \\times \\bigwedge(V)^{(n|0)} \\rightarrow \\bigwedge(V))}")#text(". Finally, one can check that bosonic integration commutes with either fermionic and bosonic integration, and fermionic integration anticommutes with fermionic integration; in particular, integrating a pair of ")#mi("{\\zeta_i, \\zeta_i^*}")#text(" is an operation that commutes with other such operations or with bosonic integration. Because of this, one can now define the full Berezin integral")

#align(center)[#tao-fit-display[#mitex("\\int F(\\Phi,\\Phi^*)\\ d\\Phi^* d\\Phi = \\int F(z,z^*,\\zeta,\\zeta^*)\\ dz^* dz d\\zeta^* d\\zeta")]]

#text("of a Schwartz analytic function ")#mi("{F \\in \\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" by integrating out all the pairs ")#mi("{z_i, z_i^*}")#text(" and ")#mi("{\\zeta_i, \\zeta_i^*}")#text(" (with the order in which these pairs are integrated being irrelevant). This gives an integration functional from ")#mi("{\\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\times \\bigwedge(V)^{(n|m)} \\rightarrow \\bigwedge(V))}")#text(" to ")#mi("{\\bigwedge(V)}")#text(". From the translation invariance properties of the individual bosonic and fermonic integrals, we see that this functional is invariant with respect to independent translations of ")#mi("{\\Phi}")#text(" and ")#mi("{\\Phi^*}")#text(" by elements of ")#mi("{\\bigwedge(V)^{(n|m)}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-5312fb609f60384731fc>#text(" Take ")#mi("{n=m=1}")#text(". If ")#mi("{a,b}")#text(" are bosons with the real scalar part of ")#mi("{a}")#text(" being positive, then the gaussian function")

#align(center)[#tao-fit-display[#mitex("(z,\\zeta) \\mapsto e^{-2\\pi (z^* a z + \\zeta^* b \\zeta)}")]]

#text("can be expanded (using the nilpotent nature of ")#mi("{\\zeta^* b \\zeta}")#text(") as")

#align(center)[#tao-fit-display[#mitex("e^{-2\\pi z^* a z} (1 - 2\\pi \\zeta^* b \\zeta )")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("e^{-2\\pi z^* a z} + 2\\pi b e^{-2\\pi i z^* a z} \\zeta \\zeta^*")]]

#text("and this is a Schwartz analytic function on ")#mi("{\\bigwedge(V)^{(1|1)}}")#text(". Performing the bosonic integrals (using ")#link(<tao-967763ee7f1606f5df64>)[#text("(13)")]#text(") we then get")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi (z^* a z + \\zeta^* b \\zeta)}\\ dz^* dz = a^{-1} + 2\\pi a^{-1} b \\zeta \\zeta^*")]]

#text("and then on performing the fermionic integrals we obtain")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi (z^* a z + \\zeta^* b \\zeta)}\\ dz^* dz d\\zeta^* d\\zeta = a^{-1} b.")]]

#text("If instead one performs the fermionic integral first, one obtains")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi (z^* a z + \\zeta^* b \\zeta)}\\ d\\zeta^* d\\zeta = b e^{-2\\pi i z^* a z},")]]

#text("and then on performing the bosonic integrals one ends up at the same place:")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi (z^* a z + \\zeta^* b \\zeta)}\\ d\\zeta^* d\\zeta dz^* dz = a^{-1} b.")]]

#text("Note how the parameters ")#mi("{a}")#text(" and ")#mi("{b}")#text(" scale in the opposite way in this integral.")
]

#text("We now derive the general scaling law for Berezin integrals")

#align(center)[#tao-fit-display[#mitex("\\int F(\\Phi,\\Phi^*)\\ d\\Phi^* d\\Phi")]]

#text("in which we scale ")#mi("{\\Phi}")#text(" by a matrix that suitably respects the bosonic and fermonic components of ")#mi("{\\Phi}")#text(". More precisely, define an ")#mi("{(n|m) \\times (n|m)}")#text(" ")#link("http://en.wikipedia.org/wiki/Supermatrix")[#text("supermatrix")]#text(" to be a ")#mi("{n+m \\times n+m}")#text(" block matrix of the form")

#align(center)[#tao-fit-display[#mitex("\\Sigma = \\begin{pmatrix} A & \\sigma \\\\ \\rho & B \\end{pmatrix}")]]

#text("where ")#mi("{A = \\Sigma_{bb}}")#text(" is a ")#mi("{n \\times n}")#text(" matrix with bosonic entries, ")#mi("{\\sigma = \\Sigma_{bf}}")#text(" is an ")#mi("{n \\times m}")#text(" matrix with fermionic entries, ")#mi("{\\rho = \\Sigma_{fb}}")#text(" is an ")#mi("{m \\times n}")#text(" matrix with fermionic entries, and ")#mi("{B = \\Sigma_{ff}}")#text(" is an ")#mi("{m \\times m}")#text(" matrix with bosonic entries. Observe that if ")#mi("{\\Phi}")#text(" is an ")#mi("{(n|m)}")#text("-dimensional column supervector and ")#mi("{\\Phi^\\dagger}")#text(" is an ")#mi("{(n|m)}")#text("-dimensional row supervector then")

#align(center)[#tao-fit-display[#mitex("\\Phi^\\dagger \\Sigma \\Phi = z^\\dagger A z + z^\\dagger \\sigma \\zeta + \\zeta^\\dagger \\rho z + \\zeta^\\dagger B \\zeta.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Scaling law)")]#text(" Let ")#mi("{F \\in \\mathcal{SA}(\\bigwedge(V)^{(n|m)} \\rightarrow\\bigwedge(V))}")#text(" be a Schwartz analytic function, and let ")#mi("{\\Sigma}")#text(" be a ")#mi("{(n|m) \\times (n|m)}")#text(" matrix. If the scalar part of ")#mi("{\\Sigma}")#text(" is sufficiently close to the identity (or equivalently, the scalar parts of ")#mi("{A,B}")#text(" are sufficiently close to the identity), then we have")

#align(center)[#tao-fit-display[#mitex("\\int F( \\Sigma^{-1} \\Phi, \\Phi^* )\\ d\\Phi^* \\Phi = \\text{Sdet}(\\Sigma) \\int F( \\Phi, \\Phi^* )\\ d\\Phi^* \\Phi")]]

#text("where ")#mi("{\\text{Sdet}(\\Sigma)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Superdeterminant")[#text("superdeterminant")]#text(" (also known as the ")#emph[#text("Berezinian")]#text(") of ")#mi("{\\Sigma}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Sdet}(\\Sigma) = \\text{det}( A - \\sigma B^{-1} \\rho ) \\text{det}(B)^{-1}")]]

#text("(in particular, this quantity is bosonic).")
]

#text("The formula for the superdeterminant should be compared with the Schur complement formula")

#align(center)[#tao-fit-display[#mitex("\\text{det} \\begin{pmatrix} A & S \\\\ R & B \\end{pmatrix} = \\text{det}( A - S B^{-1} R ) \\text{det}(B)")]]

#text("for ordinary ")#mi("{n+m \\times n+m}")#text(" block matrices (which was discussed in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous blog post")]#text(")")

#emph[#text("Proof:")]#text(" When ")#mi("{\\Sigma}")#text(" is a block-diagonal matrix (so that ")#mi("{\\sigma}")#text(" and ")#mi("{\\rho}")#text(" vanish, and the superdeterminant simplifies to ")#mi("{\\text{det}(A) \\text{det}(B)^{-1}}")#text("), the claim follows from the separate scaling laws for bosonic and fermonic integration obtained previously. When ")#mi("{\\Sigma}")#text(" is a shear matrix (so that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are the identity, and one of ")#mi("{\\sigma,\\rho}")#text(" vanishes, and the superdeterminant simplifies to ")#mi("{1}")#text(") the claim follows from the translation invariance of either the fermonic or bosonic integral (after performing these two integrals in a suitable order). For the general case, we use the factorisation")

#align(center)[#tao-fit-display[#mitex("\\Sigma = \\begin{pmatrix} 1 & \\sigma B^{-1} \\\\ 0 & 1 \\end{pmatrix} \\begin{pmatrix} A-\\sigma B^{-1} \\rho & 0 \\\\ 0 & B \\end{pmatrix} \\begin{pmatrix} 1 & 0 \\\\ B^{-1} \\rho & 1 \\end{pmatrix},")]]

#text("noting that the two shear matrices have superdeterminant ")#mi("{1}")#text(", while the block-diagonal matrix has the same superdeterminant as ")#mi("{\\Sigma}")#text(", to deduce the general case from the two special cases previously mentioned. ")#mi("\\Box")

#text("One consequence of this scaling law (and the nontrivial nature of the Berezin integral) is that one has the mutliplication law")

#align(center)[#tao-fit-display[#mitex("\\text{Sdet}(\\Sigma \\Gamma) = \\text{Sdet}(\\Sigma) \\text{Sdet}(\\Gamma)")]]

#text("for any two supermatrices ")#mi("{\\Sigma,\\Gamma}")#text(", at least if their scalar parts are sufficiently close to the identity. This in turn implies that the superdeterminant is the multiplicative analogue of the ")#link("http://en.wikipedia.org/wiki/Supertrace")[#text("supertrace")]

#align(center)[#tao-fit-display[#mitex("\\text{Str}(\\Sigma) := \\text{tr}(A) - \\text{tr}(B)")]]

#text("in the sense that")

#align(center)[#tao-fit-display[#mitex("\\text{Sdet}(\\exp(\\Sigma)) = \\exp( \\text{Str}(\\Sigma))")]]

#text("for any supermatrix ")#mi("{\\Sigma}")#text(" (at least if its scalar part is sufficiently small). Note also that the supertrace obeys the expected cyclic property")

#align(center)[#tao-fit-display[#mitex("\\text{Str}(\\Sigma \\Gamma ) = \\text{Str}(\\Gamma \\Sigma)")]]

#text("which can also be deduced from the previous identities by matrix differentiation, as indicated in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous post")]#text(".")

#text("By repeating the derivation of ")#link(<tao-967763ee7f1606f5df64>)[#text("(13)")]#text(" (reducing to integrals that are basically higher dimensional versions of Example ")#link(<tao-5312fb609f60384731fc>)[#text("1")]#text("), one has the Grassmann gaussian integral formula ")#metadata(none) <tao-eba504016a2e21d4dca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\int e^{-2\\pi (\\Phi^\\dagger \\Sigma \\Phi + \\Psi^\\dagger \\Phi + \\Phi^\\dagger \\tilde \\Psi + c)}\\ d\\Phi^* d\\Phi = \\text{Sdet}(\\Sigma)^{-1} e^{-2\\pi (c - \\Psi^\\dagger \\Sigma^{-1} \\tilde \\Psi)}")]]

#text(" whenever ")#mi("{\\Sigma}")#text(" is an ")#mi("{(n|m) \\times (n|m)}")#text(" supermatrix whose bosonic part ")#mi("{\\Sigma_{bb}}")#text(" has positive definite scalar Hermitian part, ")#mi("{\\Psi, \\tilde \\Psi}")#text(" are ")#mi("{(n|m)}")#text("-dimensional supervectors, and ")#mi("{c \\in {\\bf C}}")#text(", with ")#mi("{\\Phi^\\dagger}")#text(" being the transpose of ")#mi("{\\Phi^*}")#text(". In particular, one has ")#metadata(none) <tao-0bb0a719492edd3a793f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\int e^{-2\\pi \\Phi^\\dagger \\Sigma \\Phi}\\ d\\Phi^* d\\Phi = \\text{Sdet}(\\Sigma)^{-1}.")]]



#text("We can isolate the bosonic and fermionic special cases of this identity, namely ")#metadata(none) <tao-372149b50ddc8ac078cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\int e^{-2\\pi z^\\dagger A z}\\ dz^* dz = \\text{det}(A)^{-1}")]]

#text(" and ")#metadata(none) <tao-59d89853bbcd996e72a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int e^{-2\\pi \\zeta^\\dagger B \\zeta}\\ d\\zeta^* d\\zeta = \\text{det}(B)")]]

#text(" whenever ")#mi("{A}")#text(", ")#mi("{B}")#text(" are ")#mi("{n \\times n}")#text(" and ")#mi("{m \\times m}")#text(" matrices with bosonic entries respectively. For comparison, we also observe the real fermionic analogue of these identities, namely")

#align(center)[#tao-fit-display[#mitex("\\int e^{-\\pi \\xi^T A \\xi}\\ d\\xi = \\text{Pf}(A)")]]

#text("where the Berezin integral is now over ")#mi("{m}")#text(" fermonic variables ")#mi("{\\xi_1,\\ldots,\\xi_m}")#text(", and ")#mi("{A}")#text(" is an ")#mi("{m \\times m}")#text(" antisymmetric bosonic matrix, with ")#mi("{\\text{Pf}(A)}")#text(" being the ")#link("http://en.wikipedia.org/wiki/Pfaffian")[#text("Pfaffian")]#text(" of ")#mi("{A}")#text(". This can be seen by directly Taylor expanding ")#mi("{e^{-\\pi \\xi^T A \\xi}}")#text(" and isolating the ")#mi("{\\xi_1 \\ldots \\xi_m}")#text(" term. One can then develop a theory of superpfaffians in analogy to that of superdeterminants, which among other things may be helpful for manipulating the Gaussian Orthogonal Ensemble (GOE) (or at least the skew-symmetric analogue of GOE), but we will not do so here.")

#text("As noted in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous blog post")]#text(", one can often start with an identity involving a determinant and apply matrix differentiation to obtain further useful identities. If we start with ")#link(<tao-0bb0a719492edd3a793f>)[#text("(18)")]#text(", replace ")#mi("{\\Sigma}")#text(" by an infinitesimal perturbation ")#mi("{\\Sigma+\\epsilon \\Lambda}")#text(" for an arbitrary ")#mi("{(n|m) \\times (n|m)}")#text(" supermatrix ")#mi("{\\Lambda}")#text(" matrix, and extract the linear component in ")#mi("{\\Lambda}")#text(", one arrives at the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf C}^n} e^{-2\\pi \\Phi^\\dagger \\Sigma \\Phi} (-2\\pi \\Phi^\\dagger \\Lambda \\Phi)\\ d\\Phi^* d\\Phi = - \\text{Sdet}(\\Sigma)^{-1} \\text{Str}(\\Sigma^{-1} \\Lambda).")]]

#text("In particular, if we set ")#mi("{\\Lambda}")#text(" to be the elementary matrix")

#align(center)[#tao-fit-display[#mitex("\\Lambda := \\begin{pmatrix} e_k e_j^\\dagger & 0 \\\\ 0 & 0 \\end{pmatrix}")]]

#text("then we have ")#metadata(none) <tao-cf9226534cf9645e4a54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\frac{((\\Sigma^{-1})_{bb})_{jk}}{\\text{Sdet}(\\Sigma)} = 2\\pi \\int e^{-2\\pi \\Phi^\\dagger \\Sigma \\Phi} z^*_k z_j\\ d\\Phi^* d\\Phi")]]

#text(" and in particular (if we have no fermionic elements) ")#metadata(none) <tao-2e4312b0724b4cfd908f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\frac{((\\Sigma^{-1})_{bb})_{jk}}{\\text{det}(A)} = 2\\pi \\int_{{\\bf C}^n} e^{-2\\pi z^\\dagger A z} z^*_k z_j\\ dz d\\overline{z}")]]



#heading(level: 1)[#strong[#text(" — 2. Application to GUE statistics — ")]]

#text("We now use the above Gaussian integral identities to compute some GUE statistics. These statistics are initially rather complicated looking integrals over ")#mi("{O(n^2)}")#text(" variables, but after some application of the above identities, we can cut the number of variables of integration down to ")#mi("{O(n)}")#text(", and by a further use of these gaussian identities we can reduce this number down to just ")#mi("{O(1)}")#text(", at which point it becomes feasible to obtain asympotics for such integrals by techniques such as the ")#link("http://en.wikipedia.org/wiki/Method_of_steepest_descent")[#text("method of steepest descent")]#text(" (also known as the ")#emph[#text("saddle point method")]#text(").")

#text("To illustrate this general phenomenon, we begin with a simple example which only requires classical (or bosonic) integration.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-07ed400759a0f606a8b5>#text(" Let ")#mi("{W_n}")#text(" be a GUE matrix, thus ")#mi("{W_n = \\frac{1}{\\sqrt{n}} (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" where ")#mi("{\\xi_{ij}}")#text(" has the standard real normal distribution ")#mi("{N(0,1)_{\\bf R}}")#text(" (i.e. density function ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx}")#text(") when ")#mi("{i=j}")#text(", and the standard complex normal distribution ")#mi("{N(0,1)_{\\bf C}}")#text(" (i.e. density function ")#tao-math("{\\frac{1}{\\pi} e^{-\\left|z\\right|^2}\\ dz}", block: false)#text(") when ")#mi("{i \\neq j}")#text(", with ")#mi("{\\xi_{ij}}")#text(" being jointly independent for ")#mi("{i \\geq j}")#text(". Let ")#mi("{E_\\eta := E+i\\eta}")#text(" be a complex number with positive imaginary part ")#mi("{\\eta}")#text(". Then ")#metadata(none) <tao-ef2bee7868007cd42452>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("{\\bf E} \\frac{1}{\\text{det}(W_n - E_\\eta)} = i^n \\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2 - \\frac{2\\pi^2}{n} \\left|z\\right|^4}\\ dz d\\overline{z}.", block: true)]]


]

#emph[#text("Proof:")]#text(" From ")#link(<tao-372149b50ddc8ac078cd>)[#text("(19)")]#text(" (or ")#link(<tao-967763ee7f1606f5df64>)[#text("(13)")]#text(") applied to ")#mi("{i(W_n-E_\\eta)}")#text(" (which has Hermitian part ")#mi("{\\eta}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\text{det}(W_n-E_\\eta)} = i^n \\int_{{\\bf C}^n} e^{-2\\pi i z^\\dagger (W_n-E_\\eta) z}\\ dz d\\overline{z}")]]

#text("and so by Fubini’s theorem (which can be easily justified in view of all the exponential decay in the integrand) we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\frac{1}{\\text{det}(W_n-E_\\eta)}  & = i^n \\int_{{\\bf C}^n} {\\bf E} e^{-2\\pi i z^\\dagger (W_n-E_\\eta) z}\\ dz d\\overline{z}", block: true)



#tao-math(" & = i^n \\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2} {\\bf E} e^{-2\\pi i z^\\dagger W_n z}\\ dz d\\overline{z}.", block: true)
]

#text("Now observe that the top left ")#mi("{e_1^\\dagger W_n e_1}")#text(" coordinate of ")#mi("{W_n}")#text(" is ")#mi("{\\frac{1}{\\sqrt{n}} \\xi_{11}}")#text(", and ")#mi("{\\xi_{11}}")#text(" has the standard normal distribution ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text(". Thus we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} e^{-t e_1^\\dagger W_n e_1}  & = \\frac{1}{\\sqrt{2\\pi}} \\int_{\\bf R} e^{-tx/\\sqrt{n}} e^{-x^2/2}\\ dx", block: true)



#tao-math(" & = e^{t^2/2n}", block: true)
]

#text("for any ")#mi("{t \\in {\\bf C}}")#text(" with non-negative real part, thanks to ")#link(<tao-8e3987644acada3413d5>)[#text("(9)")]#text(". By the unitary invariance of the GUE ensemble ")#mi("{W_n}")#text(", we thus have ")#metadata(none) <tao-3b6a765ede676559e0f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\mathop{\\bf E} e^{-2\\pi i z^\\dagger W_n z} = e^{-2\\pi^2 \\left|z\\right|^4/n}", block: true)]]

#text(" since we can use that invariance to reduce to the case ")#mi("{z=te_1}")#text(", and the claim follows. ")#mi("\\Box")

#text("The right-hand side of ")#link(<tao-ef2bee7868007cd42452>)[#text("(23)")]#text(" is simpler than the left-hand side, as the integration is only over ")#mi("{{\\bf C}^n}")#text(" (as opposed to the ")#mi("{n^2}")#text("-dimensional space of Hermitian matrices), and there are no determinant factors. The integral can be simplified further by the following trick (known to physicists as the ")#link("http://en.wikipedia.org/wiki/Hubbard%E2%80%93Stratonovich_transformation")[#text("Hubbard-Stratonovich transformation")]#text(". As the gaussian ")#mi("{e^{-\\pi x^2}}")#text(" is its own Fourier transform, we have ")#metadata(none) <tao-5e8d7d9574b0b6c3feb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("e^{-\\pi x^2} = \\int_{\\bf R} e^{-\\pi t^2} e^{2\\pi i xt}\\ dt")]]

#text(" for any ")#mi("{x \\in {\\bf R}}")#text(" (and also for ")#mi("{x \\in {\\bf C}}")#text(", by analytic continuation). The point here is that a quadratic exponential in ")#mi("{x}")#text(" can be replaced with a combination of linear exponentials in ")#mi("{x}")#text(". Applying this identity with ")#mi("{x}")#text(" replaced by ")#tao-math("{\\frac{\\sqrt{2\\pi} \\left|z\\right|^2}{\\sqrt{n}}}", block: false)#text(", we conclude that ")#metadata(none) <tao-66b382705bedfa660945>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("e^{-\\frac{2\\pi^2}{n} \\left|z\\right|^4} = \\int_{\\bf R} e^{-\\pi t^2} e^{2\\pi i \\frac{\\sqrt{2\\pi}}{n^{1/2}} t \\left|z\\right|^2}\\ dt,", block: true)]]

#text(" thus replacing a quartic exponential by a combination of quadratic ones. By Fubini’s theorem, the right-hand side of ")#link(<tao-ef2bee7868007cd42452>)[#text("(23)")]#text(" can be written")

#align(center)[#tao-fit-display[#tao-math("i^n \\int_{\\bf R} e^{-\\pi t^2} \\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2} e^{2\\pi i \\frac{\\sqrt{2\\pi}}{n^{1/2}} t \\left|z\\right|^2}\\ dz d\\overline{z} dt.", block: true)]]

#text("Applying ")#link(<tao-236ab8a4a122e6c35a0f>)[#text("(10)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2} e^{2\\pi i \\frac{\\sqrt{2\\pi}}{n^{1/2}} t \\left|z\\right|^2}\\ dz d\\overline{z} = \\frac{1}{(-iE_\\eta - i \\sqrt{\\frac{2\\pi}{n}} t)^n}", block: true)]]

#text("and so ")#link(<tao-ef2bee7868007cd42452>)[#text("(23)")]#text(" simplifies further to")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\frac{1}{\\text{det}(W_n - E_\\eta)} = (-1)^n \\int_{\\bf R} (E_\\eta + \\sqrt{\\frac{2\\pi}{n}} t)^{-n} e^{-\\pi t^2}\\ dt.")]]

#text("We thus see that the expression ")#mi("{{\\bf E} \\frac{1}{\\text{det}(W_n - E_\\eta)}}")#text(" has now been reduced to a one-dimensional integral, which can be estimated by a variety of techniques, such as the ")#link("http://en.wikipedia.org/wiki/Method_of_steepest_descent")[#text("method of steepest descent")]#text(" (also known as the ")#emph[#text("saddle point method")]#text(").")

#text("The equation ")#link(<tao-2e4312b0724b4cfd908f>)[#text("(22)")]#text(" allows one to manipulate components of an inverse ")#mi("{A^{-1}}")#text(" of a matrix, so long as this component is weighted by a reciprocal determinant. For instance, it implies that ")#metadata(none) <tao-15f3b852d2465ae56ff5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\frac{1}{\\text{det}(W_n-E_\\eta)} ((W_n-E_\\eta)^{-1})_{jk} = - 2\\pi i^{n+1} \\int_{{\\bf C}^n} e^{-2\\pi i z^\\dagger (W_n-E_\\eta) z} z^*_k z_j\\ dz d\\overline{z}")]]

#text(" for any ")#mi("{1 \\leq j,k \\leq n}")#text(", and so by repeating the proof of Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("2")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\frac{1}{\\text{det}(W_n - E_\\eta)} ((W_n-E_\\eta)^{-1})_{jk}")]]

#align(center)[#tao-fit-display[#tao-math("= - 2\\pi i^{n+1} \\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2 - \\frac{2\\pi^2}{n} \\left|z\\right|^4} z^*_k z_j\\ dz d\\overline{z}.", block: true)]]

#text("We can use ")#link(<tao-66b382705bedfa660945>)[#text("(26)")]#text(" to write the above expression as")

#align(center)[#tao-fit-display[#tao-math("- 2\\pi i^{n+1} \\int_{\\bf R} e^{-\\pi t^2} \\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2} e^{2\\pi i \\sqrt{\\frac{2\\pi}{n}} t \\left|z\\right|^2} z^*_k z_j\\ dz d\\overline{z} dt.", block: true)]]

#text("By ")#link(<tao-2e4312b0724b4cfd908f>)[#text("(22)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf C}^n} e^{2\\pi i E_\\eta \\left|z\\right|^2} e^{2\\pi i \\sqrt{\\frac{2\\pi}{n}} t \\left|z\\right|^2} z^*_k z_j\\ dz d\\overline{z}= \\frac{1}{2\\pi (-iE_\\eta - i \\sqrt{\\frac{2\\pi}{n}} t)^{n+1}} \\delta_{jk}", block: true)]]

#text("where ")#mi("{\\delta_{jk}}")#text(" is the Kronecker delta function. We thus have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\frac{1}{\\text{det}(W_n - E_\\eta)} ((W_n-E_\\eta)^{-1})_{jk}")]]

#align(center)[#tao-fit-display[#mitex("= -i \\delta_{jk} \\int_{\\bf R} (-E_\\eta - \\sqrt{\\frac{2\\pi}{n}} t)^{-n-1} e^{-\\pi t^2}\\ dt.")]]

#text("By introducing ")#mi("{n}")#text(" fermionic variables ")#mi("{\\zeta_1,\\ldots,\\zeta_n}")#text(" and their formal adjoints ")#mi("{\\zeta_1^*,\\ldots,\\zeta_n^*}")#text(", one can now eliminate the reciprocal determinant. Indeed, from ")#link(<tao-59d89853bbcd996e72a2>)[#text("(20)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\text{det}(W_n-E_\\eta) = i^{-n} \\int e^{-2\\pi i \\zeta^\\dagger (W_n-E_\\eta) \\zeta}\\ d\\zeta^* d\\zeta;")]]

#text("combining this with ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(27)")]#text(" one has ")#metadata(none) <tao-48a22f634ac821029a78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("((W_n-E_\\eta)^{-1})_{jk} = - 2\\pi i \\int e^{-2\\pi i \\Phi^\\dagger (W_n-E_\\eta) \\Phi} z^*_k z_j\\ d\\Phi^* d\\Phi,")]]

#text(" where ")#mi("{\\Phi}")#text(" consists of ")#mi("{n}")#text(" bosonic and ")#mi("{n}")#text(" fermionic variables, and we have abused notation by identifying the ")#mi("{n \\times n}")#text(" matrix ")#mi("{W_n - E_\\eta}")#text(" with the supermatrix")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} W_n - E_\\eta & 0 \\\\ 0 & W_n - E_\\eta \\end{pmatrix}.")]]

#text("Now we compute the expectation")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} e^{-2\\pi i \\Phi^\\dagger W_n \\Phi}.")]]

#text("It is convenient here to realise the Wigner ensemble ")#mi("{W_n}")#text(" as the Hermitian part ")#mi("{W_n = \\frac{G+G^*}{\\sqrt{2n}}}")#text(" of a complex gaussian matrix (with entries being iid copies of ")#mi("{N(0,1)_{\\bf C}}")#text("). Then the above expression is")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi i \\Phi^\\dagger (G +G^*) \\Phi/ \\sqrt{2n}} e^{-\\text{tr}(GG^*)}\\ dG d G^*")]]

#text("where ")#mi("{dG}")#text(" is a suitable Haar measure on the space of complex matrices, normalised so that")

#align(center)[#tao-fit-display[#mitex("\\int e^{-\\text{tr}(GG^*)/2}\\ dG dG^* = 1.")]]

#text("We can expand this as")

#align(center)[#tao-fit-display[#mitex("\\int e^{-2\\pi i \\text{tr}( (G+G^*) ( z z^\\dagger - \\zeta \\zeta^\\dagger) )/\\sqrt{2n} } e^{-\\text{tr}(GG^*)}\\ dG_n,")]]

#text("and rearrange this as")

#align(center)[#tao-fit-display[#mitex("e^{-\\frac{2\\pi^2}{n} \\text{tr}( ( z z^\\dagger - \\zeta \\zeta^\\dagger)^2 ) }")]]

#align(center)[#tao-fit-display[#mitex("\\int e^{-\\text{tr}((G- 2\\pi i ( z z^\\dagger - \\zeta \\zeta^\\dagger) / \\sqrt{2n}) (G^*- 2\\pi i ( z z^\\dagger - \\zeta \\zeta^\\dagger) / \\sqrt{2n})}\\ dG dG^*.")]]

#text("By contour shifting ")#mi("{G}")#text(" and ")#mi("{G^*}")#text(" separately, we see that the integral here is still ")#mi("{1}")#text(". One can also compute that")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( (z z^\\dagger - \\zeta \\zeta^\\dagger)^2 ) = (z^\\dagger z)^2 - (\\zeta^\\dagger \\zeta)^2 + 2(\\zeta^\\dagger z) (z^\\dagger \\zeta)")]]

#text("and so we can write ")#metadata(none) <tao-e900143ac7e3d090462d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("{\\bf E} ((W_n-E_\\eta)^{-1})_{jk}")]]

#text(" as ")#metadata(none) <tao-60ba1dd5d232b0213d4e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("-2\\pi i \\int e^{2\\pi i \\Phi^\\dagger E_\\eta \\Phi} e^{-\\frac{2\\pi^2}{n} ((z^\\dagger z)^2 - (\\zeta^\\dagger \\zeta)^2 + 2(\\zeta^\\dagger z) (z^\\dagger \\zeta))} z^*_k z_j\\ d\\Phi^* d\\Phi.")]]

#text(" To simplify this ")#mi("{O(n)}")#text("-dimensional integral, we use the Hubbard-Stratonovich transformation. From ")#link(<tao-5e8d7d9574b0b6c3feb0>)[#text("(25)")]#text(" (which can be extended by analyticity from complex ")#mi("{x}")#text(" to hosonic ")#mi("{x}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("e^{-\\frac{2\\pi^2}{n} (z^\\dagger z)^2} = \\int_{\\bf R} e^{-\\pi a^2} e^{-2\\pi i a \\sqrt{2\\pi/n} z^\\dagger z}\\ da")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("e^{\\frac{2\\pi^2}{n} (\\zeta^\\dagger \\zeta)^2} = \\int_{\\bf R} e^{-\\pi b^2} e^{2\\pi b \\sqrt{2\\pi/n} \\zeta^\\dagger \\zeta}\\ db")]]

#text("while from ")#link(<tao-eba504016a2e21d4dca1>)[#text("(17)")]#text(" (with ")#mi("{n=0,m=1}")#text(", ")#mi("{\\Sigma=1}")#text(", ")#mi("{c=0}")#text(", ")#mi("{\\Psi^\\dagger = \\sqrt{2\\pi/n} i \\zeta^\\dagger z}")#text(", and ")#mi("{\\tilde \\Psi := \\sqrt{2\\pi/n} i z^\\dagger \\zeta}")#text(") one has")

#align(center)[#tao-fit-display[#mitex("e^{-\\frac{4\\pi^2}{n} (\\zeta^\\dagger z) (z^\\dagger \\zeta)} = \\int e^{-2\\pi (\\rho^* \\rho + \\sqrt{2\\pi/n} i \\zeta^\\dagger z \\rho + \\sqrt{2\\pi/n} i \\rho^* z^\\dagger \\zeta)}\\ d\\rho^* d\\rho")]]

#text("and so the expression ")#link(<tao-60ba1dd5d232b0213d4e>)[#text("(30)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("-2\\pi i \\int e^{-2\\pi i \\Phi^\\dagger E_\\eta \\Phi} e^{-\\pi (a^2+b^2 + 2\\rho^* \\rho)} e^{-2\\pi i \\sqrt{2\\pi/n} \\Phi^\\dagger R_n \\Phi} z^*_k z_j\\ d\\Phi^* d\\Phi da db d\\rho^* d\\rho")]]

#text("where ")#mi("{R_n}")#text(" is the ")#mi("{(n|n) \\times (n|n)}")#text(" supermatrix")

#align(center)[#tao-fit-display[#mitex("R_n := \\begin{pmatrix} a I_n & \\rho^* I_n \\\\ \\rho I_n & ibI_n \\end{pmatrix}")]]

#text("and ")#mi("{I_n}")#text(" is the ")#mi("{n \\times n}")#text(" identity matrix.")

#text("One can perform the ")#mi("{\\Phi, \\Phi^*}")#text(" integrals using ")#link(<tao-cf9226534cf9645e4a54>)[#text("(21)")]#text(", yielding")

#align(center)[#tao-fit-display[#mitex("-i \\int \\frac{ (((E_\\eta - \\sqrt{2\\pi/n} R_n)^{-1})_{bb})_{jk} }{\\text{Sdet}(E_\\eta - \\sqrt{2\\pi/n} R_n)} e^{-\\pi (a^2+b^2 + 2\\rho^* \\rho)}\\ da db d\\rho^* d\\rho.")]]

#text("This expression may look somewhat complicated, but there are now only four variables of integration (two bosonic and two fermionic), and this can be evaluated exactly by a tedious but straightforward computation; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2114358")[#text("this paper of Disertori")]#text(" for details. After evaluating the fermionic integrals and performing some rescalings, one eventually arrives at the exact expression")

#align(center)[#tao-fit-display[#mitex("\\delta_{jk} \\frac{n}{2\\pi} \\int_{{\\bf R}^2} e^{-n(a^2+b^2)/2} \\frac{(E_\\eta - ib)^n}{(E_\\eta-a)^{n+1}} (1 - \\frac{n+1}{n} \\frac{1}{(E_\\eta-a)(E_\\eta-ib)})\\ da db")]]

#text("for ")#link(<tao-e900143ac7e3d090462d>)[#text("(29)")]#text(", which can then be estimated by a (somewhat involved) application of the method of steepest descent; again, see the paper of Disertori for details.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217246")[#strong[#text("La derivación y la integración desde un punto de vista algebraico « Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")]

#text("[…] un reblog de nuestro crack Terry Tao sobre como capturar los conceptos esenciales de la derivación y la […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of humberto triviño")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217259")[#strong[#text("humberto triviño")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("el crearlos en ocasiones podría restringir ciertos aspectos que son inherentes en el mismo espacio, aunque facilite ciertos procesos .")

#text("entiendo la conexión, pero me asalta la duda del manejos de este tipo de invariantes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217291")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#strong[#text("Puzzle Question.")]#text(" Over GF(2) minus and plus are the same. What does this mean for the theories of differentiation and integration over GF(2)?")

#text("Cf. Links to differential logic papers on ")#link("http://inquiryintoinquiry.com/bibliography/")[#text("this bib page")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d78c5e247b7fcbd6450a73414750fefb03c282dd7b435a01935d531382b60f9-0b9347354e02360d3eba0f1f8bbd0205d1685555e3a8d158195c13eb6a503edf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dochunosei")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217334")[#strong[#text("dochunosei")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("Nice post. I have a couple of points/questions, mostly directed at the issue of renormalization for formal integration of polynomials. First, one could make polynomials genuinely integrable by integrating against, say, $e^{-x^2} d x$. This would mean sacrificing translation invariance, but can anything be salvaged from which one could build a corresponding formal algebraic integral? Second, in view of Remark 1 and the application in Sec. 1, is there a connection between the notion of renormalization used here and renormalization groups as used in quantum field theory and statistical mechanics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#text("When weighted against, say, ")#mi("e^{-x^2/2}\\ dx")#text(", the analogue of the condition ")#mi("I(f^{\\prime})=0")#text(" in the above post is now ")#mi("I(f^{\\prime}) = I(xf)")#text(". It is then again true that functionals that obey this law and obey some mild regularity conditions must come from integration against some constant multiple of ")#mi("e^{-x^2/2}\\ dx")#text("; this observation, incidentally, serves as motivation for ")#link("http://en.wikipedia.org/wiki/Stein's_method")[#text("Stein’s method")]#text(" in probability.")

#text("As for the renormalisation here, it is quite a simple one (extracting a mean value of a function at a very large scale) and is not really on the same level of sophistication as renormalisation group theory which deals with self-similarity across multiple scales.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3c19e3c1378e4e42f77be0d4ed44706da50f84349f4a9de186dc91f9638c2b1-1dc76913eda898a74c4afc601c1b17b68466e721835168462273d92296ffc939.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kasper Henriksen")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217410")[#strong[#text("Kasper Henriksen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Next, note that any Schwartz function of mean zero has an antiderivative which is also Schwartz, and so {I} annihilates all mean zero Schwartz functions, and thus must be a scalar multiple of the usual integration functional. Using the normalisation (4), we see that {I} must therefore be the usual integration functional, giving the claimed uniqueness.")
]

#text("But in (4) you have that {I(x\\mapsto \\exp(-\\pi x^2))=1}, so {I} can’t annihilate all mean zero Schwartz functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d78c5e247b7fcbd6450a73414750fefb03c282dd7b435a01935d531382b60f9-0b9347354e02360d3eba0f1f8bbd0205d1685555e3a8d158195c13eb6a503edf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dochunosei")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217414")[#strong[#text("dochunosei")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#text("An unfortunate confusion of terminology: that Gaussian bump has its centre of mass (i.e. the integral of ")#mi("x \\mapsto x \\exp ( - \\pi x^{2})")#text(") at 0, but its total mass (i.e. the integral ")#mi("x \\mapsto \\exp ( - \\pi x^{2})")#text(") is 1. I think that when Prof. Tao wrote “mean zero” he meant “total mass = 0”, not “centre of mass = 0”.")

#emph[#text("[Reworded to reduce confusion – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217487")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#text("When you talk of “bosonic and fermionic quantities”, do you actually mean that we should leave the freedom to consider supercommutative extensions of the ring of scalars itself?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-217490")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#text("Ah, sorry, I overlooked that your functions were ")#mi("\\bigwedge(V)")#text("-valued in the first place…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-218241")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("Is anyone else having trouble with the RSS feed for these posts? This post still hasn’t shown up in my feed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-219626")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2013")])]

#text("Hi Terrence,")

#text("The terminology ” supercommutative algebra” sounds weird. The link to wikipedia you provided deals with ")#mi("\\mathbb{Z}_2")#text("-graded algebra, which Alain Connes used in “non commutative geometry” – you can check for instance ")#link("http://www.alainconnes.org/docs/book94bigpdf.pdf")[#text("http://www.alainconnes.org/docs/book94bigpdf.pdf")]#text(" (page 445). Do we then use supercommutaive algebra for solving noncommutative geometry problems? Rather confusing…")

#text("Thanx")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-219656")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2013")])]

#text("Hi Terry,")

#text("Remark 1 : Error writing the formula of a polynomial.")

#text("Best reagrds,")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-219804")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2013")])]

#text("Error in Remark 1 still there however.")

#text("I guess ")#mi("x \\mapsto a_0+a_1+\\ldots+a_d x_d")#text(" should be corrected to ")#mi("x \\mapsto a_0+a_1x+\\ldots+a_d x^d")#text(".")

#emph[#text("[Oops, that should be fixed now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-517962")[#strong[#text("Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("[…] in the physical literature in order to assign values to otherwise divergent integrals. See also this post for an unrelated abstraction of the integration concept involving integration over supercommutative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58f863a46ea7ac8571a6df7c4e6d092955e84b0dfcdaf4cf41853a9bd664aa9d-8f5fdb6fdd6867f7141a5961d4ced58821ab271c9ae5f84c013488d23d03f3b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward")]], [#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/#comment-673324")[#strong[#text("Edward")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("I think there’s a typo in the definition of the (one-dimensional) Berezin integral of a strongly analytic function w/r/t the ")#mi("\\xi_i")#text(" variable. The RHS shouldn’t be an integral.")

#emph[#text("[Corrected, thanks – T.]")]
]
