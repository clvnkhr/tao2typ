// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/18/spending-symmetry/
// Converted to Typst by tao2typ: "2026-10-14T09:28:42.404377+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Spending symmetry", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Spending symmetry")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/")[#text("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I recently finished the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/11/blog-book.pdf")[#text("first draft")]#text(" of the last of ")#link("https://terrytao.wordpress.com/books/")[#text("my books")]#text(" based on my ")#link("https://terrytao.wordpress.com/2011/")[#text("2011 blog posts")]#text(" (and also my Google buzzes and Google+ posts from that year), entitled “")#link("https://terrytao.wordpress.com/books/spending-symmetry/")[#text("Spending symmetry")]#text("“. The PDF of this draft is available ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/11/blog-book.pdf")[#text("here")]#text(". This is again a rather assorted (and lightly edited) collection of posts (and buzzes, and Google+ posts), though concentrating in the areas of analysis (both standard and nonstandard), logic, and geometry. As always, comments and corrections are welcome.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spending symmetry « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-193918")[#strong[#text("Spending symmetry « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("[…] Spending symmetry. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74972abb3d88166e6defc47848b9f9848243272d5ae9370eb328e5ac872c3b63-b2cf98bc60817888784ec0b87385808800270f9dffde9db1fecf1b1e9a766e32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ju’x")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-193919")[#strong[#text("Ju’x")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("Page 95, line 3 : “similar, actually, to the approach taken in I took to the nullstellensatz in” should be rewritten.")

#emph[#text("[Thanks, this will be done in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dce448d8005819071c4b7dbd87de59da91ed58bfdb05e5487e7e871efc5785f-b266b0f4f9913afa7577b80ca7a53c8d0809b749c3474a6dae04968c9891227a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-193923")[#strong[#text("h")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("May I suggest using hyperlinks for url’s in the pdf file?")

#emph[#text("[Good suggestion; this will be done in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/738ab60216ef7fa7236252e2fc8735d2d932ef86f401304ced2003146f8cbb3b-19c8b885b0b640855e01a645756ffc73d41450328a2b0a3a6acf76132a9f424a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pgiacome")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-193965")[#strong[#text("pgiacome")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("your productivity in terms of papers and book is sometimes scaring")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-194004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("Looks nice. The first chapter “argument from ignorance” describes some inferences that I think are called “")#text("abductive reasoning")#text("“; there is a good Wikipedia article with that title. I tried to hyperlink it but I don’t know if that will work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arnaud")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-194085")[#strong[#text("Arnaud")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Page 47 Line 10 , “thus ")#mi("P")#text("” should be “thus ")#mi("Q")#text("”")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-194325")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Loving re-reading the long blue-eyed islanders post! Possible typo: Is there a minus sign missing on ")#mi("M_{0,1}^-")#text(", around “…From the perspective")#linebreak()#text(" of ")#mi("K_1")#text(", it is possible that one is in the world ")#mi("M_2(M_ {0,1}")#text(", in which ")#mi("I_1")#text(" does not")#linebreak()#text(" have blue eyes…” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-194326")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Never mind – it rendered wrong for me for some reason..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c1841e9864e8b8e9a900d123ff6abf1bb1e35439807a4e0e4d5177143b9eddc-4339250cc422d445b19094d25a70f26fe6ee184b30eb98db9c5bc6b585ff9242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GARRY HERRINGTON")]], [#link("https://terrytao.wordpress.com/2012/11/18/spending-symmetry/#comment-197087")[#strong[#text("GARRY HERRINGTON")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("Thanks Terrence. I enjoy reading your blog and its great to have some posts saved in a convenient form.")

#text("Regards, Garry __________________________________")
]
