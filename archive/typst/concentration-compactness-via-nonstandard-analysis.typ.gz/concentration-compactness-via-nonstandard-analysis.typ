// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T09:05:41.985775+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Concentration compactness via nonstandard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Concentration compactness via nonstandard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the key difficulties in performing analysis in infinite-dimensional function spaces, as opposed to finite-dimensional vector spaces, is that the ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(" no longer holds: a bounded sequence in an infinite-dimensional function space need not have any convergent subsequences (when viewed using the strong topology). To put it another way, the closed unit ball in an infinite-dimensional function space usually fails to be (sequentially) compact.")#linebreak()#text(" As compactness is such a useful property to have in analysis, various tools have been developed over the years to try to salvage some sort of substitute for the compactness property in infinite-dimensional spaces. One of these tools is ")#emph[#text("concentration compactness")]#text(", which was ")#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")[#text("discussed previously on this blog")]#text(". This can be viewed as a compromise between weak compactness (which is true in very general circumstances, but is often too weak for applications) and strong compactness (which would be very useful in applications, but is usually false), in which one obtains convergence in an intermediate sense that involves a group of symmetries acting on the function space in question.")#linebreak()#text(" Concentration compactness is usually stated and proved in the language of standard analysis: epsilons and deltas, limits and supremas, and so forth. In this post, I wanted to note that one could also state and prove the basic foundations of concentration compactness in the framework of nonstandard analysis, in which one now deals with infinitesimals and ultralimits instead of epsilons and ordinary limits. This is a fairly mild change of viewpoint, but I found it to be informative to view this subject from a slightly different perspective. The nonstandard proofs require a fair amount of general machinery to set up, but conversely, once all the machinery is up and running, the proofs become slightly shorter, and can exploit tools from (standard) infinitary analysis, such as orthogonal projections in Hilbert spaces, or the continuous-pure point decomposition of measures. Because of the substantial amount of setup required, nonstandard proofs tend to have significantly more net complexity than their standard counterparts when it comes to basic results (such as those presented in this post), but the gap between the two narrows when the results become more difficult, and for particularly intricate and deep results it can happen that nonstandard proofs end up being simpler overall than their standard analogues, particularly if the nonstandard proof is able to tap the power of some existing mature body of infinitary mathematics (e.g. ergodic theory, measure theory, Hilbert space theory, or topological group theory) which is difficult to directly access in the standard formulation of the argument.")#linebreak()#text(" ")#metadata(none) <tao-9ce367cac326810b6327>

#heading(level: 1)[#strong[#text(" — 1. Weak sequential compactness in a Hilbert space — ")]]

#text("Before turning to concentration compactness, we will warm up with the simpler situation of weak sequential compactness in a Hilbert space. For sake of notation we shall only consider complex Hilbert spaces, although all the discussion here works equally well for real Hilbert spaces.")#linebreak()#text(" Recall that a bounded sequence ")#mi("{x_n}")#text(" of vectors in a Hilbert space ")#mi("{H}")#text(" is said to ")#link("http://en.wikipedia.org/wiki/Weak_convergence_(Hilbert_space)")[#text("converge weakly")]#text(" to a limit ")#mi("{x}")#text(" if one has ")#mi("{\\langle x_n,y\\rangle \\rightarrow \\langle x,y \\rangle}")#text(" for all ")#mi("{y \\in H}")#text(". We have the following basic theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Sequential Banach-Alaoglu theorem)")]#text(" ")#metadata(none) <tao-180e58d2e0d1dbee943a>#text(" Every bounded sequence ")#mi("{x_n}")#text(" of vectors in a Hilbert space ")#mi("{H}")#text(" has a weakly convergent subsequence.")
]

#text("The usual (standard analysis) proof of this theorem runs as follows:")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Sketch) By restricting to the closed span of the ")#mi("{x_n}")#text(", we may assume without loss of generality that ")#mi("{H}")#text(" is separable. Letting ")#mi("{y_1, y_2, \\ldots}")#text(" be a dense subet of ")#mi("{H}")#text(", we may apply the Bolzano-Weierstrass theorem iteratively, followed by the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli diagonalisation argument")]#text(", to find a subsequence ")#mi("{x_{n_j}}")#text(" for which ")#mi("{\\langle x_{n_j}, y_m \\rangle}")#text(" converges to a limit for each ")#mi("{m}")#text(". Using the boundedness of the ")#mi("{x_{n_j}}")#text(" and a density argument, we conclude that ")#mi("{\\langle x_{n_j}, y \\rangle}")#text(" converges to a limit for each ")#mi("{y}")#text("; applying the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem#The_Hilbert_space_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(", the limit takes the form ")#mi("{\\langle x, y \\rangle}")#text(" for some ")#mi("{x}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" However, this proof does not extend easily to the concentration compactness setting, when there is also a group action. For this, we need a more “algorithmic” proof based on the “energy increment method”. We give one such (standard analysis) proof as follows:")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" As ")#mi("{x_n}")#text(" is bounded, we have some bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|x_n\\right\\|^2 \\leq E", block: true)]]

#text("for some finite ")#mi("{E}")#text(". Of course, this bound would persist if we passed from ")#mi("{x_n}")#text(" to a subsequence.")#linebreak()#text(" Suppose for contradiction that no subsequence of ")#mi("{x_n}")#text(" was weakly convergent. In particular, ")#mi("{x_n}")#text(" itself was not weakly convergent, which means that there exists ")#mi("{y_1 \\in H}")#text(" for which ")#mi("{\\langle x_n,y_1\\rangle}")#text(" did not converge. We can take ")#mi("{y_1}")#text(" to be a unit vector. Applying the Bolzano-Weierstrass theorem, we can pass to a subsequence (which, by abuse of notation, we continue to call ")#mi("{x_n}")#text(") in which ")#mi("{\\langle x_n,y_1\\rangle}")#text(" converged to some non-zero limit ")#mi("{c_1}")#text(". We can choose ")#mi("{c_1}")#text(" to be nearly maximal in magnitude among all possible choices of subsequence and of ")#mi("{y_1}")#text("; in particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left|\\langle x_n, y \\rangle\\right| \\leq 2 \\left|c_1\\right|", block: true)]]

#text("(say) for all other choices of unit vector ")#mi("{y}")#text(".")#linebreak()#text(" We may now decompose")

#align(center)[#tao-fit-display[#mitex("x_{n} = c_1 \\phi_1 + x^{\\prime}_{1,n} + w_{1,n}")]]

#text("where ")#mi("{x^{\\prime}_{1,n}}")#text(" is orthogonal to ")#mi("{\\phi_1}")#text(" and ")#mi("{w_{1,n}}")#text(" converges strongly to zero. From Pythagoras theorem we see that ")#mi("{x^{\\prime}_{1,n}}")#text(" asymptotically has strictly less energy than ")#mi("{E}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|x^{\\prime}_{1,n}\\right\\|^2 \\leq E - \\left|c_1\\right|^2.", block: true)]]

#text("If ")#mi("{x^{\\prime}_{1,n}}")#text(" was weakly convergent, then ")#mi("{x_n}")#text(" would be too, so we may assume that it is not weakly convergent. Arguing as before, we may find a unit vector ")#mi("{\\phi_2}")#text(" (which we can take to be orthogonal to ")#mi("{\\phi_1}")#text(") and a constant ")#mi("{c_2}")#text(" such that (after passing to a subsequence, and abusing notation once more) one had a decomposition")

#align(center)[#tao-fit-display[#mitex("x^{\\prime}_{1,n} = c_2 \\phi_2 + x^{\\prime}_{2,n} + w_{2,n}")]]

#text("in which ")#mi("{x^{\\prime}_{2,n}}")#text(" is orthogonal to both ")#mi("{\\phi_1,\\phi_2}")#text(" and ")#mi("{w_{2,n}}")#text(" converges strongly to zero, and such that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left|\\langle x^{\\prime}_{1,n}, y \\rangle\\right| \\leq 2 \\left|c_2\\right|", block: true)]]

#text("for all unit vectors ")#mi("{y}")#text(". From Pythagoras, we have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|x^{\\prime}_{2,n}\\right\\|^2 \\leq E - \\left|c_1\\right|^2 - \\left|c_2\\right|^2.", block: true)]]

#text("We iterate this process to obtain an orthonormal sequence ")#mi("{\\phi_1,\\phi_2,\\ldots}")#text(" and constants ")#mi("{c_1,c_2,\\ldots}")#text(" obeying the Bessel inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^\\infty \\left|c_k\\right|^2 \\leq E", block: true)]]

#text("(which, in particular, implies that the ")#mi("{c_k}")#text(" go to zero as ")#mi("{k \\rightarrow \\infty}")#text(") such that, for each ")#mi("{k}")#text(", one has a subsequence of the ")#mi("{x_n}")#text(" for which one has a decomposition of the form")

#align(center)[#tao-fit-display[#mitex("x_n = \\sum_{i=1}^{k-1} c_i \\phi_i + x^{\\prime}_{k,n} + w_{k,n}")]]

#text("where ")#mi("{w_{k,n}}")#text(" converges strongly to zero, and for which")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left|\\langle x^{\\prime}_{k,n}, y \\rangle\\right| \\leq 2 \\left|c_{k+1}\\right|", block: true)]]

#text("for all unit vectors ")#mi("{y}")#text(". The series ")#mi("{\\sum_{i=1}^\\infty c_i \\phi_i}")#text(" then converges (conditionally in the strong topology) to a limit ")#mi("{x}")#text(", and by diagonalising all the subsequences we obtain a final subsequence ")#mi("{x_{n_j}}")#text(" which converges weakly to ")#mi("{x}")#text(". ")#mi("\\Box")#linebreak()#text(" Now we give a third proof, which is a nonstandard analysis proof that is analogous to the second standard analysis proof given above.")#linebreak()#text(" The basics of nonstandard analysis are reviewed in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post")]#text(" (and see also this ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("later post on ultralimit analysis")]#text(", as well as ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("the most recent post on this topic")]#text("). Very briefly, we will need to fix a non-principal ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" ")#mi("{p \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(" on the natural numbers. Once one fixes this ultrafilter, one can define the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{n \\rightarrow p} x_n}")#text(" of any sequence of standard objects ")#mi("{x_n}")#text(", defined as the equivalence class of all sequences ")#mi("{(y_n)_{n \\in {\\bf N}}}")#text(" such that ")#mi("{\\{ n \\in {\\bf N}: x_n = y_n \\} \\in p}")#text(". We then define the ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" ")#mi("{{}^* X}")#text(" of a standard set ")#mi("{X}")#text(" to be the collection of all ultralimits ")#mi("{\\lim_{n \\rightarrow p} x_n}")#text(" of sequences ")#mi("{x_n}")#text(" in ")#mi("{X}")#text(". We can interpret ")#mi("{{}^* X}")#text(" as the space of all nonstandard elements of ")#mi("{X}")#text(", with the standard space ")#mi("{X}")#text(" being embedded in the nonstandard one ")#mi("{{}^* X}")#text(" by identifying ")#mi("{x}")#text(" with its nonstandard counterpart ")#mi("{{}^* x := \\lim_{n \\rightarrow p} x}")#text(". One can extend all (first-order) structures on ")#mi("{X}")#text(" to ")#mi("{{}^* X}")#text(" in the obvious manner, and a ")#link("http://en.wikipedia.org/wiki/Ultrapower#.C5.81o.C5.9B.27s_theorem")[#text("famous theorem of Los")]#text(" asserts that all first-order sentences that are true about a standard space ")#mi("{X}")#text(", will also be true about the nonstandard space ")#mi("{{}^* X}")#text(". Thus, for instance, the ultrapower ")#mi("{{}^* H}")#text(" of a standard Hilbert space ")#mi("{H}")#text(" over the standard complex numbers ")#mi("{{\\bf C}}")#text(" will be a nonstandard Hilbert space ")#mi("{{}^* H}")#text(" over the nonstandard reals ")#mi("{{}^* {\\bf R}}")#text(" or the nonstandard complex numbers ")#mi("{{}^* {\\bf C}}")#text(". It has a nonstandard inner product ")#mi("{\\langle, \\rangle: {}^* H \\times {}^* H \\rightarrow {}^* {\\bf C}}")#text(" instead of a standard one, which obeys the nonstandard analogue of the Hilbert space axioms. In particular, it is complete in the nonstandard sense: any nonstandard Cauchy sequence ")#mi("{(x_n)_{n \\in {}^* {\\bf N}}}")#text(" of nonstandard vectors ")#mi("{x_n \\in {}^* H}")#text(" indexed by the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(" will converge (again, in the nonstandard sense) to a limit ")#mi("{x \\in {}^* H}")#text(".")#linebreak()#text(" The ultrapower ")#mi("{{}^* H}")#text(" – the space of ultralimits ")#mi("{\\lim_{n \\rightarrow p} x_n}")#text(" of ")#emph[#text("arbitrary")]#text(" sequences ")#mi("{x_n}")#text(" in ")#mi("{H}")#text(" – turns out to be too large and unwieldy to be helpful for us. We will work instead with a more tractable subquotient, defined as follows. Let ")#mi("{O(H)}")#text(" be the space of ultralimits ")#mi("{\\lim_{n \\rightarrow p} x_n}")#text(" of ")#emph[#text("bounded")]#text(" sequences ")#mi("{x_n \\in H}")#text(", and let ")#mi("{o(H)}")#text(" be the space of ultralimits ")#mi("{\\lim_{n \\rightarrow p} x_n}")#text(" of sequences ")#mi("{x_n \\in H}")#text(" that converge to zero. It is clear that ")#mi("{o(H)}")#text(", ")#mi("{O(H)}")#text(" are vector spaces over the ")#emph[#text("standard")]#text(" complex numbers ")#mi("{{\\bf C}}")#text(", with ")#mi("{o(H)}")#text(" being a subspace of ")#mi("{O(H)}")#text(". (The space ")#mi("{o(H)}")#text(" is also known as the ")#link("http://en.wikipedia.org/wiki/Monad_(non-standard_analysis)")[#text("monad")]#text(" of the origin of ")#mi("{H}")#text(".) We define the quotient space ")#mi("{\\tilde H := O(H) / o(H)}")#text(", which is then also a vector space over ")#mi("{{\\bf C}}")#text(". One easily verifies that ")#mi("{H}")#text(" is a subspace of ")#mi("{O(H)}")#text(" that is disjoint from ")#mi("{o(H)}")#text(", so we can embed ")#mi("{H}")#text(" as a subspace of ")#mi("{\\tilde H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" When ")#mi("{H}")#text(" is finite dimensional, the Bolzano-Weierstrass theorem (or more precisely, the ")#emph[#text("proof")]#text(" of this theorem) shows that ")#mi("{H = \\tilde H}")#text(". For infinite-dimensional spaces, though, ")#mi("{\\tilde H}")#text(" is larger than ")#mi("{H}")#text(", basically because there exist bounded sequences in ")#mi("{H}")#text(" with no convergent subsequences. Thus we can view the quotient ")#mi("{\\tilde H/H}")#text(" as measuring the failure of the Bolzano-Weierstrass theorem (a sort of “Bolzano-Weierstrass cohomology”, if you will).")
]

#text("Now we place a Hilbert space structure on ")#mi("{\\tilde H}")#text(". Observe that if ")#mi("{x = \\lim_{n \\rightarrow p} x_n}")#text(" and ")#mi("{y = \\lim_{n \\rightarrow p} y_n}")#text(" are elements of ")#mi("{O(H)}")#text(" (so that ")#mi("{x_n, y_n}")#text(" are bounded), then the nonstandard inner product ")#mi("{\\langle x,y\\rangle = \\lim_{n \\rightarrow p} \\langle x_n,y_n\\rangle}")#text(" is a nonstandard complex number which is bounded (i.e. it it lies in ")#mi("{O({\\bf C})}")#text("). Since ")#mi("{{\\bf C} = O({\\bf C})/o({\\bf C})}")#text(", we can thus extract a ")#emph[#text("standard part")]#text(" ")#mi("{\\text{st}\\langle x,y\\rangle}")#text(", defined as the unique standard complex number such that")

#align(center)[#tao-fit-display[#mitex("\\langle x,y\\rangle = \\text{st}\\langle x,y\\rangle + o(1)")]]

#text("where ")#mi("{o(1)}")#text(" denotes an infinitesimal, i.e. a non-standard quantity whose magnitude is less than any standard positive real ")#mi("{\\varepsilon > 0}")#text(". From the Cauchy-Schwarz inequality we see that if we modify either ")#mi("{x}")#text(" or ")#mi("{y}")#text(" by an element of ")#mi("{o(H)}")#text(", then the standard part ")#mi("{\\text{st}\\langle x,y \\rangle}")#text(" does not change. Thus, we see that the map ")#mi("{x,y \\mapsto \\text{st}\\langle x,y\\rangle}")#text(" on ")#mi("{O(H)}")#text(" descends to a map ")#mi("{x,y \\mapsto \\langle x,y \\rangle}")#text(" on ")#mi("{\\tilde H}")#text(". One easily checks that this map is a standard Hermitian inner product on ")#mi("{\\tilde H}")#text(" that extends the one on the subspace ")#mi("{H}")#text(". (If one prefers to think in terms of commutative diagrams, one can think of the inner product as a bilinear map from the short exact sequence ")#mi("{0 \\rightarrow o(H) \\rightarrow O(H) \\rightarrow \\tilde H \\rightarrow 0}")#text(" to the short exact sequence ")#mi("{0 \\rightarrow o({\\bf C}) \\rightarrow O({\\bf C}) \\rightarrow {\\bf C} \\rightarrow 0}")#text(".) Furthermore, by using the countable saturation (or Bolzano-Weierstrass) property of nonstandard analysis (see ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("previous post")]#text("), we can also show that ")#mi("{\\tilde H}")#text(" is complete with respect to this inner product; thus ")#mi("{\\tilde H}")#text(" is a standard Hilbert space that contains ")#mi("{H}")#text(" as a subspace. (One can view ")#mi("{\\tilde H}")#text(" as a sort of nonstandard completion of ")#mi("{H}")#text(", in a manner somewhat analogous to how the Stone-Cech compactification ")#mi("{\\beta X}")#text(" of a space can be viewed as a topological completion of ")#mi("{X}")#text(". This is of course consistent with the philosophy of ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("the previous post")]#text(".)")#linebreak()#text(" After all this setup, we can now give the third proof of Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(":")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" Let ")#mi("{z := \\lim_{n \\rightarrow p} x_n}")#text(" be the ultralimit of the ")#mi("{x_n}")#text(", then ")#mi("{z}")#text(" is an element of ")#mi("{O(H)}")#text(". Let ")#mi("{\\tilde z}")#text(" be the image of ")#mi("{z}")#text(" in ")#mi("{\\tilde H}")#text(", and let ")#mi("{x}")#text(" be the orthogonal projection of ")#mi("{\\tilde z}")#text(" to ")#mi("{H}")#text(". We claim that a subsequence of ")#mi("{x_n}")#text(" converges weakly to ")#mi("{x}")#text(".")#linebreak()#text(" For any ")#mi("{y \\in H}")#text(", ")#mi("{\\tilde z - x}")#text(" is orthogonal to ")#mi("{y}")#text(", and thus ")#mi("{\\langle z-x, y \\rangle = o(1)}")#text(". In other words, ")#metadata(none) <tao-52c226638d8564a6eb5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lim_{n \\rightarrow p} \\langle x_n, y \\rangle = \\langle x, y \\rangle + o(1)")]]

#text("for all ")#mi("{y \\in H}")#text(". This is already the nonstandard analogue of weak convergence along a subsequence, but we can get to weak convergence itself with only a little more argument. Indeed, from ")#link(<tao-52c226638d8564a6eb5f>)[#text("(1)")]#text(" we can easily construct a subsequence ")#mi("{x_{n_j}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle x_{n_j}, x_i \\rangle - \\langle x, x_i \\rangle\\right| \\leq \\frac{1}{j}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle x_{n_j}, x \\rangle - \\langle x, x \\rangle\\right| \\leq \\frac{1}{j}", block: true)]]

#text("for all ")#mi("{1 \\leq i \\leq j}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("\\lim_{j \\rightarrow \\infty} \\langle x_{n_j}, y \\rangle = \\langle x,y \\rangle")]]

#text("whenever ")#mi("{y}")#text(" is a finite linear combination of the ")#mi("{x_i}")#text(" and ")#mi("{x}")#text(". Applying a density argument using the boundedness of the ")#mi("{x_n}")#text(", this is then true for all ")#mi("{y}")#text(" in the closed span of the ")#mi("{x_i}")#text(" and ")#mi("{x}")#text("; it is also clearly true for ")#mi("{y}")#text(" in the orthogonal complement, and the claim follows. ")#mi("\\Box")#linebreak()#text(" Observe that in contrast with the first two proofs, the third proof gave a “canonical” choice for the subsequence limit ")#mi("{x}")#text(". This is ultimately because the ultrafilter ")#mi("{p}")#text(" already “made all the choices beforehand”, in some sense.")#linebreak()#text(" Observe also that we used the existence of orthogonal projections in Hilbert spaces in the above proof. If one unpacks the usual proof that these projections exist, one will find an energy increment argument that is not dissimilar to that used in the second proof of Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(". Thus we see that the somewhat intricate energy increment argument from that second proof has in some sense been encapsulated into a general-purpose package in the nonstandard setting, namely the existence of orthogonal projections.")

#heading(level: 1)[#strong[#text(" — 2. Concentration compactness for unitary group actions — ")]]

#text("Now we generalise the sequential Banach-Alaoglu theorem to allow for a group of symmetries. The setup is now that of a (standard) complex vector space ")#mi("{H}")#text(", together with a locally compact group ")#mi("{G}")#text(" acting unitarily on ")#mi("{H}")#text(" in a jointly continuous manner, thus the map ")#mi("{(g,x) \\mapsto gx}")#text(" is jointly continuous from ")#mi("{G \\times H}")#text(" to ")#mi("{H}")#text(" (or equivalently, the representation map from ")#mi("{G}")#text(" to ")#mi("{U(H)}")#text(" is continuous if we give ")#mi("{U(H)}")#text(" the strong operator topology). We also assume that ")#mi("{G}")#text(" is a group of ")#emph[#text("dislocations")]#text(", which means that ")#mi("{g_n x}")#text(" converges weakly to zero in ")#mi("{H}")#text(" whenever ")#mi("{x \\in H}")#text(" and ")#mi("{g_n}")#text(" goes to infinity in ")#mi("{G}")#text(" (which means that ")#mi("{g_n}")#text(" eventually escapes any given compact subset of ")#mi("{G}")#text("). A typical example of such a group is the translation action ")#mi("{h: f(\\cdot) \\mapsto f(\\cdot-h)}")#text(" of ")#mi("{{\\bf R}^d}")#text(" on ")#mi("{L^2({\\bf R}^d)}")#text(", another example is the scaling action ")#mi("{\\lambda: f(\\cdot) \\mapsto \\frac{1}{\\lambda^{d/2}} f(\\frac{\\cdot}{\\lambda})}")#text(" of ")#mi("{{\\bf R}^+}")#text(" on ")#mi("{L^2({\\bf R}^d)}")#text(". (One can also combine these two actions to give an action of the semidirect product ")#mi("{{\\bf R}^+ \\ltimes {\\bf R}^d}")#text(" on ")#mi("{L^2({\\bf R}^d)}")#text(".)")#linebreak()#text(" The basic theorem here is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Profile decomposition)")]#text(" ")#metadata(none) <tao-51d1e6a398acbda7e15b>#text(" Let ")#mi("{G, H}")#text(" be as above. Let ")#mi("{x_n}")#text(" be a bounded sequence in ")#mi("{H}")#text(" obeying the energy bound")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|x_n\\right\\|^2 \\leq E.", block: true)]]

#text("Then, after passing to a subsequence, one can find a sequence ")#mi("{\\phi_1, \\phi_2, \\ldots \\in H}")#text(" with the Bessel inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^\\infty \\left\\|\\phi_k\\right\\|^2 \\leq E", block: true)]]

#text("and group elements ")#mi("{g_{k,n} \\in G}")#text(" for ")#mi("{k,n \\in {\\bf N}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("g_{k^{\\prime},n}^{-1} g_{k,n} \\rightarrow \\infty \\text{ as } n \\rightarrow \\infty")]]

#text("whenever ")#mi("{k \\neq k^{\\prime}}")#text(" and ")#mi("{\\phi_k, \\phi_{k^{\\prime}}}")#text(" are non-zero, such that for each ")#mi("{K \\in {\\bf N}}")#text(" one has the decomposition")

#align(center)[#tao-fit-display[#mitex("x_n = \\sum_{k=1}^K g_{k,n} \\phi_k + w_{K,n}")]]

#text("such that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|w_{K,n}\\right\\|^2 \\leq E - \\sum_{k=1}^K \\left\\|\\phi_k\\right\\|^2", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\sup_{g \\in G} \\left|\\langle g^{-1} w_{K,n}, y\\rangle\\right|^2 \\leq \\sum_{k=K+1}^\\infty \\left\\|\\phi_k\\right\\|^2", block: true)]]

#text("for all unit vectors ")#mi("{y}")#text(", and such that ")#mi("{g_{k,n}^{-1} w_{K,n}}")#text(" converges weakly to zero for every ")#mi("{1 \\leq k \\leq K}")#text(".")
]

#text("Note that Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(" is the case when ")#mi("{G}")#text(" is trivial.")#linebreak()#text(" There is a version of the conclusion available in which ")#mi("{K}")#text(" can be taken to be infinite, and also one can generalise ")#mi("{G}")#text(" to be a more general object than a group by modifying the hypotheses somewhat; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1951819")[#text("this paper of Schindler and Tintarev")]#text(". The version with finite ")#mi("{K}")#text(" is slightly more convenient though for applications to nonlinear dispersive and wave equations; see ")#link("http://www.math.ucla.edu/~visan/ClayLectureNotes.pdf")[#text("these lecture notes of Killip and Visan")]#text(" for some applications of this type of decomposition. In order for this theorem to be useful for applications, one needs to exploit some sort of ")#emph[#text("inverse theorem")]#text(" that controls other norms of a vector ")#mi("{w}")#text(" in terms of expressions such as ")#tao-math("{\\sup_{g \\in G} \\left|\\langle gw, y \\rangle\\right|}", block: false)#text("; these theorems tend to require “hard” harmonic analysis and cannot be established purely by such “soft” analysis tools as nonstandard analysis.")#linebreak()#text(" One can adapt the second proof of Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(" to give a standard analysis proof of Theorem ")#link(<tao-51d1e6a398acbda7e15b>)[#text("3")]#text(":")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Sketch) Applying Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(" we can (after passing to a subsequence) find group elements ")#mi("{g_{1,n}}")#text(" such that ")#mi("{g_{1,n}^{-1} x_n}")#text(" converges weakly to a limit ")#mi("{\\phi_1 \\in H}")#text(", which we can choose to be nearly maximal in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi^{\\prime}_1 \\right\\| \\leq 2 \\left\\| \\phi_1 \\right\\|", block: true)]]

#text("(say) whenever ")#mi("{\\phi_1}")#text(" is the weak limit of ")#mi("{g_{n_j}^{-1} x_{n_j}}")#text(" for some subsequence ")#mi("{x_{n_j}}")#text(" and some collection of group elements ")#mi("{g_{n_j}}")#text(". In particular, this implies (from further application of Theorem ")#link(<tao-180e58d2e0d1dbee943a>)[#text("1")]#text(", and an argument by contradiction) that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\sup_{g \\in G} \\left|\\langle g^{-1} x_n, y \\rangle\\right| \\leq 2 \\left\\| \\phi_1 \\right\\|", block: true)]]

#text("for any unit vector ")#mi("{y}")#text(".")#linebreak()#text(" We may now decompose")

#align(center)[#tao-fit-display[#mitex("x_{n} = g_{1,n} \\phi_1 + w_{1,n}")]]

#text("where ")#mi("{g_{1,n}^{-1} w_{1,n}}")#text(" converges weakly to zero. From Pythagoras theorem we see that ")#mi("{w_{1,n}}")#text(" asymptotically has strictly less energy than ")#mi("{E}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|w_{1,n}\\right\\|^2 \\leq E - \\left\\|\\phi_1\\right\\|^2.", block: true)]]

#text("We then repeat the argument, passing to a further subsequence and finding group elements ")#mi("{g_{2,n}}")#text(" such that ")#mi("{g_{2,n}^{-1} w_{1,n}}")#text(" converges weakly to ")#mi("{\\phi_2 \\in H}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\sup_{g \\in G} \\left|\\langle g^{-1} x_{1,n}, y \\rangle\\right| \\leq 2 \\left\\| \\phi_2 \\right\\|", block: true)]]

#text("for any unit vector ")#mi("{y}")#text(".")#linebreak()#text(" Note that ")#mi("{g_{1,n}^{-1} w_{1,n}}")#text(" converges weakly to zero, while ")#mi("{g_{2,n}^{-1} w_{1,n}}")#text(" converges weakly to ")#mi("{\\phi_2}")#text(". If ")#mi("{\\phi_2}")#text(" is non-zero, this implies that ")#mi("{g_{1,n}^{-1} g_{2,n}}")#text(" must go to infinity (otherwise it has a convergent subsequence, and this soon leads to a contradiction).")#linebreak()#text(" If one iterates the above construction and passes to a diagonal subsequence one obtains the claim. ")#mi("\\Box")#linebreak()#text(" Now we give the nonstandard analysis proof. As before, we introduce the short exact sequence of Hilbert spaces:")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow o(H) \\rightarrow O(H) \\rightarrow \\tilde H \\rightarrow 0.")]]

#text("We will also need an analogous short exact sequence of groups")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow o(G) \\rightarrow O(G) \\rightarrow G \\rightarrow 0")]]

#text("where ")#mi("{O(G) \\leq {}^* G}")#text(" is the space of ultralimits ")#mi("{\\lim_{n \\rightarrow p} g_n}")#text(" of sequences ")#mi("{g_n}")#text(" in ")#mi("{G}")#text(" that lie in a compact subset of ")#mi("{G}")#text(", and ")#mi("{o(G) \\leq O(G)}")#text(" is the space of ultralimits of ")#mi("{\\lim_{n \\rightarrow p} g_n}")#text(" of sequences ")#mi("{g_n}")#text(" that converge to the identity element (i.e. ")#mi("{o(G)}")#text(" is the monad of the group identity). One easily verifies that ")#mi("{o(G)}")#text(" is a normal subgroup of ")#mi("{O(G)}")#text(", and that the quotient is isomorphic to ")#mi("{G}")#text(". (Indeed, ")#mi("{O(G)}")#text(" can be expressed as a semi-direct product ")#mi("{G \\ltimes o(G)}")#text(", though we will not need this fact here.)")#linebreak()#text(" The group ")#mi("{{}^* G}")#text(" acts unitarily on ")#mi("{{}^* H}")#text(", and so preserves both ")#mi("{o(H)}")#text(" and ")#mi("{O(H)}")#text(". As such, it also acts unitarily on ")#mi("{\\tilde H}")#text(". The induced action of the subgroup ")#mi("{o(G)}")#text(" is trivial; and the induced action of the subgroup ")#mi("{O(G)}")#text(" preserves ")#mi("{H}")#text(".")#linebreak()#text(" Let ")#mi("{\\langle ({}^* G) H \\rangle}")#text(" be the closed span of the set ")#mi("{\\{ gx: g \\in {}^* G; h \\in H \\}}")#text(" in ")#mi("{\\tilde H}")#text("; this is a Hilbert space. Inside this space we have the subspaces ")#mi("{gH}")#text(" for ")#mi("{g \\in {}^* G}")#text(". As ")#mi("{O(G)}")#text(" preserves ")#mi("{H}")#text(", we see that ")#mi("{gH = g^{\\prime}H}")#text(" whenever ")#mi("{g, g^{\\prime}}")#text(" lie in the same coset of ")#mi("{O(G)}")#text(", so we can define ")#mi("{\\gamma H}")#text(" for any ")#mi("{\\gamma \\in {}^* G / O(G)}")#text(" in a well-defined manner. On the other hand, if ")#mi("{g, g^{\\prime}}")#text(" do not lie in the same coset of ")#mi("{O(G)}")#text(", then we have ")#mi("{g^{\\prime} = g \\lim_{n \\rightarrow p} h_n}")#text(" for some sequence ")#mi("{h_n}")#text(" in ")#mi("{G}")#text(" that goes to infinity. As ")#mi("{G}")#text(" is a group of dislocations, we conclude that ")#mi("{g^{\\prime} H}")#text(" and ")#mi("{gH}")#text(" are now orthogonal. In other words, ")#mi("{\\gamma^{\\prime} H}")#text(" and ")#mi("{\\gamma H}")#text(" are orthogonal whenever ")#mi("{\\gamma, \\gamma^{\\prime} \\in {}^* G / O(G)}")#text(" are distinct. We conclude that we have the decomposition ")#metadata(none) <tao-18eae2639da621527142>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle ({}^* G) H \\rangle = \\bigoplus_{\\gamma \\in {}^* G/O(G)} \\gamma H")]]

#text("where ")#mi("{\\bigoplus}")#text(" is the Hilbert space direct sum.")#linebreak()#text(" Now we can prove Theorem ")#link(<tao-51d1e6a398acbda7e15b>)[#text("3")]#text(". As in the previous section, starting with a bounded sequence ")#mi("{x_n}")#text(" in ")#mi("{H}")#text(", we form the ultralimit ")#mi("{z := \\lim_{n \\rightarrow p} x_n \\in O(H)}")#text(" and the image ")#mi("{\\tilde z \\in \\tilde H}")#text(". We let ")#mi("{x}")#text(" be the orthogonal projection of ")#mi("{\\tilde z}")#text(" to ")#mi("{\\langle ({}^* G) H \\rangle}")#text(". By ")#link(<tao-18eae2639da621527142>)[#text("(2)")]#text(", we can write")

#align(center)[#tao-fit-display[#mitex("x = \\sum_k g_k \\phi_k")]]

#text("for some at most countable sequence of vectors ")#mi("{\\phi_k \\in H}")#text(" and ")#mi("{g_k \\in {}^* G}")#text(", with the ")#mi("{g_n}")#text(" lying in distinct cosets of ")#mi("{O(G)}")#text(". In particular, for any ")#mi("{k \\neq k^{\\prime}}")#text(", ")#mi("{g_{k^{\\prime}}^{-1} g_k}")#text(" is the ultralimit of a sequence of vectors going to infinity. By adding dummy values of ")#mi("{g_k,\\phi_k}")#text(" if necessary we may assume that ")#mi("{k}")#text(" ranges from ")#mi("{1}")#text(" to infinity. Also, one has the Bessel inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_k \\left\\| \\phi_k\\right\\|^2 = \\left\\|x\\right\\|^2 \\leq \\left\\|z\\right\\|^2 \\leq E", block: true)]]

#text("and from Cauchy-Schwarz and Bessel one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle z-\\sum_{k=1}^K g_k \\phi_k, g y \\rangle\\right| \\leq \\sum_{k=K+1}^\\infty \\left\\|\\phi_k\\right\\|^2.", block: true)]]

#text("for any unit vector ")#mi("{y \\in H}")#text(" and ")#mi("{g \\in G}")#text(". From this we can obtain the required conclusions by arguing as in the previous section.")

#heading(level: 1)[#strong[#text(" — 3. Concentration compactness for measures — ")]]

#text("We now give a variant of the profile decomposition, for Borel probability measures ")#mi("{\\mu_n}")#text(" on ")#mi("{{\\bf R}^d}")#text(". Recall that such a sequence is said to be ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there is a ball ")#mi("{B(0,R)}")#text(" such that ")#mi("{\\limsup_{n \\rightarrow \\infty} \\mu_n({\\bf R}^d \\backslash B(0,R)) \\leq \\varepsilon}")#text(". Given any Borel probability measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^d}")#text(" and any ")#mi("{x \\in {\\bf R}^d}")#text(", define the translate ")#mi("{\\tau_x \\mu}")#text(" to be the Borel probability measure given by the formula ")#mi("{\\tau_x \\mu(E) := \\mu(E-x)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Profile decomposition for probability measures on ")#mi("{{\\bf R}^d}")#text(")")]#text(" Let ")#mi("{\\mu_n}")#text(" be a sequence of Borel probability measures on ")#mi("{{\\bf R}^d}")#text(". Then, after passing to a subsequence, one can find a sequence ")#mi("{c_k}")#text(" of non-negative real numbers with ")#mi("{\\sum_k c_k \\leq 1}")#text(", a tight sequence ")#mi("{\\nu_{k,n}}")#text(" of positive measures whose mass converges to ")#mi("{1}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{k}")#text(", and shifts ")#mi("{x_{k,n} \\in {\\bf R}^d}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("x_{k,n} - x_{k^{\\prime},n} \\rightarrow \\infty \\text{ as } n \\rightarrow \\infty")]]

#text("for all ")#mi("{k \\neq k^{\\prime}}")#text(", and such that for each ")#mi("{K}")#text(", one has the decomposition")

#align(center)[#tao-fit-display[#mitex("\\mu_n = \\sum_{k=1}^K c_k \\tau_{k,n} \\nu_{k,n} + \\rho_{K,n}")]]

#text("where the error ")#mi("{\\rho_{K,n}}")#text(" obeys the bounds")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\sup_{x \\in {\\bf R}^d} \\rho_{K,n}( B(x,R) ) \\leq \\sup_{k \\geq K} c_k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\rho_{K,n}( B(x_{k,n},R) ) = 0")]]

#text("for all radii ")#mi("{R}")#text(" and ")#mi("{1 \\leq k \\leq K}")#text(".")#linebreak()#text(" Furthermore, one can ensure that for each ")#mi("{k}")#text(", ")#mi("{\\nu_{k,n}}")#text(" converges in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to a probability measure ")#mi("{\\nu_k}")#text(".")
]

#text("We first give the standard proof of this theorem:")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Sketch) Suppose first that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\sup_{x \\in {\\bf R}^d} \\mu_n(B(x,R)) = 0")]]

#text("for all ")#mi("{R}")#text(". Then we are done by setting all the ")#mi("{c_k}")#text(" equal to zero, and ")#mi("{\\rho_{K,n} = \\mu_n}")#text(". So we may assume that we can find ")#mi("{R}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\sup_{x \\in {\\bf R}^d} \\mu_n(B(x,R)) = \\alpha")]]

#text("for some ")#mi("{\\alpha > 0}")#text("; we may also assume that ")#mi("{\\alpha}")#text(" is approximately maximal in the sense that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\sup_{x \\in {\\bf R}^d} \\mu_n(B(x,R^{\\prime})) \\leq 2\\alpha")]]

#text("(say) for all other radii ")#mi("{R^{\\prime}}")#text(". By passing to a subsequence, we may thus find ")#mi("{x_{1,n} \\in {\\bf R}^d}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mu_n(B(x_{1,n},R)) = \\alpha;")]]

#text("By passing to a further subsequence using the Helly selection principle (or the sequential Banach-Alaoglu theorem), we may assume that the translates ")#mi("{\\tau_{-x_{1,n}} \\mu_n}")#text(" converge in the vague topology to a limit of total mass at most ")#mi("{1}")#text(" and at least ")#mi("{\\alpha}")#text(", and which can be expressed as ")#mi("{c_1 \\nu_1}")#text(" for some ")#mi("{c_1 \\geq \\alpha}")#text(" and a probability measure ")#mi("{\\nu_1}")#text(".")#linebreak()#text(" As ")#mi("{\\tau_{-x_{1,n}} \\mu_n}")#text(" converges vaguely to ")#mi("{c_1 \\nu_1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\tau_{-x_{1,n}} \\mu_n( B( 0,R^{\\prime}) \\backslash B(0,R) ) \\leq c_1 \\nu_1( {\\bf R}^d \\backslash B(0,R/2) )")]]

#text("for any ")#mi("{0 < R < R^{\\prime}}")#text(". By making ")#mi("{R^{\\prime}_n}")#text(" grow sufficiently slowly to infinity with respect to ")#mi("{n}")#text(", we may thus ensure that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\tau_{-x_{1,n}} \\mu_n( B( 0,R^{\\prime}_n) \\backslash B(0,R) ) \\leq c_1 \\nu_1( {\\bf R}^d \\backslash B(0,R/2) )")]]

#text("for all integers ")#mi("{R>0}")#text(". If we then set ")#mi("{c_1 \\tilde \\nu_{1,n}}")#text(" to be the restriction of ")#mi("{\\tau_{-x_{1,n}} \\mu_n}")#text(" to ")#mi("{B(0,R^{\\prime}_n)}")#text(", we see that ")#mi("{\\tilde \\nu_{1,n}}")#text(" is tight, converges vaguely to ")#mi("{\\nu_{1,n}}")#text(", and has total mass converging to ")#mi("{1}")#text(". We can thus split")

#align(center)[#tao-fit-display[#mitex("\\mu_n = c_1 \\tau_{x_{1,n}} \\tilde \\nu_{1,n} + \\rho_{1,n}")]]

#text("for some residual positive measure ")#mi("{\\rho_{1,n}}")#text(" of total mass converging to ")#mi("{1-c_1}")#text(", and such that ")#mi("{\\rho_{1,n}(B(x_{1,n},R)) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{R}")#text(". We can then iterate this procedure to obtain the claims of the theorem (after one last diagonalisation to combine together all the subsequences). ")#mi("\\Box")#linebreak()#text(" Now we give the nonstandard proof. We take the ultralimit ")#mi("{\\mu := \\lim_{n \\rightarrow p} \\mu_n}")#text(" of the standard Borel probability measures ")#mi("{\\mu_n}")#text(" on ")#mi("{{\\bf R}^d}")#text(", resulting in a nonstandard Borel probability measure. What, exactly, is a nonstandard Borel probability measure? A standard Borel probability measure, such as ")#mi("{\\mu_n}")#text(", is a map ")#mi("{\\mu_n: {\\mathcal B} \\rightarrow [0,1]}")#text(" from the standard Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" to the unit interval ")#mi("{[0,1]}")#text(" which is countably additive and maps ")#mi("{{\\bf R}^n}")#text(" to ")#mi("{1}")#text(". Thus, the nonstandard Borel probability measure is a nonstandard map ")#mi("{\\mu: {}^* {\\mathcal B} \\rightarrow {}^* [0,1]}")#text(" from the nonstandard Borel ")#mi("{\\sigma}")#text("-algebra (the collection of all ultralimits of standard Borel sets) to the nonstandard interval ")#mi("{{}^* [0,1]}")#text(" which is nonstandardly countably additive and maps ")#mi("{{}^* {\\bf R}^n}")#text(" to ")#mi("{1}")#text(". In particular, it is finitely additive.")#linebreak()#text(" There is an important subtlety here. The nonstandard Borel ")#mi("{\\sigma}")#text("-algebra is closed under nonstandard countable unions: if ")#mi("{(E_n)_{n \\in {}^* {\\bf N}}}")#text(" is a nonstandard countable sequence of nonstandard Borel sets (i.e. an ultralimit of standard countable sequences ")#mi("{(E_{n,m})_{n \\in {\\bf N}}}")#text(" of standard Borel sets), then ")#mi("{\\bigcup_n E_n}")#text(" is also nonstandard Borel, but this is not necessarily the case for external countable unions, thus if ")#mi("{(E_n)_{n \\in {\\bf N}}}")#text(" is an external countable sequence of nonstandard Borel sets, then ")#mi("{\\bigcup_n E_n}")#text(" need not be nonstandard Borel. On the other hand, ")#mi("{{\\mathcal B}}")#text(" is certainly still closed under finite unions and other finite Boolean operations, so it can be viewed (externally) as a Boolean algebra, at least.")#linebreak()#text(" Now we perform the Loeb measure construction (which was also introduced in ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("the previous post")]#text("). Consider the standard part ")#mi("{\\text{st}(\\mu)}")#text(" of ")#mi("{\\mu}")#text("; this is a finitely additive map from ")#mi("{{}^* {\\mathcal B}}")#text(" to ")#mi("{[0,1]}")#text(". From the countable saturation property, one can verify that this map is a premeasure, and so (by the ")#link("http://en.wikipedia.org/wiki/Hahn%E2%80%93Kolmogorov_theorem")[#text("Hahn-Kolmogorov theorem")]#text(") extends to a countably additive probability measure ")#mi("{\\tilde \\mu}")#text(" on the measure-theoretic completion ")#mi("{\\tilde {\\mathcal B} := \\overline{\\langle {}^* {\\mathcal B} \\rangle}}")#text(" of ")#mi("{{}^* {\\mathcal B}}")#text(".")#linebreak()#text(" The measure ")#mi("{\\tilde \\mu}")#text(" is a measure on ")#mi("{{}^* {\\bf R}^d}")#text(". We push it forward to the quotient space ")#mi("{{}^* {\\bf R}^d/O({\\bf R}^d)}")#text(" by the obvious quotient map ")#mi("{\\pi: {}^* {\\bf R}^d \\rightarrow {}^* {\\bf R}^d/O({\\bf R}^d)}")#text(" to obtain a pushforward measure ")#mi("{\\pi_* \\tilde \\mu}")#text(" on the pushforward ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\pi_* \\tilde {\\mathcal B}}")#text(", which consists of all (external) subsets ")#mi("{E}")#text(" of ")#mi("{{}^* {\\bf R}^d/O({\\bf R}^d)}")#text(" whose preimage ")#mi("{\\pi^{-1}(E)}")#text(" is measurable in ")#mi("{\\tilde {\\mathcal B}}")#text(".")#linebreak()#text(" We claim that every point in ")#mi("{{}^* {\\bf R}^d/O({\\bf R}^d)}")#text(" is measurable in ")#mi("{\\pi_* \\tilde {\\mathcal B}}")#text(", or equivalently that every coset ")#mi("{x+O({\\bf R}^d)}")#text(" in ")#mi("{{}^* {\\bf R}^d}")#text(" is measurable in ")#mi("{{\\mathcal B}}")#text(". Indeed, this coset is the union of the countable family of (nonstandard) balls ")#tao-math("{\\{ y \\in {}^* {\\bf R}^d: \\left|x-y\\right| < n \\}}", block: false)#text(" for ")#mi("{n \\in {\\bf N}}")#text(", each one of which is a nonstandard Borel set and thus measurable in ")#mi("{\\tilde {\\mathcal B}}")#text(".")#linebreak()#text(" Because of this, we can decompose the measure ")#mi("{\\pi_* \\tilde \\mu}")#text(" into pure point and singular components, thus")

#align(center)[#tao-fit-display[#mitex("\\pi_* \\tilde \\mu = \\sum_{k} c_k \\delta_{x_k+O({\\bf R}^d)} + \\rho")]]

#text("where ")#mi("{c_k}")#text(" are standard non-positive reals, ")#mi("{k}")#text(" ranges over an at most countable set, ")#mi("{x_k + O({\\bf R}^d)}")#text(" are disjoint cosets in ")#mi("{{}^* {\\bf R}^d/O({\\bf R}^d)}")#text(", and ")#mi("{\\rho}")#text(" is a finite measure on ")#mi("{\\pi_* \\tilde {\\mathcal B}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_k c_k + \\left\\|\\rho \\right\\| = 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\rho(\\{ x + O({\\bf R}^d) \\}) = 0")]]

#text("for every coset ")#mi("{x+O({\\bf R}^d)}")#text(".")#linebreak()#text(" Now we analyse the restriction of ")#mi("{\\tilde \\mu}")#text(" to a single coset ")#mi("{x_k+O({\\bf R}^d)}")#text(", which has total mass ")#mi("{c_k}")#text(". For any standard continuous, compactly supported function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", one can form the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{x_k+O({\\bf R}^d)} {}^* f(x -x_k)\\ d\\tilde \\mu(x).")]]

#text("This is a non-negative continuous linear functional, so by the Riesz representation theorem there exists a non-negative Radon measure ")#mi("{\\nu_k}")#text(" on ")#mi("{{\\bf R}^d}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{x_k+O({\\bf R}^d)} {}^* f(x -x_k)\\ d\\tilde \\mu(x) = c_k \\int_{{\\bf R}^d} f(y)\\ d\\nu_k(y)")]]

#text("for all such ")#mi("{f}")#text(". As ")#mi("{x_k+O({\\bf R}^d)}")#text(" has total mass ")#mi("{c_k}")#text(", ")#mi("{\\nu_k}")#text(" is a probability measure. From definition of ")#mi("{\\tilde \\mu}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{{}^* {\\bf R}^d} {}^* f(x -x_k)\\ d\\mu(x) = c_k \\int_{{\\bf R}^d} f(y)\\ d\\nu_k(y) + o(1)")]]

#text("for all ")#mi("{f}")#text(".")#linebreak()#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x_k,R)) \\leq c_k+o(1)")]]

#text("for every standard ")#mi("{R}")#text(", and thus by the overspill principle there exists an unbounded ")#mi("{R_k}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x_k,R_k)) \\leq c_k+o(1);")]]

#text("since ")#mi("{\\mu(x_k + O({\\bf R}^d)) = c_k}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x_k,R_k)) = c_k+o(1);")]]

#text("If we set ")#mi("{c_k \\tilde \\nu_k}")#text(" to be the restriction of ")#mi("{\\tau_{-x_k} \\mu}")#text(" to ")#mi("{B(0,R_k)}")#text(", we thus see that")

#align(center)[#tao-fit-display[#mitex("\\int_{{}^* {\\bf R}^d} {}^* f(x)\\ d\\tilde \\nu_k(y) = \\int_{{\\bf R}^d} f(y)\\ d\\nu_k(y) + o(1)")]]

#text("for all test functions ")#mi("{f}")#text(". Writing ")#mi("{\\tilde \\nu_k}")#text(" as the ultralimit of probability measures ")#mi("{\\tilde \\nu_{k,n}}")#text(", we thus see (upon passing to a subsequence) that ")#mi("{\\tilde \\nu_{k,k}}")#text(" converges vaguely to the probability measure ")#mi("{\\nu_k}")#text(", and is in particular tight.")#linebreak()#text(" For any standard ")#mi("{K \\geq 1}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\mu = \\sum_{k=1}^K c_k \\tau_{x_k} \\nu_k + \\rho_K")]]

#text("where ")#mi("{\\rho_K}")#text(" is a finite measure. Letting ")#mi("{\\tilde \\rho_K}")#text(" be the Loeb extension of the standard part of ")#mi("{\\rho_K}")#text(", we see that ")#mi("{\\tilde \\rho_K}")#text(" assigns zero mass to ")#mi("{x_k+O({\\bf R}^d)}")#text(" for ")#mi("{k \\leq K}")#text(" and assigns a mass of at most ")#mi("{\\sup_{k > K} c_k}")#text(" to any other coset of ")#mi("{O({\\bf R}^d)}")#text(". This implies that")

#align(center)[#tao-fit-display[#mitex("\\tilde \\rho_K( B(x,R) ) \\leq \\sup_{k > K} c_k + o(1)")]]

#text("for any standard ")#mi("{R}")#text(". Expressing ")#mi("{\\rho_K}")#text(" as an ultralimit of ")#mi("{\\rho_{K,n}}")#text(", we then obtain the claim.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("Prof. Tao, do you intend to teach a course in nonstandard analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48333")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("The short answer is no (any more than I would teach a course on, say, the construction of number systems; it is too foundational a subject for the type of course topics I have in mind). But there may be occasion to develop some nonstandard arguments within a broader course topic. For instance, ")#link("https://terrytao.wordpress.com/category/teaching/254b-higher-order-fourier-analysis/")[#text("in my 254B course on higher order Fourier analysis last year")]#text(", I mentioned the nonstandard approach to equidistribution, for instance in ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(" of that course. Somewhat relatedly, I also mentioned the ultrafilter approach to Ramsey theory in my ")#link("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")[#text("254A course on ergodic theory")]#text(" from the previous year (see e.g. ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Notes 3")]#text(" from that course).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48337")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("The course on ergodic theory should be “254A” :) ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Prof. Tao,")

#text("Which courses are you planning to teach in near future? I hope you teach a grad level complex analysis and probability theory…")

#text("Thanks")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8831c28918f694948e6b5259716111419afba243579a58971108cbab996ffe7e-dd1c349211d2b3b8f8e399c4494264464eaae9b1e70aef9b62b59d4d0e090ba5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48335")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("I wonder if you have read my work on Infinity? I do not want to link which would be inappropriate, but just asking.")

#text("Cheers,")#linebreak()#text(" NS")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c4195e5dc954ecbe350ea8090375abbf2deb0e6afffd80b30f19e2813386c34-4cb28dbefab7a84cda7371f33c38135a975c7335925feddc82227f74a70be069.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich Kohlenbach")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48371")[#strong[#text("Ulrich Kohlenbach")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Dear Terry,")

#text("many thanks for your interesting posting.")

#text("In connection with your treatment of the sequential weak compactntess in Hilbert space I like to mention three recent papers of mine:")

#text("1) In my paper “Goedel functional interpretation and weak compactness”")#linebreak()#text(" (available at ")#link("http://www.mathematik.tu-darmstadt.de/~kohlenbach/weakcompactness-els.pdf")[#text("http://www.mathematik.tu-darmstadt.de/~kohlenbach/weakcompactness-els.pdf")]#text(" )")#linebreak()#text(" I carry out (a variant version) of the Goedel “Dialectica” interpretation of the standard proof for the weak compactness as sketched in your posting. This results in a certain effective functional Omega* that comprises the computational content of that principle in the sense that it is precisely Omega* that is needed to extract bounds from proofs of combinatorial statements that use weak compactness. Omega* is primitive recursive in Spector’s bar recursion of lowest type. This is optimal in the sense that already the usual Bolzano-Weierstrass principle [0,1] requires this. In particular, Omega* locally stays within Goedel’s primitive recursive functionals of finite type. The construction also uses energy increment ideas. It would be interesting to see whether your 2nd proof results in a simpler bound that e.g. may need only one use of bar recursion (corresponding to the use of the Bolzano-Weierstrass principle) whereas I have a 2nd use corresponding to the Riesz representation theorem.")

#text("2) In “A uniform quantitative version of sequential weak compactness")#linebreak()#text(" and Baillon’s nonlinear ergodic theorem” (also available from the above")#linebreak()#text(" site) I use Omega* to extract an explicit uniform bound on a metastable")#linebreak()#text(" (in your sense) version of Baillon’s nonlinear ergodic theorem.")

#text("3) Interestingly, when weak compactness is used to prove a strong convergence result, the quantitative analysis in the spirit of Goedel’s")#linebreak()#text(" interpretation often seems to be able to eliminate weak compactness")#linebreak()#text(" altogether: see my recent paper:")#linebreak()#text(" “On quantitative versions of theorems due to F.E. Browder and R. Wittmann. Advances in Mathematics 226, pp. 2764-2795 (2011).")

#text("With best regards,")#linebreak()#text(" Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b446e55748e0188e37db93c4b283dd127a8e0660f7ae0d2d895a3e6894b5037-3f417b71d8656ba93e90c8971d145d6a4739948a8732a3be13c7b95d27356057.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bright, YU")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48399")[#strong[#text("Bright, YU")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Hi, Terry. I wanna ask a question not directly related to this post, but somehow I find it interesting and maybe you have an answer to it.")

#text("Suppose u is a harmonic function on the Euclidean Plane, given (x,y),then by Mean Value Property, u(x,y) should equals the mean value of u along a circle with radius r centred at (x,y).")#linebreak()#text(" With the mean value theorem for integral, u should attains the value at some point(s), say (m,n) on the circle.")#linebreak()#text(" SO, my question is that what is the set of such points if we pick one (m,n) on each circle and let r range from 0 to infinity?")

#text("Looking forward to your reply.")

#text("Bright, YU")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48477")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2010")])]

#text("Bright,")

#text("Your question is a bit on the general side.")

#text("For example, for a constant function, the set of points (")#mi("(m,n)_r")#text("?) is the entire circle for all ")#mi("r")#text(".")

#text("For a linear function, such as ")#mi("f(x,y)=x+y")#text(", the set of points ")#mi("\\{(m,n)_r:r\\geq 0\\}")#text(", if we choose for example ")#mi("(x,y)=(1,1)")#text(", is going to correspond to half of the circle (a picture will show you which half).")

#text("If however you pick ")#mi("(x,y)=(0,0)")#text(" the points are always going to be those corresponding to ")#mi("\\theta =3\\pi/4,-\\pi/4")#text(".")

#text("J.P.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/210a26938940e30de2e5fd9653e67d376c898f34b8119a4f55f651dcda6163e4-4b21a1c65fa650f5f814a96bbb68d350c5c96a78666ad31079bf6a87bf029667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iori1986iori")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48596")[#strong[#text("iori1986iori")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2010")])]

#text("大哥，你好强悍！big brother, u really smart")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48697")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("I have a naive question. Is this related to concentration of measure (around a median) a la Paul Levy and vitaly Milman?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48714")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2010")])]

#text("As far as I know there is no connection. Concentration of measure is ultimately coming from the law of large numbers, whereas the type of concentration on subsequences seen here is coming from things like the Bolzano-Weierstrass theorem. In both cases there is convergence to a limit, but other than that there appears to be no further relationship.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48867")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2010")])]

#text("Terry,")

#text("I have checked with both my blogging software (in my Blog list) and Google reader and it looks like your RSS feed has stopped as of December 6th. The last entry I get has the title: “Strongly dense fre”. I just re-subscribed to your feed and get the same result. If I am the only one to get this then sorry, if not…")

#text("Cheers,")

#text("Igor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48938")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("This happened to me as well. I can’t imagine what would cause this. Perhaps the feed has a maximum size which has been exceeded?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48979")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2010")])]

#text("It’s fixed now. Thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d023a26e9eac15c40a8e0133fd20148e09c176ab8a2fa62fde3a38fa8450c4-f7b5da897dfdebece30b4b73906c6b29d6fd399c54387f940145ef243a72ded9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avery Carr")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-48903")[#strong[#text("Avery Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("Prof. Tao,")

#text("Can Concentration Compactness be applied to the Invariant Subspace Problem for Hilbert Spaces? Thank you.")

#text("Avery Carr")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3b5ae3a06873c9605762674d85e5d73428994da966210907d664014577e0122-0f9857fb06c04531ee7e2573109141f4146db71a66f360808238c02c69a183dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peter p.")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-51540")[#strong[#text("peter p.")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("Apparently, P.L. Lions makes the comment in his 1984 paper that “This crucial lemma is proved with the help of the notion of the concentration function of a measure -introduced by P. Levy [14]”. He was referring to the concentration compactness lemma, I think, which occupies a big portion of his paper. Maybe worth a look.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-63755")[#strong[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("[…] symmetry that is available for the space . (Concentration compactness is discussed in these previous blog posts.) One then has to deal with sequences of data that are not strongly convergent, but are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-93081")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] two constructions are at least partially interchangeable in this setting. (See also these previous posts for the use of ultralimits as a substitute for topological limits.) In the theory of approximate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-185894")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] us to reduce the need to invoke the nonstandard measure theory of Loeb, discussed for instance in this blog post); we will use the notion of a (real) commutative probability space , which for us will be a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-255867")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] analysis can be used as a framework to describe the theory of concentration compactness; see this previous blog post for further discussion. Finally, if one starts with a finitely generated group with a word metric […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Go 2 It")]], [#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/#comment-615196")[#strong[#text("Go 2 It")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("Some typos:")

#text("in the middle of section 2, “do not lie in the same coset of ")#mi("{}^* H")#text("“: should be ")#mi("O(G)")

#text("in the nonstandard proof of theorem 3, “nonstandard interval ")#mi("[0,1]")#text("“: should be ")#mi("{}^* [0,1]")

#text("following “obvious quotient map”, missing “")#mi("O(\\mathbb{R}^d) \\rightarrow")#text("”")

#emph[#text("[Corrected, thanks – T.]")]
]
