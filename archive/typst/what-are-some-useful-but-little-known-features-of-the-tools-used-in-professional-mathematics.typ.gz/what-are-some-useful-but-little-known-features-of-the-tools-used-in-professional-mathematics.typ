// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T15:19:54.238439+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What are some useful, but little-known, features of the tools used in professional mathematics?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What are some useful, but little-known, features of the tools used in professional mathematics?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/")[#text("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A few days ago, I was talking with Ed Dunne, who is currently the Executive Editor of ")#link("http://www.ams.org/mr-database")[#text("Mathematical Reviews")]#text(" (and in particular with its online incarnation at ")#link("http://www.ams.org/mathscinet/search.html")[#text("MathSciNet")]#text("). At the time, I was mentioning how laborious it was for me to create a BibTeX file for dozens of references by using MathSciNet to locate each reference separately, and to export each one to BibTeX format. He then informed me that underneath to every MathSciNet reference there was a little link to add the reference to a ")#link("http://www.ams.org/notices/200604/comm-mathscinet.pdf")[#text("Clipboard")]#text(", and then one could export the entire Clipboard at once to whatever format one wished. In retrospect, this was a functionality of the site that had always been visible, but I had never bothered to explore it, and now I can populate a BibTeX file much more quickly.")

#text("This made me realise that perhaps there are many other useful features of popular mathematical tools out there that only a few users actually know about, so I wanted to create a blog post to encourage readers to post their own favorite tools, or features of tools, that are out there, often in plain sight, but not always widely known. Here are a few that I was able to recall from my own workflow (though for some of them it took quite a while to consciously remember, since I have been so used to them for so long!):")

#enum(start: 1, 
[#link("https://chrome.google.com/webstore/detail/tex-for-gmail/gjnmclkoadjdljnfmbnnhaahilafoeji?hl=en")[#text("TeX for Gmail")]#text(". A Chrome plugin that lets one write TeX symbols in emails sent through Gmail (by writing the LaTeX code and pressing a hotkey, usually F8).")],
[#link("http://www.boomeranggmail.com/")[#text("Boomerang for Gmail")]#text(". Another Chrome plugin for Gmail, which does two main things. Firstly, it can “boomerang” away an email from your inbox to return at some specified later date (e.g. one week from today). I found this useful to declutter my inbox regarding mail that I needed to act on in the future, but was unable to deal with at present due to travel, or because I was waiting for some other piece of data to arrive first. Secondly, it can send out email with some specified delay (e.g. by tomorrow morning), giving one time to cancel the email if necessary. (Thanks to Julia Wolf for telling me about Boomerang!)")],
[#text("Which just reminds me, the ")#link("https://support.google.com/mail/answer/2819488?co=GENIE.Platform%3DDesktop&hl=en")[#text("Undo Send")]#text(" feature on Gmail has saved me from embarrassment a few times (but one has to set it up first; it delays one’s emails by a short period, such as 30 seconds, during which time it is possible to undo the email).")],
[#link("https://inkscape.org/learn/tutorials/latex/")[#text("LaTeX rendering in Inkscape")]#text(". I used to use plain text to write mathematical formulae in my images, which always looked terrible. It took me years to realise that Inkscape had the functionality to compile LaTeX within it.")],
[#link("http://texniccenter.sourceforge.net/editor.html")[#text("Bookmarks in TeXnicCenter")]#text(". I probably only use a tiny fraction of the functionality that TeXnicCenter offers, but one little feature I quite like is the ability to bookmark a portion of the TeX file (e.g. the bibliography at the end, or the place one is currently editing) with one hot-key (Ctrl-F2) and then one can cycle quickly between one bookmarked location and another with some further hot-keys (F2 and shift-F2).")],
[#text("Actually, there are a number of ")#link("https://support.microsoft.com/en-us/help/12445/windows-keyboard-shortcuts")[#text("Windows keyboard shortcuts")]#text(" that are worth experimenting with (and similarly for Mac or Linux systems of course).")],
[#link("http://detexify.kirelabs.org/classify.html")[#text("Detexify")]#text(" has been the quickest way for me to locate the TeX code for a symbol that I couldn’t quite remember (or when hunting for a new symbol that would roughly be shaped like something I had in mind).")],
[#text("For writing LaTeX on my blog, I use Luca Trevisan’s ")#link("https://lucatrevisan.wordpress.com/latex-to-wordpress/")[#text("LaTeX to WordPress Python script")]#text(" (together with a little batch file I wrote to actually run the python script).")],
[#text("Using the camera on my phone to record a blackboard computation or a slide (or the wifi password at a conference centre, or any other piece of information that is written or displayed really). If the phone is set up properly this can be far quicker than writing it down with pen and paper. (I guess this particular trick is now quite widely used, but I still see people surprised when someone else uses a phone instead of a pen to record things.)")],
[#text("Using my online calendar not only to record scheduled future appointments, but also to block out time to do specific tasks (e.g. reserve 2-3pm at Tuesday to read paper X, or do errand Y). I have found I am able to get a much larger fraction of my “to do” list done on days in which I had previously blocked out such specific chunks of time, as opposed to days in which I had left several hours unscheduled (though sometimes those hours were also very useful for finding surprising new things to do that I had not anticipated). (I learned of this little trick online somewhere, but I have long since lost the original reference.)")]
)

#text("Anyway, I would very much like to hear what other little tools or features other readers have found useful in their work.")

#heading(level: 1)[#text("Comments (81)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-490318")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2017/12/20/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-491398")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2018")])]

#text("I also use Alt and a four digit number in order to get special characters, mostly the en-dash Alt+0150 (result: –) which is used e.g. in the Hahn–Banach theorem (even though TeX seems to replace any — by –)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c87d3c23e8653c494c169d4ff01bf14b69a6b096b53161dcd658ab554af79df9-e200142bf03dda406f511d69a556227e36e95f5366f1257ca3ed5b3e3e9e7ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Knowledge Worker")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-495282")[#strong[#text("Knowledge Worker")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("This is a tip from a computer scientist turned to be an amateur mathematician which I employ to learn at a conceptual level so perhaps this would be useful to someone else:")

#text("You can use Firefox with the ‘ScrapBook X’ extension which allows you to take whatever note you want like formulas, math definitions, math pictures and/or entire webpages/documents. Then you can export them as a html tree which you can rearrange as you want and copy it to your smartphone.")

#text("After that you can install the android apps ‘CHM Reader X’ to read the same html tree you see in your computer and ‘EBookDroid’ which will open the PDF&Djvu documents.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e710f2f27218a13b5ffdb05a97ebe5cb4bccd8fc3474f372a1d4d9f21858669-4b832ac55c37ac8a26ffa302e1064930cc3c4d770aedaec5abb8ac3da027395d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gdunkerley")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-531565")[#strong[#text("gdunkerley")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("Pardon for commenting on an old thread, but workflowy and the chrome extension wFX are probably the most useful tools I’ve ever come across.")#linebreak()#text(" Workflowy is basically a site that lets you create bullet text lists that can be indefinitely long and deep; people use it for scheduling their days, planning projects, setting reminders, and all sorts of other things. It’s very minimal (and therefore minimally distracting) with few features outside of some keyboard commands for navigating your sublists more efficiently.")

#link("https://workflowy.com/")[#text("https://workflowy.com/")]

#text("wFX lets you set custom keyboard commands in chrome to pull up sites, workflowy lists, or run scripts. It can be used to navigate workflowy, but I mostly use it to navigate to particular sites very quickly. It’s definitely faster than opening a bookmarks folder.")

#link("https://chrome.google.com/webstore/detail/wfx-for-workflowy/jbehgpdjkcconnaagjhddddfdajbpfhi?hl=en")[#text("https://chrome.google.com/webstore/detail/wfx-for-workflowy/jbehgpdjkcconnaagjhddddfdajbpfhi?hl=en")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/506179ae92e9a02dbc587110ebe6c08f4d34bf73238ffa0e63259df96ba2c161-ba93d6a09673b4a61e6eedd47d19cdff49bf062ba01051f6cc8ab1b905b07ef0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gianmarco Brocchi")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-551741")[#strong[#text("Gianmarco Brocchi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("A little Python script to collect LaTeX sources for upload to the arXiv:")#linebreak()#text(" ")#link("https://github.com/dougalsutherland/arxiv-collector")[#text("https://github.com/dougalsutherland/arxiv-collector")]

#text("(Particularly useful if you are experiencing problems with .bbl files,")#linebreak()#text(" ")#link("https://github.com/plk/biblatex/wiki/biblatex-and-the-arXiv")[#text("https://github.com/plk/biblatex/wiki/biblatex-and-the-arXiv")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9ace19bba304a536e43a70cee6a7768ca778def36ecd9eba689224956a7ea8f-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrii Mironchenko")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-598061")[#strong[#text("Andrii Mironchenko")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#link("https://draftable.com/compare")[#text("https://draftable.com/compare")]#linebreak()#text(" allows seeing the differences between 2 versions of pdf files, which is very nice e.g. to track the changes which the coauthors have made.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-637624")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Geogebra: Another thing I really find useful is the geogebra software (or its web version); it can be used to draw graphs and then attach it as a screenshot along with emails, whenever required (also since it shows the coordinate axes in the background, so drawing here is much simpler than on paint or other similar softwares). It also has the added advantage that for any (not-too-complicated) drawing made on the screen with cursor, the Tikz code or the Asymptote code for the same drawing can be obtained from it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a091bc6ab2f7f5b20cedcc7332c23a651a2493faa7a9ad8e2393a3a6c1f7da3-69d53fa6668c24b7bd931f6e36ab96bc12d6e6e0450aaa52ba720e8ecc1e9a32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Wassink")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-639430")[#strong[#text("Tim Wassink")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("With regards to point number 10, I think that Cal Newport might be the reference, at least he talks about similar stuff. ")#link("https://www.calnewport.com/blog/2013/12/21/deep-habits-the-importance-of-planning-every-minute-of-your-work-day/")[#text("https://www.calnewport.com/blog/2013/12/21/deep-habits-the-importance-of-planning-every-minute-of-your-work-day/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-2/#comment-686026")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2024")])]

#text("Dear Prof Tao,")

#text("The LaTeX rendering for Inkscape link seems to have been moved to ")#link("https://inkscape.org/learn/tutorials/latex/")[#text("https://inkscape.org/learn/tutorials/latex/")]

#text("I left the same comment yesterday but it still doesn’t show now. I am not sure if there’s a technical problem. I apologize if you see two identical comments.")

#text("Thank you for your time in advance.")

#text("Yours truly,")

#text("Guanyuming He")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483483")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("TeXmacs is a text processor with math support. LaTeX export and import are partially :-( supported: ")#link("http://texmacs.org")[#text("http://texmacs.org")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483486")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Rendering (text and math) in TeXmacs is comparably good with TeX (however, I doubt when we should or should not insert spaces between symbols, what is not a trouble in TeX). Quite scriptable (I’d say better than TeX).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483484")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("LyX is a (not quite WYSIWYG) text processor which uses LaTeX to create final documents, but allows to use a GUI interface while editing it: ")#link("https://www.lyx.org")[#text("https://www.lyx.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/949494182c5c9a1c632f04630468ebef1a228a8c633c5fc60773cfa696cd01aa-0d59957573aa391c62aebcac013482a0721b6f88457ef2151c12bf7774a5c683.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leandro Cioletti")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483485")[#strong[#text("Leandro Cioletti")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("I like very much Jabref + Texstudio to handle .bib files. To keep tracking changes in LaTeX files edited in collaboration, Meld (diff program) is a nice program for Linux users.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c52f5f9db72c2a746b53657c30a728ab1a584da9dec3d31ec51a87200376ccf8-2b094d5f046c5b07a97668ac29e8e237f17f393130ad955e52d658b061dcc71c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nttoan81")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483488")[#strong[#text("nttoan81")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#link("https://www.ctan.org/pkg/latexdiff?lang=en")[#text("Latexdiff")]#text(" could be useful in marking changes / differences made between two latex files (e.g., after each iteration in a collaborative work).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eppstein")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483491")[#strong[#text("eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Occasionally one encounters a reference that is not in MathSciNet. If you can find a doi for your reference, you can get its bibtex from a unix command line by")

#text("curl -LH “Accept: application/x-bibtex” ")#link("http://dx.doi.org/XXXX.XXXXXX")[#text("http://dx.doi.org/XXXX.XXXXXX")]

#text("(where the X’s are replaced by the doi).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SeventhGuest")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483501")[#strong[#text("SeventhGuest")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Google scholar provides bibtex entries that you can copy and paste into your .bib file. Unfortunately, they are not all written in a consistent style. It’s useful anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483519")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("You can also simply paste the doi into ")#link("http://www.doi2bib.org/")[#text("http://www.doi2bib.org/")]#text(" and click to copy the bibtex to your clipboard if you don’t use the command line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4faa3117d88bc18332610ef0e05e7d8e856308b1a1b3b1a6326fda860ff8f7-a7d523184492c8441464b0d11bdb29eeb7ac8f3ed452eb1bcdd93aa158b9c9e6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor V. Albert")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483586")[#strong[#text("Victor V. Albert")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("I use Mendeley: I click to add a new entry manually, paste the doi into the proper slot, and then click the magnifying glass icon next to it, which auto-looks up the doi and fills in all the data.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483496")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("1) In his talk at PCMI today, Dunne pointed out that MathSciNet has a remote access feature. When you’re on your institution’s network, you can click an icon on the top-right of the page (which I had never noticed) to download a cookie that gives you access whether on or off network for a period of 90 days, at which point you can renew.")

#text("2) For people who tend to keep a large number of browser tabs open, ")#link("https://www.one-tab.com/")[#text("OneTab")]#text(" lets you collapse all of them to a page with a list of hyperlinks, which you can organize into groups. Helps to reduce memory usage and clutter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483499")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Your comment about using your cell phone prompted an ancient memory I had totally forgotten! I once had a math class in which a student had apparently gotten permission of the professor to photograph the blackboard in lieu of actually taking notes. At that time, cameras only recorded on film, so he would have had to get all that film developed, and possibly printed, before it could be useful. It seemed to me to be more work than help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc6d2b444634f27d3e9b89987fd3c2d40f33cc63845f219b32983c4c4f0b1888-9a79d3ee9553703367cfd1a2bb8e9497ba366908942de0b5fb062c3e35892a3b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j2kun")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483500")[#strong[#text("j2kun")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("I use a program called latexmk (")#link("https://www.ctan.org/pkg/latexmk/?lang=en")[#text("https://www.ctan.org/pkg/latexmk/?lang=en")]#text(") to continuously recompile my tex files (recompiled automatically on save, and I have my editor set up to save if I stop typing for two seconds). I detailed my setup here: ")#link("https://jeremykun.com/2015/01/10/my-latex-workflow-latexmk-sharelatex-and-stackedit/")[#text("https://jeremykun.com/2015/01/10/my-latex-workflow-latexmk-sharelatex-and-stackedit/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483511")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("latexdiff has been pointed out.")

#text("the latex style ")#link("https://www.sharelatex.com/learn/Multi-file_LaTeX_projects")[#text("subfiles")]#text(" allow in a more convenient way (than include")#linebreak()#text(" or input) to split an article in subsections to work parallel.")

#text("the LaTeX style ")#link("https://www.ctan.org/pkg/todonotes?lang=en")[#text("todonotes")]#text(", allow to put margin notes with an error")#linebreak()#text(" precisely to the part in the document you refer to (the choice of this")#linebreak()#text(" epsilon is not correct).")

#text("GNU emacs (running on Linux Mac and Windows) supports also sending")#linebreak()#text(" mathematical formula as png as does gmail.")

#text("The GNU emacs package ")#link("https://www.gnu.org/software/auctex/")[#text("auctex")]#text(" allows to display formulas either via")#linebreak()#text(" special fonts or using preview-LaTeX via png pictures. In any case the")#linebreak()#text(" source code is not changed.")

#text("Mercurial version control system (using for example ")#link("https://bitbucket.org/")[#text("bitbucket")]#text(")")#linebreak()#text(" simplifies the interchanges of modifications (I presume subversion and")#linebreak()#text(" git provide similar functionality, but mercurial supports keyword")#linebreak()#text(" expansion in which case you get a nice header, via the LaTeX ")#link("https://www.ctan.org/tex-archive/macros/latex/contrib/rcsinfo?lang=en")[#text("rcsinfo")]#linebreak()#text(" style, printing out date and the actual version of the document).")

#text("Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62c485fd90e1d243e3381a2a9fde5195b09f284407ce782c63d6e9123eba2f46-f72ab756d99c59e4ab5b56a7b305ed69c5277d0ab89ead058002496c56ccc365.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marcogorelli")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483513")[#strong[#text("marcogorelli")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Best study/work hack ever: ")#link("https://selfcontrolapp.com/")[#text("https://selfcontrolapp.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0d851a5161cc5b8e023b231e88f5861a9f784e89acdc1c6bbe75a3bc98dde82-e1ec3e396dabd1bced61319f4bdf7083b1503fb85344fcaed5a1ac4a5968de40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shahrooz Janbaz")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483516")[#strong[#text("Shahrooz Janbaz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Much useful post dear Professor Tao. There is a general rule: always, there are some features which we are not aware of them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bryan")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483518")[#strong[#text("Bryan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#link("https://www.overleaf.com/")[#text("Overleaf.com")]#text(" for collaborative (latex) work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483520")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("I’ve also used ")#link("https://www.sharelatex.com/")[#text("sharelatex.com")]#text(" for collaborating on latex files. Some universities have a type of site license that grants you upgraded features for one or both of these websites, so you should check with the relevant people at your institution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483521")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("I’m surprised that no one has mentioned ")#link("https://en.wikipedia.org/wiki/Git")[#text("git")]#text(" yet, or other forms of version control. I found that the initial learning curve was a little offputting, but once I got used to it, I found it to be a great way to work with several coauthors at once. Changes are tracked at just the right level of granularity that makes it easy to follow along. And branches let you easily fork different versions, e.g. for the arxiv, for journals, or conferences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483522")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Also, regarding Git, whenever I clone a new git repository I keep the repo in my Dropbox (which is another indispensable tool) so that it automatically syncs any changes between my work computer and my laptop.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483524")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("In the mailing list I read, it is general advised not to do so, but instead use a server which really supports the VC system, github or bitbucket")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483523")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("I mentioned mercurial :) (together with git and subversion) above.")#linebreak()#text(" I think however (without the intention to start a flamewar) that")#linebreak()#text(" mercurial is better suited than git for latex users.")#linebreak()#text(" 1. it has keyword expansion")#linebreak()#text(" 2. local rev which simplify navigation")#linebreak()#text(" 3. named branches")

#text("Uwe Brauer")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483555")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Sorry that I missed your comment; you did beat me to it with Git. Regarding dropbox, I should clarify that I still use bitbucket to host the repository, but I keep my local copy in a dropbox folder. Since I’m only ever on one of my two computers at a time, it has never caused a problem for me in years of use.")

#text("I should also mention that there are nice GUIs for Git, like SourceTree, GitKraken, and the Git Hub app. There are probably similar resources for mercurial, but I’ve not used that.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f40d973dfab05042ffe8032cc5d98ea97f9c45c9937e547a1693d4fcac0abb0-c9fd914613927993fd059ea1b17c1bb7b360ffcc481f5df673538e9b4cc89a17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stiofáin")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483526")[#strong[#text("Stiofáin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("A remarkably useful trick I only discovered a few days ago: if there is an arXiv pre-print and maybe still not published (so you cant get the citation from MathSciNet) you can still get a bibtex entry for it by going to the arXiv page, on the right hand side click NASA ADS then click bibtex entry and you will get a fully formatted entry for it!")

#text("As for writing LaTeX documents after trying many different environments, the best I think is the LaTeX-suite add-on for vim ")#link("http://vim-latex.sourceforge.net/")[#text("http://vim-latex.sourceforge.net/")]#text(" but it doesn’t seem to be that well known I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef29003b829b0e0209fd260cfe8a8772a6e01ae06c24fd1107135931b5936d8d-a8314ea82245aa66773c82a749bf0ba3eb286535f53ee170d945ecc047831d53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wiselyrunning")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483527")[#strong[#text("wiselyrunning")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("If anyone is interested in Markdown editor that has good support for LaTeX, I would recommend you check out the app ")#link("https://typora.io/")[#text("Typora")]#text(". Unlike many other pieces of software, it’s a pleasure to look at.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483528")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("GNU emacs has a tool called ")#link("https://github.com/pzorin/bibretrieve")[#text("bibretrive")]#text(" which allows you to select the internet databases you want to access , say /mathscinet/ arxiv etc,")#linebreak()#text(" then author and title")#linebreak()#text(" and then if succesful")#linebreak()#text(" presents you a list of possible references which can then be inserted in bibtex format in your (global) bibtex database")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd366d60058a5a463c592880db8bcad746981d9cf730e5e200b2aa3963f3eb6a-8cd11ef2cf4d09d96bc08e5ac907ccc87b4f84cbadc84a240767b5f7fbc22aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483534")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Sometimes it is useful to strip commented lines from LaTeX source files (it can even avoid some embarrassing situations!). There are some scripts to do this at tex.stackexchange.com (")#link("https://tex.stackexchange.com/q/83663/69595")[#text("https://tex.stackexchange.com/q/83663/69595")]#text("). I’ve modified those to my preference.")

#text("I’m also using a version of Trevisan’s script, modified to output to MathJaX.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Many good suggestions so far!")

#text("I’m now reminded of another LaTeX package I learned to use from some coauthors: ")#link("https://www.ctan.org/pkg/showkeys?lang=en")[#text("showkeys")]#text(", which labels all references to equations, theorems, and citations by their label, which is useful when proofreading a draft. Of course one should comment out the package when it is finally time to submit, but this just requires editing one line of code.")

#text("Ah, now something else comes to mind: while I do sometimes use version control software like svn or git, nowadays I find Dropbox to be a reasonable compromise; it has less functionality, but very easy to use, regardless of the technological expertise of one’s coauthors (many of whom would already be using Dropbox anyway). To reduce editing conflicts, when collaborating via dropbox we usually split up the paper so that each section has its own tex file, together with the master tex file that \\inputs all the other ones. This way each coauthor can work on a separate portion of the paper concurrently without much chance of conflict (we usually coordinate by email who is editing what). Then when the paper is ready for submission we recombine into a single TeX file. (Also, if there is a particularly tricky LaTeX compiling error caused by some global interaction between various lines of code, one can try to localise the problem by commenting out one of more sections, each of which can be done with a single line of code in the master file.)")

#text("ADDED LATER: regarding internet access away from one’s home institution: ")#link("https://www.eduroam.us/")[#text("eduroam")]#text(" has pretty good coverage in the US at least (and most institutions there subscribe to the service). Many institutions also have some way to use a proxy server and/or VPN to access their credentials remotely for things like accessing online journals or other subscription services. Finally, in a pinch, many modern phones have a way to share their data service by serving as a wireless hotspot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483550")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Concerning showkeys, I find the package ")#link("https://www.ctan.org/pkg/refcheck?lang=en")[#text("refcheck")]#text(" a bit better suited.")

#text("I also split my documents in sections but I also think that the")#linebreak()#text(" subfile class is more convenient than input since you can run LaTeX on")#linebreak()#text(" the master and the slaves without editing the master file.")

#text("A last word about bitbucket, github etc. These servers have a useful tool")#linebreak()#text(" namely, issues (which is originally for bugtracking) but which comes")#linebreak()#text(" in handy for discussing gaps in proofs and statements (this can be")#linebreak()#text(" done by email, but not everybody respects the thread or uses an")#linebreak()#text(" appropriate subject), but you are very right most of professional")#linebreak()#text(" mathematicians are not keen to learn bitbucket and friends.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/221b3210fa59fc5b8f10eb463945f15061e1f48986970f16971ca565b4f9e34d-d78b939933e77c0f8d6b11f7291c5be6964cd394dd89a4f17161718ca8904f7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rege Serinko")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483544")[#strong[#text("Rege Serinko")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("This is a very recent discovery for me—about a week ago.")

#text("I’ve used LaTeX for along time and I wasn’t aware that the current version allows for optional arguments, with specified defaults, in \\newcommand and other macros. However, it only permits a single optional argument which must be the first argument. I found that very limiting. First off, the logical location for the optional argument may not be the first slot. Further, it would be nice to have more than one optional argument. So I started digging and found the package ")#link("https://www.ctan.org/tex-archive/macros/latex/contrib/xargs?lang=en")[#text("xargs")]#text(". It remedies both of these shortcomings.")

#text("But I needed more. For example, I wanted to define a single new command that handled both expectations and conditional expectation, The solution to this is in the ")#link("https://www.ctan.org/pkg/etoolbox?lang=en")[#text("etoolbox")]#text(" package which has if-else commands built in")

#text("Here is my macro that does just that.")#linebreak()#text(" \\newcommandx{\\e}[2][2]{\\mathbf{E}\\ifstrequal{#2}{}{\\left[#1\\right]}{\\left[#1\\middle|#2\\right]}}")

#text("The first [2] specifies that there are two arguments, just as in the \\newcommand macro. The second [2] specifies that the second argument, which is the conditioning event, is optional and that the default value is empty. A default value of B would be specified by [2=B]. The list is comma separated and allows up to 9 argument. The xarg package is well documented you can learn more there. The command \\ifstrequal{#2}{} specifies that if the argument #2 is empty to print out the content in the first set of braces {\\left[#1\\right]} else print out the content of the second set of braces {\\left[#1\\middle|#2\\right]}. It works really well.")

#text("After I got the hang of it, I began to consolidate several of my \\newcommand macros into a single \\newcommandx macros. For example, by nesting the if-else statements, I have a single macro to write a sequence, finite or infinite, increasing, decreasing or neither any choice of symbol to represent the terms of the sequence.")

#text("That’s my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483548")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("I recommend against the use of such macros (which a basically")#linebreak()#text(" abbreviations). Instead let the editor make the work. In GNU emacs in")#linebreak()#text(" math mode I type for example `e and it expands to \\epsilon. This way the")#linebreak()#text(" LaTeX source file is much easier to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483732")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2017")])]

#text("I think NewDocumentCommand, as part of the xparse package, also does all of this (and more).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ea0793089b01acc76fb6ca1930ee96387a9dfc5b1d7bb01e2f60267c9a5f8e6-4fab5d786a9d7e9c6b14651c79016829f947ac3102677d25122668956cd64439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerry Luo")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483545")[#strong[#text("Jerry Luo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#link("https://www.chachatelier.fr/latexit/")[#text("LaTeXiT")]#text(" can be used in a lot of different programs to instantly compile TeX. I’ve used it in Evernote to take notes without doing a full TeX program, and in OmniGraffle to help make figures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fcd28a5e9e55fd52daa2c3de53eb407a69db5f0dc11cbd5e23db8dfa64790ec-b36e26aeeb5b75577e239bfc485452d393964d89572bd18142d428a09905bb73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruno Santos")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483547")[#strong[#text("Bruno Santos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("My favorite is Librarian (")#link("https://fermatslibrary.com/librarian")[#text("https://fermatslibrary.com/librarian")]#text("): A Chrome plugin that lets you get direct links to references in arXiv papers, reference extraction and citation export in formats like BibTex.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28267fedbe2938ebd47d7eb1e75f6c04ab49f0b694a1ccf732e196c2946826e3-c357eef8aab13767ada88aae9d1087b8ffdb8e69216780493d288e4ec7eb336e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valentin polishchuk")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483731")[#strong[#text("valentin polishchuk")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2017")])]

#text("I like Scholar button ")#link("https://chrome.google.com/webstore/detail/google-scholar-button/ldipcbpaocekfooobnbcddclnhejkcpn?hl=en")[#text("https://chrome.google.com/webstore/detail/google-scholar-button/ldipcbpaocekfooobnbcddclnhejkcpn?hl=en")]#text(" : A Chrome plugin that lets you get direct links to references in *any* document (html or pdf), reference extraction and citation export in formats like BibTex.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d74ee354cc775976595e73270bfc5c01624ec0906863b2fdfb60b355c78217a7-197aba0c7db902e809c951d3ed918d7ca3ae4cac05aec2c6b9b350f0aabbaaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward Dunne")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483549")[#strong[#text("Edward Dunne")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("Something people ask about frequently for MathSciNet is access at home or on the road. It’s another little known feature we have had for a while. Instructions are here ")#link("http://blogs.ams.org/beyondreviews/2015/04/28/using-mathscinet-at-home-or-on-the-road/")[#text("http://blogs.ams.org/beyondreviews/2015/04/28/using-mathscinet-at-home-or-on-the-road/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76c27050d3d012f9aaac21f302ce7a16646f1516f94d307d20e6551d1d8b99df-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanisvili")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483551")[#strong[#text("Paata Ivanisvili")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#link("https://www.diffchecker.com/")[#text("https://www.diffchecker.com/")]#text(" Here you can compare and find differences between two texts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483567")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2017")])]

#text("I just checked, this is a line wise diffchecker (at it was to be expected).")#linebreak()#text(" I compared")#linebreak()#text(" This is true")#linebreak()#text(" with")#linebreak()#text(" This is")#linebreak()#text(" true")

#text("and the checker found a difference. If that were a latex file the resulting pdf file would look the same. That is why latexdiff is so useful. I ignores this sort of changes")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55b09fd124a17dcca3e13366901c6f66f0658ff92835dd6f4a682deaa336a7bb-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanisvili")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483577")[#strong[#text("Paata Ivanisvili")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("Thank you. Indeed, latexdiff is much better than diffchecker. I just found that if you don’t have latexdiff package you can use it online ")#link("https://3142.nl/latex-diff/")[#text("https://3142.nl/latex-diff/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d33b7136a506a6b0e8deb05d0ba9cfa4997c269e3c0901344c1562ebc50c4808-7a1849d23fba6196afe727988c83396bf2d3b5befcd9e9b6ecbddcfb3a612242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thebirdreader")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483578")[#strong[#text("thebirdreader")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("MathSciNet is a tool in itself. I think there are many researchers who don’t really think of using it whenever they encounter a new strand of papers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NobodySaysTomato")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483588")[#strong[#text("NobodySaysTomato")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("Can you elaborate a bit on how you use MathSciNet?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d33b7136a506a6b0e8deb05d0ba9cfa4997c269e3c0901344c1562ebc50c4808-7a1849d23fba6196afe727988c83396bf2d3b5befcd9e9b6ecbddcfb3a612242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thebirdreader")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483596")[#strong[#text("thebirdreader")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2017")])]

#text("The feature I find the most useful and that I use a lot is to find all papers that cite a given paper. That way you get a clear picture on how a subfield developed and research problems easily spring into your mind. I use this both on seminal papers and on papers that I find through Google.")

#text("What I would really like would be to directly SQL-interrogate the MathSciNet database, but I don’t think that feature would ever be added.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7deb22ebaf93c109793b43e4238c650aaea1c149b1f233bf0771f85c128095f3-a5e6c5c2c5306af81b846efb51196cba99c07d55aba9a2707dea3e5797a437a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483579")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("PaperClip keeps recent items copied available for pasting.")

#emph[#text("[Do you mean ")#link("https://itunes.apple.com/us/app/copyclip-clipboard-history-manager/id595191960?mt=12")[#text("CopyClip")]#text("? For Windows, the closest equivalent seems to be ")#link("https://sourceforge.net/projects/clipman/")[#text("Clipboard Manager")]#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483580")[#strong[#text("Handy Math Thingies – The Square Root")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")]

#text("[…] This made me realise that perhaps there are many other useful features of popular mathematical tools out there that only a few users actually know about, so I wanted to create a blog post to encourage readers to post their own favorite tools, or features of tools, that are out there, often in plain sight, but not always widely known. … (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a75cc5d45355cf37134cf176ccef4804425ed9dc4489046a969a16187eb793f-aca8f518dae2fdb566321a598609c46e00444176209393af615dc6068dcae98e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alessandro")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483590")[#strong[#text("alessandro")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#text("for the diff procedure, i think that textwrangler (on mac) is able to do an excellent job. for handling pdf files of publications dowloading the descriptions from mathscinet, i think that papers (mac and windows) is very nice.")

#text("a question: do you know a good latex-aware spell checker? excalibur on the mac is outdated…. a linux oriented solution would be great too. thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483592")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2017")])]

#raw("aspell --mode=tex")#text(" or ")#raw("aspell -t")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a75cc5d45355cf37134cf176ccef4804425ed9dc4489046a969a16187eb793f-aca8f518dae2fdb566321a598609c46e00444176209393af615dc6068dcae98e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alessandro")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483594")[#strong[#text("alessandro")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2017")])]

#text("great, thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8472461435b9f02a2a588743050d6b3d37ea445ede9a1c9b9c89df96e4990b2-af1f20d8f6f26c18f0a7bf3cf223c584ece5b850ecc48c95d14415207aa91a66.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Lawford")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483597")[#strong[#text("Steve Lawford")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2017")])]

#text("This is a great post and discussion, thank you!")

#text("1.")

#text("The following paper (on workflow in empirical social science) contains some related ideas on version control, task management, etc., that carry across to other fields: ")#link("http://www.brown.edu/Research/Shapiro/pdfs/CodeAndData.pdf")[#text("http://www.brown.edu/Research/Shapiro/pdfs/CodeAndData.pdf")]

#text("2.")

#text("Personally, I use git and GitHub for version control of code (and some .tex): ")#link("https://git-scm.com/")[#text("https://git-scm.com/")]#text(" (git) ")#link("https://github.com/")[#text("https://github.com/")]#text(" (GitHub). The paid version of GitHub lets you have private repositories: you can invite non-paying collaborators to these, and the repositories will remain private for them too.")

#text("3.")

#text("Sharelatex works really well for collaborative papers. I use the cheapest paid option, which lets me have up to 10 collaborators per “project”: ")#link("https://www.sharelatex.com/project")[#text("https://www.sharelatex.com/project")]#text(" (sharelatex). The software seems to crash (“full refresh needed”) much less than a few years ago, and the interface is really nice (I do not use the chat option: see next point). Colleagues have told me that Overleaf has very similar functionality, but I have not used it: ")#link("https://www.overleaf.com/")[#text("https://www.overleaf.com/")]

#text("4.")

#text("Google Hangouts is very handy: this serves as an instant-messaging system. I leave it open all the time, and it gets all project-related discussion out of email (which is a good thing for me: ")#link("https://www.youtube.com/watch?v=z9UjeTMb3Yk")[#text("https://www.youtube.com/watch?v=z9UjeTMb3Yk")]#text("). You can upload figures, screenshots, etc., and it synchronizes across PC, tablet, smartphone… I also use Google Drive to share / store larger files, with a separate folder for each project.")

#text("5.")

#text("For task management / note-taking / to do lists, I have tried Asana, Trello, Remember The Milk, Evernote, etc. I find it hard to maintain any long-term momentum using these tools. From experience, Google Calendar is the most convenient for me (blocking out slots for particular tasks), with a simple .txt “to do” list in Google Drive that all collaborators update with numbered bullet points; and Google Hangouts for real-time discussion. I think that the trick is to find one simple set of tools that work well together, and then to use it for all projects! (and then adjust the system when better tools become available). Tech-based tools are indispensable, but sometimes pencil-and-paper is better! :) ")#link("http://www.43folders.com/2004/09/03/introducing-the-hipster-pda")[#text("http://www.43folders.com/2004/09/03/introducing-the-hipster-pda")]

#text("6.")

#text("For general coding, I use Python 2.7. The Spyder bundle is one that works well: ")#link("https://sourceforge.net/projects/winpython/files/WinPython_2.7/")[#text("https://sourceforge.net/projects/winpython/files/WinPython_2.7/")]#text(" (just download and run the .exe installer; this will create a folder in the same location as the .exe; open that folder and create a shortcut to the Spyder .exe; move this shortcut to a convenient location; double-clicking the shortcut will launch Spyder, with a split-screen interface for code and output). There are a few differences between the versions, and I still use an old one which I know works well:")#linebreak()#text(" ")#link("https://sourceforge.net/projects/winpython/files/WinPython_2.7/2.7.6.4/")[#text("https://sourceforge.net/projects/winpython/files/WinPython_2.7/2.7.6.4/")]

#text("7.")

#text("For coding issues, I frequently refer to stackoverflow (look for questions and answers with a high number of “votes”): ")#link("https://stackoverflow.com/")[#text("https://stackoverflow.com/")]

#text("For math-related questions, I often look at stackechange: ")#link("https://math.stackexchange.com/")[#text("https://math.stackexchange.com/")]

#text("8.")

#text("When searching for literature, Google Scholar is great: ")#link("https://scholar.google.fr/")[#text("https://scholar.google.fr/")]#text(" (as well as arXiv, etc.)")

#text("9.")

#text("JabRef is quite a nice tool for reference management: ")#link("http://www.jabref.org/")[#text("http://www.jabref.org/")]#text(" (but I just add references manually to a .bib file now: less overhead).")

#text("10.")

#text("I have played with a few “self-control” apps, but have ditched them all except for Freedom (which blocks all internet access; although the best option is just to leave the PC at home…): ")#link("https://freedom.to/")[#text("https://freedom.to/")]#text(" and StayFocusd (Google Chrome plug-in): ")#link("http://www.stayfocusd.com/")[#text("http://www.stayfocusd.com/")]#text(" (which can block selected sites after a specified time-period; I leave this running all the time). The best time-management / self-control system for my research seems to be working on exciting projects with collaborators (eliminating much of the incentive to surf the web) and scheduling my calendar in advance with “to do” list tasks.")

#text("I hope that some of these links will be useful to others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c52f5f9db72c2a746b53657c30a728ab1a584da9dec3d31ec51a87200376ccf8-2b094d5f046c5b07a97668ac29e8e237f17f393130ad955e52d658b061dcc71c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nttoan81")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483606")[#strong[#text("nttoan81")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2017")])]

#text("Regarding inserting latex into a figure, you could simply use:")

#text("\\put(X,Y){math latex or any text here}")

#text("with X,Y being Cartesian coordinates. Try this:")

#text("\\begin{figure}")#linebreak()#text(" \\includegraphics[scale=1]{figure-name}")#linebreak()#text(" \\put(50,50){let us mention $math$ here}")#linebreak()#text(" \\end{figure}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/221b3210fa59fc5b8f10eb463945f15061e1f48986970f16971ca565b4f9e34d-d78b939933e77c0f8d6b11f7291c5be6964cd394dd89a4f17161718ca8904f7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Regis Serinko")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483607")[#strong[#text("Regis Serinko")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2017")])]

#text("I’ve been using ")#link("https://www.geogebra.org/")[#text("GeoGebra")]#text(" for my graphs. You can put LaTeX in very easily. The LaTeX can be positioned by dragging or specifying the position. The graphs can be exported in many formats including SVG and PDF.")#linebreak()#text(" Further, graphs can be tweaked in Inkscape by exporting them in SVG format.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/335cb13ab39894a9dd735639d07c00485508c5c7c2509f6a9411ad452641d26d-cb5da10004feb1f2e906dd9feab7da16f5a8d9ddae6814d9be84fe2ec8a8f8b9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeyuanhu")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483635")[#strong[#text("zeyuanhu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("Reblogged this on ")#link("https://zeyuanhu.wordpress.com/2017/07/12/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/")[#text("Randomize stuff…")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a924fa0018a154b94d479db0a0ef1dfc9f05254796c436bfd0ece3dba6d217fc-d7db087759cdb77b4d5a803d78470ebbaa47f6aeb95c3419d47fe7e9877fbb0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483673")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2017")])]

#text("Emacs with the auctex mode has a preview feature which shows all formulae and figures inline, switching back to the latex code at the location of the cursor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483690")[#strong[#text("What are some useful, but little-known, features of the tools used in professional mathematics?")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")]

#text("[…] 來源： What are some useful, but little-known, features of the tools used in professional mathematics? […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0edc51e1d359a442aa2abf8cd0e44aa8b406a7098b8f8cd1bc8e17a62cb82255-2c226ff5ee28e322d49ff1d7acdbea0efe15b544fe98e59e1b7e142cc7f83d56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483697")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")])]

#text("Thanks! I find such posts extremely useful, and indeed once wrote a similar one myself: ")#link("https://windowsontheory.org/2016/04/28/theory-life-hacks/")[#text("https://windowsontheory.org/2016/04/28/theory-life-hacks/")]

#text("Some features I find useful that I think weren’t mentioned yet:")

#text("1) Alt-Equal to add formulas in PowerPoint, and the fact that you can use latex-like syntax such as \\alpha^2 in them and it will generally work (replacing curly braces with parenthesis).")

#text("2) Using a clipboard manager and a text extender. The former remembers all the things you copied and not just the last one. Very useful when you want to copy 5 distinct pieces of information from a webpage. The latter allows you to define shortcuts for pieces of text you type again and again. I use it for storing folders and even for some form letters. I personally use ditto and breevy for windows, but am sure there are other programs as well.")

#text("3) Using markdown rather than latex to type short technical documents such as blog posts, write ups to discuss proof ideas, and even lecture notes. If you don’t need the fine control over design provided by latex, you need to type much less in markdown. In particular, I no longer use Gmailtex but rather the “markdown here” plug-in (markdown here also works well with Google inbox, which provides much of the Boomerang functionality).")

#text("4) On a general note, much of the problems we face as mathematicians/researchers when collaborating with people are similar to those faced by programmers, but they tend to be much savvier in developing and adopting tools, and so it’s good to check periodically if there are any programmer tools that can be useful. For example, I do find git and slack quite useful for collaborations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Samuelson")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483700")[#strong[#text("Peter Samuelson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")])]

#text("Forward and inverse search are incredibly useful for me, and several TeX editors have it. It allows you to ctrl-click on the pdf file and then the editor takes you to the point in the LaTex code corresponding to the location you clicked on. (You can also go the other way, from code to pdf file.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483765")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("I use three monitors.One to write LaTeX code in Emacs editor,one to show the compiled pdf files,so that I can have live preview.And the last one to draw graphs,read ebooks,surf the internet and so on……")

#text("In this way I don’t need to switch too often,which will break my workflow,and I have a broader view.")

#text("I also use boox max,which is a big(13 inch) ebook reader utilizing the e-ink technology(looks the same as paper books).So that I don’t need to print pdf files on A4 papers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55703ba96a2fddfe62c98db1bda477637dcb23c230fe11231f22d156cd47fc05-ef2719000842415a3ba771d8189e82932db756134bdda1f9cb53dfabe271a327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Harmsworth")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483858")[#strong[#text("Phil Harmsworth")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Thanks to a blog post by Tim Gowers (")#link("https://gowers.wordpress.com/2013/10/24/what-i-did-in-my-summer-holidays/")[#text("https://gowers.wordpress.com/2013/10/24/what-i-did-in-my-summer-holidays/")]#text("), I discovered TiddlyWiki (")#link("http://tiddlywiki.com/")[#text("http://tiddlywiki.com/")]#text("). I’ve only used it to capture odd jottings, such as notes about references/information sources, ideas to try out, and so forth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483861")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("Hi, the problem is the link to")#linebreak()#text(" ")#link("http://gowers.tiddlyspace.com")[#text("http://gowers.tiddlyspace.com")]#linebreak()#text(" is dead and the service seems down.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55703ba96a2fddfe62c98db1bda477637dcb23c230fe11231f22d156cd47fc05-ef2719000842415a3ba771d8189e82932db756134bdda1f9cb53dfabe271a327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Harmsworth")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483946")[#strong[#text("Phil Harmsworth")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("That’s precisely why I provided a link to Tiddlywiki instead.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-483968")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("I have found “Grammarly” useful in writing texts/emails. It couples to my Gmail and some other apps (it is active now that I am typing here). In addition to finding spelling errors (standard), it checks some of the grammar, such as verb tense consistencies, plural/singular forms, and sometimes suggest fine-tuning of the text (e.g., catches extra spaces, suggests a missing hyphen etc.). It isn’t perfect but useful enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c21da60fb8475f9102696a843be0de675e16320e5d187168ef83aa9fde35fe76-96e1892f43d8f50df245da820fa611fcf34fc36d72bfd9b5fe3cbf917b5e0e99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blogauthor")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484131")[#strong[#text("blogauthor")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("SInce it is sort-of-surprising that TikZ appears not to have been mentioned so far in this thread: TikZ’s *loop* and *calculating* capabilities are an example. To keep this short, here is a brief, unexaplained (and by itself, non-compilable, needless to say) code-snippetwhich, if you need to, can points you in some useful directions:")#linebreak()#text(" \\pgfmathsetmacro\\highestindex{int(#1-1)}")#linebreak()#text(" \\foreach \\counter in {0,…,\\highestindex}{")#linebreak()#text(" \\pgfmathsetmacro{\\aux}{360/#1}")#linebreak()#text(" \\pgfmathsetmacro{\\angle}{\\counter*\\hilf}")

#text("etc")

#text("}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/468686383a4fd192afe4172bfb30c2624d93c443421f85eda74d4ff3dd07ffeb-047dffa10e496e70536ffd084d0390eb98f1dc615ed96d4875c4fd4eb961d5bb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of test | raylesstrees")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484136")[#strong[#text("test | raylesstrees")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("[…] via What are some useful, but little-known, features of the tools used in professional mathematics? — … […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/468686383a4fd192afe4172bfb30c2624d93c443421f85eda74d4ff3dd07ffeb-047dffa10e496e70536ffd084d0390eb98f1dc615ed96d4875c4fd4eb961d5bb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Small tutorial to inkscape, with a view towards category theory and graph theory. | raylesstrees")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484137")[#strong[#text("Small tutorial to inkscape, with a view towards category theory and graph theory. | raylesstrees")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("[…] at What’s new, it was, thankfully, mentioned that inkscape has some degree of LaTeX-interpretation capability. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c21da60fb8475f9102696a843be0de675e16320e5d187168ef83aa9fde35fe76-96e1892f43d8f50df245da820fa611fcf34fc36d72bfd9b5fe3cbf917b5e0e99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blogauthor")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484138")[#strong[#text("blogauthor")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Also, the opacity-option of TikZ (by making it possible to make the arrow translucent) makes it easy to have _labels of arrows in commutative diagrams sitting precisely ON the arrow_, freeing one of the obligation to make the arbitrary choice whether to place the label of the arrow on either side of it (since with black-on-black the label would otherwise be damaged). This seems an under-used, easily used, feature-of-a-tool to me. Relative to modern technology, of course, gray/diaphanous arrows are acceptable, and even more beautiful than black ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47686e8e186a2139ce330e529e62ee0e9a50b2f7eb27670506b886522fbc6ae5-4136aff1cb7100adbce3f457eaaee678004c2f2f5a91c75825c5a218027e4c74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Natingga")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484511")[#strong[#text("David Natingga")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2017")])]

#text("I use Git version control system to save my thesis, papers… It keeps the history of the work. It can be useful especially for collaboration when I can work on some paper with other person and want to see who wrote what or merge our work in an efficient way without waiting for the other person to finish her editing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason M.")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484565")[#strong[#text("Jason M.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2017")])]

#text("I find it useful to use Gmail’s Multiple Inboxes feature, keeping an extra panel above the main inbox and matching the search query is:starred.")

#text("Then any starred email stays pinned to the top of my gmail page. This")#linebreak()#text(" is another solution to the first issue you mentioned in your discussion of Boomerang.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3957ce9eca0e36e483cdd15cb1aa7a071545a26029d39fec7664e56a84d8739-deb6d1035d7ca3a0a6cfc20589cc7b84a10777a669dd4628e169eae1c051e1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio Russo")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484678")[#strong[#text("Antonio Russo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2017")])]

#text("I like to work with my android phone while I am travelling by train. So I write my stuff with Verbtex and calculate it with Anoc Octave.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MathSciNet")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484699")[#strong[#text("MathSciNet")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2017")])]

#text("About MathSciNet access at home on on the road. It is possible but not very convenient to bring home computer to work every 90 days or login through library. My question is why not have open access? Nobody but professional scientists will even use mathscinet, at work, at home or on the road, so what is the point of requiring login?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52749ecd5235abc2603d9e719428d509107a64c92da7c298bf219662124b75db-84c1dc1cde59a123b9ed01001a2832df14e2e6109c4849e1c5d8c44dce4dec6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Kruel")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-484925")[#strong[#text("Alexander Kruel")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2017")])]

#text("Online Mathematics Editor: A fast way to write and share mathematics formula (exports to LaTeX).")

#link("https://www.mathcha.io/")[#text("https://www.mathcha.io/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17e7f6d624e40deddd540fb3ae512564e189e2d800d0047dcc47531e5ad6298a-eb99eeb53f0f7cb7f584dddfdd1f307f3fadeec628e66e1bf73b1a6b2f42b5ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier Dussau")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-485703")[#strong[#text("Xavier Dussau")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("I use phraseexpress ")#link("http://www.phraseexpress.com/")[#text("http://www.phraseexpress.com/")]#text(" to make personal shortcuts. For example, when I write &enu in an editor, automatically I obtain")#linebreak()#text(" \\begin{enumerate} \\item \\item \\end{enumerate}")#linebreak()#text(" It’s quite useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69c4675abb48673add21c7a8f98445b78b52f945751513ff629552e6973c46f-97dcebb9699a6a5e079a54c5738a7e87da13f359d808190fa83a3c81e2f6bf17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Operative Handler")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-486208")[#strong[#text("Operative Handler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2017")])]

#text("I would also add the Tor Browser for browsing which uses second-generation onion routing to provide privacy, which is essential in our time. You can find it at their official websitee: ")#link("https://www.torproject.org/download/download-easy.html.en")[#text("https://www.torproject.org/download/download-easy.html.en")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8be7777646f2f3be2d01bbe951824dd295af5f18c54be02be024b291b2409bbf-1e370fe1a3ee6e5f11746a7ef926e608b3d923b6e6aec3c457b8330ba2558807.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barbara G.")]], [#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-486333")[#strong[#text("Barbara G.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Whoa, that looks really useful!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/07/what-are-some-useful-but-little-known-features-of-the-tools-used-in-professional-mathematics/comment-page-1/#comment-486628")[#strong[#text("What are some useful, but little-known, features of the tools used in professional mathematics? — What’s new | Team OCC")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2017")]

#text("[…] via What are some useful, but little-known, features of the tools used in professional mathematics? — … […]")
]
