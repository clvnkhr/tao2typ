// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/
// Converted to Typst by tao2typ: "2026-10-14T06:53:04.535095+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 1: Overview", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 1: Overview")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In this lecture, I define the basic notion of a ")#emph[#text("dynamical system")]#text(" (as well as the more structured notions of a ")#emph[#text("topological dynamical system")]#text(" and a ")#emph[#text("measure-preserving system")]#text("), and describe the main topics we will cover in this course.")

#metadata(none) <tao-518d9bd8c1ebd5e05254>#text("We’ll begin abstractly. Suppose that X is a non-empty set (whose elements will be referred to as ")#emph[#text("points")]#text("), and ")#mi("T: X \\to X")#text(" is a transformation. Later on we shall put some structures on X (such as a ")#link("http://en.wikipedia.org/wiki/Topology")[#text("topology")]#text(", a ")#mi("\\sigma")#text("-algebra, or a probability measure), and some assumptions on T, but let us work in total generality for now. (Indeed, a guiding philosophy in the first half of the course will be to try to study dynamical systems in as maximal generality as possible; later on, though, when we turn to more algebraic dynamical systems such as nilsystems, we shall exploit the specific structure of such systems more thoroughly.)")

#text("One can think of X as a ")#link("http://en.wikipedia.org/wiki/State_space")[#text("state space")]#text(" for some system, and T as the evolution of some discrete deterministic (")#link("http://tosio.math.toronto.edu/wiki/index.php/Time_translation_symmetry")[#text("autonomous")]#text(") dynamics on X: if x is a point in X, denoting the current state of a system, then Tx can be interpreted as the state of the same system after one unit of time has elapsed. (In particular, evolution equations which are ")#link("http://en.wikipedia.org/wiki/Well-posed")[#text("well-posed")]#text(" can be viewed as a continuous dynamical system.) More geometrically, one can think of T as some sort of shift operation (e.g. a rotation) on the space X.")

#text("Given X and T, we can define the iterates ")#mi("T^n: X \\to X")#text(" for every non-negative integer n; if T is also invertible, then we can also define ")#mi("T^n")#text(" for negative integer n as well. In the language of ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(", T induces a representation of either the additive ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(" ")#mi("{\\Bbb Z}^+")#text(" or the additive group ")#mi("{\\Bbb Z}")#text(". (From the dynamical perspective, this representation is the mathematical manifestation of ")#emph[#text("time")]#text(".) More generally, one can consider representations of other groups, such as the real line ")#mi("{\\Bbb R}")#text(" (corresponding the dynamics ")#mi("t \\mapsto T^t")#text(" of a continuous time evolution) or a lattice ")#mi("{\\Bbb Z}^d")#text(" (which corresponds to the dynamics of d commuting shift operators ")#mi("T_1,\\ldots,T_d: X \\to X")#text("), or of many other semigroups or groups (not necessarily commutative). However, for simplicity we shall mostly restrict our attention to ")#mi("{\\Bbb Z}")#text("-actions in this course, though many of the results here can be generalised to other actions (under suitable hypotheses on the underlying semigroup or group, of course).")

#text("Henceforth we assume T to be invertible, in which case we refer to the pair ")#mi("(X,T)")#text(" as a ")#emph[#link("http://en.wikipedia.org/wiki/Cyclic_group")[#text("cyclic")]#text(" dynamical system")]#text(", or ")#link("http://en.wikipedia.org/wiki/Discrete_dynamical_system")[#emph[#text("dynamical system")]]#text(" for short. Here are some simple examples of such systems:")

#enum(start: 1, 
[#strong[#text("Finite systems")]#text(". Here, X is a finite set, and ")#mi("T: X \\to X")#text(" is a permutation on X.")],
[#strong[#text("Group actions")]#text(". Let G be a group, and let X be a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" for G, i.e. a non-empty space with a ")#link("http://en.wikipedia.org/wiki/Orbit_%28group_theory%29#Types_of_actions")[#text("transitive")]#text(" G-action; thus X is isomorphic to ")#mi("G/\\Gamma")#text(", where ")#mi("\\Gamma := \\text{Stab}(x)")#text(" is the ")#link("http://en.wikipedia.org/wiki/Orbit_%28group_theory%29#Orbits_and_stabilizers")[#text("stabiliser")]#text(" of one of the points x in X. Then every group element ")#mi("g \\in G")#text(" defines a dynamical system ")#mi("(X, T_g)")#text(" defined by ")#mi("T_g x := gx")#text(".")],
[#strong[#text("Circle rotations")]#text(". As a special case of Example 2, every real number ")#mi("\\alpha \\in {\\Bbb R}")#text(" induces a dynamical system ")#mi("({\\Bbb R}/{\\Bbb Z}, T_\\alpha)")#text(" given by the rotation ")#mi("T_\\alpha x := x + \\alpha")#text(". This is the prototypical example of a very ")#emph[#text("structured")]#text(" system, with plenty of algebraic structure (e.g. the shift map ")#mi("T_\\alpha")#text(" is an isometry on the circle, thus two points always stay the same distance apart under shifts).")],
[#strong[#text("Cyclic groups")]#text(". Another special case of Example 2 is the cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" with shift ")#mi("x \\mapsto x+1")#text("; this is the prototypical example of a finite dynamical system.")],
[#strong[#text("Bernoulli systems")]#text(". Every non-empty set ")#mi("\\Omega")#text(" induces a dynamical system ")#mi("(\\Omega^{\\Bbb Z}, T)")#text(", where T is the left shift ")#mi("T (x_n)_{n \\in {\\Bbb Z}} := (x_{n+1})_{n \\in {\\Bbb Z}}")#text(". This is the prototypical example of a very ")#emph[#text("pseudorandom")]#text(" system, with plenty of mixing (e.g. the shift map tends to move a pair of two points randomly around the space).")],
[#strong[#text("Boolean Bernoulli system")]#text(". This is isomorphic to a special case of Example 5, in which ")#mi("X = 2^{\\Bbb Z} := \\{ A: A \\subset {\\Bbb Z} \\} \\equiv \\{0,1\\}^{\\Bbb Z}")#text(" is the power set of the integers, and ")#mi("TA := A-1 := \\{ a-1: a \\in A \\}")#text(" is the left shift. (Here we endow ")#mi("\\{0,1\\}")#text(" with the discrete topology.)")],
[#link("http://en.wikipedia.org/wiki/Baker's_map")[#strong[#text("Baker’s map")]]#text(". Here, ")#mi("X := [0,1)^2")#text(", and ")#mi("T(x,y) := (\\{2x\\}, \\frac{y + \\lfloor 2x \\rfloor}{2})")#text(", where ")#mi("\\lfloor x \\rfloor")#text(" is the ")#link("http://en.wikipedia.org/wiki/Greatest_integer_function")[#text("greatest integer function")]#text(", and ")#mi("\\{x\\} := x - \\lfloor x \\rfloor")#text(" is the fractional part. This is isomorphic to Example 6, as can be seen by inspecting the effect of T on the binary expansions of x and y.")]
)

#text("The map ")#mi("T^n")#text(" can be interpreted as an isomorphism in several different ")#link("http://en.wikipedia.org/wiki/Category_%28mathematics%29")[#text("categories")]#text(":")

#enum(start: 1, 
[#text("as a set isomorphism (i.e. a bijection) ")#mi("T^n: X \\to X")#text(" from points ")#mi("x \\in X")#text(" to points ")#mi("T^n x \\in X")#text(";")],
[#text("as a ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_%28structure%29")[#text("Boolean algebra")]#text(" isomorphism ")#mi("T^n: 2^X \\to 2^X")#text(" from sets ")#mi("E \\subset X")#text(" to sets ")#mi("T^n E := \\{ T^n x: x \\in E \\}")#text("; or")],
[#text("as an ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" isomorphism ")#mi("T^n: {\\Bbb R}^X \\to {\\Bbb R}^X")#text(") from real-valued functions ")#mi("f: X \\to {\\Bbb R}")#text(" to real-valued functions ")#mi("T^n f: X \\to {\\Bbb R}")#text(", defined by")

#mi("T^n f(x) := f( T^{-n} x );")#text(" (1)")],
[#text("as an algebra isomorphism ")#mi("T^n: {\\Bbb C}^X \\to {\\Bbb C}^X")#text(" of complex valued functions, defined exactly as in 3.")]
)

#text("We will abuse notation and use the same symbol ")#mi("T^n")#text(" to refer to all of the above isomorphisms; the specific meaning of ")#mi("T^n")#text(" should be clear from context in all cases. Our sign conventions here are chosen so that we have the pleasant identities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("T^n \\{x\\} = \\{ T^n x \\}; \\quad T^n 1_E = 1_{T^n E}")]]

#text("for all points x and sets E, where of course ")#mi("1_E")#text(" is the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator function")]#text(" of E.")

#text("One of the main topics of study in dynamical systems is the asymptotic behaviour of ")#mi("T^n")#text(" as ")#mi("n \\to \\infty")#text(". We can pose this question in any of the above categories, thus")

#enum(start: 1, 
[#text("For a given point ")#mi("x \\in X")#text(", what is the behaviour of ")#mi("T^n x")#text(" as ")#mi("n \\to \\infty")#text("?")],
[#text("For a given set ")#mi("E \\subset X")#text(", what is the behaviour of ")#mi("T^n E")#text(" as ")#mi("n \\to \\infty")#text("?")],
[#text("For a given real or complex-valued function ")#mi("f: X \\to {\\Bbb R}, {\\Bbb C}")#text(", what is the behaviour of ")#mi("T^n f")#text(" as ")#mi("n \\to \\infty")#text("?")]
)

#text("These are of course very general and vague questions, but we will formalise them in many different ways later in the course. (For instance, one can distinguish between worst-case, average-case, and best-case behaviour in x, E, f, or n.) The answer to these questions also depends very much on the dynamical system; thus a major focus of study in this subject is to seek classifications of dynamical systems which allow one to answer the above questions satisfactorily. (In particular, ergodic theory is a framework in which our understanding of the ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("dichotomy between structure and randomness")]#text(" is at is most developed.)")

#text("One can also ask for more ")#emph[#text("quantitative")]#text(" versions of the above asymptotic questions, in which n ranges in a finite interval (e.g. ")#mi("{}[N] := \\{1,\\ldots,N\\}")#text(" for some large integer N), as opposed to going off to infinity, and one wishes to estimate various numerical measurements of ")#mi("T^n x")#text(", ")#mi("T^n E")#text(", or ")#mi("T^n f")#text(" in this range.")

#text("In this very general setting, in which X is an unstructured set, and T is an arbitrary bijection, there is not much of interest one can say with regards to these questions. However, one obtains a surprisingly rich and powerful theory when one adds a little bit more structure to X and T (thus changing categories once more). In particular, we will study the following two structured versions of a dynamical system:")

#enum(start: 1, 
[#emph[#text("Topological dynamical systems")]#text(" ")#mi("(X,T) = (X,{\\mathcal F},T)")#text(", in which ")#mi("X = (X,{\\mathcal F})")#text(" is a compact ")#link("http://en.wikipedia.org/wiki/Metrizable_space")[#text("metrisable")]#text(" (and thus ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(") topological space, and T is a topological isomorphism (i.e. a ")#link("http://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]#text("); and")],
[#emph[#text("Measure-preserving systems")]#text(" ")#mi("(X,T) = (X,{\\mathcal X},\\mu,T)")#text(", in which ")#mi("X = (X,{\\mathcal X},\\mu)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(", and ")#mi("T")#text(" is a probability space isomorphism, i.e. T and ")#mi("T^{-1}")#text(" are both measurable, and ")#mi("\\mu(TE) = \\mu(E)")#text(" for all measurable ")#mi("E \\in {\\mathcal X}")#text(". [In this course we shall tilt towards a measure-theoretic perspective rather than a probabilistic one, thus it might be better to think of ")#mi("\\mu")#text(" of as a normalised finite measure rather than as a probability measure. On the other hand, we will rely crucially on the probabilistic notions of ")#emph[#text("conditional expectation ")]#text("and ")#emph[#text("conditional independence")]#text(" later in this course.] For technical reasons we also require the measurable space ")#mi("(X, {\\mathcal X})")#text(" to be ")#link("http://en.wikipedia.org/wiki/Separable_sigma_algebra")[#emph[#text("separable")]]#text(" (i.e. ")#mi("{\\mathcal X}")#text(" is countably generated).")]
)

#strong[#text("Remark 1.")]#text(" By ")#link("http://en.wikipedia.org/wiki/Metrization_theorem")[#text("Urysohn’s metrisation theorem")]#text(", a compact space is metrisable if and only if it is Hausdorff and ")#link("http://en.wikipedia.org/wiki/Second-countable_space")[#text("second countable")]#text(", thus providing a purely topological characterisation of a topological dynamical system. ")#mi("\\diamond")

#text("[It is common to add a bit more structure to each of these systems, for instance endowing a topological dynamical system with a metric, or endowing a measure preserving system with the structure of a ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("standard Borel space")]#text("; we will see examples of this in later lectures.] The study of topological dynamical systems and measure-preserving systems is known as ")#emph[#text("topological dynamics")]#text(" and ")#emph[#text("ergodic theory")]#text(" respectively. The two subjects are closely analogous at a heuristic level, and also have some more rigorous connections between them, so we shall pursue them in a somewhat parallel fashion in this course.")

#text("Observe that we assume compactness in 1. and finite measure in 2.; these “boundedness” assumptions ensure that the dynamics somewhat resembles the (overly simple) case of a finite dynamical system. Dynamics on non-compact topological spaces or infinite measure spaces ")#text("can be quite nasty, and there does not appear to be a useful general theory in these cases")#text(" is a more complicated topic; see for instance ")#link("http://www.math.tau.ac.il/~aaro/book/book.html")[#text("this book of Aaronson")]#text(". [Updated, Jan 9; thanks to Tamar Ziegler for the link.]")

#text("Note that the action of the isomorphism ")#mi("T^n")#text(" on sets E and functions f will be compatible with the topological or measure-theoretic structure:")

#enum(start: 1, 
[#text("If ")#mi("(X,T) = (X,{\\mathcal F},T)")#text(" is a topological dynamical system, then ")#mi("T^n: {\\mathcal F}\\to {\\mathcal F}")#text(" is a topological isomorphism on open sets, and ")#mi("T^n: C(X) \\to C(X)")#text(" is also a ")#link("http://en.wikipedia.org/wiki/C%2A-algebra")[#mi("C^*")#text("-algebra")]#text(" isomorphism on the space ")#mi("C(X)")#text(" of real -valued (or complex-valued) continuous functions on X.")],
[#text("If ")#mi("(X,T) = (X, {\\mathcal X}, \\mu, T)")#text(" is a measure-preserving system, then ")#mi("T^n: {\\mathcal X} \\to {\\mathcal X}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebra")]#text(" isomorphism on measurable sets, and ")#mi("T^n: L^p({\\mathcal X},\\mu) \\to L^p({\\mathcal X},\\mu)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach space")]#text(" isomorphism on ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("p^{th}")#text("-power integrable functions")]#text(" for ")#mi("1 \\leq p\\leq \\infty")#text(". (For ")#mi("p=\\infty")#text(", ")#mi("T^n")#text(" is a ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra ")]#text("isomorphism, whilst for ")#mi("p=2")#text(", ")#mi("T^n")#text(" is a ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space ")]#text("isomorphism (i.e. a ")#link("http://en.wikipedia.org/wiki/Unitary_transformation")[#text("unitary transformation")]#text(").)")]
)

#text("We can thus see that tools from the analysis of Banach spaces, von Neumann algebras, and Hilbert spaces may have some relevance to ergodic theory; for instance, the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" for unitary operators is quite useful.")

#text("In the first half of this course, we will study topological dynamical systems and measure-preserving systems in great generality (with few assumptions on the structure of such systems), and then specialise to specific systems as appropriate. This somewhat abstract approach is broadly analogous to the combinatorial (as opposed to algebraic or arithmetic) approach to additive number theory. For instance, we will shortly be able to establish the following general result in topological dynamics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Birkhoff recurrence theorem")]#text(". Let (X,T) be a topological dynamical system. Then there exists a point ")#mi("x \\in X")#text(" which is ")#emph[#text("recurrent")]#text(" in the sense that there exists a sequence ")#mi("n_j \\to\\infty")#text(" such that ")#mi("T^{n_j} x \\to x")#text(" as ")#mi("j \\to\\infty")#text(".")
]

#text("As a corollary, we will be able to obtain the more concrete result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Weyl recurrence theorem")]#text(". Let ")#mi("P: {\\Bbb Z} \\to {\\Bbb R}/{\\Bbb Z}")#text(" be a polynomial (modulo 1). Then there exists a sequence ")#mi("n_j \\to \\infty")#text(" such that ")#mi("P(n_j) \\to P(0)")#text(".")
]

#text("This is already a somewhat non-trivial theorem; consider for instance the case ")#mi("P(n) := \\sqrt{2} n^2 \\text{ mod } 1")#text(".")

#text("In a similar spirit, we will be able to prove the general topological dynamical result")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Topological van der Waerden theorem")]#text(". Let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of a topological dynamical system (X,T), and let ")#mi("k\\geq 1")#text(" be an integer. Then there exists an open set U in this cover and a shift ")#mi("n \\geq 1")#text(" such that ")#mi("U \\cap T^n U \\cap \\ldots \\cap T^{(k-1)n} U \\neq \\emptyset")#text(". (Equivalently, there exists U, n, and a point x such that ")#mi("x, T^n x, \\ldots, T^{(k-1)n} x \\in U")#text(".)")
]

#text("and conclude an (equivalent) combinatorial result")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#strong[#text("van der Waerden theorem")]]#text(". Let ")#mi("{\\Bbb N} = U_1 \\cup \\ldots \\cup U_m")#text(" be a finite colouring of the integers. Then one of the colour classes ")#mi("U_j")#text(" contains arbitrarily long arithmetic progressions.")
]

#text("More generally, topological dynamics is an excellent tool for establishing colouring theorems of ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey type")]#text(".")

#text("Analogously, we will be able to show the following general ergodic theory result")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Furstenberg multiple recurrence theorem")]#text(". Let ")#mi("(X,T)")#text(" be a measure-preserving system, let ")#mi("E \\in {\\mathcal X}")#text(" be a set of positive measure, and let ")#mi("k \\geq 1")#text(". Then there exists ")#mi("n\\geq 1")#text(" such that ")#mi("E \\cap T^n E \\cap \\ldots \\cap T^{(k-1)n} E \\neq \\emptyset")#text(" (or equivalently, there exists ")#mi("x \\in X")#text(" and ")#mi("n \\geq 1")#text(" such that ")#mi("x, T^n x, \\ldots, T^{(k-1)n} \\in E")#text(").")

#text("Similarly, if ")#mi("f: X \\to {\\Bbb R}^+")#text(" is a bounded measurable non-negative function which is not almost everywhere zero, and ")#mi("k \\geq 1")#text(", then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N \\int_X f T^n f \\ldots T^{(k-1) n} f > 0.")]]
]

#text("and deduce an equivalent (and highly non-trivial) combinatorial analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di's_theorem")[#strong[#text("Szemerédi’s theorem")]]#text(". Let ")#mi("E \\subset {\\Bbb Z}")#text(" be a set of positive upper density, thus ")#tao-math("\\limsup_{N \\to \\infty} \\frac{\\left|E \\cap [-N,N]\\right|}{2N+1} > 0", block: false)#text(". Then E contains arbitrarily long arithmetic progressions.")
]

#text("More generally, ergodic theory methods are extremely powerful in deriving “density Ramsey theorems”. Indeed, there are several theorems of this type which currently have no known non-ergodic theory proof. [From general techniques in ")#link("http://en.wikipedia.org/wiki/Proof_theory")[#text("proof theory")]#text(", one could, in principle, take an ergodic theory proof and mechanically convert it into what would technically be a non-ergodic proof, for instance avoiding the use of infinitary objects, but this is not really in the spirit of what most mathematicians would call a genuinely new proof.]")

#text("The first half of this course will be devoted to results of the above type, which apply to general topological dynamical systems or general measure-preserving systems. One important insight that will emerge from analysis of the latter is that in many cases, a large portion of the measure-preserving system is irrelevant for the purposes of understanding long-time average behaviour; instead, there will be a smaller system, known as a ")#emph[#text("characteristic factor")]#text(" for the system, which completely controls these asymptotic averages. A deep and powerful fact is that in many situations, this characteristic factor is extremely structured algebraically, even if the original system has no obvious algebraic structure whatsoever. Because of this, it becomes important to study algebraic dynamical systems, such as the group actions on homogeneous spaces described earlier, as it allows one to obtain more precise results. (For instance, this algebraic structure was used to show that the limit in (3) actually converges, a result which does not seem accessible purely through the techniques used to prove the Furstenberg recurrence theorem.) This study will be the focus of the second half of the course, particularly in the important case of ")#emph[#text("nilsystems")]#text(" – group actions arising from a ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" with discrete stabiliser. One of the key results here is ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’s theorem")]#text(", which describes the distribution of orbits ")#mi("\\{ T^n x: n \\in {\\Bbb Z} \\}")#text(" in nilsystems, and also in a more general class of group actions on homogeneous spaces. It is unlikely that we will end up proving Ratner’s theorem in full generality, but we will try to cover a few special cases of this theorem.")

#text("In closing, I should mention that the topics I intend to cover in this course are only a small fraction of the vast area of ergodic theory and dynamical systems; for instance, there are parts of this field connected with complex analysis and fractals, ODE, probability and information theory, harmonic analysis, group theory, operator algebras, or mathematical physics which I will say absolutely nothing about here.")

#text("[")#emph[#text("Update")]#text(", Jan 28: Definition of measure-preserving system modified to add the separability condition.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1fc5b5751b962e0eaa33c46950720e44bae6e13c5c5bf6908505900bbdeff77-da7da91a4f1aa4858d5b55fec0e3f8587cccca6681b912e7a6ad3fd00b6ac162.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tamar Ziegler")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23622")[#strong[#text("Tamar Ziegler")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Hi Terry,")

#text("Just a comment regarding infinite measure preserving systems. There")#linebreak()#text(" is a rather developed general theory in this case as well. There is an overview")#linebreak()#text(" paper on ")#link("http://www.math.tau.ac.il/~aaro/book/book.html")[#text(" Jon Aaronson’s ")]#text(" web page (he has also written a book on the subject).")

#text("Best,")#linebreak()#text(" Tammy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Dear Terry,")

#text("What text book would you recommend for this topic? Thanks.")

#text("–Anon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous 2")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23659")[#strong[#text("Anonymous 2")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Dear Prof. Tao, are you going to have the notes available in a more “printable” format such as pdf? I hope so.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23672")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Dear Tammy: Thanks for the heads-up! I’ve updated the relevant paragraph.")

#text("Dear Anonymous: Right now I am using Furstenberg’s “Recurrence in Ergodic Theory and Combinatorial Number Theory” and Glasner’s “Ergodic Theory via Joinings”, together with a large number of miscellaneous on-line resources such as papers, course notes, and even Wikipedia. Some of these are linked from my web page for this course.")

#text("Dear Anonymous 2: I am planning to compile several of the blog posts here into a book format; more information to follow soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Dear Prof.Tao:")#linebreak()#text(" Anonymous 2’s suggestion may be worth consideration. Your blog is excellent and I benefit a lot from it. But sometimes when I want to read the post carefully, I have to view online. Could you also provide pdf or dvi version of “short story article”? May it add to some technical difficulties? Many thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3e4345348e039e1122922cc7ae6808a63c820f28f074704e6ea6bdafaeb2f-b8521ec4aebbfbf4f426c3dd1f70372c541ae23f11be677dd6038bda89c0828e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darren")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23723")[#strong[#text("darren")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Since Furstenberg’s book is out of print and quite hard to find, you might also want to point people to “Ergodic Theory” by Petersen. It covers the ergodic theoretic proof of Szemeredi’s Theorem and everything that leads up to it but unfortunately does not cover Ratner’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23725")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("You can find used copies of Furstenberg’s book at ABE book search:")

#link("http://www.abebooks.com/")[#text("http://www.abebooks.com/")]

#text("This web site is a great source for locating out of print math books.")

#text("They also have multiple copies of Ellis’ Lectures on Topological Dynamics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("‘Dynamical Systems and Ergodic Theory’ by Pollicott and Yuri may be useful. It covers Szemerédi’s theorem and is available electronically:")

#link("http://www.warwick.ac.uk/~masdbl/book.html")[#text("http://www.warwick.ac.uk/~masdbl/book.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 2: Three categories of dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23842")[#strong[#text("254A, Lecture 2: Three categories of dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("[…] dynamical systems, topological dynamical systems, and measure-preserving systems (as defined in the previous lecture), it is convenient to give these three classes the structure of a category. One of the basic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-23867")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("Pollicott and Yuri’s book has good chapters on recurrence theorems, but if I recall correctly, you should watch out for typos!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-24107")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Sir")

#text("Can you explain the meaning of the notation \\Omega^\\mathbb{Z} that has been used in the Bernoulli System example for representing the set of the states of such a system?")

#text("Nilay")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-24177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Dear Nilay,")

#text("When A and B are sets, then ")#mi("{}A^B")#text(" refers to the space of all functions from B to A, or equivalently the space of all sequences ")#mi("(a_b)_{b \\in B}")#text(" in A indexed by B. See")

#link("http://en.wikipedia.org/wiki/Exponentiation#Exponentiation_over_sets")[#text("http://en.wikipedia.org/wiki/Exponentiation#Exponentiation_over_sets")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c053a50100399f65096debd21fb063d61fbe7ba356e23bab9499a4443bc8e963-cf654da6b1dee3932869c33919327ce6557554bd2c773002f8288582deffa3bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon 9")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-24419")[#strong[#text("Anon 9")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Regarding anonymous 2’s suggestion, I wish someone should make a tool that does automatically what anonymous 2 suggested. That tool would take any wordpress math blog article and produce a tex file or a pdf file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48e1326c95be276acedb6747686616cc4eefaff062fbacfb5d9b94fa7b980734-3b7584db4b846a9e48c2d92c8529e366af008d002ca373f5c741a3961a991eb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Krishna Bhogaonker")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-485305")[#strong[#text("Krishna Bhogaonker")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("@Anon 9 Actually, I believe that Pandoc can do this. Pandoc can convert between latex, html, markdown, and any variety of syntaxes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matas")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-25050")[#strong[#text("Matas")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("Furstenberg multiple recurrence theorem: why should not “E \\cap T^n E \\cap \\ldots \\cap T^{(k-1)n} E \\neq \\emptyset” be changed to “E \\cap T^{-n} E \\cap \\ldots \\cap T^{-(k-1)n} E \\neq \\emptyset” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-25066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("Dear Matas,")

#text("The two statements are equivalent (if you apply ")#mi("T^{-(k-1)n}")#text(" to the former and rearrange, you obtain the latter, and similarly one can obtain the latter from the former).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93fb26ec0795d2f4c84825063418b1de4f7aa1d6772003aca2a0d9a070e75c40-3bf5a49ffb4af024981d964c7b63103f409f1b918dc75d53cee8286ceee87d1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-26450")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Dear prof. Tao:")

#text("Thank you for making these notes available for people who can not possibly attend your classes (I’m from Spain!).")

#text("I have one doubt: Does “mod 1” refer to taking the fractional part? Then, which are the purpose and the advantage of writting it as “modulo arithmetic” instead of using a fractional operator? I looked for it on the net, but I couldn’t find any source! (Any links would make for it)")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-26451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Dear Jose,")

#text("I use ")#mi("x \\mapsto x \\mod 1")#text(" to denote the quotient map from the real line ")#mi("{\\Bbb R}")#text(" to the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" (thus, if one views ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" as the space of cosets ")#mi("\\{ x + {\\Bbb Z}: x \\in {\\Bbb R} \\}")#text(", then ")#mi("x \\mod 1 = x + {\\Bbb Z}")#text("). The fractional part map ")#mi("x \\mapsto \\{x\\}")#text(" is essentially a branch of the quotient map, formed by identifying the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" with a unit interval such as ")#mi("{}[0,1)")#text(" or ")#mi("{}(-1/2,1/2]")#text(" (depending on one’s conventions), and so ")#mi("\\{x\\}")#text(" is a real number rather than an element of the circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". Thus, for instance, the fractional part of 3.4 would be 0.4, but ")#mi("3.4 \\text{ mod } 1")#text(" would be the coset ")#mi("3.4 + {\\Bbb Z} = 0.4 + {\\Bbb Z}")#text(". The two concepts are of course very closely related, but not quite the same: for instance, the map ")#mi("x \\mapsto x \\text{ mod } 1")#text(" is continuous and a homomorphism (thus ")#mi("x \\text{ mod } 1 + y \\text{ mod } 1 = (x+y) \\text{ mod } 1")#text("), while the fractional part map ")#mi("x \\mapsto \\{x\\}")#text(" is neither.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93fb26ec0795d2f4c84825063418b1de4f7aa1d6772003aca2a0d9a070e75c40-3bf5a49ffb4af024981d964c7b63103f409f1b918dc75d53cee8286ceee87d1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-26453")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Thanks, it’s crystal clear now :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28156a1faabf4ab1584d5287aa7eeb539c9e6f836a20e25107ffeb0514c43d7e-fdc683de6d0550073b8cc5a2aec0203ccc0a1d50e2323a9795cc84157153aa5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luca Goldoni")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-27990")[#strong[#text("Luca Goldoni")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("Dear prof Tao,")

#text("thank you so many for your very deep and very clear lectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-32688")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("[…] 2: circle extensions of a dynamical system. Recall (see e.g. my lecture notes) that a dynamical system is a pair X = (X,T), where X is a space and is an invertible map. (One […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ea2e9e950e31d497ab6c7e75097cc6813c265a8cc2610faab2e9d6dfb9b3203-a7ee6ec69e16e3890c67096756436df5ed20ac4a172132b039c71412455b895c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nara")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-33302")[#strong[#text("Nara")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2008")])]

#text("Dear Prof. Tao,")

#text("Thanks so much to make your lecture note to be publicly available.")#linebreak()#text(" I totally appreciate it.")

#text("I have a silly question since I’m kind of new with the ergodic theory . I wonder if there is a dynamical system that does not leave any measure preserved.")#linebreak()#text(" And it would be very generous of you if you may give several examples for different cases, that is, for X is finite, sigma-finite, or infinite.")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-33308")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2008")])]

#text("Dear Nara,")

#text("Actually, every topological dynamical system has at least one invariant measure; this is known as the Krylov-Bogolyubov theorem and appears as Corollary 1 in Lecture 7:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("254A, Lecture 7: Structural theory of topological dynamical systems")]
]

#text("see also")

#link("http://en.wikipedia.org/wiki/Krylov-Bogolyubov_theorem")[#text("http://en.wikipedia.org/wiki/Krylov-Bogolyubov_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6c90ff88c2aa7ae7eb4504922799f1d15e6d3b4828ce0f84e5bca5a269d9d83-3a17ce26a2d41e59d6e8830208d48c4addf24344f33e3a8dfb100b2a5d72eaa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mark hooper")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-42823")[#strong[#text("mark hooper")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("Dear Terry Tao,")

#text("Love this stuff but needs some “applets” to illustrate points – a picture paints a thousand words")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-153873")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2012")])]

#text("Concerning the passage: “as an algebra isomorphism T^n: {\\Bbb R}^X \\to {\\Bbb R}^X) from real-valued functions f: X \\to {\\Bbb R} to real-valued functions T^n f: X \\to {\\Bbb R}, defined by")#linebreak()#text(" T^n f(x) := f( T^{-n} x ); (1)”")

#text("Is there any particular reason why we choose the convention of setting ")#mi("T^n f(x) = f(T^{-n}x)")#text(" rather than ")#mi("f(T^n x)")#text("?")

#text("At first glance, it seems to me that the latter convention would be more natural, because if we regard a function ")#mi("f")#text(" as a map ")#mi("f: X \\longrightarrow \\mathbb{R}")#text(" and ")#mi("T^n")#text(" as a map ")#mi("T^n: X \\longrightarrow X")#text(", then setting ")#mi("T^n f(x) = f(T^{n} x)")#text(" amounts to taking the composition of these two maps.")

#text("On other hand, the current convention calls for us to compose ")#mi("f")#text(" with the inverse of ")#mi("T^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-153899")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2012")])]

#text("In the case of Z-actions (which is what is considered here) there is not much difference, but one (minor) advantage of the negative shift is that it pushes supports forwards rather than backwards: the support of ")#mi("T^n f")#text(" is the image of the support of ")#mi("f")#text(" by ")#mi("T^n")#text(", rather than ")#mi("T^{-n}")#text(". (This is for the same reason that if one wants to shift a function ")#mi("f: {\\bf R} \\to {\\bf R}")#text(" right by some shift ")#mi("h")#text(", one must _subtract_ h from the argument to get the shifted function ")#mi("T^h f(x) := f(x-h)")#text(", rather than add h. This reflects the basic duality between functions on a domain, and points in that domain.")

#text("The negative convention becomes of more substantial use when one considers the dynamics of a noncommutative group G, rather than the integers. If one wants to have an action rather than an anti-action (so that ")#mi("T^g T^h = T^{gh}")#text(", rather than ")#mi("T^g T^h = T^{hg}")#text("), one should write ")#mi("T^g f(x) := f(T^{g^{-1}} x)")#text(" rather than ")#mi("T^g f(x) = f(T^g x)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-456259")[#strong[#text("Naive approach to finding best L1 fit to a vector time series | zulfahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2015")]

#text("[…] This simple model is unlikely to describe the volatility process obviously but it’s useful to understand ergodicity. Abstractly, ergodic theory studies iterates of a map . Terry Tao’s ergodic theory notes are here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-461917")[#strong[#text("What is Gauge? | The Conscience of A Libertarian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2015")]

#text("[…] 2: circle extensions of a dynamical system. Recall (see e.g. mylecture notes) that a dynamical system is a pair X = (X,T), where X is a space and is an invertible map. (One […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-483764")[#strong[#text("An Epsilon of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] Theory: with a view towards … Ergodic Theory, Lecture 1 … ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")]#text(" (Terry what’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/#comment-486284")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2017")])]

#text("Dear Prof. Tao,")

#text("example 3 is not a special case of example 1, since ")#mi("\\mathbb R / \\mathbb Z")#text(" is not a finite set. If “finite” is removed from example 1, then it’s true.")

#emph[#text("[Remark removed, thanks – T.]")]
]
