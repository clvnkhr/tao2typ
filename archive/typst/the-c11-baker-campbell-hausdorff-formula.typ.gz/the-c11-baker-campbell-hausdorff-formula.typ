// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/
// Converted to Typst by tao2typ: "2026-10-14T16:36:32.595702+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The C^{1,1} Baker-Campbell-Hausdorff formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The C^{1,1} Baker-Campbell-Hausdorff formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/")[#text("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" with ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie algebra")]#text(" ")#mi("{{\\mathfrak g}}")#text(". As is well known, the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" is a local homeomorphism near the identity. As such, the group law on ")#mi("{G}")#text(" can be locally pulled back to an operation ")#mi("{*: U \\times U \\rightarrow {\\mathfrak g}}")#text(" defined on a neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(", defined as")

#align(center)[#tao-fit-display[#mitex("x * y := \\log( \\exp(x) \\exp(y) )")]]

#text("where ")#mi("{\\log}")#text(" is the local inverse of the exponential map. One can view ")#mi("{*}")#text(" as the group law expressed in local exponential coordinates around the origin.")

#text("An asymptotic expansion for ")#mi("{x*y}")#text(" is provided by the ")#link("http://en.wikipedia.org/wiki/Baker%E2%80%93Campbell%E2%80%93Hausdorff_formula")[#text("Baker-Campbell-Hausdorff (BCH) formula")]

#align(center)[#tao-fit-display[#mitex("x*y = x+y+ \\frac{1}{2} [x,y] + \\frac{1}{12}[x,[x,y]] - \\frac{1}{12}[y,[x,y]] + \\ldots")]]

#text("for all sufficiently small ")#mi("{x,y}")#text(", where ")#mi("{[,]: {\\mathfrak g} \\times {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie bracket")]#text(". More explicitly, one has the ")#emph[#text("Baker-Campbell-Hausdorff-Dynkin formula")]#text(" ")#metadata(none) <tao-769a4e6d0003189c7e96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("x * y = x + \\int_0^1 F( \\text{Ad}_x \\text{Ad}_{ty} ) y\\ dt")]]

#text("for all sufficiently small ")#mi("{x,y}")#text(", where ")#mi("{\\text{Ad}_x = \\exp( \\text{ad}_x )}")#text(", ")#mi("{\\text{ad}_x: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is the adjoint representation ")#mi("{\\text{ad}_x(y) := [x,y]}")#text(", and ")#mi("{F}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("F( t ) := \\frac{t \\log t}{t-1}")]]

#text("which is real analytic near ")#mi("{t=1}")#text(" and can thus be applied to linear operators sufficiently close to the identity. One corollary of this is that the multiplication operation ")#mi("{*}")#text(" is real analytic in local coordinates, and so every smooth Lie group is in fact a real analytic Lie group.")

#text("It turns out that one does not need the full force of the smoothness hypothesis to obtain these conclusions. It is, for instance, a classical result that ")#mi("{C^2}")#text(" regularity of the group operations is already enough to obtain the Baker-Campbell-Hausdorff formula. Actually, it turns out that we can weaken this a bit, and show that even ")#mi("{C^{1,1}}")#text(" regularity (i.e. that the group operations are continuously differentiable, and the derivatives are locally Lipschitz) is enough to make the classical derivation of the Baker-Campbell-Hausdorff formula work. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (")#mi("{C^{1,1}}")#text(" Baker-Campbell-Hausdorff formula)")]#text(" ")#metadata(none) <tao-833a61955631ab7a5609>#text(" Let ")#mi("{{\\bf R}^d}")#text(" be a finite-dimensional vector space, and suppose one has a continuous operation ")#mi("{*: U \\times U \\rightarrow {\\bf R}^d}")#text(" defined on a neighbourhood ")#mi("{U}")#text(" around the origin, which obeys the following three axioms:")

#list(
[#text("(Approximate additivity) For ")#mi("{x,y}")#text(" sufficiently close to the origin, one has")

#metadata(none) <tao-a0b1505271eb8bd05b38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("x*y = x+y+O(\\left|x\\right| \\left|y\\right|).", block: true)]]

#text("(In particular, ")#mi("{0*x=x*0=x}")#text(" for ")#mi("{x}")#text(" sufficiently close to the origin.)")],
[#text("(Associativity) For ")#mi("{x,y,z}")#text(" sufficiently close to the origin, ")#mi("{(x*y)*z = x*(y*z)}")#text(".")],
[#text("(Radial homogeneity) For ")#mi("{x}")#text(" sufficiently close to the origin, one has")

#metadata(none) <tao-ca2b25a9b0e7a993f09d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(sx) * (tx) = (s+t)x")]]

#text("for all ")#mi("{s,t \\in [-1,1]}")#text(". (In particular, ")#mi("{x * (-x) = (-x) * x = 0}")#text(" for all ")#mi("{x}")#text(" sufficiently close to the origin.)")]
)

#text("Then ")#mi("{*}")#text(" is real analytic (and in particular, smooth) near the origin. (In particular, ")#mi("{*}")#text(" gives a neighbourhood of the origin the structure of a ")#link("http://en.wikipedia.org/wiki/Local_Lie_group")[#text("local Lie group")]#text(".)")
]

#text("Indeed, we will recover the Baker-Campbell-Hausdorff-Dynkin formula (after defining ")#mi("{\\text{Ad}_x}")#text(" appropriately) in this setting; see below the fold.")

#text("The reason that we call this a ")#mi("{C^{1,1}}")#text(" Baker-Campbell-Hausdorff formula is that if the group operation ")#mi("{*}")#text(" has ")#mi("{C^{1,1}}")#text(" regularity, and has ")#mi("{0}")#text(" as an identity element, then Taylor expansion already gives ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(", and in exponential coordinates (which, as it turns out, can be defined without much difficulty in the ")#mi("{C^{1,1}}")#text(" category) one automatically has ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(3)")]#text(".")

#text("We will record the proof of Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("1")]#text(" below the fold; it largely follows the classical derivation of the BCH formula, but due to the low regularity one will rely on tools such as telescoping series and Riemann sums rather than on the fundamental theorem of calculus. As an application of this theorem, we can give an alternate derivation of one of the components of the solution to Hilbert’s fifth problem, namely the construction of a Lie group structure from a Gleason metric, which was covered in ")#link("https://terrytao.wordpress.com/2011/06/15/hilberts-fifth-problem-and-gleason-metrics/")[#text("the previous post")]#text("; we discuss this at the end of this article. With this approach, one can avoid any appeal to von Neumann’s theorem and Cartan’s theorem (discussed in ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("this post")]#text("), or the Kuranishi-Gleason extension theorem (discussed in ")#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/")[#text("this post")]#text(").")

#metadata(none) <tao-20c8b597f7d6c77f67a6>

#heading(level: 1)[#strong[#text(" — 1. Proof of Baker-Campbell-Hausdorff formula — ")]]

#text("We begin with some simple bounds of Lipschitz and ")#mi("{C^{1,1}}")#text(" type on the group law ")#mi("{*}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Lipschitz bounds)")]#text(" ")#metadata(none) <tao-8ac1ef5381caf75418d7>#text(" If ")#mi("{x,y,z}")#text(" are sufficiently close to the origin, then ")#metadata(none) <tao-723013d616bc63f2582f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("x * y = x + y + O( \\left|x+y\\right| \\left|y\\right| )", block: true)]]

#text("and ")#metadata(none) <tao-d8150a8f796972239933>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("x * y = x + y + O( \\left|x+y\\right| \\left|x\\right| )", block: true)]]

#text("and ")#metadata(none) <tao-fc60dfc45dcf693f71be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("x * y = x * z + O( \\left|y-z\\right| )", block: true)]]

#text("and similarly ")#metadata(none) <tao-de3c66d3e51b7c1d670e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("y * x = z * x + O( \\left|y-z\\right| ).", block: true)]]
]

#emph[#text("Proof:")]#text(" We begin with the first estimate. If ")#mi("{h := x * y}")#text(", then ")#mi("{h}")#text(" is small, and (on multiplying by ")#mi("{-y}")#text(") we have ")#mi("{x = h * (-y)}")#text(". By ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("x = h - y + O(\\left|h\\right| \\left|y\\right|)", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("x+y = h ( 1 + O(\\left|y\\right|) ).", block: true)]]

#text("As ")#mi("{y}")#text(" is small, we may invert the ")#tao-math("{1+O(\\left|y\\right|)}", block: false)#text(" factor to obtain ")#link(<tao-723013d616bc63f2582f>)[#text("(4)")]#text(". The proof of ")#link(<tao-d8150a8f796972239933>)[#text("(5)")]#text(" is similar.")

#text("Now we prove ")#link(<tao-fc60dfc45dcf693f71be>)[#text("(6)")]#text(". Write ")#mi("{h := (-y) * z}")#text(". From ")#link(<tao-723013d616bc63f2582f>)[#text("(4)")]#text(" or ")#link(<tao-d8150a8f796972239933>)[#text("(5)")]#text(" we have ")#tao-math("{h = O(\\left|y-z\\right|)}", block: false)#text(". Since ")#mi("{z = y * h}")#text(", we have ")#mi("{x*z = x*y*h}")#text(", so by ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" ")#tao-math("{x*z = x*y + O(\\left|h\\right|)}", block: false)#text(", and the claim follows. The proof of ")#link(<tao-de3c66d3e51b7c1d670e>)[#text("(7)")]#text(" is similar. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Adjoint representation)")]#text(" For all ")#mi("{x}")#text(" sufficiently close to the origin, there exists a linear transformation ")#mi("{\\text{Ad}_x: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" such that ")#mi("{x * y * (-x) = \\text{Ad}_x(y)}")#text(" for all ")#mi("{y}")#text(" sufficiently close to the origin.")
]

#emph[#text("Proof:")]#text(" Fix ")#mi("{x}")#text(". The map ")#mi("{y \\mapsto x * y * (-x)}")#text(" is continuous near the origin, so it will suffice to establish additivity, in the sense that")

#align(center)[#tao-fit-display[#mitex("x * (y+z) * (-x) = (x * y * (-x)) + (x * z * (-x))")]]

#text("for ")#mi("{y,z}")#text(" sufficiently close to the origin.")

#text("Let ")#mi("{n}")#text(" be a large natural number. Then from ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("(y+z) = (\\frac{1}{n} y + \\frac{1}{n} z)^{*n}")]]

#text("where ")#mi("{x^{*n} = x * \\ldots * x}")#text(" is the product of ")#mi("{n}")#text(" copies of ")#mi("{x}")#text(". Conjugating this by ")#mi("{x}")#text(", we see that")

#tao-aligned(keep: true)[


#tao-math("x * (y+z) * (-x)  & = (x * (\\frac{1}{n} y + \\frac{1}{n} z) * (-x))^n", block: true)



#tao-math(" & = n (x * (\\frac{1}{n} y + \\frac{1}{n} z) * (-x)).", block: true)
]

#text("But from ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} y + \\frac{1}{n} z = \\frac{1}{n} y * \\frac{1}{n} z + O( \\frac{1}{n^2} )")]]

#text("and thus (by Lemma ")#link(<tao-8ac1ef5381caf75418d7>)[#text("2")]#text(")")

#align(center)[#tao-fit-display[#mitex("x * (\\frac{1}{n} y + \\frac{1}{n} z) * (-x) = x * \\frac{1}{n} y * \\frac{1}{n} z * (-x) + O( \\frac{1}{n^2} ).")]]

#text("But if we split ")#mi("{x * \\frac{1}{n} y * \\frac{1}{n} z * (-x)}")#text(" as the product of ")#mi("{x * \\frac{1}{n} y * (-x) }")#text(" and ")#mi("{x * \\frac{1}{n} z * (-x)}")#text(" and use ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("x * \\frac{1}{n} y * \\frac{1}{n} z * (-x) = x * \\frac{1}{n} y * (-x) + x * \\frac{1}{n} z * (-x) + O(\\frac{1}{n^2}).")]]

#text("Putting all this together we see that")

#tao-aligned(keep: true)[


#tao-math("x * (y+z) * (-x)  & = n( x * \\frac{1}{n} y * (-x) + x * \\frac{1}{n} z * (-x) + O(\\frac{1}{n^2}) )", block: true)



#tao-math(" & = x * y * (-x) + x * z * (-x) + O(\\frac{1}{n});", block: true)
]

#text("sending ")#mi("{n \\rightarrow \\infty}")#text(" we obtain the claim. ")#mi("\\Box")

#text("From ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{Ad}_x - I \\right\\|_{op} = O(\\left|x\\right|)", block: true)]]

#text("for ")#mi("{x}")#text(" sufficiently small. Also from the associativity property we see that ")#metadata(none) <tao-a116a1e6cc53a1c07bd1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\text{Ad}_{x*y} = \\text{Ad}_x \\text{Ad}_y")]]

#text("for all ")#mi("{x,y}")#text(" sufficiently small. Combining these two properties (and using ")#link(<tao-723013d616bc63f2582f>)[#text("(4)")]#text(") we conclude in particular that ")#metadata(none) <tao-b6b7e9c088359e36f5de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\text{Ad}_x - \\text{Ad}_y \\right\\|_{op} = O(\\left|x-y\\right|)", block: true)]]

#text("for ")#mi("{x,y}")#text(" sufficiently small. Thus we see that ")#mi("{Ad}")#text(" is a continuous linear representation. In particular, ")#mi("{t \\mapsto \\text{Ad}_{tx}}")#text(" is a continuous homomorphism into a linear group, and so we have the ")#emph[#text("Hadamard lemma")]

#align(center)[#tao-fit-display[#mitex("\\text{Ad}_x = \\exp( \\text{ad}_x )")]]

#text("where ")#mi("{\\text{ad}_x: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is the linear transformation")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_x = \\frac{d}{dt} \\text{Ad}_{tx} |_{t=0}.")]]

#text("From ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(8)")]#text(", ")#link(<tao-b6b7e9c088359e36f5de>)[#text("(9)")]#text(", ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\text{Ad}_{tx} \\text{Ad}_{ty} = \\text{Ad}_{t(x+y)} + O(\\left|t\\right|^2)", block: true)]]

#text("for ")#mi("{x,y,t}")#text(" sufficiently small, and so by the product rule we have")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_{x+y} = \\text{ad}_x + \\text{ad}_y.")]]

#text("Also we clearly have ")#mi("{\\text{ad}_{tx} = t \\text{ad}_x}")#text(" for ")#mi("{x, t}")#text(" small. Thus we see that ")#mi("{\\text{ad}_x}")#text(" is linear in ")#mi("{x}")#text(", and so we have")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_x y = [x,y]")]]

#text("for some bilinear form ")#mi("{[,]: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(".")

#text("One can show that this bilinear form in fact defines a Lie bracket, but for now, all we need is that it is manifestly real analytic (since all bilinear forms are polynomial and thus analytic), thus ")#mi("{\\text{ad}_x}")#text(" and ")#mi("{\\text{Ad}_x}")#text(" depend analytically on ")#mi("{x}")#text(".")

#text("We now give an important approximation to ")#mi("{x*y}")#text(" in the case when ")#mi("{y}")#text(" is small:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-8e76e9a00cae1534d7e0>#text(" For ")#mi("{x,y}")#text(" sufficiently small, we have")

#align(center)[#tao-fit-display[#tao-math("x*y = x + F(\\text{Ad}_x) y + O(\\left|y\\right|^2)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(z) := \\frac{z \\log z}{z-1}.")]]
]

#emph[#text("Proof:")]#text(" If we write ")#mi("{z := x*y - x}")#text(", then ")#tao-math("{z = O(\\left|y\\right|)}", block: false)#text(" (by ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(") and")

#align(center)[#tao-fit-display[#mitex("(-x) * (x+z) = y.")]]

#text("We will shortly establish the approximation ")#metadata(none) <tao-3fc7c96a56b6e20ca727>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("(-x) * (x+z) = \\frac{1-\\exp(-\\text{ad}_x)}{\\text{ad}_x} z + O( \\left|z\\right|^2 );", block: true)]]

#text("inverting")

#align(center)[#tao-fit-display[#mitex("\\frac{1-\\exp(-\\text{ad}_x)}{\\text{ad}_x} = \\frac{\\text{Ad}_x - 1}{\\text{Ad}_x \\log \\text{Ad}_x}")]]

#text("we obtain the claim.")

#text("It remains to verify ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(10)")]#text(". Let ")#mi("{n}")#text(" be a large natural number. We can expand the left-hand side of ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(10)")]#text(" as a telescoping series ")#metadata(none) <tao-d2dae6d1b4625413eade>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{j=0}^{n-1} (-\\frac{j+1}{n} x) * (\\frac{j+1}{n} x + \\frac{j+1}{n} z) - (-\\frac{j}{n} x) * (\\frac{j}{n} x + \\frac{j}{n} z).")]]

#text("Using ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(3)")]#text(", the first summand can be expanded as")

#align(center)[#tao-fit-display[#mitex("(-\\frac{j}{n} x) * (-\\frac{x}{n}) * (\\frac{x}{n} + \\frac{z}{n}) * (\\frac{j}{n} x + \\frac{j}{n} z).")]]

#text("From ")#link(<tao-723013d616bc63f2582f>)[#text("(4)")]#text(" one has ")#tao-math("{(-\\frac{x}{n}) * (\\frac{x}{n} + \\frac{z}{n}) = \\frac{z}{n} + O( \\frac{\\left|z\\right|}{n^2} )}", block: false)#text(", so by ")#link(<tao-fc60dfc45dcf693f71be>)[#text("(6)")]#text(", ")#link(<tao-de3c66d3e51b7c1d670e>)[#text("(7)")]#text(" we can write the preceding expression as")

#align(center)[#tao-fit-display[#tao-math("(-\\frac{j}{n} x) * \\frac{z}{n} * (\\frac{j}{n} x + \\frac{j}{n} z) + O( \\frac{\\left|z\\right|}{n^2} )", block: true)]]

#text("which by definition of ")#mi("{\\text{Ad}}")#text(" can be rewritten as ")#metadata(none) <tao-882faefe28371f8145b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("(\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n}) * (-\\frac{j}{n} x) * (\\frac{j}{n} x + \\frac{j}{n} z) + O( \\frac{\\left|z\\right|}{n^2} ).", block: true)]]

#text("From ")#link(<tao-723013d616bc63f2582f>)[#text("(4)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("(-\\frac{j}{n} x) * (\\frac{j}{n} x + \\frac{j}{n} z) = O( \\left|z\\right| )", block: true)]]

#text("while from ")#link(<tao-b6b7e9c088359e36f5de>)[#text("(9)")]#text(" one has ")#tao-math("{\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n} = O( \\left|z\\right|/n )}", block: false)#text(", hence from ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" we can rewrite ")#link(<tao-882faefe28371f8145b8>)[#text("(12)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n} + (-\\frac{j}{n} x) * (\\frac{j}{n} x + \\frac{j}{n} z) + O(\\frac{\\left|z\\right|^2}{n}) + O( \\frac{\\left|z\\right|}{n^2} ).", block: true)]]

#text("Inserting this back into ")#link(<tao-d2dae6d1b4625413eade>)[#text("(11)")]#text(", we can thus write the left-hand side of ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{j=0}^{n-1} \\text{Ad}_{-\\frac{j}{n} x} \\frac{z}{n}) + O( \\left|z\\right|^2 ) + O( \\frac{\\left|z\\right|}{n} ).", block: true)]]

#text("Writing ")#mi("{\\text{Ad}_{-\\frac{j}{n} x} = \\exp( - \\frac{j}{n} \\text{ad}_x )}")#text(", and then letting ")#mi("{n \\rightarrow \\infty}")#text(", we conclude (from the convergence of the Riemann sum to the Riemann integral) that")

#align(center)[#tao-fit-display[#tao-math("(-x) * (x+z) = \\int_0^1 \\exp(-t \\text{ad}_x) z\\ dt + O( \\left|z\\right|^2 )", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("We can then integrate this to obtain an exact formula for ")#mi("{*}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Baker-Campbell-Hausdorff-Dynkin formula)")]#text(" For ")#mi("{x, y}")#text(" sufficiently small, one has")

#align(center)[#tao-fit-display[#mitex("x * y = x + \\int_0^1 F( \\text{Ad}_x \\text{Ad}_{ty} ) y\\ dt.")]]
]

#text("The right-hand side is clearly real analytic in ")#mi("{x}")#text(" and ")#mi("{y}")#text(", and Lemma ")#link(<tao-833a61955631ab7a5609>)[#text("1")]#text(" follows.")

#emph[#text("Proof:")]#text(" Let ")#mi("{n}")#text(" be a large natural number. We can express ")#mi("{x*y}")#text(" as the telescoping sum")

#align(center)[#tao-fit-display[#mitex("x + \\sum_{j=0}^{n-1} x * (\\frac{j+1}{n} y) - x * (\\frac{j}{n} y).")]]

#text("From ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(3)")]#text(" followed by Lemma ")#link(<tao-8e76e9a00cae1534d7e0>)[#text("4")]#text(" and ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(8)")]#text(", one has")

#tao-aligned(keep: true)[


#tao-math("x * (\\frac{j+1}{n} y)  & = x * (\\frac{j}{n} y) * \\frac{y}{n}", block: true)



#tao-math(" & = x * (\\frac{j}{n} y) + F( \\text{Ad}_x \\text{Ad}_{\\frac{j}{n} y} ) \\frac{y}{n} + O( \\frac{1}{n^2} ).", block: true)
]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("x*y = x + \\frac{1}{n} \\sum_{j=0}^{n-1} F( \\text{Ad}_x \\text{Ad}_{\\frac{j}{n} y} ) y + O( \\frac{1}{n} ).")]]

#text("Sending ")#mi("{n \\rightarrow \\infty}")#text(", so that the Riemann sum converges to a Riemann integral, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" It seems likely that one can relax the ")#mi("{C^{1,1}}")#text(" type condition ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(" in the above arguments to the weaker ")#mi("{C^1}")#text(" conditions")

#align(center)[#tao-fit-display[#tao-math("x * y = x + y + o_{y \\rightarrow 0}(\\left|x\\right|)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("x * y = x + y + o_{x \\rightarrow 0}(\\left|y\\right|)", block: true)]]

#text("where ")#tao-math("{o_{y \\rightarrow 0}(\\left|x\\right|)}", block: false)#text(" is bounded by ")#tao-math("{c(\\left|y\\right|) \\left|x\\right|}", block: false)#text(" for some function ")#mi("{c}")#text(" that goes to zero at zero, and similarly for ")#tao-math("{o_{x \\rightarrow 0}(\\left|y\\right|)}", block: false)#text(", as the effect of this is to replace various ")#mi("{O(\\frac{1}{n})}")#text(" errors with errors ")#mi("{o_{n \\rightarrow \\infty}(1)}")#text(" that still go to zero as ")#mi("{n \\rightarrow \\infty}")#text(". However, ")#mi("{C^{1,1}}")#text(" type regularity is what is provided to us by Gleason metrics, so this type of regularity suffices for applications related to Hilbert’s fifth problem.")
]

#heading(level: 1)[#strong[#text(" — 2. Building a Lie group from a Gleason metric — ")]]

#text("We can now give a slightly alternate derivation of Theorem 7 from the ")#link("https://terrytao.wordpress.com/2011/06/15/hilberts-fifth-problem-and-gleason-metrics/")[#text("previous post")]#text(", which asserted that every locally compact group with a Gleason metric was isomorphic to a Lie group. As in those notes, one begins by constructing the space ")#mi("{L(G)}")#text(" of one-parameter subgroups, demonstrating that it is isomorphic to a finite-dimensional vector space ")#mi("{{\\bf R}^d}")#text(", constructing the exponential map ")#mi("{\\exp: L(G) \\rightarrow G}")#text(", and then showing that this map is locally a homeomorphism. Thus we can identify a neighbourhood of the identity in ")#mi("{G}")#text(" with a neighbourhood of the origin in ")#mi("{{\\bf R}^d}")#text(", thus giving a locally defined multiplication operation ")#mi("{*}")#text(" in ")#mi("{{\\bf R}^d}")#text(". By construction, this map is continuous and associative, and obeys the homogeneity ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(3)")]#text(" by the definition of the exponential map. Now we verify the ")#mi("{C^{1,1}}")#text(" estimate ")#link(<tao-a0b1505271eb8bd05b38>)[#text("(2)")]#text(". From Lemma 8 in the ")#link("https://terrytao.wordpress.com/2011/06/15/hilberts-fifth-problem-and-gleason-metrics/")[#text("previous post")]#text(", one can verify that the exponential map is bilipschitz near the origin, and the claim is now to show that")

#align(center)[#tao-fit-display[#tao-math("d( \\phi(1) \\psi(1), (\\phi+\\psi)(1)) \\ll \\left\\| \\phi(1) \\right\\| \\left\\| \\psi(1) \\right\\|", block: true)]]

#text("for ")#mi("{\\phi, \\psi}")#text(" sufficiently close to the identity in ")#mi("{L(G)}")#text(". By definition of ")#mi("{\\phi+\\psi}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("d( \\phi(1) \\psi(1), (\\phi(1/n)\\psi(1/n))^n) \\ll \\left\\| \\phi(1) \\right\\| \\left\\| \\psi(1) \\right\\|", block: true)]]

#text("for all ")#mi("{n}")#text("; but this follows from Lemma 8 of the previous post (and the observation, from the escape property, that ")#tao-math("{\\left\\|\\phi(1/n)\\right\\| \\ll \\left\\|\\phi(1)\\right\\|/n}", block: false)#text(" and ")#tao-math("{\\left\\| \\psi(1/n) \\right\\| \\ll \\left\\| \\psi(1)\\right\\|/n}", block: false)#text(").")

#text("Applying Theorem ")#link(<tao-833a61955631ab7a5609>)[#text("1")]#text(", we now see that ")#mi("{*}")#text(" is smooth, and so the group operations are smooth near the origin. Also, for any ")#mi("{g \\in G}")#text(", conjugation by ")#mi("{g}")#text(" is an (local) outer automorphism of a neighbourhood of the identity, hence also an automorphism of ")#mi("{L(G)}")#text(". Since linear maps are automatically smooth, we conclude that conjugation by ")#mi("{g}")#text(" is smooth near the origin in exponential coordinates. From this, we can transport the smooth structure from a neighbourhood of the origin to the rest of ")#mi("{G}")#text(" (using either left or right translations), and obtain a Lie group structure as required.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of “Metric spaces with dilations”, the book draft updated | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-54129")[#strong[#text("“Metric spaces with dilations”, the book draft updated | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2011")])]

#text("[…] that the bracket is related to the commutator). This will be posted on arxiv soon. UPDATE: see this post by Tao on the (commutative, say) BCH formula. It is commutative because of his “radial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Planar rooted trees and Baker-Campbell-Hausdorff formula | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-54186")[#strong[#text("Planar rooted trees and Baker-Campbell-Hausdorff formula | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2011")])]

#text("[…] the bibliography!) for the subject of writing “finitary“, “noncommutative” BCH formulae, from self-similarity arguments using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of subashpoudel")]], [#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-54206")[#strong[#text("subashpoudel")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2011")])]

#text("Nice.")#linebreak()#text(" Thanks for sharing the article and the formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-54261")[#strong[#text("Eighth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")]

#text("[…] Terence Tao: Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem, Hilbert’s Fifth Problem and Gleason metrics, The C^{1,1} Baker-Campbell-Hausdorff formula […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noncommutative Baker-Campbell-Hausdorff formula: the problem | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-54569")[#strong[#text("Noncommutative Baker-Campbell-Hausdorff formula: the problem | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2011")])]

#text("[…] come back to a problem alluded in a previous post, where the proof of the Baker-Campbell-Hausdorff formula from this post by Tao is characterized as “commutative”, because of the “radial homogeneity” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason’s lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/#comment-56085")[#strong[#text("Gleason’s lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2011")])]

#text("[…] regularity is relatively routine, with two different such approaches indicated in the preceding blog posts.) In particular, the easiest task to accomplish will be that of Proposition 10, which establishes […]")
]
