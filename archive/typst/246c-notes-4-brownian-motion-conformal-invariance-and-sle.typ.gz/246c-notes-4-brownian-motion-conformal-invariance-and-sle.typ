// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/
// Converted to Typst by tao2typ: "2026-10-14T16:38:22.263493+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246C notes 4: Brownian motion, conformal invariance, and SLE", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246C notes 4: Brownian motion, conformal invariance, and SLE")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 May 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/")[#text("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("Notes 3")]#text(".")#linebreak()#text(" ")#strong[#text("Important note:")]#text(" As this is not a course in probability, we will try to avoid developing the general theory of stochastic calculus (which includes such concepts as filtrations, martingales, and Ito calculus). This will unfortunately limit what we can actually prove rigorously, and so at some places the arguments will be somewhat informal in nature. A rigorous treatment of many of the topics here can be found for instance in Lawler’s ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Conformally Invariant Processes in the Plane")]#text(", from which much of the material here is drawn.")#linebreak()#text(" In these notes, random variables will be denoted in boldface.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" A real random variable ")#mi("{\\mathbf{X}}")#text(" is said to be normally distributed with mean ")#mi("{x_0 \\in {\\bf R}}")#text(" and variance ")#mi("{\\sigma^2 > 0}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} F(\\mathbf{X}) = \\frac{1}{\\sqrt{2\\pi} \\sigma} \\int_{\\bf R} e^{-(x-x_0)^2/2\\sigma^2} F(x)\\ dx")]]

#text("for all test functions ")#mi("{F \\in C_c({\\bf R})}")#text(". Similarly, a complex random variable ")#mi("{\\mathbf{Z}}")#text(" is said to be normally distributed with mean ")#mi("{z_0 \\in {\\bf R}}")#text(" and variance ")#mi("{\\sigma^2>0}")#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} F(\\mathbf{Z}) = \\frac{1}{\\pi \\sigma^2} \\int_{\\bf C} e^{-\\left|z-z_0\\right|^2/\\sigma^2} F(z)\\ dx dy", block: true)]]

#text("for all test functions ")#mi("{F \\in C_c({\\bf C})}")#text(", where ")#mi("{dx dy}")#text(" is the area element on ")#mi("{{\\bf C}}")#text(".")#linebreak()#text(" A ")#emph[#text("real Brownian motion")]#text(" with base point ")#mi("{x_0 \\in {\\bf R}}")#text(" is a random, almost surely continuous function ")#mi("{\\mathbf{B}^{x_0}: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" (using the locally uniform topology on continuous functions) with the property that (almost surely) ")#mi("{\\mathbf{B}^{x_0}(0) = x_0}")#text(", and for any sequence of times ")#mi("{0 \\leq t_0 < t_1 < t_2 < \\dots < t_n}")#text(", the increments ")#mi("{\\mathbf{B}^{x_0}(t_i) - \\mathbf{B}^{x_0}(t_{i-1})}")#text(" for ")#mi("{i=1,\\dots,n}")#text(" are independent real random variables that are normally distributed with mean zero and variance ")#mi("{t_i - t_{i-1}}")#text(". Similarly, a ")#emph[#text("complex Brownian motion")]#text(" with base point ")#mi("{z_0 \\in {\\bf C}}")#text(" is a random, almost surely continuous function ")#mi("{\\mathbf{B}^{z_0}: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" with the property that ")#mi("{\\mathbf{B}^{z_0}(0) = z_0}")#text(" and for any sequence of times ")#mi("{0 \\leq t_0 < t_1 < t_2 < \\dots < t_n}")#text(", the increments ")#mi("{\\mathbf{B}^{z_0}(t_i) - \\mathbf{B}^{z_0}(t_{i-1})}")#text(" for ")#mi("{i=1,\\dots,n}")#text(" are independent complex random variables that are normally distributed with mean zero and variance ")#mi("{t_i - t_{i-1}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Thanks to the central limit theorem, the hypothesis that the increments ")#mi("{\\mathbf{B}^{x_0}(t_i) - \\mathbf{B}^{x_0}(t_{i-1})}")#text(" be normally distributed can be dropped from the definition of a Brownian motion, so long as one retains the independence and the normalisation of the mean and variance (technically one also needs some uniform integrability on the increments beyond the second moment, but we will not detail this here). A similar statement is also true for the complex Brownian motion (where now we need to normalise the variances and covariances of the real and imaginary parts of the increments).")
]

#text("Real and complex Brownian motions exist from any base point ")#mi("{x_0}")#text(" or ")#mi("{z_0}")#text("; see e.g. ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(" for a construction. We have the following simple invariances:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]

#list(
[#text("(i) (Translation invariance) If ")#mi("{\\mathbf{B}^{x_0}}")#text(" is a real Brownian motion with base point ")#mi("{x_0 \\in {\\bf R}}")#text(", and ")#mi("{h \\in {\\bf R}}")#text(", show that ")#mi("{\\mathbf{B}^{x_0}+h}")#text(" is a real Brownian motion with base point ")#mi("{x_0+h}")#text(". Similarly, if ")#mi("{\\mathbf{B}^{z_0}}")#text(" is a complex Brownian motion with base point ")#mi("{z_0 \\in {\\bf R}}")#text(", and ")#mi("{h \\in {\\bf C}}")#text(", show that ")#mi("{\\mathbf{B}^{z_0}+c}")#text(" is a complex Brownian motion with base point ")#mi("{z_0+h}")#text(".")],
[#text("(ii) (Dilation invariance) If ")#mi("{\\mathbf{B}^{0}}")#text(" is a real Brownian motion with base point ")#mi("{0}")#text(", and ")#mi("{\\lambda \\in {\\bf R}}")#text(" is non-zero, show that ")#tao-math("{t \\mapsto \\lambda \\mathbf{B}^0(t / \\left|\\lambda\\right|^{1/2})}", block: false)#text(" is also a real Brownian motion with base point ")#mi("{0}")#text(". Similarly, if ")#mi("{\\mathbf{B}^0}")#text(" is a complex Brownian motion with base point ")#mi("{0}")#text(", and ")#mi("{\\lambda \\in {\\bf C}}")#text(" is non-zero, show that ")#tao-math("{t \\mapsto \\lambda \\mathbf{B}^0(t / \\left|\\lambda\\right|^{1/2})}", block: false)#text(" is also a complex Brownian motion with base point ")#mi("{0}")#text(".")],
[#text("(iii) (Real and imaginary parts) If ")#mi("{\\mathbf{B}^0}")#text(" is a complex Brownian motion with base point ")#mi("{0}")#text(", show that ")#mi("{\\sqrt{2} \\mathrm{Re} \\mathbf{B}^0}")#text(" and ")#mi("{\\sqrt{2} \\mathrm{Im} \\mathbf{B}^0}")#text(" are independent real Brownian motions with base point ")#mi("{0}")#text(". Conversely, if ")#mi("{\\mathbf{B}^0_1, \\mathbf{B}^0_2}")#text(" are independent real Brownian motions of base point ")#mi("{0}")#text(", show that ")#mi("{\\frac{1}{\\sqrt{2}} (\\mathbf{B}^0_1 + i \\mathbf{B}^0_2)}")#text(" is a complex Brownian motion with base point ")#mi("{0}")#text(".")]
)
]

#text("The next lemma is a special case of the ")#link("https://en.wikipedia.org/wiki/Optional_stopping_theorem")[#text("optional stopping theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Optional stopping identities)")]#text(" ")#metadata(none) <tao-25bd152797157817e497>

#list(
[#text("(i) (Real case) Let ")#mi("{\\mathbf{B}^{x_0}}")#text(" be a real Brownian motion with base point ")#mi("{x_0 \\in {\\bf R}}")#text(". Let ")#mi("{\\mathbf{t}}")#text(" be a bounded stopping time – a bounded random variable with the property that for any time ")#mi("{t \\geq 0}")#text(", the event that ")#mi("{\\mathbf{t} \\leq t}")#text(" is determined by the values of the trajectory ")#mi("{\\mathbf{B}^{x_0}}")#text(" for times up to ")#mi("{t}")#text(" (or more precisely, this event is measurable with respect to the ")#mi("{\\sigma}")#text(" algebra generated by this proprtion of the trajectory). Then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathbf{B}^{x_0}(\\mathbf{t}) = x_0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} (\\mathbf{B}^{x_0}(\\mathbf{t})-x_0)^2 - \\mathbf{t} = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} (\\mathbf{B}^{x_0}(\\mathbf{t})-x_0)^4 = O( \\mathop{\\bf E} \\mathbf{t}^2 ).")]]],
[#text("(ii) (Complex case) Let ")#mi("{\\mathbf{B}^{z_0}}")#text(" be a complex Brownian motion with base point ")#mi("{z_0 \\in {\\bf C}}")#text(". Let ")#mi("{\\mathbf{t}}")#text(" be a bounded stopping time – a bounded random variable with the property that for any time ")#mi("{t \\geq 0}")#text(", the event that ")#mi("{\\mathbf{t} \\leq t}")#text(" is determined by the values of the trajectory ")#mi("{\\mathbf{B}^{x_0}}")#text(" for times up to ")#mi("{t}")#text(". Then")

#tao-aligned(keep: true)[


#tao-math("\\mathop{\\bf E} \\mathbf{B}^{z_0}(\\mathbf{t})  & = z_0", block: true)



#tao-math("\\mathop{\\bf E} (\\mathrm{Re}(\\mathbf{B}^{z_0}(\\mathbf{t})-z_0))^2 - \\frac{1}{2} \\mathbf{t}  & = 0", block: true)



#tao-math("\\mathop{\\bf E} (\\mathrm{Im}(\\mathbf{B}^{z_0}(\\mathbf{t})-z_0))^2 - \\frac{1}{2} \\mathbf{t}  & = 0", block: true)



#tao-math("\\mathop{\\bf E} \\mathrm{Re}(\\mathbf{B}^{z_0}(\\mathbf{t})-z_0) \\mathrm{Im}(\\mathbf{B}^{z_0}(\\mathbf{t})-z_0)  & = 0", block: true)



#tao-math("\\mathop{\\bf E} \\left|\\mathbf{B}^{x_0}(\\mathbf{t})-z_0\\right|^4  & = O( \\mathop{\\bf E} \\mathbf{t}^2 ).", block: true)
]]
)
]

#emph[#text("Proof:")]#text(" (Slightly informal) We just prove (i) and leave (ii) as an exercise. By translation invariance we can take ")#mi("{x_0=0}")#text(". Let ")#mi("{T}")#text(" be an upper bound for ")#mi("{\\mathbf{t}}")#text(". Since ")#mi("{\\mathbf{B}^0(T)}")#text(" is a real normally distributed variable with mean zero and variance ")#mi("{T}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathbf{B}^0( T ) = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathbf{B}^0( T )^2 = T")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathbf{B}^0( T )^4 = 3T^2.")]]

#text("By ")#link("https://en.wikipedia.org/wiki/Law_of_total_expectation")[#text("the law of total expectation")]#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathop{\\bf E}(\\mathbf{B}^0( T ) | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathop{\\bf E}((\\mathbf{B}^0( T ))^2 | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = T")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathop{\\bf E}((\\mathbf{B}^0( T ))^4 | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = 3T^2")]]

#text("where the inner conditional expectations are with respect to the event that ")#mi("{\\mathbf{t}, \\mathbf{B}^{0}(\\mathbf{t})}")#text(" attains a particular point in ")#mi("{S}")#text(". However, from the independent increment nature of Brownian motion, once one conditions ")#mi("{(\\mathbf{t}, \\mathbf{B}^{0}(\\mathbf{t}))}")#text(" to a fixed point ")#mi("{(t, x)}")#text(", the random variable ")#mi("{\\mathbf{B}^0(T)}")#text(" becomes a real normally distributed variable with mean ")#mi("{x}")#text(" and variance ")#mi("{T-t}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}(\\mathbf{B}^0( T ) | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = \\mathbf{B}^{z_0}(\\mathbf{t})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( (\\mathbf{B}^0( T ))^2 | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = \\mathbf{B}^{z_0}(\\mathbf{t})^2 + T - \\mathbf{t}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( (\\mathbf{B}^0( T ))^4 | \\mathbf{t}, \\mathbf{B}^{z_0}(\\mathbf{t}) ) = \\mathbf{B}^{z_0}(\\mathbf{t})^4 + 6(T - \\mathbf{t}) \\mathbf{B}^{z_0}(\\mathbf{t})^2 + 3(T - \\mathbf{t})^2")]]

#text("which give the first two claims, and (after some algebra) the identity")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mathbf{B}^{z_0}(\\mathbf{t})^4 - 6 \\mathbf{t} \\mathbf{B}^{z_0}(\\mathbf{t})^2 + 3 \\mathbf{t}^2 = 0")]]

#text("which then also gives the third claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Prove the second part of Lemma ")#link(<tao-25bd152797157817e497>)[#text("4")]#text(".")
]

#metadata(none) <tao-a89c3c7762c9486ab6d6>

#heading(level: 1)[#strong[#text(" — 1. Conformal invariance of Brownian motion — ")]]

#text("Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and ")#mi("{z_0}")#text(" a point in ")#mi("{U}")#text(". We can define the ")#emph[#text("complex Brownian motion with base point ")#mi("{z_0}")#text(" restricted to ")#mi("{U}")]#text(" to be the restriction ")#mi("{\\mathbf{B}^{z_0}: [0,\\mathbf{t}) \\rightarrow U}")#text(" of a complex Brownian motion ")#mi("{\\mathbf{B}^{z_0}}")#text(" with base point ")#mi("{z_0}")#text(" to the first time ")#mi("{\\mathbf{t} \\in (0,+\\infty]}")#text(" in which the Brownian motion exits ")#mi("{U}")#text(" (or ")#mi("{+\\infty}")#text(" if no such time exists). We have a fundamental conformal invariance theorem of Lévy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Lévy’s theorem on conformal invariance of Brownian motion)")]#text(" Let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a conformal map between two open subsets ")#mi("{U,V}")#text(" of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{\\mathbf{B}^{z_0}: [0, \\mathbf{t}) \\rightarrow U}")#text(" be a complex Brownian motion with base point ")#mi("{z_0}")#text(" restricted to ")#mi("{U}")#text(". Define a rescaling ")#mi("{\\mathbf{\\tau}: [0, \\mathbf{t}) \\rightarrow [0,+\\infty)}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\mathbf{\\tau}(t) := \\int_0^t \\left|\\phi^{\\prime}(\\mathbf{B}^{z_0}(s))\\right|^2\\ ds.", block: true)]]

#text("Note that this is almost surely a continuous strictly monotone increasing function. Set ")#mi("{\\mathbf{t}^{\\prime} := \\lim_{t \\rightarrow \\mathbf{t}} \\mathbf{\\tau}(t)}")#text(" (so that ")#mi("{\\mathbf{\\tau}}")#text(" is a homeomorphism from ")#mi("{[0,\\mathbf{t})}")#text(" to ")#mi("{[0,\\mathbf{t}^{\\prime})}")#text("), and let ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}: [0, \\mathbf{t}^{\\prime}) \\rightarrow V}")#text(" be the function defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde{\\mathbf{B}}^{\\phi(z_0)}(\\mathbf{\\tau}(t)) := \\phi( \\mathbf{B}^{z_0}( t) ).")]]

#text("Then ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" is a complex Brownian motion with base point ")#mi("{\\phi(z_0)}")#text(" restricted to ")#mi("{V}")#text(".")
]

#text("Note that this significantly generalises the translation and dilation invariance of complex Brownian motion.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Somewhat informal – to do things properly one should first set up ")#link("https://en.wikipedia.org/wiki/It%C3%B4_calculus")[#text("Ito calculus")]#text(") To avoid technicalities we will assume that ")#tao-math("{\\left|\\phi^{\\prime}\\right|}", block: false)#text(" is bounded above and below on ")#mi("{U}")#text(", so that the map ")#mi("{\\mathbf{\\tau}}")#text(" is uniformly bilipschitz; the general case can be obtained from this case by a limiting argument that is not detailed here. With this assumption, we see that ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" almost surely extends continuously to the endpoint time ")#mi("{\\mathbf{t}^{\\prime}}")#text(" if this time is finite. Once one conditions on the value of ")#mi("{\\mathbf{t}^{\\prime}}")#text(" and ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" up to this time ")#mi("{\\mathbf{t}^{\\prime}}")#text(", we then extend this motion further (if ")#mi("{\\mathbf{t}^{\\prime} < \\infty}")#text(") by declaring ")#mi("{t \\mapsto \\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime})}")#text(" for ")#mi("{t^{\\prime} \\geq \\mathbf{t}^{\\prime}}")#text(" to be a complex Brownian motion with base point ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(\\mathbf{t^{\\prime}})}")#text(", translated in time by ")#mi("{\\mathbf{t}^{\\prime}}")#text(". Now ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" is defined on all of ")#mi("{[0,+\\infty)}")#text(", and it will suffice to show that this is a complex Brownian motion based at ")#mi("{\\phi(z_0)}")#text(". The basing is clear, so it suffices to show for all times ")#mi("{0 \\leq t^{\\prime}_0 < t^{\\prime}_1 < \\dots < t^{\\prime}_n}")#text(" that the increments ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_i) - \\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_{i-1})}")#text(" are independent and normally distributed with mean zero and variance ")#mi("{t^{\\prime}_i - t^{\\prime}_{i-1}}")#text(".")#linebreak()#text(" If one conditions on ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t)}")#text(" up to time ")#mi("{t^{\\prime}_{n-1}}")#text(", then the increment ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_n) - \\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_{n-1})}")#text(" will just be normally distributed with mean zero and variance ")#mi("{t^{\\prime}_n -t^{\\prime}_{n-1}}")#text(" if ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" already left ")#mi("{V}")#text(" at or before time ")#mi("{t^{\\prime}_{n-1}}")#text("; if instead ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}}")#text(" stayed within ")#mi("{V}")#text(" during this period, then ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_{n-1})}")#text(" is equal to ")#mi("{\\phi(z_1)}")#text(" for some ")#mi("{z_1 \\in U}")#text(", and the increment ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_n) - \\tilde{\\mathbf{B}}^{\\phi(z_0)}(t^{\\prime}_{n-1})}")#text(" would have the same law as ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_1)}(t^{\\prime}_n - t^{\\prime}_{n-1}) - \\phi(z_1)}")#text(". Thus, to prove the required claim, it will suffice to just establish the ")#mi("{n=1}")#text(", ")#mi("{t_0=0}")#text(" case, that is to say it suffices to show that for any ")#mi("{t_1>0}")#text(", the random variable ")#mi("{\\tilde{\\mathbf{B}}^{\\phi(z_0)}(t_1)}")#text(" is normally distributed with mean ")#mi("{\\phi(z_0)}")#text(" and variance ")#mi("{t_1}")#text(".")#linebreak()#text(" Let ")#mi("{F \\in C^\\infty_c({\\bf C})}")#text(" be a test function. It will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} F( \\mathbf{B}^{\\phi(z_0)}(t_1) ) = \\frac{1}{\\pi t_1} \\int_{\\bf C} e^{-\\left|z-z_0\\right|^2/t_1} F(z)\\ dx dy.", block: true)]]

#text("If we define the field")

#align(center)[#tao-fit-display[#tao-math("u(t,z^{\\prime}) := \\frac{1}{\\pi (t_1-t)} \\int_{\\bf C} e^{-\\left|z-z^{\\prime}\\right|^2/(t_1-t)} F(z)\\ dx dy", block: true)]]

#text("for ")#mi("{0 \\leq t < t_1}")#text(" and ")#mi("{z^{\\prime} \\in {\\bf C}}")#text(", with ")#mi("{u(t_1,z^{\\prime}) := F(z^{\\prime})}")#text(", then it will suffice to prove the more general claim ")#metadata(none) <tao-469cc643a19fb75901e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\tilde u(t,z^{\\prime}) = u(t, z^{\\prime})")]]

#text("for all ")#mi("{0 \\leq t \\leq t_1}")#text(" and ")#mi("{z^{\\prime} \\in {\\bf C}}")#text(" (with the convention that ")#mi("{\\tilde{\\mathbf{B}}^{z^{\\prime}}}")#text(" is just Brownian motion based at ")#mi("{z^{\\prime}}")#text(" if ")#mi("{z^{\\prime}}")#text(" lies outside of ")#mi("{V}")#text("), where")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,z^{\\prime}) := \\mathop{\\bf E} F( \\tilde{\\mathbf{B}}^{z^{\\prime}}( t_1-t ) )")]]

#text("As is well known, ")#mi("{u}")#text(" is smooth on ")#mi("{[0,t_1] \\times {\\bf C}}")#text(" and solves the backwards heat equation ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t u = - \\partial_{xx} u - \\partial_{yy} u")]]

#text("on this domain. The strategy will be to show that ")#mi("{\\tilde u}")#text(" also solves this equation.")#linebreak()#text(" Let ")#mi("{0 \\leq t \\leq t_1}")#text(" and ")#mi("{z^{\\prime} \\in {\\bf C}}")#text(". If ")#mi("{t=t_1}")#text(" then clearly ")#mi("{\\tilde u(t,z^{\\prime}) = F(z^{\\prime}) = u(t,z^{\\prime})}")#text(". If instead ")#mi("{t < t_1}")#text(" and ")#mi("{z^{\\prime} \\not \\in U}")#text(", then ")#mi("{\\tilde{\\mathbf{B}}^{z^{\\prime}}}")#text(" is a Brownian motion and then we have ")#mi("{\\tilde u(t,z^{\\prime}) = u(t,z^{\\prime})}")#text(". Now suppose that ")#mi("{t < t_1}")#text(" and ")#mi("{z^{\\prime} = \\phi(z)}")#text(" for some ")#mi("{z \\in U}")#text(", and let ")#mi("{dt>0}")#text(" be small enough that ")#mi("{t+ dt \\leq t_1}")#text(", where ")#mi("{C}")#text(" is an upper bound for ")#tao-math("{\\left|\\phi^{\\prime}\\right|^2}", block: false)#text(" on ")#mi("{U}")#text(". Let ")#mi("{\\mathbf{t}}")#text(" be the first time such that either ")#mi("{\\mathbf{B}^z(\\mathbf{t}) \\not \\in U}")#text(" or")

#align(center)[#tao-fit-display[#tao-math("\\mathbf{t}^{\\prime} := \\int_0^{\\mathbf t} \\left|\\phi^{\\prime}(\\mathbf{B}^{z}(s))\\right|^2\\ ds = dt.", block: true)]]

#text("Then if we let ")#mi("{\\mathbf{t}}")#text(" be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\mathbf{t}^{\\prime} := \\int_0^{\\mathbf t} \\left|\\phi^{\\prime}(\\mathbf{B}^{z}(s))\\right|^2\\ ds,", block: true)]]

#text("then ")#mi("{0 \\leq \\mathbf{t}^{\\prime} \\leq dt}")#text(" and ")#mi("{\\tilde{\\mathbf{B}}^{z^{\\prime}}( t + \\mathbf{t}^{\\prime}) = \\mathbf{B}^z(\\mathbf{t})}")#text(". Let us now condition on a specific value of ")#mi("{\\mathbf{t}}")#text(", and on the trajectory ")#mi("{\\mathbf{B}^z}")#text(" up to time ")#mi("{\\mathbf{t}}")#text(". Then the (conditional) distribution of ")#mi("{\\tilde{\\mathbf{B}}^{z^{\\prime}}( t_1-t )}")#text(" is that of ")#mi("{\\tilde{\\mathbf{B}}^{\\mathbf{B}^z(\\mathbf{t})}( t_1 - t - \\mathbf{t^{\\prime}} )}")#text(", and hence the conditional expectation is ")#mi("{\\tilde u( t + \\mathbf{t}^{\\prime}, \\mathbf{B}^z(\\mathbf{t}))}")#text(". By the law of total expectation, we conclude the identity")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,z^{\\prime}) = \\mathop{\\bf E} \\tilde u( t + \\mathbf{t}^{\\prime}, \\mathbf{B}^z(\\mathbf{t})).")]]

#text("Next, we obtain the analogous estimate ")#metadata(none) <tao-895f7dcdf72d7dd427df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(t,z^{\\prime}) = \\mathop{\\bf E} u( t + \\mathbf{t}^{\\prime}, \\mathbf{B}^z(\\mathbf{t})) + O( dt^{3/2} ).")]]

#text("From Taylor expansion we have")

#tao-aligned(keep: true)[


#tao-math("u( t + \\mathbf{t}^{\\prime}, \\mathbf{B}^z(\\mathbf{t}))  & = u(t,z) + \\mathbf{t^{\\prime}} \\partial_t u(t,z) + \\mathrm{Re}(\\mathbf{B}^z(\\mathbf{t})-z) \\partial_x u(t,z) + \\mathrm{Im}(\\mathbf{B}^z(\\mathbf{t})-z) \\partial_y u(t,z)", block: true)



#tao-math(" & + \\frac{1}{2} (\\mathrm{Re}(\\mathbf{B}^z(\\mathbf{t})-z))^2 \\partial_{xx} u(t,z)", block: true)



#tao-math(" & + (\\mathrm{Re}(\\mathbf{B}^z(\\mathbf{t})-z)) (\\mathrm{Im}(\\mathbf{B}^z(\\mathbf{t})-z)) \\partial_{xy} u(t,z)", block: true)



#tao-math(" & + \\frac{1}{2} (\\mathrm{Im}(\\mathbf{B}^z(\\mathbf{t})-z))^2 \\partial_{yy} u(t,z)", block: true)



#tao-math(" & + O( \\left|\\mathbf{B}^z(\\mathbf{t}) - z\\right|^3 ).", block: true)
]

#text("Taking expectations and applying Lemma ")#link(<tao-25bd152797157817e497>)[#text("4")]#text(", ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(2)")]#text(" and Hölder’s inequality (which can interpolate between the bounds ")#tao-math("{\\mathop{\\bf E} \\left|\\mathbf{B}^z(\\mathbf{t}) - z\\right|^4 = O(dt^2)}", block: false)#text(" and ")#tao-math("{\\mathop{\\bf E} \\left|\\mathbf{B}^z(\\mathbf{t}) - z\\right|^2 = O(dt)}", block: false)#text(" to conclude ")#tao-math("{\\mathop{\\bf E} \\left|\\mathbf{B}^z(\\mathbf{t}) - z\\right|^3 = O(dt^{3/2})}", block: false)#text("), we obtain the desired claim ")#link(<tao-895f7dcdf72d7dd427df>)[#text("(3)")]#text(". Subtracting, we now have")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,z^{\\prime}) - u(t,z^{\\prime}) = \\mathop{\\bf E} (\\tilde u-u)( t + \\mathbf{t}^{\\prime}, \\mathbf{B}^z(\\mathbf{t})) + O( dt^{3/2} ).")]]

#text("The expression in the expectation vanishes unless ")#mi("{\\mathbf{t}^{\\prime} = dt}")#text(", hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde u(t) - u(t)\\right\\|_{L^\\infty({\\bf C})} \\leq \\left\\| \\tilde u(t+dt) - u(t+dt) \\right\\|_{L^\\infty({\\bf C})} + O(dt^{3/2}).", block: true)]]

#text("Iterating this using the fact that ")#mi("{\\tilde u-u}")#text(" vanishes at ")#mi("{t=t_1}")#text(", and sending ")#mi("{dt}")#text(" to zero (noting that the cumulative error term will go to zero since ")#mi("{3/2 > 1}")#text("), we conclude that ")#mi("{\\tilde u(t)=u(t)}")#text(" for all ")#mi("{0 \\leq t \\leq t_1}")#text(", giving the claim. ")#mi("\\Box")#linebreak()#text(" One can use Lévy’s theorem (or variants of this theorem) to prove various results in complex analysis rather efficiently. As a quick example, we sketch a Brownian motion-based proof of Liouville’s theorem (omitting some technical steps). Suppose for contradiction that we have a nonconstant bounded entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(". If ")#mi("{\\mathbf{B}^0}")#text(" is a complex Brownian motion based at ")#mi("{0}")#text(", then a variant of Levy’s theorem can be used to show that the image ")#mi("{f(\\mathbf{B}^0)}")#text(" is a time parameterisation of Brownian motion. But it is easy to show that Brownian motion is almost surely unbounded, so the image ")#mi("{f({\\bf C})}")#text(" cannot be bounded.")#linebreak()#text(" If ")#mi("{U}")#text(" is an open subset of ")#mi("{{\\bf C}}")#text(" whose complement contains an arc, then one can show that for any ")#mi("{z_0 \\in U}")#text(", the complex Brownian motion ")#mi("{\\mathbf{B}^{z_0}}")#text(" based at ")#mi("{z_0}")#text(" will hit the boundary ")#mi("{\\partial U}")#text(" of ")#mi("{U}")#text(" in a finite time ")#mi("{\\mathbf{t}}")#text(". The location ")#mi("{\\mathbf{B}^{z_0}(\\mathbf{t})}")#text(" where this motion first hits the boundary is then a random variable in ")#mi("{\\partial U}")#text("; the law of this variable is called the ")#emph[#text("harmonic measure")]#text(" of ")#mi("{U}")#text(" with base point ")#mi("{z_0}")#text(", and we will denote it by ")#mi("{\\mu^U_{z_0}}")#text("; it is a probability measure on ")#mi("{\\partial U}")#text(". The reason for the terminology “harmonic measure” comes from the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7")]#text(" ")#metadata(none) <tao-7215d1384efb84579b44>#text(" Let ")#mi("{U}")#text(" be a bounded open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a harmonic (or holomorphic) function that extends continuously to ")#mi("{\\partial U}")#text(". Then for any ")#mi("{z_0 \\in U}")#text(", one has the representation formula ")#metadata(none) <tao-ddc03b574018168d8d45>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(z_0) = {\\mathbf E} f( \\mathbf{B}^{z_0}(\\mathbf{t})) = \\int_{\\partial U} f(z)\\ d\\mu^U_{z_0}(z).")]]
]

#emph[#text("Proof:")]#text(" (Informal) For simplicity let us assume that ")#mi("{f}")#text(" extends smoothly to some open neighbourhood of ")#mi("{\\partial U}")#text(". Let ")#mi("{\\tilde {\\mathbf B}^{z_0}}")#text(" be the motion that is equal to ")#mi("{\\mathbf{B}^{z_0}}")#text(" up to time ")#mi("{\\mathbf{t}}")#text(", and then is constant at ")#mi("{\\mathbf{B}^{z_0}(\\mathbf{t})}")#text(" for all later times. A variant of the Taylor expansion argument used to prove Lévy’s theorem shows that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f( \\tilde{\\mathbf{B}}^{z_0}(t) ) = \\mathop{\\bf E} f( \\tilde{\\mathbf{B}}^{z_0}(t+dt) ) + O( dt^{3/2})")]]

#text("for any ")#mi("{0 \\leq t < t+dt < \\infty}")#text(", which on iterating and sending ")#mi("{dt}")#text(" to zero implies that ")#mi("{\\mathop{\\bf E} f( \\tilde{\\mathbf{B}}^{z_0}(t) )}")#text(" is independent of time. Since this quantity converges to ")#mi("{f(z_0)}")#text(" as ")#mi("{t \\rightarrow 0}")#text(" and to ")#mi("{f( \\mathbf{B}^{z_0}(\\mathbf{t}))}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" This theorem can also extend to unbounded domains provided that ")#mi("{f}")#text(" does not grow too fast at infinity (for instance if ")#mi("{f}")#text(" is bounded, basically thanks to the neighbourhood recurrent properties of complex Brownian motion); we do not give a precise statement here. Among other things, this theorem gives an immediate proof of the ")#link("https://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" for harmonic functions, since if ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" on the boundary ")#mi("{\\partial U}")#text(" then from the triangle inequality one has ")#tao-math("{\\left|f(z_0)\\right|\\leq M}", block: false)#text(" for all ")#mi("{z_0 \\in U}")#text(". It also gives an alternate route to Liouville’s theorem: if ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is entire and bounded, then applying the maximum principle to the complement of a small disk ")#mi("{D(z_1,\\varepsilon)}")#text(" we see that ")#mi("{f(z_0) = f(z_1)}")#text(" for all distinct ")#mi("{z_0,z_1 \\in {\\bf C}}")#text(".")#linebreak()#text(" When the boundary ")#mi("{\\partial U}")#text(" is sufficiently nice (e.g. analytic), the harmonic measure becomes absolutely continuous with respect to one-dimensional Lebesgue measure; however, we will not pay too much attention to these sorts of regularity issues in this set of notes.")#linebreak()#text(" From Levy’s theorem on the conformal invariance of Brownian motion we deduce the conformal invariance of harmonic measure, thus for any conformal map ")#mi("{f: U \\rightarrow V}")#text(" that extends continuously to the boundaries ")#mi("{\\partial U, \\partial V}")#text(" and any ")#mi("{z_0 \\in {\\bf C}}")#text(", the harmonic measure ")#mi("{\\mu^V_{f(z_0)}}")#text(" of ")#mi("{V}")#text(" with base point ")#mi("{f(z_0)}")#text(" is the pushforward of the harmonic measure ")#mi("{\\mu^U_{z_0}}")#text(" of ")#mi("{U}")#text(" with base point ")#mi("{z_0}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_{\\partial V} g(w)\\ d\\mu^V_{f(z_0)}(w) = \\int_{\\partial U} g(f(z))\\ d\\mu^U_{z_0}(z)")]]

#text("for any continuous compactly supported test function ")#mi("{g}")#text(", and also")

#align(center)[#tao-fit-display[#mitex("\\mu^V_{f(z_0)}( E ) = \\mu^U_{z_0}( f^{-1}(E) )")]]

#text("for any (Borel) measurable ")#mi("{E \\subset \\partial V}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Poisson kernel)")]#text(" ")#metadata(none) <tao-eb3102a6cb586765d01f>

#list(
[#text("(i) If ")#mi("{U = D(0,1)}")#text(" and ")#mi("{z_0 = re^{i\\alpha} \\in U}")#text(", show that the measure ")#mi("{\\mu_{z_0}}")#text(" on the unit circle ")#mi("{\\partial U = \\{ e^{i\\theta}: 0 \\leq \\theta < 2\\pi\\}}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("\\mu_{z_0} = \\frac{1}{2\\pi} \\mathrm{Re} \\frac{1+re^{i(\\theta-\\alpha)}}{1-re^{i(\\theta-\\alpha)}}\\ d\\theta")]]

#text("where ")#mi("{d\\theta}")#text(" is arclength measure. In particular, when ")#mi("{z_0=0}")#text(", then ")#mi("{\\mu_{z_0}}")#text(" is the uniform measure on the unit circle.")],
[#text("(ii) If ")#mi("{U = \\{ z: \\mathrm{Im} z > 0 \\}}")#text(" and ")#mi("{z_0 = x_0+iy_0 \\in U}")#text(", show that the measure ")#mi("{\\mu_{z_0}}")#text(" on the real line is given by")

#align(center)[#tao-fit-display[#mitex("\\mu_{z_0} = \\frac{1}{\\pi} \\frac{y_0}{(x-x_0)^2 + y_0^2}\\ dx.")]]

#text("(For this exercise one can assume that harmonic measure is well defined for unbounded domains, and that the representation formula ")#link(<tao-ddc03b574018168d8d45>)[#text("(4)")]#text(" continues to hold for bounded harmonic or holomorphic functions.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Brownian motion description of conformal mapping)")]#text(" Let ")#mi("{U}")#text(" be the region enclosed by a Jordan curve ")#mi("{\\partial U}")#text(", and let ")#mi("{z_1,z_2,z_3}")#text(" be three distinct points on ")#mi("{\\partial U}")#text(" in anticlockwise order. Let ")#mi("{w_1,w_2,w_3}")#text(" be three distinct points on the boundary ")#mi("{\\partial D(0,1)}")#text(" of the unit disk ")#mi("{D(0,1)}")#text(", again traversed in anticlockwise order. Let ")#mi("{\\phi: U \\rightarrow D(0,1)}")#text(" be the conformal map that takes ")#mi("{z_j}")#text(" to ")#mi("{w_j}")#text(" for ")#mi("{j=1,2,3}")#text(" (the existence and uniqueness of this map follows from the Riemann mapping theorem). Let ")#mi("{z_0 \\in U}")#text(", and for ")#mi("{ij=12,23,31}")#text(", let ")#mi("{p_{ij}}")#text(" be the probability that the terminal point ")#mi("{\\mathbf{B}^{z_0}(\\mathbf{t})}")#text(" of Brownian motion at ")#mi("{U}")#text(" with base point ")#mi("{z_0}")#text(" lies in the arc between ")#mi("{z_i}")#text(" and ")#mi("{z_j}")#text(" (here we use the fact that the endpoints ")#mi("{z_i,z_j}")#text(" are hit with probability zero, or in other words that the harmonic measure is continuous; see Exercise ")#link(<tao-817c1a5e9086a6b981b1>)[#text("15")]#text(" below). Thus ")#mi("{p_{12}, p_{23}, p_{31}}")#text(" are non-negative and sum to ")#mi("{1}")#text(". Let ")#mi("{\\zeta_1,\\zeta_2,\\zeta_3 \\in \\partial B(0,1)}")#text(" be the complex numbers ")#mi("{\\zeta_1 := 1}")#text(", ")#mi("{\\zeta_2 := e^{2\\pi i p_{12}}}")#text(", ")#mi("{\\zeta_3 := e^{2\\pi i (p_{12} + p_{23})} = e^{-2\\pi i p_{31}}}")#text(". Show the crossratio identity")

#align(center)[#tao-fit-display[#mitex("\\frac{(\\phi(z_0) - w_1)(w_3 - w_2)}{(\\phi(z_0)-w_2)(w_3-w_1)} = \\frac{ \\zeta_1 (\\zeta_3 - \\zeta_2)}{\\zeta_2 (\\zeta_3 - \\zeta_1)}.")]]

#text("In principle, this allows one to describe conformal maps purely in terms of Brownian motion.")
]

#text("We remark that the link between Brownian motion and conformal mapping can help gain an intuitive understanding of the Carathéodory kernel theorem (Theorem 12 from ")#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("Notes 3")]#text("). Consider for instance the example in Exercise 13 from those notes. It is intuitively clear that a Brownian motion ")#mi("{\\mathbf{B}^0}")#text(" based at the origin will very rarely pass through the slit beween ")#mi("{-1 + \\frac{i}{2w_n}}")#text(" and ")#mi("{-1 + \\frac{i}{2w_n}}")#text(", instead hitting the right side of the boundary of ")#mi("{f_n(D(0,1))}")#text(" first. As such, the harmonic measure of the left side of the boundary should be very small, and in fact one can use this to show that the preimage under ")#mi("{f_n}")#text(" of the region to the left of the boundary goes to zero in diameter as ")#mi("{n \\rightarrow \\infty}")#text(", which helps explain why the limiting function ")#mi("{f}")#text(" does not map to this region at all.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Brownian motion description of conformal radius)")]

#list(
[#text("(i) Let ")#mi("{0 < r_1 < r_2}")#text(" and ")#mi("{z_0 \\in {\\bf C}}")#text(" with ")#tao-math("{r_1 < \\left|z_0\\right| < r_2}", block: false)#text(". Show that the probability that the Brownian motion ")#mi("{\\mathbf{B}^{z_0}}")#text(" hits the circle ")#tao-math("{\\{ \\left|z\\right| = r_1\\}}", block: false)#text(" before it hits ")#tao-math("{\\{ \\left|z\\right| = r_2\\}}", block: false)#text(" is equal to ")#tao-math("{\\frac{\\log(r_2/\\left|z_0\\right|)}{\\log(r_2/r_1)}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" ")#tao-math("{\\log\\left|z\\right|}", block: false)#text(" is harmonic away from the origin.)")],
[#text("(ii) Let ")#mi("{U}")#text(" be a simply connected proper subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(", and let ")#mi("{r}")#text(" be the conformal radius of ")#mi("{U}")#text(" around ")#mi("{z_0}")#text(". Show that for small ")#mi("{\\varepsilon_2 > \\varepsilon_1 > 0}")#text(", the probability that a Brownian motion based at a point ")#mi("{z_1}")#text(" with ")#tao-math("{\\left|z_1-z_0\\right| = \\varepsilon_2}", block: false)#text(" will hit the circle ")#tao-math("{\\{ \\left|z-z_0\\right| = r_1\\}}", block: false)#text(" before it hits the boundary ")#mi("{\\partial U}")#text(" is equal to ")#mi("{\\frac{\\log(r/\\varepsilon_2) + o(1)}{\\log(r/\\varepsilon_1)}}")#text(", where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{\\varepsilon_1,\\varepsilon_2 \\rightarrow 0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-71c34000feaca9fee776>#text(" Let ")#mi("{K}")#text(" be a connected subset of ")#mi("{D(0,1)}")#text(", let ")#mi("{{\\mathbf B}^0}")#text(" be a Brownian motion based at the origin, and let ")#mi("{\\mathbf{t}}")#text(" be the first time this motion exits ")#mi("{D(0,1)}")#text(". Show that the probability that ")#mi("{\\mathbf{B}^0([0,\\mathbf{t}])}")#text(" hits ")#mi("{K}")#text(" is at least ")#mi("{c\\mathrm{diam}(K)}")#text(" for some absolute constant ")#mi("{c>0}")#text(". (")#emph[#text("Hint:")]#text(" one can control the event that ")#mi("{\\mathbf{B}^0}")#text(" makes a “loop” around a point in ")#mi("{K}")#text(" at radius less than ")#mi("{\\mathrm{diam}(K)}")#text(", which is enough to force intersection with ")#mi("{K}")#text(", at least if one works some distance away from the boundary of the disk.)")
]

#text("We now sketch the proof of a basic Brownian motion estimate that is useful in applications. We begin with a lemma that says, roughly speaking, that “folding” a set reduces the probability of it being hit by Brownian motion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" Let ")#mi("{-1 < x < 1}")#text(", and let ")#mi("{K}")#text(" be a closed subset of the unit disk ")#mi("{D(0,1)}")#text(". Write ")#mi("{K^+ := \\{ z \\in K: \\mathrm{Im}(z) \\geq 0 \\}}")#text(" and ")#mi("{K^- := \\{ z \\in K: \\mathrm{Im}(z) < 0 \\}}")#text(", and write ")#mi("{K^{\\prime} := K^+ \\cup \\overline{K^-}}")#text(" (i.e. ")#mi("{K}")#text(" reflected onto the upper half-plane). Let ")#mi("{{\\mathbf B}^{x}}")#text(" be a complex Brownian motion based at ")#mi("{x}")#text(", and let ")#mi("{\\mathbf{t}}")#text(" be the first time this motion hits the boundary of ")#mi("{D(0,1)}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mathbf{P}( \\mathbf{B}^x([0,\\mathbf{t}]) \\text{ intersects} K ) \\geq \\mathbf{P}( \\mathbf{B}^x([0,\\mathbf{t}]) \\text{ intersects} K^{\\prime} ).")]]
]

#emph[#text("Proof:")]#text(" (Informal) To illustrate the argument at a heuristic level, let us make the (almost surely false) assumption that the Brownian motion ")#mi("{\\mathbf{B}^x}")#text(" only crosses the real axis at a finite set of times ")#mi("{t_0=0 < t_1 < \\dots < t_n < \\mathbf{t}}")#text(" before hitting the disk. Then the Brownian motion ")#mi("{\\mathbf{B}^x([0,\\mathbf{t}])}")#text(" would split into subcurves ")#mi("{\\mathbf{B}^x([t_i,t_{i+1}])}")#text(" for ")#mi("{i=0,\\dots,n}")#text(", with the convention that ")#mi("{t_{i+1} = \\mathbf{t}}")#text(". Each subcurve would lie in either the upper half-plane or the lower half-plane, with equal probability of each; furthermore, one could arbitrarily apply complex conjugation to one or more of these subcurves and still obtain a motion with the same law. Observe that if one conditions on the Brownian motion up to time ")#mi("{t_i}")#text(", and the subcurve ")#mi("{\\mathbf{B}^x([t_i,t_{i+1}])}")#text(" has a probability ")#mi("{p_i^+}")#text(" of hitting ")#mi("{K^+}")#text(" when it lies in the upper half-plane, and a probability ")#mi("{p_i^-}")#text(" of hitting ")#mi("{K^-}")#text(" when it lies in the lower half-plane, then it will have a probability of at most ")#mi("{p_i^+ + p_i^-}")#text(" of hitting ")#mi("{K^{\\prime}}")#text(" when it lies in the upper half-plane, and probability ")#mi("{0}")#text(" of hitting ")#mi("{K^{\\prime}}")#text(" when it lies in the lower half-plane; thus the probability of this subcurve hitting ")#mi("{K^{\\prime}}")#text(" is less than or equal to that of it hitting ")#mi("{K}")#text(". In principle, the lemma now follows from repeatedly applying the law of total expectation.")#linebreak()#text(" This naive argument does not quite work because a Brownian motion starting at a real number will in fact almost surely cross the real axis an infinite number of times. However it is possible to adapt this argument by redefining the ")#mi("{t_i}")#text(" so that after each time ")#mi("{t_i}")#text(", the Brownian motion is forced to move some small distance before one starts looking for the next time ")#mi("{t_{i+1}}")#text(" it hits the real axis. See the proof of Lemma 6.1 of ")#link("http://www.math.uchicago.edu/~lawler/harmonic.pdf")[#text("these notes of Lawler")]#text(" for a complete proof along these lines. ")#mi("\\Box")#linebreak()#text(" This gives an inequality similar in spirit to the Grötzsch modulus estimate from ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Beurling projection theorem)")]#text(" ")#metadata(none) <tao-c3711e602070c4c956c9>#text(" Let ")#mi("{0 < \\varepsilon < 1}")#text(", and let ")#mi("{K}")#text(" be a compact connected subset the annulus ")#tao-math("{\\{ \\varepsilon \\leq \\left|z\\right| \\leq 1 \\}}", block: false)#text(" that intersects both boundary circles of the annulus. Let ")#mi("{{\\mathbf B}^0}")#text(" be a complex Brownian motion based at ")#mi("{0}")#text(", and let ")#mi("{\\mathbf{t}}")#text(" be the first time this motion hits the outer boundary ")#tao-math("{\\{ \\left|z\\right|=1\\}}", block: false)#text(" of the annulus. Then the probability that ")#mi("{\\mathbf{B}^0([0,\\mathbf{t}])}")#text(" intersects ")#mi("{K}")#text(" is greater than or equal to the probability that ")#mi("{\\mathbf{B}^0([0,\\mathbf{t}])}")#text(" intersects the interval ")#mi("{[\\varepsilon,1]}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) One can use the above lemma to fold ")#mi("{K}")#text(" around the real axis without increasing the probability of being hit by Brownian motion. By rotation, one can similarly fold ")#mi("{K}")#text(" around any other line through the origin. By repeatedly folding ")#mi("{K}")#text(" in this fashion to reduce its angular variation, one can eventually replace ")#mi("{K}")#text(" with a set that lies inside the sector ")#mi("{\\{ re^{i\\theta}: \\varepsilon \\leq r \\leq 1; 0 \\leq \\theta \\leq \\delta \\}}")#text(" for any ")#mi("{\\delta}")#text(". However, by the monotone convergence theorem, the probability that ")#mi("{\\mathbf{B}^0([0,\\mathbf{t}])}")#text(" intersects this sector converges to the probability that it intersects ")#mi("{[\\varepsilon,1]}")#text(" in the limit ")#mi("{\\delta \\rightarrow 0}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" With the notation as the above corollary, show that the probability that ")#mi("{\\mathbf{B}^0([0,\\mathbf{t}])}")#text(" intersects the interval ")#mi("{[\\varepsilon,1]}")#text(" is ")#mi("{O(\\varepsilon^{1/2})}")#text(". (")#emph[#text("Hint:")]#text(" apply a square root conformal map to the disk with ")#mi("{[\\varepsilon,1]}")#text(" removed, and then compare with the half-plane harmonic measure from Exercise ")#link(<tao-eb3102a6cb586765d01f>)[#text("8")]#text("(ii).)")
]

#text("The following consequence of the above estimate, giving a sort of Hölder regularity of Brownian measure, is particularly useful in applications.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Beurling estimate)")]#text(" ")#metadata(none) <tao-817c1a5e9086a6b981b1>#text(" Let ")#mi("{U}")#text(" be an open set not containing ")#mi("{0}")#text(", with the property that the connected component of ")#mi("{{\\bf C} \\backslash U}")#text(" containing ")#mi("{0}")#text(" intersects the unit circle ")#tao-math("{\\{ \\left|z\\right| = r \\}}", block: false)#text(". Let ")#mi("{z_0 \\in U}")#text(" be such that ")#tao-math("{\\left|z_0\\right| \\geq 2r}", block: false)#text(". Then for any ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{\\mu^U_{z_0}( D(0,\\varepsilon r) ) = O(\\varepsilon^{1/2})}")#text("; that is to say, the probability that a Brownian motion based at ")#mi("{z_0}")#text(" exits ")#mi("{U}")#text(" at a point within ")#mi("{\\varepsilon r}")#text(" from the origin is ")#mi("{O(\\varepsilon^{1/2})}")#text(". (")#emph[#text("Hint:")]#text(" one can use conformal mapping to show that the probability appearing at the end of Corollary ")#link(<tao-c3711e602070c4c956c9>)[#text("13")]#text(" is ")#mi("{O(\\varepsilon^{1/2})}")#text(".) Conclude in particular that harmonic measures ")#mi("{\\mu^U_{z_0}}")#text(" are always continuous (they assign zero to any point).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{U}")#text(" be a region bounded by a Jordan curve, let ")#mi("{z_0 \\in U}")#text(", let ")#mi("{\\mathbf{B}^{z_0}}")#text(" be the Brownian motion based at ")#mi("{z_0}")#text(", and let ")#mi("{\\mathbf{t}}")#text(" be the first time this motion exits ")#mi("{U}")#text(". Then for any ")#mi("{R > 0}")#text(", show that the probability that the curve ")#mi("{\\mathbf{B}^{z_0}([0,\\mathbf{t}])}")#text(" has diameter at least ")#mi("{R \\mathrm{dist}(z, \\partial U)}")#text(" is at most ")#mi("{O(R^{-1/2})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{f: D(0,1) \\rightarrow U}")#text(" be a conformal map with ")#mi("{f(0)=0}")#text(", and let ")#mi("{\\gamma: [0,1] \\rightarrow \\overline{U}}")#text(" be a curve with ")#mi("{\\gamma(0) \\in \\partial U}")#text(" and ")#mi("{\\gamma(t) \\in U}")#text(" for ")#mi("{0 < t \\leq 1}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{diam}( f^{-1}( \\gamma([0,1]) ) ) \\leq O( (\\frac{\\mathrm{diam}(\\gamma([0,1]))}{\\left|f^{\\prime}(0)\\right|})^{1/2}).", block: true)]]

#text("(Hint: use Exercise ")#link(<tao-71c34000feaca9fee776>)[#text("11")]#text(".)")
]

#heading(level: 1)[#strong[#text(" — 2. Half-plane capacity — ")]]

#text("One can use Brownian motion to construct other close relatives of harmonic measure, such Green’s functions, excursion measures. See for instance ")#link("http://www.math.uchicago.edu/~lawler/harmonic.pdf")[#text("these lecture notes of Lawler")]#text(" for more details. We will focus on one such use of Brownian motion, to interpret the concept of ")#emph[#text("half-plane capacity")]#text("; this is a notion that is particularly well adapted to the study of chordal Loewner equations (it plays a role analogous to that of conformal radius for the radial Loewner equation).")#linebreak()#text(" Let ")#mi("{\\mathbf{H} := \\{ z: \\mathrm{Im}(z) > 0 \\}}")#text(" be the upper half-plane. A subset ")#mi("{A}")#text(" of the upper half-plane ")#mi("{\\mathbf{H}}")#text(" is said to be a ")#emph[#text("compact hull")]#text(" if it is bounded, closed in ")#mi("{\\mathbf{H}}")#text(", and the complement ")#mi("{\\mathbf{H} \\backslash A}")#text(" is simply connected. By the Riemann mapping theorem, for any compact hull ")#mi("{A}")#text(", there is a unique conformal map ")#mi("{g_A: \\mathbf{H} \\backslash A \\rightarrow \\mathbf{H}}")#text(" which is normalised at infinity in the sense that ")#metadata(none) <tao-cadc8edab738c1df2ce1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("g_A(z) = z + \\frac{b_1}{z} + \\frac{b_2}{z^2} + \\dots")]]

#text("for some complex numbers ")#mi("{b_1, b_2, \\dots}")#text(". The quantity ")#mi("{b_1}")#text(" is particularly important and will be called the ")#emph[#text("half-plane capacity")]#text(" of ")#mi("{A}")#text("and denoted ")#mi("{\\mathrm{hcap}(A)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Examples of half-plane capacity)")]#text(" ")#metadata(none) <tao-f14bf29d6ce8c8ca08a8>

#list(
[#text("(i) Show the translation invariance ")#mi("{\\mathrm{hcap}(A + x) = \\mathrm{hcap}(A)}")#text(" and the dilation invariance ")#mi("{\\mathrm{hcap}(\\lambda A) = \\lambda^2 \\mathrm{hcap}(A)}")#text(" for any compact hull ")#mi("{A}")#text(", any ")#mi("{x \\in {\\bf R}}")#text(", and any ")#mi("{\\lambda > 0}")#text(", where ")#mi("{A+x := \\{ z + x: z \\in A \\}}")#text(" and ")#mi("{\\lambda A := \\{ \\lambda z: z \\in A \\}}")#text(".")],
[#text("(ii) If ")#mi("{A}")#text(" is a vertical line segment ")#mi("{[x, x+i\\delta] = \\{ x+yi: 0 \\leq y \\leq \\delta \\}}")#text(" for some ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{\\delta>0}")#text(", show that ")#mi("{g_A}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("g_A(z) := x + ((z-x)^2 + \\delta^2)^{1/2} = z + \\frac{\\delta^2}{2z} + \\dots")]]

#text("(using the standard branch of the square root), so that ")#metadata(none) <tao-57ebcad971562456e522>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathrm{hcap}( [x, x+i\\delta] ) = \\frac{\\delta^2}{2}.")]]],
[#text("(iii) If ")#mi("{A}")#text(" is the semicircle ")#mi("{D(x,r) \\cap \\mathbf{H}}")#text(", then ")#mi("{g_A}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("g_A(z) := z + \\frac{r^2}{z-x} = z + \\frac{r^2}{z} + \\dots")]]

#text("so that ")#metadata(none) <tao-b61996cd5ccfacf3f95b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\mathrm{hcap}( D(x,r) \\cap \\mathbf{H} ) = r^2.")]]]
)
]

#text("In general, we have the following Brownian motion characterisation of half-plane capacity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19")]#text(" ")#metadata(none) <tao-8a865efd6c90c1c447e0>#text(" Let ")#mi("{A}")#text(" be a compact hull, with conformal map ")#mi("{g_A: \\mathbf{H} \\backslash A \\rightarrow \\mathbf{H}}")#text(" and half-plane capacity ")#mi("{b_1}")#text(".")

#list(
[#text("(i) If ")#mi("{\\mathbf{B}^{z_0}}")#text(" is complex Brownian motion based at some point ")#mi("{z_0 \\in \\mathbf{H} \\backslash A}")#text(", and ")#mi("{\\mathbf{t}}")#text(" is the first time this motion exits ")#mi("{\\mathbf{H} \\backslash A}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Im}(z_0) = \\mathrm{Im}( g_A(z_0) ) + \\mathbf{E} \\mathrm{Im} \\mathbf{B}^{z_0}(\\mathbf{t}).")]]],
[#text("(ii) We have")

#align(center)[#tao-fit-display[#mitex("b_1 = \\lim_{y \\rightarrow +\\infty} y \\mathbf{E} \\mathrm{Im} \\mathbf{B}^{iy}(\\mathbf{t}).")]]]
)
]

#emph[#text("Proof:")]#text(" (Sketch) Part (i) follows from applying Theorem ")#link(<tao-7215d1384efb84579b44>)[#text("7")]#text(" to the bounded harmonic function ")#mi("{z \\mapsto \\mathrm{Im}(z - g_A(z))}")#text(". Part (ii) follows from part (i) by setting ")#mi("{z_0 = iy}")#text(" for a large ")#mi("{y}")#text(", rearranging, and sending ")#mi("{y \\rightarrow \\infty}")#text(" using ")#link(<tao-cadc8edab738c1df2ce1>)[#text("(5)")]#text(". ")#mi("\\Box")#linebreak()#text(" Among other things, this proposition demonstrates that ")#mi("{\\mathrm{Im}(g_A(z_0)) \\leq \\mathrm{Im}(z_0)}")#text(" for all ")#mi("{z_0 \\in \\mathbf{H} \\backslash A}")#text(", and that the half-plane capacity is always non-negative (in fact it is not hard to show from the above proposition that it is strictly positive as long as ")#mi("{A}")#text(" is non-empty).")#linebreak()#text(" If ")#mi("{A, A^{\\prime}}")#text(" are two compact hulls with ")#mi("{A \\subset A^{\\prime}}")#text(", then ")#mi("{g_A}")#text(" will map ")#mi("{\\mathbf{H} \\backslash A^{\\prime}}")#text(" conformally to the complement of ")#mi("{g_A( A^{\\prime} \\backslash A)}")#text(" in ")#mi("{\\mathbf{H}}")#text(". Thus ")#mi("{g_A( A^{\\prime} \\backslash A)}")#text(" is also a convex hull, and by the uniqueness of Riemann maps we have the identity ")#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("g_{A^{\\prime}} = g_{g_A(A^{\\prime} \\backslash A)} \\circ g_A")]]

#text("which on comparing Laurent expansions leads to the further identity ")#metadata(none) <tao-fb9ac8c2dd0b60445475>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mathrm{hcap}(A^{\\prime}) = \\mathrm{hcap}( g_A(A^{\\prime} \\backslash A) ) + \\mathrm{hcap}( A).")]]

#text("In particular we have the monotonicity ")#mi("{\\mathrm{hcap}(A^{\\prime}) \\geq \\mathrm{hcap}(A)}")#text(", with equality if and only if ")#mi("{A^{\\prime}=A}")#text(". One may verify that these claims are consistent with Exercise ")#link(<tao-f14bf29d6ce8c8ca08a8>)[#text("18")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Submodularity of half-plane capacity)")]#text(" Let ")#mi("{A_1, A_2}")#text(" be two compact hulls.")

#list(
[#text("(i) If ")#mi("{z_0 \\in \\mathbf{H} \\backslash (A_1 \\cap A_2)}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Im}(g_{A_1}(z_0)) + \\mathrm{Im}(g_{A_2}(z_0)) \\geq \\mathrm{Im}(g_{A_1 \\cap A_2}(z_0)) + \\mathrm{Im}(g_{A_1 \\cup A_2}(z_0)).")]]

#text("(")#emph[#text("Hint:")]#text(" use Proposition ")#link(<tao-8a865efd6c90c1c447e0>)[#text("19")]#text(", and consider how the times in which a Brownian motion ")#mi("{\\mathbf{B}^{z_0}}")#text(" exits ")#mi("{\\mathbf{H} \\backslash A_1}")#text(", ")#mi("{\\mathbf{H} \\backslash A_2}")#text(", ")#mi("{\\mathbf{H} \\backslash (A_1 \\cup A_2)}")#text(", and ")#mi("{\\mathbf{H} \\backslash (A_1 \\cap A_2)}")#text(" are related.)")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{hcap}(A_1) + \\mathrm{hcap}(A_2) \\geq \\mathrm{hcap}(A_1 \\cap A_2) + \\mathrm{hcap}(A_1 \\cup A_2).")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-6a20b12fb04b136c7c9e>#text(" Let ")#mi("{A}")#text(" be a compact hull bounded in a disk ")#mi("{D(0,R)}")#text(". For any ")#mi("{x>R}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathbf{P}( \\mathbf{B}^{iy}( \\mathbf{t} ) \\in [x,+\\infty) ) = \\frac{1}{2} - \\frac{g_A(x)}{\\pi y} + o(1)")]]

#text("as ")#mi("{y \\rightarrow +\\infty}")#text(", where ")#mi("{\\mathbf{B}^{iy}}")#text(" is complex Brownian motion based at ")#mi("{iy}")#text(" and ")#mi("{\\mathbf{t}}")#text(" is the first time it exits ")#mi("{\\mathbf{H} \\backslash A}")#text(". Similarly, for any ")#mi("{x < -R}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathbf{P}( \\mathbf{B}^{iy}( \\mathbf{t} ) \\in (-\\infty,x] ) = \\frac{1}{2} + \\frac{g_A(x)}{\\pi y} + o(1).")]]

#text("This formula gives a Brownian motion interpretation for ")#mi("{g_A}")#text(" on the portion ")#mi("{(-\\infty,R) \\cup (R,+\\infty)}")#text(" of the boundary of ")#mi("{\\mathbf{H} \\backslash A}")#text(". It can be used to give useful quantitative estimates for ")#mi("{g_A}")#text(" in this region; see Section 3.4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. The chordal Loewner equation — ")]]

#text("We now develop (in a rather informal fashion) the theory of the chordal Loewner equation, which roughly speaking is to conformal maps from the upper half-plane ")#mi("{{\\mathbf H}}")#text(" to the complement ")#mi("{{\\mathbf H} \\backslash A}")#text(" of complex hulls as the radial Loewner equation is to conformal maps from the unit disk to subsets of the complex plane. A more rigorous treatment can be found in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(".")#linebreak()#text(" Suppose one has a simple curve ")#mi("{\\gamma: [0,+\\infty) \\rightarrow \\overline{\\mathbf{H}}}")#text(" such that ")#mi("{\\gamma(0) \\in {\\bf R}}")#text(" and ")#mi("{\\gamma(0,+\\infty) \\in {\\mathbf H}}")#text(". There are important and delicate issues regarding the regularity hypotheses on this curve (which become particularly important in SLE, when the regularity is quite limited), but for this informal discussion we will ignore all of these issues.")#linebreak()#text(" For each time ")#mi("{t}")#text(", the set ")#mi("{\\gamma((0,t])}")#text(" forms a compact hull, and so has some half-plane capacity ")#mi("{\\mathrm{hcap}( \\gamma((0,t]))}")#text(". From the monotonicity of capacity, this half-plane capacity is increasing in ")#mi("{t}")#text(". It is traditional to normalise the curve ")#mi("{\\gamma}")#text(" so that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\mathrm{hcap}( \\gamma((0,t])) = 2t;")]]

#text("this is analogous to normalising the Loewner chains from ")#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("Notes 3")]#text(" to have conformal radius ")#mi("{e^t}")#text(" at time ")#mi("{t}")#text(". A basic example of such normalised curves would be the curves ")#mi("{\\gamma(t) = x+2 t^{1/2} i}")#text(" for some fixed ")#mi("{x}")#text(", since the normalisation follows from ")#link(<tao-57ebcad971562456e522>)[#text("(6)")]#text(".")#linebreak()#text(" Let ")#mi("{g_t: \\mathbf{H} \\backslash \\gamma((0,t]) \\rightarrow \\mathbf{H}}")#text(" be the conformal maps associated to these compact hulls. From ")#link(<tao-e81935fb86434cdaaeee>)[#text("(8)")]#text(" we will have ")#metadata(none) <tao-9822e147622a0c888d02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("g_{t+dt} = g_{t+dt \\leftarrow t} \\circ g_t")]]

#text("for any ")#mi("{t \\geq 0}")#text(" and ")#mi("{dt>0}")#text(", where ")#mi("{g_{t + dt \\leftarrow t}: \\mathbf{H}\\backslash g_t(\\gamma((t,t+dt]))) \\rightarrow \\mathbf{H}}")#text(" is the conformal map associated to the compact hull ")#mi("{g_t(\\gamma((t,t+dt]))}")#text(". From ")#link(<tao-fb9ac8c2dd0b60445475>)[#text("(9)")]#text(" this hull has half-plane capacity ")#mi("{2dt}")#text(", thus we have the Laurent expansion")

#align(center)[#tao-fit-display[#mitex("g_{t+dt \\leftarrow t}(z) = z + \\frac{2dt}{z} + \\dots .")]]

#text("It can be shown (using the Beurling estimate) that ")#mi("{g_t}")#text(" extends continuously to the tip ")#mi("{\\gamma(t)}")#text(" of the curve ")#mi("{\\gamma([0,t])}")#text(", and attains a real value ")#mi("{U_t := g_t(\\gamma(t))}")#text(" at that point; furthermore, ")#mi("{U_t}")#text(" depends continuously on ")#mi("{t}")#text(". See Lemma 4.2 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(". As such, ")#mi("{g_t(\\gamma((t,t+dt]))}")#text(" should be a short arc (of length ")#mi("{O(dt)}")#text(") starting at ")#mi("{U_t := g_t(\\gamma(t))}")#text(". If ")#mi("{U_t=0}")#text(", it is possible to use a quantitative version of Exercise ")#link(<tao-6a20b12fb04b136c7c9e>)[#text("21")]#text(" (again using the Beurling estimate) to obtain an estimate basically of the form")

#align(center)[#tao-fit-display[#mitex("g_{t+dt \\leftarrow t}(z) = z + \\frac{2dt}{z} + o(dt).")]]

#text("for any fixed ")#mi("{z \\in \\mathbf{H}}")#text(". If ")#mi("{U_t}")#text(" is non-zero, we instead have ")#metadata(none) <tao-6876d341ea8a0ff8bb5e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("g_{t+dt \\leftarrow t}(z) = z + \\frac{2dt}{z - U_t} + o(dt).")]]

#text("For instance, if ")#mi("{\\gamma(t) = x + 2t^{1/2} i}")#text(", then ")#mi("{U_t = x}")#text(" for all ")#mi("{t}")#text(", and from Exercise ")#link(<tao-f14bf29d6ce8c8ca08a8>)[#text("18")]#text(" we have the exact formula")

#align(center)[#tao-fit-display[#mitex("g_{t+dt \\leftarrow t}(z) = x + ((z-x)^2 + 4 dt)^{1/2} = z + \\frac{2dt}{z - x} + o(dt).")]]

#text("Inserting ")#link(<tao-6876d341ea8a0ff8bb5e>)[#text("(12)")]#text(" into ")#link(<tao-9822e147622a0c888d02>)[#text("(11)")]#text(" and using the chain rule, we obtain")

#align(center)[#tao-fit-display[#mitex("g_{t+dt}(z) = g_t(z) + \\frac{2dt}{g_t(z) - U_t} + o(dt)")]]

#text("and we then arrive at the ")#emph[#text("(chordal) Loewner equation")]#text(" ")#metadata(none) <tao-0790928f3c5853a8b0b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\partial_t g_t(z) = \\frac{2}{g_t(z) - U_t}")]]

#text("for all ")#mi("{t \\geq 0}")#text(" and ")#mi("{z \\in \\mathbf{H} \\backslash \\gamma((0,t])}")#text(". This equation can be justified rigorously for any simple curve ")#mi("{\\gamma}")#text(": see Proposition 4.4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(". Note that the imaginary part of ")#mi("{\\frac{2}{g_t(z)-U_t}}")#text(" is negative, which is consistent with the observation made previously that the imaginary part of ")#mi("{g_t(z)}")#text(" is decreasing in ")#mi("{t}")#text(".")#linebreak()#text(" We have started with a chain of compact hulls ")#mi("{\\gamma((0,t])}")#text(" associated to a simple curve, and shown that the resulting conformal maps ")#mi("{g_t: \\mathbf{H} \\backslash \\gamma((0,t]) \\rightarrow \\mathbf{H}}")#text(" obey the Loewner equation for some continuous driving term ")#mi("{U_t: [0,+\\infty) \\rightarrow {\\bf R}}")#text(". Conversely, suppose one is given a continuous driving term ")#mi("{U_t: [0,+\\infty) \\rightarrow {\\bf R}}")#text(". It follows from ")#link("https://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence and uniqueness theorem")]#text(" that for each ")#mi("{z \\in \\mathbf{H}}")#text(" there is a unique maximal time of existence ")#mi("{0 < T(z) \\leq +\\infty}")#text(" such that the ODE ")#link(<tao-0790928f3c5853a8b0b5>)[#text("(13)")]#text(" with initial data ")#mi("{g_0(z)}")#text(" can be solved for time ")#mi("{0 \\leq t < T(z)}")#text(". If we then define ")#mi("{H_t := \\{ z \\in \\mathbf{H}: T(z) > t \\}}")#text(", one can show that for each time ")#mi("{t}")#text(", ")#mi("{g_t}")#text(" is a conformal map from ")#mi("{H_t}")#text(" to ")#mi("{\\mathbf{H}}")#text(" with the Laurent expansion")

#align(center)[#tao-fit-display[#mitex("g_t(z) = z + \\frac{2t}{z} + \\dots,")]]

#text("hence the complement ")#mi("{K_t := \\mathbf{H} \\backslash H_t}")#text(" are an increasing sequence of compact hulls with half-plane capacity ")#mi("{2t}")#text(". Proving complex differentiability of ")#mi("{g_t}")#text(" can be done from first principles, and the Laurent expansion near infinity is also not hard; the main difficulty is to show that the map ")#mi("{g_t: H_t \\rightarrow \\mathbf{H}}")#text(" is surjective, which requires solving ")#link(<tao-0790928f3c5853a8b0b5>)[#text("(13)")]#text(" backwards in time (and here one can do this indefinitely as now one is moving away from the real axis instead of towards it). See Theorem 4.6 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(" for details (in fact a more general theorem is proven, in which the single point ")#mi("{U_t}")#text(" is replaced by a probability measure, analogously to how the radial Loewner equation uses Herglotz functions instead of a single driving function when not restricted to slit domains). However, there is a subtlety, in that the hulls ")#mi("{K_t}")#text(" are not necessarily the image of simple curves ")#mi("{\\gamma}")#text(". This is often the case for short times if the driving function ")#mi("{U_t}")#text(" does not oscillate too wildly, but it can happen that the curve ")#mi("{\\gamma}")#text(" that one would expect to trace out ")#mi("{K_t}")#text(" eventually intersects itself, in which case the region it then encloses must be absorbed into the hull ")#mi("{K_t}")#text(" (cf. the “pinching off” phenomenon in the Carathéodory kernel theorem). Nevertheless, it is still possible to have Loewner chains that are “generated” by non-simple paths ")#mi("{\\gamma: [0,+\\infty) \\rightarrow \\mathbf{H}}")#text(", in the sense that ")#mi("{H_t}")#text(" consists of the unbounded connected component of the complement ")#mi("{\\mathbf{H} \\backslash \\gamma([0,t])}")#text(".")#linebreak()#text(" There are some symmetries of the transform from the ")#mi("{U_t}")#text(" to the ")#mi("{g_t}")#text(". If one translates ")#mi("{U_t}")#text(" by a constant, ")#mi("{\\tilde U_t = U_t + x_0}")#text(", then the resulting domains ")#mi("{H_t}")#text(" are also translated, ")#mi("{\\tilde H_t = H_t + x_0}")#text(", and ")#mi("{\\tilde g_t(z) = g_t(z-x_0) + x_0}")#text(". Slightly less trivially, for any ")#mi("{\\lambda > 0}")#text(", if one performs a rescaled dilation ")#mi("{\\tilde U_t := \\lambda^{-1} U_{\\lambda^2 t}}")#text(", then one can check using ")#link(<tao-0790928f3c5853a8b0b5>)[#text("(13)")]#text(" that ")#mi("{\\tilde H_t = \\lambda^{-1} H_{\\lambda^2 t}}")#text(", and the corresponding conformal maps ")#mi("{\\tilde g_t}")#text(" are given by ")#mi("{\\tilde g_t(z) = \\lambda^{-1} g_{\\lambda^2 t}(\\lambda z)}")#text(". On the other hand, just performing a scalar multiple ")#mi("{\\tilde U_t = \\lambda U_t}")#text(" on the driving force ")#mi("{U_t}")#text(" can transform the behavior of ")#mi("{g_t}")#text(" dramatically; the transform from ")#mi("{U_t}")#text(" to ")#mi("{g_t}")#text(" is very definitely not linear!")

#heading(level: 1)[#strong[#text(" — 4. Schramm-Loewner evolution — ")]]

#text("In the previous section, we have indicated that every continuous driving function ")#mi("{U: [0,\\infty) \\rightarrow {\\bf R}}")#text(" gives rise to a family ")#mi("{g_t: H_t \\rightarrow \\mathbf{H}}")#text(" of conformal maps obeying the Loewner equation ")#link(<tao-0790928f3c5853a8b0b5>)[#text("(13)")]#text(". The (chordal) ")#link("https://en.wikipedia.org/wiki/Schramm%E2%80%93Loewner_evolution")[#text("Schramm-Loewner evolution")]#text(" (")#mi("{SLE_\\kappa}")#text(") with parameter ")#mi("{\\kappa \\geq 0}")#text(" is the special case in which the driving function ")#mi("{t \\mapsto U_t}")#text(" takes the form ")#mi("{U_t = \\sqrt{\\kappa} \\mathbf{B}_t}")#text(" for some real Brownian motion based at the origin. Thus ")#mi("{\\mathbf{g}_t: \\mathbf{H}_t \\rightarrow \\mathbf{H}}")#text(" is now a random conformal map from a random domain ")#mi("{\\mathbf{H}_t}")#text(", defined by solving the Schramm-Loewner equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\mathbf{g}_t(z) = \\frac{2}{\\mathbf{g}_t(z) - \\sqrt{\\kappa} \\mathbf{B}_t}")]]

#text("with initial condition ")#mi("{\\mathbf{g}_0(z) = z}")#text(" for ")#mi("{z \\in \\mathbf{H}}")#text(", and with ")#mi("{\\mathbf{H}_t}")#text(" defined as the set of all ")#mi("{z}")#text(" for which the above ODE can be solved up to time ")#mi("{t}")#text(" taking values in ")#mi("{\\mathbf{H}}")#text(". The parameter ")#mi("{\\kappa}")#text(" cannot be scaled away by simple renormalisations such as scaling, and in fact the behaviour of ")#mi("{SLE_\\kappa}")#text(" is rather sensitive to the value of ")#mi("{\\kappa}")#text(", with special behaviour or significance at various values such as ")#mi("{\\kappa = 2, 8/3, 3, 4, 6, 8}")#text(" playing particularly special roles; there is also a duality relationship between ")#mi("{SLE_\\kappa}")#text(" and ")#mi("{SLE_{16/\\kappa}}")#text(" which we will not discuss here.")#linebreak()#text(" The ")#mi("{\\kappa=0}")#text(" case is rather boring, in which ")#mi("{\\mathbf{g}_t(z) = \\sqrt{z^2+4t}}")#text(" is deterministic, and ")#mi("{\\mathbf{H}_t}")#text(" is just ")#mi("{\\mathbf{H}_t}")#text(" with the line segment between ")#mi("{0}")#text(" and ")#mi("{2\\sqrt{t}i}")#text(" removed. The cases ")#mi("{\\kappa>0}")#text(" are substantially more interesting. It is a non-trivial theorem (particularly at the special value ")#mi("{\\kappa = 8}")#text(") that ")#mi("{SLE_\\kappa}")#text(" is almost surely generated by some random path ")#mi("{\\mathbf{\\gamma}: [0,+\\infty) \\rightarrow \\mathbf{H}}")#text("; see Theorem 6.3 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(". The nature of this path is sensitive to the choice of parameter ")#mi("{\\kappa}")#text(":")

#list(
[#text("For ")#mi("{0 \\leq \\kappa \\leq 4}")#text(", the path is almost surely simple and goes to infinity as ")#mi("{t \\rightarrow \\infty}")#text("; it also avoids the real line (except at time ")#mi("{t=0}")#text(").")],
[#text("For ")#mi("{4 < \\kappa < 8}")#text(", the path is almost surely not space-filling, but nevertheless the regions ")#mi("{\\mathbf{H}_t}")#text(" shrink to the empty set: ")#mi("{\\bigcap_{t>0} \\mathbf{H}_t = \\emptyset}")#text("; it also has non-trivial intersection with the real line.")],
[#text("For ")#mi("{\\kappa \\geq 8}")#text(", the path is almost surely space-filling (which of course also implies that ")#mi("{\\bigcap_{t>0} \\mathbf{H}_t = \\emptyset}")#text("), and also hits every point on ")#mi("{{\\bf R}}")#text(".")]
)

#text("See Section 6.2 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(". The path becomes increasingly fractal as ")#mi("{\\kappa}")#text(" increases: it is a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2153402")[#text("result of Rohde and Schramm")]#text(" and ")#link("https://arxiv.org/abs/math/0211322")[#text("Beffara")]#text(" that the image almost surely has Hausdorff dimension ")#mi("{\\min(1 + \\frac{\\kappa}{8}, 2)}")#text(".")#linebreak()#text(" We have asserted that ")#mi("{SLE_\\kappa}")#text(" defines a random path in ")#mi("{\\mathbf{H}}")#text(" that starts at the origin and generally “wanders off” to infinity (though for ")#mi("{\\kappa > 4}")#text(" it keeps recurring back to bounded sets infinitely often). By the Riemann mapping theorem, we can now extend this to other domains. Let ")#mi("{U}")#text(" be a simply connected open proper subset of ")#mi("{{\\bf C}}")#text(" whose boundary we will assume for simplicity to be a Jordan curve (this hypothesis can be relaxed). Let ")#mi("{z_0, z_\\infty}")#text(" be two distinct points on the boundary ")#mi("{\\partial U}")#text(". By the Riemann mapping theorem and Carathéodory’s theorem (Theorem 20 from ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text("), there is a conformal map ")#mi("{\\phi: U \\rightarrow \\mathbf{H}}")#text(" whose continuous extension ")#mi("{\\phi: \\overline{U} \\rightarrow \\overline{\\mathbf{H}}}")#text(" maps ")#mi("{z_0}")#text(" and ")#mi("{z_\\infty}")#text(" to ")#mi("{0}")#text(" and ")#mi("{\\infty}")#text(" respectively; this map is unique up to rescalings ")#mi("{\\phi \\mapsto \\lambda \\phi}")#text(" for ")#mi("{\\lambda > 0}")#text(". One can then define the Schramm-Loewner evolution ")#mi("{SLE_\\kappa}")#text(" on ")#mi("{U}")#text(" from ")#mi("{z_0}")#text(" to ")#mi("{z_\\infty}")#text(" to be the family of conformal maps ")#mi("{\\phi^{-1} \\circ \\mathbf{g}_t \\circ \\phi: \\phi^{-1}(\\mathbf{H}_t) \\rightarrow U}")#text(" for ")#mi("{t>0}")#text(", where ")#mi("{\\mathbf{g}_t: \\mathbf{H}_t \\rightarrow \\mathbf{H}}")#text(" is the usual Schramm-Loewner evolution ")#mi("{SLE_\\kappa}")#text(" with parameter ")#mi("{\\kappa}")#text(". The Schramm-Loewner evolution ")#mi("{SLE_\\kappa}")#text(" on ")#mi("{U}")#text(" is well defined up to a time reparameterisation ")#mi("{t \\mapsto \\lambda^{-2} t}")#text(". The Markovian and stationary nature of Brownian motion translates to an analogous Markovian and conformally invariant property of ")#mi("{SLE_\\kappa}")#text(". Roughly speaking, it is the following: if ")#mi("{U}")#text(" is any reasonable domain with two boundary points ")#mi("{z_0, z_\\infty}")#text(", ")#mi("{\\mathbf{g}_t: \\mathbf{U}_t \\rightarrow U}")#text(" is ")#mi("{SLE_\\kappa}")#text(" on this domain from ")#mi("{t_0}")#text(" to ")#mi("{t_\\infty}")#text(" with associated path ")#mi("{\\mathbf{\\gamma}: [0,+\\infty) \\rightarrow U}")#text(", and ")#mi("{t_0>0}")#text(" is any time, then after conditioning on the path up to time ")#mi("{t_0}")#text(", the remainder of the ")#mi("{SLE_\\kappa}")#text(" path has the same image as the ")#mi("{SLE_\\kappa}")#text(" path on the domain ")#mi("{\\mathbf{U}_{t_0}}")#text(" from ")#mi("{\\mathbf{\\gamma}(t_0)}")#text(" to ")#mi("{t_\\infty}")#text(". Conversely, under suitable regularity hypotheses, the ")#mi("{SLE_\\kappa}")#text(" processes are the ")#emph[#text("only")]#text(" random path processes on domains with this property (much as Brownian motion is the only Markovian stationary process, once one normalises the mean and variance). As a consequence, whenever one now a random path process that is known or suspected to enjoy some conformal invariance properties, it has become natural to conjecture that it obeys the law of ")#mi("{SLE_\\kappa}")#text(" (though in some cases it is more natural to work with other flavours of SLE than the chordal SLE discussed here, such as radial SLE or whole-plane SLE). For instance, in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1776084")[#text("the pioneering work of Schramm")]#text(", this line of reasoning was used to conjecture that the ")#link("https://en.wikipedia.org/wiki/Loop-erased_random_walk")[#text("loop-erased random walk")]#text(" in a domain has the law of (radial) ")#mi("{SLE_2}")#text("; this conjecture was then established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2044671")[#text("by Lawler, Schramm, and Werner")]#text(". Many further processes have since been either proven or conjectured to be linked to one of the SLE processes, such as the limiting law of a ")#link("https://en.wikipedia.org/wiki/Loop-erased_random_walk#Uniform_spanning_tree")[#text("uniform spanning tree")]#text(" (proven to be ")#mi("{SLE_8}")#text("), interfaces of the ")#link("https://en.wikipedia.org/wiki/Ising_model")[#text("Ising model")]#text(" (proven to be ")#mi("{SLE_3}")#text("), or the scaling limit of self-avoiding random walks (conjectured to be ")#mi("{SLE_{8/3}}")#text("). Further discussion of these topics is beyond the scope of this course, and we refer the interested reader to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2129588")[#text("Lawler’s book")]#text(" for more details.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-500299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2018")])]

#text("What is known about the original motivation to introduce the SLE ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-500455")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("My understanding is that Schramm introduced the (radial) SLE in his ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1776084")[#text("2000 paper")]#text(" to study the scaling limit of loop-erased random walk. ")#link("https://arxiv.org/abs/math/0602151")[#text("Schramm’s ICM lecture")]#text(" also gives some further motivation (though not the original one) coming from Smirnov’s proof of conformal invariance of hexagonal percolation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-501281")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2018")])]

#text("Hi Terry, Rohde and Schramm’s paper proved that SLE is almost surely a curve with Hausdorff dimension at most {\\min(1 + \\frac{\\kappa}{8}, 2)}. The exact Hausdorff dimension is established by Beffara in a separate paper: ")#link("https://arxiv.org/pdf/math/0211322.pdf")[#text("https://arxiv.org/pdf/math/0211322.pdf")]#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ab8f067911a56250151101930c10cfd4565f7df454368d9c8480516058985ef-445c64f76135d38f9aad08fb4b8c8412d7a70f402d8de6a1c20c2d309b421a3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-501307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("Dear Terry,")#linebreak()#text(" I think the scaling limit of self-avoiding random walk is conjectured to be SLE_{8/3}, not SLE_{4/3}. See for example, ")#link("https://en.wikipedia.org/wiki/Self-avoiding_walk")[#text("https://en.wikipedia.org/wiki/Self-avoiding_walk")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-501310")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("I’ve always found the SLE curves exceedingly ugly insofar as I have read about them. Yet, these are the curves that provably are the limit shapes of the interfaces between regions that arise in statistical models such as Uniform Spanning Tree or Potts or Percolation (of various types and colors) and we are looking for the SLE constant.")

#text("Even more basic, is that the image Brownian motion under conformal transformation is a time change of Brownian motion. So this is like doing random walk in Polar Coodinates or some other very complicated grid network.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Lessa")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-501356")[#strong[#text("Pablo Lessa")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("I think Corollary 13 should say that the probability of intersecting ")#mi("K")#text(" is greater than or equal to that of intersecting the segment ")#mi("[\\epsilon,1]")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-622838")[#strong[#text("246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: Notes 2. Next set of notes: Notes 4. We now approach conformal maps from yet another perspective. Given an open subset of the complex […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-644245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2022")])]

#text("Brownian motion is conformal invariant. This is so cool!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-686862")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2024")])]

#text("I believe that in the definition of a normally distributed complex random variable, x_0 should instead read z_0.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-689254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dear Dr. Tao,")

#text("I found the definition of the Brownian motion hard to understand. Do you have any visualizing resources of the Brownian Motion?")

#text("Thanks in advance.")

#emph[#text("[I recommend doing web searches or AI queries to find suitable links. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-692523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2026")])]

#text("Hello,")

#text("In the definition of complex Brownian motion, should it be z_0 \\in \\C? In the box on optional stopping identities, should it be ")#linebreak()#text("“B^{z_0} for times up to t?” Also, should it be z_0 \\in \\C in the same paragraph?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-693303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Dear Dr. Tao,")

#text("I am confused about the proof of Lemma 4: The statement of Lemma 4 does not involve conditional expectation or total expectation, so why does this proof involve the law of total expectation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/#comment-693312")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("This is a basic example of a “conditioning argument”: in many situations (particularly when Markovian processes are involved), conditional expectations are easier to compute than unconditional expectation, so if even if one is interested in an unconditional expectation, it can be useful to invoke the law of total expectation to express that quantity in terms of conditional expectations. (Perhaps if one reverses the order of the proof in the blog post, so that one computes the conditional expectation first and then applies the law of total expectation to deduce unconditional expectations, the structure of the argument might be more intuitive for you.)")
]
]
