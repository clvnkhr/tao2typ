// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/
// Converted to Typst by tao2typ: "2026-10-14T09:11:31.403015+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Central extensions of Lie groups, and cocycle averaging", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Central extensions of Lie groups, and cocycle averaging")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/")[#text("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the last few months, I have been working my way through the theory behind the solution to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(", as I (together with Emmanuel Breuillard, Ben Green, and Tom Sanders) have found this theory to be useful in obtaining noncommutative inverse sumset theorems in arbitrary groups; I hope to be able to report on this connection at some later point on this blog. Among other things, this theory achieves the remarkable feat of creating a smooth Lie group structure out of what is ostensibly a much weaker structure, namely the structure of a locally compact group. The ability of algebraic structure (in this case, group structure) to upgrade weak regularity (in this case, continuous structure) to strong regularity (in this case, smooth and even analytic structure) seems to be a recurring theme in mathematics, and an important part of what I like to call the “dichotomy between structure and randomness”.")

#text("The theory of Hilbert’s fifth problem sprawls across many subfields of mathematics: Lie theory, representation theory, group theory, nonabelian Fourier analysis, point-set topology, and even a little bit of group cohomology. The latter aspect of this theory is what I want to focus on today. The general question that comes into play here is the ")#emph[#text("extension problem")]#text(": given two (topological or Lie) groups ")#mi("{H}")#text(" and ")#mi("{K}")#text(", what is the structure of the possible groups ")#mi("{G}")#text(" that are formed by extending ")#mi("{H}")#text(" by ")#mi("{K}")#text(". In other words, given a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0,")]]

#text("to what extent is the structure of ")#mi("{G}")#text(" determined by that of ")#mi("{H}")#text(" and ")#mi("{K}")#text("?")

#text("As an example of why understanding the extension problem would help in structural theory, let us consider the task of classifying the structure of a Lie group ")#mi("{G}")#text(". Firstly, we factor out the connected component ")#mi("{G^\\circ}")#text(" of the identity as")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow G^\\circ \\rightarrow G \\rightarrow G/G^\\circ \\rightarrow 0;")]]

#text("as Lie groups are locally connected, ")#mi("{G/G^\\circ}")#text(" is discrete. Thus, to understand general Lie groups, it suffices to understand the extensions of discrete groups by connected Lie groups.")

#text("Next, to study a connected Lie group ")#mi("{G}")#text(", we can consider the conjugation action ")#mi("{g: X \\mapsto gXg^{-1}}")#text(" on the Lie algebra ")#mi("{{\\mathfrak g}}")#text(", which gives the ")#link("http://en.wikipedia.org/wiki/Adjoint_representation_of_a_Lie_group")[#text("adjoint representation")]#text(" ")#mi("{\\text{Ad}: G \\rightarrow GL({\\mathfrak g})}")#text(". The kernel of this representation consists of all the group elements ")#mi("{g}")#text(" that commute with all elements of the Lie algebra, and thus (by connectedness) is the center ")#mi("{Z(G)}")#text(" of ")#mi("{G}")#text(". The adjoint representation is then faithful on the quotient ")#mi("{G/Z(G)}")#text(". The short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow Z(G) \\rightarrow G \\rightarrow G/Z(G) \\rightarrow 0")]]

#text("then describes ")#mi("{G}")#text(" as a central extension (by the abelian Lie group ")#mi("{Z(G)}")#text(") of ")#mi("{G/Z(G)}")#text(", which is a connected Lie group with a faithful finite-dimensional linear representation.")

#text("This suggests a route to Hilbert’s fifth problem, at least in the case of connected groups ")#mi("{G}")#text(". Let ")#mi("{G}")#text(" be a connected locally compact group that we hope to demonstrate is isomorphic to a Lie group. As discussed in ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("a previous post")]#text(", we first form the space ")#mi("{L(G)}")#text(" of one-parameter subgroups of ")#mi("{G}")#text(" (which should, eventually, become the Lie algebra of ")#mi("{G}")#text("). Hopefully, ")#mi("{L(G)}")#text(" has the structure of a vector space. The group ")#mi("{G}")#text(" acts on ")#mi("{L(G)}")#text(" by conjugation; this action should be both continuous and linear, giving an “adjoint representation” ")#mi("{\\text{Ad}: G \\rightarrow GL(L(G))}")#text(". The kernel of this representation should then be the center ")#mi("{Z(G)}")#text(" of ")#mi("{G}")#text(". The quotient ")#mi("{G/Z(G)}")#text(" is locally compact and has a faithful linear representation, and is thus a Lie group by von Neumann’s version of Cartan’s theorem (discussed in ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("this previous post")]#text("). The group ")#mi("{Z(G)}")#text(" is locally compact abelian, and so it should be a relatively easy task to establish that it is also a Lie group. To finish the job, one needs the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Central extensions of Lie are Lie)")]#text(" ")#metadata(none) <tao-acd785249c11fdda9ea4>#text(" Let ")#mi("{G}")#text(" be a locally compact group which is a central extension of a Lie group ")#mi("{H}")#text(" by an abelian Lie group ")#mi("{K}")#text(". Then ")#mi("{G}")#text(" is also isomorphic to a Lie group.")
]

#text("This result can be obtained by combining a ")#link("http://www.ams.org/mathscinet-getitem?mr=36238")[#text("result of Kuranishi")]#text(" with a ")#link("http://www.ams.org/mathscinet-getitem?mr=33830")[#text("result of Gleason")]#text("; I am recording this argument below the fold. The point here is that while ")#mi("{G}")#text(" is initially only a topological group, the smooth structures of ")#mi("{H}")#text(" and ")#mi("{K}")#text(" can be combined (after a little bit of cohomology) to create the smooth structure on ")#mi("{G}")#text(" required to upgrade ")#mi("{G}")#text(" from a topological group to a Lie group. One of the main ideas here is to improve the behaviour of a cocycle by averaging it; this basic trick is helpful elsewhere in the theory, resolving a number of cohomological issues in topological group theory. The result can be generalised to show in fact that arbitrary (topological) extensions of Lie groups by Lie groups remain Lie; this was shown by ")#link("http://www.ams.org/mathscinet-getitem?mr=33830")[#text("Gleason")]#text(". However, the above special case of this result is already sufficient (in conjunction with the rest of the theory, of course) to resolve Hilbert’s fifth problem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" We have shown in the above discussion that every connected Lie group is a central extension (by an abelian Lie group) of a Lie group with a faithful continuous linear representation. It is natural to ask whether this central extension is necessary. Unfortunately, not every connected Lie group admits a faithful continuous linear representation. An example (due to Birkhoff) is the Heisenberg-Weyl group")

#align(center)[#tao-fit-display[#mitex("G := \\begin{pmatrix} 1 & {\\bf R} & {{\\bf R}/{\\bf Z}} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix} = \\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix} / \\begin{pmatrix} 1 & 0 & {\\bf Z} \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}.")]]

#text("Indeed, if we consider the group elements")

#align(center)[#tao-fit-display[#mitex("A := \\begin{pmatrix} 1 & 1 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B := \\begin{pmatrix} 1 & 0 & 1/p \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("for some prime ")#mi("{p}")#text(", then one easily verifies that ")#mi("{B}")#text(" has order ")#mi("{p}")#text(" and is central, and that ")#mi("{AB}")#text(" is conjugate to ")#mi("{A}")#text(". If we have a faithful linear representation ")#mi("{\\rho: G \\rightarrow GL_n({\\bf C})}")#text(" of ")#mi("{G}")#text(", then ")#mi("{\\rho(B)}")#text(" must have at least one eigenvalue ")#mi("{\\alpha}")#text(" that is a primitive ")#mi("{p^{th}}")#text(" root of unity. If ")#mi("{V}")#text(" is the eigenspace associated to ")#mi("{\\alpha}")#text(", then ")#mi("{\\rho(A)}")#text(" must preserve ")#mi("{V}")#text(", and be conjugate to ")#mi("{\\alpha \\rho(A)}")#text(" on this space. This forces ")#mi("{\\rho(A)}")#text(" to have at least ")#mi("{p}")#text(" distinct eigenvalues on ")#mi("{V}")#text(", and hence ")#mi("{V}")#text(" (and thus ")#mi("{{\\bf C}^n}")#text(") must have dimension at least ")#mi("{p}")#text(". Letting ")#mi("{p \\rightarrow \\infty}")#text(" we obtain a contradiction. (On the other hand, ")#mi("{G}")#text(" is certainly isomorphic to the extension of the linear group ")#mi("{{\\bf R}^2}")#text(" by the abelian group ")#mi("{{\\bf R}/{\\bf Z}}")#text(".)")
]

#metadata(none) <tao-cac03c747a2b8e41a136>

#heading(level: 1)[#strong[#text(" — 1. A little group cohomology — ")]]

#text("Let us first ignore the topological or Lie structure, consider the (central) extension problem for discrete groups only. Thus, let us suppose we have a (discrete) group ")#mi("{G = (G,\\cdot)}")#text(" which is a central extension of a group ")#mi("{H}")#text(" by a group ")#mi("{K}")#text(". We view ")#mi("{K}")#text(" as a central subgroup of ")#mi("{G}")#text(" (which we write additively to emphasise its abelian nature), and use ")#mi("{\\pi: G \\rightarrow H}")#text(" to denote the projection map. If ")#mi("{k \\in K}")#text(" and ")#mi("{g \\in G}")#text(", we write ")#mi("{g+k}")#text(" for ")#mi("{kg=gk}")#text(" to emphasise the central nature of ")#mi("{K}")#text(".")

#text("It may help to view ")#mi("{G}")#text(" as a principal ")#mi("{K}")#text("-bundle over ")#mi("{H}")#text(", with ")#mi("{K}")#text(" being thought of as the “vertical” component of ")#mi("{G}")#text(" and ")#mi("{H}")#text(" as the “horizontal” component. Thus ")#mi("{G}")#text(" is the union of “vertical fibres” ")#mi("{\\pi^{-1}(h)}")#text(", ")#mi("{h \\in H}")#text(" indexed by the horizontal group ")#mi("{H}")#text(", each of which is a coset (or a ")#link("http://en.wikipedia.org/wiki/Torsor")[#text("torsor")]#text(") of the vertical group ")#mi("{K}")#text(".")

#text("As central extensions are not unique, we will need to specify some additional data beyond ")#mi("{H}")#text(" and ")#mi("{K}")#text(". One way to view this data is to specify a ")#link("http://en.wikipedia.org/wiki/Section_(fiber_bundle)")[#text("section")]#text(" of the extension, that is to say a map ")#mi("{\\phi: H \\rightarrow G}")#text(" that is a right-inverse for the projection map ")#mi("{\\pi}")#text(", thus ")#mi("{\\phi}")#text(" selects one element ")#mi("{\\phi(h)}")#text(" from each fibre ")#mi("{\\pi^{-1}(h)}")#text(" of the projection map (which is also a coset of ")#mi("{K}")#text("). Such a section can be always chosen using the axiom of choice, though of course there is no guarantee of any measurability, continuity, or smoothness properties of such a section if the groups involved have the relevant measure-theoretic, topological, or smooth structure.")

#text("Note that we do not necessarily require the section ")#mi("{\\phi}")#text(" to map the goup identity ")#mi("{1_H}")#text(" of ")#mi("{H}")#text(" to the group identity ")#mi("{1_G}")#text(" of ")#mi("{G}")#text(", though in practice it is usually not difficult to impose this constraint if desired.")

#text("The group ")#mi("{G}")#text(" can then be described, as a set, as the disjoint union of its fibres ")#mi("{\\phi(h)+K}")#text(" for ")#mi("{h \\in H}")#text(":")

#align(center)[#tao-fit-display[#mitex("G = \\biguplus_{h\\in H} \\phi(h)+K.")]]

#text("Thus each element ")#mi("{g \\in G}")#text(" can be uniquely expressed as ")#mi("{\\phi(h)+k}")#text(" for some ")#mi("{h \\in H}")#text(" and ")#mi("{k \\in K}")#text(", and can thus be viewed as a system of coordinates of ")#mi("{G}")#text(" (identifying it as a set with ")#mi("{H \\times K}")#text("). Now we turn to the group operations ")#mi("{()^{-1}: G \\rightarrow G}")#text(" and ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(". If ")#mi("{h_1,h_2 \\in H}")#text(", then the product ")#mi("{\\phi(h_1)\\phi(h_2)}")#text(" must lie in the fibre of ")#mi("{h_1h_2}")#text(", and so we have")

#align(center)[#tao-fit-display[#mitex("\\phi(h_1) \\phi(h_2) = \\phi(h_1 h_2) + \\psi( h_1,h_2 )")]]

#text("for some function ")#mi("{\\psi: H \\times H \\rightarrow K}")#text(". By the centrality of ")#mi("{K}")#text(", this describes the product law for general elements of ")#mi("{G}")#text(" in the ")#mi("{H \\times K}")#text(" coordinates: ")#metadata(none) <tao-8d7ec9aa29b87f7634b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(\\phi(h_1)+k_1) (\\phi(h_2)+k_2) = \\phi(h_1h_2) + (k_1+k_2+\\psi(h_1,h_2)).")]]

#text("Using the associative law for ")#mi("{G}")#text(", we see that ")#mi("{\\psi}")#text(" must obey the ")#emph[#text("cocycle equation")]#text(" ")#metadata(none) <tao-6a5b32b39ff583bc5f86>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\psi(h_1,h_2) + \\psi(h_1 h_2,h_3) = \\psi(h_1,h_2 h_3) + \\psi(h_2,h_3)")]]

#text("for all ")#mi("{h_1,h_2,h_3 \\in K}")#text("; we refer to functions ")#mi("{\\psi}")#text(" that obey this equation as ")#emph[#text("cocycles")]#text(" (the reason for this terminology being explained in ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("this previous blog post")]#text("). The space of all such cocyles is denoted ")#mi("{Z^2(H,K)}")#text(" (or ")#mi("{Z^2_{disc}(H,K)}")#text(", if we wish to emphasise that we are working for now in the discrete category, as opposed to the measurable, topological, or smooth category); this is an abelian group with respect to pointwise addition. Using ")#link(<tao-8d7ec9aa29b87f7634b2>)[#text("(1)")]#text(", we also have a description of the group identity ")#mi("{1_G}")#text(" of ")#mi("{G}")#text(" in coordinates: ")#metadata(none) <tao-135c4cf302528b452dba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("1_G = \\phi(1_H) - \\psi(1_H,1_H).")]]

#text("Indeed, this can be seen by noting that ")#mi("{1_G}")#text(" is the unique solution of the group equation ")#mi("{g \\cdot g = g}")#text(". Similarly, we can describe the inverse operation in ")#mi("{H \\times K}")#text(" coordinates: ")#metadata(none) <tao-f9fb0451ba0369d444c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(\\phi(h)+k)^{-1} = \\phi(h^{-1}) + (-k-\\psi(h,h^{-1})-\\psi(1_H,1_H)).")]]

#text("Thus we see that the cocycle ")#mi("{\\psi}")#text(", together with the group structures on ")#mi("{H}")#text(" and ")#mi("{K}")#text(", capture all the group-theoretic structure of ")#mi("{G}")#text(". Conversely, given any cocycle ")#mi("{\\psi \\in Z^2(H,K)}")#text(", one can place a group structure on the set ")#mi("{H \\times K}")#text(" by declaring the multiplication law as")

#align(center)[#tao-fit-display[#mitex("(h_1,k_1) \\cdot (h_2,k_2) := (h_1 h_2, k_1 + k_2 + \\psi(h_1,h_2)),")]]

#text("the identity element as ")#mi("{(1_H, -\\psi(1_H,1_H))}")#text(", and the inversion law as")

#align(center)[#tao-fit-display[#mitex("(h,k)^{-1} = (h^{-1}, -k-\\psi(h,h^{-1}) - \\psi(1_H,1_H)).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-ff233f554635517e85bf>#text(" Using the cocycle equation ")#link(<tao-6a5b32b39ff583bc5f86>)[#text("(2)")]#text(", show that the above operations do indeed yield group structure on ")#mi("{H \\times K}")#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Group_(mathematics)#Definition")[#text("group axioms")]#text(" are obeyed). If ")#mi("{\\psi}")#text(" arises as the cocycle associated to a section of a group extension ")#mi("{G}")#text(", we then see from ")#link(<tao-8d7ec9aa29b87f7634b2>)[#text("(1)")]#text(", ")#link(<tao-135c4cf302528b452dba>)[#text("(3)")]#text(", ")#link(<tao-f9fb0451ba0369d444c8>)[#text("(4)")]#text(" that this group structure we have just placed on ")#mi("{H \\times K}")#text(" is isomorphic to that on ")#mi("{G}")#text(".")
]

#text("Thus we see that once we select a section, we can describe a central extension of ")#mi("{K}")#text(" by ")#mi("{H}")#text(" (up to group isomorphism) as a cocycle, and conversely every cocycle arises in this manner. However, we have some freedom in deciding how to select this section. Given one section ")#mi("{\\phi: H \\rightarrow G}")#text(", any other section ")#mi("{\\phi^{\\prime}: H \\rightarrow G}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\phi^{\\prime}(h) = \\phi(h) + f(h)")]]

#text("for some function ")#mi("{f: H \\rightarrow K}")#text("; conversely, every such function ")#mi("{f}")#text(" can be used to shift a section ")#mi("{\\phi}")#text(" to a new section ")#mi("{\\phi^{\\prime}}")#text(". We refer to such functions ")#mi("{f}")#text(" as ")#emph[#text("gauge functions")]#text(". The cocycles ")#mi("{\\psi, \\psi^{\\prime}}")#text(" associated to ")#mi("{\\phi,\\phi^{\\prime}}")#text(" are related by the ")#emph[#text("gauge transformation")]

#align(center)[#tao-fit-display[#mitex("\\psi^{\\prime}(h_1,h_2) = \\psi(h_1,h_2) + df(h_1,h_2)")]]

#text("where ")#mi("{df: H \\times H \\rightarrow K}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("df(h_1,h_2) := f(h_1)+f(h_2)-f(h_1h_2).")]]

#text("We refer to functions of the form ")#mi("{df}")#text(" as ")#emph[#text("coboundaries")]#text(", and denote the space of all such coboundaries as ")#mi("{B^2(H,K)}")#text(" (or ")#mi("{B^2_{disc}(H,K)}")#text(", if we want to emphasise the discrete nature of these coboundaries). One easily verifies that all coboundaries are cocycles, and so ")#mi("{B^2(H,K)}")#text(" is a subgroup of ")#mi("{Z^2(H,K)}")#text(". We then define the ")#emph[#text("second group cohomology")]#text(" ")#mi("{H^2(H,K)}")#text(" (or ")#mi("{H^2_{disc}(H,K)}")#text(") to be the quotient group")

#align(center)[#tao-fit-display[#mitex("H^2(H,K) := Z^2(H,K) / B^2(H,K),")]]

#text("and refer to elements of ")#mi("{H^2(H,K)}")#text(" as ")#emph[#text("cohomology classes")]#text(". (There are higher order group cohomologies, which also have some relevance for the extension problem, but will not be needed here; see ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("this previous post")]#text(" for further discussion. The first group cohomology ")#mi("{H^1(H,K) = Hom(H,K)}")#text(" is just the space of homomorphisms from ")#mi("{H}")#text(" to ")#mi("{K}")#text("; again, this has some relevance for the extension problem but will not be needed here.)")

#text("We call two cocycles ")#emph[#text("cohomologous")]#text(" if they differ by a coboundary (i.e. they lie in the same cohomology class). Thus we see that different sections of a single central group extension provide cohomologous cocycles. Conversely, if two cocycles are cohomologous, then the group structures on ")#mi("{H \\times K}")#text(" given by these cocycles are easily seen to be isomorphic; furthermore, if we restrict group isomorphism to fix each fibre of ")#mi("{\\pi}")#text(", this is the only way in which group structures generated by such cocycles are isomorphic. Thus, we see that up to group isomorphism, central group extensions are described by cohomology classes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" All constant cocycles are coboundaries, and so if desired one can always normalise a cocycle ")#mi("{\\psi: H \\times H \\rightarrow K}")#text(" (up to coboundaries) so that ")#mi("{\\psi(1_H,1_H) = 0}")#text(". This can lead to some minor simplifications to some of the cocycle formulae (such as ")#link(<tao-135c4cf302528b452dba>)[#text("(3)")]#text(", ")#link(<tao-f9fb0451ba0369d444c8>)[#text("(4)")]#text(").")
]

#text("The trivial cohomology class of course contains the trivial cocycle, which in turn generates the direct product ")#mi("{H \\times K}")#text(". Non-trivial cohomology classes generate “skew” products that will not be isomorphic to the direct product ")#mi("{H \\times K}")#text(" (at least if we insist on fixing each fibre). In particular, we see that if the second group cohomology ")#mi("{H^2(H,K)}")#text(" is trivial, then the only central extensions of ")#mi("{H}")#text(" by ")#mi("{K}")#text(" are (up to isomorphism) the direct product extension.")

#text("In general, we do not expect the cohomology group to be trivial: not every cocycle is a coboundary. A simple example is provided by viewing the integer group ")#mi("{{\\bf Z}}")#text(" as a central extension of a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" by the subgroup ")#mi("{N{\\bf Z}}")#text(" using the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow N{\\bf Z} \\rightarrow {\\bf Z} \\rightarrow {\\bf Z}/N{\\bf Z} \\rightarrow 0.")]]

#text("Clearly ")#mi("{{\\bf Z}}")#text(" is not isomorphic to ")#mi("{N{\\bf Z} \\times {\\bf Z}/N{\\bf Z}}")#text(" (the former group is torsion-free, while the latter group is not), and so ")#mi("{H^2({\\bf Z}/N{\\bf Z}, NZ)}")#text(" is non-trivial. If we use the section ")#mi("{\\phi: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf Z}}")#text(" that maps ")#mi("{i \\text{ mod } N}")#text(" to ")#mi("{i}")#text(" for ")#mi("{i=0,\\ldots,N-1}")#text(", then the associated cocycle ")#mi("{\\psi( i \\text{ mod } N, j \\text{ mod } N)}")#text(" is the familiar “carry bit” one learns about in primary school, which equals ")#mi("{N}")#text(" when ")#mi("{i,j=0,1,\\ldots,N-1}")#text(" and ")#mi("{i+j \\geq N}")#text(", but vanishes for other ")#mi("{i,j =0,1,\\ldots,N-1}")#text(".")

#text("However, when the “vertical group” ")#mi("{K}")#text(" is sufficiently “Euclidean” in nature, one can start deploying the method of ")#emph[#text("averaging")]#text(" to improve the behaviour of cocycles. Here is a simple example of the averaging method in action:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-bb9b481224ee5b7128ed>#text(" Let ")#mi("{H}")#text(" be a finite group, and let ")#mi("{K}")#text(" be a real vector space. Then ")#mi("{H^2(H,K)}")#text(" is trivial.")
]

#emph[#text("Proof:")]#text(" We need to show that every cocycle is a coboundary. Accordingly, let ")#mi("{\\psi \\in Z^2(H,K)}")#text(" be a cocycle, thus")

#align(center)[#tao-fit-display[#mitex("\\psi(h_1,h_2) + \\psi(h_1 h_2,h_3) = \\psi(h_1,h_2 h_3) + \\psi(h_2,h_3)")]]

#text("for all ")#mi("{h_1,h_2,h_3 \\in H}")#text(". We sum this equation over all ")#mi("{h_3 \\in H}")#text(", and then divide by the cardinality ")#tao-math("{\\left|H\\right|}", block: false)#text(" of ")#mi("{H}")#text("; note that this averaging operation relies on the finite nature of ")#mi("{H}")#text(" and the vector space nature of ")#mi("{K}")#text(". We obtain as a consequence")

#align(center)[#tao-fit-display[#mitex("\\psi(h_1,h_2) + f(h_1 h_2) = f(h_1) + f(h_2)")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("f(h) := {\\bf E}_{h_3 \\in H} \\psi(h,h_3) = \\frac{1}{\\left|H\\right|} \\sum_{h_3 \\in H} \\psi(h,h_3)", block: true)]]

#text("is the averaging of ")#mi("{\\psi}")#text(" in the second variable. We thus have ")#mi("{\\psi = df}")#text(", and so ")#mi("{\\psi}")#text(" is a coboundary as desired. ")#mi("\\Box")

#text("It is instructive to compare this argument against the non-triviality of ")#mi("{H^2({\\bf Z}/N{\\bf Z}, N{\\bf Z})}")#text(" mentioned earlier. While ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" is still finite, the problem here is that ")#mi("{N{\\bf Z}}")#text(" is not a vector space and so one cannot divide by ")#mi("{N}")#text(" to “straighten” the cocycle. However, the averaging argument can still achieve some simplification to such cocycles:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{H}")#text(" be a finite group, and let ")#mi("{\\psi \\in Z^2(H,{\\bf Z})}")#text(" is a cocycle. Show that ")#mi("{\\psi}")#text(" is cohomologous to a cocycle taking values in ")#mi("{\\{-1,0,+1\\}}")#text(". (")#emph[#text("Hint:")]#text(" average the cocycle as before using the reals ")#mi("{{\\bf R}}")#text(", then round to the nearest integer.)")
]

#text("Now we turn from discrete group theory to topological group theory. Now ")#mi("{H}")#text(", ")#mi("{K}")#text(", ")#mi("{G}")#text(" are required to be topological groups rather than discrete groups, with the projection map ")#mi("{\\pi: G \\rightarrow H}")#text(" continuous. (In particular, if ")#mi("{H}")#text(" is Hausdorff, then ")#mi("{K}")#text(" must be closed.) In this case, it is no longer the case that every (discrete) cocycle ")#mi("{\\psi \\in Z^2_{disc}(H,K)}")#text(" gives rise to a topological group, because the group structure on ")#mi("{H \\times K}")#text(" given by ")#mi("{\\psi}")#text(" need not be continuous with respect to the product topology of ")#mi("{H \\times K}")#text(". However, if the cocycle ")#mi("{\\psi}")#text(" is ")#emph[#text("continuous")]#text(", then it is clear that the group operations will be continuous, and so we will in fact generate a topological group. Conversely, if we have a section ")#mi("{\\phi: H \\rightarrow G}")#text(" which is continuous, then it is not difficult to verify that the cocycle generated is also continuous. This leads to a slightly different group cohomology, using the space ")#mi("{Z^2_{top}(H,K)}")#text(" of continuous cocycles, and also the space ")#mi("{B^2_{top}(H,K)}")#text(" of coboundaries ")#mi("{df}")#text(" arising from continuous gauge functions ")#mi("{f}")#text(".")

#text("However, such “global” cohomology contains some nontrivial global topological obstructions that limit its usefulness for the extension problem. One particularly fundamental such obstruction is that one does not expect global continuous sections ")#mi("{\\phi: H \\rightarrow G}")#text(" of a group extension to exist in general, unless ")#mi("{H}")#text(" or ")#mi("{K}")#text(" have a particularly simple topology (e.g. if they are contractible or simply connected). For instance, with the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow {\\bf Z} \\rightarrow {\\bf R} \\rightarrow {\\bf R}/{\\bf Z} \\rightarrow 0")]]

#text("there is no way to continuously lift the horizontal group ")#mi("{{\\bf R}/{\\bf Z}}")#text(" back up to the real line ")#mi("{{\\bf R}}")#text(", due to the presence of nontrivial ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(". While these global obstructions are quite interesting from an algebraic topology perspective, they are not of central importance in the theory surrounding Hilbert’s fifth problem, which is instead more concerned with the ")#emph[#text("local")]#text(" topological and Lie structure of groups.")

#text("Because of this, we shall work with ")#emph[#text("local")]#text(" sections and cocycles instead of global ones. A ")#emph[#text("local section")]#text(" in a topological group extension")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0")]]

#text("is a continuous map ")#mi("{\\phi: U \\rightarrow G}")#text(" from an open neighbourhood ")#mi("{U}")#text(" of the identity ")#mi("{1_H}")#text(" in ")#mi("{H}")#text(" to ")#mi("{G}")#text(" which is a right inverse of ")#mi("{\\pi}")#text(" on ")#mi("{U}")#text(", thus ")#mi("{\\phi(h) \\in \\pi^{-1}(h)}")#text(" for all ")#mi("{h \\in U}")#text(". (It is not yet obvious why local sections exist at all – there may still be ")#emph[#text("local")]#text(" obstructions to trivialising the fibre bundle – but certainly this task should be easier than that of locating ")#emph[#text("global")]#text(" continuous sections.)")

#text("Similarly, a ")#emph[#text("local cocycle")]#text(" is a continuous map ")#mi("{\\psi: U \\times U \\rightarrow K}")#text(" defined on some open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{H}")#text(" that obeys the cocycle equation ")#link(<tao-6a5b32b39ff583bc5f86>)[#text("(2)")]#text(" whenever ")#mi("{h_1,h_2,h_3 \\in U}")#text(" are such that ")#mi("{h_1h_2, h_2 h_3 \\in U}")#text(". We consider two local sections ")#mi("{\\phi: U \\rightarrow G}")#text(", ")#mi("{\\phi^{\\prime}: U^{\\prime} \\rightarrow G}")#text(" to be ")#emph[#text("locally identical")]#text(" if there exists a neighbourhood ")#mi("{U^{\\prime\\prime}}")#text(" of the identity contained in both ")#mi("{U}")#text(" and ")#mi("{U^{\\prime}}")#text(" such that ")#mi("{\\phi}")#text(" and ")#mi("{\\phi^{\\prime}}")#text(" agree on ")#mi("{U^{\\prime\\prime}}")#text(". Similarly, we consider two local cocycles ")#mi("{\\psi: U \\times U \\rightarrow G}")#text(" and ")#mi("{\\psi^{\\prime}: U^{\\prime} \\times U^{\\prime} \\rightarrow G}")#text(" to be locally identical if there is a neighbourhood ")#mi("{U^{\\prime\\prime}}")#text(" of the identity in ")#mi("{U \\cap U^{\\prime}}")#text(" such that ")#mi("{\\psi}")#text(" and ")#mi("{\\psi^{\\prime}}")#text(" agree on ")#mi("{U^{\\prime\\prime} \\times U^{\\prime\\prime}}")#text(". We let ")#mi("{Z^2_{top,loc}(H,K)}")#text(" be the space of local cocycles, modulo local identity; this is easily seen to be an abelian group.")

#text("One easily verifies that every local section induces a local cocycle (perhaps after shrinking the open neighbourhood ")#mi("{U}")#text(" slightly), which is well-defined up to local identity. Conversely, the computations used to show Exercise ")#link(<tao-ff233f554635517e85bf>)[#text("1")]#text(" show that every local cocycle creates a ")#emph[#text("local")]#text(" group structure on ")#mi("{H \\times K}")#text(".")

#text("If ")#mi("{U}")#text(" is an open neighbourhood the identity of ")#mi("{H}")#text(", ")#mi("{f: U \\rightarrow K}")#text(" is a continuous gauge function, and ")#mi("{U^{\\prime}}")#text(" is a smaller neighbourhood such that ")#mi("{(U^{\\prime})^2 \\subset U}")#text(", we can define the ")#emph[#text("local coboundary")]#text(" ")#mi("{df: U^{\\prime} \\times U^{\\prime} \\rightarrow K}")#text(" by the usual formula")

#align(center)[#tao-fit-display[#mitex("df(h_1,h_2) := f(h_1)+f(h_2) - f(h_1 h_2).")]]

#text("This is well-defined up to local identity. We let ")#mi("{B^2_{top,loc}(H,K)}")#text(" be the space of local coboundaries, modulo local identity; this is a subgroup of ")#mi("{Z^2_{top,loc}(H,K)}")#text(". Thus, one can form the local topological group cohomology ")#mi("{H^2_{top,loc}(H,K) := Z^2_{top,loc}(H,K) / B^2_{top,loc}(H,K)}")#text(". We say that two local cocycles are ")#emph[#text("locally cohomologous")]#text(" if they differ by a local coboundary.")

#text("The relevance of local cohomology to the Lie group extension problem can be seen from the following lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-5d920e9810479476191a>#text(" Let ")#mi("{G}")#text(" be a central (topological) group extension of a Lie group ")#mi("{H}")#text(" by a Lie group ")#mi("{K}")#text(". If there is a local section ")#mi("{\\phi: U \\rightarrow G}")#text(" whose associated local cocycle ")#mi("{\\psi: U^{\\prime} \\times U^{\\prime} \\rightarrow K}")#text(" is locally cohomologous to a ")#emph[#text("smooth")]#text(" local cocycle ")#mi("{\\psi^{\\prime}: U^{\\prime\\prime} \\times U^{\\prime\\prime} \\rightarrow K}")#text(", then ")#mi("{G}")#text(" is also isomorphic to a Lie group.")
]

#text("Note that the notion of smoothness of a (local) cocycle ")#mi("{\\psi: U^{\\prime} \\times U^{\\prime} \\rightarrow K}")#text(" makes sense, because there are smooth structures in place for both ")#mi("{H}")#text(" (and hence ")#mi("{U^{\\prime}}")#text(") and ")#mi("{K}")#text(". In contrast, one cannot initially talk about a smooth (local) section ")#mi("{\\phi: U \\rightarrow G}")#text(", because ")#mi("{G}")#text(" initially only has a topological structure and not a smooth one.")

#mi("\\Box")

#text("By hypothesis, we locally have ")#mi("{\\psi = \\psi^{\\prime} + df}")#text(" for some continuous gauge function ")#mi("{f: U^{\\prime\\prime\\prime} \\rightarrow K}")#text(". Rotating ")#mi("{\\phi}")#text(" by ")#mi("{f}")#text(", we thus obtain another local section ")#mi("{\\phi^{\\prime}: U^{\\prime\\prime\\prime\\prime} \\rightarrow G}")#text(" whose associated local cocycle is smooth. We use this section to identify ")#mi("{\\pi^{-1}(U^{(5)})}")#text(" as a topological space with ")#mi("{U^{(5)} \\times K}")#text(" for some sufficiently small neighbourhood ")#mi("{U^{(5)}}")#text(" of the origin. We can then give ")#mi("{\\pi^{-1}(U^{(5)})}")#text(" a smooth structure induced from the product smooth structure on ")#mi("{U^{(5)} \\times K}")#text(". By ")#link(<tao-8d7ec9aa29b87f7634b2>)[#text("(1)")]#text(", ")#link(<tao-f9fb0451ba0369d444c8>)[#text("(4)")]#text(" (and ")#link(<tao-135c4cf302528b452dba>)[#text("(3)")]#text("), we see that the group operations are smooth on a neighbourhood of the identity in ")#mi("{G}")#text(".")

#text("To finish the job and give ")#mi("{G}")#text(" the structure of a Lie group, we need to extend this smooth structure to the rest of ")#mi("{G}")#text(" in a manner which preserves the smooth nature of the group operations. Firstly, by using the local coordinates of ")#mi("{U^{(5)} \\times K}")#text(" we see that ")#mi("{G}")#text(" is locally connected. Thus, if ")#mi("{G^\\circ}")#text(" is the connected component of the identity, then the quotient group ")#mi("{G/G^\\circ}")#text(".")

#text("Now we use the same argument that we gave in the ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("post on von Neumann’s theorem")]#text(". Firstly, we extend the smooth structure on a neighbourhood of the identity on ")#mi("{G}")#text(" to the rest of ")#mi("{G}")#text(" by (say) left-invariance; it is easy to see that these smooth coordinate patches are compatible with each other. A continuity argument then shows that the group operations are smooth on ")#mi("{G^\\circ}")#text(". Each element ")#mi("{g}")#text(" of ")#mi("{G}")#text(" acts via conjugation by a continuous homomorphism ")#mi("{x \\mapsto gxg^{-1}}")#text(" on the Lie group ")#mi("{G^\\circ}")#text("; by applying Cartan’s theorem to the graph of this homomorphism as in the preceding post, we see that that such homomorphisms are smooth. From this we can then conclude that the group operations are smooth on all of ")#mi("{G}")#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Proof of theorem — ")]]

#text("Lemma ")#link(<tao-5d920e9810479476191a>)[#text("3")]#text(" suggests a strategy to prove Theorem ")#link(<tao-acd785249c11fdda9ea4>)[#text("1")]#text(": first, obtain a local section of ")#mi("{G}")#text(", extract the associated local cocycle, then “straighten” it to a smooth cocycle. This will indeed be how we proceed. In obtaining the local section and in smoothing the cocycle we will take advantage of the averaging argument, adapted to the Lie algebra setting.")

#text("We begin by constructing the section, following ")#link("http://www.ams.org/mathscinet-getitem?mr=33830")[#text("this paper of Gleason")]#text(". The idea is to use the zero set of a certain continuous function ")#mi("{F: G \\rightarrow V}")#text(" from ")#mi("{G}")#text(" into a finite-dimensional vector space ")#mi("{V}")#text(". We will use topological arguments to force this function to have a zero at every fibre, and will give ")#mi("{F}")#text(" some “vertical non-degeneracy” to prevent it from having more than one zero on any given fibre, at least locally.")

#text("Let’s see how this works in the special case when the abelian Lie group ")#mi("{K}")#text(" is compact, so that (by the Peter-Weyl theorem, as discussed in this post) it can be modeled as a closed subgroup of a unitary group ")#mi("{U(n)}")#text(", thus we have an injective continuous homomorphism ")#mi("{\\rho: K \\rightarrow U(n)}")#text(". We view ")#mi("{U(n)}")#text(" as a subset of the vector space ")#mi("{{\\bf C}^{n^2}}")#text(" of ")#mi("{n \\times n}")#text(" complex matrices.")

#text("The group ")#mi("{G}")#text(" is locally compact and also Hausdorff (being the extension of one Hausdorff group by another). Thus, we may then apply the (LCH version of the) ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(" (discussed on this blog ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("here")]#text("), and extend the map ")#mi("{\\rho: K \\rightarrow {\\bf C}^{n^2}}")#text(" to a continuous (and compactly supported) function ")#mi("{F_0: G \\rightarrow {\\bf C}^{n^2}}")#text(" defined on all of ")#mi("{G}")#text(".")

#text("Note that while the original map ")#mi("{\\rho}")#text(" was a homomorphism, thus ")#metadata(none) <tao-0bd236a80fe5ce59d9f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\rho(k + k^{\\prime}) = \\rho(k) \\rho(k^{\\prime})")]]

#text("for all ")#mi("{k,k^{\\prime} \\in K}")#text(", the extension ")#mi("{F_0}")#text(" need not obey any analogous symmetry in general. However, this can be rectified by an averaging argument. Define the function ")#mi("{F_1: G \\rightarrow {\\bf C}^{n^2}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("F_1(g) := \\int_K \\rho(k^{\\prime})^{-1} F_0(g+k^{\\prime})\\ d\\mu_K(k^{\\prime}),")]]

#text("where ")#mi("{\\mu_K}")#text(" is normalised Haar measure on ")#mi("{K}")#text(". Then ")#mi("{F_1}")#text(" is still continuous and still extends ")#mi("{\\rho}")#text("; but, unlike ")#mi("{F_0}")#text(", it now obeys the ")#emph[#text("equivariance")]#text(" property")

#align(center)[#tao-fit-display[#mitex("F_1(g+k) = \\rho(k) F_1(g)")]]

#text("for ")#mi("{g \\in G}")#text(" and ")#mi("{k \\in K}")#text(", as can easily be seen from ")#link(<tao-0bd236a80fe5ce59d9f3>)[#text("(5)")]#text(".")

#text("The function ")#mi("{F_1}")#text(" is a better extension than ")#mi("{F_0}")#text(", but suffers from another defect; while ")#mi("{\\rho}")#text(" took values in the closed group ")#mi("{\\rho(K)}")#text(", ")#mi("{F_1}")#text(" takes values in ")#mi("{{\\bf C}^{n^2}}")#text(" (for instance, ")#mi("{F_1}")#text(" is going to be compactly supported). There may well be global topological reasons that prevent ")#mi("{F_1}")#text(" from taking values in ")#mi("{\\rho(K)}")#text(" at all points, but as long as we are willing to work ")#emph[#text("locally")]#text(", we can repair this issue as follows. Using the inverse function theorem, one can find a manifold ")#mi("{W \\subset {\\bf C}^{n^2}}")#text(" going through the identity matrix ")#mi("{I}")#text(", which is transverse to ")#mi("{\\rho(K)}")#text(" in the sense that every matrix ")#mi("{M}")#text(" that is sufficiently close to the identity can be uniquely (and continuously) decomposed as ")#mi("{\\pi_1(M) \\pi_2(M)}")#text(", where ")#mi("{\\pi_1(M) \\in \\rho(K)}")#text(" and ")#mi("{\\pi_2(M) \\in W}")#text(". (Indeed, to build ")#mi("{W}")#text(", one can just use a complementary subspace to the tangent space (or Lie algebra) of ")#mi("{\\rho(K)}")#text(" at the identity.). For ")#mi("{g}")#text(" sufficiently close to the identity ")#mi("{1_G}")#text(", we may thus factor")

#align(center)[#tao-fit-display[#mitex("F_1(g) = F_2(g) F_3(g)")]]

#text("where ")#mi("{F_2(g) \\in \\rho(K)}")#text(" and ")#mi("{F_3(g) \\in W}")#text(". By construction, ")#mi("{F_2}")#text(" will be continuous and take values in ")#mi("{\\rho(K)}")#text(" near ")#mi("{1_G}")#text(", and equal ")#mi("{\\rho}")#text(" on ")#mi("{K}")#text(" near ")#mi("{1_G}")#text("; it will also obey the equivariance")

#align(center)[#tao-fit-display[#mitex("F_2(g+k) = \\rho(k) F_2(g)")]]

#text("for ")#mi("{g \\in G}")#text(" and ")#mi("{k \\in K}")#text(" that are sufficiently close to the identity. From this, we see that for each ")#mi("{h \\in H}")#text(" that is sufficiently close to the identity, there exists a unique solution ")#mi("{\\phi(h)}")#text(" in ")#mi("{\\pi^{-1}(h)}")#text(" to the equation ")#mi("{F_2(g) = I}")#text(" that is also close to the identity; from the continuity of ")#mi("{F_2}")#text(" we see that ")#mi("{\\phi}")#text(" is continuous near the identity and is thus a local section of ")#mi("{G}")#text(" as required.")

#text("Now we argue in the general case, in which the abelian Lie group ")#mi("{K}")#text(" need not be compact. If ")#mi("{K}")#text(" is connected, then it is isomorphic to a Euclidean space quotiented by a discrete subgroup. In particular, it can be quotiented down to a torus in a manner which is a local homeomorphism near the origin. Embedding that torus in a unitary group ")#mi("{U(n)}")#text(", we obtain an continuous homomorphism ")#mi("{\\rho: K \\rightarrow U(n)}")#text(" which is still ")#emph[#text("locally")]#text(" injective and has compact image. One can then repeat the previous arguments to obtain a local section; we omit the details.")

#text("Finally, if ")#mi("{K}")#text(" is not connected, we can work with the connected component ")#mi("{K^\\circ}")#text(" of the identity, which is locally the same as ")#mi("{K}")#text(", and repeat the previous argument again to obtain a local section.")

#text("Using this local section, we obtain a local cocycle ")#mi("{\\psi: U \\times U \\rightarrow K}")#text("; shifting by a constant, we may assume that ")#mi("{\\psi(1_H,1_H)=0}")#text(". Near the identity, the abelian Lie group ")#mi("{K}")#text(" can be locally identified with a Euclidean space ")#mi("{{\\bf R}^n}")#text(", so (shrinking ")#mi("{U}")#text(" if necessary) ")#mi("{\\psi}")#text(" induces a ")#mi("{{\\bf R}^n}")#text("-valued local cocycle ")#mi("{\\tilde \\psi: U \\times U \\rightarrow {\\bf R}^n}")#text(".")

#text("We will smooth this cocycle by an averaging argument akin to the one used in Lemma ")#link(<tao-bb9b481224ee5b7128ed>)[#text("2")]#text(". Instead of a discrete averaging, though, we will now use a non-trivial left-invariant Haar measure ")#mi("{\\mu_H}")#text(" on ")#mi("{H}")#text(" (the existence of which is guaranteed by a classical theorem of Weil). As we only have a local cocycle, though, we will need to only average using a smooth, compactly supported function ")#mi("{\\eta: H \\rightarrow {\\bf R}^+}")#text(" supported on a small neighbourhood ")#mi("{U^{\\prime}}")#text(" of ")#mi("{U}")#text(" (small enough that ")#mi("{(U^{\\prime})^3 \\subset U}")#text("), normalised so that ")#mi("{\\int_H \\eta(h_3)\\ d\\mu_H(h_3) = 1}")#text(". For any ")#mi("{h_1,h_2,h_3 \\in U^{\\prime}}")#text(", we have the cocycle equation")

#align(center)[#tao-fit-display[#mitex("\\tilde \\psi(h_1,h_2) + \\tilde \\psi(h_1h_2,h_3) = \\tilde \\psi(h_1,h_2 h_3) + \\tilde \\psi(h_2,h_3);")]]

#text("we average this against ")#mi("{\\eta(h_3)\\ d\\mu_H(h_3)}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\tilde \\psi(h_1,h_2) + F(h_1 h_2) = F(h_1) + F(h_2) + \\Psi(h_1,h_2)")]]

#text("for ")#mi("{h_1,h_2\\in U^{\\prime}}")#text(", where ")#mi("{F: (U^{\\prime})^2 \\rightarrow {\\bf R}^n}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("F(h) := \\int_H \\tilde \\psi(h,h_3) \\eta(h_3)\\ d\\mu_H(h_3)")]]

#text("and ")#mi("{\\Psi: U^{\\prime} \\times U^{\\prime} \\rightarrow {\\bf R}^n}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\Psi(h_1,h_2) := \\int_H (\\tilde \\psi(h_1,h_2 h_3) - \\tilde \\psi(h_1,h_3)) \\eta(h_3)\\ d\\mu_H(h_3).")]]

#text("The function ")#mi("{F}")#text(" is continuous, and so ")#mi("{\\tilde \\psi}")#text(" is locally cohomologous to ")#mi("{\\Psi}")#text(". Using the left-invariance of ")#mi("{\\mu_H}")#text(", we can rewrite ")#mi("{\\Psi}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\Psi(h_1,h_2) := \\int_H \\tilde \\psi(h_1,h_3) (\\eta(h_2^{-1} h_3) - \\eta(h_3))\\ d\\mu_H(h_3),")]]

#text("from which it becomes clear that ")#mi("{\\Psi}")#text(" is smooth in the ")#mi("{h_2}")#text(" variable. A similar averaging argument (now against a bump function on a right-invariant measure) then shows that ")#mi("{\\Psi}")#text(" is in turn locally cohomologous to another local cocycle ")#mi("{\\Psi^{\\prime}: U^{\\prime\\prime} \\times U^{\\prime\\prime} \\rightarrow {\\bf R}^n}")#text(" which is now smooth in both the ")#mi("{h_1}")#text(" and ")#mi("{h_2}")#text(" variables. Pulling ")#mi("{{\\bf R}^n}")#text(" back to ")#mi("{K}")#text(", we conclude that ")#mi("{\\psi}")#text(" is locally cohomologous to a smooth local cocycle, and Theorem ")#link(<tao-acd785249c11fdda9ea4>)[#text("1")]#text(" now follows from Lemma ")#link(<tao-5d920e9810479476191a>)[#text("3")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b969614ac837f7ac2e79c19069c6394596353daa034c32391d0f585eb6647ffb-03c1f9181bc7e7c77d77c765018c7b4a27079d9ef1d7dda6072497cc0c6d74c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter McNamara")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-53708")[#strong[#text("Peter McNamara")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2011")])]

#text("I think that what you are denoting as H^1 is customarily the second cohomology group H^2 in group cohomology.")

#text("PS. I noticed something odd: this post didn’t show up in Google reader.")

#text("(& typo: in section 1, “vertical group H” should be “vertical group K”)")

#emph[#text("[Gah! Corrected, thanks. (I’ve been working too much with extensions of dynamical systems, which are based on H^1 instead of H^2 cohomology, and got confused. I don’t know how to resolve the Google reader issue; the article shows up in the RSS feed, so the problem must lie elsewhere.) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-54022")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] In this post I would like to detail the final component to the proof of Theorem 2, namely Theorem 7. (I plan to discuss the other two steps, Theorem 5 and Theorem 6, in a separate post.) The strategy is similar to that used to prove von Neumann’s theorem, as discussed in this previous post (and von Neumann’s theorem is also used in the proof), but with the Gleason metric serving as a substitute for the faithful linear representation. Namely, one first gives the space of one-parameter subgroups of enough of a structure that it can serve as a proxy for the “Lie algebra” of ; specifically, it needs to be a vector space, and the “exponential map” needs to cover an open neighbourhood of the identity. This is enough to set up an “adjoint” representation of , whose image is a Lie group by von Neumann’s theorem; the kernel is essentially the centre of , which is abelian and can also be shown to be a Lie group by a similar analysis. To finish the job one needs to use arguments of Kuranishi and of Gleason, as discussed in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The C^{1,1} Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-54122")[#strong[#text("The C^{1,1} Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2011")])]

#text("[…] We will record the proof of Theorem 1 below the fold; it largely follows the classical derivation of the BCH formula, but due to the low regularity one will rely on tools such as telescoping series and Riemann sums rather than on the fundamental theorem of calculus. As an application of this theorem, we can give an alternate derivation of one of the components of the solution to Hilbert’s fifth problem, namely the construction of a Lie group structure from a Gleason metric, which was covered in the previous post; we discuss this at the end of this article. With this approach, one can avoid any appeal to von Neumann’s theorem and Cartan’s theorem (discussed in this post), or the Kuranishi-Gleason extension theorem (discussed in this post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Capri")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-56447")[#strong[#text("Capri")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")])]

#text("Quoting: The ability of algebraic structure (in this case, group structure) to upgrade weak regularity (in this case, continuous structure) to strong regularity (in this case, smooth and even analytic structure) seems to be a recurring theme in mathematics, and an important part of what I like to call the “dichotomy between structure and randomness”. (End quote.)")

#text("I tried following the post, but got lost. But I find this comment fascinating, yet mysterious. Can you give a more “elementary” example of this phenomenon (of upgrading weak regularity to strong using algebraic structure)? Also what is its connection to the dichotomy (between structure and randomness)? If it helps, I am from a CS background.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-56556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2011")])]

#text("The simplest example is probably Cauchy’s functional equation:")

#link("http://en.wikipedia.org/wiki/Cauchy%27s_functional_equation")[#text("http://en.wikipedia.org/wiki/Cauchy%27s_functional_equation")]

#text("Any solution to this equation that is merely continuous (or even measurable), is automatically smooth (and even analytic).")

#text("Regarding the connection to the dichotomy, this is an example of what I call “rigidity” in these slides: ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/icmslides2.pdf")[#text("http://www.math.ucla.edu/~tao/preprints/Slides/icmslides2.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Capri")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-56973")[#strong[#text("Capri")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2011")])]

#text("Terry, I didn’t expect an example so remarkably simple! And thanks for the pointer.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-476853")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2017")])]

#text("I don’t fully undersand the name “cocycle equation” for equation (2):")

#mi("\\displaystyle  \\psi(h_1,h_2) + \\psi(h_1 h_2,h_3) = \\psi(h_1,h_2 h_3) + \\psi(h_2,h_3)")

#text("According the post ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("Cohomology for dynamical systems")]#text(", the phrase that “")#mi("\\psi")#text(" is a cocycle” means that the coboundary of the function (cochain) ")#mi("\\psi")#text(" is 0. The coboundary of an 1-cochain ")#mi("\\rho: G\\times X\\to U")#text(" is")

#mi("\\delta \\rho(g,h,x) = \\rho(g,hx) - \\rho(gh,x) + \\rho(h,x)")

#text("With the replacement ")#mi("X\\to G")#text(",")#mi("\\rho \\to \\psi")#text(", ")#mi("g\\to h_1")#text(", ")#mi("h\\to h_2")#text(", ")#mi("x=h_3")#text(" we get the coboundary of ")#mi("\\psi")#text(":")

#mi("\\delta \\psi(h_1,h_2,h_3) = \\psi(h_1,h_2h_3) - \\psi(h_1h_2,h_3) + \\psi(h_2,h_3)")

#text(", so the cocycle condition would be")

#mi("\\psi(h_1h_2,h_3) = \\psi(h_1,h_2h_3) + \\psi(h_2,h_3)")#text(".")

#text("The term ")#mi("\\psi(h_1,h_2)")#text(" is not present here. So why is called the equation having this excess term a “cocycle condition”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-476880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2017")])]

#text("The cocycle here (in the sense of the previous blog post) is not an ")#mi("H")#text("-cocycle, but rather a ")#mi("G")#text("-cocycle. The fact that ")#mi("G")#text(" is not necessarily a direct product of ")#mi("G")#text(" with ")#mi("U")#text(" is what produces the additional ")#mi("\\psi(h_1,h_2)")#text(" correction.")

#text("In a bit more detail: a typical element of ")#mi("G")#text(" is of the form ")#mi("\\phi(h)+k")#text(" for some ")#mi("h \\in H")#text(", ")#mi("k \\in K")#text(". This acts on ")#mi("H \\times K")#text(" via left multiplication using the law (1); in the notation of the previous post, the relevant cocycle ")#mi("\\rho: G \\times H \\to U")#text(" is then given by")

#mi("\\rho( \\phi(h)+k, x ) = k + \\psi(h,x)")

#text("where the group action of ")#mi("G")#text(" on ")#mi("H")#text(" is given by projecting down to ")#mi("H")#text(":")

#mi("(\\phi(h)+k)x := hx.")

#text("The cocycle equation")

#mi("\\rho( (\\phi(h_1)+k_1)(\\phi(h_2)+k_2), x ) = \\rho( \\phi(h_1)+k_1, (\\phi(h_2)+k_2) x ) + \\rho( \\phi(h_2)+k_2, x )")

#text("from the previous post should then correspond to the cocycle equation")

#mi("\\psi(h_1,h_2) + \\psi(h_1 h_2, h_3) = \\psi(h_1, h_2 h_3) + \\psi(h_2, h_3)")

#text("from the current post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-476992")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("Oh, now I see, thanks! (however, I think that “")#mi("G")#text(" is not necessarily a direct product of ")#mi("G")#text(" with ")#mi("U")#text("” should be “")#mi("G")#text(" is not necessarily a direct product of ")#mi("H")#text(" with ")#mi("K")#text("“, and “the relevant cocycle ")#mi("\\rho: G \\times H \\to U")#text("” should be “the relevant cocycle ")#mi("\\rho: G \\times H \\to K")#text("“)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-477042")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("So, ")#mi("\\psi")#text(" isn’t really a cocycle in the sense of your previous blog post. But you call it cocycle so often, that I feel that is is a a real cocycle in some other sense it is. As far as I know, cocycles are cochains with zero coboundary, Is there any cochain complex that contains the ")#mi("\\psi")#text(" -s themselves as cocycles?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-476855")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2017")])]

#text("And the ")#mi("X\\to G")#text(" replacement is also a mistyping. Instead of this, The replacements are ")#mi("G\\to H")#text(", ")#mi("X\\to H")#text(" and ")#mi("U\\to K")#text(". correctly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f83f23213ededb7aa2bc284dbf0465f54577a13cbaea4e110db9c17ca082b24-ef19401bf55c63cfc5f648c0d26dd27652f838bd3be4e5d397d323eb7caa8f4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sundar")]], [#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/#comment-534421")[#strong[#text("Sundar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Dear Prof. Tao,")

#text("I really very much like the averaging trick to make a continuous cocycle cohomologous to a smooth one. I believe this will give a proof of the fact the cohomology defined using continuous cochains and smooth cochains are indeed isomorphic. It is also true that in some case, there is no difference between Moore’s cohomology using Borel cochains and continuous cohomology.")

#text("Is there a simple way to see that a Borel cocycle is cohomologous to a smooth one ?")
]
