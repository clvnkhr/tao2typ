// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/
// Converted to Typst by tao2typ: "2026-10-14T15:16:53.840240+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/")[#text("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the second of the ")#link("http://www.math.ucla.edu/dls/2009/stein.shtml")[#text("Distinguished Lecture Series")]#text(" given by ")#link("http://en.wikipedia.org/wiki/Elias_Stein")[#text("Eli Stein")]#text(" here at UCLA, Eli expanded on the themes in the ")#link("https://terrytao.wordpress.com/2008/10/22/distinguished-lecture-series-i-eli-stein-singular-integrals-and-several-complex-variables-some-new-perspectives/")[#text("first lecture")]#text(", in particular providing more details as to the recent (not yet published) results of ")#link("http://comp.uark.edu/~lanzani/")[#text("Lanzani ")]#text("and Stein on the boundedness of the Cauchy integral on domains in several complex variables.")

#metadata(none) <tao-59961079243d5917268f>

#text("Eli began by recalling how the classical Calderòn-Zygmund paradigm works for convolution operators ")#mi("T: f \\mapsto f*K")#text(" on Euclidean space ")#mi("{\\Bbb R}^d")#text(". The type of ")#link("http://en.wikipedia.org/wiki/Distribution_(mathematics)")[#text("distributional")]#text(" kernels K that this paradigm applies to can be described in one of three equivalent ways:")

#enum(start: 1, 
[#text("K is equal away from the origin to a smooth function ")#mi("K_0")#text(" that is a homogeneous symbol of order -d, in the sense that it obeys the bounds ")#tao-math("\\left|\\partial_x^\\alpha K(x)\\right| \\leq C_\\alpha \\left|x\\right|^{-d-\\alpha}", block: false)#text(" for all multi-indices ")#mi("\\alpha")#text(" and all non-zero x.")],
[#text("The (distributional) Fourier transform ")#mi("\\hat K = m")#text(" of K is equal to a homogeneous symbol of order 0, in the sense that it obeys the bounds ")#tao-math("\\left|\\partial_\\xi^\\alpha m(\\xi)\\right| \\leq C_\\alpha \\left|\\xi\\right|^{-\\alpha}", block: false)#text(" for all multi-indices ")#mi("\\alpha")#text(" and all non-zero ")#mi("\\xi")#text(".")],
[#text("There is a decomposition ")#mi("K = \\sum_{j=-\\infty}^\\infty \\phi_j")#text(" (with the sum converging in a distributional sense), where ")#mi("\\phi_j(x) := 2^{jd} \\phi^{(j)}(2^j x)")#text(" and the ")#mi("\\phi^{(j)}")#text(" are ")#link("http://en.wikipedia.org/wiki/Bump_function")[#text("bump functions")]#text(" with mean zero uniformly in j.")]
)

#text("[One can get by with less regularity in all of 1, 2, 3, and still get a reasonable theory, but the equivalences are no longer as clean.]")

#text("The fact that every kernel of the form 1. can be decomposed in the form 3. can be seen by dyadic decomposition of K, followed by a rebalancing to make all components mean zero (Eli referred to this as a “Ponzi scheme”, albeit one that converges rather than diverges); the converse implication is also straightforward. A similar Littlewood-Paley decomposition allows one to equate 2. and 3. With the formulation 2., it becomes clear that ")#mi("\\hat K")#text(" is bounded and so (by ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(") T is bounded on ")#mi("L^2")#text(". The Calderòn-Zygmund paradigm then uses this ")#mi("L^2")#text(" boundedness, and the kernel properties in 1., to obtain the weak-type (1,1) bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left| \\{ x \\in {\\Bbb R}^d: \\left|Tf(x)\\right| \\geq \\lambda \\}\\right| \\geq \\frac{C}{\\lambda} \\left\\|f\\right\\|_{L^1({\\Bbb R}^d)},", block: true)]]

#text("which by the ")#link("http://en.wikipedia.org/wiki/Interpolation_space")[#text("Marcinkiewicz interpolation theorem")]#text(" and duality gives ")#mi("L^p")#text(" boundedness for all ")#mi("1 < p < \\infty")#text(". The proof of the weak-type (1,1) bound is by now classical and was not discussed in detail in Eli’s lecture, though he did mention that a key step came from the fact that “cancellation implies localisation”: specifically, if f is absolutely integrable on some ball B and has mean zero, then f is mostly localised to the double ")#mi("B^*")#text(" of B in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\Bbb R}^d \\backslash B^*} |Tf(x)|\\ dx \\leq \\left\\|f\\right\\|_{L^1(B)}.", block: true)]]

#text("The proof of (1) then proceeds by decomposing an arbitrary ")#mi("L^1")#text(" function into localised mean zero functions to which the above bound can be usefully applied, plus an error which is in ")#mi("L^2")#text(" and can be treated by the ")#mi("L^2")#text(" boundedness theory.")

#text("Using the Fourier-analytic characterisation 2., one can easily show that the class of convolution operators of the above form is in fact a commutative ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(".")

#text("As mentioned in the previous lecture, the above theory can be carried over fairly easily to non-isotropic settings, such as that given by the ")#link("http://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]#text(". This group arises from the unit ball in ")#mi("{\\Bbb C}^n")#text(", which is holomorphically equivalent to the Siegel upper half-space")

#align(center)[#tao-fit-display[#tao-math("\\{ (z_1,\\ldots,z_n): \\text{Im}(z_n) \\geq \\left|z_1\\right|^2 + \\ldots + \\left|z_{n-1}\\right|^2 \\}.", block: true)]]

#text("The boundary of this domain can be parameterised (setting ")#mi("t:= \\text{Re}(z_n)")#text(") as the space ")#mi("\\{ (z,t): z \\in {\\Bbb C}^{n-1}, t \\in {\\Bbb R} \\}")#text(", with the group action ")#mi("(z,t) (z^{\\prime},t^{\\prime}) = (z+z^{\\prime},t+t^{\\prime}+2\\text{Im}(z\\overline{z^{\\prime}}))")#text(". This space is also equipped with a natural scaling ")#mi("(z,t) \\mapsto (\\delta z, \\delta^2 t)")#text(" consistent with the group action, as well as a norm ")#tao-math("\\left|(z,t)\\right|_H := \\left|z\\right| + \\left|t\\right|^{1/2}", block: false)#text(" consistent with the scaling, which in turn induces a left-invariant metric ")#tao-math("d_H(x,y) := \\left\\| y^{-1} x \\right\\|_H", block: false)#text(". There is also a Haar measure ")#mi("dx = dz dt")#text(" which is compatible with all these structures (giving rise, in particular, to a ")#emph[#text("space of homogeneous type")]#text("). It turns out that one can define a class of ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" operators ")#mi("T: f \\mapsto f*K")#text(" in this setting in complete analogy to the Euclidean case, using the above structures to replace the Euclidean ones (and with the homogeneous dimension ")#mi("2n")#text(" playing the role of the Euclidean dimension, and with the multi-index ")#mi("\\partial_z^\\alpha \\partial_t^\\beta")#text(" given the magnitude of ")#tao-math("\\left|\\alpha\\right|+2\\left|\\beta\\right|", block: false)#text(" rather than ")#tao-math("\\left|\\alpha\\right|+\\left|\\beta\\right|", block: false)#text("). The one new difficulty is that the Fourier-analytic description of the kernel (given by 2. above) is no longer available, and so the ")#mi("L^2")#text(" boundedness has to be established by other means. One way is to use the decomposition in 3., which splits T as the sum of the convolution operators ")#mi("T_j: f \\mapsto f * \\phi_j")#text(". Each ")#mi("T_j")#text(" is easily shown to be individually bounded on ")#mi("L^2")#text(", and the various smoothness and cancellation conditions present allows one to show that the operators ")#mi("T_k^* T_j")#text(" or ")#mi("T_j^* T_k")#text(" decay exponentially fast in ")#tao-math("\\left|j-k\\right|", block: false)#text(". Applying the Cotlar-Stein lemma (which I discussed in this ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("earlier blog post")]#text(") one obtains the ")#mi("L^2")#text(" boundedness.")

#text("A similar argument also establishes that the space of operators of this form a (non-commutative) algebra; the key point is that operators such as ")#mi("T_j T_k")#text(" behave very much like ")#tao-math("2^{-\\left|j-k\\right|} T_{\\max(j,k)}", block: false)#text(", as can be seen after computing kernels. (Unlike the situation with the algebra of ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(", the commutator of two operators here is ")#emph[#text("not")]#text(" of lower order; this can already be seen from scale-invariance considerations.)")

#text("Eli then turned to the ")#emph[#text("T(1) theorem")]#text(", which was the key technical tool needed to analyse the Cauchy integral on Lipschitz curves. A simplified version of this theorem in Euclidean spaces ")#mi("{\\Bbb R}^d")#text(" is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("T(1) Theorem (special case). ")]#text("Let T be a linear operator on ")#mi("{\\Bbb R}^d")#text(" with distributional kernel K, thus ")#mi("T f(x) = \\int_{{\\Bbb R}^d} K(x,y) f(y)")#text(". Suppose also that")

#list(
[#text("(Size and regularity) ")#tao-math("\\left|\\partial_x^\\alpha \\partial_y^\\beta K(x,y)\\right| \\leq C \\left|x-y\\right|^{-d-\\left|\\alpha\\right|-\\left|\\beta\\right|}", block: false)#text(" whenever ")#tao-math("\\left|\\alpha\\right|+\\left|\\beta\\right| \\leq 1", block: false)#text(".")],
[#text("(Cancellation) T(1)=0, and ")#tao-math("\\left\\|T \\phi_{R,x_0} \\right\\|_{L^2} \\leq C R^{d/2}", block: false)#text(" for all ")#mi("x_0 \\in {\\Bbb R}^d")#text(" and ")#mi("R > 0")#text(", where ")#mi("\\phi_{R,x_0}(x) = \\phi( (x-x_0)/R )")#text(".")],
[#text("(Adjoint cancellation) The above cancellation estimates also hold for the adjoint ")#mi("T^*")#text(" of T.")]
)

#text("Then T is bounded in ")#mi("L^2({\\Bbb R}^d)")#text(".")
]

#text("The condition T(1)=0 (and dually, ")#mi("T^*(1)=0")#text(") can be relaxed, but then this requires introducing the theory of paraproducts, and this turns out not to be necessary for the application to Cauchy integrals.")

#text("The proof of the T(1) theorem follows broadly similar lines to the previous arguments: one wants to split T into components ")#mi("T_j")#text(" to which one can apply the ")#link("http://en.wikipedia.org/wiki/Cotlar%E2%80%93Stein_lemma")[#text("Cotlar-Stein lemma")]#text(". In previous arguments, this decomposition was done by splitting the kernel K into dyadic pieces. This turns out to be difficult to accomplish in this setting, because it disrupts the delicate cancellation properties of T. Instead, it is easier to proceed by using Littlewood-Paley projections, for instance introducing the operators ")#mi("S_j f := f * \\Phi_j")#text(" and ")#mi("\\Delta_j := S_j - S_{j-1}")#text(" (these operators are also called ")#mi("P_{\\leq j}")#text(" and ")#mi("P_j")#text(" in the PDE literature), where ")#mi("\\Phi_j(x) = 2^{jd} \\Phi(2^j x)")#text(" and ")#mi("\\Phi")#text(" is a suitable bump function of total mass one. One has the telescoping series (or summation by parts) formula")

#align(center)[#tao-fit-display[#mitex("T = \\sum_{j=-\\infty}^\\infty \\Delta_j T S_j + S_{j-1} T \\Delta_j")]]

#text("and so it suffices to establish some almost orthogonality properties of the ")#mi("\\Delta_j T S_j")#text(" and ")#mi("S_{j-1} T \\Delta_j")#text(". But the identities ")#mi("\\Delta_j^* 1 = 0, S_j 1 = 1")#text(" and the hypothesis ")#mi("T(1)=0")#text(" show that we retain the cancellation conditions")

#align(center)[#tao-fit-display[#mitex("(\\Delta_j T S_j) 1 = 0; \\quad (\\Delta_j T S_j)^* 1 = 0,")]]

#text("and similarly for ")#mi("S_{j-1} T \\Delta_j")#text(". From this and further exploitation of the properties of T, it is not too difficult to establish enough almost orthogonality conditions that the Cotlar-Stein lemma can be applied to bound T.")

#text("Eli now turned to the Cauchy integral on domains ")#mi("\\Omega")#text(" in ")#mi("{\\Bbb C}^n")#text(". As mentioned in the previous lecture, there are many candidates for this operator; but in the case when ")#mi("\\Omega")#text(" is given by a defining function ")#mi("\\rho")#text(" (which means that ")#mi("\\Omega := \\{ w \\in {\\Bbb C}^n: \\rho(w) < 0 \\}")#text(" and ")#mi("\\nabla \\rho")#text(" is non-vanishing on the boundary of ")#mi("\\Omega")#text("), and that the domain is strongly ")#mi("{\\Bbb C}")#text("-linear (which means that the Hessian ")#mi("\\nabla^2 \\rho")#text(" is strictly positive definite on the complex tangent space ")#mi("T^{\\Bbb C}_p \\partial \\Omega")#text(" at any boundary point p), there is one particularly simple operator, the ")#emph[#text("Cauchy-Leray operator,")]#text(" which is the Cauchy-Fantappié operator")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C} f(z) := \\frac{1}{(2\\pi i)^n} \\int_{\\partial \\Omega} \\frac{G \\wedge \\bigwedge^{n-1} (\\overline{\\partial} G)}{\\Delta^n}\\ f(w)")]]

#text("with ")#mi("\\Delta(z,w) := \\langle G, z-w \\rangle")#text(" specialised to the case where ")#mi("G = \\partial \\rho = \\partial_{w_1} \\rho dw_1 + \\ldots + \\partial_{w_n} \\rho dw_n")#text(" is the complex gradient of the defining function ")#mi("\\rho")#text(". This operator, as presently defined, requires two derivatives of ")#mi("\\rho")#text(" on ")#mi("\\partial \\Omega")#text(" and so makes sense for ")#mi("C^2")#text(" functions ")#mi("\\rho")#text("; the strong ")#mi("{\\Bbb C}")#text("-linear condition ensures that ")#mi("\\Delta")#text(" does not vanish too often (locally, ")#mi("\\Delta")#text(" resembles the distance function on the Heisenberg group).")

#text("The first main theorem of Lanzani and Stein is that even when the defining function ")#mi("\\rho")#text(" is in the class ")#mi("C^{1,1}")#text(" (i.e. it is continuously differentiable, and its first derivatives are Lipschitz continuous), and the domain is strongly ")#mi("{\\Bbb C}")#text("-linear convex, then ")#mi("{\\mathcal C}")#text(" can still be defined, and is bounded on ")#mi("L^p({\\partial \\Omega})")#text(" for all ")#mi("1 < p < \\infty")#text(".")

#text("Before one can even begin establishing boundedness here, though, there is an even more fundamental problem, which is that the it is not clear that the operator ")#mi("{\\mathcal C}")#text(" even be ")#emph[#text("defined")]#text(", say for smooth compactly supported f. The problem is that if ")#mi("\\rho")#text(" is ")#mi("C^{1,1}")#text(", then G is merely Lipschitz continuous, which means (by the Radamacher differentiation theorem) that ")#mi("\\partial G")#text(" is merely an ")#mi("L^\\infty({\\Bbb C}^n)")#text(" function. But ")#mi("\\partial \\Omega")#text(" is a measure zero subset of ")#mi("{\\Bbb C}^n")#text(", and so there need not be a meaningful restriction of ")#mi("\\partial G")#text(" to ")#mi("\\partial \\Omega")#text(".")

#text("As a toy example of this phenomenon, let’s take ")#mi("\\Omega")#text(" to be the upper half-plane ")#mi("\\{ z: \\text{Im}(z) > 0 \\}")#text(" in the complex plane, and let G be the scalar function ")#tao-math("G(z) := \\left|\\text{Im}(z)\\right|", block: false)#text(". Then G is Lipschitz, but the vertical derivative ")#mi("\\partial_y G")#text(" of G, while being an ")#mi("L^\\infty({\\Bbb C})")#text(" function, is not defined at the boundary ")#mi("\\partial \\Omega")#text(" (i.e. the real axis). (This particular example can be evaded by restricting G to the upper half-plane, but the example ")#tao-math("G(z) := \\left|\\text{Im}(z)\\right|^{1+it}", block: false)#text(" for some real non-zero t shows that the problem can still persist there.) But observe that the ")#emph[#text("tangential")]#text(" derivative ")#mi("\\partial_y G")#text(" still makes sense on the boundary ")#mi("\\partial \\Omega")#text(". It turns out that this phenomenon is general; a Lipschitz function G on a (")#mi("C^{1,1}")#text(") domain ")#mi("\\Omega")#text(" in ")#mi("{\\Bbb C}^n")#text(" can have its tangential derivatives meaningfully restricted to ")#mi("\\partial \\Omega")#text(", in the sense that integrals such as ")#mi("\\int_{\\partial \\Omega} dG \\wedge \\omega")#text(" are well-defined for continuous 2n-2-forms ")#mi("\\omega")#text(". Similarly, if ")#mi("\\rho")#text(" is ")#mi("C^{1,1}")#text(", one can meaningfully define ")#mi("\\int_{\\partial \\Omega} \\overline{\\partial} \\partial \\rho \\wedge \\omega")#text(" for continuous 2n-3-forms ")#mi("\\omega")#text(". These facts are proven by carefully approximating the Lipschitz (resp. ")#mi("C^{1,1}")#text(") function by smooth functions; these smooth functions cannot converge in the Lipschitz (resp. ")#mi("C^{1,1}")#text(") topology (otherwise the limit would be ")#mi("C^1")#text(" (resp. ")#mi("C^2")#text(")), but it turns out that one can still obtain an approximation in which the tangential derivatives (resp. second derivatives) converge uniformly on ")#mi("\\partial \\Omega")#text(", which allows for a meaningful limit for these tangential derivatives on the boundary.")

#text("Using these facts, one can make sense of the Cauchy-Leray operator ")#mi("{\\mathcal C}")#text(" in the ")#mi("C^1")#text(" setting. It is convenient to introduce the ")#emph[#text("Leray measure")]#text(" ")#mi("d\\mu_\\rho")#text(" on the boundary ")#mi("\\partial \\Omega")#text(", defined by duality (i.e. the Riesz representation theorem) by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\partial \\Omega} f(\\omega)\\ d\\mu_\\rho(\\omega) := \\int_{\\partial \\Omega} f(\\omega) (\\partial \\rho) \\wedge \\bigwedge^{n-1} (\\overline{\\partial} \\partial \\rho)")]]

#text("for continuous compactly supported f. The previous discussion lets us establish that the above expression is a continuous linear functional on such f and so does indeed define a measure; the strong ")#mi("{\\Bbb C}")#text("-linear convexity can be used to show that this measure is positive (indeed, the ")#link("http://en.wikipedia.org/wiki/Radon-Nikodym_derivative")[#text("Radon-Nikodym derivative")]#text(" between the Leray measure and surface measure is essentially the derivative of the Levi matrix ")#mi("\\nabla^2 \\rho|_{T^{\\Bbb C} \\partial \\Omega}")#text("). With respect to this measure, the Cauchy-Leray operator becomes a singular integral whose kernel is basically ")#mi("1 / \\Delta^{n-1}")#text(". The key point here is that this kernel only involves ")#emph[#text("first")]#text(" derivatives of ")#mi("\\rho")#text(" and not second, and so has some regularity. In fact, using the strong ")#mi("{\\Bbb C}")#text("-linear convexity one can ensure that this kernel obeys all the required bounds for a suitable variant of the T(1) theorem (adapted to spaces of homogeneous type, following ")#link("http://www.ams.org/mathscinet-getitem?mr=447954")[#text("Coifman and Weiss")]#text("; one should think of the Heisenberg group as a model example of the type of geometry that is natural here) to obtain the ")#mi("L^2")#text(" and ")#mi("L^p")#text(" boundedness. The most difficult thing to check is the cancellation condition on ")#mi("{\\mathcal C}(1)")#text(". Here, one uses an additional “minor miracle” in higher dimensions which is not available in one complex variable, namely that the Cauchy-Leray kernel can be expressed as the derivative of a function with one higher order of homogeneity. (In one dimension, the Cauchy kernel ")#mi("1/z")#text(" is almost the derivative of ")#mi("\\log z")#text(", but there are issues with branch cuts and besides, ")#mi("\\log z")#text(" is not quite homogeneous of degree 0.) More explicitly, if we introduce the operator S on one-forms h defined by the formula")

#align(center)[#tao-fit-display[#mitex("Sh = \\int_{\\partial \\Omega} \\frac{ h(\\omega) \\wedge \\bigwedge^{n-1} (\\overline{\\partial} \\partial \\rho)}{\\Delta^{n-1}}")]]

#text("then one can show by an integrations by parts argument that ")#mi("{\\mathcal C} f")#text(" is basically ")#mi("S(df)")#text(" plus a lower order term which is easily dealt with. This makes ")#mi("{\\mathcal C}(1)")#text(" essentially zero, and allows one to go forward and apply the T(1) theorem to conclude.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathaaron")]], [#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/#comment-33254")[#strong[#text("mathaaron")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2008")])]

#text("Hi Prof. Tao,")#linebreak()#text(" I have a question. We know that the usual Littlewood-Paley theory decomposes the frequency space into dyadic pieces. What if we decompose the frequency space into arbitrary intervals which are still disjoint and countable, do we still have the Littlewood-Paley inequality ?")#linebreak()#text(" What is the benefit by dyadic decompsition ? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/#comment-33267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2008")])]

#text("Dear mathaaron,")

#text("For arbitrary decompositions into intervals we still have the upper inequality for ")#mi("p \\geq 2")#text(" (and hence the lower inequality for ")#mi("p \\leq 2")#text(", by duality); this was worked out by Rubio de Francia. The other inequalities are false though; see my paper with Michael Cowling on this point at")

#link("http://front.math.ucdavis.edu/math.CA/0011246")[#text("http://front.math.ucdavis.edu/math.CA/0011246")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/#comment-33273")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2008")])]

#text("Is there an easy example to see that the Hilbert Transform (or more general CZOs) do not satisfy any L^p -> L^q bounds for (p !=q). Of course, if you had such a bound, you could interpolate a whole range of L^p->L^q’ inequalities from it and the L^p -> L^p boundedness (so it doesn’t seem plausible), but I don’t see any easy counterexamples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hongjie")]], [#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/#comment-33284")[#strong[#text("Hongjie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2008")])]

#text("An easy example is to consider f_n(x)=n^{1/2}I_{(-1/n,1/n)}, n=1,2,…. You can see that the Hilbert transform is not bounded from, say, L^2 to L^3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/23/distinguished-lecture-series-ii-elias-stein-the-cauchy-integral-in-cn/#comment-33320")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2008")])]

#text("Dear anonymous,")

#text("One can also rule out ")#mi("(L^p, L^q)")#text(" bounds for ")#mi("p \\neq q")#text(" by dimensional analysis or scale invariance considerations, i.e. seeing what the scaling transformation ")#mi("f(x) \\mapsto f(\\lambda x)")#text(" does to the ")#mi("L^p")#text(" norm of f and the ")#mi("L^q")#text(" norm of Hf. Sending ")#mi("\\lambda \\to 0")#text(" or ")#mi("\\lambda \\to \\infty")#text(" will give an absurd result if p is not equal to q. (Of course, this is basically Hongjie’s example in disguise.)")

#text("There is also a general principle (due, I believe, to Littlewood) that any non-trivial translation-invariant operator cannot map a high exponent Lebesgue space to a low exponent one, which I discuss in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("Amplification, arbitrage, and the tensor power trick")]
]
]
