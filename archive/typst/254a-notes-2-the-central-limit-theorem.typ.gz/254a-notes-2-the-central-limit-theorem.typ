// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/
// Converted to Typst by tao2typ: "2026-10-14T08:52:26.703902+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 2: The central limit theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 2: The central limit theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Consider the sum ")#mi("{S_n := X_1+\\ldots+X_n}")#text(" of iid real random variables ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" of finite mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(" for some ")#mi("{\\sigma > 0}")#text(". Then the sum ")#mi("{S_n}")#text(" has mean ")#mi("{n\\mu}")#text(" and variance ")#mi("{n\\sigma^2}")#text(", and so (by Chebyshev’s inequality) we expect ")#mi("{S_n}")#text(" to usually have size ")#mi("{n\\mu + O(\\sqrt{n} \\sigma)}")#text(". To put it another way, if we consider the ")#emph[#text("normalised sum")]#text(" ")#metadata(none) <tao-733859c1fc6b9331793b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("Z_n := \\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}")]]

#text("then ")#mi("{Z_n}")#text(" has been normalised to have mean zero and variance ")#mi("{1}")#text(", and is thus usually of size ")#mi("{O(1)}")#text(".")

#text("In the ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("previous set of notes")]#text(", we were able to establish various tail bounds on ")#mi("{Z_n}")#text(". For instance, from Chebyshev’s inequality one has ")#metadata(none) <tao-2dfe50e4e2d62571816e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf P}(\\left|Z_n\\right| > \\lambda) \\leq \\lambda^{-2},", block: true)]]

#text("and if the original distribution ")#mi("{X}")#text(" was bounded or subgaussian, we had the much stronger ")#link("http://en.wikipedia.org/wiki/Chernoff_inequality")[#text("Chernoff bound")]#text(" ")#metadata(none) <tao-76f73c895b3f5ae270a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("{\\bf P}(\\left|Z_n\\right| > \\lambda) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text("; in other words, the ")#mi("{Z_n}")#text(" are uniformly subgaussian.")

#text("Now we look at the distribution of ")#mi("{Z_n}")#text(". The fundamental ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(" tells us the asymptotic behaviour of this distribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Central limit theorem)")]#text(" ")#metadata(none) <tao-667ae99a22d281e83efd>#text(" Let ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" be iid real random variables of finite mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(" for some ")#mi("{\\sigma > 0}")#text(", and let ")#mi("{Z_n}")#text(" be the normalised sum ")#link(<tao-733859c1fc6b9331793b>)[#text("(1)")]#text(". Then as ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{Z_n}")#text(" converges in distribution to the standard normal distribution ")#mi("{N(0,1)_{\\bf R}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that ")#mi("{Z_n}")#text(" does not converge in probability or in the almost sure sense. (")#emph[#text("Hint:")]#text(" the intuition here is that for two very different values ")#mi("{n_1 \\ll n_2}")#text(" of ")#mi("{n}")#text(", the quantities ")#mi("{Z_{n_1}}")#text(" and ")#mi("{Z_{n_2}}")#text(" are almost independent of each other, since the bulk of the sum ")#mi("{S_{n_2}}")#text(" is determined by those ")#mi("{X_n}")#text(" with ")#mi("{n > n_1}")#text(". Now make this intuition precise.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-65ea5c55a9c3c88d87c7>#text(" Use Stirling’s formula from ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Notes 0a")]#text(" to verify the central limit theorem in the case when ")#mi("{X}")#text(" is a Bernoulli distribution, taking the values ")#mi("{0}")#text(" and ")#mi("{1}")#text(" only. (This is a variant of Exercise 2 from those notes, or Exercise 2 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(". It is easy to see that once one does this, one can rescale and handle any other two-valued distribution also.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Use Exercise 9 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(" to verify the central limit theorem in the case when ")#mi("{X}")#text(" is gaussian.")
]

#text("Note we are only discussing the case of real iid random variables. The case of complex random variables (or more generally, vector-valued random variables) is a little bit more complicated, and will be discussed later in this post.")

#text("The central limit theorem (and its variants, which we discuss below) are extremely useful tools in random matrix theory, in particular through the control they give on random walks (which arise naturally from linear functionals of random matrices). But the central limit theorem can also be viewed as a “commutative” analogue of various spectral results in random matrix theory (in particular, we shall see in later lectures that the ")#emph[#text("Wigner semicircle law")]#text(" can be viewed in some sense as a “noncommutative” or “free” version of the central limit theorem). Because of this, the ")#emph[#text("techniques")]#text(" used to prove the central limit theorem can often be adapted to be useful in random matrix theory. Because of this, we shall use these notes to dwell on several different proofs of the central limit theorem, as this provides a convenient way to showcase some of the basic methods that we will encounter again (in a more sophisticated form) when dealing with random matrices.")

#metadata(none) <tao-14283f60bc45ba88300f>

#heading(level: 1)[#strong[#text(" — 1. Reductions — ")]]

#text("We first record some simple reductions one can make regarding the proof of the central limit theorem. Firstly, we observe ")#emph[#text("scale invariance")]#text(": if the central limit theorem holds for one random variable ")#mi("{X}")#text(", then it is easy to see that it also holds for ")#mi("{aX+b}")#text(" for any real ")#mi("{a, b}")#text(" with ")#mi("{a \\neq 0}")#text(". Because of this, one can ")#emph[#text("normalise")]#text(" to the case when ")#mi("{X}")#text(" has mean ")#mi("{\\mu=0}")#text(" and variance ")#mi("{\\sigma^2 = 1}")#text(", in which case ")#mi("{Z_n}")#text(" simplifies to ")#metadata(none) <tao-4f240c3fce857e766bc5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("Z_n = \\frac{X_1 + \\ldots + X_n}{\\sqrt{n}}.")]]

#text("The other reduction we can make is ")#emph[#text("truncation")]#text(": to prove the central limit theorem for arbitrary random variables ")#mi("{X}")#text(" of finite mean and variance, it suffices to verify the theorem for ")#emph[#text("bounded")]#text(" random variables. To see this, we first need a basic linearity principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Linearity of convergence)")]#text(" ")#metadata(none) <tao-37382dc7d7573d3ea960>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional real or complex vector space, ")#mi("{X_n, Y_n}")#text(" be sequences of ")#mi("{V}")#text("-valued random variables (not necessarily independent), and let ")#mi("{X, Y}")#text(" be another pair of ")#mi("{V}")#text("-valued random variables. Let ")#mi("{c_n, d_n}")#text(" be scalars converging to ")#mi("{c, d}")#text(" respectively.")

#list(
[#text("If ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", and ")#mi("{Y_n}")#text(" converges in distribution to ")#mi("{Y}")#text(", and at least one of ")#mi("{X, Y}")#text(" is deterministic, show that ")#mi("{c_n X_n+d_n Y_n}")#text(" converges in distribution to ")#mi("{c X+d Y}")#text(".")],
[#text("If ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(", and ")#mi("{Y_n}")#text(" converges in probability to ")#mi("{Y}")#text(", show that ")#mi("{c_n X_n+d_n Y_n}")#text(" converges in probability to ")#mi("{c X+ dY}")#text(".")],
[#text("If ")#mi("{X_n}")#text(" converges almost surely to ")#mi("{X}")#text(", and ")#mi("{Y_n}")#text(" converges almost surely ")#mi("{Y}")#text(", show that ")#mi("{c_n X_n+d_n Y_n}")#text(" converges almost surely to ")#mi("{cX+dY}")#text(".")]
)

#text("Show that the first part of the exercise can fail if ")#mi("{X, Y}")#text(" are not deterministic.")
]

#text("Now suppose that we have established the central limit theorem for bounded random variables, and want to extend to the unbounded case. Let ")#mi("{X}")#text(" be an unbounded random variable, which we can normalise to have mean zero and unit variance. Let ")#mi("{N = N_n > 0}")#text(" be a truncation parameter depending on ")#mi("{n}")#text(" which, as usual, we shall optimise later, and split ")#mi("{X = X_{\\leq N} + X_{>N}}")#text(" in the usual fashion (")#tao-math("{X_{\\leq N} = X {\\bf I}(\\left|X\\right| \\leq N)}", block: false)#text("; ")#tao-math("{X_{>N} = X {\\bf I}(\\left|X\\right| > N)}", block: false)#text("). Thus we have ")#mi("{S_n = S_{n,\\leq N} + S_{n,>N}}")#text(" as usual.")

#text("Let ")#mi("{\\mu_{\\leq N}, \\sigma_{\\leq N}^2}")#text(" be the mean and variance of the bounded random variable ")#mi("{X_{\\leq N}}")#text(". As we are assuming that the central limit theorem is already true in the bounded case, we know that if we fix ")#mi("{N}")#text(" to be independent of ")#mi("{n}")#text(", then")

#align(center)[#tao-fit-display[#mitex("Z_{n,\\leq N} := \\frac{S_{n,\\leq N} - n \\mu_{\\leq N}}{\\sqrt{n} \\sigma_{\\leq N}}")]]

#text("converges in distribution to ")#mi("{N(0,1)_{\\bf R}}")#text(". By a diagonalisation argument, we conclude that there exists a sequence ")#mi("{N_n}")#text(" going (slowly) to infinity with ")#mi("{n}")#text(", such that ")#mi("{Z_{n,\\leq N_n}}")#text(" still converges in distribution to ")#mi("{N(0,1)_{\\bf R}}")#text(".")

#text("For such a sequence, we see from dominated convergence that ")#mi("{\\sigma_{\\leq N_n}}")#text(" converges to ")#mi("{\\sigma = 1}")#text(". As a consequence of this and Exercise ")#link(<tao-37382dc7d7573d3ea960>)[#text("5")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{S_{n,\\leq N_n} - n \\mu_{\\leq N_n}}{\\sqrt{n}}")]]

#text("converges in distribution to ")#mi("{N(0,1)_{\\bf R}}")#text(".")

#text("Meanwhile, from dominated convergence again, ")#mi("{\\sigma_{>N_n}}")#text(" converges to ")#mi("{0}")#text(". From this and ")#link(<tao-2dfe50e4e2d62571816e>)[#text("(2)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{S_{n,>N_n} - n \\mu_{>N_n}}{\\sqrt{n}}")]]

#text("converges in distribution to ")#mi("{0}")#text(". Finally, from linearity of expectation we have ")#mi("{\\mu_{\\leq N_n} + \\mu_{>N_n} = \\mu = 0}")#text(". Summing (using Exercise ")#link(<tao-37382dc7d7573d3ea960>)[#text("5")]#text("), we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The truncation reduction is not needed for some proofs of the central limit theorem (notably the Fourier-analytic proof), but is very convenient for some of the other proofs that we will give here, and will also be used at several places in later notes.")
]

#text("By applying the scaling reduction after the truncation reduction, we observe that to prove the central limit theorem, it suffices to do so for random variables ")#mi("{X}")#text(" which are bounded ")#emph[#text("and")]#text(" which have mean zero and unit variance. (Why is it important to perform the reductions in this order?)")

#heading(level: 1)[#strong[#text(" — 2. The Fourier method — ")]]

#text("Let us now give the standard Fourier-analytic proof of the central limit theorem. Given any real random variable ")#mi("{X}")#text(", we introduce the ")#emph[#text("characteristic function")]#text(" ")#mi("{F_X: {\\bf R} \\rightarrow {\\bf C}}")#text(", defined by the formula ")#metadata(none) <tao-ec222e8a5c1f4e1867c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("F_X(t) := {\\bf E} e^{itX}.")]]

#text("Equivalently, ")#mi("{F_X}")#text(" is the Fourier transform of the probability measure ")#mi("{\\mu_X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" The signed Bernoulli distribution has characteristic function ")#mi("{F(t) = \\cos(t)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-1d359c60ec04e10677d7>#text(" Show that the normal distribution ")#mi("{N(\\mu,\\sigma^2)_{\\bf R}}")#text(" has characteristic function ")#mi("{F(t) = e^{it\\mu} e^{-\\sigma^2 t^2/2}}")#text(".")
]

#text("More generally, for a random variable ")#mi("{X}")#text(" taking values in a real vector space ")#mi("{{\\bf R}^d}")#text(", we define the characteristic function ")#mi("{F_X: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" by ")#metadata(none) <tao-5de7a16d0673dfc37ab5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("F_X(t) := {\\bf E} e^{it\\cdot X}")]]

#text("where ")#mi("{\\cdot}")#text(" denotes the Euclidean inner product on ")#mi("{{\\bf R}^d}")#text(". One can similarly define the characteristic function on complex vector spaces ")#mi("{{\\bf C}^d}")#text(" by using the complex inner product")

#align(center)[#tao-fit-display[#mitex("(z_1,\\ldots,z_d) \\cdot (w_1,\\ldots,w_d) := \\text{Re}(z_1 \\overline{w_1} + \\ldots + z_d \\overline{w_d})")]]

#text("(or equivalently, by identifying ")#mi("{{\\bf C}^d}")#text(" with ")#mi("{{\\bf R}^{2d}}")#text(" in the usual manner.)")

#text("More generally, one can define the characteristic function on any finite dimensional real or complex vector space ")#mi("{V}")#text(", by identifying ")#mi("{V}")#text(" with ")#mi("{{\\bf R}^d}")#text(" or ")#mi("{{\\bf C}^d}")#text(". (Strictly speaking, one either has to select an inner product on ")#mi("{V}")#text(" to do this, or else make the characteristic function defined on the ")#emph[#text("dual space")]#text(" ")#mi("{V^*}")#text(" instead of on ")#mi("{V}")#text(" itself; see for instance ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("my notes on the Fourier transform")]#text(" in general locally compact abelian groups. But we will not need to care about this subtlety in our applications.)")

#text("The characteristic function is clearly bounded in magnitude by ")#mi("{1}")#text(", and equals ")#mi("{1}")#text(" at the origin. By the Lebesgue dominated convergence theorem, ")#mi("{F_X}")#text(" is continuous in ")#mi("{t}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Riemann-Lebesgue lemma)")]#text(" Show that if ")#mi("{X}")#text(" is an absolutely continuous random variable taking values in ")#mi("{{\\bf R}^d}")#text(" or ")#mi("{{\\bf C}^d}")#text(", then ")#mi("{F_X(t) \\rightarrow 0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(". Show that the claim can fail when the absolute continuity hypothesis is dropped.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that the characteristic function ")#mi("{F_X}")#text(" of a random variable ")#mi("{X}")#text(" taking values in ")#mi("{{\\bf R}^d}")#text(" or ")#mi("{{\\bf C}^d}")#text(" is in fact ")#link("http://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text(" on its domain.")
]

#text("Let ")#mi("{X}")#text(" be a real random variable. If we Taylor expand ")#mi("{e^{itX}}")#text(" and formally interchange the series and expectation, we arrive at the heuristic identity ")#metadata(none) <tao-bcbb0eeac8d6a4240d57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("F_X(t) = \\sum_{k=0}^\\infty \\frac{(it)^k}{k!} {\\bf E} X^k")]]

#text("which thus interprets the characteristic function of a real random variable ")#mi("{X}")#text(" as a kind of generating function for the moments. One rigorous version of this identity is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Taylor expansion of characteristic function)")]#text(" ")#metadata(none) <tao-9d4c90764c2da7f5a69d>#text(" Let ")#mi("{X}")#text(" be a real random variable with finite ")#mi("{k^{th}}")#text(" moment for some ")#mi("{k \\geq 1}")#text(". Show that ")#mi("{F_X}")#text(" is ")#mi("{k}")#text(" times continuously differentiable, and one has the partial Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("F_X(t) = \\sum_{j=0}^k \\frac{(it)^j}{j!} {\\bf E} X^j + o( \\left|t\\right|^k )", block: true)]]

#text("where ")#tao-math("{o(\\left|t\\right|^k)}", block: false)#text(" is a quantity that goes to zero as ")#mi("{t \\rightarrow 0}")#text(", times ")#tao-math("{\\left|t\\right|^k}", block: false)#text(". In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d^j}{dt^j} F_X(t) = i^j {\\bf E} X^j")]]

#text("for all ")#mi("{0 \\leq j \\leq k}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-633ac296aa882e8a15dd>#text(" Establish ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text(" in the case that ")#mi("{X}")#text(" is subgaussian, and show that the series converges locally uniformly in ")#mi("{t}")#text(".")
]

#text("Note that the characteristic function depends only on the distribution of ")#mi("{X}")#text(": if ")#mi("{X \\equiv Y}")#text(", then ")#mi("{F_X = F_Y}")#text(". The converse statement is true also: if ")#mi("{F_X=F_Y}")#text(", then ")#mi("{X \\equiv Y}")#text(". This follows from a more general (and useful) fact, known as ")#link("http://en.wikipedia.org/wiki/L%C3%A9vy%27s_continuity_theorem")[#text("Lévy’s continuity theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Lévy continuity theorem, special case)")]#text(" ")#metadata(none) <tao-5a1a84de8c2ec09ba6b5>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional real or complex vector space, and let ")#mi("{X_n}")#text(" be a sequence of ")#mi("{V}")#text("-valued random variables, and let ")#mi("{X}")#text(" be an additional ")#mi("{V}")#text("-valued random variable. Then the following statements are equivalent:")

#list(
[#text("(i) ")#mi("{F_{X_n}}")#text(" converges pointwise to ")#mi("{F_X}")#text(".")],
[#text("(ii) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Without loss of generality we may take ")#mi("{V = {\\bf R}^d}")#text(".")

#text("The implication of (i) from (ii) is immediate from ")#link(<tao-5de7a16d0673dfc37ab5>)[#text("(6)")]#text(" and the definition of convergence in distribution (see Definition 10 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text("), since the function ")#mi("{x \\mapsto e^{it \\cdot x}}")#text(" is bounded continuous.")

#text("Now suppose that (i) holds, and we wish to show that (ii) holds. By Exercise 23(iv) of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(X_n) \\rightarrow {\\bf E} \\varphi(X)")]]

#text("whenever ")#mi("{\\varphi: V \\rightarrow {\\bf R}}")#text(" is a continuous, compactly supported function. By approximating ")#mi("{\\varphi}")#text(" uniformly by ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz functions")]#text(" (e.g. using the ")#link("http://en.wikipedia.org/wiki/Stone-Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text("), it suffices to show this for Schwartz functions ")#mi("{\\varphi}")#text(". But then we have the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("\\varphi(X_n) = \\int_{{\\bf R}^d} \\hat \\varphi(t) e^{it \\cdot X_n}\\ dt")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\hat \\varphi(t) := \\frac{1}{(2\\pi)^d} \\int_{{\\bf R}^d} \\varphi(x) e^{-it \\cdot x}\\ dx")]]

#text("is a Schwartz function, and is in particular absolutely integrable (see e.g. these ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("lecture notes of mine")]#text("). From the Fubini-Tonelli theorem, we thus have ")#metadata(none) <tao-e215f82eb7d66a8ea261>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\bf E} \\varphi(X_n) = \\int_{{\\bf R}^d} \\hat \\varphi(t) F_{X_n}(t)\\ dt")]]

#text("and similarly for ")#mi("{X}")#text(". The claim now follows from the Lebesgue dominated convergence theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" ")#metadata(none) <tao-6f482b0b6604c69c6a3c>#text(" Setting ")#mi("{X_n := Y}")#text(" for all ")#mi("{n}")#text(", we see in particular the previous claim that ")#mi("{F_X = F_Y}")#text(" if and only if ")#mi("{X \\equiv Y}")#text(". It is instructive to use the above proof as a guide to prove this claim directly.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Lévy’s continuity theorem, full version)")]#text(" Let ")#mi("{V}")#text(" be a finite-dimensional real or complex vector space, and let ")#mi("{X_n}")#text(" be a sequence of ")#mi("{V}")#text("-valued random variables. Suppose that ")#mi("{F_{X_n}}")#text(" converges pointwise to a limit ")#mi("{F}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{F}")#text(" is continuous at ")#mi("{0}")#text(".")],
[#text("(ii) ")#mi("{X_n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight")]#text(" sequence.")],
[#text("(iii) ")#mi("{F}")#text(" is the characteristic function of a ")#mi("{V}")#text("-valued random variable ")#mi("{X}")#text(" (possibly after extending the sample space).")],
[#text("(iv) ")#mi("{X_n}")#text(" converges in distribution to some ")#mi("{V}")#text("-valued random variable ")#mi("{X}")#text(" (possibly after extending the sample space).")]
)

#emph[#text("Hint")]#text(": To get from (ii) to the other conclusions, use ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(" and Theorem ")#link(<tao-5a1a84de8c2ec09ba6b5>)[#text("13")]#text(". To get back to (ii) from (i), use ")#link(<tao-e215f82eb7d66a8ea261>)[#text("(8)")]#text(" for a suitable Schwartz function ")#mi("{\\varphi}")#text(". The other implications are easy once Theorem ")#link(<tao-5a1a84de8c2ec09ba6b5>)[#text("13")]#text(" is in hand.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" Lévy’s continuity theorem is very similar in spirit to ")#link("http://en.wikipedia.org/wiki/Weyl%27s_criterion")[#text("Weyl’s criterion")]#text(" in equidistribution theory.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Esséen concentration inequality)")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in ")#mi("{{\\bf R}^d}")#text(". Then for any ")#mi("{r>0}")#text(", ")#mi("{\\varepsilon > 0}")#text(", show that ")#metadata(none) <tao-5b0435f03790e0fa682d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\sup_{x_0 \\in {\\bf R}^d} {\\bf P}( \\left|X - x_0\\right| \\leq r ) \\leq C_{d,\\varepsilon} r^d \\int_{t \\in {\\bf R}^d: \\left|t\\right| \\leq \\varepsilon/r} |F_X(t)|\\ dt", block: true)]]

#text("for some constant ")#mi("{C_{d,\\varepsilon}}")#text(" depending only on ")#mi("{d}")#text(" and ")#mi("{\\varepsilon}")#text(". (")#emph[#text("Hint:")]#text(" Use ")#link(<tao-e215f82eb7d66a8ea261>)[#text("(8)")]#text(" for a suitable Schwartz function ")#mi("{\\varphi}")#text(".) The left-hand side of ")#link(<tao-5b0435f03790e0fa682d>)[#text("(9)")]#text(" is known as the ")#emph[#text("small ball probability")]#text(" of ")#mi("{X}")#text(" at radius ")#mi("{r}")#text(".")
]

#text("In Fourier analysis, we learn that the Fourier transform is a particularly well-suited tool for studying convolutions. The probability theory analogue of this fact is that characteristic functions are a particularly well-suited tool for studying sums of independent random variables. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Fourier identities)")]#text(" ")#metadata(none) <tao-2e1712f7908f611efbf8>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional real or complex vector space, and let ")#mi("{X, Y}")#text(" be independent random variables taking values in ")#mi("{V}")#text(". Then ")#metadata(none) <tao-8bda670c0fd677f51186>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("F_{X+Y}(t) = F_X(t) F_Y(t)")]]

#text("for all ")#mi("{t \\in V}")#text(". Also, for any scalar ")#mi("{c}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F_{cX}(t) = F_X(\\overline{c}t)")]]

#text("and more generally, for any linear transformation ")#mi("{T: V \\rightarrow V}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F_{TX}(t) = F_X(T^*t).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" Note that this identity ")#link(<tao-8bda670c0fd677f51186>)[#text("(10)")]#text(", combined with Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("8")]#text(" and Remark ")#link(<tao-6f482b0b6604c69c6a3c>)[#text("14")]#text(", gives a quick alternate proof of Exercise 9 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(".")
]

#text("In particular, in the normalised setting ")#link(<tao-4f240c3fce857e766bc5>)[#text("(4)")]#text(", we have the simple relationship ")#metadata(none) <tao-8b5b14c53b1345927e8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("F_{Z_n}(t) = F_X( t / \\sqrt{n} )^n")]]

#text("that describes the characteristic function of ")#mi("{Z_n}")#text(" in terms of that of ")#mi("{X}")#text(".")

#text("We now have enough machinery to give a quick proof of the central limit theorem:")

#emph[#text("Proof:")]#text(" (Proof of Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("1")]#text(") We may normalise ")#mi("{X}")#text(" to have mean zero and variance ")#mi("{1}")#text(". By Exercise ")#link(<tao-9d4c90764c2da7f5a69d>)[#text("11")]#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("F_X(t) = 1 - t^2/2 + o(\\left|t\\right|^2)", block: true)]]

#text("for sufficiently small ")#mi("{t}")#text(", or equivalently")

#align(center)[#tao-fit-display[#tao-math("F_X(t) = \\exp( - t^2/2 + o(\\left|t\\right|^2) )", block: true)]]

#text("for sufficiently small ")#mi("{t}")#text(". Applying ")#link(<tao-8b5b14c53b1345927e8a>)[#text("(11)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("F_{Z_n}(t) \\rightarrow \\exp( - t^2/2 )")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{t}")#text(". But by Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("8")]#text(", ")#mi("{\\exp(-t^2/2)}")#text(" is the characteristic function of the normal distribution ")#mi("{N(0,1)_{\\bf R}}")#text(". The claim now follows from the Lévy continuity theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Vector-valued central limit theorem)")]#text(" Let ")#mi("{\\vec X=(X_1,\\ldots,X_d)}")#text(" be a random variable taking values in ")#mi("{{\\bf R}^d}")#text(" with finite second moment. Define the ")#link("http://en.wikipedia.org/wiki/Covariance_matrix")[#text("covariance matrix")]#text(" ")#mi("{\\Sigma(\\vec X)}")#text(" to be the ")#mi("{d \\times d}")#text(" matrix ")#mi("{\\Sigma}")#text(" whose ")#mi("{ij^{th}}")#text(" entry is the covariance ")#mi("{{\\bf E} (X_i - {\\bf E}(X_i)) (X_j - {\\bf E}(X_j))}")#text(".")

#list(
[#text("Show that the covariance matrix is positive semi-definite real symmetric.")],
[#text("Conversely, given any positive definite real symmetric ")#mi("{d \\times d}")#text(" matrix ")#mi("{\\Sigma}")#text(" and ")#mi("{\\mu \\in {\\bf R}^d}")#text(", show that the ")#emph[#text("normal distribution")]#text(" ")#mi("{N(\\mu,\\Sigma)_{{\\bf R}^d}}")#text(", given by the absolutely continuous measure")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{((2\\pi)^d \\det \\Sigma)^{1/2}} e^{- (x-\\mu) \\cdot \\Sigma^{-1} (x-\\mu) / 2}\\ dx,")]]

#text("has mean ")#mi("{\\mu}")#text(" and covariance matrix ")#mi("{\\sigma}")#text(", and has a characteristic function given by")

#align(center)[#tao-fit-display[#mitex("F(t) = e^{i \\mu \\cdot t} e^{- t \\cdot \\Sigma t / 2}.")]]

#text("How would one define the normal distribution ")#mi("{N(\\mu,\\Sigma)_{{\\bf R}^d}}")#text(" if ")#mi("{\\Sigma}")#text(" degenerated to be merely positive semi-definite instead of positive definite?")],
[#text("If ")#mi("{\\vec S_n := \\vec X_1+\\ldots + \\vec X_n}")#text(" is the sum of ")#mi("{n}")#text(" iid copies of ")#mi("{\\vec X}")#text(", show that ")#mi("{\\frac{\\vec S_n - n \\mu}{\\sqrt{n}}}")#text(" converges in distribution to ")#mi("{N(0,\\Sigma(X))_{{\\bf R}^d}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Complex central limit theorem)")]#text(" Let ")#mi("{X}")#text(" be a complex random variable of mean ")#mi("{\\mu \\in {\\bf C}}")#text(", whose real and imaginary parts have variance ")#mi("{\\sigma^2/2}")#text(" and covariance ")#mi("{0}")#text(". Let ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" be iid copies of ")#mi("{X}")#text(". Show that as ")#mi("{n \\rightarrow \\infty}")#text(", the normalised sums ")#link(<tao-733859c1fc6b9331793b>)[#text("(1)")]#text(" converge in distribution to the standard complex gaussian ")#mi("{N(0,1)_{\\bf C}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Lindeberg central limit theorem)")]#text(" Let ")#mi("{X_1,X_2,\\ldots}")#text(" be a sequence of independent (but not necessarily identically distributed) real random variables, normalised to have mean zero and variance one. Assume the (strong) ")#link("http://en.wikipedia.org/wiki/Lindeberg_condition")[#text("Lindeberg condition")]

#align(center)[#tao-fit-display[#tao-math("\\lim_{N \\rightarrow \\infty} \\limsup_{n \\rightarrow \\infty} \\frac{1}{n} \\sum_{j=1}^n {\\bf E} \\left|X_{j,>N}\\right|^2 = 0", block: true)]]

#text("where ")#tao-math("{X_{j,>N} := X_j {\\bf I}(\\left|X_j\\right| > N)}", block: false)#text(" is the truncation of ")#mi("{X_j}")#text(" to large values. Show that as ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\frac{X_1+\\ldots+X_n}{\\sqrt{n}}}")#text(" converges in distribution to ")#mi("{N(0,1)_{\\bf R}}")#text(". (")#emph[#text("Hint")]#text(": modify the truncation argument.)")
]

#text("A more sophisticated version of the Fourier-analytic method gives a more quantitative form of the central limit theorem, namely the ")#link("http://en.wikipedia.org/wiki/Berry%E2%80%93Esseen_theorem")[#text("Berry-Esséen theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 23 (Berry-Esséen theorem)")]#text(" ")#metadata(none) <tao-be5fe2ee6cf8d5a95850>#text(" Let ")#mi("{X}")#text(" have mean zero, unit variance, and finite third moment. Let ")#mi("{Z_n := (X_1+\\ldots+X_n)/\\sqrt{n}}")#text(", where ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(". Then we have ")#metadata(none) <tao-c674406e16ee30cbd392>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\bf P}( Z_n < a ) = {\\bf P}( G < a ) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3))", block: true)]]

#text("uniformly for all ")#mi("{a \\in {\\bf R}}")#text(", where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(", and the implied constant is absolute.")
]

#emph[#text("Proof:")]#text(" (Optional) Write ")#tao-math("{\\varepsilon := {\\bf E} \\left|X\\right|^3/\\sqrt{n}}", block: false)#text("; our task is to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( Z_n < a ) = {\\bf P}( G < a ) + O( \\varepsilon )")]]

#text("for all ")#mi("{a}")#text(". We may of course assume that ")#mi("{\\varepsilon < 1}")#text(", as the claim is trivial otherwise.")

#text("Let ")#mi("{c > 0}")#text(" be a small absolute constant to be chosen later. Let ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" be an non-negative Schwartz function with total mass ")#mi("{1}")#text(" whose Fourier transform is supported in ")#mi("{[-c,c]}")#text(", and let ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the smoothed out version of ")#mi("{1_{(-\\infty,0]}}")#text(", defined as")

#align(center)[#tao-fit-display[#mitex("\\varphi(x) := \\int_{\\bf R} 1_{(-\\infty,0]}(x - \\varepsilon y) \\eta(y)\\ dy.")]]

#text("Observe that ")#mi("{\\varphi}")#text(" is decreasing from ")#mi("{1}")#text(" to ")#mi("{0}")#text(".")

#text("We claim that it suffices to show that ")#metadata(none) <tao-d2efaa6dd6ae6136c199>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("{\\bf E} \\varphi(Z_n - a) = {\\bf E} \\varphi(G - a ) + O_\\eta(\\varepsilon)")]]

#text("for every ")#mi("{a}")#text(", where the subscript means that the implied constant depends on ")#mi("{\\eta}")#text(". Indeed, suppose that ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(13)")]#text(" held. Define ")#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sigma := \\sup_a \\left|{\\bf P}( Z_n < a ) - {\\bf P}( G < a )\\right|", block: true)]]

#text("thus our task is to show that ")#mi("{\\sigma = O(\\varepsilon)}")#text(".")

#text("Let ")#mi("{a}")#text(" be arbitrary, and let ")#mi("{K > 0}")#text(" be a large absolute constant to be chosen later. We write")

#tao-aligned(keep: true)[


#tao-math("{\\bf P}( Z_n < a )  & \\leq {\\bf E} \\varphi(Z_n - a - K \\varepsilon ) +", block: true)



#tao-math(" & + {\\bf E} (1 - \\varphi(Z_n - a - K \\varepsilon )) {\\bf I}(Z_n < a)", block: true)
]

#text("and thus by ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(13)")]

#tao-aligned(keep: true)[


#tao-math("{\\bf P}( Z_n < a )  & \\leq {\\bf E} \\varphi(G - a - K \\varepsilon ) +", block: true)



#tao-math(" & + {\\bf E} (1 - \\varphi(Z_n - a - K \\varepsilon )) {\\bf I}(Z_n < a) + O_\\eta(\\varepsilon).", block: true)
]

#text("Meanwhile, from ")#link(<tao-a543997d84f12798350c>)[#text("(14)")]#text(" and an integration by parts we see that")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} (1 - \\varphi(Z_n - a - K \\varepsilon )) {\\bf I}(Z_n < a)  & = {\\bf E} (1 - \\varphi(G - a - K \\varepsilon )) {\\bf I}(G < a) +", block: true)



#tao-math(" & + O(( 1 - \\varphi(-K\\varepsilon) )\\sigma).", block: true)
]

#text("From the bounded density of ")#mi("{G}")#text(" and the rapid decrease of ")#mi("{\\eta}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(G - a - K \\varepsilon ) + {\\bf E} (1 - \\varphi(G - a - K \\varepsilon )) {\\bf I}(G < a)")]]

#align(center)[#tao-fit-display[#mitex("= {\\bf P}( G < a ) + O_{\\eta,K}(\\varepsilon).")]]

#text("Putting all this together, we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( Z_n < a ) \\leq {\\bf P}(G < a) + O_{\\eta,K}(\\varepsilon) + O(( 1 - \\varphi(-K\\varepsilon) )\\sigma).")]]

#text("A similar argument gives a lower bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( Z_n < a ) \\geq {\\bf P}(G < a) - O_{\\eta,K}(\\varepsilon) - O(\\varphi(K\\varepsilon)\\sigma),")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf P}( Z_n < a ) -{\\bf P}(G < a)\\right| \\leq O_{\\eta,K}(\\varepsilon) + O(( 1 - \\varphi(-K\\varepsilon) )\\sigma) + O(\\varphi(K\\varepsilon)\\sigma).", block: true)]]

#text("Taking suprema over ")#mi("{a}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\sigma \\leq O_{\\eta,K}(\\varepsilon) + O(( 1 - \\varphi(-K\\varepsilon) )\\sigma) + O(\\varphi(K\\varepsilon)\\sigma).")]]

#text("If ")#mi("{K}")#text(" is large enough (depending on ")#mi("{c}")#text("), we can make ")#mi("{1 - \\varphi(-K\\varepsilon)}")#text(" and ")#mi("{\\varphi(K\\varepsilon)}")#text(" small, and thus absorb the latter two terms on the right-hand side into the left-hand side. This gives the desired bound ")#mi("{\\sigma = O(\\varepsilon)}")#text(".")

#text("It remains to establish ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(13)")]#text(". Applying ")#link(<tao-e215f82eb7d66a8ea261>)[#text("(8)")]#text(", it suffices to show that ")#metadata(none) <tao-421c47d8c413985f08df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\int_{\\bf R} \\hat \\varphi(t) (F_{Z_n}(t) - F_G(t))\\ dt\\right| \\leq O(\\varepsilon).", block: true)]]

#text("Now we estimate each of the various expressions. Standard Fourier-analytic computations show that")

#align(center)[#tao-fit-display[#mitex("\\hat \\varphi(t) = \\hat 1_{(-\\infty,a]}(t) \\hat \\eta(\\varepsilon t)")]]

#text("and that")

#align(center)[#tao-fit-display[#tao-math("\\hat 1_{(-\\infty,a]}(t) = O( \\frac{1}{1+\\left|t\\right|} ).", block: true)]]

#text("Since ")#mi("{\\hat \\eta}")#text(" was supported in ")#mi("{[-c,c]}")#text(", it suffices to show that ")#metadata(none) <tao-e2ea8eb98a17c6f005f4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\int_{\\left|t\\right| \\leq c/\\varepsilon} \\frac{\\left|F_{Z_n}(t) - F_G(t)\\right|}{1+\\left|t\\right|}\\ dt \\leq O(\\varepsilon).", block: true)]]

#text("From Taylor expansion we have")

#align(center)[#tao-fit-display[#tao-math("e^{itX} = 1 + it X - \\frac{t^2}{2} X^2 + O( \\left|t\\right|^3 \\left|X\\right|^3 )", block: true)]]

#text("for any ")#mi("{t}")#text("; taking expectations and using the definition of ")#mi("{\\varepsilon}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("F_X(t) = 1 - t^2/2 + O( \\varepsilon \\sqrt{n} \\left|t\\right|^3 )", block: true)]]

#text("and in particular")

#align(center)[#tao-fit-display[#tao-math("F_X(t) = \\exp( - t^2/2 + O( \\varepsilon \\sqrt{n} \\left|t\\right|^3 ) )", block: true)]]

#text("if ")#tao-math("{\\left|t\\right| \\leq c / {\\bf E} \\left|X\\right|^3}", block: false)#text(" and ")#mi("{c}")#text(" is small enough. Applying ")#link(<tao-8b5b14c53b1345927e8a>)[#text("(11)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("F_{Z_n}(t) = \\exp(-t^2/2 + O( \\varepsilon \\left|t\\right|^3 ))", block: true)]]

#text("if ")#tao-math("{\\left|t\\right| \\leq c/\\varepsilon}", block: false)#text(". Meanwhile, from Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("8")]#text(" we have ")#mi("{F_G(t) = \\exp(-t^2/2)}")#text(". Elementary calculus then gives us")

#align(center)[#tao-fit-display[#tao-math("\\left|F_{Z_n}(t) - F_G(t)\\right| \\leq O( \\varepsilon \\left|t\\right|^3 \\exp( - t^2/4 ) )", block: true)]]

#text("(say) if ")#mi("{c}")#text(" is small enough. Inserting this bound into ")#link(<tao-e2ea8eb98a17c6f005f4>)[#text("(16)")]#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Show that the error terms here are sharp (up to constants) when ")#mi("{X}")#text(" is a signed Bernoulli random variable.")
]

#heading(level: 1)[#strong[#text(" — 3. The moment method — ")]]

#text("The above Fourier-analytic proof of the central limit theorem is one of the quickest (and slickest) proofs available for this theorem, and is accordingly the “standard” proof given in probability textbooks. However, it relies quite heavily on the Fourier-analytic identities in Exercise ")#link(<tao-2e1712f7908f611efbf8>)[#text("18")]#text(", which in turn are extremely dependent on both the commutative nature of the situation (as it uses the identity ")#mi("{e^{A+B}=e^A e^B}")#text(") and on the independence of the situation (as it uses identities of the form ")#mi("{{\\bf E}(e^A e^B) = ({\\bf E} e^A)({\\bf E} e^B)}")#text("). When we turn to random matrix theory, we will often lose (or be forced to modify) one or both of these properties, which often causes the Fourier-analytic methods to fail spectacularly. Because of this, it is also important to look for non-Fourier based methods to prove results such as the central limit theorem. These methods often lead to proofs that are lengthier and more technical than the Fourier proofs, but also tend to be more robust, and in particular can often be extended to random matrix theory situations. Thus both the Fourier and non-Fourier proofs will be of importance in this course.")

#text("The most elementary (but still remarkably effective) method available in this regard is the ")#emph[#text("moment method")]#text(", which we have already used in the ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("previous notes")]#text(", which seeks to understand the distribution of a random variable ")#mi("{X}")#text(" via its moments ")#mi("{X^k}")#text(". In principle, this method is equivalent to the Fourier method, through the identity ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text("; but in practice, the moment method proofs tend to look somewhat different than the Fourier-analytic ones, and it is often more apparent how to modify them to non-independent or non-commutative settings.")

#text("We first need an analogue of the Lévy continuity theorem. Here we encounter a technical issue: whereas the Fourier phases ")#mi("{x \\mapsto e^{itx}}")#text(" were bounded, the moment functions ")#mi("{x \\mapsto x^k}")#text(" become unbounded at infinity. However, one can deal with this issue as long as one has sufficient decay:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Moment continuity theorem)")]#text(" ")#metadata(none) <tao-6d05eb6c33124ea53ade>#text(" Let ")#mi("{X_n}")#text(" be a sequence of uniformly subgaussian real random variables, and let ")#mi("{X}")#text(" be another subgaussian random variable. Then the following statements are equivalent:")

#list(
[#text("(i) For every ")#mi("{k=0,1,2,\\ldots}")#text(", ")#mi("{{\\bf E} X_n^k}")#text(" converges pointwise to ")#mi("{{\\bf E} X^k}")#text(".")],
[#text("(ii) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We first show how (ii) implies (i). Let ")#mi("{N > 0}")#text(" be a truncation parameter, and let ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth function that equals ")#mi("{1}")#text(" on ")#mi("{[-1,1]}")#text(" and vanishes outside of ")#mi("{[-2,2]}")#text(". Then for any ")#mi("{k}")#text(", the convergence in distribution implies that ")#mi("{{\\bf E} X_n^k \\varphi(X_n/N)}")#text(" converges to ")#mi("{{\\bf E} X^k \\varphi(X/N)}")#text(". On the other hand, from the uniform subgaussian hypothesis, one can make ")#mi("{{\\bf E} X_n^k (1 - \\varphi(X_n/N))}")#text(" and ")#mi("{{\\bf E} X^k (1-\\varphi(X/N))}")#text(" arbitrarily small for fixed ")#mi("{k}")#text(" by making ")#mi("{N}")#text(" large enough. Summing, and then letting ")#mi("{N}")#text(" go to infinity, we obtain (i).")

#text("Conversely, suppose (i) is true. From the uniform subgaussian hypothesis, the ")#mi("{X_n}")#text(" have ")#mi("{(k+1)^{st}}")#text(" moment bounded by ")#mi("{(Ck)^{k/2}}")#text(" for all ")#mi("{k \\geq 1}")#text(" and some ")#mi("{C}")#text(" independent of ")#mi("{k}")#text(" (see Exercise 4 from ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text("). From Taylor’s theorem with remainder (and Stirling’s formula, ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula")[#text("Notes 0a")]#text(") we conclude")

#align(center)[#tao-fit-display[#tao-math("F_{X_n}(t) = \\sum_{j=0}^k \\frac{(it)^j}{j!} {\\bf E} X_n^j + O( (Ck)^{-k/2} \\left|t\\right|^{k+1} )", block: true)]]

#text("uniformly in ")#mi("{t}")#text(" and ")#mi("{n}")#text(". Similarly for ")#mi("{X}")#text(". Taking limits using (i) we see that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\rightarrow \\infty} \\left|F_{X_n}(t) - F_X(t)\\right| = O( (Ck)^{-k/2} \\left|t\\right|^{k+1} ).", block: true)]]

#text("Then letting ")#mi("{k \\rightarrow \\infty}")#text(", keeping ")#mi("{t}")#text(" fixed, we see that ")#mi("{F_{X_n}(t)}")#text(" converges pointwise to ")#mi("{F_X(t)}")#text(" for each ")#mi("{t}")#text(", and the claim now follows from the Lévy continuity theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" One corollary of Theorem ")#link(<tao-6d05eb6c33124ea53ade>)[#text("25")]#text(" is that the distribution of a subgaussian random variable is uniquely determined by its moments (actually, this could already be deduced from Exercise ")#link(<tao-633ac296aa882e8a15dd>)[#text("12")]#text(" and Remark ")#link(<tao-6f482b0b6604c69c6a3c>)[#text("14")]#text("). The situation can fail for distributions with slower tails, for much the same reason that a smooth function is not determined by its derivatives at one point if that function is not analytic.")

#text("The Fourier inversion formula provides an easy way to recover the distribution from the characteristic function. Recovering a distribution from its moments is more difficult, and sometimes requires tools such as analytic continuation; this problem is known as the ")#emph[#text("inverse moment problem")]#text(" and will not be discussed here.")
]

#text("To prove the central limit theorem, we know from the truncation method that we may assume without loss of generality that ")#mi("{X}")#text(" is bounded (and in particular subgaussian); we may also normalise ")#mi("{X}")#text(" to have mean zero and unit variance. From the Chernoff bound ")#link(<tao-76f73c895b3f5ae270a5>)[#text("(3)")]#text(" we know that the ")#mi("{Z_n}")#text(" are uniformly subgaussian; so by Theorem ")#link(<tao-6d05eb6c33124ea53ade>)[#text("25")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} Z_n^k \\rightarrow {\\bf E} G^k")]]

#text("for all ")#mi("{k=0,1,2,\\ldots}")#text(", where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(" is a standard gaussian variable.")

#text("The moments ")#mi("{{\\bf E} G^k}")#text(" are easy to compute:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-a71e7a852678feb58602>#text(" Let ")#mi("{k}")#text(" be a natural number, and let ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(". Show that ")#mi("{{\\bf E} G^k}")#text(" vanishes when ")#mi("{k}")#text(" is odd, and equal to ")#mi("{\\frac{k!}{2^{k/2} (k/2)!}}")#text(" when ")#mi("{k}")#text(" is even. (This can either be done directly by using the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", or by using Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("8")]#text(" and Exercise ")#link(<tao-633ac296aa882e8a15dd>)[#text("12")]#text(".)")
]

#text("So now we need to compute ")#mi("{{\\bf E} Z_n^k}")#text(". Using ")#link(<tao-4f240c3fce857e766bc5>)[#text("(4)")]#text(" and linearity of expectation, we can expand this as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} Z_n^k = n^{-k/2} \\sum_{1 \\leq i_1,\\ldots,i_k \\leq n} {\\bf E} X_{i_1} \\ldots X_{i_k}.")]]

#text("To understand this expression, let us first look at some small values of ")#mi("{k}")#text(".")

#list(
[#text("For ")#mi("{k=0}")#text(", this expression is trivially ")#mi("{1}")#text(".")],
[#text("For ")#mi("{k=1}")#text(", this expression is trivially ")#mi("{0}")#text(", thanks to the mean zero hypothesis on ")#mi("{X}")#text(".")],
[#text("For ")#mi("{k=2}")#text(", we can split this expression into the diagonal and off-diagonal components:")

#align(center)[#tao-fit-display[#mitex("n^{-1} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^2 + n^{-1} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 2 X_i X_j.")]]

#text("Each summand in the first sum is ")#mi("{1}")#text(", as ")#mi("{X}")#text(" has unit variance. Each summand in the second sum is ")#mi("{0}")#text(", as the ")#mi("{X_i}")#text(" have mean zero and are independent. So the second moment ")#mi("{{\\bf E} Z_n^2}")#text(" is ")#mi("{1}")#text(".")],
[#text("For ")#mi("{k=3}")#text(", we have a similar expansion")

#tao-aligned(keep: true)[


#tao-math("n^{-3/2} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^3  & + n^{-3/2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 3 X_i^2 X_j + 3 X_i X_j^2", block: true)



#tao-math(" & + n^{-3/2} \\sum_{1 \\leq i < j < k \\leq n} {\\bf E} 6 X_i X_j X_k.", block: true)
]

#text("The summands in the latter two sums vanish because of the (joint) independence and mean zero hypotheses. The summands in the first sum need not vanish, but are ")#mi("{O(1)}")#text(", so the first term is ")#mi("{O(n^{-1/2})}")#text(", which is asymptotically negligible, so the third moment ")#mi("{{\\bf E} Z_n^3}")#text(" goes to ")#mi("{0}")#text(".")],
[#text("For ")#mi("{k=4}")#text(", the expansion becomes quite complicated:")

#tao-aligned(keep: true)[


#tao-math("n^{-2} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^4  & + n^{-2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 4 X_i^3 X_j + 6 X_i^2 X_j^2 + 4 X_i X_j^3", block: true)



#tao-math(" & + n^{-2} \\sum_{1 \\leq i < j < k \\leq n} {\\bf E} 12 X_i^2 X_j X_k + 12 X_i X_j^2 X_k + 12 X_i X_j X_k^2", block: true)



#tao-math(" & + n^{-2} \\sum_{1 \\leq i < j < k < l \\leq n} {\\bf E} 24 X_i X_j X_k X_l.", block: true)
]

#text("Again, most terms vanish, except for the first sum, which is ")#mi("{O( n^{-1} )}")#text(" and is asymptotically negligible, and the sum ")#mi("{n^{-2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 6 X_i^2 X_j^2}")#text(", which by the independence and unit variance assumptions works out to ")#mi("{n^{-2} 6 \\binom{n}{2} = 3 + o(1)}")#text(". Thus the fourth moment ")#mi("{{\\bf E} Z_n^4}")#text(" goes to ")#mi("{3}")#text(" (as it should).")]
)

#text("Now we tackle the general case. Ordering the indices ")#mi("{i_1,\\ldots,i_k}")#text(" as ")#mi("{j_1 < \\ldots < j_m}")#text(" for some ")#mi("{1 \\leq m \\leq k}")#text(", with each ")#mi("{j_r}")#text(" occuring with multiplicity ")#mi("{a_r \\geq 1}")#text(" and using elementary ")#link("http://en.wikipedia.org/wiki/Enumerative_combinatorics")[#text("enumerative combinatorics")]#text(", we see that ")#mi("{{\\bf E} Z_n^k}")#text(" is the sum of all terms of the form ")#metadata(none) <tao-397d460b0d90e5d7ea3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("n^{-k/2} \\sum_{1 \\leq j_1 < \\ldots < j_m \\leq n} c_{k,a_1,\\ldots,a_m} {\\bf E} X_{j_1}^{a_1} \\ldots X_{j_m}^{a_m}")]]

#text("where ")#mi("{1 \\leq m \\leq k}")#text(", ")#mi("{a_1,\\ldots,a_m}")#text(" are positive integers adding up to ")#mi("{k}")#text(", and ")#mi("{c_{k,a_1,\\ldots,a_m}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Multinomial_distribution")[#text("multinomial")]#text(" coefficient")

#align(center)[#tao-fit-display[#mitex("c_{k,a_1,\\ldots,a_m} := \\frac{k!}{a_1! \\ldots a_m!}.")]]

#text("The total number of such terms depends only on ")#mi("{k}")#text(" (in fact, it is ")#mi("{2^{k-1}}")#text(" (exercise!), though we will not need this fact).")

#text("As we already saw from the small ")#mi("{k}")#text(" examples, most of the terms vanish, and many of the other terms are negligible in the limit ")#mi("{n \\rightarrow \\infty}")#text(". Indeed, if any of the ")#mi("{a_r}")#text(" are equal to ")#mi("{1}")#text(", then every summand in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" vanishes, by joint independence and the mean zero hypothesis. Thus, we may restrict attention to those expressions ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" for which all the ")#mi("{a_r}")#text(" are at least ")#mi("{2}")#text(". Since the ")#mi("{a_r}")#text(" sum up to ")#mi("{k}")#text(", we conclude that ")#mi("{m}")#text(" is at most ")#mi("{k/2}")#text(".")

#text("On the other hand, the total number of summands in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" is clearly at most ")#mi("{n^m}")#text(" (in fact it is ")#mi("{\\binom{n}{m}}")#text("), and the summands are bounded (for fixed ")#mi("{k}")#text(") since ")#mi("{X}")#text(" is bounded. Thus, if ")#mi("{m}")#text(" is ")#emph[#text("strictly")]#text(" less than ")#mi("{k/2}")#text(", then the expression in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" is ")#mi("{O( n^{m-k/2} )}")#text(" and goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". So, asymptotically, the only terms ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" which are still relevant are those for which ")#mi("{m}")#text(" is ")#emph[#text("equal")]#text(" to ")#mi("{k/2}")#text(". This already shows that ")#mi("{{\\bf E} Z_n^k}")#text(" goes to zero when ")#mi("{k}")#text(" is odd. When ")#mi("{k}")#text(" is even, the only surviving term in the limit is now when ")#mi("{m=k/2}")#text(" and ")#mi("{a_1=\\ldots=a_m = 2}")#text(". But then by independence and unit variance, the expectation in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" is ")#mi("{1}")#text(", and so this term is equal to")

#align(center)[#tao-fit-display[#mitex("n^{-k/2} \\binom{n}{m} c_{k,2,\\ldots,2} = \\frac{1}{(k/2)!} \\frac{k!}{2^{k/2}} + o(1),")]]

#text("and the main term is happily equal to the moment ")#mi("{{\\bf E} G^k}")#text(" as computed in Exercise ")#link(<tao-a71e7a852678feb58602>)[#text("27")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. The Lindeberg swapping trick — ")]]

#text("The moment method proof of the central limit theorem that we just gave consisted of four steps:")

#list(
[#text("(Truncation and normalisation step) A reduction to the case when ")#mi("{X}")#text(" was bounded with zero mean and unit variance.")],
[#text("(Inverse moment step) A reduction to a computation of asymptotic moments ")#mi("{\\lim_{n \\rightarrow \\infty} {\\bf E} Z_n^k}")#text(".")],
[#text("(Analysis step) Showing that most terms in the expansion of this asymptotic moment were zero, or went to zero as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(Algebra step) Using enumerative combinatorics to compute the remaining terms in the expansion.")]
)

#text("In this particular case, the enumerative combinatorics was very classical and easy – it was basically asking for the number of ways one can place ")#mi("{k}")#text(" balls in ")#mi("{m}")#text(" boxes, so that the ")#mi("{r^{th}}")#text(" box contains ")#mi("{a_r}")#text(" balls, and the answer is well known to be given by the multinomial ")#mi("{\\frac{k!}{a_1! \\ldots a_r!}}")#text(". By a small algebraic miracle, this result matched up nicely with the computation of the moments of the gaussian ")#mi("{N(0,1)_{\\bf R}}")#text(".")

#text("However, when we apply the moment method to more advanced problems, the enumerative combinatorics can become more non-trivial, requiring a fair amount of combinatorial and algebraic computation. The algebraic miracle that occurs at the end of the argument can then seem like a very fortunate but inexplicable coincidence, making the argument somehow unsatisfying despite being rigorous.")

#text("In a 1922 paper, Lindeberg observed that there was a very simple way to ")#emph[#text("decouple")]#text(" the algebraic miracle from the analytic computations, so that all relevant algebraic identities only need to be verified in the special case of ")#emph[#text("gaussian")]#text(" random variables, in which everything is much easier to compute. This ")#emph[#text("Lindeberg swapping trick")]#text(" (or ")#emph[#text("Lindeberg replacement trick")]#text(") will be very useful in the later theory of random matrices, so we pause to give it here in the simple context of the central limit theorem.")

#text("The basic idea is follows. We repeat the truncation-and-normalisation and inverse moment steps in the preceding argument. Thus, ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of a boudned real random variable ")#mi("{X}")#text(" of mean zero and unit variance, and we wish to show that ")#mi("{{\\bf E} Z_n^k \\rightarrow {\\bf E} G^k}")#text(", where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(", where ")#mi("{k \\geq 0}")#text(" is fixed.")

#text("Now let ")#mi("{Y_1,\\ldots,Y_n}")#text(" be iid copies of the gaussian itself: ")#mi("{Y_1,\\ldots,Y_n \\equiv N(0,1)_{\\bf R}}")#text(". Because the sum of independent gaussians is again a gaussian (Exercise 9 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(", we see that the random variable")

#align(center)[#tao-fit-display[#mitex("W_n := \\frac{Y_1+\\ldots+Y_n}{\\sqrt{n}}")]]

#text("already has the same distribution as ")#mi("{G}")#text(": ")#mi("{W_n \\equiv G}")#text(". Thus, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} Z_n^k = {\\bf E} W_n^k + o(1).")]]

#text("Now we perform the analysis part of the moment method argument again. We can expand ")#mi("{{\\bf E} Z_n^k}")#text(" into terms ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" as before, and discard all terms except for the ")#mi("{a_1=\\ldots=a_m=2}")#text(" term as being ")#mi("{o(1)}")#text(". Similarly, we can expand ")#mi("{{\\bf E} W_n^k}")#text(" into very similar terms (but with the ")#mi("{X_i}")#text(" replaced by ")#mi("{Y_i}")#text(") and again discard all but the ")#mi("{a_1=\\ldots=a_m}")#text(" term.")

#text("But by hypothesis, the second moments of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" match: ")#mi("{{\\bf E} X^2 = {\\bf E} Y^2 = 1}")#text(". Thus, by joint independence, the ")#mi("{a_1=\\ldots=a_m=2}")#text(" term ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(17)")]#text(" for ")#mi("{X}")#text(" is exactly equal to that of ")#mi("{Y}")#text(". And the claim follows.")

#text("This is almost exactly the same proof as in the previous section, but note that we did ")#emph[#text("not")]#text(" need to compute the multinomial coefficient ")#mi("{c_{k,a_1,\\ldots,a_m}}")#text(", nor did we need to verify the miracle that this coefficient matched (up to normalising factors) to the moments of the gaussian. Instead, we used the much more mundane “miracle” that the sum of independent gaussians was again a gaussian.")

#text("To put it another way, the Lindeberg replacement trick factors a universal limit theorem, such as the central limit theorem, into two components:")

#list(
[#text("A ")#emph[#text("universality")]#text(" or ")#emph[#text("invariance")]#text(" result, which shows that the distribution (or other statistics, such as moments) of some random variable ")#mi("{F(X_1,\\ldots,X_n)}")#text(" is asymptotically unchanged in the limit ")#mi("{n \\rightarrow \\infty}")#text(" if each of the input variables ")#mi("{X_i}")#text(" are replaced by a gaussian substitute ")#mi("{Y_i}")#text("; and")],
[#text("The ")#emph[#text("gaussian case")]#text(", which computes the asymptotic distribution (or other statistic) of ")#mi("{F(Y_1,\\ldots,Y_n)}")#text(" in the case when ")#mi("{Y_1,\\ldots,Y_n}")#text(" are all gaussians.")]
)

#text("The former type of result tends to be entirely analytic in nature (basically, one just needs to show that all error terms that show up when swapping ")#mi("{X}")#text(" with ")#mi("{Y}")#text(" are ")#mi("{o(1)}")#text("), while the latter type of result tends to be entirely algebraic in nature (basically, one just needs to exploit the many pleasant algebraic properties of gaussians). This decoupling of the analysis and algebra steps tends to simplify both, both at a technical level and at a conceptual level.")

#heading(level: 1)[#strong[#text(" — 5. Individual swapping — ")]]

#text("In the above argument, we swapped all the original input variables ")#mi("{X_1,\\ldots,X_n}")#text(" with gaussians ")#mi("{Y_1,\\ldots,Y_n}")#text(" ")#emph[#text("en masse")]#text(". There is also a variant of the Lindeberg trick in which the swapping is done ")#emph[#text("individually")]#text(". To illustrate the individual swapping method, let us use it to show the following weak version of the Berry-Esséen theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 28 (Berry-Esséen theorem, weak form)")]#text(" ")#metadata(none) <tao-73cce42f1f0e9099688b>#text(" Let ")#mi("{X}")#text(" have mean zero, unit variance, and finite third moment, and let ")#mi("{\\varphi}")#text(" be smooth with uniformly bounded derivatives up to third order. Let ")#mi("{Z_n := (X_1+\\ldots+X_n)/\\sqrt{n}}")#text(", where ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(". Then we have ")#metadata(none) <tao-eeecf85814215b61dd9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("{\\bf E} \\varphi( Z_n ) = {\\bf E} \\varphi(G) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3) \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right| )", block: true)]]

#text("where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{Y_1,\\ldots,Y_n}")#text(" and ")#mi("{W_n}")#text(" be in the previous section. As ")#mi("{W_n \\equiv G}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(Z_n) - \\varphi(W_n) = o(1).")]]

#text("We telescope this (using linearity of expectation) as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(Z_n) - \\varphi(W_n) = -\\sum_{i=0}^{n-1} {\\bf E} \\varphi( Z_{n,i} ) - \\varphi( Z_{n,i+1} )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("Z_{n,i} := \\frac{X_1+\\ldots+X_i+Y_{i+1}+\\ldots+Y_n}{\\sqrt{n}}")]]

#text("is a partially swapped version of ")#mi("{Z_n}")#text(". So it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\varphi( Z_{n,i} ) - \\varphi( Z_{n,i+1} ) = O( ({\\bf E} \\left|X\\right|^3) \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right| /n^{3/2} )", block: true)]]

#text("uniformly for ")#mi("{0 \\leq i < n}")#text(".")

#text("We can write ")#mi("{Z_{n,i} = S_{n,i} + Y_{i+1}/\\sqrt{n}}")#text(" and ")#mi("{Z_{n,i+1} = S_{n,i} + X_{i+1}/\\sqrt{n}}")#text(", where ")#metadata(none) <tao-a97c5f2dd3d5023df257>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("S_{n,i} := \\frac{X_1+\\ldots+X_i+Y_{i+2}+\\ldots+Y_n}{\\sqrt{n}}.")]]

#text("To exploit this, we use Taylor expansion with remainder to write")

#tao-aligned(keep: true)[


#tao-math("\\varphi(Z_{n,i})  & = \\varphi(S_{n,i}) + \\varphi^{\\prime}(S_{n,i}) Y_{i+1}/\\sqrt{n}", block: true)



#tao-math(" & + \\frac{1}{2} \\varphi^{\\prime\\prime}(S_{n,i}) Y_{i+1}^2 / n + O( \\left|Y_{i+1}\\right|^3 / n^{3/2} \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right| )", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\varphi(Z_{n,i+1})  & = \\varphi(S_{n,i}) + \\varphi^{\\prime}(S_{n,i}) X_{i+1}/\\sqrt{n}", block: true)



#tao-math(" & + \\frac{1}{2} \\varphi^{\\prime\\prime}(S_{n,i}) X_{i+1}^2 / n + O( \\left|X_{i+1}\\right|^3 / n^{3/2} \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right|)", block: true)
]

#text("where the implied constants depend on ")#mi("{\\varphi}")#text(" but not on ")#mi("{n}")#text(". Now, by construction, the moments of ")#mi("{X_{i+1}}")#text(" and ")#mi("{Y_{i+1}}")#text(" match to second order, thus")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\varphi( Z_{n,i} ) - \\varphi( Z_{n,i+1} )  & = O( {\\bf E} \\left|Y_{i+1}\\right|^3 \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right| / n^{3/2} )", block: true)



#tao-math(" & + O( {\\bf E} \\left|X_{i+1}\\right|^3 \\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime\\prime\\prime}(x)\\right| / n^{3/2} ),", block: true)
]

#text("and the claim follows. (Note from Hölder’s inequality that ")#tao-math("{{\\bf E} \\left|X\\right|^3 \\geq 1}", block: false)#text(".) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" The above argument relied on Taylor expansion, and the hypothesis that the moments of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" matched to second order. It is not hard to see that if we assume more moments matching (e.g. ")#mi("{{\\bf E} X^3 = {\\bf E} Y^3 = 3}")#text("), and more smoothness on ")#mi("{\\varphi}")#text(", we see that we can improve the ")#mi("{\\frac{1}{\\sqrt{n}}}")#text(" factor on the right-hand side. Thus we see that we expect swapping methods to become more powerful when more moments are matching. We will see this when we discuss the ")#emph[#text("four moment theorem")]#text(" of Van Vu and myself in later lectures, which (very) roughly speaking asserts that the spectral statistics of two random matrices are asymptotically indistinguishable if their coefficients have matching moments to fourth order.")
]

#text("Theorem ")#link(<tao-73cce42f1f0e9099688b>)[#text("28")]#text(" is easily implied by Theorem ")#link(<tao-be5fe2ee6cf8d5a95850>)[#text("23")]#text(" and an integration by parts. In the reverse direction, let us see what Theorem ")#link(<tao-73cce42f1f0e9099688b>)[#text("28")]#text(" tells us about the cumulative distribution function")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( Z_n < a )")]]

#text("of ")#mi("{Z_n}")#text(". For any ")#mi("{\\varepsilon > 0}")#text(", one can upper bound this expression by")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(Z_n)")]]

#text("where ")#mi("{\\varphi}")#text(" is a smooth function equal to ")#mi("{1}")#text(" on ")#mi("{(-\\infty,a]}")#text(" that vanishes outside of ")#mi("{(-\\infty,a+\\varepsilon]}")#text(", and has third derivative ")#mi("{O(\\varepsilon^{-3})}")#text(". By Theorem ")#link(<tao-73cce42f1f0e9099688b>)[#text("28")]#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( Z_n < a ) \\leq {\\bf E} \\varphi(G) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3) \\varepsilon^{-3} ).", block: true)]]

#text("On the other hand, as ")#mi("{G}")#text(" has a bounded probability density function, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(G) = {\\bf P}(G < a ) + O(\\varepsilon)")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( Z_n < a ) \\leq {\\bf P}( G < a ) + O(\\varepsilon) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3) \\varepsilon^{-3} ).", block: true)]]

#text("A very similar argument gives the matching lower bound, thus")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( Z_n < a ) = {\\bf P}( G < a ) + O(\\varepsilon) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3) \\varepsilon^{-3} ).", block: true)]]

#text("Optimising in ")#mi("{\\varepsilon}")#text(" we conclude that ")#metadata(none) <tao-8a770f8dde87daf006c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("{\\bf P}( Z_n < a ) = {\\bf P}( G < a ) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3))^{1/4}.", block: true)]]

#text("Comparing this with Theorem ")#link(<tao-be5fe2ee6cf8d5a95850>)[#text("23")]#text(" we see that we have lost an exponent of ")#mi("{1/4}")#text(". In our applications to random matrices, this type of loss is acceptable, and so the swapping argument is a reasonable substitute for the Fourier-analytic one in this case. Also, this method is quite robust, and in particular extends well to higher dimensions; we will return to this point in later lectures, but see for instance Appendix D of ")#link("http://arxiv.org/abs/0906.0510")[#text("this paper of myself and Van Vu")]#text(" for an example of a multidimensional Berry-Esséen theorem proven by this method.")

#text("On the other hand there is another method that can recover this loss while still avoiding Fourier-analytic techniques; we turn to this topic next.")

#heading(level: 1)[#strong[#text(" — 6. Stein’s method — ")]]

#link("http://en.wikipedia.org/wiki/Stein's_method")[#text("Stein’s method")]#text(", introduced by Charles Stein in 1970 (who should not be confused with a number of other eminent mathematicians with this surname, including ")#link("http://en.wikipedia.org/wiki/Elias_Stein")[#text("my advisor")]#text("), is a powerful method to show convergence in distribution to a special distribution, such as the gaussian. In several recent papers, this method has been used to control several expressions of interest in random matrix theory (e.g. the distribution of moments, or of the Stieltjes transform.) We will not use it much in this course, but this method is of independent interest, so I will briefly discuss (a very special case of) it here.")

#text("The probability density function ")#mi("{\\rho(x) := \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text(" of the standard normal distribution ")#mi("{N(0,1)_{\\bf R}}")#text(" can be viewed as a solution to the ordinary differential equation ")#metadata(none) <tao-4ad815618f703e2f509a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\rho^{\\prime}(x) + x \\rho(x) = 0.")]]

#text("One can take adjoints of this, and conclude (after an integration by parts) that ")#mi("{\\rho}")#text(" obeys the integral identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\rho(x) (f^{\\prime}(x) - x f(x))\\ dx = 0")]]

#text("for any continuously differentiable ")#mi("{f}")#text(" with both ")#mi("{f}")#text(" and ")#mi("{f^{\\prime}}")#text(" bounded (one can relax these assumptions somewhat). To put it another way, if ")#mi("{G \\equiv N(0,1)}")#text(", then we have ")#metadata(none) <tao-74101a325e6263b37f11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\bf E} f^{\\prime}(G) - G f(G) = 0")]]

#text("whenever ")#mi("{f}")#text(" is continuously differentiable with ")#mi("{f, f^{\\prime}}")#text(" both bounded.")

#text("It turns out that the converse is true: if ")#mi("{X}")#text(" is a real random variable with the property that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f^{\\prime}(X) - X f(X) = 0")]]

#text("whenever ")#mi("{f}")#text(" is continuously differentiable with ")#mi("{f, f^{\\prime}}")#text(" both bounded, then ")#mi("{X}")#text(" is Gaussian. In fact, more is true, in the spirit of Theorem ")#link(<tao-5a1a84de8c2ec09ba6b5>)[#text("13")]#text(" and Theorem ")#link(<tao-6d05eb6c33124ea53ade>)[#text("25")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 30 (Stein continuity theorem)")]#text(" ")#metadata(none) <tao-065b43e11b0a0e76aeeb>#text(" Let ")#mi("{X_n}")#text(" be a sequence of real random variables with uniformly bounded second moment, and let ")#mi("{G \\equiv N(0,1)}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{{\\bf E} f^{\\prime}(X_n) - X_n f(X_n)}")#text(" converges to zero whenever ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is continuously differentiable with ")#mi("{f, f^{\\prime}}")#text(" both bounded.")],
[#text("(ii) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{G}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" To show that (ii) implies (i), it is not difficult to use the uniform bounded second moment hypothesis and a truncation argument to show that ")#mi("{{\\bf E} f^{\\prime}(X_n) - X_n f(X_n)}")#text(" converges to ")#mi("{{\\bf E} f^{\\prime}(G) - G f(G)}")#text(" when ")#mi("{f}")#text(" is continuously differentiable with ")#mi("{f, f^{\\prime}}")#text(" both bounded, and the claim then follows from ")#link(<tao-74101a325e6263b37f11>)[#text("(22)")]#text(".")

#text("Now we establish the converse. It suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi(X_n) - {\\bf E} \\varphi(G) \\rightarrow 0")]]

#text("whenever ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a bounded Lipschitz function. We may normalise ")#mi("{\\varphi}")#text(" to be bounded in magnitude by ")#mi("{1}")#text(".")

#text("Trivially, the function ")#mi("{\\varphi(\\cdot)-{\\bf E} \\varphi(G)}")#text(" has zero expectation when one substitutes ")#mi("{G}")#text(" for the argument ")#mi("{\\cdot}")#text(", thus ")#metadata(none) <tao-95220649f7d73b138d2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\frac{1}{\\sqrt{2\\pi}} \\int_{-\\infty}^{\\infty} e^{-y^2/2} (\\varphi(y) - {\\bf E}\\varphi(G))\\ dy = 0.")]]

#text("Comparing this with ")#link(<tao-74101a325e6263b37f11>)[#text("(22)")]#text(", one may thus hope to find a representation of the form ")#metadata(none) <tao-3097e26b7f3cbdb92076>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\varphi(x) - {\\bf E} \\varphi(G) = f^{\\prime}(x) - x f(x)")]]

#text("for some continuously differentiable ")#mi("{f}")#text(" with ")#mi("{f, f^{\\prime}}")#text(" both bounded. This is a simple ODE and can be easily solved (by the method of ")#link("http://en.wikipedia.org/wiki/Integrating_factor")[#text("integrating factors")]#text(") to give a solution ")#mi("{f}")#text(", namely ")#metadata(none) <tao-5a0f2d4795141ce8ba96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("f(x) := e^{x^2/2} \\int_{-\\infty}^x e^{-y^2/2} (\\varphi(y) - {\\bf E}\\varphi(G))\\ dy.")]]

#text("(One could dub ")#mi("{f}")#text(" the ")#emph[#text("Stein transform")]#text(" of ")#mi("{\\varphi}")#text(", although this term does not seem to be in widespread use.) By the fundamental theorem of calculus, ")#mi("{f}")#text(" is continuously differentiable and solves ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(". Using ")#link(<tao-95220649f7d73b138d2d>)[#text("(23)")]#text(", we may also write ")#mi("{f}")#text(" as ")#metadata(none) <tao-d0eae71e89a724145124>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("f(x) := -e^{x^2/2} \\int_x^{\\infty} e^{-y^2/2} (\\varphi(y) - {\\bf E}\\varphi(G))\\ dy.")]]

#text("By completing the square, we see that ")#mi("{e^{-y^2/2} \\leq e^{-x^2/2} e^{-x(y-x)}}")#text(". Inserting this into ")#link(<tao-5a0f2d4795141ce8ba96>)[#text("(25)")]#text(" and using the bounded nature of ")#mi("{\\varphi}")#text(", we conclude that ")#tao-math("{f(x) = O_\\varphi(1/\\left|x\\right|)}", block: false)#text(" for ")#mi("{x < -1}")#text("; inserting it instead into ")#link(<tao-d0eae71e89a724145124>)[#text("(26)")]#text(", we have ")#tao-math("{f(x) = O_\\varphi( 1/\\left|x\\right|)}", block: false)#text(" for ")#mi("{x > 1}")#text(". Finally, easy estimates give ")#mi("{f(x) = O_\\varphi(1)}")#text(" for ")#tao-math("{\\left|x\\right| \\leq 1}", block: false)#text(". Thus for all ")#mi("{x}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("f(x) = O_\\varphi( \\frac{1}{1+\\left|x\\right|} )", block: true)]]

#text("which when inserted back into ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(" gives the boundedness of ")#mi("{f^{\\prime}}")#text(" (and also of course gives the boundedness of ")#mi("{f}")#text("). In fact, if we rewrite ")#link(<tao-d0eae71e89a724145124>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("f(x) := - \\int_0^\\infty e^{-s^2/2} e^{-sx} (\\varphi(x+s) - {\\bf E}\\varphi(G))\\ ds,")]]

#text("we see on differentiation under the integral sign (and using the Lipschitz nature of ")#mi("{\\varphi}")#text(") that ")#mi("{f^{\\prime}(x) = O_\\varphi(1/x)}")#text(" for ")#mi("{x>1}")#text("; a similar manipulation (starting from ")#link(<tao-5a0f2d4795141ce8ba96>)[#text("(25)")]#text(") applies for ")#mi("{x<-1}")#text(", and we in fact conclude that ")#tao-math("{f^{\\prime}(x) = O_\\varphi(\\frac{1}{1+\\left|x\\right|})}", block: false)#text(" for all ")#mi("{x}")#text(".")

#text("Applying ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(" with ")#mi("{x=X_n}")#text(" and taking expectations, we have")

#align(center)[#tao-fit-display[#mitex("\\varphi(X_n) - {\\bf E} \\varphi(G) = f^{\\prime}(X_n) - X_n f(X_n).")]]

#text("By the hypothesis (i), the right-hand side goes to zero, hence the left-hand side does also, and the claim follows. ")#mi("\\Box")

#text("The above theorem gave only a qualitative result (convergence in distribution), but the proof is quite quantitative, and can be used to in particular to give Berry-Esséen type results. To illustrate this, we begin with a strengthening of Theorem ")#link(<tao-73cce42f1f0e9099688b>)[#text("28")]#text(" that reduces the number of derivatives of ")#mi("{\\varphi}")#text(" that need to be controlled:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 31 (Berry-Esséen theorem, less weak form)")]#text(" ")#metadata(none) <tao-22cd34c14a4641fd5aa2>#text(" Let ")#mi("{X}")#text(" have mean zero, unit variance, and finite third moment, and let ")#mi("{\\varphi}")#text(" be smooth, bounded in magnitude by ")#mi("{1}")#text(", and Lipschitz. Let ")#mi("{Z_n := (X_1+\\ldots+X_n)/\\sqrt{n}}")#text(", where ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(". Then we have ")#metadata(none) <tao-6d5ef1fdb68c5ab10b7c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("{\\bf E} \\varphi( Z_n ) = {\\bf E} \\varphi(G) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3) (1+\\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime}(x)\\right|) )", block: true)]]

#text("where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Set ")#tao-math("{A := 1+\\sup_{x \\in{\\bf R}} \\left|\\varphi^{\\prime}(x)\\right|}", block: false)#text(".")

#text("Let ")#mi("{f}")#text(" be the Stein transform ")#link(<tao-5a0f2d4795141ce8ba96>)[#text("(25)")]#text(" of ")#mi("{\\varphi}")#text(", then by ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi( Z_n ) - {\\bf E} \\varphi(G) = {\\bf E} f^{\\prime}( Z_n ) - Z_n f(Z_n).")]]

#text("We expand ")#mi("{Z_n f(Z_n) = \\frac{1}{\\sqrt{n}} \\sum_{i=1}^n X_i f(Z_n)}")#text(". For each ")#mi("{i}")#text(", we then split ")#mi("{Z_n = Z_{n;i} + \\frac{1}{\\sqrt{n}} X_i}")#text(", where ")#mi("{Z_{n;i} := (X_1 + \\ldots + X_{i-1} + X_{i+1} + \\ldots + X_n)/\\sqrt{n}}")#text(" (cf. ")#link(<tao-a97c5f2dd3d5023df257>)[#text("(19)")]#text("). By the fundamental theorem of calculus, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X_i f(Z_n) = {\\bf E} X_i f(Z_{n;i}) + \\frac{1}{\\sqrt{n}} X_i^2 f^{\\prime}(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i)")]]

#text("where ")#mi("{t}")#text(" is uniformly distributed in ")#mi("{[0,1]}")#text(" and independent of all of the ")#mi("{X_1,\\ldots,X_n}")#text(". Now observe that ")#mi("{X_i}")#text(" and ")#mi("{Z_{n;i}}")#text(" are independent, and ")#mi("{X_i}")#text(" has mean zero, so the first term on the right-hand side vanishes. Thus ")#metadata(none) <tao-d97c2ccbf0f17f94afba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("{\\bf E} \\varphi( Z_n ) - {\\bf E} \\varphi(G) = \\frac{1}{n} \\sum_{i=1}^n {\\bf E} f^{\\prime}(Z_n) - X_i^2 f^{\\prime}(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i).")]]

#text("Another application of independendence gives")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f^{\\prime}(Z_{n;i}) = {\\bf E} X_i^2 f^{\\prime}(Z_{n;i})")]]

#text("so we may rewrite ")#link(<tao-d97c2ccbf0f17f94afba>)[#text("(28)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} (f^{\\prime}(Z_n) - f^{\\prime}(Z_{n;i})) - X_i^2 (f^{\\prime}(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i)-f^{\\prime}(Z_{n;i})).")]]

#text("Recall from the proof of Theorem ")#link(<tao-065b43e11b0a0e76aeeb>)[#text("30")]#text(" that ")#tao-math("{f(x) = O(1/(1+\\left|x\\right|))}", block: false)#text(" and ")#tao-math("{f^{\\prime}(x) = O(A/(1+\\left|x\\right|))}", block: false)#text(". By the product rule, this implies that ")#mi("{xf(x)}")#text(" has a Lipschitz constant of ")#mi("{O(A)}")#text(". Applying ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(" and the definition of ")#mi("{A}")#text(", we conclude that ")#mi("{f^{\\prime}}")#text(" has a Lipschitz constant of ")#mi("{O( A )}")#text(". Thus we can bound the previous expression as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} \\frac{1}{\\sqrt{n}} O( A \\left|X_i\\right| + A \\left|X_i\\right|^3 )", block: true)]]

#text("and the claim follows from Hölder’s inequality. ")#mi("\\Box")

#text("This improvement already reduces the ")#mi("{1/4}")#text(" loss in ")#link(<tao-8a770f8dde87daf006c4>)[#text("(20)")]#text(" to ")#mi("{1/2}")#text(". But one can do better still by pushing the arguments further. Let us illustrate this in the model case when the ")#mi("{X_i}")#text(" not only have bounded third moment, but are in fact bounded:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Berry-Esséen theorem, bounded case)")]#text(" ")#metadata(none) <tao-142b031fbca7c162934e>#text(" Let ")#mi("{X}")#text(" have mean zero, unit variance, and be bounded by ")#mi("{O(1)}")#text(". Let ")#mi("{Z_n := (X_1+\\ldots+X_n)/\\sqrt{n}}")#text(", where ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(". Then we have ")#metadata(none) <tao-f78638713bc3b4acd556>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("{\\bf P}( Z_n < a ) = {\\bf P}( G < a ) + O( \\frac{1}{\\sqrt{n}} )")]]

#text("whenever ")#mi("{a=O(1)}")#text(", where ")#mi("{G \\equiv N(0,1)_{\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{\\phi := 1_{(-\\infty,a]}}")#text(", thus we seek to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\phi(Z_n) - \\phi(G) = O( \\frac{1}{\\sqrt{n}} ).")]]

#text("Let ")#mi("{f}")#text(" be the Stein transform ")#link(<tao-5a0f2d4795141ce8ba96>)[#text("(25)")]#text(" of ")#mi("{\\phi}")#text(". ")#mi("{\\phi}")#text(" is not continuous, but it is not difficult to see (e.g. by a limiting argument) that we still have the estimates ")#tao-math("{f(x) = O(1/(1+\\left|x\\right|))}", block: false)#text(" and ")#mi("{f^{\\prime}(x) = O(1)}")#text(" (in a weak sense), and that ")#mi("{xf}")#text(" has a Lipschitz norm of ")#mi("{O(1)}")#text(" (here we use the hypothesis ")#mi("{a=O(1)}")#text("). A similar limiting argument gives")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\phi(Z_n) - \\phi(G) = {\\bf E} f^{\\prime}(Z_n) - Z_n f(Z_n)")]]

#text("and by arguing as in the proof of Theorem ")#link(<tao-22cd34c14a4641fd5aa2>)[#text("31")]#text(", we can write the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} (f^{\\prime}(Z_n) - f^{\\prime}(Z_{n;i})) - X_i^2 (f^{\\prime}(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i)-f^{\\prime}(Z_{n;i})).")]]

#text("From ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(24)")]#text(", ")#mi("{f^{\\prime}}")#text(" is equal to ")#mi("{\\phi}")#text(", plus a function with Lipschitz norm ")#mi("{O(1)}")#text(". Thus, we can write the above expression as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} (\\phi(Z_n) - \\phi(Z_{n;i})) - X_i^2 (\\phi(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i)-\\phi(Z_{n;i})) + O( 1/\\sqrt{n} ).")]]

#text("The ")#mi("{\\phi(Z_{n;i})}")#text(" terms cancel (due to the independence of ")#mi("{X_i}")#text(" and ")#mi("{Z_{n;i}}")#text(", and the normalised mean and variance of ")#mi("{X_i}")#text("), so we can simplify this as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\phi(Z_n) - \\frac{1}{n} \\sum_{i=1}^n {\\bf E} X_i^2 \\phi(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i)")]]

#text("and so we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} X_i^2 \\phi(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i) = {\\bf E} \\phi(G) + O( 1/\\sqrt{n} ).")]]

#text("Since ")#mi("{t}")#text(" and ")#mi("{X_i}")#text(" are bounded, and ")#mi("{\\phi}")#text(" is non-increasing, we have")

#align(center)[#tao-fit-display[#mitex("\\phi(Z_{n;i} + O(1/\\sqrt{n})) \\leq \\phi(Z_{n;i} + \\frac{t}{\\sqrt{n}} X_i) \\leq \\phi(Z_{n;i} - O(1/\\sqrt{n}));")]]

#text("applying the second inequality and using independence to once again eliminate the ")#mi("{X_i^2}")#text(" factor, we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n {\\bf E} \\phi(Z_{n;i} - O(1/\\sqrt{n}) ) \\geq {\\bf E} \\phi(G) + O( 1/\\sqrt{n} )")]]

#text("which implies (by another appeal to the non-increasing nature of ")#mi("{\\phi}")#text(" and the bounded nature of ")#mi("{X_i}")#text(") that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\phi(Z_n - O(1/\\sqrt{n}) ) \\geq {\\bf E} \\phi(G) + O( 1/\\sqrt{n} )")]]

#text("or in other words that")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (Z_n \\leq a + O(1/\\sqrt{n})) \\geq {\\bf P} (G \\leq a) + O( 1/\\sqrt{n} ).")]]

#text("Similarly, using the lower bound inequalities, one has")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (Z_n \\leq a - O(1/\\sqrt{n})) \\leq {\\bf P} (G \\leq a) + O( 1/\\sqrt{n} ).")]]

#text("Moving ")#mi("{a}")#text(" up and down by ")#mi("{O(1/\\sqrt{n})}")#text(", and using the bounded density of ")#mi("{G}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Actually, one can use Stein’s method to obtain the full Berry-Esséen theorem, but the computations get somewhat technical, requiring an induction on ")#mi("{n}")#text(" to deal with the contribution of the exceptionally large values of ")#mi("{X_i}")#text(": see ")#link("http://www.ams.org/mathscinet-getitem?mr=746011")[#text("this paper of Barbour and Hall")]#text(".")

#heading(level: 1)[#strong[#text(" — 7. Predecessor comparison — ")]]

#text("Suppose one had never heard of the normal distribution, but one still suspected the existence of the central limit theorem – thus, one thought that the sequence ")#mi("{Z_n}")#text(" of normalised distributions was converging in distribution to something, but was unsure what the limit was. Could one still work out what that limit was?")

#text("Certainly in the case of Bernoulli distributions, one could work explicitly using Stirling’s formula (see Exercise ")#link(<tao-65ea5c55a9c3c88d87c7>)[#text("3")]#text("), and the Fourier-analytic method would also eventually work. Let us now give a third way to (heuristically) derive the normal distribution as the limit of the central limit theorem. The idea is to compare ")#mi("{Z_n}")#text(" with its predecessor ")#mi("{Z_{n-1}}")#text(", using the recursive formula ")#metadata(none) <tao-cb04eeab181fd02dd8b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("Z_n = \\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1} + \\frac{1}{\\sqrt{n}} X_n")]]

#text("(normalising ")#mi("{X_n}")#text(" to have mean zero and unit variance as usual; let us also truncate ")#mi("{X_n}")#text(" to be bounded, for simplicity). Let us hypothesise that ")#mi("{Z_n}")#text(" and ")#mi("{Z_{n-1}}")#text(" are approximately the same distribution; let us also conjecture that this distribution is absolutely continuous, given as ")#mi("{\\rho(x)\\ dx}")#text(" for some smooth ")#mi("{\\rho(x)}")#text(". (If we secretly knew the central limit theorem, we would know that ")#mi("{\\rho(x)}")#text(" is in fact ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text(", but let us pretend that we did not yet know this fact.) Thus, for any test function ")#mi("{\\varphi}")#text(", we expect ")#metadata(none) <tao-f9594884e4e4580f74ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("{\\bf E} \\varphi( Z_n ) \\approx {\\bf E} \\varphi( Z_{n-1} ) \\approx \\int_{\\bf R} \\varphi(x) \\rho(x)\\ dx.")]]

#text("Now let us try to combine this with ")#link(<tao-cb04eeab181fd02dd8b2>)[#text("(30)")]#text(". We assume ")#mi("{\\varphi}")#text(" to be smooth, and Taylor expand to third order:")

#tao-aligned(keep: true)[


#tao-math("\\varphi( Z_n )  & = \\varphi(\\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1}) + \\frac{1}{\\sqrt{n}} X_n \\varphi^{\\prime}(\\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1})", block: true)



#tao-math(" & + \\frac{1}{2n} X_n^2 \\varphi^{\\prime\\prime}(\\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1}) + O( \\frac{1}{n^{3/2}} )", block: true)
]

#text("Taking expectations, and using the independence of ")#mi("{X_n}")#text(" and ")#mi("{Z_{n-1}}")#text(", together with the normalisations on ")#mi("{X_n}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\varphi( Z_n ) = {\\bf E} \\varphi(\\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1}) + \\frac{1}{2n} \\varphi^{\\prime\\prime}(\\frac{\\sqrt{n-1}}{\\sqrt{n}} Z_{n-1}) + O( \\frac{1}{n^{3/2}} ).")]]

#text("Up to errors of ")#mi("{O( \\frac{1}{n^{3/2}} )}")#text(", one can approximate the second term here by ")#mi("{\\frac{1}{2n} \\varphi^{\\prime\\prime}(Z_{n-1})}")#text(". We then insert ")#link(<tao-f9594884e4e4580f74ae>)[#text("(31)")]#text(" and are led to the heuristic equation")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\varphi(x) \\rho(x) \\approx \\int_{\\bf R} \\varphi(\\frac{\\sqrt{n-1}}{\\sqrt{n}} x) \\rho(x) + \\frac{1}{2n} \\varphi^{\\prime\\prime}(x) \\rho(x)\\ dx + O( \\frac{1}{n^{3/2}} ).")]]

#text("Changing variables for the first term on the right hand side, and integrating by parts for the second term, we have")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\bf R} \\varphi(x) \\rho(x)  & \\approx \\int_{\\bf R} \\varphi(x) \\frac{\\sqrt{n}}{\\sqrt{n-1}} \\rho(\\frac{\\sqrt{n}}{\\sqrt{n-1}} x)", block: true)



#tao-math(" & + \\frac{1}{2n} \\varphi(x) \\rho^{\\prime\\prime}(x)\\ dx + O( \\frac{1}{n^{3/2}} ).", block: true)
]

#text("Since ")#mi("{\\varphi}")#text(" was an arbitrary test function, this suggests the heuristic equation")

#align(center)[#tao-fit-display[#mitex("\\rho(x) \\approx \\frac{\\sqrt{n}}{\\sqrt{n-1}} \\rho(\\frac{\\sqrt{n}}{\\sqrt{n-1}} x) + \\frac{1}{2n} \\rho^{\\prime\\prime}(x) + O( \\frac{1}{n^{3/2}} ).")]]

#text("Taylor expansion gives")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sqrt{n}}{\\sqrt{n-1}} \\rho(\\frac{\\sqrt{n}}{\\sqrt{n-1}} x) = \\rho(x) + \\frac{1}{2n} \\rho(x) + \\frac{1}{2n} x \\rho^{\\prime}(x) + O( \\frac{1}{n^{3/2}} )")]]

#text("which leads us to the heuristic ODE")

#align(center)[#tao-fit-display[#mitex("L\\rho(x) = 0")]]

#text("where ")#mi("{L}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_operator")[#text("Ornstein-Uhlenbeck operator")]

#align(center)[#tao-fit-display[#mitex("L \\rho(x) := \\rho(x) + x \\rho^{\\prime}(x) + \\rho^{\\prime\\prime}(x).")]]

#text("Observe that ")#mi("{L \\rho}")#text(" is the total derivative of ")#mi("{x \\rho(x) + \\rho^{\\prime}(x)}")#text("; integrating from infinity, we thus get")

#align(center)[#tao-fit-display[#mitex("x \\rho(x) + \\rho^{\\prime}(x) = 0")]]

#text("which is ")#link(<tao-4ad815618f703e2f509a>)[#text("(21)")]#text(", and can be solved by standard ODE methods as ")#mi("{\\rho(x) = c e^{-x^2/2}}")#text(" for some ")#mi("{c}")#text("; the requirement that probability density functions have total mass ")#mi("{1}")#text(" then gives the constant ")#mi("{c}")#text(" as ")#mi("{\\frac{1}{\\sqrt{2\\pi}}}")#text(", as we knew it must.")

#text("The above argument was not rigorous, but one can make it so with a significant amount of PDE machinery. If we view ")#mi("{n}")#text(" (or more precisely, ")#mi("{\\log n}")#text(") as a time parameter, and view ")#mi("{\\phi}")#text(" as depending on time, the above computations heuristically lead us eventually to the ")#link("http://en.wikipedia.org/wiki/Fokker%E2%80%93Planck_equation")[#text("Fokker-Planck equation")]#text(" for the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(",")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\rho(t,x) = L \\rho")]]

#text("which is a linear parabolic equation that is fortunate enough that it can be solved exactly (indeed, it is not difficult to transform this equation to the linear heat equation by some straightforward changes of variable). Using the spectral theory of the Ornstein-Uhlenbeck operator ")#mi("{L}")#text(", one can show that solutions to this equation starting from an arbitrary probability distribution, are attracted to the gaussian density function ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text(", which as we saw is the steady state for this equation. The stable nature of this attraction can eventually be used to make the above heuristic analysis rigorous. However, this requires a substantial amount of technical effort (e.g. developing the theory of Sobolev spaces associated to ")#mi("{L}")#text(") and will not be attempted here. One can also proceed by relating the Fokker-Planck equation to the associated stochastic process, namely the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(", but this requires one to first set up stochastic calculus, which we will not do here. (The various Taylor expansion calculations we have performed in these notes, though, are closely related to stochastic calculus tools such as ")#link("http://en.wikipedia.org/wiki/It%C5%8D%27s_lemma")[#text("Ito’s lemma")]#text(".) Stein’s method, discussed above, can also be interpreted as a way of making the above computations rigorous (by not working with the density function ")#mi("{\\rho}")#text(" directly, but instead testing the random variable ")#mi("{Z_n}")#text(" against various test functions ")#mi("{\\varphi}")#text(").")

#text("This argument does, though highlight two ideas which we will see again in later notes when studying random matrices. Firstly, that it is profitable to study the distribution of some random object ")#mi("{Z_n}")#text(" by comparing it with its predecessor ")#mi("{Z_{n-1}}")#text(", which one presumes to have almost the same distribution. Secondly, we see that it may potentially be helpful to approximate (in some weak sense) a discrete process (such as the iteration of the scheme ")#link(<tao-cb04eeab181fd02dd8b2>)[#text("(30)")]#text(") with a continuous evolution (in this case, a Fokker-Planck equation) which can then be controlled using PDE methods.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (99)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-670017")[#strong[#text("Solved – Central limit theorem proof not using characteristic functions - Everything about Math, Questions, Topics")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2022")]

#text("[…] Also, Stein's method is nothing short of black magic! You can find an exposition of the proof in section 6 of this link. You'll find other proofs of the CLT in the link as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Square Root Cancellation Heuristic | George Shakan")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-680277")[#strong[#text("The Square Root Cancellation Heuristic | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2023")])]

#text("[…] This is the so-called square root cancellation. If we take a random vector of dimension with randomly generated entries, we expect the order of the sum to be . Here , and it is a general phenomenon that most of the sums will lie between, say, and . This general principle goes much deeper than vectors and turns out to be very well-studied concept in several areas of mathematics (see this post for Number Theory or this post for Probability). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-684742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2024")])]

#text("Dear Terry,")

#text("There is maybe a typo immediately after (26) when writing the “completing the square”.")

#emph[#text("[Sorry, I don’t see any typo; could you be more specific? -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-685213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2024")])]

#text("The Big-O notations you use when you talk about random variables are Big-O-in-probability right?")

#link("https://en.wikipedia.org/wiki/Big_O_in_probability_notation")[#text("https://en.wikipedia.org/wiki/Big_O_in_probability_notation")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-685217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("No; those are usually labeled with an additional subscript or other decoration (in the case of the Wikipedia article, one would subscript the big-O notation by p to indicate that it is a big-O-in-probability).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686054")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("Dear professor Tao:")

#text("In the weak Berry-Esséen theorem, why can one assume the third derivative of ")#mi("\\varphi")#text(" to be ")#mi("O(\\varepsilon^{-3})")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2024")])]

#text("This follows from the definition of ")#mi("\\varphi")#text(". It may help to first change variables to ")#mi("\\varphi(x) = \\varepsilon^{-1} \\int_{-\\infty}^0 \\eta( x - t/\\varepsilon)\\ dt")#text(" and then differentiate under the integral sign to see this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2024")])]

#text("Thank you for replying, professor Tao. But doesn’t this also follow from three applications of the mean value theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2024")])]

#text("There are multiple ways to establish this bound.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2024")])]

#text("Dear professor Tao:")

#text("May I ask for a little more explanation on how to optimize in epsilon to conclude (20)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-686063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2024")])]

#text("I got this step, thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-692644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2026")])]

#text("Dear Prof. Tao,")

#text("Perhaps this is a kind of silly question, but I didn’t see any description of continuity in the statement of Lévy’s continuity theorem. Did I miss something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-692661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2026")])]

#text("I am ")#link("https://claude.ai/share/33cf9707-7888-40bf-95d7-d30f9c29e12c")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-693173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2026")])]

#text("Dear Prof. Tao:")

#text("I’m not familiar with Fourier analysis, so I find the proofs of the Central Limit Theorem and its various variants using Fourier-analytic methods somewhat obscure and difficult to understand. I’d like to ask: what exactly is the reason that CLT and its variants (like ")#emph[#text("vector-valued CLT, complex CLT, Lindeberg CLT, Berry-Esseen theorem")]#text(") are particularly well-suited to being proved using Fourier analysis rather than other approachs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-2/#comment-693183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2026")])]

#text("The Fourier transform is exceptionally suitable for studying convolution, which determines the distribution of the sum of independent variables. Ultimately, this is because convolution is a bilinear, translation-invariant operation, suggesting that it is amenable to the representation theory of the translation action, which is in turn described by the Fourier transform.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c805a001d9440fba0fe77d9d48b728d794bd507990cb8c64fb1e0f4cc3d66e27-b0495b22c8cd5c2dc12753a3cdc9ae1971ccb30d3ad9374d4b881e243bc9fb60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43101")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Very nice notes! Thank you!")

#text("Just a remark: in ")#link("http://arxiv.org/abs/0705.1224")[#text("http://arxiv.org/abs/0705.1224")]#text(" and ")#link("http://arxiv.org/abs/0908.0391")[#text("http://arxiv.org/abs/0908.0391")]#text(", one can find some applications of Stein’s method in random matrix theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43105")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("More applications of Stein’s method in random matrix theory appear ")#link("http://www.mathematik.uni-bielefeld.de/fgweb/Preprints/fg03018.pdf")[#text("here")]#text(", ")#link("http://arxiv.org/abs/math.PR/0509441")[#text("here")]#text(", and ")#link("http://arxiv.org/abs/math/0701464")[#text("here")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43102")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("A couple of very minor typos:")#linebreak()#text(" 1) in the second-last paragraph of section 3, it should be “to those terms in (17)”")#linebreak()#text(" 2) Beginning of section 4: “Lindeberg observed that” – the comma between observed and that is not correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43103")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("I think there might be a parsing error around “where L is the rhox” in the last section… or maybe I just don’t get it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Peccati")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43107")[#strong[#text("Giovanni Peccati")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Hi Terry,")

#text("thank you for these inspiring lecture notes !")

#text("Small typo, in the brackets starting 5 lines after formula (30) (If we secretely…) there is a square root missing in the normalizing factor of the Gaussian density.")

#text("Best, G")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Thanks for the corrections!")

#text("Somewhat embarrassingly, I was only dimly aware of the work on applying Stein’s method to random matrices; it seems that the fraction of literature on the subject that I am familiar with is still not fully representative. Thanks for the references!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af45d79e5b098ceb6de38fde366406c35900957c8d6b7df4dd04d7299dee2e9f-577326d8a604a42aebab67c6282a15db482f82e7fc3459676170911250f1955e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim vB")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43125")[#strong[#text("Tim vB")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Dear Terry,")#linebreak()#text(" thanks for this marvelous lecture notes!")#linebreak()#text(" I hope the following two remarks are not too pedantic, but both points made me stop for a short while:")#linebreak()#text(" 1. The part “now we get the Fokker-Planck-Equation and that can be solved exactly” confused me a bit, because the Fokker-Planck-Equation can “usually” not be solved excatly – the one for the Ornstein-Uhlenbeck process can. It’s of course clear from the context that you mean exactly this, but I think it would help me if you redundantly write ” the above computations heuristically lead us eventually to the Fokker-Planck equation of the Ornstein-Uhlenbeck process”.")#linebreak()#text(" 2. Wouldn’t most people say the Ornstein-Uhlenbeck process is the solution of a stochastic ordinary differential equation (stochastic ODE) rather than a stochastic partial differential equation?")

#emph[#text("[Fair enough; I’ve adjusted the notes accordingly.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab534a8f210b7cf9df4446d8db37ac4c66c9daafd983558d524c978586bd377-240112ddbb705ed9e4227fe8af6e34f039e5a6a1a89b991de7041335fc3c4c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43248")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2010")])]

#text("More tedious [potential] corrections:")

#text("1. Two Eqs. after Eq. (14): P(…)\\leq E(…)")

#text("2. Eq (16): square in denominator correct?")

#text("3. Theorem 4,5: F should be phi (or vice versa)")

#text("4(a). Proof of Theorem 5: several missing parentheses? (or E symbols), e.g.")

#text("\\displaystyle {\\bf E} (\\varphi(Z_n) – \\varphi(W_n)) = o(1).")

#text("This is done quite a lot, so I will assume it was done on purpose.")

#text("4(b). telescoping sum, multiply by -1")

#text("5. After Eq. (26): tex error for bound on f. I assume you want")

#text("{f(x) = O_\\varphi( 1/|x|)}")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of salazar")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43265")[#strong[#text("salazar")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2010")])]

#text("Second 1 and 3. For 4, since W_n is a RV, there should be no ambiguity. For 2, I haven’t been able to see how to replace \\hat{eta}.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2010")])]

#mi("\\hat \\eta")#text(" can be bounded by an absolute constant. (The denominator of ")#tao-math("1+\\epsilon \\left|t\\right|", block: false)#text(" was a relic from an earlier version of the argument, but is now redundant due to the restriction to the range ")#tao-math("\\left|t\\right| \\leq c/\\epsilon", block: false)#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43273")[#strong[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] the central limit theorem from the fundamental solution of the heat equation (cf. Section 7 of Notes 2), although the derivation is only heuristic because one first needs to know that some limiting […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ecbbe842fcf76149a4a3f6d3c570043796f02a77cd75521103a7cafa52ed3c2-e17da03456178531679bb993f76635fb927e60f7a9c2b9ef576253d75296abfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Naive")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43414")[#strong[#text("Andreas Naive")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2010")])]

#text("Excellent notes!")

#text("Just a small fix:")

#text("In (30), ")#mi("\\frac{1}{\\sqrt{n-1}}")#text(" should be ")#mi("\\frac{1}{\\sqrt{n}}")#text(", which slightly simplify the following argument.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43465")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] vein, we may apply the truncation argument (much as was done for the central limit theorem in Notes 2) to reduce the semi-circular law to the bounded case: Exercise 5 Show that in order to prove the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43564")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] an interesting analogue in the freely independent setting. For instance, the central limit theorem (Notes 2) for averages of classically independent random variables, which roughly speaking asserts that such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43732")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2010")])]

#text("Dear Prof. Tao,")

#text("I have some problems on Ex 12 (Esseen concentration inequaity) and Thm 3:")

#text("Ex 12. Let ")#mi("r \\rightarrow \\infty")#text(", the value on LHS of (9) should be 1, while that on RHS should be 0. Then the inequality breaks down.")

#text("Thm 3. In the paragraph immediately below (14), I do not understand how to apply an integration by parts argument, since one does not know the exact distribution of ")#mi("X")#text(".")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2010")])]

#text("Ah, there was a factor of r^d missing in the concentration inequality; it is fixed now.")

#text("As for Theorem 3, the point is that the distribution of X is the Stieltjes derivative of the cumulative distribution function ")#mi("F(a) := {\\bf P}(X \\leq a)")#text(" of X; ")#mi("{\\bf E} f(X) = \\int_{-\\infty}^\\infty f dF")#text(". If we integrate the latter integral by parts, we see that small perturbations of F in the uniform norm lead to small perturbations of ")#mi("{\\bf E} f(X)")#text(" when f has bounded total variation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43733")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2010")])]

#text("Sorry, it is Ex 11.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6901e6f3a4aeff0c9e65a571b3513ba18cd5a2cf1123618d90eced15b554cae4-0dec33f410a763d82075e508bb8e1c6467df7189ee3996462be6e18d41e0b168.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YP")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43740")[#strong[#text("YP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2010")])]

#text("The derivation of Gaussian in Section 7 is amazing! (To me it seems very much in the spirit of physics). Isn’t it strange that to our brain it seems very natural to make this argument as it is, whereas for scientific community you actually need to add days of hard work (in Sobolev spaces etc)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vedadi")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43744")[#strong[#text("vedadi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2010")])]

#text("Dear Prof. Tao,")

#text("We know that for ")#mi("X_1, X_2, ...")#text(" i.i.d mean zero, variance one random variables, ")#mi("\\frac{S_n}{n^{a}}")#text(" converges in distribution to the point mass at zero, ")#mi("\\delta_{0}")#text(" and standard normal r.v. ")#mi("Z")#text(" for ")#mi("a=1, 1/2")#text(" respectively. Do we have convergence in distribution for other values ")#mi("0<a<1 ?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: The least singular value « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43799")[#strong[#text("254A, Notes 7: The least singular value « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2010")])]

#text("[…] understand this walk, we apply (a slight variant) of the Berry-Esséen theorem from Notes 2: Exercise 1 Show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43823")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("Dear Prof. Tao,")

#text("I finished reading this note. As usual, I have some problems :-)")

#text("1. For the moment method, we first apply Chernoff bound (3), and then we can assume that ")#mi("Z_n")#text(" are uniformly guassian. But when proving Chernoff bound in Note 1, we have used the identity ")#mi("e^{A+B}=e^A e^B")#text(". When we are dealing random matrices, if we also use Chernoff bounds, then it seems we shall have some trouble.")

#text("2. I still do not know how to prove the conclusion in Ex 11. Suppose one is trying to bound the easy probability (with ")#mi("d=1")#text(" and ")#mi("x_0=0")#text("):")

#tao-math("P\\{\\left|X\\right| \\leq r\\}", block: false)#text(".")

#text("By Fourier transform, we obtain")

#tao-math("(P\\{\\left|X\\right| \\leq r\\}=) C\\int_{\\bf R} \\frac{sin rt}{t} F_X(t)=C\\int_{\\left|t\\right|\\leq \\epsilon/r}+\\int_{\\left|t\\right|>\\epsilon/r} \\frac{sin rt}{t} F_X(t).", block: false)

#text("Clearly, to show ")#tao-math("P\\{\\left|X\\right| \\leq r\\}", block: false)#text(" has the same bound as in exercise, we need to show that ")#tao-math("\\int_{\\left|t\\right|>\\epsilon/r} \\frac{sin rt}{t} F_X(t)", block: false)#text(" has that bound. I don’t know to show this.")

#text("3. A small typo: the ")#mi("F")#text(" in Theorem 5 seems to be ")#mi("\\phi")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-43835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("1. For random matrices, one does not apply the Chernoff bound to the matrix directly, but to other scalar expressions related to that matrix, e.g. linear combinations of the matrix entries.")

#text("2. One first needs to replace the sharp cutoff to the ball of radius r by a smoother cutoff. This is the method of smoothing sums:")

#link("http://www.tricki.org/article/Smoothing_sums")[#text("http://www.tricki.org/article/Smoothing_sums")]

#text("3. Thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-44671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2010")])]

#text("These notes are very helpful, thank you very much!")#linebreak()#text(" I do not have a strong background in the Fourier analysis, could you point me to a refernce to the solutions to Exercise 11 and Exercise 15?")

#text("A few comments I have:")

#text("In Exercise 13, the characteristic function should be $e^{i\\mu}t…$ instead of $e^{-i\\mu}t$?")

#text("In Part 1 of this note, the “N” in the last two singled-out equations should be replaced with “N_n”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-44688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("Thanks for the corrections,’")

#text("For Ex11, see Lemma 7.17 of my book “Additive combinatorics” with Van Vu. Ex15 can be found in most graduate texts in probability, including those listed at the link given.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahmet Arivan")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-46239")[#strong[#text("Ahmet Arivan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2010")])]

#text("Great notes. I have probably a very stupid question. But in the Stein method section, it is claimed that if f(t) =O(1/1+|t|) and f'(t)=O(1) then tf(t) is Lipschitz with constant of O(1). Is it possible to give a hint on why this is true?")

#text("Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-46303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2010")])]

#text("Ah yes, that requires an additional argument (which needs the Lipschitz hypothesis on phi). I’ve modified the text accordingly (and in particular weakened the Berry-Esseen type claim, since the Lipschitz property is not present in that case.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-187416")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2012")])]

#text("Small thing: I think the last part of the proof of Theorem 6, showing that ")#tao-math("f^{\\prime}(x)=O_\\phi(1/(1+\\left|x\\right|))", block: false)#text(", with implicit constant linear in the bounded Lipschitz norm of ")#mi("\\phi")#text(", belongs just after this proof since we aren’t assuming ")#mi("\\phi")#text(" is Lipschitz here. – or leave it in with modification of the phrase “using the Lipschitz nature of ")#mi("\\phi")#text("” :)")

#emph[#text("[Corrected by assuming $\\phi$ to be Lipschitz. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-47986")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Regarding Section 7: I had always vaguely figured that if ")#mi("Z_n")#text(" were going to converge to a particular distribution, it would have to converge to an eigenfunction of the Fourier transform. Do you know of any heuristic (or rigorous!) derivations of the CLT using this idea?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-47989")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("I think the more accurate statement would be that a stable law ")#mi("Z")#text(" should have a Fourier transform whose logarithm is an eigenfunction of the scaling operation, since the convolution ")#mi("Z_1+Z_2")#text(" of ")#mi("Z")#text(" with itself needs to be a rescaling of ")#mi("Z")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d703f698a4fa9a3fc870dc71ed44c8a1ad606a9afeb76142da2460b611b076b6-c7a24c16d5796c6745ebd6015fd217d5bd5dac4bf319ea6d476c85a867c19bf4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-48129")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")])]

#text("At the beginning of the proof of theorem 1, it seems that the first “for sufficiently small t” is not needed. Only the second is needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-50775")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("Hi Terry,")

#text("I am a bit puzzled about Exercise 1. I am thinking of $Z_n$ as a map from $n$ copies of $\\Omega$ to $R$. If this is the case, what does it mean to say $Z_n$ converges almost surely? Isn’t the underlying sample space varying as $n$ varies?")

#text("The CLT says something about the push forward of the measures from $\\Omega^n$ to $R$ and I can understand it. So even if the sample space changes, it doesn’t matter as we are comparing the push forward measures. In the strong LLN case, it still sounds fine to me if I interpret the almost sure convergence as almost sure convergence to the constant map on $\\Omega^n$ given by the expectation. But I am having trouble trying to understand what Exercise 1 means.")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-50776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("The intent here is to work in a common extension of all these probability spaces, where we have an infinite sequence ")#mi("X_1, X_2, X_3, \\ldots")#text(" of iid random variables (and this is also the correct way to interpret the strong law of large numbers).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-50789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2011")])]

#text("Dear Prof. Tao,")

#text("Let ")#mi("M(t)")#text(" be the moment generating function of a non degenerate r.v ")#mi("X")#text(". Then is ")#mi("c(t)=\\log M(t)")#text(" always strictly increasing and strictly convex on ")#mi("[0, \\infty)")#text(" ?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-70959")[#strong[#text("The law of large numbers and the central limit theorem | Controlled Complexity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")]

#text("[…] theorem (CLT). There are excellent resources on the net for LLN and CLT. For example, this and this are highly recommended readings. This blog will play a complementary with figures and animations to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-87760")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2011")])]

#text("Can anyone help me to compute the expected waiting time of the first occurrence of the patten, say, TTHT. here ")#mi("P(H)=p, P(T)=q")#linebreak()#text(" is there a general approach to solve this sort of problems?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-107228")[#strong[#text("Diffusion in Ehrenfest wind-tree model « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2011")]

#text("[…] of the word “abnormal” comes by comparison with Brownian motion and/or central limit theorem: once we know that the diffusion is “sublinear” (maybe after removing the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-133572")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")])]

#text("Dear Prof. Tao,")

#text("Let ")#mi("S_n")#text(" be the simple symmetric random walk in one dimension.")#linebreak()#text(" Assume that K is a large constant and ")#mi("0<c<1.")#text(" I need a lower bound for the following probability which does not depend on ")#mi("N.")

#tao-math("P(\\max_{n \\leq N}\\left|S_n\\right|\\leq Kc\\sqrt{N}, \\left|S_N\\right|\\leq c\\sqrt{N})", block: false)

#text("What is the idea behind finding a lower bound for this type of quantities?")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/656bdc976f25d5e760700ad172bc96d8852498beb8c77316d849abf46c7fac54-8e0c65a62fe45b484091572b10958d8e1fec4a7cf059c75c61a6ca567b133a17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Kohn")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-180669")[#strong[#text("Robert Kohn")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2012")])]

#text("Hi, thanks for insightful presentation. My question is, suppose that the ")#mi("x_i")#text(" are independent with finite third moments, zero mean and unit variance. What can we say about the convergence of the third moment of the normalized sum ?")#linebreak()#text(" In addition, what results of the same kind can we get if the ")#mi("x_i")#text(" are correlated?")

#text("Thanks,")#linebreak()#text(" Robert Kohn")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194492")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("Regarding Exercise 1: I don’t see how the intuition help. What I thought is to give a lower bound of ")#mi("P(Z_n>\\epsilon)")#text(" for some ")#mi("\\epsilon>0")#text(", which is from the definition of convergence in probability. Could you elaborate the intuition? Why would independence help here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("Actually, one needs a lower bound on ")#tao-math("{\\bf P}(\\left|Z_n-Z_m\\right| \\geq \\varepsilon)", block: false)#text(" to contradict convergence in probability to an unspecified limit (lower bounding ")#mi("{\\bf P}(Z_n \\geq \\varepsilon)")#text(" merely prevents convergence in probability to zero, or to a non-positive random variable). But if one can quantify some approximate independence between ")#mi("Z_n")#text(" and ")#mi("Z_m")#text(" for n,m widely separated, then this, together with the central limit theorem, can supply the desired lower bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194582")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("An attempt is that both ")#mi("Z_n")#text(" and $Z_{2n}$ converge to ")#mi("Z\\sim N(0,1)")#text(" in distribution by CLT. Thus one has ")#mi("\\frac{\\sqrt{2}Z_{2n}-Z_n}{\\sqrt{2}-1}\\to Z")#text(". I still don’t see how one can bound ")#tao-math("{\\Bbb P}(\\left|Z_{2n}-Z_n\\right|\\geq\\epsilon)", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#mi("Z_{2n}")#text(" and ")#mi("Z_n")#text(" are still quite correlated, so it is a bit tricky to separate them by ")#mi("\\varepsilon")#text(". Try ")#mi("Z_{Mn}")#text(" and ")#mi("Z_n")#text(" instead for some large M (larger than ")#mi("1/\\varepsilon^2")#text(" or so). The point is that these two random variables are almost independent (more precisely, ")#mi("Z_n")#text(" and ")#mi("Z_{Mn} - M^{-1/2} Z_n")#text(" are independent) which makes it difficult for them to stay so close to each other so often.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194589")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("What puzzles me is the use of “independence” here. As a beginner, I only think that ")#mi("X")#text(" and ")#mi("Y")#text(" are independent if and only if ")#mi("P(X\\in A,Y\\in B)=P(X\\in A)P(Y\\in B)")#text(" where ")#mi("A")#text(" and ")#mi("B")#text(" are Borel sets in the corresponding Borel sigma algebra. Why does this concept have anything to do with the “distance” between these random variables? It’s quite intuitive though: two things are “independent”, then they should not be too “close” to each other. But I don’t see the connection. (Eventually I come up with something like ")#mi("E(XY)=E(X)E(Y)")#text(". Is this the point? )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-194631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("If X and Y are independent, then ")#mi("{\\bf P}( X < -\\varepsilon \\wedge Y > \\varepsilon)")#text(" (for instance) will be large if ")#mi("{\\bf P}(X <-\\varepsilon)")#text(" and ")#mi("{\\bf P}(Y > \\varepsilon)")#text(" are large, thus giving some separation between X and Y. (One can also in principle work with expectations, but this requires some hypotheses on absolute integrability that one then has to justify separately.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-196705")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("Finding a lower bound for ")#tao-math("{\\bf P}(\\left|Z_{n}-Z_{Mn}\\right|\\geq\\varepsilon)", block: false)#text(" is still not “obvious” to me. I tried ")#tao-math("{\\bf P}(\\left|Z_{n}-Z_{Mn}\\right|\\geq\\varepsilon)\\geq{\\bf P}(Z_{n} < -\\varepsilon\\wedge Z_{Mn} > \\varepsilon)", block: false)#text(". And the independence between ")#mi("Z_n")#text(" and ")#mi("Z_{Mn}-M^{-1/2}Z_n")#text(" gives ")#mi("{\\bf P}(Z_{n}<-\\varepsilon\\wedge Z_{Mn}-M^{-1/2}Z_n>\\varepsilon)={\\bf P}(Z_{n}<-\\varepsilon){\\bf P}(Z_{Mn}-M^{-1/2}Z_n>\\varepsilon)")#text(". Since ")#mi("M")#text(" is chosen such that ")#mi("M> 1/\\varepsilon^2")#text(", ")#mi("M^{-1/2}<\\varepsilon")#text(" implies that this is very close to the desired estimate. But I don’t see the way to bound ")#mi("{\\bf P}(Z_{n}<-\\varepsilon)")#text(" and ")#mi("{\\bf P}(Z_{Mn}-M^{-1/2}Z_n>\\varepsilon)")#text(". Since I haven’t use CLT so far, I am wondering there must be lack of something here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-196709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("The CLT describes the limiting value of ")#mi("P(Z_n < -\\varepsilon)")#text(" in the limit as ")#mi("n \\to \\infty")#text(" with ")#mi("\\varepsilon")#text(" fixed, and similarly for ")#mi("Z_{Mn} - M^{-1/2} Z_n")#text(" (which is basically a rescaled variant of ")#mi("Z_{(M-1)n}")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-196715")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("I found in some book that random variables ")#mi("X_n")#text(" converging in distribution to $X$ is defined as (and the author also calls it “weak convergence”)")#linebreak()#text(" ")#mi("\\lim_{n\\to\\infty}\\int f(x)dP^{X_n}=\\int f(x)dP^X")#text(" for all bounded, continuous function ")#mi("f")#text(". Is it “equivalent” to the definition in [254A Note4 Exercise 18](")#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")]#text(")? But in [245B Note 11](")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")]#text("), weak convergence is convergence in weak topology. I am totally confused with the terminologies.")

#text("[I don’t know how to give links like people do in MathOverflow.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-196721")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("Yes, these notions are all connected to each other; see Exercise 23 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]#text(" . (Though, strictly speaking, ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague convergence")]#text(" of measures – which is equivalent to convergence in distribution – is an example of weak* convergence rather than weak convergence.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dc626304da0365f0cc3e2f2c5a5c458fa1a133eb94a8a1134d1c5a71c2c879d-8a4166634463b1d60306d2ddccc9023d39f5414172a4d39ffa23b9183f0d576d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-220479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2013")])]

#text("Hi professor Tao,")

#text("does the CLT hold if we substitute the hypothesis of finite mean and variance with the hypothesis of finite second order moment, ")#mi("{\\bf E} X^2")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-220558")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2013")])]

#text("By Holder’s inequality (or the Cauchy-Schwarz inequality), finite second order moment is equivalent to finite mean and variance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dc626304da0365f0cc3e2f2c5a5c458fa1a133eb94a8a1134d1c5a71c2c879d-8a4166634463b1d60306d2ddccc9023d39f5414172a4d39ffa23b9183f0d576d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-222328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2013")])]

#text("Thanks a lot for the answer! By the way, does { \\Z_n := \\frac{S_n – n \\mu}{\\sqrt{n} \\sigma} to N(0,1)} implies that {\\frac{S_n}{n} to N(\\mu,\\frac{\\sigma^2}{n}) }? This implication seems quite weird to me, since {n to \\infty}, but on a book about generalized polynomial chaos I fount the following sentence: “the numerical average of a sequence of i.i.d. random variables will converge, as n is increased, to a Gaussian distribution { N(\\mu,\\frac{\\sigma^2}{n}) } […]”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-222376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2013")])]

#text("If one uses a rescaled notion of convergence, then this statement is true, although if one uses unrescaled versions of convergence (e.g. convergence in distribution, vague convergence, total variation convergence, etc.) then the statement is either false or trivially true, depending on exactly which mode of convergence is specified. It is somewhat of an abuse of notation to refer to convergence of random variables without specifying the exact nature of the convergence, although for informal mathematical discussion it is generally permissible to be a bit loose in this regard.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-228068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2013")])]

#text("(i) In Remark 1 the word theorem is missing from “central limit theorem.”")#linebreak()#text(" (ii) The equation following the sentence “From the bounded density of $G$ and the rapid decrease of $\\eta$ we have…” I think the first term should be an expectation and not probability.")#linebreak()#text(" (iii) Do you use any convention for capitalizing theorems? For example, you write “central limit theorem” in lower case but “Taylor” expansion in upper case.")#linebreak()#text(" (iv) What is the diagonalisation argument in “By a diagonalisation argument, we conclude that there exists a sequence…”? Is there a Wikipedia page? Thanks.")

#emph[#text("[Corrected, thanks. Taylor is a ")#link("http://en.wikipedia.org/wiki/Proper_noun")[#text("proper noun")]#text(" and is therefore capitalised in English. The ")#link("http://en.wikipedia.org/wiki/Diagonalization_argument")[#text("diagonalisation argument")]#text(", originally due to Cantor, refers to any procedure in which one repeatedly extracts sequences with various properties and then passes to a diagonal subsequence with an even better property. Actually, the ")#link("http://en.wikipedia.org/wiki/Arzela-ascoli_theorem")[#text("Arzela-Ascoli diagonalisation argument")]#text(" is closer in spirit to the one used here than the Cantor diagonalisation argument.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-229139")[#strong[#text("חסם צ'רנוף, חסם אנטרופיה ומה שביניהם | One and One")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")]

#text("[…] נדבר עליו כאן, אתם מוזמנים לקרוא עליו בבלוג של טרי טאו. אבל גם אם פשוט נאמין שהאינטגרל הזה קרוב מספיק […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-461365")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] theorem (including some further proofs, such as one based on Stein’s method) can be found in this blog post. Some further variants of the central limit theorem, such as local limit theorems, stable laws, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ef37ef9991c2a36a25f2b607b4d6f5e0a63c9ae82472da55dcdbb9f424730f8-92467fa5bbe8c5315439ab9c859395864633e8e4512ca7a7dbfe5d5d92550f72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vladimir")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-464453")[#strong[#text("Vladimir")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("Dear Tao, I do not get it why in the proof of theorem 7 the t is uniformly distributed even if independence of Z_n:i is clear to me? Could you help please?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-464459")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#mi("t")#text(" is uniformly distributed by definition. In less probabilistic language, the identity being asserted here is that")

#mi("\\displaystyle X_n f(Z_{n,i} + \\frac{1}{\\sqrt{n}} X_n) = X_n f(Z_{n,i}) + X_n^2 \\frac{1}{\\sqrt{n}} \\int_0^1 f^{\\prime}(Z_{n,i} + \\frac{s}{\\sqrt{n}} X_n)\\ ds")

#text("which is of course a special case of the fundamental theorem of calculus.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bda3e808d3b54372b99c58ceb48988864b2b046ed59b532f9abfbcb521be3de-a8317c9e42825cd8cabb5ad327f1c57c754da432e68a7adf110e64523a15499b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vladimir")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-464508")[#strong[#text("Vladimir")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("Many thanks, now I get it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-465756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2016")])]

#text("Dear Prof. Tao, in exercise 8, shouldn’t the derivative be evaluated at 0?")

#emph[#text("[Exercise reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33fb108daa38f8d2af8eae8357760b779b7f01d5ed07146b52a05dc1a695d2cb-a5d042c0bc3b10f1592dff851569a64586fa81e2ab19812ce7c93561d428ca94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Kumar Bagaria")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-468182")[#strong[#text("Vivek Kumar Bagaria")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2016")])]

#text("Great notes! How does the ‘Vector-valued central limit’ behave if the dimension of the vector scales with the number of samples $n$ ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-468204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2016")])]

#text("This basically comes down to the dependence of constants of the Berry-Esseen theorem on dimension. The best bound I know of in this direction comes from ")#link("http://www.ams.org/mathscinet-getitem?mr=1965117")[#text("this 2003 paper of Bentkus")]#text(", but there may be further improvements since then.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-468215")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2016")])]

#text("why is the third moment important in that paper? CLT is about second moments right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-468218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2016")])]

#text("If one just wants qualitative convergence (with no rate), then second moment conditions suffice, but in order to obtain quantitative bounds one needs some higher moment assumption (to deal with the errors caused by truncation arguments). Also one can get faster rates of convergence than Berry-Esseen if the original distribution matches third or higher moments with the gaussian, as can be seen from the Lindeberg argument (or from the Fourier argument).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/319b487f0982a89e5d58572ba2bde281c7ad310f849923fa2889a445ba98de0a-82b024e7ff4c12c1c879699c524b7ea7712ff4c172457884148112c431995099.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sahiba")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-474153")[#strong[#text("Sahiba")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2016")])]

#text("Hey, can you help me in Exercise 1? I’m not able to solve it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b832586099b7bd3352edea234e12eb729d9dead00732f77ed19966ab735402f-34bbe549a98fdf9c1af047c749ea39e456696f26901ac00126f6fd7d39431017.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rawls")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-477684")[#strong[#text("John Rawls")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("These notes are immensely useful as always, but I have a small question: how exactly does the diagonalization argument in Section 1 work? We know that ")#mi("\\lim_{n\\to\\infty}\\mathbb{E}[f(Z_{n,\\leq N})]=\\mathbb{E}[f(G)]")#text(" for each fixed ")#mi("N")#text(" and all bounded continuous ")#mi("f")#text(", but it seems that the rate of convergence depends not only on ")#mi("N")#text(" but also on ")#mi("f")#text(". How then can we choose ")#mi("N_n")#text(" so that we get ")#mi("\\lim_{n\\to\\infty}\\mathbb{E}[f(Z_{n,\\leq N_n})]=\\mathbb{E}[f(G)]")#text(" for all ")#mi("f")#text(", or at least for all ")#mi("f")#text(" in some nice subclass? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-477714")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("One can work with some countable dense sequence of functions ")#mi("f_m")#text(" (e.g. indicator functions of ")#mi("(-\\infty,q_m)")#text(" with ")#mi("q_1,q_2,\\dots")#text(" an enumeration of the rationals will work). For each ")#mi("N")#text(", we then can find ")#mi("n_N")#text(" such that ")#mi("{\\bf E} f_m(Z_{n, \\leq N})")#text(" lies within ")#mi("1/N")#text(" of ")#mi("{\\bf E}(f_m(G))")#text(" for all ")#mi("m \\leq N")#text(" and ")#mi("n \\geq n_N")#text("; we can also ensure that the ")#mi("n_N")#text(" are increasing in ")#mi("N")#text(". Letting ")#mi("n \\mapsto N_n")#text(" be the inverse of ")#mi("N \\mapsto n_N")#text(" (or more precisely, ")#mi("N_n")#text(" is the first ")#mi("N")#text(" for which ")#mi("n_N \\geq n")#text(") we see that ")#mi("\\lim_{n \\to \\infty} {\\bf E}(f_m(Z_{n,\\leq N_n})) = {\\bf E}(f_m(G))")#text(" for all ")#mi("m")#text(", and by approximating a general ")#mi("f")#text(" using the ")#mi("f_m")#text(" we obtain convergence in distribution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b832586099b7bd3352edea234e12eb729d9dead00732f77ed19966ab735402f-34bbe549a98fdf9c1af047c749ea39e456696f26901ac00126f6fd7d39431017.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rawls")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-478068")[#strong[#text("John Rawls")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("Very clever, thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a8c0d5eb2350f01abae1f66d91357ff482183aa1e2d8b786515df4ccb515fc-8a1f824969c9882fdf50f442379dff8ac43e376b2eeb7108e371c48375f6488f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tpfly")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-478109")[#strong[#text("tpfly")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2017")])]

#text("Hi professor Tao,")#linebreak()#text(" I’m reading this series of notes and I have a question about the proof of Berry Esseen Theorem. You said that in order to establish (13) it suffices to establish (15) because of (8). But (8) requires that $\\varphi$ is Schwartz, or at least L1 and the fourier transform should be also L1, because the Fourier inverse is used. However the function in the proof of berry esseen is decreasing from $1$ to $0$, is (8) still available with this kind of functions?")#linebreak()#text(" Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a8c0d5eb2350f01abae1f66d91357ff482183aa1e2d8b786515df4ccb515fc-8a1f824969c9882fdf50f442379dff8ac43e376b2eeb7108e371c48375f6488f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tpfly")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-478117")[#strong[#text("tpfly")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("I found the answer of my question by taking a limit, that is, ")#mi("\\mathbb{E}\\varphi(X-a)=\\lim_{T\\to +\\infty}\\mathbb{E}[\\varphi(X-a)-\\varphi(X+T)]")#text(" and now the expectation is taken on a Schwartz function.")

#text("By the way I think there are some mistakes in this proof, the Fourier transform")#linebreak()#text(" ")#tao-math("\\displaystyle \\hat 1_{-\\infty,a]}=O(\\frac{1}{1+\\left|t\\right|})", block: false)#linebreak()#text(" should be")#linebreak()#text(" ")#tao-math("\\displaystyle \\hat 1_{-\\infty,a]}=O(\\frac{1}{\\left|t\\right|})", block: false)#linebreak()#text(" as there must be a singular point at 0, otherwise ")#mi("\\int1_{-\\infty,a]}")#text(" would be finite. And")#linebreak()#text(" ")#mi("\\displaystyle \\hat \\varphi(t) = \\hat 1_{(-\\infty,a]}(t) \\hat \\eta(t/\\epsilon)")#linebreak()#text(" should be")#linebreak()#text(" ")#mi("\\displaystyle \\hat \\varphi(t) = \\hat 1_{(-\\infty,a]}(t) \\hat \\eta(t\\epsilon)")#text(".")

#emph[#text("[New version of proof given – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-483436")[#strong[#text("Syntactic Translations of Berry-Esséen and the CLT | Polynomially Bounded")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")]

#text("[…] noted in Remark 29 here, one can improve the constant term by changing the replacement variables. In particular, it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-490411")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("A couple of typos in the proof of Theorem 23: In the first display after (15) it should say ")#mi("\\hat{\\eta}(\\varepsilon t)")#text(" (with no change to (16)), and above the last display it should say “if ")#mi("t\\le c/\\varepsilon")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cdaadf58661f723b55ec413c297133e7bc34c7ba05f711cf43eb552ab0d1304-e59406f6acfb92e0821532b1e085275b041d63734a37796ad8da9f3e74baae42.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankit")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-496257")[#strong[#text("Ankit")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Hi Prof. Tao,")

#text("Thanks for the wonderful notes. These are great for self-studying.")

#text("In Eq. (17), shouldn’t there be a summation over different choices of {a_1,\\ldots,a_m} as well? cf. with the case of k = 4 where terms are explicitly written.")#linebreak()#text(" It doesn’t affect the result in the end though because all of them have to be 2 for the non-vanishing term.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-496287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("One is summing over all choices of ")#mi("m")#text(" and of ")#mi("a_1,\\dots,a_m")#text(", yes (see the text immediately before and after (17)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cdaadf58661f723b55ec413c297133e7bc34c7ba05f711cf43eb552ab0d1304-e59406f6acfb92e0821532b1e085275b041d63734a37796ad8da9f3e74baae42.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankit")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-496295")[#strong[#text("Ankit")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("I see. Thank you for replying.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dae179f2bf31931641fa86906791cb696e40d8a09d8f76257d00c23970bb4891-95d1d7735975d5a8b8459de6c7207792e602eed5741c96b871f92165b5fd8ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Damodar")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-496799")[#strong[#text("Damodar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("Prof. Tao, I would be very glad if you could look at my blog post on ” A full proof of Berry-Esseen inequality in the Central Limit Theorem”.")

#text("Description: This theorem gives us the maximum convergence limit of the basin of attraction in the Central limit theorem.")

#text("Link: ")#link("http://www.physicslog.com/proof-berry-essen-theorem/")[#text("http://www.physicslog.com/proof-berry-essen-theorem/")]

#text("Thanks,")#linebreak()#text(" Damodar")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-501146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2018")])]

#text("Dear Prof Tao, I have a question about the proof using the Fourier method. The proof (around equation (11)) only uses $t$ in a neighborhood of the origin. My question is if this is equivalent to independence (i.e., does $F_{X,Y}(t,s)=F_X(t)F_Y(t)$ for $t$ in a neighborhood of the origin imply $F_{X,Y}(t,s)=F_X(t)F_Y(t)$ for all $t \\in V$)? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-501295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2018")])]

#text("If ")#mi("X,Y")#text(" are bounded (or subgaussian) random variables, then ")#mi("F_X(t), F_Y(t)")#text(" are analytic functions of ")#mi("t")#text(", and so by analytic continuation any identity that holds for small ")#mi("t")#text(" automatically holds for large ")#mi("t")#text(". I don’t know what happens though if ")#mi("X,Y")#text(" are more heavy-tailed, there may well be (somewhat artificial) counterexamples in this setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-540598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2020")])]

#text("Dear Prof. Tao, Do you know if there are quantitative versions of local central limit theorems, akin to the Berry-Esseen inequality? I am in particular interested in bounded integer i.i.d. random variables, assuming the number-theoretic issues are not a problem, i.e. the gcd is 1. E.g. think uniform distribution on the set of squares of integers in an interval.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-641287")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("Prof. Tao in Exercise 2 is Kolmogorov’s zero-one law the main thing that works behind the scenes: passing on to a subsequence it suffices to consider only almost sure convergence of a subsequence, but then we see that the normalized sums have mean zero and variance one so the limiting random variable would also have variance one, however since these ")#mi("(Z_{n_j})")#text(" is a sequence of tail random variables so if it converges in the almost sure sense then the limit must be a constant with probability one and will hence have zero variance, a contradiction which refutes our assumption and hence proves the claim.")

#text("Is this correct in your opinion?")

#emph[#text("[This is indeed one way to solve the exercise – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Neely")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-643761")[#strong[#text("Michael Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("In the “Random Matrix” book Exercise 1.1.10, what answer did you have in mind? The question may need some fixes, a counter-example seems to be when ")#mi("X")#text(" is uniformly distributed over ")#mi("[0,1]")#text(", ")#mi("X(Omega) = [0,1]")#text(", and ")#mi("X^{\\prime} = X 1\\{X \\neq 1/2\\}")#text(", so ")#mi("X")#text(" and ")#mi("X^{\\prime}")#text(" have the same distribution but ")#mi("X^{\\prime}")#text(" cannot be 1/2 so we cannot have ")#mi("X=X^{\\prime}(\\phi(\\omega))")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Neely")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-643764")[#strong[#text("Michael Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("By the way this is a stackexchange question here (I gave some preliminary comments on thoughts on the posting of HangY) ")#link("https://math.stackexchange.com/questions/4450636/distribution-of-a-random-variable-exercise/4450746#4450746")[#text("https://math.stackexchange.com/questions/4450636/distribution-of-a-random-variable-exercise/4450746#4450746")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-643789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Oops, you are right, the exercise is not correct as stated. (On standard probability spaces one can salvage it up to almost sure agreement by using a relative product construction, but this is not the point I wanted to make in this exercise.) I have added an erratum replacing the exercise by one which makes the desired point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Neely")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-643794")[#strong[#text("Michael Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Thanks for the quick reply! However, I don’t think this works. I believe I can construct two independent random variables ")#mi("X_i:Omega\\rightarrow\\mathbb[0,1]")#text(" for ")#mi("i\\in\\{1,2\\}")#text(", both uniformly distributed over ")#mi("[0,1]")#text(", such that the intersection of their images ")#mi("X_1(\\Omega)\\cap X_2(\\Omega)")#text(" is the empty set. If I understand your updated question properly, this is a (counterintuitive) counter example to your claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Neely")]], [#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/comment-page-1/#comment-643795")[#strong[#text("Michael Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Nevermind, I think my counterexample might be circumvented by your “almost surely” insertion (taken on the probability spaces, rather than on the R space) if we give different parts of the two different spaces measure 0 with respect to the different measures.")
]
]
]
]
