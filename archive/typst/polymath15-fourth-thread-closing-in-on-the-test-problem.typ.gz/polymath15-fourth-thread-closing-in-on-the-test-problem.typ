// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:20:01.740535+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, fourth thread: closing in on the test problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, fourth thread: closing in on the test problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 February 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the fourth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/this post")[#text("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("We are getting closer to finishing off the following test problem: can one show that ")#mi("{H_t(x+iy) \\neq 0}")#text(" whenever ")#mi("{t = y = 0.4}")#text(", ")#mi("{x \\geq 0}")#text("? This would morally show that ")#mi("{\\Lambda \\leq 0.48}")#text(". A wiki page for this problem has now been created ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("here")]#text(". We have obtained a number of approximations ")#mi("{A+B, A^{\\prime}+B^{\\prime}, A^{eff}+B^{eff}, A^{toy}+B^{toy}}")#text(" to ")#mi("{H_t}")#text(" (see wiki page), though numeric evidence indicates that the approximations are all very close to each other. (Many of these approximations come with a correction term ")#mi("{C}")#text(", but thus far it seems that we may be able to avoid having to use this refinement to the approximations.) The effective approximation ")#mi("{A^{eff} + B^{eff}}")#text(" also comes with an effective error bound")

#align(center)[#tao-fit-display[#tao-math("\\left|H_t - A^{eff} - B^{eff}\\right| \\leq E_1 + E_2 + E_3", block: true)]]

#text("for some explicit (but somewhat messy) error terms ")#mi("{E_1,E_2,E_3}")#text(": see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")[#text("this wiki page")]#text(" for details. The original approximations ")#mi("{A+B, A^{\\prime}+B^{\\prime}}")#text(" can be considered deprecated at this point in favour of the (slightly more complicated) approximation ")#mi("{A^{eff}+B^{eff}}")#text("; the approximation ")#mi("{A^{toy}+B^{toy}}")#text(" is a simplified version of ")#mi("{A^{eff}+B^{eff}}")#text(" which is not quite as accurate but might be useful for testing purposes.")

#text("It is convenient to normalise everything by an explicit non-zero factor ")#mi("{B^{eff}_0}")#text(". Asymptotically, ")#mi("{(A^{eff} + B^{eff}) / B^{eff}_0}")#text(" converges to 1; numerically, it appears that its magnitude (and also its real part) stays roughly between 0.4 and 3 in the range ")#mi("{10^5 \\leq x \\leq 10^6}")#text(", and we seem to be able to keep it (or at least the toy counterpart ")#mi("{(A^{toy} + B^{toy}) / B^{toy}_0}")#text(") away from zero starting from about ")#mi("{x \\geq 4 \\times 10^6}")#text(" (here it seems that there is a useful trick of multiplying by Euler-type factors like ")#mi("{1 - \\frac{1}{2^{1-s}}}")#text(" to cancel off some of the oscillation). Also, the bounds on the error ")#mi("{(H_t - A^{eff} - B^{eff}) / B^{eff}_0}")#text(" seem to be of size about 0.1 or better in these ranges also. So we seem to be on track to be able to rigorously eliminate zeroes starting from about ")#mi("{x \\geq 10^5}")#text(" or so. We have not discussed too much what to do with the small values of ")#mi("{x}")#text("; at some point our effective error bounds will become unusable, and we may have to find some more faster ways to compute ")#mi("{H_t}")#text(".")

#text("In addition to this main direction of inquiry, there have been additional discussions on the dynamics of zeroes, and some numerical investigations of the behaviour Lehmer pairs under heat flow. Contributors are welcome to summarise any findings from these discussions from previous threads (or on any other related topic, e.g. improvements in the code) in the comments below.")

#heading(level: 1)[#text("Comments (105)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493062")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("A note that some of the phases and exponents in the toy approximation were not quite correct in the previous post, but are now correct on the wiki (here it was very helpful by the way to have numerics for all the other approximations as this was very effective at detecting these inaccuracies). The expression ")#mi("(A^{toy}+B^{toy})/B^{toy}_0")#text(" now takes the form")

#mi("\\displaystyle \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2}-\\frac{\\pi i t}{8}+\\frac{t}{4} \\log^2 \\frac{N^2}{n}}} + e^{i\\theta} N^{-y} \\sum_{n=1}^N \\frac{1}{n^{\\frac{1-y+ix}{2}+\\frac{\\pi i t}{8}+\\frac{t}{4} \\log^2 \\frac{N^2}{n}}}")

#text("for some explicit but probably not very important phase ")#mi("\\theta")#text(". To make this non-zero it suffices to show that")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y+ix^{\\prime}}{2}+\\frac{t}{4} \\log^2 \\frac{N^2}{n}}}\\right| > N^{-y} \\left|\\sum_{n=1}^N \\frac{1}{n^{\\frac{1-y+ix^{\\prime}}{2}+\\frac{t}{4} \\log^2 \\frac{N^2}{n}}}\\right|", block: false)

#text("where ")#mi("x^{\\prime} := x + \\pi t/4")#text(" is a slight shift of ")#mi("x")#text(". This is basically the same problem as before except for a very tiny shift in the ")#mi("x")#text(" parameter. In particular the trick of multiplying by factors such as ")#mi("1 - \\frac{1}{2^{\\frac{1+y+ix^{\\prime}}{2} + \\frac{t}{4} \\log^2 \\frac{N^2}{2}}}")#text(" should still be useful (a key point being that this factor also produces a bit of cancellation on the RHS as well as the LHS, albeit to a lesser extent due to the mismatch in the ")#mi("y")#text(" term of the exponent).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("To set some explicit benchmarks, I think a good roadmap would be the following:")

#text("Goal 1. Show that ")#mi("(A^{toy}+B^{toy})/B^{toy}_0")#text(" is non-vanishing for any ")#mi("x>0")#text(" (or maybe say ")#mi("x>100")#text(" to exclude any pathologies at small ")#mi("x")#text(" coming from the inaccurate nature of the approximation).")

#text("Goal 2. Show that ")#mi("(A^{eff}+B^{eff})/B^{eff}_0")#text(" is non-vanishing for any ")#mi("x>0")#text(" (or ")#mi("x>100")#text(", etc.)")

#text("Goal 3. Show that for all decently large ")#mi("x")#text(", one can lower bound ")#tao-math("\\left|A^{eff}+B^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(" by ")#tao-math("\\left|H_t - A^{eff} - B^{eff}\\right|/\\left|B^{eff}_0\\right| \\leq (E_1+E_2+E_3)/\\left|B^{eff}_0\\right|", block: false)#text(" (this will solve the test problem for sufficiently large ")#mi("x")#text(", something additional will have to be done when ")#mi("x")#text(" is so small that the ")#mi("A^{eff}+B^{eff}")#text(" approximation is no longer effectively accurate).")

#text("My guess is that once we figure out how to efficiently achieve Goal 1, Goal 2 would be doable by a slight modification of the method, and Goal 3 would then also be relatively straightforward (of course we have to become better at controlling the errors ")#mi("E_1,E_2,E_3")#text(" for this).")

#text("As mentioned above, to establish Goal 1 it suffices to establish the inequality")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{1}{n^{0.7 + \\frac{ix^{\\prime}}{2} + 0.1 \\log \\frac{N^2}{n}}}\\right| > N^{-0.4} \\left|\\sum_{n=1}^N \\frac{1}{n^{0.3 + \\frac{ix^{\\prime}}{2} + 0.1 \\log \\frac{N^2}{n}}}\\right|", block: false)

#text("for all ")#mi("x")#text(" in the range of interest, where ")#mi("x^{\\prime} = x + \\pi/10")#text(" and ")#mi("N = \\lfloor \\sqrt{x/4\\pi} \\rfloor")#text(". Some thoughts on this:")

#text("(a) The variable ")#mi("N")#text(" keeps jumping with ")#mi("x")#text(" at square multiples of ")#mi("4\\pi")#text(". However, we may be able to get away with rounding ")#mi("N")#text(" down to the nearest multiple of (say) 100 and treating the error by the triangle inequality. This creates significantly fewer jumps and we can start using the fundamental theorem of calculus (bounding the derivative of the expressions inside the absolute values) between each pair of jumps. Another minor side benefit of decreasing ")#mi("N")#text(" is that it may also improve slightly the bound on the derivative (the large ")#mi("n")#text(" terms are a bit more oscillatory than the small ")#mi("n")#text(" terms).")

#text("(b) As before we can try to multiply both sides by Euler factors like ")#mi("1 - \\frac{1}{2^{0.7 + \\frac{ix^{\\prime}}{2} + 0.1 \\log \\frac{N^2}{2}}}")#text(" to have less oscillation (this may help reduce the upper bound on the derivative).")

#text("(c) If we have an upper bound on the derivative then we can try to use that to sample ")#mi("x")#text(" adaptively, rather than using a worst-case mesh, as this may lead to some useful speedup. For instance, suppose ")#tao-math("\\left|A^{toy} + B^{toy} / B_0^{toy}\\right|", block: false)#text(" numerically ranges between 0.4 and 3 and has a derivative that can be provably upper bounded by 5 (these numbers are made up for sake of argument). Then we could be conservative and sample ")#tao-math("\\left|A^{toy} + B^{toy} / B_0^{toy}\\right|", block: false)#text(" for ")#mi("x")#text(" in an equally spaced mesh of size ")#mi("0.4/5")#text(", and as long as the ratio ")#tao-math("\\left|A^{toy} + B^{toy} / B_0^{toy}\\right|", block: false)#text(" always evaluates to be greater than 0.4 on this mesh, we are OK for Goal 1. But if for instance at some value of x this ratio evaluates to be larger, say 2.1, then we can skip ahead to ")#mi("x + 2.1/5")#text(" rather than ")#mi("x+0.4/5")#text(" since that is the first place where a zero could conceivably occur. There are variants of this strategy where we evaluate the first derivative at the mesh point and use some upper bound on the second derivative, together with a Taylor expansion with remainder, to try to get an even larger skip, but perhaps just a first derivative analysis will already give a sufficient speedup for our purposes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493078")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("On further thought I think (a) is not going to give significant speedups. The intervals ")#mi("[4N^2 \\pi, 4(N+1)^2 \\pi]")#text(" on which ")#mi("N")#text(" is constant are so much larger than the mesh sizes we are considering that there is little to gain by concatenating them into even larger intervals, so one may as well treat each such interval separately. Even for ")#mi("x")#text(" up to ")#mi("4 \\times 10^7")#text(", ")#mi("N")#text(" only goes up to about 1784, and the cost of doing 1784 individual calculations would be trivial compared against the total number of mesh points one has to work with.")

#text("The other thing is that one does not have to work on the above goals sequentially; it is also possible for instance for some participants to work on understanding the error terms ")#mi("E_1,E_2,E_3")#text(" even before say Goal 1 is completed. Also I am beginning to suspect that the error analysis may not be sufficient to handle medium values of x, such as ")#mi("x \\sim 10^4")#text(", and one may indeed need to revive the “C” term in the ")#mi("A+B-C")#text(" type approximations in order to obtain a significantly better error term, as suggested in previous comments, to handle this range.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493136")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("I thought of multiplying the sumands on the LHS of inequality 2 by:")#linebreak()#text(" 1 = ")#mi("n^{-y}/n^{-y}")#linebreak()#text(" to render denominators in sums on LHS and RHS equal (I think).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("this idea of using equal denominators is also mentioned in ")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493119")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493119")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493066")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("For ")#mi("B_{0}^{eff}")#text(", I get a pretty good agreement with the tables")#linebreak()#text(" when I take a ")#mi("z")#text(" with imaginary part 0.4, as shown")#linebreak()#text(" below:")

#text("? B0(10^3 + 0.4*I)")#linebreak()#text(" = 3.4426 E-167 + 3.5411 E-167*I")

#text("? B0(10^4 + 0.4*I)")#linebreak()#text(" = -1.1850 E-1700 – 7.7879 E-1700*I")

#text("? B0(10^5 + 0.4*I)")#linebreak()#text(" = -7.6133 E-17047 + 2.5066 E-17047*I")

#text("So I suppose ")#mi("z")#text(" is ")#mi("x + 0.4 i")#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493070")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Yes, throughout that wiki page it is assumed that ")#mi("t = y = 0.4")#text(". Thanks for checking against the tables, it is always good to have independent confirmation to guard against errors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Is it possible to exploit also some (perhaps crude) information on the asymptotics of the phases of the dominant parts of ")#mi("A+ B")#text(" and the error term (not merely their magnitudes) to improve on the triangle inequality ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("My feeling is that we will not be able to get much out of this, because ")#mi("A")#text(" and ")#mi("B")#text(" oscillate in opposite directions (they are sort of conjugate to each other), and so one will periodically run into situations in which the triangle inequality is best possible. A caricature of the situation would be if we had ")#mi("A(x) = e^{i (\\frac{x}{4}\\log \\frac{x}{4\\pi} - \\frac{x}{4})} a(x)")#text(" and ")#mi("B(x) = e^{-i (\\frac{x}{4}\\log \\frac{x}{4\\pi} - \\frac{x}{4})} b(x)")#text(" where ")#mi("a(x), b(x)")#text(" were fairly slowly varying (note that the toy approximations ")#mi("A^{toy}, B^{toy}")#text(" are basically of this form, assuming that the small ")#mi("n")#text(" components of the sum ")#mi("n=1,\\dots,N")#text(" dominate, as they seem to do numerically). If one wanted to keep ")#mi("A(x)+B(x)")#text(" away from zero, it would suffice to show that ")#tao-math("\\left|a(x)\\right| > \\left|b(x)\\right|", block: false)#text(" for all ")#mi("x")#text(". On the other hand, if there was an interval of moderate length (e.g. a unit interval) on which one instead had ")#tao-math("\\left|a(x)\\right| < \\left|b(x)\\right|", block: false)#text(", then ")#mi("A(x)+B(x)")#text(" would wind around the origin a non-trivial number of times, and so by the argument principle one should expect to have a zero of ")#mi("A(x)+B(x)")#text(" for some ")#mi("y \\geq 0.4")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("In the wiki page on the test problem, ")#mi("N")#text(" is defined in the first approach (and its modification) without the square root.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Another possibility for fast simulteneous(!) computation of ")#mi("A+B, B_0")#text(" and the bound on the error term on a large grid, is to use ideas from Platt’s paper on a (high precision) FFT-based method (with rigorous bounds).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493082")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("It does seem that the trick of multiplying by an Euler factor also produces a moderate improvement in the derivative bounds.")

#text("Recall that we are trying to prove a bound of the form ")#tao-math("\\left|b(x)\\right| > \\left|a(x)\\right|", block: false)#text(" for all ")#mi("x")#text(", where")

#mi("\\displaystyle b(x) := \\sum_{n=1}^N \\frac{1}{n^{0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2/n)}}")#linebreak()#text(" ")#mi("\\displaystyle a(x) := N^{-0.4} \\sum_{n=1}^N \\frac{1}{n^{0.3 + ix^{\\prime}/2 + 0.1 \\log(N^2/n)}},")

#mi("x^{\\prime} = x + \\pi/10")#text(", ")#mi("N = \\lfloor \\sqrt{x/4\\pi} \\rfloor")#text(". Let us pick a value of ")#mi("N")#text(", so that ")#mi("x")#text(" ranges in the interval ")#mi("[4N^2 \\pi, 4(N+1)^2 \\pi)")#text(". I picked ")#mi("N = 892")#text(" for sake of discussion, as this gives the interval that contains ")#mi("x=10^7")#text(". On this interval, the triangle inequality gives the bounds")

#tao-math("\\displaystyle \\left|b(x)-1\\right| \\leq \\sum_{n=2}^N \\frac{1}{n^{0.7 + 0.1 \\log(N^2/n)}} \\approx 0.946", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a(x)\\right| \\leq N^{-0.4} \\sum_{n=1}^N \\frac{1}{n^{0.3 + 0.1 \\log(N^2/n)}} \\approx 0.2789", block: false)

#text("which is not quite enough to make the ")#mi("n=1")#text(" term of ")#mi("b")#text(" dominate since ")#mi("0.946+0.2789 > 1")#text(". We have the derivative bounds")

#tao-math("\\displaystyle \\left|b^{\\prime}(x)\\right| \\leq \\frac{1}{2} \\sum_{n=1}^N \\frac{\\log n}{n^{0.7 + 0.1 \\log(N^2/n)}} \\approx 1.096", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a^{\\prime}(x)\\right| \\leq \\frac{1}{2} N^{-0.4} \\sum_{n=1}^N \\frac{\\log n}{n^{0.3 + 0.1 \\log(N^2/n)}} \\approx 0.4144", block: false)

#text("so the quantity ")#tao-math("\\left|b(x)\\right|-\\left|a(x)\\right|", block: false)#text(" fluctuates at a rate of at most ")#mi("1.096+0.4144 \\approx 1.511")#text(", and one could design a mesh (either fixed-spacing or adaptive) to explore the interval ")#mi("[4N^2 \\pi, 4(N+1)^2 \\pi)")#text(" accordingly.")

#text("Now suppose we transform the inequality ")#tao-math("\\left|b(x)\\right| > \\left|a(x)\\right|", block: false)#text(" to the equivalent inequality ")#tao-math("\\left|b_2(x)\\right| > \\left|a_2(x)\\right|", block: false)#text(", where")

#mi("\\displaystyle b_2(x) = b(x) (1 - \\frac{1}{2^{0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2/2)}})")#linebreak()#text(" ")#mi("\\displaystyle a_2(x) = a(x) (1 - \\frac{1}{2^{0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2/2)}}).")

#text("A brief computation shows that")

#mi("\\displaystyle b_2(x) := \\sum_{n=1}^{2N} \\frac{1_{n \\leq N} - 1_{2|n} / (n/2)^{0.2 \\log 2}}{n^{0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2/n)}}")#linebreak()#text(" ")#mi("\\displaystyle a_2(x) := N^{-0.4} \\sum_{n=1}^{2N} \\frac{1_{n \\leq N} - 1_{2|n} 2^{-0.4} / (n/2)^{0.2 \\log 2}}{n^{0.3 + ix^{\\prime}/2 + 0.1 \\log(N^2/n)}}.")

#text("The same triangle inequality analysis as before gives the bounds")

#tao-math("\\displaystyle \\left|b_2(x)-1\\right| \\leq \\sum_{n=2}^{2N} \\frac{\\left|1_{n \\leq N} - 1_{2|n} / (n/2)^{0.2 \\log 2}\\right|}{n^{0.7 + 0.1 \\log(N^2/n)}} \\approx 0.480", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a_2(x)\\right| \\leq N^{-0.4} \\sum_{n=1}^{2N} \\frac{\\left|1_{n \\leq N} - 1_{2|n} 2^{-0.4} / (n/2)^{0.2 \\log 2}\\right|}{n^{0.3 + 0.1 \\log(N^2/n)}} \\approx 0.2300", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|b^{\\prime}_2(x)\\right| \\leq \\frac{1}{2} \\sum_{n=1}^{2N} \\frac{\\left|1_{n \\leq N} - 1_{2|n} / (n/2)^{0.2 \\log 2}\\right|\\log n}{n^{0.7 + 0.1 \\log(N^2/n)}} \\approx 0.7373", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a^{\\prime}_2(x)\\right| \\leq \\frac{1}{2} N^{-0.4} \\sum_{n=1}^{2N} \\frac{\\left|1_{n \\leq N} - 1_{2|n} 2^{-0.4} / (n/2)^{0.2 \\log 2}\\right|\\log n}{n^{0.3 + 0.1 \\log(N^2/n)}} \\approx 0.3620", block: false)

#text("so in fact now ")#tao-math("\\left|b_2(x)\\right|-\\left|a_2(x)\\right|", block: false)#text(" is bounded away from zero (it is at least ")#mi("1 - 0.480 - 0.2300 \\approx 0.2897")#text(") and oscillates at rate at most ")#mi("0.7373+0.3620 \\approx 1.0993")#text(", thus we have removed a bit of the oscillation from ")#tao-math("\\left|b(x)\\right|-\\left|a(x)\\right|", block: false)#text(" by this procedure.")

#text("One gets similar improvements for smaller values of ")#mi("N")#text(". For instance for ")#mi("N=282")#text(" (corresponding to ")#mi("x=10^6")#text("), we have ")#tao-math("\\left|b(x)-1\\right| \\leq 1.4455", block: false)#text(", ")#tao-math("\\left|a(x)\\right| \\leq 0.6047", block: false)#text(", ")#tao-math("\\left|b^{\\prime}(x)\\right| \\leq 1.7850", block: false)#text(", ")#tao-math("\\left|a^{\\prime}(x)\\right| \\leq 0.8781", block: false)#text(" and ")#tao-math("\\left|b_2(x)-1\\right| \\leq 0.8074", block: false)#text(", ")#tao-math("\\left|a_2(x)\\right| \\leq 0.5001", block: false)#text(", ")#tao-math("\\left|b^{\\prime}_2(x)\\right| \\leq 1.2605", block: false)#text(", ")#tao-math("\\left|a^{\\prime}_2(x)\\right| \\leq 0.7796", block: false)#text(". Thus it should be a lot faster to verify ")#tao-math("\\left|b_2(x)\\right|-\\left|a_2(x)\\right|>0", block: false)#text(" than ")#tao-math("\\left|b(x)\\right| - \\left|a(x)\\right|>0", block: false)#text(", as the former left-hand side oscillates less rapidly and is also more likely to stay further away from the origin, so one would need fewer points to evaluate the function.")

#text("As suggested by KM one might also multiply through by the Euler product at 3 and 5 and perhaps get some further modest gains. (But at this point the complexity of evaluating these more complicated sums may overwhelm the gain coming from having fewer evaluation points.) Another thing one can try is to modify the Euler factors slightly, e.g. considering multiplying by ")#mi("1 - \\frac{\\theta}{2^{0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2/2)}}")#text(" for some parameter ")#mi("\\theta")#text(" that is not necessarily equal to 1. Right now I am using ")#mi("\\theta=1")#text(" as this kills off completely the ")#mi("n=2")#text(" term in the ")#mi("b(x)")#text(" sum, but this might not necessarily be the best choice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493109")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("I was able to match the above numbers and generate estimates for all N from 1 to 1784 (x upto 4*10^7) upto the first 3 Euler factors.")

#text("Interesting N values")#linebreak()#text(" ——————–threshold")#linebreak()#text(" estimate————0—0.05–0.1")#linebreak()#text(" |b5(x)|-|a5(x)|—282—308—338")#linebreak()#text(" |b3(x)|-|a3(x)|—322—352—387")#linebreak()#text(" |b2(x)|-|a2(x)|—478—527—582")#linebreak()#text(" |b1(x)|-|a1(x)|–1391–1559–1761")

#text("N=338 corresponds to x ~ 1.5 million")

#text("upper bound of derivatives")#linebreak()#text(" ———————–N range")#linebreak()#text(" estimate—————1-28—29-63–64-89–90-199–200-282–283-337")#linebreak()#text(" max|b’5(x)|+|a’5(x)|—4.05—3.86—3.32—3.04—-2.24—-1.89")#linebreak()#text(" max|b’3(x)|+|a’3(x)|—3.44—3.43—3.14—2.92—-2.23—-1.91")#linebreak()#text(" max|b’2(x)|+|a’2(x)|—3.10—3.17—3.09—2.93—-2.34—-2.04")#linebreak()#text(" max|b’1(x)|+|a’1(x)|—3.61—3.82—3.79—3.66—-3.02—-2.66")

#text("N=28 corresponds to x=10568. Assuming |A+B|/|B0| stays over 0.4 beyond N=28, this indicates a mesh size of 0.1 or slightly lower would work at the start.")#linebreak()#text(" Also, the derivative bound fluctuates in lower N ranges, and at higher ranges max|b’2(x)|+|a’2(x)| is not very different compared to")#linebreak()#text(" max|b’p(x)|+|a’p(x)| with p>2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Some of the formulas in comments have log^2(N^2 / n) and in later comments similar formulas have log(N^2 / n) instead. Is that real or a typo?")

#emph[#text("[Oops, a typo: it should be single power of log throughout, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4604ae7da0bcd9c20a3eafb0fdced718c9a11b53b3667afb1a9fa40cba7a4d63-4524d4a5efd5f21548023ecad85309af23390314a1b50a9d413ac3683b99d497.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vsevolod")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493105")[#strong[#text("Vsevolod")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Quite a small typo: “or at least the toy counterpart” instead of “ot at least the toy counterpart”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493108")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("After correcting a sign error I made in defining ")#mi("B^{eff}")#text(", I get excellent agreement between the tables in the wiki and my PARI/gp version of them. Below, I recopy the corrected functions needed to define ")#mi("B^{eff}")#text(" in Pari/GP:")

#text("B(Z)=(1/8)*exp((t/4)*conj(al1(I*real(Z)/2+(1+imag(Z))/2))^2)*conj(H01(I*real(Z)/2+(1+imag(Z))/2))*sum(Y=1,M(Z),1/exp((-I*real(Z)/2+(1+imag(Z))/2+conj(t*al1(I*real(Z)/2+(1+imag(Z))/2))/2-(t/4)*log(Y))*log(Y)))")

#text("al1(S)=1/(2*S)+1/(S-1)+(1/2)*log(S/(2*Pi))")

#text("H01(S)=(S*(S-1)/2)*exp((-S/2)*log(Pi))*sqrt(2*Pi)*exp((S/2-1/2)*log(S/2)-S/2)")

#text("M(Z)=floor(sqrt((real(Z)/2-Pi*t/8)/(2*Pi)))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493125")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("David,")

#text("Below the Pari/GP code I wrote to compute Ht-effective including all the error terms. Maybe you could use parts of it or compare outcomes with your own code. It already contains the fix of the small sign error in ")#mi("T^{\\prime}")#text(" and ")#mi("T^{\\prime}_{0}")#text(" that was spotted today (I checked the impact and it is indeed very small).")

#text("Overall very good matches with the Wiki data, although small differences (in the 3rd digit) emerge at higher x. On Github, we have compared the output with KM’s mpmath program and the only remaining (small) difference seems to reside in the method of computation of the vwf-integral. The vwf-integral limits in the code are currently set at 6. The value of t can be set at the top.")

#text("\\\\Ht_effective A + B + Err (=E1 + E2) + C (=E3)")#linebreak()#text(" \\\\init")#linebreak()#text(" default(realprecision, 20)")#linebreak()#text(" t=0.4")#linebreak()#text(" intlim=6")#linebreak()#text(" S(s)=real(s)")#linebreak()#text(" T(s)=imag(s)")#linebreak()#text(" S1(s)=1-S(s)+T(s)*I")#linebreak()#text(" Td(s)=T(s)+Pi*t/8")#linebreak()#text(" T3(s)=T(s)-3.33")#linebreak()#text(" T4(s)=12*(Td(s)-0.33)")#linebreak()#text(" M(s)=floor(sqrt(Td(s)/(2*Pi)))")

#text("\\\\calculate A and B")#linebreak()#text(" ALF(s)=1/(2*s)+1/(s-1)+1/2*log(s/(2*Pi))")#linebreak()#text(" H00(s)=(s/2)*(s-1)*Pi^(-s/2)")#linebreak()#text(" H01(s)= H00(s)*sqrt(2*Pi)*exp((s-1)/2*log(s/2)-s/2)")#linebreak()#text(" QA(s,n)=s+t/2*ALF(s)-t/4*log(n)")#linebreak()#text(" QB(s,n)=1-s+t/2*conj(ALF(S1(s)))-t/4*log(n)")#linebreak()#text(" A0(s)=exp(t/4*ALF(s)^2)*H01(s)")#linebreak()#text(" B0(s)=exp(t/4*conj(ALF(S1(s)))^2)*conj(H01(S1(s)))")#linebreak()#text(" A(s)=A0(s)*sum(n=1,M(s),1/(n^(QA(s,n))))")#linebreak()#text(" B(s)=B0(s)*sum(n=1,M(s),1/(n^(QB(s,n))))")

#text("\\\\eps error")#linebreak()#text(" SE(s,n)=s+t/2*ALF(s)-t/4*log(n)")#linebreak()#text(" ER(s)=1/(2*T3(s))*(1/4*t^2*(abs(ALF(s))^2)+1/3+t)")#linebreak()#text(" EPS(s)=zeta(real(SE(s,M(s))))*exp(ER(s))*ER(s)")#linebreak()#text(" Err(s)=abs(A0(s)*EPS(s))+abs(B0(s)*EPS(S1(s)))")

#text("\\\\C and vwf error")#linebreak()#text(" a0(s)=sqrt(Td(s)/(2*Pi))")#linebreak()#text(" v1(sig,s)=1+0.4*9^(sig)/a0(s)+0.346*2^(1.5*sig)/(a0(s)^2)")#linebreak()#text(" v21(sig,s)=0.9^(ceil(-sig))")#linebreak()#text(" v22(sig,s)=sum(k=1,floor(-1*sig)+4,(1.1/a0(s))^k*gamma(k/2))")#linebreak()#text(" v2(sig,s)=1+v21(sig,s)*v22(sig,s)")#linebreak()#text(" v(sig,s)=if(real(sig)>=0,v1(sig,s),v2(sig,s))")#linebreak()#text(" w1(sig,s)=1+(sig^2)/(Td(s)^2)")#linebreak()#text(" w2(sig,s)=1+((1-sig)^2)/(Td(s)^2)")#linebreak()#text(" w3(sig,s)=(sig-1)*log(w1(sig,s))/4+w4(sig,s)+1/T4(s)")#linebreak()#text(" w4(sig,s)=if(sig<0,(Td(s)/2*atan(sig/Td(s))-sig/2),0)")#linebreak()#text(" w(sig,s)=sqrt(w1(sig,s))*sqrt(w2(sig,s))*exp(w3(sig,s))")#linebreak()#text(" f1(sig,s)=exp((-1/t)*(sig-S(s))^2)")#linebreak()#text(" f(sig,s)=(1/(2*sqrt(Pi*t)))*(f1(sig,s)+f1(1-sig,s))")#linebreak()#text(" vwf(s)=intnum(u = -intlim, intlim, v(u,s)*w(u,s)*f(u,s))")#linebreak()#text(" C1(s)=sqrt(Pi)*exp(-(t*Pi^2)/64)*(Td(s))^(3/2)*exp(-Pi/4*T(s))")#linebreak()#text(" C(s)=C1(s)*vwf(s)")

#text("\\\\all components together")#linebreak()#text(" E(s)=1/8*(A(s)+B(s)+C(s)+Err(s))")#linebreak()#text(" H(z)=(E(I*real(z)/2+(1-imag(z))/2))")

#text("\\\\generate output: note that Ht(x+yi)=E(1/2+(x+y*i)/2*i)")#linebreak()#text(" print((H(10000000+0.4*I)))")#linebreak()#text(" print((E(1/2+(10000000+0.4*I)/2*I)))")#linebreak()#text(" print((1/8*B0(1/2+(10000000+0.4*I)/2*I)))")#linebreak()#text(" print((B(1/2+(10000000+0.4*I)/2*I)/B0(1/2+(10000000+0.4*I)/2*I)))")

#text("︡4.6138 E-1705458 – 1.4530 E-1705457*I")#linebreak()#text(" 4.6138 E-1705458 – 1.4530 E-1705457*I")#linebreak()#text(" 2.1644 E-1705458 – 9.6337 E-1705458*I")#linebreak()#text(" 1.6400 + 0.019799*I")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493130")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Oops. Compared the code once again with the Wiki-formulae and spotted a mistake. The C-factor should not be divided by 8, so the correct line should be:")

#text("E(s)=1/8*(A(s)+B(s)+Err(s))+C(s)")

#text("The 1/8 factor can of course also be applied directly to A(s),B(s) and Err(s), when they are defined.")

#text("Fortunately the impact of this error on the final result is small.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Actually, you discovered a typo in the wiki! The 1/8 should in fact be applied to the E_3 error, sorry about that. Fortunately this typo moves in the “good” direction :)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493116")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("I made a minor sign error in the effective error estimates, but fortunately it is in a good direction: the quantities ")#mi("T^{\\prime}")#text(" and ")#mi("T^{\\prime}_0")#text(", which were previously defined as ")#mi("T - \\pi t/8")#text(" and ")#mi("T^{\\prime}_0 - \\pi t/8")#text(" respectively, are instead ")#mi("T + \\pi t/8")#text(" and ")#mi("T^{\\prime}_0 + \\pi t/8")#text(" (I had the wrong sign for ")#mi("\\beta_N")#text(" in the estimation of ")#mi("G_{t,N}")#text("). This slightly changes ")#mi("N")#text(" in the ")#mi("A^{eff}+B^{eff}")#text(" approximation, which is now ")#mi("\\lfloor \\sqrt{(x+\\pi t/4)/4\\pi} \\rfloor")#text(" rather than ")#mi("\\lfloor \\sqrt{(x-\\pi t/4)/4\\pi} \\rfloor")#text(". I found this because the formula for ")#mi("x^{\\prime} = x + \\pi t/4")#text(" in the comments above also had the plus sign instead of the minus one, which looked inconsistent or at least suspicious. I don’t think this changes the previous numerics substantially though, given how small ")#mi("\\pi t/4 = 0.314\\dots")#text(" is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493119")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("It seems the calculations for the toy problem are clarified using the language of Dirichlet series. Indeed observe that")

#mi("\\displaystyle b(x) = \\sum_{n=1}^N \\frac{b_n}{n^s}")#linebreak()#text(" ")#mi("\\displaystyle a(x) = \\sum_{n=1}^N \\frac{a_n}{n^s}")

#text("where ")#mi("s := 0.7 + ix^{\\prime}/2 + 0.1 \\log(N^2)")#text(", ")#mi("b_n := \\exp( 0.1 \\log^2 n)")#text(", and ")#mi("a_n := (n/N)^{0.4} b_n")#text(". The vanilla triangle inequality argument gives")

#tao-math("\\displaystyle \\left|b(x)-1\\right| \\leq \\sum_{n=2}^N \\frac{b_n}{n^\\sigma}", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a(x)\\right| \\leq \\sum_{n=1}^N \\frac{a_n}{n^\\sigma}", block: false)

#text("where ")#mi("\\sigma := 0.7 + 0.1 \\log(N^2)")#text(", thus one can keep ")#tao-math("\\left|b(x)\\right| > \\left|a(x)\\right|", block: false)#text(" so long as")

#tao-math("\\displaystyle \\sum_{n=1}^N \\frac{\\left|b_n\\right|+\\left|a_n\\right|}{n^\\sigma} < 2;", block: false)

#text("these are the same bounds as before.")

#text("Now the Euler factor trick can be viewed as a special case of the standard analytic number theory trick of mollifying a Dirichlet series by multiplying it by a short Dirichlet polynomial to remove some of the main sources of oscillation. Indeed, one can multiply ")#mi("b(x)")#text(" and ")#mi("a(x)")#text(" by the same Dirichlet polynomial ")#mi("f(x) := \\sum_{d=1}^D \\frac{\\lambda_d}{d^s}")#text(" for an arbitrary collection of coefficients ")#mi("\\lambda_d")#text(" to obtain")

#mi("\\displaystyle b(x) f(x) = \\sum_{n=1}^{DN} \\frac{\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d b_{n/d}}{n^s}")

#mi("\\displaystyle a(x) f(x) = \\sum_{n=1}^{DN} \\frac{\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d a_{n/d}}{n^s}.")

#text("If we normalise ")#mi("\\lambda_1 = 1")#text(", the triangle inequality then gives")

#tao-math("\\displaystyle \\left|b(x) f(x)-1\\right| \\leq \\sum_{n=2}^{DN} \\frac{\\left|\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d b_{n/d}\\right|}{n^\\sigma}", block: false)

#tao-math("\\displaystyle \\left|a(x) f(x)\\right| \\leq \\sum_{n=1}^{DN} \\frac{\\left|\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d a_{n/d}\\right|}{n^\\sigma}", block: false)

#text("and we can now ensure that ")#tao-math("\\left|b(x)\\right| > \\left|a(x)\\right|", block: false)#text(" so long as")

#tao-math("\\displaystyle \\sum_{n=1}^{DN} \\frac{\\left|\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d b_{n/d}\\right| + \\left|\\sum_{d=1}^D 1_{n \\leq dN} 1_{d|n} \\lambda_d a_{n/d}\\right|}{n^\\sigma} < 2.", block: false)

#text("The vanilla triangle inequality corresponds to just using ")#mi("D=1")#text(" and ")#mi("\\lambda_1=1")#text(". Using the Euler factor at 2 corresponds to taking ")#mi("D=2")#text(", ")#mi("\\lambda_1 = 1")#text(", and ")#mi("\\lambda_2 = - b_2")#text(" (this cancels the ")#mi("n=2")#text(" summand of the ")#mi("b")#text(" term). This might not be the optimal choice of ")#mi("\\lambda_2")#text(" to use in the ")#mi("D=2")#text(" case. Using the Euler factor at both 2 and 3 corresponds to taking ")#mi("D=6")#text(", ")#mi("\\lambda_1 = 1")#text(", ")#mi("\\lambda_2 = -b_2")#text(", ")#mi("\\lambda_3 = -b_3")#text(", ")#mi("\\lambda_6 = +b_2b_3")#text(", and all other ")#mi("\\lambda_d")#text(" vanishing (incidentally my calculations for this case differ slightly from KM’s, though I was able to confirm his calculations for ")#mi("a_1,b_1")#text(" and ")#mi("a_2,b_2")#text(", I think the contribution of the ")#mi("d=6")#text(" term could be a bit tricky, as I had made some errors by hand with this term before). However, one is free to use other values of ")#mi("\\lambda_d")#text(", and it could be that this could lead to further ranges of ")#mi("N")#text(" for which we can guarantee ")#tao-math("\\left|b(x)\\right| > \\left|a(x)\\right|", block: false)#text(" (thus far we tentatively seem to have reached all the way down to ")#mi("N \\geq 282")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Here is a lemma that may be useful.")

#strong[#text("Lemma")]#text(" Let ")#mi("a_n, b_n")#text(" be real numbers for ")#mi("n=1,\\dots,N")#text(" with ")#mi("b_1 = 1")#text(" and ")#mi("-1 < a_1 < 1")#text(". Let ")#mi("\\sigma")#text(" be a real number, and suppose that")

#tao-math("\\displaystyle \\sum_{n=2}^N \\frac{\\max( \\frac{\\left|b_n+a_n\\right|}{1+a_1}, \\frac{\\left|b_n-a_n\\right|}{1-a_1})}{n^\\sigma} < 1.", block: false)

#text("Then one has")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{b_n}{n^s}\\right| >  \\left|\\sum_{n=1}^N \\frac{a_n}{n^s}\\right|", block: false)

#text("whenever ")#mi("\\mathrm{Re}(s) = \\sigma")#text(".")

#strong[#text("Remark")]#text(" The condition (1) improves a little bit upon the condition")

#tao-math("\\displaystyle \\left|a_1\\right| + \\sum_{n=2}^N \\frac{\\left|b_n\\right|+\\left|a_n\\right|}{n^\\sigma} < 1", block: false)

#text("that one gets from directly applying the triangle inequality; the gain is particularly good when ")#mi("a_n, b_n")#text(" have coherent signs (e.g. they are all positive). Intuitively, the point is that the triangle inequality is only sharp if the ")#mi("b_n/n^s")#text(" are all negative reals for ")#mi("n \\geq 2")#text(", and the ")#mi("a_n/n^s")#text(" are all the same phase for ")#mi("n \\geq 1")#text(", and this is inconsistent with all the ")#mi("a_n, b_n")#text(" having the same sign (with ")#mi("b_1=1")#text(" and ")#mi("a_1")#text(" positive).")

#strong[#text("Proof")]#text(" It suffices to show that for any real phase ")#mi("\\theta")#text(", the quantity")

#mi("\\displaystyle \\sum_{n=1}^N \\frac{b_n + e^{i\\theta} a_n}{n^s}")

#text("is non-zero. By the triangle inequality, we can do this if")

#tao-math("\\displaystyle \\sum_{n=2}^N \\frac{\\left|b_n + e^{i\\theta} a_n\\right|}{\\left|1 + e^{i\\theta} a_1\\right|} \\frac{1}{n^\\sigma} < 1.", block: false)

#text("Observe from the cosine rule that")

#tao-math("\\frac{\\left|b_n + e^{i\\theta} a_n\\right|^2}{\\left|1 + e^{i\\theta} a_1\\right|^2} = \\frac{b_n^2 + a_n^2 + 2 a_n b_n \\cos \\theta}{1 + a_1^2 + 2 a_1 \\cos \\theta}", block: false)

#text("is a fractional linear function of ")#mi("\\cos \\theta")#text(" with no poles in the range ")#mi("[-1,1]")#text(" of ")#mi("\\cos(\\theta)")#text(", and is hence monotone on this interval Thus ")#tao-math("\\frac{\\left|b_n + e^{i\\theta} a_n\\right|}{\\left|1 + e^{i\\theta} a_1\\right|}", block: false)#text(" attains its maximum either when ")#mi("e^{i\\theta}=+1")#text(" or ")#mi("e^{i\\theta}=-1")#text(", thus")

#tao-math("\\frac{\\left|b_n + e^{i\\theta} a_n\\right|}{\\left|1 + e^{i\\theta} a_1\\right|} \\leq \\max( \\frac{\\left|b_n+a_n\\right|}{1+a_1}, \\frac{\\left|b_n-a_n\\right|}{1-a_1} )", block: false)

#text("and the claim follows. ")#mi("\\Box")

#text("Using this criterion in place of the triangle inequality, and not using any Euler factor mollifiers, I can improve the threshold ")#mi("N \\geq 1391")#text(" that KM obtained to ")#mi("N \\geq 1080")#text(". Presumably similar gains can be obtained when one combines this lemma with the Euler factors (or with other Dirichlet mollifiers, as I mentioned in the previous comment), but I haven't tried this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493152")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("Using the sharper inequality, I was able to match N=1080 with no Euler factor, but the results with the factor mollifiers seem aggressive.")#linebreak()#text(" Mollifier—N")#linebreak()#text(" Euler2—–296")#linebreak()#text(" Euler3—–136")#linebreak()#text(" Euler5——80")

#text("N= 80 corresponds to 80425!! This may need to be double checked.")

#text("where b_p_n = exp(0.1*logn*logn)*|conditional factor_p_n| using the coefficients derived earlier.")

#text("Also, I was able to run |b_p(x)| – |a_p(x)| delta evaluations with fixed mesh size 0.1 for all x between 10k and 200k (1.9 mil evaluation points) and p=1,2,3. From earlier data, the upper bound of |b’p(x)| + |a’p(x)| was known to be below 4, so I was looking for events where the delta was below 0.4.")

#text("For |b_1(x)| – |a_1(x)|, the last such event was at x=38280 (N=55) for a total of 782 events. Minimum was 0.186 reached at 17291.2")#linebreak()#text(" For |b_2(x)| – |a_2(x)|, this occured at x=22024 (N=41) for a total of 152 events. Minimum was 0.185 reached at 10530 (the earlier point was a close second)")#linebreak()#text(" For |b_3(x)| – |a_3(x)|, this occured at x=21538.5 (N=41) for a total of 72 events. Minimum was 0.201 reached at 17291.2")

#text("Using a mesh size of 0.05, the region x=10k to 22k was again verified, looking for delta values below 0.16 (since max|b’2(x)|+|a’2(x)| in the N range 29-63 was 3.17), but no such values were found, thus clearing all the points.")#linebreak()#text(" It would have been better to use a adaptive mesh as suggested earlier, rather than use such a iterative procedure.")

#text("Also, you mentioned that arbitrary lambda coefficients are allowed in the mollifiers, but just wanted to share the way I had proceeded with the d=6 derivation earlier")

#mi("\\frac{1}{n^{s^{\\prime} - 0.1 \\log(n)}}\\frac{-1}{2^{s^{\\prime} - 0.1 \\log(2)}}\\frac{-1}{3^{s^{\\prime} - 0.1 \\log(3)}}")#linebreak()#text(" ")#mi("= \\frac{1}{(6n)^{s^{\\prime}}}\\frac{1}{n^{-0.1 \\log(n)} 2^{-0.1 \\log(2)} 3^{-0.1 \\log(3)}}")#linebreak()#text(" ")#mi("= \\frac{1}{(6n)^{s^{\\prime}}}\\frac{1}{(6n)^{-0.1 \\log(n)} 6^{0.1 \\log(n)} (n^{-0.1 \\log(6)} n^{0.1 \\log(6)})(6^{-0.1 \\log(6)} 6^{0.1 \\log(6)}) 2^{-0.1 \\log(2)}3^{-0.1 \\log(3)}}")#linebreak()#text(" ")#mi("= \\frac{1}{(6n)^{s^{\\prime}}}\\frac{1}{(6n)^{-0.1 \\log(6n)} 6^{0.1 \\log(n)} n^{0.1 \\log(6)} 2^{0.1 \\log(3)} 3^{0.1 \\log(2)}}")#linebreak()#text(" ")#mi("= \\frac{1}{(6n)^{s^{\\prime} -0.1 \\log(6n)}}\\frac{1}{n^{0.2 \\log(6)} exp(0.2 \\log2 \\log(3)}")#linebreak()#text(" ")#mi("\\textrm{ with } s^{\\prime} = 0.7 + ix/2 + 0.1\\log(N^2) \\textrm{ (and an additional } \\frac{1}{6^{0.4}} \\textrm{ factor in the RHS)}")#linebreak()#text(" leading to the final conditional factors")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493179")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("Thanks for this! The bounds are looking remarkably good, I will try to double check them with my somewhat primitive Maple skills. It also seems that your calculation of the d=6 term was correct and mine was wrong.")

#text("If this all checks out it seems that we actually have a numerical verification of the non-vanishing of ")#mi("A^{toy}+B^{toy}")#text(" for all ")#mi("x \\geq 10^4")#text(". Next we would have to adapt these methods to ")#mi("A^{eff}+B^{eff}")#text(". A new technical difficulty here is that there is an expression ")#mi("\\alpha_1(s)")#text(" in the exponent which depends on ")#mi("x")#text(" and not just on ")#mi("N")#text(". However the dependence on x is rather mild and we may be able to somehow approximate ")#mi("\\alpha_1(s)")#text(" by something that only depends on ")#mi("N")#text(".")

#text("As requested I will try to upload my Maple code to the git repository, though I am not really proficient in these things and I would hardly recommend using my code for much other than confirmation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493183")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("I was also able to write a general procedure for the triangle inequality estimates, which can use any number of Euler factors (although it’s quite slow at the moment). Using 4 factors, the 0 threshold was crossed slightly below N=265. Will try to adapt it for the sharper inequality as well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("KM, so far I have verified the triangle inequality thresholds of ")#mi("N \\geq 1391, 478, 322")#text(" using ")#mi("Euler_1, Euler_2, Euler_3")#text(" respectively, and for ")#mi("N \\geq 1080")#text(" using ")#mi("Euler_1")#text(" and the Lemma. However I am getting different (and slightly worse) results than your ")#mi("N \\geq 296, 136")#text(" for the use of the Lemma with ")#mi("Euler_2, Euler_3")#text("; will report on the thresholds I get soon (and then I will also work on confirming ")#mi("Euler_5")#text("). Looking at your code, I think the problem is that one shouldn’t be putting absolute values around the cond[n][] terms in lines 221, 222 of ab_analysis.py; the signs of bn2, an2, etc. are actually rather important in the Lemma. By the way I am also putting the lemma and the numerical results on the wiki page.")

#text("EDIT: For ")#mi("Euler_2 + Lemma")#text(" I get ")#mi("N \\geq 341")#text(" (replacing ")#mi("N \\geq 296")#text("). For ")#mi("Euler_3 + Lemma")#text(" I get ")#mi("N \\geq 220")#text(" (replacing ")#mi("N \\geq 136")#text(").")

#text("EDIT2: ")#mi("N \\geq 282")#text(" threshold for ")#mi("Euler_5 + Triangle")#text(" confirmed. For ")#mi("Euler5 + Lemma")#text(" I get ")#mi("N \\geq 241")#text(" (i.e. worse than ")#mi("Euler3 + Lemma")#text(")!")

#text("EDIT3: I can improve the ")#mi("N \\geq 220")#text(" threshold for ")#mi("Euler3 + Lemma")#text(" slightly to ")#mi("N \\geq 213")#text(" by dropping the ")#mi("d=6")#text(" term from the ")#mi("Euler3")#text(" mollifier, i.e. taking ")#mi("\\lambda_1 = 1, \\lambda_2 = -b_2, \\lambda_3 = -b_3")#text(" and all other terms zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493220")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Thanks, I removed the absolute part around the cond terms. There was another typo where i was using bn and an to compute bn2,an2,bn3,…, thus multiplying two conditional terms, instead of treating them independently.")

#text("I was able to match N=341 for E2 + Lemma and N=220 for E3+ Lemma. But I am getting N=192 for E5 + Lemma (at N=241, the estimate is coming out to be 0.888)")

#text("Using the general procedure with the sharper inequality, I get N=180 for E7+Lemma, and 176 for E11 + Lemma")

#text("I have also started a x point evaluation run for x between 200k and 600k (N=219) with an adaptive mesh.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Ah, I made a stupid typo in my own code. I can now confirm your value of ")#mi("N=192")#text(" for ")#mi("E_5 + Lemma")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493226")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("I wasn’t able to replicate N=213 with the custom mollifier ")#mi("\\lambda_1 = 1, \\lambda_2 = -b_2, \\lambda_3 = -b_3")#text(", and instead got N=235. For now, I have added a function abtoy_custom_mollifier in ab_analysis.py, and will experiment again later with different mollifiers.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493237")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Gah, you’re right; the same typo that caused an error in my previous calculation was also present here. I’ve confirmed your value of 235. So I guess this is not a good mollifier :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493347")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Custom mollifiers do work. By treating the lambda coefficients as parameters to be optimized, and minimizing the Lemma sum using a standard minimization algorithm (the sum for D=30 wasn’t fully minimized), we get")

#mi("D=2, \\lambda_1 = 1, \\lambda_2 = -1.15 \\Rightarrow N=336, \\sum = 0.9995")#linebreak()#text(" ")#mi("(1.15 \\textrm{ is close to } \\pi/e)")#linebreak()#text(" ")#mi("D=6, \\lambda_1 = 1, \\lambda_2 = -1.045, \\lambda_3 = -1.12, \\lambda_6 = 0.9135 \\Rightarrow N=212, \\sum = 0.997")#linebreak()#text(" ")#mi("D=30, \\lambda_1 = 1,\\lambda_2=-1.1455,\\lambda_3=-1.1189,\\lambda_5=-1.2779,\\lambda_6=1.0447,\\lambda_{10}=1.1377,\\lambda_{15}=1.5231,\\lambda_{30}=-1.6408 \\Rightarrow N=182, \\sum = 0.998")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Great! I’ve added this to the wiki (now moved to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0")]#text(" because the previous page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#text(" was becoming slow to load). It seems that trying to optimise the mollifier shrinks the range of x that we need to check by about 10-20% which is not that dramatic, but perhaps these sorts of optimisations add up (or more precisely, multiply up) after a while…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("I can’t find the code that participants are using for this project, the github linked from the project wiki hasn’t had any commits in almost two weeks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493180")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("Actually, all the new code is in the adjusted AB branch which has been in merge review since couple of weeks. Have merged that and Prof. Tao’s recent branch (with Maple code and relevant papers) into master, which is much easier to find.")#linebreak()#text(" In the python folder, please check mputility.py and the research folder.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493221")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("I acknowledge that the main task now is to establish the lowest possible x-bound beyond which ")#mi("H_{eff, t=0.4}(2(x+0.4i)) \\ne 0")#text(". The encouraging results of the toy-model indicate that this x-bound is going to be brought well in reach of computing that ")#mi("H_{eff, t=0.4}(2(x+0.4i))")#text(" (and ")#mi("y \\ge 0.4")#text(") doesn’t vanish below that. In the context of computation, I would like to share the outcomes of an experiment I did.")

#text("In a nutshell: an x-ray plot shows all the points where ")#mi("\\Re\\big{\\left(H_t(2(x+yi))\\right)} = 0")#text(" (green lines) and ")#mi("\\Im\\big{\\left(H_t(2(x+yi))\\right)} = 0")#text(" (red lines), so the H_t-function only vanishes when the two lines cross. For a certain fixed ")#mi("y")#text(", a real line (that wiggles quite a bit) is always accompanied by two imaginary lines (which are much better behaved). Hence the idea to measure the distance a green line keeps from its embracing red lines and then to calculate the distribution of these distances over a wide range of ")#mi("x")#text(".")

#text("The approach is visualised here: ")#link("https://ibb.co/jTihiH")[#text("https://ibb.co/jTihiH")]

#text("The distributions for various ")#mi("t")#text(" over ")#mi("x")#text(" ranging from 1000 to 50000 (yielding 62870 ")#mi("\\Re\\big{\\left(H_t(z)\\right)}=0")#text("‘s), for both ")#mi("y=0")#text(" and ")#mi("y=0.4")#text(" is shown here: ")#link("https://ibb.co/m1cExc")[#text("https://ibb.co/m1cExc")]

#text("Few observations:")#linebreak()#text(" 1) The line ")#mi("\\Im\\big{\\left(H_t(2(x+0i))\\right)} = 0")#text(" doesn’t oscillate, hence to embrace ")#mi("\\Re\\big{\\left(H_t(2(x+0i))\\right)} = 0")#text(" I used ")#mi("\\Im\\big{\\left(H_t(2(x+0.1i))\\right)} = 0")#text(".")#linebreak()#text(" 2) I appreciate that the Ht-ABC-formula has been deprecated now, however since we don’t have an effectively bounded ")#mi("H_{eff}")#text(" C-error term for lower ")#mi("x")#text(" yet, I still used it to produce the plots (also since the match with ")#mi("\\Xi(t)")#text(" at lower ")#mi("x")#text(" was pretty good).")#linebreak()#text(" 3) The data looks encouraging for the problem at hand. Distributions clearly tend to convergence towards more ‘normal’ shapes with increasingly emptier ‘tails’, when ")#mi("t")#text(" and ")#mi("y")#text(" move away from zero.")#linebreak()#text(" 4) I wonder whether it is correct to say that when the distribution for ")#mi("y=t=0.4")#text(" has empty tails say below 40% and above 60%, that given certain error terms of say max 5%, that line then must be zero-free up to ")#mi("x=50.000")#text("?")

#text("Couldn’t resist a philosophical note :)")#linebreak()#text(" The paraphrased Newman-quote: ‘RH if true, then it is barely so’ is also illustrated by the plots. When ")#mi("t")#text(" and ")#mi("y")#text(" move towards zero, the distribution gets increasingly wider. Assuming the RH (")#mi("\\Lambda=0")#text("), the non-trivial zeros apparently need to get ‘crammed’ into all the available slots at ")#mi("t=y=0")#text(" to be able to encode the required information about the error term in the distribution of primes. The zeros seem to dangerously balance on the thin edge of a real cliff and even the tiniest negative ")#mi("t")#text(" would already push some of them over into the sea of complex numbers…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Hah! That Newnan quote is ‘barely’ rubbish.. And RH is true! 😄")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Nice pictures! One small thing: I think the notational conventions we’ve been using are to use ")#mi("z = x+yi = x+0.4i")#text(" for the argument of ")#mi("H_t")#text(", and ")#mi("s = \\frac{1+iz}{2} = 0.3 + \\frac{ix}{2} = \\sigma+iT")#text(" for the argument of ")#mi("\\xi_t")#text(" (thus for instance ")#mi("T = x/2")#text("). It seems your conventions may differ from this by a factor of two, although for the purposes of qualitative illustration this probably doesn’t matter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493257")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("You are absolutely right and I should have been much clearer on why I used ")#mi("2z")#text(" as the argument! I actually did start from the convention that ")#mi("H_t(z) \\sim \\frac{1}{8} \\xi_t( \\frac{1}{2} + \\frac{iz}{2} )")#text(" with ")#mi("z=x+iy")#text(", however then consciously multiplied ")#mi("z")#text(" by ")#mi("2")#text(" to obtain ")#mi("H_t(2z) \\sim \\frac{1}{8} \\xi_t( \\frac{1}{2} + iz )")#text(" that allows for better (visual) comparison to known values (zeros) of ")#mi("\\xi_0(\\frac12 + iz)")#text(" (for instance the sample x-ray in the first picture is from the area where the first Lehmer pair did induce some still visible ‘wiggles’ in the green lines).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("In that case your y=0.4 may in fact correspond to what the rest of us would call y=0.8 (but I am not 100% sure on this, perhaps one can crosscheck against some of the numerical data in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")]#text(" , which is for y=0.4 in our notation).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("p.s. I have now updated the wiki page at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")]#text(" with the refined approximation ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" to ")#mi("A^{eff}+B^{eff}")#text(". In practice it seems that ")#mi("C^{eff}")#text(" stays quite close to ")#mi("C")#text(" (and ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" stays close to ")#mi("A+B-C")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493264")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("This is my first try at translating into PARI/gp.")#linebreak()#text(" It gives H_0(28.2073) ~= 0 , which seems quite good.")

#text("Heff2(Z)=A(Z)+B(Z)-C(Z)")

#text("C(Z)=(1/8)*exp(t*(Pi^2)/64)*(sp(Z)*(sp(Z)-1)/2)*((-1)^M(Z))*(Pi^(-sp(Z)/2)*gamma(sp(Z)/2)*(a(Z)^(-sig(Z)))*C0(Z)*U(Z)+Pi^(-(1-sp(Z))/2)*gamma((1-sp(Z))/2)*(a(Z)^(-(1-sig(Z))))*conj(C0(Z))*conj(U(Z)))")

#text("sp(Z)=(1-imag(Z))/2+I*real(Z)/2+I*Pi*t/8")

#text("a(Z)=sqrt((real(Z)/2+Pi*t/8)/(2*Pi))")

#text("sig(Z)=real(sp(Z))")

#text("C0(Z)=(exp(Pi*I*((p(Z)^2)/2+3/8))-I*sqrt(2)*cos(Pi*I/2))/(2*cos(Pi*p(Z)))")

#text("U(Z)=exp(-I*((Tp(Z)/2)*log(Tp(Z)/(2*Pi))-Tp(Z)/2-Pi/8))")

#text("Tp(Z)=real(Z)/2+Pi*t/8")

#text("p(Z)=1-2*(a(Z)-M(Z))")

#text("M(Z)=floor(sqrt((real(Z)/2+Pi*t/8)/(2*Pi)))")

#text("A(Z)=(1/8)*exp((t/4)*(al1(I*real(Z)/2+(1-imag(Z))/2)^2))*H01(I*real(Z)/2+(1-imag(Z))/2)*sum(Y=1,M(Z),1/exp((I*real(Z)/2+(1-imag(Z))/2+t*al1(I*real(Z)/2+(1-imag(Z))/2)/2-(t/4)*log(Y))*log(Y)))")

#text("B(Z)=(1/8)*exp((t/4)*conj(al1(I*real(Z)/2+(1+imag(Z))/2))^2)*conj(H01(I*real(Z)/2+(1+imag(Z))/2))*sum(Y=1,M(Z),1/exp((-I*real(Z)/2+(1+imag(Z))/2+conj(t*al1(I*real(Z)/2+(1+imag(Z))/2))/2-(t/4)*log(Y))*log(Y)))")

#text("H01(S)=(S*(S-1)/2)*exp((-S/2)*log(Pi))*sqrt(2*Pi)*exp((S/2-1/2)*log(S/2)-S/2)")

#text("al1(S)=1/(2*S)+1/(S-1)+(1/2)*log(S/(2*Pi))")

#text("B0(Z)=(1/8)*exp((t/4)*conj(al1(I*real(Z)/2+(1+imag(Z))/2))^2)*conj(H01(I*real(Z)/2+(1+imag(Z))/2))")

#text("====")

#text("? real(Heff2(28.207303425056217036624775835617549798))")#linebreak()#text(" = 1.6860423122756198997 E-41")

#text("? t")#linebreak()#text(" = 0.E-38")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Thanks for the confirmation! That is remarkably good accuracy for such a small value of ")#mi("x")#text(". I wonder if it would be possible to have some comparative tables or plots of ")#mi("H_t, A+B, A+B-C, A^{eff}+B^{eff}")#text(", and ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" for such values of ")#mi("x")#text(" (perhaps normalised by dividing by something like ")#mi("B^{eff}_0")#text(" to eliminate the exponential decay). It may help give a sense of when the ")#mi("A^{eff}+B^{eff}")#text(" approximation is no longer viable, in which case one would need to switch to ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" (and get better explicit error terms).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493277")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("I think I can produce that normalized data (after dividing by ")#mi("B_0^{eff}")#text(". Indeed, 28.207 is pretty close to twice 14.13 (first non-trivial zeta zero).")#linebreak()#text(" The computer is working on this:")

#text("I’m computing the absolute value of ")#mi("(H_{0.4}(z) - H_{0.4}^{eff}(z))/B_{0}^{eff}(z)")#text(" for 20 real numbers ")#mi("z")#text(" from 160 to 3200. Here, ")#mi("H^{eff}")#text(" includes the ")#mi("C^{eff}")#text(" term, and ")#mi("H_{0.4}(z)")#text(" is computed using the integral formula defining ")#mi("H_{t}")#text(" .")

#text("T.B.C. …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493282")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("[ continued…]")

#text("There seems to be a local maximum once again near ")#mi("z = 800")#text(" .")

#text("The PARI/gp code to do the comparison of ")#mi("H_{0.4}^{eff}")#text(" with ")#mi("H_{0.4}")#text(", with the output, is copied below:")

#text("? \\p 550")#linebreak()#text(" realprecision = 558 significant digits (550 digits displayed)")

#text("? w20=vector(20)")#linebreak()#text(" = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]")

#text("? t=0.4")#linebreak()#text(" […]")

#text("? intnumgaussinit(800);")#linebreak()#text(" […]")

#text("? for(K=1, 20, x50= K*160 ;s=0.0;for(J=0,30,s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=Heff2(x50); b0=B0(x50);s4 = abs((s2-s)/b0);w20[K] = s4;)")

#text("? \\p 10")#linebreak()#text(" realprecision = 19 significant digits (10 digits displayed)")

#text("? for(K=1,20, print(K*160,” “, w20[K]))")#linebreak()#text(" 160 0.009155667752")#linebreak()#text(" 320 0.0005529962481")#linebreak()#text(" 480 0.0004966282128")#linebreak()#text(" 640 0.0004482768972")#linebreak()#text(" 800 0.002686105466 // local maximum")#linebreak()#text(" 960 0.001270168744")#linebreak()#text(" 1120 0.0009957229500")#linebreak()#text(" 1280 0.0007024411378")#linebreak()#text(" 1440 0.0007000473085")#linebreak()#text(" 1600 0.0004882487218")#linebreak()#text(" 1760 0.0002518910919")#linebreak()#text(" 1920 0.0008378989413")#linebreak()#text(" 2080 0.0004924765754")#linebreak()#text(" 2240 0.0001171320991")#linebreak()#text(" 2400 0.0002443802551")#linebreak()#text(" 2560 0.0004569058755")#linebreak()#text(" 2720 0.0006355966221")#linebreak()#text(" 2880 0.0008864917365")#linebreak()#text(" 3040 4.326840265 E-5")#linebreak()#text(" 3200 0.0003598521453")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Thanks for this data! I put it on the wiki at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Controlling_.7CH_t-A-B.7C.2F.7CB_0.7C")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Controlling_.7CH_t-A-B.7C.2F.7CB_0.7C")]#text(" next to your previous data on ")#tao-math("\\left|H_t - (A+B-C)\\right|/\\left|B_0\\right|", block: false)#text(" (see third table) and the improvement in accuracy is substantial. Could you also give data for ")#tao-math("\\left|H_t - (A+B)\\right|/\\left|B_0\\right|", block: false)#text(" and ")#tao-math("\\left|H_t - (A^{eff}+B^{eff})\\right|/\\left|B_0^{eff}\\right|", block: false)#text(" for the same range of ")#mi("x")#text("? This would give some guidance as to the range of ")#mi("x")#text(" for which we would have to utilise the ")#mi("C")#text(" correction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493284")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Below, for the sake of getting results faster, I take ")#mi("H_{0.4}^{eff}")#text(" as the “standard” to which ")#mi("A^{eff}(z) + B^{eff}(z)")#text(" is compared, after division by ")#mi("B_{0}^{eff}")#text(" :")

#text("? QABeff(Z) = abs(A(Z) + B(Z) – Heff2(Z))/abs(B0(Z))")

#text("? for(K=3,7, print(10^K,” “, QABeff(10^K)))")#linebreak()#text(" 1000 0.15607")#linebreak()#text(" 10000 0.033581")#linebreak()#text(" 100000 0.0077278")#linebreak()#text(" 1000000 0.0017772")#linebreak()#text(" 10000000 0.00026013")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Is your ")#mi("H^{eff}")#text(" the same as ")#mi("A^{eff} + B^{eff} - C^{eff}")#text("? If so, then I guess your ")#mi("QABeff")#text(" would be ")#tao-math("\\left|C^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(". I get very slightly different data for this ratio (here I am assuming ")#mi("y=0")#text("):")

#text("1000 0.1659471018")#linebreak()#text(" 10000 0.03571919360")#linebreak()#text(" 100000 0.008219920842")#linebreak()#text(" 1000000 0.001890567784")#linebreak()#text(" 10000000 0.0002777949355")

#text("The differences are small, but I’d like to pin it down – probably there is a typo in my own code since it seems your implementation approximates ")#mi("H_t")#text(" to very high accuracy. For ")#mi("z = 10^3")#text(", for instance, I am getting these values:")

#mi("A^{eff} =  -0.5819206433 \\times 10^{-167}  - 0.3039318881 10^{-167} i")

#mi("B^{eff} =  -0.5819206433 \\times 10^{-167}  + 0.3039318881 10^{-167} i")

#mi("C^{eff} =  -0.5290455851 \\times 10^{-167}")

#mi("B^{eff}_0 =  0.1839421902 \\times 10^{-166} + 0.2603864477 \\times 10^{-166} i")

#text("Does this match your numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493289")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("This is sample code to write to a file the normalized values of ")#mi("A^{eff} + B^{eff}")#text(", ")#mi("H_{0.4}^{eff}")#text(" :")

#text("? for(K=20, 1000, x50=K; w = (A(x50)+B(x50))/B0(x50); write(outputHeffAB, x50,” “, w))")

#text("? for(K=20, 1000, x50=K; w = Heff2(x50)/B0(x50); write(outputHeffABC, x50,” “, w))")

#text("But I don’t know how to do plots in PARI/gp .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493293")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("For z^3, t=0.4 I am currently getting (hoping my code is correct…):")

#text("A_eff -5.8191933398261330947 E-168 – 3.0393189395893835125 E-167*I")#linebreak()#text(" B_eff -5.8191933398261330947 E-168 + 3.0393189395893835125 E-167*I")#linebreak()#text(" C_eff -4.9757097161525819004 E-168 + 0.E-205*I")#linebreak()#text(" B0_eff 1.8394229213245936177 E-167 + 2.6038636181013073063 E-167*I")

#text("Just to show the good match I get between the ")#mi("\\xi")#text("-function (1st) with (A+B-C)_eff. C-term listed independently (3rd) at t=0, y=0:")

#text("x=25")#linebreak()#text(" 0.00066948088996085741409 – 7.174648137343063403 E-42*I")#linebreak()#text(" 0.00065734215678865204259 + 0.E-41*I")#linebreak()#text(" 0.0002148587374553108988")

#text("x=50")#linebreak()#text(" 1.7280715206373737196 E-9 – 1.9158377441940858392 E-47*I")#linebreak()#text(" 1.6625508526575364227 E-9 + 0.E-45*I")#linebreak()#text(" 7.4751288517910783610 E-8 + 0.E-45*I")

#text("x=100")#linebreak()#text(" 3.9527439074473614238 E-16 – 1.1093017595597491695 E-53*I")#linebreak()#text(" 3.9779357479763186216 E-16 + 0.E-53*I")#linebreak()#text(" -4.0160884429998658723 E-16 + 0.E-53*I")

#text("x=500")#linebreak()#text(" 1.0763588275034730133 E-82 + 5.653984195680004678 E-119*I")#linebreak()#text(" 1.0770837316884739789 E-82 + 0.E-120*I")#linebreak()#text(" -2.1026699008978412660 E-83 + 0.E-120*I")

#text("x=1000")#linebreak()#text(" -3.0912467355888789916 E-167 – 3.251797352795581408 E-203*I")#linebreak()#text(" -3.0904791459693381129 E-167 + 0.E-205*I")#linebreak()#text(" -5.2704332443772292555 E-168 + 0.E-205*I")

#text("x=10000")#linebreak()#text(" 1.1326355002579265086 E-1700 + 2.3068258704312139077 E-1736*I")#linebreak()#text(" 1.1324594118594644316 E-1700 + 0.E-1738*I")#linebreak()#text(" -1.4441315742576007239 E-1701 + 0.E-1738*I")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("I can confirm the full precision of Rudolph’s values for ")#mi("A^{eff}")#text(", ")#mi("B^{eff}")#text(", and ")#mi("B^{eff}_0")#text(" using my own implementation based on the wiki for ")#mi("x=1000 y=0 t=0.4")#text(", but I haven’t yet implemented the ")#mi("C^{eff}")#text(" correction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493296")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Yes, it should all be the effective type, unless I’m mistaken.")#linebreak()#text(" I seem to get the same thing as you for ")#mi("B_{0}^{eff}")#text(", slightly different w.r.t. ")#mi("A^{eff}")#text(" and ")#mi("B^{eff}")#text(", and really different for ")#mi("C^{eff}")#text(":")

#text("? x50=1000; w = A(x50); print(w)")#linebreak()#text(" -5.819193340 E-168 – 3.039318940 E-167*I")

#text("? x50=1000; w = B(x50); print(w)")#linebreak()#text(" -5.819193340 E-168 + 3.039318940 E-167*I")

#text("? x50=1000; w = C(x50); print(w)")#linebreak()#text(" -4.975709716 E-168 + 0.E-186*I")

#text("? x50=1000; w = B0(x50); print(w)")#linebreak()#text(" 1.839422921 E-167 + 2.603863618 E-167*I")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493300")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Ah, thanks for this, I tracked down the bugs in my own code. (For the record: I had used ")#mi("T =x/2")#text(" instead of ")#mi("T^{\\prime} = x/2 + \\pi t/8")#text(", and I had also omitted the factor of ")#mi("\\exp( t \\pi^2 / 64)")#text(".) My data now matches yours to three significant figures; for instance I have ")#mi("C^{eff} = -4.97671022 \\times 10^{-167}")#text(" now. The discrepancy is a lot smaller but I’d still like to pin down what’s going on; as far as I can tell it is not simply a matter of not having enough digits of precision. Staying with ")#mi("x = 1000, y = 0, t = 0.4")#text(", I also calculate")

#mi("C_0(p) = 0.3763483070 - 0.2292780192 i")#linebreak()#text(" ")#mi("U = -0.5779312326 - 0.816085467 i")#linebreak()#text(" ")#mi("\\Gamma(s^{\\prime}/2) = 1.333548739 \\times 10^{-171} - 8.4934750812 \\times 10^{-172} i.")

#text("Do these correspond to the numbers you are getting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493302")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("I got:")

#text("Co(p) 0.376348307023843 + 1.58717855690832*I")#linebreak()#text(" U -0.577931232612849 – 0.816085467564882*I")#linebreak()#text(" Gamma(s’/2) 1.33354873965418 E-171 – 8.49347508127889 E-172*I")

#text("So, the difference seems to be only in the imaginary part of C0(p). The error could easily be in my code, but here is a thought: for C0 my code is:")

#text("C0(s)=(exp(Pi*I*((P(s)^2)/2+3/8))-I*sqrt(2)*cos(Pi*I/2))/(2*cos(Pi*P(s)))")

#text("I can simply put C0(s) since the only variable is P(s), so I will always get p as the outcome. When I would put in C0(P(s)), it would give a very different outcome. I think that somewhere in this space the difference originates from.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Again I get the same numbers as Rudolph for those three parts of ")#mi("C^{eff}")#text(" when I use the formulas on the wiki.")#linebreak()#text(" C0 : 0.37634830702384258887 + 1.5871785569083238623*I")#linebreak()#text(" U : -0.57793123261284940132 – 0.81608546756488229758*I")#linebreak()#text(" Gamma(s’ / 2) : 1.3335487396541778349e-171 – 8.4934750812788891334e-172*I")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("There’s a typo in the wiki where ")#mi("\\cos(\\pi i / 2)")#text(" should be ")#mi("\\cos(\\pi p / 2)")#text(". With this correction I get imaginary part 0.22927801920219723181 matching Terry’s number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("imaginary part -0.22927801920219723181 I mean, with the negative sign. The typo is in the last part of the numerator of the definition of ")#mi("C_{0}(p)")#text(" in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Choices_of_approximation")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Thanks for this! I’m glad now that we tracked down the numerical discrepancy, we might not have discovered the typo for a long time otherwise. I’ve corrected the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493310")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Right now, the computer is working on the data for the table: z = 160 to 3200, ")#mi("H_{0.4}(z)")#text(" (integral) compared to ")#mi("A(z) + B(z)")#text(" …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493311")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Good catch, that must be it.")

#text("One more question: when we ‘call’ C0 from the formula for C, should we use s or s’ ? It is only a small difference, but just be sure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Well, the way it is done in the wiki, ")#mi("C_0")#text(" is a function of ")#mi("p")#text(", which is in turn a function of ")#mi("a")#text(" and ")#mi("N")#text(", which are functions of ")#mi("T^{\\prime}")#text(", which is the imaginary part of ")#mi("s^{\\prime}")#text(", which is a shifted form of ")#mi("s")#text(". So one could make ")#mi("C_0")#text(" a function of ")#mi("p")#text(", or of ")#mi("T^{\\prime}")#text(", or of ")#mi("s^{\\prime}")#text(", or of ")#mi("s")#text(", depending on how one codes it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Sorry Rudolph I can’t answer your questions about “when we ‘call’ C0 from the formula for C, should we use s or s’” or “I can simply put C0(s) since the only variable is P(s), so I will always get p as the outcome”. Maybe they’re technical questions about how to use Pari/GP but I’m not using that system and I haven’t used it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493318")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("For ")#mi("C^{eff}")#text(" I see -4.9767102201547040018e-168 which is off by exactly a factor of 10 from what Terry wrote, but I assume he just typo’d 167 instead of 168 when writing his comment.")

#emph[#text("[Yes, that was a typo on my part – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493281")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Also got the code for new C working and the match at t=0 seems excellent even at small x (can confirm David’s zero at 28.207). Could there be a small typo on Wiki where C0(p) should actually be C0(s) (also for its conjugated version)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("It should indeed be ")#mi("C_0(p)")#text(" (though, as ")#mi("p")#text(" ultimately depends on ")#mi("s")#text(", one could also view ")#mi("C_0(p)")#text(" as a function of ")#mi("s")#text("). Here I am following the notation of the Arias de Reyna paper ")#link("https://pdfs.semanticscholar.org/7964/fbdc0caeec0a41304deb8d2d8b2e2be639ee.pdf")[#text("https://pdfs.semanticscholar.org/7964/fbdc0caeec0a41304deb8d2d8b2e2be639ee.pdf")]#text(" (see e.g. equation (5.2)).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493294")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("You’re right! It should be ")#mi("C_{0}(p)")#text(" indeed, apologies for the false alarm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493336")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("A final question just to be sure that I have translated the wiki-formulae correctly into computer code.")

#text("On wiki, the definition of ")#mi("C^{eff}")#text(" uses ")#mi("s^{\\prime}")#text(" as the main variable in the arguments of all its components. Since ")#mi("p")#text(" ultimately is a function of ")#mi("s")#text(", should the ")#mi("p")#text(" in the component ")#mi("C_o(p)")#text(" be dependent on ")#mi("s")#text(" or also on ")#mi("s^{\\prime}")#text(" ? For ")#mi("U")#text(" the same question could be raised.")

#text("For ")#mi("x=1000, y=0, t=0.4")#text(", the choice would give this difference in ")#mi("C^{eff}")#text(":")

#text("using ")#mi("C_{0}(s) \\rightarrow -4.97671022015470 E-168 + 0.E-186*I")#linebreak()#text(" using ")#mi("C_{0}(s^{\\prime}) \\rightarrow -4.99500582650853 E-168 + 0.E-186*I")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("From my reading of David’s code, it seems that ")#mi("p")#text(" is a function of ")#mi("s")#text(" (which is called Z in the PARI code) rather than ")#mi("s^{\\prime}")#text(" (as the shift by ")#mi("\\pi T/8")#text(" is coded into these functions), so one would use ")#mi("s")#text(" as the input for David’s ")#mi("C_0")#text(" function rather than ")#mi("s^{\\prime}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("I don’t see the definition of ")#mi("\\sigma")#text(" in ")#mi("C^{eff}")#text(", is it ")#mi("(1 - y)/2")#text("?")

#emph[#text("[Yes, I have updated the wiki to reflect this – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("This is probably a dumb question but are there explicit tail bounds for the E3 improper integral error term?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493236")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Not yet; that’s something I plan to look at soon, as it looks like ")#mi("E_3")#text(" is the dominant error and also the one which is hardest to estimate at present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493252")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("It’s not clear to me what the optimal way of bounding ")#mi("E_3")#text(" will be, but one simple-minded way is just to truncate the integral defining it at some large values of ")#mi("\\sigma")#text(", relying on the decay of ")#mi("f(\\sigma)")#text(" and the not-too-fast increase of ")#mi("w,v")#text(" to show that outside this truncation the integral is small, while inside the truncation ")#mi("w(\\sigma)")#text(" is close to 1, and otherwise evaluate everything algebraically as far as possible.")

#text("This is complicated a little bit by discontinuities in the definition of ")#mi("v")#text(", but I think these should be able to be dealt with in one way or another.")

#text("I’ve only gotten as far as to estimate ")#mi("w")#text(" inside some hypothetical cutoffs, and even then I’ve not made an effort to optimize these cutoffs and just done a sort of back-of-the-envelope computation with _a lot_ of lost information in the constants. Nonetheless, it seems that something like the following will be true:")

#text("For ")#mi("T_0^{\\prime} > 20")#text(" say, for ")#mi("\\sigma \\in (0,\\sqrt{T_0^{\\prime}})")#text(",")

#mi("w(\\sigma) = 1 + O_{\\leq}\\Big{\\left(\\frac{3}{2} \\frac{1}{T_0^{\\prime}}\\right)}")#text(",")

#text("while for ")#mi("\\sigma \\in (-(T_0^{\\prime})^{1/3},0)")#text(", the same bound holds true.")

#text("Haven’t yet plugged these into the integrals or dealt with the range outside this truncation…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("This is a promising approach! I will try it and see what I get.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("On the wiki page for this test problem, should the second ")#mi("B^{eff} :=")#text(" be ")#mi("B^{eff}_0 :=")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("I think there’s a sign typo on this thread’s wiki, where ")#mi("\\frac{1+y-ix}{2}")#text(" in part of the definition of ")#mi("B^{eff}")#text(" should be ")#mi("\\frac{1+y+ix}{2}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("If the sign is correct, then there is a corresponding typo in the effective bounds wiki page; the signs are inconsistent between these two pages.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493235")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("It was the effective wiki page that had the sign error, now corrected; thanks for pointing it out.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493239")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("I have entered some calculations ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Analysing_the_effective_model")[#text("on the wiki")]#text(" on how to transition from the toy model to the effective approximation.")

#text("Currently, to show that ")#mi("A^{toy}+B^{toy}")#text(" is non-vanishing, we have to verify that")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{b_n}{n^{s^{toy}}}\\right| - \\left|\\sum_{n=1}^N \\frac{a_n^{toy}}{n^{s^{toy}}}\\right| > 0", block: false)

#text("where ")#mi("s^{toy} := \\sigma^{toy}+iT^{toy}")#text(" has real part ")#mi("\\sigma^{toy} := \\frac{1+y}{2} + \\frac{t}{2} \\log N")#text(" (and imaginary part ")#mi("T^{toy} := \\frac{x}{2} +\\frac{\\pi t}{8}")#text(", though this imaginary part has not played much role so far), ")#mi("b_n := \\exp( \\frac{t}{4} \\log^2 n)")#text(", ")#mi("a_n := (n/N)^y b_n")#text(", and we took ")#mi("N := \\lfloor \\sqrt{\\frac{x}{4\\pi}} \\rfloor")#text(". We now have a number of ways to establish this lower bound for various values of ")#mi("N")#text(".")

#text("For the problem of showing that ")#mi("A^{eff} + B^{eff}")#text(" is non-vanishing, it similarly suffices to verify that")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{b_n}{n^{s^{eff}}}\\right| - \\left|\\sum_{n=1}^N \\frac{a_n^{eff}}{n^{s^{eff}}}\\right| > 0 \\quad (1)", block: false)

#text("where ")#mi("s^{eff} = \\sigma^{eff} + i T^{eff}")#text(" has a more complicated form than ")#mi("s^{toy}")#text(", but the real part ")#mi("\\sigma^{eff}")#text(" is greater than or equal to ")#mi("\\sigma^{toy}")#text(" (assuming ")#mi("y \\geq 1/3")#text(", which we have right now), ")#mi("b_n")#text(" is as before, ")#mi("N")#text(" is very slightly different as ")#mi("N := \\lfloor \\sqrt{ \\frac{x}{4\\pi} + \\frac{t}{16} } \\rfloor")#text(" (thus ")#mi("x_N \\leq x < x_{N+1}")#text(" where ")#mi("x_N := 4\\pi N^2 - \\frac{\\pi t}{4}")#text("), and ")#mi("a_n^{eff}")#text(" turns out to take the form")

#mi("a_n^{eff} = e^\\delta a_n^{toy} + O_{\\leq}(e_n)")

#text("where ")#mi("\\delta")#text(" is the small quantity")

#tao-math("\\displaystyle \\delta := \\frac{\\pi y}{2(x_N-6-\\frac{14+2y}{\\pi})} + \\frac{2y(7+y)}{x_N^2} \\log \\frac{\\left|1+y+ix_{N+1}\\right|}{4\\pi}", block: false)

#text("(roughly of size ")#mi("O(1/x)")#text(") and ")#mi("e_n")#text(" is a small error")

#mi("\\displaystyle e_n := e^\\delta (\\exp( \\frac{ty\\log n}{2(x_N-6)} - 1) a^{toy}_n.")

#text("(roughly of size ")#mi("O( a^{toy}_n \\frac{\\log n}{x} )")#text("). So, up to the ")#mi("\\delta")#text(" and ")#mi("e_n")#text(" factors, ")#mi("a_n^{eff}")#text(" is basically the same as ")#mi("a_n^{toy}")#text(", and the previous analysis should go through (the fact that ")#mi("\\sigma^{eff}")#text(" is slightly larger than ")#mi("\\sigma^{toy}")#text(" actually works in one's favor, one can simply just use the criteria we have with just ")#mi("\\sigma^{toy}")#text("). The one annoying thing is that the error term ")#mi("O_{\\leq}(e_n)")#text(" is complex valued, and the Lemma that has been giving the best values of ")#mi("N")#text(" requires real coefficients. So one basically has to extract out the ")#mi("e_n")#text(" errors separately using the triangle inequality, leading to a messier criterion for showing non-vanishing (or for more generally lower bounding the LHS of (1)). In principle one can also insert the Euler product mollifiers as before; the criterion then gets somewhat messy but should still be usable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493280")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("For the effective approximation with the Lemma inequality, the same bounds as the current toy bounds seem to hold (I checked with upto 2 Euler factors) – 1080, 341, 220. Away from the critical N value we get different estimates. For e.g. at N=100, |b2| – |a2| toy estimate is 1.612 and effective estimate is 1.515, but they both go below 1 at N=341.")

#text("Also, I stopped the adaptive mesh x point toy evaluation at 500k (N=199) (which was started at x=200k). Mesh size was determined as (|b2(x)|-|a2(x)|)/4. Minimum value for |b2(x)|-|a2(x)| was 0.604. Hence with the earlier exercise upto 200k, the entire range 10k to 500k has been now considered. I will now evaluate the effective approximation for the same range.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493283")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Also some minor typos in that section of the wiki. The triangle inequality has the n^sigma factor missing, and in the Lemma inequality, 1-a1 and 1+a1 should be flipped.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493288")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("Good catches! I have corrected the wiki accordingly.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("In the “Final bound” section of the effective bounds wiki page and in the effective bounds section of the test problem page, some of the error terms involve a ")#mi("T")#text(". Should these be ")#mi("T^{\\prime}")#text(" or ")#mi("T_0")#text(" or does the ")#mi("T")#text(" mean ")#mi("x/2")#text(" or something else?")

#emph[#text("[")#mi("T")#text(" is ")#mi("x/2")#text("; I have added this to the description. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493299")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("For the range 160 to 3200, I can provide data for tables, after a break :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493313")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("This is what I get for ")#mi("(H_{0.4}(z) - ( A^{eff}(z) + B^{eff}(z) ))/B_{0}^{eff}(z)")#text(" in absolute value:")

#text("? for(K=1, 20, x50= K*160 ;s=0.0;for(J=0,30,s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=A(x50)+B(x50); b0=B0(x50);s4 = abs((s2-s)/b0);w20[K] = s4;)")

#text("? \\p 19")#linebreak()#text(" realprecision = 19 significant digits")

#text("? for(K=1,20, print(K*160,” “, w20[K]))")#linebreak()#text(" 160 0.1675083979955609185")#linebreak()#text(" 320 0.2776948344513698276")#linebreak()#text(" 480 0.1675667240356922231")#linebreak()#text(" 640 0.1635077306008453928")#linebreak()#text(" 800 0.2045038601879677257")#linebreak()#text(" 960 0.1031837988358064657")#linebreak()#text(" 1120 0.07541968034203085865")#linebreak()#text(" 1280 0.1339118061014743863")#linebreak()#text(" 1440 0.07958929988050262854")#linebreak()#text(" 1600 0.07700542235140914608")#linebreak()#text(" 1760 0.09568042045936396570")#linebreak()#text(" 1920 0.06385275621986742745")#linebreak()#text(" 2080 0.09421231232885752514")#linebreak()#text(" 2240 0.05888587520703223358")#linebreak()#text(" 2400 0.07899341548208345822")#linebreak()#text(" 2560 0.06283843631123482445")#linebreak()#text(" 2720 0.05966972584730198272")#linebreak()#text(" 2880 0.07980560515423855917")#linebreak()#text(" 3040 0.04636072344121703969")#linebreak()#text(" 3200 0.09664223832561922043")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493340")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Just to clarify: is this the same calculation as in your preceding comment ")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493282")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493282")]#text(" , but with the corrected version of ")#mi("C^{eff}")#text("? The accuracy seems to be somewhat worse with this new set of data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493354")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("No, it’s a different calculation: it’s the normalized error in ")#mi("A^{eff} + B^{eff}")#text(", as an approximation to ")#mi("H_{0.4}")#text(" (using the defining integral).")#linebreak()#text(" As far as I can tell, the corrected ")#mi("C_{0}")#text(" and ")#mi("C^{eff}")#text(" do not affect values of ")#mi("A^{eff} + B^{eff}")#text(" …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493359")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Thanks for clarifying! I’ve added this to the table, which is now moved to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")]#text(" because the page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#text(" was becoming slow to load. It is now quite clear that the C corrections do give a noticeable improvement in the accuracy of the approximation.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493363")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("One column is just a bit off, I think.")#linebreak()#text(" With the corrected ")#mi("C^{eff}")#text(" , the normalized errors of ")#mi("H^{eff}(z) - (A^{eff}(z) + B^{eff}(z) - C^{eff}(z))")#text(" compared to the integral formula are likely a bit smaller.")#linebreak()#text(" For example, with the corrected ")#mi("C^{eff}")#text(" , for z=1600, I now get a normalized error of 0.000439823 (versus 0.000488248 on the wiki).")

#text("Except for z = 800, the normalized errors on the wiki used the old ")#mi("C^{eff}")#text(": the one with a typo. I’m recalculating.")

#text("? x50= 1600 ;s=0.0;for(J=0,30,s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=Heff2(x50); b0=B0(x50);s4 = abs((s2-s)/b0); s4")

#text("= 0.0004398235678")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493365")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Using the corrected ")#mi("C^{eff}")#text(", the normalized error in ")#mi("H^{eff}")#text(" looks marginally better, on average, than when using the ")#mi("C^{eff}")#text(" with a typo :")

#text("? for(K=1, 20, x50= K*160 ;s=0.0;for(J=0,30,s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=Heff2(x50); b0=B0(x50);s4 = abs((s2-s)/b0);w20[K] = s4;) // corrected C^eff")#linebreak()#text(" […]")

#text("? for(K=1,20, print(K*160,” “, w20[K]))")#linebreak()#text(" 160 0.00887362155217")#linebreak()#text(" 320 0.000708716878236")#linebreak()#text(" 480 0.000327585584191")#linebreak()#text(" 640 0.000523969818792")#linebreak()#text(" 800 0.00264434457030")#linebreak()#text(" 960 0.000819848578351")#linebreak()#text(" 1120 0.000978838228690")#linebreak()#text(" 1280 0.000679785836479")#linebreak()#text(" 1440 0.000655447626435")#linebreak()#text(" 1600 0.000439823567873")#linebreak()#text(" 1760 0.000231103881282")#linebreak()#text(" 1920 0.000849398936325")#linebreak()#text(" 2080 0.000505410233739")#linebreak()#text(" 2240 0.000107206342271")#linebreak()#text(" 2400 0.000229146425813")#linebreak()#text(" 2560 0.000492123116208")#linebreak()#text(" 2720 0.000656180976718")#linebreak()#text(" 2880 0.000878298302262")#linebreak()#text(" 3040 4.70113907733 E-5")#linebreak()#text(" 3200 0.000354582706466")

#emph[#text("[New data added, thanks – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493316")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("My numbers are almost the same as Terry’s: the ")#mi("C_{0}(1000)")#text(" values differ in their imaginary parts only, it seems… :")

#text("? C0(1000)")#linebreak()#text(" = 0.3763483070 + 1.5871785569*I // not the same")

#text("? U(1000)")#linebreak()#text(" = -0.5779312326 – 0.8160854676*I // the same")

#text("? gamma(sp(1000)/2)")#linebreak()#text(" = 1.3335487397 E-171 – 8.4934750813 E-172*I // the same")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493317")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("David there’s a typo in the wiki (")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493308")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493308")]#text(") so")#linebreak()#text(" C0(Z)=(exp(Pi*I*((p(Z)^2)/2+3/8))-I*sqrt(2)*cos(Pi*I/2))/(2*cos(Pi*p(Z)))")#linebreak()#text(" should be changed to")#linebreak()#text(" C0(Z)=(exp(Pi*I*((p(Z)^2)/2+3/8))-I*sqrt(2)*cos(Pi*p(Z)/2))/(2*cos(Pi*p(Z)))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493319")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2018")])]

#text("I tested for comparison with ")#mi("H_{0.4}(800)")#text(" (integral formula).")

#text("With C0 “new”, the error of ")#mi("H^{eff}(800)")#text(" is slightly smaller than")#linebreak()#text(" with C0 per the Wiki:")

#text("? C0new(Z) = (exp(Pi*I*((p(Z)^2)/2+3/8))-I*sqrt(2)*cos(Pi*p(Z)/2))/(2*cos(Pi*p(Z)))")

#text("? C0new(1000)")#linebreak()#text(" = 0.3763483070238425883 – 0.2292780192021972320*I")

#text("? C0(Z)=C0new(Z)")

#text("? x50= 800 ;s=0.0;for(J=0,30,s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=Heff2(x50); b0=B0(x50);s4 = abs((s2-s)/b0); s4")

#text("= 0.002644344570 (versus 0.002686105466 in Wiki table).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493345")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("When your main research reference is the first part of a seven year old two-part work that cites its second part as “to appear” ")#link("https://i.imgur.com/IrSHTib.jpg")[#text("https://i.imgur.com/IrSHTib.jpg")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493349")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("After the wiki revision of ")#mi("C_{0}")#text(" now at: ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Controlling_.7CH_t-A-B.7C.2F.7CB_0.7C")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Controlling_.7CH_t-A-B.7C.2F.7CB_0.7C")]#text(" everything matches:")

#text("? C0(1000)")#linebreak()#text(" = 0.3763483070238425883 – 0.2292780192021972320*I")

#text("? U(1000)")#linebreak()#text(" = -0.5779312326128494048 – 0.8160854675648822951*I")

#text("? gamma(sp(1000)/2)")#linebreak()#text(" = 1.333548739654177835 E-171 – 8.493475081278889133 E-172*I")

#text("========================")#linebreak()#text(" user-defined functions :")

#text("A =")#linebreak()#text(" (Z)->(1/8)*exp((t/4)*(al1(I*real(Z)/2+(1-imag(Z))/2)^2))*H01(I*real(Z)/2+(1-imag(Z))/2)*sum(Y=1,M(Z),1/exp((I*real(Z)/2+(1-imag(Z))/2+t*al1(I*real(Z)/2+(1-imag(Z))/2)/2-(t/4)*log(Y))*log(Y)))")

#text("B =")#linebreak()#text(" (Z)->(1/8)*exp((t/4)*conj(al1(I*real(Z)/2+(1+imag(Z))/2))^2)*conj(H01(I*real(Z)/2+(1+imag(Z))/2))*sum(Y=1,M(Z),1/exp((-I*real(Z)/2+(1+imag(Z))/2+conj(t*al1(I*real(Z)/2+(1+imag(Z))/2))/2-(t/4)*log(Y))*log(Y)))")

#text("B0 =")#linebreak()#text(" (Z)->(1/8)*exp((t/4)*conj(al1(I*real(Z)/2+(1+imag(Z))/2))^2)*conj(H01(I*real(Z)/2+(1+imag(Z))/2))")

#text("C =")#linebreak()#text(" (Z)->(1/8)*exp(t*(Pi^2)/64)*(sp(Z)*(sp(Z)-1)/2)*((-1)^M(Z))*(Pi^(-sp(Z)/2)*gamma(sp(Z)/2)*(a(Z)^(-sig(Z)))*C0(Z)*U(Z)+Pi^(-(1-sp(Z))/2)*gamma((1-sp(Z))/2)*(a(Z)^(-(1-sig(Z))))*conj(C0(Z))*conj(U(Z)))")

#text("C0 =")#linebreak()#text(" (Z)->(exp(Pi*I*((p(Z)^2)/2+3/8))-I*sqrt(2)*cos(Pi*p(Z)/2))/(2*cos(Pi*p(Z)))")

#text("H01 =")#linebreak()#text(" (S)->(S*(S-1)/2)*exp((-S/2)*log(Pi))*sqrt(2*Pi)*exp((S/2-1/2)*log(S/2)-S/2)")

#text("Heff2 =")#linebreak()#text(" (Z)->A(Z)+B(Z)-C(Z)")

#text("M =")#linebreak()#text(" (Z)->floor(sqrt((real(Z)/2+Pi*t/8)/(2*Pi)))")

#text("Tp =")#linebreak()#text(" (Z)->real(Z)/2+Pi*t/8")

#text("U =")#linebreak()#text(" (Z)->exp(-I*((Tp(Z)/2)*log(Tp(Z)/(2*Pi))-Tp(Z)/2-Pi/8))")

#text("a =")#linebreak()#text(" (Z)->sqrt((real(Z)/2+Pi*t/8)/(2*Pi))")

#text("al1 =")#linebreak()#text(" (S)->1/(2*S)+1/(S-1)+(1/2)*log(S/(2*Pi))")

#text("p =")#linebreak()#text(" (Z)->1-2*(a(Z)-M(Z))")

#text("sig =")#linebreak()#text(" (Z)->real(sp(Z))")

#text("sp =")#linebreak()#text(" (Z)->(1-imag(Z))/2+I*real(Z)/2+I*Pi*t/8")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Would it make sense to record that code in a new Pari/GP directory in the github project, next to the existing julia, maple, matlab, and python directories?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493355")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("I believe so, or maybe. It’s my current best effort at coding the mathematical functions for the effective approximation, as written up by Terry on the Wiki. It doesn’t have everything, but it has the definitions needed to calculate the effective approximations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493360")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("Thanks for this! I think we can now be fairly confident in the accuracy of the formula for the refined effective approximation ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(", thanks to everybody for helping out with the debugging process. I’ve also put a text file with David’s PARI code into the git repository.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493352")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("This is what I get for ")#mi("(H_{0.4}(z) - A(z) - B(z))/B_{0}(z)")#text(", in the non-effective type estimates:")

#text("160 0.174873661533")#linebreak()#text(" 320 0.278624615745")#linebreak()#text(" 480 0.167598495339")#linebreak()#text(" 640 0.165084846603")#linebreak()#text(" 800 0.201954876756")#linebreak()#text(" 960 0.103387669714")#linebreak()#text(" 1120 0.0767779295558")#linebreak()#text(" 1280 0.132886551163")#linebreak()#text(" 1440 0.0802159981813")#linebreak()#text(" 1600 0.0777462698681")#linebreak()#text(" 1760 0.0950946156489")#linebreak()#text(" 1920 0.0629013452776")#linebreak()#text(" 2080 0.0949328843573")#linebreak()#text(" 2240 0.0591497767926")#linebreak()#text(" 2400 0.0785798163298")#linebreak()#text(" 2560 0.0621868667021")#linebreak()#text(" 2720 0.0585282736442")#linebreak()#text(" 2880 0.0787554869341")#linebreak()#text(" 3040 0.0462460274843")#linebreak()#text(" 3200 0.0963053589535")

#text("The PARI/gp session is still running, so we might cross-check a sample of")#linebreak()#text(" ")#mi("A(z) + B(z)")#text(" values…")

#emph[#text("[Data added to wiki, thanks. Looks like the accuracy of ")#mi("A+B")#text(" and ")#mi("A^{eff}+B^{eff}")#text(" is almost identical – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2018")])]

#text("I have tentatively calculated a fairly tractable and usable upper bound ")#mi("E_3^*")#text(" for the main error term ")#mi("E_3")#text(" at the end of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")]#text(" . Explicitly, the bound is")

#mi("E_3^* = \\frac{1}{8} \\sqrt{\\pi} \\exp( - \\frac{t\\pi^2}{64}) (T^{\\prime}_0)^{3/2} e^{-\\pi T_0/4} \\exp( \\frac{0.181}{T^{\\prime}_0 - 3.33}) (1 + \\frac{5.15}{a_0-1.25})")

#text("where ")#mi("T_0")#text(" is any lower bound for ")#mi("T")#text(" that is greater than or equal to 100, ")#mi("T^{\\prime}_0 := T_0 + \\pi t/8")#text(", and ")#mi("a_0 := \\sqrt{T^{\\prime}_0/2\\pi}")#text(". Actually one should just set ")#mi("T_0 = T")#text(" for the best bound (eventually I’ll probably replace ")#mi("T_0")#text(" with ")#mi("T")#text(" throughout in the wiki calculations in fact, it is a legacy from a period in which I was not sure if the error estimates were going to be monotone decreasing in ")#mi("T")#text("). I don’t yet have the ability to easily calculate ")#mi("E_3")#text(" in maple, but using ")#mi("C^{eff}")#text(" as a proxy it looks like ")#mi("E_3^*")#text(" is only worse than ")#tao-math("\\left|C^{eff}\\right|", block: false)#text(" by a factor of two or so (see table at the end of the above link), and this looks promisingly small once ")#mi("x")#text(" goes above ")#mi("10^4")#text(" or so. Asymptotically, the last two factors in the above definition of ")#mi("E_3^*")#text(" are close to 1, and the remaining expression ")#mi("\\frac{1}{8} \\sqrt{\\pi} \\exp( - \\frac{t\\pi^2}{64}) (T^{\\prime}_0)^{3/2} e^{-\\pi T_0/4}")#text(" is basically the upper bound for ")#tao-math("\\left|C^{eff}\\right|", block: false)#text(" coming from the fact that ")#tao-math("\\left|C_0(p)\\right| \\leq 1/2", block: false)#text(" (equality should occur when ")#mi("x")#text(" is close to a discontinuity for ")#mi("N")#text(", i.e. ")#mi("x + \\pi t/4 \\approx 4\\pi N^2")#text(").")

#text("In the end I didn’t quite use the suggestion of splitting the ")#mi("\\sigma")#text(" integration into small and large portions; instead it was more efficient to estimate various factors in the integrands by expressions of the form ")#mi("\\exp( a \\sigma^2 + b \\sigma + c )")#text(" for ")#mi("a")#text(" not too large, which could then be absorbed into the gaussian factors in the f factor. The case of very large ")#mi("k")#text(" had to be treated separately but here ")#mi("\\sigma")#text(" was very large and negative and the contribution was in fact super-exponentially small from this case.")

#text("I’ll double check the ")#mi("E_3^*")#text(" derivation soon, and also start working on getting some usable upper bound on ")#mi("E_1,E_2")#text(". If we have all that then it seems that by putting everything together we should be able to handle all ")#mi("x")#text(" past a certain point (e.g. ")#mi("N \\geq 200")#text(", which corresponds to ")#mi("x \\geq 5 \\times 10^6")#text(" or so), leaving one with a range that looks (barely) within the range of numerical verification.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493384")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("I get an exact match with your wiki table, the one that compares the normalised ")#mi("C^{eff}")#text(" and ")#mi("E_{3}^{*}")#text(". Also produced some graphs that illustrate how well the new bound actually works. The discontinuities that David spotted in the previous thread are well visible and appear to all stay within the bound.")

#text("Using ")#mi("t=y=0.4")#text(":")

#text("For ")#mi("500 \\le x \\le 10^{3}")#text(": ")#link("https://ibb.co/d7zDv7")[#text("https://ibb.co/d7zDv7")]

#text("For ")#mi("500 \\le x \\le 10^{4}")#text(": ")#link("https://ibb.co/efY6F7")[#text("https://ibb.co/efY6F7")]

#text("For ")#mi("500 \\le x \\le 10^{5}")#text(": ")#link("https://ibb.co/eYdZ2n")[#text("https://ibb.co/eYdZ2n")]

#text("For ")#mi("500 \\le x \\le 10^{6}")#text(": ")#link("https://ibb.co/fjSu2n")[#text("https://ibb.co/fjSu2n")]

#text("For ")#mi("500 \\le x \\le 10^{7}")#text(": ")#link("https://ibb.co/gDsf8S")[#text("https://ibb.co/gDsf8S")]

#text("Also got some encouraging timing results for the oncoming numerical verification effort.")

#mi("H^{eff}(10^7 + 0.4i)")#text(" with the latest ")#mi("C^{eff}")#text(", now computes in Pari/gp in 32.2 ms, compared to the previous ")#mi("C^{eff}")#text(" (with the vwf-integral) that required 87.9 ms. A step change improvement :)")

#emph[#text("[Linked to on wiki, thanks! -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493398")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("Thanks much for the graphs Rudolph. I see that one should be careful in drawing conclusions about the fine structure when eyeballing these. See e.g. x=[1200,10000] in graph 3, then in graph 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493400")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("Note that the graph’s y-axis scaling reduces for higher x to be able to keep the differences visible. Eyeballing these graphs should just help reinforce the intuition and most certainly won’t provide any hard evidence :)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493401")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("Yup thanks again.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("Is it possible to derive (for any fixed positive ")#mi("t, y")#text(" and sufficiently large ")#mi("x")#text(") a simple effective bound for ")#mi("H_t(x+ i y) / B_0^{eff} -1")#text(" which would decay to zero for large ")#mi("x")#text("?")#linebreak()#text(" It seems that such bound is sufficient to give an effective upper bound (i.e. an explicit function of ")#mi("t")#text(") on the real part of any nonreal zero of ")#mi("H_t")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("We’re close to doing this I think. By the triangle inequality we have")

#tao-math("\\left|\\frac{H_t}{B_0^{eff}}-1\\right| \\leq \\frac{\\left|A^{eff}\\right|}{\\left|B_0^{eff}\\right|} + \\frac{\\left|B^{eff}-B^{eff}_0\\right|}{\\left|B^{eff}_0\\right|} + \\frac{\\left|E_1\\right|}{\\left|B^{eff}_0\\right|} + \\frac{\\left|E_2\\right|}{\\left|B^{eff}_0\\right|} + \\frac{\\left|E^*_3\\right|}{\\left|B^{eff}_0\\right|}.", block: false)

#text("All terms on the right hand side are known to go to zero as ")#mi("x \\to \\infty")#text(", and if we made the effort we could probably get enough effective bounds on all of these to produce an explicit rate. But this would probably not be the most efficient way to keep ")#mi("H_t")#text(" away from zero; in particular it seems useful to multiply ")#mi("H_t/B^{eff}_0")#text(" by a suitable mollifier first before subtracting 1 in order to reduce the oscillation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, fifth thread: finishing off the test problem? | What's new")]], [#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493395")[#strong[#text("Polymath15, fifth thread: finishing off the test problem? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]
