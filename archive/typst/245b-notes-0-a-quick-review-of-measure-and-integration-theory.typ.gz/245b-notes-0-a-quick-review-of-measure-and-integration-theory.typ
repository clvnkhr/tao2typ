// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:35:30.324943+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, notes 0: A quick review of measure and integration theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, notes 0: A quick review of measure and integration theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In these notes we quickly review the basics of abstract measure theory and integration theory, which were covered in the previous course but will of course be relied upon in the current course. This is only a brief summary of the material; of course, one should consult a real analysis text for the full details of the theory.")

#heading(level: 1)[#metadata(none) <tao-58cd1ee7f41de58932ab>#text("— Measurable spaces —")]

#text("Ideally, measure theory on a space X should be able to assign a measure (or “volume”, or “mass”, etc.) to every set in X. Unfortunately, due to paradoxes such as the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(", many natural notions of measure (e.g. Lebesgue measure) cannot be applied to measure all subsets of X; instead, one must restrict attention to certain ")#emph[#text("measurable")]#text(" subsets of X. This turns out to suffice for most applications; for instance, just about any “non-pathological” subset of Euclidean space that one actually encounters will be Lebesgue measurable (as a general rule of thumb, any set which does not rely on the axiom of choice in its construction will be measurable).")

#text("To formalise this abstractly, we use")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" A ")#emph[#text("measurable space")]#text(" ")#mi("(X,{\\mathcal X})")#text(" is a set X, together with a collection ")#mi("{\\mathcal X}")#text(" of subsets of X which form a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebra")]#text(", thus ")#mi("{\\mathcal X}")#text(" contains the empty set and X, and is closed under countable intersections, countable unions, and complements. A subset of X is said to be measurable with respect to the measurable space if it lies in ")#mi("{\\mathcal X}")#text(".")

#text("A function ")#mi("f: X \\to Y")#text(" from one measurable space ")#mi("(X, {\\mathcal X})")#text(" to another ")#mi("(Y, {\\mathcal Y})")#text(" is said to be measurable if ")#mi("f^{-1}(E) \\in {\\mathcal X}")#text(" for all ")#mi("E \\in {\\mathcal Y}")#text(".")
]

#strong[#text("Remark 1.")]#text(" The class of measurable spaces forms a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(", with the measurable functions being the morphisms. The symbol ")#mi("\\sigma")#text(" stands for “countable union”; cf. ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("\\sigma")#text("-compact")]#text(", ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("\\sigma")#text("-finite")]#text(", ")#link("http://en.wikipedia.org/wiki/F%CF%83_set")[#mi("F_\\sigma")#text(" set")]#text(" . ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" The notion of a measurable space ")#mi("(X,{\\mathcal X})")#text(" (and of a measurable function) is superficially similar to that of a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological space")]#text(" ")#mi("(X,{\\mathcal F})")#text(" (and of a continuous function); the topology ")#mi("{\\mathcal F}")#text(" contains ")#mi("\\emptyset")#text(" and X just as the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" does, but is now closed under arbitrary unions and finite intersections, rather than countable unions, countable intersections, and complements. The two categories are linked to each other by the ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("Borel algebra")]#text(" construction, see Example 2 below. ")#mi("\\diamond")

#strong[#text("Example 1.")]#text(" We say that one ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" on a set X is ")#emph[#text("coarser")]#text(" than another ")#mi("{\\mathcal X}^{\\prime}")#text(" (or that ")#mi("{\\mathcal X}^{\\prime}")#text(" is finer than ")#mi("{\\mathcal X}")#text(") if ")#mi("{\\mathcal X} \\subset {\\mathcal X^{\\prime}}")#text(" (or equivalently, if the identity map from ")#mi("(X, {\\mathcal X}^{\\prime})")#text(" to ")#mi("(X, {\\mathcal X})")#text(" is measurable); thus every set which is measurable in the coarse space is also measurable in the fine space. The coarsest ")#mi("\\sigma")#text("-algebra on a set X is the ")#emph[#text("trivial")]#text(" ")#mi("\\sigma")#text("-algebra ")#mi("\\{ \\emptyset, X \\}")#text(", while the finest is the ")#emph[#text("discrete")]#text(" ")#mi("\\sigma")#text("-algebra ")#mi("2^X:= \\{ E: E \\subset X \\}")#text(". ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" The intersection ")#mi("\\bigwedge_{\\alpha \\in A} {\\mathcal X}_\\alpha := \\bigcap_{\\alpha \\in A} {\\mathcal X}_\\alpha")#text(" of an arbitrary family ")#mi("({\\mathcal X}_\\alpha)_{\\alpha \\in A}")#text(" of ")#mi("\\sigma")#text("-algebras on X is another ")#mi("\\sigma")#text("-algebra on X. Because of this, given any collection ")#mi("{\\mathcal F}")#text(" of sets on X we can define the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}[{\\mathcal F}]")#text(" ")#emph[#text("generated")]#text(" by ")#mi("{\\mathcal F}")#text(", defined to be the intersection of all the ")#mi("\\sigma")#text("-algebras containing ")#mi("{\\mathcal F}")#text(", or equivalently the coarsest algebra for which all sets in ")#mi("{\\mathcal F}")#text(" are measurable. (This intersection is non-vacuous, since it will always involve the discrete ")#mi("\\sigma")#text("-algebra ")#mi("2^X")#text(".) In particular, the open sets ")#mi("{\\mathcal F}")#text(" of a topological space ")#mi("(X,{\\mathcal F})")#text(" generate a ")#mi("\\sigma")#text("-algebra, known as the ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#emph[#text("Borel ")#mi("\\sigma")#text("-algebra")]]#text(" of that space.")

#text("We can also define the")#link("http://en.wikipedia.org/wiki/Join_(mathematics)")[#text(" join")]#text(" ")#mi("\\bigvee_{\\alpha \\in A} {\\mathcal X}_\\alpha")#text(" of any family ")#mi("({\\mathcal X}_\\alpha)_{\\alpha \\in A}")#text(" of ")#mi("\\sigma")#text("-algebras on X by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\bigvee_{\\alpha \\in A} {\\mathcal X}_\\alpha := {\\mathcal B}[ \\bigcup_{\\alpha \\in A} {\\mathcal X}_\\alpha ].")]]

#text("For instance, the Lebesgue ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal L}")#text(" of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measurable")[#text("Lebesgue measurable sets")]#text(" on a Euclidean space ")#mi("{\\Bbb R}^n")#text(" is the join of the Borel ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(" and the algebra of ")#link("http://en.wikipedia.org/wiki/Null_set")[#text("null sets")]#text(" and their complements (also called ")#emph[#text("co-null sets")]#text("). ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" A function ")#mi("f: X \\to Y")#text(" from one topological space to another is said to be")#emph[#text(" Borel measurable")]#text(" if it is measurable once X and Y are equipped with their respective Borel ")#mi("\\sigma")#text("-algebras. Show that every continuous function is Borel measurable. (The converse statement, of course, is very far from being true; for instance, the pointwise limit of a sequence of measurable functions, if it exists, is also measurable, whereas the analogous claim for continuous functions is completely false.) ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" A function ")#mi("f: {\\Bbb R}^n \\to {\\Bbb C}")#text(" is said to be ")#emph[#text("Lebesgue measurable")]#text(" if it is measurable from ")#mi("{\\Bbb R}^n")#text(" (with the Lebesgue ")#mi("\\sigma")#text("-algebra) to ")#mi("{\\Bbb C}")#text(" (with the ")#emph[#text("Borel")]#text(" ")#mi("\\sigma")#text("-algebra), or equivalently if ")#mi("f^{-1}(B)")#text(" is Lebesgue measurable for every open ball B in ")#mi("{\\Bbb C}")#text(". Note the asymmetry between Lebesgue and Borel here; in particular, the composition of two Lebesgue measurable functions need ")#emph[#text("not")]#text(" be Lebesgue measurable. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" Given a function ")#mi("f: X \\to Y")#text(" from a set X to a measurable space ")#mi("(Y, {\\mathcal Y})")#text(", we can define the ")#link("http://en.wikipedia.org/wiki/Pullback")[#text("pullback")]#text(" ")#mi("f^{-1}({\\mathcal Y})")#text(" of ")#mi("{\\mathcal Y}")#text(" to be the ")#mi("\\sigma")#text("-algebra ")#mi("f^{-1}({\\mathcal Y}) := \\{ f^{-1}(E): E \\in {\\mathcal Y} \\}")#text("; this is the coarsest structure on X that makes f measurable. For instance, the pullback of the Borel ")#mi("\\sigma")#text("-algebra from [0,1] to ")#mi("{}[0,1]^2")#text(" under the map ")#mi("(x,y) \\mapsto x")#text(" consists of all sets of the form ")#mi("E \\times [0,1]")#text(", where ")#mi("E \\subset [0,1]")#text(" is Borel-measurable.")

#text("More generally, given a family ")#mi("(f_{\\alpha}: X \\to Y_\\alpha)_{\\alpha \\in A}")#text(" of functions into measurable spaces ")#mi("(Y_\\alpha, {\\mathcal Y}_\\alpha)")#text(", we can form the ")#mi("\\sigma")#text("-algebra ")#mi("\\bigvee_{\\alpha \\in A} f_\\alpha^{-1}({\\mathcal Y}_\\alpha)")#text(" ")#emph[#text("generated")]#text(" by the ")#mi("f_\\alpha")#text("; this is the coarsest structure on X that makes all the ")#mi("f_\\alpha")#text(" simultaneously measurable.")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" In probability theory and information theory, the functions ")#mi("f_\\alpha: X \\to Y_\\alpha")#text(" in Example 3 can be interpreted as observables, and the ")#mi("\\sigma")#text("-algebra generated by these observables thus captures mathematically the concept of observable information. For instance, given a time parameter t, one might define the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal F}_{\\leq t}")#text(" generated by all observables for some random process (e.g. Brownian motion) that can be made at time t or earlier; this endows the underlying event space X with an uncountable increasing family of ")#mi("\\sigma")#text("-algebras. ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" If E is a subset of a measurable space ")#mi("(Y, {\\mathcal Y})")#text(", the pullback of ")#mi("{\\mathcal Y}")#text(" under the inclusion map ")#mi("\\iota: E \\to Y")#text(" is called the ")#emph[#text("restriction ")]#text("of ")#mi("{\\mathcal Y}")#text(" to E and is denoted ")#mi("{\\mathcal Y}\\downharpoonright_E")#text(". Thus, for instance, we can restrict the Borel and Lebesgue ")#mi("\\sigma")#text("-algebras on a Euclidean space ")#mi("{\\Bbb R}^n")#text(" to any subset of such a space. ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Let M be an n-dimensional ")#link("http://en.wikipedia.org/wiki/Manifold")[#text("manifold")]#text(", and let ")#mi("(\\pi_\\alpha: U_\\alpha \\to V_\\alpha)")#text(" be an ")#link("http://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlas")]#text(" of coordinate charts for M, where ")#mi("U_\\alpha")#text(" is an open cover of M and ")#mi("V_\\alpha")#text(" are open subsets of ")#mi("{\\Bbb R}^n")#text(". Show that the Borel ")#mi("\\sigma")#text("-algebra on M is the unique ")#mi("\\sigma")#text("-algebra whose restriction to each ")#mi("U_\\alpha")#text(" is the pullback via ")#mi("\\pi_\\alpha")#text(" of the restriction of the Borel ")#mi("\\sigma")#text("-algebra of ")#mi("{\\Bbb R}^n")#text(" to ")#mi("V_\\alpha")#text(". ")#mi("\\diamond")

#strong[#text("Example 5.")]#text(" A function ")#mi("f: X \\to A")#text(" into some index set A will partition X into level sets ")#mi("f^{-1}(\\{\\alpha\\})")#text(" for ")#mi("\\alpha \\in A")#text("; conversely, every ")#link("http://en.wikipedia.org/wiki/Partition_of_a_set")[#text("partition")]#text(" ")#mi("X = \\bigcup_{\\alpha \\in A} E_\\alpha")#text(" of X arises from at least one function f in this manner (one can just take f to be the map from points in X to the partition cell that that point lies in). Given such an f, we call the ")#mi("\\sigma")#text("-algebra ")#mi("f^{-1}(2^A)")#text(" the ")#mi("\\sigma")#text("-algebra ")#emph[#text("generated")]#text(" by the partition; a set is measurable with respect to this structure if and only if it is the union of some sub-collection ")#mi("\\bigcup_{\\alpha \\in B} E_\\alpha")#text(" of cells of the partition. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Show that a ")#mi("\\sigma")#text("-algebra on a finite set X necessarily arises from a partition ")#mi("X = \\bigcup_{\\alpha \\in A} E_\\alpha")#text(" as in Example 5, and furthermore the partition is unique (up to relabeling). Thus in the finite world, ")#mi("\\sigma")#text("-algebras are essentially the same concept as partitions. ")#mi("\\diamond")

#strong[#text("Example 6.")]#text(" Let ")#mi("(X_\\alpha, {\\mathcal X}_\\alpha)_{\\alpha \\in A}")#text(" be a family of measurable spaces, then the Cartesian product ")#mi("\\prod_{\\alpha \\in A} X_\\alpha")#text(" has canonical projection maps ")#mi("\\pi_\\beta: \\prod_{\\alpha \\in A} X_\\alpha \\to X_\\beta")#text(" for each ")#mi("\\beta \\in A")#text(". The ")#emph[#text("product ")#mi("\\sigma")#text("-algebra")]#text(" ")#mi("\\prod_{\\alpha \\in A} {\\mathcal X}_\\alpha")#text(" is defined as the ")#mi("\\sigma")#text("-algebra on ")#mi("\\prod_{\\alpha \\in A} X_\\alpha")#text(" generated by the ")#mi("\\pi_\\alpha")#text(" as in Example 3. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Let ")#mi("(X_\\alpha)_{\\alpha \\in A}")#text(" be an at most countable family of ")#link("http://en.wikipedia.org/wiki/Second-countable_space")[#text("second countable")]#text(" topological spaces. Show that the Borel ")#mi("\\sigma")#text("-algebra of the product space (with the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text(") is equal to the product of the Borel ")#mi("\\sigma")#text("-algebras of the factor spaces. In particular, the Borel ")#mi("\\sigma")#text("-algebra on ")#mi("{\\Bbb R}^n")#text(" is the product of n copies of the Borel ")#mi("\\sigma")#text("-algebra on ")#mi("{\\Bbb R}")#text(". (The claim can fail when the countability hypotheses are dropped, though in most applications in analysis, these hypotheses are satisfied.) We caution however that the Lebesgue ")#mi("\\sigma")#text("-algebra on ")#mi("{\\Bbb R}^n")#text(" is ")#emph[#text("not")]#text(" the product of n copies of the one-dimensional Lebesgue ")#mi("\\sigma")#text("-algebra, as it contains some additional null sets; however, it is the completion of that product. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("(X,{\\mathcal X})")#text(" and ")#mi("(Y,{\\mathcal Y})")#text(" be measurable spaces. Show that if E is measurable with respect to ")#mi("{\\mathcal X} \\times {\\mathcal Y}")#text(", then for every ")#mi("x \\in X")#text(", the set ")#mi("\\{ y \\in Y: (x,y) \\in E \\}")#text(" is measurable in ")#mi("{\\mathcal Y}")#text(", and similarly for every ")#mi("y \\in Y")#text(", the set ")#mi("\\{ x \\in X: (x,y) \\in E \\}")#text(" is measurable in ")#mi("{\\mathcal X}")#text(". Thus, sections of Borel-measurable sets are again Borel-measurable. (The same is not true for Lebesgue-measurable sets.) ")#mi("\\diamond")

#heading(level: 1)[#text("— Measure spaces —")]

#text("Now we endow measurable spaces with a ")#link("http://en.wikipedia.org/wiki/Measure_(mathematics)")[#text("measure")]#text(", turning them into measure spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" (Measures) A (non-negative) ")#emph[#text("measure")]#text(" ")#mi("\\mu")#text(" on a measurable space ")#mi("(X, {\\mathcal X})")#text(" is a function ")#mi("\\mu: {\\mathcal X} \\to [0,+\\infty]")#text(" such that ")#mi("\\mu(\\emptyset)=0")#text(", and such that we have the countable additivity property ")#mi("\\mu( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu(E_n)")#text(" whenever ")#mi("E_1,E_2,\\ldots")#text(" are disjoint measurable sets. We refer to the triplet ")#mi("(X,{\\mathcal X},\\mu)")#text(" as a ")#emph[#text("measure space")]#text(".")

#text("A measure space ")#mi("(X,{\\mathcal X},\\mu)")#text(" is ")#emph[#text("finite")]#text(" if ")#mi("\\mu(X) < \\infty")#text("; it is a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#emph[#text("probability space")]]#text(" if ")#mi("\\mu(X)=1")#text(" (and then we call ")#mi("\\mu")#text(" a ")#emph[#text("probability measure")]#text("). It is ")#emph[#mi("\\sigma")#text("-finite")]#text(" if X can be covered by countably many sets of finite measure.")

#text("A measurable set E is a null set if ")#mi("\\mu(E)=0")#text(". A property on points x in X is said to hold for ")#link("http://en.wikipedia.org/wiki/Almost_everywhere")[#emph[#text("almost every")]]#text(" ")#mi("x \\in X")#text(" (or ")#link("http://en.wikipedia.org/wiki/Almost_surely")[#emph[#text("almost surely")]]#text(", for probability spaces) if it holds outside of a null set. We abbreviate almost every and almost surely as a.e. and a.s. respectively. The complement of a null set is said to be a ")#emph[#text("co-null set")]#text(" or to have ")#emph[#text("full measure")]#text(".")
]

#strong[#text("Example 7. ")]#text("(")#link("http://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac measures")]#text(") Given any measurable space ")#mi("(X,{\\mathcal X})")#text(" and a point ")#mi("x \\in X")#text(", we can define the ")#emph[#text("Dirac measure")]#text(" (or ")#emph[#text("Dirac mass")]#text(") ")#mi("\\delta_x")#text(" to be the measure such that ")#mi("\\delta_x(E) = 1")#text(" when ")#mi("x \\in E")#text(" and ")#mi("\\delta_x(E)=0")#text(" otherwise. This is a probability measure. ")#mi("\\diamond")

#strong[#text("Example 8.")]#text(" (")#link("http://en.wikipedia.org/wiki/Counting_measure")[#text("Counting measure")]#text(") Given any measurable space ")#mi("(X,{\\mathcal X})")#text(", we define counting measure ")#mi("\\#")#text(" by defining ")#mi("\\#(E)")#text(" to be the cardinality |E| of E when E is finite, or ")#mi("+\\infty")#text(" otherwise. This measure is finite when X is finite, and ")#mi("\\sigma")#text("-finite when X is at most countable. If X is also finite, we can define ")#emph[#text("normalised counting measure")]#text(" ")#tao-math("\\frac{1}{\\left|X\\right|} \\#", block: false)#text("; this is a probability measure, also known as ")#link("http://en.wikipedia.org/wiki/Uniform_distribution_(discrete)")[#emph[#text("uniform probability measure")]]#text(" on X (especially if we give X the discrete ")#mi("\\sigma")#text("-algebra). ")#mi("\\diamond")

#strong[#text("Example 9. ")]#text(" Any finite non-negative linear combination of measures is again a measure; any finite convex combination of probability measures is again a probability measure. ")#mi("\\diamond")

#strong[#text("Example 10.")]#text(" If ")#mi("f: X \\to Y")#text(" is a measurable map from one measurable space ")#mi("(X,{\\mathcal X})")#text(" to another ")#mi("(Y, {\\mathcal Y})")#text(", and ")#mi("\\mu")#text(" is a measure on ")#mi("{\\mathcal X}")#text(", we can define the push-forward ")#mi("f_* \\mu: {\\mathcal Y} \\to [0,+\\infty]")#text(" by the formula ")#mi("f_* \\mu(E) := \\mu(f^{-1}(E))")#text("; this is a measure on ")#mi("(Y, {\\mathcal Y})")#text(". Thus, for instance, ")#mi("f_* \\delta_x = \\delta_{f(x)}")#text(" for all ")#mi("x \\in X")#text(". ")#mi("\\diamond")

#text("We record some basic properties of measures of sets:")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu)")#text(" be a measure space.")

#enum(start: 1, 
[#text("(Monotonicity) If ")#mi("E \\subset F")#text(" are measurable sets, then ")#mi("\\mu(E) \\leq \\mu(F)")#text(". (In particular, any measurable subset of a null set is again a null set.)")],
[#text("(Countable subadditivity) If ")#mi("E_1,E_2,\\ldots")#text(" are a countable sequence of measurable sets, then ")#mi("\\mu(\\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty \\mu(E_n)")#text(". (Of course, one also has subadditivity for finite sequences.) In particular, any countable union of null sets is again a null set.")],
[#text("(Monotone convergence for sets) If ")#mi("E_1 \\subset E_2 \\subset \\ldots")#text(" are measurable, then ")#mi("\\mu(\\bigcup_{n=1}^\\infty E_n) = \\lim_{n\\to \\infty} \\mu(E_n)")#text(".")],
[#text("(Dominated convergence for sets) If ")#mi("E_1 \\supset E_2 \\supset \\ldots")#text(" are measurable, and ")#mi("\\mu(E_1)")#text(" is finite, then ")#mi("\\mu(\\bigcap_{n=1}^\\infty E_n) = \\lim_{n\\to \\infty} \\mu(E_n)")#text(". Show that the claim can fail if ")#mi("\\mu(E_1)")#text(" is infinite. ")#mi("\\diamond")]
)

#strong[#text("Exercise 7.")]#text(" A measure space is said to be complete if every subset of a null set is measurable (and is thus again a null set). Show that every measure space ")#mi("(X, {\\mathcal X}, \\mu)")#text(" has a unique minimal complete refinement ")#mi("(X, \\overline{{\\mathcal X}}, \\mu)")#text(", known as the completion of ")#mi("(X, {\\mathcal X}, \\mu)")#text(", and that a set is measurable in ")#mi("\\overline{{\\mathcal X}}")#text(" if and only if it is equal almost everywhere to a measurable set in ")#mi("{\\mathcal X}")#text(". (The completion of the Borel ")#mi("\\sigma")#text("-algebra with respect to Lebesgue measure is known as the Lebesgue ")#mi("\\sigma")#text("-algebra.) ")#mi("\\diamond")

#text("A powerful way to construct measures on ")#mi("\\sigma")#text("-algebras ")#mi("{\\mathcal X}")#text(" is to first construct them on a smaller ")#emph[#text("Boolean algebra")]#text(" ")#mi("{\\mathcal A}")#text(" that generates ")#mi("{\\mathcal X}")#text(", and then extend them via the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Caratheodory_extension_theorem")[#text("Carathéodory’s extension theorem")]#text(", special case) Let ")#mi("(X, {\\mathcal X})")#text(" be a measurable space, and let ")#mi("{\\mathcal A}")#text(" be a Boolean algebra (i.e. closed under ")#emph[#text("finite")]#text(" unions, intersections, and complements) that generates ")#mi("{\\mathcal X}")#text(". Let ")#mi("\\mu: {\\mathcal A} \\to [0,+\\infty]")#text(" be a function such that")

#enum(start: 1, 
[#mi("\\mu(\\emptyset) = 0")#text(";")],
[#text("If ")#mi("A_1,A_2,\\ldots \\in {\\mathcal A}")#text(" are disjoint and ")#mi("\\bigcup_{n=1}^\\infty A_n \\in {\\mathcal A}")#text(", then ")#mi("\\mu( \\bigcup_{n=1}^\\infty A_n ) = \\sum_{n=1}^\\infty \\mu(A_n)")#text(".")]
)

#text("Then ")#mi("\\mu")#text(" can be extended to a measure ")#mi("\\mu: {\\mathcal X} \\to [0,+\\infty]")#text(" on ")#mi("{\\mathcal X}")#text(", which we shall also call ")#mi("\\mu")#text(".")
]

#strong[#text("Remark 5. ")]#text(" The conditions 1,2 in the above theorem are clearly necessary if ")#mi("\\mu")#text(" has any hope to be extended to a measure on ")#mi("{\\mathcal X}")#text(". Thus this theorem gives a necessary and sufficient condition for a function on a Boolean algebra to be extended to a measure. The extension can easily be shown to be unique when X is ")#mi("\\sigma")#text("-finite. ")#mi("\\diamond")

#strong[#text("Proof. ")]#text("(sketch) Define the outer measure ")#mi("\\mu_*(E)")#text(" of any set ")#mi("E \\subset X")#text(" as the infimum of ")#mi("\\sum_{n=1}^\\infty \\mu(A_n)")#text(", where ")#mi("(A_n)_{n=1}^\\infty")#text(" ranges over all coverings of E by elements in ")#mi("{\\mathcal A}")#text(". It is not hard to see that ")#mi("\\mu_*")#text(" agrees with ")#mi("\\mu")#text(" on ")#mi("{\\mathcal A}")#text(", so it will suffice to show that it is a measure on ")#mi("{\\mathcal X}")#text(".")

#text("It is easy to check that ")#mi("\\mu_*")#text(" is monotone and countably subadditive (as in parts 1,2 of Exercise 6) on all of ")#mi("2^X")#text(", and assigns zero to ")#mi("\\emptyset")#text("; thus it is an ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure in the abstract sense")]#text(". But we need to show countable additivity on ")#mi("{\\mathcal X}")#text(". The key is to first show the related property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu_*(A) = \\mu_*(A \\cap E) + \\mu_*(A \\backslash E)")]]

#text("for all ")#mi("A \\subset X")#text(" and ")#mi("E \\in {\\mathcal X}")#text(". This can first be shown for ")#mi("E \\in {\\mathcal A}")#text(", and then one observes that the class of E that obey (2) for all A is a ")#mi("\\sigma")#text("-algebra; we leave this as a (moderately lengthy) exercise.")

#text("The identity (2) already shows that ")#mi("\\mu_*")#text(" is finitely additive on ")#mi("{\\mathcal X}")#text("; combining this with countable subadditivity and monotonicity, we conclude that ")#mi("\\mu_*")#text(" is countably additive, as required. ")#mi("\\Box")

#strong[#text("Exercise 8.")]#text(" Let the notation and hypotheses be as in Theorem 1. Show that given any ")#mi("\\varepsilon > 0")#text(" and any set ")#mi("E \\in {\\mathcal X}")#text(" of finite measure, there exists a set ")#mi("F \\in {\\mathcal A}")#text(" which differs from E by a set of measure at most ")#mi("\\varepsilon")#text(". Thus sets in the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" “almost” lie in the algebra ")#mi("{\\mathcal A}")#text("; this is an example of ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s first principle")]#text(". The same statements of course apply for the completion ")#mi("\\overline{{\\mathcal X}}")#text(" of ")#mi("{\\mathcal X}")#text(". ")#mi("\\diamond")

#text("One can use Theorem 1 to construct Lebesgue measure on ")#mi("{\\Bbb R}")#text(" and on ")#mi("{\\Bbb R}^n")#text(" (taking ")#mi("{\\mathcal A}")#text(" to be, say, the algebra generated by half-open intervals or boxes), although the verification of hypothesis 2 of Theorem 2 turns out to be somewhat delicate, even in the one-dimensional case. But one can at least get the higher-dimensional Lebesgue measure from the one-dimensional one by the product measure construction:")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("(X_1,{\\mathcal X}_1,\\mu_1), \\ldots, (X_n,{\\mathcal X}_n,\\mu_n)")#text(" be a finite collection of ")#mi("\\sigma")#text("-finite measure spaces, and let ")#mi("(\\prod_{i=1}^n X_i, \\prod_{i=1}^n {\\mathcal X}_i)")#text(" be the product measurable space . Show that there exists a unique measure ")#mi("\\mu")#text(" on this space such that ")#mi("\\mu( \\prod_{i=1}^n A_i ) = \\prod_{i=1}^n \\mu_i(A_i)")#text(" for all ")#mi("A_i \\in {\\mathcal X}_i")#text(". The measure ")#mi("\\mu")#text(" is referred to as the ")#emph[#text("product measure")]#text(" of the ")#mi("\\mu_1,\\ldots,\\mu_n")#text(" and is denoted ")#mi("\\prod_{i=1}^n \\mu_i")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" Let E be a Lebesgue measurable subset of ")#mi("{\\Bbb R}^n")#text(". and let m be Lebesgue measure. Establish the ")#link("http://en.wikipedia.org/wiki/Inner_regular_measure")[#text("inner regularity")]#text(" property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("m(E) =\\sup \\{ m(K): K \\subset E, \\text{ compact} \\}")]]

#text("and the ")#link("http://en.wikipedia.org/wiki/Outer_regular_measure")[#text("outer regularity")]#text(" property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4).")])
#mitex("{}m(E)=\\inf\\{m(U): E \\subset U,\\text{ op{}en}\\}")]]

#text("Combined with the fact that m is ")#link("http://en.wikipedia.org/wiki/Locally_finite_measure")[#text("locally finite")]#text(", this implies that m is a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Integration —")]

#text("Now we define integration on a measure space ")#mi("(X, {\\mathcal X}, \\mu)")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" (Integration) Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a measure space.")

#enum(start: 1, 
[#text("If ")#mi("f: X \\to [0,+\\infty]")#text(" is a non-negative ")#emph[#link("http://en.wikipedia.org/wiki/Simple_function")[#text("simple function")]]#text(" (i.e. a measurable function that only takes on finitely many values ")#mi("a_1,\\ldots,a_n")#text("), we define the integral ")#mi("\\int_X f\\ d\\mu")#text(" of f to be ")#mi("\\int_X f\\ d\\mu = \\sum_{i=1}^n a_i \\mu( f^{-1}(\\{a_i\\}) )")#text(" (with the convention that ")#mi("\\infty \\cdot 0 = 0")#text("). In particular, if ")#mi("f=1_A")#text(" is the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator function")]#text(" of a measurable set A, then ")#mi("\\int_X 1_A\\ d\\mu = \\mu(A)")#text(".")],
[#text("If ")#mi("f: X \\to [0,+\\infty]")#text(" is a non-negative measurable function, we define the integral ")#mi("\\int_X f\\ d\\mu")#text(" to be the supremum of ")#mi("\\int_X g\\ d\\mu")#text(", where g ranges over all simple functions bounded between 0 and f.")],
[#text("If ")#mi("f: X \\to [-\\infty,+\\infty]")#text(" is a measurable function, whose positive and negative parts ")#mi("f_+ := \\max(f,0)")#text(", ")#mi("f_- := \\max(-f,0)")#text(" have finite integral, we say that f is ")#emph[#link("http://en.wikipedia.org/wiki/Absolutely_integrable")[#text("absolutely integrable")]]#text(" and define ")#mi("\\int_X f\\ d\\mu := \\int_X f_+\\ d\\mu - \\int_X f_-\\ d\\mu")#text(".")],
[#text("If ")#mi("f: X \\to {\\Bbb C}")#text(" is a measurable function with real and imaginary parts absolutely integrable, we say that f is absolutely integrable and define ")#mi("\\int_X f\\ d\\mu := \\int_X \\text{Re} f\\ d\\mu + i \\int_X \\text{Im} f\\ d\\mu")#text(".")]
)

#text("We will sometimes show the variable of integration, e.g. writing ")#mi("\\int_X f(x)\\ d\\mu(x)")#text(" for ")#mi("\\int_X f\\ d\\mu")#text(", for sake of clarity.")
]

#text("The following results are standard, and the proofs are omitted:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Standard facts about integration) Let ")#mi("(X,{\\mathcal X}, \\mu)")#text(" be a measure space.")

#enum(start: 1, 
[#text("All the above integration notions are compatible with each other; for instance, if f is both non-negative and absolutely integrable, then definitions 2 and 3 (and 4) agree.")],
[#text("The functional ")#mi("f \\mapsto \\int_X f\\ d\\mu")#text(" is linear over ")#mi("{\\Bbb R}^+")#text(" for simple functions or non-negative functions, is linear over ")#mi("{\\Bbb R}")#text(" for real-valued absolutely integrable functions, and linear over ")#mi("{\\Bbb C}")#text(" for complex-valued absolutely integrable functions. In particular, the set of (real or complex) absolutely integrable functions on ")#mi("(X,{\\mathcal X},\\mu)")#text(" is a (real or complex) vector space.")],
[#text("A complex-valued measurable function ")#mi("f: X \\to {\\Bbb C}")#text(" is absolutely integrable if and only if ")#mi("\\int_X |f|\\ d\\mu < \\infty")#text(", in which case we have the ")#link("http://en.wikipedia.org/wiki/Triangle_inequality")[#text("triangle inequality")]#text(" ")#tao-math("\\left|\\int_X f\\ d\\mu\\right| \\leq \\int_X |f|\\ d\\mu", block: false)#text(". Of course, the same claim holds for real-valued measurable functions.")],
[#text("If ")#mi("f: X \\to [0,+\\infty]")#text(" is non-negative, then ")#mi("\\int_X f\\ d\\mu \\geq 0")#text(", with equality holding if and only if f = 0 a.e.")],
[#text("If one modifies an absolutely integrable function on a set of measure zero, then the new function is also absolutely integrable, and has the same integral as the original function. Similarly, two non-negative functions that agree a.e. have the same integral. (Because of this, we can meaningfully integrate functions that are only defined almost everywhere.)")],
[#text("If ")#mi("f: X \\to {\\Bbb C}")#text(" is absolutely integrable, then f is finite a.e., and vanishes outside of a ")#mi("\\sigma")#text("-finite set.")],
[#text("If ")#mi("f: X \\to {\\Bbb C}")#text(" is absolutely integrable, and ")#mi("\\varepsilon > 0")#text(" then there exists a complex-valued simple function ")#mi("g: X \\to {\\Bbb C}")#text(" such that ")#mi("\\int_X |f-g|\\ d\\mu \\leq \\varepsilon")#text(". (This is a manifestation of ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s second principle")]#text(".)")],
[#text("(Change of variables formula) If ")#mi("\\phi: X \\to Y")#text(" is a measurable map to another measurable space ")#mi("(Y,{\\mathcal Y})")#text(", and ")#mi("g: Y \\to {\\Bbb C}")#text(", then we have ")#mi("\\int_X g \\circ \\phi\\ d\\mu = \\int_Y g\\ d\\phi_* \\mu")#text(", in the sense that whenever one of the integrals is well defined, then the other is also, and equals the first.")]
)
]

#text("It is also important to note that the Lebesgue integral on ")#mi("{\\Bbb R}^n")#text(" extends the more classical ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(". As a consequence, many properties of the Riemann integral (e.g. change of variables formula with respect to smooth diffeomorphisms) are inherited by the Lebesgue integral, thanks to various limiting arguments.")

#text("We now recall the fundamental convergence theorems relating limits and integration: the first three are for non-negative functions, the last three are for absolutely integrable functions. They are ultimately derived from their namesakes in Exercise 6 and an approximation argument by simple functions, and the proofs are again omitted. (They are also closely related to each other, and are in fact largely equivalent.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (Convergence theorems) Let ")#mi("(X,{\\mathcal X}, \\mu)")#text(" be a measure space.")

#enum(start: 1, 
[#text("(")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("Monotone convergence")]#text(" for sequences) If ")#mi("0 \\leq f_1 \\leq f_2 \\leq \\ldots")#text(" are measurable, then ")#mi("\\int_X \\lim_{n \\to \\infty} f_n\\ d\\mu = \\lim_{n \\to \\infty} \\int_X f_n\\ d\\mu")#text(".")],
[#text("(Monotone convergence for series) If ")#mi("f_n: X \\to [0,+\\infty]")#text(" are measurable, then ")#mi("\\int_X \\sum_{n=1}^\\infty f_n\\ d\\mu = \\sum_{n=1}^\\infty \\int_X f_n\\ d\\mu")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(") If ")#mi("f_n: X \\to [0,+\\infty]")#text(" are measurable, then ")#mi("\\int_X \\liminf_{n \\to \\infty} f_n\\ d\\mu \\leq \\liminf_{n \\to \\infty} \\int_X f_n\\ d\\mu")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("Dominated convergence")]#text(" for sequences) If ")#mi("f_n: X \\to {\\Bbb C}")#text(" are measurable functions converging pointwise a.e. to a limit f, and ")#tao-math("\\left|f_n\\right| \\leq g", block: false)#text(" a.e. for some absolutely integrable ")#mi("g: X \\to [0,+\\infty]")#text(", then ")#mi("\\int_X \\lim_{n \\to \\infty} f_n\\ d\\mu = \\lim_{n \\to \\infty} \\int_X f_n\\ d\\mu")#text(".")],
[#text("(Dominated convergence for series) If ")#mi("f_n: X \\to {\\Bbb C}")#text(" are measurable functions with ")#mi("\\sum_n \\int_X |f_n|\\ d\\mu < \\infty")#text(", then ")#mi("\\sum_n f_n(x)")#text(" is absolutely convergent for a.e. x and ")#mi("\\int_X \\sum_{n=1}^\\infty f_n\\ d\\mu = \\sum_{n=1}^\\infty \\int_X f_n\\ d\\mu")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Egorov%27s_theorem")[#text("Egorov’s theorem")]#text(") If ")#mi("f_n: X \\to {\\Bbb C}")#text(" are measurable functions converging pointwise a.e. to a limit f on a subset A of X of finite measure, and ")#mi("\\varepsilon > 0")#text(", then there exists a set of measure at most ")#mi("\\varepsilon")#text(", outside of which ")#mi("f_n")#text(" converges uniformly to f in A. (This is a manifestation of ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s third principle")]#text(".)")]
)
]

#strong[#text("Remark 7.")]#text(" As a rule of thumb, if one does not have exact or approximate monotonicity or domination (where “approximate” means “up to an error ")#mi("e")#text(" whose ")#mi("L^1")#text(" norm ")#mi("\\int_X |e|\\ d\\mu")#text(" goes to zero”), then one should not expect the integral of a limit to equal the limit of the integral in general; there is just too much room for oscillation. ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Let ")#mi("f: X \\to {\\Bbb C}")#text(" be an absolutely integrable function on a measure space ")#mi("(X,{\\mathcal X},\\mu)")#text(". Show that f is ")#link("http://en.wikipedia.org/wiki/Uniform_integrability")[#text("uniformly integrable")]#text(", in the sense that for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" such that ")#mi("\\int_E |f|\\ d\\mu \\leq \\varepsilon")#text(" whenever E is a measurable set of measure at most ")#mi("\\delta")#text(". (The property of uniform integrability becomes more interesting, of course when applied to a family of functions, rather than to a single function.) ")#mi("\\diamond")

#text("With regard to product measures and integration, the fundamental theorem in this subject is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4. ")]#text(" (")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(") Let ")#mi("(X,{\\mathcal X},\\mu)")#text(" and ")#mi("(Y,{\\mathcal Y},\\nu)")#text(" be ")#mi("\\sigma")#text("-finite measure spaces, with product space ")#mi("(X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu)")#text(".")

#enum(start: 1, 
[#text("(Tonelli theorem) If ")#mi("f: X \\times Y \\to [0,+\\infty]")#text(" is measurable, then ")#mi("\\int_{X\\times Y} f\\ d\\mu \\times \\nu = \\int_X (\\int_Y f(x,y)\\ d\\nu(y))\\ d\\mu(x)")#text(" ")#mi("= \\int_Y (\\int_X f(x,y)\\ d\\mu(x)) d\\nu(y)")#text(".")],
[#text("(Fubini theorem) If ")#mi("f: X \\times Y \\to {\\Bbb C}")#text(" is absolutely integrable, then we also have ")#mi("\\int_{X\\times Y} f\\ d\\mu \\times \\nu = \\int_X (\\int_Y f(x,y)\\ d\\nu(y))\\ d\\mu(x)")#text(" ")#mi("= \\int_Y (\\int_X f(x,y)\\ d\\mu(x)) d\\nu(y)")#text(", with the inner integrals being absolutely integrable a.e. and the outer integrals all being absolutely integrable.")],
[#text("If ")#mi("(X,{\\mathcal X},\\mu)")#text(" and ")#mi("(Y,{\\mathcal Y},\\nu)")#text(" are complete measure spaces, then the same claims hold with the product ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X} \\times {\\mathcal Y}")#text(" replaced by its completion.")]
)
]

#strong[#text("Remark 8.")]#text(" The theorem fails for non-")#mi("\\sigma")#text("-finite spaces, but virtually every measure space actually encountered in “hard analysis” applications will be ")#mi("\\sigma")#text("-finite. (One should be cautious, however, with any space constructed using ultrafilters or the first uncountable ordinal.) It is also important that f obey some measurability in the product space; there exist non-measurable f for which the iterated integrals exist (and may or may not be equal to each other, depending on the properties of f and even on which axioms of set theory one chooses), but the product integral (of course) does not. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 20: statement of Egorov’s theorem corrected.]")

#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07f12f18c6a6ce1d779cc5f179be2187c7543f56ee81b2a23908729c82cd5915-b88e90adb7c8b2d9c1958cf062f7cf630c45d9bcfd6f548e687e101cf5707c92.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Waqar Ahmed")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-643777")[#strong[#text("Waqar Ahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Please add this site ")#link("https://snip.mathpix.com/")[#text("https://snip.mathpix.com/")]#text(" into the software section. It is used to convert the image into latex.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a75edac8286128b0d4e899a2e4e2601b1d30471a4849383ddf741b499b67dcd0-ad941f6a12224375189bb2fa337a573a0f4ac2878458ed85060fed0fb3f85670.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reinaldo Cristo")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-678766")[#strong[#text("Reinaldo Cristo")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("Terry, can we extend this definition to: spaces and subspaces as: existential possibilities whether in the mathematical, physical, philosophical or conceptual sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-678841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Ask Chat GPT")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-689156")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2025")])]

#text("Dear professor Tao:")

#text("Where do we use the assumption that ")#mi("U_\\alpha")#text(" is an open cover of M in Exercise 2?")

#emph[#text("[This is part of the definition of an atlas. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-689162")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2025")])]

#text("Dear professor Tao:")

#text("To be precise, in Example 5, should f maps to partition cells or index of partition cells?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-689213")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Dear professor Tao:")

#mi("\\mu(A_i)")#text(" should be ")#mi("\\mu_i(A_i)")#text(" in Exercise 9.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-2/#comment-689214")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Also, in Exercise 9, should we add the ")#mi("\\sigma")#text("-finite hypothesis to each factor space ")#mi("(X_i, {\\mathcal X}_i, \\mu_i)")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinwei Yu")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34564")[#strong[#text("Xinwei Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Dear Prof. Tao,")

#text("You said “any set which does not rely on the axiom of choice in its construction will be [Lebesgue] measurable”. Could you give me a hint on how to prove it or tell me where to find the proof? Thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Thanks again for a great post. A few typos:")

#text("1. Definition 1: Last sentence of the first paragraph, $\\mathcal B$ should be $\\mathcal X$?")

#text("2. Example 1: $/sigma$ should be $\\sigma$.")

#text("3. Example 4: In the first sentence $(Y, \\mathcal Y)$ is missing the right parenthesis.")

#text("4. Definition 3: In the second item, missing $\\$ in int_g.")

#text("5. Right before Theorem 3: “They are derived from their namesakes in Exercise 5” should really be Exercise 6? Same for the second paragraph of “Proof” after Remark 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c85b000ae60d66daa86352072c059c090db3d37e7267d2122fa3c7211198b9e-dcffc1dd9b7889d59319af6c163c3246de75e1a4cd88daab40d18069f404e048.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34570")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Xinwei Yu, the paper you’re looking for is by Robert Solovay")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Robert_M._Solovay")[#text("http://en.wikipedia.org/wiki/Robert_M._Solovay")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34571")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Hi Xinwei,")

#text("Solovay proved that it’s consistent with the negation of the axiom of choice that all functions are measurable. See")

#link("http://en.wikipedia.org/wiki/Non-measurable_set")[#text("http://en.wikipedia.org/wiki/Non-measurable_set")]

#text("and Solovay’s wiki entry for a discussion & ref. (Almost surely a difficult result to reprove on one’s own…)")

#text("Prof. Tao–tiny typo, in the para before Ex. 1, “the join if the Borel” –> “the join of the Borel”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinwei Yu")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34575")[#strong[#text("Xinwei Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Thanks Andy and Ian!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34576")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Thanks for the corrections!")

#text("Regarding non-measurable sets, perhaps the more precise statement is that any set which can be constructed ")#strike[#text("using")]#text(" without using the axiom of choice is measurable in at least one model of set theory (excluding the axiom of choice), though it need not be measurable in every model. But as a first approximation at least, “sets constructed without choice are measurable” is a good rule of thumb.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34581")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Don’t you mean: any set which can be constructed WITHOUT using the axiom of choice?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34590")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Shouldn’t the equation in theorem 3 item 1 be:")#linebreak()#text(" ")#mi("\\int_X \\lim_{n \\to \\infty} f_n\\ d\\mu = \\lim_{n \\to \\infty}\\int_X f_n\\ d\\mu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fd32a954b1244811372165c66d2e0e7d3c49c287250df20a64cd1df138b92d7-2340eda464d7cc2f368520668bbf2e77862f4ef07e72737648a4d4a011ec4584.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34591")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Thanks for this post. It was a pleasure to read and to find to my surprise that I could remember most of it from when I learnt it many years ago (although I would fail miserably trying to construct any of the proofs these days as I’m long out of practice).")

#text("One thing I recall is that the first text I used (Ash: Real Analysis and Probability) derived the Caratheodary theorem and then proceeded to construct Lebesgue measure etc. much as you do. Later on I picked up Rudin’s Real and Complex Analysis and found that this approach was not used. Instead some form of the Riesz Representation Theorem was used to perform the construction using linear functionals on locally compact Hausdorf spaces (if I remember correctly…). I was a bit upset at the time since, having fought may way through many pages using the first approach, it now seamed I would need to climb the same mountain again by a different route. Anyway, how might you rate the pros and cons of these two approaches?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KKK")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34592")[#strong[#text("KKK")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Hi Prof. Tao,")

#text("Is it possible to have a pdf (or latex) version of your notes? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Thanks for the corrections!")

#text("Dear James: I do plan to discuss the Riesz representation approach a bit later in this course. Both approaches are important, but arrive at the same goal (construction of the Lebesgue measure and Lebesgue integral) from opposite directions. Philosophically, it comes down to whether one views measure as the fundamental concept (and integration being defined in terms of measure, via simple functions etc.), or integration as the fundamental concept (with measure then being a special case of the integral, by specialising to indicator functions). The Caratheodory approach takes the former view, building measures first and only later defining the integral, while the Riesz approach does the opposite. The two approaches roughly correspond to two of the basic perspectives we have to view modern mathematics, namely the set-theoretic perspective (studying a space concretely, via its points and subsets) and the category-theoretic perspective (studying a space abstractly, via the functions or maps into or out of that space). Both of these perspectives are important (as are other perspectives, e.g. information-theoretic perspective, algorithmic perspective, model-theoretic perspective, etc.), and I feel it is important to have one’s foundational theoretical concepts supported by as many of these perspectives as possible.")

#text("The Caratheodory approach is more elementary – no integrals, function spaces, point set topology, etc. – but there is definitely a fair amount of combinatorial trickery involved (e.g. the verification that if one decomposes an interval into countably many subintervals, that the length of the big interval is the sum of the smaller ones is really rather non-trivial). The Riesz approach is slicker, and more natural in many ways, but does require much more theory (though this theory is definitely useful for many other things also). Also, in the Riesz approach, the hard part of building the integral still exists; but it’s just hidden in the construction of the ")#emph[#text("Riemann")]#text(" integral (or, alternatively, in the construction of Haar measure).")

#text("From a pedagogical perspective, I prefer to do Caratheodory first, to get an initial construction of Lebesgue measure and integral, then do function spaces (using the L^p spaces provided by the Lebesgue integral as model examples), and then finally to do Riesz representation and close the circle. One can do things in a different order, but I find that without the L^p spaces, the function space material becomes a bit abstract, and not as easy to motivate.")

#text("Dear KKK: I plan to include these notes in my yearly book compilation of the blog, though the timing of this particular notes turns out to be maximally unfortunate in this regard. (I am currently in the process of compiling the 2008 posts and should have a draft PDF for those shortly.) If you “print preview” the post, though, then you can get a slightly cleaner version of the file, which can be converted to PDF.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("p.s. Incidentally, one of the quickest ways I know of to construct Lebesgue measure on, say, [0,1], is to first construct it on the infinite discrete cube ")#mi("\\{0,1\\}^{{\\Bbb N}}")#text(" (which, being totally disconnected, allows for some simplifications in either the Caratheodory or Riesz approaches) and then use the binary expansion to identify this with [0,1] (modulo a countable set of terminating binary decimals, which can be easily dealt with.) But from a pedagogical perspective this is not a particularly good way to see Lebesgue measure for the first time; if you will pardon the pun, it is totally disconnected from the geometric intuition one already has for the concepts of measure and integration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34596")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("“any set which can be constructed without using the axiom of choice is measurable in at least one model of set theory (excluding the axiom of choice)”")

#text("I don’t know if I understand this statement correct, but you seem to suggest that the model to choose depends on the set? If I understand the title of Solovay’s paper “A model of set-theory in which every set of reals is Lebesgue measurable” correctly: There is at least one model of set theory (excluding the axiom of choice) in which any set that can be constructed without using the axiom of choice is measurable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34608")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("The trick of constructing Lebesgue measure by first using the totally disconnected Cantor set can also be used in proving the Riesz representation theorem (at least for finite measures). First, you construct a measure from a functional on any totally disconnected compact Hausdoff space, which is significantly simpler than the general case (in particular, if you have already done the Caratheodory approach, verifying the countable additivity hypothesis to apply the Caratheodory extension theorem is trivial). Since free compact Hausdorff spaces (in the categorical sense) are totally disconnected, every compact Hausdorff space X is a quotient of a totally disconnected compact Hausdorff space Y. By Hahn-Banach, a functional on C(X) extends to C(Y), which then gives a measure on Y which can be pushed forward to X.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fd32a954b1244811372165c66d2e0e7d3c49c287250df20a64cd1df138b92d7-2340eda464d7cc2f368520668bbf2e77862f4ef07e72737648a4d4a011ec4584.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34612")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("Dear Terence,")

#text("I had never considered the contrast between the Caratheodory and Riesz approaches as an example of the two mathematical points view that you have talked about (“problem solving and model building”- maybe that was Timothy Gowers…)")

#text("I agree that I think the Caratheodery approach is better from a pedagogical point of view – more “hands on” and leaves you with a feeling that you have constructed something “from the ground up” rather than by some clever slight of hand.")

#text("However, how would you place the Daniell integral, or the Henstock–Kurzweil one – in so far as they might be useful for a first calculus course for people who might not go on to higher level maths?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34614")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("Dear Sune: Yes, you are right, Solovay’s result even allows one to take the same model to make every set constructible without choice measurable. (Though this does raise a question that I do not know the answer to: is there a set that can be constructed without AC which is not ")#emph[#text("necessarily")]#text(" measurable, i.e. it is non-measurable in at least one model of set theory? I suppose one first has to formalise what “constructed without AC” means more precisely to answer this.)")

#text("Dear Eric: Thanks for the comments! Another way to use the totally disconnected trick is to then invoke the Kolmogorov extension theorem rather than the Caratheodory one, though this is only a minor variation of the usual Caratheodory approach in the end.")

#text("Dear James: The set-theoretic vs. category-theoretic distinction (or in this context, the measure-theoretic vs. functional distinction) is perhaps slightly different from the problem solving vs. theory building distinction that Gowers writes about, though I can see that there might be some correlation between the two in practice.")

#text("I was not too familiar with the two integrals you mentioned, so I looked them up. The Daniell integral seems like a variant of the Riesz approach, using elementary functions instead of continuous ones to build the initial linear functional that will become the integral. Meanwhile, the Henstock-Kurzweil integral seems to be a variant of the Riemann integral and thus coming from the geometric perspective rather than the measure-theoretic or functional perspectives.")

#text("For undergraduate mathematics purposes, I think the Riemann integral is largely adequate, especially outside of analysis, which is the main place in mathematics where one has to deal with singularities and other pathologies. While the Riemann integral does not enjoy the convergence theorems (Theorem 3) that make the Lebesgue integral so convenient for analysis, one at least still has good behaviour under the uniform convergence topology (which is good enough for many applications outside of analysis). Furthermore, the Riemann integral ties in closely with one’s intuitive geometric notions of area, etc., and reinforces the close analogy between summation and integration (and more generally, between the discrete and the continuous) that helps build a lot of algebraic intuition for integration also.")

#text("There is unlikely to be any one “best” notion of integration that covers all cases and applications. For instance, the Lebesgue integral (or any of the other integrals mentioned above) cannot directly handle principal value integrals, or integrals obtained via zeta function regularisation, even though both of these types of integration are of significant importance in certain subfields of mathematics. Like many other broad and fundamental mathematical concepts (e.g. “number”, “space”, “limit”, “distance”, “size”, “similar”, etc.), it seems best to view integration as a loosely related family of mathematical operations, rather than to try to force all of them artificially into a single unifying formal or axiomatic framework.")

#text("The Lebesgue approach does have a philosophy which seems particularly compatible with analysis and related disciplines, namely that it treats “small” sets as “negligible” (thus, for instance, identifying two functions if they agree outside of a set of measure zero). This fits in well with the general tendency in analysis to routinely discard various small errors. Littlewood’s principles tell us that up to such small errors, Lebesgue-measurable sets are essentially elementary, Lebesgue-measurable functions are essentially continuous, and pointwise convergence is essentially uniform, so the Lebesgue theory is basically nothing more than the completion of the classical Riemann theory, and thus very natural in any situation in which one is willing to ignore what is going on in a set of small measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, notes 0a. An alternate approach to the Carathéodory extension theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34615")[#strong[#text("254A, notes 0a. An alternate approach to the Carathéodory extension theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("[…] theorem, elementary sets, Lebesgue measure | by Terence Tao In this supplemental note to the previous lecture notes, I would like to give an alternate proof of a (weak form of the) Carathéodory extension theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2df8ddd7022a8e843e49120b9cf229e19d7492d7f64d0da0e56fda01048e8cd6-190153de264712b6c6d8de7f720f70f25413f519cda397fb2f2d92b2c2baa6bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wangtwo")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34616")[#strong[#text("wangtwo")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("Dear Pro Tao")

#text("I think in example 3 that you should use ")#mi("\\bigvee")#text(" but not ")#mi("\\bigwedge")#text(".")

#text("In the following sentence")#linebreak()#text(" “we can form the ")#mi("\\sigma")#text("-algebra ")#mi("\\bigwedge_{\\alpha \\in A} f_\\alpha^{-1}({\\mathcal Y}_\\alpha)")#text(" generated by the ")#mi("f_\\alpha")#text(";”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34636")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear Prefossor Tao:")

#text("When I met a propblem in measure theory which ask for some property for a ")#mi("\\sigma")#text("– algebra, I find I could always just asume the family of sets which satisfy this property is ")#mi("\\mathcal A")#text(" (say) and then try to prove it is indeed a ")#mi("\\sigma")#text("– algebra. This method is so strong and een in this post, it can be applied for several times. In the end, though I can finish the proof, I feel like the conclusion just come “out of nowhere”.")

#text("For an arbitrarily chosen set in a ")#mi("\\sigma")#text("– algebra, sometimes I have the impulse to get it “by hand”, I want to get this set through several countable union or countable joint, which is obvious impossible. Every time in this situation, I find the above method always can be used.")

#text("I am wondering if there are some more important thoughts in this phenomenon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34639")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear Liuxiaochuan,")

#text("One can indeed replicate the argument you describe (i.e. showing that the collection of sets that obey a certain property forms a ")#mi("\\sigma")#text("-algebra, and also contains some generating set ")#mi("{\\mathcal A}")#text(", and thus must contain the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}[{\\mathcal A}]")#text(" generated by that set) by repeatedly taking countable unions and intersections of generators in ")#mi("{\\mathcal A}")#text(" instead. The catch is that “repeatedly” means “iterated up to the first uncountable ordinal” in the case of the Borel algebra (see ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("http://en.wikipedia.org/wiki/Borel_algebra")]#text(" ), and is more complicated still in the case of general ")#mi("\\sigma")#text("-algebras (involving “trees” of at most countable depth, if I recall correctly). So the relationship between a generating set and the algebra that they generate is significantly more complicated for ")#mi("\\sigma")#text("-algebras than it is for other algebraic structures (e.g. rings, groups, vector spaces, Boolean algebras, topologies, etc.) where the description of the generated structure tends to be much more concrete and explicit.")

#text("Basically, what is going in here is that one is using powerful axioms of set theory (indeed, one is literally relying on the power set axiom, in order to consider the collection of all ")#mi("\\sigma")#text("-algebras containing a certain base set ")#mi("{\\mathcal A}")#text(") to bypass the tedious task of actually working out constructively what sets can be generated from some base set ")#mi("{\\mathcal A}")#text(" of generators, and jumping straight to the existence of the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}[{\\mathcal A}]")#text(" generated by that set ")#mi("{\\mathcal A}")#text(", without getting much information as to precisely what that ")#mi("\\sigma")#text("-algebra consists of. As a consequence, the only real way to establish properties on this ")#mi("\\sigma")#text("-algebra is to exploit its definition as the minimal ")#mi("\\sigma")#text("-algebra containing ")#mi("{\\mathcal A}")#text(".")

#text("There is a certain amount of reverse mathematics analysis in the literature that shows that some reliance on strong axioms of set theory (axiom of choice being of course the most famous one, but there are others) is necessary to establish some of the basic results in measure theory, which may give some formal limitations on what one can do by purely “constructive” methods here, but I am not really an expert on these things.")

#text("Of course, the Borel measurable sets that one actually encounters in concrete applications tend to be fairly low on the Borel hierarchy, e.g. they are often just ")#mi("F_\\sigma")#text(" or ")#mi("G_\\delta")#text(" sets at worst, and similarly for Lebesgue measurable sets, etc.. So for many specific applications, one can probably replace the general theory with some more concrete but ")#emph[#text("ad hoc")]#text(" substitute, in which everything is done “by hand” and one only takes countable unions and intersections a fairly limited number of times. This would probably make one’s arguments significantly longer and messier, though, and also harder to generalise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34645")[#strong[#text("Phil")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Hi Prof. Tao,")

#text("In Exercise 8, I think you meant to put “element of” rather than “subset of” in two instances.")

#text("Exercise 9 only seems correct when all the measures involved are probability measures.")

#text("You commented on Theorem 3 that the convergence theorems for integrals of functions were largely equivalent to the corresponding ones for sets. On the other hand, on face value, they seem to be “stronger” statements since they reduce to Exercise 5 when we apply them to characteristic functions of sets. I think this is a relevant case study for the recent discussion on Gowers’ Weblog regarding how one equivalent statement can be “stronger” than another.")

#text("From the way integration theory is developed here, they seem stronger, but consider the following alternative approach to integration of functions (which maybe you had in mind when you said they were equivalent). First construct the Lebesgue measure on R, and develop the product measure without reference to integration of functions. Define the integral of a positive function as, literally, “the area under the curve” in the product measure sense, then proceed as one usually would. From this standpoint, the linearity of the integral becomes a consequence of the translation invariance of the Lebesgue measure, and the convergence theorems for functions become special cases of the convergence theorems for sets.")

#text("I think this approach is geometrically intuitive and gives insight to the “equivalences” discussed, but probably it’s a bit too gross to practice because the constructions of Lebesgue measure and the product measure without appeal to integration can be tough and it also doesn’t generalize to vector valued integration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34653")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear Phil: Thanks for the corrections!")

#text("It is true that by interpreting a (non-negative) integral as the measure of a set in a higher-dimensional space, one can equate the integral convergence theorems with their measure counterparts, but I had a slightly different correspondence in mind, namely if one specialises a convergence theorem to the case of simple functions taking a fixed finite set of values, then the integral theorem quickly collapses to just the set version. The integral convergence theorems can then be recovered from this special case by a discretisation argument. (One has to be a little careful to avoid using the very same convergence theorem one is trying to prove in order to justify the limiting procedure, of course.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34665")[#strong[#text("245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("[…] The implication of 3. from 1. is Exercise 11 from Notes 0. The implication of 2. from 3. is trivial. To deduce 1. from 2., apply Theorem 1 to and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12e1cd09d203b7adee19b981dd355b1f1f08e5bdf6a36eb6f1a021f25b12e6f4-043f84517119398875f7b3e07bceb4d2dbebde4af63483edd7172651b8ad6029.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Shipman")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34723")[#strong[#text("Joe Shipman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("You say in your last sentence that iterated integrals may or not be equal to each other. In my thesis (Cardinal Conditions for Strong Fubini Theorems, October 1990 TAMS) I showed that for non-negative functions in n dimensions, it is consistent with ZFC (and a consequence of a real-valued measurable cardinal) that iterated integrals are always equal whenever they exist (consistency previously shown by H. Friedman for n=2; Sierpinski’s famous example where iterated integrals of non-negative functions differ depends on the continuum hypothesis). The non-negativity assumption is necessary or there are simple counterexamples, for example the function on [0,infty)^2 that is 0 for y>x, 1 for x>y>(x-1), -1 for (x-1)>y>(x-2), 0 for (x-2)>y.")#linebreak()#text(" — Joe Shipman")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("Thanks for the clarification!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/915dfe2d431a98f56f49e3643353e6072cbb5882b5463d5de974dd4bd3b6d202-8ddec3584c3304616ad7d72331787b2f6aa86a0937590417abe4a7e86cb39c77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohamed")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34742")[#strong[#text("Mohamed")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("Thanks")#linebreak()#text(" I Would ask if you have simple note regarding to differential geometry and gauge theory since I found so hard to understand this theory")#linebreak()#text(" regards")#linebreak()#text(" Mohamed")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("You might try these posts of mine:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("What is a gauge?")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/")[#text("PCM article: Ricci flow")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("285G, Lecture 0: Riemannian manifolds and curvature")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-34824")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("[…] to f outside of a set of measure zero. (Compare with Egorov’s theorem (Theorem 3.6 from Notes 0), which equates pointwise convergence with uniform convergence outside of a set of arbitrarily […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-35144")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")])]

#text("Dear Prof. Tao,")

#text("Thanks a lot for your so nice lecture note!")

#text("There seems some problem in your Egorov Theorem. I think we need to restrict the theorem on some ")#mi("\\mu")#text("-finite set ")#mi("A")#text(". Otherwise, there is a counterexample: Let ")#mi("X={\\bf R}")#text(", ")#tao-math("f_n(x)=1_{\\left|x\\right|>n}", block: false)#text(" and ")#mi("\\mu=Leb")#text(". Clearly, ")#mi("f_n \\rightarrow 0")#text(" pointwisely, but we cannot find any small set ")#mi("B")#text(" to make ")#mi("f_n \\rightarrow 0")#text(" uniformly on ")#mi("B^c")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-35147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")])]

#text("Oops, you’re right; it’s corrected now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-35892")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第零节是关于测度论的复习，基本上都是已知的结论，其中关于littlewood的三个学习实分析的原则还是蛮有意思的，我是头一次听说，不过这些思想在学习过程中依然感受到了。测度论中有很多很规范的证明方法，而且这些方法常常跟选择有关。我在评论中问了陶教授一个问题，已经困扰了我一段时间：测度论中有的问题会要求证明一个西格玛代数具有什么什么性质，这时候有一种很强大的方法，就是将满足这个性质的集合类直接设出来，然后再证明它确实是个西格玛代数。此种方法在运用的时候，常常会感到结论不知从什么地方出来的。证明的过程不具有启发性。陶教授回答了不少，上面的问题，正常的处理方法应该是从这个西格玛代数中任取一个元素，然后直接证明该元素是满足目标的性质的。但问题是，我们对这个任意的元素很难有个确切的描述。事实上，我们不得对“可数交”，“可数并”这样的操作做不可数次才行。而这本身其实正式选择公理强大行的体现。因为即使利用上面的方法构造出了“更清楚”的证明，其过程也一定会很复杂，很难看。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-36286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Dear Professor Tau,")

#text("What am I missing in Exercise 8? It seems that the example you give in Remark 1 under your “alternate approach” shows the necessity of X ")#mi("\\sigma")#text("-finite. In this example, the algebra is the collection of finite unions of sets ")#mi("[a,b) \\cap {\\Bbb Q}")#text(", ")#mi("a>b\\in{\\Bbb R}")#text(", which generates the discrete ")#mi("\\sigma")#text("-algebra on ")#mi("{\\Bbb Q}")#text(", and every non-empty set in the algebra has measure ")#mi("\\infty")#text(". If we extend to the counting measure, then the assertion in Exercise 8 fails for every ")#mi("\\varepsilon < 1")#text(" and ")#mi("E")#text(" with ")#mi("0 < \\mu(E) < \\infty")#text(".")

#text("Jim Lewis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-36290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Hmm, you’re right. I think I thought I could restrict the algebra ")#mi("{\\mathcal A}")#text(" to E so that I can work entirely in a finite measure setting, but of course this doesn’t work since E doesn’t lie in ")#mi("{\\mathcal A}")#text(". I’ve adjusted the exercise accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-39454")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Dear Prof. Tao,")

#text("is the following claim right?")

#text("” any measure on ")#mi("[0,1]")#text(" is the limit of finite linear combination of Dirac delta unit masses at points of [0,1].”")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-39455")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Yes, this is correct, as long as one uses the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to define the concept of a limit of a sequence of measures. The claim is closely related to the fact that the ")#link("http://en.wikipedia.org/wiki/Riemann-Stieltjes_integral")[#text("Riemann-Stieltjes integral")]#text(" is compatible with the ")#link("http://en.wikipedia.org/wiki/Lebesgue-Stieltjes_integral")[#text("Lebesgue-Stieltjes integral")]#text(". For instance, the vague convergence of ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} \\delta_{n/N}")#text(" to Lebesgue measure on [0,1] follows from the compatibility of the Riemann and Lebesgue integrals when integrating continuous functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-39456")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Dear Prof. Tao,")

#text("I am asking this question to clarify my understanding.")

#text("is the following right?")

#text("for any")#linebreak()#text(" right continuous,")#linebreak()#text(" nondecreasing function F,")

#text("we can define an outer measure ")#mi("\\mu^*")#text(" on power set of R, then")

#mi("\\mu^*")#text(" measurable sets form a sigma algebra ")#mi("M_{\\mu}")#text(" which contains Borel sigma algebra, and the restriction ")#mi("\\mu")#text(" of ")#mi("\\mu^*")#text(" to ")#mi("M_{\\mu}")#text(" is a complete measure and it is inner and outer regular…")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-39457")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("wow! Prof Tao, you are so fast… thanks a lot")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0bed9230663d13e60637a3af844925addcc29c7e7c04f809a59f613c7b84d45-a370e33da26faabe936757d66ddbf6d13462ee145e0ee19afba47fe73f322da4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Reid")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-40786")[#strong[#text("Mark Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")])]

#text("Dear Professor Tao,")

#text("When I studied integration theory as an undergraduate it was in the Caratheodory style you mention (measures first, integration later). Some of the work I am doing now in statistical learning theory involves a fair bit of functional analysis and expectations are a central object of study. The Riesz approach to integration theory you mention in your comment above sounds like an approach I would like to understand better.")

#text("I was wondering if you could recommend any good books (or papers) on the Riesz approach to integration theory, particularly probability theory.")

#text("Thanks in advance,")

#text("Mark.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-43033")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("[…] will assume familiarity with the foundations of measure theory; see for instance these earlier lecture notes of mine for a quick review of that topic. This is also not intended to be a first introduction to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-43039")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("“In these notes we quickly review the basics of abstract measure theory and integration theory, which was covered in the previous course..”")

#text("Which previous course is being referred to here, and is the referred course available online? If not, what is the recommended book for the referred course?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-43048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#link("http://www.math.ucla.edu/~ralston/245a.1.08f/")[#text("245a")]#text(", taught by my colleague, Jim Ralston. The textbook was Folland’s “Real Analysis”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Roth’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-44135")[#strong[#text("254B, Notes 2: Roth’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2010")])]

#text("[…] additive probability measure on . (Hint: use the Carathéodory extension theorem, see e.g. my 254B notes 0 or notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c26a03c106943ae9b230ccacf2546bca696163fa7e12767b9379b4cedcb4bc63-d47fdc0b4cc97fd5b02eed9d350c3504c46d2c9ff52b412eb5f343dddeb65184.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abdussalam mustapha")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-45123")[#strong[#text("abdussalam mustapha")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2010")])]

#text("Dear prof.")#linebreak()#text(" I am a student newly admited into Msaters programme in mathematics but I have poor background in some knowledge of the basics more especially in measure theory and integration. I want you to please assist me with materials that will help me grasp the main ideas in measures. Thank you")

#text("Mustapha Abdussalam")#linebreak()#text(" Usmanu Danfodiyo University, Sokoto,")#linebreak()#text(" Nigeria.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 245A, Real analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-46724")[#strong[#text("Course announcement: 245A, Real analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("[…] also this preliminary 245B post for a summary of the material to be covered in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-98769")[#strong[#text("An engineering introduction to measure theory « Memming")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")]

#text("[…] Terry Tao has a great summary on measure theory and integration. Advertisement Eco World Content From Across The Internet. Featured on EcoPressed The EU is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11c92a9e40dd700fbf96e4c904b9825b2165c591c799533693913426e4149ed0-b32547069fe8e29084e3425b1562d7f9cefda24c6dcbf741acbad3ff5509e154.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qasim")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-455413")[#strong[#text("Qasim")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2015")])]

#text("Hi all,")#linebreak()#text(" I am looking for Categorical properties of measurable space such as initial structure, final structure and discrete structure…Thanks in advance")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-488922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("Example 2 gives a connection between “sigma-algebra” and “topology”. Why would one need to introduce the “sigma-algebra” structure in the first place? Is it possible to develop the measure theory (and the integration theory) with merely the notion of “topology” on a set X? What could go wrong with this attempt?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-488927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("The space of continuous functions (or, for that matter, Riemann integrable functions) is not closed under pointwise limits or infinite sums, whereas the space of measurable functions is. This is one of the main advantages of the Lebesgue integration theory in analysis, as it often allows one to interchange such limits and sums with integrals using such tools as the monotone convergence theorem or dominated convergence theorem. If one could only integrate functions that respected the topology (aka continuous functions), then it becomes significantly more difficult at a technical level to perform such interchanges.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f6389068638f41dbc3dd8d15bcbb6b83609fb2299f17d95130109862311b6e5-02367edd0fc7b4cb4eff2e1ae15c06c9bf286b5f2eeadd8afa3ded3030def7ae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxie Schmidt")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-497482")[#strong[#text("Maxie Schmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("We recently had a similar extra credit assignment in my graduate Analysis II course. The assignment was to create a “roadmap” of notions of (modes of) convergence relevant to the course. I talked with the professor after showing him this link as a reference, and he suggested that I post my solution roadmap as a comment here. Without going on too much about what’s in the pdf and why it’s useful to organize and compare these topics for understanding, I will just give the link to my comparison: [roadmap pdf linked here](")#link("http://people.math.gatech.edu/~mschmidt34/files/roadmap.pdf")[#text("http://people.math.gatech.edu/~mschmidt34/files/roadmap.pdf")]#text("). I would appreciate any **constructive** feedback about this document.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6db11c42f6a299967801aba0fc1694b74efb1f5ee199ae0df48a0ce2225a79fc-479b5f38bd9d1e72b6b4931abcb1e362842b79140087686f74cfcdbfa6a49e90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Dippel")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-522083")[#strong[#text("Jack Dippel")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("Dear Terry, A small comment about Exercise 8. I am not sure about the")#linebreak()#text(" assertion that when the measure is ")#mi("\\sigma")#text("-finite, any element")#linebreak()#text(" of the ")#mi("\\sigma")#text("-algebra is well-approximated by an element of")#linebreak()#text(" the algebra ")#mi("\\mathcal{A}")#text(". For example, consider the case that")#linebreak()#text(" ")#mi("\\mathcal{A}")#text(" consists of the finite and co-finite subsets of")#linebreak()#text(" ")#mi("\\mathbb{N}")#text(", and the measure is counting measure. Then the")#linebreak()#text(" extension theorem simply gives counting measure on all subsets of")#linebreak()#text(" ")#mi("\\mathbb{N}")#text("; and if ")#mi("S\\subset \\mathbb{N}")#text(" is neither")#linebreak()#text(" finite nor co-finite, then any set ")#mi("A \\in \\mathcal{A}")#text(" will have")#linebreak()#text(" ")#tao-math("\\left|A \\triangle S\\right| = \\infty", block: false)#text(".")

#emph[#text("[You are right; I have deleted this part of the exercise. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d8e56c6515bdf809b467413fc6dfccb9df4404760d5dd25300dd46f77933483-a733215d0f5e552b3bb0bfb65ed8920b8fc5a5301840049b830a0fbcf94455e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nadroj Straw")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-522231")[#strong[#text("Nadroj Straw")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("This is a reply to Mr. Jack Dippel. I’m having trouble understanding this counter-example. Can you help me understand why the space is sigma finite?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-614177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#emph[#linebreak()#text(" We now recall the fundamental convergence theorems relating limits and integration: the first three are for non-negative functions, the last three are for absolutely integrable functions. They are ultimately derived from their namesakes in Exercise 5 and an approximation argument by simple functions, and the proofs are again omitted.")#linebreak()#text(" ")]

#text("Is there a typo in the numbering? I don’t see how the convergence theorems follow from Exercise 5. (It is probably Exercise 6.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-639105")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2022")])]

#text("Sir, I think there is something wrong in the 3rd line of proof of Theorem 1 (Caratheodary’s theorem). I think there is an extra “if”.")

#text("It is indeed the case that ")#mi("\\mu_* (A) = \\mu (A) \\forall A \\in \\mathcal{A}")#text(" by the countable-disjoint-additivity of ")#mi("\\mu")#text(" , the property ")#mi("\\mu ( \\phi ) = 0")#text(" and the Boolean algebra properties of ")#mi("\\mathcal{A}")#text(", because once we have these properties then for any two given coverings, we can refine our coverings to get a common sub-covering of each of them and then use the disjoint countable subadditivity.")#linebreak()#text(" Is this correct?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-639149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2022")])]

#text("Your comment is not clear.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-639188")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2022")])]

#text("Could you please say which part in unclear?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-639189")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2022")])]

#text("I am sorry that I am afraid that all of your comments are not clear at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-639235")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2022")])]

#text("Not sure about the other comments, but in this one, it seemed to me that there is an extra “if” (word) in the mentioned line. It is of course nothing serious.")#linebreak()#text(" But just in case someone finds a doubt thinking some part of the statement has been omitted, I gave an explanation of how the claim in that line follows.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e64663ebdb1da344143e32b97af00eb2007826a545b8c3151dbfe9c2a5057461-ddd48ac0570ddd04fe6c62fb2db02073e7f510892649a911768aad421f254525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tuzhihao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-640490")[#strong[#text("tuzhihao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Dear Prof. Tao,")

#text("In the first sentence of the first paragraph, it seems that “…, which was covered …” should be “…, which were covered …”, in order to be consistent with the previous word “the basics of …” .")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e64663ebdb1da344143e32b97af00eb2007826a545b8c3151dbfe9c2a5057461-ddd48ac0570ddd04fe6c62fb2db02073e7f510892649a911768aad421f254525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruce Tu")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-640613")[#strong[#text("Bruce Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2022")])]

#text("Dear Prof. Tao,")

#text("There seem to be some typos as follows.")

#text("1. In the second line from the last in Example 2, the second “of” of this part “… is the join of the Borel ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(" and of the algebra of …” should be dropped.")

#text("2. In the second line from the last in Example 8, “")#tao-math("\\frac{1}{\\left|E\\right|} \\#", block: false)#text("” should be “")#tao-math("\\frac{1}{\\left|X\\right|} \\#", block: false)#text("”; of course, ")#mi("X")#text(" should be non-empty so that ")#tao-math("\\left|X\\right| \\neq 0", block: false)#text(".")

#text("3. In the first sentence of the second paragraph of the proof of Theorem 1, “as in parts 1,2 of Exercise 5” should be “as in parts 1,2 of Exercise 6”.")

#text("4. In both (3) and (4) of Exercise 10, “")#mi("\\mu")#text("” should be “")#mi("m")#text("”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-641523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("I’m confused with the notion of “join” in Example 2. According to the Wikipedia link you gave in the notes, it seems that “meet” and “join” are somehow the same as “intersection” and “union” of sets as ")#link("https://en.wikipedia.org/wiki/Join_and_meet#Examples")[#text("https://en.wikipedia.org/wiki/Join_and_meet#Examples")]#text(" shows. But (1) suggests that “join” is not the same as “union”. What is going wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/comment-page-1/#comment-641537")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Joins and meets can be defined on any lattice. In the special case where the lattice happens to be the power set of some set ")#mi("X")#text(" (partially ordered by subset inclusion ")#mi("\\subseteq")#text("), then join and meet coincide with union and intersection, as noted in the examples section of the linked Wikipedia article. However, if one works with a different lattice (for instance the lattice of ")#mi("\\sigma")#text("-algebras on a domain ")#mi("X")#text(", ordered by subset inclusion) then it is entirely possible for join and meet to not agree with the union and intersection operations; as noted in the Wikipedia article, this can happen for instance if the lattice in question is a family of sets (ordered by subset inclusion) that is not closed under unions, which is the case here (the union of two sigma-algebras is not a sigma-algebra in general).")
]
]
