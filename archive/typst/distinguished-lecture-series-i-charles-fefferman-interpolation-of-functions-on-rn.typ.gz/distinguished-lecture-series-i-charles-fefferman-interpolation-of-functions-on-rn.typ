// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/
// Converted to Typst by tao2typ: "2026-10-14T16:35:04.796385+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series I: Charles Fefferman, “Interpolation of functions on R^n”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series I: Charles Fefferman, “Interpolation of functions on R^n”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/")[#text("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The first ")#link("http://www.math.ucla.edu/dls/index.html")[#text("Distinguished Lecture Series")]#text(" at UCLA of this academic year is being given this week by my good friend and fellow Medalist ")#link("http://en.wikipedia.org/wiki/Charles_Fefferman")[#text("Charlie Fefferman")]#text(", who also happens to be my “older brother” (we were both students of ")#link("http://en.wikipedia.org/wiki/Elias_Stein")[#text("Elias Stein")]#text("). The theme of Charlie’s lectures is “Interpolation of functions on ")#mi("{\\Bbb R}^n")#text("“, in the spirit of the classical ")#link("http://en.wikipedia.org/wiki/Whitney_extension_theorem")[#text("Whitney extension theorem")]#text(", except that now one is considering much more quantitative and computational extension problems (in particular, viewing the problem from a ")#link("http://en.wikipedia.org/wiki/Theoretical_computer_science")[#text("theoretical computer science")]#text(" perspective). Today Charlie introduced the basic problems in this subject, and stated some of the results of his ")#link("http://www.math.princeton.edu/facultypapers/Fefferman/FittingData_Part_I.pdf")[#text("joint")]#text(" ")#link("http://www.math.princeton.edu/facultypapers/Fefferman/Fitting_Data_Part_II.pdf")[#text("work")]#text(" with ")#link("http://www.math.princeton.edu/~bklartag/index.html")[#text("Bo’az Klartag")]#text("; he will continue the lectures on Thursday and Friday.")

#text("The general topic of extracting quantitative bounds from classical qualitative theorems is a subject that I am personally very fond of, and Charlie gave a wonderfully accessible presentation of the main results, though the actual details of the proofs were left to the next two lectures.")

#text("As usual, all errors and omissions here are my responsibility, and are not due to Charlie.")

#metadata(none) <tao-08c6425005e130cc7817>

#text("The original extension question addressed by Whitney (with further work by many others including Glaeser, Brudnyi-Shvartsman, Zobin, Bierstone-Milman-Pawlucki, Fefferman, and Brudnyi-Brudnyi) is the following. Suppose one is given a subset E of a given Euclidean space ")#mi("{\\Bbb R}^n")#text(", and suppose one also given a function ")#mi("f: E \\to {\\Bbb R}")#text(", as well as a regularity m (which is a non-negative integer). Is it then possible to extend f to a globally defined function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(" (thus ")#mi("F(x)=f(x)")#text(" for all ")#mi("x \\in E")#text("), which lies in the regularity class ")#mi("C^m({\\Bbb R}^n)")#text(" of m-times continuously differentiable functions?")

#text("Some easy remarks about this question:")

#enum(start: 1, 
[#text("The larger E is, the harder it is to obtain an extension. For instance, if E is finite, then an easy application of the ")#link("http://en.wikipedia.org/wiki/Lagrange_polynomial")[#text("Lagrange interpolation formula")]#text(" shows that any function ")#mi("f: E \\to {\\Bbb R}")#text(" can be extended to a smooth function (or even a polynomial) ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(". At the other extreme, if ")#mi("E = {\\Bbb R}^n")#text(", then of course f can be extended to a ")#mi("C^m")#text(" function F if and only if f already has bounded continuous derivatives up to ")#mi("m^{th}")#text(" order.")],
[#text("On the other hand, it is easy to reduce to the case when E is bounded; if E is unbounded and one can solve the extension problem for the bounded sets ")#mi("E \\cap B(0,R)")#text(" for every radius R (and for the restriction of f to these sets), then it is not difficult (by use of partitions of unity) to show that the extension problem can be solved for the unbounded set E.")],
[#text("One can reduce further to the case when E is compact, because if the values of a continuous function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(" is specified on a set E, this uniquely specifies F on the closure ")#mi("\\overline{E}")#text(".")]
)

#text("The case m=0 of this problem is answered by the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(". For higher m, the problem is partially answered by the ")#link("http://en.wikipedia.org/wiki/Whitney_extension_theorem")[#text("Whitney extension theorem")]#text(" (of which more will be said in subsequent talks).")

#text("Charlie’s talk is concerned with more “finitary” or “quantitative” versions of the above problem. Now E is a ")#emph[#text("finite")]#text(" subset of ")#mi("{\\Bbb R}^n")#text(", with cardinality |E|=N (say), so that ")#mi("f: E \\to {\\Bbb R}")#text(" is now simply a list of N real numbers. (One should think of n and m as being fixed and relatively small, but N as being extremely large.) As remarked above, it is now very easy to extend f to an m-times continuously differentiable function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(", and one can even make F boundedly continuously differentiable, thus the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{C^m({\\Bbb R}^n)} := \\sup_{0 \\leq j \\leq m} \\sup_{x \\in {\\Bbb R^n}} \\left|\\nabla^j F(x)\\right|", block: true)]]

#text("is finite. However, one can now ask some quantitative questions, which we will first state in a rather informal fashion:")

#enum(start: 1, 
[#text("Given the data n, m, E, f, what is the best possible value of ")#tao-math("\\left\\|F\\right\\|_{C^m({\\Bbb R}^n)}", block: false)#text("? Can this value (or some approximation to this value) be “computed” efficiently?")],
[#text("Given the data n, m, E, f, can one “compute” an extension F of f whose norm ")#tao-math("\\left\\|F\\right\\|_{C^m({\\Bbb R}^n)}", block: false)#text(" is close to optimal?")],
[#text("Can the extension operation ")#mi("f \\mapsto F")#text(" be chosen to be linear?")],
[#text("How does one answer Q1, Q2, Q3 if we allow the use of approximate extensions ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(", in which F(x) is only required to be close to f(x) for ")#mi("x \\in E")#text(", rather than equal to f(x), with some error tolerance ")#mi("\\sigma(x) \\geq 0")#text(" which may depend on x?")],
[#text("How does one answer Q1, Q2, Q3 if we also are allowed to discard a few elements of E (so that F(x) is now only required to be equal or close to f(x) outside of a small exceptional set)?")]
)

#text("Such questions are of relevance in computer science problems such as ")#link("http://en.wikipedia.org/wiki/Computational_learning_theory")[#text("machine learning")]#text(", in which an unknown smooth function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text(" is “learned” by sampling its values at a finite number of points ")#mi("x \\in E")#text(", but where the observed values f(x) at x can differ from the true value F(x) by some experimental error ")#mi("\\sigma(x)")#text(" (and in some small number of cases, f(x) may be completely incorrect). The problem is then how to interpolate F from this noisy (and occasionally completely wrong) data. Such problems are of course also related to the more classical problem of ")#link("http://en.wikipedia.org/wiki/Regression_analysis")[#text("regression")]#text(" in statistics, but with the difference that the function F is only assumed to be smooth (in some quantitative sense), rather than being linear, polynomial, or otherwise being determined by a small number of parameters.")

#text("The above questions are of course rather imprecise. To make them more precise, we need to specify what “compute” means. For simplicity, let us take a computational model in which one has a certain amount of memory, say M registers ")#mi("x_1,\\ldots,x_M")#text(", with each register containing an infinite-precision real number. We then consider performing a number of operations on these registers, where each operation involves only a small number (e.g. two or three) of the registers and performs a simple operation (e.g. adding or multiplying the values of two registers and placing the result in a third). [The infinite precision model is not realistic, of course, but Charlie remarked that provided that one can tolerate a sufficient amount of boredom, one can state and prove analogues of the results stated below for finite precision computational models.]")

#text("A computer with M registers can certainly ")#emph[#text("store")]#text(" all the data n, m, E, f (and sometimes ")#mi("\\sigma")#text(") needed for the above problems, if M is larger than some constant multiple of N. But what can it mean to “compute” a function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}")#text("? The domain of this function is infinite and so it cannot be “stored” in this finite-memory computer simply by storing each of its values separately. So instead, we shall say that F can be computed on a computer with M registers with an amount W of one-time work and an amount Q of query work if, after W computations, the computer has reached a state in which, after being given any input x, the computer can output F(x) (to infinite accuracy) after at most Q computations.")

#text("To state the theorems of Fefferman and Klartag we need a little more notation. Given data n, m, E, f, as well as an error tolerance function ")#mi("\\sigma: E \\to {\\Bbb R}^+")#text(", let us define the quantity ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)}", block: false)#text(" to be the best constant M such that one can find a function ")#mi("F \\in C^m({\\Bbb R}^n)")#text(" with ")#tao-math("\\left\\|F\\right\\|_{C^m({\\Bbb R}^n)} \\leq M", block: false)#text(", which approximates f in the sense that ")#tao-math("\\left|F(x)-f(x)\\right| \\leq M \\sigma(x)", block: false)#text(" for all ")#mi("x \\in E")#text(". This quantity ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)}", block: false)#text(" is then a norm on f (for fixed E and ")#mi("\\sigma")#text("), and measures how well one can fit a reasonably smooth function F to the data f with error tolerance ")#mi("\\sigma")#text(". (If one wants to fit F to f perfectly, one can simply set ")#mi("\\sigma = 0")#text(".) If a function F obeys the above properties with an M which is comparable in magnitude to the optimal value ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)}", block: false)#text(", thus ")#tao-math("M = O( \\left\\|f\\right\\|_{(E,\\sigma)} )", block: false)#text(", then we say that F is an ")#emph[#text("essentially optimal")]#text(" interpolant of f. (Here and in the sequel, all implied constants in the O() notation are allowed to depend on the dimension n and the regularity m, but are uniform in N, E, f, ")#mi("\\sigma")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". If n, m are fixed, and E, f, ")#mi("\\sigma")#text(" are given with |E|=N, then one can compute the order of magnitude of ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)}", block: false)#text(" using only ")#mi("O(N \\log N)")#text(" computations and ")#mi("O(N)")#text(" amount of memory. [More precisely, one can use these computational resources to produce a quantity Y which differs from ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)}", block: false)#text(" by at most a multiplicative constant.]")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". With the same setup as Theorem 1, one can compute an essentially optimal function F using only ")#mi("O(N \\log N)")#text(" one-time work, ")#mi("O(N)")#text(" memory, and ")#mi("O( \\log N )")#text(" query work. Furthermore, for fixed n, m, E, ")#mi("\\sigma")#text(", the map ")#mi("f \\mapsto F")#text(" can be chosen to be linear!")
]

#text("Apart from the factors of ")#mi("\\log N")#text(", these bounds are optimal, as one needs O(N) amount of work and memory merely to ")#emph[#text("read")]#text(" all the data. (From the way we have set up the problem, one cannot hope to obtain any meaningful results by sampling only a small portion of the data.)")

#text("Now let us consider the problem of what happens if we are willing to discard k points (say) from E in order to improve the interpolant. To this end, let us define the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{(E,\\sigma,k)} := \\inf \\{ \\left\\|f\\right\\|_{(E \\backslash S, \\sigma)}: S \\subset E; \\left|S\\right| \\leq k\\}", block: true)]]

#text("to denote the quality of the best interpolant one obtains from the data f after being allowed to reject k data points S. The key problem, of course, is to work out which sets S are good to reject; once S is identified, one can use Theorems 1 and 2 to compute the quantity ")#tao-math("\\left\\|f\\right\\|_{(E,\\sigma,k)}", block: false)#text(", as well as a good interpolant F. Let us say that a set S is an ")#emph[#text("essentially optimal")]#text(" rejection set if we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{(E \\backslash S, \\sigma)} = O( \\left\\|f\\right\\|_{(E,\\sigma,c\\left|S\\right|)} )", block: true)]]

#text("for some constant c > 0 (depending only on n and m); this means that throwing out S gives you about as good a fit as you can hope to accomplish with the remaining data, apart from the fact that you may have thrown out a bit more data (by a multiplicative factor) than you really needed to.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". With the same setup as Theorem 1, one can compute an ordering ")#mi("\\{x_1,\\ldots,x_N\\}")#text(" of E in ")#mi("O(N^2 \\log N)")#text(" computations and ")#mi("O( N )")#text(" memory, such that the set ")#mi("\\{x_1,\\ldots,x_k\\}")#text(" is an essentially optimal rejection set for every ")#mi("0 \\leq k \\leq N")#text(".")
]

#text("Basically, this theorem says that there is a polynomial time algorithm to order the data from the most unreliable ")#mi("x_1")#text(" to the most reliable ")#mi("x_N")#text(", so that if you are willing to throw out about k points of data to get a good fit with a smooth model, then an essentially optimal way to do this is simply to throw out the k most unreliable points ")#mi("x_1,\\ldots,x_k")#text(". Charlie believes that the ")#mi("O(N^2 \\log N)")#text(" amount of work can be reduced, but this is not yet been established rigorously.")

#text("One of the keys to these results is a remarkable reduction of the problem to a local one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finiteness theorem.")]#text(" Let n, m, E, ")#mi("\\sigma")#text(" be as before, with E finite. Then there exists a constant C (depending only on n,m) such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)} \\sim \\max \\{ \\left\\|f\\right\\|_{(S,\\sigma)}: S \\subset E, \\left|S\\right| \\leq C \\}", block: true)]]

#text("for all functions ")#mi("f: E \\to {\\Bbb R}")#text(", where ")#mi("X \\sim Y")#text(" means that X and Y are equal up to multiplicative constants (i.e. X = O(Y) and Y = O(X)).")
]

#text("Informally, this is saying that if you want to estimate the extent to which one can fit a smooth function to N points of data, it is enough to look at O(1) points of data at a time and see how well one can fit a smooth function to that. Since a data fitting problem for O(1) points can be done in O(1) time (for instance, by using the methods of the Whitney extension theorem), this already gives a polynomial time version of Theorem 1, since there are only polynomially many sets S of size O(1). To give a nearly linear-time version, one needs the following refinement, which cuts down the number of sets required to be linear in N:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Better finiteness theorem.")]#text(" Let n, m, E, ")#mi("\\sigma")#text(" be as before, with E finite. Then there exists a sequence ")#mi("S_1, \\ldots, S_L")#text(" of subsets of S of size O(1) and number ")#mi("L = O( N )")#text(", and computable using ")#mi("O(N \\log N)")#text(" computations and ")#mi("O(N)")#text(" memory, such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{(E,\\sigma)} \\sim \\max \\{ \\left\\|f\\right\\|_{(S_l,\\sigma)}: 1 \\leq l \\leq S \\}", block: true)]]

#text("for all functions ")#mi("f: E \\to {\\Bbb R}")#text(", where ")#mi("X \\sim Y")#text(" means that X and Y are equal up to multiplicative constants (i.e. X = O(Y) and Y = O(X)).")
]

#text("Charlie emphasised that the finiteness of E was important in all of these results; one could not use compactness methods to obtain similar claims for infinite sets E, basically because the space ")#mi("C^m({\\Bbb R}^n)")#text(" has no good compactness properties. (On the other hand, the slightly weaker space ")#mi("C^{m-1,1}({\\Bbb R}^n)")#text(" is fine. For instance, it is well known the optimal ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz")]#text(" (or ")#mi("C^{0,1}")#text(") norm ")#tao-math("\\left\\|F\\right\\|_{Lip({\\Bbb R}^n)}", block: false)#text(" of an extension F of a function f defined on a possibly infinite set E is equal to the Lipschitz norm ")#tao-math("\\left\\|f\\right\\|_{Lip(E)}", block: false)#text(" of f itself, or equivalently to the supremum of the optimal Lipschitz norm of the extension of F from two points of f, where the supremum is taken over all two-point subsets of E.)")

#text("Indeed, the finiteness theorem is false for infinite sets E; a good example is when m = 1, ")#mi("E = {\\Bbb R}^n")#text(", and ")#tao-math("f(x) := \\left|x\\right|", block: false)#text(". Every finite restriction of f can be extended in ")#mi("C^1")#text(" with norm arbitrarily close to 1, but f itself can only be extended to be Lipschitz rather than ")#mi("C^1")#text(".")

#text("Nevertheless, there are meaningful analogues of the above theorems for infinite sets. For this, Charlie set up some notation. Given a point ")#mi("x_0")#text(" and a regularity m, let ")#mi("{\\mathcal P}_{x_0} := {\\Bbb R}[x] / ((x-x_0)^{m+1})")#text(" denote the ring of polynomials in n variables ")#mi("x = (x_1,\\ldots,x_n)")#text(", in which every polynomial of degree m+1 or higher in ")#mi("x-x_0")#text(" is neglected. In particular, note that there is a ring homomorphism from ")#mi("C^m({\\Bbb R}^n)")#text(" to ")#mi("{\\mathcal P}_{x_0}")#text(" that sends any m-times continuously differentiable function f to its order m ")#link("http://en.wikipedia.org/wiki/Taylor_polynomial")[#text("Taylor expansion ")]#mi("J_{x_0}(F)")#text(" at ")#mi("x_0")#text(" (the letter J stands for ")#link("http://en.wikipedia.org/wiki/Jet_%28mathematics%29")[#text("jet")]#text("). Given a compact set E, define a ")#emph[#text("bundle")]#text(" to be a collection ")#mi("(H_x)_{x \\in E}")#text(", where for each ")#mi("x \\in E")#text(", ")#mi("H_x")#text(" is either empty, or is the coset of an ideal of ")#mi("{\\mathcal P}_{x_0}")#text(". A function ")#mi("f\\in C^m({\\Bbb R}^n)")#text(" is said to be a ")#emph[#text("section")]#text(" of a bundle ")#mi("(H_x)_{x \\in E}")#text(" if we have ")#mi("J_x(f) \\in H_x")#text(" for all ")#mi("x \\in E")#text(". Charlie then posed the following basic question:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question")]#text(". Fix n, m, E. Which bundles ")#mi("(H_x)_{x \\in E}")#text(" admit sections?")
]

#text("The special case of this question in which ")#mi("H_x := \\{ P \\in {\\mathcal P}_x: P(x)=f(x)\\}")#text(" for some given function ")#mi("f: E \\to {\\Bbb R}")#text(" is the classic extension problem of Whitney.")

#text("Charlie promised a good answer to this question, but as time was running out for this talk, he left it as a cliffhanger for the next talk. So stay tuned…")

#text("[")#emph[#text("Update")]#text(", Nov 14: typos fixed.]")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-14883")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2007")])]

#text("Hello Prof. Tao,")#linebreak()#text(" Thanks for the post and for your great blog!")#linebreak()#text(" I noticed some typos :")#linebreak()#text(" 1. In the first equation which is not inline (the norm of F) you want j to play some role in the RHS.")#linebreak()#text(" 2. Two sentences above the last QUESTION, F should be f and the inclusion should hold for all x in E.")#linebreak()#text(" Perhaps the typos are in my head, if so I apologize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-14886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2007")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Charles Fefferman, “Interpolation of functions on R^n” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-15154")[#strong[#text("Distinguished Lecture Series II: Charles Fefferman, “Interpolation of functions on R^n” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2007")])]

#text("[…] about bundles that underlies all the results, answering the “cliffhanger” question from the last lecture, and broadly outlined the proof, except for a major technical wrinkle about “Whitney […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-39821")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("Dear Terry,")

#text("When you attend talks….do you in general take notes? Is this a good practice?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d7ca852d802a7baa32e1d6b6a68d62837f379996ffe8571e8ac0df57c7ff30b-a51cfc4ca0da2d96db763b17ad4f15f98b5943cf2e8b9bd3fc4a3c10d3d48a5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-45680")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("Dear Terry, is it known whether Whitney’s extension theorem is false for functions on a separable Banach space? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-467951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2016")])]

#text("In real analysis, one has the extension theorem for Sobolev space ")#mi("W^{1,p}(U)")#text(" assuming ")#mi("\\partial U")#text(" is ")#mi("C^1")#text(": one can extend ")#mi("W^{1,p}(U)")#text(" to ")#mi("W^{1,p}(\\mathbb{R}^n)")#text(". Does this result have anything to do with the Whitney Extension Theorem? In history, which one of these two results was discovered first?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-467966")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#text("Whitney published his theorem in 1934, while Sobolev introduced his spaces in the 1960s (though I think other mathematicians may have been using some version of what we now call Sobolev spaces prior to this). So I would presume the Sobolev space extension theorem was discovered after Whitney’s theorem.")

#text("Fefferman and his coauthors have also worked on Sobolev extension problems (in Sobolev spaces with more than one degree of regularity), see e.g. ")#link("http://www.ams.org/journals/jams/2014-27-01/S0894-0347-2013-00763-8/home.html")[#text("http://www.ams.org/journals/jams/2014-27-01/S0894-0347-2013-00763-8/home.html")]#text(" . So presumably there is a relationship between the two extension problems, though I have not studied these works in detail.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4c176746d965aef463b13b27963557dbbe9b9fec37b81af9b5a34a431720061-85e9c36149ed668baabec152ad92da01ad1e0edcf0538485bcfa38b431d09b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-508363")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("A related article(a function fitting method): ")#link("https://arxiv.org/abs/1811.01336")[#text("https://arxiv.org/abs/1811.01336")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4c176746d965aef463b13b27963557dbbe9b9fec37b81af9b5a34a431720061-85e9c36149ed668baabec152ad92da01ad1e0edcf0538485bcfa38b431d09b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh Dachiraju")]], [#link("https://terrytao.wordpress.com/2007/11/13/distinguished-lecture-series-i-charles-fefferman-interpolation-of-functions-on-rn/#comment-519274")[#strong[#text("Rajesh Dachiraju")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("A problem I am working on, may be worth mentioning on this thread :")

#link("https://mathoverflow.net/q/332439/14414")[#text("https://mathoverflow.net/q/332439/14414")]
]
