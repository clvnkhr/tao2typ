// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/
// Converted to Typst by tao2typ: "2026-10-14T06:58:24.771895+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 1: Flows on Riemannian manifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 1: Flows on Riemannian manifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the first lecture, we introduce ")#emph[#text("flows")]#text(" ")#mi("t \\mapsto (M(t), g(t))")#text(" on Riemannian manifolds ")#mi("(M,g)")#text(", which are recipes for describing smooth deformations of such manifolds over time, and derive the basic ")#emph[#text("first variation formulae")]#text(" for how various structures on such manifolds (e.g. curvature, length, volume) change by such flows. (One can view these formulae as describing the relationship between two “infinitesimally close” Riemannian manifolds.) We then specialise to the case of ")#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/")[#text("Ricci flow")]#text(" (together with some close relatives of this flow, such as renormalised Ricci flow, or Ricci flow composed with a diffeomorphism flow). We also discuss the “de Turck trick” that modifies the Ricci flow into a nonlinear parabolic equation, for the purposes of establishing local existence and uniqueness of that flow.")

#metadata(none) <tao-615ddf53fe1f7961c11d>

#heading(level: 1)[#text("— Flows on Riemannian manifolds —")]

#text("For the purposes of this course, we are not interested in just a single Riemannian manifold ")#mi("(M, g)")#text(", but rather a one-parameter family of such manifolds ")#mi("t \\mapsto (M(t), g(t))")#text(", parameterised by a “time” parameter t. The manifold ")#mi("(M(t), g(t))")#text(" at time t is going to determine the manifold ")#mi("(M(t+dt), g(t+dt))")#text(" at an infinitesimal time t + dt into the future, according to some prescribed evolution equation (e.g. Ricci flow). In order to do this rigorously, we will need to “differentiate” a manifold flow ")#mi("t \\mapsto (M(t), g(t))")#text(" with respect to time.")

#text("There are at least two ways to do this. The simplest is to restrict to the case in which the underlying manifold ")#mi("M = M(t)")#text(" is fixed (as a smooth manifold), so that only the metric ")#mi("g = g(t)")#text(" varies in time. As g takes values as sections in a vector bundle, there is then no difficulty in defining time derivatives ")#mi("\\dot g(t) = \\frac{d}{dt} g(t)")#text(" in the usual manner:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dt} g(t) := \\lim_{dt \\to 0} \\frac{g(t+dt) - g(t)}{dt}.")]]

#text("We can of course similarly define the time derivative of any other tensor field by the same formula.")

#text("The one drawback of the above simple approach is that it forces the topology of the underlying manifold M to stay constant. A more general approach is to view each d-dimensional manifold M(t) as a slice of a d+1-dimensional “")#link("http://en.wikipedia.org/wiki/Spacetime")[#text("spacetime")]#text("” manifold ")#mi("{\\bf M}")#text(" (possibly with boundary or singularities). This spacetime is (usually) equipped with a ")#emph[#text("time coordinate")]#text(" ")#mi("t: {\\bf M} \\to {\\Bbb R}")#text(", as well as a ")#emph[#text("time vector field")]#text(" ")#mi("\\partial_t \\in \\Gamma(T {\\bf M})")#text(" which obeys the transversality condition ")#mi("\\partial_t t = 1")#text(". The level sets of the time coordinate t then determine the sets M(t), which (assuming non-degeneracy of t) are smooth d-dimensional manifolds which collectively have a tangent bundle ")#mi("\\text{ker}(dt) \\subset T{\\bf M}")#text(" which is a d-dimensional subbundle of the d+1-dimensional tangent bundle ")#mi("T{\\bf M}")#text(" of ")#mi("{\\bf M}")#text(". The metrics g(t) can then be viewed collectively as a section ")#mi("{\\bf g}")#text(" of ")#mi("(\\text{ker}(dt)^*)^{\\otimes 2}")#text(". The analogue of the time derivative ")#mi("\\frac{d}{dt} g(t)")#text(" is then the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" ")#mi("{\\mathcal L}_{\\partial_t} {\\bf g}")#text(". One can then define other Riemannian structures (e.g. Levi-Civita connections, curvatures, etc.) and differentiate those in a similar manner.")

#text("The former approach is of course a special case of the latter, in which ")#mi("{\\bf M} = M \\times I")#text(" for some time interval ")#mi("I \\subset {\\Bbb R}")#text(" with the obvious time coordinate and time vector field. The advantage of the latter approach is that it can be extended (with some technicalities) into situations in which the topology changes (though this may cause the time coordinate to become degenerate at some point, thus forcing the time vector field to develop a singularity). This leads to concepts such as ")#emph[#text("generalised Ricci flow")]#text(", which we will not discuss here, though it is an important part of the definition of ")#emph[#text("Ricci flow with surgery ")]#text("(see Chapters 3.8 and 14 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" for details). Instead, we focus exclusively for now on the former viewpoint, in which ")#mi("M = M(t)")#text(" does not depend on time.")

#text("Suppose we have a smooth flow ")#mi("(M,g(t))")#text(" of metrics on a fixed background manifold M. The rate of change of the metric ")#mi("g_{\\alpha \\beta}(t)")#text(" is given by ")#mi("\\dot g_{\\alpha \\beta}(t)")#text(". By the ")#link("http://en.wikipedia.org/wiki/Chain_rule")[#text("chain rule")]#text(", this implies that any other expression that depends on this metric, such as the curvatures ")#mi("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta(t)")#text(", ")#mi("\\text{Ric}_{\\alpha \\beta}(t)")#text(", ")#mi("R(t)")#text(", should have a rate of change that depends linearly on ")#mi("\\dot g_{\\alpha \\beta}(t)")#text(". We now compute exactly what these rates of change are. In principle, this can be done by writing everything explicitly using local coordinates and applying the chain rule, but we will try to keep things as coordinate-free as possible as it seems to cut down the computation slightly.")

#text("To abbreviate notation, we shall omit the explicit time dependence in what follows, e.g. abbreviating g(t) to just g. We shall call a tensor field w")#emph[#text(" time-independent")]#text(" or ")#emph[#text("static")]#text(" if it does not depend on t, or equivalently that ")#mi("\\dot w = 0")#text(".")

#text("From differentiating the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("g^{\\alpha \\beta} g_{\\beta \\gamma} = \\delta^\\alpha_\\gamma")]]

#text("we obtain the variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{dt} g^{\\alpha\\beta} = - g^{\\alpha \\gamma} g^{\\beta \\delta} \\dot g_{\\gamma \\delta}")]]

#text("(here is a place where the raising and lowering conventions can be confusing if applied blindly!).")

#text("Next, we compute how covariant differentiation deforms with respect to time. For a scalar function f, the derivative ")#mi("\\nabla_\\alpha f \\equiv df")#text(" does not involve the metric, and so the rate of change formula is simple:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{d}{dt} \\nabla_\\alpha f = \\nabla_\\alpha \\dot f.")]]

#text("In particular, if f is static, then so is ")#mi("\\nabla_\\alpha f")#text(".")

#text("Now we take a static vector field ")#mi("X^\\beta")#text(". From (4) and the product rule we see that the expression ")#mi("\\frac{d}{dt} \\nabla_\\alpha X^\\beta")#text(" is linear over ")#mi("C^\\infty(M)")#text(" (interpreted as the space of static scalar fields). Thus we must have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{d}{dt} \\nabla_\\alpha X^\\beta = \\dot \\Gamma_{\\alpha \\gamma}^\\beta X^\\gamma")]]

#text("for some rank (1,2) tensor ")#mi("\\dot \\Gamma_{\\alpha \\gamma}^\\beta")#text(". From the Leibnitz rule and (4) we can obtain similar formulae for other tensors, e.g.")

#align(center)[#mi("\\frac{d}{dt} \\nabla_\\alpha \\omega_\\beta = - \\dot \\Gamma_{\\alpha \\beta}^\\gamma \\omega_\\gamma")#text(" (5′)")]

#text("for any static one-form ")#mi("\\omega_\\beta")#text(".")

#text("What is ")#mi("\\dot \\Gamma_{\\alpha \\beta}^\\gamma")#text("? Well, we can work it out from the properties of the Levi-Civita connection. Differentiating the torsion-free identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta f = \\nabla_\\beta \\nabla_\\alpha f")]]

#text("for static scalar fields f using (4), (5′), we conclude the symmetry ")#mi("\\dot \\Gamma_{\\alpha \\beta}^\\gamma = \\dot \\Gamma_{\\beta \\alpha}^\\gamma")#text(". Similarly, differentiating the respect-of-metric identity ")#mi("\\nabla_\\alpha g_{\\beta \\gamma} = 0")#text(" we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("- \\dot \\Gamma_{\\alpha \\beta}^\\delta g_{\\delta \\gamma} - \\dot \\Gamma_{\\alpha \\gamma}^\\delta g_{\\beta \\delta} + \\nabla_\\alpha \\dot g_{\\beta \\gamma} = 0.")]]

#text("These two facts allow us to solve for ")#mi("\\dot \\Gamma_{\\alpha \\beta}^\\gamma")#text(":")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\dot \\Gamma_{\\alpha \\beta}^\\gamma = \\frac{1}{2} g^{\\gamma \\delta} ( \\nabla_\\alpha \\dot g_{\\beta \\delta} + \\nabla_\\beta \\dot g_{\\alpha \\delta} - \\nabla_\\delta\\dot g_{\\alpha \\beta} )")]]

#text("(compare with the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbols")[#text("usual formula for the Christoffel symbols")]#text(" in local coordinates).")

#text("Now we turn to curvature tensors. We have the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta X^\\gamma - \\nabla_\\beta \\nabla_\\alpha X^\\gamma = \\text{Riem}_{\\alpha \\beta \\delta}^\\gamma X^\\delta")]]

#text("for any static vector field X. Taking the time derivative of this using (5), (5′), etc. we obtain")

#align(center)[#tao-fit-display[#mitex("-\\dot \\Gamma_{\\alpha \\beta}^{\\delta} \\nabla_\\delta X^\\gamma + \\dot \\Gamma_{\\alpha \\delta}^\\gamma \\nabla_\\beta X^\\delta + \\nabla_\\alpha \\dot \\Gamma_{\\beta \\delta}^\\gamma X^\\delta")]]

#align(center)[#tao-fit-display[#mitex("+\\dot \\Gamma_{\\beta \\alpha}^\\delta \\nabla_\\delta X^\\gamma - \\dot \\Gamma_{\\beta \\delta}^\\gamma \\nabla_\\alpha X^\\delta - \\nabla_\\beta \\dot \\Gamma_{\\alpha \\delta}^\\gamma X^\\delta")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("= \\dot{\\text{Riem}}_{\\alpha \\beta \\delta}^\\gamma X^\\delta")]]

#text("which eventually simplifies to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\dot{\\text{Riem}}_{\\alpha \\beta \\delta}^\\gamma = \\nabla_\\alpha \\dot \\Gamma_{\\beta \\delta}^\\gamma - \\nabla_\\beta \\dot \\Gamma_{\\alpha \\delta}^\\gamma.")]]

#text("(one can view this as a linearisation of the ")#link("http://en.wikipedia.org/wiki/Riemann_curvature_tensor")[#text("usual formula for the Riemann curvature tensor")]#text(" in terms of Christoffel symbols). Combining (8) and (11), and using the fact that the Levi-Civita connection respects the metric, we thus have")

#tao-aligned(keep: true)[


#tao-math("\\dot{\\text{Riem}}_{\\alpha \\beta \\delta}^\\gamma  & = \\frac{1}{2} g^{\\gamma \\sigma} ( \\nabla_\\alpha \\nabla_\\delta \\dot g_{\\beta \\sigma} - \\nabla_\\alpha \\nabla_\\sigma \\dot g_{\\delta \\beta} - \\nabla_\\beta \\nabla_\\delta \\dot g_{\\alpha \\sigma} + \\nabla_\\beta \\nabla_\\sigma \\dot g_{\\delta \\alpha}", block: true)



#tao-math(" & - \\text{Riem}_{\\alpha \\beta \\delta}^\\mu \\dot g_{\\mu \\sigma} - \\text{Riem}_{\\alpha \\beta \\sigma}^\\mu \\dot g_{\\delta \\mu}).", block: true, numbering: n => [#text("(12)")])
]

#strong[#text("Exercise 1. ")]#text(" Show that (12) is consistent with the antisymmetry properties of the Riemann tensor, and with the Bianchi identities, as presented in the ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("previous lecture")]#text(". ")#mi("\\diamond")

#text("Taking traces, we obtain a variation formula for the Ricci tensor")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\dot{\\text{Ric}}_{\\alpha \\beta} = - \\frac{1}{2}\\Delta_L \\dot g_{\\alpha \\beta} - \\frac{1}{2} \\nabla_\\alpha \\nabla_\\beta \\text{tr}(\\dot g) +\\frac{1}{2} \\nabla_\\alpha \\nabla^\\gamma \\dot g_{\\beta \\gamma} + \\frac{1}{2} \\nabla_\\beta \\nabla^\\gamma \\dot g_{\\alpha \\gamma}")]]

#text("where ")#mi("\\text{tr}(\\pi) := g^{\\alpha \\beta} \\pi_{\\alpha \\beta}")#text(" is the trace, and the ")#emph[#text("Lichnerowicz Laplacian")]#text(" (or ")#emph[#text("Hodge-de Rham Laplacian")]#text(") ")#mi("\\Delta_L")#text(" on symmetric rank (0,2) tensors ")#mi("\\pi_{\\alpha \\beta}")#text(" is defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\Delta_L\\pi_{\\alpha \\beta} := \\Delta \\pi_{\\alpha \\beta} + 2 g^{\\sigma \\gamma} \\text{Riem}_{\\sigma \\alpha \\beta}^{\\delta} \\pi_{\\gamma \\delta} - \\text{Ric}_\\alpha^\\gamma \\pi_{\\gamma\\beta} - \\text{Ric}_\\beta^\\gamma \\pi_{\\gamma \\alpha}")]]

#text("and ")#mi("\\Delta \\pi_{\\alpha \\beta} = \\nabla_\\gamma \\nabla^\\gamma \\pi_{\\alpha \\beta}")#text(" is the usual connection Laplacian. Taking traces once again, one obtains a variation formula for the scalar curvature:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\dot R = - \\text{Ric}^{\\alpha \\beta} \\dot g_{\\alpha \\beta} - \\Delta \\text{tr}(\\dot g) + \\nabla^\\alpha \\nabla^\\beta \\dot g_{\\alpha \\beta}.")]]

#strong[#text("Exercise 2.")]#text(" Verify the derivation of (13) and (15). [")#emph[#text("Aside")]#text(": – I wonder if there are more direct derivations of (13) and (15) that do not require one to go through so many computations. One can use (22) and (26) below as consistency checks for these formulae, but this does not quite seem sufficient.] ")#mi("\\diamond")

#text("We will also need to understand how deformation of the metric affects two other quantities, length and volume. The length ")#mi("L(\\gamma)")#text(" of a curve ")#mi("\\gamma: [a,b] \\to M")#text(" in a Riemannian manifold ")#mi("(M,g)")#text(" is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("L(\\gamma) := \\int_a^b g( \\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )^{1/2}\\ du =: \\int_\\gamma ds.")]]

#text("where ")#mi("ds = \\gamma_* g( \\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )^{1/2}\\ du")#text(" is the measure on the curve ")#mi("\\gamma")#text(" induced by the metric.")

#strong[#text("Exercise 3.")]#text(" If ")#mi("\\gamma")#text(" varies smoothly in time (but with static endpoints ")#mi("\\gamma(a), \\gamma(b)")#text(", show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\frac{d}{dt} L(\\gamma) = \\frac{1}{2} \\int_\\gamma \\dot g( S, S )\\ ds - \\int_\\gamma g( \\nabla_S S, V )\\ ds")]]

#text("where at every point ")#mi("x = \\gamma(u)")#text(" of the curve, ")#mi("S = \\gamma^{\\prime}(u) /g( \\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )^{1/2}")#text(" is the unit tangent, and ")#mi("V = \\dot \\gamma(u)")#text(" is the variation field. (Strictly speaking, one needs to work on the pullback tensor bundles on ")#mi("{}[a,b]")#text(" rather than M in order to make the formulae in (17) well defined.) ")#mi("\\diamond")

#text("The distance between two points x, y on a manifold is defined as ")#mi("d(x,y) := \\inf L(\\gamma)")#text(", where ")#mi("\\gamma")#text(" ranges over all curves from x to y. For smooth connected complete manifolds, it is not hard to show (e.g. by using a reduction to the unit speed case, followed by a minimising sequence argument and the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelà-Ascoli theorem")]#text(", combined with some local theory of short geodesics to ensure ")#mi("C^1")#text(" regularity of the limiting curve) that this infimum is actually attained for some minimising ")#link("http://en.wikipedia.org/wiki/Geodesic")[#emph[#text("geodesic")]]#text(" ")#mi("\\gamma")#text(", which is then a critical point for ")#mi("L(\\gamma)")#text(". (However, this infimum need not be unique if x, y are far apart.) From (17) we conclude that such geodesics must obey the equation ")#mi("\\nabla_S S = 0")#text(" (thus the unit tangent vector parallel transports itself). We also conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\frac{d}{dt} d(x,y) = \\inf \\frac{1}{2} \\int_\\gamma \\dot g( S, S )\\ ds")]]

#text("where the infimum is over all the minimising geodesics from x to y. Thus, a positive ")#mi("\\dot g")#text(" (in the sense of quadratic forms) will increase distances between two marked points, while a negative ")#mi("\\dot g")#text(" will decrease it.")

#text("Next, we look at the evolution of the volume measure ")#mi("d\\mu = d\\mu(t)")#text(". This measure is defined using any frame ")#mi("(e_a)_{1 \\leq a \\leq d}")#text(" and dual frame ")#mi("(e^a)_{1 \\leq a \\leq d}")#text(" as")

#align(center)[#tao-math("d\\mu := \\sqrt{\\det g} \\left|e^1 \\wedge \\ldots \\wedge e^d\\right|", block: false)#text(" (18′)")]

#text("where ")#mi("\\det g")#text(" is the determinant of the matrix with components ")#mi("g_{ab} = g( e_a, e_b )")#text(" (one can check that this measure is defined independently of the choice of frame). Intuitively, this measure is the unique measure such that an infinitesimal cube whose sides are orthogonal vectors of infinitesimal length ")#mi("r")#text(", will have volume ")#mi("r^d + O( r^{d+1} )")#text(". It is not hard to show (using coordinates, and the variation formula ")#mi("\\frac{d}{dt} \\det(A) = \\text{tr}(A^{-1} \\dot A) \\det(A)")#text(" for the determinant) that one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\frac{d}{dt} d\\mu = \\frac{1}{2} \\text{tr}(\\dot g)\\ d\\mu.")]]

#text("Thus, a positive trace for ")#mi("\\dot g")#text(" implies volume expansion, and a negative trace implies volume contraction. This is broadly consistent with how length is affected by metric distortion, as discussed previously.")

#heading(level: 1)[#text("— Dilations —")]

#text("Now we specialise to some specific flows ")#mi("(M, g(t))")#text(" of a Riemannian metric on a fixed background manifold M. The simplest such flow (besides the trivial flow ")#mi("g(t)=g(0)")#text(", of course) is that of a dilation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("g(t) := A(t) g(0)")]]

#text("where ")#mi("A(t) > 0")#text(" is a positive scalar with ")#mi("A(0)=1")#text(". The flow here is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\dot g(t) = a(t) g(t)")]]

#text("where ")#mi("a(t) := \\frac{\\dot A(t)}{A(t)} = \\frac{d}{dt} \\log A(t)")#text(" is the ")#link("http://en.wikipedia.org/wiki/Logarithmic_derivative")[#text("logarithmic derivative")]#text(" of A (or equivalently, ")#mi("A(t) = \\exp(\\int_0^t a(t^{\\prime})\\ dt^{\\prime})")#text("). In this case our variation formulas become very simple:")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} g^{\\alpha \\beta}  & = - a g^{\\alpha \\beta}", block: true)



#tao-math("\\dot \\Gamma_{\\alpha \\beta}^\\gamma  & = 0", block: true)



#tao-math("\\dot{\\text{Riem}}_{\\alpha \\beta \\gamma}^\\delta  & = 0", block: true)



#tao-math("\\dot{\\text{Ric}}_{\\alpha \\beta}  & = 0", block: true, numbering: n => [#text("(22)")])



#tao-math("\\dot R  & = - a R", block: true)



#tao-math("\\frac{d}{dt} d(x,y)  & = \\frac{1}{2} a d(x,y)", block: true)
]

#align(center)[#mi("\\frac{d}{dt} d\\mu = \\frac{d}{2} a\\ d\\mu")#text(";")]

#text("note that these formulae are consistent with (20) and the scaling heuristics at the end of the ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("previous lecture")]#text(". In particular, a positive value of ")#mi("a")#text(" means that length and volume are increasing, and a negative value means that length and volume are decreasing.")

#heading(level: 1)[#text("— Diffeomorphisms —")]

#text("Another basic flow comes from smoothly varying one-parameter families of diffeomorphisms ")#mi("\\phi(t): M \\to M")#text(" with ")#mi("\\phi(0)")#text(" equal to the identity. This induces a flow")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23).")])
#mitex("g(t) := \\phi(t)^* g(0)")]]

#text("Infinitesimally, this flow is given by the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\dot g(t) = {\\mathcal L}_{X(t)} g(t)")]]

#text("where ")#mi("X(t) := \\phi(t)^* \\dot \\phi(t)")#text(" is the vector field representing the infinitesimal diffeomorphism at time t. (One can use ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard’s existence theorem")]#text(" to recover ")#mi("\\phi")#text(" from X, though one has to solve an ODE for this and so the formula is not fully explicit.) The quantity ")#mi("\\pi_{\\alpha \\beta} := {\\mathcal L}_X g_{\\alpha \\beta}")#text(" is known as the ")#emph[#link("http://en.wikipedia.org/wiki/Strain_tensor")[#text("deformation tensor")]]#text(" of X, and it is a short exercise to verify the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\pi_{\\alpha \\beta} = \\nabla_\\alpha X_\\beta + \\nabla_\\beta X_\\alpha.")]]

#text("(Informally, this tensor measures the obstruction to K being a ")#link("http://en.wikipedia.org/wiki/Killing_vector_field")[#text("Killing vector field")]#text(".)")

#text("It is clear from diffeomorphism invariance that all tensors deform via the Lie derivative:")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} g^{\\alpha \\beta}  & = {\\mathcal L}_X g^{\\alpha \\beta}", block: true)



#tao-math("\\dot{\\text{Riem}}_{\\alpha \\beta \\gamma}^\\delta  & = {\\mathcal L}_X \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta", block: true, numbering: n => [#text("(26)")])



#tao-math("\\dot{\\text{Ric}}_{\\alpha \\beta}  & = {\\mathcal L}_X \\text{Ric}_{\\alpha \\beta}", block: true)
]

#align(center)[#mi("\\dot R = {\\mathcal L}_X R")#text(".")]

#text("[The formula for ")#mi("\\dot \\Gamma_{\\alpha \\beta}^\\gamma")#text(" does not have such a nice representation, since ")#mi("\\Gamma_{\\alpha \\beta}^\\gamma")#text(" is not a tensor.]")

#strong[#text("Exercise 4.")]#text(" Establish the ")#emph[#text("first variation formula")]#text(" ")#mi("\\frac{d}{dt} d(x,y) = \\inf g( X(y), S(y) ) - g( X(x), S(x) )")#text(", where the infimum ranges over all minimal geodesics from x to y (which in particular determine the unit tangent vector S at x and at y). ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" As observed ")#link("http://www.ams.org/mathscinet-getitem?mr=593487")[#text("by Kazdan")]#text(", one can compare the identities (26) with the variation formulae (11), (13), (15) to provide an alternate derivation of the Bianchi identities. ")#mi("\\diamond")

#text("Applying (19), (25) we see that variation of the volume measure ")#mi("d\\mu")#text(" is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\frac{d}{dt} d\\mu = \\text{div}(X)\\ d\\mu")]]

#text("where ")#mi("\\text{div}(X) := \\nabla_\\alpha X^\\alpha")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divergence")[#text("divergence")]#text(" of X. On the other hand, for compact manifolds M at least, diffeomorphisms preserve the total volume ")#mi("\\text{vol}(M) := \\int_M\\ d\\mu")#text(". We thus conclude ")#link("http://en.wikipedia.org/wiki/Stokes%27_theorem")[#emph[#text("Stokes’ theorem")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\int_M \\text{div}(X)\\ d\\mu = 0")]]

#text("on compact manifolds for arbitrary smooth vector fields X. It is not difficult to extend this to non-compact manifolds in the case when X is compactly supported. From (28) and the product rule we also obtain the ")#link("http://en.wikipedia.org/wiki/Integration_by_parts")[#text("integration by parts")]#text(" formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\int_M f \\nabla_\\alpha X^\\alpha\\ d\\mu = - \\int_M (\\nabla_\\alpha f) X^\\alpha\\ d\\mu.")]]

#text("As one particular special case of (29), we observe that the Laplacian on ")#mi("C^\\infty(M)")#text(" is formally ")#link("http://en.wikipedia.org/wiki/Self-adjoint")[#text("self-adjoint")]#text(".")

#heading(level: 1)[#text("— Ricci flow —")]

#text("Finally, we come to the main focus of this entire course, namely ")#emph[#text("Ricci flow")]#text(". A one-parameter family of metrics g(t) on a smooth manifold M for all time t in an interval I is said to obey ")#emph[#text("Ricci flow")]#text(" if we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\frac{d}{dt} g(t) = -2 \\text{Ric}(t).")]]

#text("Note that this equation makes tensorial sense since g and Ric are both symmetric rank 2 tensors. The factor of 2 here is just a notational convenience and is not terribly important, but the minus sign – is crucial (at least, if one wants to solve Ricci flow ")#emph[#text("forwards")]#text(" in time). Note that Ricci flow, like all other parabolic flows (of which the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]#text(" is the model example), is not time-reversible – solvability forwards in time does not imply solvability backwards in time!")

#text("In the preceding examples of dilation flow and diffeomorphism flow, it was easy to get from the infinitesimal evolution to the global evolution, either by using an integrating factor or by solving some ODEs. The situation for Ricci flow turns out to be significantly less trivial (and indeed, resolving the global existence problem properly is a large part of the proof of the Poincaré conjecture). Nevertheless, we do have the following relatively easy result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (local existence). If M is compact and ")#mi("g(0)")#text(" is a smooth Riemannian metric on M, then there exists a time ")#mi("T>0")#text(", and a unique Ricci flow ")#mi("t \\mapsto g(t)")#text(" with initial metric g(0) on the time interval ")#mi("t \\in [0,T)")#text(".")
]

#text("This theorem was first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("by Hamilton")]#text(" using the ")#link("http://en.wikipedia.org/wiki/Nash-Moser_theorem")[#text("Nash-Moser iteration method")]#text(", and then a simplified proof given by ")#link("http://www.ams.org/mathscinet-getitem?mr=697987")[#text("de Turck")]#text(". We will not prove Theorem 1 here, but we will shortly indicate the main trick of de Turck used to reduce the problem to a standard local existence problem for nonlinear parabolic PDE.")

#text("Solutions have various names depending on their interval I of existence (or ")#emph[#text("lifespan")]#text("):")

#enum(start: 1, 
[#text("A solution is ")#emph[#text("ancient")]#text(" if I has ")#mi("-\\infty")#text(" as a left endpoint.")],
[#text("A solution is ")#emph[#text("immortal")]#text(" if I has ")#mi("+\\infty")#text(" as a right-endpoint.")],
[#text("A solution is ")#emph[#text("global")]#text(" if it is both ancient and immortal, thus ")#mi("I = {\\Bbb R}")#text(".")]
)

#text("The ancient solutions will play a particularly important role in our analysis later in this course, when we rescale (or ")#emph[#text("blow up")]#text(") the time variable (and the metric) as we approach a singularity of the Ricci flow, and then look at the asymptotic limiting profile of these rescaled solutions.")

#text("It is a routine matter to compute the variations of various tensors under the Ricci flow:")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} g^{\\alpha \\beta}  & = 2 \\text{Ric}^{\\alpha \\beta}", block: true)



#tao-math("\\dot R  & = \\Delta R + 2 \\left|\\text{Ric}\\right|^2", block: true)



#tao-math("\\dot{\\text{Ric}}_{\\alpha \\beta}  & = \\Delta_L \\text{Ric}_{\\alpha \\beta}", block: true, numbering: n => [#text("(31)")])



#tao-math(" & = \\Delta \\text{Ric}_{\\alpha \\beta} + 2 \\text{Ric}^\\gamma_{\\delta} \\text{Riem}_{\\gamma \\alpha \\beta}^\\delta - 2 \\text{Ric}_{\\alpha \\gamma} \\text{Ric}^{\\gamma}_\\beta", block: true)



#tao-math("\\dot{\\text{Riem}}  & = \\Delta \\text{Riem} + {\\mathcal O}(g^{-1} \\text{Riem}^2)", block: true)
]

#text("where ")#mi("{\\mathcal O}(g^{-1} \\text{Riem}^2)")#text(" is a moderately complicated combination of the tensors ")#mi("g^{-1}")#text(", Riem, and Riem that I will not write down explicitly here. In particular, we see that all of the curvature tensors obey some sort of tensor nonlinear heat equation. Parabolic theory then suggests that these tensors will behave for short times much like solutions to the linear heat equation (for instance, they should become smoother over time, and they should obey various maximum principles). We will see various manifestations of this principle later in this course.")

#text("We also have variation formulae for length and volume:")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} d(x,y)  & = - \\sup \\int_\\gamma \\text{Ric}( S, S )\\ ds", block: true, numbering: n => [#text("(32)")])



#tao-math("\\frac{d}{dt} d\\mu  & = -R\\ d\\mu.", block: true, numbering: n => [#text("(33)")])
]

#text("Thus Ricci flow tends to enlarge length and volume in regions of negative curvature, and reduce length and volume in regions of positive curvature.")

#heading(level: 1)[#text("— Modifying Ricci flow —")]

#text("Ricci flow (30) combines well with the dilation flows (21) and diffeomorphism flows (24), thanks to the dilation symmetry and diffeomorphism invariance of Ricci flow. (It can even be combined with these two flows simultaneously, although we will not need such a unified flow here.)")

#text("For instance, if g(t) solves Ricci flow and we set ")#mi("\\tilde g(s) := A(s) g(t(s))")#text(" for some reparameterised time ")#mi("s = s(t)")#text(" and some scalar ")#mi("A = A(s) > 0")#text(", then the Ricci curvature here is ")#mi("\\tilde{\\text{Ric}}(s) = \\text{Ric}(t(s))")#text(". We then see from the chain rule that ")#mi("\\tilde g")#text(" obeys the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\frac{d}{ds} \\tilde g(s) = - 2 A(s) \\frac{dt}{ds} \\tilde{\\text{Ric}}(s) + a(s) \\tilde g(s)")]]

#text("where ")#mi("a")#text(" is the logarithmic derivative of A. If we normalise the time reparameterisation by requiring ")#mi("\\frac{dt}{ds} = 1/A(s)")#text(", we thus see that ")#mi("\\tilde g")#text(" obeys ")#emph[#text("normalised Ricci flow")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\frac{d}{ds} \\tilde g = - 2 \\tilde{\\text{Ric}} + a \\tilde g(s)")]]

#text("which can be viewed as a combination of (30) and (21). Conversely, it is not difficult to reverse these steps and transform a solution to (35) for some a into a solution of Ricci flow by reparameterising time and renormalising the metric by a scalar. Normalised Ricci flow is useful for studying singularities, as it can “blow up” the interesting portion of the dynamics to keep it at unit scale, instead of cascading to finer and finer scales as is usual when approaching a singularity. The parameter a is at one’s disposal to set; for instance, one could choose a to normalise the volume of M to be constant, or perhaps to normalise the maximum scalar curvature ")#tao-math("\\left\\|R\\right\\|_\\infty", block: false)#text(" to be constant. (Of course, only one quantity at a time can be normalised to be constant, since one only has one free parameter to set.)")

#text("Setting a=0, we observe in particular that the solution space to Ricci flow enjoys the ")#emph[#text("scaling symmetry")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("g(t) \\mapsto \\lambda g(\\frac{t}{\\lambda})")]]

#text("for any ")#mi("\\lambda > 0")#text(". Thus, if we enlarge a manifold M by ")#mi("\\sqrt{\\lambda}")#text(" (or equivalently, if we fix M but make the metric g ")#mi("\\lambda")#text(" times as large), then Ricci flow will become slower by a factor of ")#mi("\\lambda")#text(", and conversely if we shrink a manifold by ")#mi("\\sqrt{\\lambda}")#text(" then Ricci flow speeds up by ")#mi("\\lambda")#text(". Thus, as a first approximation, big manifolds tend to evolve slowly under Ricci flow, and small ones tend to evolve quickly.")

#text("Similarly, Ricci flow combines well with diffeomorphisms. If g(t) solves Ricci flow and ")#mi("\\phi(t): M \\to M")#text(" is a smoothly varying family of diffeomorphisms, then we can define a modified Ricci flow ")#mi("\\tilde g(t) := \\phi(t)^* g(t)")#text(" (cf. (23)). As Ricci curvature is intrinsic, this new metric has curvature ")#mi("\\tilde{\\text{Ric}}(t) = \\phi(t)^* \\text{Ric}(t)")#text(". It is then not hard to see that ")#mi("\\tilde g")#text(" evolves by the flow")

#align(center)[#mi("\\frac{d}{dt} \\tilde g = - 2 \\tilde{\\text{Ric}} + {\\mathcal L}_X \\tilde g")#text(" (36′)")]

#text("where ")#mi("X(t) := \\phi^*(t) \\dot \\phi(t)")#text(" are the vector fields that direct the flow ")#mi("\\phi")#text(" as before. Note that (36′) is a combination of (30) and (24). Conversely, given a solution to a modified Ricci flow (36′) for some smoothly time-varying vector field X, one can convert it back to a Ricci flow by solving for the diffeomorphisms ")#mi("\\phi")#text(" and then using them as a change of variables.")

#text("The modified flows (36′) (with various choices of vector field X) arise in a number of contexts. For instance, they are useful for studying ")#emph[#text("gradient Ricci solitons")]#text(", which will be an important special solution to Ricci flow that we will encounter later. Also, modified Ricci flow is an excellent tool for assisting the proof of local existence (Theorem 1), because it can be used (via the “de Turck trick”) to “gauge away” some nasty non-parabolic components in Ricci flow, leaving behind a nicely parabolic non-linear PDE known as ")#emph[#text("Ricci-de Turck flow")]#text(" which is straightforward to solve.")

#text("To explain this, let us first write the Ricci flow equation (30) “in coordinates” in order to attempt to solve it as a nonlinear PDE. (The current state of the art of PDE existence theory does not cope all that well with the coordinate-independent frameworks which are embraced by differential geometers; in order to demonstrate existence of just about any equation, one usually has to break the covariance of the situation, and pick some coordinate system to work with. On the other hand, for particularly geometric equations, such as Ricci flow, there are often some special coordinate systems that one can pick that will simplify the PDE analysis enormously.)")

#text("The traditional way to express Ricci flow in coordinates is, of course, to use local coordinate charts, but let us present a slightly different way to do this, relying on an arbitrarily chosen ")#emph[#text("background metric")]#text(" ")#mi("\\overline{g}")#text(" on M which does not depend on time. (For instance, one could pick ")#mi("\\overline{g} = g(0)")#text(" to be the initial metric, although we do not need to do so.) This gives us a background connection ")#mi("\\overline{\\nabla}")#text(", background curvature tensors ")#mi("\\overline{\\text{Riem}}, \\overline{\\text{Ric}}, \\overline{R}")#text(", and so forth. One can then express the evolving metric in terms of the background by a variety of formulae. For instance, the evolving connection ")#mi("\\nabla")#text(" can be expressed in terms of the background connection ")#mi("\\overline{\\nabla}")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\nabla_\\alpha X^\\beta = \\overline{\\nabla}_\\alpha X^\\beta + \\Gamma_{\\alpha \\gamma}^\\beta X^\\gamma")]]

#text("where the Christoffel symbol ")#mi("\\Gamma_{\\alpha \\gamma}^\\beta")#text(" is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\Gamma_{\\alpha \\gamma}^\\beta = \\frac{1}{2} g^{\\beta \\delta} ( \\overline{\\nabla}_\\alpha g_{\\gamma \\delta} + \\overline{\\nabla}_\\gamma g_{\\alpha \\delta} - \\overline{\\nabla}_\\delta g_{\\alpha \\gamma} ).")]]

#strong[#text("Exercise 5. ")]#text("Verify (37) and (38). Then use these formulae to give an alternate derivation of (5) and (8). ")#mi("\\diamond")

#text("From (37) and the definition of Riemann curvature one concludes that")

#tao-aligned(keep: true)[


#tao-math("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta  & = \\overline{\\text{Riem}}_{\\alpha \\beta \\gamma}^\\delta + \\overline{\\nabla}_\\alpha \\Gamma_{\\beta \\gamma}^\\delta - \\overline{\\nabla}_\\beta \\Gamma_{\\alpha \\gamma}^\\delta", block: true)



#tao-math(" & + \\Gamma_{\\alpha\\mu}^\\delta \\Gamma_{\\beta \\gamma}^\\mu - \\Gamma_{\\beta\\mu}^\\delta \\Gamma_{\\alpha \\gamma}^\\mu.", block: true, numbering: n => [#text("(39)")])
]

#text("Contracting this, we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\text{Ric}_{\\alpha \\beta} = \\overline{\\text{Ric}}_{\\alpha \\beta} + \\overline{\\nabla}_\\delta \\Gamma_{\\alpha \\beta}^\\delta - \\overline{\\nabla}_\\alpha \\Gamma_{\\delta \\beta}^\\delta + {\\mathcal O}(\\Gamma^2).")]]

#text("Inserting (38) and only keeping careful track of the top order terms, we can eventually rewrite (40) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\overline{\\text{Ric}}_{\\alpha \\beta} - \\frac{1}{2} g^{\\gamma \\delta} \\overline{\\nabla}_\\gamma \\overline{\\nabla}_\\delta g_{\\alpha \\beta} + \\frac{1}{2} {\\mathcal L}_X g_{\\alpha \\beta} + {\\mathcal O}( g^{-2} \\overline{\\nabla} g \\overline{\\nabla} g )")]]

#text("where X is the vector field")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("X^\\alpha := g^{\\beta\\gamma} \\Gamma_{\\beta \\gamma}^\\alpha.")]]

#strong[#text("Exercise 6.")]#text(" Show that the expression (41) for the Ricci curvature can be used to imply (13). Conversely, use (13) to recover (41) without performing an excessive amount of explicit computation. (Hint: first show that the Ricci tensor can be crudely expressed as ")#mi("\\overline{\\text{Ric}} + {\\mathcal O}(g^{-1} \\overline{\\nabla}^2 g ) + {\\mathcal O}(g^{-2} \\overline{\\nabla} g \\overline{\\nabla} g )")#text(".) ")#mi("\\diamond")

#text("Thus, if we happen to have a solution g to modified Ricci flow (36′) with the vector field X given by (42), then the equation (36′) simplifies to the ")#emph[#text("Ricci-de Turck flow")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("\\frac{d}{dt} g = g^{\\gamma \\delta} \\overline{\\nabla}_\\gamma \\overline{\\nabla}_\\delta g - 2 \\overline{\\text{Ric}} + {\\mathcal O}( g^{-2} \\overline{\\nabla} g \\overline{\\nabla} g ).")]]

#text("Conversely, it is not too difficult to reverse these steps and convert a solution to Ricci-de Turck flow to a solution to Ricci flow.")

#text("The equation (43) is a quasilinear parabolic evolution equation on g (which we think of now as evolving on a fixed background Riemannian manifold ")#mi("(M, {\\overline g})")#text(", and one can establish local existence for (43) by a variety of methods. From this and the preceding remarks one can eventually establish Theorem 1, although we will not do so in detail here.")

#strong[#text("Remark 2.")]#text(" (This remark is intended primarily for experts in nonlinear PDE.) One particular way to establish existence for Ricci-de Turck flow (and probably not the most efficient) is sketched as follows. If one writes ")#mi("g = \\overline{g} + h")#text(", then one can recast (43) as a heat equation against the fixed background metric that takes the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\frac{d}{dt} h - \\overline{\\Delta} h = {\\mathcal O}( h \\overline{\\nabla}^2 h ) + F( h,\\overline{\\nabla h} )")]]

#text("for some smooth function F depending on the background (assuming that h is small in ")#mi("L^\\infty")#text(" norm so that one can compute the inverse ")#mi("g^{-1} = (\\overline{g} + h)^{-1}")#text(" smoothly). The essentially semilinear equation (44) can be solved (for initial data small and smooth, and on small time intervals) on a compact manifold M by, say, the Picard iteration method, based on estimates such as the energy inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\left\\| u \\right\\|_{L^\\infty_t H^k_x(I \\times M)} + \\left\\| u \\right\\|_{L^2_t H^{k+1}_x(I \\times M)} \\ll_{I,k} \\left\\| u(0) \\right\\|_{H^k_x(M)} + \\left\\| F \\right\\|_{L^2_t H^{k-1}_x(I \\times M)}", block: true)]]

#text("for some suitably large integer k (")#mi("k > d/2 + 1")#text(" will do), and with implied constants depending on the background metric, whenever u is a tensor that solves the heat equation ")#mi("\\frac{d}{dt}u - \\overline{\\Delta} u = F")#text(". This energy estimate can be easily established by integration by parts. To expand in a little more detail: the Picard iteration method proceeds by constructing iterative approximations ")#mi("h^{(n)}")#text(" to a solution h of (44) by solving a sequence of inhomogeneous heat equations")

#align(center)[#mi("\\frac{d}{dt} h^{(n)} - \\overline{\\Delta} h^{(n)} = {\\mathcal O}( h^{(n-1)} \\overline{\\nabla}^2 h^{(n-1)} ) + F( h^{(n-1)},\\overline{\\nabla h^{(n-1)}} )")#text(" (44′)")]

#text("starting from ")#mi("h^{(0)} = 0")#text(" (say). The main task is to show that the sequence ")#mi("h^{(n)}-h^{(n-1)}")#text(" converges rapidly to zero in a suitable function space, such as ")#mi("C^0_t H^k_x \\cap L^2_t H^{k+1}_x")#text(". This can be done by applying (45) with ")#mi("u = h^{(n)}-h^{(n-1)}")#text(" or ")#mi("u = h^{(n)}")#text(", and also using some product estimates in Sobolev spaces that are ultimately based on the Sobolev embedding theorem.")

#text("There is the still the issue of how to establish existence for the ")#emph[#text("linear")]#text(" heat equation on tensors, but this can be done by functional calculus (once one establishes that ")#mi("\\Delta")#text(" is a genuinely self-adjoint operator), or by making a reasonably accurate parametrix for the heat kernel. One (minor) advantage of this Picard iteration based approach is that it allows one to establish uniqueness and continuous dependence on initial data as well as just existence, and to show that the nonlinear solution obeys similar estimates (locally in time) to that of the linear heat equation. But uniqueness and continuity will not be necessary for the arguments in this course, and the estimates we need can always be established ")#emph[#text("a posteriori")]#text(" by energy inequalities anyway. ")#mi("\\diamond")

#strong[#text("Remark 3. ")]#text("The diffeomorphisms needed to convert solutions to Ricci-de Turck flow (43) back to solutions of Ricci flow (30) themselves obey a pleasant evolution equation; in fact, they evolve by harmonic map heat flow from the fixed domain ")#mi("(M, \\overline{g})")#text(" to the target ")#mi("(M, g(t))")#text(". See Chapter 3.4 of Chow and Knopf’s book “")#link("http://www.ams.org/mathscinet-getitem?mr=2061425")[#text("Ricci Flow: an introduction")]#text("” for further discussion. More generally, it seems that harmonic maps (and harmonic map heat flow, and harmonic coordinates) often provide natural coordinate systems that make various geometric PDE analytically tractable. On the other hand, for ")#emph[#text("geometric ")]#text("arguments it seems better to work with the original Ricci flow; the de Turck diffeomorphisms seem to obscure many of the delicate monotonicity properties that are essential to the deeper understanding of Ricci flow, and are also not completely covariant as they rely on an arbitrary choice of background metric ")#mi("\\overline{g}")#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Apr 3: Minor corrections.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (67)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-2/#comment-671981")[#strong[#text("Existence of minimizing geodesic – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")]

#text("[…] have read in a post in Terence Tao's blog that in every connected smooth manifold, any two points can be joined by $C^1$-piecewise minimising […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-2/#comment-694055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2026")])]

#text("Dear Prof. Tao,")

#text("Besides the de Turck trick mentioned here, Hamilton originally used the Nash-Moser iteration method to prove the local existence of the Ricci flow. Both approaches can establish the local existence of the Ricci flow, but using the de Turck trick is much simpler because it reduces the Ricci flow to a quasilinear parabolic equation. I would like to ask, apart from the fact that it simplifies the analysis, why is the Ricci flow well suited to the de Turck trick? Is it related to the gauge structure or other structures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ea5e8351bc52b04b984facb313dfb2122bc3ce8edda88d8889e3525e72587c0-8906d1b3c4a21b122a16401ca8fa5747c4e5992900e673f0be4f8b586cfa768e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan Thurston")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27749")[#strong[#text("Dylan Thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("You’re missing some dots on the g’s in the expression for ")#mi("\\dot{\\Gamma}^\\gamma_{\\alpha\\beta}")#text(", no?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("Oops! Well spotted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wenwen")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27793")[#strong[#text("wenwen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("The third formula of (22) seems to be wrong. The first formula of (31) need a minus sign.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear wenwen,")

#text("Actually, I believe the third formula of (22) is correct (it follows from the second, and from (11); one can also obtain it from dimensional analysis), and similarly the first formula of (31) follows from (30) and (3) (I’ve changed ")#mi("\\dot g^{\\alpha \\beta}")#text(" to ")#mi("\\frac{d}{dt} g^{\\alpha \\beta}")#text(" to reduce confusion here, given that the raising and lowering operations aren’t commuting with time differentiation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27827")[#strong[#text("285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("[…] an interval), and is the left-endpoint of I, then is a Ricci flow on , as defined in the previous lecture (in particular, M(t) is constant on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27872")[#strong[#text("Stefan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2008")])]

#text("Thanks for these notes! Two minor comments:")#linebreak()#text(" – There is the $L(\\gamma)$ missing on the left-hand side of (17). It is also a bit confusing that $t$ is used both for the flow-time and the parameterisation of the curve.")

#text("– In the paragraph after (18) it says ‘length $t^d$’ where it should just be $t$. Also here, a letter different from $t$ might be useful.")

#text("Best, Stefan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2008")])]

#text("Dear Stefan: Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 3: The maximum principle, and the pinching phenomenon « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-27895")[#strong[#text("285G, Lecture 3: The maximum principle, and the pinching phenomenon « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2008")])]

#text("[…] of a manifold undergoing Ricci flow do indeed obey nonlinear parabolic PDE (see equations (31) from Lecture 1), we will be able to obtain some important lower bounds on curvature, and in particular establishes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-28234")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Thank you for Remark 2. Every other reference I’ve seen casually states that the proof follows from “standard parabolic PDE” without giving any citation or summary of the argument. I eventually “convinced” myself that I could prove it using the Inverse Function Theorem (as well as linear estimates, of course), but I know I’m not the only one who is annoyed by the absence of a proper citation. I guess the assumption is that the reader is expert enough at PDE that it’s trivial, or is blissfully ignorant about PDE.")

#text("Also, regarding the existence of minimizing geodesics, you mentioned that it follows from Arzela-Ascoli, and I’ve read this before but never understood it. A minimizing sequence of unit speed curves is certainly bounded in ")#mi("C^1")#text(", and Arzela-Ascoli gives us a convergent subsequence, but that subsequence only converges in a weaker norm, so (even assuming regularity) why should the limit be minimizing? (On the other hand, the minimizing sequence argument makese sense to me if we work in Sobolev space, because we can use weak compactness and weak lower semicontinuity of the energy functional.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 4: Finite time extinction of the second homotopy group « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-28838")[#strong[#text("285G, Lecture 4: Finite time extinction of the second homotopy group « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("[…] flow on Riemannian metrics. Our task is to show that at time zero. By equations (15), (19) of Lecture 1, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29224")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("[…] mentioned in Lecture 1, local existence of the Ricci flow is a fairly standard application of nonlinear parabolic theory, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29309")[#strong[#text("285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("[…] in time in some arbitrary manner, a simple application of integration by parts (equation (29) from Lecture 1) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29329")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("Dear Dan,")

#text("Hmm, you raise a good point. The Arzela-Ascoli theorem only gives a minimiser in the Lipschitz class rather than the C^1 class (and now one needs to use weak derivatives or the theory of rectifiability to make sense of the length of such curves). Actually this seems to be the best one can do just from compactness; if for instance you put a pointy obstacle within your manifold then geodesics will definitely have corners to them. But if you also know that locally length-minimising geodesics are smooth (which can be obtained from the Gauss lemma in small neighbourhoods of the origin) this gives you enough regularity to get back into C^1, and then you are done (note that by Fatou-type lemmas, the length of a limiting curve is at most the limit of the lengths of the approximating curves). I’ll amend the text accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29405")[#strong[#text("285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2008")])]

#text("[…] a regularisation of Chow-Chu’s viewpoint. Possibly related posts: (automatically generated)285G, Lecture 1: Flows on Riemannian manifolds285G, Lecture 7: Rescaling of Ricci flows and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29617")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("Thanks. It’s good to know I’m not crazy. I once worked out the argument along the lines you suggest, using rectifiable curves, but imho the Sobolev argument seems more elegant (albeit less elementary).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29864")[#strong[#text("285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2008")])]

#text("[…] preserved along X, as is the inner product between any two such v’s (cf. equation (15) from Lecture 3). A brief computation then shows […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29896")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] of Exercise 6, as well as the evolution equation for scalar curvature (equation (31) of Lecture 1), show that the scalar curvature of a solution is strictly positive at every point in spacetime. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-29910")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] the Riemann curvature tensor under Ricci flow (see equation (31) of Lecture 1). The bound on Riemann curvature can then obtained by an application of Hamilton’s maximum […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/371e142bc300ab9e7766fa0f0a7f6e4b7b005efc1d33c1edce60a5059fae0725-9baa03b803570fa26d7a5867dc122131fdc9695161f459831097dd3f13abde24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math Student")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30105")[#strong[#text("Math Student")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2008")])]

#text("If somebody could show step by step how (3) was derived from (2), I would really appreciate it.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30140")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] the variation formulae from Lecture 1, we have and . Inserting these formulae and integrating by parts to isolate u, we see that it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear Math Student,")

#text("Differentiating (2) using the product rule gives ")#mi("(\\frac{d}{dt} g^{\\alpha \\beta}) g_{\\beta \\gamma} + g^{\\alpha \\beta} \\dot g_{\\beta \\gamma} = 0")#text(". Multiplying this by ")#mi("g^{\\gamma \\delta}")#text(" and using (2) again gives the claim after some rearranging (and some relabeling).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30201")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("[…] (Proposition 1 from Lecture 4) that , and hence by the volume variation formula (equation (33) from Lecture 1) the volume is decreasing in time at a constant rate . Let us shift time so that the volume is in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/371e142bc300ab9e7766fa0f0a7f6e4b7b005efc1d33c1edce60a5059fae0725-9baa03b803570fa26d7a5867dc122131fdc9695161f459831097dd3f13abde24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kaz")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30210")[#strong[#text("Kaz")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("Dear Professor Tao:")

#text("I got it. Thank you so much. I didn’t think I will be lucky enough to get the answer from you directly.")

#text("I should inform you that I am not a student in your class. I hope it was still permissible that I post a question online; my name is Kaz by the way. To understand the proof, I started following your lectures about a month ago, about 15 lectures behind. I plan to keep up with your blog and ask questions when I have some.")

#text("Your open-to-putlic blog is very much appreciated.")

#text("Best regards,")

#text("Kaz (Math Student)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7af95cf7119181c539e7c13620b62940a2a81ddcde278df4b2437722dc43728-2ad3d419daf57450f7a04a5a163e2d2bad2ec8d7953fe6683d345dabc84d0f65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30941")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("Dear Professor Tao,")

#text("There is a typo in formula (39) in the indices of the Riem “bar” term. Also in formula (41) the second derivative of g should be taken using the background connection, I mean some bars are missing.")

#text("The formula you have written for the variation of determinant only works for symmetric matrices, for the general case you should use ” the inverse of the transpose of A” instead of “the inverse of A”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-30945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("Dear Mohammad: thanks again for the corrections! But I believe the formula for variation of the determinant is correct as stated. Using the Newton approximation ")#mi("A(t) \\approx A(0) + \\dot A(0) dt")#text(" we have ")#mi("\\det(A(t)) \\approx \\det(A(0)) \\det( I + A(0)^{-1} \\dot A(0) dt )")#text(". Since ")#mi("\\det( I + B dt ) \\approx 1 + \\text{tr}(B) dt")#text(", we obtain the stated formula. (One can also observe that the stated formula is invariant under multiplying A on the left or the right by a fixed matrix, which is not the case if one inserts a transpose in the formula.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21aa472f8f494bc91b3f99127ecfb240005ad8fd92924bde9342f28755854eba-7971f5b8170dffe3c80165b7c231573ce5686efec2b955b95c917ec0dd874252.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-31146")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Another correction! There are two equations with number 36.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-32689")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("[…] existence of Ricci flow uses a gauge of de Turck that is also related to harmonic maps (see e.g. my lecture notes); and in my own work on wave maps, a certain “caloric gauge” based on harmonic map heat […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of torus")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-39517")[#strong[#text("torus")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("Dear Prof Tao,")

#text("we say torus is ")#mi("S^{1}\\times S^{1},")#text(" I understand we put one circle on the plane and then for every point on this circle we are putting another circle which has center of that point and it is radius is perpendicular to the first one. in that case when I imagine this figure, I could not see any hole on it. because the circles we put on the first one touch each other around the center of the first circle.")

#text("is my understanding wrong or why do people draw torus with a hole?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-39520")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("If you shrink the radii of the vertical circles you will recover the familiar toroidal shape. Alternatively, if one does not want to distort lengths, one can work in four dimensions, so that the vertical circles are completely perpendicular to the horizontal circle. (Right now, only one of the two dimensions of the vertical circle is perpendicular to the horizontal circle, which is what is causing the problem.) This latter description is what is actually meant by the Cartesian product ")#mi("S^1 \\times S^1")#text(", at least if one views the circle ")#mi("S^1")#text(" as a subset of ")#mi("{\\Bbb R}^2")#text("; this set is sometimes called the “flat torus”. By shrinking the vertical radii and then flattening one of the vertical dimensions back to three dimensions we see that the set ")#mi("S^1 \\times S^1 \\subset {\\Bbb R}^4")#text(" is indeed topologically equivalent to the familiar torus.")

#text("Since higher dimensions are harder to visualise than lower dimensions, perhaps a better (and still equivalent) way to view ")#mi("S^1 \\times S^1")#text(" is to first flatten ")#mi("S^1")#text(" by viewing it is isomorphic to ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" (or equivalently, the interval [0,1] with the vertices identified), and then ")#mi("S^1 \\times S^1")#text(" is isomorphic to ")#mi("{\\Bbb R}^2/{\\Bbb Z}^2")#text(" (or equivalently, the square ")#mi("[0,1]^2")#text(" with the edges identified).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometry beginner")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-39823")[#strong[#text("geometry beginner")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("Dear Prof. Tao,")

#text("It is not clear for me when people say ” closed smooth manifold…”.")

#text("a manifold M is basically a topologic space and in any topologic space the set M itself is closed. why do we say ”closed” manifold?")

#text("Could you explain this point?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-39824")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("For manifolds, “closed” means “without boundary”, as opposed to “topologically closed”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometry beginner")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-41867")[#strong[#text("geometry beginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("Dear Prof. Tao,")

#text("We know that in order to show that a topologic manifold is a smooth manifold it suffices to put a differentiable atlas on it. let’s look at the following example:")

#mi("G=\\{(x,x^{2/3}) :  x \\in {\\Bbb R}\\}")#text(" is a 1 dimensional topologic manifold.")

#text("as an atlas let’s take ")#mi("\\{(G, \\phi)\\}")#text(" where ")#mi("\\phi : G \\to {\\Bbb R},  \\phi(x, x^{2/3})=x")#text(".")

#text("We know that there is a maximal atlas which contains the above atlas. therefore ")#mi("G")#text(" is a smooth manifold.")

#text("the function ")#mi("x \\to x^{2/3}")#text(" is not smooth but its graph is a smooth manifold.")

#text("is that true? if not, where is my mistake?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-41868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("This is indeed a smooth structure on G (you’ve just pulled back the smooth structure on ")#mi("{\\Bbb R}")#text("), but it is not compatible with the ambient structure on ")#mi("{\\Bbb R}^2")#text(" (the inclusion map is not smooth). So the structure is fairly useless if one insists on viewing G as an embedded manifold.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometry beginner")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-41869")[#strong[#text("geometry beginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you for your answer. I am still confused with the following issue.")

#text("We know that any smooth manifold can be embedded in ")#mi("{\\Bbb R}^{n}")#text(" for some suitable n. in that case do you mean that G is embedded in a larger space? (i.e ")#mi("n > 2")#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-41870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("G can be smoothly embedded in (and indeed identified with) ")#mi("{\\Bbb R}")#text(" by using the map ")#mi("\\phi")#text(". However, the inclusion embedding of ")#mi("G")#text(" in ")#mi("{\\Bbb R}^2")#text(" is not smooth, and so it is dangerous to use this smooth structure on G while simultaneously thinking of G as the subset ")#mi("\\{ (x,x^{2/3}): x \\in {\\Bbb R} \\}")#text(" of ")#mi("{\\Bbb R}^2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometry beginner")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-41879")[#strong[#text("geometry beginner")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2009")])]

#text("Dear Prof. Tao,")

#text("Let")

#mi("A= \\{(x,\\sin (1/x)) :  0< x< 1 \\}")#text(" and ")#mi("B=\\{(0, y) : -1 <y < 1\\}")

#text("is ")#mi("A \\cup B")#text(" a submanifold of ")#mi("{\\Bbb R}^2")#text("?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-143145")[#strong[#text("short-time existence | kassandra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2012")]

#text("[…] Ben Andrews, Christopher Hopper: The Ricci Flow in Riemannian Geometry. Page 90. Terence Tao: 285G, Lecture 1: Flows on Riemannian manifolds (Weblog “What’s new”) This entry was posted on 16. May 2012, in general, ricci […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jolany hassan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147568")[#strong[#text("jolany hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("Dear Tao, we know, we have short time existence on Ricci flow so can we get from this fact short time existence on Normalized Kahler Ricci flow?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("Yes, because (a) every Kahler manifold is also a Riemannian manifold (by forgetting the complex structure, and using the real part of the Hermitian metric to give the Riemannian metric); (b) the Ricci flow on a Riemannian manifold which also happens to be Kahler, preserves the property of being Kahler (and even preserves the Kahler class up to rescaling), if one keeps the complex structure fixed; and (c) for Kahler manifolds, the Ricci flow and the Kahler-Ricci flow are identical (except (in some literature) for a factor of two in the choice of normalisation factor).")

#text("I don’t have the reference physically handy here, but I believe these points are addressed in “Hamilton, R. S. The formation of singularities in the Ricci flow, Surveys in differential geometry, Vol. II (Cambridge, MA, 1993), 7–136, Int. Press, Cambridge, MA, 1995”. It is also covered in “The Ricci flow: techniques and applications” by Chow et al.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jolany hassan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147588")[#strong[#text("jolany hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("We have short time existence on Ricci flow but unfortunately we don’t have this fact on normalized Ricci flow . So how you could extend the short time existence on normalized Kahler Ricci flow? see page 5 of ")#link("http://www.math.mcgill.ca/gantumur/math581w12/downloads/Ricci.pdf")[#text("http://www.math.mcgill.ca/gantumur/math581w12/downloads/Ricci.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147593")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("As mentioned in the link you provided (and also in my blog post above), there is a bijection between solutions of Ricci flow and solutions of normalised Ricci flow that can be used to pass from one to the other; the reference provided in that link (R. S. Hamilton, “Three-manifolds with positive Ricci curvature,” Journal of Di erential Geometry, vol. 17,")#linebreak()#text(" no. 2, pp. 255-306, 1982.) will certainly contain the details (or, you could simply read my blog post above). The same transformation also works to connect solutions to Kahler-Ricci flow to normalised Kahler-Ricci flow (since these flows are simply special cases of the Ricci and normalised Ricci flow respectively, up to some harmless normalising factors of 2).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jolany hassan")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147596")[#strong[#text("jolany hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("Dear Tao, if we accept your method, so we have long time existence for Ricci flow , So why H.D.Cao for proving Calabi Yau conjecture proved it for normalized Kahler Ricci flow without using this fact and in several pages?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("Long-time existence of normalised Ricci flow does not necessarily imply long-time existence of un-normalised Ricci flow, due to the time renormalisation. For instance, in the case of a sphere shrinking to a point, the un-normalised Ricci flow blows up in finite (un-normalised) time, but if one normalises to have constant volume (for instance), then the normalised Ricci flow exists for all (normalised) time.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO TRIVIÑO NAVARRO")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-147609")[#strong[#text("HUMBERTO TRIVIÑO NAVARRO")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("muy interesante la forma como tiene la conexión y la claridad de sus contenidos .")#linebreak()#text(" podría consultarle sobre un tema de teoría de membranas y la formalización sobre figuras en cuarta , quinta dimensión.")#linebreak()#text(" encontrando algo más allá del punto de partida de la botella de kleiner en particular¡¡?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5ce0e85ca6aebc61c6052e9ea8f4bec4948fa3564ebb6969215beef660700d4-ecdba11f44d083511f2956f80d4caa18cf4b27535f347d5551ddf531aab6747d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dimitri")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-184250")[#strong[#text("Dimitri")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2012")])]

#text("Before proceeding, I’d like to apologize if this is not exactly the right “chain of responses” to pose my question.")#linebreak()#text(" I’ve just started enhancing my knowledge in the field of Manifold Theory, and I came up with the following question:")

#text("“Given a manifold M, how could we proof the existence of (and find) a function/transformation g{.}, such that the new manifold M’ = g{M} has the following property: the tangent space of M’, T(M’), has at least one constant function (or equivalently, there is a “valley” in which one can travel without increasing or decreasing his/her gradient).”")

#text("This may have been already answered. In any case, I would be grateful to get any suggestions and ideas about that question, or even a suggestion of textbooks with the related theory so as to tackle this problem.")

#text("Best regards!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cc2cf190f8ea32b366fb4043114d93c49d6382140915fea2122d40b0216de90-cc1664f1826da0e9fc72c095d4eeb81a97d397daacd5c7e4307fe6dce0cd5845.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrygrigg")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-214992")[#strong[#text("harrygrigg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2013")])]

#text("Reblogged this on ")#link("http://harrygrigg.wordpress.com/2013/01/29/93/")[#text("harrygrigg")]#text(" and commented:")#linebreak()#text(" Words from the Genius.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daoyuan Han")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-241019")[#strong[#text("Daoyuan Han")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2013")])]

#text("Hi, professor Tao, how do you get (11) from (10)?")

#emph[#text("[Oops, there were some sign errors in (10) which should now be fixed – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-262973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("Thanks, and another question, how to get the second term in (17); I understand both metric and curve are changing over time, I guess the second term is to evaluate the impact of curve changing assuming the metric is constant.")

#emph[#text("[See responses to zns below. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-263232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Thanks, but what confuses me is the second part of the r.h.s of (17), how to get the second part of the r.h.s of (17)?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df79217b7261526ad308fe270426a9f4b37d748870496d5a7013450d4f9b8662-6d7dcc78ba06277c35df52339c241913c4152765cc6801d7a17a9f11101552bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zns")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-251410")[#strong[#text("zns")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("Dear Professor Tao, is formula 17 correct? I am getting something like \\frac{1}{2}\\int_{\\gamma}{\\dot{g}(S,\\gamma’)} for the first factor instead.")

#text("Thank you in advance. ZNS")

#emph[#text("[The calculation appears correct to me. If for instance ")#mi("\\gamma")#text(" does not vary in time, the first variation of ")#mi("\\int_a^b g( \\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )^{1/2}\\ du")#text(" is ")#mi("\\frac{1}{2} \\int_a^b \\dot g(\\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )  g(\\gamma^{\\prime}(u), \\gamma^{\\prime}(u))^{-1/2}\\ du")#text(", which matches the first term in (17). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df79217b7261526ad308fe270426a9f4b37d748870496d5a7013450d4f9b8662-6d7dcc78ba06277c35df52339c241913c4152765cc6801d7a17a9f11101552bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zns")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-251448")[#strong[#text("zns")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("Dear Prof. Tao, thank you for your reply,")#linebreak()#text(" I am just getting the same formula that you wrote, but with a -1 in the exponent instead of -1/2 due to the definition of S and (possibly) some wrong calculations of mine and that is mainly the reason of my confusion.")#linebreak()#text(" In any case thank you again.")

#emph[#text("[The calculation is just the chain rule combined with the fact that the derivative of ")#mi("x^{1/2}")#text(" is ")#mi("\\frac{1}{2} x^{-1/2}")#text(". Note also that ")#mi("dS")#text(" is equal to ")#mi("g( \\gamma^{\\prime}(u), \\gamma^{\\prime}(u) )^{1/2} du")#text(". -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-263486")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Dear Prof. Tao. I Was wondering if you would be interested in my ideas concerning the problem of curl of tensors. Have I understood correctly that the Riemann curvature tensor is related to the curl of a rank 2 antisymmetric tensor? I have some thoughts around how to think about electromagnetism and gravity, and the curl of the electromagnetic field tensor seems to yield something like a Riemann curvature tensor. My ideas can be found at ")#link("http://jussilindgren.wordpress.com")[#text("http://jussilindgren.wordpress.com")]

#text("Best, Jussi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-263527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Hi, Professor Tao, (24) and below the definition of ")#mi("X(t)")#text(" confuses me a little bit, should ")#mi("X(t)")#text(" be equal to the push-forward of ")#mi("\\dot \\phi(t)")#text(", which is (")#mi("\\phi_{*}(t)\\dot\\phi(t)")#text(") rather than ")#mi("\\phi^{*}(t)\\dot \\phi(t)")#text(" ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-454266")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("Your definition of “Volume measure” states that ")#mi("g_{ab} = g(e_a,e_b)")#text("; are you sure this is not supposed to be ")#mi("g(\\partial_a, \\partial_b)")#text("?")

#text("…in fact, should that coefficient even be there?")

#emph[#text("[One can label the frame as ")#mi("(\\partial_a)_{a=1}^d")#text(" instead of ")#mi("(e_a)_{a=1}^d")#text(" if one wishes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-454289")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("But labelling it as ")#mi("(\\partial_a(s) := T_s x^{-1} . e^a)_{1\\le a \\le d}")#text(" means the frame is no longer arbitrary; it’s a coordinate frame induced by the chart ")#mi("x: U \\subset M \\rightarrow \\mathbf{R}^d")#text(". The way you have it set up, the coefficients ")#mi("g_{ab}")#text(" depend on the choice of frame. (Perhaps this is what you want?)")

#emph[#text("[Yes; the coefficients ")#mi("g_{ab}")#text(" depend on the choice of frame, but the volume measure ")#mi("d\\mu")#text(" does not. One can specialise to coordinate frames if desired to define the volume measure, but it is not necessary to do so. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isomorphismes")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-457427")[#strong[#text("isomorphismes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2015")])]

#text("Reblogged this on ")#link("https://hiremebecauseimsmart.wordpress.com/2015/07/18/285g-lecture-1-flows-on-riemannian-manifolds/")[#text("Human Mathematics")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91589be27626f72733cc1808751765a4cde674a87637b22b5e863c97ce36ea21-50bf6d2dff46874bd8b944a52af69d16bff14c325ccb6e37091c96b0b6e39771.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wilson@not abstract")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-466379")[#strong[#text("wilson@not abstract")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2016")])]

#text("For equation (11), I get a similar result, but wonder if it is equivalent. What I got is exactly with covariant derivative ")#mi("\\nabla_\\alpha")#text(" exchanged with ")#mi("\\frac{\\partial}{\\partial\\alpha}")#text(", and same for ")#mi("\\beta")#text(". What is wrong with my calculation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-574338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2020")])]

#text("In equation (3), I believe \\frac{d}{dt}g^{-1} should be \\-g^{-1}\\dot g g^{-1} instead of \\-g^{-1}g^{-1} \\dot g .")

#emph[#text("[In Penrose notation the order of the tensors does not matter: ")#mi("g^{\\alpha \\gamma} g^{\\beta \\delta} \\dot g_{\\gamma \\delta} = g^{\\alpha \\gamma} \\dot g_{\\gamma \\delta} g^{\\beta \\delta}")#text(". Both of these correspond to ")#mi("- g^{-1} \\dot g g^{-1}")#text(" in coordinate free notation. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-574692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2020")])]

#text("I think the subscript of Riem in the formula for Lichnerowicz Laplacian in (31) really should be \\gamma\\alpha\\beta")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d581be42b01c30a27d5c1f641020a901c2a2c4ec2b35396ef12182571a77dee8-ae189b7b1f2f179a6984dd34cb09b67361b577067fd8ab0cdcda39f0d9d6091a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-590954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2020")])]

#text("About equation 18, is it true we can find \\gamma_t geodesic (for g(t)), with \\gamma_t(a) = x, \\gamma_t(b) = y such that \\gamma_t is smooth on t? I “proved” equation 18 with this assumption but I don’t know why is it true.")

#text("I would appreciate if anyone can point further reference about this topic. I am just starting in Riemann geometry and couldn’t find anything about what happens to d(x,y) when we change the metric in introductory books. Thanks")

#text("By the way, thanks for the notes. I found by accident in google while looking for something like equation 18")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-591368")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2020")])]

#text("One cannot guarantee that the geodesics vary smoothly in ")#mi("t")#text(", but this is not necessary to establish (18). One needs to obtain upper and lower bounds for $d(x,y)$ at time $t = t_0 + dt$, say for positive small ")#mi("dt")#text(", that are accurate up to errors of ")#mi("o(dt)")#text(". The upper bound can be obtained by re-using the geodesics at time ")#mi("t_0")#text(" as test geodesics at time ")#mi("t_0+dt")#text(". To get the lower bound, use a compactness argument to show that any minimizing geodesic ")#mi("\\gamma")#text(" at time ")#mi("t")#text(" must lie within ")#mi("o(1)")#text(" of a minimizing geodesic ")#mi("\\tilde \\gamma")#text(" at time ")#mi("t_0")#text(". Then compare the time ")#mi("t")#text(" length of ")#mi("\\gamma")#text(" with the time ")#mi("t_0")#text(" length of ")#mi("\\gamma")#text(" by Taylor expansion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d581be42b01c30a27d5c1f641020a901c2a2c4ec2b35396ef12182571a77dee8-ae189b7b1f2f179a6984dd34cb09b67361b577067fd8ab0cdcda39f0d9d6091a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-591606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2020")])]

#text("Thank you very much for your answer, it helped me a lot")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6019702fb0d973c6f733d1b297a82fba49d3ff4672ef516f59ca43a905eec128-5d50ef26b541301daa6c81eb4cab566f8e5f1d1d2679907865a9002bf882a1f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khitish")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-636289")[#strong[#text("Khitish")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2021")])]

#text("Dear Professor Tao,")

#text("Thank you for these wonderful lecture notes.")

#text("In eqn. (24), you defined ")#mi("X(t)=\\phi_{*}(t)\\dot{\\phi }(t)")#text(". Aren’t we supposed to push-forward the vector at t=0, hence requiring ")#mi("X(t)=\\phi_{*}(t)\\dot{\\phi }(0)")#text("?")

#emph[#text("[This should have been pullback rather than pushforward; now corrected. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d1d4d7eedcb7a8bc8349ab1a5d339a84bc414c6555cfebfb9f9fbbb7f6af109-35d0a53f486762b86e3168086f0157107186a6a5e2355ec6022cef86aaf49543.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-638015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2021")])]

#text("Equation (17) does not seem true: as it is written, rescaling the speed of the path will change the value of ")#mi("\\frac d{dt} L(\\gamma)")#text(". I think that")

#mi("\\frac d{dt} L(\\gamma) = \\frac 12 \\int \\dot g(S,\\gamma^{\\prime} ) - \\int g(\\nabla_{\\gamma^{\\prime}} S, V)")

#text("should be correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/comment-page-1/#comment-638023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2021")])]

#text("I think the formula is correct as stated (note that we are fixing ")#mi("a, b")#text(", so we cannot rescale the speed of the path).")
]
]
