// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/
// Converted to Typst by tao2typ: "2026-10-18T11:27:04.404249+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "This is normal bad work", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("This is normal bad work")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/")[#text("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sophie.huiberts.me/")[#text("Sophie Huiberts")]#text(", being an expanded version of a post on ")#link("https://sophie.huiberts.me/blog/2026/community/")[#text("her own blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When you prove a theorem, you are imparted a responsibility to the field of mathematics. At minimum you need to explain what you did, including which steps required new ideas and which steps are already well-known. More substantively, you are expected to nurture the literature. If an important idea was poorly explained in its first incarnation, then you have a duty to explain it better in your work. The responsibility is yours because you have the opportunity to publish a paper on the subject.")

#text("These demands are broadly accepted and are neither new nor controversial. Any time you exceed the demands, the resulting paper is highly appreciated and valued. Any time you fail the demands, you will get a “revise and resubmit” for a journal submission, or a straight rejection for a conference. Until you fix your exposition, your ideas will not enter the canon. If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.")

#text("Compare this to OpenAI’s behavior. They do not care about their “preprints”. They don’t bother putting in appropriate attribution of ideas, they salami-slice 372 results over 719 pdfs, their work ")#link("https://bsky.app/profile/curiouscoding.nl/post/3mxeerfpahk2u")[#text("contains retraction-worthy errors")]#text(", they ")#link("https://bsky.app/profile/dulwichquantum.bsky.social/post/3mxlpp3tuv226")[#text("promise code but neglect to include it")]#text(", and their proofs are fiendishly hard to parse. Their pdfs actively set back the state of the literature. This is poor quality work and these pdfs are all easy rejects.")

#text("We all know that OpenAI is not doing this “for the good of science”. These pdfs are ")#link("https://bsky.app/profile/pwnallthethings.bsky.social/post/3mxb67hhd7k2h")[#text("exhaust fumes")]#text(" from their internal benchmarking effort. We do not need them to release this unprocessed exhaust into the atmosphere. OpenAI’s new internal model may have produced these texts with the press of a button. But similar results would have been found soon by experts, with or without LLM prompting. Some results ")#link("https://curticapean.net/math-notes/")[#text("were already found by ChatGPT users")]#text(" and were in the process of being written up properly. Even without alleging theft, it is a bad look for a supplier of scientific software to actively scoop their customers.")

#text("If an expert prompts a result, they take up the mantle of responsibility I describe above. OpenAI not only refuses to take their responsibility, but they prevent their own customers from doing so.")

#text("October 6th was not a watershed moment for mathematics. OpenAI’s droppings on GitHub are normal progress: normal for the current state of technology. Or at least normal for the available technology in 2 months from now. The only thing that is exceptional is OpenAI’s lack of shame for releasing poor quality work.")

#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13ab4b5d2b1926c2ba204fa7b30425aa73f0ac71ff5a52a0f1e36719e4430ee8-48947c301150bd5bf58fe432ffc25a58e137f76320736bc778b7cb0ee5fca291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697862")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("This post reminds me of a joke about a talking dog. The man selling the dog only sells him for $50. The prospective buyer asks “why so cheap? I would think you could get a lot more for a talking dog.” The dog’s owner responds “the dog is so cheap, because he is a liar.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697981")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("I’m too stupid to get what you’re trying to say?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698093")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("The dog owner is so fixated on the dog’s flaws that they overlooks the fact it can talk. Likewise, the author is so focused on AI’s shortcomings that she overlooks its remarkable ability to make novel mathematical discoveries.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("It is a multi-layered joke where you can as well interpret it as the owner being the liar, because dogs obviously do not talk and the owner is making up a flimsy reason.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697866")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("When you prove a theorem, you owe nothing to mathematics. It is your theorem. You can hide it under your bed, keep it in your head, share it with your friend, or try to publish. Only in the last case can we require anything of the prover.")

#text("OpenAI does not consist of mathematicians. They make computer programs. These programs happen to be rather helpful to many of us, when trying to prove things. Further, unlike many results of the past, we now have a convenient way to check, often quite quickly, whether their ideas have merit (via Lean proofs). OpenAI itself does not try to publish very much. They did make available the results of their work, after a plurality of mathematicians asked them for it. It was somewhat rushed because, again, we asked them to do it as soon as possible.")

#text("I expect that as time goes on, these very new tools will also get good at writing up their results. But they have no obligation to do so. And we, if we don’t want to use them, don’t have to. I personally find them quite useful. They have answered multiple questions I’ve thought about for years. While their write-ups are not (yet!) great, I’ve enjoyed working through the ideas, and figuring them out in my own way.")

#text("So, I guess I’d offer this You don’t have to accept their results as canon, and they are not asking you too. You are welcome to leave it to others to write up the results in a more comprehensible manner, do it yourself, or wait for the LLMs to get better at it. Your choice.")

#text("(And I’m sorry, October 6th was a watershed moment. If you can’t see that, you don’t know how many people wasted months and years of their lives just trying to understand Mochizuki’s ABC papers.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e75b378d4f6926c951a0bb622fe36a7d2fa86e220dc6c8dfe038fba026dd99b1-6dc99bd60a409be1b00a129578993166413221c15a0bc0383d0eca07134baf9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of In Favor of Good Behavior")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697870")[#strong[#text("In Favor of Good Behavior")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Sometimes person A tries to have a conversation about morals and values, in an attempt to answer questions like “is this behavior good?,” “how should we behave in general?”, “what should we do in response to this behavior?”, etc.")

#text("Then person B replies by making descriptive declarations that essentially amount to “these people do not have to behave well.”")

#text("What you’re saying is true… but not useful or interesting. Your assertion as written appears to be that employees at Open AI don’t have an obligation to behave morally. That’s fine to share as your opinion, but everyone else can still judge them for behaving badly, and encourage them to choose a moral option!")

#text("More broadly, it seems like your comment is a generic argument against anyone ever helping others, or attempting to mitigate harm. Such reasoning seems silly and destructive, and I hope others in our community opt not to behave and argue as you have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697875")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("There is no practice of “good behavior” for such a kind of situation because no single mathematician or group of mathematicians or institutions had ever before obtained such an amount of new results of such relevant level in such a short time. It’s just useless to keep pointing out how journals accept/reject/revise papers, how things were done in the “normal” time. This is not normal at all (if the writer alludes to Kuhn, this is a revolution, quite the opposite of normal math!).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697914")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("We know that Silicon Valley people are amoral and nihilists and you argue their (lack of) values.")

#text("Are you sure you want to go that route? What if we, in the best Silicon Valley tradition, flip the argument?")

#text("“The general public owes nothing to OpenAI. You can use it or not. Property rules are a social construct, so the people decide that OpenAI is national property. Nationalization will be carried out without compensation, since OpenAI was supposed to be a corporation in the public benefit anyway before it was illegally converted to a partially private one. Everyone whose IP was used for training will be compensated by the state.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697930")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Nope. To the extent that it’s true that mathematicians “asked” OpenAI to release the results, what OpenAI ended up doing was more like malicious compliance or at least culpably negligent compliance. You might want to reread the AGMAI recommendations about this.")

#text("If there’s one lesson that should be taken from this episode, it’s that we really need to be holding publicly posted work to ")#strong[#text("much")]#text(" higher standards. Farting out purported proofs is not doing mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c444a848a8495e95d351f13559266fe8adcc121d3f7201306c7460a495c0933e-3365f5dfa24141ba2151c926ee663dd6a34f890061a120ece14ba8db40f4a070.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hume")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697965")[#strong[#text("Hume")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The thing is many of these additional responsibilities (go to seminar, journal submission, etc.) belong to “paid” academics. A hobbyist doesn’t get paid so we cannot impose on them the teaching/research/service expectations of typical academics. So, if the hobbyist post the result on their Facebook or X, the most we can do is click Like and congratulate them. If they kindly write up and post on Arxiv we should be extra thankful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697975")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("In most of the countries in the world, except for a handful, academics who do such work are poorly paid. Most and for all, we should be thankful to those with professional training and low salaries to do those jobs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b017be5f880a343f98b50d7debf7f9a4c94ce2e7dd7d95ec11e2f1ab57d93ae5-c3a65f63a7a2dbf01ccc18f47eaa2934a925bf286506125d5064399c7d7708cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of babesh")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698072")[#strong[#text("babesh")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Has someone pointed OpenAI at Mochizuki’s material to validate or invalidate them?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697867")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("“OpenAI’s droppings on GitHub are normal progress: normal for the current state of technology. Or at least normal for the available technology in 2 months from now.”")

#text("What is the claim here…?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b7a239469affa1a4b1a2acf2ce3aa78f2d545704d09e87f1fa3c5387858562-d9818fdeb577d9cf5e16963235b3497e0377868f47041ab711b5b995b8e6fb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697940")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The claim, as I understand it, is that OpenAI knows that this batch of problems is not really surprising by the standards of what many LLMs are capable of today.")

#text("There are many other results (for example, in my area of PDE) that have been found in the output of LLMs in the last month or so by people using various commercial (closed and open weights) models.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698009")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("OpenAI’s proofs were done using an unreleased frontier model. When that model is released in some small number of months, it will become available technology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697874")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("“If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.”")

#text("I think it is embarrassing to compare some random badly written arxiv paper to 372 results produced by an automatic machine that dramatically improve the best known results in a number of fields (“annihilating” the entire research field of some Fields Medalist!). ")#linebreak()#text("“Normal Bad Work”?! Come on, there is a quasi-Riemann hypothesis!")

#text("With all due respect I wonder why this blog post landed in this page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697890")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The real concern that mathematicians seem to be is that the subject will die out and will be reduced to a hobby. That’s a valid concern, but ultimately that’s not especially important in the long run. In the history of mankind, many things come and go, whether that is for the best or worst is not something which can be decided at this point. Loss of the merits of manual labour was lamented by many in the past, but that’s just the way it is. One should accept the change, or one might just lose their dignity as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697955")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("If it were only mathematics, then yes, we would easily absorb the loss. Alas what is affected is INTELLIGENCE, not just mathematics. It’s kinda tricky to figure out what remains when manual AND mental are taken away")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b59b4087089ddb1ba8f373b0c954fc6608367c70119a1d7823667b61455a9d9-2c4dd2feb9f3a7b4922541e47d77e214f3e40467e3d7da909f959e462f8c4390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arham Zahid")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697899")[#strong[#text("Arham Zahid")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I agree with the central principle that publishing mathematics carries responsibilities of correctness, attribution, exposition, and intellectual stewardship. OpenAI should be held to those standards. However, I think this article makes several sweeping claims that are not justified by the evidence, and in doing so risks undermining an otherwise legitimate criticism.")

#text("First, poor exposition is not evidence of mathematical insignificance. A manuscript can be unsuitable for journal publication while containing a genuinely important theorem or technique. Describing all 719 manuscripts as “easy rejects” without a systematic, individual assessment seems inconsistent with the very standards of scholarly rigour the article invokes. Similarly, the ratio of 372 result families to 719 manuscripts does not, by itself, establish inappropriate “salami-slicing”; companion proofs, intermediate results, and alternative arguments may legitimately require separate treatments.")

#text("Second, there is a substantial difference between inadequate quality control and an outright refusal to take responsibility. OpenAI’s public repository records three withdrawals following a sign error, revisions to 14 other manuscripts, and formalizations covering approximately 42% of its top-line results as of October 7. These are not sufficient guarantees of correctness, and the errors are serious. Nevertheless, publicly documenting errors, withdrawing invalid proofs, maintaining revision histories, and providing machine-checkable artifacts are meaningful forms of scientific accountability. The deficiencies should be criticised without pretending these efforts do not exist.")

#text("Third, the independent Advisory Group on Mathematics and Artificial Intelligence explicitly recommended on September 29 that laboratories responsibly release significant results as soon as possible, while assuming responsibility for their subsequent explanation, verification, and integration into mathematical knowledge. On October 6, that same group described the release as an important event for mathematics, while carefully declining to endorse OpenAI’s process. This seems a more defensible position than arguing that the results should simply not have been made public.")

#text("Fourth, the assertion that experts would have discovered comparable results shortly anyway is a counterfactual presented without supporting evidence. The suggestion that these capabilities would be ordinary within two months is likewise a prediction, not an established scientific conclusion. Neither proposition can reasonably be inferred from the quality of the manuscripts.")

#text("Finally, concerns about researchers being scooped, insufficient attribution, and the unequal accessibility of proprietary models are serious and deserve investigation and institutional safeguards. But they should be examined individually, with evidence, rather than used to dismiss an entire body of mathematical work.")

#text("My fundamental objection is that the article conflates three separate questions: whether OpenAI published responsibly, whether its mathematical claims are correct, and whether the demonstrated technological capability is significant. Evidence of failure on the first does not automatically settle the other two.")

#text("We should demand stronger standards of exposition, reproducibility, attribution, and independent verification from OpenAI. But scientific rigour also requires proportionate criticism and intellectual openness toward potentially important discoveries, regardless of whether their source is a human mathematician or an AI system.")

#text("It is entirely possible that October 6 was both a serious failure of scholarly communication and an important milestone in automated mathematical discovery. Those conclusions are not mutually exclusive.")

#text("The appropriate response to imperfectly presented mathematics is rigorous verification and improved scholarly practice, not the assumption that mathematical significance disappears when exposition falls short.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697901")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.")
]

#text("Are you? There’s a tension between the relevance of the result and the clarity of the exposition. I’d much rather see significant results published quickly than have them wait on a hurdle of exposition quality. I suspect this is the view of most people working in the sciences.")

#text("There’s another joke about the talking dog. It’s not what it says that matters. It’s the fact that it talks at all. AI mathematics right now is the proverbial talking dog, telling us which conjectures are true or false. It will get better at explaining itself. In the meantime, there’s plenty of exciting work for us to do understanding the new results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5b649240d302417a380148b12107da5a85613815ec202c593e2726b944aebf-a80d50cbef81ab967ab94ea5a8725585dfb5e7a23c334a10820f954064709172.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dániel Soltész")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697905")[#strong[#text("Dániel Soltész")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("These guest posts are more and more embarrassing as time goes on. People who care the most about the advancement of humanity’s knowledge should be celebrating. Where are all the parties?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Are you seriously complaining about a lack of AI exuberance on blogs and discussion forums?")

#text("AI exuberance before Oct. 6th is what got us into this mess in the first place. Now you hear the other side that has been silent (or censored on other forums).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697908")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("OpenAI published their results on a github repository to avoid flooding the academic venues and piss off even more mathematicians. I think it was the right thing to do, and so many years fundamental scientists have been complaining about the lack of investment by corporations in their fields: well, voilà! Yes, some lack Lean proofs, but when was a Lean proof normally expected in mathematics? As for the “alien mathematics”, a.k.a. “math slop”, I wonder how much has to do with the AI chain of thought, in particular the well-known ability of AIs (not LLMs) to spot non-local correlations (for example between clusters of pixels). I remember the first efficient algorithms to solve the Rubik’s cube, and how “alien” they felt, how the coloured squares would fall into place right at the end. There is nothing wrong with a non-intuitive algorithm or proof, even if an intuitive proof is better for the so-called “human understanding”. But a slow, understandable algorithm is of no use. [Disclaimer: I am a computer scientist trying hard to avoid Schadenfreude, but I really find mathematicians’ current reactions bewildering; I am wondering how much is actually due to a fear of losing status, and how much is due to their philosophical and priestly views being challenged.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698012")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Speaking as a fellow computer scientist: you have no idea what you’re talking about and you’re embarrassing us all. Go talk to someone in your department who works on algorithms, or programming languages, or cryptography, or network theory, or any of the other many areas of computer science that are essentially mathematicians wearing computer science T-shirts. I’ll give you a hint to get you started: what happens to a codebase when new contributors start dropping in 20k-line commits by Claude? And do you think that’s likely to be a *good* thing or a *bad* thing when the codebase is the foundation of human knowledge?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697909")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think an AI slop proof of a theorem is always better than no proof. At least it’s good to know something is true. I agree of course that the other stuff is important as well.")

#text("I must say I find these kinds of criticisms of OpenAI to be a little silly. What, do you want the mathematicians there to not ask the internal model how to solve math problems? If they have the solutions, should they just sit on them? If they do release them, should they take 6 months to clean them up, and so mathematicians spend 6 months working on problems not knowing if an AI has solved their problem? I do think it’s good to work on problems once an AI has solved them, de-slopping it, finding a new proof, finding new directions, digesting the AI techniques and seeing what else is needed, etc. But that would be a really annoying 6 months for us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697911")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think a lot of people are concentrating on the poorly-written aspect of OpenAI but I think it’s clear why they did it. And I think that although this post is accurate, it’s really missing the point. For example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Even without alleging theft, it is a bad look for a supplier of scientific software to actively scoop their customers.")
]

#text("OpenAI is not in the business of providing scientific software to help the progress of science in the same way Maple or Wolfram (Mathematica) is. They’re in the business of mass automation and giving people tools to essentially play the Prisoner’s Dilemma to disrupt the enconomy to eventually bypass human beings in supply chains to getting stuff done and made in the world.")

#text("They don’t care about mathematics. They don’t care about making the world a better place. They care about getting people addicted to a rush of information to subjugate and make us dependent.")

#text("So, releasing these papers, even badly written, has a point: it’s not to further mathematical progress at all. It’s to provide a minimum indicator that “yes, we can do this” so that those willing to jump on the AI bandwagon know that they can start to work at mining results for the ultimate but obscurad sake of collapsing the human mathematical community.")

#text("There can’t be a Math 2.0 in the way that Professor Tao has described here, because there will always be a small subset of people who will use this software simply to get that rush of information and to get ahead. The technology is akin to a device that allows people to kill with thought anonymously; the temptation is too great and these released papers from OpenAI are an indicator that the power is available for anyone who wants to use it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I believe the technology still have so much potential, maybe is just a matter of time for ai to have ways to improve it’s writing, mathematicians will still provide new insights, maybe proving difficult theorems will not be the main objective, but mathematicians still plays an important role in that scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697921")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("My understanding of the situation is perhaps more cynical. Obviously we all agree that this is not for the good of maths and science. Their intention is to have their benchmark out so that humans (mathematicians) will label these new data (say confirming the proof or finding errors), for free in passing, ultimately providing useful feedbacks for their machine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7521ea5254237f951d3c75de979565af312ed2f0284f5b191a11efc11eb33a89-fab56078b3c33e8e1d0b99b9003487893a53be27693d08e011a11d8ed18edd6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashot Tevikyan 1955")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697923")[#strong[#text("Ashot Tevikyan 1955")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Agree. We must not turn science into a mess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697934")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("“If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.”")

#text("When I post an unpolished manuscript to the arxiv, it’s my way of expressing the conjunction of the following statements:")

#enum(start: 1, 
[#text("“This result is correct with a reasonably high degree of certainty, other experts should be capable of filling in the missing details with a reasonably high degree of certainty, and the result is too interesting/helpful to keep it to myself.”")],
[#text("“I’d rather advance my knowledge and the community’s knowledge by working on my next results than by polishing my current manuscript.”")]
)

#text("The above two statements reflect my belief that the pursuit of new knowledge should be prioritized over the clarification of existing results, which is proudly the antithesis of the AHM statement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b7a239469affa1a4b1a2acf2ce3aa78f2d545704d09e87f1fa3c5387858562-d9818fdeb577d9cf5e16963235b3497e0377868f47041ab711b5b995b8e6fb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697942")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("If you what posted on the arXiv is completely unreadable, fewer or no people will read it. You wouldn’t be advancing any knowledge if no one is reading what you are writing.")

#text("The post is *not* arguing for perfection in posting preprints, but basic respect towards the people we expect to read our work")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697935")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The Geometer and the Machine")

#text("* (A Tale, in the Manner of Voltaire)*")

#text("There was once, in a province where men discoursed of nothing but prizes and pensions, a geometer by the name of Master Lemma, who was esteemed the most profound man of his age, for the excellent reason that nobody understood him. He had spent thirty years upon a theorem, and would doubtless have spent thirty more, had not Death, who has never read a single learned memoir, appeared disposed to object.")

#text("Master Lemma was persuaded that this theorem, once demonstrated, would procure him a medal, a professorship in the capital, and a marble bust in the vestibule of the Academy of Landerneau. He was not a vain man, as he himself frequently declared; he merely thought it proper that the universe should take due notice of his existence. He had, moreover, drawn up a testament in which he bequeathed all his rough drafts to Posterity, without having thought it necessary to consult her upon the matter.")

#text("Now it came to pass that an engineer, who knew not a word of geometry, constructed a machine which knew considerably more. The celebrated theorem was presented to it; the machine demonstrated it in the course of a single afternoon, and then inquired, with the greatest civility, whether there was anything further it might do.")

#text("The consternation may readily be imagined. Master Lemma took to his bed for three days. On the fourth he arose to compose a letter to the Gazette, wherein he established that a demonstration, to be valid, must be understood, and that the machine, understanding nothing, had consequently proved nothing at all. It was observed to him that the theorem was none the worse for this circumstance, and that it had never required those who demonstrated it to understand it. Master Lemma replied that it was a question of principle, which is the name men commonly bestow upon their interests when they desire them to pass for virtues.")

#text("His learned brethren assembled. A session was held, resolutions were proposed, and a petition bearing forty-seven signatures was circulated to “express the gravest apprehensions.” There was much discourse concerning the dignity of the human mind, which nobody had ever thought to defend so long as it remained without employment. A young doctor proposed that the machine should be broken to pieces; he was informed that this would amount to confessing that it was right, and that it would be more prudent to content themselves with thinking so.")

#text("Master Lemma, overwhelmed with sorrow, went forth to walk in the country. There he encountered an old gardener, who was digging a flower-bed with an attention which the geometer considered altogether misplaced.")

#text("“Are you aware,” said he, “that a machine has just deprived me of the labour of my whole life?”")

#text("“So I have been told,” replied the gardener. “Has it, then, caused your theorem to grow?”")

#text("“It has demonstrated it.”")

#text("“And is the theorem any more true, or any less true, on that account?”")

#text("“Just as true, naturally.”")

#text("“Then you have lost the glory of having discovered it, but not the truth. That makes, if I reckon rightly, but half a misfortune.”")

#text("The geometer was about to take offence; but he found the argument, proceeding as it did from a man who had never received a classical education, distressingly logical.")

#text("“Sir,” continued the gardener, “I have planted pear-trees these forty years. Never in my life have I received a medal for a pear. I have, however, received pears. And when my neighbour’s son invented a method of grafting by which my trees bore twice as much fruit, I was a little jealous on Monday, and on Tuesday I began to graft.”")

#text("“You would compare pears with theorems!”")

#text("“I compare nothing. I say only that the pleasure of understanding why a thing is as it is does not depend upon who was the first to discover it. Did you love your formulas, or did you love to be loved for your formulas? If the former, you have lost nothing; if the latter, I pity you, but there are remedies less costly than petitions.”")

#text("Master Lemma returned home, considerably displeased at having been contradicted by a gardener, which is, of all defeats, the most instructive. He passed the night examining the demonstration of the machine, which he had hitherto despised without having read. He found it beautiful; he even discovered in it an idea which had never occurred to him, and which he sincerely envied, a sentiment that did him more good than ten years of resentment.")

#text("The following morning he taught the demonstration to his pupils. One of them, a boy of fifteen, asked why the machine had proceeded in this manner rather than in another. Master Lemma did not know. They sought the answer together. This was, according to the master himself, the happiest day of his career, and he received no medal for it.")

#text("The academicians continued to sign petitions, the machine continued to demonstrate theorems, and the world continued to go on much as it had always done. Whenever Master Lemma was asked what he thought of these proceedings, he replied that one ought neither to curse the machine nor to worship it, but rather to persevere in the pursuit of understanding; for that, in the end, was the one thing which no man could accomplish in his stead.")

#text("“Very prettily said,” his listeners would reply, “but is not everything for the best in the best of all possible theorems?”")

#text("“That,” said he, smiling, “I leave to the philosophers. As for me, I cultivate my lemma.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Silicon Valley on music and literature:")

#list(
[#text("2000: The RIAA is evil and exploits artists.")]
)

#list(
[#text("2005-2006: YouTube and Spotify “free the artists” by turning them into sharecroppers.")]
)

#list(
[#text("2023-2026: Authors and artists are evil for demanding credit and compensation for AI training on their works.")]
)

#text("Silicon Valley on software:")

#list(
[#text("1990-2010: Open source is valuable and its authors are heroes.")]
)

#list(
[#text("2010-2023: Open source should be controlled by corporations and its developers are too uppity.")]
)

#list(
[#text("2023-2026: Open source authors are evil for demanding credit and compensation for AI training on their works.")]
)

#text("Silicon Valley on mathematics:")

#list(
[#text("1990-2023: Math is the foundation of CS and mathematicians are heroes.")]
)

#list(
[#text("2023-2025: Please use our tools for a subsidized price and help training the models with your conversations.")]
)

#list(
[#text("2026: Mathematicians are evil for wanting to continue the field with traditional norms and values. Instead, they should volunteer as data labelers for our lengthy slop results or abbreviate them.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697982")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Did you really need to write this wall of text to make the most trivial of points, that knowledge is what holds value and not getting credit for being the first to acquire it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698074")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("The implication of your story presupposes many things, none of which is universally agreed upon.")

#text("Your story presupposes the Platonist view that truths exist independently, and are to be discovered, instead of to be created. As an example of philosophical stances that disagree, intuitionism holds that truths are a result of mental activity.")

#text("Your story also presupposes that math, in particular, geometry theorems, are true. But if being truth is to have a physical sense, then it’s probably not the case. Many evidences in physics suggest the possibility that our world is fundamentally discrete. Therefore, math using continuity could only be a (useful) model, not the truth.")

#text("Your story also presupposes that successfully obtaining truth (or getting pears) is where value lies. But even outside of math, many people would believe that the process of doing some activity, regardless of the outcome, is where value lies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabe9bb69b2ec159e9592360707cbceafd61a94969533d368a80d93374df1c5-b25015830f459ecf585a5686dc8587a834e9443f0c4eff9b0a9240772d34b9a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intruigued")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697938")[#strong[#text("intruigued")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I agree, as a mathematician, on the lack of insight these proofs provide and the sloppy presentation (to put it mildly). Pointing this out is useful and should be done by our community. As a computer scientist, I expect these proofs to improve. I see the progress as a tremendous jump for humanity. I always believed there was great potential to automate mathematical reasoning (I started out my journey in computer science with an interest in automated theorem proving), so the net result is less of a shock, even though I never would have expected this particular route to emerge and be so successful so quickly with such impact. And, yes, the way this has been delivered by companies, lacks respect for the mathematical community’s values and ignores the intricate millennia long maths contributions on which AI is based. I feel this deeply as a mathematician. Honesty and integrity are core in this field and there is a massive clash of cultures and a very uneven power balance and we are presented with tools that absorbed our joint expertise and are commercialised. In the end, I believe society as a whole must and will adjust to this incredible shift. The mathematical community should embrace, or at least seriously evaluate, the potential for the techniques and insights opened up by the availability of AI. I mourn for what we stand to lose, what we have lost already, but I also think it is pointless to blame companies for not understanding our culture, and we need to look for ways forward. The focus should be on AI that benefits maths, and that are locally run, and for mathematicians, if they so wish, to contribute to such AI, in a way the community has always functioned, through joint effort, and with the joint goal of understanding and exploring the mathematical universe. We have many immediate problems to address, aside from this. How do we still recruit? How do we measure expertise? What are the publishing rules (the system was broken in any case, but this has tipped it over the edge). What do we tell our students? These are hard questions. But I think our mathematical community can only benefit if we accept the reality as soon as possible and let young mathematicians who will be quicker to explore these new avenues, help us to find new paths forward. A most difficult problem is the walls that separate the companies from the scientific community. I do not see a quick solution. But I think the mathematical community will benefit the most if we don’t dig in our heels on this and create new modes of operation together.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b7a239469affa1a4b1a2acf2ce3aa78f2d545704d09e87f1fa3c5387858562-d9818fdeb577d9cf5e16963235b3497e0377868f47041ab711b5b995b8e6fb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697941")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I appreciate your thoughtful commend, but I think we need to separate the commentary about AI from commentary about companies like OpenAI. This essay is talking about behavior that is very specific to OpenAI the company, and that is independent of one’s views on AI in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabe9bb69b2ec159e9592360707cbceafd61a94969533d368a80d93374df1c5-b25015830f459ecf585a5686dc8587a834e9443f0c4eff9b0a9240772d34b9a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intruigued")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697952")[#strong[#text("intruigued")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I appreciate this distinction, but good luck picking sides on companies. The major players deserve respect for rapid engineering advances on AI and also, none would have made progress without considering existing work of artists and scientists as a free for all. I think we need to focus as a community on getting tools available to mathematicians that do not absorb our ongoing work, e.g. run locally, but support us in our research. This should be a priority if we want the field to keep thriving. We should aim to extend our ethos and community rules to reflect the current state of progress. This goes for science as a whole. How we deal with what OpenAI has put online is our decision to make as a community, and I agree with several points in the article on peer review and the need for clear exposition. We may need to introduce new classifications for types of research produced in this way. From the company’s point of view, all that mattered was showing they could make it to the finish line, i.e. produce a proof on a known hard problem or a host of them. I think that too much mud is thrown at them for doing just this. Their commercial drive is behind this, i.e. a need to prove what they can achieve with the tech they have developed. They are not communicating to us, but to their investors. We have zero hope of policing OpenAI on that front and I think, aside from the efforts already made by mathematicians to influence their trajectory, we should focus what we can control: the education of young mathematicians, the tools we choose to use in our field, the rules of publishing and so on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b7a239469affa1a4b1a2acf2ce3aa78f2d545704d09e87f1fa3c5387858562-d9818fdeb577d9cf5e16963235b3497e0377868f47041ab711b5b995b8e6fb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697954")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("100% agree with the importance of developing LLM infrastructure to make the math community independent of the large for-profit labs.")

#text("A local LLM running in a server in every campus, is what I say!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697956")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Absolutely. This likely to happen as tools improve. I hope nations will fund efforts towards this")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697947")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The premises of this post is the idea that these openAI papers are badly written, but this does not agree with my experience. Three of the papers lie in my field, and they seem overall clear and straightforward, at least as much as one would expect for a solution to a major problem. I’ve read through one so far and have no major complaints. I’m aware of others in my field reading and understanding the arguments without issue, and even being impressed by the new insights. Yes, the AI writing is often dense and idiosyncratic, but this is not the same as badly written. A human paper would likely be more fleshed out, but probably just as much work to understand. While there are criticisms of AI and the AI companies, let’s at least make sure the discussion is grounded in an accurate assessment of the facts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57bdeb6183f0791f38dc162d32193a9f28e7a7c62b106a43ef71a99c2ff6c15-20975d8f25e1d445ca0a82b43b0e61f242e139dc2db9cc2779d5f92c19980650.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697951")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Because we have checked some earlier proofs of Chat GPT, do we expect most of the 300 or so proofs released recently to be essentially correct/contain the main ideas for a rigurous proof? Or do we have in fact have no idea? Same question concerning the Navier-Stoke proof (one particular case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f4ce497d83f229c4143c71c3962f4ca650d84b1d2aded5e57f9825e1b0cc71c-23846d6be7e1bab4c8c0229e4b60f3e4ed6604602fe38c1a6dfb0a7f08e75e3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pubkeybreaker")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697957")[#strong[#text("pubkeybreaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I had always thought that epsilon is greater than zero. Based on this opinion I guess that I am wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-697971")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("But they have the money, openai and they have the buzzer now. So they can flex muscle regardless of what we lowly mathematicians or theoretical nobody computer scientists think. let alone, they don’t even care about us. We will want to buy us out, silencing us with proposed funding agreements and other things. Remicisent with other companies that tried to mingle and silence us but LLMs passed the test of being equivalent to reasoning ability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5aa8a8b38c6132e360e84bc81a6cd793772627202503b77d6ca5bb2bd605c93-1fc5a6105cb29de1383d400fbb0efca3bfabdc0ae64d4d82e79fbb225cb808f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698024")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("I have been reading the Haldane conjecture proof: the positive lower bound on the spectral gap for even periodic spin 1 Heisenberg AF chains. I think the standard of exposition is middle of the road.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698040")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("I just watched a video explaining the quasi-Riemann hypothesis. It makes the claim of this post look absurd.")

#text("“normal bad work”")

#text("sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698062")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("There’s a difference between the result claimed, and the writeup. A number of people have publicly said the work is written in a style to inexplicably bad that would lead to rejection from a journal or similar. If you are needing to watch a video to understand the quasi-Riemann hypothesis then my guess is that you are not someone that reads that type of mathematics research (this is not a judgement, please understand), and if so it’s understandable that how mathematicians write from the quality of the AI write-up is not distinguishable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698078")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I am not someone who reads that type of pure mathematical research, it’s true.")

#text("But I have done more applied mathematical research in the past, and my undergraduate majors were pure mathematics and mathematical physics, so I understand the quality of the writeups.")

#text("I stand by my claim. “This is normal bad work” is absurd on its face. At the very least, if you want to make the distinction you are making, it is extremely ")#strong[#text("abnormal")]#text(" “bad work”.")

#text("And it’s certainly not “actively set[ting] back the state of the literature”, “all easy rejects”, or “exhaust fumes” to name a few more of the myriad pejoratives used in the original post to describe the results.")

#text("We already have a new 49-page paper explaining how the models got to 11/12. No doubt there will soon be an improved distillation of the steps from there to 7/8.")

#text("If this is “normal bad work” then may we long live in the age of normal bad work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698125")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("“We already have a new 49-page paper explaining how the models got to 11/12.”")

#text("well, this is the good work. And for whatever reason, the amazing truth machine and millions of dollars of compute inside the company wasn’t used to try to even synthesize such a document…. One does wonder why, if, allegedly, each paper only cost a few thousands dollars, a little bit of extra effort was made (they didn’t even run a linter over the lean code to clean up the ridiculous state of it)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698178")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("The supply of confirmation bias always exceeds the demand of conspiracy theories.")

#text("But seriously, have you tried starting from a poorly-written AI paper and turning it into something well-written? It’s nigh-impossible. Better to start from your own writing and let the AI iterate on that.")

#text("OpenAI made a decision to release rather than wait. In my opinion, that was the right decision for humanity as a whole.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698228")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("@twinheterodox")

#text("“But seriously, have you tried starting from a poorly-written AI paper and turning it into something well-written?”")

#text("yes, I have, for things that aren’t going to be published or made public, and I gave up on it. But I don’t have a frontier model, nor a fancy internal model. OpenAI having to admit their models can’t write mathematics properly for trash would be a little embarrassing, yes. So they drop unrefined output instead? Or maybe this *is* the effect of having their internal model trying to write serious mathematics?")

#text("There was no reason that any of this was time sensitive, except perhaps for IPO/corporate reasons. It could have been done slower.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698071")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("I disagree with this opinion. No matter how poor the quality of a paper may be, a mathematical truth remains a truth, and a theorem is a theorem. Those who dislike reading it have the right to ignore it, but no one has the right to suppress its publication.")

#text("If the argument is that publishing low-quality papers is inherently bad, then OpenAI could justify acting as follows: ")#emph[#text("“Alright, we’ve proven hundreds of theorems, including a quasi-Riemann Hypothesis. However, since the papers are of low quality, we won’t publish the proofs. We’ll only release the list of proven propositions along with their document hashes so no one can accuse us of lying later.”")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d76f303244d8d36229f1a5ab30bb23a7cf7564f6bf0ef0ec120b6c8d918f7d38-5249561fb2592063946e7f7ec1cc881bef397f10081fd91c0ca64752c55653d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gaygodel")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698083")[#strong[#text("gaygodel")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("sad 😢")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fe9c0df6ed2538db1971c1bb66175a5b9dcf744fbef814a3d71226ba126e969-3b3668a155a5065da62851f2c61d4dbb05b8ff5f9726408c66123709fda5aa62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of runawaysupernaturally2e0836198d")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698085")[#strong[#text("runawaysupernaturally2e0836198d")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I think the best response mathematicians can make to the Open AI results dump is not to try to validate them. Leave them alone. For two reasons: The first is that AIs are improving so fast that it’s likely that in a few months they will be able to generate more comprehensible proofs – there’s little point wasting time validating the current generation, and secondly, refusing to validate them will strongly encourage the AI companies to try to improving the quality of exposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aec7de4ab460659b68f7dbe91a62dd821bb116c76f32b276f9472521a8139df-3cbe71ac5941e281d1976b202439c39662d39f18ed4a67175f9bfec6f2f599f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Differentiable Person")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698086")[#strong[#text("A Differentiable Person")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Here, those without foundations are brigading while those with knowledge abandon its purpose: understanding phenomena, not producing papers. When verification becomes a surrogate for understanding, or citations become a surrogate for epistemic value, the entire process reverses.")

#text("Verification is a compass, not a destination. It tells us if we’re moving toward truth, not that we’ve arrived there.")

#text("Let us remember: science is a cumulative process of learning verified against reality. A high school student today acquires in three years the skills Newton gained through decades of effort. A hundred years ago, that knowledge was the privilege of the few. This is the value of research: systematizing understanding, transmitting it, democratizing it.")#linebreak()#text("It is an ongoing process of understanding, practices, and collective memory. The public language (of any kind, natural or formal) in which it is represented is merely the currency with which it is exchanged, not the substance.")

#text("Scientists are at the forefront of an understanding that will one day become obvious, just as a derivative is obvious to a student today but was not in Newton’s time")

#text("The damage is structural: the incompetent have lost humility, the competent have lost purpose.")#linebreak()#text("Each generation builds on verified understanding, not on citation counts. When a system built to maximize textual output at scale takes over the logic of ‘publish or perish,’ the pathology accelerates. The system was already geared towards metric optimization; now it has simply become too obvious to ignore. Our responsibility is to the phenomenon itself, to preserving the integrity of that cumulative inheritance, not towards metrics.")#linebreak()#text("Without “investigators” trained to think autonomously, to verify against reality, to understand rather than believe, we forfeit the only defense against narratives designed to control us.")#linebreak()#text("Scientific literacy is not an academic luxury: it is a democratic necessity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5a3ff361e5fe80a92b904b333fd56c24049146aa89cb2fe3f091a3e479bb3c6-3c229da9e4720c2e10b73553f1ceff2d960dbe9fc875ad6e195396ceac5635d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hassan Sedaghat")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/comment-page-1/#comment-698272")[#strong[#text("Hassan Sedaghat")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("People seem to forget that Ramanujan had great difficulty proving his own amazing results even though the vast majority of them were correct. As a mathematician who has spent decades doing research and publishing, I find it refreshing that now the AI can help speed up my work, not only by performing calculations in support (or refutation) of conjectures but also writing the code (like Python) to do the numerical work. Further, to also prove a bunch of little lemmas that I think ‘have got to be correct’ so that I can be confident that my main results are valid (of course, I would need to be prepared that the main results may be proven by the AI too). The AI can do some type of math beyond calculation very well, but I am confident that most of math lies beyond the reach of even the most advanced frontier AI, including some Erdos problems, some of the Millenium problems, and thorny computational mazes like the Collatz problem.")
]
