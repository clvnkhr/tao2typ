// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/
// Converted to Typst by tao2typ: "2026-10-14T15:21:28.289415+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "This is normal bad work", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("This is normal bad work")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/")[#text("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sophie.huiberts.me/")[#text("Sophie Huiberts")]#text(", being an expanded version of a post on ")#link("https://sophie.huiberts.me/blog/2026/community/")[#text("her own blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When you prove a theorem, you are imparted a responsibility to the field of mathematics. At minimum you need to explain what you did, including which steps required new ideas and which steps are already well-known. More substantively, you are expected to nurture the literature. If an important idea was poorly explained in its first incarnation, then you have a duty to explain it better in your work. The responsibility is yours because you have the opportunity to publish a paper on the subject.")

#metadata(none) <tao-6c4d87e7a6fe966c43fd>

#text("These demands are broadly accepted and are neither new nor controversial. Any time you exceed the demands, the resulting paper is highly appreciated and valued. Any time you fail the demands, you will get a “revise and resubmit” for a journal submission, or a straight rejection for a conference. Until you fix your exposition, your ideas will not enter the canon. If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.")

#text("Compare this to OpenAI’s behavior. They do not care about their “preprints”. They don’t bother putting in appropriate attribution of ideas, they salami-slice 372 results over 719 pdfs, their work ")#link("https://bsky.app/profile/curiouscoding.nl/post/3mxeerfpahk2u")[#text("contains retraction-worthy errors")]#text(", they ")#link("https://bsky.app/profile/dulwichquantum.bsky.social/post/3mxlpp3tuv226")[#text("promise code but neglect to include it")]#text(", and their proofs are fiendishly hard to parse. Their pdfs actively set back the state of the literature. This is poor quality work and these pdfs are all easy rejects.")

#text("We all know that OpenAI is not doing this “for the good of science”. These pdfs are ")#link("https://bsky.app/profile/pwnallthethings.bsky.social/post/3mxb67hhd7k2h")[#text("exhaust fumes")]#text(" from their internal benchmarking effort. We do not need them to release this unprocessed exhaust into the atmosphere. OpenAI’s new internal model may have produced these texts with the press of a button. But similar results would have been found soon by experts, with or without LLM prompting. Some results ")#link("https://curticapean.net/math-notes/")[#text("were already found by ChatGPT users")]#text(" and were in the process of being written up properly. Even without alleging theft, it is a bad look for a supplier of scientific software to actively scoop their customers.")

#text("If an expert prompts a result, they take up the mantle of responsibility I describe above. OpenAI not only refuses to take their responsibility, but they prevent their own customers from doing so.")

#text("October 6th was not a watershed moment for mathematics. OpenAI’s droppings on GitHub are normal progress: normal for the current state of technology. Or at least normal for the available technology in 2 months from now. The only thing that is exceptional is OpenAI’s lack of shame for releasing poor quality work.")

#heading(level: 1)[#text("Comments (38)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697862")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("This post reminds me of a joke about a talking dog. The man selling the dog only sells him for $50. The prospective buyer asks “why so cheap? I would think you could get a lot more for a talking dog.” The dog’s owner responds “the dog is so cheap, because he is a liar.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("I’m too stupid to get what you’re trying to say?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("When you prove a theorem, you owe nothing to mathematics. It is your theorem. You can hide it under your bed, keep it in your head, share it with your friend, or try to publish. Only in the last case can we require anything of the prover.")

#text("OpenAI does not consist of mathematicians. They make computer programs. These programs happen to be rather helpful to many of us, when trying to prove things. Further, unlike many results of the past, we now have a convenient way to check, often quite quickly, whether their ideas have merit (via Lean proofs). OpenAI itself does not try to publish very much. They did make available the results of their work, after a plurality of mathematicians asked them for it. It was somewhat rushed because, again, we asked them to do it as soon as possible.")

#text("I expect that as time goes on, these very new tools will also get good at writing up their results. But they have no obligation to do so. And we, if we don’t want to use them, don’t have to. I personally find them quite useful. They have answered multiple questions I’ve thought about for years. While their write-ups are not (yet!) great, I’ve enjoyed working through the ideas, and figuring them out in my own way.")

#text("So, I guess I’d offer this You don’t have to accept their results as canon, and they are not asking you too. You are welcome to leave it to others to write up the results in a more comprehensible manner, do it yourself, or wait for the LLMs to get better at it. Your choice.")

#text("(And I’m sorry, October 6th was a watershed moment. If you can’t see that, you don’t know how many people wasted months and years of their lives just trying to understand Mochizuki’s ABC papers.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af8189c29401e7395ae33c483346a3d31106272eaecea74a304b3dc2819ac687-ab4d3ccfc26ae24d32601c00cd93f25276ff134de661017c830fb04e1d19ac26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of In Favor of Good Behavior")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697870")[#strong[#text("In Favor of Good Behavior")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Sometimes person A tries to have a conversation about morals and values, in an attempt to answer questions like “is this behavior good?,” “how should we behave in general?”, “what should we do in response to this behavior?”, etc.")

#text("Then person B replies by making descriptive declarations that essentially amount to “these people do not have to behave well.”")

#text("What you’re saying is true… but not useful or interesting. Your assertion as written appears to be that employees at Open AI don’t have an obligation to behave morally. That’s fine to share as your opinion, but everyone else can still judge them for behaving badly, and encourage them to choose a moral option!")

#text("More broadly, it seems like your comment is a generic argument against anyone ever helping others, or attempting to mitigate harm. Such reasoning seems silly and destructive, and I hope others in our community opt not to behave and argue as you have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("There is no practice of “good behavior” for such a kind of situation because no single mathematician or group of mathematicians or institutions had ever before obtained such an amount of new results of such relevant level in such a short time. It’s just useless to keep pointing out how journals accept/reject/revise papers, how things were done in the “normal” time. This is not normal at all (if the writer alludes to Kuhn, this is a revolution, quite the opposite of normal math!).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("We know that Silicon Valley people are amoral and nihilists and you argue their (lack of) values.")

#text("Are you sure you want to go that route? What if we, in the best Silicon Valley tradition, flip the argument?")

#text("“The general public owes nothing to OpenAI. You can use it or not. Property rules are a social construct, so the people decide that OpenAI is national property. Nationalization will be carried out without compensation, since OpenAI was supposed to be a corporation in the public benefit anyway before it was illegally converted to a partially private one. Everyone whose IP was used for training will be compensated by the state.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697930")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Nope. To the extent that it’s true that mathematicians “asked” OpenAI to release the results, what OpenAI ended up doing was more like malicious compliance or at least culpably negligent compliance. You might want to reread the AGMAI recommendations about this.")

#text("If there’s one lesson that should be taken from this episode, it’s that we really need to be holding publicly posted work to ")#strong[#text("much")]#text(" higher standards. Farting out purported proofs is not doing mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea7fe065205b2120c9d4f46ba71cb03d44ff60922c92b237f6039150e65e7acf-a893e0f35ad6c4f03399068bdd6e044fc7c7a539813fbc0785a9af3bfcc65d44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hume")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697965")[#strong[#text("Hume")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The thing is many of these additional responsibilities (go to seminar, journal submission, etc.) belong to “paid” academics. A hobbyist doesn’t get paid so we cannot impose on them the teaching/research/service expectations of typical academics. So, if the hobbyist post the result on their Facebook or X, the most we can do is click Like and congratulate them. If they kindly write up and post on Arxiv we should be extra thankful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("In most of the countries in the world, except for a handful, academics who do such work are poorly paid. Most and for all, we should be thankful to those with professional training and low salaries to do those jobs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("“OpenAI’s droppings on GitHub are normal progress: normal for the current state of technology. Or at least normal for the available technology in 2 months from now.”")

#text("What is the claim here…?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697940")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The claim, as I understand it, is that OpenAI knows that this batch of problems is not really surprising by the standards of what many LLMs are capable of today.")

#text("There are many other results (for example, in my area of PDE) that have been found in the output of LLMs in the last month or so by people using various commercial (closed and open weights) models.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("“If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.”")

#text("I think it is embarrassing to compare some random badly written arxiv paper to 372 results produced by an automatic machine that dramatically improve the best known results in a number of fields (“annihilating” the entire research field of some Fields Medalist!). ")#linebreak()#text("“Normal Bad Work”?! Come on, there is a quasi-Riemann hypothesis!")

#text("With all due respect I wonder why this blog post landed in this page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The real concern that mathematicians seem to be is that the subject will die out and will be reduced to a hobby. That’s a valid concern, but ultimately that’s not especially important in the long run. In the history of mankind, many things come and go, whether that is for the best or worst is not something which can be decided at this point. Loss of the merits of manual labour was lamented by many in the past, but that’s just the way it is. One should accept the change, or one might just lose their dignity as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697955")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("If it were only mathematics, then yes, we would easily absorb the loss. Alas what is affected is INTELLIGENCE, not just mathematics. It’s kinda tricky to figure out what remains when manual AND mental are taken away")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a67b80df60444832128eaa8ddbb8c90ad4c59f0818d7384a32b7a18920da5140-6295882a181d680e67b5f82b6a3edb8faac672539829928b9d7cb26c03331267.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arham Zahid")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697899")[#strong[#text("Arham Zahid")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I agree with the central principle that publishing mathematics carries responsibilities of correctness, attribution, exposition, and intellectual stewardship. OpenAI should be held to those standards. However, I think this article makes several sweeping claims that are not justified by the evidence, and in doing so risks undermining an otherwise legitimate criticism.")

#text("First, poor exposition is not evidence of mathematical insignificance. A manuscript can be unsuitable for journal publication while containing a genuinely important theorem or technique. Describing all 719 manuscripts as “easy rejects” without a systematic, individual assessment seems inconsistent with the very standards of scholarly rigour the article invokes. Similarly, the ratio of 372 result families to 719 manuscripts does not, by itself, establish inappropriate “salami-slicing”; companion proofs, intermediate results, and alternative arguments may legitimately require separate treatments.")

#text("Second, there is a substantial difference between inadequate quality control and an outright refusal to take responsibility. OpenAI’s public repository records three withdrawals following a sign error, revisions to 14 other manuscripts, and formalizations covering approximately 42% of its top-line results as of October 7. These are not sufficient guarantees of correctness, and the errors are serious. Nevertheless, publicly documenting errors, withdrawing invalid proofs, maintaining revision histories, and providing machine-checkable artifacts are meaningful forms of scientific accountability. The deficiencies should be criticised without pretending these efforts do not exist.")

#text("Third, the independent Advisory Group on Mathematics and Artificial Intelligence explicitly recommended on September 29 that laboratories responsibly release significant results as soon as possible, while assuming responsibility for their subsequent explanation, verification, and integration into mathematical knowledge. On October 6, that same group described the release as an important event for mathematics, while carefully declining to endorse OpenAI’s process. This seems a more defensible position than arguing that the results should simply not have been made public.")

#text("Fourth, the assertion that experts would have discovered comparable results shortly anyway is a counterfactual presented without supporting evidence. The suggestion that these capabilities would be ordinary within two months is likewise a prediction, not an established scientific conclusion. Neither proposition can reasonably be inferred from the quality of the manuscripts.")

#text("Finally, concerns about researchers being scooped, insufficient attribution, and the unequal accessibility of proprietary models are serious and deserve investigation and institutional safeguards. But they should be examined individually, with evidence, rather than used to dismiss an entire body of mathematical work.")

#text("My fundamental objection is that the article conflates three separate questions: whether OpenAI published responsibly, whether its mathematical claims are correct, and whether the demonstrated technological capability is significant. Evidence of failure on the first does not automatically settle the other two.")

#text("We should demand stronger standards of exposition, reproducibility, attribution, and independent verification from OpenAI. But scientific rigour also requires proportionate criticism and intellectual openness toward potentially important discoveries, regardless of whether their source is a human mathematician or an AI system.")

#text("It is entirely possible that October 6 was both a serious failure of scholarly communication and an important milestone in automated mathematical discovery. Those conclusions are not mutually exclusive.")

#text("The appropriate response to imperfectly presented mathematics is rigorous verification and improved scholarly practice, not the assumption that mathematical significance disappears when exposition falls short.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697901")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.")
]

#text("Are you? There’s a tension between the relevance of the result and the clarity of the exposition. I’d much rather see significant results published quickly than have them wait on a hurdle of exposition quality. I suspect this is the view of most people working in the sciences.")

#text("There’s another joke about the talking dog. It’s not what it says that matters. It’s the fact that it talks at all. AI mathematics right now is the proverbial talking dog, telling us which conjectures are true or false. It will get better at explaining itself. In the meantime, there’s plenty of exciting work for us to do understanding the new results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c0fdc97575138a4c8252f4c53df5a6facee508a6ac969c5e3d7bf5b04d67428-1d78821ddbbfd66506956011ab24e1af37fe8087a475020e6732784b027c5aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dániel Soltész")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697905")[#strong[#text("Dániel Soltész")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("These guest posts are more and more embarrassing as time goes on. People who care the most about the advancement of humanity’s knowledge should be celebrating. Where are all the parties?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Are you seriously complaining about a lack of AI exuberance on blogs and discussion forums?")

#text("AI exuberance before Oct. 6th is what got us into this mess in the first place. Now you hear the other side that has been silent (or censored on other forums).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("OpenAI published their results on a github repository to avoid flooding the academic venues and piss off even more mathematicians. I think it was the right thing to do, and so many years fundamental scientists have been complaining about the lack of investment by corporations in their fields: well, voilà! Yes, some lack Lean proofs, but when was a Lean proof normally expected in mathematics? As for the “alien mathematics”, a.k.a. “math slop”, I wonder how much has to do with the AI chain of thought, in particular the well-known ability of AIs (not LLMs) to spot non-local correlations (for example between clusters of pixels). I remember the first efficient algorithms to solve the Rubik’s cube, and how “alien” they felt, how the coloured squares would fall into place right at the end. There is nothing wrong with a non-intuitive algorithm or proof, even if an intuitive proof is better for the so-called “human understanding”. But a slow, understandable algorithm is of no use. [Disclaimer: I am a computer scientist trying hard to avoid Schadenfreude, but I really find mathematicians’ current reactions bewildering; I am wondering how much is actually due to a fear of losing status, and how much is due to their philosophical and priestly views being challenged.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697909")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think an AI slop proof of a theorem is always better than no proof. At least it’s good to know something is true. I agree of course that the other stuff is important as well.")

#text("I must say I find these kinds of criticisms of OpenAI to be a little silly. What, do you want the mathematicians there to not ask the internal model how to solve math problems? If they have the solutions, should they just sit on them? If they do release them, should they take 6 months to clean them up, and so mathematicians spend 6 months working on problems not knowing if an AI has solved their problem? I do think it’s good to work on problems once an AI has solved them, de-slopping it, finding a new proof, finding new directions, digesting the AI techniques and seeing what else is needed, etc. But that would be a really annoying 6 months for us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697911")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think a lot of people are concentrating on the poorly-written aspect of OpenAI but I think it’s clear why they did it. And I think that although this post is accurate, it’s really missing the point. For example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Even without alleging theft, it is a bad look for a supplier of scientific software to actively scoop their customers.")
]

#text("OpenAI is not in the business of providing scientific software to help the progress of science in the same way Maple or Wolfram (Mathematica) is. They’re in the business of mass automation and giving people tools to essentially play the Prisoner’s Dilemma to disrupt the enconomy to eventually bypass human beings in supply chains to getting stuff done and made in the world.")

#text("They don’t care about mathematics. They don’t care about making the world a better place. They care about getting people addicted to a rush of information to subjugate and make us dependent.")

#text("So, releasing these papers, even badly written, has a point: it’s not to further mathematical progress at all. It’s to provide a minimum indicator that “yes, we can do this” so that those willing to jump on the AI bandwagon know that they can start to work at mining results for the ultimate but obscurad sake of collapsing the human mathematical community.")

#text("There can’t be a Math 2.0 in the way that Professor Tao has described here, because there will always be a small subset of people who will use this software simply to get that rush of information and to get ahead. The technology is akin to a device that allows people to kill with thought anonymously; the temptation is too great and these released papers from OpenAI are an indicator that the power is available for anyone who wants to use it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I believe the technology still have so much potential, maybe is just a matter of time for ai to have ways to improve it’s writing, mathematicians will still provide new insights, maybe proving difficult theorems will not be the main objective, but mathematicians still plays an important role in that scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("My understanding of the situation is perhaps more cynical. Obviously we all agree that this is not for the good of maths and science. Their intention is to have their benchmark out so that humans (mathematicians) will label these new data (say confirming the proof or finding errors), for free in passing, ultimately providing useful feedbacks for their machine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cfb52009fbb600752d2e6bbc58a89a3d6b7e9b3efb811c34ceb740c7bfb0334d-4f4d4879ad1f1c32620ac1763bc74225a06f39fb89de6e7bfd7174a9e03022a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashot Tevikyan 1955")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697923")[#strong[#text("Ashot Tevikyan 1955")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Agree. We must not turn science into a mess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("“If you post unpolished manuscripts to the arXiv, you are embarrassing yourself.”")

#text("When I post an unpolished manuscript to the arxiv, it’s my way of expressing the conjunction of the following statements:")

#enum(start: 1, 
[#text("“This result is correct with a reasonably high degree of certainty, other experts should be capable of filling in the missing details with a reasonably high degree of certainty, and the result is too interesting/helpful to keep it to myself.”")],
[#text("“I’d rather advance my knowledge and the community’s knowledge by working on my next results than by polishing my current manuscript.”")]
)

#text("The above two statements reflect my belief that the pursuit of new knowledge should be prioritized over the clarification of existing results, which is proudly the antithesis of the AHM statement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697942")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("If you what posted on the arXiv is completely unreadable, fewer or no people will read it. You wouldn’t be advancing any knowledge if no one is reading what you are writing.")

#text("The post is *not* arguing for perfection in posting preprints, but basic respect towards the people we expect to read our work")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The Geometer and the Machine")

#text("* (A Tale, in the Manner of Voltaire)*")

#text("There was once, in a province where men discoursed of nothing but prizes and pensions, a geometer by the name of Master Lemma, who was esteemed the most profound man of his age, for the excellent reason that nobody understood him. He had spent thirty years upon a theorem, and would doubtless have spent thirty more, had not Death, who has never read a single learned memoir, appeared disposed to object.")

#text("Master Lemma was persuaded that this theorem, once demonstrated, would procure him a medal, a professorship in the capital, and a marble bust in the vestibule of the Academy of Landerneau. He was not a vain man, as he himself frequently declared; he merely thought it proper that the universe should take due notice of his existence. He had, moreover, drawn up a testament in which he bequeathed all his rough drafts to Posterity, without having thought it necessary to consult her upon the matter.")

#text("Now it came to pass that an engineer, who knew not a word of geometry, constructed a machine which knew considerably more. The celebrated theorem was presented to it; the machine demonstrated it in the course of a single afternoon, and then inquired, with the greatest civility, whether there was anything further it might do.")

#text("The consternation may readily be imagined. Master Lemma took to his bed for three days. On the fourth he arose to compose a letter to the Gazette, wherein he established that a demonstration, to be valid, must be understood, and that the machine, understanding nothing, had consequently proved nothing at all. It was observed to him that the theorem was none the worse for this circumstance, and that it had never required those who demonstrated it to understand it. Master Lemma replied that it was a question of principle, which is the name men commonly bestow upon their interests when they desire them to pass for virtues.")

#text("His learned brethren assembled. A session was held, resolutions were proposed, and a petition bearing forty-seven signatures was circulated to “express the gravest apprehensions.” There was much discourse concerning the dignity of the human mind, which nobody had ever thought to defend so long as it remained without employment. A young doctor proposed that the machine should be broken to pieces; he was informed that this would amount to confessing that it was right, and that it would be more prudent to content themselves with thinking so.")

#text("Master Lemma, overwhelmed with sorrow, went forth to walk in the country. There he encountered an old gardener, who was digging a flower-bed with an attention which the geometer considered altogether misplaced.")

#text("“Are you aware,” said he, “that a machine has just deprived me of the labour of my whole life?”")

#text("“So I have been told,” replied the gardener. “Has it, then, caused your theorem to grow?”")

#text("“It has demonstrated it.”")

#text("“And is the theorem any more true, or any less true, on that account?”")

#text("“Just as true, naturally.”")

#text("“Then you have lost the glory of having discovered it, but not the truth. That makes, if I reckon rightly, but half a misfortune.”")

#text("The geometer was about to take offence; but he found the argument, proceeding as it did from a man who had never received a classical education, distressingly logical.")

#text("“Sir,” continued the gardener, “I have planted pear-trees these forty years. Never in my life have I received a medal for a pear. I have, however, received pears. And when my neighbour’s son invented a method of grafting by which my trees bore twice as much fruit, I was a little jealous on Monday, and on Tuesday I began to graft.”")

#text("“You would compare pears with theorems!”")

#text("“I compare nothing. I say only that the pleasure of understanding why a thing is as it is does not depend upon who was the first to discover it. Did you love your formulas, or did you love to be loved for your formulas? If the former, you have lost nothing; if the latter, I pity you, but there are remedies less costly than petitions.”")

#text("Master Lemma returned home, considerably displeased at having been contradicted by a gardener, which is, of all defeats, the most instructive. He passed the night examining the demonstration of the machine, which he had hitherto despised without having read. He found it beautiful; he even discovered in it an idea which had never occurred to him, and which he sincerely envied, a sentiment that did him more good than ten years of resentment.")

#text("The following morning he taught the demonstration to his pupils. One of them, a boy of fifteen, asked why the machine had proceeded in this manner rather than in another. Master Lemma did not know. They sought the answer together. This was, according to the master himself, the happiest day of his career, and he received no medal for it.")

#text("The academicians continued to sign petitions, the machine continued to demonstrate theorems, and the world continued to go on much as it had always done. Whenever Master Lemma was asked what he thought of these proceedings, he replied that one ought neither to curse the machine nor to worship it, but rather to persevere in the pursuit of understanding; for that, in the end, was the one thing which no man could accomplish in his stead.")

#text("“Very prettily said,” his listeners would reply, “but is not everything for the best in the best of all possible theorems?”")

#text("“That,” said he, smiling, “I leave to the philosophers. As for me, I cultivate my lemma.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Silicon Valley on music and literature:")

#list(
[#text("2000: The RIAA is evil and exploits artists.")]
)

#list(
[#text("2005-2006: YouTube and Spotify “free the artists” by turning them into sharecroppers.")]
)

#list(
[#text("2023-2026: Authors and artists are evil for demanding credit and compensation for AI training on their works.")]
)

#text("Silicon Valley on software:")

#list(
[#text("1990-2010: Open source is valuable and its authors are heroes.")]
)

#list(
[#text("2010-2023: Open source should be controlled by corporations and its developers are too uppity.")]
)

#list(
[#text("2023-2026: Open source authors are evil for demanding credit and compensation for AI training on their works.")]
)

#text("Silicon Valley on mathematics:")

#list(
[#text("1990-2023: Math is the foundation of CS and mathematicians are heroes.")]
)

#list(
[#text("2023-2025: Please use our tools for a subsidized price and help training the models with your conversations.")]
)

#list(
[#text("2026: Mathematicians are evil for wanting to continue the field with traditional norms and values. Instead, they should volunteer as data labelers for our lengthy slop results or abbreviate them.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Did you really need to write this wall of text to make the most trivial of points, that knowledge is what holds value and not getting credit for being the first to acquire it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/338736fac548406cd729f7a90f220d2223f212b1d725fd8bee6ed7d415b83576-e0c108d8d8dcdd24c63172abfce0c3dbcec4b3069428ec72500a01cb95b780a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intruigued")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697938")[#strong[#text("intruigued")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I agree, as a mathematician, on the lack of insight these proofs provide and the sloppy presentation (to put it mildly). Pointing this out is useful and should be done by our community. As a computer scientist, I expect these proofs to improve. I see the progress as a tremendous jump for humanity. I always believed there was great potential to automate mathematical reasoning (I started out my journey in computer science with an interest in automated theorem proving), so the net result is less of a shock, even though I never would have expected this particular route to emerge and be so successful so quickly with such impact. And, yes, the way this has been delivered by companies, lacks respect for the mathematical community’s values and ignores the intricate millennia long maths contributions on which AI is based. I feel this deeply as a mathematician. Honesty and integrity are core in this field and there is a massive clash of cultures and a very uneven power balance and we are presented with tools that absorbed our joint expertise and are commercialised. In the end, I believe society as a whole must and will adjust to this incredible shift. The mathematical community should embrace, or at least seriously evaluate, the potential for the techniques and insights opened up by the availability of AI. I mourn for what we stand to lose, what we have lost already, but I also think it is pointless to blame companies for not understanding our culture, and we need to look for ways forward. The focus should be on AI that benefits maths, and that are locally run, and for mathematicians, if they so wish, to contribute to such AI, in a way the community has always functioned, through joint effort, and with the joint goal of understanding and exploring the mathematical universe. We have many immediate problems to address, aside from this. How do we still recruit? How do we measure expertise? What are the publishing rules (the system was broken in any case, but this has tipped it over the edge). What do we tell our students? These are hard questions. But I think our mathematical community can only benefit if we accept the reality as soon as possible and let young mathematicians who will be quicker to explore these new avenues, help us to find new paths forward. A most difficult problem is the walls that separate the companies from the scientific community. I do not see a quick solution. But I think the mathematical community will benefit the most if we don’t dig in our heels on this and create new modes of operation together.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697941")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I appreciate your thoughtful commend, but I think we need to separate the commentary about AI from commentary about companies like OpenAI. This essay is talking about behavior that is very specific to OpenAI the company, and that is independent of one’s views on AI in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/338736fac548406cd729f7a90f220d2223f212b1d725fd8bee6ed7d415b83576-e0c108d8d8dcdd24c63172abfce0c3dbcec4b3069428ec72500a01cb95b780a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intruigued")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697952")[#strong[#text("intruigued")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I appreciate this distinction, but good luck picking sides on companies. The major players deserve respect for rapid engineering advances on AI and also, none would have made progress without considering existing work of artists and scientists as a free for all. I think we need to focus as a community on getting tools available to mathematicians that do not absorb our ongoing work, e.g. run locally, but support us in our research. This should be a priority if we want the field to keep thriving. We should aim to extend our ethos and community rules to reflect the current state of progress. This goes for science as a whole. How we deal with what OpenAI has put online is our decision to make as a community, and I agree with several points in the article on peer review and the need for clear exposition. We may need to introduce new classifications for types of research produced in this way. From the company’s point of view, all that mattered was showing they could make it to the finish line, i.e. produce a proof on a known hard problem or a host of them. I think that too much mud is thrown at them for doing just this. Their commercial drive is behind this, i.e. a need to prove what they can achieve with the tech they have developed. They are not communicating to us, but to their investors. We have zero hope of policing OpenAI on that front and I think, aside from the efforts already made by mathematicians to influence their trajectory, we should focus what we can control: the education of young mathematicians, the tools we choose to use in our field, the rules of publishing and so on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697954")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("100% agree with the importance of developing LLM infrastructure to make the math community independent of the large for-profit labs.")

#text("A local LLM running in a server in every campus, is what I say!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Absolutely. This likely to happen as tools improve. I hope nations will fund efforts towards this")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("The premises of this post is the idea that these openAI papers are badly written, but this does not agree with my experience. Three of the papers lie in my field, and they seem overall clear and straightforward, at least as much as one would expect for a solution to a major problem. I’ve read through one so far and have no major complaints. I’m aware of others in my field reading and understanding the arguments without issue, and even being impressed by the new insights. Yes, the AI writing is often dense and idiosyncratic, but this is not the same as badly written. A human paper would likely be more fleshed out, but probably just as much work to understand. While there are criticisms of AI and the AI companies, let’s at least make sure the discussion is grounded in an accurate assessment of the facts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38b8a7b6703075d6f8dc6dda3537c685c0d505c571efaade21d67f32fa9dc8ba-3cd74665a89149a463ba33e567a60344e60fad0efc2f402d071f5ee7a44c41df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697951")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Because we have checked some earlier proofs of Chat GPT, do we expect most of the 300 or so proofs released recently to be essentially correct/contain the main ideas for a rigurous proof? Or do we have in fact have no idea? Same question concerning the Navier-Stoke proof (one particular case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pubkeybreaker")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697957")[#strong[#text("pubkeybreaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I had always thought that epsilon is greater than zero. Based on this opinion I guess that I am wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/this-is-normal-bad-work/#comment-697971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("But they have the money, openai and they have the buzzer now. So they can flex muscle regardless of what we lowly mathematicians or theoretical nobody computer scientists think. let alone, they don’t even care about us. We will want to buy us out, silencing us with proposed funding agreements and other things. Remicisent with other companies that tried to mingle and silence us but LLMs passed the test of being equivalent to reasoning ability.")
]
