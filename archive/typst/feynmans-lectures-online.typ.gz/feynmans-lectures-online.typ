// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/
// Converted to Typst by tao2typ: "2026-10-14T16:35:48.584162+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Feynman’s lectures online", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Feynman’s lectures online")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/")[#text("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Seven videotaped lectures from 1964 by ")#link("http://en.wikipedia.org/wiki/Richard_Feynman")[#text("Richard Feynman")]#text(" given in Cornell, on “")#link("http://en.wikipedia.org/wiki/The_Character_of_Physical_Law")[#text("The Character of Physical Law")]#text("“, have ")#link("http://research.microsoft.com/tuva")[#text("recently been put online")]#text(" (by ")#link("http://research.microsoft.com/en-us/")[#text("Microsoft Research")]#text(", through the purchase of these lectures from the Feynman estate by Bill Gates, as ")#link("http://news.cnet.com/8301-13860_3-10286732-56.html")[#text("described in this interview with Gates")]#text("), with a number of multimedia enhancements (external links, subtitles, etc.). These lectures, intended for a general audience, broadly cover the same type of material that is in his famous ")#link("http://en.wikipedia.org/wiki/The_Feynman_Lectures_on_Physics")[#text("lectures on physics")]#text(".")

#text("I have just finished the first lecture, describing the history and impact of the law of gravitation as a model example of a physical law; I had of course known of Feynman’s reputation as an outstandingly clear, passionate, and entertaining lecturer, but it is quite something else to see that lecturing style directly. The lectures are each about an hour long, but I recommend setting aside the time to view at least one of them, both for the substance of the lecture and for the presentation. His introduction to the first lecture is surprisingly poetic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The artists of the Renaissance said that man’s main concern should be for man.")

#text("And yet, there are some other things of interest in this world: even the artist appreciates sunsets, and ocean waves, and the march of the stars across the heavens.")

#text("And there is some reason, then, to talk of other things sometimes.")

#text("As we look into these things, we get an aesthetic pleasure directly on observation, but there’s also a rhythm and pattern between the phenomena of nature, which isn’t apparent to the eye, but only to the eye of analysis.")

#text("And it’s these rhythms and patterns that we call physical laws.")

#text("What I want to talk about in this series of lectures is the general characteristics of these physical laws. …")
]

#text("The talk then shifts to the very concrete and specific topic of gravitation, though, as can be seen in this portion of the video:")

#text("Coincidentally, I covered some of the material in Feynman’s first lecture in my ")#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/")[#text("own talk on the cosmic distance ladder")]#text(", though I was approaching the topic from a rather different angle, and with a less elegant presentation.")

#text("[")#link("http://tierneylab.blogs.nytimes.com/2009/07/15/gates-puts-feynman-lectures-online")[#emph[#text("Via the New York Times")]]#text(". Note that some browsers may need a ")#link("http://www.microsoft.com/silverlight/default.aspx")[#text("Silverlight extension")]#text(" in order to view the videos. Youtube versions of three of the seven lectures are ")#link("http://www.youtube.com/results?search_type=search_playlists&search_query=1964+Messenger+Lecture&uni=1")[#text("available here")]#text(". Another, much more recent, series of videotaped lectures of Feynman is ")#link("http://www.vega.org.uk/video/subseries/8")[#text("available here")]#text(".]")

#text("[")#emph[#text("Update")]#text(", July 15: Of particular interest to mathematicians is his second lecture “The relation of mathematics and physics”. He draws several important contrasts between the reasoning of physics and the axiomatic reasoning of formal, settled mathematics, of the type found in textbooks; but it is quite striking to me that the reasoning of ")#emph[#text("unsettled")]#text(" mathematics – recent fields in which the precise axioms and theoretical framework has not yet been fully formalised and standardised – matches Feynman’s description of physical reasoning in many ways. I suspect that Feynman’s impressions of mathematics as performed by mathematicians in 1964 may differ a little from the way mathematics is performed today.]")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/067411199bf2aebfa0906c36307a106e70570a266a116a471348293415fd9d4f-f1615e6a92554c717e965fab86307461b3ed3404db7c53b4e7d2a7d2fc90ad81.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drazick")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40062")[#strong[#text("Drazick")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("Too bad Microsoft requires Silverlight for it.")#linebreak()#text(" I wish they used the Video Tag :-).")

#text("Thanks for the info…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53cce0bcb393e92d56d7e0b5934a3639bd00021d1fc8eadf75c0b5c88cc8a8fb-8397ad1dba6fa09f6473de0abb800233ddbbf7749809d3d2bfc707f6aaec92ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40064")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("Too bad Microsoft doesn’t have the capacity and bandwidth to serve these lectures in a manner that would allow watching them without stalling every 5 seconds and without Silverlight hogging the CPU….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thuris")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40065")[#strong[#text("Thuris")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("Excellent news! Thank you so much for posting this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40066")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("The first lecture on ‘The Law of Gravitation’ is super-brilliant and spell-binding, to say the least! What a master expositor!")

#text("Btw, anyone noticed the uncanny resemblance to Bill O’Reilly? :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a88124dcfb4b4ab7b6b5954a4057c18dfbd308a80d0245dd295e3ae134282d82-b9e4f45bf9efe8309aecca589c2f43794c90156a931121fe32720575239b0152.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40068")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Kudos to Microsoft for making these available. Shame on them for limiting who can see them by using Silverlight which those of using Linux can’t get.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40069")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Thanks for the tip. I don’t have the proprietary software to enable me to see the videos. Luckily, what I consider to be the most valuable lectures, the 1979 Douglas Robb Memorial Lectures at the University of Auckland, are still available via Google Videos: ")#link("http://video.google.com.au/videosearch?q=feynman+auckland&filter=0&start=0")[#text("http://video.google.com.au/videosearch?q=feynman+auckland&filter=0&start=0")]#linebreak()#text(" and work fine on my setup which includes Firefox 3.5 on openSUSE 11.0. In Lectures 1, 2 and 3 Feynman digs right into Quantum Electrodynamics without oversimplification.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40071")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e76v4")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")]

#text("[…] Online Feynman lectures recommended. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40072")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("I was struck by this part from lecture 2, part 4")

#text("“We can deduce … from one part of physics, like the law of Gravitation, a principle [conservation of angular momentum] which turns out to be much more valid than the derivation. This doesn’t happen in mathematics, that theorems come out where they’re not supposed to be!”")

#text("It seems to me that current mathematics has a great deal of this flavour. Results are proved for function fields and believed for number fields; proved in discrete models and believed in continuous ones; proved for periodic boundary conditions and believed for rapidly decaying ones. Maybe a better contrast would be to say that mathematicians are intrigued, but not satisfied, in these cases, while physicists are willing to accept them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Dear David,")

#text("Yes, I had a similar impression (see the update to my blog post above). I do think modern mathematics has broadened beyond the formalist axiomatic perspective which was perhaps more dominant in 1964 than it is today, and now explicitly incorporates other modes of thinking, including ones analogous to the generalisations and heuristics used in physical thinking. But the standard of rigorous proof is, of course, still the fundamental one with which to judge mathematical progress, in contrast to physics which is more interested in the practical accuracy, utility, and consistency of a theory, and the physical insights gained by that theory. (The distinction between consistency and rigour is analogous to the distinction Feynman draws between “Babylonian” and “Greek” mathematics in his second lecture.)")

#text("Jaffe and Quinn ")#link("http://arxiv.org/find/all/1/all:+AND+Jaffe+Quinn/0/1/0/all/0/1")[#text("famously proposed")]#text(" creating an intermediate discipline of “theoretical mathematics” which would specialise in proposing mathematical conjectures based on the type of generalisations, analogies, approximations, and consistency checks used in theoretical physics, with the rigorous confirmation provided by traditional mathematics then serving as the analogue of experimental validation. (Note that this is distinct from experimental mathematics, which looks to numerics to provide the data to build and confirm conjectures, rather than to rigorously proved theorems.) I am uneasy however about any sort of decoupling between heuristics and rigour; it can be quite dangerous to make conjectures about a mathematical field if you cannot rigorously prove more basic results in that field, and subcontracting the understanding gained from these rigorous efforts to others does not seem to fully solve this problem. The converse is also true: a mathematician who proves theorems rigorously, but is content to take the intuition, perspective, and heuristics of the field from other experts at face value, rather than developing them innately, is also going to eventually run adrift or be unable to progress beyond a certain level.")

#text("[See also ")#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")[#text("my thoughts on the three stages of mathematical thinking")]#text(", each of which plays an essential role in one’s mathematical development.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d94d29934c6997587c92e70bbccd18aa130883c4196421d5e805d85e98860074-b74cd49f088ffd1e6c0a16b5d0bf7f7b197c9a0fdb2aa060df95f99da2b7afca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Kaul")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-41897")[#strong[#text("Vivek Kaul")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("Thank Terry for your explanation of the utility of both heuristics and rigor. Sometimes, though I am unable to grasp the relation between the two. For example ,we use Lebesgue integrals with real numbers knowing very well that charge is actually quantized in nature. Then how do we actually check the consistency of the assumptions. In fact, any place where we use real numbers, I find it hard to see how our approximations to natural phenomenon can be rigorously proved without knowing whether real numbers exist in nature.")

#text("Also could you please explain the difference between rigorous proof of a theorem and consistency of a theorem. Is consistency just checked by some easy test cases?")

#text("And according to Karl Popper, mathematics is about establishing equivalences between different entities . Mathematical statements are close to analytic statements or tautologies within the axiomatic framework and they help to change statements into a form that is empirically verifiable or falsifiable . And there, the statistical method provides the interaction between mathematical model and empirical testing. So nothing is proved, only things are accepted till the hypothesis cannot be rejected.")

#text("Do you agree with this analysis?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40076")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Thanks for posting these videos, they’re really interesting. My dad met Feynman while he was a student at Caltech, he said Feynman would go to the student dinners every once in a while. When he did my dad said he was the center of attention, and not just because he was famous, but because he was so interesting and energetic and captivating. Talking with (or listening to) someone that passionate is inspiring.")

#text("Thurston has a very interesting and well-written reply to Jaffe and Quinn’s article called “On proof and progress in mathematics.” (I’m not sure if putting a link to it would cause the comment to be flagged as spam, but it’s on the Arxiv.) It’s definitely worth reading.")

#text("I also liked the ending of Feynman’s second talk, where he basically said that ignorance of mathematics and physics is the only thing that could cause people to think that the most interesting thing in the universe is man.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40080")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Towards the end of Lecture 7 ")#emph[#text("Seeking New Laws")]#text(", Feynman discusses the future of science in sobering terms:")

#emph[#text("“We are very lucky to live in an age in which we are still making discoveries. It is like the discovery of America—you only discover it once. The age in which we live is the one in which we are discovering the fundamental laws of nature, and that day will never come again. It is very exciting, it is marvelous, but this excitement will have to go. Of course, in the future there will be other interests. There will be the interest in the connection of one level of phenomena with another—phenomena in biology and so on, or, if you are talking about exploration, exploring other planets, but there will not still be the same things that we are doing now.”")]

#text("This quote is transcribed from the book version of Feynman’s lectures, which is titled ")#emph[#text("The Character of Physical Law")]#text(", MIT Press, 1965.")

#text("Feynman was right to foresee that the excitement of physics was peaking … physics graduate enrollment (in the US) has never again approached the levels of the 1960-70s. And Feynman was also right to foresee that enterprises in biological science would supply niches for the coming generation of scientists–the Human Genome Project is a great example.")

#text("Now it is 55 years later, and we can ask, what is going on that is comparably exciting to the science of 1964 … and what ")#emph[#text("new")]#text(" enterprises will supply jobs for yet ")#emph[#text("another")]#text(" generation of mathematicians, scientists, and engineers? `Cuz hey, our planet has literally one billion people who presently are in need of goods jobs … with another four billion people are on the way. Which is sobering (to say the least), but on the other hand (as James Earl Jones famously said) “I’m sorry sir, those ")#emph[#text("are")]#text(" the numbers.”")

#text("To sound a note of Feynman-esque optimism, I am posting from the conference ")#emph[#text("FOMMS 2009: Foundations for Innovation")]#text(" and the attitude here is ")#emph[#text("terrific")]#text(" (to use a word that Feynman was fond of). As speaker Klaus Schulten (author of the well-respected molecular simulation package NAMD) asserted “Everything that can be imaged, can be computed” … and the sense of the FOMMS attendees is that (in the long run) every molecular structure in the planetary biome, and every synthesized molecular structure too, can and will be computationally simulated.")

#text("Complementary to the FOMMS Workshop’s vigorous optimism about computation is the vigorous optimism of next month’s ")#link("http://www.research.cornell.edu/KIC/events/mrfm2009/")[#emph[#text("Kavli Conference: Routes to Three-Dimensional Imaging of Single Molecules")]]#text(" (which John Marohn is hosting at Cornell) … the Kavli/Cornell conference will focus on acquiring by 3D quantum spin imaging the spatial information that the FOMMS attendees require to initialize their simulation codes.")

#text("Here at FOMMS, David Baker said from the podium “It is heresy to suggest that simulation codes might yield better structures than x-ray crystallography, but I have to say, that I am beginning to wonder whether that heresy might be true!” Surely, Feynman would have enjoyed this computational heresy very much … and would enjoy too the complementary advances in molecular-scale microscopy that will be the focus of the Cornell/Kavli Workshop in August … especially since Feynman himself worked vigorously on research in computational physics, structural biology, and microscopy.")

#text("What’s the connection of all this to mathematics? Well, please let me suggest that ")#emph[#text("both")]#text(" of these conferences would benefit if more mathematicians attended them! Because to a remarkable yet under-recognized extent, everyone at both conferences is working with the same ")#link("http://faculty.washington.edu/sidles/QSEPACK/Kavli/QSE_summary.pdf")[#text("mathematical structures")]#text(", which are ubiquitous in both classical and quantum simulations: symplectic state-spaces and symplectic integration algorithms, gradients of potential functions, and PDEs deriving from underlying stochastic processes.")

#text("Even though we use these state-spaces all the time … and base large enterprises upon them … we are very far from having a satisfactory mathematical understanding of them.")

#text("We can only conclude, that there is no reason to be jealous of Feynman’s generation of the 1960s …because the opportunities of our generation are even grander … and more wonderful … and more urgent of achievement too … for mathematicians, scientists, and engineers alike.")

#text("That’s why our generation is a lucky one … even luckier than Feynman’s generation! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40081")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("The Douglas Robb Memorial Lectures are also at ")#link("http://vega.org.uk/video/subseries/8")[#text("http://vega.org.uk/video/subseries/8")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40083")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")]

#text("[…] Feynman’s lectures online Seven videotaped lectures from 1964 by Richard Feynman given in Cornell, on “The Character of Physical […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc3eb57377e738a899fe2d264be66528a6a5c6faddf5331fd52f21f8557a1bef-e4c57f0c784e8469132495f714de8f5e6911d070133550f2571eb5275158757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kebabbert")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40086")[#strong[#text("Kebabbert")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Dear prof Tao,")

#text("I have a question for you. I have downloaded your lecture notes as additional reading as I try to learn some more math. I think your lecture notes are far better than most of the stuff Ive read. They are more pedagogical, and you motivate all concepts before introducing them. Ive learned LOTS from your lecture notes. I prefer them to any book, actually.")

#text("My question is, only some of your lecture notes are available online. Many links are dead. If you have more lecture notes, would it be possible that you made them available on your web page? I would love to read them too! For instance the Topology course.")

#text("Best regards,")#linebreak()#text(" Kebabbert")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("The second of the more recent Feynman lectures has a nice exposition of the method of stationary phase.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Dear Kebabbert,")

#text("If you could tell me the pages with the dead links, and what those links are, I can try to restore them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40099")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Interestingly not very long ago all of these lectures were on youtube (I know as I saw them and also placed links for them on my blog), I just checked up and all are now deleted. So much for free distribution/dissemination of knowledge. Though Microsoft’s effort is much appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40100")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Apologies, not ALL of them.")#linebreak()#text(" Happened due to passive typing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("With regard to broken links, the postscript and html links do not work here:")

#link("http://www.math.ucla.edu/~tao/resource/general/132.1.00w/")[#text("http://www.math.ucla.edu/~tao/resource/general/132.1.00w/")]

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40108")[#strong[#text("Weekend miscellany — The Endeavour")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2009")]

#text("[…] Feynman lectures online […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John McAndrew")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40110")[#strong[#text("John McAndrew")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2009")])]

#text("Terence, Feynman obviously had a playful approach to physics and was a brilliant communicator which is reflected in his famous 3 volume Lectures on Physics which are still used today. In the mathematical community, I would suggest that an equivalent is… John Horton Conway.")

#text("Which mathematicians do you most admire and for what reasons?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40112")[#strong[#text("The Character of Physical Law « Todd and Vishal’s blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2009")]

#text("[…] (I came to know about the existence of the videos released by the Microsoft Research group from Terence Tao.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40122")[#strong[#text("The Character of Physical Law | Phasing")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2009")]

#text("[…] (I came to know about the existence of the videos released by the Microsoft Research group from Terence Tao.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f3110a4fe11b8f0b11e3ce966c2ab2ac2e8f0a67944606caffbfd26cbfe3313-6c6d41a295497437ca2e6ac72536111291bf8459ae5a38a65e89cd98d8469fe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40127")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2009")])]

#text("thanks for the links, they were quite enjoyable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("The audio of the famous lectures (1961-1963) are on itunes:")

#link("http://ax.search.itunes.apple.com/WebObjects/MZSearch.woa/wa/search?entity=audiobook&media=all&submit=seeAllLockups&term=feynman+lectures")[#text("http://ax.search.itunes.apple.com/WebObjects/MZSearch.woa/wa/search?entity=audiobook&media=all&submit=seeAllLockups&term=feynman+lectures")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40624")[#strong[#text("Richard Feynman and The Quest for Tannu Tuva « Onionesque Reality")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")]

#text("[…] came to know of these lectures on Prof Terence Tao’s page, who, as an aside – I find very inspirational […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a729ef9d3e83215f84e636062ee29db91ea7e194feccc61c283702840dd3a0d1-c287711d254a0b15a5de085c038583e5582fba5b962d08fec804fcc85ae54930.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Lopez-Ortiz")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40681")[#strong[#text("Alex Lopez-Ortiz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#emph[#text("“We can deduce … from one part of physics, like the law of Gravitation, a principle [conservation of angular momentum] which turns out to be much more valid than the derivation. This doesn’t happen in mathematics, that theorems come out where they’re not supposed to be!”")]

#text("A somewhat surprising statement. I wonder if what he meant is that in physics a finite set of incomplete examples can establish the law, and that this is not possible in mathematics.")

#text("Say, borrowing from his example, if physicists experimentally observe conservation of angular momentum in three or four rather disparate settings the physical law is considered established.")

#text("The analogy in mathematics would be to consider it established that the integral is an antiderivative from the mere fact that it holds for a few disparate functions. Mathematicians will certainly use this as evidence to conjecture the general theorem, but the result still needs to be proven in its full generality on its own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40682")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Doesn’t this simply mean that Newton’s systematic understanding of Gravity was superseded by Einstein – so Newtonian Gravity, which once looked fundamental, was a mere approximation.")

#text("On the other hand, conservation of angular momentum, which was a by-product of Newtonian dynamics, survives, and is in fact now understood to reflect the fact that there is no privileged direction in space – it expresses the fundamental symmetry of things under rotation.")

#text("Mathematics builds on axioms it regards as fundamental – provided the axioms and rules of deduction remain the same and are consistent, the conclusions are unaltered.")

#text("Feynman expressed many times that the test of science was experiment, and if theory did not fit experiment it was the theory which had to change. But some surprising elements may remain.")

#text("This is philosophically interesting, but I’m not sure what it has to do with polymath.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40683")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Sorry, somehow hit the wrong thread in referring to polymath. The point is that there is a difference between physics and maths. Maths can live in its own world, physics is answerable to experiment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40754")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("This is slightly off topic, but I just learned about a surprising personal side to Feynman. I was reading the book Wesley the Owl by Stacey O’Brien on the bus home today (I have a naturalist bent as well) and ran across this odd comment:")

#text("“When I was a kid, my dad was friends with Richard Feynman before he’d won his Nobel Prize in physics. Always an iconoclast, Feynman never let anyone tell him how to act or behave. He would go to topless bars to sit there and do calculations on the tablecloth. He wasn’t there to look at naked girls; he just liked the ambience.”")

#text("Topless bars? Ambience?")

#text("That’s not as unusual though as the next physicist she talked about:")

#text("“Yet another physicist at Caltech insisted on working in the buff in his office. There was a picture in one of the hallways in the physics department of him sitting naked at his desk, taken tastefully from the side.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-40763")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2009")])]

#text("I remember the sandwich that my mentor and coauthor Feynman had the owner of the topless bar in Pasadena add to the booze menu, after the City shut it down. That was a ham and cheese sandwich.")

#text("Feynman, who liked going there (“after a hard day dealing with oscillating bodies, it’s nice to see some oscillating bodies”), succeeded in keeping the place open a few more months. When the city tried enforcing the anti-topless-bar ordinance, the owner could now say: “we’re not a topless bar. We’re a topless restaurant.”")

#text("The other Feynman sandwich anecdote: Leonard Susskind and Feynman are getting a “Feynman sandwich” at the local deli, and Feynman remarks that a “Susskind sandwich” would be similar, but with “more ham”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-41602")[#strong[#text("Devils Backyard » Blog Archive » Richard Feynman and The Quest for Tannu Tuva")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")]

#text("[…] came to know of these lectures on Prof Terence Tao’s page, who I find very inspiring […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-43377")[#strong[#text("Richard Feynman and The Quest for Tannu Tuva | BlogHalt.com (Pre-Launch)")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")]

#text("[…] came to know of these lectures on Prof Terence Tao’s page, who I find very inspiring […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/15/feynmans-lectures-online/#comment-686819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2024")])]

#text("Project tuva has now been retired (see ")#link("https://en.wikipedia.org/wiki/Project_Tuva")[#text("wikipedia")]#text(" for youtube links to the lectures)")
]
