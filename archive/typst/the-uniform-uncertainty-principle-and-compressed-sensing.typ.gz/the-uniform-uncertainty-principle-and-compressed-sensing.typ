// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/
// Converted to Typst by tao2typ: "2026-10-14T15:16:56.434985+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The uniform uncertainty principle and compressed sensing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The uniform uncertainty principle and compressed sensing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/")[#text("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am in Seville, Spain, for a ")#link("http://congreso.us.es/harmonic08/")[#text("conference in harmonic analysis and related topics")]#text(". My talk is titled “")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/uup.pdf")[#text("the uniform uncertainty principle and compressed sensing")]#text("“. The content of this talk overlaps substantially with my ")#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/")[#text("Ostrowski lecture on the same topic")]#text("; the slides I prepared for the Seville lecture can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/uup.pdf")[#text("here")]#text(".")

#text("[")#emph[#text("Update")]#text(", Dec 6: Some people have asked about my other lecture given in Seville, on structure and randomness in the prime numbers. This lecture is largely equivalent to the one posted ")#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/")[#text("here")]#text(".]")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2008")])]

#text("Did you check the proof of the Goldbach conjecture submitted to arxiv today?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33771")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2008")])]

#text("I only looked at it briefly, skipping to the last section which seems to be the only part that actually has to do with primes and the Goldbach problem. From the arguments given there, it appears the author only proves a somewhat weaker statement than the Goldbach conjecture, namely that there ")#emph[#text("exists")]#text(" an even number greater than four which is the sum of two primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f03a6b0299f29a32f1be013ef12fb170b65b2ddbb3cdf4c74af19e3d7ec0bf9-2d62b6b408fb8968cef0c2412392c16f820a1815f5adf11ddc7e35267df694d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AA")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33783")[#strong[#text("AA")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2008")])]

#text("I copied the word “somewhat” from that comment and pasted it to my short list of “staggering understatements of the year 2008”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33806")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2008")])]

#text("I think that calling that a staggering understatement is itself an understatement of epic proportions. And recursively, what I myself just wrote is probably an understatement too.")

#text("Anyway, if anybody wonders about Terry’s whereabouts now that the Seville conference is over, I can reveal that he is currently in Trondheim, Norway, where he has delivered this year’s ")#link("http://www.ntnu.no/onsager")[#text("Onsager lecture")]#text(" (after receiving his very own Onsager medal of course).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2008")])]

#text("Terence have you heard from Alexander Grothendieck? Any plans to meet him, to get him working on math again? He’s gone from maths for a long time now, what is he doing currently?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33814")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2008")])]

#text("I also found that reply amusing :-) The same guy has over 700 pages of papers on the arxiv, and from a glancing at a couple of them, they seem to be filled with nonsense (although with many mathematically sophisticated words). It makes me wonder what’s going through the head of someone who would learn so many words and then arrange them in (seemingly) meaningless sentences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-34475")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2008")])]

#text("Terry,")

#text("Your lecture on Compressed Sensing at the Onsager Lecture series is at:")

#link("http://multimedie.adm.ntnu.no/mediasite/Viewer/?peid=dffa743e1d7446f7b493ea3205ddd41d")[#text("http://multimedie.adm.ntnu.no/mediasite/Viewer/?peid=dffa743e1d7446f7b493ea3205ddd41d")]

#text("it cannot be read on Chrome and Opera, but they are available in chunks on Youtube:")

#link("http://nuit-blanche.blogspot.com/2008/12/cs-terence-tao-video-presentation-of.html")[#text("http://nuit-blanche.blogspot.com/2008/12/cs-terence-tao-video-presentation-of.html")]

#text("Another item that you might find interesting is a list of different technologies that are implementing CS in hardware (the single pixel camera at Rice being the prime example)")

#link("http://igorcarron.googlepages.com/compressedsensinghardware")[#text("http://igorcarron.googlepages.com/compressedsensinghardware")]

#text("Cheers,")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/05/the-uniform-uncertainty-principle-and-compressed-sensing/#comment-34477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2008")])]

#text("Dear Igor,")

#text("Thanks for the links!")
]
