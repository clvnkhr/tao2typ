// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/
// Converted to Typst by tao2typ: "2026-10-14T15:16:45.319865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("It is well known that the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\dot f = \\Delta f")]]

#text("on a compact Riemannian manifold (M,g) (with metric g static, i.e. independent of time), where ")#mi("f: [0,T] \\times M \\to {\\Bbb R}")#text(" is a scalar field, can be interpreted as the ")#link("http://en.wikipedia.org/wiki/Gradient_flow#Gradient_field")[#text("gradient flow")]#text(" for the ")#link("http://en.wikipedia.org/wiki/Dirichlet_energy")[#text("Dirichlet energy")]#text(" functional")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("E(f) := \\frac{1}{2} \\int_M \\left|\\nabla f\\right|_g^2\\ d\\mu", block: true)]]

#text("using the inner product ")#mi("\\langle f_1, f_2 \\rangle_\\mu := \\int_M f_1 f_2\\ d\\mu")#text(" associated to the volume measure ")#mi("d\\mu")#text(". Indeed, if we evolve f in time at some arbitrary rate ")#mi("\\dot f")#text(", a simple application of integration by parts (equation (29) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{dt} E(f) = - \\int_M (\\Delta f) \\dot f\\ d\\mu = \\langle -\\Delta f, \\dot f \\rangle_\\mu")]]

#text("from which we see that (1) is indeed the gradient flow for (3) with respect to the inner product. In particular, if f solves the heat equation (1), we see that the Dirichlet energy is decreasing in time:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{d}{dt} E(f) = - \\int_M \\left|\\Delta f\\right|^2\\ d\\mu.", block: true)]]

#text("Thus we see that by representing the PDE (1) as a gradient flow, we automatically gain a controlled quantity of the evolution, namely the energy functional that is generating the gradient flow. This representation also strongly suggests (though does not quite prove) that solutions of (1) should eventually converge to stationary points of the Dirichlet energy (2), which by (3) are just the harmonic functions (i.e. the functions f with ")#mi("\\Delta f = 0")#text(").")

#text("As one very quick application of the gradient flow interpretation, we can assert that the only periodic (or “breather”) solutions to the heat equation (1) are the harmonic functions (which, in fact, must be constant if M is compact, thanks to the maximum principle). Indeed, if a solution f was periodic, then the monotone functional E must be constant, which by (4) implies that f is harmonic as claimed.")

#text("It would therefore be desirable to represent Ricci flow as a gradient flow also, in order to gain a new controlled quantity, and also to gain some hints as to what the asymptotic behaviour of Ricci flows should be. It turns out that one cannot quite do this directly (there is an obstruction caused by ")#emph[#text("gradient steady solitons")]#text(", of which we shall say more later); but Perelman nevertheless observed that one ")#emph[#text("can")]#text(" interpret Ricci flow as gradient flow if one first quotients out the diffeomorphism invariance of the flow. In fact, there are infinitely many such gradient flow interpretations available. This fact already allows one to rule out “breather” solutions to Ricci flow, and also reveals some information about how ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_inequality")[#text("Poincaré’s inequality")]#text(" deforms under this flow.")

#text("The energy functionals associated to the above interpretations are subcritical (in fact, they are much like ")#mi("R_{\\min}")#text(") but they are not coercive; Poincaré’s inequality holds both in collapsed and non-collapsed geometries, and so these functionals are not excluding the former. However, Perelman discovered a perturbation of these functionals associated to a deeper inequality, the ")#emph[#text("log-Sobolev inequality")]#text(" (first introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=420249")[#text("by Gross")]#text(" in Euclidean space). This inequality ")#emph[#text("is")]#text(" sensitive to volume collapsing at a given scale. Furthermore, by optimising over the scale parameter, the controlled quantity (now known as the ")#emph[#text("Perelman entropy")]#text(") becomes scale-invariant and prevents collapsing at any scale – precisely what is needed to carry out the first phase of the strategy outlined in the ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("previous lecture")]#text(" to establish global existence of Ricci flow with surgery.")

#text("The material here is loosely based on ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(", ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott’s notes")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2251315")[#text("Müller’s book")]#text(".")

#metadata(none) <tao-d1bbc255633493256d9c>

#heading(level: 1)[#text("— Ricci flow as gradient flow —")]

#text("We would like to represent Ricci flow")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\dot g = - 2 \\text{Ric}")]]

#text("as a gradient flow of some functional (with respect to some inner product, or at least with respect to some Riemannian metric on the space of all metrics g). We will assume that all quantities are smooth and that the manifold is either compact or that all expressions being integrated are rapidly decreasing at infinity (so no boundary terms etc. arise from integration by parts).")

#text("To do this, our starting point will be the first variation formula for the scalar curvature R (equation (15) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") for an arbitrary instantaneous deformation ")#mi("\\dot g")#text(" of the metric g:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\dot R = - \\text{Ric}^{\\alpha \\beta} \\dot g_{\\alpha \\beta} - \\Delta \\text{tr}(\\dot g) +\\nabla^\\alpha \\nabla^\\beta \\dot g_{\\alpha \\beta}.")]]

#text("We can integrate in M to eliminate the latter two terms on the right-hand side (by Stokes theorem, see equation (28) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") to get")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_M \\dot R\\ d\\mu = - \\int_M \\text{Ric}^{\\alpha \\beta} \\dot g_{\\alpha \\beta} \\ d\\mu.")]]

#text("This looks rather promising; it suggests that if we introduce the ")#link("http://en.wikipedia.org/wiki/Einstein-Hilbert_action")[#text("Einstein-Hilbert functional")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("H(M,g) := \\int_M R\\ d\\mu")]]

#text("then the Ricci flow (5) might be interpretable as a gradient flow for -2H.")

#text("Unfortunately, there is a problem because R is not the only time-dependent quantity in the right-hand side of (8); the volume measure ")#mi("d\\mu")#text(" also evolves in time by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{d}{dt} d\\mu = \\frac{1}{2} \\text{tr}(\\dot g)\\ d\\mu")]]

#text("(see equation (19) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). Thus, from the product rule, the true variation of the Einstein-Hilbert functional is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dt} H(M,g) = \\int_M (- \\text{Ric}^{\\alpha \\beta} + \\frac{1}{2} R g^{\\alpha \\beta}) \\dot g_{\\alpha \\beta}\\ d\\mu.")]]

#text("So the gradient flow of -2H (using the inner product associated to ")#mi("d\\mu")#text(") is not Ricci flow, but is instead a rather strange flow")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\dot g = -2 \\text{Ric} + R g = -2G")]]

#text("where ")#mi("G:= \\text{Ric} - \\frac{1}{2} R")#text(" is the ")#link("http://en.wikipedia.org/wiki/Einstein_tensor")[#text("Einstein tensor")]#text(". This flow does not have any particularly nice properties in general (it is not parabolic in three and higher dimensions, even after applying the de Turck trick from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). On the other hand, in two dimensions the right-hand side of (10) vanishes and H(M,g) becomes invariant under deformations (we have already exploited this fact to prove the ")#link("http://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet formula")]#text(", see Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text("). More generally, we recover see from (10) the fact (well known in general relativity) that the (formal) stationary points of the Einstein-Hilbert functional are precisely the solutions of the vacuum ")#link("http://en.wikipedia.org/wiki/Einstein_field_equations")[#text("Einstein equations")]#text(" ")#mi("G=0")#text(" (or equivalently, ")#mi("\\text{Ric}=0")#text(" in any dimension other than 2).")

#text("We see that the variation of the measure ")#mi("d\\mu")#text(" in time is causing us some difficulty. To fix this problem, let us take the (rather non-geometric looking) step of replacing this evolving measure ")#mi("d\\mu")#text(" by some static measure ")#mi("dm")#text(" which we select in advance, and consider instead the variation of the functional ")#mi("\\int_M R\\ dm")#text(" with respect to some arbitrary perturbation ")#mi("\\dot g")#text(". Now that m is static, we can apply (6) to get")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{d}{dt} \\int_M R\\ dm = \\int_M (- \\text{Ric}^{\\alpha \\beta} \\dot g_{\\alpha \\beta} - \\Delta \\text{tr}(\\dot g) +\\nabla^\\alpha \\nabla^\\beta \\dot g_{\\alpha \\beta})\\ dm.")]]

#text("Previously, we used Stokes’ theorem to eliminate the latter two terms on the right-hand side to leave us with the one term ")#mi("\\int_M \\text{Ric}^{\\alpha \\beta} \\dot g_{\\alpha \\beta}\\ dm")#text(" that we do want. Unfortunately, Stokes’ theorem only applies for the volume measure ")#mi("d\\mu")#text(", not for our static measure ")#mi("dm")#text("! In order to apply Stokes’ theorem, we must therefore convert the static measure back to volume measure. The ")#link("http://en.wikipedia.org/wiki/Radon-Nikodym_derivative")[#text("Radon-Nikodym derivative")]#text(" ")#mi("\\frac{d\\mu}{dm}")#text(" of the two measures should be some positive function, which we shall denote by ")#mi("e^f")#text(" for some scalar (and time-varying) function ")#mi("f: M \\to {\\Bbb R}")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("dm = e^{-f} d\\mu.")]]

#text("Inserting (13) into (12), integrating by parts using the volume measure ")#mi("d\\mu")#text(", and then using (13) again to convert back to the static measure ")#mi("dm")#text(", we see after a little calculation that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\int_M \\Delta \\text{tr}(\\dot g)\\ dm = \\int_M ( \\left|\\nabla f\\right|_g^2 - \\Delta f) \\text{tr}(\\dot g)\\ dm", block: true)]]

#text("and similarly")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\int_M \\nabla^\\alpha \\nabla^\\beta \\dot g_{\\alpha \\beta}\\ dm = \\int_M ( (\\nabla^\\alpha f) (\\nabla^\\beta g) - \\nabla^{\\alpha} \\nabla^{\\beta} f) \\dot g_{\\alpha \\beta} \\ dm")]]

#text("and so we can express the right-hand side of (12) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\langle -\\text{Ric}^{\\alpha \\beta} - (\\left|\\nabla f\\right|_g^2 - \\Delta f) g^{\\alpha \\beta} + (\\nabla^\\alpha f) (\\nabla^\\beta f) - \\nabla^{\\alpha} \\nabla^{\\beta} f, \\dot g_{\\alpha \\beta} \\rangle_m.", block: true)]]

#text("This looks rather unpleasant; we managed to eradicate the scalar curvature term ")#mi("\\frac{1}{2} R")#text(" that was present in the variation in (10), but at the cost of introducing four new terms involving f. But to deal with this, first observe from differentiating (13) and using (9) and the static nature of dm that we know the first variation of f:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\dot f = \\frac{1}{2} \\text{tr}(\\dot g).")]]

#text("So the term ")#mi("\\langle \\Delta f g^{\\alpha \\beta}, \\dot g_{\\alpha \\beta} \\rangle_m")#text(" that appears in (16) can be rewritten as ")#mi("2 \\int_M (\\Delta f) \\dot f\\ dm")#text(". Now this term looks familiar… in fact, it essentially the variation (3) of the Dirichlet energy functional for the measure dm! This suggests that we may be able to simplify (16) if we modify our functional ")#mi("\\int_M R\\ dm")#text(" by adding some multiple of the Dirichlet functional ")#tao-math("E := \\frac{1}{2} \\int_M \\left|\\nabla f\\right|_g^2\\ dm", block: false)#text(".")

#text("One cannot apply (3) directly, though, because (a) g is evolving in time, rather than static, and also (b) dm is not the volume measure for g. But we have all the equations to deal with this, and one can compute the first variation of E:")

#strong[#text("Exercise 1. ")]#text("Show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\frac{d}{dt} E = - \\frac{1}{2} \\langle \\Delta f g^{\\alpha \\beta} - \\left|\\nabla f\\right|_g^2 g^{\\alpha \\beta} + (\\nabla f)^\\alpha (\\nabla f)^{\\beta}, \\dot g_{\\alpha \\beta} \\rangle_m.", block: true)]]

#text("(Hint: expand out ")#tao-math("\\left|\\nabla f\\right|_g^2 = g^{\\alpha \\beta} (\\nabla_\\alpha f) (\\nabla_\\beta f)", block: false)#text(" and use (3) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(".) ")#mi("\\diamond")

#text("If we thus define the functional")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("{\\mathcal F}_m( M, g ) := \\int_M (R + \\left|\\nabla f\\right|^2)\\ dm", block: true)]]

#text("we see from (16), (18) that we get a lot of cancellation, ending up with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\frac{d}{dt} {\\mathcal F}_m( M, g ) = - \\langle \\text{Ric}^{\\alpha \\beta} + \\nabla^{\\alpha} \\nabla^{\\beta} f, \\dot g_{\\alpha \\beta} \\rangle_m.")]]

#text("Thus the gradient flow of ")#mi("-2{\\mathcal F}_m(M,g)")#text(" with respect to the inner product ")#mi("\\langle h, k \\rangle_m := \\int_M h^{\\alpha \\beta} k_{\\alpha \\beta}\\ dm")#text(" on symmetric two-forms (or more precisely, on the tangent space of such forms at g) is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\dot g_{\\alpha \\beta} = - 2 \\text{Ric}_{\\alpha \\beta} - 2 \\nabla_{\\alpha} \\nabla_{\\beta} f.")]]

#text("From (17) we see that f now evolves by a backward heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\dot f = - \\Delta f - R.")]]

#text("With this flow, we see that ")#mi("{\\mathcal F}_m")#text(" is monotone increasing, with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\frac{d}{dt} {\\mathcal F}_m = 2 \\int_M \\left|\\text{Ric} + \\text{Hess}(f)\\right|^2\\ dm.", block: true)]]

#text("The equation (21) is")#emph[#text(" almost")]#text(" Ricci flow (5), but with one additional term associated with f. But we can observe (using equation (25) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") that ")#mi("2\\nabla_{\\alpha} \\nabla_{\\beta} f = {\\mathcal L}_{\\nabla f} g_{\\alpha \\beta}")#text(" is just the Lie derivative of g in the direction of the gradient vector field ")#mi("\\nabla^\\gamma f")#text(". Thus we see that (23) is a modified Ricci flow (see equation (36) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("), which is conjugate to genuine Ricci flow by a diffeomorphism as discussed in that lecture. Thus while we have not established Ricci flow as a gradient flow directly, we have managed to find a whole family of gradient flows (parameterised by a choice of static measure dm, or equivalently by a choice of potential function f evolving by (17)) which are equivalent to Ricci flow modulo diffeomorphism. (Indeed, by placing an appropriate Riemannian structure on the moduli space of metrics modulo diffeomorphism, one can express Ricci flow modulo diffeomorphism as a true (formal) gradient flow; see Section 9 of the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott notes")]#text(".) As remarked in ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(", one can view f as a kind of gauge function for the Ricci flow.")

#strong[#text("Example 1.")]#text(" If (M,g) is a Euclidean space ")#mi("M = {\\Bbb R}^d")#text(" with the contracted Euclidean metric ")#mi("g = \\frac{\\tau}{t_0} \\eta")#text(" for times ")#mi("0 \\leq t < t_0")#text(", where ")#mi("\\tau := t_0 - t")#text(" and ")#mi("\\eta")#text(" is the standard metric, with ")#mi("dm")#text(" equal to the Gaussian measure ")#tao-math("\\frac{1}{(4\\pi t_0)^{d/2}} e^{-\\left|x\\right|^2/4t_0}\\ dx", block: false)#text(" (thus ")#tao-math("f(t,x) = \\frac{\\left|x\\right|^2}{4t_0} + \\frac{d}{2} \\log(4\\pi \\tau)", block: false)#text("), then g, f solve (21), (22). (One has to be a bit careful here because M is non-compact, of course.) ")#mi("\\diamond")

#text("We can of course conjugate away the infinitesimal diffeomorphism given by the vector field ")#mi("\\nabla f")#text(", which converts the system (21), (22) to the system")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\dot g = -2\\text{Ric}; \\quad \\dot f = -\\Delta f + \\left|\\nabla f\\right|_g^2 - R", block: true)]]

#text("(here we use the fact that ")#tao-math("{\\mathcal L}_{\\nabla f} f = \\left|\\nabla f\\right|_g^2", block: false)#text("), which is Ricci flow coupled with a nonlinear backwards heat equation for the potential f. (Note that the equation for f is not always solvable forwards in time for any non-zero amount of time, but we can always solve it instantaneously for a fixed time, which is good enough for first variation analysis.) The non-linear backwards heat equation equation for f can be linearised by setting ")#mi("u := e^{-f}")#text(", in which case it becomes the ")#emph[#text("adjoint heat equation")]

#align(center)[#mi("\\dot u = - \\Delta u + R u")#text(". (24′)")]

#strong[#text("Exercise 2. ")]#text("Writing ")#mi("dm := u d\\mu")#text(", show that (24′) is equivalent to the equation")

#align(center)[#mi("\\frac{d}{dt} dm = - \\Delta dm")#text(" (24”)")]

#text("where ")#mi("dm")#text(" is viewed as a d-form for the purposes of applying the Laplacian. Thus the adjoint heat equation can be viewed as the backwards heat equation for d-forms. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" If (M,g) is a static Euclidean space ")#mi("M = {\\Bbb R}^d")#text(" and ")#tao-math("f(t,x) = \\frac{\\left|x\\right|^2}{4\\tau} + \\frac{d}{2} \\log(4\\pi \\tau)", block: false)#text(" with ")#mi("\\tau = t_0 - t")#text(" and the time variable t is restricted to be less than ")#mi("t_0")#text(", then g, f solve (24), and ")#mi("dm = e^{-f} d\\mu")#text(" is the Gaussian measure ")#tao-math("\\frac{1}{(4\\pi \\tau)^{d/2}} e^{-\\left|x\\right|^2/4\\tau}\\ dx", block: false)#text(", which solves the backwards heat equation. Note that this is the conjugated version of Example 1. Again, one needs to take care because M is non-compact. ")#mi("\\diamond")

#text("By performing this conjugation, the measure m is no longer static, and we reflect this by changing the notation a little to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("{\\mathcal F}(M, g, f) := {\\mathcal F}_{e^{-f} \\mu}(M,g) = \\int_M (\\left|\\nabla f\\right|^2 + R) e^{-f}\\ d\\mu.", block: true)]]

#text("The relationship between ")#mi("{\\mathcal F}")#text(" and the flow (24) is analogous to that between ")#mi("{\\mathcal F}_m")#text(" and (21), (22). For instance, we have the following analogue of (23):")

#strong[#text("Exercise 3. ")]#text(" If g, f solve (24), show that")

#align(center)[#tao-math("\\displaystyle \\frac{d}{dt} {\\mathcal F}(M, g, f) = 2 \\int_M \\left|\\text{Ric} + \\text{Hess}(f)\\right|^2 e^{-f}\\ d\\mu", block: false)#text(". ")#mi("\\diamond")#text(" (26)")]

#text("Thus ")#mi("{\\mathcal F}(M,g,f)")#text(" is monotone non-decreasing in time. We would like to use this to develop a controlled quantity for Ricci flow, but we need to eliminate f. This can be accomplished by taking an infimum, defining")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\lambda(M,g) := \\inf_{f: \\int_M e^{-f}\\ d\\mu = 1} {\\mathcal F}(M,g,f).")]]

#text("The normalisation ")#mi("\\int_M e^{-f}\\ d\\mu = 1")#text(" (which makes dm a probability measure) is needed to ensure a meaningful infimum; note that this normalisation is preserved by the flow (24) since dm is only moved around by diffeomorphisms. This quantity has an interpretation as the best constant in a Poincaré inequality:")

#strong[#text("Exercise 4.")]#text(" Show that ")#mi("\\lambda(M,g)")#text(" is the least number for which one has the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\int_M 4 \\left|\\nabla u\\right|_g^2 + R\\left|u\\right|^2\\ d\\mu \\geq \\lambda(M,g) \\int_M \\left|u\\right|^2\\ d\\mu", block: true)]]

#text("for all ")#mi("u")#text(" in the ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev space")]#text(" ")#mi("H^1(M)")#text(". (")#emph[#text("Hint")]#text(": reduce to the case when u is positive and smooth and then make the substitution ")#mi("u = e^{-f/2}")#text(".) Conclude in particular that ")#mi("\\lambda(M,g)")#text(" is finite, that it is the least eigenvalue of the self-adjoint modified Laplacian ")#mi("-4\\Delta + R")#text(", and lies between ")#mi("R_{\\min}")#text(" and the average scalar curvature ")#mi("\\overline{R} := \\int_M R\\ d\\mu / \\int_M\\ d\\mu")#text(". ")#mi("\\diamond")

#text("A variational argument (using the standard fact that ")#mi("H^1(M)")#text(" embeds compactly into ")#mi("L^2(M)")#text(") shows that equality in (28) is attained by some strictly positive ")#mi("u = e^{-f/2}")#text(" with norm ")#tao-math("\\int_M \\left|u\\right|^2\\ d\\mu = 1", block: false)#text(", and so the infimum in (27) is also attained for some f. Applying the flow (24) instantaneously at a given time, we conclude (formally, at least) that we have the monotonicity formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\frac{d}{dt} \\lambda(M,g) = 2 \\int_M \\left|\\text{Ric} + \\text{Hess}(f)\\right|^2 e^{-f}\\ d\\mu", block: true)]]

#text("for any solution to Ricci flow (5), where f is the extremiser for (27) (note that this extremiser f need not evolve via (25)). (One can in fact make this formula rigorous whenever the Ricci flow is smooth and M is compact, but we will not detail this here.)")

#text("This monotonicity is similar to the monotonicity of ")#mi("R_{\\min}")#text(". For instance, the functional ")#mi("\\lambda(M,g)")#text(" has a dimension of -2 in the sense of the previous lecture, same as ")#mi("R_{\\min}")#text(". As further evidence of similarity, we have:")

#strong[#text("Exercise 5.")]#text(" Show that ")#mi("\\frac{d}{dt} \\lambda(M,g) \\geq \\frac{2}{d} \\lambda(M,g)^2")#text(", and use this to conclude an analogue of Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(" for ")#mi("\\lambda(M,g)")#text(". In particular conclude that Ricci flow must develop a finite time singularity if ")#mi("\\lambda(M,g)")#text(" is positive. ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" If ")#mi("(M,g)")#text(" is a Ricci flow which is a ")#emph[#text("steady breather")]#text(" in the sense that it is periodic modulo isometries (thus ")#mi("(M,g(t))")#text(" is isometries to ")#mi("(M,g(0))")#text(" for some ")#mi("t > 0")#text("), show that at time zero we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\text{Ric} = - \\text{Hess}(f) = - \\frac{1}{2} \\mathcal{L}_{\\nabla f} g")]]

#text("for some ")#mi("f: M \\to {\\Bbb R}")#text(". Conclude that ")#mi("g(t) = \\exp( t \\nabla f )^* g(0)")#text(", thus ")#mi("(M,g(t))")#text(" simply evolves by diffeomorphism by the gradient field f. (For this you may need to use the uniqueness of the initial value problem for Ricci flow.) In other words, all steady breathers are ")#emph[#text("gradient steady solitons")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" One can apply a similar argument to deal with compact ")#emph[#text("expanding breathers")]#text(" (in which ")#mi("(M,g(t))")#text(" is isometric to a larger dilate of ")#mi("(M,g(0))")#text(" for some ")#mi("t>0")#text(" by normalising ")#mi("\\lambda(M,g)")#text(" by a power of the volume as in Exercise 1 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(", concluding that such breathers are necessarily gradient expanding solitons with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\text{Ric} = - \\text{Hess}(f) - \\frac{g}{2\\sigma}")]]

#text("at time zero for some potential f and some ")#mi("\\sigma > 0")#text("; see ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(" (or Section 7 of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(") for details. With a little more work (using the maximum principle) one can in fact show that f is constant, and so the only compact expanding breathers are Einstein manifolds. (Actually, this result can also be established using Exercise 1 from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(" directly, as follows from the ")#link("http://www.ams.org/mathscinet-getitem?mr=1714939")[#text("work of Hamilton")]#text(".) This normalisation of ")#mi("\\lambda(M,g)")#text(" is also closely related to the ")#link("http://en.wikipedia.org/wiki/Yamabe_invariant")[#text("Yamabe invariant")]#text(" of M; see this ")#link("http://arxiv.org/abs/math/0608504")[#text("paper of Kotschick")]#text(" for further discussion. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" Any Ricci-flat manifold (i.e. ")#mi("\\text{Ric}=0")#text(") is of course a gradient steady soliton with ")#mi("f = 0")#text(". A more non-trivial example is given by ")#emph[#text("Hamilton’s cigar soliton")]#text(" (also known as ")#emph[#text("Witten’s black hole")]#text("), which is the two-dimensional manifold ")#mi("M = {\\Bbb R}^2")#text(" with the conformal metric ")#mi("dg^2 = \\frac{dx^2+dy^2}{1+x^2+y^2}")#text(" and gradient function ")#mi("f := \\log \\sqrt{1+x^2+y^2}")#text("; we leave the verification of the gradient shrinking property (30) as an exercise. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" If Ricci flow was a gradient flow for a functional which was geometric (or more precisely, invariant under diffeomorphism), then this flow could not deform a metric by any non-trivial diffeomorphism (since this is a stationary direction for this functional, rather than a steepest descent). Thus the existence of non-trivial gradient steady solitons, such as the cigar soliton, explains why Ricci flow cannot be directly expressed as a gradient flow without introducing a non-geometric object such as the reference measure dm or the potential function f. (See also Proposition 1.7 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2251315")[#text("Müller’s book")]#text(" for a different way of seeing that Ricci flow is not a pure gradient flow.) ")#mi("\\diamond")

#strong[#text("Exercise 7. ")]#text("If (M,g) is a gradient steady soliton with potential f, show that ")#mi("R + \\Delta f = 0")#text(", ")#tao-math("\\left|\\nabla f\\right|^2 + R = \\text{const}", block: false)#text(", and ")#tao-math("\\dot f = \\left|\\nabla f\\right|^2", block: false)#text(". (Hint: to prove the second identity, differentiate (30) and use the second Bianchi identity (Exercise 7 from ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text(").) Use the maximum principle to then conclude that the only compact gradient steady solitons are the Ricci-flat manifolds. ")#mi("\\diamond")

#heading(level: 1)[#text("— Nash entropy —")]

#text("Let us return to our analysis of the functional ")#mi("{\\mathcal F}_m(M,g)")#text(", in which ")#mi("dm=e^{-f}\\ d\\mu")#text(" was fixed and g evolved by the modified Ricci flow (21) (which forced f to evolve by the backwards heat equation (22)). We then obtained the monotonicity formula (23). We shall normalise dm to be a probability measure.")

#text("We can squeeze a little bit more out of this formula – in particular, making it scale invariant – by introducing the ")#emph[#text("Nash entropy")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("N_m(M,g) := \\int \\log \\frac{dm}{d\\mu}\\ dm = - \\int f\\ dm")]]

#text("which is the ")#link("http://en.wikipedia.org/wiki/Kullback-Leibler_divergence")[#text("relative entropy")]#text(" of ")#mi("d\\mu")#text(" with respect to the background measure dm. (Some further relations and analogies between the functionals described here and notions of entropy from statistical mechanics are discussed in ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(".) From (22) and one integration by parts (using (13), of course) we know how this entropy changes with time:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("\\frac{d}{dt} N_m(M,g) = \\int (\\left|\\nabla f\\right|^2 + R)\\ dm = {\\mathcal F}_m(M,g).", block: true)]]

#text("To exploit this identity, let us first consider the case of gradient shrinking solitons:")

#strong[#text("Exercise 8.")]#text(" Suppose that a Riemannian manifold (M,g)=(M,g(0)) verifies an equation of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\text{Ric} = - \\text{Hess}(f) + \\frac{1}{2\\tau} g")]]

#text("for some function f and some ")#mi("\\tau > 0")#text(". Show that this equation is preserved for times ")#mi("0 \\leq t < \\tau(0)")#text(" if g evolves by Ricci flow, if ")#mi("\\tau")#text(" evolves by ")#mi("\\dot \\tau = -1")#text(" (i.e. ")#mi("\\tau(t) = \\tau(0)-t")#text("), and ")#tao-math("\\partial_t f = \\left|\\nabla f\\right|_g^2", block: false)#text(", and that ")#mi("g(t) = \\frac{\\tau(t)}{\\tau(0)} \\exp( t \\nabla f ) g(0)")#text(" for all ")#mi("0 \\leq t < \\tau(0)")#text(". Such solutions are known as ")#emph[#text("gradient shrinking solitons")]#text("; they combine Ricci flow with the diffeomorphism and scaling flows from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(". Note that any positively curved ")#link("http://en.wikipedia.org/wiki/Einstein_manifold")[#text("Einstein manifold")]#text(", such as the sphere, will be a gradient shrinking soliton (with f=0). Example 1 also shows that Euclidean space can also be viewed as a gradient shrinking soliton. ")#mi("\\diamond")

#text("If we are to find a scale-invariant (and diffeomorphism-invariant) monotone quantity for Ricci flow, it had better be constant on the gradient shrinking solitons. In analogy with (23), we would therefore like the variation of this monotone quantity with respect to Ricci flow to look something like")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("2\\int_M \\left|\\text{Ric} + \\text{Hess}(f) - \\frac{1}{2\\tau} g\\right|_g^2\\ dm", block: true)]]

#text("where ")#mi("\\tau")#text(" is some quantity decreasing at the constant rate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\dot \\tau = -1.")]]

#text("But the scaling is wrong; time has dimension 2 with respect to the Ricci flow scaling, and so the dimension of a variation of a scale-invariant quantity should be -2, while the expression (34) has dimension -4. (Note that f should be dimensionless (up to logarithms), ")#mi("\\tau")#text(" has the same dimension of time, i.e. 2, and ")#mi("\\int_M dm=1")#text(" is of course dimensionless.) So actually we should be looking at")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("2\\tau\\int_M \\left|\\text{Ric} + \\text{Hess}(f) - \\frac{1}{2\\tau} g\\right|_g^2\\ dm.", block: true)]]

#text("To find a functional whose derivative is (36), we expand the integrand as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\left|\\text{Ric} + \\text{Hess}(f) - \\frac{1}{2\\tau} g\\right|_g^2 = \\left|\\text{Ric} + \\text{Hess}(f)\\right|_g^2 - \\frac{1}{\\tau} (R + \\Delta f) + \\frac{d}{4\\tau^2}.", block: true)]]

#text("Using (32) and the normalisation ")#mi("\\int_M\\ dg = 1")#text(", we can thus express (36) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\tau \\frac{d}{dt} {\\mathcal F}_m(M,g) - 2 {\\mathcal F}_m(M,g) + \\frac{d}{2\\tau}.")]]

#text("Using (32) and (35), we can express this as a total derivative:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\frac{d}{dt} (\\tau {\\mathcal F}_m(M,g) - N_m(M,g) + \\frac{d}{2} \\log \\tau).")]]

#text("Thus the quantity in parentheses is monotone increasing in time under Ricci flow (and with f, ")#mi("\\tau")#text(" evolving by (22), (35)).")

#text("In analogy with Example 1, we rewrite the potential function f as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("f = \\tilde f + \\frac{d}{2} \\log(4\\pi \\tau)")]]

#text("then ")#mi("\\tilde f")#text(" obeys the slight variant of (22)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\frac{d}{dt} \\tilde f = -\\Delta f - R + \\frac{d}{2\\tau}")]]

#text("and is related to the fixed measure m by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("dm = (4\\pi \\tau)^{-d/2} e^{-\\tilde f}\\ d\\mu")]]

#text("and the equality between (36) and (39) becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\frac{d}{dt} {\\mathcal W}_m(M,g,\\tau) = 2\\tau\\int_M \\left|\\text{Ric} + \\text{Hess}(\\tilde f) - \\frac{1}{2\\tau} g\\right|_g^2\\ dm", block: true)]]

#text("where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#tao-math("{\\mathcal W}_m(M,g,\\tau) := \\int_M [\\tau(R + \\left|\\nabla \\tilde f\\right|^2) + \\tilde f - d]\\ dm.", block: true)]]

#text("The -d term here is harmless (since m is fixed), and is in place to normalise this expression to vanish in the Euclidean case (Example 1, where now ")#tao-math("\\tilde f(t,x) = \\left|x\\right|^2/4t_0", block: false)#text(").")

#text("As before, it is convenient to conjugate away the diffeomorphism by ")#mi("\\nabla f")#text(" to recover a pure Ricci flow. Define the ")#emph[#text("Perelman entropy")]#text(" ")#mi("{\\mathcal W}(M,g,f,\\tau)")#text(" of a manifold ")#mi("(M,g)")#text(", a scalar function ")#mi("f: M \\to {\\Bbb R}")#text(", and a positive real ")#mi("\\tau > 0")#text(", by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("{\\mathcal W}(M,g,f,\\tau) = \\int_M [\\tau(R + \\left|\\nabla f\\right|^2) + f - d] (4\\pi \\tau)^{-d/2} e^{-f}\\ d\\mu.", block: true)]]

#text("Note that this quantity has dimension 0 (if f is viewed as dimensionless, and ")#mi("\\tau")#text(" given the dimension 2).")

#strong[#text("Exercise 9.")]#text(" Suppose that g evolves by Ricci flow (5), f evolves by the nonlinear backward heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#tao-math("\\dot f = -\\Delta f + \\left|\\nabla f\\right|^2 - R + \\frac{d}{2\\tau},", block: true)]]

#text("and ")#mi("\\tau")#text(" evolves by (35). Show that")

#align(center)[#tao-math("\\displaystyle \\frac{d}{dt} {\\mathcal W}(M,g,f,\\tau) = 2\\tau \\int_M \\left|\\text{Ric} + \\text{Hess}(f) - \\frac{1}{2\\tau} g\\right|_g^2 (4\\pi \\tau)^{-d/2} e^{-f}\\ d\\mu", block: false)#text(". ")#mi("\\diamond")#text(" (47)")]

#text("If we write ")#mi("u := (4\\pi \\tau)^{-d/2} e^{-f}")#text(", show that (46) is also equivalent to the adjoint heat equation")

#align(center)[#mi("\\dot u = - \\Delta u + R u")#text(". ")#mi("\\diamond")#text(" (48)")]

#text("We have thus obtained a scale-invariant monotonicity formula, albeit one which depends on two additional time-varying parameters, f and ")#mi("\\tau")#text(". To eliminate them, the obvious thing to do is to just take the infimum over all f and ")#mi("\\tau")#text("; but we need to be sure that the infimum exists at all. This will be studied next.")

#heading(level: 1)[#text("— Connection to the log-Sobolev inequality —")]

#text("We have just established the monotonicity formula (47) whenever g evolves by Ricci flow (5) and f, ")#mi("\\tau")#text(" evolve by (46), (35). Let us now temporarily specialise to the case when ")#mi("(M,g)")#text(" is a static Euclidean space ")#mi("{\\Bbb R}^d")#text(" (which of course obeys Ricci flow), and ")#mi("\\tau = -t")#text(" (which of course obeys (35)), and now restrict to negative times ")#mi("t < 0")#text(". Now all curvatures ")#mi("R, \\text{Ric}")#text(" vanish, thus for instance by (48) we see that ")#mi("u=(4\\pi \\tau)^{-d/2} e^{-f}")#text(" obeys the free backwards heat equation ")#mi("\\dot u = - \\Delta u")#text(". We will normalise ")#mi("dm = u\\ d\\mu")#text(" to be a probability measure, thus ")#mi("\\int_{{\\Bbb R}^d} u\\ dx = 1")#text(".")

#strong[#text("Example 4.")]#text(" The key example to keep in mind here is ")#tao-math("f(t,x) = \\left|x\\right|^2/4\\tau", block: false)#text(", in which case u becomes the backwards heat kernel ")#tao-math("u(t,x) = (4\\pi \\tau)^{-d/2} e^{-\\left|x\\right|^2/4\\tau}", block: false)#text(". ")#mi("\\diamond")

#text("We can now re-express the functional (45) in terms of u as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("{\\mathcal W}(M,g,f,\\tau) = \\int_{{\\Bbb R}^d} (\\tau \\frac{\\left|\\nabla u\\right|^2}{u} - u \\log u)\\ dx - \\frac{d}{2} \\log(4\\pi \\tau) - d.", block: true)]]

#text("One easily verifies by direct calculation that this expression vanishes in the model case of Example 4. For more general u, we know that this quantity is monotone increasing in time, and so")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("{\\mathcal W}(M,g,f,\\tau)(t) \\geq \\lim_{t \\to -\\infty} {\\mathcal W}(M,g,f,\\tau)(t).")]]

#text("Now suppose u is some non-negative test function ")#mi("u_0(x)")#text(" at time zero with total mass 1, then from the fundamental solution for the backwards heat equation we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#tao-math("u(t,x) = \\frac{1}{(4\\pi \\tau)^{d/2}} \\int_{{\\Bbb R}^d} e^{-\\left|x-y\\right|^2/4\\tau} u_0(y)\\ dy = \\frac{1}{(4\\pi \\tau)^{d/2}} \\tilde u( t, x/\\sqrt{\\tau} )", block: true)]]

#text("where ")#mi("\\tilde u")#text(" is the renormalised solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#tao-math("\\tilde u(t, x) := \\int_{{\\Bbb R}^d} e^{-\\left|x - (y/\\sqrt{\\tau})\\right|^2 / 4} u_0(y)\\ dy.", block: true)]]

#text("Observe that ")#mi("\\tilde u(t,x)")#text(" converges pointwise to ")#tao-math("e^{-\\left|x\\right|^2/4}", block: false)#text(" as ")#mi("t \\to -\\infty")#text(" for fixed x. Thus in some renormalised sense this general solution is converging to the model solution in Example 3 in the limit ")#mi("t \\to -\\infty")#text(".")

#text("We can rewrite the functional (49) after some calculation as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#tao-math("{\\mathcal W}(M,g,f,\\tau) = \\int_{{\\Bbb R}^d} [\\tau \\frac{\\left|\\nabla \\tilde u\\right|^2}{\\tilde u^2} - \\log \\tilde u] (-4\\pi)^{-d/2} \\tilde u\\ dx - d.", block: true)]]

#text("One can check that ")#mi("\\nabla \\tilde u")#text(" is converging pointwise to ")#tao-math("\\nabla e^{-\\left|x\\right|^2/4}", block: false)#text(". A careful application of dominated convergence then shows that in the limit ")#mi("t \\to -\\infty")#text(", (53) converges to the value attained in Example 3, i.e. zero. By the monotonicity formula, we have thus demonstrated that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("{\\mathcal W}(M,g,f,\\tau) \\geq 0")]]

#text("for all times ")#mi("-\\infty < t < 0")#text(". Writing ")#mi("u = \\phi^2")#text(" and rearranging (49), we conclude the ")#emph[#text("log-Sobolev inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(55)")])
#tao-math("2\\int_{{\\Bbb R}^d} \\phi^2 \\log \\phi\\ dx \\leq 4\\tau \\int_{{\\Bbb R}^d} \\left|\\nabla \\phi\\right|^2\\ dx - \\frac{d}{2} \\log(4 \\pi \\tau) - d", block: true)]]

#text("valid whenever ")#mi("\\tau > 0")#text(" and ")#mi("\\int_{{\\Bbb R}^d} \\phi^2\\ dx = 1")#text(".")

#strong[#text("Exercise 10. ")]#text("By letting ")#tao-math("dm := (4\\pi \\tau)^{-d/2} e^{-\\left|x\\right|^2/4\\tau} dx", block: false)#text(" be standard Gaussian measure and writing ")#mi("u dx = F^2 dm")#text(", deduce the original log-Sobolev inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(56)")])
#tao-math("\\int_{{\\Bbb R}^d} F^2 \\log F^2\\ dm \\leq \\tau \\int_{{\\Bbb R}^d} \\left|\\nabla F\\right|^2 dm", block: true)]]

#link("http://www.ams.org/mathscinet-getitem?mr=420249")[#text("of Gross")]#text(", valid whenever ")#mi("\\tau > 0")#text(" and ")#mi("\\int_{{\\Bbb R}^d} F^2\\ dm = 1")#text(". [One key feature of this inequality, as compared to more traditional Sobolev inequalities, is that it is almost completely independent of the dimension d.] ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" We have seen how knowledge of the heat kernel can lead to log-Sobolev inequalities, by evolving by the (backwards) heat flow (this is an example of the ")#emph[#text("semigroup method")]#text(" for proving inequalities). This connection can in fact be reversed, using log-Sobolev inequalities to deduce information about heat kernels. Heat kernels can in turn be used to deduce ordinary Sobolev estimates, which then imply log-Sobolev estimates by convexity inequalities such as Hölder’s inequality, thus showing that all these phenomena are morally equivalent. There is a vast literature on these subjects (and other related topics, such as hypercontractivity); so much so that there are not only multiple surveys on the subject, but even a ")#link("http://www.ams.org/mathscinet-getitem?mr=2325763")[#text("survey of all the surveys")]#text(". ")#mi("\\diamond")

#text("We now return to the case of general Ricci flows (not just the Euclidean one).")

#strong[#text("Exercise 11.")]#text(" Let (M,g) be a compact Riemannian manifold, and let ")#mi("\\tau > 0")#text(". Using the Euclidean log-Sobolev inequality (48), show that we have a lower bound of the form ")#mi("{\\mathcal W}(M,g,f,\\tau) \\geq - C(M,g,\\tau)")#text(" for all functions f with ")#mi("\\int (4\\pi \\tau)^{-d/2} e^{-f}\\ d\\mu = 1")#text(". Show in fact that ")#mi("C(M,g,\\tau)")#text(" can be chosen to depend only on ")#mi("\\tau")#text(", the dimension, an upper bound for the magnitude of the RIemann curvature, and a lower bound for the injectivity radius. Using a rescaling and compactness argument, show also that we can take ")#mi("C(M,g,\\tau) \\to 0")#text(" as ")#mi("\\tau \\to 0")#text(". (Details can be found in Section 3.1 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(".) ")#mi("\\diamond")

#text("We can now define the quantity ")#mi("\\mu(M,g,\\tau)")#text(" to be the infimum of ")#mi("{\\mathcal W}(M,g,f,\\tau)")#text(" for all functions f with ")#mi("\\int (4\\pi \\tau)^{-d/2} e^{-f}\\ d\\mu = 1")#text("; thus ")#mi("\\mu(M,g,\\tau)")#text(" is non-decreasing if we evolve ")#mi("\\tau")#text(" by (35). Thus we have obtained a one-parameter family of dimensionless monotone quantities (recalling that ")#mi("\\tau")#text(" has dimension 2 with respect to scaling).")

#strong[#text("Remark 4.")]#text(" One can interpret ")#mi("\\mu(M,g,\\tau)")#text(" as a nonlinear analogue of the eigenvalue ")#mi("\\lambda(M,g)")#text(". Indeed, just as ")#mi("\\lambda(M,g)")#text(" is the least number ")#mi("\\lambda")#text(" for which one can solve the linear eigenfunction equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(57)")])
#mitex("(4\\Delta + R) \\Phi = \\lambda \\Phi")]]

#text("subject to the constraint ")#mi("\\int_M \\Phi^2 = 1")#text(", ")#mi("\\mu(M,g,\\tau)")#text(" is the least number ")#mi("\\mu")#text(" for which one can solve the nonlinear eigenfunction equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(58)")])
#mitex("\\tau (4\\Delta+R) \\Phi = 2 \\Phi \\log \\Phi + (\\mu+d) \\Phi")]]

#text("subject to the constraints ")#mi("\\Phi > 0")#text(" and ")#mi("\\int_M (4\\pi \\tau)^{-d/2} \\Phi^2\\ d\\mu = 1")#text(". In particular we expect ")#mi("\\mu(M,g,\\tau)")#text(" to behave roughly like ")#mi("\\tau \\lambda(M,g)")#text(" in the limit ")#mi("\\tau \\to \\infty")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 12. ")]#text("Show that the only shrinking breathers (those in which ")#mi("(M,g(t))")#text(" is isometric to a contraction of ")#mi("(M,g(0))")#text(" for some ")#mi("t>0")#text(") are the gradient shrinking solitons. ")#mi("\\diamond")

#heading(level: 1)[#text("— Non-collapsing —")]

#text("We now relate log-Sobolev inequalities (i.e. lower bounds on ")#mi("\\mu(M,g,\\tau)")#text(") to non-collapsing. We first note that by substituting ")#mi("(4\\pi \\tau)^{-d/2} e^{-f} = \\phi^2")#text(" into (45) as in the Euclidean case, that we have the log-Sobolev inequality")

#tao-aligned(keep: true)[


#tao-math("\\int_{M} \\phi^2 \\log \\phi^2\\ d\\mu  & \\leq 4\\tau \\int_{M} \\left|\\nabla \\phi\\right|_g^2\\ d\\mu", block: true)



#tao-math(" & + \\tau \\int_M R \\left|\\phi\\right|^2\\ d\\mu - \\frac{d}{2} \\log(4 \\pi \\tau) - d - \\mu(M,g,\\tau)", block: true, numbering: n => [#text("(59)")])
]

#text("whenever ")#mi("\\phi")#text(" is non-negative with ")#mi("\\int_M \\phi^2\\ d\\mu = 1")#text(".")

#text("To use this, suppose we have a ball ")#mi("B = B(p,\\sqrt{\\tau})")#text(" which has bounded normalised curvature, so in particular ")#mi("R = O( \\tau^{-1} )")#text(" on this ball.")#linebreak()#text(" On the other hand, if ")#mi("\\phi")#text(" is supported on B with ")#mi("L^2")#text(" mass 1, then from ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("\\int_{M} \\phi^2 \\log \\phi^2\\ d\\mu \\geq \\log \\frac{1}{\\text{Vol}(B)}")]]

#text("and we thus conclude from (59) that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(60)")])
#tao-math("\\log \\frac{\\tau^{d/2}}{\\text{Vol}} \\leq 4 \\tau \\int_M \\left|\\nabla \\phi\\right|_g^2 + O(1) - \\mu(M,g,\\tau).", block: true)]]

#text("If we let ")#mi("\\phi(x) := c \\psi( d(x,p) / \\sqrt{\\tau} )")#text(", where ")#mi("\\psi")#text(" is a bump function that equals 1on [-1/2,1/2] and is supported on [-1,1] (thus ")#mi("\\phi=c")#text(" on the ball ")#mi("B_{1/2} := B( p, \\sqrt{\\tau}/2 )")#text(", and ")#mi("c \\leq 1/\\text{Vol}(B_{1/2})^{1/2}")#text(" is the normalisation constant needed to ensure that ")#mi("\\phi")#text(" has ")#mi("L^2")#text(" mass one, then ")#mi("\\nabla \\phi = O( c / \\sqrt{\\tau} )")#text(" on this ball, and so we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(61)")])
#mitex("\\log \\frac{\\tau^{d/2}}{\\text{Vol}(B)} \\leq O( \\text{Vol}( B ) / \\text{Vol}( B_{1/2} ) ) - \\mu(M,g,\\tau).")]]

#text("At this point we need to invoke the relative ")#link("http://en.wikipedia.org/wiki/Bishop-Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(" from comparison geometry, which among other things ensures that ")#mi("\\text{Vol}(B) = O( \\text{Vol}(B_{1/2})")#text(" under the assumption of bounded normalised curvature. Indeed, from equations (15) and (17) from the previous lecture we see that ")#mi("{\\mathcal L}_{\\partial_r}\\ d\\mu = O( 1/r )\\ d\\mu")#text(" inside the ball of radius ")#mi("1/\\sqrt{\\tau}")#text(", from which the claim easily follows within the radius of injectivity. (To generalise the inequality beyond this region, one simply works on the region inside the ")#link("http://en.wikipedia.org/wiki/Cut_locus_(Riemannian_manifold)")[#text("cut locus")]#text(", which is star-shaped around the origin in ")#mi("T_p M")#text(".)")

#text("Using this inequality, we thus conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(62)")])
#mitex("\\text{Vol}(B) \\gg \\tau^{d/2} \\exp( \\mu( M,g,\\tau) ).")]]

#text("Thus a lower bound on ")#mi("\\mu(M,g,\\tau)")#text(" enforces non-collapsing of volume at scale ")#mi("\\tau")#text(".")

#strong[#text("Exercise 13.")]#text(" Use (62), Exercise 11 and the monotonicity properties of ")#mi("\\mu(M,g,\\tau)")#text(" to establish ")#mi("\\kappa")#text("-noncollapsing of Ricci flows (Theorem 2 from the ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("previous lecture")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 5. ")]#text("This argument in fact establishes a stronger form of non-collapsing, in which in order to get non-collapsing at time ")#mi("t_0")#text(" and scale ")#mi("r_0")#text(", one only needs bounded normalised curvature at time ")#mi("t_0")#text(" (instead of on the time interval ")#mi("{}[t_0-r_0^2,t_0]")#text("). It also works in arbitrary dimension. The second proof of non-collapsing that we will give, based on the Perelman reduced volume instead of Perelman entropy, needs the spacetime bounded normalised curvature assumption but also works in arbitrary dimension. ")#mi("\\diamond")

#strong[#text("Remark 6. ")]#text("The parameter ")#mi("\\kappa")#text(" in the above result, which measures the quality of the non-collapsing, will deteriorate with time T. This is because the decay of ")#mi("\\tau")#text(" from (35) entails that in order to get non-collapsing of the manifold at time ")#mi("t_0")#text(" and scale ")#mi("r_0")#text(", one needs some non-collapsing at time zero and scale ")#mi("\\sqrt{r_0 + t_0^2}")#text(". Of course, since the manifold is initially compact, one always has some non-collapsing at each scale, but the quantitative constants associated to this non-collapsing will deteriorate as the scale increases, which will happen when T increases. Fortunately (and especially in view of our finite time extinction results) we only need to analyse Ricci flow on compact (though potentially rather large) time intervals ")#mi("{}[0,T]")#text(". ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" It was recently shown ")#link("http://arxiv.org/abs/0706.1594")[#text("by Zhang")]#text(" that the monotonicity properties of the quantities ")#mi("\\mu(M,g,\\tau)")#text(" also hold for Ricci flows with surgery. This should enable one to completely replace all applications of Perelman reduced volume in the existing proof of the Poincaré conjecture in the literature by Perelman (as well as in the expositions of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(", ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(", and ")#link("http://arxiv.org/abs/math/0607607")[#text("Morgan-Tian")]#text(") by Perelman entropy, which may lead to a shorter proof overall (although one still needs the Perelman reduced length for another purpose, namely to control the geometry of ancient non-collapsed Ricci flows). However, we shall mostly follow the original arguments of Perelman in this course. ")#mi("\\diamond")

#strong[#text("Remark 8. ")]#text("The above entropy functionals are also useful for studying the forward or backward heat equation on a static Riemannian manifold ")#mi("(M,g)")#text(" (basically, one keeps the heat-type equations for u or f but now replace Ricci flow by the trivial flow ")#mi("\\dot g = 0")#text("). However, some sign assumptions on curvature are now needed to recover the same type of monotonicity results. See this ")#link("http://www.ams.org/mathscinet-getitem?mr=2030576")[#text("paper of Ni")]#text(" for details. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", April 25: some corrections.]")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29326")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("Minor typo: 285A, in the title, should be 285G")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29335")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("A few little typos:")

#text("The equations are not uniquely numbered from 46 to 49. The exercises are not uniquely numbered from 9 to 10.")

#text("Some parentheses would be useful in equations 32 and (the second) 46.")

#text("In Exercise 5, Remark 1, and (the second) Exercise 9, I think you want to say “isometric” instead of “diffeomorphic.”")

#text("At the beginning of the “non-collapsing” section, there is a reference to equation 35 that doesn’t make sense. Perhaps you meant 45?")

#text("Finally, there is a typo in equation 53, and I also think that the sign on ")#mi("\\mu")#text(" is wrong (and persists in later equations).")

#text("Thank you for the lucid discussion of the Perelman entropy (and related topics).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29393")[#strong[#text("285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2008")])]

#text("[…] the volume comparison result whenever one has bounded normalised curvature, which was used in the previous lecture; indeed, thanks to the above inequality, it suffices to prove the claim for model […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29684")[#strong[#text("285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2008")])]

#text("[…] that . Note that this fact implies the monotonicity of Perelman reduced volume (cf. Exercise 2 from Lecture 8). [It seems that the elliptic analogue of this fact is the assertion that the Newton-type potential […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29835")[#strong[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("[…] 16 May, 2008 in 285G – poincare conjecture, math.DG by Terence Tao Tags: canonical neighbourhoods, compactness and contradiction, gradient shrinking solitons, kappa-solutions In previous lectures, we have established (modulo some technical details) two significant components of the proof of the Poincaré conjecture: finite time extinction of Ricci flow with surgery (Theorem 4 of Lecture 2), and a -noncollapsing of Ricci flows with surgery (which, except for the surgery part, is Theorem 2 of Lecture 7). Now we come to the heart of the entire argument: the topological and geometric control of the high curvature regions of a Ricci flow, which is absolutely essential in order for one to define surgery on these regions in order to move the flow past singularities. This control is intimately tied to the study of a special type of Ricci flow, the -solutions to the Ricci flow equation; we will be able to use compactness arguments (as well as the -noncollapsing results already obtained) to deduce control of high curvature regions of arbitrary Ricci flows from similar control of -solutions. A secondary compactness argument lets us obtain that control of -solutions from control of an even more special type of solution, the gradient shrinking solitons that we already encountered in Lecture 8. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-29889")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] 2 from Lecture 7. Of course, we already proved (a stronger version) of this theorem already in Lecture 8, using the Perelman entropy, but this second proof is also important, because the reduced volume is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-30084")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] 2. If (M,g) is Hamilton’s cigar (Example 3 from Lecture 8), and is a sequence on M tending to infinity, then converges geometrically to the pointed round […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-30205")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("[…] shift time so that the volume is in fact equal to , and consider the Perelman entropy defined in Lecture 8. Testing this entropy with ) we obtain an upper bound . On the other hand, on the sequence of times […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f61d02769df1e2d61422f4e2f00a6e35f5ac4d976ead7fc4340704c946d18778-c597499ac61ab82755b7aaeaed7cdfac0a6fb3673f9d9a6e5a507732a74d7203.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-454388")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2015")])]

#text("One typo:")#linebreak()#text(" The modified laplacian after the sentence")#linebreak()#text(" “that it is the least eigenvalue of the self-adjoint modified Laplacian”")#linebreak()#text(" should be ")#mi("-4 \\Delta + R")

#text("Thanks for all the useful posts.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-485921")[#strong[#text("Energies, gradient flows, and large deviations: a modelling point of view | Franca Hoffmann's Homepage")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")]

#text("[…] are keen to know the connection between gradient flows and the Poincaré conjecture, have a look at this blog post by Terence Tao. You may also get a glimpse at some of Perelman’s ideas that helped solve […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f488fe5eb54fd5f29b04e1bf41351463f874c62757cde145654e7d57e06b22ec-0a389555b8d0d1f1416a90086e1b6bb1c789840b749168d1c9db61c3bfd86312.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AC")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-623008")[#strong[#text("AC")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2021")])]

#text("Hi, Prof. Tao. Does example 2 and (the first sentence of) example 3 together suggest that the Euclidean space R^n can be viewed as both a steady and shrinking gradient soliton? Thanks.")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-673803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2023")])]

#text("I believe ")#mi("\\frac{1}{\\tau}")#text(" should be ")#mi("\\tau")#text(" in inequality (56) since the right hand side has to be scale invariant.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/#comment-675543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2023")])]

#text("The second line below formula (29) wrote “f need not evolve via (25)” should it be (24) instead of (25) since (25) is not an evolution equation?")
]
