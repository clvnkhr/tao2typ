// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:39:12.523202+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An abridged proof of Marton’s conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An abridged proof of Marton’s conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 June 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/")[#text("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This post is dedicated to ")#link("https://lucatrevisan.github.io/")[#text("Luca Trevisan")]#text(", who ")#link("https://windowsontheory.org/2024/06/19/luca-trevisan-1971-2024/")[#text("recently passed away")]#text(" due to cancer. Though far from his most significant contribution to the field, I would like to mention that, as with most of my other blog posts on this site, this page was written with the assistance of Luca’s ")#link("https://lucatrevisan.wordpress.com/latex-to-wordpress/using-latex2wp/")[#text("LaTeX to WordPress converter")]#text(". Mathematically, his work and insight on pseudorandomness in particular have greatly informed how I myself think about the concept. – T.]")]

#text("Recently, ")#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")[#text("Timothy Gowers, Ben Green, Freddie Manners, and I")]#text(" were able to establish the following theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Marton’s conjecture)")]#text(" ")#metadata(none) <tao-2cf3ad35047e38f8eb42>#text(" Let ")#mi("{A \\subset {\\bf F}_2^n}")#text(" be non-empty with ")#tao-math("{\\left|A+A\\right| \\leq K\\left|A\\right|}", block: false)#text(". Then there exists a subgroup ")#mi("{H}")#text(" of ")#mi("{{\\bf F}_2^n}")#text(" with ")#tao-math("{\\left|H\\right| \\leq \\left|A\\right|}", block: false)#text(" such that ")#mi("{A}")#text(" is covered by at most ")#mi("{2K^C}")#text(" translates of ")#mi("{H}")#text(", for some absolute constant ")#mi("{C}")#text(".")
]

#text("We established this result with ")#mi("{C=12}")#text(", although it has since been improved to ")#mi("{C=9}")#text(" ")#link("https://arxiv.org/abs/2404.09639")[#text("by Jyun-Jie Liao")]#text(".")

#text("Our proof was written in order to optimize the constant ")#mi("{C}")#text(" as much as possible; similarly for the more detailed ")#link("https://teorth.github.io/pfr/blueprint/")[#text("blueprint of the proof")]#text(" that was prepared in order to formalize the result in Lean. I have been asked a few times whether it is possible to present a streamlined and more conceptual version of the proof in which one does not try to establish an explicit constant ")#mi("{C}")#text(", but just to show that the result holds for some constant ")#mi("{C}")#text(". This is what I will attempt to do in this post, though some of the more routine steps will be outsourced to the aforementioned blueprint.")

#text("The key concept here is that of the ")#emph[#text("entropic Ruzsa distance")]#text(" ")#mi("{d[X;Y]}")#text(" between two random variables ")#mi("{X,Y}")#text(" taking values ")#mi("{{\\bf F}_2^n}")#text(", defined as")

#align(center)[#tao-fit-display[#mitex("d[X;Y] := {\\mathbf H}[X^{\\prime}+Y^{\\prime}] - \\frac{1}{2} {\\mathbf H}[X] - \\frac{1}{2} {\\mathbf H}[Y]")]]

#text("where ")#mi("{X^{\\prime},Y^{\\prime}}")#text(" are independent copies of ")#mi("{X,Y}")#text(", and ")#mi("{{\\mathbf H}[X]}")#text(" denotes the Shannon entropy of ")#mi("{X}")#text(". This distance is symmetric and non-negative, and obeys the triangle inequality")

#align(center)[#tao-fit-display[#mitex("d[X;Z] \\leq d[X;Y] + d[Y;Z]")]]

#text("for any random variables ")#mi("{X,Y,Z}")#text("; see ")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-triangle")[#text("the blueprint")]#text(" for a proof. The above theorem then follows from an entropic analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Entropic Marton’s conjecture)")]#text(" ")#metadata(none) <tao-6e4b16e5625e14c7444a>#text(" Let ")#mi("{X}")#text(" be a ")#mi("{{\\bf F}_2^n}")#text("-valued random variable with ")#mi("{d[X;X] \\leq \\log K}")#text(". Then there exists a uniform random variable ")#mi("{U_H}")#text(" on a subgroup ")#mi("{H}")#text(" of ")#mi("{{\\bf F}_2^n}")#text(" such that ")#mi("{d[X; U_H] \\leq C \\log K}")#text(" for some absolute constant ")#mi("{C}")#text(".")
]

#text("We were able to establish Theorem ")#link(<tao-6e4b16e5625e14c7444a>)[#text("2")]#text(" with ")#mi("{C=11}")#text(", which implies Theorem ")#link(<tao-2cf3ad35047e38f8eb42>)[#text("1")]#text(" with ")#mi("{C=12}")#text(" by fairly standard additive combinatorics manipulations (such as the Ruzsa covering lemma); see ")#link("https://teorth.github.io/pfr/blueprint/sect0007.html#pfr")[#text("the blueprint for details")]#text(".")

#text("The key proposition needed to establish Theorem ")#link(<tao-6e4b16e5625e14c7444a>)[#text("2")]#text(" is the following distance decrement property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Distance decrement)")]#text(" ")#metadata(none) <tao-dddbfcddab1e53247f4b>#text(" If ")#mi("{X,Y}")#text(" are ")#mi("{{\\bf F}_2^n}")#text("-valued random variables, then one can find ")#mi("{{\\bf F}_2^n}")#text("-valued random variables ")#mi("{X^{\\prime},Y^{\\prime}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime};Y^{\\prime}] \\leq (1-\\eta) d[X;Y]")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d[X;X^{\\prime}], d[Y,Y^{\\prime}] \\leq C d[X;Y]")]]

#text("for some absolute constants ")#mi("{C, \\eta > 0}")#text(".")
]

#text("Indeed, suppose this proposition held. Starting with ")#mi("{X,Y}")#text(" both equal to ")#mi("{X}")#text(" and iterating, one can then find sequences of random variables ")#mi("{X_n, Y_n}")#text(" with ")#mi("{X_0=Y_0=X}")#text(",")

#align(center)[#tao-fit-display[#mitex("d[X_n;Y_n] \\leq (1-\\eta)^n d[X;X],")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d[X_{n+1};X_n], d[Y_{n+1};Y_n] \\leq C (1-\\eta)^n d[X;X].")]]

#text("In particular, from the triangle inequality and geometric series")

#align(center)[#tao-fit-display[#mitex("d[X_n;X], d[Y_n;X] \\leq \\frac{C}{\\eta} d[X;X].")]]

#text("By weak compactness, some subsequence of the ")#mi("{X_n}")#text(", ")#mi("{Y_n}")#text(" converge to some limiting random variables ")#mi("{X_\\infty, Y_\\infty}")#text(", and by some simple continuity properties of entropic Ruzsa distance, we conclude that")

#align(center)[#tao-fit-display[#mitex("d[X_\\infty;Y_\\infty] = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d[X_\\infty;X], d[Y_\\infty;X] \\leq \\frac{C}{\\eta} d[X;X].")]]

#text("Theorem ")#link(<tao-6e4b16e5625e14c7444a>)[#text("2")]#text(" then follows from the “100% inverse theorem” for entropic Ruzsa distance; see ")#link("https://teorth.github.io/pfr/blueprint/sect0004.html")[#text("the blueprint for details")]#text(".")

#text("To prove Proposition ")#link(<tao-dddbfcddab1e53247f4b>)[#text("3")]#text(", we can reformulate it as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Lack of distance decrement implies vanishing)")]#text(" ")#metadata(none) <tao-6f57299cfbe42bc2bf1d>#text(" If ")#mi("{X,Y}")#text(" are ")#mi("{{\\bf F}_2^n}")#text("-valued random variables, with the property that")

#metadata(none) <tao-0ab2dd2f64c9fd4e4310>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("d[X^{\\prime};Y^{\\prime}] > d[X;Y] - \\eta ( d[X;Y] + d[X^{\\prime};X] + d[Y^{\\prime},Y] )")]]

#text("for all ")#mi("{{\\bf F}_2^n}")#text("-valued random variables ")#mi("{X^{\\prime},Y^{\\prime}}")#text(" and some sufficiently small absolute constant ")#mi("{\\eta > 0}")#text(", then one can derive a contradiction.")
]

#text("Indeed, we may assume from the above proposition that")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime};Y^{\\prime}] \\leq d[X;Y] - \\eta ( d[X; Y] + d[X^{\\prime};X] + d[Y^{\\prime},Y] )")]]

#text("for some ")#mi("{X^{\\prime},Y^{\\prime}}")#text(", which will imply Proposition ")#link(<tao-dddbfcddab1e53247f4b>)[#text("3")]#text(" with ")#mi("{C = 1/\\eta}")#text(".")

#text("The entire game is now to use Shannon entropy inequalities and “entropic Ruzsa calculus” to deduce a contradiction from ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(1)")]#text(" for ")#mi("{\\eta}")#text(" small enough. This we will do below the fold, but before doing so, let us first make some adjustments to ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(1)")]#text(" that will make it more useful for our purposes. Firstly, because conditional entropic Ruzsa distance (see ")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#cond-dist-def")[#text("blueprint")]#text(" for definitions) is an average of unconditional entropic Ruzsa distance, we can automatically upgrade ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(1)")]#text(" to the conditional version")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime}|Z;Y^{\\prime}|W] \\geq d[X;Y] - \\eta ( d[X;Y] + d[X^{\\prime}|Z;X] + d[Y^{\\prime}|W;Y] )")]]

#text("for any random variables ")#mi("{Z,W}")#text(" that are possibly coupled with ")#mi("{X^{\\prime},Y^{\\prime}}")#text(" respectively. In particular, if we define a “relevant” random variable ")#mi("{X^{\\prime}}")#text(" (conditioned with respect to some auxiliary data ")#mi("{Z}")#text(") to be a random variable for which")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime}|Z;X] = O( d[X;Y] )")]]

#text("or equivalently (by the triangle inequality)")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime}|Z;Y] = O( d[X;Y] )")]]

#text("then we have the useful lower bound")

#metadata(none) <tao-aa553fca74950f72b4d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d[X^{\\prime}|Z;Y^{\\prime}|W] \\geq (1-O(\\eta)) d[X;Y]")]]

#text("whenever ")#mi("{X^{\\prime}}")#text(" and ")#mi("{Y^{\\prime}}")#text(" are relevant conditioning on ")#mi("{Z, W}")#text(" respectively. This is quite a useful bound, since the laws of “entropic Ruzsa calculus” will tell us, roughly speaking, that virtually any random variable that we can create from taking various sums of copies of ")#mi("{X,Y}")#text(" and conditioning against other sums, will be relevant. (Informally: the space of relevant random variables is ")#mi("{(1-O(\\eta))d[X;Y]}")#text("-separated with respect to the entropic Ruzsa distance.)")

#heading(level: 1)[#strong[#text(" — 1. Main argument — ")]]

#text("Now we derive more and more consequences of ")#link(<tao-aa553fca74950f72b4d3>)[#text("(2)")]#text(" – at some point crucially using the hypothesis that we are in characteristic two – before we reach a contradiction.")

#text("Right now, our hypothesis ")#link(<tao-aa553fca74950f72b4d3>)[#text("(2)")]#text(" only supplies lower bounds on entropic distances. The crucial ingredient that allows us to proceed is what we call the ")#emph[#text("fibring identity")]#text(", which lets us convert these lower bounds into useful upper bounds as well, which in fact match up very nicely when ")#mi("{\\eta}")#text(" is small. Informally, the fibring identity captures the intuitive fact that the doubling constant of a set ")#mi("{A}")#text(" should be at least as large as the doubling constant of the image ")#mi("{\\pi(A)}")#text(" of that set under a homomorphism, times the doubling constant of a typical fiber ")#mi("{A \\cap \\pi^{-1}(\\{z\\})}")#text(" of that homomorphism; and furthermore, one should only be close to equality if the fibers “line up” in some sense.")

#text("Here is the fibring identity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Fibring identity)")]#text(" ")#metadata(none) <tao-1ade283448135c268e70>#text(" Let ")#mi("{\\pi: G \\rightarrow H}")#text(" be a homomorphism. Then for any independent ")#mi("{G}")#text("-valued random variables ")#mi("{X, Y}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("d[X;Y]  & = d[\\pi(X); \\pi(Y)] + d[X|\\pi(X); Y|\\pi(Y)]", block: true)



#tao-math(" & + I[X-Y : \\pi(X),\\pi(Y) | \\pi(X)-\\pi(Y) ].", block: true)
]
]

#text("The proof is of course ")#link("https://teorth.github.io/pfr/blueprint/sect0005.html#fibring-ident")[#text("in the blueprint")]#text(", but given that it is a central pillar of the argument, I reproduce it here.")

#emph[#text("Proof:")]#text(" Expanding out the definition of Ruzsa distance, and using the ")#link("https://en.wikipedia.org/wiki/Conditional_entropy#Chain_rule")[#text("conditional entropy chain rule")]

#align(center)[#tao-fit-display[#mitex("{\\mathbf H}[X] = {\\mathbf H}[\\pi(X)] + {\\mathbf H}[X|\\pi(X)]")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathbf H}[Y] = {\\mathbf H}[\\pi(Y)] + {\\mathbf H}[Y|\\pi(Y)],")]]

#text("it suffices to establish the identity")

#tao-aligned(keep: true)[


#tao-math("{\\mathbf H}[X-Y]  & = {\\mathbf H}[\\pi(X)-\\pi(Y)] + {\\mathbf H}[X - Y|\\pi(X), \\pi(Y)]", block: true)



#tao-math(" & + I[X-Y : \\pi(X),\\pi(Y) | \\pi(X)-(Y) ].", block: true)
]

#text("But from the chain rule again we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbf H}[X-Y] = {\\mathbf H}[\\pi(X)-\\pi(Y)] + {\\mathbf H}[X - Y|\\pi(X)-\\pi(Y)]")]]

#text("and from the definition of ")#link("https://en.wikipedia.org/wiki/Conditional_mutual_information")[#text("conditional mutual information")]#text(" (using the fact that ")#mi("{\\pi(X)-\\pi(Y)}")#text(" is determined both by ")#mi("{X-Y}")#text(" and by ")#mi("{(\\pi(X),\\pi(Y))}")#text(") one has")

#tao-aligned(keep: true)[


#tao-math("{\\mathbf H}[X - Y|\\pi(X)-\\pi(Y)]  & = {\\mathbf H}[X - Y|\\pi(X), \\pi(Y)]", block: true)



#tao-math(" & + I[X-Y : \\pi(X),\\pi(Y) | \\pi(X)-(Y) ]", block: true)
]

#text("giving the claim. ")#mi("\\Box")

#text("We will only care about the characteristic ")#mi("{2}")#text(" setting here, so we will now assume that all groups involved are ")#mi("{2}")#text("-torsion, so that we can replace all subtractions with additions. If we specialize the fibring identity to the case where ")#mi("{G = {\\bf F}_2^n \\times {\\bf F}_2^n}")#text(", ")#mi("{H = {\\bf F}_2^n}")#text(", ")#mi("{\\pi: G \\rightarrow H}")#text(" is the addition map ")#mi("{\\pi(x,y) = x+y}")#text(", and ")#mi("{X = (X_1, X_2)}")#text(", ")#mi("{Y = (Y_1, Y_2)}")#text(" are pairs of independent random variables in ")#mi("{{\\bf F}_2^n}")#text(", we obtain the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-e77c4b3f81059b97c4d2>#text(" Let ")#mi("{X_1,X_2,Y_1,Y_2}")#text(" be independent ")#mi("{{\\bf F}_2^n}")#text("-valued random variables. Then we have the identity")

#tao-aligned(keep: true)[


#tao-math("d[X_1;Y_1] + d[X_2;Y_2]  & = d[X_1+X_2;Y_1+Y_2]", block: true)



#tao-math(" & + d[X_1|X_1+X_2;Y_1|Y_1+Y_2]", block: true)



#tao-math(" & + I[(X_1+Y_1, X_2+Y_2) : (X_1+X_2,Y_1+Y_2) | X_1+X_2+Y_1+Y_2 ].", block: true)
]
]

#text("This is a useful and flexible identity, especially when combined with ")#link(<tao-aa553fca74950f72b4d3>)[#text("(2)")]#text(". For instance, we can discard the conditional mutual information term as being non-negative, to obtain the inequality")

#tao-aligned(keep: true)[


#tao-math("d[X_1;Y_1] + d[X_2;Y_2]  & \\geq d[X_1+X_2;Y_1+Y_2]", block: true)



#tao-math(" & + d[X_1|X_1+X_2;Y_1|Y_1+Y_2].", block: true)
]

#text("If we let ")#mi("{X_1, Y_1, X_2, Y_2}")#text(" be independent copies of ")#mi("{X, Y, Y, X}")#text(" respectively (note the swap in the last two variables!) we obtain")

#align(center)[#tao-fit-display[#mitex("2 d[X;Y] \\geq d[X+Y;X+Y] + d[X_1|X_1+X_2;Y_1|Y_1+Y_2].")]]

#text("From entropic Ruzsa calculus, one can check that ")#mi("{X+Y}")#text(", ")#mi("{X_1|X_1+X_2}")#text(", and ")#mi("{Y_1|Y_1+Y_2}")#text(" are all relevant random variables, so from ")#link(<tao-aa553fca74950f72b4d3>)[#text("(2)")]#text(" we now obtain both upper and lower bounds for ")#mi("{d[X+Y;X+Y]}")#text(":")

#align(center)[#tao-fit-display[#mitex("d[X+Y; X+Y] = (1 + O(\\eta)) d[X;Y].")]]

#text("A pleasant upshot of this is that we now get to work in the symmetric case ")#mi("{X=Y}")#text(" without loss of generality. Indeed, if we set ")#mi("{X^* := X+Y}")#text(", we now have from ")#link(<tao-aa553fca74950f72b4d3>)[#text("(2)")]#text(" that")

#metadata(none) <tao-e9e9ba8db7027b0365e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("d[X^{\\prime}|Z; Y^{\\prime}|W] \\geq (1-O(\\eta)) d[X^*;X^*]")]]

#text("whenever ")#mi("{X^{\\prime}|Z, Y^{\\prime}|W}")#text(" are relevant, which by entropic Ruzsa calculus is equivalent to asking that")

#align(center)[#tao-fit-display[#mitex("d[X^{\\prime}|Z; X^*], d[Y^{\\prime}|W; X^*] = O(d[X^*;X^*]).")]]

#text("Now we use the fibring identity again, relabeling ")#mi("{Y_1,Y_2}")#text(" as ")#mi("{X_3,X_4}")#text(" and requiring ")#mi("{X_1,X_2,X_3,X_4}")#text(" to be independent copies of ")#mi("{X^*}")#text(". We conclude that")

#tao-aligned(keep: true)[


#tao-math("2d[X^*; X^*]  & = d[X_1+X_2;X_3+Y_4] + d[X_1|X_1+X_2;X_3|X_1+X_4]", block: true)



#tao-math(" & + I[(X_1+X_3, X_2+X_4) : (X_1+X_2,X_3+X_4) | X_1+X_2+X_3+X_4 ].", block: true)
]

#text("As before, the random variables ")#mi("{X_1+X_2}")#text(", ")#mi("{X_3+X_4}")#text(", ")#mi("{X_1|X_1+X_2}")#text(", ")#mi("{X_3|X_3+X_4}")#text(" are all relevant, so from ")#link(<tao-e9e9ba8db7027b0365e7>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("d[X_1+X_2;X_3+X_4], d[X_1|X_1+X_2;X_3|X_1+X_4]")]]

#align(center)[#tao-fit-display[#mitex("\\geq (1-O(\\eta)) d[X^*;X^*].")]]

#text("We could now also match these lower bounds with upper bounds, but the more important takeaway from this analysis is a really good bound on the conditional mutual information:")

#align(center)[#tao-fit-display[#mitex("I[(X_1+X_3, X_2+X_4) : (X_1+X_2,X_3+X_4) | X_1+X_2+X_3+X_4 ]")]]

#align(center)[#tao-fit-display[#mitex("= O(\\eta) d[X^*;X^*].")]]

#text("By the ")#link("https://en.wikipedia.org/wiki/Data_processing_inequality")[#text("data processing inequality")]#text(", we can discard some of the randomness here, and conclude")

#align(center)[#tao-fit-display[#mitex("I[X_1+X_3 : X_1+X_2 | X_1+X_2+X_3+X_4 ] = O(\\eta) d[X^*;X^*].")]]

#text("Let us introduce the random variables")

#align(center)[#tao-fit-display[#mitex("S := X_1+X_2+X_3+X_4; U := X_1+X_2; V = X_1 + X_3")]]

#text("then we have")

#align(center)[#tao-fit-display[#mitex("I[U : V | S] = O(\\eta) d[X^*;X^*].")]]

#text("Intuitively, this means that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are very nearly independent given ")#mi("{S}")#text(". For sake of argument, let us assume that they are ")#emph[#text("actually")]#text(" independent; one can achieve something resembling this by invoking the ")#emph[#text("entropic Balog-Szemerédi-Gowers theorem")]#text(", established in ")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#entropic-bsg")[#text("the blueprint")]#text(", after conceding some losses of ")#mi("{O(\\eta) d[X^*,X^*]}")#text(" in the entropy, but we skip over the details for this blog post. The key point now is that because we are in characteristic ")#mi("{2}")#text(", ")#mi("{U+V}")#text(" has the same form as ")#mi("{U}")#text(" or ")#mi("{V}")#text(":")

#align(center)[#tao-fit-display[#mitex("U + V = X_2 + X_3.")]]

#text("In particular, by permutation symmetry, we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbf H}[U+V|S] ={\\mathbf H}[U|S] ={\\mathbf H}[V|S],")]]

#text("and so by the definition of conditional Ruzsa distance we have a massive distance decrement")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_s d[U|S=s; V|S=s] = 0,")]]

#text("(where ")#mi("{s}")#text(" is drawn from the distribution of ")#mi("{S}")#text("), contradicting ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(1)")]#text(" as desired. (In reality, we end up decreasing the distance not all the way to zero, but instead to ")#mi("{O(\\eta d[X^*,X^*])}")#text(" due to losses in the Balog-Szemerédi-Gowers theorem, but this is still enough to reach a contradiction. The quantity ")#mi("{{\\bf E}_s d[U|S=s; V|S=s]}")#text(" is very similar to ")#mi("{d[U|S; V|S]}")#text(", but is slightly different; the latter quantity is ")#mi("{{\\bf E}_{s,s^{\\prime}}d[U|S=s; V|S=s^{\\prime}]}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" A similar argument works in the ")#mi("{m}")#text("-torsion case for general ")#mi("{m}")#text(". Instead of decrementing the entropic Ruzsa distance, one instead decrements a “multidistance”")

#align(center)[#tao-fit-display[#mitex("{\\mathbf H}[X_1 + \\dots + X_m] - \\frac{1}{m} ({\\mathbf H}[X_1] + \\dots + {\\mathbf H}[X_m])")]]

#text("for independent ")#mi("{X_1,\\dots,X_m}")#text(". By an iterated version of the fibring identity, one can first reduce again to the symmetric case where the random variables are all copies of the same variable ")#mi("{X^*}")#text(". If one then takes ")#mi("{X_{i,j}}")#text(", ")#mi("{i,j=1,\\dots,m}")#text(" to be an array of ")#mi("{m^2}")#text(" copies of ")#mi("{X^*}")#text(", one can get to the point where the row sums ")#mi("{\\sum_i X_{i,j}}")#text(" and the column sums ")#mi("{\\sum_j X_{i,j}}")#text(" have small conditional mutual information with respect to the double sum ")#mi("{S := \\sum_i \\sum_j X_{i,j}}")#text(". If we then set ")#mi("{U := \\sum_i \\sum_j j X_{i,j}}")#text(" and ")#mi("{V := \\sum_i \\sum_j i X_{i,j}}")#text(", the data processing inequality again shows that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are nearly independent given ")#mi("{S}")#text(". The ")#mi("{m}")#text("-torsion now crucially intervenes as before to ensure that ")#mi("{U+V = \\sum_i \\sum_j (i+j) X_{i,j}}")#text(" has the same form as ")#mi("{U}")#text(" or ")#mi("{V}")#text(", leading to a contradiction as before. See ")#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/")[#text("this previous blog post")]#text(" for more discussion.")
]

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2024")])]

#text("Is there a conjectured value for the best exponent ")#mi("C")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2024")])]

#text("By considering Hamming balls, it is known that the best constant ")#mi("C")#text(" for Theorem 1 is at least ")#mi("1.46601\\dots")#text("; see Theorem 1.8 (or Theorem 1.10) of ")#link("https://arxiv.org/abs/math/0703668")[#text("https://arxiv.org/abs/math/0703668")]#text(". In particular the ratio between the best upper and lower bound here is approximately 6. At a recent AIM workshop there was an effort to establish a corresponding lower bound for Theorem 2, but I don’t know what the end result of their calculation was (and whether the ratio is better).")

#text("In the absence of any better construction, one could tentatively conjecture that the Hamming ball counterexamples are in fact the optimal ones, but the evidence for such a conjecture is quite scant at present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2024")])]

#text("(This is Zach Hunter. I worked on this at AIM with Hans Yu.)")

#text("The AIM project suggested that a “continuous Niveau set” was optimal. Specifically, choose ")#mi("p")#text(" so that ")#mi("h(p) = 1/2")#text(" (here ")#mi("h")#text(" is the binary entropy function). Then letting ")#mi("C = 2h(2p(1-p))")#text(" should be optimal for Theorem 2 (this can be achieved in one dimension by considering the distribution which takes one value with probability ")#mi("p")#text(" and the other value with probability ")#mi("1-p")#text("; it can also be achieved in higher dimensions by “tensorizing” the 1-dimensional optimum in various ways (in general it is not clear how to compute things for arbitrary tensorizations, but due to nice properties of the 1-dimensional optimum, lots of things cancel out)). Note that this actually gives a slightly worse constant ")#mi("C \\approx 1.427")#text(", but Theorem 2 is slightly easier (we don’t have have that the subspace is smaller than ")#mi("A")#text(", which affects things).")

#text("There is even a reasonable hope to prove that ")#mi("C")#text(" is the best value here, at least for random variables that behaves like “continuous downsets” (extending the analysis from Terry’s paper with Ben which he linked). We had a moral skeleton of what to do. I’ve been busy writing other papers lately, but hopefully in the next month I will find time to flesh out the skeleton.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685203")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2024")])]

#text("flesh out the skeleton. mwhahahaha")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685208")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2024")])]

#text("Thanks for the update! The best known upper bound for Theorem 2 currently is ")#mi("C=10")#text(" (see Theorem 4 of ")#link("https://arxiv.org/abs/2404.09639")[#text("https://arxiv.org/abs/2404.09639")]#text(") so we now have the curious situation in which the ratio between the best bounds for the entropy version of the theorem, being about 7.04, is actually slightly worse than the best bounds for the combinatorial version, which is about 6.14. This is because the best upper bound of Theorem 1 is not actually derived from the best upper bound of Theorem 2, but by a more technical variant of Theorem 2 that also involves replacing some applications of the Shannon entropy in the quantity to be minimized by the Kullback-Leibler divergence instead to avoid some losses of the doubling constant.")

#text("In any case, it seems like a worthwhile project to understand how entropy and downsets interact, and may help clarify exactly what steps in the entropy argument are still lossy. One thing we noticed while optimizing the constant ")#mi("C")#text(" from our initial value (which was about 500 or so, and very broadly speaking followed lines similar to that outlined in this post) to our final value of 12 was that almost every invocation of the Ruzsa triangle inequality seemed to be inefficient, and a lot of our quantitative gains came from eliminating the use of this inequality as much as possible, for instance by using the Kaimonovich-Vershik-Madiman inequality as a partial substitute (although this one also seems to be a little lossy in the most critical scenarios, for instance it is not sharp in the gaussian case). I suspect that the entropic Balog-Szemeredi-Gowers lemma is the main remaining source of inefficiency, though I don’t know how to avoid using it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685214")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("Sorry, we should have ")#mi("C=(1/4)/(h(2p(1-p))-h(p)) \\approx 1.17")#text(". (I had forgotten how the actual numbers work)")

#text("The point is that ")#mi("p")#text(" is chosen so that ")#mi("d[X;U_H]")#text(" is the same for the two possible subspace ")#mi("H")#text(". This means that ")#mi("H[X]-(1/2)(H[X]+0)= 1-(1/2)(H[X]+1)")#text(". Solving that gives ")#mi("H[X] = h(p)= 1/2")#text(", making the distance to both subspaces ")#mi("1/4")#text(". From there, you compute ")#mi("d[X;X] = h(2p(1-p))-h(p)")#text(", and get ")#mi("C")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2024")])]

#text("“Mathematically ")#emph[#text("his work and insight on pseudorandomness")]#text("“.. can you elaborate on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("The work of Luca that most directly influenced my own thinking was ")#link("https://www.arxiv.org/abs/0806.0381")[#text("his simplified proof")]#text(" (with Tulsiani, Reingold, and Vadhan) of the transference principle of Ben Green and myself (later formalized more explicitly in a paper of Tamar Ziegler and myself), using the min-max theorem from game theory, and using thresholding to manipulate the structured component of a function; these were tools that I was not previously familiar with (though Gowers independently obtained a similar simplification using language more familiar to me, for instance using the Hahn-Banach theorem in place of the min-max theorem). More broadly, through his blog, I learned about other ways of thinking that were standard in TCS (e.g., viewing pseudorandomness as the ability to “fool” various tests for randomness) or theorems in TCS (such as Impagliazzo’s “hard core” theorem) that I was also unaware of.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2024")])]

#text("Is there are application of Marton’s conjecture to information theory? Asking this as she worked on information theory. Is there any motivation from information theory as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685254")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("From what I can tell from ")#link("https://cseweb.ucsd.edu/~slovett/files/addcomb-survey.pdf")[#text("Lovett’s survey")]#text(", Marton was motivated by the “")#link("https://ieeexplore.ieee.org/document/1056022")[#text("two help one")]#text("” problem, in which two people (say Alice and Bob) both possess two long bit strings, and one wants to compute the bitwise XOR of these strings (i.e., the positions in which they differ), to reasonable accuracy, with as little communication as possible. However, I do not know the details of this connection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("Thank you. The paper talks about correlated strings which is a nightmare scenario. For independent strings, I bet the answer is known trivially as joint entropy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2024")])]

#text("This is more of a story. Random coding and the probabilistic method were the default techniques for obtaining tight results in information theory. However, for this problem, Korner and Marton realized that linear codes gave an optimal solution for the doubly symmetric binary source. (There are other p(x,y), with X and Y binary, where one needs to convey both of the sequences effectively to compute the modulo two sum – Exercise in Csiszar and Korner’s book). The fact that they use same linear matrix A at both senders to encode strings bothered them as this was a “structured code” as opposed to a random construction. Marton, always wanted to know whether there were other ways of achieving the optimal result here. At some point, she perhaps believed that any good code must be close enough to a linear code and hence the conjecture was born. This was also one of the primary reasons why she moved away from coding theorems in information theory. This story is partly from Marton herself and from other reliable sources.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685284")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2024")])]

#text("How essential would you say working in $2$-torsion (or $m$-torsion) is here? It’s hard to tell from this whether it is something technical that could be solved without changing the overall strategy or whether it is something more essential.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("Well, one reason is that the form of PFR considered here is simply false in the unbounded torsion setting, which typically has very few finite subgroups. For instance, in the integers ")#mi("{\\bf Z}")#text(", a long arithmetic progression such as ")#mi("\\{1,\\dots,N\\}")#text(" has bounded doubling, but is far from any finite subgroup of ")#mi("{\\bf Z}")#text(" (of which there is only the trivial group ")#mi("\\{0\\}")#text("). In the entropic version of the problem, the key counterexample comes from discrete gaussians spread out over a similarly large arithmetic progression, e.g., a random variable on the integers with probability distribution ")#mi("n \\mapsto \\frac{1}{Z_N} e^{-n^2/N^2}")#text(" for some large ")#mi("N")#text(" and suitable normalizing constant ")#mi("Z_N")#text(" (which is comparable to ")#mi("N")#text("). These gaussians appear to be “local minimizers” of entropic Ruzsa distance: any reasonable operation one does with a gaussian, such as taking the sum of two or more independent copies and conditioning against some other sum, produces another gaussian with essentially the same entropic doubling constant. So any analogue of the “endgame” in the integer setting has to somehow be able to “detect” these gaussians; something resembling an “inverse theorem” to the effect that local minimizers of entropic doubling constants must be “essentially gaussian” would be needed, I think, to allow this approach to PFR to succeed in the integer setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/910228d1619a439a84f8fcdfdb763034b1bfc34d3a7b8abe130863e4ab518c1d-11a4b2b05ac0ef0e7f5eeee19bb913f29bcd32351683433ae135f63492951e62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikko Pitkonen")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685298")[#strong[#text("Mikko Pitkonen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("Is there a way to compute U_H in polynomial time in Theorem 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("It may depend on what one means by “polynomial time”. But assuming that, given a random variable ")#mi("X")#text(" of a certain size and doubling constant, one can “compute” further random variables such as ")#mi("X_1+X_2")#text(" (or ")#mi("X_1+X_2")#text(" conditioned on a value of ")#mi("X_1 + X_2 + X_3 + X_4")#text(") in “polynomial time”, and in particular compute their entropies in “polynomial time” as well, then the proof provides a reasonable algorithm: given a random variable of a doubling constant ")#mi("\\log K")#text(", the argument provides a bounded list of (conditioned) random variables of a form such as the ones indicated above, at least one of which is guaranteed to have a doubling constant less than or equal to ")#mi("(1-\\eta) \\log K")#text(" for some absolute constant ")#mi("\\eta > 0")#text(", and which is relatively close in Ruzsa distance to the original random variable (in particular, the entropy is not that much larger). After computing the entropy of each of these candidates, one then isolates one candidate that does achieve the improvement in the doubling constant, and iterates this procedure about ")#mi("O(\\log\\log K)")#text(" times, until one arrives at a random variable with doubling constant less than ")#mi("\\varepsilon")#text(" for some small absolute constant ")#mi("\\varepsilon")#text(". This is now very close to a uniform distribution on a subgroup ")#mi("H")#text(" and it should be possible to locate ")#mi("H")#text(" in “polynomial time” (but there may be subtleties depending on whether one wants ")#mi("H")#text(" to be described via a membership oracle, or by an explicit list of elements).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/910228d1619a439a84f8fcdfdb763034b1bfc34d3a7b8abe130863e4ab518c1d-11a4b2b05ac0ef0e7f5eeee19bb913f29bcd32351683433ae135f63492951e62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikko Pitkonen")]], [#link("https://terrytao.wordpress.com/2024/06/22/an-abridged-proof-of-martons-conjecture/#comment-685345")[#strong[#text("Mikko Pitkonen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2024")])]

#text("Thank you for your reply, this really clarified things for me. In my application ")#mi("log K = poly(n)")#text(" and I need some kind of lower bound for the circuit complexity. There are some uniform lower bounds for approximating the entropy of a random variable, but I don’t know if computing entropies is necessary for computing ")#mi("U_H")#text(".")
]
]
]
